

# Generated at 2022-06-11 16:52:26.351755
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:52:28.258725
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm = None)
    assert s
    pass

# Generated at 2022-06-11 16:52:37.269331
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    # Mock the TaskQueueManager
    task_queue_manager = TaskQueueManager(
        inventory = None,
        variable_manager = None,
        loader = None,
        options = None,
        passwords = None,
        stdout_callback=None,
        run_additional_callbacks=None,
        run_tree=False,
    )
    # Construct an instance of our class
    result = StrategyModule(task_queue_manager)
    # Check the type of the object
    assert isinstance(result, StrategyModule)


# Generated at 2022-06-11 16:52:40.466663
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("tqm")
    assert strategy_module is not None
    assert strategy_module.get_host_pinned() == True

# Generated at 2022-06-11 16:52:41.261506
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)

# Generated at 2022-06-11 16:52:42.275924
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm._host_pinned == True

# Generated at 2022-06-11 16:52:47.538600
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager("host_pinned")
    test_class = StrategyModule(tqm)

    assert test_class._host_pinned == True

# Generated at 2022-06-11 16:52:50.144294
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   tqm = "test"
   strategy_module = StrategyModule(tqm)
   assert strategy_module.is_pinned

# Generated at 2022-06-11 16:52:51.800783
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule(42)
    assert x._host_pinned



# Generated at 2022-06-11 16:52:54.902411
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "test"
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True


# Generated at 2022-06-11 16:52:57.069048
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None) is not None

# Generated at 2022-06-11 16:52:58.837493
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('test_tqm')
    return True



# Generated at 2022-06-11 16:53:00.651914
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule()
    assert mod._host_pinned == True

# Generated at 2022-06-11 16:53:01.739542
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-11 16:53:03.786062
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert hasattr(strategy, "_host_pinned")
    assert strategy._host_pinned is True

# Generated at 2022-06-11 16:53:06.560710
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print ("Testing constructor of class StrategyModule")
    strategy_module = StrategyModule(tqm = None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:53:09.334153
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"
    assert StrategyModule.__doc__ == "Executes tasks on each host without interruption"
    assert StrategyModule.__module__ == "ansible.plugins.strategy.host_pinned"

# Generated at 2022-06-11 16:53:13.419876
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Unit test for class StrategyModule
    """

    tqm = object

    test_host_pinned = StrategyModule(tqm)
    assert test_host_pinned._host_pinned

# Generated at 2022-06-11 16:53:14.029069
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-11 16:53:17.605135
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a test object
    test_obj = StrategyModule(tqm=None)

    display.display("test_obj._host_pinned = " + str(test_obj._host_pinned))

    assert isinstance(test_obj, StrategyModule)
    assert isinstance(test_obj, FreeStrategyModule)

test_StrategyModule()

# Generated at 2022-06-11 16:53:28.699953
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        acl = StrategyModule(1)
        assert acl.tqm == 1
        assert acl._host_pinned == True
        assert acl._final_q == []
        assert acl._prio_queue == {}
        assert acl._pcount == 0
        assert acl._cur_serial == 0
        assert acl._blocked_hosts == []
        assert acl._workers == []
        assert acl._active_hosts == []
        assert acl._active_workers == []
        assert acl._executing_workers == []
    except AssertionError:
        print("Assertion in Strategy Module failed")

# Generated at 2022-06-11 16:53:32.721605
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module is not None, "Failed to create host_pinned strategy module"
    assert strategy_module._host_pinned, "Failed to set _host_pinned to True"

# Generated at 2022-06-11 16:53:34.790895
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule("tqm")
    # assert isinstance("tqm", StrategyModule)
    assert s._host_pinned == True



# Generated at 2022-06-11 16:53:35.384965
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:53:40.458024
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Method to test StrategyModule
    """
    strategy_module_obj = StrategyModule("tqm")
    assert strategy_module_obj
    assert strategy_module_obj._tqm._final_q
    assert strategy_module_obj._tqm._failed_hosts
    assert strategy_module_obj._tqm._stats
    assert strategy_module_obj._tqm
    assert strategy_module_obj._tqm.inventory
    assert strategy_module_obj._host_pinned

# Generated at 2022-06-11 16:53:41.260259
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)

# Generated at 2022-06-11 16:53:48.272861
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Python 3
    if isinstance(display, Display):
        from ansible.plugins.strategy.host_pinned import StrategyModule

        assert isinstance(StrategyModule(display), StrategyModule), "StrategyModule should return valid class"

    # Python 2
    if (hasattr(display, '__iter__')):
        from ansible.plugins.strategy.host_pinned import StrategyModule

        assert isinstance(StrategyModule(display), StrategyModule), "StrategyModule should return valid class"

# Generated at 2022-06-11 16:53:53.717370
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global display
    class HostPinnedStrategyModule(StrategyModule):
        #Constructor test
        def __init__(self, tqm):
            self.host_pinned = False
    tqm = None
    t = HostPinnedStrategyModule(tqm)
    assert not t.host_pinned, "TEST: Expected HostPinnedStrategyModule.host_pinned == False, got %s" % t.host_pinned


# Generated at 2022-06-11 16:53:56.381778
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
        strategy_obj = StrategyModule(None)
        strategy_obj._host_pinned = True


# Generated at 2022-06-11 16:53:57.909927
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-11 16:54:03.496516
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm=None)
    assert s._host_pinned == True

# Generated at 2022-06-11 16:54:04.480745
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(object())

# Generated at 2022-06-11 16:54:05.026495
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-11 16:54:07.209028
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    host_pinned = sm._host_pinned
    assert host_pinned

# Generated at 2022-06-11 16:54:12.169794
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from mock import Mock
    from ansible.playbook.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager('test', Mock())
    tqm._host_pinned = True
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True


# Generated at 2022-06-11 16:54:14.233710
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_obj = StrategyModule(tqm=None)
    assert strategy_obj._host_pinned == True

# Generated at 2022-06-11 16:54:16.404174
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule('tqm')
    assert s
    assert s._host_pinned == True

# Generated at 2022-06-11 16:54:17.641968
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = None
  StrategyModule(tqm)

# Generated at 2022-06-11 16:54:18.597637
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__()

# Generated at 2022-06-11 16:54:28.027940
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-11 16:54:42.949042
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars.reserved import reserved

    variable_manager = VariableManager()
    loader = DataLoader()
    display

# Generated at 2022-06-11 16:54:44.193859
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-11 16:54:52.074000
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_queue_manager import TaskQueueManager
    from ansible.config.manager import ConfigManager
    from ansible.inventory.manager import InventoryManager

    config_manager = ConfigManager()
    config_manager.set_variable('defaults', 'display_skipped_hosts', False)
    config_manager.set_variable('defaults', 'display_ok_hosts', False)

    inventory_manager = InventoryManager()

    tqm = TaskQueueManager(
        inventory=inventory_manager,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None,
        run_additional_callbacks=True,
        run_tree=False,
    )

    strategy_module = StrategyModule(tqm)
    assert strategy

# Generated at 2022-06-11 16:54:54.241524
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    avm = StrategyModule(tqm)
    assert avm.__str__() == 'FreeStrategyModule(tqm)'

# Generated at 2022-06-11 16:55:00.633824
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
        Unit-test :
            If a strategy plugin strategy is not implemented correctly in constructor and
            we will check by creating two object of class StrategyModule but first object we will create
            without parameter and second object we will create with parameter.
            We expect that it will not raise any Exception. 
    """
    strategy_obj = StrategyModule(None)
    assert strategy_obj._host_pinned is True
    strategy_obj = StrategyModule(25)
    assert strategy_obj._host_pinned is True

# Generated at 2022-06-11 16:55:03.858013
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = unittest.mock.Mock(name='tqm')
    strategy = StrategyModule(tqm)
    assert strategy
    assert isinstance(strategy, StrategyModule)
    assert isinstance(strategy, FreeStrategyModule)
    assert strategy._host_pinned is True



# Generated at 2022-06-11 16:55:04.554580
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:55:05.097910
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:55:10.039203
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test for constructor with parameters
    tqm =  object()
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True
    assert sm._tqm == tqm
    assert sm._display is not None
    assert sm._display._verbosity == 2


# Generated at 2022-06-11 16:55:11.919857
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Test with empty object
    strategy = StrategyModule()


# Generated at 2022-06-11 16:55:39.482067
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import errors
    import unittest

    class TestStrategyModule(unittest.TestCase):
        def setUp(self):
            self.strategy_module = StrategyModule(0)

        def test_strategy_module_with_0_args(self):
            self.assertIsInstance(self.strategy_module, StrategyModule)

        def test_strategy_module_with_1_args(self):
            with self.assertRaises(errors.AnsibleError):
                StrategyModule(1)
    unittest.main()


# Generated at 2022-06-11 16:55:40.250601
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()
    assert obj

# Generated at 2022-06-11 16:55:42.180062
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm is not None

# Generated at 2022-06-11 16:55:43.646926
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = Mock()
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-11 16:55:44.661221
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-11 16:55:47.626650
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned is True
    assert strategy._default_serialization_data == dict()

# Generated at 2022-06-11 16:55:48.298537
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:55:51.825633
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager

    tqm = TaskQueueManager()
    sm = StrategyModule(tqm)

__all__ = []


# Generated at 2022-06-11 16:55:55.458313
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    tqm = object()
    strategy = ansible.plugins.strategy.host_pinned.StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-11 16:55:56.744929
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True

# Generated at 2022-06-11 16:56:34.693692
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    t = TaskQueueManager(None)
    sm = StrategyModule(t)
    assert sm.tqm is t


# Generated at 2022-06-11 16:56:37.709900
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_obj=StrategyModule(None)
    assert strategy_obj._host_pinned == True

# Generated at 2022-06-11 16:56:39.366820
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm = None)

# Generated at 2022-06-11 16:56:40.744176
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule(tqm="tqm")
    assert x._host_pinned == True


# Generated at 2022-06-11 16:56:41.318246
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:56:43.401658
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '__init__')
    assert StrategyModule.__init__.__doc__ is not None

# Generated at 2022-06-11 16:56:48.481372
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # initialize the tqm
    tqm = TaskQueueManager(connection=None, module_name=None, private_data_dir=None, forks=None, close_on_completion=None, stats=None,
        verbosity=None, inventory=None, loader=None, options=None, passwords=None)
    # initialize the strategy module
    strategy_module = StrategyModule(tqm)

    # test the _host_pinned is the same as the class
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:56:51.434637
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.strategy.host_pinned import StrategyModule as HostPinnedStrategyModule
    assert issubclass(HostPinnedStrategyModule, StrategyModule)

# Generated at 2022-06-11 16:56:54.149815
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  import mock
  tqm = mock.MagicMock()
  strategy = StrategyModule(tqm)

  # Testing constructor of StrategyModule
  assert strategy._host_pinned == True

# Generated at 2022-06-11 16:56:55.549363
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   StrategyModule(tqm = "Mock_For_Test")

# Generated at 2022-06-11 16:58:40.416987
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host1 = {
        "name": "localhost",
        "groups": ["ungrouped"],
        "vars": {}
    }
    host2 = {
        "name": "127.0.0.1",
        "groups": ["ungrouped"],
        "vars": {}
    }
    host3 = {
        "name": "google",
        "groups": ["ungrouped"],
        "vars": {}
    }
    host4 = {
        "name": "yahoo",
        "groups": ["ungrouped"],
        "vars": {}
    }
    host5 = {
        "name": "yandex",
        "groups": ["ungrouped"],
        "vars": {}
    }


# Generated at 2022-06-11 16:58:43.665453
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ""
    sm = StrategyModule(tqm)

    assert sm._host_pinned is True
    assert sm._pattern_cache != ""
    assert sm._host_states != ""
    assert sm._play is None

# Generated at 2022-06-11 16:58:47.634950
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy is not None
    assert strategy._host_pinned

# Generated at 2022-06-11 16:58:48.925848
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule()
    assert x._host_pinned is True

# Generated at 2022-06-11 16:58:50.057336
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-11 16:58:50.949713
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    st= StrategyModule("test")

# Generated at 2022-06-11 16:58:52.473137
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    class Class:

        def __init__(self):
            self.host_pinned = True

    StrategyModule(Class())

# Generated at 2022-06-11 16:58:57.942841
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list='localhost')
    tqm = TaskQueueManager(
        inventory=inventory,
        variable_manager=inventory.variable_manager,
        loader=loader,
        options=Options(connection='local'),
        passwords={},
        stdout_callback=DefaultRunnerCallbacks(),
    )
    strategy = StrategyModule(tqm)
    assert(strategy._host_pinned is True)


#TODO: test StrategyModule(tqm)

# Generated at 2022-06-11 16:59:01.762033
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # create a mock tqm object for parameter of constructor
    class Tqm:
        def __init__(self):
            pass
    tqm = Tqm()

    # test the constructor
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-11 16:59:02.534707
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 17:02:20.553922
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO:
    # Check self._host_pinned is set properly
    display.display("Test not implemented")
    assert True

# Generated at 2022-06-11 17:02:22.562955
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule('test')
    assert sm._host_pinned == True


# Generated at 2022-06-11 17:02:23.830922
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-11 17:02:25.629636
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = StrategyModule("tqm")
    assert tqm._host_pinned


    # Unit test for run of class StrategyModule