

# Generated at 2022-06-11 16:52:27.541412
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    b = ansible.plugins.strategy.host_pinned.StrategyModule(tqm)
    assert b._host_pinned == True

# Generated at 2022-06-11 16:52:28.318893
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-11 16:52:32.585865
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Starting execution of the test case")
    obj = StrategyModule(tqm=None)
    assert obj._host_pinned == True

test_StrategyModule()
print("Completion of the test case")

# Generated at 2022-06-11 16:52:34.425724
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=0)
    assert obj._host_pinned

# Generated at 2022-06-11 16:52:35.836316
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	print(StrategyModule.__init__.__doc__)

# Generated at 2022-06-11 16:52:42.054284
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTqm:
        num_workers = 2
        def __init__(self):
            self.inventory = {}
        def get_host_list(self):
            return ['host1', 'host2']

    test_tqm = TestTqm()
    test_strategy_obj = StrategyModule(test_tqm)
    assert test_strategy_obj._host_pinned

# Generated at 2022-06-11 16:52:42.857445
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:52:46.883802
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = object()
  strategyModule = StrategyModule(tqm)
  assert strategyModule._host_pinned == True


# Generated at 2022-06-11 16:52:49.348823
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("test_tqm")
    assert strategy_module._host_pinned is True

# Generated at 2022-06-11 16:52:50.318948
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-11 16:52:55.739971
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    m = StrategyModule(1)
    assert m.__class__.__name__ == 'StrategyModule'
    assert m._host_pinned is True
    assert m._last_hosts is []
    assert m._batch_num is 0


# Generated at 2022-06-11 16:52:56.605612
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:52:57.215826
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:53:04.240966
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import os

    class TestStrategyModule(unittest.TestCase):

        def setUp(self):
            import time
            import ansible.playbook.play
            import ansible.playbook.play_context
            import ansible.playbook.task
            from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

            self._start_time = time.time()
            class MockPlaybook(object):
                pass

            class MockTask(object):
                pass

            class MockPlay(object):
                pass

            self._playbook = MockPlaybook()
            self._play = MockPlay()

            self._play.connection = 'smart'

# Generated at 2022-06-11 16:53:05.406509
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm())

# Generated at 2022-06-11 16:53:09.632483
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_display = Display()
    my_tqm = {"display": my_display}
    free_strat_module = FreeStrategyModule(my_tqm)
    my_strat_module = StrategyModule(my_tqm)

    assert my_strat_module._host_pinned == True

# Generated at 2022-06-11 16:53:17.561334
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    from test.unit.plugins.strategy.test_free import tqm

    class TestStrategyModule(unittest.TestCase):

        def setUp(self):
            self.strategy_module = StrategyModule(tqm)

        def test_strategy_module(self):
            self.assertEqual(self.strategy_module._host_pinned, True)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestStrategyModule)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-11 16:53:20.281900
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule

    StrategyModule("test_tqm")

# Generated at 2022-06-11 16:53:22.291791
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_object = StrategyModule.__init__(tqm)
    assert my_object._host_pinned is True

# Generated at 2022-06-11 16:53:24.682663
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm = None)
    assert obj is not None

# Unit tests for methods of class StrategyModule

# Generated at 2022-06-11 16:53:28.397717
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    tqm = None
    StrategyModule(tqm)
    assert True

# Generated at 2022-06-11 16:53:32.020286
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_display = Display()
    test_tqm = dict()
    test_StrategyModule = StrategyModule(test_tqm)
    assert test_StrategyModule._host_pinned == True

# Generated at 2022-06-11 16:53:33.111846
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-11 16:53:39.374984
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Tests if the correct parent class is initialized
    import mock
    mock_class = mock.create_autospec(object)
    mock_class.return_value = None
    with mock.patch('ansible.plugins.strategy.host_pinned.FreeStrategyModule', mock_class):
        from ansible.plugins.strategy.host_pinned import StrategyModule
        tqm = None
        strategy_module = StrategyModule(tqm)
        assert mock_class.assert_called

    # Tests if _host_pinned is set correctly
    assert strategy_module._host_pinned

# Generated at 2022-06-11 16:53:40.841041
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    p=StrategyModule(None)
    assert p._host_pinned == True

# Generated at 2022-06-11 16:53:41.340746
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-11 16:53:43.606979
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule(None)
    print(strategyModule.__class__.__name__)
    print(strategyModule._host_pinned)

# Generated at 2022-06-11 16:53:45.009410
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm = None)

# Generated at 2022-06-11 16:53:54.900107
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-11 16:54:02.014672
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   test_tqm = StrategyModule
   assert test_tqm.__name__ == 'StrategyModule'

# Generated at 2022-06-11 16:54:17.361816
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import pytest
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy import StrategyBase
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    from ansible.playbook.play import Play

    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch, MagicMock, call
    from ansible_collections.ansible.community.tests.unit.config import _base_parser_args


# Generated at 2022-06-11 16:54:18.191706
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Generated at 2022-06-11 16:54:19.949917
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule((1,))
    assert type(tqm) == FreeStrategyModule

# Generated at 2022-06-11 16:54:21.073131
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)

# Generated at 2022-06-11 16:54:23.116374
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'default ansible Play() strategy plugin'

# Generated at 2022-06-11 16:54:24.410965
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert s._host_pinned == True

# Generated at 2022-06-11 16:54:26.717167
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule({'val': 1})
    assert strategy_module._host_pinned == True
    assert strategy_module._tqm == {'val': 1}

# Generated at 2022-06-11 16:54:27.619807
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('tqm')

# Generated at 2022-06-11 16:54:29.068493
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-11 16:54:30.117074
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-11 16:54:40.933538
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task_queue_manager = 1 # stub object
    strategy_module = StrategyModule(task_queue_manager)
    assert(strategy_module._host_pinned is True)

# Generated at 2022-06-11 16:54:49.503369
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule, object)
    assert issubclass(StrategyModule, FreeStrategyModule)
    assert hasattr(StrategyModule, '__init__')
    assert callable(StrategyModule.__init__)
    assert hasattr(StrategyModule, '_host_pinned')
    assert hasattr(StrategyModule, '__doc__')
    assert hasattr(StrategyModule, '__name__')
    assert callable(StrategyModule)

    # Run StrategyModule constructor test
    print("Now running StrategyModule constructor test...")
    strategy_module = StrategyModule(tqm=1)
    assert strategy_module._host_pinned is True

# Generated at 2022-06-11 16:54:51.480886
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm)
    assert obj._host_pinned == True

# Generated at 2022-06-11 16:54:52.053915
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:54:53.548849
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    t = StrategyModule()
    
    assert t is not None

# Generated at 2022-06-11 16:54:58.821022
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule

    tqm = mock.MagicMock()
    strategy = StrategyModule(tqm)

    assert strategy._host_pinned
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-11 16:54:59.722038
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-11 16:55:00.717993
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    stm = StrategyModule()
    assert stm._host_pinned is True


# Generated at 2022-06-11 16:55:02.429969
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule(False)
    assert mod._host_pinned == True
    assert isinstance(mod._display, Display)

# Generated at 2022-06-11 16:55:04.702756
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ''
    StrategyModule(tqm)

# Generated at 2022-06-11 16:55:26.365931
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-11 16:55:29.455367
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    strategy = ansible.plugins.strategy.host_pinned.StrategyModule(None)
    assert type(strategy.get_name()) is str
    assert type(strategy.get_description()) is str

# Generated at 2022-06-11 16:55:30.260938
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:55:30.921953
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-11 16:55:33.073992
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_instance = StrategyModule(tqm)
    assert strategy_instance._host_pinned == True

# Generated at 2022-06-11 16:55:35.080144
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  temp = StrategyModule(tqm)
  assert temp is not None
  assert temp._host_pinned is True

# Generated at 2022-06-11 16:55:37.499909
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("BEGIN test_StrategyModule")
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned is True
    print("END test_StrategyModule")

# Generated at 2022-06-11 16:55:40.105581
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a mock display instance
    disp = Display()
    # Call constructor of StrategyModule()
    sm = StrategyModule(disp)
    # Call variable used in constructor
    # print(sm)
    sm._host_pinned

# Generated at 2022-06-11 16:55:42.066612
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    assert(StrategyModule(tqm)._host_pinned)

# Generated at 2022-06-11 16:55:42.863593
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()
    pass

# Generated at 2022-06-11 16:56:22.912481
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-11 16:56:23.517764
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-11 16:56:31.562967
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import ansible
    tqm = ansible.executor.task_queue_manager.TaskQueueManager(inventory=None, variable_manager=None, loader=None, options=None, passwords=None, stdout_callback=None)
    return_value = ansible.plugins.strategy.host_pinned.StrategyModule(tqm)
    assert return_value is not None, 'return value is none'
    assert return_value._host_pinned is True, 'return value._host_pinned is'
    assert return_value._host_pinned is True, 'return value._host_pinned is not True'
    return_value._host_pinned = False
    assert return_value._host_pinned is False, 'return value._host_pinned is not False'

# Generated at 2022-06-11 16:56:33.426784
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ This is the constructor test case for StrategyModule class
    """
    assert 'Ansible' in DOCUMENTATION

# Generated at 2022-06-11 16:56:37.603635
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = type('test', (object,), {'host_list': None})
    tqm.host_list = type('test', (object,), {'get_hosts': None})
    test_self = StrategyModule(tqm)
    assert test_self._host_pinned == True

# Generated at 2022-06-11 16:56:38.438349
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:56:39.430636
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-11 16:56:41.134426
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned is True

# Generated at 2022-06-11 16:56:43.948009
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    def __init__(self, tqm):
        super(StrategyModule, self).__init__(tqm)
        self._host_pinned = True

# Generated at 2022-06-11 16:56:45.129570
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test = StrategyModule(None)
    assert test._host_pinned

# Generated at 2022-06-11 16:58:23.247713
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    swm = StrategyModule(None)
    assert(swm._host_pinned)

# Generated at 2022-06-11 16:58:30.117380
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_names = ['host1', 'host2']
    task_queue_manager = dict()
    task_queue_manager['host_names'] = host_names
    task_queue_manager['_tqm_variables'] = dict()
    task_queue_manager['stats'] = dict()
    task_queue_manager['callback_queue'] = dict()
    task_queue_manager['result_q'] = dict()
    strategy_module = StrategyModule(task_queue_manager)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:58:31.519679
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule("tqm")

# Generated at 2022-06-11 16:58:40.863814
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.verbosity = 3
    my_strategy = StrategyModule('tqm')
    assert my_strategy != None
    assert my_strategy.name == "host_pinned"
    assert my_strategy.host_pinned == True
    assert my_strategy.get_host_list() == []
    assert my_strategy.get_failed_hosts() == []
    assert my_strategy.get_unreachable_hosts() == []
    assert my_strategy.get_changed_hosts() == []
    assert my_strategy.get_dark_hosts() == []
    assert my_strategy.get_all_hosts_by_task() == []

    # test run()
    # my_strategy.run()

# Generated at 2022-06-11 16:58:50.714049
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import lib.ansible_modlib.plugins.strategies.host_pinned as my_strategy_module
    my_strategy_module.display.verbosity = 3
    my_strategy_module.display.color = 'never'

    my_tqm = {}
    my_strategy_module.StrategyModule(my_tqm)

    print("Unit test result success")

# Test by running
# ansible-playbook --forks=2 --subset=hosts test/host_pinned.yaml
# ansible-playbook --forks=8 --subset=hosts test/host_pinned.yaml

# Generated at 2022-06-11 16:58:51.882780
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    StrategyModule(tqm)

# Generated at 2022-06-11 16:58:53.667205
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule("Ansible")
    assert module.get_host_pinned() is True, "Host_pinned fails"

# Generated at 2022-06-11 16:58:55.708386
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = {
    'tqm': {
      'tasks': 'tasks'
    }
  }
  t = StrategyModule(tqm)
  assert t._host_pinned == True

# Generated at 2022-06-11 16:58:56.893779
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: implement unit test
    assert True

# Generated at 2022-06-11 16:58:58.912187
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-11 17:02:22.268955
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module

# Generated at 2022-06-11 17:02:23.915340
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
     module = StrategyModule(tqm="tqm")
     assert module