

# Generated at 2022-06-11 16:52:23.678960
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:52:29.337584
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = dict()
        strategy_object = StrategyModule(tqm)
        assert strategy_object.__class__.__base__ == FreeStrategyModule
        assert strategy_object._host_pinned ==  True
    except Exception:
        assert False, "Strategy Module constructor test failed"

# Unit test to check whether use_tree is set to true when tree is used

# Generated at 2022-06-11 16:52:31.305325
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)
    assert not StrategyModule(tqm=None)._host_pinned


# Generated at 2022-06-11 16:52:32.449235
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:52:33.098083
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:52:36.351793
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager

    tqm = TaskQueueManager(None, None)

    assert isinstance(StrategyModule(tqm), StrategyModule)

# Generated at 2022-06-11 16:52:38.790306
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj_1 = StrategyModule([])
    assert isinstance(obj_1, StrategyModule)

# Generated at 2022-06-11 16:52:41.982763
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('tqm')
    assert StrategyModule.__name__ == 'StrategyModule'
    assert strategy_module.__class__.__name__ == 'StrategyModule'
    assert strategy_module._host_pinned

# Generated at 2022-06-11 16:52:47.659373
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTqm(object):
        pass
    tqm = TestTqm()
    test_strategy = StrategyModule(tqm)
    assert test_strategy._host_pinned == True

# vim: foldmethod=marker: filetype=yaml

# Generated at 2022-06-11 16:52:49.561934
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule

    strategy = StrategyModule(None)
    assert strategy._host_pinned

test_StrategyModule()

# Generated at 2022-06-11 16:52:51.682998
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy

# Generated at 2022-06-11 16:52:53.430935
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''

# Generated at 2022-06-11 16:52:55.056090
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)
    assert strategy == StrategyModule

# Generated at 2022-06-11 16:52:57.978285
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy = StrategyModule(tqm)
    # Test StrategyModule.__init__ by calling StrategyModule._display
    strategy._display()



# Generated at 2022-06-11 16:52:58.653009
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:53:06.905774
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible import context
    from ansible.executor.task_queue_manager import TaskQueueManager
    options = context.CLIOptions({})
    tqm = TaskQueueManager(
        inventory=dict(),
        variable_manager=dict(),
        loader=dict(),
        options=options,
        passwords=dict(),
        stdout_callback=dict(),
    )
    strategy_object = StrategyModule(tqm)
    assert strategy_object._host_pinned is True


# Generated at 2022-06-11 16:53:12.378938
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned as strategy
    assert strategy.StrategyModule.__bases__[0].__name__ == 'FreeStrategyModule'
    assert strategy.StrategyModule.get_host_only.__func__ == FreeStrategyModule.get_host_only.__func__

# Test the update_current_task() method

# Generated at 2022-06-11 16:53:12.992993
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-11 16:53:13.694634
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   pass

# Generated at 2022-06-11 16:53:15.588604
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 1
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True


# Generated at 2022-06-11 16:53:23.743269
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    import ansible.plugins.loader as plugins
    loader = plugins.ModuleLoader()
    module = plugins.get_strategy_plugin(loader, 'host_pinned')
    assert isinstance(module, StrategyModule), 'expected %s but got %s' % (type(StrategyModule), type(module))

# Generated at 2022-06-11 16:53:24.734699
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-11 16:53:28.145768
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert(s is not None)
    assert(hasattr(s, '_host_pinned'))
    assert(s._host_pinned == True)

# Generated at 2022-06-11 16:53:32.174379
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Creating object of class StrategyModule")
    obj = StrategyModule("display object")
    print("Object created successfully")

if __name__ == '__main__':
    test_StrategyModule()
    print("StrategyModule is tested successfully")

# Generated at 2022-06-11 16:53:37.150909
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.strategy.host_pinned import StrategyModule as HostPinned
    t = StrategyModule([])
    assert isinstance(t, StrategyModule)
    assert not isinstance(t, HostPinned)
    h = HostPinned([])
    assert isinstance(h, StrategyModule)
    assert isinstance(h, HostPinned)

# Generated at 2022-06-11 16:53:38.313468
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned

# Generated at 2022-06-11 16:53:40.094405
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule.__doc__ == FreeStrategyModule.__doc__)

# Generated at 2022-06-11 16:53:41.530124
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = StrategyModule()
    assert tqm._host_pinned == True

# Generated at 2022-06-11 16:53:44.579434
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)
    assert issubclass(StrategyModule, FreeStrategyModule)
    assert StrategyModule.__name__ == "StrategyModule"

# Generated at 2022-06-11 16:53:46.788128
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    ans = StrategyModule(tqm)
    assert ans is not None

# Generated at 2022-06-11 16:53:51.827480
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm)
    assert module._host_pinned

# Generated at 2022-06-11 16:53:52.545242
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:53:53.095062
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-11 16:53:54.333711
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  strategy_module = StrategyModule(tqm)
  assert True


# Generated at 2022-06-11 16:53:56.382073
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm = None)

# Generated at 2022-06-11 16:53:59.141610
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result = StrategyModule.__init__(StrategyModule)
    assert result == None


# Generated at 2022-06-11 16:54:04.992789
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Instantiate object of class MockTQM and assign it to variable tqm.
    tqm = MockTQM(MockOptions(None, None))

    # Instantiate object of class StrategyModule with parameter tqm.
    sm = StrategyModule(tqm)

    # Assert that the attribute host_pinned of object of class StrategyModule is True.
    assert sm._host_pinned



# Generated at 2022-06-11 16:54:06.388704
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm)
    assert obj._host_pinned == True

# Generated at 2022-06-11 16:54:07.858372
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Constructor of class StrategyModule
    StrategyModule(None)


# Generated at 2022-06-11 16:54:09.093043
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()
    assert obj is not None

# Generated at 2022-06-11 16:54:19.645951
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    print(strategy_module._host_pinned)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-11 16:54:26.174761
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module=StrategyModule("tqm")
    print(strategy_module._name)
    print(strategy_module._tqm)
    print(strategy_module._display)
    print(strategy_module._display._verbosity)
    print(strategy_module._display._play)
    print(strategy_module._display._task)
    print(strategy_module._display._no_log)
    print(strategy_module._host_pinned)

# unit test for run function of class StrategyModule

# Generated at 2022-06-11 16:54:27.454419
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(1)
    assert obj._host_pinned


# Generated at 2022-06-11 16:54:29.693029
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None

    mm = FreeStrategyModule(tqm)
    assert mm._host_pinned == False

    hm = StrategyModule(tqm)
    assert hm._host_pinned == True

# Generated at 2022-06-11 16:54:31.906445
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule(tqm)
    assert tqm._host_pinned == True

# Generated at 2022-06-11 16:54:33.205011
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(object)

# Generated at 2022-06-11 16:54:34.783535
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__  == "StrategyModule"


# Generated at 2022-06-11 16:54:42.660725
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    # Create temporary directories to save tasks, unsuccessful and successful results of Ansible tasks
    import tempfile
    import shutil
    temp_dir = tempfile.mkdtemp()

    # Create object of TaskQueueManager class
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None,
        run_additional_callbacks=False,
        run_tree=False,
    )

    s = StrategyModule(tqm)

    # Check if object of TaskQueueManager class is created
    assert isinstance(s, StrategyModule)

    # Remove the temporary directory created
    shutil.rmtree(temp_dir)

# Generated at 2022-06-11 16:54:45.704504
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {"something": "something"}
    strat = StrategyModule(tqm)
    assert tqm==strat._tqm
    assert strat._host_pinned == True

# Generated at 2022-06-11 16:54:47.011777
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned

# Generated at 2022-06-11 16:55:07.841391
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm=None)
    assert (sm._host_pinned == True)

# Generated at 2022-06-11 16:55:10.290496
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    FreeStrategyModule.__init__('tqm')
    StrategyModule.__init__('tqm')

test_StrategyModule()

# Generated at 2022-06-11 16:55:13.213291
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert(isinstance(strategy_module, StrategyModule))
# assert(strategy_module._host_pinned == True)

display.debug('in strategy_host_pinned')

# Generated at 2022-06-11 16:55:14.075460
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-11 16:55:16.810489
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_StrategyModule = StrategyModule(1)
    assert test_StrategyModule._host_pinned


# Generated at 2022-06-11 16:55:17.325788
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:55:18.687467
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm = 'tqm')
    assert (s._host_pinned == True)

# Generated at 2022-06-11 16:55:20.054507
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule("tqm") is not None


# Generated at 2022-06-11 16:55:22.850130
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Unit test to check if Strategy pattern is implemented in __init__ method

# Generated at 2022-06-11 16:55:24.053132
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('tqm')

# Generated at 2022-06-11 16:56:14.928379
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    class MockConnection:
        def __init__(self, host, port=2121):
            self.host = host
            self.port = port

    class MockPlay:
        def __init__(self, name="", connection=None, hosts=[]):
            self.name = name
            self.hosts = hosts
            self.connection = connection
            self.vars = dict()
            self.vars['hosts'] = hosts
            self.vars['host'] = host
            self.vars['name'] = name

    host = MockConnection('localhost')
    play = MockPlay(hosts=[host])
    tqm = TaskQueueManager(None, None, [play], None, None, None, None, None, None, None)
    t

# Generated at 2022-06-11 16:56:17.067754
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:56:17.657783
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:56:25.901012
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.plugins.strategy.host_pinned import StrategyModule

    options = dict(
        connection='local',
        module_path=['/to/mymodules'],
        forks=10,
        become=None,
        become_method=None,
        become_user=None,
        check=False,
        diff=False
    )

    loader = DataLoader()
    passwords = dict()


# Generated at 2022-06-11 16:56:26.703693
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule({})
    assert strategy._host_pinned

# Generated at 2022-06-11 16:56:35.225945
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {'_inventory': 'inv',
       '_loader': 'ldr',
       '_variable_manager': 'mgr',
       '_all_hosts': 'hosts',
       '_subset': 'sub',
       '_options': 'opts',
       '_final_q': 'queue',
       '_initial_q': 'init_queue',
       '_workers': 'workers'}
    sm = StrategyModule(tqm)
    ret = sm._get_serialized_groups()
    assert ret == []

# Generated at 2022-06-11 16:56:39.607942
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module=StrategyModule(tqm)
    equallity=strategy_module._host_pinned
    assert equallity == True


# Generated at 2022-06-11 16:56:48.640781
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook import Playbook
    from unit.plugins.test.test_strategy import fake_loader
    from unit.plugins.test.test_strategy import fake_playbook
    from unit.plugins.test.test_strategy import fake_playbook_basedir

# Generated at 2022-06-11 16:56:57.238817
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    from ansible.utils.display import Display
    from ansible.utils.plugins import get_all_plugin_loaders
    from ansible.plugins.loader import strategy_loader

    display = Display()
    all_plugin_loaders = get_all_plugin_loaders()
    strategy_plugin_loader = all_plugin_loaders[strategy_loader]
    for plugin_name in strategy_plugin_loader.all(class_only=True):
        print("    testing strategy_module={}".format(plugin_name))
        strategy_module = strategy_plugin_loader.get(plugin_name, class_only=True)

# Generated at 2022-06-11 16:57:06.596988
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    class DummyOptions():
        pass
    class DummyQueue():
        pass
    opts = DummyOptions()
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=opts,
        passwords=None,
        stdout_callback=None,
        run_additional_callbacks=None,
        run_tree=False,
        parallel_plugins=None,
        deprecated_plugins=None,
        display=None,
        )
    sm = StrategyModule(tqm)

# Generated at 2022-06-11 16:58:54.518685
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy import Action
    from ansible.plugins.strategy import StrategyBase
    from ansible.plugins.strategy import display

    class Tqm:
        def __init__(self):
            self.stats = Stats()
            self.host_list = HostList()
            self.workers = 0
            self.notified_handlers = defaultdict(list)
            self.failed_hosts = defaultdict(list)
            self.unreachable_hosts = defaultdict(list)
            self.callback_loader = None


    tqm = Tqm()
    mydisplay = display.Display()
    assert isinstance(mydisplay, display.Display)


# Generated at 2022-06-11 16:58:59.991057
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Tqm(object):
        def __init__(self):
            self.stats = None
        def get_failed_hosts(self):
            return {}
        def get_host_pinned(self):
            return {}
        def get_tasks_done(self):
            return set()
        def get_hosts_remaining(self):
            return set()
        def remove_host(self, host):
            return None
        def add_host(self, host):
            return None

    tqm = Tqm()
    strategy = StrategyModule(tqm)
    assert strategy is not None
    assert hasattr(strategy, 'host_pinned')

# Generated at 2022-06-11 16:59:04.192501
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.debug("Testing StrategyModule constructor")
    # Arrange
    tqm = "test"
    display.debug("Test case: Host pinned strategy, init")
    # Act
    strategy_module = StrategyModule(tqm)
    # Assert
    assert strategy_module is not None

# Generated at 2022-06-11 16:59:05.347888
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-11 16:59:14.279556
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import Play
    from ansible.executor import task_queue_manager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import vars_loader, lookup_loader, filter_loader
    pb = Play()
    dl = DataLoader()
    tqm = task_queue_manager.TaskQueueManager(
        inventory=Inventory(dl, { "hosts": "all" }),
        variable_manager=VariableManager(),
        loader=dl,
        options=pb.options,
        passwords={},
        stdout_callback=None
        )
    strategy = StrategyModule(tqm)
    host_pinned = strategy._host_pinned
   

# Generated at 2022-06-11 16:59:15.092592
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__

# Generated at 2022-06-11 16:59:16.168663
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = None
  strategy = StrategyModule(tqm)

# Generated at 2022-06-11 16:59:18.010426
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ob = StrategyModule(tqm = 'ansible_tqm')
    assert ob._host_pinned == True
    assert ob._tqm == 'ansible_tqm'

# Generated at 2022-06-11 16:59:20.235402
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    instance = StrategyModule(tqm)
    assert instance._host_pinned is True, 'instance._host_pinned must be True'

# Generated at 2022-06-11 16:59:23.012387
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # test calling superclass with StrategyModule and test value returned.
    temp1 = StrategyModule()

    # test object attributes of base class and test value returned.
    temp2 = temp1.__init__()
    print(temp1, temp2)