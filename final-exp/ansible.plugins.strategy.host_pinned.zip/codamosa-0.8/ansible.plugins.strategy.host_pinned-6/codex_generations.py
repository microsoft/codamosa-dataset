

# Generated at 2022-06-11 16:52:28.028796
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-11 16:52:28.955065
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)


# Generated at 2022-06-11 16:52:30.879354
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule(tqm = None)
    assert mod._host_pinned == True

# Generated at 2022-06-11 16:52:32.447395
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  sm = StrategyModule(None)
  assert sm != None

# Generated at 2022-06-11 16:52:36.835568
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    task_queue_manager = TaskQueueManager(
        inventory=None, variable_manager=None, loader=None, options=None, passwords=None, stdout_callback=None)
    StrategyModule(tqm=task_queue_manager)

# Generated at 2022-06-11 16:52:40.243242
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = StrategyModule
    tqm = StrategyModule(test_tqm)
    tqm.get_host_list()

# Generated at 2022-06-11 16:52:41.338133
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned

# Generated at 2022-06-11 16:52:47.065851
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test constructor
    obj = StrategyModule(tqm='tqm')
    assert obj is not None
    assert hasattr(obj, '_host_pinned') is True
    assert obj._host_pinned is True


# Generated at 2022-06-11 16:52:48.502952
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)

# Generated at 2022-06-11 16:52:51.264780
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    test = StrategyModule(tqm)
    assert test._host_pinned == True
    assert test._display._verbosity > 0

# Generated at 2022-06-11 16:52:53.280231
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)

# Generated at 2022-06-11 16:52:56.811731
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = [object]
    strategy = StrategyModule(tqm)
    assert strategy
    assert strategy._host_pinned == True

# Use the Free strategy module as a base to test how the new constructor works

# Generated at 2022-06-11 16:52:59.303538
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert (StrategyModule.__name__.__eq__('StrategyModule'))

# Generated at 2022-06-11 16:53:00.607298
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule.__init__('tqm')

# Generated at 2022-06-11 16:53:02.048870
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule constructor")
    assert StrategyModule(tqm='tqm')

# Generated at 2022-06-11 16:53:04.109567
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    sm = StrategyModule("Test")
    assert sm._host_pinned == True

# Generated at 2022-06-11 16:53:13.457150
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\nChecking constructor of class StrategyModule...")
    if __name__ == "__main__":
        from ansible.executor.task_queue_manager import TaskQueueManager
        from ansible.parsing.dataloader import DataLoader
        from ansible.vars import VariableManager
        from ansible.inventory import Inventory
        options = None
        loader = DataLoader()
        variable_manager = VariableManager()
        inventory = Inventory(loader=loader, variable_manager=variable_manager)
        tqm = TaskQueueManager(inventory=inventory, variable_manager=variable_manager, loader=loader, options=options,
                               stdout_callback="default", use_task_cache=False,
                               run_additional_callbacks=False, run_tree=False)
        strategyModule = StrategyModule(tqm)

# Generated at 2022-06-11 16:53:14.435566
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm='')

# Generated at 2022-06-11 16:53:15.357750
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-11 16:53:16.184253
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-11 16:53:27.533919
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy.host_pinned import FreeStrategyModule
    tqm = mock.MagicMock()
    tqm.options = mock.MagicMock()
    tqm.options.verbosity = 1
    strategy = StrategyModule(tqm)

    assert isinstance(strategy, FreeStrategyModule), "StrategyModule should be instance of FreeStrategyModule"
    assert strategy._host_pinned is True, "Host pinned should be True"
    assert strategy._host_pinned is not None, "Host pinned should not be None"

# Generated at 2022-06-11 16:53:28.649996
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None


# Generated at 2022-06-11 16:53:32.721413
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    with patch(TaskQueueManager, '__init__'):
        StrategyModule(TaskQueueManager())

# Generated at 2022-06-11 16:53:33.371976
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Constructor of class StrategyModule - testing with valid args
    assert StrategyModule('foo') is not None


# Generated at 2022-06-11 16:53:34.315439
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm = None)

# Generated at 2022-06-11 16:53:35.593131
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "TQM"
    StrategyModule(tqm)

# Generated at 2022-06-11 16:53:36.713796
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm='tqm')
    

# Generated at 2022-06-11 16:53:37.240127
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:53:38.286415
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True
    return True

# Generated at 2022-06-11 16:53:40.053470
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned

# Generated at 2022-06-11 16:53:48.272952
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create a StrategyModule object
    a = StrategyModule(None)
    # check if the object is correctly created
    assert a._host_pinned == True
    assert a._is_multiprocessing == False
    assert a._inventory == None
    assert a._variable_manager == None

# Generated at 2022-06-11 16:53:54.025810
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.utils.display import Display
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule

    display = Display()
    try:
        sm = StrategyModule(display)
    except Exception as ex:
        if not isinstance(ex, TypeError):
            raise ex
        sm = StrategyModule()

    assert isinstance(sm, StrategyModule)
    assert isinstance(sm, FreeStrategyModule)


# Generated at 2022-06-11 16:53:54.566316
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-11 16:53:56.856316
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-11 16:53:58.346489
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule != None



# Generated at 2022-06-11 16:54:01.561248
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    TQM = 'TQM'
    strategy_module = StrategyModule(TQM)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:54:08.279868
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule

    tqm = True

    try:
        strategy_module = StrategyModule(tqm)
    except Exception as err:
        print("Error in StrategyModule() " + str(err))
        raise

    # Check the name of the current strategy
    assert strategy_module._name == 'host_pinned'
    # Check the constructor of the parent class
    assert isinstance(strategy_module, StrategyModule)
    # Check the return value of _host_pinned  is True
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:54:10.300845
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MockTQM()
    StrategyModule(tqm)


# Generated at 2022-06-11 16:54:11.663957
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule, object)

# Generated at 2022-06-11 16:54:12.331134
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-11 16:54:23.739798
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a StrategyModule object
    sm = StrategyModule(tqm)
    # Check if StrategyModule object is created
    if isinstance(sm, StrategyModule):
        print("StrategyModule object created")
    else:
        print("StrategyModule object not created")


# Generated at 2022-06-11 16:54:27.444183
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestModule:
        class Display:
            __name__ = 'Display'
    class TestTQM:
        class Display:
            __name__ = 'Display'
        def __init__(self, check=False, diff=False, tags=None, vault_password=None, extra_vars=None, subset=None, inventory=None, private_key_file=None, forks=5, module_path=None, connection_user=None, connection_port=22, remote_user=None, remote_pass=None, remote_port=None, private_key_file=None, syntax=None, module_path=None, only_tags=None, skip_tags=None, inventory=None, listhosts=None, subset=None, module_vars=None):
            self.inventory = 'inventory'

# Generated at 2022-06-11 16:54:29.639617
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    assert obj._host_pinned == True

# Generated at 2022-06-11 16:54:30.465879
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-11 16:54:31.674049
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-11 16:54:33.714753
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''


# Test class StrategyModule

# Generated at 2022-06-11 16:54:36.657058
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'


# Generated at 2022-06-11 16:54:37.573198
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 16:54:38.862001
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-11 16:54:44.450976
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Test if StrategyModule constructor works as expected
    '''
    ## tqm = TaskQueueManager()
    tqm = object()
    strategyModule = StrategyModule(tqm)
    assert strategyModule._tqm == tqm
    assert strategyModule._host_pinned



# Generated at 2022-06-11 16:55:04.834680
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    try:
        StrategyModule.__init__
        assert True
    except AttributeError:
        assert False


# Generated at 2022-06-11 16:55:07.108044
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert(strategy._host_pinned == True)


# Generated at 2022-06-11 16:55:08.055360
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule, object)

# Generated at 2022-06-11 16:55:09.828336
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass
# vim: set noexpandtab ts=4 sw=4:

# Generated at 2022-06-11 16:55:11.720486
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule("tqm")
    assert obj._host_pinned == True

# Generated at 2022-06-11 16:55:15.102725
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # create test object
    s = StrategyModule(None)
    assert isinstance(s, StrategyModule)
    assert s._host_pinned is True
    assert s.name == 'host_pinned'

# Generated at 2022-06-11 16:55:16.634405
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    q = []
    w = StrategyModule(q)
    assert w._host_pinned == True
    assert w._tqm == q
    assert w._stats is not None

# Generated at 2022-06-11 16:55:17.792948
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:55:18.595823
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:55:29.834752
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Testing constructor of class StrategyModule"""
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars

    basedir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    test_loader = DataLoader()


# Generated at 2022-06-11 16:56:16.447123
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  strategy_module = StrategyModule(tqm=tqm)
  assert str(strategy_module) == '<ansible.plugins.strategy.host_pinned.StrategyModule object at 0x7fa9bdf0e588>'
  assert strategy_module.get_host_pinned() == True

# Generated at 2022-06-11 16:56:17.962931
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_obj = StrategyModule()
    assert strategy_obj._host_pinned == True

# Generated at 2022-06-11 16:56:20.184693
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test with mock object
    def fake_host():
        return 'fake_host'
    tqm = fake_host
    StrategyModule(tqm)

# Generated at 2022-06-11 16:56:28.766151
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from collections import namedtuple
    from ansible.utils.display import Display
    display = Display()
    Options = namedtuple('Options', ['listtags', 'listtasks', 'listhosts', 'syntax', 'connection','module_path', 'forks', 'remote_user', 'private_key_file', 'ssh_common_args', 'ssh_extra_args', 'sftp_extra_args', 'scp_extra_args', 'become', 'become_method', 'become_user', 'verbosity', 'check', 'diff'])

# Generated at 2022-06-11 16:56:31.867031
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert callable(StrategyModule)


# Generated at 2022-06-11 16:56:32.486358
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:56:33.476462
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule
    module.__init__()

# Generated at 2022-06-11 16:56:34.549398
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)


# Generated at 2022-06-11 16:56:39.011838
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create object instance of class StrategyModule
    strategy = StrategyModule()
    # test attribute host_pinned
    assert strategy._host_pinned


# Generated at 2022-06-11 16:56:40.713477
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    tqm = []
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:58:17.360160
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('TaskQueueManager')

# Generated at 2022-06-11 16:58:18.170641
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:58:19.403046
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Unit tests for StrategyModule"""
    t = StrategyModule("Test host_pinned")
    assert t

# Generated at 2022-06-11 16:58:20.621201
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule("tqm")
    assert isinstance(strategy._host_pinned, bool)

# Generated at 2022-06-11 16:58:23.093592
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    sm = StrategyModule('tqm')
    assert sm._host_pinned == True

# Generated at 2022-06-11 16:58:27.499739
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    strategy_module = StrategyModule(None)

    assert strategy_module._host_pinned is True
    assert isinstance(strategy_module._tqm, StrategyModule)
    assert strategy_module._batch_size == 1

# Generated at 2022-06-11 16:58:29.769864
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm=None)
    assert sm._host_pinned

# Generated at 2022-06-11 16:58:31.571828
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    m = StrategyModule(None)
    assert m._host_pinned

# Generated at 2022-06-11 16:58:33.962721
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert Display.__name__ == "Display"

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-11 16:58:35.798535
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test = StrategyModule(None)
    assert test._host_pinned == True


# Generated at 2022-06-11 17:01:57.911070
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()
    assert obj

# unit test for create_worker method of class StrategyModule

# Generated at 2022-06-11 17:02:02.471601
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Testing constructor of class StrategyModule.')
    strategy = StrategyModule(None)
    assert strategy.__class__.__name__ == 'StrategyModule'
    assert strategy.__init__ is not None
    print('Test constructor of class StrategyModule is OK.')


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-11 17:02:04.609670
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm='')
    assert (sm._host_pinned == True)

# Generated at 2022-06-11 17:02:05.105873
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 17:02:09.494810
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert issubclass(StrategyModule, FreeStrategyModule)
    s = StrategyModule('tqm')
    assert hasattr(s, '_host_pinned')
    assert s._host_pinned == True
    assert s.get_host_list(play=None) == []

if __name__ == '__main__':
    test_StrategyModule()
    print('Test module worked!')

# Generated at 2022-06-11 17:02:09.885455
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-11 17:02:19.499719
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from collections import namedtuple
    from ansible.utils.display import Display
    from ansible.utils.vars import AnsibleVars

    testTqm = namedtuple('testTqm', 'inventory hosts all_hosts file_vars')
    testTqm.inventory = namedtuple('testInv', 'testHosts')
    testTqm.inventory.testHosts = ['test1.example.com', 'test2.example.com', 'test3.example.com', 'test4.example.com']
    testTqm.hosts = namedtuple('testHosts', 'get_vars is_failed get_name')

# Generated at 2022-06-11 17:02:21.082235
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-11 17:02:30.052418
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.executor.host_result import HostResult
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars


    def _load_name_to_host(self):
        '''
        Builds a lookup table of hostnames to inventory host objects
        '''
        self._name_to_host = {}