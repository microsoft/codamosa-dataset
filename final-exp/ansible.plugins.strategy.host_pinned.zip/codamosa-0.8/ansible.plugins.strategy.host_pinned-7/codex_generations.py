

# Generated at 2022-06-11 16:52:23.745639
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(None)._host_pinned, bool)

# Generated at 2022-06-11 16:52:25.491529
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy is not None
    assert strategy._host_pinned

# Generated at 2022-06-11 16:52:26.179531
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:52:28.584436
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:52:30.185639
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Generated at 2022-06-11 16:52:32.943288
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = DummyTqm()
    s = StrategyModule(tqm)
    assert s._host_pinned



# Generated at 2022-06-11 16:52:36.314420
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class tqm:
        def __init__(self):
            self.stats = dict()
            self.hostvars = dict()
    sm = StrategyModule(tqm())   # noqa

# Generated at 2022-06-11 16:52:40.958803
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(StrategyModule(tqm=1))
    #assert StrategyModule(tqm=1) == StrategyModule(tqm=1)
    #assert StrategyModule(tqm=1) != StrategyModule(tqm=2)

# Generated at 2022-06-11 16:52:41.737922
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    aa = StrategyModule(1)


# Generated at 2022-06-11 16:52:46.039373
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule

    strategy_obj = StrategyModule("tqm_test")

# Generated at 2022-06-11 16:52:52.658678
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # ensure that the correct base class is used
    from ansible.plugins.strategy.free import StrategyModule
    assert StrategyModule.__bases__ == (StrategyModule,)

    # ensure that the correct attributes are set
    assert hasattr(StrategyModule, '_host_pinned')
    assert StrategyModule._host_pinned == True


# Generated at 2022-06-11 16:53:00.529152
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM():
        def __init__(self):
            self.host_pinned = True

    import ansible.plugins.strategy.host_pinned
    role_l = {'host_pinned':ansible.plugins.strategy.host_pinned.StrategyModule}
    tqm = TestTQM()
    host_pinned = strategy_loader.get('host_pinned')
    strategy_module = role_l['host_pinned'](tqm)
    assert strategy_module._host_pinned == True

# flag to activeate unit tests
test_StrategyModule()

# Generated at 2022-06-11 16:53:03.793375
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print ("Testing StrategyModule constructor")
    obj = StrategyModule(None)
    if not isinstance(obj, StrategyModule):
        raise AssertionError()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-11 16:53:06.561565
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy is not None

test_StrategyModule()

# Generated at 2022-06-11 16:53:13.870281
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None,
    )
    strategy_instance = StrategyModule(tqm)
    assert strategy_instance._host_pinned == True

# vim: set et ts=8 sw=4 sts=4:

# Generated at 2022-06-11 16:53:16.930315
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test with FreeStrategyModule
    assert hasattr(FreeStrategyModule, '__init__')
    assert callable(FreeStrategyModule.__init__)
    assert hasattr(StrategyModule, '__init__')
    assert callable(StrategyModule.__init__)

# Generated at 2022-06-11 16:53:28.597658
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	
	print("\n *** Test case 1: test_StrategyModule_with_successful_case_constructor *** \n")
	
	print("Object tqm created and is passed as parameter to the constructor")
	tqm = "tqm"
	strategyModule = StrategyModule(tqm)
	
	print("Checking the value of variable self._host_pinned: expected value is True. Actual value is " + str(strategyModule._host_pinned))
	assert strategyModule._host_pinned == True, "Test case 1: test_StrategyModule_with_successful_case_constructor FAILED"
	print("Test case 1: test_StrategyModule_with_successful_case_constructo PASSED")
	

# Generated at 2022-06-11 16:53:33.118880
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   import mock
   test_tqm = mock.MagicMock()
   test_strategy = StrategyModule(test_tqm)
   assert isinstance(test_strategy, StrategyModule)
   assert test_strategy._host_pinned is True


# Generated at 2022-06-11 16:53:34.846068
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned = StrategyModule()
    assert host_pinned._host_pinned == True

# Generated at 2022-06-11 16:53:35.423629
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:53:38.443126
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(1)._host_pinned

# Generated at 2022-06-11 16:53:39.518559
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)
    assert True

# Generated at 2022-06-11 16:53:50.372285
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = "test-host"
    inventory = dict()
    inventory[host] = dict()
    inventory[host]["hostname"] = "test-host"
    tqm = dict()
    tqm["_inventory"] = inventory
    tqm["_options"] = dict()
    tqm["_options"][" forks"] = 5
    tqm["_options"]["become_method"] = "become"
    tqm["_options"]["become_user"] = "become_user"
    tqm["_options"]["ask_become_pass"] = False
    tqm["_options"]["ask_pass"] = False
    tqm["_options"]["check"] = False
    tqm["_options"]["connection"] = "connection"


# Generated at 2022-06-11 16:53:58.920696
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    from ansible.plugins.strategy.host_pinned import TASK_BLOCKING, TASK_GENERAL, TASK_IMPORTANT, TASK_OPTIONAL
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy.host_pinned import TASK_WAITING, TASK_CONTROL, TASK_PENDING, TASK_STARTED, TASK_FINISHED
    from ansible.plugins.strategy.host_pinned import TaskQueueManager

    tqm = TaskQueueManager(None, None)
    strategy = StrategyModule(tqm)
    assert strategy._tqm == tqm
    assert strategy._blocks == []
    assert strategy._display == display
    assert strategy._host_pinned

# Generated at 2022-06-11 16:54:00.493929
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm=None)
    assert s._host_pinned

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-11 16:54:02.005731
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)

# Tests for method set_host_run

# Generated at 2022-06-11 16:54:09.823053
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    class Test:
        def __init__(self):
            self.strategy = 'host_pinned'
            self.subset = 'all'
            self.serial = None
            self.become = False
            self.become_method = 'sudo'
            self.become_user = None
            self.verbosity = 0
            self.extra_vars = {}
            self.start_at_task = ''
            self.register = None
            self.all_vars = {}

        def pop_vars(self):
            return {'foo': 'bar'}

    class Test2:
        def __init__(self):
            self.tags = {'foo': 'bar'}

    class Test3:
        def __init__(self):
            self.tags = {'foo': 'bar'}



# Generated at 2022-06-11 16:54:11.612114
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule('tqm')
    assert obj._host_pinned == True

# Generated at 2022-06-11 16:54:16.140861
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #Create a mock of FreeStrategyModule
    freestrat = FreeStrategyModule()
    #Create a mock of class StrategyModule
    strat = StrategyModule(freestrat)
    #Check if the variables are of correct type
    assert isinstance(strat._host_pinned, bool)

# Generated at 2022-06-11 16:54:18.147389
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    _StrategyModule = StrategyModule()
    assert _StrategyModule._host_pinned == True

# Generated at 2022-06-11 16:54:23.739354
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True
    return strategy

# Generated at 2022-06-11 16:54:25.036819
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm._host_pinned == True

# Generated at 2022-06-11 16:54:25.922506
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None

# Generated at 2022-06-11 16:54:27.536587
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_queue_manager = StrategyModule.__init__(mock.ANY, mock.ANY)

# Generated at 2022-06-11 16:54:28.973803
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm = None)
    assert s._host_pinned is True
#

# Generated at 2022-06-11 16:54:30.501911
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = StrategyModule()
    assert tqm != None

# Generated at 2022-06-11 16:54:32.594891
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_module = StrategyModule(None)
    assert test_module.__class__.__name__ == 'StrategyModule'

# Generated at 2022-06-11 16:54:35.148497
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:54:35.841699
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:54:37.742087
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm = None)
    assert module._host_pinned == True

# Generated at 2022-06-11 16:54:47.011551
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = True
  obj = StrategyModule(tqm)

# Generated at 2022-06-11 16:54:47.572915
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:54:48.058059
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:54:49.140840
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    StrategyModule(tqm)
# End of unit test

# Generated at 2022-06-11 16:54:52.643786
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    sm = ansible.plugins.strategy.host_pinned.StrategyModule("tqm")
    assert sm._host_pinned

# Generated at 2022-06-11 16:54:55.241598
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm=None
    test_StrategyModule = StrategyModule(tqm)
    assert test_StrategyModule._host_pinned == True

# Generated at 2022-06-11 16:54:56.405704
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)

# Generated at 2022-06-11 16:54:57.426468
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-11 16:54:58.038870
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:55:00.106793
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "test"
    assert(StrategyModule.__init__(tqm)) == super(StrategyModule)

# Generated at 2022-06-11 16:55:23.550534
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(0)
    assert strategy._host_pinned == True

# Generated at 2022-06-11 16:55:26.497430
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule

    strategy_module = StrategyModule()

    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:55:27.746946
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(None)
    assert module is not None

# Generated at 2022-06-11 16:55:30.473591
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:55:33.421046
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm = None)
    assert (sm.__class__.__bases__[0].__name__ == 'FreeStrategyModule')
    assert (sm._host_pinned == True)

# Generated at 2022-06-11 16:55:34.040016
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:55:35.040077
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)

# Generated at 2022-06-11 16:55:38.443695
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy import StrategyBase
    StrategyBase.register_plugin('host_pinned', StrategyModule)
    assert StrategyBase.is_valid_plugin('host_pinned')

# Generated at 2022-06-11 16:55:41.602612
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    if __name__ == '__main__':
        tqm = None
        strategy = StrategyModule(tqm)
        print(strategy._host_pinned)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-11 16:55:43.109116
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    # Verify the expected results
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:56:24.488498
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned as host_pinned
    ansible.plugins.strategy.host_pinned.StrategyModule(None)


# Generated at 2022-06-11 16:56:26.594022
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned = StrategyModule(None)
    assert host_pinned._host_pinned == True

# Generated at 2022-06-11 16:56:27.464205
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)._host_pinned

# Generated at 2022-06-11 16:56:38.822966
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock
# Mock class TQM
    class TQM(object):
        def __init__(self):
            self.host_pinned = True
            self.host_pinned_serial = 1
            self.host_pinned_batch = 0
            self.host_pinned_all = True
            self.host_pinned_remaining = 5
            
    tqm = TQM()
# Mock class MockCurPlay
    class MockCurPlay(object):
        def __init__(self):
            self.serial = 1
            self.serial_failure_threshold = 0
            self.strategy = 'host_pinned'
            
    cur_play = MockCurPlay() 
# Initialize object of class StrategyModule with arguments tqm and cur_play

# Generated at 2022-06-11 16:56:40.316620
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule('tqm')
    assert obj._host_pinned == True
    
    

# Generated at 2022-06-11 16:56:41.108341
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '__init__')

# Generated at 2022-06-11 16:56:43.017041
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)._host_pinned
    assert strategy

# Generated at 2022-06-11 16:56:43.990553
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-11 16:56:49.929389
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = [
    {
        "host": "localhost",
        "port": 22,
        "username": "ubuntu",
        "password": "ubuntu",
        "_ansible_no_log": False,
        "become_method": "sudo",
        "become_user": "root"
    },
    {
        "host": "127.0.0.1",
        "port": 22,
        "username": "ubuntu",
        "password": "ubuntu",
        "_ansible_no_log": False,
        "become_method": "sudo",
        "become_user": "root"
    }
]
    assert StrategyModule(tqm)

# Generated at 2022-06-11 16:56:52.420997
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule() == None

StrategyModule.run = FreeStrategyModule.run
StrategyModule.cleanup = FreeStrategyModule.cleanup

# Generated at 2022-06-11 16:58:39.162865
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host1 = '127.0.0.1'
    host2 = '127.0.0.2'
    host3 = '127.0.0.3'
    host4 = '127.0.0.4'
    test_tqm = TestTQM([host1, host2, host3, host4])
    strategy_module = StrategyModule(test_tqm)

    assert(strategy_module._host_pinned) == True, 'Test Failed: constructor failed to initialize variable.'


if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-11 16:58:40.021503
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm)
    assert isinstance(s, StrategyModule)

# Generated at 2022-06-11 16:58:41.292806
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   tqm = ''
   StrategyModule(tqm)

# Generated at 2022-06-11 16:58:42.666591
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test = StrategyModule(None)
    assert test._host_pinned is True

# Generated at 2022-06-11 16:58:44.079209
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-11 16:58:49.084280
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Mock TQM
    tqm = Mock()

    # Create instance of StrategyModule
    strategy_module = StrategyModule(tqm)

    # Test __init__()
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:58:50.098416
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned == True
    assert strategy_module.get_host_list() == None

# Generated at 2022-06-11 16:58:51.301185
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule("tqm")
    assert sm._host_pinned == True

# Generated at 2022-06-11 16:58:58.388308
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # import needed modules
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.strategy.host_pinned import StrategyModule
    # create dummy objects
    tqm_obj = TaskQueueManager(
        inventory=InventoryManager(loader=DataLoader(), sources=''),
        variable_manager=VariableManager(loader=DataLoader(), inventory=InventoryManager(loader=DataLoader(), sources='')),
        loader=DataLoader(),
        options=None,
        passwords=dict(),
        stdout_callback='default',
    )

# Generated at 2022-06-11 16:59:00.613023
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(object)
    assert strategy is not None

if __name__ == '__main__':
    test_StrategyModule()