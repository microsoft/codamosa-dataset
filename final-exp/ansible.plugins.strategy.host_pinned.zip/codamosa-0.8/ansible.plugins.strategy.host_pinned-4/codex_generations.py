

# Generated at 2022-06-11 16:52:30.484659
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm="tqm")
    assert strategy._host_pinned == True
    assert strategy._tqm == "tqm"
    assert strategy._inventory is None
    assert strategy._play_context is None
    assert strategy._variable_manager is None
    assert strategy._all_hosts is None
    assert strategy._stats is None

# Generated at 2022-06-11 16:52:31.117004
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-11 16:52:34.378017
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = mock.MagicMock()
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-11 16:52:42.276985
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-11 16:52:52.306747
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor import task_queue_manager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory import inventory
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    # Create executor
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    executor = 'free'

# Generated at 2022-06-11 16:52:56.301307
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned as strategy_host_pinned
    my_object = strategy_host_pinned.StrategyModule(1)
    assert isinstance(my_object, strategy_host_pinned.StrategyModule)

# Generated at 2022-06-11 16:52:57.718830
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert( not 'free' in  globals().keys())



# Generated at 2022-06-11 16:52:59.215114
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)

# Generated at 2022-06-11 16:52:59.818115
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-11 16:53:00.608615
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:53:03.971692
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    import tempfile
    f = tempfile.NamedTemporaryFile(mode='w+')

# Generated at 2022-06-11 16:53:04.828699
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:53:06.906217
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm=None)
    assert isinstance(s._host_pinned, bool)

# Generated at 2022-06-11 16:53:08.342289
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = Mock()
    StrategyModule(tqm)

# Generated at 2022-06-11 16:53:09.638591
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm=None)
    assert sm._host_pinned # True

# Generated at 2022-06-11 16:53:15.815534
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    globals = {'__file__': 'host_pinned_strategy.py', '__name__': 'host_pinned_strategy', '__package__': ''}
    locals = {}
    result = StrategyModule.__init__(globals, locals)
    expected_result = super(StrategyModule, StrategyModule).__init__(globals, locals)
    assert result == expected_result



# Generated at 2022-06-11 16:53:17.676668
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    st=StrategyModule(None)
    # Test attributes were initialized
    assert st._host_pinned == True



# Generated at 2022-06-11 16:53:19.373745
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert False == "TODO"

# Generated at 2022-06-11 16:53:20.937698
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule('test')
    assert sm._host_pinned is True

# Generated at 2022-06-11 16:53:22.600787
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    free_strategy_module = FreeStrategyModule(tqm=None)
    # test if StrategyModule's __init__ is called
    assert free_strategy_module._host_pinned is False

# Generated at 2022-06-11 16:53:26.505946
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    assert (StrategyModule(tqm) == None)


# Generated at 2022-06-11 16:53:28.449749
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('tqm')
    assert strategy_module._host_pinned

# Generated at 2022-06-11 16:53:30.309288
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    assert obj._host_pinned == True

# Generated at 2022-06-11 16:53:36.068373
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock
    import ansible.plugins.strategy.host_pinned as hp

    # this is the class we are testing
    test_class = hp.StrategyModule

    # make an instance
    module1 = test_class(mock.Mock())

    # check if the return is what we expect
    assert type(module1._host_pinned) == bool
    assert module1._host_pinned == True

# Generated at 2022-06-11 16:53:43.106199
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manger import TaskQueueManager as TQM
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    loader = DataLoader()
    playbooks  = ["host_pinned.yml"]
    inventory  = InventoryManager(loader, "host_pinned.yml")

# Generated at 2022-06-11 16:53:46.083776
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:53:51.222443
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy import linear
    from ansible.executor.task_queue_manager import TaskQueueManager
    x = linear.StrategyModule(TaskQueueManager())
    assert isinstance(x, linear.StrategyModule) is False
    assert isinstance(x, StrategyModule) is True

# Generated at 2022-06-11 16:53:53.480527
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert (strategy._host_pinned == True)



# Generated at 2022-06-11 16:53:54.291693
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm = None)

# Generated at 2022-06-11 16:53:58.879918
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    strategy_module = StrategyModule('tqm')
    assert strategy_module._host_pinned is True

# Generated at 2022-06-11 16:54:05.373862
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # check if the object got instantiated correctly
    obj = StrategyModule()
    if not isinstance(obj, StrategyModule):
        raise AssertionError('Failed to instantiate the class correctly')
    return True

# Generated at 2022-06-11 16:54:06.431433
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-11 16:54:09.272034
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    def __init__(self, tqm):
        super(StrategyModule, self).__init__(tqm)
        self._host_pinned = True

# Generated at 2022-06-11 16:54:12.011842
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    host_pinned = StrategyModule(tqm)
    assert host_pinned._host_pinned == True

# Generated at 2022-06-11 16:54:13.286009
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__



# Generated at 2022-06-11 16:54:23.023501
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class ValueTQM(object):
        pass

    fakeTQM = ValueTQM()
    fakeTQM.hostvars = "hostvars"
    fakeTQM.host_pinned = "host_pinned"
    fakeTQM.timeout = "timeout"
    fakeTQM.forks = "forks"
    fakeTQM.step = "step"
    fakeTQM.basedir = "basedir"
    fakeTQM.become_methods = "become_methods"
    fakeTQM.default_poll_interval = "default_poll_interval"
    fakeTQM.playbooks = "playbooks"
    fakeTQM.new_stdin = "new_stdin"
    fakeTQM.inventory = "inventory"
    fake

# Generated at 2022-06-11 16:54:25.597577
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = AnsibleTest()
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned

# Unit Test
import unittest
# Unit test TestCase

# Generated at 2022-06-11 16:54:26.408858
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-11 16:54:29.184913
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule=StrategyModule('tqm')
    assert str(strategyModule._host_pinned)=='True'

#unit test for init method
#def test_init():
    

# unit test for method run

# Generated at 2022-06-11 16:54:30.754185
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    assert obj._host_pinned == True

# Generated at 2022-06-11 16:54:39.023120
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('test')

# Generated at 2022-06-11 16:54:42.799580
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert (StrategyModule.__doc__ is not None)
    obj = StrategyModule(tqm = "tqm")
    assert (obj._host_pinned is True)

# Generated at 2022-06-11 16:54:44.867897
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ Unit test for constructor of class StrategyModule """
    m = StrategyModule(None)
    assert True

# Generated at 2022-06-11 16:54:53.735549
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.inventory import Inventory
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.executor import task_queue_manager

    #Creating a test inventory
    inventory = Inventory(host_list=[])
    host1 = Host(name="host1", port=22, groups=["group1"])
    host2 = Host(name="host2", port=22, groups=["group1"])

    #Add hosts to inventory
    inventory.add_host(host1)
    inventory.add_host(host2)
    host_list_item1 = dict(host=host1, task_vars=dict(ansible_connection='local'))
    host_list_item2

# Generated at 2022-06-11 16:54:54.384104
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:54:56.122224
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm._host_pinned == True

# Generated at 2022-06-11 16:54:59.030273
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    obj = StrategyModule(tqm)
    assert obj._host_pinned == True

if __name__ == "__main__":
        test_StrategyModule()

# Generated at 2022-06-11 16:55:00.433533
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm._host_pinned



# Generated at 2022-06-11 16:55:02.322072
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Unit test for constructor"""
    tqm = super(StrategyModule, StrategyModule)
    StrategyModule(tqm)

# Generated at 2022-06-11 16:55:05.736976
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    def test_constructor(StrategyModule):
        strategy_module = StrategyModule()

        assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:55:28.043330
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert not hasattr(StrategyModule, '_host_pinned')
    StrategyModule(None)
    assert StrategyModule._host_pinned

# Generated at 2022-06-11 16:55:30.757135
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule(None)
    assert mod._host_pinned == True


# Generated at 2022-06-11 16:55:32.567103
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
        stm = StrategyModule("tqm")
        assert stm._host_pinned == True

# Generated at 2022-06-11 16:55:33.192919
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:55:35.736629
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = "test_StrategyModule"
    tqm = "test_tqm"
    sub = StrategyModule(tqm)
    assert display == "test_StrategyModule"

# Generated at 2022-06-11 16:55:37.499491
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None

# Generated at 2022-06-11 16:55:43.525011
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    tqm = dict()
    tqm['tasks'] = list()
    tqm['tasks'].append('Task')
    tqm['variable_manager'] = 'VariableManager'
    tqm['passwords'] = dict()
    tqm['results_queue'] = 'Queue'
    tqm['connection_info'] = dict()
    tqm['queue_items'] = dict()
    tqm['stats'] = dict()
    tqm['hostvars'] = dict()
    tqm['hostvars']['Host'] = 'Host'

    strategy_module = FreeStrategyModule(tqm)
    assert tqm == strategy_module._tqm

# Generated at 2022-06-11 16:55:45.725887
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_strategy = StrategyModule('foo')
    assert test_strategy._host_pinned

# Generated at 2022-06-11 16:55:46.248533
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-11 16:55:47.753233
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'


# Generated at 2022-06-11 16:56:25.878651
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MagicMock()
    StrategyModule(tqm)

# Generated at 2022-06-11 16:56:28.523311
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test'
    s = StrategyModule(tqm)
    assert s._host_pinned
    assert s._tqm == 'test'

# Generated at 2022-06-11 16:56:30.060739
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()


# Generated at 2022-06-11 16:56:30.863779
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:56:32.434474
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ts = StrategyModule(None)
    assert ts._host_pinned == True

# Generated at 2022-06-11 16:56:34.648962
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    assert obj._host_pinned == True, 'Host_pinned should be true'

# Generated at 2022-06-11 16:56:35.434681
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:56:41.611809
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("********\nTESTING\n********\n")
    print("Testing StrategyModule")
    from ansible.plugins.strategy.host_pinned import StrategyModule
    strategy = StrategyModule(tqm=tqm, host_pinned=host_pinned)
    assert strategy.host_pinned

# Generated at 2022-06-11 16:56:44.411525
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    stm = StrategyModule("TESTS")
    # "TESTS" is automatically converted to test by that time
    assert stm._host_pinned == True

# Generated at 2022-06-11 16:56:46.609157
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)
    assert StrategyModule.__doc__ is not None


# Generated at 2022-06-11 16:58:24.216668
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    t = dict(name='host_pinned')
    strategy = StrategyModule(t)

    assert strategy._host_pinned
    assert strategy._failed_hosts
    assert strategy._unreachable_hosts
    assert strategy._changed_hosts

# Generated at 2022-06-11 16:58:25.593325
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule.__init__(StrategyModule,tqm='tqm')

# Generated at 2022-06-11 16:58:27.177288
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    test_obj = StrategyModule(tqm)
    assert not test_obj is None


# Generated at 2022-06-11 16:58:29.992281
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned = StrategyModule()
    assert host_pinned._host_pinned == True

# Generated at 2022-06-11 16:58:30.733576
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:58:32.429306
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)


# Generated at 2022-06-11 16:58:33.505927
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)

# Generated at 2022-06-11 16:58:34.868789
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule(None)

# Generated at 2022-06-11 16:58:40.679876
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    def mock_super(self, tqm):
        self._tqm = tqm
        self._display = tqm._display
        self._fail_hosts = dict()
        self._queue = None
        self._tqm._final_q = self._queue
    StrategyModule.__init__ = mock_super
    tqm = MockTQM()
    tqm._display = display
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True


# Generated at 2022-06-11 16:58:47.486724
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule', "Wrong class name"
    assert StrategyModule.__doc__ == FreeStrategyModule.__doc__, "Wrong doc string"
    assert StrategyModule._host_pinned, "Failed to set _host_pinned attribute"

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-11 17:02:01.371898
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)
    assert tqm == None

# Generated at 2022-06-11 17:02:04.825720
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    assert obj._host_pinned


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-11 17:02:05.605573
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm = None)

# Generated at 2022-06-11 17:02:07.078362
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule('test')
    assert s is not None

# Generated at 2022-06-11 17:02:08.927440
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Test StrategyModule object with host_pinned strategy
    """

    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned == True

# Generated at 2022-06-11 17:02:12.513177
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.display import Display
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy.host_pinned import StrategyModule

    display = Display()
    task_queue_manager = TaskQueueManager(None, None, None, None, None, None, 'host_pinned', None, None, display, None)
    strategy_module = StrategyModule(task_queue_manager)

    assert strategy_module
    assert strategy_module._host_pinned

# Generated at 2022-06-11 17:02:13.755199
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert s._host_pinned == True

# Generated at 2022-06-11 17:02:15.654489
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_mpdule = StrategyModule()
    assert StrategyModule._host_pinned == True

# test case for class StrategyModule

# Generated at 2022-06-11 17:02:18.781808
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule(tqm)
    strategy_plugin = strategy_plugin(tqm)
    assert strategy_plugin._host_pinned

# Generated at 2022-06-11 17:02:19.998948
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)