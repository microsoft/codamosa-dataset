

# Generated at 2022-06-11 16:52:30.051660
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestFreeStrategyModule(FreeStrategyModule):
        def __init__(self, tqm):
            super(TestFreeStrategyModule, self).__init__(tqm)
    test_free_strategy_module = TestFreeStrategyModule(None)
    assert test_free_strategy_module._host_pinned

# Generated at 2022-06-11 16:52:32.369994
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned = FreeStrategyModule(tqm)
    assert host_pinned._host_pinned == True

# Generated at 2022-06-11 16:52:37.975155
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    context = PlayContext()
    context._host_pinned = True
    tqm = TaskQueueManager(None, context)
    strat = StrategyModule(tqm)
    assert strat._host_pinned == True

# Generated at 2022-06-11 16:52:41.263539
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj1 = StrategyModule(None)
    assert obj1._host_pinned == True
    assert obj1._cur_serial == 0
    assert obj1._host_list is None
    assert obj1.display is not None

# Generated at 2022-06-11 16:52:42.513022
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule("tqm")
    assert strategy._host_pinned


# Generated at 2022-06-11 16:52:46.134319
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  args = {}
  obj = StrategyModule(args)
  assert obj is not None

# Generated at 2022-06-11 16:52:47.496646
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module



# Generated at 2022-06-11 16:52:48.208567
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:52:49.379249
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    channel = StrategyModule.__init__()
    assert channel.host_pinned == True

# Generated at 2022-06-11 16:52:50.820385
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    p = StrategyModule()
    assert p._host_pinned == True

# Generated at 2022-06-11 16:52:52.662444
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == True

# Generated at 2022-06-11 16:52:55.106576
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Constructor without any argument
    obj1 = StrategyModule()
    # Constructor with arguments
    obj2 = StrategyModule(tqm)

# Generated at 2022-06-11 16:52:55.742640
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:52:56.660800
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Check if it is setting the host_pinned to true
    assert StrategyModule(None)._host_pinned

# Generated at 2022-06-11 16:52:58.143175
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert False, "there are no tests for this code"


# Generated at 2022-06-11 16:53:09.277334
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import traceback
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import load_extra_vars
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["myhosts"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-11 16:53:10.400708
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    StrategyModule(tqm)


# Generated at 2022-06-11 16:53:14.635239
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert isinstance(strategy,FreeStrategyModule)
    assert isinstance(strategy,StrategyModule)
    assert strategy._host_pinned == True

# Generated at 2022-06-11 16:53:16.171884
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned_object = StrategyModule()
    assert isinstance(host_pinned_object._host_pinned, bool)


# Generated at 2022-06-11 16:53:17.572586
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__(StrategyModule, 'tqm') == None

# Generated at 2022-06-11 16:53:21.219324
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == FreeStrategyModule.__doc__

# Generated at 2022-06-11 16:53:23.293654
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm=None
    s=StrategyModule(tqm)
    assert s is not None

# Generated at 2022-06-11 16:53:25.647490
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule
    sys = StrategyModule(tqm)
    assert sys._host_pinned == True

# Generated at 2022-06-11 16:53:28.943388
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("unit test for StrategyModule")
    my_tqm = None
    my_strategy_module = StrategyModule(my_tqm)
    assert(my_strategy_module)

# Generated at 2022-06-11 16:53:30.810355
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned = StrategyModule(tqm)
    host_pinned._host_pinned

# Generated at 2022-06-11 16:53:37.518794
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned

    assert ansible.plugins.strategy.host_pinned.StrategyModule.__name__ == 'StrategyModule'
    assert ansible.plugins.strategy.host_pinned.StrategyModule.__doc__  == ansible.plugins.strategy.host_pinned.__doc__

    strategy_obj = ansible.plugins.strategy.host_pinned.StrategyModule(None)
    assert strategy_obj._host_pinned == True

# Generated at 2022-06-11 16:53:38.550634
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('tqm')

# Generated at 2022-06-11 16:53:39.237504
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:53:50.079708
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars

    loader = DataLoader()
    inventory = InventoryManager(loader, 'localhost,', False)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    display = Display()
    variable_manager.extra_vars = load_extra_vars(loader=loader, options=None, vars_files=None)
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-11 16:53:51.875304
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule([])
    assert strategyModule is not None
    assert strategyModule._host_pinned == True

# Generated at 2022-06-11 16:53:59.822309
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        from ansible.utils.display import Display
        display = Display()
        from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
        from ansible.executor.task_queue_manager import TaskQueueManager
        a = TaskQueueManager()
        StrategyModule(a)
    except Exception as e:
        display.vvvv(traceback.format_exc())
        raise AssertionError(e)

# Generated at 2022-06-11 16:54:00.605933
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:54:01.241123
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-11 16:54:02.641913
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule(tqm)
    assert tqm._host_pinned == True

# Generated at 2022-06-11 16:54:03.092651
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:54:05.365223
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm = None)
    assert hasattr(strategy, '_host_pinned')
    assert strategy._host_pinned is True

# Generated at 2022-06-11 16:54:06.389198
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert not StrategyModule.__init__

# Generated at 2022-06-11 16:54:08.199302
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy is not None

# Generated at 2022-06-11 16:54:09.001488
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:54:10.145262
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm="test")

# Generated at 2022-06-11 16:54:22.631961
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned as class_to_test
    import ansible.plugins.strategy.free as FreeStrategyModule
    host_pinned_module = class_to_test.StrategyModule("tqm")
    assert isinstance(host_pinned_module, FreeStrategyModule.StrategyModule)

# Generated at 2022-06-11 16:54:24.992434
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Constructor - StrategyModule")
    tqm = None
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True


# Generated at 2022-06-11 16:54:25.546674
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-11 16:54:27.495288
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test case 1
    strategy_module = StrategyModule(None)

    assert strategy_module
    assert strategy_module._host_pinned

# Generated at 2022-06-11 16:54:28.339466
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(True)


# Generated at 2022-06-11 16:54:31.123689
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        strategy = StrategyModule(tqm)
    except Exception:
        assert False
    assert True

# Test the play() method

# Generated at 2022-06-11 16:54:34.015840
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm=None)
    assert sm._host_pinned

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-11 16:54:34.302847
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-11 16:54:41.125774
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=loader,
        passwords=None,
        stdout_callback=None,
        run_additional_callbacks=True,
        run_tree=False,
        vault_password=None,
        stdin_callback=None,
    )

    strategy_module = StrategyModule(tqm)

    assert strategy_module != None

# Generated at 2022-06-11 16:54:42.241949
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-11 16:55:01.088300
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-11 16:55:01.580569
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:55:02.270986
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)

# Generated at 2022-06-11 16:55:04.604012
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule(None)
    assert mod._host_pinned == True

# Generated at 2022-06-11 16:55:06.037813
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 16:55:08.548588
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.verbosity = 0
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True
    display.verbosity = 2

# Generated at 2022-06-11 16:55:10.324698
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    obj = StrategyModule(tqm)

# Generated at 2022-06-11 16:55:11.840651
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-11 16:55:14.371584
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeTQM()
    strategy = StrategyModule(tqm)
    assert strategy.tqm == tqm


# Generated at 2022-06-11 16:55:15.053924
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:55:59.782896
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned = StrategyModule(tqm)
    assert host_pinned._host_pinned == True

# Generated at 2022-06-11 16:56:00.375587
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:56:02.027413
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm = None)
    assert obj._host_pinned == True

# Generated at 2022-06-11 16:56:03.427103
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__

# Generated at 2022-06-11 16:56:05.567623
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TaskQueueManager(playbook, inventory, variable_manager, loader, options, passwords)
    strategy = StrategyModule(tqm)

# Generated at 2022-06-11 16:56:14.665700
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-11 16:56:18.129734
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  import unittest.mock as mock
  tqm = mock.MagicMock()
  strategy = StrategyModule(tqm)
  assert strategy._tqm == tqm

# Generated at 2022-06-11 16:56:20.028619
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import pinned
    plugin = pinned.StrategyModule('')
    assert plugin._host_pinned == True

# Generated at 2022-06-11 16:56:21.540611
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule("tqm") != None

# Generated at 2022-06-11 16:56:23.217333
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule()
    assert x._host_pinned == True

# Generated at 2022-06-11 16:57:49.601623
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)

# Generated at 2022-06-11 16:57:51.442571
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule(tqm)
    assert FreeStrategyModule._host_pinned == True

# Test that the constructor in class StrategyModule assigns a value to _host_pinned

# Generated at 2022-06-11 16:57:52.011627
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:57:52.672600
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    instance = StrategyModule()

# Generated at 2022-06-11 16:57:53.468462
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:57:59.950841
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy = StrategyModule(tqm)
    assert strategy.tqm == tqm
    assert strategy._tqm_batches is None
    assert strategy.batch is None
    assert strategy._batch_name is None
    assert strategy.cur_batch is None
    assert strategy.new_batch is None
    assert strategy._sleep_time == 0.01
    assert strategy._host_pinned is True



# Generated at 2022-06-11 16:58:00.810611
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm=None
    mod = StrategyModule(tqm)
    assert mod._host_pinned == True

# Generated at 2022-06-11 16:58:06.335121
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    assert issubclass(ansible.plugins.strategy.host_pinned.StrategyModule, FreeStrategyModule)
    # TODO: create some input and assert correct results
    strategy = ansible.plugins.strategy.host_pinned.StrategyModule(None)
    assert strategy._host_pinned

# Generated at 2022-06-11 16:58:06.904225
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:58:09.662218
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert(isinstance(strategy, StrategyModule) )

# Generated at 2022-06-11 17:01:36.783216
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import _fixtures
    import ansible.playbook.block
    tqm = _fixtures.tqm

    sm = StrategyModule(tqm)

    assert sm.get_host_list(play=_fixtures.play) == ['foo']
    assert sm.get_failed_hosts(play=_fixtures.play) == []
    assert sm.display.verbosity == 2
    assert sm.display.columns == 80
    assert ansible.playbook.block.dont_write_tags == False

    sm.add_tqm_variables(play=_fixtures.play, host=_fixtures.host)
    assert sm.VariableManager.extra_vars == {'meta_hostvars': {'bar': 'baz'}}

# Generated at 2022-06-11 17:01:38.465497
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	tqm = None
	StrategyModule(tqm)

if __name__ == '__main__':
	test_StrategyModule()

# Generated at 2022-06-11 17:01:39.376896
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-11 17:01:41.993085
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    temp_task_queue_manager = object
    temp_strategy_module = StrategyModule(temp_task_queue_manager)
    assert temp_strategy_module._host_pinned is True

# Generated at 2022-06-11 17:01:42.494537
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 17:01:43.603988
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-11 17:01:46.957830
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned == True



# Generated at 2022-06-11 17:01:47.576948
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert not StrategyModule

# Generated at 2022-06-11 17:01:48.594294
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '__init__')

# Generated at 2022-06-11 17:01:50.209341
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    assert(2 + 3 == 5)