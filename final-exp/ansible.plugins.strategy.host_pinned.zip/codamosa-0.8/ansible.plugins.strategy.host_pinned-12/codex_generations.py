

# Generated at 2022-06-11 16:52:24.813197
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(True)

# Generated at 2022-06-11 16:52:27.323914
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   tqm = MockTqm()
   StrategyModule(tqm)
   assert display.display('Host Pinned Strategy plugin loaded')


# Generated at 2022-06-11 16:52:29.897829
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM:
        _initial_queue_congestion = 5

    tqm = TQM()
    sm = StrategyModule(tqm)
    assert sm._host_pinned



# Generated at 2022-06-11 16:52:34.186077
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    scm = StrategyModule(None)
    assert scm._host_pinned == True
    assert scm._batches == list()
    assert scm._inventory is None
    assert scm._variable_manager is None
    assert scm._loader is None

# Generated at 2022-06-11 16:52:35.998477
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    s = StrategyModule(tqm)
    assert s._host_pinned == True

# Generated at 2022-06-11 16:52:36.681347
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-11 16:52:42.017617
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MagicMock(spec=['stats'])
    tqm.stats = {'dark': {}}
    tqm.__class__ = MagicMock
    tqm.__class__.__name__ = 'AdHocManager'
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-11 16:52:48.143945
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # The constructor of StrategyModule is tested indirectly by the tests including test_host_pinned_strategy.py
    # since the constructor of class StrategyModule is called from inside of the load_strategy method
    # of the ansible.plugins.strategy.__init__ file, so it is tested indirectly.
    pass

# Generated at 2022-06-11 16:52:50.225557
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    test = StrategyModule(display)
    assert isinstance(test, FreeStrategyModule)

# Generated at 2022-06-11 16:53:00.887734
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    import collections
    import ansible.plugins.strategy.host_pinned
    import ansible.playbook.task
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.block
    import ansible.template
    import ansible.vars.manager
    import ansible.utils.vars

    # create a dummy task for testing
    task1 = ansible.playbook.task.Task()
    task1._role = None
    task1._block = ansible.playbook.block.Block()
    task1._role_name = 'dummy'
    task1._parent = None
    task1._dep_chain = ansible.utils.vars.VariableManager([])
    task1._role = None
    task1._loader = None

# Generated at 2022-06-11 16:53:02.690865
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule("")
    assert x

# Generated at 2022-06-11 16:53:03.423588
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(1)._host_pinned == True

# Generated at 2022-06-11 16:53:05.588628
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    tm = ansible.plugins.strategy.host_pinned.StrategyModule('test')
    assert tm._host_pinned == True
    assert hasattr(tm, 'display')
    assert hasattr(tm.display, 'display')

# Generated at 2022-06-11 16:53:08.281496
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_tqm = None
    sm = StrategyModule(my_tqm)

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-11 16:53:09.305204
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned is True

# Generated at 2022-06-11 16:53:11.492994
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm._host_pinned

# Generated at 2022-06-11 16:53:12.581732
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-11 16:53:13.646894
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 16:53:20.791453
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    tqm = {"_finished_hosts": ["test123"], "_worker_prc": {"test123": True}, "_notified_handlers": True, "display": display}
    tqm_1 = {"_finished_hosts": ["test123"], "_worker_prc": {"test123": True}, "_notified_handlers": True}
    tqm_2 = {"_finished_hosts": ["test123"], "_worker_prc": "test123", "_notified_handlers": True}
    tqm_3 = {"_finished_hosts": ["test123"], "_worker_prc": ["test123"], "_notified_handlers": True}

# Generated at 2022-06-11 16:53:22.392652
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule("tqm")
    assert strategy is not None

# Generated at 2022-06-11 16:53:35.476971
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# vim: set expandtab shiftwidth=4: #
# -*- coding: utf-8 -*-
#
# (c) 2012-2014, Michael DeHaan <michael.dehaan@gmail.com>
#
# This file is part of Ansible
#
# Ansible is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Ansible is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a

# Generated at 2022-06-11 16:53:36.359862
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    c = StrategyModule()



# Generated at 2022-06-11 16:53:37.236836
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None) is not None

# Generated at 2022-06-11 16:53:38.986367
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-11 16:53:41.455024
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  assert StrategyModule.__doc__ != None
  assert StrategyModule.__init__.__doc__ != None
  assert StrategyModule(Display())._host_pinned == True

# Generated at 2022-06-11 16:53:42.398448
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-11 16:53:43.097497
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:53:45.602964
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    obj = StrategyModule(tqm)
    assert(obj != None)



# Generated at 2022-06-11 16:53:48.663158
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Mock the required args
    tqm = "tqm"

    # Call the constructor
    obj = StrategyModule(tqm)
    # TODO: there should probably be some asserts here...

# Generated at 2022-06-11 16:53:50.078554
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule, object)


# Generated at 2022-06-11 16:53:54.602885
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 16:53:57.566177
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_object = StrategyModule()
    
    

# Generated at 2022-06-11 16:54:00.070379
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned == True

# Generated at 2022-06-11 16:54:01.236905
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-11 16:54:02.863619
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)

    assert strategy._host_pinned == True

# Generated at 2022-06-11 16:54:03.494354
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:54:04.481583
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-11 16:54:06.354600
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm = None)
    assert strategy_module._host_pinned == True


# Generated at 2022-06-11 16:54:09.966968
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.strategy import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(None, None, None, None, None, None)
    strategy = strategy_loader.get('host_pinned', tqm)
    assert(isinstance(strategy,StrategyModule))


# Generated at 2022-06-11 16:54:11.798610
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(None)
    assert a is not None


# Generated at 2022-06-11 16:54:20.302033
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-11 16:54:21.442048
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)

# Generated at 2022-06-11 16:54:23.161049
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import host_pinned
    assert host_pinned is not None

# Generated at 2022-06-11 16:54:23.742665
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:54:27.412634
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor


# Generated at 2022-06-11 16:54:28.152672
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:54:29.448128
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy!=None

# Generated at 2022-06-11 16:54:32.045555
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)

    assert strategy_module._host_pinned is True

# Test StrategyModule.run function

# Generated at 2022-06-11 16:54:37.219358
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create instance of class StrategyModule
    strategy_module = StrategyModule(None)
    # Test if is the instantiated class StrategyModule
    assert isinstance(strategy_module, StrategyModule)
    # Test if the instance of the class StrategyModule is an instance of the class FreeStrategyModule
    assert isinstance(strategy_module, FreeStrategyModule)

# Generated at 2022-06-11 16:54:38.733885
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    strategy_module = StrategyModule(display)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:54:58.352620
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule(None)
    strategy = StrategyModule(tqm)
    assert strategy is not None
    assert strategy._host_pinned

# Generated at 2022-06-11 16:54:59.601195
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'


# Generated at 2022-06-11 16:55:06.821828
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestConnection(object):
        def __init__(self, host, port=None):
            self.host = host
            self.port = port
        def _connect(self):
            pass
        def exec_command(self, cmd, tmp_path, sudo_user=None, sudoable=False, executable='/bin/sh', in_data=None, su=None, su_user=None):
            return (0, '', '')
        def put_file(self, in_path, out_path):
            pass
        def fetch_file(self, in_path, out_path):
            pass
        def close(self):
            pass
    class TestInventory(object):
        def get_hosts(self, pattern="all"):
            return ['localhost']

# Generated at 2022-06-11 16:55:11.355197
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = load_fixture('initialized_task_queue_manager')
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None
    assert strategy_module.tqm is tqm
    assert strategy_module._host_pinned



# Generated at 2022-06-11 16:55:13.774383
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    StrategyModule('tqm')



# Generated at 2022-06-11 16:55:14.954390
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)


# Generated at 2022-06-11 16:55:17.123953
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert dir(StrategyModule) == dir(FreeStrategyModule)

# Generated at 2022-06-11 16:55:18.236571
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)._host_pinned == True


# Generated at 2022-06-11 16:55:20.031168
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm)
    assert module._host_pinned == True




# Generated at 2022-06-11 16:55:30.720434
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy_host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common.collections import ImmutableDict
    import ansible.constants as C

    # Create a task queue manager

# Generated at 2022-06-11 16:56:18.593911
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display_ut = Display()
    display_ut.set_verbosity('5')
    tm = True
    sm = StrategyModule(tm)
    assert sm.get_tqm() == tm
    assert sm.get_display() == display_ut
    assert sm.get_host_pinned() == True


# Generated at 2022-06-11 16:56:22.547023
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class MockTQM:
        def __init__(self):
            self._host_pinned = True

    tqm_object = MockTQM()
    strategy_object = StrategyModule(tqm_object)
    assert strategy_object._host_pinned

# Generated at 2022-06-11 16:56:31.071151
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.handler
    import ansible.plugins.loader
    import ansible.plugins.strategy
    import ansible.utils.context_objects
    import ansible.utils.display
    import ansible.utils.loader
    import ansible.utils.plugin_docs
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars
    from ansible.vars.clean import module_response_deepcopy
    from ansible.vars.hostvars import HostVars

# Generated at 2022-06-11 16:56:34.647954
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    result = ansible.plugins.strategy.host_pinned.StrategyModule(None)
    assert result.__class__.__name__ == 'StrategyModule'

# Generated at 2022-06-11 16:56:35.898901
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None


# Generated at 2022-06-11 16:56:40.011307
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert isinstance(s, StrategyModule) == True
    assert s._host_pinned == True

# Generated at 2022-06-11 16:56:40.678313
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-11 16:56:41.272712
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:56:49.443329
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.playbook.task_queue_manager import TaskQueueManager
    from ansible.executor.task_queue_manager import TaskQueueManager as ExecutorTaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import os
    import sys
    from ansible.constants import DEFAULT_MODULE_PATH
    from ansible.utils.display import Display
    from ansible.utils.shlex import shlex_split
    from ansible.vars.manager import VariableManager
    # import pdb; pdb.set_trace()
    tqm = TaskQueueManager()
    display = Display()
    inventory = "/etc/ansible/hosts"
    loader = None

# Generated at 2022-06-11 16:56:52.370510
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = False
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned is True
    assert strategy._batch is None

# Generated at 2022-06-11 16:58:33.215565
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    obj = StrategyModule(tqm)
    assert obj is not None

# Generated at 2022-06-11 16:58:33.781909
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return True

# Generated at 2022-06-11 16:58:34.703744
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:58:37.937146
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("*** test_StrategyModule()")

    tqm = None
    try:
        t = StrategyModule(tqm)
    except:
        print("Failed to create instance of host_pinned")
        assert(False)

# Generated at 2022-06-11 16:58:38.804175
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)._host_pinned == True

# Generated at 2022-06-11 16:58:39.977199
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        assert False
    except AssertionError:
        assert True

# Generated at 2022-06-11 16:58:40.553839
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(object())

# Generated at 2022-06-11 16:58:42.408536
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=[])
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:58:53.453228
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.module_utils import basic
    from ansible.playbook.play_context import PlayContext

    class Host(object):
        def __init__(self, name):
            self.name = name
            self.vars = dict()
            self.groups = []

    class Play(object):
        def __init__(self):
            self.hosts = []
            self.tasks = []

        def get_vars(self):
            return dict()

    class Task(object):
        pass

    class ActionModule(object):
        def __init__(self):
            self.module_name = "test"

        def run(self, tmp=None, task_vars=None):
            return dict(msg="Hello, world.")


# Generated at 2022-06-11 16:58:54.796047
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    assert obj._host_pinned == True


# Generated at 2022-06-11 17:02:20.228073
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 17:02:22.211750
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm=None)
    assert module._host_pinned == True