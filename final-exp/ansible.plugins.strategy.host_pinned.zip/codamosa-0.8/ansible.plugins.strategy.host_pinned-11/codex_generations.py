

# Generated at 2022-06-11 16:52:27.092727
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Test function constructor in Ansible module"""
    # TODO: Need to check the parameters of StrategyModule
    #assert (strategy == 'strategy_pinned')
    return True


# Generated at 2022-06-11 16:52:29.268438
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    tqm = MagicMock()
    StrategyModule(tqm)

# Generated at 2022-06-11 16:52:31.305578
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = None
    sm = StrategyModule(tqm=test_tqm)
    assert sm._host_pinned

# Generated at 2022-06-11 16:52:32.902668
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert False


# Generated at 2022-06-11 16:52:34.770330
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global StrategyModule
    tqm = object
    strategy = StrategyModule(tqm)

# Generated at 2022-06-11 16:52:36.513401
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule()
        assert True
    except Exception as e:
        assert False

# Generated at 2022-06-11 16:52:39.456736
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   tqm=object
   strategy_module=StrategyModule(tqm)
   assert strategy_module is not None

# Generated at 2022-06-11 16:52:41.185467
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm='tqm')
    assert strategy._host_pinned == True


# Generated at 2022-06-11 16:52:43.354510
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        StrategyModule(tqm)
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 0

# Generated at 2022-06-11 16:52:52.594634
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    class TQM:
        pass

    tqm = TQM()
    tqm.get_vars = True
    tqm.start_at_task = True
    tqm.send_callback = True
    tqm._final_q = True
    tqm._workers = True
    tqm.get_inventory = True
    tqm.notified_handlers = True
    tqm.finished_hosts = True
    tqm._inventory = True
    tqm._last_task_banner = True
    tqm._failed_hosts = True
    tqm.stats = True
    tqm.inventory = True
    tqm.callback = True
    tqm._play = True
    tqm._cur_serial_failure_count = True


# Generated at 2022-06-11 16:53:02.721100
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-11 16:53:03.423774
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)
    assert(True)

# Generated at 2022-06-11 16:53:05.412768
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        instance = StrategyModule()
    except NameError as e:
        assert False, "Unexpected exception raised: " + str(e)
    except Exception:
        assert False, "Unhandled exception raised"
    else:
        assert isinstance(instance, object)


# Generated at 2022-06-11 16:53:09.981731
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '_host_pinned'), \
        "Class 'StrategyModule' does not have attribute '_host_pinned'"
    assert StrategyModule._host_pinned == True, \
        "Class 'StrategyModule' does not initialize attribute '_host_pinned' " \
        "with value 'True'"

# Generated at 2022-06-11 16:53:19.397368
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Initialize the class
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned is True, "Should be True"
    assert strategy_module._tqm is None, "Should be None"
    assert strategy_module._inventory is None, "Should be None"
    assert strategy_module._loader is None, "Should be None"
    assert strategy_module._variable_manager is None, "Should be None"
    assert strategy_module._all_vars is None, "Should be None"
    assert strategy_module._play is None, "Should be None"
    assert strategy_module._options is None, "Should be None"
    assert strategy_module._stdout_callback is None, "Should be None"
    assert strategy_module._internal_state is None, "Should be None"

# Generated at 2022-06-11 16:53:26.429812
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")

    # Creating a new instance of class FreeStrategyModule
    strategy_module = FreeStrategyModule(None)

    # Testing if the "__init__" method raises an AttributeError
    print("Testing if the \"__init__\" method raises an AttributeError")
    try:
        strategy_module.__init__()
    except AttributeError:
        print("Passed test")
    else:
        print("Failed test")


# Generated at 2022-06-11 16:53:28.399621
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(tqm='tqm'), StrategyModule)


# Generated at 2022-06-11 16:53:28.899470
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Generated at 2022-06-11 16:53:35.250107
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import mock
    unittest.mock.patch('ansible.plugins.strategy.host_pinned.StrategyModule.__init__')
    unittest.mock.patch('ansible.plugins.strategy.host_pinned.StrategyModule._host_pinned')
    unittest.mock.patch('ansible.plugins.strategy.host_pinned.display')


# Generated at 2022-06-11 16:53:35.807893
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:53:38.444531
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1 == 1

# Generated at 2022-06-11 16:53:40.176210
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  test = StrategyModule()
  assert test._host_pinned == True

# Generated at 2022-06-11 16:53:40.679230
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-11 16:53:50.275094
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Test constructor of class StrategyModule
    """
    # Check if the constructor is changed
    assert StrategyModule.__init__.__code__.co_argcount == 2
    # Check if the init method is overridden
    assert StrategyModule.__init__.__dict__['__func__'] is not FreeStrategyModule.__init__.__dict__['__func__']

if __name__ == "__main__":
    import nose
    import sys
    sys.argv.append("--cover-package=ansible.plugins.strategy.host_pinned")
    sys.argv.append("--cover-branches")
    sys.argv.append("--cover-erase")
    nose.runmodule()

# Generated at 2022-06-11 16:53:55.052619
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(None,None,None,None,None)
    result = StrategyModule(tqm)
    assert isinstance(result,StrategyBase)
    assert result._host_pinned == True

# Generated at 2022-06-11 16:53:58.041149
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    s = StrategyModule(tqm)
    assert isinstance(s, FreeStrategyModule)
    assert hasattr(s, '_host_pinned')
    assert s._host_pinned == True

# Generated at 2022-06-11 16:53:59.453544
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-11 16:54:03.357550
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager('/etc/ansible/hosts')
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned

# Generated at 2022-06-11 16:54:07.206878
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy
    import ansible.plugins.strategy.host_pinned
    reload(ansible.plugins.strategy)
    reload(ansible.plugins.strategy.host_pinned)
    obj = ansible.plugins.strategy.host_pinned.StrategyModule(None)
    assert obj._host_pinned

# Generated at 2022-06-11 16:54:11.736899
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule({})
    assert isinstance(strategyModule, StrategyModule)
    assert not isinstance(strategyModule, FreeStrategyModule)
    assert hasattr(strategyModule, "_host_pinned")
    assert strategyModule._host_pinned == True

# Generated at 2022-06-11 16:54:17.622937
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tmp = StrategyModule(None)
    assert tmp._host_pinned is True

# Generated at 2022-06-11 16:54:22.467169
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global display
    # Using display to capture output from calling constructor
    # creating class StrategyModule
    display = Display()
    sm = StrategyModule(tqm = None)
    # check if _host_pinned attribute is true
    assert(sm._host_pinned == True)
    # Display should have called initialized
    assert(display.display == 'Initializing strategy host_pinned\n')

# Generated at 2022-06-11 16:54:23.795698
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_instance = StrategyModule(None)
    assert test_instance._host_pinned

# Generated at 2022-06-11 16:54:31.278194
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

    parser = None


# Generated at 2022-06-11 16:54:33.758720
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule([])
    res = StrategyModule(tqm)
    assert res._host_pinned is True

# Generated at 2022-06-11 16:54:35.329771
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule('Tqm'), object)


# Generated at 2022-06-11 16:54:38.035450
# Unit test for constructor of class StrategyModule
def test_StrategyModule(): 
    # Exercise 1: print values of different variables in __init__(self, tqm)
    StrategyModule.__init__(tqm)


# Generated at 2022-06-11 16:54:38.943584
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)


# Unit test

# Generated at 2022-06-11 16:54:41.398837
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-11 16:54:44.400920
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = None
  s = StrategyModule(tqm)
  assert s._host_pinned == True


# Generated at 2022-06-11 16:54:53.873451
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm=None)
    assert s._host_pinned

# Generated at 2022-06-11 16:54:56.121836
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy._host_pinned is True
    assert strategy._play is not None

# Generated at 2022-06-11 16:54:59.030498
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm)
    if strategy_module is not None:
        print("successful in calling class StrategyModule")
    else:
        print("error in calling class StrategyModule")

# Generated at 2022-06-11 16:55:01.469923
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(1)
    assert strategy_module is not None

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-11 16:55:02.843757
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-11 16:55:04.604654
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule('tqm');

# Generated at 2022-06-11 16:55:12.462631
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    tqm = TaskQueueManager(
        inventory=Inventory(loader=null_loader, variable_manager=VariableManager(loader=null_loader, inventory=inventory)),
        variable_manager=VariableManager(loader=null_loader, inventory=inventory),
        loader=null_loader,
        options=options,
        passwords=passwords,
        stdout_callback=display.display,
    )
    strategy_module_obj = StrategyModule(tqm)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-11 16:55:16.770678
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = DummyTQM()
    s = StrategyModule(tqm)
    assert s.tqm == tqm
    assert s._host_pinned

# Generated at 2022-06-11 16:55:17.285860
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  pass

# Generated at 2022-06-11 16:55:18.381231
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module is not None

# Generated at 2022-06-11 16:55:39.361445
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__

# Generated at 2022-06-11 16:55:46.752302
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.template import Templar
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager

    strategy_module = StrategyModule()


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-11 16:55:47.840297
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-11 16:55:49.538456
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    free_obj = FreeStrategyModule.__init__(FreeStrategyModule)
    assert free_obj._host_pinned == False

# Generated at 2022-06-11 16:55:58.817682
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestClass(object):
        pass
    obj = TestClass()
    obj.tqm = TestClass()
    obj.tqm.serial = 1
    obj.tqm.send_callback = TestClass()
    obj.tqm.send_callback.on_any = TestClass()
    obj.tqm.stats = TestClass()
    obj.tqm.hostvars = {}
    obj.tqm.inventory = {}
    obj.tqm.inventory.hosts = {}
    obj.tqm.inventory.get_hosts = TestClass()
    obj.tqm.Builder = TestClass()
    obj.tqm.Builder.load_file = TestClass()
    obj.tqm.Tqm = TestClass()
    obj.tqm.ph = TestClass

# Generated at 2022-06-11 16:56:00.648407
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.name == 'host_pinned'

# Generated at 2022-06-11 16:56:01.308026
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:56:03.375247
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)

# vim: set expandtab: ts=4: sw=4:

# Generated at 2022-06-11 16:56:08.213965
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print ("Testing Strategy module")
    my_strategy = StrategyModule('tqm')
    print (my_strategy._host_pinned)
    assert my_strategy._host_pinned == True

# Calling the main function
if __name__ == '__main__':
    test_StrategyModule()
    print ("Test Completed Successfully")

# Generated at 2022-06-11 16:56:13.384841
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible import context, display
    context._init_global_context(123)
    display._init_global_context(123)
    display.verbosity = 123
    display.debug = 123
    display.deprecated = 123
    display.skipped = 123
    display.unreachable = 123
    sm = StrategyModule("test")
    assert sm._host_pinned is True

# Generated at 2022-06-11 16:56:45.604933
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)


# Generated at 2022-06-11 16:56:55.836268
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ create a task queue manager and a strategy module on top
        of it and run through __init__()"""
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.runner.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory

    play_context = PlayContext()

# Generated at 2022-06-11 16:56:58.402995
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = 'tqm'
  obj = StrategyModule(tqm)
  assert obj._host_pinned == True

# Generated at 2022-06-11 16:56:59.513870
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: How to test a class constructor?
    pass

# Generated at 2022-06-11 16:57:02.881851
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create an object of class FreeStrategyModule
    # As __init__ of StrategyModule is not implemented,
    # this will call __init__ of FreeStrategyModule
    strategy_module = StrategyModule(tqm=None)

    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:57:04.241199
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = []
    StrategyModule(tqm)

# Generated at 2022-06-11 16:57:06.229550
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule('tqm')
    assert(strategy)
    assert(strategy._host_pinned)

# Generated at 2022-06-11 16:57:06.988291
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 16:57:07.942831
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-11 16:57:15.534942
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test'
    strategy_name = 'host_pinned'
    strategy_task = StrategyModule(tqm)
    assert strategy_task._host_pinned is True
    assert strategy_task._host_pinned == True
    assert strategy_task.get_name() == strategy_name
    assert strategy_task.get_name() == 'host_pinned'
    assert strategy_task.get_name() == 'host_pinned'
    assert strategy_task.display is not None
    assert strategy_task.display == display


# Generated at 2022-06-11 16:58:48.925746
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule
    tqm.__init__
    assert tqm.__init__



# Generated at 2022-06-11 16:58:50.370147
# Unit test for constructor of class StrategyModule
def test_StrategyModule():   
    obj = StrategyModule("obj")
    assert(obj._host_pinned == True)

# Generated at 2022-06-11 16:58:51.576076
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    temp = StrategyModule(None)
    assert temp._host_pinned is True

# Generated at 2022-06-11 16:58:53.375335
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule
    s = StrategyModule(tqm)
    assert s._host_pinned == True

# Generated at 2022-06-11 16:58:55.710160
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a new StrategyModule object
    x = StrategyModule(None)
    # Verify that the constructor of BaseStrategyModule was called
    # (creating a new object of class FreeStrategyModule)
    assert x._host_pinned == True

# Generated at 2022-06-11 16:58:58.053555
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Constructor')
    tqm = None
    sm = StrategyModule(tqm)
    print('Done')


# Generated at 2022-06-11 16:59:08.363025
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.utils.shlex
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible import constants as C
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import callback_loader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    # Reset displayed

# Generated at 2022-06-11 16:59:10.520014
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(None), FreeStrategyModule)
    assert isinstance(StrategyModule(None), StrategyModule)

# Generated at 2022-06-11 16:59:10.948889
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-11 16:59:12.271908
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test = StrategyModule(None)
    assert test._host_pinned
