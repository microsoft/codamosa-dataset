

# Generated at 2022-06-11 16:52:29.200565
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    test StrategyModule class constructor
    '''
    tqm = None
    mod = StrategyModule(tqm)
    assert mod._host_pinned == True

# Generated at 2022-06-11 16:52:30.879718
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    assert StrategyModule(tqm)._host_pinned



# Generated at 2022-06-11 16:52:32.902761
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task_queue_manager = ''
    StrategyModule(task_queue_manager)

# Generated at 2022-06-11 16:52:36.236370
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    testobj = ansible.plugins.strategy.host_pinned.StrategyModule('test')
    assert testobj._host_pinned == True

# Generated at 2022-06-11 16:52:38.689535
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global StrategyModule
    test_obj = StrategyModule()
    assert test_obj

# Generated at 2022-06-11 16:52:40.730830
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:52:42.338321
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass
# Importing the strategy and calling it's constructor
strat = StrategyModule.__name__
StrategyModule(strat)

# Generated at 2022-06-11 16:52:45.403138
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'


# Generated at 2022-06-11 16:52:46.259034
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:52:53.293198
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing class StrategyModule")

    # Constructor test
    ###################

    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.utils.display import Display
    from ansible.plugins.strategy.free import FreeStrategyModule
    from ansible.playbook.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback.default import CallbackModule
    #from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-11 16:52:55.841342
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-11 16:53:05.406536
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_queue_manager import TaskQueueManager
    from ansible.template import Templar
    from ansible.plugins.loader import strategy_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.stats import AggregateStats

    if not strategy_loader.all():
        strategy_loader.add_directory('./lib/ansible/plugins/strategy')

# Generated at 2022-06-11 16:53:06.121525
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(object)

# Generated at 2022-06-11 16:53:07.466953
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TestQManager()
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned

# Generated at 2022-06-11 16:53:09.401967
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    strategy._host_pinned = True


# Make sure the constructor can be called

# Generated at 2022-06-11 16:53:12.168488
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    assert callable(StrategyModule)

# Generated at 2022-06-11 16:53:13.690956
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)


# Generated at 2022-06-11 16:53:15.280831
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()
    assert s._host_pinned==True

test_StrategyModule()

# Generated at 2022-06-11 16:53:16.349519
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_obj = StrategyModule(None)
    assert strategy_obj is not None



# Generated at 2022-06-11 16:53:16.843859
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:53:19.568750
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   pass

# Generated at 2022-06-11 16:53:30.812598
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    tqm = free.tqm = Mock()
    StrategyModule(tqm)

    print("assert_called_once_with(1) called")
    StrategyModule.assert_called_once_with(1)

    print("assert_called_once_with(tqm) called")
    StrategyModule.assert_called_once_with(tqm)

# Generated at 2022-06-11 16:53:35.163807
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule.__init__(FreeStrategyModule, tqm)
    assert tqm.__class__.__name__ == 'FreeStrategyModule'
    assert tqm.__class__.__name__ == 'StrategyModule'

# Generated at 2022-06-11 16:53:42.490511
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    tqm = dict()
    tqm['_final_q_empty'] = False
    tqm['_failed_hosts'] = dict()
    tqm['stats'] = dict()
    tqm['inventory'] = dict()
    tqm['_inventory_does_not_require_pipelining'] = False
    tqm['_inventory_host_pattern'] = '*'
    tqm['_inventory_list'] = dict()
    tqm['_inventory_list']['all'] = dict()
    tqm['_inventory_list']['all']['hosts'] = True
    tqm['_inventory_list']['all']['vars'] = True

# Generated at 2022-06-11 16:53:48.446698
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule as host_pinned
    from ansible.errors import AnsibleError
    # class Host, we will pass to Host as a constructor
    fake_tqm = "fake_tqm"
    test_strategy = host_pinned(fake_tqm)

    assert test_strategy._host_pinned == True

# Generated at 2022-06-11 16:53:49.969814
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-11 16:53:55.744967
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock
    import sys
    tqm_object = mock.Mock()
    tqm_object.display = display
    tqm_object.loader = None
    tqm_object.stats = None
    tqm_object.options = None
    tqm_object.variable_manager = None
    strategy_object = StrategyModule(tqm_object)
    assert isinstance(strategy_object, StrategyModule)

# Unit test of calling test_StrategyModule()

# Generated at 2022-06-11 16:53:58.209045
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  strategy_module = StrategyModule(None)
  assert strategy_module

# Generated at 2022-06-11 16:54:00.275693
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Instantiate the StrategyModule with a tqm
    strategy = StrategyModule("some queue manager instance")

    # Test StrategyModule attributes
    assert strategy._host_pinned is True
    assert strategy._display is not None

# Generated at 2022-06-11 16:54:01.854226
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule({})
    assert s._host_pinned == True

# Generated at 2022-06-11 16:54:06.172971
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:54:07.161766
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert type(StrategyModule(None)) is StrategyModule

# Generated at 2022-06-11 16:54:07.816684
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:54:09.409288
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm._host_pinned is True

# Generated at 2022-06-11 16:54:11.799359
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule as strategy_module
    assert strategy_module

# Generated at 2022-06-11 16:54:13.884446
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 123
    q = StrategyModule(tqm)
    assert q.tqm == 123

# Generated at 2022-06-11 16:54:17.481686
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = []
    strm = StrategyModule(tqm)
    assert isinstance(strm, StrategyModule)
    assert isinstance(strm, FreeStrategyModule)
    assert strm._host_pinned


# Generated at 2022-06-11 16:54:19.554791
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Constructor without arguments
    strategy = StrategyModule()
    # Check the class of the object
    assert isinstance(strategy, object)



# Generated at 2022-06-11 16:54:21.844685
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert(strategy_module._host_pinned == True)

# Generated at 2022-06-11 16:54:30.175547
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-11 16:54:39.108188
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True

# Generated at 2022-06-11 16:54:41.536538
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    test_obj = StrategyModule(tqm)
    assert True

# Generated at 2022-06-11 16:54:50.940758
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Fake_TQM(object):
        def __init__(self):
            self.stats = Fake_Stats()
            self.hostvars = dict()

    class Fake_Stats(object):
        def __init__(self):
            self.hosts = dict()

    fake_tqm = Fake_TQM()
    fake_tqm.hostvars[u'test1.example.com'] = dict()
    fake_tqm.hostvars[u'test2.example.com'] = dict()

# Generated at 2022-06-11 16:54:52.406650
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = []
    StrategyModule(tqm)

# Generated at 2022-06-11 16:54:54.554691
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Create a strategy module object
    tqm = None # Dummy value for tqm
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True, 'Host pinned is False'

# Generated at 2022-06-11 16:55:00.392669
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    h = StrategyModule(tqm)
    assert h._host_pinned == True
    assert h.get_host_list() is None
    assert h.get_next_task_lockfile(hostname=None) is None
    assert h.get_next_task_for_host(host=None, peek=False) is None
    assert h.run_handlers() is None
    assert h.save_tasks() is None

# Generated at 2022-06-11 16:55:01.618024
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=0)


# Generated at 2022-06-11 16:55:02.703532
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule, type)


# Generated at 2022-06-11 16:55:04.852494
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    assert obj._host_pinned == True

# Generated at 2022-06-11 16:55:06.774581
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule()
    except Exception as e:
        assert(False)

# Generated at 2022-06-11 16:55:28.420335
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned = StrategyModule()
    assert host_pinned._host_pinned == True

# Generated at 2022-06-11 16:55:33.488990
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        assert False, "WTF!!!"
    except AssertionError as e: raise e
    except: pass

    try:
        assert tqm._stats
    except AssertionError as e: raise e
    except: pass

    try:
        assert tqm.get_hosts(), "no hosts found"
    except AssertionError as e: raise e
    except Exception as e:
        print('EXCEPTION:', e)
        raise e


tqm = {'_stats': '???'}
hosts = [{'hostname': 'host1'}, {'hostname': 'host2'}]


test_StrategyModule()

# Generated at 2022-06-11 16:55:34.081316
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:55:36.487140
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)

    assert strategy._host_pinned == True

# vi: ts=4 expandtab syntax=python

# Generated at 2022-06-11 16:55:40.606710
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  # Test if the constructor creates a new StrategyModule object
  tqm = object()
  try:
    strategy_module = StrategyModule(tqm)
    print("StrategyModule object:", strategy_module)
    assert bool(strategy_module) == True
  except Exception as ex:
    print("Exception:", ex)

# Test if the test case passes
test_StrategyModule()

# Generated at 2022-06-11 16:55:41.401774
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:55:42.901838
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Test Strategy Module constructor"""
    tqm = Mock()
    StrategyModule(tqm)

# Generated at 2022-06-11 16:55:51.610746
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.callbacks import DefaultRunnerCallbacks
    from ansible.utils.display import Display
    display = Display()

    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=DefaultRunnerCallbacks(),
        run_additional_callbacks=None,
        run_tree=False,
        halt_on_unreachable=False,
        halt_on_task_error=False,
        mapped_tower_instance_ids=None,
        enable_remote_user_module=False,
        enable_network_cli_module=False,
    )
   

# Generated at 2022-06-11 16:55:55.237035
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   strategy_module = StrategyModule(1)

   # Show that __str__ returns a string
   assert isinstance(str(strategy_module), str)

   # Show that the value has been set
   assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:55:56.038018
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-11 16:56:35.929088
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager("/usr/bin/ansible", "/usr/bin/ansible", "/etc/ansible/hosts", "/etc/ansible/ansible.cfg", "/etc/ansible/roles", "/usr/bin/ansible")
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True
    assert strategy._blocked_hosts == {}

# Generated at 2022-06-11 16:56:38.787859
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  assert StrategyModule(tqm)._host_pinned == True

# Generated at 2022-06-11 16:56:39.609867
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-11 16:56:43.861929
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager()
    StrategyModule(tqm)
    tqm.cleanup()
    del tqm

# Generated at 2022-06-11 16:56:44.741062
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()


# Generated at 2022-06-11 16:56:50.374458
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert isinstance(StrategyModule, type)
    Module = StrategyModule

    tqm = 'test'
    module = Module(tqm)

    assert module._host_pinned == True
    assert module._tqm == 'test'

# Generated at 2022-06-11 16:56:51.242751
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(True)

# Generated at 2022-06-11 16:56:53.977400
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategymodule = StrategyModule()
    print("myStrategyModule in test")
    assert(strategymodule.myStrategyModule == "myStrategyModule")
    

# Generated at 2022-06-11 16:56:55.751833
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:56:57.748759
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    _tqm = None
    _run = StrategyModule(_tqm)
    assert _run is not None

# Generated at 2022-06-11 16:58:34.004718
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # this is the default.
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned

# Generated at 2022-06-11 16:58:36.120507
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    test_StrategyModule = StrategyModule(tqm)
    assert test_StrategyModule._host_pinned == True

# Generated at 2022-06-11 16:58:36.942101
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:58:39.542107
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule()
    assert isinstance(x, StrategyModule)
    assert x._host_pinned


from ansible.plugins.strategy import StrategyBase
from ansible.errors import AnsibleError


# Generated at 2022-06-11 16:58:40.376932
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-11 16:58:41.632160
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule("Test")
    assert module._host_pinned == True

# Generated at 2022-06-11 16:58:42.703100
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm = 'tqm')

# Generated at 2022-06-11 16:58:44.826909
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:58:54.898518
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        from ansible.executor.task_queue_manager import TaskQueueManager
        from ansible.inventory.manager import InventoryManager
        from ansible.parsing.dataloader import DataLoader
        from ansible.vars.manager import VariableManager
    except ImportError as e:
        raise RuntimeError('Unable to import module ({})'.format(e))

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-11 16:58:56.090038
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True

# Generated at 2022-06-11 17:02:14.722255
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test Strategy Module constructor
    try:
        from ansible.plugins.strategy.free import StrategyModule
        from ansible.utils.display import Display
        display = Display()
        tqm = display
        StrategyModule(tqm)
    except Exception as err:
        assert False, "StrategyModule constructor did not work as expected"
    else:
        assert True, "StrategyModule constructor worked as expected"

# Generated at 2022-06-11 17:02:15.429704
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  pass

# Generated at 2022-06-11 17:02:15.946417
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 17:02:16.599324
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 17:02:19.584303
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestClass():
        def __init__(self):
            self.tqm = 1
    tc = TestClass()
    StrategyModule(tc.tqm)

# Generated at 2022-06-11 17:02:21.153817
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategyModule = StrategyModule(tqm)
    assert strategyModule is not None

# Generated at 2022-06-11 17:02:22.029530
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 17:02:23.154754
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)

# Generated at 2022-06-11 17:02:24.482100
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(1)
    assert strategy._host_pinned == True

# Generated at 2022-06-11 17:02:28.165545
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print (StrategyModule)
    print (StrategyModule.__doc__)
    print (StrategyModule.__dict__)
    strategy = StrategyModule()
    print (strategy)
    print (strategy.__doc__)
    print (strategy.__dict__)
    
    
test_StrategyModule()