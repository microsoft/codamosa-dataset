

# Generated at 2022-06-11 16:52:28.259008
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  strategy_module = StrategyModule(tqm = None)
  assert strategy_module != None

# Generated at 2022-06-11 16:52:30.344203
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)._host_pinned == True

# Generated at 2022-06-11 16:52:32.729343
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    Obj = StrategyModule(tqm)
    assert Obj._host_pinned == True

# Generated at 2022-06-11 16:52:35.796318
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    class FakeTQM(object):
        pass

    tqm = FakeTQM()
    result = StrategyModule(tqm)
    assert result._host_pinned is True

# Generated at 2022-06-11 16:52:37.086196
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-11 16:52:40.085410
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:52:42.087726
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule("tqm")
    assert obj.__dict__ == {'tqm':'tqm','_host_pinned':True}


# Generated at 2022-06-11 16:52:45.665234
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)
    assert strategy
    assert strategy._host_pinned

# Generated at 2022-06-11 16:52:48.018179
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-11 16:52:55.381083
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(None)
    assert a._host_pinned == True
    assert a._limit_for_loop == True
    assert a._wait_for_available_results == True
    assert a._wakeup_parents_loop == True
    assert a._tqm.stats.processed == {}
    assert a._worker_prune_results == {}
    assert a._workers == {}
    assert a._unreachable_hosts == {}


# Generated at 2022-06-11 16:52:57.706628
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm=None)
    assert module._host_pinned


# Test get_hosts_remaining method

# Generated at 2022-06-11 16:52:59.051049
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mock_tqm = None
    strategy = StrategyModule(mock_tqm)

# Generated at 2022-06-11 16:53:00.739248
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm='tqm')

# Generated at 2022-06-11 16:53:01.475602
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:53:02.782649
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned

# Generated at 2022-06-11 16:53:03.239483
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:53:03.658993
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return None

# Generated at 2022-06-11 16:53:05.355157
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Returns the StrategyModule object if it is created
    assert True

# Generated at 2022-06-11 16:53:11.000611
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule constructor")
    config = dict(
                    forks=100,
                    remote_user='slotlocker'
                    )
    tqm = MagicMock()
    tqm.get_vars.return_value = dict()

    strategy = StrategyModule(tqm)
    class_attributes = dir(strategy)
    assert '_host_pinned' in class_attributes
    assert strategy._host_pinned == True

# Generated at 2022-06-11 16:53:14.509991
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    if sm._host_pinned:
        print("Unit test has passed successfully")
    else:
        print("Unit test has failed")

# Generated at 2022-06-11 16:53:19.611914
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm = None)

    assert hasattr(strategy_module, '_host_pinned'), "strategy_module: Class StrategyModule has no attr named _host_pinned"

# Generated at 2022-06-11 16:53:20.783326
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()

# Generated at 2022-06-11 16:53:21.982118
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module=StrategyModule(tqm)

# Generated at 2022-06-11 16:53:33.542589
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class DummyCallbacks(object):
        def on_any(self, *args, **kwargs):
            pass
        def runner_on_failed(self, host, res, ignore_errors=False):
            pass
        def runner_on_ok(self, host, res):
            pass
        def runner_on_skipped(self, host, item=None):
            pass
        def runner_on_unreachable(self, host, res):
            pass
        def runner_on_no_hosts(self):
            pass
        def runner_on_async_poll(self, host, res, jid, clock):
            pass
        def runner_on_async_ok(self, host, res, jid):
            pass

# Generated at 2022-06-11 16:53:35.206195
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    the_strat = StrategyModule(None)
    assert the_strat._host_pinned is True

# Generated at 2022-06-11 16:53:36.109240
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-11 16:53:37.023475
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	print("In StrategyModule1")
	pass

# Generated at 2022-06-11 16:53:38.805897
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(strategy_name="fizzbuzz")
    assert isinstance(a, StrategyModule)
    assert a._host_pinned is True

# Generated at 2022-06-11 16:53:40.759558
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned

# Generated at 2022-06-11 16:53:41.904339
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("tqm")
    assert strategy_module is not None

# Generated at 2022-06-11 16:53:46.872212
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None) is not None

# Generated at 2022-06-11 16:53:48.621197
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ''' constructor test '''
    tqm = None
    assert StrategyModule(tqm)._host_pinned

# Generated at 2022-06-11 16:53:52.575433
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback="default",
    )
    s = StrategyModule(tqm)

    

# Generated at 2022-06-11 16:53:54.175797
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    var = StrategyModule(tqm)
    assert var._host_pinned is True

# Generated at 2022-06-11 16:53:59.730970
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Setup
    tqm = 1
    # Action
    strategy_module = StrategyModule(tqm)
    # Assertion
    assert strategy_module is not None
    # Teardown - none necessary


# Generated at 2022-06-11 16:54:08.752709
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create a TQM instance
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    variable_manager = VariableManager()

    # no config files, just command line options
    settings = {
        'host_key_checking': False
    }
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=variable_manager,
        loader=loader,
        options=settings,
        passwords=dict(),
        stdout_callback='default',
    )

    # initialize the strategy module
    strategy_module = StrategyModule(tqm)
    assert strategy_module.tqm == tqm
    assert strategy_module._host

# Generated at 2022-06-11 16:54:09.630528
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()
    assert s._name == 'host_pinned'

# Generated at 2022-06-11 16:54:10.303188
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:54:11.665573
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None

# Generated at 2022-06-11 16:54:12.972980
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-11 16:54:29.406992
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import mock
    import collections
    import ansible.playbook.task_queue_manager

    class TestStrategyModule(unittest.TestCase):
        ''' test for StrategyModule.__init__ '''

        def setUp(self):
            self.tqm = mock.MagicMock(spec=ansible.playbook.task_queue_manager.TaskQueueManager)
            self.strategy_module = StrategyModule(self.tqm)

        def test_StrategyModule(self):
            self.assertTrue(isinstance(self.strategy_module, StrategyModule))
            self.assertTrue(isinstance(self.strategy_module, FreeStrategyModule))
            self.assertEqual(self.strategy_module._host_pinned, True)

    unittest.main()

# Generated at 2022-06-11 16:54:34.877524
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(None)
    a._tqm = {'name':'test'}
    assert a._tqm == {'name':'test'}, 'Field not set'
    a = StrategyModule(None)
    a._host_pinned = False
    assert a._host_pinned == False, 'Field not set'

# Generated at 2022-06-11 16:54:39.189861
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TQM()
    strategy_module= StrategyModule(tqm)
    print("test_StrategyModule: _host_pinned: " +str(strategy_module._host_pinned))  #_host_pinned: true
    assert strategy_module._host_pinned == True


# Generated at 2022-06-11 16:54:41.171677
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule constructor")
    assert(1 == 1)


# Generated at 2022-06-11 16:54:44.089694
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ''
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:54:44.769158
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:54:45.898747
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-11 16:54:46.481759
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:54:47.249216
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert (StrategyModule is not None)

# Generated at 2022-06-11 16:54:47.873105
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:55:08.711917
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)
    assert StrategyModule.__doc__ == StrategyModule.__init__.__doc__

# Generated at 2022-06-11 16:55:11.856161
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ Create a new StrategyModule object"""
    strategyModule = StrategyModule(None)
    assert strategyModule._host_pinned is True

# Generated at 2022-06-11 16:55:13.955111
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy is not None
    assert strategy._host_pinned is True

# Generated at 2022-06-11 16:55:15.103346
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-11 16:55:16.893689
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Establish instance
    strategy = StrategyModule(tqm=None)

    # Verify that StrategyModule constructed correctly
    assert strategy._host_pinned is True

# Tests for class StrategyModule

# Generated at 2022-06-11 16:55:20.450997
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm)
    assert s._host_pinned == True
    assert s._hosts_left == None
    assert s._hosts_left_count == None

# Generated at 2022-06-11 16:55:24.910394
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	print('Testing unit test for class StrategyModule')
	try:
		_ = StrategyModule(None)
		print('unit test passed')
	except:
		print('unit test failed')


# Generated at 2022-06-11 16:55:26.883331
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm="tqm")
    assert obj._host_pinned == True

# Generated at 2022-06-11 16:55:28.632915
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)
    print("\nClass StrategyModule initialization test completed...\n")
    

# Generated at 2022-06-11 16:55:30.054666
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert(strategy_module._host_pinned == True)

# Generated at 2022-06-11 16:56:12.353098
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_module = StrategyModule(tqm=None)
    assert test_module._host_pinned == True

# Generated at 2022-06-11 16:56:15.532146
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None


# Generated at 2022-06-11 16:56:17.418447
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None) is not None


# Generated at 2022-06-11 16:56:18.483373
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True

# Generated at 2022-06-11 16:56:24.102107
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager('/root/ansible/playbook', {'inventory': '/root/ansible/hosts'}, [], 5, True, None)
    strategy = StrategyModule(tqm)
    assert strategy.__class__.__name__ == 'StrategyModule'
    assert strategy._host_pinned == True

# Generated at 2022-06-11 16:56:26.254151
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = TaskQueueManager()
  strategy = StrategyModule(tqm)
  assert strategy._host_pinned

# Generated at 2022-06-11 16:56:27.463454
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-11 16:56:34.149556
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None
    )
    s = StrategyModule(tqm)
    assert s._host_pinned is True


# Generated at 2022-06-11 16:56:37.573307
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule(tqm=None)

# Test for method get_host_list of class StrategyModule

# Generated at 2022-06-11 16:56:40.786768
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()
    assert s._host_pinned is True

# vim: set et ft=python ts=4 sw=4 :

# Generated at 2022-06-11 16:58:22.821647
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible import context
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.cli.adhoc import AdHocCLI as cli
    from ansible.inventory.manager import InventoryManager
    options = cli.base_parser(desc="Ad-hoc", runas_opts=True).parse_args(['-i', 'localhost,', '-m', 'ping', 'localhost'])
    variables = cli.get_default_vars(options)

    context._init_global_context(options)

    inventory = InventoryManager(loader=options.loader, sources=options.inventory)
    play_context = PlayContext()

# Generated at 2022-06-11 16:58:26.339804
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test'
    strategy_test = StrategyModule(tqm)
    assert strategy_test._host_pinned == True

# Generated at 2022-06-11 16:58:27.467087
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    StrategyModule(tqm)

# Generated at 2022-06-11 16:58:36.092423
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_list = ['a', 'b', 'c', 'd']

    tqm = TaskQueueManager(None, None, None)
    strategy = StrategyModule(tqm)

    strategy._initialize_the_process_pool()

    assert strategy._display.verbosity == 0
    assert strategy._inventory.list_hosts(host_list) == ['a', 'b', 'c', 'd']
    assert strategy._inventory.hosts == {'a': {}, 'b': {}, 'c': {}, 'd': {}}


# Generated at 2022-06-11 16:58:36.895714
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-11 16:58:38.199132
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy._host_pinned



# Generated at 2022-06-11 16:58:39.700524
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of StrategyModule")
    assert StrategyModule("tqm") is not None


# Generated at 2022-06-11 16:58:40.517798
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm="test")

# Generated at 2022-06-11 16:58:43.468140
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(0)
    strategy = StrategyModule(tqm)

    assert strategy._host_pinned == True

# Generated at 2022-06-11 16:58:50.138662
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    setattr(__builtins__, 'display', display)

    """
According to the __init__ method in the StrategyModule class in library/plugins/strategy/host_pinned.py, the
obj object will initialize the self._host_pinned to True.
    """
    obj = StrategyModule("Test")

    assert obj is not None
    assert obj._host_pinned is True

# Generated at 2022-06-11 17:02:20.632781
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm)

if __name__ == '__main__':
    from units.mock.loader import DictDataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DictDataLoader({
        "strategy.yml": """
        - hosts: localhost
          tasks:
          - name: ping
            ping:
          - name: fail
            fail:
          - name: ping
            ping:
        ---
        - hosts: localhost
          serial: 2
          tasks:
          - name: ping1
            ping:
          - name: ping2
            ping:
          - name: ping3
            ping:
          - name: ping4
            ping:
        """,
    })

# Generated at 2022-06-11 17:02:22.210509
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm is not None

# Generated at 2022-06-11 17:02:23.872351
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert (StrategyModule.__doc__ is not None)


# Generated at 2022-06-11 17:02:26.731579
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    action_iterator = None
    host_list = None

    strategy_obj = StrategyModule(tqm)

    assert strategy_obj._host_pinned == True

