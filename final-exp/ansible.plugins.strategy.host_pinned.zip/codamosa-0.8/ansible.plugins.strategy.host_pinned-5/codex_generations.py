

# Generated at 2022-06-11 16:52:25.183859
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s_obj = StrategyModule(None)
    assert s_obj._host_pinned

# Generated at 2022-06-11 16:52:26.179845
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)

# Generated at 2022-06-11 16:52:34.064483
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    import ansible.plugins.strategy.host_pinned
    from ansible.plugins.strategy.host_pinned import StrategyModule

    import ansible.plugins.strategy.free
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule

    print(isinstance(StrategyModule, type))
    print(isinstance(StrategyModule, type(FreeStrategyModule)))

    class Test:
        def __init__(self):
            pass

    class TestFreeStrategyModule(FreeStrategyModule):
        def __init__(self):
            super(TestFreeStrategyModule, self).__init__(Test())
            self._host_pinned = True

    print(isinstance(StrategyModule, type(TestFreeStrategyModule)))

# Generated at 2022-06-11 16:52:35.633161
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    m = StrategyModule(tqm=None)
    assert m._host_pinned

# Generated at 2022-06-11 16:52:43.743290
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__.__name__ == '__init__'
    assert StrategyModule.__init__.__doc__ == '''\
    Initialize the strategy plugin.
    '''
    assert StrategyModule.__init__.__code__.co_argcount == 2
    assert StrategyModule.__init__.__code__.co_varnames == ('self', 'tqm')
    assert StrategyModule.__init__.__code__.co_filename == StrategyModule.__module__
    assert StrategyModule.__init__.__code__.co_firstlineno == 12
    assert StrategyModule.__init__.__code__.co_flags == 0

# Generated at 2022-06-11 16:52:46.197891
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-11 16:52:48.955956
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ''' test_StrategyModule(): Unit test for constructor of class StrategyModule '''
    display = Display()
    display.debug("test_StrategyModule(): Unit test for constructor of class StrategyModule")
    return

# Generated at 2022-06-11 16:52:59.936157
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule constructor")
    ansible_options = {'connection': 'local', 'module_path': '.', 'forks': 10, 'remote_user': 'vagrant', 'private_key_file': '~/.vagrant.d/insecure_private_key', 'ssh_common_args': '', 'ssh_extra_args': '', 'sftp_extra_args': '', 'scp_extra_args': '', 'become': True, 'become_method': 'sudo', 'become_user': 'root', 'verbosity': 0, 'check': False, 'listhosts': None, 'listtasks': None, 'listtags': None, 'syntax': None, 'module_path': None}
    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-11 16:53:01.021256
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-11 16:53:10.199220
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Make sure the class is of type StrategyModule
strategy_module = StrategyModule('TEST')
assert strategy_module.__class__.__name__ == 'StrategyModule'

# Make sure the StrategyModule is of type FreeStrategyModule
assert StrategyModule('TEST').__class__.__name__ == 'FreeStrategyModule'

# Make sure the StrategyModule can call the method get_hosts_left_to_run
assert callable(getattr(StrategyModule('TEST'), 'get_hosts_left_to_run', None))

# Make sure the StrategyModule has an attribute _host_pinned
assert hasattr(StrategyModule('TEST'), '_host_pinned')

# Generated at 2022-06-11 16:53:14.161998
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategyModule = StrategyModule(tqm)
    assert strategyModule._host_pinned == True



# Generated at 2022-06-11 16:53:16.210714
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("tqm")
    assert strategy_module._host_pinned == True
    assert strategy_module._display == display

# Generated at 2022-06-11 16:53:16.737758
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:53:17.196454
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-11 16:53:19.199271
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm = None)


# Generated at 2022-06-11 16:53:19.820501
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule != None

# Generated at 2022-06-11 16:53:28.146195
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Create an instance of task queue manager class
    tqm = TaskQueueManager("/path/to/playbook", "/path/to/inventory", "/path/to/options", "/path/to/datastructure", "/path/to/loader", "/path/to/variable_manager", "/path/to/shared_loader_obj")

    tqm_instance = StrategyModule(tqm)

    assert(tqm_instance._host_pinned == True)

# Generated at 2022-06-11 16:53:30.011908
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(None)
    assert a is not None
    assert isinstance(a._host_pinned, bool)

# Generated at 2022-06-11 16:53:34.747830
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule constructor")
    # Create instance of tqm
    tqm = object()
    # Create instance StrategyModule
    strategy = StrategyModule(tqm)
    assert isinstance(strategy, FreeStrategyModule)

# Create test case for StrategyModule.get_host_iterator()

# Generated at 2022-06-11 16:53:36.359269
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm=None)
    assert isinstance(sm, StrategyModule)

# Generated at 2022-06-11 16:53:40.413278
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm._host_pinned

# Generated at 2022-06-11 16:53:43.606132
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule) == True
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'

# Generated at 2022-06-11 16:53:47.451032
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global module
    module = StrategyModule(tqm)
    try:
        assert_equal(module.__class__.__name__, "StrategyModule")
    except AssertionError:
        raise

# Generated at 2022-06-11 16:53:48.746778
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    assert not StrategyModule._host_pinned


# Generated at 2022-06-11 16:53:52.120339
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    assert StrategyModule(tqm=None)


if __name__ == '__main__':
    # Unit test construction of class StrategyModule
    test_StrategyModule()

# Generated at 2022-06-11 16:53:53.203574
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm = None)

# Generated at 2022-06-11 16:53:56.213076
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '__init__')
    assert callable(StrategyModule.__init__)



# Generated at 2022-06-11 16:54:00.022922
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ""
    strategy = StrategyModule(tqm)
    assert(strategy._host_pinned)


# Make sure the constructor tests works
test_StrategyModule()

# Generated at 2022-06-11 16:54:01.186079
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO
    assert False

# Generated at 2022-06-11 16:54:03.211942
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    myStrategyModule = StrategyModule("tqm")
    assert myStrategyModule._host_pinned == True

# Generated at 2022-06-11 16:54:09.947547
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    testStrategyModule = StrategyModule(tqm='')
    # import pdb; pdb.set_trace()
    assert testStrategyModule._host_pinned is True

# Generated at 2022-06-11 16:54:12.169775
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    strategymodule = StrategyModule(tqm)
    assert strategymodule


# Generated at 2022-06-11 16:54:13.440987
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__

# Generated at 2022-06-11 16:54:16.355018
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strate_module = StrategyModule('tqm')
    assert strate_module._host_pinned is True
    assert strate_module._display is not None
    assert strate_module._display.verbosity == 0


# Generated at 2022-06-11 16:54:17.915100
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_object = StrategyModule()
    assert test_object
    assert test_object._host_pinned == True

# Generated at 2022-06-11 16:54:20.072161
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Unit test for constructor of class StrategyModule")
    tqm = StrategyModule(123)
    assert tqm._host_pinned == True

# Generated at 2022-06-11 16:54:20.771214
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:54:26.081113
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
#hosts manages the list of the hosts
    print("*********************test1********************")
    hosts = [
        {'inventory_hostname': 'test1'},
        {'inventory_hostname': 'test2'},
        {'inventory_hostname': 'test3'},
    ]
    tqm = MockTQM(hosts)
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned is True
    print("test1 is passed")
    

# Generated at 2022-06-11 16:54:27.009932
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__

# Generated at 2022-06-11 16:54:27.539131
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-11 16:54:38.196331
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing the constructor")
    tqm = {}
    StrategyModule(tqm)
    print("Constructor seems to be working")
    return True

# Unit Test for the method __init__

# Generated at 2022-06-11 16:54:40.502495
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(tqm=None)
    assert a._host_pinned == True

# Generated at 2022-06-11 16:54:42.394187
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-11 16:54:44.864018
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test StrategyModule class constructor
    strategy_module = StrategyModule(tqm = '')
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:54:45.329072
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-11 16:54:47.431346
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = strategy()
    strategy_module = StrategyModule(tqm)
    strategy_module.__init__(tqm)

# Generated at 2022-06-11 16:54:49.032385
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result = StrategyModule(0)
    assert result._host_pinned == True


# Generated at 2022-06-11 16:54:51.767976
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    load = StrategyModule(tqm="tqm")
    assert load.get__host_pinned() == True

# Generated at 2022-06-11 16:54:53.596421
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule(None)
    assert(strategyModule._host_pinned is True)

# Generated at 2022-06-11 16:54:56.711789
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    test_strategy = StrategyModule(tqm)
    assert test_strategy._host_pinned is True, '_host_pinned should be True'

# Generated at 2022-06-11 16:55:18.417368
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-11 16:55:23.647238
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test with a mock
    mock_tqm = True
    assert StrategyModule(mock_tqm)._host_pinned == True
    mock_tqm = False
    assert StrategyModule(mock_tqm)._host_pinned == True

# Generated at 2022-06-11 16:55:25.159672
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-11 16:55:25.682919
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-11 16:55:27.421494
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    assert FreeStrategyModule
    assert display

# Generated at 2022-06-11 16:55:29.334618
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # call constructor of class StrategyModule
    StrategyModule()



# Generated at 2022-06-11 16:55:33.910453
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    from ansible.utils.display import Display

    display = Display()

    assert issubclass(StrategyModule, FreeStrategyModule)


# Generated at 2022-06-11 16:55:37.213911
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class test_tqm:
        def __init__(self):
            self.stats = None

    test_tqm = test_tqm()
    assert StrategyModule(test_tqm)._host_pinned

# Generated at 2022-06-11 16:55:37.739358
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:55:39.447171
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str = StrategyModule("tqm")
    print(str)
    assert str._host_pinned == True, 'Host pinned variable is not True'

# Generated at 2022-06-11 16:56:20.071204
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  StrategyModule(tqm)

# Generated at 2022-06-11 16:56:21.897664
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert getattr(StrategyModule, '_host_pinned', True) == True

# Generated at 2022-06-11 16:56:23.124562
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(None)
    assert module

# Generated at 2022-06-11 16:56:26.070574
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert hasattr(strategy_module, '_host_pinned')
    assert isinstance(strategy_module, FreeStrategyModule)

# Generated at 2022-06-11 16:56:26.993861
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule()


# Generated at 2022-06-11 16:56:27.976966
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:56:29.306895
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__.__doc__

# Generated at 2022-06-11 16:56:30.535432
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None
    assert StrategyModule.__init__.__doc__ is not None

# Generated at 2022-06-11 16:56:40.439777
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.vars import combine_vars
    from ansible.vars.reserved import DEFAULT_HOST_LIST
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.constants import DEFAULT_SUDO_USER, DEFAULT_SUDO_PASS, DEFAULT_MODULE_PATH, DEFAULT_FORKS, DEFAULT_REM

# Generated at 2022-06-11 16:56:42.148266
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule, object)


# vim: expandtab filetype=python shiftwidth=4 tabstop=4

# Generated at 2022-06-11 16:58:20.615586
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor import task_queue_manager
    tqm = task_queue_manager.TaskQueueManager(None, None)
    s = StrategyModule(tqm)
    assert s._host_pinned

# Generated at 2022-06-11 16:58:21.740425
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)

# Generated at 2022-06-11 16:58:22.284990
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:58:22.777722
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:58:26.339321
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True


# vim: et ts=4 sw=4

# Generated at 2022-06-11 16:58:28.404913
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned = StrategyModule('tqm')
    result = host_pinned._host_pinned
    assert result == True

# Generated at 2022-06-11 16:58:30.731724
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(123)
    assert obj._host_pinned == True

# Generated at 2022-06-11 16:58:31.574149
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:58:33.117209
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True

# Generated at 2022-06-11 16:58:35.162439
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a=StrategyModule(None)
    print (a)
# test_StrategyModule()

# Generated at 2022-06-11 17:01:58.356664
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = dict()
    test_strategy_module = StrategyModule(test_tqm)
    assert test_strategy_module._host_pinned == True

# Generated at 2022-06-11 17:02:01.411980
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    sm = StrategyModule(tqm=None)
    assert sm._host_pinned == True
    
    

# Generated at 2022-06-11 17:02:03.192949
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm='tqm') is not None


# Generated at 2022-06-11 17:02:03.781951
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 17:02:05.396513
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    StrategyModule()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-11 17:02:06.628412
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule()
    assert strategyModule

# Generated at 2022-06-11 17:02:10.132298
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM:
        def __init__(self):
            self._fact_cache = [["test"]]
            self._inventory = None
            self._variable_manager = None
            self._loader = None
    test_strategy = StrategyModule(TestTQM())
    assert test_strategy._host_pinned == True

# Generated at 2022-06-11 17:02:18.010251
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.template import Templar
    from ansible import inventory
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars

    strategy_module = StrategyModule(None)


# Generated at 2022-06-11 17:02:18.721175
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   assert StrategyModule

# Generated at 2022-06-11 17:02:21.853734
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock # https://docs.python.org/3/library/unittest.mock.html
    tqm = mock.MagicMock()
    plugin = StrategyModule(tqm)
    assert plugin._host_pinned