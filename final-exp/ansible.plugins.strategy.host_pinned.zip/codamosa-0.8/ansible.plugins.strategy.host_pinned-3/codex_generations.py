

# Generated at 2022-06-11 16:52:25.940331
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    tqm = 'test_tqm'

    s = StrategyModule(tqm)
    assert s._tqm == tqm
    assert s._host_pinned

# Generated at 2022-06-11 16:52:28.738248
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest.mock

    tqm = unittest.mock.MagicMock()
    StrategyModule(tqm)

# Generated at 2022-06-11 16:52:37.412309
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__module__ == 'host_pinned'
    assert StrategyModule.__doc__ == 'This is a base ansible strategy module, which does nothing. This is used to provide common code for strategy plugins.'
    assert StrategyModule.__init__.__doc__ == 'This is a base ansible strategy module, which does nothing. This is used to provide common code for strategy plugins.'
    assert StrategyModule.run_queue.__doc__ == 'This is a base ansible strategy module, which does nothing. This is used to provide common code for strategy plugins.'

# Generated at 2022-06-11 16:52:38.537432
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:52:39.965643
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-11 16:52:41.412140
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Unit test - strategy_plugins/host_pinned.py
    assert callable(StrategyModule)

# Generated at 2022-06-11 16:52:47.109498
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm)

    assert sm.tqm == tqm
    assert sm.get_host_list() == tqm.get_host_list()
    assert sm._host_pinned == True



# Generated at 2022-06-11 16:52:58.880604
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert 'host_pinned' in StrategyModule.__doc__
    assert 'short_description' in StrategyModule.__doc__
    assert 'description' in StrategyModule.__doc__
    assert 'version_added' in StrategyModule.__doc__
    assert 'author' in StrategyModule.__doc__
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy'
    assert StrategyModule.__bases__ == (FreeStrategyModule,)

    assert FreeStrategyModule.__name__ == 'FreeStrategyModule'
    assert 'free' in FreeStrategyModule.__doc__
    assert 'short_description' in FreeStrategyModule.__doc__

# Generated at 2022-06-11 16:53:01.873375
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(isinstance(StrategyModule, object))
    tqm = object
    ans = StrategyModule(tqm)
    assert(isinstance(ans._host_pinned, bool))

# Generated at 2022-06-11 16:53:03.129404
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy is not None
    assert strategy._host_pinned is True

# Generated at 2022-06-11 16:53:13.457134
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess
    from ansible.plugins.loader import action_loader, lookup_loader, module_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

# Generated at 2022-06-11 16:53:15.045715
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    m = StrategyModule(tqm=None)
    assert m._host_pinned is True

# Generated at 2022-06-11 16:53:16.515024
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TQM()
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned

# Generated at 2022-06-11 16:53:17.265160
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-11 16:53:18.475629
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None


# Generated at 2022-06-11 16:53:30.160419
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-11 16:53:31.704431
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Test for class StrategyModule

# Generated at 2022-06-11 16:53:33.974304
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ''
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:53:38.544956
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class StrategyModuleMock(StrategyModule):
        @staticmethod
        def __init__(tqm):
            StrategyModule.__init__(tqm)
            self._host_pinned = True
    tqm = 'test_tqm'
    strategy_module_mock = StrategyModuleMock(tqm)
    assert strategy_module_mock._host_pinned

# Generated at 2022-06-11 16:53:46.699844
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.plugins.callback.default as callback_default
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=callback_default.CallbackModule(),
        run_additional_callbacks=False,
        run_tree=False,
    )
    strategy = StrategyModule(tqm=tqm)
    assert strategy._host_pinned is True

# Generated at 2022-06-11 16:53:50.028276
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(object)
    assert sm._host_pinned == True

# Generated at 2022-06-11 16:53:52.219222
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = 1
  ansTqm = StrategyModule(tqm)
  assert ansTqm._host_pinned

# Generated at 2022-06-11 16:53:52.834227
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(0)

# Generated at 2022-06-11 16:53:56.700746
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    strategy_module = StrategyModule(tqm)
    assert isinstance(strategy_module, StrategyModule)

    # Print the object
    print(strategy_module)


# Generated at 2022-06-11 16:53:58.040581
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("test_tqm")
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:54:08.028715
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test for default constructor
    strategy = StrategyModule(None)
    assert strategy is not None

    # Test for normal constructor calling
    strategy = StrategyModule(strategy)
    assert strategy is not None

    assert strategy._host_pinned is True
    assert hasattr(strategy, 'display')
    assert hasattr(strategy, 'get_next_queued_task')
    assert hasattr(strategy, 'run_handlers')
    assert hasattr(strategy, '_locked')
    assert hasattr(strategy, '_get_next_task_lockfiles')
    assert hasattr(strategy, '_get_next_task_for_host')
    assert hasattr(strategy, '_wait_on_pending_results')
    assert hasattr(strategy, '_queue_task')

# Generated at 2022-06-11 16:54:09.272988
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)._host_pinned

# Generated at 2022-06-11 16:54:11.558919
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test'
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-11 16:54:15.700298
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)

    assert strategy is not None
    assert strategy.display is not None
    assert strategy.display.display == display.display
    assert strategy._host_pinned == True
    assert strategy._fact_cache is None

# Generated at 2022-06-11 16:54:17.725998
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    StrategyModule(tqm)

# Generated at 2022-06-11 16:54:22.111459
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == True

# Generated at 2022-06-11 16:54:24.902171
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__bases__ == (FreeStrategyModule,)
    assert hasattr(StrategyModule, '_host_pinned')


# For unit test purposes only, so strategy objects can be tested independently

# Generated at 2022-06-11 16:54:30.491403
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
        Test to check the constructor of class StrategyModule.
        It checks if inherited class is implemented and initializing is done correctly.
    '''
    from collections import namedtuple
    connection = namedtuple('connection', ['host', 'port'])
    tqm = namedtuple('tqm', ['connection', '_workers'])
    tqm.connection = connection('localhost', 8080)
    tqm._workers = 5
    strategy = StrategyModule(tqm)
    assert isinstance(strategy, FreeStrategyModule)
    assert strategy._host_pinned

# Generated at 2022-06-11 16:54:33.969358
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = AnsibleCoreTestUtil.create_tqm()
    sm = StrategyModule(tqm)
    result = sm._host_pinned
    assert result is True


# Generated at 2022-06-11 16:54:35.508389
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)



# Generated at 2022-06-11 16:54:36.803565
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule("tqm")


# Generated at 2022-06-11 16:54:38.071107
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm='Test')


# Generated at 2022-06-11 16:54:39.888665
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule('')
    assert module._host_pinned


# Generated at 2022-06-11 16:54:42.645240
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_list=['test']
    strategy_setup = StrategyModule(host_list)
    assert strategy_setup._host_pinned == True

# Generated at 2022-06-11 16:54:43.874428
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-11 16:54:54.325362
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:54:56.122054
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    StrategyModuleInstance = StrategyModule('data')
    assert StrategyModuleInstance

# Generated at 2022-06-11 16:54:57.995323
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned == True

# Generated at 2022-06-11 16:54:58.905946
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-11 16:55:01.048900
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    free_strategy = StrategyModule(tqm)
    assert free_strategy._host_pinned

# Generated at 2022-06-11 16:55:01.547855
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:55:03.204775
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("checking strategy module creation: class StrategyModule")
    pass

# Unit test to check the private variable _host_pinned

# Generated at 2022-06-11 16:55:03.719940
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:55:04.851754
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-11 16:55:06.773671
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy._host_pinned

# Generated at 2022-06-11 16:55:31.673106
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'Test Queue Manager'
    print("Test StrategyModule")
    sm = StrategyModule(tqm)
    print("Done with test StrategyModule")

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-11 16:55:35.765080
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Create AnsibleRunnerMock
    class AnsibleRunnerMock:
        def __init__(self):
            pass
    ansibleRunner = AnsibleRunnerMock()

    # Test for run method to modify self._host_pinned
    strategy = StrategyModule(ansibleRunner)
    assert strategy._host_pinned == True

# Generated at 2022-06-11 16:55:37.213839
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule("test")
    assert module._host_pinned is True

# Generated at 2022-06-11 16:55:37.739098
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:55:38.251488
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-11 16:55:39.164076
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-11 16:55:39.827401
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:55:40.386400
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:55:41.987083
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    m = StrategyModule(None)
    assert m

# Unit tests for overriding methods

# Generated at 2022-06-11 16:55:42.787944
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: Add test for StrategyModule
    pass

# Generated at 2022-06-11 16:56:22.135118
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:56:23.222094
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule("tqm")
    assert x._host_pinned == True

# Generated at 2022-06-11 16:56:24.634701
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    st = StrategyModule(None)

    assert st._host_pinned == True

# Generated at 2022-06-11 16:56:27.115243
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('tqm')
    assert strategy_module is not None
    assert strategy_module._host_pinned is True

# Generated at 2022-06-11 16:56:32.736002
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor for StrategyModule")
    tqm = "Hello World"
    strategy_module = StrategyModule(tqm)
    assert str(strategy_module) == ("StrategyModule:{'_host_pinned': True, '_tqm': 'Hello World'}")


# Generated at 2022-06-11 16:56:35.261836
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test constructor of StrategyModule
    strategy_module = StrategyModule(None)
    assert strategy_module is not None
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:56:46.852006
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.hashs import md5s
    from ansible.plugins.strategy import TestStrategyModule
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.parsing.vault import VaultLib
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import callback

# Generated at 2022-06-11 16:56:47.985356
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-11 16:56:48.656780
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:56:49.571805
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('Testing')

# Generated at 2022-06-11 16:58:30.042360
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  s=StrategyModule("tqm")
  assert hasattr(s,'_host_pinned')

# Generated at 2022-06-11 16:58:30.781574
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:58:33.411785
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-11 16:58:35.121434
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(1)

# unit test for display of class StrategyModule

# Generated at 2022-06-11 16:58:36.483802
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   module = StrategyModule()
   assert module._host_pinned

# Generated at 2022-06-11 16:58:37.474690
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(42)
    assert strategy._host_pinned == True
    assert strategy._tqm == 42

# Generated at 2022-06-11 16:58:39.303013
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # The constructor of the StrategyModule class does not explicitly return anything,
    # so the next line is here to prevent missing return warning.
    StrategyModule()

# Generated at 2022-06-11 16:58:40.132440
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(None), StrategyModule)

# Generated at 2022-06-11 16:58:41.543621
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy is not None

# Generated at 2022-06-11 16:58:42.926040
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm._host_pinned

# Generated at 2022-06-11 17:02:06.662598
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(None)
    assert module is not None
    module._host_pinned = True
    assert module._host_pinned is True



# Generated at 2022-06-11 17:02:13.024942
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Instantiation of class StrategyModule
    """
    test_tqm = 'test tqm'
    test_obj = StrategyModule(test_tqm)

    assert test_obj._tqm == 'test tqm'
    assert test_obj._display == 'Display'
    assert test_obj._batch_size == 'all'
    assert test_obj._inventory_update_cache == 'True'
    assert test_obj._inventory_filename == 'None'
    assert test_obj._inventory == 'None'
    assert test_obj._pattern == 'None'
    assert test_obj._host_pinned == 'True'
    assert test_obj._hosts == '[]'
    assert test_obj._workers == '[]'
    assert test_obj._notified_handlers == '{}'

# Generated at 2022-06-11 17:02:13.824695
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-11 17:02:14.580026
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '__init__')

# Generated at 2022-06-11 17:02:15.654615
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-11 17:02:26.230941
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.loader import loader, module_loader
    from ansible.config.manager import ConfigManager

    config_manager = ConfigManager()
    config_data = config_manager.get_config_data()

    # Create a fake strategy plugin module to test StrategyModule class
    class Fake_StrategyPluginModule(object):
        pass

    strategy_module_name = 'free'
    strategy_plugin_module = Fake_StrategyPluginModule()
    strategy_plugin_module.__name__ = strategy_module_name
    strategy_plugin_module.name = strategy_module_name
    strategy_plugin_module.__doc__ = __doc__

    module_loader.add(strategy_module_name, strategy_plugin_module)