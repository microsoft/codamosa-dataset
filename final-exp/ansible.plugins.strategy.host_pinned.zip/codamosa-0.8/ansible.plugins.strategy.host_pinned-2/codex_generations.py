

# Generated at 2022-06-11 16:52:25.491707
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("tqm")
    assert strategy_module._host_pinned == True
    assert strategy_module._final_qsize == 0

# Generated at 2022-06-11 16:52:26.178967
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:52:29.165689
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule Class")
    result = StrategyModule(None)
    assert result != None
    print("StrategyModule class is working")


# Generated at 2022-06-11 16:52:29.911853
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:52:32.200779
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule("tqm")
    assert a._host_pinned
    print("test_StrategyModule finished")

# Generated at 2022-06-11 16:52:33.630885
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-11 16:52:35.140170
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()
    assert obj._host_pinned == True

# Generated at 2022-06-11 16:52:36.038426
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-11 16:52:36.680914
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:52:37.998218
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(2)

# Generated at 2022-06-11 16:52:42.053793
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)
    from ansible.plugins.strategy.serial import StrategyModule as SerialStrategyModule
    assert issubclass(StrategyModule, SerialStrategyModule)

# Generated at 2022-06-11 16:52:46.198450
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert "FreeStrategyModule" is FreeStrategyModule.__name__
    assert "StrategyModule" is StrategyModule.__name__

# Generated at 2022-06-11 16:52:47.198821
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-11 16:52:48.600113
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return True, "unit test OK"

# Generated at 2022-06-11 16:52:50.963020
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task_queue_manager = None
    free_strategy_module = StrategyModule(task_queue_manager)
    assert free_strategy_module is not None

# Generated at 2022-06-11 16:52:54.691427
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert type(strategy_module).__name__ == 'StrategyModule'
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:52:57.615824
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    # On creating a strategy module object, the value of _host_pinned should be True
    assert strategy_module._host_pinned

# Generated at 2022-06-11 16:52:58.238625
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:53:00.325255
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm._host_pinned == True

# Generated at 2022-06-11 16:53:01.379613
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(1)._host_pinned == True

# Generated at 2022-06-11 16:53:04.768687
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None
    # TODO: test constructor


# Generated at 2022-06-11 16:53:06.857235
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("tqm")
    assert strategy_module._host_pinned == True


# Generated at 2022-06-11 16:53:07.299724
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:53:09.034249
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    obj = StrategyModule(tqm)
    assert obj is not None

# Generated at 2022-06-11 16:53:17.526969
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from collections import namedtuple
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.strategy.host_pinned import StrategyModule as MyStrategyModule
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel
    from ansible.vars.manager import VariableManager

    # Mock display object
    display = Display()

    # Mock variable manager
    variable_manager = VariableManager()

    # Mock object
    sentinel = Sentinel()

    # Instantiate the module
    module = StrategyModule(sentinel)
    assert isinstance(module, MyStrategyModule)
    assert module._tqm is sentinel

# Generated at 2022-06-11 16:53:20.630638
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "tqm"
    strategy_module = StrategyModule(tqm)
    assert strategy_module

# Generated at 2022-06-11 16:53:21.777064
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_obj = StrategyModule()


# Generated at 2022-06-11 16:53:23.394672
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a=StrategyModule('tqm')
    assert a._host_pinned

# Generated at 2022-06-11 16:53:24.384686
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  StrategyModule("tqm")

# Generated at 2022-06-11 16:53:30.309707
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    resolved_paths = ['/bin/bash', '/usr/bin/python']
    tqm = 'test_tqm'
    strategy_module = StrategyModule(tqm)
    assert strategy_module._resolved_paths == resolved_paths
    assert strategy_module._tqm == 'test_tqm'
    assert strategy_module._host_pinned == True


# Generated at 2022-06-11 16:53:34.920677
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a=StrategyModule()

# Generated at 2022-06-11 16:53:43.605799
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Setup
    pass

    # Test set attributes
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-11 16:53:46.083836
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result = StrategyModule(tqm=1)
    assert result._host_pinned == True

# Generated at 2022-06-11 16:53:48.050143
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned is True

# Generated at 2022-06-11 16:53:49.621886
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned



# Generated at 2022-06-11 16:53:51.019634
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm=None
    StrategyModule(tqm)

# Generated at 2022-06-11 16:53:55.627523
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned.StrategyModule as host_pinned_strategy_module
    import ansible.plugins.strategy.free.StrategyModule as free_strategy_module
    strategy_module = host_pinned_strategy_module.StrategyModule(tqm)
    assert isinstance(strategy_module, free_strategy_module.StrategyModule)

# Generated at 2022-06-11 16:53:57.145857
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {'host_pinned': 'True', 'serial': 1}
    StrategyModule(tqm)

# Generated at 2022-06-11 16:53:58.071637
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:54:05.374365
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"
    assert StrategyModule.__bases__ == (FreeStrategyModule,object)
    assert StrategyModule.__init__.__name__ == "__init__"
    assert StrategyModule.__init__.__module__ == StrategyModule.__module__
    assert isinstance(StrategyModule.__init__.__code__,type)
    assert StrategyModule.__init__.__code__.co_varnames == ('self','tqm')

# Generated at 2022-06-11 16:54:15.233025
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ansible.utils.get_config()
    sucess = StrategyModule(tqm)
    assert sucess, "Testcase for constructor StrategyModule: Failed"
    print("Testcase for constructor StrategyModule: Passed")


# Generated at 2022-06-11 16:54:17.361937
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test'
    test_obj = StrategyModule(tqm)
    assert test_obj._host_pinned == True

# Generated at 2022-06-11 16:54:18.531529
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned is True

# Generated at 2022-06-11 16:54:19.458174
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)

# Generated at 2022-06-11 16:54:21.754356
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule("tqm"), StrategyModule)
    assert issubclass(StrategyModule("tqm"), FreeStrategyModule)

# Generated at 2022-06-11 16:54:23.471789
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=free_strategy_tqm())


# Generated at 2022-06-11 16:54:27.866621
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude

    tqm = None
    sm = StrategyModule(tqm)

    assert sm._host_pinned is True
    assert sm._display is not None
    assert sm._print is False


# Generated at 2022-06-11 16:54:34.828524
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock

    test_mock = mock.Mock(spec=StrategyModule)
    test_mock.assert_not_called()

    test = StrategyModule(test_mock)
    test.assert_not_called()

    test_mock.assert_called_once_with(test_mock)
    test.assert_called_once_with(test_mock)

    assert test._host_pinned == True


# Generated at 2022-06-11 16:54:35.421840
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:54:36.109419
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule

# Generated at 2022-06-11 16:54:53.289583
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:54:55.890621
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_instance = StrategyModule()
    assert hasattr(test_instance, '_host_pinned')==True



# Generated at 2022-06-11 16:54:57.384736
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert(s._host_pinned == True)

# Generated at 2022-06-11 16:55:00.553753
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # First argument of the constructor is of type TaskQueueManager
    fake_tqm = object()
    strategy = StrategyModule(fake_tqm)
    # For now it is only needed to check that the class is instantiated
    assert strategy

# Generated at 2022-06-11 16:55:01.469295
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-11 16:55:03.154118
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a test strategy module
    sm = StrategyModule(None)
    # Test attribute of StrategyModule class
    assert sm._host_pinned == True

# Generated at 2022-06-11 16:55:04.586272
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test'
    strategy = StrategyModule(tqm)
    assert strategy._tqm == tqm
    assert strategy._host_pinned == True

# Generated at 2022-06-11 16:55:06.883717
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  x = StrategyModule(TaskQueueManager())
  assert x._host_pinned == True



# Generated at 2022-06-11 16:55:07.455072
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:55:09.914091
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    t = StrategyModule(None)
    assert t._host_pinned

# Generated at 2022-06-11 16:55:55.675420
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible_test.strategy_loader_fixture import _tqm

    test_StrategyModule = StrategyModule(_tqm)
    assert test_StrategyModule is not None

# Generated at 2022-06-11 16:56:02.193779
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.loader import module_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=module_loader,
        stdout_callback="null",
    )
    sm = StrategyModule(tqm)
    assert sm.batch_size == 1
    assert sm.__class__.__name__ == 'StrategyModule'
    assert sm._host_pinned == True

# Generated at 2022-06-11 16:56:04.807171
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test value'
    strategy_module = StrategyModule(tqm)
    assert strategy_module._tqm == tqm

# Generated at 2022-06-11 16:56:05.389506
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:56:06.902333
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = None  # Always pass
  StrategyModule(tqm)

# Generated at 2022-06-11 16:56:08.528359
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    p = StrategyModule(tqm=None)
    assert p is not None

# Generated at 2022-06-11 16:56:09.992363
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    assert not obj is None

# Generated at 2022-06-11 16:56:10.481803
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1 == 1

# Generated at 2022-06-11 16:56:12.466166
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned == True

# Generated at 2022-06-11 16:56:17.370250
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test for constructor of class StrategyModule
    '''
    tqm = (1,2,3)
    s = StrategyModule(tqm)
    assert tqm == s._tqm
    assert s._host_pinned

# Generated at 2022-06-11 16:57:43.346660
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)


# Generated at 2022-06-11 16:57:44.995689
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyObj = StrategyModule("tqm")

# Generated at 2022-06-11 16:57:46.245699
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(1)


# Generated at 2022-06-11 16:57:46.749031
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-11 16:57:47.950577
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm._host_pinned == True

# Generated at 2022-06-11 16:57:48.492963
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)._host_pinned is True

# Generated at 2022-06-11 16:57:49.709780
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-11 16:57:51.386690
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    handle = StrategyModule(None)
    handle._host_pinned = True


# Generated at 2022-06-11 16:57:57.856836
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-11 16:57:58.604961
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 17:01:26.692328
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    tqm_instance = ansible.plugins.strategy.host_pinned.StrategyModule(tqm = None)
    print(tqm_instance._tqm)
    print(tqm_instance._inventory)
    print(tqm_instance._display)
    print(tqm_instance._var_manager)
    print(tqm_instance._loader)
    print(tqm_instance._host_pinned)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-11 17:01:27.530661
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)

# Generated at 2022-06-11 17:01:30.279325
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    tqm = {}
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 17:01:34.054067
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    s = StrategyModule(tqm)

    assert s._queued_task_queue is None
    assert s._workers_permitted == {}
    assert s._hosts_by_worker is None
    assert s._host_pinned is True


# Generated at 2022-06-11 17:01:34.984150
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None) != None

# Generated at 2022-06-11 17:01:37.087307
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    host_pinned = StrategyModule(None)
    assert host_pinned._host_pinned == True

# Generated at 2022-06-11 17:01:38.758899
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule("tqm")
    assert s._host_pinned == True
    assert s._lockfile == None
    assert s._queue == None

# Generated at 2022-06-11 17:01:40.766102
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ''' Constructor does not accept any argument '''
    with pytest.raises(TypeError):
        StrategyModule()

# Generated at 2022-06-11 17:01:46.359593
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create fake tqm
    tqm = {}
    # Test that StrategyModule constructor can be invoked without errors
    strategy = StrategyModule(tqm=tqm)
    # Test that StrategyModule.tqm attribute is initialized correctly
    assert strategy.tqm == tqm, \
        "StrategyModule.tqm attribute is not initialized correctly"

# Generated at 2022-06-11 17:01:48.516747
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    b = StrategyModule(tqm=None)
    assert b.__class__ == StrategyModule
    assert b._host_pinned == True