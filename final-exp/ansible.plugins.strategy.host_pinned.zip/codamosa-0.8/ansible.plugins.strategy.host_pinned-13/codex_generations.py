

# Generated at 2022-06-11 16:52:28.700057
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned is True

# Generated at 2022-06-11 16:52:30.499937
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = [1, 2]
    sm = StrategyModule(tqm)

# Generated at 2022-06-11 16:52:32.487884
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned

# Generated at 2022-06-11 16:52:41.510656
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  import sys
  import copy
  import os

  # Empty args
  args = {}

  # Mock objects
  class Mock_TQM(object):

    def __init__(self):
      self.args = None
      self.display = None
      self.hostvars = None
      self.inventory = None
      self.loader = None
      self.stats = None
      self.variable_manager = None
      self.extra_vars = None
      self.noop_vars = None
      self.passwords = None
      self.callback_loader = None
      self.default_callback_whitelist = None
      self.result_callback = None
      self.run_additional_callbacks = None
      self.run_tree = None
      self.strategy = None
      self.timeout = None
      self

# Generated at 2022-06-11 16:52:45.202298
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule("tqm")
    assert(obj._host_pinned == True)

# Generated at 2022-06-11 16:52:46.939854
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    StrategyModule(tqm)

# Generated at 2022-06-11 16:52:58.794028
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import os
    import json

    loader = DataLoader()

    cur_dir = os.path.dirname(__file__)
    test_data_file_path = os.path.join(cur_dir, os.path.pardir, 'test_data.json')
    with open(test_data_file_path) as f:
        test_data = json.load(f)

    variable_manager = VariableManager()

# Generated at 2022-06-11 16:53:00.651920
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule({})
    assert strategy._host_pinned

# Generated at 2022-06-11 16:53:01.381748
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:53:02.685997
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('test')
    assert strategy_module

# Generated at 2022-06-11 16:53:05.966654
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Assert the object is created
    assert isinstance(StrategyModule({}), StrategyModule)

# Generated at 2022-06-11 16:53:10.032251
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Constructor")
    tqm = "Test"
    test_instance = StrategyModule(tqm)
    assert test_instance._host_pinned == True
    assert test_instance._display == None
    assert test_instance._need_to_unblock == None


# Generated at 2022-06-11 16:53:14.927480
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create an object of FreeStrategyModule class
    f = FreeStrategyModule(None)
    # Create an object of StrategyModule class
    s = StrategyModule(None)

    assert f._host_pinned == False
    assert s._host_pinned == True

# Generated at 2022-06-11 16:53:15.617063
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__



# Generated at 2022-06-11 16:53:16.640549
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule('testStrategyModule')

# Generated at 2022-06-11 16:53:17.125513
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True is True

# Generated at 2022-06-11 16:53:20.434308
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    tqm = StrategyModule()
    assert tqm._host_pinned == True

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-11 16:53:23.446892
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a strategy module instance
    strategy = StrategyModule('test')
    # Assert the host_pinned value is True
    assert strategy._host_pinned is True

# Generated at 2022-06-11 16:53:28.450034
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm_instance = 'tqm_instance'
    strategy_module = StrategyModule(tqm_instance)
    assert strategy_module is not None
    assert strategy_module._tqm == tqm_instance
    assert strategy_module._host_pinned


' '.join(StrategyModule.__doc__.split())

# Generated at 2022-06-11 16:53:32.973905
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule.__name__ == 'StrategyModule')
    assert(StrategyModule.__doc__ == FreeStrategyModule.__doc__)
    assert(StrategyModule.__doc__ == '''Base ansible Task execution class (for this host)''')



# Generated at 2022-06-11 16:53:40.109898
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class DummyTqm:
        class DummyQueue:
            def __init__(self,hosts):
                self.hosts = hosts
        def __init__(self,hosts):
            self.hosts=DummyTqm.DummyQueue(hosts)
    h = ["a","b","c","d"]
    tqm = DummyTqm(h)
    sm = StrategyModule(tqm)
    assert(sm.get_host_pinned()==True)

# Generated at 2022-06-11 16:53:50.322192
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global strategy
    global tqm
    import ansible.playbook.task_queue_manager
    tqm = ansible.playbook.task_queue_manager.TaskQueueManager(inventory=None, variable_manager=None, loader=None, options=None, passwords=None, stdout_callback=None, run_additional_callbacks=True, run_tree=False, settings=None)
    strategy = StrategyModule(tqm)
    assert tqm == strategy._tqm
    assert strategy.get_host_list() == []
    strategy.add_tasks(None)
    assert strategy.get_host_list() == []
    assert strategy.get_next_task_for_host(None, None) == None
    assert strategy._host_pinned

# Generated at 2022-06-11 16:53:52.499317
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule==StrategyModule
    tqm = None
    test=StrategyModule(tqm)


# Generated at 2022-06-11 16:53:53.399420
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-11 16:54:01.002307
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   strategy_module = StrategyModule(tqm=None)
   # Check for object type of strategy_module
   assert isinstance(strategy_module,StrategyModule.__class__)
   # check for object type of _host_pinned
   assert isinstance(strategy_module._host_pinned,object)
   # check for value of _host_pinned
   assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:54:02.482781
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(tqm), FreeStrategyModule)

# Generated at 2022-06-11 16:54:05.461191
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    assert StrategyModule.__name__ == "StrategyModule"

    s = StrategyModule('')
    assert s.__class__.__name__ == "StrategyModule"

# Generated at 2022-06-11 16:54:17.022498
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned == True
    assert strategy_module._batch_count == 0
    assert strategy_module._cur_running_tasks is None
    assert strategy_module._cur_serial_no == 0
    assert strategy_module._iterator is None
    assert strategy_module._max_serial_failures is None
    assert strategy_module._play is None
    assert strategy_module._running_queue is None
    assert strategy_module._serial_no == 0
    assert strategy_module._stats is None
    assert strategy_module._task_cache is None
    assert strategy_module._task_count == 0
    assert strategy_module._total_task_count == 0
    assert strategy_module._wait_for_available_results == False
    assert strategy_module._wait_for_serial

# Generated at 2022-06-11 16:54:26.549439
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.module_utils._text import to_text
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    
    # Create a fake tqm object
    class FakeTQM:

        def __init__(self):
            self.shared_loader_obj = None
            self.inventory = None
            self.variables = None
            self.loader = None
            self.options = None
            self.passwords = None
            self.stdout_callback = None
            self.connection_plugins = None
            self.callback_plugins = None
            self.callbacks = None
            self.stats = None
            self.fail_hosts = None
            self.done_hosts = None

# Generated at 2022-06-11 16:54:33.536524
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule("test")
    assert strategy._host_pinned == True
    assert strategy._batch_size == 0
    assert strategy._inventory == None
    assert strategy._play_iterator == None
    assert strategy._unreachable_queue == None
    assert strategy._variable_manager == None
    assert strategy._worker_prc == None
    assert strategy._worker_prcs == None
    assert strategy._worker_procs == None
    assert strategy._exit_on_error == None

# Generated at 2022-06-11 16:54:38.861486
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm='tqm')._host_pinned is True

# Generated at 2022-06-11 16:54:40.932962
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert s._host_pinned == True

# Generated at 2022-06-11 16:54:41.490371
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-11 16:54:45.300858
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MockTQM()
    strategy = StrategyModule(tqm)
    assert strategy.tqm == tqm
    assert strategy._host_pinned == True


# Generated at 2022-06-11 16:54:47.100464
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategymodule = StrategyModule('tqm')
    assert strategymodule._host_pinned == True

# Generated at 2022-06-11 16:54:48.418514
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    print(strategy_module)

# Generated at 2022-06-11 16:54:51.767319
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned as strategy_host_pinned
    reload(strategy_host_pinned)
    testobj = strategy_host_pinned.StrategyModule(None)

# Generated at 2022-06-11 16:54:52.394836
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    assert FreeStrategyModule

# Generated at 2022-06-11 16:54:55.891872
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    fake_tqm = type('fake_tqm', (object,), {})
    assert isinstance(StrategyModule(fake_tqm), StrategyModule)

# testing the StrategyModule constructor with a different argument

# Generated at 2022-06-11 16:54:57.382507
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ bogus test to get the class defined for documentation"""
    assert True

# Generated at 2022-06-11 16:55:07.799389
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:55:08.670177
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-11 16:55:11.480330
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj_StrategyModule = StrategyModule(tqm='tqm')
    assert obj_StrategyModule

# Generated at 2022-06-11 16:55:14.725712
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    val = obj._host_pinned
    assert val == True
    print("Test passed: StrategyModule constructor")

# Test method get_host_list()

# Generated at 2022-06-11 16:55:17.869930
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = None
    strategy_instance = StrategyModule(test_tqm)
    assert strategy_instance.__class__.__name__ == 'StrategyModule'

# Generated at 2022-06-11 16:55:19.606158
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule('tqm')
    assert s._host_pinned == True

# Generated at 2022-06-11 16:55:28.597941
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_queue_manager import TaskQueueManager
    from ansible.executor.task_queue_manager import _load_callbacks_for_plugin
    from ansible.inventory.manager import InventoryManager

    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=None, sources=None),
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
    )
    _load_callbacks_for_plugin(tqm)

    sm = StrategyModule(tqm)

# Generated at 2022-06-11 16:55:28.981238
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:55:31.166798
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global display
    display = Display()
    s = StrategyModule(display)
    assert s._host_pinned == True

# Generated at 2022-06-11 16:55:31.932834
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:55:54.943600
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-11 16:55:58.118591
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Unit test for constructor of class StrategyModule
    """

    # None object of class TaskQueueManager, should raise an exception
    if True:
        try:
            a = StrategyModule(None)
        except Exception as err:
            print("Exception: " + str(err))

# Generated at 2022-06-11 16:55:59.254113
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(1)


# Generated at 2022-06-11 16:56:00.765581
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm = "tqm")
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:56:05.567748
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest

    class TestStrategyModule(unittest.TestCase):
        def test_constructor(self):
            self.assertIsInstance(StrategyModule(None), StrategyModule)
            self.assertTrue(StrategyModule(None)._host_pinned)


    t = TestStrategyModule()
    t.test_constructor()

# Generated at 2022-06-11 16:56:06.214799
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	pass

# Generated at 2022-06-11 16:56:08.374734
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ""
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None

# Generated at 2022-06-11 16:56:10.236307
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock
    module = StrategyModule(mock.MagicMock())
    assert module._host_pinned is True

# Generated at 2022-06-11 16:56:13.482480
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    strategy = StrategyModule(tqm)
    assert strategy
    assert strategy._tqm == 'tqm'
    assert strategy._host_pinned == True

# Generated at 2022-06-11 16:56:15.678900
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=tqm)


# Generated at 2022-06-11 16:56:51.162085
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   TQM = "TQM"
   StrategyModule(TQM)

# Generated at 2022-06-11 16:56:53.634425
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ## strategy_module = StrategyModule(tqm)
    strategy_module = StrategyModule
    assert(strategy_module)


# Generated at 2022-06-11 16:56:57.886137
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from nose.tools import assert_equal
    from ansible.plugins.strategy import StrategyModule

    tqm = TQM()
    strategy = StrategyModule(tqm)

    assert_equal(strategy._host_pinned, True, 'Host must be pinned')
    assert_equal(tqm, strategy._tqm, 'TQM not initialized correctly')


# Generated at 2022-06-11 16:56:58.902622
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-11 16:57:00.686125
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-11 16:57:01.360787
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:57:02.822703
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Attempting to start test")
    try:
        s = StrategyModule("test")
    except:
        print("Failed")
        raise
    print("Passed")

# Generated at 2022-06-11 16:57:03.486848
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule("tqm")
    assert x._host_pinned == True

# Generated at 2022-06-11 16:57:04.173260
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1==1

# Generated at 2022-06-11 16:57:07.619701
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  class _tqm:
    def __init__(self):
      self.hostvars = {}

  tqm = _tqm()
  sm = StrategyModule(tqm)
  assert sm._host_pinned == True


# Generated at 2022-06-11 16:58:53.225468
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Test the constructor"""
    display = Display()
    tqm = TaskQueueManager(
        inventory=Inventory(loader=DictDataLoader(dict())),
        variable_manager=VariableManager(),
        loader=DictDataLoader(dict()),
        options=Options(),
        passwords=dict(),
        stdout_callback=DefaultRunnerCallbacks(),
    )
    result = StrategyModule(tqm)
    assert result._host_pinned == True


# Generated at 2022-06-11 16:58:53.704872
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-11 16:58:54.483257
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('tqm')
    assert StrategyModule

# Generated at 2022-06-11 16:58:56.083131
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    stm = StrategyModule(None)
    assert stm is not None
    assert stm._host_pinned == True

# Generated at 2022-06-11 16:59:01.434620
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mock_tqm = {"tqm1": 1}
    mock_self = {"self1": 1}
    test_strategy_module1 = StrategyModule(mock_tqm)
    mock_self["tqm"] = mock_tqm
    mock_self["_host_pinned"] = True
    assert test_strategy_module1.__dict__ == mock_self

# Generated at 2022-06-11 16:59:02.617650
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-11 16:59:11.022392
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.debug import enable_debugger
    from ansible import context
    from ansible.plugins.strategy import StrategyModule
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    context._init_global_context(load_default_config=False)
    enable_debugger()
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None,
    )
    sm = StrategyModule(tqm)
    assert sm is not None

# Generated at 2022-06-11 16:59:12.346988
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("")
    print("Testing constructor of class StrategyModule")


# Generated at 2022-06-11 16:59:19.343512
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import context
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_extra_vars
    from ansible.utils.vars import merge_vars
    from ansible.utils.vars import combine_vars

    # Hostpinned Strategy constructor
    test_tqm = None
    strategyModule = StrategyModule(test_tqm)

    # StrategyModule constructor
    test_tqm = None
    strategyModule = StrategyModule(test_tqm)

    # FreeStrategyModule constructor
    test_tqm = None
    strategyModule = FreeStrategyModule(test_tqm)

    # display.fatal method
    display.fatal("test")
   

# Generated at 2022-06-11 16:59:20.274619
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('tqm')._host_pinned