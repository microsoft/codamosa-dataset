

# Generated at 2022-06-11 16:52:30.019304
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  # Instantiate the StrategyModule class
  test_strategyModule = StrategyModule(tqm=None)
  # Assert that the _host_pinned attribute is set to True
  assert test_strategyModule._host_pinned == True


# Generated at 2022-06-11 16:52:32.324093
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import time

    tqm = StrategyModule(time.time())
    assert tqm._host_pinned

# Generated at 2022-06-11 16:52:34.675250
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True



# Generated at 2022-06-11 16:52:36.352369
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Load the strategy module as a Python module
from ansible.plugins.strategy import host_pinned

# Generated at 2022-06-11 16:52:38.197455
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-11 16:52:40.125991
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    assert obj is not None

# Generated at 2022-06-11 16:52:41.843331
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	print("Inside test_StrategyModule() ")
	#test_StrategyModule = StrategyModule()
	#test_StrategyModule.test_print()

# Generated at 2022-06-11 16:52:44.995464
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule('something')
    assert strategy._host_pinned == True

# Generated at 2022-06-11 16:52:46.790745
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule("Test")
    assert strategy is not None

# Generated at 2022-06-11 16:52:51.264571
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = {}
    host['test'] = {}

    tasks = [{"test": 1}]
    variables = {}
    # Use StrategyModule() to construct an instance of class StrategyModule
    sm = StrategyModule(host, tasks, variables)
    assert sm._host_pinned == True

# Generated at 2022-06-11 16:52:56.551031
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"
    assert StrategyModule.__doc__ == FreeStrategyModule.__doc__
    assert StrategyModule.__module__ == FreeStrategyModule.__module__
    assert StrategyModule.__dict__ == FreeStrategyModule.__dict__

# Generated at 2022-06-11 16:53:00.345154
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)
    strategy_module = StrategyModule(None)
    assert isinstance(strategy_module, FreeStrategyModule)
    # return outputs from StrategyModule class is None as of now, need to check from codebase.
    assert strategy_module._host_pinned == True

# Generated at 2022-06-11 16:53:01.429509
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-11 16:53:02.732997
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm = None)
    assert obj

# Generated at 2022-06-11 16:53:06.114769
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_queue_manager import TaskQueueManager
    try:
        # The task_queue_manager receives the options from the playbook, which are in-turn populated from the cli options.
        tqm = TaskQueueManager(None, None, None, None)
        # Instantiate the test strategy module
        strategy = StrategyModule(tqm)
        assert isinstance(strategy, StrategyModule)
    except Exception as e:
        assert False, 'Unhandled exception raised: {0}'.format(e)

# Generated at 2022-06-11 16:53:06.675956
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule

# Generated at 2022-06-11 16:53:07.134765
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule()

# Generated at 2022-06-11 16:53:08.307113
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Generated at 2022-06-11 16:53:09.034158
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"

# Generated at 2022-06-11 16:53:09.505604
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-11 16:53:11.810433
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-11 16:53:12.633003
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:53:13.254653
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:53:18.655571
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert len(StrategyModule.__doc__) > 0
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__init__.__code__.co_argcount == 2
    assert StrategyModule.__init__.__code__.co_varnames[0] == 'self'
    assert StrategyModule.__init__.__code__.co_varnames[1] == 'tqm'

# Generated at 2022-06-11 16:53:19.571455
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:53:25.696864
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock, patch, create_autospec
    from ansible.plugins.strategy import StrategyModule
    from ansible.utils.display import Display
    tqm = create_autospec(MagicMock)
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-11 16:53:27.231959
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__ is not FreeStrategyModule.__init__

# Generated at 2022-06-11 16:53:29.603969
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test'
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned



# Generated at 2022-06-11 16:53:35.806281
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.executor.task_queue_manager import TaskQueueManager
    strategy = StrategyModule(TaskQueueManager(Playbook(), Play()))

    # Assert that we get an object of class StrategyModule
    assert isinstance(strategy, StrategyModule)

    # Assert that strategy._host_pinned is set correctly
    assert strategy._host_pinned == True

# Generated at 2022-06-11 16:53:37.679612
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm=None)
    ansible_assert(module._host_pinned, True)



# Generated at 2022-06-11 16:53:44.579816
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #mock tqm
    tqm = object()

    #construct a StrategyModule
    #I am not sure which assert method is proper here
    assert StrategyModule(tqm)

# Generated at 2022-06-11 16:53:46.787572
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = StrategyModule("tqm")
    assert host._host_pinned == True

# Generated at 2022-06-11 16:53:47.497858
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(True)

# Generated at 2022-06-11 16:53:48.447726
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(object)

# Generated at 2022-06-11 16:53:49.970174
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm._host_pinned == True

# Generated at 2022-06-11 16:53:50.969591
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_host_pinned = StrategyModule()

# Generated at 2022-06-11 16:53:58.083600
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    from ansible.utils.display import Display
    display = Display()
    assert isinstance(display, Display)
    tqm = {}
    strategy_module = StrategyModule(tqm)
    assert isinstance(strategy_module, StrategyModule)
    assert isinstance(strategy_module, FreeStrategyModule)
    assert tqm == {}
    assert strategy_module.tqm == {}
    assert strategy_module._host_pinned == True


if __name__ == '__main__':
    print('Testing Ansible host_pinned strategy module')
    test_StrategyModule()

# Generated at 2022-06-11 16:53:59.517751
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Constructor test
    assert StrategyModule is not None

# Generated at 2022-06-11 16:54:04.161442
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM:
        def __init__(self):
            self.stats = dict(processed=dict(), dark=dict(), fail_percentage=dict())
    tqm = TQM()
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned


# Generated at 2022-06-11 16:54:06.087037
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    obj = StrategyModule(tqm)
    assert obj._host_pinned == True


# Generated at 2022-06-11 16:54:15.260614
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  # creating object of class StrategyModule with dummy arguments
  tqm = None
  x = StrategyModule(tqm)
  assert x._host_pinned == True

# Generated at 2022-06-11 16:54:17.476124
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True

# Generated at 2022-06-11 16:54:21.622301
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"
    assert StrategyModule.__doc__  == None

    assert StrategyModule.__init__.__name__ == "__init__"
    assert StrategyModule.__init__.__doc__  == None

    assert StrategyModule._host_pinned == True

# Generated at 2022-06-11 16:54:30.067528
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-11 16:54:31.322732
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-11 16:54:35.194181
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  from ansible.plugins.strategy.host_pinned import StrategyModule
  from ansible.executor.task_queue_manager import TaskQueueManager

  s = StrategyModule(TaskQueueManager())
  assert s._host_pinned

# Generated at 2022-06-11 16:54:36.241092
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule != FreeStrategyModule

# Generated at 2022-06-11 16:54:37.784309
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    S = StrategyModule("TQM")
    assert S._host_pinned == True

# Generated at 2022-06-11 16:54:41.218363
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test 1: strategy_plugins/host_pinned.py: StrategyModule: test for constructor of class StrategyModule")
    sm = StrategyModule(None)
    assert sm.__class__ == StrategyModule

# Generated at 2022-06-11 16:54:44.618495
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True
    assert strategy == strategy.host_state_map



# Generated at 2022-06-11 16:55:07.193042
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    print("StrategyModule tqm = ", sm._tqm)
    assert sm._tqm is None
    assert sm._host_pinned

# Generated at 2022-06-11 16:55:09.460020
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


if __name__ == "__main__" and __package__ is None:
    test_StrategyModule()

# Generated at 2022-06-11 16:55:10.613683
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  assert StrategyModule.__init__ != None

# Generated at 2022-06-11 16:55:17.469397
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Unit test of constructor of class StrategyModule
    """
    name = 'free'
    strategy_data = '''
{
    "default_strategy": "free",
    "strategy_plugins": [
        {
            "name": "free",
            "class_name": "FreeStrategyModule"
        },
        {
            "name": "host_pinned",
            "class_name": "HostPinnedStrategyModule"
        }
    ]
}
'''
    strategy_path = '%s/%s' % (os.path.dirname(__file__), '../../../plugins/strategy')
    strategy_paths = [strategy_path]
    display = Display()
    # TODO: has to get right attributes and right return type

# Generated at 2022-06-11 16:55:18.554985
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__ is not FreeStrategyModule.__init__

# Generated at 2022-06-11 16:55:20.258803
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("tqm")
    assert strategy_module
    assert strategy_module._host_pinned

# Generated at 2022-06-11 16:55:22.557341
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule('sg')


# Generated at 2022-06-11 16:55:23.688121
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-11 16:55:24.867786
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    tqm = Display()

# Generated at 2022-06-11 16:55:26.497528
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of StrategyModule class")
    StrategyModule()

# Generated at 2022-06-11 16:56:15.827081
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory import Inventory
    import ordered_set
    import jinja2

    mock_task = Task()
    mock_task._role = Role()
    mock_task.block = Block()
    mock_task.name = "fake"
    mock_task.loop = None
    mock_task.notified_by = None
    mock_task.changed_when = True
    mock_task.when = True
    mock_task.tags = ordered_set.OrderedSet(['all'])

# Generated at 2022-06-11 16:56:17.875175
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule

# Test if StrategyModule works

# Generated at 2022-06-11 16:56:19.915700
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm)
    assert s._host_pinned == True
    assert s.hosts_left == []


# Generated at 2022-06-11 16:56:22.053818
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    stmod = StrategyModule(tqm={})
    assert stmod._host_pinned == True


# Generated at 2022-06-11 16:56:27.386148
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.strategy_plugins import register_strategy_plugin
    from ansible.plugins.strategy import get_strategy_precedence
    register_strategy_plugin(
        'host_pinned',
        'tests.unit.plugins.strategy.test_host_pinned.StrategyModule',
        get_strategy_precedence('host_pinned'))

# Generated at 2022-06-11 16:56:28.279580
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-11 16:56:32.270831
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a=StrategyModule()
    print("\nClass StrategyModule::")
    print("\ta._host_pinned = " + str(a._host_pinned))

test_StrategyModule()

# Generated at 2022-06-11 16:56:32.786197
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    assert obj
    assert obj._host_pinned

# Generated at 2022-06-11 16:56:34.260154
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    #strategy = StrategyModule(tqm)
    #assert strategy

# Generated at 2022-06-11 16:56:37.640384
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-11 16:58:11.658042
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-11 16:58:12.285541
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 16:58:13.195335
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule(None)
    assert mod._host_pinned == True

# Generated at 2022-06-11 16:58:20.531425
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Constructor of StrategyModule

    :return:
    """
    import mock
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Create a mock for object TaskQueueManager
    with mock.patch('ansible.executor.task_queue_manager.TaskQueueManager') as mock_manager:
        tqm = mock_manager.return_value
        strategy = StrategyModule(tqm)
        assert isinstance(strategy, StrategyModule)
        assert isinstance(strategy._tqm, TaskQueueManager)
        assert strategy.name == 'host_pinned'
        assert strategy._host_pinned is True

# Generated at 2022-06-11 16:58:21.301684
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-11 16:58:26.137291
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager

    tqm = TaskQueueManager(None, None, None, None, None, None, None, None)
    s = StrategyModule(tqm)
    assert s._host_pinned is True

# Generated at 2022-06-11 16:58:28.604758
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = "localhost"
    display = Display()
    tqm = {"loader": "display"}
    sm = StrategyModule(tqm)
    return True

# Generated at 2022-06-11 16:58:34.742401
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)
    print("Unit test for strategy.host_pinned.py is successfull")

# To run unit test use the following command:
# python -m pytest test_host_pinned.py -v -s

# Unit test to check if the initial value of _host_pinned is set to True.

# Generated at 2022-06-11 16:58:38.319511
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    from ansible.plugins.strategy.host_pinned import StrategyModule as HostPinnedStrategyModule
    assert issubclass(HostPinnedStrategyModule, FreeStrategyModule)



# Generated at 2022-06-11 16:58:40.454396
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    assert StrategyModule(tqm) is not None

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-11 17:02:09.551401
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    assert issubclass(StrategyModule, object)
    assert issubclass(StrategyModule, FreeStrategyModule)
    strategy_instance = StrategyModule(tqm=None)
    assert strategy_instance.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert hasattr(strategy_instance, '_host_pinned')
    assert strategy_instance._host_pinned == True
    assert hasattr(strategy_instance, '_tqm')
    assert strategy_instance._tqm == None


# Generated at 2022-06-11 17:02:11.293859
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
        sm = StrategyModule(tqm = "")
        assert sm._host_pinned == True

# Generated at 2022-06-11 17:02:15.462101
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class test_host:
        pass
    test_host.name = 'test_host'
    test_host_list = [test_host]
    test_tqm = {'host_list': test_host_list}
    test_strategy_module = StrategyModule(test_tqm)
    assert test_strategy_module._host_pinned

# Generated at 2022-06-11 17:02:19.290902
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)
    aStrategyModule = StrategyModule()
    assert isinstance(aStrategyModule, FreeStrategyModule)
    assert aStrategyModule._host_pinned == True

# Generated at 2022-06-11 17:02:21.209903
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Constructor of class StrategyModule
    module = StrategyModule(None)

    assert module == None
    assert module._host_pinned == True

# Generated at 2022-06-11 17:02:22.029009
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-11 17:02:25.013749
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    obj = FreeStrategyModule(display)
    obj._host_pinned = True

# Execute a test for class StrategyModule
#test_StrategyModule()

# Generated at 2022-06-11 17:02:26.383719
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MagicMock()
    StrategyModule(tqm)