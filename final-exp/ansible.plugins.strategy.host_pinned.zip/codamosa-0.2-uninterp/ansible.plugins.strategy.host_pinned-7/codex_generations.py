

# Generated at 2022-06-17 14:01:45.575383
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.free.StrategyModule,)

# Generated at 2022-06-17 14:01:57.909270
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-17 14:02:05.162693
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__bases__ == (FreeStrategyModule,)

# Generated at 2022-06-17 14:02:06.936362
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-17 14:02:19.280672
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:02:28.960993
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:02:32.143847
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'

# Generated at 2022-06-17 14:02:35.507848
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-17 14:02:44.299722
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:02:55.591965
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.free.StrategyModule,)

# Generated at 2022-06-17 14:02:58.572802
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-17 14:02:59.861995
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None

# Generated at 2022-06-17 14:03:10.327191
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:03:11.536890
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-17 14:03:22.341713
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'

# Generated at 2022-06-17 14:03:32.443879
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:03:45.677053
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-17 14:03:46.811006
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-17 14:03:58.509940
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:04:00.535371
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-17 14:04:06.654870
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__bases__ == (FreeStrategyModule,)

# Generated at 2022-06-17 14:04:07.523112
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-17 14:04:09.255386
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:04:19.271170
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.free.StrategyModule,)

# Generated at 2022-06-17 14:04:29.301536
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-17 14:04:30.846624
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:04:32.144671
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-17 14:04:33.747909
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-17 14:04:36.469502
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned == True

# Generated at 2022-06-17 14:04:38.057422
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)

# Generated at 2022-06-17 14:04:51.884891
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'

# Generated at 2022-06-17 14:04:53.513304
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-17 14:04:53.956237
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-17 14:04:57.706162
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:04:59.569143
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True


# Generated at 2022-06-17 14:05:00.415767
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)

# Generated at 2022-06-17 14:05:01.739266
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-17 14:05:09.492012
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:05:21.370302
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:05:33.081750
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:05:52.374536
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:05:57.373681
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-17 14:05:58.043717
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-17 14:05:58.771200
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-17 14:06:07.970903
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    from ansible.plugins.strategy import StrategyBase
    from ansible.plugins.loader import strategy_loader
    from ansible.utils.display import Display
    display = Display()
    strategy_loader.add_directory('./lib/ansible/plugins/strategy')
    strategy_loader.add_directory('./lib/ansible/plugins/strategy/host_pinned')
    strategy_loader.add_directory('./lib/ansible/plugins/strategy/free')
    strategy_loader.add_directory('./lib/ansible/plugins/strategy/linear')

# Generated at 2022-06-17 14:06:18.867476
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:06:23.029702
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__bases__ == (FreeStrategyModule,)

# Generated at 2022-06-17 14:06:30.459605
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:06:33.962789
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-17 14:06:44.110958
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:07:09.484652
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:07:10.660504
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-17 14:07:22.203981
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__bases__ == (FreeStrategyModule,)

# Generated at 2022-06-17 14:07:30.233449
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__bases__ == (FreeStrategyModule,)

# Generated at 2022-06-17 14:07:32.058510
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-17 14:07:33.576390
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-17 14:07:38.659503
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'

# Generated at 2022-06-17 14:07:45.941528
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:07:55.343414
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.free.StrategyModule,)

# Generated at 2022-06-17 14:08:06.121741
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''

# Generated at 2022-06-17 14:08:53.825226
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-17 14:08:54.785966
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-17 14:08:56.102252
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-17 14:09:06.435468
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-17 14:09:08.412234
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-17 14:09:09.398191
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-17 14:09:10.402435
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None

# Generated at 2022-06-17 14:09:19.545779
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:09:20.933036
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-17 14:09:21.956863
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)._host_pinned == True

# Generated at 2022-06-17 14:10:54.723776
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-17 14:11:04.359161
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:11:14.109383
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.free.StrategyModule,)

# Generated at 2022-06-17 14:11:17.061748
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"
    assert StrategyModule.__doc__ == "Executes tasks on each host without interruption"
    assert StrategyModule.__module__ == "ansible.plugins.strategy.host_pinned"
    assert StrategyModule.__bases__ == (FreeStrategyModule,)

# Generated at 2022-06-17 14:11:22.994994
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.free.StrategyModule,)

# Generated at 2022-06-17 14:11:23.862417
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:11:24.971249
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-17 14:11:32.991801
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.free.StrategyModule,)

# Generated at 2022-06-17 14:11:34.851503
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)._host_pinned

# Generated at 2022-06-17 14:11:44.479490
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__doc__ == 'Executes tasks on each host without interruption'