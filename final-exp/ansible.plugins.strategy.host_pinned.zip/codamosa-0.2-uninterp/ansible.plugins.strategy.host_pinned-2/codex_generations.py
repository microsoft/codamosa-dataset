

# Generated at 2022-06-17 14:01:33.981813
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)

# Generated at 2022-06-17 14:01:43.917722
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__bases__ == (FreeStrategyModule,)

# Generated at 2022-06-17 14:01:55.364875
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:02:05.323137
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:02:16.948004
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.free.StrategyModule,)

# Generated at 2022-06-17 14:02:18.041127
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-17 14:02:19.922556
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-17 14:02:29.322176
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:02:42.825113
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__bases__ == (FreeStrategyModule,)

# Generated at 2022-06-17 14:02:54.072656
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:03:04.894406
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:03:05.895091
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None

# Generated at 2022-06-17 14:03:16.995124
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:03:19.573880
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-17 14:03:20.612296
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:03:31.169064
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:03:44.985216
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:03:45.879476
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__

# Generated at 2022-06-17 14:03:57.769480
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:04:07.561976
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__bases__ == (FreeStrategyModule,)

# Generated at 2022-06-17 14:04:22.149627
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.free.StrategyModule,)

# Generated at 2022-06-17 14:04:23.269944
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-17 14:04:24.383964
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-17 14:04:31.564399
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:04:40.384611
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.free.StrategyModule,)

# Generated at 2022-06-17 14:04:40.928429
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-17 14:04:42.612981
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-17 14:04:44.043594
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-17 14:04:53.067943
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:05:04.104018
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:05:10.748424
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-17 14:05:13.300515
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-17 14:05:23.610975
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options_vars

# Generated at 2022-06-17 14:05:34.099959
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.free.StrategyModule,)

# Generated at 2022-06-17 14:05:37.781848
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''

# Generated at 2022-06-17 14:05:38.597997
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-17 14:05:47.789332
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-17 14:05:48.836753
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:05:49.653347
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-17 14:05:50.494028
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-17 14:06:09.088421
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-17 14:06:18.776958
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.free.StrategyModule,)

# Generated at 2022-06-17 14:06:19.432697
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-17 14:06:21.606413
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-17 14:06:29.814330
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:06:31.062994
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-17 14:06:43.081842
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:06:52.265042
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:06:52.825081
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-17 14:07:05.177274
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__bases__ == (FreeStrategyModule,)
    assert StrategyModule.__dict__['__init__'].__name__ == '__init__'

# Generated at 2022-06-17 14:07:31.144801
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'

# Generated at 2022-06-17 14:07:35.513905
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == FreeStrategyModule.__doc__
    assert StrategyModule.__init__.__doc__ == FreeStrategyModule.__init__.__doc__

# Generated at 2022-06-17 14:07:39.873743
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__bases__ == (FreeStrategyModule,)

# Generated at 2022-06-17 14:07:44.440149
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.free.StrategyModule,)

# Generated at 2022-06-17 14:07:45.809366
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-17 14:07:55.057660
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.free.StrategyModule,)

# Generated at 2022-06-17 14:07:56.197847
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:08:06.790428
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:08:09.085268
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == FreeStrategyModule.__doc__

# Generated at 2022-06-17 14:08:09.975364
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-17 14:09:06.963302
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:09:14.845407
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__bases__ == (ansible.plugins.strategy.free.StrategyModule,)

# Generated at 2022-06-17 14:09:15.676440
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-17 14:09:25.857714
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-17 14:09:26.297768
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-17 14:09:27.660662
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None

# Generated at 2022-06-17 14:09:29.816535
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-17 14:09:30.525531
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-17 14:09:43.798679
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:09:46.719247
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'

# Generated at 2022-06-17 14:11:30.081637
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-17 14:11:42.614017
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__bases__ == (FreeStrategyModule,)