

# Generated at 2022-06-13 15:06:31.465114
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TaskQueueManager(None, None)
    strategy_module = StrategyModule(tqm)

# Generated at 2022-06-13 15:06:32.686230
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_obj = StrategyModule("")
    assert strategy_obj._host_pinned == True

# Generated at 2022-06-13 15:06:34.966140
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm='tqm')
    assert obj is not None
    assert obj._host_pinned == True


# Generated at 2022-06-13 15:06:35.483159
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-13 15:06:44.122106
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from collections import namedtuple
    from ansible.plugins.loader import strategy_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-13 15:06:45.007000
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-13 15:06:46.326077
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert(sm._host_pinned)

# Generated at 2022-06-13 15:06:47.716410
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule('tqm')
    assert s._host_pinned == True

# Generated at 2022-06-13 15:06:48.266812
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-13 15:06:51.087827
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #initialize
    tqm = ''
    stMod = StrategyModule(tqm)
    assert stMod._host_pinned == True
    assert stMod._tqm == tqm



# Generated at 2022-06-13 15:06:53.121482
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Define a strategy
    strategy = StrategyModule('test')
    assert strategy._host_pinned == True


# Generated at 2022-06-13 15:06:53.922741
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-13 15:06:55.497624
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned = StrategyModule()
    assert host_pinned._host_pinned == True

# Generated at 2022-06-13 15:06:57.549797
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm=object)
    assert sm._host_pinned == True

# Generated at 2022-06-13 15:06:58.628978
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm)
    assert obj._host_pinned == True

# Generated at 2022-06-13 15:06:59.357032
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule(None)


# Generated at 2022-06-13 15:07:01.156592
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-13 15:07:04.110752
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm = None)
    assert module._host_pinned == True

# Generated at 2022-06-13 15:07:06.026291
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ansible.plugins.strategy.host_pinned.StrategyModule(tqm=None)

# Generated at 2022-06-13 15:07:07.924972
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)



# Generated at 2022-06-13 15:07:11.674293
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule
    assert module.__name__ == 'StrategyModule'

# Generated at 2022-06-13 15:07:12.281408
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-13 15:07:12.930708
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-13 15:07:13.736565
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ Create a StrategyModule class, and verify it is an instance of StrategyModule """
    StrategyModule(tqm=None)

# Generated at 2022-06-13 15:07:14.369939
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1 == 1

# Generated at 2022-06-13 15:07:17.288380
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    myobj = StrategyModule(tqm)
    assert myobj._host_pinned == True

# Generated at 2022-06-13 15:07:17.756586
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-13 15:07:19.357581
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = True
    StrategyModule(tqm)

# Generated at 2022-06-13 15:07:21.073043
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm="tqm")
    assert strategy._host_pinned

# Test that the class of StrategyModule is StrategyModule

# Generated at 2022-06-13 15:07:22.185807
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-13 15:07:28.010995
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = FreeStrategyModule(play_context)
    assert isinstance(strategy, FreeStrategyModule)
    assert strategy.tqm == play_context
    assert strategy._host_pinned == True

# Generated at 2022-06-13 15:07:28.510255
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-13 15:07:30.264672
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule({})
    assert strategy_module._host_pinned is True


# Generated at 2022-06-13 15:07:35.103969
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # class StrategyModule(object):

    # def __init__(self, tqm):
        # self._name = 'host_pinned'
        # self._display = Display()
        # self._tqm = tqm
        # self._batch_size = 0
        # self._batch_count = 0
        # self._inventory_hosts = {}
        # self._host_pinned = False

    assert StrategyModule._name == 'host_pinned'
    # assert StrategyModule._display == Display()
    # assert StrategyModule._tqm == tqm
    assert StrategyModule._batch_size == 0
    assert StrategyModule._batch_count == 0
    assert StrategyModule._inventory_hosts == {}
    assert StrategyModule._host_pinned == True

# Generated at 2022-06-13 15:07:38.120772
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    constructor test
    '''
    # pylint: disable=too-many-statements
    TQM = None
    strategy = StrategyModule(TQM)
    assert strategy.get_name() == 'host_pinned'

# Generated at 2022-06-13 15:07:41.724608
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # test case 1
    # test constructor of class StrategyModule
    strategy_obj = StrategyModule("tqm")
    assert strategy_obj is not None
    assert strategy_obj.tqm == "tqm"
    assert strategy_obj._host_pinned == True
    assert strategy_obj._display == display

# Generated at 2022-06-13 15:07:44.275301
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock
    display = mock.Mock()
    tqm = mock.Mock()

    module = StrategyModule(tqm)
    assert module._tqm is tqm
    assert module._host_pinned is True



# Generated at 2022-06-13 15:07:45.318696
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(122)
    assert a._host_pinned == True

# Generated at 2022-06-13 15:07:47.562559
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Testing StrategyModule class')
    display_obj = Display()
    strategy_module_obj = StrategyModule(display_obj)
    print(strategy_module_obj)
    assert strategy_module_obj is not None

test_StrategyModule()

# Generated at 2022-06-13 15:07:51.876485
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule.__init__(tqm)")

    tqm = 'tqm'

    try:
        test = StrategyModule(tqm)

    except:
        print("ERROR: StrategyModule.__init__(tqm)")
        return False

    return True

# Generated at 2022-06-13 15:08:02.180516
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	tqm = StrategyModule(None)
	print(tqm._host_pinned)

# Generated at 2022-06-13 15:08:07.341496
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global Display
    Display = Display
    global StrategyModule
    StrategyModule = StrategyModule
    try:
        from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
        from ansible.utils.display import Display
    except ImportError:
        return
    display = Display()
    StrategyModule('')

# Generated at 2022-06-13 15:08:08.819013
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__ != FreeStrategyModule.__init__

# Generated at 2022-06-13 15:08:12.027315
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    playbook = "some playbook"

    display.verbosity = 4
    display.deprecated('This is deprecated.')
    assert display.verbosity == 4

    tqm = None

    s = StrategyModule(tqm)

# Generated at 2022-06-13 15:08:13.704323
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True

# Generated at 2022-06-13 15:08:14.226742
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-13 15:08:15.954849
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
        sm = StrategyModule(None)
        assert isinstance(sm, StrategyModule)

# Generated at 2022-06-13 15:08:17.456032
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)
    assert isinstance(StrategyModule(tqm=None), StrategyModule)

# Generated at 2022-06-13 15:08:24.267379
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = Host('127.0.0.1')
    vm = MagicMock()
    vm.wait_for_connection = MagicMock()
    vm.wait_for_connection.return_value = True
    connection = Connection(vm)
    task = Task(MagicMock(), connection, host)
    result = Result()
    display.verbosity = 0
    tqm = TaskQueueManager('host_pinned', MagicMock(), None, None)
    tqm.tasks.append(task)
    tqm.results_callback.process_result(host, result)
    tqm.host_pinned = False
    s = StrategyModule(tqm)
    assert s._host_pinned == True


# Generated at 2022-06-13 15:08:28.411254
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # TODO: mock the objects needed for parameter tqm

    # test the constructor
    strategy = StrategyModule(tqm)

    print("test_StrategyModule: %s" % strategy)

# Generated at 2022-06-13 15:08:44.811760
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-13 15:08:47.881405
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    t = StrategyModule(tqm='')
    assert t._host_pinned==True

# Generated at 2022-06-13 15:08:50.980414
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    FreeStrategyModule.__init__(StrategyModule, tqm=None)
    StrategyModule.__init__(StrategyModule, tqm=None)

# Generated at 2022-06-13 15:08:51.400141
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return

# Generated at 2022-06-13 15:08:52.554243
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=object())


# Generated at 2022-06-13 15:08:54.730359
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert(strategy._host_pinned == True)
    assert(strategy.tqm == None)

# Generated at 2022-06-13 15:08:55.552171
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    PlayContext()
    StrategyModule()
    assert True

# Generated at 2022-06-13 15:08:56.966677
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    strategy = StrategyModule(display)
    assert strategy._host_pinned == True

# Generated at 2022-06-13 15:08:57.737566
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule('tqm')

# Generated at 2022-06-13 15:08:58.215194
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-13 15:09:39.547568
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-13 15:09:41.774677
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a= StrategyModule()
    assert a._host_pinned == True
    a1 = StrategyModule(tqm=None)
    assert a1._host_pinned == True

# Generated at 2022-06-13 15:09:43.290494
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    s = StrategyModule(tqm)

# Generated at 2022-06-13 15:09:44.610297
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm=None)
    assert sm._host_pinned

# Generated at 2022-06-13 15:09:46.201229
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Test StrategyModule
    module = StrategyModule(tqm=None)

    # Test _host_pinned
    assert module._host_pinned is True

# Generated at 2022-06-13 15:09:47.810849
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    assert StrategyModule(tqm)._host_pinned

# Generated at 2022-06-13 15:09:49.621204
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule")
    assert StrategyModule
    print("Success: StrategyModule")


# Generated at 2022-06-13 15:09:52.795870
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned as strategy_pinned
    obj = strategy_pinned.StrategyModule()
    assert obj._host_pinned == True
    assert obj._tqm == None
    assert obj._display == None

# Generated at 2022-06-13 15:09:53.352603
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-13 15:09:53.931738
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-13 15:11:10.952213
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module._host_pinned == True, 'strategy_module._host_pinned should be True'

# Generated at 2022-06-13 15:11:14.417030
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        a = StrategyModule(1)
        assert a._host_pinned == True
    except Exception as e:
        print("Exception: %s" % e)
    return

# Unit test
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-13 15:11:15.674891
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    assert obj._host_pinned == True

# Generated at 2022-06-13 15:11:18.190810
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Test_TQM(object):
        def __init__(self):
            self.workers = 10
            self.options = None
    tqm = Test_TQM()
    sm = StrategyModule(tqm)
    return sm

# Generated at 2022-06-13 15:11:21.102619
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass
#     class Tqm():
#         def __init__(self):
#             self.host_pinned = True
# 
#     tqm1 = Tqm()
#     s = StrategyModule(tqm1)
#     #assert s._host_pinned == True

# Generated at 2022-06-13 15:11:22.570083
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-13 15:11:25.752492
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Initializing StrategyModule object with tqm parameter
    # It should not throw an exception
    StrategyModule("tqm")

# Generated at 2022-06-13 15:11:33.979185
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-13 15:11:34.538118
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-13 15:11:35.404392
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm)
    assert obj is not None

# Generated at 2022-06-13 15:14:34.198898
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tm = StrategyModule(None)
    assert tm._host_pinned

# Generated at 2022-06-13 15:14:38.562029
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(
        inventory = None,
        variable_manager = None,
        loader = None,
        options = None,
        passwords = None,
        stdout_callback = None,
        run_additional_callbacks = False,
        run_tree = True,
        checkpoint_callback = None,
    )
    strategy = StrategyModule(tqm)
    assert str(strategy ) != ""
    assert strategy._host_pinned == True

# Generated at 2022-06-13 15:14:41.224799
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__mro__ == (StrategyModule, FreeStrategyModule, object)

    assert hasattr(StrategyModule, '__init__')
    assert callable(StrategyModule.__init__)
    assert StrategyModule.__doc__ == FreeStrategyModule.__doc__
    assert StrategyModule.__init__.__doc__ == FreeStrategyModule.__init__.__doc__

# Generated at 2022-06-13 15:14:42.143993
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)


# Generated at 2022-06-13 15:14:51.578148
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # make a fake connection plugin
    class MockConnectionClass:

        def __init__(self, *args, **kwargs):
            self.queue_name = 'testhost'

        def __radd__(self, other):
            return other + 1

    class MockTQM:

        def __init__(self, *args, **kwargs):
            self.hosts = {'testhost': {'vars': {}}}
            self.connection_info = {'testhost': {'connection': 'local'}}
            self.cur_block_var_names = []

    print("Create StrategyModule with fake QueueManager object")
    strategy_module = StrategyModule(tqm=MockTQM())
    print("Test host_pinned attribute is True")
    assert strategy_module._host_pinned is True

# Generated at 2022-06-13 15:14:52.143628
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-13 15:14:53.345596
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    stmap = StrategyModule(strategy_module)
    pass

# Generated at 2022-06-13 15:14:53.808442
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1 == 1

# Generated at 2022-06-13 15:14:54.231143
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  StrategyModule('')

# Generated at 2022-06-13 15:15:02.802887
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager

    empty_group = Group('empty_group')

    all_group = Group('all')
    all_group.add_host(Host(name='host1', port=22, groups=[empty_group, all_group]))
    all_group.add_host(Host(name='host2', port=22, groups=[empty_group, all_group]))