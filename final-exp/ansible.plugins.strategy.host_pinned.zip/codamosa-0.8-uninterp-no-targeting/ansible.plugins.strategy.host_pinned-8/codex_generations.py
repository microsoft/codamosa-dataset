

# Generated at 2022-06-21 07:30:01.057818
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned = StrategyModule(None)
    assert host_pinned

# Generated at 2022-06-21 07:30:04.404773
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    strategy_module = StrategyModule('tqm')
    assert strategy_module is not None

# Generated at 2022-06-21 07:30:06.412615
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    assert StrategyModule(tqm).tqm == tqm

# Generated at 2022-06-21 07:30:09.590056
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = DummyStrategyModule()
    s = StrategyModule(tqm)
    assert s._host_pinned == True


# Generated at 2022-06-21 07:30:14.382609
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.strategy.host_pinned import StrategyModule
    sm = StrategyModule(5)
    assert sm._host_pinned == True

# Generated at 2022-06-21 07:30:16.405194
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule("test")
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:30:17.731982
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)



# Generated at 2022-06-21 07:30:20.043106
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule, type)

# Generated at 2022-06-21 07:30:29.511562
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor import task_queue_manager
    from ansible.plugins.strategy.host_pinned import StrategyModule

    loader = DataLoader()

    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost,')
    variable_manager.set_inventory(inventory)

    play_source =  dict(
            name = "Ansible Play",
            hosts = 'all',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='setup', args=''))
            ]
        )


# Generated at 2022-06-21 07:30:32.267671
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    assert StrategyModule



# Generated at 2022-06-21 07:30:34.779608
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-21 07:30:43.447686
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from io import StringIO
    # Create an inventory for testing
    yaml_inventory = """
    all:
      hosts:
        host1:
        host2:
        host3:
    """

    # Create a variable manager for testing
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=StringIO(yaml_inventory))
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-21 07:30:44.102362
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-21 07:30:45.419523
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing in StrategyModule")
    tqm = None
    strategy_module = StrategyModule(tqm)


# Generated at 2022-06-21 07:30:46.481305
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:30:49.009058
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	tqm = object()
	host = object()
	strategy_module = StrategyModule(tqm)
	assert strategy_module._host_pinned is True


# Generated at 2022-06-21 07:30:53.519558
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = None
        StrategyModule(tqm)
    except Exception as err:
        assert False, 'Failed to instantiate StrategyModule: {0}'.format(err)

# Generated at 2022-06-21 07:30:59.147170
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock
    mock_tqm = mock.MagicMock()
    mock_plugin = StrategyModule(mock_tqm)
    assert mock_plugin.tqm == mock_tqm
    assert mock_plugin._host_pinned is True
    assert isinstance(mock_plugin._display, Display)

# Generated at 2022-06-21 07:31:02.322148
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    strategy_dict = strategy.__dict__
    assert strategy_dict['_host_pinned'] == True

# Generated at 2022-06-21 07:31:05.096137
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule(None)
    assert strategyModule._host_pinned == True



# Generated at 2022-06-21 07:31:07.979926
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:31:10.145382
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(display)
    assert strategy_module._host_pinned is True
    assert strategy_module._display is display

# Generated at 2022-06-21 07:31:17.605105
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible import context
    from units.mock.loader import DictDataLoader
    from units.mock.inventory import MockInventory
    from units.mock.playbook_reader import MockPlaybookReader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    class Options(object):
        host_pinned = False

    context.CLIARGS = Options
    host_list = ['host1', 'host2']
    loader = DataLoader()
    inventory = MockInventory(host_list)
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    loader = DictDataLoader

# Generated at 2022-06-21 07:31:27.041430
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    print(type(StrategyModule))
    strategy_module = StrategyModule()
    print(type(strategy_module))
    print(type(strategy_module.get_host_list))
    hosts = strategy_module.get_host_list()
    print(type(hosts))
    print(hosts)
    tqm = strategy_module._tqm
    print(type(tqm))


# Generated at 2022-06-21 07:31:29.589643
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned

# Test case for method __init__ of class StrategyModule

# Generated at 2022-06-21 07:31:30.865303
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:31:32.865280
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()
    assert obj._host_pinned == True

# Generated at 2022-06-21 07:31:33.677500
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  pass

# Generated at 2022-06-21 07:31:34.487469
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:31:35.645090
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule()
    assert strategyModule._host_pinned is True

# Generated at 2022-06-21 07:31:43.044107
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None, "StrategyModule class exists"
    assert isinstance(StrategyModule, object), "StrategyModule is the class type"

# Generated at 2022-06-21 07:31:47.784814
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM(object):
        pass
    failed = False
    try:
        s = StrategyModule(TQM())
    except Exception as e:
        failed = True
        print(e)
    assert(not failed)

# Generated at 2022-06-21 07:31:50.625010
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)
    assert StrategyModule != FreeStrategyModule
    assert hasattr(FreeStrategyModule, '__init__')
    assert StrategyModule.__init__ != FreeStrategyModule.__init__

# Generated at 2022-06-21 07:31:52.887856
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm = None)
    assert obj._host_pinned

# Generated at 2022-06-21 07:31:54.293276
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule != None


# Generated at 2022-06-21 07:32:02.178777
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.utils.display
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    from ansible.utils.display import Display
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(None, None, None, None)
    print(type(tqm))
    print(type(Display()))
    print(type(FreeStrategyModule(tqm)))
    x = StrategyModule(tqm)
    print(type(x))
    print(type(x.__dict__))

# Generated at 2022-06-21 07:32:04.831690
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module

# Generated at 2022-06-21 07:32:08.691222
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    cls = ansible.plugins.strategy.host_pinned.StrategyModule(None)
    print(cls)

# Generated at 2022-06-21 07:32:09.193098
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:32:19.463012
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class tqm():
        def __init__(self):
            self.hostvars = {}
            self.hosts = {}
            self.pattern = 'all'
            self.inventory = None
            self.WRITABLE_KEYS = {'vars', 'host_vars', 'playbook_basedir', 'playbook_dir'}
            self.unreachable_hosts = set()
            self.failed_hosts = set()
            self.stats = {}
    tqm = tqm()
    StrategyModule(tqm)

# Generated at 2022-06-21 07:32:28.196704
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:32:34.776019
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    import mock
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.loader import strategy_loader

    # Create a mock task queue manager and use it to initialize a class StrategyModule object
    tqm = mock.Mock()
    strategy = strategy_loader.get('host_pinned', tqm)

    # Assert that the object initialized is an object of class StrategyModule
    assert isinstance(strategy, StrategyModule)

# Generated at 2022-06-21 07:32:36.645034
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    StrategyModule(tqm)

# Generated at 2022-06-21 07:32:37.302132
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:32:41.429179
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"
    assert StrategyModule.__doc__ == "main ansible factory module"
    instance_StrategyModule = StrategyModule()
    assert instance_StrategyModule.__class__ == StrategyModule
    assert instance_StrategyModule._host_pinned == True

# Generated at 2022-06-21 07:32:43.402573
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    tsm = StrategyModule(tqm)

# Generated at 2022-06-21 07:32:54.559108
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   # Create a stub object for class Host
   host = Host()

   # Create a stub object for class Play
   play = Play()

   # Create a stub object for class PlayContext
   play_context = PlayContext()

   # Create a stub object for class Play
   play2 = Play()

   # Create a stub object for class PlayContext
   play_context2 = PlayContext()

   # Create a stub object for class Play
   play3 = Play()

   # Create a stub object for class PlayContext
   play_context3 = PlayContext()

   # Create a stub object for class Play
   play4 = Play()

   # Create a stub object for class PlayContext
   play_context4 = PlayContext()

   # Create a stub object for class TaskQueueManager

# Generated at 2022-06-21 07:33:01.123223
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 'StrategyModule' in globals()
    assert 'FreeStrategyModule' in globals()
    assert 'test_StrategyModule' in globals()
    strategy_module = StrategyModule(object)
    assert '_host_pinned' in strategy_module.__dict__ and '_terminated' in strategy_module.__dict__ and '_tqm' in strategy_module.__dict__
    assert '_failed_hosts' in strategy_module.__dict__ and '_unreachable_hosts' in strategy_module.__dict__ and '_stats' in strategy_module.__dict__
    assert '_display' in strategy_module.__dict__ and '_wait_on_pending_results' in strategy_module.__dict__
    assert type(strategy_module).__name__ == 'StrategyModule'

# Generated at 2022-06-21 07:33:02.889582
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.name == 'host_pinned'

# Generated at 2022-06-21 07:33:03.668045
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:33:21.334264
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()
    FreeStrategyModule()

# Generated at 2022-06-21 07:33:22.426433
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-21 07:33:34.359182
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import sys
    import os
    import tempfile

    sys.path.append(os.getcwd())

    from ansible.playbook import Playbook
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash

    class TestPlaybookClass(Playbook):
        pass

    class TestInventoryClass(Inventory):
        pass

    class TestVariableManagerClass(VariableManager):
        pass


# Generated at 2022-06-21 07:33:36.103751
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(), StrategyModule)

# Generated at 2022-06-21 07:33:37.482590
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)

# Generated at 2022-06-21 07:33:40.683117
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned = StrategyModule.__init__(StrategyModule)
    assert host_pinned is None, "StrategyModule constructor not working properly"

# Generated at 2022-06-21 07:33:43.987910
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestModule(StrategyModule):
        def __init__(self, tqm):
            super(TestModule, self).__init__(tqm)
            self._host_pinned = True
    return TestModule


# Generated at 2022-06-21 07:33:44.976324
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:33:47.715133
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm=None)
    assert module._host_pinned

# Generated at 2022-06-21 07:33:52.216572
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_host_pinned = True
    strategy_instance = StrategyModule('tqm')
    assert strategy_instance is not None
    assert test_host_pinned == strategy_instance._host_pinned

# Generated at 2022-06-21 07:34:39.620767
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-21 07:34:40.534604
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:34:44.726809
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = None
    test_StrategyMod = StrategyModule(test_tqm)
    assert test_StrategyMod._host_pinned == True

# Generated at 2022-06-21 07:34:47.195281
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule()
    StrategyModule(tqm)


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:34:48.629352
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  StrategyModule('tqm')

# Generated at 2022-06-21 07:34:50.910454
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm)
    assert obj._host_pinned == True

# Generated at 2022-06-21 07:34:58.045416
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    strategy_module = StrategyModule(None)
    assert isinstance(strategy_module, FreeStrategyModule) == True
    assert strategy_module._host_pinned is True

# test_StrategyModule()

# Generated at 2022-06-21 07:35:01.152136
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FakeTaskQueueManager()
    s = StrategyModule(tqm)
    assert(s._host_pinned)


# Generated at 2022-06-21 07:35:03.461971
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-21 07:35:05.251925
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-21 07:36:37.300691
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule' # class name
    assert StrategyModule.__doc__  == """Executes tasks on each host without interruption
Task execution is as fast as possible per host in batch as defined by C(serial) (default all).
Ansible will not start a play for a host unless the play can be finished without interruption by tasks for another host,
i.e. the number of hosts with an active play does not exceed the number of forks.
Ansible will not wait for other hosts to finish the current task before queuing the next task for a host that has finished.
Once a host is done with the play, it opens it's slot to a new host that was waiting to start.
Other than that, it behaves just like the "free" strategy."""

# Generated at 2022-06-21 07:36:44.882661
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    success = False

    # Test failure when no tqm is specified
    try:
        tqm = None
        sm = StrategyModule(tqm)
    except Exception:
        success = True
    assert success

    # Test success when tqm is specified
    tqm = True
    sm = StrategyModule(tqm)
    assert tqm == sm._tqm

    # Test inherited attributes
    assert sm._call_queue is None
    assert sm._process_finished_queue is None
    assert sm._iterator is None
    assert sm._final_q is None
    assert sm._step is None
    assert sm._play is None
    assert sm._paused is None
    assert sm._display is None

    # Test new attributes
    assert sm._host_pinned is True
test_StrategyModule()

# Generated at 2022-06-21 07:36:50.594264
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from mock import MagicMock
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 1
    tqm = MagicMock()
    StrategyModule(tqm)

# Generated at 2022-06-21 07:36:51.477232
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:36:52.405058
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	pass

# Generated at 2022-06-21 07:36:57.616956
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    # check if it is instance of `FreeStrategyModule`
    assert isinstance(strategy, FreeStrategyModule)
    # check if _host_pinned is True
    assert strategy._host_pinned

# Generated at 2022-06-21 07:36:59.803574
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy is not None

# Generated at 2022-06-21 07:37:01.831428
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule('tqm')
    assert a._host_pinned is True


# Generated at 2022-06-21 07:37:04.659514
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:37:08.123162
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True