

# Generated at 2022-06-21 07:30:00.687362
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_instance = StrategyModule(tqm="tqm")
    assert strategy_instance._host_pinned == True

# Generated at 2022-06-21 07:30:05.211178
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert type(StrategyModule) == type
    assert isinstance(StrategyModule, object)
    assert issubclass(StrategyModule, FreeStrategyModule)
    assert StrategyModule.__name__ == "StrategyModule"

# Generated at 2022-06-21 07:30:07.807184
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)

    assert isinstance(strategy_module, FreeStrategyModule)
    assert strategy_module._host_pinned == True
    assert strategy_module._tqm is None

# Generated at 2022-06-21 07:30:09.116642
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm='test')


# Generated at 2022-06-21 07:30:12.389176
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.verbosity = 4
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-21 07:30:17.725873
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy import StrategyModule as StrategyModuleParent
    strategyModule = StrategyModule()
    assert(strategyModule != None)
    assert(isinstance(strategyModule, StrategyModule))
    assert(isinstance(strategyModule, StrategyModuleParent))

# Generated at 2022-06-21 07:30:20.637195
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()

# Test for StrategyModule class

# Generated at 2022-06-21 07:30:21.456382
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:30:22.838364
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert len(StrategyModule.__doc__) > 0

# Generated at 2022-06-21 07:30:24.241256
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)

# Generated at 2022-06-21 07:30:27.015562
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  assert callable(StrategyModule), "Class StrategyModule is not callable"

# Generated at 2022-06-21 07:30:27.840788
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:30:35.662105
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import sys
    import ansible.utils.display
    from ansible.plugins.strategy.host_pinned import StrategyModule
    import ansible.utils.display
    sys.modules['ansible.utils.display'] = ansible.utils.display
    strategy_obj = StrategyModule(tqm=None)
    assert strategy_obj._host_pinned is True

# Generated at 2022-06-21 07:30:37.679255
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(tqm=None)
    assert a._host_pinned == True


# Generated at 2022-06-21 07:30:50.889022
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import constants as C
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler_task_list import HandlerTaskList
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import RoleInclude
    from ansible.plugins.strategy.free import StrategyModule
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    # noinspection PyUnresolvedReferences
    class FakePlayContext(PlayContext):
        pass

    # noinspection PyUnresolvedReferences

# Generated at 2022-06-21 07:30:53.920977
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm='Test')
    assert s._host_pinned == True
    assert s._blockers == {}
    assert s._step == 0
    assert s._display == Display()
    assert s._tqm == 'Test'

# Generated at 2022-06-21 07:30:56.154024
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    d = Display()
    tqm = TaskQueueManager()
    tqm.send_callback = mock.MagicMock()
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-21 07:30:58.089375
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None
    assert FreeStrategyModule is not None

# Generated at 2022-06-21 07:31:05.420996
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    strategy = StrategyModule(1)

    assert strategy._host_pinned is True
    assert strategy.tqm == 1
    assert strategy._hosts == []
    assert strategy._top_level_tasks == []
    assert strategy._inventory is None
    assert strategy._variable_manager is None
    assert strategy._loader is None

# Generated at 2022-06-21 07:31:08.865567
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = AnsibleQueueManager()
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:31:12.107432
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
        assert StrategyModule(None)._host_pinned

# Generated at 2022-06-21 07:31:14.961728
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module
# test_StrategyModule()

# Generated at 2022-06-21 07:31:16.954912
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    obj = StrategyModule(tqm)
    assert True

# Generated at 2022-06-21 07:31:19.663772
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule('tqm')
    assert strategy is not None
    assert strategy.get_host_pinned()



# Generated at 2022-06-21 07:31:21.009569
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert not StrategyModule.__init__(StrategyModule)

# Generated at 2022-06-21 07:31:21.812960
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:31:24.446874
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock
    mock_tqm = mock.MagicMock()
    StrategyModule(mock_tqm)

# Generated at 2022-06-21 07:31:29.552360
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class _TQM:
        def __init__(self):
            self.shared = "shared"

    sm = StrategyModule(_TQM())
    assert sm.tqm.shared == "shared"
    assert sm.name == "host_pinned"


# Generated at 2022-06-21 07:31:33.159629
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Constructor of class StrategyModule
    '''

    display = Display()
    tqm = Display()
    StrategyModule(tqm)

# Generated at 2022-06-21 07:31:35.132908
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:31:39.603548
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:31:41.233705
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert abs(1 - 1) < 0.01

# Generated at 2022-06-21 07:31:47.214318
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    tqm = TQM(
        inventory=InventoryManager(loader=DataLoader()),
        variable_manager=VariableManager(),
        loader=DataLoader(),
        options=Options(),
        passwords={},
    )
    assert tqm
    assert StrategyModule(tqm)

# Generated at 2022-06-21 07:31:49.031183
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:31:53.182235
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(None)
    assert module._host_pinned == True

# unit tests
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:31:53.997420
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:32:00.798646
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test for the constructor of class StrategyModule
    '''
    strategy_module = StrategyModule('tqm')
    assert strategy_module
    assert strategy_module._tqm == 'tqm'
    assert strategy_module._workers == 5
    assert strategy_module._worker_threads == None
    assert strategy_module._batch_size == None
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:32:01.556676
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:32:04.931490
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    strategymodule = StrategyModule(tqm)
    assert strategymodule


# Generated at 2022-06-21 07:32:05.525160
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-21 07:32:16.120229
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x=StrategyModule()

# Generated at 2022-06-21 07:32:19.047244
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    obj2 = FreeStrategyModule(tqm=None)
    assert obj is not None

# Generated at 2022-06-21 07:32:22.238680
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Run unit tests directly
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:32:24.290338
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule.__doc__ == StrategyModule.__init__.__doc__)

# Generated at 2022-06-21 07:32:26.078464
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)

# Generated at 2022-06-21 07:32:27.764335
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('')

# Generated at 2022-06-21 07:32:30.148272
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned is True

# Generated at 2022-06-21 07:32:31.452095
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	t = StrategyModule()

# Generated at 2022-06-21 07:32:32.213783
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:32:32.794645
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:32:51.861572
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    t = object()
    s = StrategyModule(t)
    assert s.tqm == t
    assert s.display == Display()
    assert s.display.verbosity == 3
    assert s._host_pinned == True

# Generated at 2022-06-21 07:33:04.412719
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    host = Host(name = 'test')
    task = Task(action = dict(module = 'test'), name = 'test')
    task.register_deps(loader = Mock(), templar = Mock())
    tqm = TaskQueueManager(
        inventory = Mock(),
        variable_manager = Mock(),
        loader = Mock(),
        options = Mock(),
        passwords = Mock(),
        standard_output_callback = 'default',
        stdout_callback = Mock(),
        run_additional_callbacks = Mock(),
        run_tree = False,
        display = Mock()
    )
    strategy = StrategyModule(tqm)
    strategy._tqm = tqm
    assert strategy._host_pinned == True
    assert strategy._never_block_hosts == False
    strategy._tqm

# Generated at 2022-06-21 07:33:06.816517
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(1)
    assert sm._host_pinned == True

# Generated at 2022-06-21 07:33:10.363264
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_instance = StrategyModule(tqm)
    assert strategy_instance._host_pinned == True

# Generated at 2022-06-21 07:33:15.658175
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    err = False
    try:
        path = "/home/ansible/.ansible/plugins/strategy"
        name = "host_pinned.py"
        mod = __import__(path + "." + name[:-3], globals(), locals(), ['object'])
        myclass = getattr(mod, 'StrategyModule')
    except ImportError as e:
        print("Failed to import module.{}: {}".format(name, e))
        err = True
    assert err == False

# Generated at 2022-06-21 07:33:18.343743
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule(tqm)
    assert tqm._host_pinned == True

# Generated at 2022-06-21 07:33:20.826952
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Test Strategy Module Imports')
    test_strategy_module = StrategyModule('tqm')
    assert test_strategy_module._host_pinned is True

# Generated at 2022-06-21 07:33:21.735830
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:33:22.568249
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:33:23.973989
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:34:10.716384
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "tqm"
    my_object = StrategyModule(tqm)
    assert my_object._host_pinned == True
    assert my_object._tqm == tqm

# Generated at 2022-06-21 07:34:13.800356
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    strgy = StrategyModule()
    strgy._host_pinned = True

# Generated at 2022-06-21 07:34:14.924796
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ != None

# Generated at 2022-06-21 07:34:26.647541
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import constants as C

    Display().verbosity = 4
    from ansible.vars.reserved import DEFAULT_VAULT_IDENTITY_LIST as DEFAULT_VAULT_IDENTITIES
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    vault_secrets_file = os.path.expanduser(C.DEFAULT_VAULT_PASSWORD_FILE)
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,', 'other,localhost'])
    variable_manager.set_inventory(inventory)

    # create a new playbook executor

# Generated at 2022-06-21 07:34:30.409143
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_StrategyModule = StrategyModule(tqm=None)
    assert hasattr(test_StrategyModule,'_host_pinned')

# Generated at 2022-06-21 07:34:33.646256
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned as host_pinned
    host_pinned.StrategyModule(1)

# Generated at 2022-06-21 07:34:35.361399
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    StrategyModule(tqm)


# Generated at 2022-06-21 07:34:37.158721
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None

# Generated at 2022-06-21 07:34:37.998142
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:34:40.449623
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-21 07:36:05.474758
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-21 07:36:08.779318
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    T = FreeStrategyModule
    a = T(tqm="t")
    assert (a._host_pinned == True)



# Generated at 2022-06-21 07:36:11.490621
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #Calling actual constructor as unit test
    strategy_obj = StrategyModule(tqm)
    #Pass if _host_pinned is set
    assert (strategy_obj._host_pinned == True)

# Generated at 2022-06-21 07:36:16.295617
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 'class StrategyModule' in dir(StrategyModule)
    assert 'def __init__' in dir(StrategyModule)


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:36:18.014064
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-21 07:36:18.987604
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:36:19.423620
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-21 07:36:23.275033
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestStrategyModule(StrategyModule):
        pass
    assert hasattr(TestStrategyModule,'__init__')
    assert '_host_pinned' in TestStrategyModule.__dict__


# Test for type of StrategyModule._host_pinned

# Generated at 2022-06-21 07:36:30.982443
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ''' test_StrategyModule.py:TestStrategyModule.test_StrategyModule '''
    tqm_mock = Mock()
    tqm_mock.host_pinned = False
    tqm_mock.serial = 20
    strategy = StrategyModule(tqm_mock)
    assert strategy._host_pinned == True
    assert strategy._serial == 20

# Generated at 2022-06-21 07:36:33.932805
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """This is a test method"""

    t = FreeStrategyModule
    sm = StrategyModule(t)

    assert sm._name == 'host_pinned'