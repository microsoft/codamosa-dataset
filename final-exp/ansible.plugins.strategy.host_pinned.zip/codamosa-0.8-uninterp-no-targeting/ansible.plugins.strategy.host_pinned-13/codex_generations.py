

# Generated at 2022-06-21 07:30:00.373193
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-21 07:30:04.941697
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = None
        s = StrategyModule(tqm)
        assert True == True
    except Exception as e:
        print(e)
        assert True == False
        

# Generated at 2022-06-21 07:30:06.412825
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert not StrategyModule(tqm = None)._host_pinned

# Generated at 2022-06-21 07:30:08.849893
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm={})
    assert strategy_module._host_pinned


# Generated at 2022-06-21 07:30:12.179825
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    assert obj is not None and isinstance(obj, StrategyModule)

# Generated at 2022-06-21 07:30:14.160781
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test __init__()
    plugin = StrategyModule(True)
    assert plugin

# Generated at 2022-06-21 07:30:15.644360
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(StrategyModule)

# Generated at 2022-06-21 07:30:19.147604
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned as host_pinned
    assert hasattr(host_pinned, 'StrategyModule')
    assert host_pinned.StrategyModule.__name__ == 'StrategyModule'
    assert host_pinned.StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'

# Test module

# Generated at 2022-06-21 07:30:21.009264
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global display

    StrategyModule(display)

# Generated at 2022-06-21 07:30:23.573276
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert isinstance(strategy_module, StrategyModule)

# Generated at 2022-06-21 07:30:30.755347
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import os
    import unittest
    import sys

    test_result = unittest.TestResult()
    test_suite = unittest.TestSuite()
    test_loader = unittest.TestLoader()

    from ansible.cli.adhoc import AdHocCLI as AdHocCLI
    from ansible.cli import CLI
    from ansible.parsing.dataloader import DataLoader

    p = os.path.dirname(os.path.realpath(__file__))

    sys.path.append(p)

    test1 = unittest.TestLoader().loadTestsFromTestCase(AdHocCLI)
    test_suite.addTests(test1)
    test2 = unittest.TestLoader().loadTestsFromTestCase(CLI)
    test_

# Generated at 2022-06-21 07:30:32.935369
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    assert obj._host_pinned is True

# Generated at 2022-06-21 07:30:36.516916
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module._host_pinned == True


# Generated at 2022-06-21 07:30:37.903958
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule({})
    strategy._host_pinned = True
    assert strategy._host_pinned

# Generated at 2022-06-21 07:30:39.676605
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Generated at 2022-06-21 07:30:51.751863
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    from ansible.utils.display import Display
    assert issubclass(StrategyModule, FreeStrategyModule)
    assert StrategyModule._host_pinned == True

# Generated at 2022-06-21 07:30:55.559448
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    obj = StrategyModule(TaskQueueManager())

# Generated at 2022-06-21 07:30:56.649499
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:30:59.061473
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    tqm = {}
    s = StrategyModule(tqm)

# Generated at 2022-06-21 07:31:01.712134
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm=None)
    assert sm._host_pinned == True



# Generated at 2022-06-21 07:31:05.174593
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    strategyModule = StrategyModule(tqm)
    assert strategyModule.__class__.__name__ == 'StrategyModule'
    assert strategyModule._tqm == 'tqm'
    assert strategyModule._host_pinned == True

# Generated at 2022-06-21 07:31:08.717566
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned is True

# Generated at 2022-06-21 07:31:12.777196
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True



# Generated at 2022-06-21 07:31:16.199602
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    fake_tqm = object()
    module = StrategyModule(fake_tqm)
    assert module._host_pinned

# Generated at 2022-06-21 07:31:18.791309
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategymodule = StrategyModule(tqm=None)
    assert strategymodule._host_pinned is True

# Generated at 2022-06-21 07:31:24.141658
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy import free
    assert issubclass(StrategyModule, free.StrategyModule)
    assert StrategyModule.__doc__ is not None


# Make sure the constructor can be called

# Generated at 2022-06-21 07:31:26.897653
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task_queue_manager = None
    strategy_module = StrategyModule(task_queue_manager)


# Generated at 2022-06-21 07:31:30.443030
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(StrategyModule)
    print(dir(StrategyModule))
    print('check for __init__')
    obj = StrategyModule()
    print(obj)
    print('passed')

test_StrategyModule()


# Generated at 2022-06-21 07:31:41.951614
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    import sys
    import os
    import ansible.constants as C
    module_list = C.DEFAULT_MODULE_PATH.split(os.pathsep)
    try:
        if 'ANSIBLE_LIBRARY' in os.environ:
            module_list.insert(0, os.environ['ANSIBLE_LIBRARY'])
    except AttributeError:
        pass


# Generated at 2022-06-21 07:31:44.326675
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(task_queue_manager=False)
    assert strategy._host_pinned == True


# Generated at 2022-06-21 07:31:48.014738
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    assert StrategyModule(tqm)._host_pinned == True

# Generated at 2022-06-21 07:31:59.627298
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.loader import strategy_loader, clear_all_caches
    from ansible.executor.task_queue_manager import TaskQueueManager

    # to prevent new plugin caches from being created now, and
    # which will create the wrong strategy plugin cache, need
    # to prevent the plugin path cache from being created
    strategy_loader._plugin_path_cache.clear()
    clear_all_caches()
    strategy_loader._find_plugins(strategy_loader._get_paths())
    tqm = TaskQueueManager(None, None, None, None, None, None)
    strategy_plugin = strategy_loader.get('host_pinned', tqm)
    assert strategy_plugin._host_pinned

# Generated at 2022-06-21 07:32:00.816512
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"

# Generated at 2022-06-21 07:32:02.760319
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm="tqm")



# Generated at 2022-06-21 07:32:04.932886
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ""
    StrategyModule(tqm)


# Generated at 2022-06-21 07:32:05.664903
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm='tqm')._host_pinned is True

# Generated at 2022-06-21 07:32:06.521053
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:32:08.543255
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None

# Generated at 2022-06-21 07:32:09.807160
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    x = StrategyModule("tqm")
    assert x._host_pinned == True
# end of unit test

# Generated at 2022-06-21 07:32:11.696950
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)

# Generated at 2022-06-21 07:32:18.211914
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:32:19.704588
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ins = StrategyModule()
    assert isinstance(ins,StrategyModule)

# Generated at 2022-06-21 07:32:26.077908
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)

    assert strategy._host_pinned == True

if __name__ == '__main__':
    from sys import argv
    test_StrategyModule()
    print('No Errors')
    exit(0)

# Generated at 2022-06-21 07:32:32.377247
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_input = {'_hosts': ['host1', 'host2'], '_pattern': 'all', '_play': 'play-test', '_variables': {'var1': 'value1'}}
    test_tqm = StrategyModule(test_input)
    assert test_tqm._tqm == test_input

test_StrategyModule()

# Generated at 2022-06-21 07:32:33.756704
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(1)
    assert strategy_module

# Generated at 2022-06-21 07:32:35.574497
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule(tqm)

    assert tqm._host_pinned == True

# Generated at 2022-06-21 07:32:36.835338
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:32:39.517067
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    assert isinstance(StrategyModule('tqm'),StrategyModule)

# Generated at 2022-06-21 07:32:41.609897
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm) == "test_StrategyModule"

# Generated at 2022-06-21 07:32:45.967556
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ansObj = mock.MagicMock()
    test_FreeStrategyModule = FreeStrategyModule(ansObj)
    assert test_FreeStrategyModule is not None

# Generated at 2022-06-21 07:32:57.522262
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned = StrategyModule()

    assert host_pinned._host_pinned == True



# Generated at 2022-06-21 07:33:04.104332
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.debug("### StrategyModule: test_StrategyModule()")
    tqm = FreeStrategyModule()
    sm = StrategyModule(tqm)
    # Check that StrategyModule is a subclass of FreeStrategyModule
    assert issubclass(StrategyModule, FreeStrategyModule)
    # Check that StrategyModule is a StrategyModule instance
    assert isinstance(sm, StrategyModule)

# Python3.x compatibility for setUpModule
# Unit tests is called from test_utils/runner.py

# Generated at 2022-06-21 07:33:08.383947
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        strategy_module = StrategyModule()
        assert strategy_module is not None
        assert strategy_module._host_pinned == True
    except Exception:
        assert False

# Generated at 2022-06-21 07:33:12.514959
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ''' construction tests '''

    tqm = mock.Mock()
    sm_object = StrategyModule(tqm)
    # _host_pinned should be none.
    assert sm_object._host_pinned is True

# Generated at 2022-06-21 07:33:14.517447
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert_raises(TypeError, StrategyModule)

# Generated at 2022-06-21 07:33:17.820751
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(strategy_instance, StrategyModule)
    assert isinstance(strategy_instance, FreeStrategyModule)


# Generated at 2022-06-21 07:33:18.649896
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule()

# Generated at 2022-06-21 07:33:21.993873
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None #TODO
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:33:25.389455
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("tqm")
    assert strategy_module._host_pinned is True
    assert strategy_module._host_pinned is True

# Generated at 2022-06-21 07:33:26.839731
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)._host_pinned == True

# Generated at 2022-06-21 07:33:56.495295
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global_vars = dict(ansible_ssh_pass = 'pass', ansible_ssh_port = 22, ansible_ssh_user = 'user', ansible_ssh_host = '127.0.0.1')
    global_vars_type = type(global_vars)
    tqm = dict(hostvars = global_vars, hosts_left = None, hosts_left_count = 0, inventory = None, run_state = None, variable_manager = None, variable_manager_type = global_vars_type, loader = None, options = None, stdout_callback = None, stdout_callback_type = None, stats = None)
    tqm_type = type(tqm)
    tqm_object = StrategyModule(tqm_type)
    assert tqm_object._host_

# Generated at 2022-06-21 07:34:07.288961
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_executor import TaskExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.included_file import IncludedFile
    from ansible.module_utils.common.collections import ImmutableDict

# Generated at 2022-06-21 07:34:08.064020
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:34:10.288661
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  obj = StrategyModule()
  return StrategyModule.__init__(obj)



# Generated at 2022-06-21 07:34:12.269509
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm._host_pinned == True

# Generated at 2022-06-21 07:34:14.443222
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule
    assert sm.__name__ == 'StrategyModule'

# Generated at 2022-06-21 07:34:17.194312
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_StrategyModule = StrategyModule(tqm)
    assert test_StrategyModule._host_pinned is True

# Generated at 2022-06-21 07:34:25.365188
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule('tqm')
    assert x._host_pinned == True
    assert x._tqm == 'tqm'
    assert x._inventory == None
    assert x._variables == None
    assert x._loader == None
    assert x._fail_hosts == dict()
    assert x._unreachable_hosts == dict()
    assert x._stats == None
    assert x._pattern_cache == dict()

# Generated at 2022-06-21 07:34:31.095551
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm = None)
    assert(isinstance(strategy, StrategyModule))
    assert( hasattr(strategy, "_host_pinned") )
    assert( getattr(strategy, "_host_pinned") )

# Generated at 2022-06-21 07:34:34.367853
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule({})
    assert strategy_module is not None
    assert strategy_module._host_pinned is True


# Generated at 2022-06-21 07:35:18.692661
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_strategy = StrategyModule("tqm")
    assert(my_strategy)

# Generated at 2022-06-21 07:35:20.164065
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-21 07:35:21.094767
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:35:23.666726
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'



# Generated at 2022-06-21 07:35:24.527881
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule()

# Generated at 2022-06-21 07:35:27.612358
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule(None)
    # assert x._host_pinned is True
    assert x._host_pinned

# Generated at 2022-06-21 07:35:30.250246
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Constructor of StrategyModule
    test = StrategyModule()
    pass

# Generated at 2022-06-21 07:35:33.488459
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule constructor")
    strategy_module = StrategyModule("taskQueueManager")
    assert(strategy_module)


# Generated at 2022-06-21 07:35:37.910531
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    ansible_runner.run(
        #test_StrategyModule test start:
        # TODO: add code to check state of variables
        #test_StrategyModule test end;
        )

# Generated at 2022-06-21 07:35:40.162684
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	tqm = []
	StrategyModule(tqm)

# Generated at 2022-06-21 07:37:03.714973
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert hasattr(StrategyModule,'__init__')
    assert StrategyModule.__doc__ == 'Host Pinned plugin which fails early if a task blocks'


# Generated at 2022-06-21 07:37:14.252936
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    inventory = InventoryManager(loader=DataLoader(), sources=['localhost,'])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    loader = DataLoader()
    variable_manager.extra_vars = {'my_var': 'my_value'}
    variable_manager.options_vars = {'my_var': 'my_value'}

# Generated at 2022-06-21 07:37:16.265307
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-21 07:37:17.906180
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-21 07:37:20.546502
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '_host_pinned')

documentation = StrategyModule.__doc__

# Generated at 2022-06-21 07:37:24.821906
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    strt_mod = None
    #tqm = TaskQueueManager(tqm_dummy)
    try:
        strt_mod = StrategyModule(tqm_dummy)
    except Exception as e:
        print("Exception in constructor of class StrategyModule", e)

    if strt_mod != None:
        print("Successfully constructed StrategyModule instance")
    else:
        print("StrategyModule instance construction failed")

# Unit test of function run() of class StrategyModule

# Generated at 2022-06-21 07:37:29.549022
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    sm = StrategyModule()
    assert sm

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:37:32.568361
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule

    assert StrategyModule.__doc__ is not None
    assert StrategyModule.__init__ is not None
    assert callable(StrategyModule.__init__)



# Generated at 2022-06-21 07:37:35.748599
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "test"
    x = StrategyModule(tqm)
    assert x._host_pinned == True


# Generated at 2022-06-21 07:37:37.252517
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm='tqm')