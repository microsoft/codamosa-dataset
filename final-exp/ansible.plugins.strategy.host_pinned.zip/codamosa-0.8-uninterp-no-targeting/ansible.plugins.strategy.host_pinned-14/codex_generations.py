

# Generated at 2022-06-21 07:30:02.389536
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)

# Generated at 2022-06-21 07:30:06.675357
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"
    assert StrategyModule.__module__ == "ansible.plugins.strategy.host_pinned"
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''

# Generated at 2022-06-21 07:30:07.424483
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:30:10.261356
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-21 07:30:13.783031
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_StrategyModule = StrategyModule(tqm=True)
    assert(test_StrategyModule._host_pinned == True)
# === END ===

# Generated at 2022-06-21 07:30:17.578173
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''


# Generated at 2022-06-21 07:30:21.008836
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule('FreeStrategyModule')
    assert obj._host_pinned == True


# Generated at 2022-06-21 07:30:21.709376
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   assert(StrategyModule)


# Generated at 2022-06-21 07:30:25.432199
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert hasattr(strategy, '_host_pinned')
    assert strategy._host_pinned is True

# Generated at 2022-06-21 07:30:26.943621
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    StrategyModule(tqm)

# Generated at 2022-06-21 07:30:29.198333
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:30:35.170511
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        strategy = StrategyModule(tqm=None)
        strategy._host_pinned = True
    except Exception as e:
        print("Failed StrategyModule: " + str(e))
        exit(1)
    exit(0)


# Generated at 2022-06-21 07:30:38.178339
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print ("Testing constructor of class StrategyModule")
    tqm = None
    tsm = StrategyModule(tqm)
    assert tsm is not None
    print ("Successful execution of constructor of class StrategyModule")


# Generated at 2022-06-21 07:30:39.829669
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-21 07:30:43.158866
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule constructor")
    assert True

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:30:46.699227
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_for_unit_test = StrategyModule("Test")
    assert(strategy_for_unit_test._host_pinned == True)

# Generated at 2022-06-21 07:30:50.772736
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm = None)
    obj._host_pinned
    assert obj._host_pinned == True, "Actual %s != Expected %s" %(obj._host_pinned, True)

# Generated at 2022-06-21 07:30:51.564981
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:30:52.375861
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)


# Generated at 2022-06-21 07:30:52.903727
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:30:57.817249
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'TestQM'
    assert StrategyModule(tqm)._host_pinned == True
    return

# Generated at 2022-06-21 07:31:05.039477
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestDisplay(object):
        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            pass
    class TestTQM(object):
        def __init__(self):
            self.display = TestDisplay()
            self.stats = dict()
            self._final_q = None
            self.hostvars = dict()
            self.inventory = dict()
            self.loader = None
            self.variable_manager = None
            self.run_handlers = True
            self.run_cleanup = True
            self.notified_handlers = dict()
            self.notified_event_handlers = dict()
            self.extra_vars = dict()
            self.options = dict()
            self.options['async'] = 0
            self

# Generated at 2022-06-21 07:31:08.148286
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module._host_pinned is True

# Generated at 2022-06-21 07:31:10.256483
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule
    strategy = strategy(tqm = 'tqm')
    assert strategy._host_pinned is True

# Generated at 2022-06-21 07:31:17.911988
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    class TestTqm(object):
        def __init__(self):
            self.test = True

    test_tqm = TestTqm()
    test_strategy_module = StrategyModule(test_tqm)

    assert test_strategy_module.tqm == test_tqm
    assert test_strategy_module._host_pinned == True

# Generated at 2022-06-21 07:31:21.497578
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sut = StrategyModule(tqm, tqm._inventory, tqm._loader, tqm._variable_manager, tqm._play_context, tqm.passwords, tqm._stdout_callback)
    #assert sut._host_pinned == True

# Generated at 2022-06-21 07:31:24.067264
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm = "Test")
    assert strategy_module is not None

# Generated at 2022-06-21 07:31:28.571258
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mock_tqm = "Mocktqm"
    test_strategy_module = StrategyModule(mock_tqm)
    assert test_strategy_module._host_pinned == True


# Generated at 2022-06-21 07:31:31.313183
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm)
    assert module._host_pinned is True


# Generated at 2022-06-21 07:31:34.485435
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = 'test'
    strategy_module = StrategyModule(test_tqm)
    assert strategy_module._host_pinned

# Generated at 2022-06-21 07:31:39.030069
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:31:39.564225
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:31:51.280360
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.plugins.strategy import StrategyBase
    from ansible.playbook.task import Task
    import ansible.constants as C
    import ansible.utils.plugin_docs as plugin_docs
    import json
    import sys

    class Options:
        verbosity = 1
        nocolor = False
        extra_vars = []
        extra_vars_path = None
        inventory = ["localhost,"]
        forks = 5
        ask_vault_pass = False
        vault_password_files = []


# Generated at 2022-06-21 07:31:54.515727
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm)
    assert isinstance(obj, StrategyModule)
    assert isinstance(obj, FreeStrategyModule)

# Generated at 2022-06-21 07:31:55.340679
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    L = StrategyModule()
    print(L._host_pinned)

# Generated at 2022-06-21 07:31:57.992717
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert(strategy._host_pinned == True)

# Generated at 2022-06-21 07:32:03.947112
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_queue_manager import TaskQueueManager
    from ansible.cli import CLI
    from ansible.plugins.strategy.host_pinned import StrategyModule
    tqm = TaskQueueManager(inventory=None, variable_manager=None, loader=None, options=CLI.base_parser(None, None).parse_args([]), passwords=None, stdout_callback=None)
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned

# Generated at 2022-06-21 07:32:07.962438
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    print (tqm)
    strategy = StrategyModule(tqm)
    print (strategy._host_pinned)

# Generated at 2022-06-21 07:32:10.034766
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule()
    assert mod.name == 'free'
    assert mod.description == 'Executes tasks in hosts in any order'
    assert mod._host_pinned

# Generated at 2022-06-21 07:32:10.816119
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True is not False

# Generated at 2022-06-21 07:32:24.290154
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_strategy_module = StrategyModule("test_tqm")
    assert test_strategy_module.tqm == "test_tqm"
    assert test_strategy_module._host_pinned == True

# Generated at 2022-06-21 07:32:30.241327
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing the constructor of StrategyModule")
    tqm = {}
    strategy_module = StrategyModule(tqm)
    print("Testing successful")
    return strategy_module

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:32:32.787557
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm_obj = None
    assert StrategyModule(tqm_obj)

# Generated at 2022-06-21 07:32:36.248464
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule_class = StrategyModule
    tqm = {}
    strategyModule = strategyModule_class(tqm)
    assert strategyModule
    assert strategyModule._host_pinned

# Generated at 2022-06-21 07:32:37.052122
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:32:37.748823
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:32:39.652806
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:32:40.989326
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__

# Generated at 2022-06-21 07:32:45.254605
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    t = StrategyModule(44)
    assert t._waiting_all_done == False
    assert t._tqm == 44
    assert t._host_pinned == True

# Generated at 2022-06-21 07:32:47.491343
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True
    tqm = 'tqm'
    strategy = StrategyModule(tqm=tqm)
    strategy_host_pinned = strategy._host_pinned
    assert strategy_host_pinned


# Generated at 2022-06-21 07:33:05.612177
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    dut = StrategyModule(tqm)
    assert dut._host_pinned == True

# Generated at 2022-06-21 07:33:07.996809
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = None
  StrategyModule(tqm)

# Generated at 2022-06-21 07:33:12.632935
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # mock tqm
    tqm = Mock()
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None
    assert strategy_module._host_pinned == True

# class Mock:
#     pass
    
# test_StrategyModule()

# Generated at 2022-06-21 07:33:15.318812
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm = 1)
    

# Generated at 2022-06-21 07:33:27.012968
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = dict()
    tqm['hosts'] = 1
    tqm['serial'] = 1
    tqm['forks'] = 1
    tqm['pattern'] = 1
    tqm['inventory'] = 1
    tqm['vars_plugins'] = 1
    tqm['variable_manager'] = 1
    tqm['loader'] = 1
    tqm['passwords'] = 1
    tqm['stdout_callback'] = 1
    tqm['run_additional_callbacks'] = 1
    tqm['run_tree'] = 1
    tqm['shared_loader_obj'] = 1
    tqm['worker_pool'] = 1

    test_obj = StrategyModule(tqm)
    assert test_obj._host_pinned == True

# Generated at 2022-06-21 07:33:29.673640
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy = StrategyModule(tqm)
    assert strategy.tqm == tqm

# Generated at 2022-06-21 07:33:32.693361
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"
    # StrategyModule class instantiation
    sm = StrategyModule(None)
    assert isinstance(sm, object)



# Generated at 2022-06-21 07:33:45.129367
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.cli.adhoc import AdHocCLI
    from ansible.plugins import module_loader
    from ansible.inventory import Inventory
    from ansible.module_utils._text import to_bytes
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    import json
    import os
    import sys

    # Default options
    module_

# Generated at 2022-06-21 07:33:47.960684
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(None)
    assert module._host_pinned

# Generated at 2022-06-21 07:33:49.344919
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()



# Generated at 2022-06-21 07:34:35.248949
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-21 07:34:40.356145
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Testing Constructor of class StrategyModule."""
    current_tqm = None
    x = StrategyModule(current_tqm)
    assert isinstance(x, StrategyModule)



# Generated at 2022-06-21 07:34:41.228537
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule()

# Generated at 2022-06-21 07:34:42.520732
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule(tqm)
    obj = StrategyModule(tqm)
    obj._host_pinned

# Generated at 2022-06-21 07:34:46.520135
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 123
    strategy = StrategyModule(tqm)
    assert(strategy._tqm == tqm)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:34:49.162394
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sc = StrategyModule(None)
    assert sc._host_pinned == True


# Generated at 2022-06-21 07:34:50.026198
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:34:53.976817
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:34:55.345308
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm='tqm')

# Generated at 2022-06-21 07:34:56.129637
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    assert obj._host_pinned is True

# Generated at 2022-06-21 07:36:24.773478
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Instantiate a StrategyModule and test _host_pinned
    strategy = StrategyModule()
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:36:27.025867
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''

# Generated at 2022-06-21 07:36:28.592473
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-21 07:36:35.976966
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # This is a test stub.  Can we use a mock class instead?
    class Tqm(object):
        def __init__(self, hosts=None, inventory=None, variable_manager=None, loader=None, options=None, shared_loader_obj=None, stdout_callback=None):
            self.hosts = hosts
            self.inventory = inventory
            self.variable_manager = variable_manager
            self.loader = loader
            self.options = options
            self.shared_loader_obj = shared_loader_obj
            self.stdout_callback = stdout_callback

    test_strategy_module = StrategyModule(Tqm())
    assert test_strategy_module._host_pinned

# Generated at 2022-06-21 07:36:40.818369
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    strategy_module = ansible.plugins.strategy.host_pinned.StrategyModule(strategy_module)
    assert (strategy_module._host_pinned == True)

# Generated at 2022-06-21 07:36:45.011708
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = [1, 2, 3]
    strategy_module = StrategyModule(tqm)
    assert(strategy_module._host_pinned == True)

# Generated at 2022-06-21 07:36:47.769868
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # check if function can be called without err
    StrategyModule(tqm="tqm")
    assert True

# Generated at 2022-06-21 07:36:50.416905
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_instance = StrategyModule(None)
    assert strategy_instance._host_pinned == True


# Generated at 2022-06-21 07:36:53.674689
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins import strategy_loader

    strategy = strategy_loader.get("host_pinned", None)
    assert strategy is not None

# Generated at 2022-06-21 07:36:57.132646
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True