

# Generated at 2022-06-21 07:30:04.545097
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_mod = StrategyModule(tqm)
    assert strategy_mod._host_pinned == True


# Generated at 2022-06-21 07:30:05.351062
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:30:06.843952
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(display.__class__.__name__ == 'Display')
    assert(StrategyModule.__name__ == 'StrategyModule')

# Generated at 2022-06-21 07:30:13.853033
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Import Test Modules
    from ansible.plugins.strategy.free import Test_StrategyModule as FreeTest_StrategyModule

    # Create Test Object
    strategy = StrategyModule(FreeTest_StrategyModule.tqm)

    # Assertions
    assert strategy is not None
    assert strategy._host_pinned is True


# Generated at 2022-06-21 07:30:15.950735
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    tqm = object()
    StrategyModule(tqm)

# Generated at 2022-06-21 07:30:21.650514
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__bases__ == (FreeStrategyModule,)

    strategy = StrategyModule()
    assert strategy.__class__.__name__ == 'StrategyModule'
    assert strategy._host_pinned is True
    assert strategy._hosts_left is None
    assert strategy._hosts_queue is None
    assert strategy._inventory is None
    assert strategy._iterator is None
    assert strategy._play is None
    assert strategy._max_hosts is None
    assert strategy._queue_result is None
    assert strategy._runners_left is None
    assert strategy._tqm is None
    assert strategy._title is None

# Generated at 2022-06-21 07:30:24.800747
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm=None)
    assert isinstance(module, FreeStrategyModule)
    assert module._host_pinned == True

# Generated at 2022-06-21 07:30:26.907455
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm=2
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None

# Generated at 2022-06-21 07:30:30.171056
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__bases__[0].__name__ == 'FreeStrategyModule'
    assert StrategyModule._host_pinned

# Generated at 2022-06-21 07:30:30.965005
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:30:33.232981
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:30:36.124975
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm._host_pinned

# Generated at 2022-06-21 07:30:37.418537
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned is True

# Generated at 2022-06-21 07:30:44.734543
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #Create a fake ansible tqm.
    class Test:
        def __init__(self):
            self.display = Display()
    tqm = Test()

    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:30:46.239464
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)

# Generated at 2022-06-21 07:30:51.568032
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Test constructor of class StrategyModule"""
    assert StrategyModule.__doc__, 'Missing __doc__'
    # Instantiate the class
    tqm = object()
    strategy_module = StrategyModule(tqm)
    # Test type
    assert type(strategy_module) == StrategyModule, 'Expected type StrategyModule, got %s instead' % type(strategy_module)
    # Test default attributes
    assert strategy_module._host_pinned

# Generated at 2022-06-21 07:30:52.993561
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '__init__')

# Generated at 2022-06-21 07:30:57.120412
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ''' 
    Unit test for constructor of class StrategyModule
    '''
    strategy = StrategyModule(tqm='')
    assert strategy._host_pinned is True

# Generated at 2022-06-21 07:31:00.007768
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_obj = StrategyModule(tqm)
    assert strategy_module_obj._host_pinned == True
    
if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-21 07:31:01.483625
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-21 07:31:07.735225
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    mod = StrategyModule(tqm)
    assert mod.tqm is tqm
    assert mod._host_pinned is True

# Generated at 2022-06-21 07:31:08.920758
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ''
    returnStrategyModule = StrategyModule(tqm)
    returnStrategyModule._host_pinned

# Generated at 2022-06-21 07:31:22.229697
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    fork_setup = Mock(return_value=None)

    tqm = Mock()
    tqm._initial_variables = {}
    tqm._forks = 5
    tqm.send_callback = Mock(return_value=None)
    tqm.run_handlers = Mock(return_value=None)
    tqm.run_queue = Mock(return_value=None)
    tqm.add_worker = Mock(return_value=None)
    tqm.process_pending_results = Mock(return_value=None)
    tqm.host_pinned = False
    tqm.get_hosts_remaining = Mock(return_value=[])

    new_strategy = StrategyModule(tqm)
    assert new_strategy._host_pinned is True


# Generated at 2022-06-21 07:31:24.290969
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    myObj = StrategyModule(None)
    assert myObj._host_pinned == True

# Generated at 2022-06-21 07:31:34.956079
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TqmTest:
        def __init__(self):
            self.tqm = ''
            self.unreachable_hosts = []
            self.stats = ''
            self.default_vars = ''
            self.inventory = ''
            self.fail_on_unreachable_host = ''
            self.use_contrib_script = ''
            self.vars_cache = ''
            self.default_vars_files = ''
            self.roles_path = ''
            self.run_additional_callbacks = ''
            self.stdout_callback = ''
    tqm = TqmTest()
    strategy_module = StrategyModule(tqm)

    assert strategy_module.name == 'host_pinned'
    assert strategy_module._host_pinned

# Generated at 2022-06-21 07:31:38.071471
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    strategy_instance = StrategyModule(tqm)
    assert isinstance(strategy_instance, StrategyModule)

# Generated at 2022-06-21 07:31:39.562073
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(ansible_module)
    assert sm._host_pinned == True

# Generated at 2022-06-21 07:31:41.237877
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule("TestClass")

# Generated at 2022-06-21 07:31:46.089880
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible_mitogen.mitogen_local import Receive
    Receive(1, 2)
    assert StrategyModule(1) != None

# Generated at 2022-06-21 07:31:46.474556
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:31:52.140970
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:31:57.376100
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    play_context = PlayContext()
    play_context.network_os = 'junos'
    play_context.remote_addr = '172.28.173.150'
    play_context.port = 22
    play_

# Generated at 2022-06-21 07:31:59.055013
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Generated at 2022-06-21 07:32:00.763040
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """This is a constructor test function of StrategyModule class"""
    obj = StrategyModule("tqm")
    assert type(obj) == StrategyModule

# Generated at 2022-06-21 07:32:03.946076
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm = 'test')
    assert module != None
    assert module._host_pinned == True


# Generated at 2022-06-21 07:32:06.228411
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert s._host_pinned is True

# Generated at 2022-06-21 07:32:08.973794
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '__init__')
    strategy = StrategyModule()
    assert strategy is not None


# Generated at 2022-06-21 07:32:13.117921
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned as strategy_host_pinned
    strategy_host_pinned.StrategyModule('host_pinned')

# Generated at 2022-06-21 07:32:18.520511
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    (tqm, hosts, all_vars) = StrategyModule.prepare(loader=None, vars_plugins=None, options=None, all_vars=None)
    strategy = StrategyModule(tqm)

# Generated at 2022-06-21 07:32:20.033517
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule("tqm")._host_pinned

# Generated at 2022-06-21 07:32:29.489709
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TestTqm()
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Create a subclass of TestTqm that just holds the constructor argument

# Generated at 2022-06-21 07:32:31.250191
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm)

# Generated at 2022-06-21 07:32:41.170234
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''Test constructor of class StrategyModule'''
    from collections import namedtuple
    from .mock.loader import DictDataLoader
    from .mock.inventory import Inventory
    from .mock.playbook import PlaybookExecutor
    Options = namedtuple('Options',
                         ['listhosts', 'listtasks', 'listtags', 'syntax', 'connection','module_path', 'forks', 'remote_user',
                          'private_key_file', 'ssh_common_args', 'ssh_extra_args', 'sftp_extra_args',
                          'scp_extra_args', 'become', 'become_method', 'become_user', 'verbosity', 'check'])

# Generated at 2022-06-21 07:32:49.427216
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Mocks needed for constructor
    class TestQueueManager():
        var1 = 'var1'

    test_queue_manager = TestQueueManager()

    # Test constructor
    try:
        StrategyModule(test_queue_manager)
    except Exception as e:
        print("Failed to instantiate StrategyModule constructor: %s" % e)
        return False

    return True

# Generated at 2022-06-21 07:32:50.074829
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:32:51.531982
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == True

# Generated at 2022-06-21 07:32:54.601767
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    obj = StrategyModule(tqm)
    assert obj is not None


# Generated at 2022-06-21 07:32:55.221462
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-21 07:32:56.186105
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:32:57.065412
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:33:15.945033
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-21 07:33:18.293624
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        import ansible.plugins.strategy.host_pinned
        strategy = ansible.plugins.strategy.host_pinned.StrategyModule(None)
    except:
        assert False
    assert True


# Generated at 2022-06-21 07:33:21.183484
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule('tqm')
    assert(a._host_pinned == True)

# Generated at 2022-06-21 07:33:25.114484
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule("")
    print("strategy: ",strategy)
    print("strategy class: ",dir(strategy))
    print("strategy._host_pinned: ",strategy._host_pinned)

if __name__ == '__main__':
    print("strategy loading done")

# Generated at 2022-06-21 07:33:26.561843
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule != FreeStrategyModule

# Generated at 2022-06-21 07:33:27.939956
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(None), StrategyModule)

# Generated at 2022-06-21 07:33:31.942469
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ Unit test for constructor of class StrategyModule """
    tqm = {}
    strategy_module = StrategyModule.__init__(tqm)
    assert strategy_module == None

# Generated at 2022-06-21 07:33:32.710798
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:33:33.872098
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-21 07:33:38.167510
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"
    assert StrategyModule.__doc__ == None

# Generated at 2022-06-21 07:34:25.838011
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Constructor of Strategy Module class.
    '''
    display = Display()
    strategy_module = StrategyModule(display)
    assert strategy_module._host_pinned is True

# Generated at 2022-06-21 07:34:28.464890
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm is not None


# Generated at 2022-06-21 07:34:30.681494
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = 'role' 
  StrategyModule(tqm)

# Generated at 2022-06-21 07:34:33.367764
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    argument = ['host_pinned']
    assert StrategyModule(argument)._host_pinned == True


# Generated at 2022-06-21 07:34:36.011765
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule

    strategy_instance = StrategyModule(tqm=None)
    assert strategy_instance._host_pinned == True

# Generated at 2022-06-21 07:34:42.457466
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    strategy_module = ansible.plugins.strategy.host_pinned.StrategyModule(None)
    assert isinstance(strategy_module, ansible.plugins.strategy.host_pinned.StrategyModule)

# Generated at 2022-06-21 07:34:44.068994
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  strategyModule = StrategyModule(None)

# Generated at 2022-06-21 07:34:45.471770
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm = None)

# Generated at 2022-06-21 07:34:56.774257
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestAnsibleTQM():
        def __init__(self):
            self.stats = None
            self.hostvars = None
            self.tqm_variables = None
            self.inventory = None
            self.stdout_callback = None
            self.options = None
            self.loader = None
            self.variable_manager = None
            self.passwords = None
            self.callback = None

    mod = StrategyModule(TestAnsibleTQM())
    assert mod._batch_size == 0

# Generated at 2022-06-21 07:35:00.051048
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True
    assert strategy_module._display == Display()

# Generated at 2022-06-21 07:36:30.835506
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule("tqm")
    assert module._host_pinned == True


# Generated at 2022-06-21 07:36:31.558443
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:36:35.648791
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert (strategy is not None)
    assert (strategy._host_pinned)


# Generated at 2022-06-21 07:36:39.954519
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = [1, 2]
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:36:42.772960
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'

# Generated at 2022-06-21 07:36:46.627939
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Test StrategyModule.__init__()."""
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned

# Generated at 2022-06-21 07:36:48.089886
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(None), StrategyModule)

# Generated at 2022-06-21 07:36:50.190470
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm = None)._host_pinned == True

# Generated at 2022-06-21 07:36:57.132647
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display_1 = Display()
    StrategyModule_instance = StrategyModule(display_1)
    assert bool(StrategyModule_instance) == True

# Ansible plugins call function in module to create instance of class StrategyModule.
# Following fragment is for testing module.
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:36:58.011417
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass