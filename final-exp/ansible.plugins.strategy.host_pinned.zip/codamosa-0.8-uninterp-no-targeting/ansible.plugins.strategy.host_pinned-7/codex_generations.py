

# Generated at 2022-06-21 07:30:05.774865
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm=None)
    assert len(s._host_pinned) > 0

# Generated at 2022-06-21 07:30:08.136248
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    display = Display()
    strategy_module = StrategyModule(display)
    assert strategy_module._host_pinned is True, 'The variable host_pinned should be true'

# Generated at 2022-06-21 07:30:11.044348
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm = None)
    assert strategy_module._host_pinned

# Generated at 2022-06-21 07:30:12.669755
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)

# Generated at 2022-06-21 07:30:15.359004
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm)
    assert module._host_pinned


# Generated at 2022-06-21 07:30:17.212390
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a= StrategyModule("A")
    assert a != None, "Failed to create object"


# Generated at 2022-06-21 07:30:20.045934
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:30:20.793452
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-21 07:30:22.222857
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:30:24.240307
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm='tqm')._host_pinned == True

# Generated at 2022-06-21 07:30:26.209676
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:30:27.054437
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(Display()) is not None

# Generated at 2022-06-21 07:30:27.918100
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:30:28.886389
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:30:31.466983
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    st = StrategyModule(None)
    assert(st is not None)
    assert (st._host_pinned is True)

# Generated at 2022-06-21 07:30:36.361865
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager()
    strategy = StrategyModule(tqm)
    assert hasattr(strategy, 'run')

# Generated at 2022-06-21 07:30:37.235930
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert strategy_module.__init__() == None

# Generated at 2022-06-21 07:30:40.290232
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    obj = StrategyModule(tqm)
    assert obj._host_pinned

# Generated at 2022-06-21 07:30:42.428082
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("strategy/host_pinned: Testing StrategyModule class constructor")
    FreeStrategyModule(tqm)
    print("strategy/host_pinned: Successfully tested StrategyModule class constructor")



# Generated at 2022-06-21 07:30:44.580693
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    assert StrategyModule(tqm)

# Generated at 2022-06-21 07:30:47.040879
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-21 07:30:48.661497
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result = StrategyModule(tqm=None)
    assert result._host_pinned == True


# Generated at 2022-06-21 07:30:49.651259
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:30:53.953327
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    fake_tqm = 'fake_tqm'
    strategy = StrategyModule(fake_tqm)
    assert strategy._tqm == fake_tqm
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:31:00.135095
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(inventory=None, variable_manager=None, loader=None, options=None, passwords=None, run_tree=False, stdout_callback=None)
    strategy_obj = StrategyModule(tqm=tqm)
    assert strategy_obj._host_pinned == True

# Generated at 2022-06-21 07:31:06.189448
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    free_strategy_module_obj = FreeStrategyModule(None)
    assert free_strategy_module_obj._host_pinned == False

    strategy_module_obj = StrategyModule(None)
    assert strategy_module_obj._host_pinned == True

# Generated at 2022-06-21 07:31:07.669184
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:31:08.450250
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule(None)
    assert(strategyModule)

# Generated at 2022-06-21 07:31:10.520217
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__

# Generated at 2022-06-21 07:31:13.217853
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned is True

# Generated at 2022-06-21 07:31:17.025270
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:31:18.629198
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned is True

# Generated at 2022-06-21 07:31:19.198628
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:31:20.159247
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:31:23.832320
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ constructor test """
    host_pinned = True
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == host_pinned

# Generated at 2022-06-21 07:31:26.360395
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.display("Calling constructor of StrategyModule")

# instantiate strategy module first
strategy_module = StrategyModule()

display.display("Calling test_StrategyModule")
test_StrategyModule()

# Generated at 2022-06-21 07:31:29.516460
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    import mock
    sm = StrategyModule(mock.MagicMock())
    assert sm.tqm is not None

# Generated at 2022-06-21 07:31:31.977946
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:31:40.271762
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a mock_tqm
    from ansible.executor.task_queue_manager import TaskQueueManager

    mock_tqm = TaskQueueManager(None)


    returned_strategy_module = StrategyModule(mock_tqm)

    import ansible.plugins.strategy.host_pinned
    assert returned_strategy_module is not None
    assert returned_strategy_module.__class__.__name__ == ansible.plugins.strategy.host_pinned.StrategyModule.__name__

# Generated at 2022-06-21 07:31:42.568984
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-21 07:31:57.033577
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestStrategyModule(StrategyModule):
        def __init__(self):
            super(TestStrategyModule, self).__init__(tqm)

    test_strategy_module = TestStrategyModule()
    assert(test_strategy_module._host_pinned)

# Generated at 2022-06-21 07:32:00.763289
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Instantiate the StrategyModule class
    strategy_module = StrategyModule(None)

    # Assert class attributes of StrategyModule class
    assert strategy_module.name == 'host_pinned'
    assert strategy_module._host_pinned

# Generated at 2022-06-21 07:32:02.690396
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned

# Generated at 2022-06-21 07:32:04.235947
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert not StrategyModule

# Generated at 2022-06-21 07:32:07.029928
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("test")
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:32:08.543237
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:32:10.776857
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    test1 = StrategyModule

    assert test1.__name__ == "StrategyModule", "StrategyModule class not found"
    assert test1.__doc__ == "Executes tasks on each host without interruption", "StrategyModule __doc__ is not as expected"



# Generated at 2022-06-21 07:32:15.256862
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module._host_pinned == True
    assert callable(strategy_module.run)

# Generated at 2022-06-21 07:32:16.481220
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Constructor of class StrategyModule
    assert StrategyModule
    pass

# Generated at 2022-06-21 07:32:17.283977
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-21 07:32:37.049099
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('######Test_StrategyModule######')
    obj = StrategyModule() # Constructor of class StrategyModule
    print(obj.__doc__)
    print(obj.__init__.__doc__)
    print('######End of Test_StrategyModule######')


# Generated at 2022-06-21 07:32:38.927154
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule.__init__, object)

# Generated at 2022-06-21 07:32:40.573401
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()

# Generated at 2022-06-21 07:32:42.097145
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule()


# Generated at 2022-06-21 07:32:45.809894
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert (StrategyModule.__name__ == 'StrategyModule')
    assert (StrategyModule.__doc__ == 'Default ansible task execution strategy plugin.')

# Generated at 2022-06-21 07:32:47.326679
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test = StrategyModule
    assert test


# Generated at 2022-06-21 07:32:47.747456
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-21 07:32:49.960677
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-21 07:32:52.089933
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '_host_pinned')

# Generated at 2022-06-21 07:33:00.225548
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestStrategyModule(StrategyModule):
        def __init__(self, tqm):
            super(StrategyModule, self).__init__(tqm)
            self.some_other_variable = True

    assert TestStrategyModule.__init__.__doc__ == FreeStrategyModule.__init__.__doc__

# Generated at 2022-06-21 07:33:32.517333
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'the_tqm'

    sm = StrategyModule(tqm)

    assert isinstance(sm, StrategyModule)

# Generated at 2022-06-21 07:33:35.788803
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned = StrategyModule(tqm='fake')
    assert host_pinned._host_pinned == True

# Generated at 2022-06-21 07:33:38.962214
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#Unit test for method execute_tasks() without 'host_pinned' set

# Generated at 2022-06-21 07:33:39.809229
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-21 07:33:44.121284
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host1 = Host('myhost')
    host2 = Host('myhost2')
    module1 = StrategyModule(host1, 'myhost')
    module2 = StrategyModule(host2, 'myhost2')
    assert module1.tqm == host1
    assert module2.tqm == host2

# Generated at 2022-06-21 07:33:46.793847
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert s._host_pinned

# Generated at 2022-06-21 07:33:54.057427
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import pytest
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager

    """Unit test for the constructor of class StrategyModule."""

    test_strategy_module = StrategyModule(TaskQueueManager(None))
    assert isinstance(test_strategy_module, StrategyModule)

# Generated at 2022-06-21 07:34:01.933227
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    test StrategyModule constructor
    """
    #import mock
    #with mock.patch('ansible.plugins.strategy.free.FreeStrategyModule.__init__') as mock_init:
    #    with StrategyModule(tqm) as strategy:
    #        pass
    #mock_init.assert_called_once_with(tqm)
    pass

# Generated at 2022-06-21 07:34:08.744922
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')  # pylint: disable=C0103
    host = inventory.get_host('localhost')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 07:34:10.288646
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule()


# Generated at 2022-06-21 07:35:30.940170
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:35:31.824002
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:35:33.804913
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert type(StrategyModule).__name__ == "StrategyModule"

# Generated at 2022-06-21 07:35:39.460384
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test for constructor of class StrategyModule
    '''
    from ansible.plugins.strategy.host_pinned import StrategyModule
    class TQM:
        def __init__(self):
            self.hostvars = {'localhost': {}}

    tqm = TQM()
    strategy = StrategyModule(tqm)
    print(strategy)

# Generated at 2022-06-21 07:35:42.804433
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = list()
    tqm = StrategyModule(tqm)
    assert(isinstance(tqm, StrategyModule))

# Generated at 2022-06-21 07:35:46.361536
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test'
    strateg = StrategyModule(tqm)
    assert strateg._host_pinned


# Generated at 2022-06-21 07:35:48.067531
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-21 07:35:49.418096
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)

# Generated at 2022-06-21 07:35:50.768570
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("TODO")


# Generated at 2022-06-21 07:35:53.693735
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sb = StrategyModule("test")
    assert sb._host_pinned == True

# Generated at 2022-06-21 07:38:54.395823
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert True == strategy._host_pinned

# Generated at 2022-06-21 07:38:58.301783
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.verbosity = 3
    tqm = 'some data'
    obj = StrategyModule(tqm)
    assert obj._host_pinned == True

# Generated at 2022-06-21 07:39:04.209129
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    fake_tqm = object()
    strategy = StrategyModule(fake_tqm)
    assert strategy != None, '__init__ of StrategyModule class has failed'

# Generated at 2022-06-21 07:39:05.501767
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-21 07:39:17.309177
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert len(StrategyModule.__bases__) == 1
    assert StrategyModule.__bases__[0].__name__ == 'FreeStrategyModule'

# Generated at 2022-06-21 07:39:21.947923
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create module as class StrategyModule gets instantiated with 2 arguments.
    mod = StrategyModule(1)
    # Check if _host_pinned is set to True
    assert mod._host_pinned is True

# Generated at 2022-06-21 07:39:25.822080
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    fsm = StrategyModule.__new__(StrategyModule)
    assert fsm._host_pinned == True

# Generated at 2022-06-21 07:39:28.796168
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(1)
    assert s._host_pinned

# override for host_pinned

# Generated at 2022-06-21 07:39:30.167026
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = StrategyModule(tqm)

# Generated at 2022-06-21 07:39:39.796768
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.utils.lock_file
    from ansible.plugins.strategy import StrategyModule
    from ansible.utils.sentinel import Sentinel
    from ansible.utils.plugins import d_import_class
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    import os
    import sys
