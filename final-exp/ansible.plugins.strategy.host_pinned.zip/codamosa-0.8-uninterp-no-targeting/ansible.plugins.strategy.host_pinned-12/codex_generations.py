

# Generated at 2022-06-21 07:30:04.248742
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # FIXME: Implement unit test for the constructor of StrategyModule class
    raise NotImplementedError()

# Generated at 2022-06-21 07:30:05.577047
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    help(StrategyModule)

# Generated at 2022-06-21 07:30:10.594711
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TaskQueueManager:
        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            pass
    
    class PlayContext:
        def __init__(self):
            self.max_fail_percentage = 100
            self.serial = 0
            self.verbosity = 0
    
    class Host:
        def __init__(self, name):
            self.name = name
    
    class Task:
        def __init__(self, host=None):
            self.host = host
    
    task_queue_manager = TaskQueueManager()
    
    a_strategy_module = StrategyModule(task_queue_manager)
    assert a_strategy_module
    assert a_strategy_module.tqm == task_queue_manager


# Generated at 2022-06-21 07:30:11.621687
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:30:13.783247
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_strategy_module = StrategyModule
    assert(True)



# Generated at 2022-06-21 07:30:16.723371
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from __main__ import tqm
    strategy = StrategyModule(tqm)

    assert(strategy._host_pinned == True)

# Generated at 2022-06-21 07:30:17.982265
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(_tqm=None)

# Generated at 2022-06-21 07:30:20.198467
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-21 07:30:22.262987
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule('tqm')
    assert strategy._host_pinned

# Generated at 2022-06-21 07:30:23.714826
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule("tqm") is not None

# Generated at 2022-06-21 07:30:27.515853
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True


# Generated at 2022-06-21 07:30:28.962231
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('tqm')

# Generated at 2022-06-21 07:30:29.815191
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-21 07:30:33.942138
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    e_tqm = {}
    fsm = FreeStrategyModule(e_tqm)
    assert fsm._host_pinned == False



# Generated at 2022-06-21 07:30:36.213142
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("****test_StrategyModule****")


# Generated at 2022-06-21 07:30:39.982394
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = _TestTQM()
    strategyModule = StrategyModule(tqm)


# Unit test of method _get_next_task_lockstep

# Generated at 2022-06-21 07:30:42.075168
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(True)
    assert module._host_pinned == True

# Generated at 2022-06-21 07:30:46.852743
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.strategy import StrategyBase
    strate_obj = StrategyModule()
    assert isinstance(strate_obj,StrategyBase)



# Generated at 2022-06-21 07:30:48.582574
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:30:49.468171
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:30:55.559815
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   class TestStrategyModule(StrategyModule):
       def __init__(self, tqm):
           super(StrategyModule, self).__init__(tqm)
           self._host_pinned = True
   test = TestStrategyModule(None)
   test._host_pinned = "ChangedTest"
   assert test._host_pinned == "ChangedTest"

# Generated at 2022-06-21 07:31:04.307617
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.callback import CallbackBase

    class TestDisplay(object):
        def colorize(self, msg, color=None, msg_type=None):
            return msg

        def display(self, msg, color=None, stderr=False, screen_only=False, logger=None):
            return msg

    class TestTQM(object):
        def __init__(self):
            self.display = TestDisplay()
            self.stats = Mock()
            self.stdout_callback = CallbackBase()

    class Mock(object):
        def __init__(self):
            self.dark = {}
            self.processed = {}

    tqm = TestTQM()
    strategy_module = StrategyModule(tqm)

# Generated at 2022-06-21 07:31:06.109559
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(StrategyModule(None))

# Generated at 2022-06-21 07:31:07.059714
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:31:08.958628
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-21 07:31:11.191264
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-21 07:31:12.790411
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-21 07:31:17.396191
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test that StrategyModule is subclass of FreeStrategyModule
    assert issubclass(StrategyModule, FreeStrategyModule)
    # Test that StrategyModule is a class
    assert isinstance(StrategyModule, type)

# Generated at 2022-06-21 07:31:19.922320
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# vim: set et fenc=utf-8 fileencoding=utf-8 sw=4 ts=4 sts=4

# Generated at 2022-06-21 07:31:25.401710
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == FreeStrategyModule.__doc__

# Generated at 2022-06-21 07:31:33.309610
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.__dict__['_host_pinned']

# Generated at 2022-06-21 07:31:34.120008
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:31:36.060126
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule('test_hosts')
    assert strategy._host_pinned is True

# Generated at 2022-06-21 07:31:39.357664
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned == True

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-21 07:31:41.893616
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-21 07:31:45.411682
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('tqm')
    assert strategy_module._host_pinned == True
    assert strategy_module._tqm == 'tqm'

# Generated at 2022-06-21 07:31:47.940708
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy
    import ansible.plugins.strategy.host_pinned
    del ansible.plugins.strategy.strategy_loader.strategy_plugins['host_pinned']
    del ansible.plugins.strategy.host_pinned
    import imp
    imp.reload(ansible.plugins.strategy)

# Generated at 2022-06-21 07:31:49.715745
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    state = StrategyModule(tqm)
    assert state._host_pinned == True

# Generated at 2022-06-21 07:31:50.520309
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:32:02.451673
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM():
        _localhost = None
        def __init__(self):
            class TestHost():
                name= "testhost"
                port = 22
            self._localhost = TestHost()
            self.inventory = None
            self.cur_pattern = "all"
            self.stats = None
            self.variable_manager = None
            self.loader = None
            self.shared_loader_obj = None
            self.exit_code = 0
            self.failed_hosts = dict()
            self.processed_hosts = dict()
            self._final_q = None
            self._initial_q = None
            self._last_task_banner = None
            self._last_play = None
            self._last_task = None
            self._failed_hosts = dict()
            self._unreach

# Generated at 2022-06-21 07:32:12.895720
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)._host_pinned

# Generated at 2022-06-21 07:32:15.180341
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(True)
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:32:21.009000
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest

    class TestStrategyModule(unittest.TestCase):

        def test_init(self):
            obj = StrategyModule(tqm='a')
            obj2 = StrategyModule(tqm='a')
            self.assertEqual(obj._host_pinned, True)
            self.assertEqual(obj2._host_pinned, True)

    unittest.main()

# Generated at 2022-06-21 07:32:23.820697
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('tqm')
    assert strategy_module._host_pinned is True

# Generated at 2022-06-21 07:32:25.573836
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None


# Generated at 2022-06-21 07:32:30.785232
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager('/tmp', {})
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned is True
    assert strategy.get_name() == 'host_pinned'

# Generated at 2022-06-21 07:32:33.055012
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)._host_pinned == True

# Generated at 2022-06-21 07:32:36.649152
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(None, None, None)
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-21 07:32:37.784371
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ans = StrategyModule()


# Generated at 2022-06-21 07:32:38.830815
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:32:56.348016
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-21 07:32:57.826782
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print ("Testing StrategyModule")
    pass

# Generated at 2022-06-21 07:32:58.677039
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:33:02.474341
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ test_StrategyModule is used as constructor test as it is not possible to test __init__ directly
    """
    tqm = object()
    obj = StrategyModule(tqm)
    assert obj._tqm == tqm

# Generated at 2022-06-21 07:33:06.587548
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    foo = StrategyModule
    assert foo.__name__ == 'StrategyModule'
    assert callable(foo)

# Test for the constructor for StrategyModule. Test the constructor for correctness.

# Generated at 2022-06-21 07:33:08.073995
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-21 07:33:15.820496
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager

    tc = Task()
    pc = PlayContext()

    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None,
        run_additional_callbacks=False,
        run_tree=False,
    )

    sm = StrategyModule(tqm)
    assert sm._host_pinned is True

# Generated at 2022-06-21 07:33:17.295582
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__

# Generated at 2022-06-21 07:33:18.725508
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(), StrategyModule)

# Generated at 2022-06-21 07:33:20.952828
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-21 07:34:08.403021
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.module_utils.facts import Facts
    import os

    # Initialise a task queue manager to keep track of tasks
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["localhost,"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 07:34:10.079022
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Generated at 2022-06-21 07:34:12.609720
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None

# Generated at 2022-06-21 07:34:14.916659
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = dict()
    assert(StrategyModule(tqm)._host_pinned)

# Generated at 2022-06-21 07:34:17.063155
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyinstance = StrategyModule("test")
    assert strategyinstance._host_pinned == True

# Generated at 2022-06-21 07:34:21.376241
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(hasattr(StrategyModule, '__init__'))
    strategy_module = StrategyModule()
    assert(hasattr(strategy_module, '_host_pinned'))

# Generated at 2022-06-21 07:34:24.894537
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a object of class StrategyModule
    strategy_module = StrategyModule(None)
    # Test if attribute _host_pinned is True
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:34:28.838147
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create strategy module
    strategy_module = StrategyModule('test')
    # test variable
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:34:33.923926
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    tqm = ansible.plugins.strategy.host_pinned.StrategyModule
    test = tqm.__init__('StrategyModule')
    assert test is not None

# Generated at 2022-06-21 07:34:35.505396
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''StrategyModule class constructor'''
    display.display("Test 1")
    return

# Generated at 2022-06-21 07:36:01.951129
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:36:04.699940
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    testmod = FreeStrategyModule(tqm)
    assert testmod != None

# Generated at 2022-06-21 07:36:08.168815
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm = None)
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:36:10.920027
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = True
    sm = StrategyModule(tqm)
    assert sm._host_pinned is True
    assert isinstance(sm, StrategyModule)

# Generated at 2022-06-21 07:36:22.958545
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM(object):
        _initializing_ = True
        _finalizing_ = False
        _workers_count = 1
        _halt_on_any_unreachable_hosts = False
        _number_of_pending_results = 0
        _result_prune_list = []
        _terminated = False
        _callback_plugins = []
        _tqm_variables = {}
        _unreachable_hosts = []
        _log_only = False
        _module_name = None
        _module_args = None
        _module_vars = {}
        _new_stdin = None
        _diff = False
        _result_q = None
        _callback_q = None
        _play_context = None
        _loader = None
        _variable_manager = None


# Generated at 2022-06-21 07:36:34.670587
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import Playbook
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display
    loader = DataLoader()
    display = Display()
    inv_manager = InventoryManager(loader, None, [], [])
    variable_manager = VariableManager(loader, inv_manager)
    playbook = Playbook.load(loader, "test_playbook", variable_manager=variable_manager)

# Generated at 2022-06-21 07:36:37.627047
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    assert obj._host_pinned is True

# Generated at 2022-06-21 07:36:39.026318
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__

# Generated at 2022-06-21 07:36:41.081000
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm.get_host_pinned() == True


# Generated at 2022-06-21 07:36:45.529565
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned

if __name__ == '__main__':
    # Unit test code.
    test_StrategyModule()