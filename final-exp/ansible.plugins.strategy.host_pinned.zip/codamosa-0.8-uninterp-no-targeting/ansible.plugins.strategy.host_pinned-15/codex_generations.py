

# Generated at 2022-06-21 07:30:02.668297
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:30:05.917051
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    s = StrategyModule(None)
    assert s._host_pinned == True

# Generated at 2022-06-21 07:30:08.085237
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #Test Case 1: Successful creation of strategy object
    tqm = 'Test_object'
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True
    
#Unit test for method get_host_list

# Generated at 2022-06-21 07:30:10.967738
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule), "StrategyModule is a subclass of FreeStrategyModule"

# Generated at 2022-06-21 07:30:13.783573
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    target = StrategyModule(tqm)
    assert (target is not None)



# Generated at 2022-06-21 07:30:18.285242
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.display import Display
    display = Display()
    # Fails on import
    try:
        from ansible.plugins.strategy.host_pinned import StrategyModule
    except ImportError as e:
        display.display('test_StrategyModule skipped: %s' % e)
        return
    display.display('pass')

# Generated at 2022-06-21 07:30:21.083422
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO:
    pass



__all__ = ['StrategyModule']

# Generated at 2022-06-21 07:30:23.648252
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None
# Test creation of StrategyModule and ensure that it is a subclass of FreeStrategyModule

# Generated at 2022-06-21 07:30:25.642700
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm._host_pinned == True

# Generated at 2022-06-21 07:30:26.458911
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:30:28.738198
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-21 07:30:31.322396
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True  # pylint: disable = protected-access

# Generated at 2022-06-21 07:30:32.357093
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:30:34.014740
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-21 07:30:35.538315
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule('tqm')

# Generated at 2022-06-21 07:30:36.668676
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return None

# Generated at 2022-06-21 07:30:37.162139
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:30:50.655437
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    import ansible.constants as C
    import os
    import tempfile
    import sys

    try:
        import json
    except ImportError:
        import simplejson as json

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unitt

# Generated at 2022-06-21 07:30:52.051796
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm = None)
    assert(strategy_module._host_pinned == True)

# Generated at 2022-06-21 07:30:53.721052
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None) is not None

# Generated at 2022-06-21 07:30:58.183926
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:31:01.785335
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned


# Generated at 2022-06-21 07:31:02.733470
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:31:03.415706
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule()



# Generated at 2022-06-21 07:31:07.058026
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:31:07.861194
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)


# Generated at 2022-06-21 07:31:12.071872
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.loader as plugins_loader
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible import context
    import ansible
    context.CLIARGS = {}
    inv = InventoryManager(ansible.utils.plugins.combiner(plugins_loader.find_plugin_paths()))
    inv.parse_inventory("test/test_strategy_plugins/inv")
    tqm = TaskQueueManager(
        inventory=inv,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
    )
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned

# Generated at 2022-06-21 07:31:14.962212
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    strategy_module=StrategyModule()
    assert strategy_module != None

# Generated at 2022-06-21 07:31:15.960744
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = StrategyModule()
    assert tqm._host_pinned == True

# Generated at 2022-06-21 07:31:23.832001
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.module_utils._text import to_text
    from ansible.plugins.strategy.host_pinned import StrategyModule
    host_list=['worker-k8s-0-3']
    task_queue_manager = MockTaskQueueManager(host_list)
    strategy_module_obj = StrategyModule(task_queue_manager)
    print(strategy_module_obj._host_pinned)

if __name__ == '__main__':
    test_StrategyModule()



# Generated at 2022-06-21 07:31:32.453287
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule(tqm='tqm')
    assert strategyModule._host_pinned == True

# Done testing StrategyModule

# Function to test StrategyModule.run
#def test_run():
    #strategyModule = StrategyModule(tqm='tqm')
    #assert strategyModule.run() == 0

# Done testing StrategyModule.run

# Generated at 2022-06-21 07:31:42.712017
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from Queue import Queue as queue
    from ansible.executor.task_queue_manager import TaskQueueManager

    tqm = TaskQueueManager(
            inventory=None,
            variable_manager=None,
            loader=None,
            options=None,
            passwords=None,
            stdout_callback=None,
            run_additional_callbacks=None,
            run_tree=False
    )
    strategy = StrategyModule(tqm)

    assert strategy._host_pinned == True
    assert isinstance(strategy._tqm, TaskQueueManager)
    assert isinstance(strategy._tqm._play_context, dict)
    assert isinstance(strategy._tqm._workers, queue)
    assert isinstance(strategy._tqm._workers_lock, threading.Lock)
   

# Generated at 2022-06-21 07:31:52.018655
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.inventory.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    # create variable_manager with empty inventory
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    # create

# Generated at 2022-06-21 07:31:54.068006
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert s._host_pinned == True

# Generated at 2022-06-21 07:31:56.214343
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_object = StrategyModule()
    assert strategy_object._host_pinned == True

# Generated at 2022-06-21 07:31:57.035839
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:31:57.856864
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:31:59.746684
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm = None)._host_pinned == True

# Generated at 2022-06-21 07:32:01.430731
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    myStrategyModule = StrategyModule(display)
    assert myStrategyModule is not None

# Generated at 2022-06-21 07:32:05.516040
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    st_strategy_module = StrategyModule(tqm)
    assert st_strategy_module

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:32:16.176401
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    tqm = 'tqm'
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:32:17.470789
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-21 07:32:19.864047
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned, "StrategyModule not creating instance with _host_pinned assigned to True"

# Generated at 2022-06-21 07:32:24.966811
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    tqm = DummyAnsibleTQM(display)
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True


# Generated at 2022-06-21 07:32:27.921110
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_obj = StrategyModule()
    assert my_obj
    assert my_obj._host_pinned == True

# Generated at 2022-06-21 07:32:38.731453
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins import strategy_loader
    from ansible.errors import AnsibleError
    from ansible.playbook import Play
    from ansible.playbook.play import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import load_extra_vars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

# Generated at 2022-06-21 07:32:39.329721
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule()

# Generated at 2022-06-21 07:32:41.480421
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule()
    assert a._host_pinned

# Generated at 2022-06-21 07:32:45.820141
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock
    tqm = mock.MagicMock()
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:32:50.686080
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Function to test the constructor of class StrategyModule
    '''
    strategy_module = StrategyModule(None)
    assert isinstance(strategy_module, StrategyModule)
    assert isinstance(strategy_module, FreeStrategyModule)

# Generated at 2022-06-21 07:33:07.998697
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = StrategyModule("host")
    assert host._host_pinned == True

# Generated at 2022-06-21 07:33:11.305015
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    st_module = StrategyModule(tqm)
    assert(st_module._host_pinned)

# Generated at 2022-06-21 07:33:13.669591
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm='')
    assert strategy._host_pinned

# Generated at 2022-06-21 07:33:17.969513
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  strategy_module = StrategyModule(tqm)
  assert strategy_module._host_pinned
  assert strategy_module._play_has_tasks
  assert strategy_module._batch

# Generated at 2022-06-21 07:33:18.896164
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-21 07:33:28.396742
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Create a fake TaskQueueManager
    tqm = TaskQueueManager(None, None, None, None, None, None, None)

    # Create an instance of StrategyModule
    strategy_module = StrategyModule(tqm)

    # Check if the constructor of class StrategyModule sets the value of _host_pinned to True
    assert strategy_module._host_pinned == True, "The StrategyModule constructor sets the value of _host_pinned to True"

    # Check if the constructor of class StrategyModule sets the value of _display to an instance of Display()
    assert isinstance(strategy_module._display, Display), "The StrategyModule constructor sets the value of _display to an instance of Display()"


# Generated at 2022-06-21 07:33:30.035899
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # for now we just assume the init does nothing...
    t = StrategyModule(None)
    assert t._host_pinned



# Generated at 2022-06-21 07:33:36.472511
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-21 07:33:38.432529
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy=StrategyModule("tqm")
    assert strategy._host_pinned

# Generated at 2022-06-21 07:33:39.876895
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-21 07:34:25.585838
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    StrategyModule(None)


# Generated at 2022-06-21 07:34:26.709725
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-21 07:34:29.135685
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert str(StrategyModule.__init__).__contains__('__init__')

# Generated at 2022-06-21 07:34:31.717875
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    s = StrategyModule(tqm)
    assert s._host_pinned == True

# Generated at 2022-06-21 07:34:33.852922
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    FreeStrategyModule("tqm")._host_pinned == True

# Generated at 2022-06-21 07:34:34.718910
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:34:36.115242
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = DummyTQM()
    sm = StrategyModule(tqm)
    assert sm is not None

# Generated at 2022-06-21 07:34:38.279378
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None) is not None


# Generated at 2022-06-21 07:34:39.139789
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:34:40.274356
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:36:13.383072
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import time
    import multiprocessing
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.blocks import TaskBlock
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.stats import AggregateStats
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.connection import ConnectionBase



# Generated at 2022-06-21 07:36:14.248936
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True
    pass

# Generated at 2022-06-21 07:36:19.425877
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    strategy = ansible.plugins.strategy.host_pinned.StrategyModule(tqm=None)
    assert strategy._host_pinned

# Generated at 2022-06-21 07:36:21.064640
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:36:26.398115
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global tqm
    tqm = None
    test_obj = StrategyModule(tqm)
    assert test_obj._host_pinned is True
    assert isinstance(test_obj._tqm, object)

# Generated at 2022-06-21 07:36:32.123518
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)
    tqm = DummyTQM()
    strategy = StrategyModule(tqm)
    assert strategy
    assert strategy.__init__.__code__.co_varnames == ('self', 'tqm')
    assert strategy._host_pinned == True


# Generated at 2022-06-21 07:36:39.321185
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy import _get_strategy_loader
    strategy_loader = _get_strategy_loader()
    strategy_instance = strategy_loader.get('host_pinned', None)
    assert isinstance(strategy_instance, StrategyModule)

# Generated at 2022-06-21 07:36:40.590426
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-21 07:36:41.361042
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert False

# Generated at 2022-06-21 07:36:42.250463
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:40:05.110706
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test that the class can be instantiated
    StrategyModule("")


EVENT_HOST_STARTED = 'playbook_on_play_start'
EVENT_HOST_FAILED = 'playbook_on_no_hosts_remaining'
