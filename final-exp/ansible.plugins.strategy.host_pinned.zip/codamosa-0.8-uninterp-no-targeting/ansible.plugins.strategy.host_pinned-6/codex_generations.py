

# Generated at 2022-06-21 07:30:06.991580
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.strategy.host_pinned import StrategyModule as HostPinnedStrategyModule
    assert issubclass(HostPinnedStrategyModule, StrategyModule)

# Generated at 2022-06-21 07:30:12.388653
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule

    strategy = StrategyModule(None)

    assert strategy is not None
    assert strategy._host_pinned

# End Unit test section

# Unit test section


# Generated at 2022-06-21 07:30:17.482633
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    s = StrategyModule(tqm)
    assert isinstance(s, StrategyModule)
    assert isinstance(s, FreeStrategyModule)
    assert s._queue_name == 'AnsiballZ_setup'
    assert s._host_pinned
    assert s._display is display

# Generated at 2022-06-21 07:30:20.934909
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:30:22.335047
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Generated at 2022-06-21 07:30:23.787024
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-21 07:30:24.879982
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = "test_tqm"
    StrategyModule(test_tqm)

# Generated at 2022-06-21 07:30:26.943359
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    obj = StrategyModule(tqm)
    assert obj._host_pinned == True

# Generated at 2022-06-21 07:30:28.300875
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=True)

# Generated at 2022-06-21 07:30:29.813003
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-21 07:30:31.820060
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:30:32.643130
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:30:37.925437
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #mock of FreeStrategyModule
    tqm = type('', (), {})()
    s = StrategyModule(tqm)
    assert isinstance(s, FreeStrategyModule)

    #check whether the super class constructor has been called
    assert s._host_pinned == True



# Generated at 2022-06-21 07:30:40.890187
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm='tqm')
    assert obj._host_pinned == True

# Generated at 2022-06-21 07:30:43.006214
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(None, ""), object)


# Generated at 2022-06-21 07:30:45.780145
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-21 07:30:47.720954
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    m = StrategyModule('Test')
    assert m._host_pinned == True

# Generated at 2022-06-21 07:30:51.637477
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task_queue_manager = object()
    s = StrategyModule(task_queue_manager)
    assert s.get_host_pinned() is True

# Generated at 2022-06-21 07:31:00.287222
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader, variable_manager, constructor_fake)
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-21 07:31:01.100843
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-21 07:31:12.131052
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule as testClass
    from ansible.plugins.strategy import StrategyModule
    from ansible.utils.display import Display
    tqm = {'some': 'thing'}
    obj = testClass(tqm)
    assert obj is not None
    assert isinstance(obj, StrategyModule)
    assert isinstance(obj, testClass)
    assert obj._host_pinned is True
    assert obj._display is not None
    assert isinstance(obj._display, Display)


# Generated at 2022-06-21 07:31:13.072462
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:31:19.621594
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create an objet of TQM
    tqm = TQM()
    # Create an object of StrategyModule
    strategy = StrategyModule(tqm)
    assert(strategy == tqm.strategy)
    assert(strategy._host_pinned == True)

# Run test for StrategyModule
test_StrategyModule()

# Generated at 2022-06-21 07:31:22.695633
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    test_strategy_module = StrategyModule(tqm)
    assert test_strategy_module._host_pinned == True

# Generated at 2022-06-21 07:31:25.501897
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule("localhost");
    assert isinstance(obj._host_pinned, bool)

# Generated at 2022-06-21 07:31:27.099024
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:31:28.827487
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    _tqm = None
    _sd = StrategyModule(_tqm)
    assert(_sd._host_pinned) == True

# Generated at 2022-06-21 07:31:30.620891
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule("tqm")

# Generated at 2022-06-21 07:31:31.462223
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:31:33.455841
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule("localhost")
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:31:39.358175
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = dict()
    assert StrategyModule(tqm).host_pinned is True

# Generated at 2022-06-21 07:31:41.162440
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)



# Generated at 2022-06-21 07:31:51.698240
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Initialize variables to test constructor
    TASK_QUEUE_MANAGER = "TASK_QUEUE_MANAGER"
    display = Display()

    # Create instance of class StrategyModule
    t = StrategyModule(TASK_QUEUE_MANAGER)

    # Assert class variables initialized properly
    #assert t.get_host_list(pattern=None, exclude=False) == "get_host_list(pattern=None, exclude=False)"
    assert t._display == display
    assert t._tqm == TASK_QUEUE_MANAGER
    assert t._run_handlers is False
    assert t._variable_manager is None
    assert t._loader is None
    assert t._final_q is None
    assert t._block_list is None
    assert t._block is None

# Generated at 2022-06-21 07:31:52.593793
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:31:55.166313
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    strategy = StrategyModule(tqm)
    assert strategy is not None


# Generated at 2022-06-21 07:31:57.408420
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule), "Class StrategyModule should have a constructor"

# Generated at 2022-06-21 07:31:59.127829
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Test constructor of class StrategyModule"""

    assert True

# Generated at 2022-06-21 07:32:10.581788
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import executor
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    inventory = Inventory(loader=DataLoader(), variable_manager=VariableManager(), host_list=[])
    variable_manager = VariableManager(loader=DataLoader())
    loader = DataLoader()
    passwords = {}
    strategy_module = 'host_pinned'

# Generated at 2022-06-21 07:32:16.746514
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock
    import ansible.plugins.strategy.host_pinned
    tqm = mock.MagicMock()
    strategy = ansible.plugins.strategy.host_pinned.StrategyModule(tqm)
    assert isinstance(strategy, StrategyModule)

# Generated at 2022-06-21 07:32:17.532353
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:32:25.847542
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:32:30.578209
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class tqm(object):
        class stats(object):
            iteration_number = 0
    tqm = tqm()
    sm = StrategyModule(tqm)
    assert sm._host_pinned



# Generated at 2022-06-21 07:32:32.988229
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test StrategyModule object initialization
    assert StrategyModule("test_tqm")

# Generated at 2022-06-21 07:32:35.375092
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ test_StrategyModule
    Tests StrategyModule class constructor
    """
    pass
    # TODO: Add test

# Generated at 2022-06-21 07:32:38.755093
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)


# In[5]:


# When running, this function basically just updates the dyn_hosts sets, and returns the result.

# Generated at 2022-06-21 07:32:42.736031
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    strategy = StrategyModule(tqm)
    assert isinstance(strategy, FreeStrategyModule)
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:32:45.977224
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
        obj = StrategyModule(tqm="tqm")
        assert obj._host_pinned == True

# Generated at 2022-06-21 07:32:47.484542
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=True)

# Generated at 2022-06-21 07:32:50.755730
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Check assumption that _host_pinned should default to True and
    # that the super class constructor doesn't change it.
    assert(StrategyModule.__init__.__globals__['self']._host_pinned is True)

# vim: set fileencoding=utf-8:

# Generated at 2022-06-21 07:32:51.552404
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:33:11.081975
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = Ansible.TestCase()
    result = StrategyModule.StrategyModule(test_tqm)
    assert result == None


# Generated at 2022-06-21 07:33:13.241693
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-21 07:33:18.801839
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager()
    assert isinstance(StrategyModule(tqm), StrategyModule)

# Generated at 2022-06-21 07:33:21.032626
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    assert hasattr(StrategyModule, '__init__')



# Generated at 2022-06-21 07:33:23.984845
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None

# Generated at 2022-06-21 07:33:25.672341
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__('self')

# Generated at 2022-06-21 07:33:27.736635
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Here we create a new object of class StrategyModule
    ans = StrategyModule()
    # We check if the object is of type StrategyModule
    assert isinstance(ans, StrategyModule)

# Generated at 2022-06-21 07:33:28.402847
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None).__init__(None)

# Generated at 2022-06-21 07:33:29.156712
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-21 07:33:30.920697
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

     tqm = None
     st = StrategyModule(tqm)

     assert st._host_pinned == True
     assert st.display == None

# Generated at 2022-06-21 07:34:14.915564
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule("test_tqm")

# Generated at 2022-06-21 07:34:17.062761
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    Object = StrategyModule()
    Object.run()
    assert Object 


# Generated at 2022-06-21 07:34:25.585469
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Hosts:
        all = "all"

    class TQM:
        hosts = Hosts()

    tqm = TQM()
    tsm = StrategyModule(tqm)
    assert tsm._host_pinned == True


# Generated at 2022-06-21 07:34:29.551829
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    obj = StrategyModule(None)

    assert obj._host_pinned == True
    assert obj._batch_size == 0

# Generated at 2022-06-21 07:34:35.057185
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ansible.utils.loader._AnsibleLoader().load_ansible_collections("ansible_collections.ansible.builtin", "tests", "unit", "modules", "network")
    StrategyModule(tqm)


# Generated at 2022-06-21 07:34:37.368622
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy is not None
    return strategy

# Generated at 2022-06-21 07:34:40.356071
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm='tqm')
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:34:41.225552
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:34:43.469232
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()
    assert s._host_pinned is True

# Generated at 2022-06-21 07:34:44.610019
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock

    tqm = mock.Mock()
    strategy = StrategyModule(tqm)

    assert strategy._host_pinned

# Generated at 2022-06-21 07:36:10.919927
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    print(ansible.plugins.strategy.host_pinned.StrategyModule)
    print(ansible.plugins.strategy.host_pinned.StrategyModule.__init__.__doc__)


# Generated at 2022-06-21 07:36:15.633561
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    tqm = ansible.plugins.strategy.host_pinned.StrategyModule('tqm')
    assert tqm != None

# Generated at 2022-06-21 07:36:18.679611
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule('');
    assert a != None, 'test_StrategyModule constructor failed!'

# Generated at 2022-06-21 07:36:19.574902
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:36:22.211541
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from .test_strategy_base import TestStrategyBase
    TestStrategyBase(StrategyModule)


# Generated at 2022-06-21 07:36:24.071717
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-21 07:36:30.282599
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
        Test StrategyModule constructor.
        :return:
        """
    import ansible.plugins.strategy_plugins.host_pinned
    test_obj = ansible.plugins.strategy_plugins.host_pinned.StrategyModule()
    assert test_obj is not None

# Generated at 2022-06-21 07:36:31.300620
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-21 07:36:33.157277
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-21 07:36:37.561086
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    v = StrategyModule('tqm')
    assert(v._host_pinned == True)

# ==================================================================
# Unit tests for class StrategyModule
# ==================================================================

# Generated at 2022-06-21 07:39:59.839157
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:40:07.401901
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host=MagicMock()
    tqm=MagicMock()
    tqm.hosts=['host']
    tqm.get_original_variables.return_value={'a':30}
    tqm.get_vars.return_value={'a':30}
    tqm.options.forks=30
    strategy=StrategyModule(tqm)
    assert strategy.tqm.hosts == ['host']