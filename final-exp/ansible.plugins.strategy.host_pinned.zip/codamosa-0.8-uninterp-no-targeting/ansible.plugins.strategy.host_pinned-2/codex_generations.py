

# Generated at 2022-06-21 07:30:00.135162
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert s._host_pinned == True

# Generated at 2022-06-21 07:30:00.985812
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:30:03.849028
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # verify inherited object is as expected
    assert not hasattr(StrategyModule, '_host_pinned')

# Generated at 2022-06-21 07:30:07.503428
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	# Test with known result
	strategy = StrategyModule('tqm')
	assert strategy._host_pinned == True
	assert strategy._batch_size == 0
	assert strategy._serialized_tasks == {}
	assert strategy._cur_serialized_task_hosts == {}

# Generated at 2022-06-21 07:30:08.230941
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-21 07:30:12.670786
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_instance = StrategyModule()

    # make sure the variables have been initialized as expected
    assert (strategy_instance._host_pinned) is True

# Generated at 2022-06-21 07:30:17.352327
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {'_meta': {'hostvars': {'host1': {'key1': 'value1'}}}}
    strategy = StrategyModule(tqm)
    # Confirm that the host_pinned attribute is set to True
    assert strategy._host_pinned

# Generated at 2022-06-21 07:30:20.786463
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # FIXME: how to unit test?
    assert True # FIXME: use assertion

# Generated at 2022-06-21 07:30:21.601437
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:30:24.243163
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import host_pinned
    assert host_pinned.StrategyModule

# Generated at 2022-06-21 07:30:28.038786
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy import _tqm
    strategy_module = StrategyModule(_tqm)
    assert strategy_module

# Generated at 2022-06-21 07:30:30.169313
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm) != None # unique hash


# Generated at 2022-06-21 07:30:32.342110
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm._host_pinned == True

# Generated at 2022-06-21 07:30:36.598152
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Check execution of the constructor of class StrategyModule
    tqm = ''
    obj = StrategyModule(tqm)
    res = obj._host_pinned
    assert res == True

# Generated at 2022-06-21 07:30:37.306383
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule != None

# Generated at 2022-06-21 07:30:39.676695
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert "StrategyModule" in str(StrategyModule.__init__)


# Generated at 2022-06-21 07:30:46.353333
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import context
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=DataLoader(), sources=['localhost,']),
        variable_manager=VariableManager(loader=DataLoader(), inventory=InventoryManager(loader=DataLoader(), sources=['localhost,'])),
        loader=DataLoader(),
        options=context.CLIARGS,
        passwords=None,
    )
    strategy = StrategyModule(tqm)
    assert strategy._

# Generated at 2022-06-21 07:30:54.784603
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    inventory = InventoryManager(host_list=['localhost'])
    tqm = TaskQueueManager(
        inventory=inventory,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback='default',
        run_additional_callbacks=True,
        run_tree=False,
        all_vars=[],
    )
    p = PlayContext()
    sm = StrategyModule(tqm)
    assert sm.tqm == tqm
    assert sm._host_pinned is True

# Generated at 2022-06-21 07:30:55.720272
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:30:57.997918
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(tqm), StrategyModule)

# Generated at 2022-06-21 07:31:03.125411
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test Constructor
    print("Testing Constructor")
    StrategyModule()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:31:04.597980
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return 1

# Test of class StrategyModule

# Generated at 2022-06-21 07:31:12.923196
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(None, None, None, None, None, 'host_pinned', None, None, False, True)
    strategy = StrategyModule(tqm)
    assert isinstance(strategy, StrategyModule)
    assert strategy._host_pinned
    assert strategy._connection_info is not None
    assert strategy._notified_handlers is not None
    assert strategy._name == 'host_pinned'

# Generated at 2022-06-21 07:31:16.272212
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    strategy_module = StrategyModule(b_tqm)


# Generated at 2022-06-21 07:31:20.617687
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.display import Display
    from ansible.plugins.strategy.host_pinned import StrategyModule
    display = Display()
    tqm = StrategyModule(display)
    assert tqm._host_pinned == True

# Testing inheritance

# Generated at 2022-06-21 07:31:22.559126
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__ is not None


# Generated at 2022-06-21 07:31:23.487078
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:31:25.045624
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ansible.plugins.strategy.host_pinned.StrategyModule(tqm)


# Generated at 2022-06-21 07:31:27.611674
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)
    assert(strategy._host_pinned == True)

# Generated at 2022-06-21 07:31:29.285425
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__(StrategyModule,2) == None



# Generated at 2022-06-21 07:31:36.152420
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert (strategy._host_pinned == True)

# Generated at 2022-06-21 07:31:36.948058
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:31:39.235946
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None
    assert StrategyModule.__init__.__doc__ is not None

# Generated at 2022-06-21 07:31:51.202255
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    class TQM:
        def get_hosts(self, pattern):
            my_hosts = []
            my_hosts.append('host1')
            my_hosts.append('host2')
            return my_hosts

    strategy_module = StrategyModule(TQM())

    assert(strategy_module._host_pinned == True)
    assert(strategy_module._display == display)
    assert(strategy_module._call_queue.qsize() == 0)
    assert(isinstance(strategy_module._injector, list))
    assert(isinstance(strategy_module._failed_hosts, list))
    assert(isinstance(strategy_module._unreachable_hosts, list))
    assert(strategy_module._tqm is TQM)

# Generated at 2022-06-21 07:31:52.141197
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:31:53.722783
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__

# Generated at 2022-06-21 07:31:59.511988
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_values = [True, False]
    for test_value in test_values:
        # use the free strategy and the strategy specified test_value
        func = StrategyModule(test_value)
        assert func._host_pinned == test_value


# Generated at 2022-06-21 07:32:08.453143
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import ansible

    class TestStrategyModule(unittest.TestCase):
        def test_StrategyModule_instance(self):
            tqm = ansible.utils.plugins.BaseTQM()
            self.assertIsInstance(StrategyModule(tqm), StrategyModule)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestStrategyModule)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-21 07:32:09.141843
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:32:09.858068
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:32:19.297226
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-21 07:32:23.672442
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned as strategy_host_pinned

    strategy_host_pinned.StrategyModule(1)


# Generated at 2022-06-21 07:32:26.898709
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-21 07:32:28.514278
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Tests if class is initialized
    assert StrategyModule

# Generated at 2022-06-21 07:32:39.174756
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    from ansible.utils.display import Display
    from ansible.plugins.strategy.host_pinned import StrategyModule
    import unittest

    class TestStrategyModule(unittest.TestCase):

        def setUp(self):
            self.test_obj = StrategyModule(Display())
            self.test_free_obj = FreeStrategyModule(Display())

        def test_init(self):
            self.assertIsInstance(self.test_obj, StrategyModule)

        def test_super(self):
            self.assertIsInstance(self.test_obj, FreeStrategyModule)

    # Run the test case

# Generated at 2022-06-21 07:32:43.810476
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    input_tqm = None
    result = StrategyModule(input_tqm)
    # This is a base class, so should not be able to instantiate it.
    assert result == NotImplemented

# Generated at 2022-06-21 07:32:45.653944
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-21 07:32:46.862254
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("**** In test_StrategyModule ****")
    sm = StrategyModule()


# Generated at 2022-06-21 07:32:47.803261
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   pass

# Generated at 2022-06-21 07:32:50.370571
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("tqm")
    assert strategy_module is not None

# Generated at 2022-06-21 07:33:11.172675
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Dummy:
        pass
    tqm = Dummy()
    sm = StrategyModule(tqm)
    assert hasattr(sm, '_host_pinned') and sm._host_pinned



# Generated at 2022-06-21 07:33:11.849060
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-21 07:33:15.945032
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-21 07:33:27.317357
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import pytest
    import ansible.plugins.strategy.host_pinned
    import ansible.plugins.strategy.free
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

# Generated at 2022-06-21 07:33:30.652848
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:33:33.862326
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    This test case is to test if the constructor of class StrategyModule
    can work correctly.
    '''
    strategy_object = StrategyModule(None)
    assert strategy_object is not None
    assert strategy_object._host_pinned is True


# Generated at 2022-06-21 07:33:35.571279
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.host_pinned == True

# Generated at 2022-06-21 07:33:37.132152
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-21 07:33:39.743538
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm=None)
    assert module._host_pinned == True

# Generated at 2022-06-21 07:33:42.318414
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=1)
    assert strategy.get_host_pinned() == True

# Generated at 2022-06-21 07:34:37.912519
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	from ansible.utils.display import Display
	import mock
	import sys

	display = Display()
	tqm = mock.Mock()
	strategy_module = StrategyModule(tqm)
	assert strategy_module._host_pinned == True
	assert strategy_module._number_lock is not None
	assert strategy_module._result_prc_lock is not None
	assert strategy_module._block_host_count == 0
	assert strategy_module._tqm == tqm
	assert strategy_module._display == display
	assert strategy_module._unblock_hosts == {}
	assert strategy_module._cur_serial_task_items == []
	assert strategy_module._barrier_queues == {}
	assert strategy_module._blocks[0] == []
	assert strategy_module._blocks[1] == []

# Generated at 2022-06-21 07:34:39.623564
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule("tqm")

# Generated at 2022-06-21 07:34:42.549567
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)
    assert(StrategyModule.__name__ == 'StrategyModule')

# Generated at 2022-06-21 07:34:44.217480
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-21 07:34:46.670038
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task_queue_manager = StrategyModule(tqm="some_value")
    assert task_queue_manager._host_pinned == True

# Generated at 2022-06-21 07:34:49.309988
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    m = StrategyModule("tq1")
    assert isinstance(m, FreeStrategyModule)



# Generated at 2022-06-21 07:34:50.982837
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)


# Generated at 2022-06-21 07:34:53.827969
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # instantiate the class object module
    module = StrategyModule(tqm)
    # assert the value of class attribute _host_pinned
    assert module._host_pinned
    # assert that the value of class attribute _host_pinned is True
    assert not module._host_pinned

# Generated at 2022-06-21 07:34:59.248290
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    assert StrategyModule.__init__
    assert '_host_pinned' in dir(StrategyModule)
    assert 'test_StrategyModule' == StrategyModule.test_StrategyModule.__name__
    assert StrategyModule.__module__ == __name__
    assert 'StrategyModule' == StrategyModule.__name__
    assert '__name__' == StrategyModule.__name__

# Generated at 2022-06-21 07:35:08.347369
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.sentinel import Sentinel
    from ansible.executor.task_queue_manager import TaskQueueManager
    class MockTaskQueueManager:
        def __init__(self):
            self.stats = Sentinel()
            self.stats.processed = {}
            self.inventory = Sentinel()
    tqm = TaskQueueManager(MockTaskQueueManager())

    strategy = StrategyModule(tqm)

    # Test to make sure the attribute was created
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:36:31.576659
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.inventory

    m = StrategyModule(None)
    assert m._host_pinned

# Generated at 2022-06-21 07:36:32.415574
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:36:35.965396
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        from ansible.plugins.strategy.host_pinned import StrategyModule
    except SystemExit:
        pass


# Generated at 2022-06-21 07:36:39.901926
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # First parameter is a task queue manager object
    tqm = 'tqm'
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned

# Generated at 2022-06-21 07:36:41.758493
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned as module
    assert issubclass(module.StrategyModule, FreeStrategyModule)

# Generated at 2022-06-21 07:36:53.628351
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import context
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from units.mock.plugins.callback import CallbackModule

    context.CLIARGS = {}

# Generated at 2022-06-21 07:36:57.710332
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mystrategy = StrategyModule()
    if mystrategy:
        pass

# class name is needed here to build docs
# pylint: disable=bad-super-call

# Generated at 2022-06-21 07:37:01.140620
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    strategy = ansible.plugins.strategy.host_pinned.StrategyModule(object)

# Generated at 2022-06-21 07:37:01.795787
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:37:04.589326
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm = None)
    assert s
    assert s._host_pinned
    assert s._tqm == None