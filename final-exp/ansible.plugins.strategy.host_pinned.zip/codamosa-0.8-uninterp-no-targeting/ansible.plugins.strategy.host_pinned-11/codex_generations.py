

# Generated at 2022-06-21 07:30:03.066997
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    # TODO

# Generated at 2022-06-21 07:30:06.452260
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True, "error in StrategyModule constructor"

# Generated at 2022-06-21 07:30:07.850203
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(0)._host_pinned == True

# Generated at 2022-06-21 07:30:13.362184
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ constructor test """

    tqm = "tqm"
    test_obj = StrategyModule(tqm)
    assert test_obj._host_pinned == True


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:30:16.517219
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    try:
        strategy = StrategyModule(tqm)
        assert strategy
    except NameError:
        assert False

# Generated at 2022-06-21 07:30:18.521310
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:30:22.552364
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module._host_pinned == True
    assert strategy_module.batch_count == 1

# Generated at 2022-06-21 07:30:24.589990
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__("test_tqm")

# Generated at 2022-06-21 07:30:26.798433
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_name = StrategyModule('tqm')
    assert strategy_name.__str__() == 'host_pinned'

# Generated at 2022-06-21 07:30:28.809734
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule()
    assert a._host_pinned == True

# Generated at 2022-06-21 07:30:37.661102
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager('/etc/ansible/ansible.cfg','/dev/null','','','','','','','','','','','','','')
    StrategyModule(tqm)
    assert True

# Generated at 2022-06-21 07:30:39.210534
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    assert FreeStrategyModule

# Generated at 2022-06-21 07:30:40.213522
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:30:48.460483
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    inventory = ansible.inventory.Inventory('hosts.txt')
    variable_manager = ansible.vars.VariableManager(inventory)
    loader = ansible.parsing.dataloader.DataLoader()
    tqm = ansible.executor.task_queue_manager.TaskQueueManager(inventory, variable_manager, loader, display, options)

    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned

# Generated at 2022-06-21 07:30:49.889697
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(None, None)
    assert StrategyModule(tqm)

# Generated at 2022-06-21 07:30:51.063934
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-21 07:31:02.471097
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, host_list='localhost')
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-21 07:31:04.598416
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_mod = StrategyModule.__init__()
    print(strategy_mod)

# Generated at 2022-06-21 07:31:06.347123
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule('tqm')

# Generated at 2022-06-21 07:31:15.298785
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule

    # Create a dummy task queue manager for testing. This is not an AnsibleTQM object
    # because it lacks a lot of state that's needed by the StrategyModule

# Generated at 2022-06-21 07:31:19.044676
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    test = StrategyModule(tqm)
    assert test._host_pinned is True

# Generated at 2022-06-21 07:31:20.578559
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm=None)
    assert s._host_pinned == True

# Generated at 2022-06-21 07:31:24.862875
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from mock import MagicMock
    from ansible.plugins.strategy import fixed
    tqm = MagicMock()
    StrategyModule.__new__(fixed.StrategyModule).__init__(tqm)

# Generated at 2022-06-21 07:31:26.384969
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-21 07:31:27.826601
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == True



# Generated at 2022-06-21 07:31:28.644250
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(1)

# Generated at 2022-06-21 07:31:29.801688
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-21 07:31:31.776184
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("test")
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:31:40.204101
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print ("Testing constructor for class StrategyModule")
    tqm = None
    testobj = StrategyModule(tqm)
    if not isinstance(testobj, StrategyModule):
        raise TypeError("Failed to create StrategyModule object")
    if not isinstance(testobj, FreeStrategyModule):
        raise TypeError("Failed to create StrategyModule object")
    if not testobj._host_pinned:
        raise TypeError("Failed to set _host_pinned in constructor")


# Generated at 2022-06-21 07:31:41.236237
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:31:46.590034
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  strategy_module = StrategyModule('tqm')
  assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:31:48.142466
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return_value = StrategyModule(tqm={})
    assert isinstance(return_value, StrategyModule)
    assert isinstance(return_value, FreeStrategyModule)


# Generated at 2022-06-21 07:31:49.849685
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        assert type(StrategyModule) == StrategyModule
    except Exception as e:
        print(str(e))



# Generated at 2022-06-21 07:32:00.336509
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    dict = {'foo': 'bar'}
    strategy = StrategyModule(dict)
    assert(strategy._tqm == dict)
    assert(strategy._host_done == {})
    assert(strategy._queue == [])
    assert(strategy._unreachable_hosts == [])
    assert(strategy._add_tqm_variables == False)
    assert(strategy._stats == {})
    assert(strategy._batch_size == 0)
    assert(strategy._display is display)
    assert(strategy._host_pinned is True)

# Generated at 2022-06-21 07:32:11.109229
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # setup() will be called with a tqm object for each test
    print("Defining StrategyModule.setup()")
    def setup(self, tqm):
        self.initialized = True
        self.tqm = tqm
        self.stratname = 'host_pinned'
        self.display = Display()
        self.display.verbosity = 99
        self.result_q = tqm._final_q
        # once the workers are running, they will block until they receive a message on this queue
        # this message is sent to the queue to unblock workers after the strategy
        # has finished putting all hosts into the queue
        self._block_q = tqm._workers_q
        self._workers_running = False
        self._unblocked = False

    # setUp() will be called with self for each test

# Generated at 2022-06-21 07:32:20.706435
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = '127.0.0.1'
    test_tqm = None
    sm = StrategyModule(test_tqm)
    # assert sm._host_pinned is True
    # assert sm._tqm is None
    # assert sm._inventory is None
    # assert sm._loader is None
    # assert sm._variable_manager is None
    # assert sm._fail_queue is None
    # assert sm._buried_queue is None
    # assert sm._blocked_hosts is None
    # assert sm._play_context is None
    # assert sm._display is None

# Generated at 2022-06-21 07:32:22.310464
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-21 07:32:28.766704
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule

    tqm = object()
    strategy = StrategyModule(tqm)

    assert strategy._host_pinned == True
    assert strategy._tqm is tqm


# Generated at 2022-06-21 07:32:30.280377
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Make sure the StrategyModule class is able to be loaded

# Generated at 2022-06-21 07:32:33.913401
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule("test")
    assert sm._host_pinned

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:32:42.239012
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:32:46.630499
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    err_msg = "The strategy object should be an instance of StrategyModule"
    assert isinstance(strategy, StrategyModule), err_msg

# Generated at 2022-06-21 07:32:47.830446
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:32:49.592693
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(object)

# Generated at 2022-06-21 07:32:52.362274
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule('tqm')
    assert mod.get_host_pinned() == True

# Generated at 2022-06-21 07:32:57.295109
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    myStrategyModule = StrategyModule("tqm")
    assert myStrategyModule._host_pinned == True
    assert myStrategyModule._display is not None

# Generated at 2022-06-21 07:33:00.740151
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM:
        pass

    obj = StrategyModule(TestTQM())
    assert obj._host_pinned == True

# Generated at 2022-06-21 07:33:02.251586
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule(tqm=None)
    print(strategyModule._host_pinned)

# Generated at 2022-06-21 07:33:03.526941
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-21 07:33:08.462408
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from mock import Mock, patch

    my_tqm = Mock()
    my_tqm.get_vars.return_value = {}
    sm = StrategyModule(my_tqm)
    assert sm

# Generated at 2022-06-21 07:33:25.248328
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None

# Generated at 2022-06-21 07:33:28.286954
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    obj = StrategyModule(tqm)
    assert obj._host_pinned == True

# Generated at 2022-06-21 07:33:29.894987
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)

# Generated at 2022-06-21 07:33:33.326231
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    TASK_QUEUE_MANAGER_CLASS = Mock()
    task_queue_manager = StrategyModule(TASK_QUEUE_MANAGER_CLASS)
    assert task_queue_manager._host_pinned == True



# Generated at 2022-06-21 07:33:35.150738
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
     return StrategyModule(None)

# Generated at 2022-06-21 07:33:46.029764
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest

    class TestStrategyModule(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            super(TestStrategyModule, self).__init__(*args, **kwargs)

        def test_constructor(self):
            from ansible.plugins.strategy.host_pinned import StrategyModule
            from ansible.plugins.loader import get_all_plugin_loaders
            from ansible.plugins.loader import get_all_strategy_classes
            import inspect
            import logging

            log = logging.getLogger()

            # Make sure we can import all strategy plugins
            loaders = get_all_plugin_loaders()
            for loader in loaders:
                for strategy in loader.get_all_strategies():
                    strategy_class = get_all_strategy

# Generated at 2022-06-21 07:33:47.539292
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None) is not None

# Generated at 2022-06-21 07:33:50.798435
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    # Verify value of private attribute _host_pinned
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:33:55.053647
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm=None)
    assert sm._host_pinned
    assert sm.tqm is None
    assert sm._inventory is None
    assert sm._iterator is None
    assert sm._vars_cache is None
    assert sm._default_vars is None

# Generated at 2022-06-21 07:33:57.327529
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    s = StrategyModule(tqm=display)
    assert s

# Generated at 2022-06-21 07:34:42.230064
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-21 07:34:43.369458
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule == StrategyModule
    assert FreeStrategyModule == FreeStrategyModule
    assert Display == Display
# test_StrategyModule()


# Generated at 2022-06-21 07:34:44.001760
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__

# Generated at 2022-06-21 07:34:47.690404
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Assigning the arguments by keyword to create a StrategyModule object
    tqm_obj = None
    strategy_obj = StrategyModule(tqm_obj)
    # Check the arguments supplied is stored in the object
    assert strategy_obj._host_pinned == True

# Generated at 2022-06-21 07:34:49.661927
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-21 07:34:52.245617
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    z = StrategyModule(None)
    assert(z._host_pinned == True)

# Generated at 2022-06-21 07:34:55.657331
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm='tqm')
    assert(strategy_module._host_pinned == True)

# Generated at 2022-06-21 07:34:57.834798
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert(strategy._host_pinned)

# Generated at 2022-06-21 07:34:59.663910
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:35:03.073346
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ansible_options = None
    inventory = None
    variable_manager = None
    loader = None
    passwords = None
    display = None
    options = None
    stdout_callback = None
    run_additional_callbacks = False
    run_tree = True
    tqm = None
    strategy = None
    new_stdout_callback = None
    new_run_additional_callbacks = False
    new_tqm = None

    strategy = StrategyModule(tqm)

    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:36:25.320848
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert '_host_pinned' in dir(StrategyModule)

# Generated at 2022-06-21 07:36:27.463349
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    TQM = True
    StrategyModule(TQM)



# Generated at 2022-06-21 07:36:31.500582
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    new_strategy_module = StrategyModule(tqm = None)
    assert 'FreeStrategyModule' in str(new_strategy_module)
    assert new_strategy_module._host_pinned == True

# Generated at 2022-06-21 07:36:33.421076
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    StrategyModule(tqm)

# Generated at 2022-06-21 07:36:37.062098
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test for no errors
    try:
        StrategyModule(None)
    except Exception as e:
        assert False
    else:
        assert True

# Generated at 2022-06-21 07:36:37.808375
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    t_strategy_module = StrategyModule()
    assert t_strategy_module != None

# Generated at 2022-06-21 07:36:39.246841
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__

# Generated at 2022-06-21 07:36:41.433644
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:36:53.459449
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import ansible.plugins.strategy.host_pinned
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    class Tasks:
        def __init__(self, block1):
            self.block = block1


# Generated at 2022-06-21 07:36:54.990861
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)