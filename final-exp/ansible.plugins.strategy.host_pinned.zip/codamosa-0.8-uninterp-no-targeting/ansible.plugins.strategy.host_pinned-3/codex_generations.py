

# Generated at 2022-06-21 07:30:00.523181
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)



# Generated at 2022-06-21 07:30:02.527029
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)


# Generated at 2022-06-21 07:30:06.139634
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    strategy = StrategyModule(tqm)
    assert strategy._tqm == tqm
    assert strategy._host_pinned is True

# Generated at 2022-06-21 07:30:07.429724
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule('test_tqm')
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:30:08.146559
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:30:19.462266
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # import required modules
    import pytest
    import ansible.constants as C
    import ansible.plugins.loader as plugin_loader
    import os
    import shutil
    import tempfile
    from ansible.executor.task_queue_manager import TaskQueueManager

    def mock_load_plugins(cls, force=False):
        try:
            from ansible.plugins.tests.test_strategy import mock_host_pinned
        except SyntaxError:
            from .ansible.plugins.tests.test_strategy import mock_host_pinned
        plugin_loader.add_directory(os.path.join(os.path.dirname(mock_host_pinned.__file__), '../'))

    class Tqm:
        def __init__(self):
            self.display = Display()



# Generated at 2022-06-21 07:30:20.496771
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ''' strategy_host_pinned.py:StrategyModule() '''
    pass

# Generated at 2022-06-21 07:30:22.549759
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    StrategyModule(tqm)

# Generated at 2022-06-21 07:30:25.083434
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule(0)
    assert x._host_pinned == True


# Generated at 2022-06-21 07:30:27.050213
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrObj = StrategyModule.StrategyModule(None)
    assert StrObj._host_pinned == True

# Generated at 2022-06-21 07:30:30.241066
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()
    assert obj._host_pinned == True


# Generated at 2022-06-21 07:30:34.318762
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    return isinstance(StrategyModule(), FreeStrategyModule)

# test case for module StrategyModule

# Generated at 2022-06-21 07:30:40.629502
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import ansible.plugins.strategy.host_pinned as host_pinned
    class TestStrategyModule(unittest.TestCase):
        def test_strategy(self):
            strategy_instance = host_pinned.StrategyModule(tqm=None)
            self.assertFalse(strategy_instance._host_pinned)
    unittest.main()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:30:41.501038
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:30:47.444967
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock
    import ansible.plugins.strategy.host_pinned
    tqm = mock.MagicMock()
    strategy = ansible.plugins.strategy.host_pinned.StrategyModule(tqm)

    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:30:50.117488
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import collections
    assert isinstance(StrategyModule(), collections.Iterable)

# Generated at 2022-06-21 07:30:56.491134
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = type('TestTQM', (object,), {'_final_q': None, '_failed_hosts': {}, '_unreachable_hosts': {}, '_stats': type('TestStats', (object,), {'_hosts': {}})})()
    StrategyModule(tqm)

# Generated at 2022-06-21 07:30:59.317985
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule("tqm")
    assert obj is not None, "Failed to get initialized class object"
    assert obj._host_pinned is True, "Host pinned initialization failed"

# Generated at 2022-06-21 07:31:00.718999
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule("strategy")

# Generated at 2022-06-21 07:31:04.055971
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = init_tqm()
    strategy = StrategyModule(tqm)

    assert strategy._host_pinned

# Generated at 2022-06-21 07:31:07.387330
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
     strategy_module = StrategyModule(tqm=None)
     assert strategy_module._host_pinned == True,'Failed to initialize constructor of class StrategyModule'

# Generated at 2022-06-21 07:31:09.849095
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module.__class__.__name__ == "StrategyModule"

# Generated at 2022-06-21 07:31:10.981066
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:31:13.654615
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    assert obj._host_pinned



# Generated at 2022-06-21 07:31:15.863680
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # print(StrategyModule.__doc__)
    obj = StrategyModule(tqm = False)
    print(obj)
    print(obj._host_pinned)

# test_StrategyModule()

# Unit test class

# Generated at 2022-06-21 07:31:17.605231
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategyModule = StrategyModule(tqm)
    assert strategyModule._host_pinned == True

# Generated at 2022-06-21 07:31:19.231951
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned

# Generated at 2022-06-21 07:31:20.720028
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-21 07:31:22.085626
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule !=None


# Generated at 2022-06-21 07:31:26.606210
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule('')
    assert strategy._host_pinned == True, "StrategyModule._host_pinned is " + str(strategy._host_pinned) + ", should be True"

# Generated at 2022-06-21 07:31:31.097709
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(StrategyModule)

# Generated at 2022-06-21 07:31:34.263142
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned

# Generated at 2022-06-21 07:31:37.936328
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)
    assert StrategyModule.__init__.__doc__ is not None

# Test documentation of class StrategyModule

# Generated at 2022-06-21 07:31:39.445772
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule('tqm')

# Generated at 2022-06-21 07:31:41.962924
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(object)
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:31:43.849405
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-21 07:31:49.638792
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor for class StrategyModule")

    # Test 1:
    ans = StrategyModule(0)
    if ans._host_pinned == True:
        print("Test 1: PASS")
    else:
        print("Test 1: FAIL")


# Local test case
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:31:51.041392
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule('test_tqm'))

# Generated at 2022-06-21 07:31:58.982704
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
        class TestStrategyModule(StrategyModule):
            def __init__(self, tqm):
                super(StrategyModule, self).__init__(tqm)
                self._host_pinned = True
        a=TestStrategyModule()
        print(type(a))
        a.__init__(1)

test_StrategyModule()

# Generated at 2022-06-21 07:32:00.444812
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm)
    assert hasattr(sm, '_host_pinned')

# Generated at 2022-06-21 07:32:13.194156
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    test_object = StrategyModule(tqm)

    assert test_object is not None

# Generated at 2022-06-21 07:32:14.812823
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("In StrategyModule constructor")

# Generated at 2022-06-21 07:32:15.976475
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    assert(StrategyModule(display))

# Generated at 2022-06-21 07:32:18.338739
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.name == 'host_pinned'
    # assert strategy.require_inventory == True

# Generated at 2022-06-21 07:32:18.762197
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:32:19.766610
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:32:21.558953
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-21 07:32:22.969209
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result = StrategyModule('tqm')
    assert result._host_pinned == True

# Generated at 2022-06-21 07:32:23.822064
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:32:26.232424
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm='tqm')


# Generated at 2022-06-21 07:32:53.700932
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import context
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import os
    import sys
    loader = DataLoader()
    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=loader, sources=''),
        variable_manager=VariableManager(loader=loader, inventory=InventoryManager(loader=loader, sources='')),
        loader=loader,
        options=context.CLIARGS,
        stdout_callback=None,
        run_additional_callbacks=False,
        run_tree=False,
    )
    sm = StrategyModule(tqm=tqm)

# Generated at 2022-06-21 07:33:05.170935
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    from ansible import settings
    from ansible.module_utils.common._collections_compat import Mapping, Sequence

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.stats import AggregateStats
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import plugin_loader
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    runners = plugin_loader.get_all_plugins()
    my_inventory = InventoryManager(settings.HOST_LIST)

# Generated at 2022-06-21 07:33:07.530091
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert "StrategyModule" == type(StrategyModule).__name__



# Generated at 2022-06-21 07:33:13.333494
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    Block.serial = 2
    Play.serial = 2
    Task.serial = 2
    tqm = None
    myModule = StrategyModule(tqm)
    assert myModule._host_pinned == True

# Generated at 2022-06-21 07:33:26.236964
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-21 07:33:30.031149
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule(1)
    assert x._host_pinned
    assert isinstance(x, StrategyModule)
    assert isinstance(x, FreeStrategyModule)


# Generated at 2022-06-21 07:33:31.665950
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule('ansible_playbook')

# Generated at 2022-06-21 07:33:32.986714
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    result = isinstance(obj, StrategyModule)
    assert result

# Generated at 2022-06-21 07:33:36.187992
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned = StrategyModule(tqm=None)
    assert host_pinned._host_pinned == True

# Generated at 2022-06-21 07:33:38.724479
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert(strategy._host_pinned)

# Generated at 2022-06-21 07:34:23.725518
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(display),StrategyModule)


# Generated at 2022-06-21 07:34:24.302359
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)._host_pinned == True

# Generated at 2022-06-21 07:34:25.953756
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = dict(display = {'verbosity' : 2})
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:34:27.808033
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)

# Generated at 2022-06-21 07:34:38.291968
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    import ansible.plugins.strategy.free
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.task_include
    import ansible.executor.task_queue_manager
    import ansible.inventory.host

    # test host_pinned constructor
    host = ansible.inventory.host.Host("dummy")
    task = ansible.playbook.task.Task()
    play = ansible.playbook.play.Play().load({}, loader=None, variable_manager=None)
    play.hosts = [host]
    play.post_validate(variable_manager=None, loader=None)


# Generated at 2022-06-21 07:34:41.301096
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__.__code__.co_argcount == 2



# Generated at 2022-06-21 07:34:45.470474
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	module = StrategyModule("tqm")
	assert module._host_pinned 

if __name__ == '__main__':
	test_StrategyModule()

# Generated at 2022-06-21 07:34:46.243665
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:34:49.082771
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned is True

# Generated at 2022-06-21 07:34:52.778102
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Test for constructor of class StrategyModule')
    strategy_obj = StrategyModule(tqm = 0)
    assert strategy_obj


# Generated at 2022-06-21 07:36:21.318321
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True
    assert strategy._tqm == None
    assert strategy._inventory_index == 1
    assert strategy._batch_index == 0
    assert strategy._batch_size == 1
    assert strategy._last_task_from_previous_batch is False

# Generated at 2022-06-21 07:36:23.290568
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule, object)

# Generated at 2022-06-21 07:36:28.218942
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('\nTEST: constructor of class StrategyModule\n')
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned == True
    print('PASS\n')

# Generated at 2022-06-21 07:36:30.783867
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned is True


# Generated at 2022-06-21 07:36:43.035382
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.runner import Runner
    from ansible.inventory import Inventory
    from ansible.playbook import PlayBook
    from ansible import callbacks
    from ansible import utils
    test_hosts = "hosts"
    test_module_path = "Module-Path"

# Generated at 2022-06-21 07:36:44.939948
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule == StrategyModule


# Generated at 2022-06-21 07:36:48.942514
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a new strategy object
    strategy = StrategyModule(tqm=None)
    # Check _host_pinned attribute
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:36:50.461644
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm)
    assert module

# Generated at 2022-06-21 07:36:51.876650
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule()._host_pinned() == True

# Generated at 2022-06-21 07:36:54.053509
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

