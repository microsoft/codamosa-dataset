

# Generated at 2022-06-21 07:30:04.566215
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ''
    obj = StrategyModule(tqm)
    assert obj._host_pinned is True

# Generated at 2022-06-21 07:30:05.349884
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:30:06.601641
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.verbosity = 4
    assert StrategyModule(None) is not None

# Generated at 2022-06-21 07:30:09.739613
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    try:
        strategy = StrategyModule(tqm)
    except:
        assert False

# Generated at 2022-06-21 07:30:10.821507
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:30:12.528178
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-21 07:30:15.088291
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test with valid inputs
    result = StrategyModule(tqm={})
    assert result._host_pinned

# Generated at 2022-06-21 07:30:16.469074
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(None), StrategyModule)

# Generated at 2022-06-21 07:30:28.739659
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import ansible.plugins.strategy.host_pinned
    ansible.plugins.strategy.host_pinned.display = Display()

    class TestHostPinned_StrategyModule(unittest.TestCase):

        def setUp(self):
            # Constructor
            self._tqm = 'test_tqm'
            self.testHostPinned = ansible.plugins.strategy.host_pinned.StrategyModule(self._tqm)

        def test_init(self):
            self.assertEqual(self.testHostPinned._tqm, self._tqm)
            self.assertEqual(self.testHostPinned._host_pinned, True)

    # unittest.main()
    suite = unittest.TestLoader().loadTestsFromTest

# Generated at 2022-06-21 07:30:33.379122
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm='tqm')
    assert strategy._host_pinned == True

if __name__ == '__main__':
    ## Run unit tests
    test_StrategyModule()

# Generated at 2022-06-21 07:30:37.487366
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned.StrategyModule
    obj = ansible.plugins.strategy.host_pinned.StrategyModule(None)



# Generated at 2022-06-21 07:30:39.058718
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-21 07:30:41.270445
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert(s._host_pinned == True)

# Generated at 2022-06-21 07:30:42.618251
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  strategy_module = StrategyModule("tqm")
  assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:30:46.010634
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Constructor of StrategyModule tests.
    """
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-21 07:30:46.674621
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 0
    StrategyModule(tqm)

# Generated at 2022-06-21 07:30:51.848014
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    strategy_options = {
        '_host_pinned': True
    }
    assert strategy_options == ansible.plugins.strategy.host_pinned.StrategyModule.__dict__['_host_pinned']

# Generated at 2022-06-21 07:30:53.805294
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:30:55.329776
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)._host_pinned == True

# Generated at 2022-06-21 07:30:58.090294
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    obj = StrategyModule(1)

    assert obj != None
    assert obj._host_pinned == True

# Generated at 2022-06-21 07:31:12.725074
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test_inventory.cfg'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 07:31:13.584474
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:31:18.790978
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Note, the TQM class is mocked for the unit test.
    TQM = 'TQM'
    strategy_module = StrategyModule(TQM)
    assert strategy_module._host_pinned == True



# Generated at 2022-06-21 07:31:21.905203
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global StrategyModule
    class TestStrategyModule(StrategyModule):
        def __init__(self, tqm):
            StrategyModule.__init__(self, tqm)
    obj = TestStrategyModule(None)
    assert obj._host_pinned == True

# Generated at 2022-06-21 07:31:25.880440
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.verbosity = 3
    tqm = FreeStrategyModule(display)
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:31:28.976024
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
     test_StrategyModule.ansible_mod = StrategyModule({})
     assert test_StrategyModule.ansible_mod._host_pinned == True

# Generated at 2022-06-21 07:31:31.385377
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(1), StrategyModule)


# Generated at 2022-06-21 07:31:33.381658
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# vim: set expandtab:ts=4:sw=4

# Generated at 2022-06-21 07:31:36.518579
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  obj = StrategyModule(tqm = None)
  assert obj._host_pinned == True
  assert obj._tqm == None

# Generated at 2022-06-21 07:31:39.942886
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm='test_tqm').__init__(tqm='test_tqm') is None
#Unit test for _get_next_task() method of class StrategyModule

# Generated at 2022-06-21 07:31:46.088705
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm='tqm')
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:31:50.851829
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class DummyTqm:
        _extra_vars = dict()
        hostvars = dict()
        inventory = dict()
        host_state_map = dict()

    tqm = DummyTqm()
    sm = StrategyModule(tqm)
    assert sm._host_pinned is True

# Unit test to test init_worker()

# Generated at 2022-06-21 07:32:02.571400
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    exitcode = 0
    try:
        from ansible.plugins.strategy import host_pinned
        from ansible.executor.task_queue_manager import TaskQueueManager
        tqm = TaskQueueManager(None, None, None, None, None, None, None, None)
        s = host_pinned.StrategyModule(tqm)
        print(s._host_pinned)
        if s._host_pinned is not True:
            from ansible.utils.display import Display
            display = Display()
            raise AssertionError('_host_pinned value error')

    except AssertionError as e:
        print('AssertionError: ', e)
        exitcode = 1

    # exit
    import sys
    sys.exit(exitcode)



# Generated at 2022-06-21 07:32:11.622990
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.module_utils._text import to_text
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    class ModelDataCache(object):
        def __init__(self):
            self._cache = {}

        def set(self, key, value):
            self._cache[key] = value

        def get(self, key):
            return self._cache[key]

    class PlayContext(object):
        def __init__(self):
            self.become = True
            self.become_method = 'sudo'

# Generated at 2022-06-21 07:32:12.490475
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:32:13.368135
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:32:15.549330
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule('tqm')
    assert obj._host_pinned == True

# Generated at 2022-06-21 07:32:17.472757
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_obj = StrategyModule(tqm)
    assert strategy_obj is not None

# Generated at 2022-06-21 07:32:18.875871
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm)

# Generated at 2022-06-21 07:32:22.612350
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned is True


# Generated at 2022-06-21 07:32:33.654314
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #print("\nSTART test_StrategyModule")
    s = StrategyModule("tqm")
    #print("\nSTOP test_StrategyModule")

# Generated at 2022-06-21 07:32:37.117600
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   tqm = mock.MagicMock()
   strategy_module = StrategyModule(tqm)
   assert strategy_module is not None
   assert strategy_module._host_pinned is True

# Generated at 2022-06-21 07:32:42.178084
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # First, create an instance of the custom class
    x = StrategyModule()

    # Next, create an instance of the built-in class
    y = FreeStrategyModule()

    # Verify the type of the object created
    assert isinstance(x, StrategyModule)

    # Verify the base class of the object created
    #assert type(x) == type(y)
    assert isinstance(x, FreeStrategyModule)

# Generated at 2022-06-21 07:32:45.177954
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Calling the constructor of class StrategyModule
    strategy_module = StrategyModule(object)
    assert(strategy_module)

# Generated at 2022-06-21 07:32:47.483097
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)



# Generated at 2022-06-21 07:32:49.519164
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = 'localhost'
    tqm = dict(host_list=[host], inventory=dict(host_list=[host]))
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned


# Generated at 2022-06-21 07:32:51.260350
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategymodule = StrategyModule.__init__(StrategyModule, {})
    assert strategymodule._host_pinned

# Generated at 2022-06-21 07:32:52.568066
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule("tqm")

# Generated at 2022-06-21 07:32:54.316882
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(StrategyModule)


# Generated at 2022-06-21 07:32:56.503381
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Generated at 2022-06-21 07:33:19.166172
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    print("Inside test_StrategyModule")
    tqm = 2
    strategy = StrategyModule(tqm)
    print("_host_pinned :: ", strategy._host_pinned)
    strategy._send_heartbeat()
    assert strategy._host_pinned == True

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:33:21.940594
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-21 07:33:23.511043
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm is not None

# Generated at 2022-06-21 07:33:25.741159
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    assert StrategyModule

# Generated at 2022-06-21 07:33:27.114479
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  assert StrategyModule.__init__

# Generated at 2022-06-21 07:33:29.824625
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'


# Generated at 2022-06-21 07:33:32.795035
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.loader import strategy_loader
    print(strategy_loader)
    test = strategy_loader.get('host_pinned',None)()
    print(test)

# Generated at 2022-06-21 07:33:36.036127
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = []
    s = StrategyModule(tqm)
    assert s is not None

# Generated at 2022-06-21 07:33:39.177581
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert (StrategyModule is not None)

    instance = StrategyModule(None)
    assert (instance is not None)


# Generated at 2022-06-21 07:33:43.780023
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    tqm = TaskQueueManager(None)
    strategy_module = StrategyModule(tqm)
    assert isinstance(strategy_module, StrategyModule)
    print("Passed")
    
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:34:25.586249
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:34:28.836562
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:34:30.406773
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-21 07:34:31.784829
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule('tqm')

# Generated at 2022-06-21 07:34:32.745551
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__ is not FreeStrategyModule.__init__

# Generated at 2022-06-21 07:34:33.834171
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    this_host_pinned = StrategyModule(tqm)
    assert isinstance(this_host_pinned._host_pinned, bool)

# Generated at 2022-06-21 07:34:34.917847
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True
    return True

# Generated at 2022-06-21 07:34:35.458313
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	pass

# Generated at 2022-06-21 07:34:38.368176
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global display
    tqm = display
    strategy = StrategyModule(tqm)
    assert strategy is not None

# Generated at 2022-06-21 07:34:40.753903
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule()
    assert module._host_pinned == True

# Generated at 2022-06-21 07:36:01.947797
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = Dummy()
    StrategyModule(tqm)



# Generated at 2022-06-21 07:36:04.109550
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned

# Generated at 2022-06-21 07:36:06.377187
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:36:07.999956
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule(None)

# Generated at 2022-06-21 07:36:09.983481
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x=StrategyModule(None)
    assert x._host_pinned == True

# Generated at 2022-06-21 07:36:12.780099
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule('test_tqm')
    assert strategyModule._host_pinned == True

# Generated at 2022-06-21 07:36:15.004833
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  strategy = StrategyModule(None)
  assert strategy._host_pinned

# Generated at 2022-06-21 07:36:20.918380
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    # Test the method __init__() of class StrategyModule
    expected = True
    actual = obj._host_pinned
    assert actual == expected, 'Test Failed: Expected: "%s", Actual: "%s"' % (expected, actual)



# Generated at 2022-06-21 07:36:21.575359
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:36:23.652491
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-21 07:39:34.878279
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-21 07:39:36.656866
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned


__all__ = ['StrategyModule']

# Generated at 2022-06-21 07:39:38.416791
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None

# Generated at 2022-06-21 07:39:39.403181
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:39:40.533641
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == True

# Generated at 2022-06-21 07:39:43.231500
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule("tqm")
    assert sm._host_pinned == True

# Generated at 2022-06-21 07:39:46.232942
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(object)
    assert(strategy_module._host_pinned is True)

# Generated at 2022-06-21 07:39:47.018039
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(), StrategyModule)

# Generated at 2022-06-21 07:39:49.484881
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm = True)
    print(strategy_module._host_pinned)

# Generated at 2022-06-21 07:39:52.841583
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(object)
    assert obj._host_pinned == True
    assert obj._tqm is object