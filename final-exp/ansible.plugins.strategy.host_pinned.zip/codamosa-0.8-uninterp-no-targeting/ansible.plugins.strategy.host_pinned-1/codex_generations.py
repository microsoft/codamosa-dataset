

# Generated at 2022-06-21 07:30:06.028889
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert FreeStrategyModule.__name__ == 'FreeStrategyModule'

# Generated at 2022-06-21 07:30:07.832244
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    a = StrategyModule(tqm)
    assert hasattr(a, '_host_pinned')
    assert a._host_pinned == True

# Generated at 2022-06-21 07:30:13.360248
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        # This is expected to fail, since the TQM is None
        StrategyModule(TQM=None)
    except TypeError as e:
        assert "__init__() missing 1 required positional argument" in str(e)

# Generated at 2022-06-21 07:30:14.805175
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Generated at 2022-06-21 07:30:15.811440
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:30:16.520107
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:30:17.330070
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:30:28.993307
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.playbook import PlayBook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    playbook = PlayBook("host_pinned")
    playbook.add_host("host01")
    print("Created playbook: {0}".format(playbook))
    # print("Type of playbook: {0}".format(type(playbook)))

    play = Play()
    play.add_host("host02", "host03", "host04")
    print("Created play: {0}".format(play))
    # print("Type of play: {0}".format(type(play)))

    task_1 = Task()
    task_1.action = "setup"

# Generated at 2022-06-21 07:30:33.716051
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None
    assert StrategyModule.__init__.__doc__ is not None
    assert StrategyModule._host_pinned is True
    assert FreeStrategyModule is not None

# Generated at 2022-06-21 07:30:34.543515
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:30:39.221717
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.display import Display
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    display = Display()
    tqm = None
    strategy = StrategyModule(tqm)
    assert isinstance(strategy, FreeStrategyModule)

# Generated at 2022-06-21 07:30:40.527107
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(1)

# Generated at 2022-06-21 07:30:43.951691
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModuleObj = StrategyModule(tqm=None)
    assert strategyModuleObj._host_pinned == True



# Generated at 2022-06-21 07:30:48.459056
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm='tqm')
    assert strategy_module.__str__() == 'host_pinned'
    assert strategy_module.get_host_queue_name('hostname') == 'hostname'

# Generated at 2022-06-21 07:30:53.138598
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    strategy = StrategyModule("tqm")
    assert strategy.__class__.__name__ == "StrategyModule"
    assert strategy.__class__.__bases__[0].__name__ == FreeStrategyModule.__name__
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:30:54.677627
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.vv("testing constructor of class StrategyModule")
    strategy_module = StrategyModule(None)



# Generated at 2022-06-21 07:30:55.734497
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.debug("Testing StrategyModule constructor")
    assert StrategyModule

# Generated at 2022-06-21 07:30:57.501994
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule("abc") != None

# Generated at 2022-06-21 07:30:59.189713
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''test_StrategyModule'''
    assert StrategyModule # Unit test for constructor of class StrategyModule

# Generated at 2022-06-21 07:31:02.182318
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        c = StrategyModule(1) # int type
    except ValueError:
        print("strategy_module class constructor only takes 'TaskQueueManager' class as its argument")

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:31:04.799771
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = StrategyModule('tqm')
    assert host._host_pinned

# Generated at 2022-06-21 07:31:09.843226
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM:
      pass
    tqm = TestTQM()
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned

# Generated at 2022-06-21 07:31:11.246850
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy



# Generated at 2022-06-21 07:31:23.195370
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.strategy.free import StrategyModule
    from ansible.plugins.strategy.linear import StrategyModule
    from ansible.plugins.strategy.debug import StrategyModule
    from ansible.plugins.strategy.linear import StrategyModule
    from ansible.plugins.strategy.debug import StrategyModule
    from ansible.plugins.strategy.free import StrategyModule
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.utils.display import Display
    from ansible.utils.display import Display
    from ansible.utils.display import Display
    module = StrategyModule()
    module = StrategyModule()
    module = StrategyModule

# Generated at 2022-06-21 07:31:26.025680
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    test = StrategyModule(tqm='tqm')
    assert test._host_pinned == True, 'Host pinned value not set to true'


# Generated at 2022-06-21 07:31:27.972224
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule()
    assert module


# Generated at 2022-06-21 07:31:28.786825
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:31:31.162000
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy.get_host_pinned() == True

# Generated at 2022-06-21 07:31:35.486630
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module != None

# Test for Host pinned strategy module's _wait_on_pending_results method

# Generated at 2022-06-21 07:31:41.129034
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import task_queue_manager

    test_tqm = task_queue_manager.TaskQueueManager(None, None)
    strategy_instance = StrategyModule(test_tqm)

    assert hasattr(strategy_instance, '_host_pinned')
    assert strategy_instance._host_pinned == True and type(strategy_instance._host_pinned) == bool

# Generated at 2022-06-21 07:31:54.733512
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import sys
    import __main__ as main
    main.CLI = lambda: None
    main.CLI.options = lambda: None
    main.CLI.options.module_path = []
    main.CLI.options.forks = 10
    main.CLI.options.listhosts = None
    main.CLI.options.listtasks = None
    main.CLI.options.listtags = None
    main.CLI.options.syntax = None
    main.CLI.options.connection = None
    main.CLI.options.module_path = None
    main.CLI.options.forks = None
    main.CLI.options.remote_user = None
    main.CLI.options.private_key_file = None
    main.CLI.options.ssh_common_args = None

# Generated at 2022-06-21 07:31:56.362506
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   strategyModule = StrategyModule(None)

# Generated at 2022-06-21 07:31:59.201449
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    assert StrategyModule


# Generated at 2022-06-21 07:32:00.007338
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-21 07:32:11.001788
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test case:
    # 1. test construction of StrategyModule with correct parameters
    # 2. test construction of StrategyModule with wrong number of parameters (should raise TypeError)
    # 3. test construction of StrategyModule with wrong type of parameters (should raise TypeError)

    # test case 1:
    strategy_mod = StrategyModule('TaskQueueManager')
    assert strategy_mod._host_pinned == True

    # test case 2:
    #args_wrong_len = ['', '', '']
    #Test with different number of parameters
    #test cases where number of parameters is lesser than required
    #if len(args_wrong_len[:-1]) < 1:
    #    try:
    #        StrategyModule(args_wrong_len[:-1])
    #    except TypeError:
    #        assert True
    #elif len(args

# Generated at 2022-06-21 07:32:14.045173
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm._host_pinned == True


# Generated at 2022-06-21 07:32:24.866204
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.display import Display
    display = Display()

# Generated at 2022-06-21 07:32:31.551333
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule
    assert StrategyModule.__name__ == "StrategyModule"
    assert StrategyModule.__module__ == "ansible.plugins.strategy.host_pinned"
    assert StrategyModule.__bases__ == (FreeStrategyModule,)
    assert sm
    assert sm._host_pinned
    assert sm._host_pinned is True

# Test strategy behavior

# Generated at 2022-06-21 07:32:33.403228
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned == True
    return strategy

# Generated at 2022-06-21 07:32:34.580767
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-21 07:32:44.450262
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(), StrategyModule)


# Generated at 2022-06-21 07:32:46.122462
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-21 07:32:48.434405
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm = None)
    assert strategy_module

# Generated at 2022-06-21 07:32:51.348672
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule(tqm=None)
    except Exception as exception:
        assert False, "Exception raised: %s" % exception
    else:
        assert True

# Generated at 2022-06-21 07:32:52.160480
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:32:55.739134
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    test_tqm = {}
    assert StrategyModule(test_tqm)

# Generated at 2022-06-21 07:32:58.522317
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(MockTQM())
    assert strategy._host_pinned == True


# Generated at 2022-06-21 07:33:00.142308
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)


# Generated at 2022-06-21 07:33:01.908631
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm="tqm")
# Test method StrategyModule.__init__

# Generated at 2022-06-21 07:33:04.405666
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    fsm = StrategyModule('')
    print(fsm._host_pinned)



# Generated at 2022-06-21 07:33:23.974408
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Inside test_StrategyModule")
    free_strategy_module = FreeStrategyModule()
    assert free_strategy_module is not None
    strategy_module = StrategyModule()
    assert strategy_module is not None
    print("Exiting test_StrategyModule")

# Generated at 2022-06-21 07:33:25.671431
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)

# Generated at 2022-06-21 07:33:27.595291
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule()
    assert module
    assert module._host_pinned == True

# Generated at 2022-06-21 07:33:32.337638
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "test_tqm"
    strategy = StrategyModule(tqm)

    assert strategy._tqm is "test_tqm"
    assert strategy._host_pinned is True


# Generated at 2022-06-21 07:33:38.641485
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Unit test for constructor of class StrategyModule"""
   #  pylint: disable=unused-variable
    fake_tqm = {}
    # Creates an object of class StrategyModule
    StrategyModule(fake_tqm)

# class StrategyModule ends here


# Generated at 2022-06-21 07:33:43.816930
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mock_tqm = MockTQM()
    strategy_module = StrategyModule(mock_tqm)
    assert strategy_module._host_pinned == True
    assert strategy_module.__init__(mock_tqm) == None

# Mock class for testing, uses dummy placeholder value for tqm

# Generated at 2022-06-21 07:33:46.062916
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   pass


# Generated at 2022-06-21 07:33:47.050623
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result = StrategyModule()
    assert result._host_pinned == True

# Generated at 2022-06-21 07:33:56.590603
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = TQM(
        None,
        inventory=InventoryManager(loader=None, sources='localhost,'),
        variable_manager=VariableManager(),
        loader=DataLoader(),
        options=Options(listtags=False, listtasks=False, listhosts=False, syntax=False, connection='local', module_path=None, forks=100, remote_user='test', private_key_file=None, ssh_common_args=None, ssh_extra_args=None, sftp_extra_args=None, scp_extra_args=None, become=False, become_method=None, become_user='root', verbosity=None, check=False),
        passwords={},
    )
    test_strategy = StrategyModule(test_tqm)
    assert test_strategy._host_pinned

# Generated at 2022-06-21 07:34:03.729981
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global display
    display = Display()
    class Dummy():
        def __init__(self, *args, **kwargs):
            pass
    tqm = Dummy()
    print("test_StrategyModule")
    StrategyModule(tqm)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:34:53.169857
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Constructor of StrategyModule class must initialize self._host_pinned
    to True and self._step to 0
    '''
    task_queue_manager = None
    strategy_module = StrategyModule(task_queue_manager)
    assert(strategy_module._host_pinned == True)
    assert(strategy_module._step == 0)

# Generated at 2022-06-21 07:35:00.107382
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor import task_queue_manager
    tqm = task_queue_manager.TaskQueueManager(
    inventory=None,
    variable_manager=variable_manager,
    loader=loader,
    options=None,
    passwords=None,
    stdout_callback=None,
    run_additional_callbacks=True,
    run_tree=False,
    )
    o = StrategyModule(tqm)
    assert o != None, "could not construct StrategyModule"

# Generated at 2022-06-21 07:35:04.131212
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule")
    global strategy_obj
    strategy_obj = StrategyModule()
    print(strategy_obj)

# Generated at 2022-06-21 07:35:08.683233
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class test_class:
        # This is a dummy class for the purpose of unit testing...
        def __init__(self):
            self.host_pinned = False
    obj = test_class()
    tqm = obj
    StrategyModule(tqm)
    assert obj.host_pinned == True

# Generated at 2022-06-21 07:35:10.941830
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:35:15.095804
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned == True

# vim: set et ts=4 sw=4 ft=python:

# Generated at 2022-06-21 07:35:17.700381
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    tqm = {}
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:35:21.020252
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = dict()
    strategy_module = StrategyModule(tqm)

    assert strategy_module._host_pinned

# Generated at 2022-06-21 07:35:22.529362
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = 'tqm'
    sm = StrategyModule(test_tqm)
    assert sm.tqm == test_tqm
    assert sm._host_pinned == True

# Generated at 2022-06-21 07:35:26.408024
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule()
    except Exception as e:
        print(e)
        assert False
    else:
        assert True

# Generated at 2022-06-21 07:36:46.911152
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm._host_pinned == True

# Generated at 2022-06-21 07:36:48.941602
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned = StrategyModule()
    assert host_pinned is not None

# Generated at 2022-06-21 07:36:51.445918
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm='test')

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:36:54.975440
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor")
    tqm = None
    obj = StrategyModule(tqm)
    assert obj is not None

# Generated at 2022-06-21 07:36:55.796071
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:36:58.009502
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '__init__')

# Generated at 2022-06-21 07:37:00.287443
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = StrategyModule(tqm)
    assert host._host_pinned

# Generated at 2022-06-21 07:37:03.865259
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Creating object for StrategyModule
    strategy_module = StrategyModule()
    # Prints the object's attribute _host_pinned
    print("\nAttribute '_host_pinned' is :",
          strategy_module._host_pinned)
    

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-21 07:37:12.750579
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import sys
    import unittest

    class TestStrategyModule(unittest.TestCase):
        def test_constructor_StrategyModule(self):
            try:
                import ansible.plugins.strategy.host_pinned
            except Exception as e:
                self.fail('Unable to import ansible.plugins.strategy.host_pinned: {0}'.format(e))

    # Run unit test
    unittest.main(argv=[sys.argv[0]])

# Generated at 2022-06-21 07:37:15.181676
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test with the following values
    tqm = None
    assert StrategyModule(tqm)

