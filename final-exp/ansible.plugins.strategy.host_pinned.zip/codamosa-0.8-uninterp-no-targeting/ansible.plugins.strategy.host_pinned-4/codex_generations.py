

# Generated at 2022-06-21 07:30:07.188778
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.utils.display import Display
    tqm = object()
    sm = StrategyModule(tqm)
    assert sm._display == Display()
    assert sm._tqm == tqm

# Generated at 2022-06-21 07:30:08.439394
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-21 07:30:10.819130
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    assert FreeStrategyModule
    assert StrategyModule.__init__

# Generated at 2022-06-21 07:30:13.642113
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_mod = StrategyModule("tqm")
    assert strategy_mod._host_pinned == True

# Generated at 2022-06-21 07:30:15.087247
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(1)

# Generated at 2022-06-21 07:30:17.101120
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	display = Display()
	host_pinned = StrategyModule(display)
	assert host_pinned == host_pinned

# Generated at 2022-06-21 07:30:21.081308
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)
    print("Success: Constructor of StrategyModule is working as expected!")

test_StrategyModule()

# Generated at 2022-06-21 07:30:25.362503
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    try:
        assert strategy_module._host_pinned == True
    except Exception:
        raise Exception("Error creating instance of class StrategyModule")



# Generated at 2022-06-21 07:30:26.611915
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  assert(StrategyModule)

# Generated at 2022-06-21 07:30:27.491055
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:30:35.730956
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Unit test for constructor of class StrategyModule"""
    # tqm is AnsibleTaskQueueManager
    from ansible.plugins.strategy import StrategyModule
    # dm is AnsibleTaskQueueManager
    dm = StrategyModule.__init__(StrategyModule, tqm)
    assert dm.host_pinned == True

# Generated at 2022-06-21 07:30:37.346571
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm = None)
    assert strategy._host_pinned

# Generated at 2022-06-21 07:30:39.676630
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(tqm=object), object)

# Generated at 2022-06-21 07:30:40.631381
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:30:46.751577
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from collections import namedtuple
    from ansible.plugins.strategy.host_pinned import StrategyModule
    TQM = namedtuple('TQM', ['hostvars', '_workers', '_inventory', 'stats'])
    tqm = TQM({}, 0, {}, {})
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned


    def get_hosts_remaining_in_play(self):
        # using list lengths here as the actual hosts remaining in play
        # can vary during execution
        return len(self._block)

    def get_hosts_remaining_in_batch(self):
        return len(self._block)

    def get_active_hosts(self):
        return self._active_hosts


# Generated at 2022-06-21 07:30:55.560432
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost')
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-21 07:30:57.860425
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global StrategyModule
    StrategyModule(None)


# Generated at 2022-06-21 07:31:00.719714
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule), "StrategyModule extends FreeStrategyModule"

# Generated at 2022-06-21 07:31:02.165765
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert type(StrategyModule) == type

# Generated at 2022-06-21 07:31:03.672458
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-21 07:31:10.300534
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    tqm = object()
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned is True
    assert strategy._tqm is tqm



# Generated at 2022-06-21 07:31:11.809518
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule('test value')

# Generated at 2022-06-21 07:31:12.617896
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1==1, "test successful"

# Generated at 2022-06-21 07:31:14.816914
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ""
    StrategyModule(tqm)

# Generated at 2022-06-21 07:31:19.100536
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mock_tqm = MagicMock()
    strategyModule = StrategyModule(mock_tqm)
    assert strategyModule.display == Display()
    assert strategyModule._tqm == mock_tqm

# Generated at 2022-06-21 07:31:21.156256
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:31:21.953426
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule()

# Generated at 2022-06-21 07:31:23.982556
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    j = StrategyModule(None)
    assert isinstance(j, object)

# Generated at 2022-06-21 07:31:26.827209
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_instance = StrategyModule(tqm)
    assert strategy_instance


# Generated at 2022-06-21 07:31:29.438033
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule(tqm)
    assert x._host_pinned == True
    return x

test_StrategyModule()

# Generated at 2022-06-21 07:31:36.734396
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Constructor test of class StrategyModule.
    '''
    strategy = StrategyModule(tqm=None)
    
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:31:39.112192
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
        tqm = object()
        strategy = StrategyModule(tqm)
        assert strategy._host_pinned

# Generated at 2022-06-21 07:31:39.645451
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:31:40.721316
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    obj = StrategyModule(tqm)
    pass

# Generated at 2022-06-21 07:31:44.597275
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    print('Test StrategyModule init')
    tqm = object()
    s = StrategyModule(tqm)

# Generated at 2022-06-21 07:31:46.017688
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(1)._host_pinned is True

# Generated at 2022-06-21 07:31:47.764854
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    strategy = ansible.plugins.strategy.host_pinned.StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:31:49.897688
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm = "tqm")
    assert sm._host_pinned == True
    


# Generated at 2022-06-21 07:31:52.663974
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Testing constructor
    temp_strategy = StrategyModule()
    assert temp_strategy._host_pinned is True

# Generated at 2022-06-21 07:31:54.067474
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)

# Generated at 2022-06-21 07:32:07.961912
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # import StrategyModule
    from ansible.plugins.strategy.host_pinned import StrategyModule
    # test strategy__init__()
    test_tqm = ""                                 # type: str
    s = StrategyModule(test_tqm)                  # type: object
    assert s._host_pinned == True

# Generated at 2022-06-21 07:32:10.941537
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('\nTESTING StrategyModule constuctor...')

    display.verbosity = 4
    tqm = object()
    strategy_module = StrategyModule(tqm)

    assert hasattr(strategy_module, '_host_pinned')
    assert strategy_module._host_pinned == True

    print('DONE testing StrategyModule constructor.')

# Generated at 2022-06-21 07:32:14.804009
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '__init__')
    assert callable(StrategyModule.__init__)


# Generated at 2022-06-21 07:32:17.283762
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
     tqm = FreeStrategyModule()
     strategy = StrategyModule(tqm)
     assert strategy._host_pinned

# Generated at 2022-06-21 07:32:18.025098
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:32:26.468909
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    args = argparse.Namespace()
    args.listtags = False
    args.listtasks = False
    args.listhosts = False
    args.syntax = False
    args.connection = 'smart'
    args.module_path = None
    args.forks = 5
    args.remote_user = None
    args.private_key_file = None
    args.ssh_common_args = None
    args.ssh_extra_args = None
    args.sftp_extra_args = None
    args.scp_extra_args = None
    args.become = False
    args.become_method = None
    args.become_user = None
    args.verbosity = 0
    args.check = False
    args.diff = False
    args.inventory = None

# Generated at 2022-06-21 07:32:29.529504
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule('tqm')
    assert module._host_pinned

# Generated at 2022-06-21 07:32:31.986931
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None) is not None

# Test Attributes of class StrategyModule

# Generated at 2022-06-21 07:32:33.845081
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:32:34.970689
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-21 07:32:50.359943
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)



# Generated at 2022-06-21 07:32:52.776282
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule("test_tqm")

    assert hasattr(strategy, "_host_pinned") == True

# Generated at 2022-06-21 07:32:53.575491
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert not StrategyModule()

# Generated at 2022-06-21 07:32:56.736801
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #Unit test for strategy module.
    assert StrategyModule() is not None

# Generated at 2022-06-21 07:32:58.093698
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test class constructor
    s = StrategyModule('test_tqm')
    assert s._host_pinned == True

# Generated at 2022-06-21 07:32:59.586279
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__

# Generated at 2022-06-21 07:33:02.362775
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm)
    assert module.__doc__ == '''Executes tasks on each host without interruption'''
    assert module._host_pinned == True

# Generated at 2022-06-21 07:33:03.659617
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None) is not None

# Generated at 2022-06-21 07:33:06.133540
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__ is not FreeStrategyModule.__init__

# Generated at 2022-06-21 07:33:10.110321
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned is True

# Generated at 2022-06-21 07:33:46.659865
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Test StrategyModule with basic True values
    """
    pass

# Generated at 2022-06-21 07:33:55.359072
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock
    import __main__ as m
    m.display = Display()

    tqm = mock.MagicMock()
    tqm.send_callback.return_value = True
    tqm.RUN_STATE_PENDING = "RUN_STATE_PENDING"
    tqm.RUN_STATE_FAILED_HOSTS = "RUN_STATE_FAILED_HOSTS"
    tqm.RUN_STATE_DONE = "RUN_STATE_DONE"

    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-21 07:33:59.317276
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    TestModule = type("TestModule", (object,), {})
    TestModule.tasks = [{"name": "test"}]
    task_queue_manager = TestModule()
    host_pinned_instance = StrategyModule(task_queue_manager)
    assert isinstance(host_pinned_instance, StrategyModule) is True
    assert host_pinned_instance._host_pinned is True
    assert host_pinned_instance._display is Display()
    assert host_pinned_instance._hosts is None
    assert host_pinned_instance._batch_count is None
    assert host_pinned_instance._batch_hosts is None
    assert host_pinned_instance._batched_loop is None
    assert host_pinned_instance._results_callback is None
    assert host_pinned_instance._final_q is None

# Generated at 2022-06-21 07:34:06.221262
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create an instance of the TaskQueueManager
    from ansible.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None,
    )

    # Create an instance of the StrategyModule
    strategy = StrategyModule(tqm)

    # Compare the __init__ method values with expected results.
    assert strategy._host_pinned is True

# Generated at 2022-06-21 07:34:07.993475
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(1)


# Generated at 2022-06-21 07:34:10.774923
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("test_tqm")
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:34:14.843545
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   strategy_module =  StrategyModule(tqm)
   assert strategy_module._host_pinned == True
   strategy_module =  StrategyModule(tqm)
   assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:34:15.557090
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-21 07:34:18.187705
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert(strategy)
    assert(strategy._host_pinned)

# Generated at 2022-06-21 07:34:20.256301
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)

# Generated at 2022-06-21 07:35:47.222806
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_object = StrategyModule(tqm)
    assert strategy_object is not None
    assert strategy_object is not None
    assert strategy_object.__class__.__name__ == 'StrategyModule'
    assert strategy_object._host_pinned


# Generated at 2022-06-21 07:35:49.375375
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm="something")
    assert strategy_module._host_pinned

# Generated at 2022-06-21 07:35:51.786687
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('pq')
    assert strategy_module.__init__ == 'pq'

# Generated at 2022-06-21 07:35:53.923731
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None

# Generated at 2022-06-21 07:36:05.088161
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import host_pinned
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import module_loader

    play_source =  dict(
            name = "Ansible Play TEST",
            hosts = 'localhost,',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='debug', args=dict(msg='TESTTASK'))),
            ]
        )

    play = Play().load(play_source, loader=module_loader)

    host = Host(name="localhost")
    tqm = None

# Generated at 2022-06-21 07:36:07.857456
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = Display()
    obj = StrategyModule(tqm)
    assert(obj is not None)

# Generated at 2022-06-21 07:36:10.776729
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert not strategy_module._host_pinned is None
# end of test_StrategyModule()

#

# Generated at 2022-06-21 07:36:12.780153
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy._host_pinned == True
    return True

# Generated at 2022-06-21 07:36:17.316776
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    stm = StrategyModule(None)
    assert stm._host_pinned == True
    assert stm.get_name() == 'host_pinned'



# Generated at 2022-06-21 07:36:18.906039
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule()



# Generated at 2022-06-21 07:39:33.214832
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm="tqm")

# Generated at 2022-06-21 07:39:36.894015
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    sm = ansible.plugins.strategy.host_pinned.StrategyModule(None)
    assert sm._display.verbosity > 0

# Generated at 2022-06-21 07:39:39.401683
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('tqm')
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:39:41.695769
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule() == 'host_pinned'

# Generated at 2022-06-21 07:39:51.166345
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test")
'''
    def run(self, iterator, play_context):
        '''

# Generated at 2022-06-21 07:40:00.859028
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import PlayBook
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible import context
    import os
    import sys
    import unittest

    from ansible.executor.task_queue_manager import TaskQueueManager

    class TestTaskQueueManager(unittest.TestCase):
        def setUp(self):
            context.CLIARGS = {'module_path': '', 'forks': 10, 'become': False, 'become_method': 'sudo', 'become_user': 'root', 'check': False, 'diff': False}
            self._inventory = Inventory(
                host_list='tests/inventory'
            )


# Generated at 2022-06-21 07:40:09.148946
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.display import Display
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager

    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
    )
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True
    assert isinstance(strategy, FreeStrategyModule)