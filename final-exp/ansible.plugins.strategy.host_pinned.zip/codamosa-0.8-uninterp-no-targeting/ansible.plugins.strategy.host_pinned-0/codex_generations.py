

# Generated at 2022-06-21 07:30:07.491701
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pattern = '*'
    pattern = 'all'
    inventory = 'inventory'
    ds = 'ds'
    tqm = 'tqm'
    s = StrategyModule(tqm)
    assert s._host_pinned == True

# Generated at 2022-06-21 07:30:12.389226
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager()

    pinned = StrategyModule(tqm)
    assert pinned._host_pinned == True



# Generated at 2022-06-21 07:30:16.238059
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        obj=StrategyModule(tqm)
        print(obj.__init__)
    except Exception as e:
        print(str(e))


# Generated at 2022-06-21 07:30:17.636502
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule()
    assert tqm._host_pinned == True


# Generated at 2022-06-21 07:30:26.277189
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest as ut
    import ansible.plugins.strategy.host_pinned as hp
    import ansible.utils.display as du
    import ansible.plugins.strategy.free as fr
    display = du.Display()
    strategyModule = hp.StrategyModule(display)
    ut.TestCase(strategyModule).assertEqual(type(strategyModule), fr.StrategyModule)

# Generated at 2022-06-21 07:30:26.800404
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:30:33.231811
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned as host_pinned
    tqm = mock.Mock()
    tqm.send_callback.return_value = None
    host_pinned.StrategyModule(tqm)
# end of unit test for constructor of class StrategyModule



# Generated at 2022-06-21 07:30:34.093527
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:30:36.820251
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    obj = StrategyModule(tqm)
    assert obj is not None

# Generated at 2022-06-21 07:30:50.497760
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import constants as C
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.inventory import Inventory
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    def get_host_pinned():
        return True

    def set_host_pinned(pinned):
        pass

    test_host = Host(name="test_host")
    test_host.set_variable("ansible_connection", "local")
    test_

# Generated at 2022-06-21 07:30:51.903602
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:30:52.712177
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	pass

# Generated at 2022-06-21 07:30:56.802953
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm=StrategyModule(test_tqm_instance)
    assert hasattr(sm,'_host_pinned')
    assert sm._host_pinned == True

# Generated at 2022-06-21 07:31:04.680149
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-21 07:31:05.068728
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:31:06.241225
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm is not None
    assert sm._host_pinned

# Generated at 2022-06-21 07:31:09.843259
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  strategy = StrategyModule()
  assert strategy._host_pinned


# Generated at 2022-06-21 07:31:10.851389
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__.__doc__

# Generated at 2022-06-21 07:31:14.374225
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(tqm=__import__('sys').modules[__name__])
    assert isinstance(a, StrategyModule)



# Generated at 2022-06-21 07:31:16.346510
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:31:20.792143
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Testing StrategyModule constructor')
    StrategyModule()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-21 07:31:25.282555
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__, "StrategyModule.__doc__ is empty"
    assert StrategyModule.__init__.__doc__, "StrategyModule.__init__.__doc__ is empty"

# Generated at 2022-06-21 07:31:26.101267
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-21 07:31:27.468320
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None

# Generated at 2022-06-21 07:31:29.763483
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(None)
    # assert type(module._host_pinned) == Boolean
    assert module._host_pinned == True

# Generated at 2022-06-21 07:31:32.792574
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

if __name__ == '__main__':
    print('Test successfully completed!')

# Generated at 2022-06-21 07:31:34.849720
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)


# Generated at 2022-06-21 07:31:38.153427
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.display(display.verbosity, "test_StrategyModule")
    tqm = None
    strategy_mod = StrategyModule(tqm)
    assert strategy_mod._host_pinned == True, "Expected True"

# Generated at 2022-06-21 07:31:39.602984
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test whether class StrategyModule can be instantiated
    assert StrategyModule

# Generated at 2022-06-21 07:31:41.246491
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO
    assert True == True

# Generated at 2022-06-21 07:31:46.350821
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:31:47.713810
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_instance = StrategyModule(tqm=None)

# Generated at 2022-06-21 07:31:48.489691
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == True

# Generated at 2022-06-21 07:31:49.847636
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert not StrategyModule(tqm=None)



# Generated at 2022-06-21 07:31:52.664806
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    st = StrategyModule(tqm=None)
    assert st._host_pinned is True

# Generated at 2022-06-21 07:31:53.817666
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:31:55.517813
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # creating a StrategyModule instance
    tqm = None
    s = StrategyModule(tqm)
    # verifying the value of _host_pinned set to True
    assert s._host_pinned



# Generated at 2022-06-21 07:31:58.136909
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    from ansible.playbook.task_queue_manager import TaskQueueManager
    TaskQueueManager()

# Generated at 2022-06-21 07:31:59.354384
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ''' Test StrategyModule constructor '''
    tqm = MockTQM()
    raise NotImplementedError



# Generated at 2022-06-21 07:32:02.690274
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    for attr in ['_host_pinned']:
        assert hasattr(StrategyModule, attr)
        assert getattr(StrategyModule, attr) is True

# Generated at 2022-06-21 07:32:23.410573
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        import unittest.mock
        from ansible.plugins.strategy.host_pinned import StrategyModule
        from ansible.plugins.strategy.free import StrategyModule
    except ImportError:
        import mock
        from ansible.plugins.strategy.host_pinned import StrategyModule
        from ansible.plugins.strategy.free import StrategyModule
    test_tqm = mock.Mock()
    test_tqm.hosts = [mock.Mock(),mock.Mock()]
    test_strategy_module = StrategyModule(test_tqm)
    assert isinstance(test_strategy_module,FreeStrategyModule),"test_StrategyModule: test_strategy_module is not an instance of FreeStrategyModule"

# Generated at 2022-06-21 07:32:25.197828
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule('test_tqm')

# Generated at 2022-06-21 07:32:29.525580
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Constructor test of StrategyModule")
    tqm = (None)
    strat = StrategyModule(tqm)
    print("StrategyModule test complete")


# Generated at 2022-06-21 07:32:30.210964
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:32:33.845854
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = []
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned


# Generated at 2022-06-21 07:32:34.644588
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   pass

# Generated at 2022-06-21 07:32:37.050095
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:32:45.268772
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager

    # setup for test
    tqm = TaskQueueManager(
        inventory=Inventory(
            hosts=[
                Host(name='test1', groups=[Group('testgroup')]),
                Host(name='test2', groups=[Group('testgroup')])],
            groups=[]),
        variable_manager=VariableManager(),
        loader=None,
        options=None,
        passwords=None,
    )


# Generated at 2022-06-21 07:32:47.483184
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("StrategyModule object successfully created.")


# Generated at 2022-06-21 07:32:48.306080
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(TestStrat()) is not None


# Generated at 2022-06-21 07:33:12.149092
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    import ansible.plugins.strategy.free
    import ansible.plugins.strategy
    assert issubclass(StrategyModule, ansible.plugins.strategy.free.StrategyModule)
    assert issubclass(StrategyModule, ansible.plugins.strategy.StrategyBase)
    assert issubclass(StrategyModule, object)
    assert issubclass(StrategyModule, Display)

# Generated at 2022-06-21 07:33:14.815755
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule.__name__ == 'StrategyModule')


# Generated at 2022-06-21 07:33:16.918855
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)


# Generated at 2022-06-21 07:33:17.839018
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-21 07:33:20.723240
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(
            0,
        )
    assert obj._host_pinned == True



# Generated at 2022-06-21 07:33:22.426305
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.verbosity = 3
    assert StrategyModule(None)


# Generated at 2022-06-21 07:33:25.060908
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)

# vim: expandtab filetype=python

# Generated at 2022-06-21 07:33:25.918848
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert not StrategyModule()

# Generated at 2022-06-21 07:33:28.977488
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True


# Generated at 2022-06-21 07:33:30.580292
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)

# Generated at 2022-06-21 07:34:14.659355
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__(StrategyModule, tqm)

# Generated at 2022-06-21 07:34:16.605780
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy._host_pinned == True

# Generated at 2022-06-21 07:34:18.042743
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    SM = StrategyModule
    assert SM

# Generated at 2022-06-21 07:34:21.828276
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TaskQueueManager()
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:34:24.862228
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule("tqm")
    assert(sm is not None)
    assert(sm._host_pinned is True)

# Generated at 2022-06-21 07:34:29.484902
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from mock import Mock

    t = Mock(return_value = None)
    x = StrategyModule(tqm = t)
    assert x != None

# Generated at 2022-06-21 07:34:32.792215
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ""
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-21 07:34:35.505386
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result = StrategyModule(tqm = True)
    assert result != None

# vim: set et ts=4 sw=4

# Generated at 2022-06-21 07:34:37.856723
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    assert obj._host_pinned == True

# Generated at 2022-06-21 07:34:49.427967
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from collections import namedtuple
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.strategy.host_pinned import StrategyModule as HostPinnedStrategyModule
    import ansible.plugins.strategy.host_pinned
    import ansible.plugins.strategy.free
    import ansible.plugins.strategy
    import ansible.utils.display
    import ansible.utils.plugin_docs
    import en_US
    tqm = namedtuple('_tqm', '_final_q')
    assert isinstance(HostPinnedStrategyModule(tqm), StrategyModule)
    assert isinstance(ansible.plugins.strategy.host_pinned.StrategyModule(tqm), StrategyModule)

# Generated at 2022-06-21 07:36:11.332555
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert not StrategyModule(None)._host_pinned

# Generated at 2022-06-21 07:36:14.104873
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = "host"
    tqm = {"host": host}
    StrategyModule(tqm)

# Generated at 2022-06-21 07:36:24.001122
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible import constants as C

    ti = TaskIterator(PlayIterator(Play.load(dict(), None, None), None, None))

    C.HOST_PINNED = True

    strategy = StrategyModule(TaskQueueManager(None, None, ti, None, None, None))
    result = strategy._host_pinned

    assert result == True

    C.HOST_PINNED = False

    strategy = StrategyModule(TaskQueueManager(None, None, ti, None, None, None))
    result = strategy._host_pinned

    assert result == False

# Generated at 2022-06-21 07:36:35.181016
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import strategy_loader

    loader = DataLoader()

# Generated at 2022-06-21 07:36:38.658225
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule(1)
    test_object = StrategyModule(tqm)
    assert test_object._host_pinned == True

# Generated at 2022-06-21 07:36:40.590722
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    assert StrategyModule(tqm)

# Generated at 2022-06-21 07:36:43.626548
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True

# Test for filter_tasks method of class StrategyModule

# Generated at 2022-06-21 07:36:46.912183
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    info = StrategyModule.__init__.__doc__
    assert info != None


# Generated at 2022-06-21 07:36:55.179735
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.play_iterator import PlayIterator
    from ansible.errors import AnsibleError
    from collections import namedtuple

# Generated at 2022-06-21 07:36:58.009979
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm=None)
    assert s._host_pinned == True