

# Generated at 2022-06-25 12:08:49.987630
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert test_case_0() is None



# Generated at 2022-06-25 12:08:51.556195
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert test_case_0() == None

# Testing host_pinned strategy = True

# Generated at 2022-06-25 12:08:53.023512
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = ''
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 12:08:54.326894
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = ''
    strategy_module_1 = StrategyModule(str_1)


# Generated at 2022-06-25 12:08:55.468776
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # invoking constructor of class StrategyModule
    test_case_0()

# Generated at 2022-06-25 12:08:56.998816
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Unit test main
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:08:57.981383
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(None)


# Generated at 2022-06-25 12:08:59.782432
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.display(u'Test StrategyModule...')
    str_0 = ''
    obj_0 = StrategyModule(str_0)
    test_case_0()
    display.display(u'Test StrategyModule OK')

# Generated at 2022-06-25 12:09:01.459241
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = ''
    strategy_module_1 = StrategyModule(str_1)
    assert strategy_module_1 is not None
    assert strategy_module_1._host_pinned == True


# Generated at 2022-06-25 12:09:06.183197
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import copy
    from .test_module_0 import MOVE_IMPORT_TO_TOP
    from .test_module_0 import MOVE_IMPORT_TO_TOP
    from .test_module_0 import MOVE_IMPORT_TO_TOP
    from .test_module_0 import MOVE_IMPORT_TO_TOP
    from .test_module_0 import MOVE_IMPORT_TO_TOP
    from .test_module_0 import MOVE_IMPORT_TO_TOP
    from .test_module_0 import MOVE_IMPORT_TO_TOP
    from .test_module_0 import MOVE_IMPORT_TO_TOP
    from .test_module_0 import MOVE_IMPORT_TO_TOP
    from ansible.compat.tests import unittest


# Generated at 2022-06-25 12:09:09.082318
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:09:09.820146
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:09:12.249982
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mc_0 = ''
    strategy_module_0 = StrategyModule(mc_0)
    assert isinstance(strategy_module_0._host_pinned,bool) == True

test_case_0()
test_StrategyModule()

# Generated at 2022-06-25 12:09:20.496485
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as err:
        display.display('Exception: {}'.format(err))
        display.display('traceback.format_exc():\n{}'.format(traceback.format_exc()))

# Make coding more python3-ish
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

DOCUMENTATION = '''
    name: serial
    plugin_type: strategy
    short_description: Execute tasks in series
    description:
        - This plugin executes tasks in series.
    version_added: "2.2"
    author: Ansible Core Team
'''

from ansible.plugins.strategy import StrategyBase
from ansible.errors import AnsibleError
from ansible.utils.display import Display



# Generated at 2022-06-25 12:09:23.294064
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = 'StrategyModule'
    strategy_module_1 = StrategyModule(str_1)
    assert strategy_module_1._host_pinned == True
    pass

# Generated at 2022-06-25 12:09:24.251124
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test with arguments: str
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:09:26.637051
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm_0 = ansible_runner_0.get_tqm()
    test_case_0(tqm_0)


# Generated at 2022-06-25 12:09:28.931423
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = ''
    strategy_module_1 = StrategyModule(str_1)
    assert strategy_module_1._host_pinned == True



# Generated at 2022-06-25 12:09:30.686355
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = ''
    strategy_module_1 = StrategyModule(str_1)
    assert strategy_module_1 is not None

# Generated at 2022-06-25 12:09:32.338331
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule constructor")

    str_0 = ''
    strategy_module_0 = StrategyModule(str_0)

test_StrategyModule()

# Generated at 2022-06-25 12:09:35.017764
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    pass

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:09:40.928480
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # use a try block, as we can not expect the user to have all the required dependencies installed.
    try:
        test_case_0()
    except ImportError:
        raise
    return 0

if __name__ == '__main__':
    import sys
    # import traceback
    sys.exit(test_StrategyModule())

# Generated at 2022-06-25 12:09:41.847367
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(str) is not None

# Generated at 2022-06-25 12:09:44.488054
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule('str')
    assert strategy_module_0.get_host_pinned() == True


# Generated at 2022-06-25 12:09:46.369095
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = ''
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 12:09:47.235383
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    assert not (strategy_module_0 is None)


# Generated at 2022-06-25 12:09:49.278754
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 12:09:53.635174
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Make sure instance is created, using constructor
    try:
        test_case_0()
    except NameError:
        print('Unable to call constructor of class StrategyModule, make sure that all necessary variables are declared and/or imported.')
        return False
    return True


# Generated at 2022-06-25 12:09:54.810513
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-25 12:09:59.517778
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    u'test constructor of class StrategyModule'

    strs = '<ansible.plugins.strategy.host_pinned.StrategyModule object at 0x7f582e0c0790>'
    strategy_module = StrategyModule(strs)
    assert strategy_module._host_pinned, "The constructor of class StrategyModule is error."




# Generated at 2022-06-25 12:10:05.716739
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Test constructor')
    strategy_module_0 = StrategyModule('Test String')
    assert strategy_module_0._host_pinned == True
    assert strategy_module_0._tqm == 'Test String'

# Generated at 2022-06-25 12:10:15.856157
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
        test_result_0 = "Succeed"
    except AssertionError as ae:
        display.error("Error occurred\n{}".format(str(ae)))
        test_result_0 = "Failed"
    except Exception as e:
        display.error("Error occurred\n{}".format(str(e)))
        test_result_0 = "Failed"
    finally:
        display.info("Unit test result for constructor : {}".format(test_result_0))


# Execute Test Cases
if __name__ == "__main__":
    display.info("========== Execute test cases for constructor ==========")
    test_StrategyModule()
    display.info("========== End of test cases for constructor ==========")

# Generated at 2022-06-25 12:10:18.026292
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = ''
    strategy_module_1 = StrategyModule(str_1)
    assert isinstance(strategy_module_1, StrategyModule)


# Generated at 2022-06-25 12:10:18.869271
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:10:24.351012
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = ''
    strategy_module_0 = StrategyModule(str_0)

import os
from ansible.plugins.strategy import host_pinned
import ansible.plugins.strategy.host_pinned
from ansible.plugins.strategy.host_pinned import StrategyModule
from ansible.plugins.strategy.host_pinned import test_StrategyModule

from ansible.plugins.strategy.host_pinned import test_case_0
# We are going to test all of the classes within this file
# There is not cases in which the constructor is called directly
from ansible.plugins.strategy.host_pinned import StrategyModule

# Generated at 2022-06-25 12:10:28.961494
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Make sure the test is only run if we are using the host_pinned strategy
    # The dummy strategy that is used in ansible-test is the host_pinned strategy
    if 'host_pinned' in C.DEFAULT_STRATEGY:
        test_case_0()



# Generated at 2022-06-25 12:10:33.001381
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = ''
    strategy_module_0 = StrategyModule(str_0)
    assert strategy_module_0._host_pinned is True
    assert strategy_module_0._serialized_tasks is True
    assert strategy_module_0._run_once is True


# Generated at 2022-06-25 12:10:34.352574
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = ''
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 12:10:35.794165
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Constructor of class StrategyModule called with parameter (str)
    test_case_0()


# Generated at 2022-06-25 12:10:39.508722
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        str_0 = ''
        strategy_module_0 = StrategyModule(str_0)
        print("test_StrategyModule, Success")
    except Exception as e:
        print("test_StrategyModule, Fail")
    finally:
        pass


# Generated at 2022-06-25 12:10:48.174548
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = ''
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 12:10:51.576134
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #Sets member variable _host_pinned to True
    str_1 = ''
    strategy_module_1 = StrategyModule(str_1)
    assert strategy_module_1._host_pinned == True

#Unit test for method run()

# Generated at 2022-06-25 12:10:53.938883
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    func_name = '___test_StrategyModule___'
    msg = func_name + '. Test case 0 failed'
    test_case_0()
    print(msg)

test_StrategyModule()

# Generated at 2022-06-25 12:10:56.818471
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('test_StrategyModule')
    # str_0 = ''
    # strategy_module_0 = StrategyModule(str_0)
    #
    # assert strategy_module_0._host_pinned

# Generated at 2022-06-25 12:10:59.466602
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert strategy_module_0._host_pinned == True



# Generated at 2022-06-25 12:11:03.709678
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = ''
    strategy_module_1 = StrategyModule(str_1)
    print(strategy_module_1.__doc__)
    assert strategy_module_1._host_pinned == True

# Generated at 2022-06-25 12:11:09.804774
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = ''
    strategy_module_0 = StrategyModule(str_0)
    strategy_module_0.get_next_task_lock()
    strategy_module_0.send_callback()
    strategy_module_0.queue_task()
    strategy_module_0.get_next_task()
    strategy_module_0._wait_on_pending_results()
    strategy_module_0.run_handlers()
    strategy_module_0.run_flush_handlers()
    strategy_module_0.run_queue()

# Generated at 2022-06-25 12:11:11.497381
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-25 12:11:23.061277
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = ''
    strategy_module_0 = StrategyModule(str_0)

    assert_equal(strategy_module_0._host_pinned, True, 'Failed to initialize StrategyModule._host_pinned!')
    assert_equal(strategy_module_0.variable_manager, None, 'Failed to initialize StrategyModule.variable_manager!')
    assert_equal(strategy_module_0.loader, None, 'Failed to initialize StrategyModule.loader!')
    assert_equal(strategy_module_0.inventory, None, 'Failed to initialize StrategyModule.inventory!')
    assert_equal(strategy_module_0.run_context, None, 'Failed to initialize StrategyModule.run_context!')

# Generated at 2022-06-25 12:11:23.620278
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'veer'
    StrategyModule(str_0)

# Generated at 2022-06-25 12:11:38.565923
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = ''
    strategy_module_0 = StrategyModule(str_0)
#

# Generated at 2022-06-25 12:11:41.617415
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = ''
    strategy_module_0 = StrategyModule(str_1)
    assert strategy_module_0._host_pinned == True



# Generated at 2022-06-25 12:11:42.414578
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:11:43.476900
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = ''
    strategy_module_0 = StrategyModule(str_0)

# Generated at 2022-06-25 12:11:45.088148
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm_0 = {}
    test_case_0()
    test_case_1()
    test_case_2()


# Generated at 2022-06-25 12:11:47.757281
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    # Assert type of "strategy_module_0" is StrategyModule
    assert(isinstance(strategy_module_0, StrategyModule))


# Generated at 2022-06-25 12:11:48.557929
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:11:51.124769
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display0 = Display()
    str0 = ''
    strategy_module_0 = StrategyModule(str0)
    assert len(strategy_module_0._tqm._final_q) == 0

# Generated at 2022-06-25 12:11:51.910139
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:11:59.832360
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = ''
    strategy_module_0 = StrategyModule(str_0)
    assert type(strategy_module_0).__name__ == StrategyModule.__name__
    assert hasattr(strategy_module_0, '_host_pinned')
    assert hasattr(strategy_module_0, '_cleanup_processes')
    assert callable(strategy_module_0._cleanup_processes)
    assert hasattr(strategy_module_0, '_vault_id_matches')
    assert callable(strategy_module_0._vault_id_matches)
    assert hasattr(strategy_module_0, '_display_callback_banner')
    assert callable(strategy_module_0._display_callback_banner)

# Generated at 2022-06-25 12:12:39.047055
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as e:
        display.error(e)

# Generated at 2022-06-25 12:12:44.381030
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = ''
    strategy_module_0 = StrategyModule(str_0)

strategy_module_0 = StrategyModule(str_0)
test_case_0()
#test_StrategyModule()

# Generated at 2022-06-25 12:12:47.824144
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    str_0 = ''
    strategy_module_0 = StrategyModule(str_0)
    display.display('strategy_module_0 is %s' % strategy_module_0)


# Generated at 2022-06-25 12:12:50.418257
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Load test cases

# Generated at 2022-06-25 12:12:52.037716
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print('success')

# Local variables:
# compile-command: "pytest -v test_strategy_host_pinned.py")
# End:

# Generated at 2022-06-25 12:12:52.643197
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:12:56.011948
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global display
    test_case_0()
    # Assert that all tasks finished
    assert display.display_messages==[], 'Expected {} but got {}'.format([],display.display_messages)
    # Return a result
    return 1

# Generated at 2022-06-25 12:12:56.882359
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)

# Generated at 2022-06-25 12:12:59.635732
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_queue_items_0 = dict()
    strategy_module_0 = StrategyModule(host_queue_items_0)
    test_case_0()

# vim: expandtab filetype=python

# Generated at 2022-06-25 12:13:00.964605
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception:
        display.warning('Unit test for constructor of class StrategyModule failed.')
        raise

# Generated at 2022-06-25 12:14:21.140740
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = ''
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 12:14:22.649117
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = ''
    strategy_module_1 = StrategyModule(str_1)


# Generated at 2022-06-25 12:14:23.327759
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:14:25.312844
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except AttributeError as err:
        print(err)
        assert False

# Generated at 2022-06-25 12:14:25.978416
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 0 == 0

# Generated at 2022-06-25 12:14:27.572794
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # def __init__(self, tqm):
    str_0 = ''
    strategy_module_0 = StrategyModule(str_0)



# Generated at 2022-06-25 12:14:30.124745
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = ''
    strategy_module_0 = StrategyModule(str_0)



# Generated at 2022-06-25 12:14:32.084567
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # AnsibleHost
    tqm = AnsibleHost()


    # StrategyModule
    strategy_module = StrategyModule(tqm)

    assert strategy_module is not None


# Generated at 2022-06-25 12:14:33.186239
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    unit_test = StrategyModule('')
    assert unit_test._host_pinned is True
    return None

# Generated at 2022-06-25 12:14:34.500767
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = ''
    strategy_module_1 = StrategyModule(str_1)

test_case_0()
test_StrategyModule()

# Generated at 2022-06-25 12:17:43.620213
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-25 12:17:45.540934
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_m = ''
    strategy_m = StrategyModule(str_m)


# Generated at 2022-06-25 12:17:49.346632
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.free import StrategyModule
    strategy_module_0 = StrategyModule()
    strategy_module_0.next_task_for_host('')
    strategy_module_0.move_to_front('')
    strategy_module_0.get_next_serialized_task('')
    strategy_module_0.get_next_task_lockstep('')
    strategy_module_0.get_next_task('')
    str_0 = ''
    strategy_module_0 = StrategyModule(str_0)
    str_1 = ''
    strategy_module_0 = StrategyModule(str_1)


# Generated at 2022-06-25 12:17:50.686410
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Call constructor of class StrategyModule with argument str_0
    test_case_0()


# Generated at 2022-06-25 12:17:52.901827
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as e:
        print(e)


# ## main function invoked by nosetests ##
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:17:55.343175
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = ''
    strategy_module_0 = StrategyModule(str_0)

# Generated at 2022-06-25 12:17:56.457681
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.debug("TestConstructor")
    assert StrategyModule("str_0")


# Generated at 2022-06-25 12:17:58.568803
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Check that exception is correctly handled
    try:
        # For now, just pass
        test_case_0()
    except TypeError:
        # Should send appropriate message
        print('TypeError exception')
    
    

test_StrategyModule()

# Generated at 2022-06-25 12:17:59.551254
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO Use fixtures to setup the test environment
    # Case 0:
    test_case_0()

# Generated at 2022-06-25 12:18:01.207198
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = ''
    strategy_module_0 = StrategyModule(str_0)
    try:
        assert isinstance(strategy_module_0, object)
    except AssertionError as e:
        raise Exception(e)
