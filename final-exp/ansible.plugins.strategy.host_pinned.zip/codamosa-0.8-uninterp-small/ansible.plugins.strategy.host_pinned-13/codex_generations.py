

# Generated at 2022-06-25 12:08:50.076069
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None

    # Executing constructor of class StrategyModule.
    try:
        StrategyModule(bytes_0)
    except Exception:
        assert False, "Exception raised during executing test_case_0 of class StrategyModule"


# Generated at 2022-06-25 12:08:51.342112
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)

# Generated at 2022-06-25 12:08:54.194293
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    assert strategy_module_0.__class__ == StrategyModule
    assert strategy_module_0._host_pinned == True
    assert strategy_module_0._tqm == None


# Generated at 2022-06-25 12:08:55.641901
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:08:57.391636
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    assert strategy_module_0._host_pinned
    assert strategy_module_0.name == 'host_pinned'
    assert strategy_module_0.get_host_list() is None


# Generated at 2022-06-25 12:08:59.269960
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test: test_StrategyModule")
    strategy_module = StrategyModule(0)
    if not strategy_module:
        raise ValueError("Unable to create instance of class StrategyModule")
    if strategy_module._host_pinned != True:
        raise ValueError("Unable to initialize variable '_host_pinned' of class StrategyModule")


# Generated at 2022-06-25 12:09:00.073874
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-25 12:09:03.004537
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Assert if the constructor raises any exception
    assert test_case_0() is None

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:09:06.907699
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    assert isinstance(strategy_module_0, StrategyModule)
    assert hasattr(strategy_module_0, '_host_pinned')
    assert type(strategy_module_0._host_pinned) is bool


# Generated at 2022-06-25 12:09:09.901335
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    assert strategy_module_0._host_pinned == True


# Generated at 2022-06-25 12:09:14.459622
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    assert isinstance(strategy_module_0, StrategyModule)


# Generated at 2022-06-25 12:09:15.976927
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes = None
    strategy_module = StrategyModule(bytes)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-25 12:09:20.035465
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_1 = None
    StrategyModule(bytes_1) == StrategyModule


# Generated at 2022-06-25 12:09:26.508935
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    assert (strategy_module_0._host_queue == [])
    assert (strategy_module_0._in_flight == set())
    assert (strategy_module_0._pending_results == {})
    assert (strategy_module_0.workers == 5)
    assert (strategy_module_0.tqm == bytes_0)


# Generated at 2022-06-25 12:09:27.721792
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:09:29.424393
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)

# Generated at 2022-06-25 12:09:30.526990
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    assert True


# Generated at 2022-06-25 12:09:32.735674
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert test_case_0() == 0
    print('test_case_0 passed')

if __name__ == "__main__":
    """ Unit test of StrategyModule """
    test_StrategyModule()

# Generated at 2022-06-25 12:09:33.573261
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:09:34.565529
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    test_case_0()


# Generated at 2022-06-25 12:09:38.885124
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:09:40.878727
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    test_case_0()

# Generated at 2022-06-25 12:09:42.973301
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    del strategy_module_0

# Generated at 2022-06-25 12:09:45.355459
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    assert strategy_module_0 != None

# Generated at 2022-06-25 12:09:46.881808
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)

# Generated at 2022-06-25 12:09:50.276591
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    inventory = None
    loader = None
    variable_manager = None
    display = None
    options = None
    passwords = None
    strategy_module_0 = StrategyModule(inventory, loader, variable_manager, display, options, passwords)

# Generated at 2022-06-25 12:10:00.131072
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case = (
        test_case_0,
    )

    count = 0
    failures = 0

    for test_function in test_case:
        count += 1
        display.info()
        print('Test Case ' + str(count))
        try:
            test_function()
        except ImportError as e:
            display.warning(
                'Skipping test function {0} since module {1} could not be imported: {2}'.format(
                    test_function.__name__,
                    test_function.__module__,
                    str(e),
                )
            )
            continue
        except Exception as e:
            display.error('Test Case {0} FAILED'.format(count))
            print('Traceback (most recent call last):')
            print()
            import traceback
            trace

# Generated at 2022-06-25 12:10:02.143379
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    assert strategy_module_0._host_pinned == True


# Generated at 2022-06-25 12:10:03.100926
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)

# Generated at 2022-06-25 12:10:04.493839
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    test_case_1()

# Generated at 2022-06-25 12:10:08.931666
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-25 12:10:10.919828
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    assert strategy_module_0 is not None


# Generated at 2022-06-25 12:10:13.907541
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    test_case_0(bytes_0)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:10:16.742631
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(None)
    assert isinstance(strategy_module_0._host_pinned, bool)

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:10:18.629497
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)

# vim: expandtab filetype=python

# Generated at 2022-06-25 12:10:19.917563
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    test_case_0(bytes_0)


# Generated at 2022-06-25 12:10:21.599409
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    assert strategy_module_0 is not None

# Generated at 2022-06-25 12:10:23.369499
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    StrategyModule(bytes_0)

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:10:25.834758
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)


test_case_0()

# Generated at 2022-06-25 12:10:27.691365
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: remove this method after refactoring the code
    pass

# Generated at 2022-06-25 12:10:38.518612
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(bytes_0)
    assert isinstance(strategy_module_0,StrategyModule)


# Generated at 2022-06-25 12:10:39.676852
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)

# Generated at 2022-06-25 12:10:41.571388
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes = None
    assert StrategyModule(bytes)


# Generated at 2022-06-25 12:10:43.779095
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Verify that result for constructor method for class StrategyModule is not None
    assert StrategyModule(bytes_0) is not None

# Generated at 2022-06-25 12:10:44.831904
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)

# Generated at 2022-06-25 12:10:47.581280
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    assert isinstance(strategy_module_0, StrategyModule)


# Generated at 2022-06-25 12:10:48.562604
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    assert StrategyModule(bytes_0) is not False

# Generated at 2022-06-25 12:10:50.068542
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:10:53.185685
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_1 = None
    strategy_module_1 = StrategyModule(bytes_1)
    assert isinstance(strategy_module_1,StrategyModule)

# test of a method

# Generated at 2022-06-25 12:10:54.139946
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    test_case_0(bytes_0)

# Generated at 2022-06-25 12:11:16.424281
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    print("Test #0: strategy_module_0 = StrategyModule(bytes_0)")
    strategy_module_0 = StrategyModule(bytes_0)
    if (strategy_module_0._host_pinned != True):
        print("Test #1: FAILED")
    else:
        print("Test #1: PASSED")
    # Test #1: strategy_module_0._host_pinned == True



# Generated at 2022-06-25 12:11:19.155442
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)

test_case_0()
test_StrategyModule()

# Generated at 2022-06-25 12:11:21.644792
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    assert isinstance(strategy_module_0, StrategyModule)


# Generated at 2022-06-25 12:11:26.732858
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # No argument passed
    try:
        StrategyModule()
    except TypeError:
        pass

    # Invalid number of arguments passed
    try:
        StrategyModule(1,2,3)
    except TypeError:
        pass

    # Valid number of arguments passed
    #Test success case
    try:
        StrategyModule(1)
    except TypeError:
        pass

# Generated at 2022-06-25 12:11:28.709219
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)



# Generated at 2022-06-25 12:11:32.093136
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # TODO: Create a mock tqm value to test the constructor
    tqm = None

    # TODO: Create a mock tqm value to test the constructor
    test_case_00 = StrategyModule(tqm)


# Generated at 2022-06-25 12:11:33.996413
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    assert isinstance(strategy_module_0, StrategyModule)

# Generated at 2022-06-25 12:11:34.874461
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    test_case_0()

# Generated at 2022-06-25 12:11:37.455127
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:11:38.492337
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)

# Generated at 2022-06-25 12:12:19.202710
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_1 = None
    strategy_module_1 = StrategyModule(bytes_1)


# Generated at 2022-06-25 12:12:20.442157
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    test_case_0(bytes_0)



# Generated at 2022-06-25 12:12:22.541694
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test: no assertions
    test_case_0()


# Generated at 2022-06-25 12:12:24.483371
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    assert '_host_pinned' in dir(strategy_module_0)



# Generated at 2022-06-25 12:12:25.875774
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    assert strategy_module_0 is not None

# Generated at 2022-06-25 12:12:26.950275
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)



# Generated at 2022-06-25 12:12:28.396474
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    assert(strategy_module_0 is not None)



# Generated at 2022-06-25 12:12:30.550896
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test_case_0
    display.display('Test case 0.\n')
    test_case_0()
    display.display('Test case 0 finished.\n')

test_StrategyModule()

# Generated at 2022-06-25 12:12:32.303086
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # To initialize the object execute the following
    strategy_module_0 = StrategyModule('file')
    strategy_module_0 = StrategyModule('ios')
    strategy_module_0 = StrategyModule()


# Generated at 2022-06-25 12:12:33.075552
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert (test_case_0() == None)

# Generated at 2022-06-25 12:13:55.561357
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    strategy_module_0.run()


# Generated at 2022-06-25 12:13:56.552268
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(None)


# Generated at 2022-06-25 12:13:57.812943
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = 0
    strategy_module_0 = StrategyModule(bytes_0)
    assert not False


# Generated at 2022-06-25 12:13:58.782504
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(FreeStrategyModule)
    assert isinst

# Generated at 2022-06-25 12:13:59.743725
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:14:03.416390
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #dst_file='test.yml'
    #gather_subset='network'
    print("# Test case 0")
    try:
        test_case_0()
    except:
        print("Failed")
        raise
    else:
        print("Passed")

#if __name__ == '__main__':
#    test_StrategyModule()

# vim: ai sts=4 et sw=4

# Generated at 2022-06-25 12:14:04.476240
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:14:06.541123
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
# Creation of StrategyModule class object
strategy_module_0 = StrategyModule(strategy_module_0)

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:14:07.665002
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)
    assert (strategy_module_0._host_pinned == True)

# Generated at 2022-06-25 12:14:10.606609
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:17:15.589472
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:17:17.541289
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:17:18.845360
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule constructor")
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:17:19.585607
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:17:20.309298
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)

# Generated at 2022-06-25 12:17:23.086287
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ansible_0 = None
    strategy_module_0 = StrategyModule(ansible_0)
    assert type(strategy_module_0) == StrategyModule
    assert strategy_module_0._host_pinned == True
    assert strategy_module_0._total_tasks == 0

# Generated at 2022-06-25 12:17:28.243578
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    string_0 = ":$d"
    strategy_module_0 = StrategyModule(string_0)
    strategy_module_0._task_name_cache = {'v_next': None, 'v_done': 0, 'v_cur': None, 'v_prev': None}
    strategy_module_0._host_pinned = True
    strategy_module_0._display = Display()
    strategy_module_0._final_q = {'v_next': None, 'v_done': 0, 'v_cur': None, 'v_prev': None}
    strategy_module_0._bumped = True
    strategy_module_0.calculate_batch_size()

# Generated at 2022-06-25 12:17:29.283241
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    assert isinstance(StrategyModule(bytes_0), StrategyModule)

# Generated at 2022-06-25 12:17:30.800972
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = None
    strategy_module_0 = StrategyModule(bytes_0)

# Generated at 2022-06-25 12:17:32.111467
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    test_case_0()
    test_case_0()