

# Generated at 2022-06-25 12:08:50.358672
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)
    assert len(strategy_module_0._display._deprecations) == 0
    assert strategy_module_0._host_pinned is True


# Generated at 2022-06-25 12:08:52.141799
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    test_case_0()
    strategy_module_0 = StrategyModule(int_0)


# Generated at 2022-06-25 12:08:53.331285
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)

# Generated at 2022-06-25 12:08:54.091022
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:08:55.537410
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # The parameters have default values, so we can call the constructor without any parameters.
    test_case_0()


# Generated at 2022-06-25 12:08:56.808065
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)


# Generated at 2022-06-25 12:08:58.280923
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(90), 'test_StrategyModule:test_case_00'

test_StrategyModule()
test_case_0()

# Generated at 2022-06-25 12:09:02.219841
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)
    assert "display" in dir(StrategyModule)
    var_0 = StrategyModule.display.test_case_0()
    assert var_0 == None


# Generated at 2022-06-25 12:09:04.428799
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 0
    strategy_module_0 = StrategyModule(int_0)


# Generated at 2022-06-25 12:09:05.777161
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)

##########################################################################
# BEGIN OF CODE: Unit Test Code
##########################################################################
# Unit test main

# Generated at 2022-06-25 12:09:09.457737
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule(200)


# Generated at 2022-06-25 12:09:13.246870
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 79
    strategy_module_0 = StrategyModule(int_0)
    int_0 = 45
    int_1 = 37
    #self.assertEqual(strategy_module_0.dsadassa(int_0, int_1), "0")


# Generated at 2022-06-25 12:09:15.095129
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    strategy_module_0 = StrategyModule(50)
    assert(strategy_module_0._host_pinned == True)

# Generated at 2022-06-25 12:09:15.579044
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-25 12:09:17.227908
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 5
    strategy_module_0 = StrategyModule(int_0)
    # Method __init__
    test_case_0()


# Generated at 2022-06-25 12:09:21.572030
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)
    assert (isinstance(strategy_module_0, StrategyModule) or isinstance(strategy_module_0, FreeStrategyModule)) == True

# Generated at 2022-06-25 12:09:23.293840
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)

# Generated at 2022-06-25 12:09:24.084269
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)

# Generated at 2022-06-25 12:09:24.611981
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:09:25.440840
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)

# Generated at 2022-06-25 12:09:28.389696
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    test_case_0(int_0)

# Generated at 2022-06-25 12:09:29.908310
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:09:31.037410
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)

# Generated at 2022-06-25 12:09:32.431280
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)
    return

# Generated at 2022-06-25 12:09:34.359800
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as err:
        print('Caught exception: ' + repr(err))

# Execute test cases in this file.

# Generated at 2022-06-25 12:09:35.332184
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert (callable(StrategyModule))


# Generated at 2022-06-25 12:09:41.019396
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)
    assert type(strategy_module_0) == StrategyModule
    assert type(strategy_module_0._host_pinned) == bool
    assert strategy_module_0._host_pinned == True


# Generated at 2022-06-25 12:09:43.169242
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Declarations
    int_0 = 90
    # Setup
    # Execution
    test_case_0()

# Generated at 2022-06-25 12:09:54.010426
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str = "test_StrategyModule"
    int_0 = 40
    strategy_module_0 = StrategyModule(int_0)
    int_1 = strategy_module_0.display.verbosity
    int_2 = strategy_module_0.tqm._extra_vars
    dict_0 = dict()
    dict_0["tasks"] = list()
    dict_0["hosts"] = list()
    dict_0["_ansible_play_hosts"] = list()
    dict_0["_ansible_play_batch"] = list()
    dict_0["_ansible_play_hosts_all"] = list()
    play_0 = strategy_module_0.tqm._create_global_tmp_play(dict_0)
    dict_1 = dict()
    dict_1["name"]

# Generated at 2022-06-25 12:09:55.495911
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(int)
# >>> str.startswith('a')

# Generated at 2022-06-25 12:09:59.996718
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 92
    strategy_module_0 = StrategyModule(int_0)


# Generated at 2022-06-25 12:10:02.603488
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)

test_StrategyModule()
test_case_0()
# There should be no error if the test is successful
print("---SUCCESS---")

# Generated at 2022-06-25 12:10:03.766299
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)

# Generated at 2022-06-25 12:10:04.955671
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:10:06.221005
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)

# Generated at 2022-06-25 12:10:08.776201
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    if not isinstance(s, StrategyModule):
        raise AssertionError()


# Generated at 2022-06-25 12:10:10.230597
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # First test:
    # Testing that the constructor of StrategyModule works properly
    test_case_0()


# Generated at 2022-06-25 12:10:14.023047
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Standard Ansible module imports
from ansible.module_utils.basic import AnsibleModule

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 12:10:14.837890
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:10:17.695217
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)
    assert int_0 == strategy_module_0._tqm
    assert strategy_module_0._host_pinned


# Generated at 2022-06-25 12:10:28.629410
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)
    assert strategy_module_0 is not None


# Generated at 2022-06-25 12:10:30.269112
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        assert_equal(test_case_0(), None)
    except AssertionError as e:
        print(e)


# Generated at 2022-06-25 12:10:31.996726
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:10:32.793752
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:10:37.925621
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)
    if not strategy_module_0._host_pinned:
        print('Failure: Construction of class StrategyModule with argument int_0 = {:d}'.format(int_0))
        print('Expected True, but got False')
        return
    print('Success: Construction of class StrategyModule with argument int_0 = {:d}'.format(int_0))

# Generated at 2022-06-25 12:10:43.199944
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert strategy_module_0._tqm._terminated is False
    assert strategy_module_0._tqm._workers_count == 90
    assert strategy_module_0._tqm._running_queue.get() is None
    assert strategy_module_0._tqm._run_queue.get() is None
    assert strategy_module_0._tqm._final_q._queue[0] is None
    assert strategy_module_0._tqm._worker_prc.is_set() is False
    assert strategy_module_0._tqm._pending_results == 0


# Generated at 2022-06-25 12:10:44.663064
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)


# Generated at 2022-06-25 12:10:45.778737
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:10:46.877091
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    case_0 = test_case_0()

# Generated at 2022-06-25 12:10:48.176265
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)


# Generated at 2022-06-25 12:11:03.789442
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)
    assert strategy_module_0._host_pinned == True


# Generated at 2022-06-25 12:11:05.304252
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)

# Generated at 2022-06-25 12:11:12.439019
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import random
    import string
    int_0 = random.randint(12, 778)
    int_1 = random.randint(83, 708)
    int_2 = random.randint(65, 782)
    int_3 = random.randint(41, 719)
    int_4 = random.randint(49, 714)
    int_5 = random.randint(19, 730)
    int_6 = random.randint(40, 703)
    int_7 = random.randint(36, 774)
    int_8 = random.randint(9, 735)
    int_9 = random.randint(38, 721)
    str_0 = ""

# Generated at 2022-06-25 12:11:14.569926
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(90)


# Generated at 2022-06-25 12:11:17.989935
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Constructor of class StrategyModule")
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)


# Generated at 2022-06-25 12:11:20.875220
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 75
    strategy_module_0 = StrategyModule(int_0)

if __name__ == "__main__":
    test_StrategyModule()
    test_case_0()

# Generated at 2022-06-25 12:11:23.711594
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)
    strategy_module_0.__init__(int_0)

test_case_0()
test_StrategyModule()

# Generated at 2022-06-25 12:11:24.613732
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:11:26.249243
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)

# Generated at 2022-06-25 12:11:29.728897
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)
    assert strategy_module_0 is not None
    print("test_StrategyModule() completed")


# Generated at 2022-06-25 12:12:05.452242
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)


# Generated at 2022-06-25 12:12:07.111041
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
# returns none


# Generated at 2022-06-25 12:12:11.051541
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)
    display.display(">>> constructor of StrategyModule was called")
    assert hasattr(strategy_module_0, '_host_pinned')

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:12:12.300852
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)


# Generated at 2022-06-25 12:12:19.165706
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Init variables for this test case
    strategy_module_0 = StrategyModule(90)

    # Check if the "Hosts" property is defined, if not raise an error
    if not hasattr(strategy_module_0, 'Hosts'):
        raise Exception("\"Hosts\" property of class \"StrategyModule\" is not defined")

    # Check if the "HostQueue" property is defined, if not raise an error
    if not hasattr(strategy_module_0, 'HostQueue'):
        raise Exception("\"HostQueue\" property of class \"StrategyModule\" is not defined")

    # Check if the "HostQueue" property has valid value, if not raise an error
    if len(strategy_module_0.HostQueue) != 3:
        raise Exception("\"HostQueue\" property of class \"StrategyModule\" is not valid")



# Generated at 2022-06-25 12:12:21.204017
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_2 = 2
    strategy_module_1 = StrategyModule(int_2)
    assert isinstance(strategy_module_1, StrategyModule)



# Generated at 2022-06-25 12:12:28.295174
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool = True
    int_0 = 90
    bool = True
    int_1 = 90
    # Test function call_playbook
    # Test function run
    # Test function get_distribution_version
    # Test function get_distribution
    # Test function get_platform_version
    # Test function get_platform
    strategy_module_0 = StrategyModule(int_0)
    strategy_module_1 = StrategyModule(int_1)
    # Test function get_name
#     assert strategy_module_1.get_name() == 'host_pinned'
    # Test function get_hosts
    # Test function get_host
    # Test function get_variable_manager
    # Test function get_loader
    # Test function get_inventory
    # Test function get_tqm
    # Test function get_variable
    #

# Generated at 2022-06-25 12:12:29.245150
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display_1 = Display()
    int_1 = 90
    strategy_module_1 = StrategyModule(int_1)

# Generated at 2022-06-25 12:12:31.164708
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    print(9)
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)
    assert isinstance(strategy_module_0, StrategyModule)

    print(10)
    assert strategy_module_0._host_pinned == True




# Generated at 2022-06-25 12:12:40.860044
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 581
    strategy_module_0 = StrategyModule(int_0)
    assert isinstance(strategy_module_0, StrategyModule)
    # Verify that the type of member variable host_pinned is bool
    assert isinstance(strategy_module_0._host_pinned, bool)
    # Test the availability of member variable host_pinned
    try:
        assert strategy_module_0._host_pinned
    except AttributeError:
        assert False
    # Test the availability of member function _get_next_task_lock
    try:
        strategy_module_0._get_next_task_lock
    except AttributeError:
        assert False
    # Test the availability of member function _initialize_processes

# Generated at 2022-06-25 12:14:08.591930
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)
    # check that you can use assertRaises with a context manager
    with pytest.raises(NameError):
        int_0 = 90
        strategy_module_0 = StrategyModule(int_0)
    assert "strategy_module_0.DEBUG = False"
    assert "strategy_module_0._tqm = int_0"
    assert "strategy_module_0._failed_hosts = dict()"
    assert "strategy_module_0._unreachable_hosts = dict()"
    assert "strategy_module_0._stats = dict(processed={})"



# Generated at 2022-06-25 12:14:09.470791
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result = True
    assert result == True

# Generated at 2022-06-25 12:14:17.890746
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)
    int_1 = 90
    strategy_module_1 = StrategyModule(int_1)
    strategy_module_2 = StrategyModule(int_1)
    strategy_module_2._host_pinned = True
    int_2 = 90
    strategy_module_3 = StrategyModule(int_2)
    int_3 = 90
    strategy_module_4 = StrategyModule(int_3)
    int_4 = 90
    strategy_module_5 = StrategyModule(int_4)
    int_5 = 90
    strategy_module_6 = StrategyModule(int_5)
    int_6 = 90
    strategy_module_7 = StrategyModule(int_6)
    int_7 = 90
    strategy_module_8 = StrategyModule

# Generated at 2022-06-25 12:14:25.503881
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 23
    strategy_module_0 = StrategyModule(int_0)
    assert strategy_module_0._host_pinned == True
    assert strategy_module_0._batch_size == 0
    assert strategy_module_0._tqm_queue == None
    assert strategy_module_0._tqm == 23
    assert strategy_module_0._inventory == None
    assert strategy_module_0._inventory_basedir == None
    assert strategy_module_0._inventory_sourcedir == None
    assert strategy_module_0._inventory_source_vars == None
    assert strategy_module_0._options == None
    assert strategy_module_0._display == display
    assert strategy_module_0._variable_manager == None
    assert strategy_module_0._all_hosts == []
    assert strategy_module

# Generated at 2022-06-25 12:14:26.213713
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:14:26.919057
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:14:29.940252
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 23
    strategy_module_0 = StrategyModule(int_0)
    assert isinstance(strategy_module_0, StrategyModule)


# Generated at 2022-06-25 12:14:30.816167
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)

    assert(True)


# Generated at 2022-06-25 12:14:31.969210
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)


# Generated at 2022-06-25 12:14:33.298383
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Arrange and Act
    test_case_0()

#  End of unit tests for constructor of class StrategyModule


# Generated at 2022-06-25 12:17:47.520485
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule(0)
    # Check that instance strategy_module_1 is not none
    if (not (strategy_module_1)):
        raise Exception("Failed to instantiate StrategyModule!")

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-25 12:17:51.840351
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(0)
    assert strategy_module_0
    assert strategy_module_0._host_pinned
    assert strategy_module_0._tqm
    assert strategy_module_0._limit
    assert strategy_module_0._index
    assert strategy_module_0._have_blocked_hosts
    assert strategy_module_0._blocked_hosts
    assert strategy_module_0._unblocked_hosts
    assert strategy_module_0._evaluated_hosts
    assert strategy_module_0._queue
    assert strategy_module_0._fire_count
    assert strategy_module_0._done_hosts
    assert strategy_module_0._wait_for_pending_done
    assert strategy_module_0._wait_for_connections
    assert strategy_module_0

# Generated at 2022-06-25 12:17:53.302066
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    
    # Test case for constructor without exception
    try:
        test_case_0()
    except:
        display.error("Error with constructor of class StrategyModule")

# Generated at 2022-06-25 12:17:57.574270
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.display(msg='StrategyModule()')
    #
    # Try constructing without any args.  This should fail.
    #
    #strategy_module_0 = StrategyModule()
    #
    # Try constructing with one arg.
    #
    strategy_module_1 = StrategyModule(90)

# Generated at 2022-06-25 12:17:58.791864
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 90
    int_0 = 90
    strategy_module_0 = StrategyModule(tqm)


# Generated at 2022-06-25 12:18:00.287339
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_1 = 90
    strategy_module_0 = StrategyModule(int_1)

if __name__ == "__main__":
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:18:01.186206
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)



# Generated at 2022-06-25 12:18:02.243292
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(90)


# Generated at 2022-06-25 12:18:04.358886
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    strategy_module_0 = StrategyModule(10)


# Generated at 2022-06-25 12:18:06.740871
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 90
    strategy_module_0 = StrategyModule(int_0)
    assert strategy_module_0._host_pinned == True

if __name__ == "__main__":
    test_case_0()
    test_StrategyModule()