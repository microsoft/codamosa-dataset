

# Generated at 2022-06-25 12:08:51.375837
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = -1946
    strategy_module_0 = StrategyModule(int_0)


# Generated at 2022-06-25 12:08:57.864538
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = -125
    strategy_module_0 = StrategyModule(int_0)
    assert isinstance(strategy_module_0, StrategyModule) == True
    assert isinstance(strategy_module_0, free.StrategyModule) == True
    assert isinstance(strategy_module_0, object) == True
    assert strategy_module_0._host_pinned == True
    assert strategy_module_0._play_has_tasks == False
    assert strategy_module_0._task_queue == []
    assert strategy_module_0._unreachable_hosts == []
    assert strategy_module_0._worker_prune == None
    assert strategy_module_0._workers == {}


# Generated at 2022-06-25 12:08:59.812808
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = -1946
    strategy_module_0 = StrategyModule(int_0)

# Generated at 2022-06-25 12:09:03.004535
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = -116
    strategy_module_0 = StrategyModule(int_0)
    int_0 = -1580
    free_strategy_module_1 = FreeStrategyModule(int_0)


# Generated at 2022-06-25 12:09:05.177004
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = -1554
    strategy_module_0 = StrategyModule(int_0)


# Generated at 2022-06-25 12:09:06.610950
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print('Test module strategy passed')

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:09:10.432314
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule")
    test_case_0()
    print("Finished Testing StrategyModule")

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    test_StrategyModule()

# Generated at 2022-06-25 12:09:11.137816
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass # TODO: construct the object and perform unit test

# Generated at 2022-06-25 12:09:15.651402
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = -128
    strategy_module_0 = StrategyModule(int_0)
    assert True

if __name__ == '__main__':
    import sys
    import pytest
    errno = pytest.main(args=[__file__])
    sys.exit(errno)
# END OF FILE

# Generated at 2022-06-25 12:09:20.361041
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = -1946
    strategy_module_0 = StrategyModule(int_0)

test_case_0()

# Generated at 2022-06-25 12:09:21.788062
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:09:24.297088
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = -1946
    strategy_module_0 = StrategyModule(int_0)


# Generated at 2022-06-25 12:09:28.860121
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_1 = -1272
    strategy_module_1 = StrategyModule(int_1)
    assert isinstance(strategy_module_1._host_pinned, bool)
    assert isinstance(strategy_module_1, object)
    assert isinstance(strategy_module_1._host_pinned, bool)
    assert strategy_module_1._host_pinned == True


# Generated at 2022-06-25 12:09:36.135597
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 15
    strategy_module_0 = StrategyModule(int_0)
    return_val_0 = strategy_module_0.check_complete()
    return_val_1 = strategy_module_0.check_complete()
    return_val_2 = strategy_module_0.check_complete()
    return_val_3 = strategy_module_0.check_complete()
    return_val_4 = strategy_module_0.check_complete()
    return_val_5 = strategy_module_0.check_complete()
    return_val_6 = strategy_module_0.check_complete()
    return_val_7 = strategy_module_0.check_complete()
    return_val_8 = strategy_module_0.check_complete()
    return_val_9 = strategy_module_0.check_

# Generated at 2022-06-25 12:09:41.300680
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = -2501
    strategy_module_0 = StrategyModule(int_0)
    assert -2501 == strategy_module_0._tqm.max_hosts
    dict_0 = {}
    dict_0['topology_depth'] = 0
    dict_0['inventory'] = None
    dict_0['cache'] = None
    dict_0['play'] = None
    dict_0['variable_manager'] = None
    dict_0['loader'] = None
    dict_0['host'] = None
    dict_0['extra'] = None
    dict_0['extra']['vars'] = {}
    dict_0['extra']['vars']['ansible_play_batch'] = None

# Generated at 2022-06-25 12:09:42.299484
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:09:45.448711
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = -921
    strategy_module_0 = StrategyModule(int_0)
    assert isinstance(strategy_module_0, StrategyModule)


# Generated at 2022-06-25 12:09:48.136592
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    int_0 = -1743
    strategy_module_0 = StrategyModule(int_0)
    # assert False # TODO: implement your test here


# Generated at 2022-06-25 12:09:51.233160
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = -4954
    strategy_module_0 = StrategyModule(int_0)
    assert strategy_module_0._host_pinned == True


# Generated at 2022-06-25 12:09:54.089583
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = -3737
    strategy_module_0 = StrategyModule(int_0)
    int_0 = 1152
    assert strategy_module_0._host_pinned == True


# Generated at 2022-06-25 12:09:57.466906
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    # Test the above constructor of class StrategyModule.
    # test_case_0()

# Generated at 2022-06-25 12:10:00.564201
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = -957
    strategy_module_0 = StrategyModule(int_0)

# Generated at 2022-06-25 12:10:02.537909
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.a("Unit test for constructor of class StrategyModule")
    test_case_0()
    display.a("End of Unit test for constructor of class StrategyModule")


# Generated at 2022-06-25 12:10:03.688471
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 4
    strategy_module_0 = StrategyModule(tqm)

# Generated at 2022-06-25 12:10:05.638032
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test: constructor of class StrategyModule")
    test_case_0()


# Generated at 2022-06-25 12:10:06.463557
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test case 0
    test_case_0()

# Generated at 2022-06-25 12:10:15.099208
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule as host_pinned_StrategyModule
    from ansible.plugins.strategy.host_pinned import test_case_0 as host_pinned_test_case_0
    from ansible.plugins.strategy.host_pinned import test_StrategyModule as host_pinned_test_StrategyModule
    
    test_case_18_instance = host_pinned_test_case_0()
    test_StrategyModule_instance = host_pinned_test_StrategyModule()
    host_pinned_StrategyModule_instance = host_pinned_StrategyModule()

# Generated at 2022-06-25 12:10:22.875220
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = -1946
    strategy_module_0 = StrategyModule(int_0)
    assert -1946 == strategy_module_0._tqm
    assert 0 == strategy_module_0._inventory
    assert False == strategy_module_0._fail_fast
    assert False == strategy_module_0._final_q
    assert True == strategy_module_0._unreachable_hosts
    assert False == strategy_module_0._final_block
    assert False == strategy_module_0._BLOCK_ERROR_MSG
    assert [    ] == strategy_module_0._display
    assert False == strategy_module_0._LOG_PATH
    assert False == strategy_module_0._tqm_has_pending_results
    assert False == strategy_module_0._tqm_has_blocked_hosts

# Generated at 2022-06-25 12:10:26.971780
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('')
    print('Unit test for constructor of class StrategyModule')
    print('')
    test_case_0()
    print('Unit tests for class StrategyModule passed')

test_StrategyModule()

# Generated at 2022-06-25 12:10:28.779085
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = -1946
    strategy_module_0 = StrategyModule(int_0)


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:10:34.459030
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-25 12:10:38.153628
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# How to run unit test
if __name__ == "__main__":
    test_StrategyModule()
else:
    print('Please run this unit test by running "python -m test.unit.plugins.strategy.host_pinned"')

# Generated at 2022-06-25 12:10:40.147532
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.display("test_StrategyModule begin")
    test_case_0()
    display.display("test_StrategyModule end")


test_StrategyModule()

# Generated at 2022-06-25 12:10:44.088544
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(int_0)
    assert type(strategy_module_0) == StrategyModule
    assert strategy_module_0._host_pinned == True




# Generated at 2022-06-25 12:10:53.336319
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = -191
    strategy_module_0 = StrategyModule(int_0)
    assert (strategy_module_0._tqm == -191)
    assert (strategy_module_0._display == display)
    assert (strategy_module_0._callbacks == [])
    assert (strategy_module_0._play_context == None)
    assert (strategy_module_0._iterator == None)
    assert (strategy_module_0._variable_manager == None)
    assert (strategy_module_0._loader == None)
    assert (strategy_module_0._inventory == None)
    assert (strategy_module_0._batch_size == None)
    assert (strategy_module_0._last_hosts == None)

# Generated at 2022-06-25 12:10:54.803484
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Unit tests
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:11:03.152394
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = -9185
    strategy_module_0 = StrategyModule(int_0)
    # Exception thrown
    try:
        # Test condition
        assert(strategy_module_0._host_pinned == False)
        # Test condition
        assert(strategy_module_0._batch_size == 1)
    except AssertionError:
        raise AssertionError("Expecting False , but got "+str(strategy_module_0._host_pinned))



# Generated at 2022-06-25 12:11:04.471516
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  int_0 = 5
  strategy_module_0 = StrategyModule(int_0)

# Generated at 2022-06-25 12:11:05.671565
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:11:07.472065
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = -2
    strategy_module_0 = StrategyModule(int_0)


# Generated at 2022-06-25 12:11:19.416608
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = (12287)
    strategy_module_0 = StrategyModule(int_0)
    assert(strategy_module_0._host_pinned == True)

for entrypoint in __entrypoints__:
    entrypoint.eval_code('free')

# Generated at 2022-06-25 12:11:20.078990
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  # Test if the constructor of class StrategyModule can assign
  assert StrategyModule

# Generated at 2022-06-25 12:11:22.642469
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test if the number of arguments is correct
    int_1 = -1946
    try:
        StrategyModule(int_1)
    except TypeError:
        print_exc()


if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:11:31.223622
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Here we are testing the execution in case of required property is not provided
    # String test_case_0(self)
    passed = True

# Generated at 2022-06-25 12:11:32.354038
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule != None


# Generated at 2022-06-25 12:11:33.247100
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:11:35.383093
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    int_0 = -1946
    strategy_module_0 = StrategyModule(int_0)

# Generated at 2022-06-25 12:11:36.586601
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_1 = -1946
    strategy_module_0 = StrategyModule(int_1)


# Generated at 2022-06-25 12:11:37.552191
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test case 0")
    test_case_0()

# Generated at 2022-06-25 12:11:38.602990
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(-1946)



# Generated at 2022-06-25 12:11:59.611878
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = -1978
    strategy_module_0 = StrategyModule(int_0)


# Generated at 2022-06-25 12:12:00.606040
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:12:01.268983
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:12:01.948125
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:12:02.708950
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:12:04.634590
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = -1946
    strategy_module_0 = StrategyModule(int_0)
    assert isinstance(strategy_module_0, object)
    assert isinstance(strategy_module_0, StrategyModule)

# Generated at 2022-06-25 12:12:09.259034
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Code to be tested
    strategy_module_1 = StrategyModule(int)
    # Code to be tested
    strategy_module_2 = StrategyModule(int)
    # Code to be tested
    strategy_module_3 = StrategyModule(int)
    # Code to be tested
    strategy_module_4 = StrategyModule(int)


# Generated at 2022-06-25 12:12:12.460962
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = -1763
    strategy_module_0 = StrategyModule(int_0)

# Generated at 2022-06-25 12:12:13.732250
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':

    test_StrategyModule()

# Generated at 2022-06-25 12:12:15.111205
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.display(u'TEST: constructor of class StrategyModule')
    test_case_0()


# Generated at 2022-06-25 12:12:56.662208
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = -1946
    strategy_module_0 = StrategyModule(int_0)
    assert True


# Generated at 2022-06-25 12:12:57.307042
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:12:57.994494
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:13:00.513040
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #assert system_wide_module_0._host_pinned == True
    int_0 = -1946
    strategy_module_0 = StrategyModule(int_0)

# Generated at 2022-06-25 12:13:01.176441
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:13:01.832660
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:13:03.084656
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = 877
    strategy_module_0 = StrategyModule(int_0)


# Generated at 2022-06-25 12:13:03.726718
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(92)

# Generated at 2022-06-25 12:13:04.408519
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:13:05.148811
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:14:30.688292
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:14:32.083520
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.debug("test_StrategyModule(): BEGIN")

    test_case_0()

    display.debug("test_StrategyModule(): END")

# Generated at 2022-06-25 12:14:33.185566
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = -1946
    strategy_module_0 = StrategyModule(int_0)



# Generated at 2022-06-25 12:14:35.563135
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    fd_0 = 1000
    strategy_module_0 = StrategyModule(fd_0)

if __name__ == '__main__':
    try:
        test_case_0()
    except NameError:
        pass
    try:
        test_StrategyModule()
    except NameError:
        pass

# Generated at 2022-06-25 12:14:36.384077
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 0
    test_case_0(tqm)

# Generated at 2022-06-25 12:14:37.607209
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = -1946
    strategy_module_0 = StrategyModule(int_0)
    assert strategy_module_0._host_pinned == True

# Generated at 2022-06-25 12:14:38.391400
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(strategy_module_0, StrategyModule)


# Generated at 2022-06-25 12:14:40.509327
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    strategy_module_0 = StrategyModule(None)
    assert not hasattr(strategy_module_0, 'tqm')
    assert hasattr(strategy_module_0, '_host_pinned')
    assert strategy_module_0._host_pinned

# Generated at 2022-06-25 12:14:42.135522
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = -1658
    strategy_module_0 = StrategyModule(int_0)

# Generated at 2022-06-25 12:14:43.501499
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-25 12:17:57.186690
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:17:59.833590
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Default constructor
    strategy_module_0 = StrategyModule()


strategy_module_1 = StrategyModule()
strategy_module_1.__init__()

strategy_module_1 = StrategyModule()
strategy_module_1.get_host_list()

strategy_module_1 = StrategyModule()
strategy_module_1.get_next_task_lock()

# Generated at 2022-06-25 12:18:00.750302
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_1 = -407
    strategy_module_1 = StrategyModule(int_1)


# Generated at 2022-06-25 12:18:01.726411
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_2 = -1946
    strategy_module_2 = StrategyModule(int_2)

# Generated at 2022-06-25 12:18:09.338280
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = -1583
    strategy_module_0 = StrategyModule(int_0)

# Generated at 2022-06-25 12:18:10.756974
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = -1946
    strategy_module_0 = StrategyModule(int_0)
    assert strategy_module_0._host_pinned == True

# Generated at 2022-06-25 12:18:11.303749
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-25 12:18:13.462265
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Stub for constructor
    int_0 = -1946
    strategy_module_0 = StrategyModule(int_0)
    int_1 = -1946
    strategy_module_1 = StrategyModule(int_1)

# Generated at 2022-06-25 12:18:14.760928
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module_strategy_0 = test_case_0()
    assert module_strategy_0._host_pinned == True

# Generated at 2022-06-25 12:18:15.631700
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    int_0 = -4138
    strategy_module_0 = StrategyModule(int_0)