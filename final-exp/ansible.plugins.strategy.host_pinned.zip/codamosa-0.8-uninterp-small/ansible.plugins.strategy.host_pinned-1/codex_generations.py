

# Generated at 2022-06-25 12:08:52.284592
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = '6-zW/FW:a'
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 12:08:53.101225
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #test_case_0()
    display.display('All the tests for  test_StrategyModule() passed')

# Generated at 2022-06-25 12:08:55.366865
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_00 = 'EU7V.-hD'
    strategy_module_00 = StrategyModule(str_00)
    assert(str_00 == strategy_module_00._tqm)


# Generated at 2022-06-25 12:08:56.904476
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()

# Generated at 2022-06-25 12:08:58.846617
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = '49ov^D'
    strategy_module_0 = StrategyModule(str_0)
    assert isinstance(strategy_module_0, StrategyModule)


# Generated at 2022-06-25 12:08:59.941668
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\nUnit test for constructor of class StrategyModule")
    test_case_0()


# Generated at 2022-06-25 12:09:02.523821
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # pass
    test_case_0()

# Unit test main
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:09:04.457618
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    args = []
    #self.assertRaisesRegex(TypeError, '^__init__\() takes exactly 2 arguments \(1 given\)$', StrategyModule, *args)
    #TypeError: __init__() takes exactly 2 arguments (1 given)
    assert True


# Generated at 2022-06-25 12:09:06.105616
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = '6-zW/FW:a'
    strategy_module_1 = StrategyModule(str_1)



# Generated at 2022-06-25 12:09:08.744868
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    # Unit Tests
    test_StrategyModule()

# Generated at 2022-06-25 12:09:10.650363
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = test_case_0()
    StrategyModule(tqm)

# Generated at 2022-06-25 12:09:12.698193
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    var_1 = (1,2,3)
    var_2 = StrategyModule(var_1)
    test_case_0()

# Generated at 2022-06-25 12:09:14.369205
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    var_1 = []

# Unit tests for methods of class StrategyModule

# Generated at 2022-06-25 12:09:15.907487
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = []
    test_case_0()
    StrategyModule(tqm)

# Generated at 2022-06-25 12:09:20.035466
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    var_1 = StrategyModule
    var_2 = (None)
    var_3 = var_1(var_2)

# Generated at 2022-06-25 12:09:20.915010
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:09:22.627269
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    var_0 = StrategyModule(var_0)
    assert 0 == 0


# Generated at 2022-06-25 12:09:25.110757
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

test_case_0()

# Generated at 2022-06-25 12:09:27.435121
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = Tqm()
    test_0 = StrategyModule(tqm)
    assert(test_0._host_pinned == True)



# Generated at 2022-06-25 12:09:30.298774
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned

    my_strategy_module = ansible.plugins.strategy.host_pinned.StrategyModule()


# Generated at 2022-06-25 12:09:31.669463
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-25 12:09:33.043064
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    var_0 = StrategyModule()
    print(var_0)

var_0 = StrategyModule()


# Generated at 2022-06-25 12:09:34.813127
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except NameError as e:
        print("TestCase 0 failed: " + e.args[0])


# Generated at 2022-06-25 12:09:36.233316
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)


# Generated at 2022-06-25 12:09:40.517748
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    tqm = ""
    x = StrategyModule(tqm)
    assert x.__class__.__name__ == 'StrategyModule'


# Generated at 2022-06-25 12:09:43.034812
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    x = StrategyModule(tqm)
    assert isinstance(x, StrategyModule) == True


# Generated at 2022-06-25 12:09:44.086062
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:09:54.693193
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # varibles for test
    inventory = MockInventory()
    var_tqm = MockTQM()
    var_tqm.inventory = inventory
    var_tqm._inventory_hosts_cache = inventory.get_hosts()
    var_tqm.stats = MockStats()
    var_tqm.get_host = MockGetHost()

    # test
    strategy = StrategyModule(var_tqm)
    assert (strategy._inventory == inventory)
    assert (strategy._inventory_hosts_cache == var_tqm._inventory_hosts_cache)
    assert (strategy._display == display)
    assert (strategy._tqm == var_tqm)
    assert (strategy._callback_sent == 1)

# Generated at 2022-06-25 12:09:57.127065
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create instance of class StrategyModule with default arguments
    strategy_module = StrategyModule()
    # Check StrategyModule was created successfully
    assert strategy_module is not None


# Generated at 2022-06-25 12:09:58.248807
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test = StrategyModule(var_0)

# Generated at 2022-06-25 12:10:01.200645
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = '6-zW/FW:a'
    strategy_module_0 = StrategyModule(str_0)
    assert strategy_module_0._host_pinned == True, 'Expected: True, Actual: {0}'.format(strategy_module_0._host_pinned)


# Generated at 2022-06-25 12:10:03.131070
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # 1.
    test_case_0()


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:10:04.919343
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Initialize host_pinned to a value
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:10:06.489358
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = '8jR'
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 12:10:08.158189
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:10:11.335608
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("========== Constructor of class StrategyModule test ==========")
    test_case_0()
    print("=========== Constructor of class StrategyModule test over! ===========")

# Run the test
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:10:20.548542
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.display import Display as display
    test_case_0()

# TEST CASE: This is a "normal" kind of test case.
# TEST CASE: This is a "normal" kind of test case.
# TEST CASE: This is a "normal" kind of test case.
# TEST CASE: This is a "normal" kind of test case.

# TEST CASE: This is a "normal" kind of test case.
# TEST CASE: This is a "normal" kind of test case.
# TEST CASE: This is a "normal" kind of test case.

# TEST CASE: This is a "normal" kind of test case.
# TEST CASE: This is a "normal" kind of test case.

# TEST CASE: This is a "normal" kind of test case.
# TEST CASE: This is a "normal" kind of test case

# Generated at 2022-06-25 12:10:22.636508
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # constructor of class StrategyModule
    str_0 = 'tqm'
    strategy_module_0 = StrategyModule(str_0)


# unit test for method StrategyModule.get_host_list

# Generated at 2022-06-25 12:10:32.483947
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    
    # initialization
    test_strategy_module_0 = StrategyModule(None)
    test_strategy_module_1 = StrategyModule(None)
    test_strategy_module_2 = StrategyModule(None)
    test_strategy_module_3 = StrategyModule(None)
    test_strategy_module_4 = StrategyModule(None)
    
    # set properties
    test_strategy_module_0._tqm = '0'
    test_strategy_module_1._tqm = '0'
    test_strategy_module_2._tqm = '0'
    test_strategy_module_3._tqm = '0'
    test_strategy_module_4._tqm = '0'
    
    # copy
    test_StrategyModule_0 = Strategy

# Generated at 2022-06-25 12:10:33.835944
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = '6-zW/FW:a'
    strategy_module_0 = StrategyModule(str_0)

# Generated at 2022-06-25 12:10:37.701234
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(None)


# Generated at 2022-06-25 12:10:42.274262
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    from ansible.plugins.strategy.free import Display
    from ansible.plugins.strategy.free import Display
    from ansible.plugins.strategy.free import Display
    assert issubclass(StrategyModule, FreeStrategyModule)
    # basic instantiation
    assert strategy_module_0.__init__() == None



# Generated at 2022-06-25 12:10:44.764405
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    test_case_0()

# Testing whether constructor of class StrategyModule throws AssertionError when called with wrong types of arguments
# Argument types: (float)

# Generated at 2022-06-25 12:10:46.913733
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = '6-zW/FW:a'
    strategy_module_0 = StrategyModule(str_0)

# Generated at 2022-06-25 12:10:53.622852
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test with basic arguments
    strategy_module_0 = StrategyModule('6-zW/FW:a')

    # Test with specialized arguments
    strategy_module_1 = StrategyModule('6-zW/FW:a')
    strategy_module_1.whereami = '6-zW/FW:a'
    strategy_module_1.batch_time = '6-zW/FW:a'
    assert strategy_module_1.whereami == '6-zW/FW:a'
    assert strategy_module_1.batch_time == '6-zW/FW:a'


# Generated at 2022-06-25 12:10:57.441370
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = '6-zW/FW:a'
    strategy_module_0 = StrategyModule(str_0)
    #To check if the strategy module attributes have been set properly
    assert strategy_module_0._host_pinned == True
    assert strategy_module_0._tqm == str_0


# Generated at 2022-06-25 12:11:01.905862
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    for i in range(10):
        test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:11:10.674629
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = '3r7zr~'
    tqm_0 = 'nP'
    strategy_module_0 = StrategyModule(tqm_0)
    assert strategy_module_0._tqm.stdout_callback == 'nul', "strategy_module_0._tqm.stdout_callback == 'nul'"
    assert strategy_module_0._host_pinned == True, "strategy_module_0._host_pinned == True"
    assert strategy_module_0._batch_size == None, "strategy_module_0._batch_size == None"
    assert strategy_module_0._cur_batch == None, "strategy_module_0._cur_batch == None"

# Generated at 2022-06-25 12:11:15.347341
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    expected_result = '6-zW/FW:a'
    strategy_module_0 = StrategyModule(expected_result)
    actual_result = strategy_module_0.tqm
    assert expected_result == actual_result


# Generated at 2022-06-25 12:11:21.688033
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test for constructor with string '6-zW/FW:a'
    str_0 = '6-zW/FW:a'
    strategy_module_0 = StrategyModule(str_0)
    # Test for constructor with string 'c{RmY7#-*'
    str_0 = 'c{RmY7#-*'
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 12:11:34.161530
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()


# Generated at 2022-06-25 12:11:36.137841
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'vnA]!Pb26'
    strategy_module_0 = StrategyModule(str_0)
    assert strategy_module_0 != None


# Generated at 2022-06-25 12:11:37.355763
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Z'
    strategy_module_0 = StrategyModule(str_0)



# Generated at 2022-06-25 12:11:38.673326
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:11:40.705454
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = ']+s|:Zt'
    strategy_module_1 = StrategyModule(str_1)


# Generated at 2022-06-25 12:11:43.861749
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# nosetests --with-coverage --cover-package=ansible.plugins.strategy.host_pinned -a '!notravis' ansible/plugins/strategy/host_pinned.py

# Generated at 2022-06-25 12:11:46.553219
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Normal case, nothing special
    str_0 = 'a'
    strategy_module_0 = StrategyModule(str_0)
    # Normal case, nothing special
    str_1 = 'A'
    strategy_module_1 = StrategyModule(str_1)


# Generated at 2022-06-25 12:11:55.980801
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # constructor test
    # Input params:
    #   tqm = AnsibleQueueManager
    # Test: No exception is thrown
    def test_StrategyModule_0():
        str_0 = '6-zW/FW:a'
        strategy_module_0 = StrategyModule(str_0)
    test_StrategyModule_0()
    # constructor test
    # Input params:
    #   tqm = AnsibleQueueManager
    # Test: No exception is thrown
    def test_StrategyModule_1():
        str_0 = None
        strategy_module_0 = StrategyModule(str_0)
    test_StrategyModule_1()
    # constructor test
    # Input params:
    #   tqm = AnsibleQueueManager
    # Test: No exception is thrown

# Generated at 2022-06-25 12:11:57.253413
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = '6-zW/FW:a'
    strategy_module_0 = StrategyModule(str_0)

# Generated at 2022-06-25 12:11:59.721993
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    params = {"serial": "1"}
    tqm = {"ansible_host_pinned": "False", "config": {"strategy": "host_pinned"}}
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == False

# Generated at 2022-06-25 12:12:11.944572
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
        display.display('[PASS] constructor test passed!')
    except AssertionError as e:
        display.display('[FAIL] constructor test failed!')


# Generated at 2022-06-25 12:12:12.683999
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:12:14.230498
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    strategy_module_0 = StrategyModule('tqm')


# Generated at 2022-06-25 12:12:15.075011
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-25 12:12:15.553152
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-25 12:12:16.255903
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-25 12:12:17.741803
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.vvvvv = 1
    display.verbosity = 5
    display.debug = True
    test_case_0()

# Generated at 2022-06-25 12:12:18.436029
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:12:19.560550
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = '6-zW/FW:a'
    strategy_module_0 = StrategyModule(str_0)

# Generated at 2022-06-25 12:12:20.190263
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:12:48.838497
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.display('========== START test_StrategyModule ==========')
    import time
    import datetime
    start_time = time.time()
    display.display('=== start_time: %s ===' % (datetime.datetime.fromtimestamp(start_time).strftime('%Y-%m-%d %H:%M:%S.%f')))

    test_case_0()

    end_time = time.time()
    display.display('=== end_time: %s ===' % (datetime.datetime.fromtimestamp(end_time).strftime('%Y-%m-%d %H:%M:%S.%f')))
    display.display('=== run time: %s ===' % (end_time - start_time))

# Generated at 2022-06-25 12:12:49.649852
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:12:55.665034
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as e:
        display.error(str(e))
        return False

    return True

# Generated at Thu Jul 12 18:50:52 2018 by generate_test_code.py script
# with Python version 2.7.14 :: Anaconda custom (64-bit)

# Expected result
# ('ok', ['6-zW/FW:a', 'a'])
# ('changed', ['6-zW/FW:a', 'a'])
# ('skipped', ['6-zW/FW:a', 'a'])
# ('failed', ['6-zW/FW:a', 'a'])
# ('unreachable', ['6-zW/FW:a', 'a'])
# ({'6-zW/FW:a': 'a

# Generated at 2022-06-25 12:12:56.606731
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert test_case_0() is None

# Generated at 2022-06-25 12:12:59.196097
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # https://docs.python.org/2/library/unittest.html
    # https://docs.python.org/2/library/unittest.html#assert-methods
    ...


# Generated at 2022-06-25 12:13:00.260454
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:13:03.611974
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = b'\x1f\x8b\x08\x00\x00\x00\x00\x00\x00\x03\xed\xbd\x09\x78\x54\x55'
    assert not test_case_0()
    print('Test is passed!')

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:13:09.161391
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tried = 0
    errors = 0
    from tests.units.mock.loader import DictDataLoader
    d = DictDataLoader({})
    t = ansible.playbook.play.Play()
    t._ds = d
    t._play_ds = d
    t._play = t

    #_send_callback() is tested in test_threads()
    #_wait_on_pending_results() is tested in test_threads()
    #_process_pending_results() is tested in test_threads()
    #_wait_on_pending_results() is tested in test_threads()
    #run() is tested in test_threads()
    #_worker_loop() is tested in test_threads()
    #_make_workers() is tested in test_threads()
    #_prime

# Generated at 2022-06-25 12:13:10.487468
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    strategy_module_1 = StrategyModule(strategy_module_0)
    assert isinstance(strategy_module_1, StrategyModule)

# Generated at 2022-06-25 12:13:11.437694
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = '6-zW/FW:a'
    strategy_module_0 = StrategyModule(str_0)



# Generated at 2022-06-25 12:13:53.636784
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.verbosity = 2
    test_case_0()

# Boilerplate code to run this file
if __name__ == '__main__':
    from ansible.module_utils.basic import AnsibleModule
    from test.support import run_unittest
    run_unittest(test_StrategyModule)

# Generated at 2022-06-25 12:13:55.296725
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()
# end of StrategyModule class

# Generated at 2022-06-25 12:13:56.807354
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = '6-zW/FW:a'
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 12:13:58.848728
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Don't need to test the whole constructor
    # But we need to test whether the constructor is correct
    # So that the results of the following method calls can be trusted
    assert StrategyModule.__init__()


# Generated at 2022-06-25 12:14:01.349656
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = '6-zW/FW:a'
    strategy_module_0 = StrategyModule(str_0)
    str_1 = '_G:ZT%o~w'
    strategy_module_1 = StrategyModule(str_1)


# Generated at 2022-06-25 12:14:02.780906
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = '6-zW/FW:a'
    strategy_module_1 = StrategyModule(str_1)



# Generated at 2022-06-25 12:14:04.301629
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'c4P,iB|'
    strategy_module_0 = StrategyModule(str_0)
    assert strategy_module_0._host_pinned == True

# Generated at 2022-06-25 12:14:06.538438
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = '6-zW/FW:a'
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 12:14:09.530979
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = '6-zW/FW:a'
    strategy_module_0 = StrategyModule(str_0)
    assert hasattr(strategy_module_0, '_tqm') == True
    assert hasattr(strategy_module_0, '_inventory') == True
    assert hasattr(strategy_module_0, '_variable_manager') == True
    assert hasattr(strategy_module_0, '_loader') == True
    assert hasattr(strategy_module_0, 'display') == True
    assert type(strategy_module_0) != type(None)

# Generated at 2022-06-25 12:14:12.948792
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = '1[2Q1(W/'
    strategy_module_0 = StrategyModule(str_0)
    assert hasattr(strategy_module_0, '_display')
    assert hasattr(strategy_module_0, '_queue')
    assert hasattr(strategy_module_0, '_runners')
    assert hasattr(strategy_module_0, '_tqm')
    assert hasattr(strategy_module_0, '__name__')
    assert hasattr(strategy_module_0, '_host_pinned')
    assert hasattr(strategy_module_0, 'run')

# unit test for run method of class StrategyModule

# Generated at 2022-06-25 12:15:42.539746
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned_0 = StrategyModule()
    assert host_pinned_0.get_name() == 'host_pinned'

# Generated at 2022-06-25 12:15:49.200164
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = '=Nf>Fn2'
    strategy_module_0 = StrategyModule(str_0)
    assert str_0 == strategy_module_0._tqm
    assert strategy_module_0._hosts_left == {}
    assert strategy_module_0.display == display
    assert strategy_module_0._display == display
    assert strategy_module_0._host_pinned == True
    assert strategy_module_0.display == display
    assert strategy_module_0._display == display
    assert strategy_module_0._host_pinned == True

# Generated at 2022-06-25 12:15:51.349346
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    num_0 = 1
    str_0 = '3'
    display_0 = Display()
    free_strategy_module_0 = FreeStrategyModule(num_0)
    test_case_0()


# Generated at 2022-06-25 12:15:53.887945
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.free import StrategyModule
    tqm_0 = '6-zW/FW:a'
    # Construction of a StrategyModule object with a string as parameter
    test_case_0(tqm_0)


# Generated at 2022-06-25 12:15:55.006045
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = 'H>'
    strategy_module_1 = StrategyModule(str_1)


# Generated at 2022-06-25 12:15:56.400982
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = '6-zW/FW:a'
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 12:15:56.879546
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:15:57.742045
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except:
        print("\n<< Test case 0 failed >>")

# Generated at 2022-06-25 12:15:58.855174
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = 'yV}`I'
    strategy_module_0 = StrategyModule(str_1)


# Generated at 2022-06-25 12:15:59.625313
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()