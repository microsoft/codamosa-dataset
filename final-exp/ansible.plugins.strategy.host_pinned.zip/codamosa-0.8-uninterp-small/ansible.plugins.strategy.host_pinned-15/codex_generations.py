

# Generated at 2022-06-25 12:08:48.661408
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-25 12:08:51.483797
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
        print('\nTest case 0 passed')
    except Exception as e:
        print('\nTest case 0 failed')
        print(e)

# Generated at 2022-06-25 12:08:53.506401
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Oi@^b<aUHiB:|fuPyQa'
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 12:08:56.312680
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Oi@^b<aUHiB:|fuPyQa'
    strategy_module_0 = StrategyModule(str_0)

if __name__ == '__main__':
    test_StrategyModule()
    test_case_0()

# Generated at 2022-06-25 12:08:57.447463
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = 'yxRl^xBf.AiK|=?[qGpp'
    strategy_module_1 = StrategyModule(str_1)


# Generated at 2022-06-25 12:08:58.974280
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:09:02.626341
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'eB1_bp}#cOZ'
    strategy_module_0 = StrategyModule(str_0)
    assert len(str_0) > 0, 'AssertionError'


# Generated at 2022-06-25 12:09:05.804055
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Oi@^b<aUHiB:|fuPyQa'
    strategy_module_0 = StrategyModule(str_0)
    assert strategy_module_0._host_pinned == True

# Generated at 2022-06-25 12:09:08.972185
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task_queue_manager_0 = 'Oi@^b<aUHiB:|fuPyQa'
    strategy_module_0 = StrategyModule(task_queue_manager_0)


# Generated at 2022-06-25 12:09:09.961035
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule('')


# Generated at 2022-06-25 12:09:16.496262
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Oi@^b<aUHiB:|fuPyQa'
    strategy_module_0 = StrategyModule(str_0)
    assert isinstance(strategy_module_0._host_pinned, bool)
    assert strategy_module_0._host_pinned

# Generated at 2022-06-25 12:09:20.803068
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'K|4b!U6!XG<;[~D,p)d'
    StrategyModule(str_0)


# Generated at 2022-06-25 12:09:24.779004
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'TUk42]b*T<9'
    display_0 = Display()
    strategy_module_0 = StrategyModule(str_0)
    strategy_module_0.display = display_0


# Generated at 2022-06-25 12:09:28.146187
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Oi@^b<aUHiB:|fuPyQa'
    strategy_module_0 = StrategyModule(str_0)
    assert_equal(strategy_module_0._host_pinned, True)


# Generated at 2022-06-25 12:09:29.075153
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:09:34.537266
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_4 = 'Oi@^b<aUHiB:|fuPyQa'
    strategy_module_0 = StrategyModule(str_4)
    assert strategy_module_0._host_pinned
    assert strategy_module_0.DONE
    assert strategy_module_0.UNREACHABLE
    assert strategy_module_0.FAILED_NODES
    assert strategy_module_0.ITERATIONS
    assert strategy_module_0.workers
    assert strategy_module_0.failed_hosts
    assert strategy_module_0.tqm

# Generated at 2022-06-25 12:09:36.225717
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ansible_0 = 'Oi@^b<aUHiB:|fuPyQa'

    StrategyModule(ansible_0)


# Generated at 2022-06-25 12:09:40.928529
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)
    strategy_module_0 = StrategyModule(strategy_module_0)
    assert isinstance(strategy_module_0, StrategyModule)

# Generated at 2022-06-25 12:09:43.073612
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # 1) Initializes an object of StrategyModule with constructor
    #test_case_0()
    pass


# Generated at 2022-06-25 12:09:53.928440
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Oi@^b<aUHiB:|fuPyQa'
    str_1 = 'nh^up4ZjX<&'
    str_2 = 'nh^up4ZjX<&'
    str_3 = 'nh^up4ZjX<&'
    strategy_module_0 = StrategyModule(str_0)
    strategy_module_1 = StrategyModule(str_1)
    strategy_module_2 = StrategyModule(str_2)
    strategy_module_3 = StrategyModule(str_3)
    assert_equals(strategy_module_0._tqm, str_0)
    assert_equals(strategy_module_1._tqm, str_1)

# Generated at 2022-06-25 12:10:03.807704
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'C#Gpf#_[O$$B*8l#t%Bw'
    thread_queue_manager_0 = ThreadQueueManager(str_0)
    # VERIFY_IS_INSTANCE(thread_queue_manager_0, ThreadQueueManager)
    if not isinstance(thread_queue_manager_0, ThreadQueueManager):
        print('Expected isinstance(thread_queue_manager_0, ThreadQueueManager) to be True')
        return
    str_1 = 'aGeJY;%]|XdSu+x<>BSM'
    strategy_module_0 = StrategyModule(str_1)
    # VERIFY_IS_INSTANCE(strategy_module_0, StrategyModule)

# Generated at 2022-06-25 12:10:06.414989
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Oi@^b<aUHiB:|fuPyQa'
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 12:10:08.388363
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:10:11.258266
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Oi@^b<aUHiB:|fuPyQa'
    strategy_module_0 = StrategyModule(str_0)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:10:17.134035
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Tests that the constructor of a class is working as expected
    # Initialize the object defined above
    # Test if the object is initialized
    # Test if the object is initialized as expected
    assert strategy_module_0 == "Oi@^b<aUHiB:|fuPyQa", 'StrategyModule constructor is not working as expected'
    assert not strategy_module_0 == "BasicStrategyModule", 'StrategyModule constructor is not working as expected'

# Generated at 2022-06-25 12:10:21.259855
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    name = 'ansible.plugins.strategy.host_pinned.StrategyModule'
    strategy_module = StrategyModule(name)
    assert strategy_module.get_name() == name
    assert str(strategy_module) == '<ansible.plugins.strategy.host_pinned.StrategyModule object'


# Generated at 2022-06-25 12:10:23.548256
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Oi@^b<aUHiB:|fuPyQa'
    strategy_module_0 = StrategyModule(str_0)

    assert isinstance(strategy_module_0, StrategyModule)


# Generated at 2022-06-25 12:10:30.141723
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    from ansible.utils.display import Display
    display = Display()
    str_0 = 'Oi@^b<aUHiB:|fuPyQa'
    strategy_module_0 = StrategyModule(str_0)
    assert(strategy_module_0._host_pinned)
    assert(strategy_module_0._tqm)
    assert(FreeStrategyModule)
    assert(display)


# Generated at 2022-06-25 12:10:34.784744
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Oi@^b<aUHiB:|fuPyQa'
    strategy_module_0 = StrategyModule(str_0)
    str_1 = 'Oi@^b<aUHiB:|fuPyQa'
    str_2 = strategy_module_0._host_pinned
    assert(str_1 == str_2)



# Generated at 2022-06-25 12:10:38.190814
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule
    except NameError:
        raise NameError("Unable to find StrategyModule")

if __name__ == '__main__':
    test_StrategyModule()


# Testing for class constructor for StrategyModule

# Generated at 2022-06-25 12:10:45.101463
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        assert StrategyModule
    except NameError:
        raise AssertionError('StrategyModule not defined.')
    assert '_host_pinned' in dir(StrategyModule)


# Generated at 2022-06-25 12:10:46.468087
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  strategy_module_0 = StrategyModule('Oi@^b<aUHiB:|fuPyQa')

test_StrategyModule()

# Generated at 2022-06-25 12:10:48.076767
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as e:
        display.debug('Error: ' + str(e))
        assert(False)

# Generated at 2022-06-25 12:10:50.482049
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Oi@^b<aUHiB:|fuPyQa'
    strategy_module_0 = StrategyModule(str_0)


# Unit test to check the method strategy of class StrategyModule

# Generated at 2022-06-25 12:10:52.732686
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = 'tqm'
    strategy_module_1 = StrategyModule(str_1)


# Generated at 2022-06-25 12:10:54.670092
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Oi@^b<aUHiB:|fuPyQa'
    strategy_module_0 = StrategyModule(str_0)
    assert strategy_module_0._host_pinned == True

# Generated at 2022-06-25 12:10:56.024549
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule), '"StrategyModule" is not callable'

test_StrategyModule()

# Generated at 2022-06-25 12:11:08.191788
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Oi@^b<aUHiB:|fuPyQa'
    strategy_module_0 = StrategyModule(str_0)
    display_0 = StrategyModule(str_0)
    display_1 = display_0
    display_0 = strategy_module_0
    display_1 = str_0
    display_1 = display_0
    display_0 = str_0
    display_0 = StrategyModule(str_0)
    display_0 = str_0
    display_1 = strategy_module_0
    display_0 = display_1
    display_1 = str_0
    display_1 = strategy_module_0
    display_0 = display_1
    display_0 = str_0
    display_1 = display_0

# Generated at 2022-06-25 12:11:11.609990
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = 'N<Ec[RlE?_a]e'
    strategy_module_1 = StrategyModule(str_1)


# Generated at 2022-06-25 12:11:14.871097
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Oi@^b<aUHiB:|fuPyQa'
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 12:11:23.450538
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    test_case_0()

# Generated at 2022-06-25 12:11:33.751380
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Oi@^b<aUHiB:|fuPyQa'
    strategy_module_0 = StrategyModule(str_0)
    if strategy_module_0.get__host_pinned():
        strategy_module_0.set__host_pinned(False)
    else:
        strategy_module_0.set__host_pinned(True)
    assert strategy_module_0.get__host_pinned() == False
    strategy_module_0.set__host_pinned(True)
    assert strategy_module_0.get__host_pinned() == True
    assert len(strategy_module_0.get__vault_pass()) == 0
    assert strategy_module_0.get__vault_pass() == ''
    assert strategy_module_0.get__new_stdin

# Generated at 2022-06-25 12:11:36.903575
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ansible_module_0 = ansible_module_Builder()
    ansible_module_0.set_ansible_module_0()
    str_0 = 'Oi@^b<aUHiB:|fuPyQa'
    strategy_module_0 = StrategyModule(str_0)
    strategy_module_0.run_()


# Generated at 2022-06-25 12:11:43.374996
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ansible_playbook_ad_hoc_t_0 = ansible.playbook.play.Play()
    ansible_playbook_ad_hoc_t_0._entries = [ansible_playbook_play_play_t_0, ansible_playbook_play_play_t_0]
    # TODO: Initialize with default values
    strategy_module_0 = StrategyModule(ansible_playbook_ad_hoc_t_0, ansible_playbook_ad_hoc_t_0)


test_case_0()

# Generated at 2022-06-25 12:11:45.527992
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Oi@^b<aUHiB:|fuPyQa'
    strategy_module_0 = StrategyModule(str_0)
    # This test is incomplete. Skip it for now.
    pass

# Generated at 2022-06-25 12:11:54.882832
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Oi@^b<aUHiB:|fuPyQa'
    strategy_module_0 = StrategyModule(str_0)
    assert str(strategy_module_0) == "<ansible.plugins.strategy.host_pinned.StrategyModule object at 0x7fd8d661c550>"

# Generated at 2022-06-25 12:11:56.250310
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:11:56.988509
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:11:58.274737
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:11:59.959003
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Dn"d>_!yC'
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 12:12:21.422125
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    display.debug("doing StrategyModule.__init__")
    assert True  # todo: implement your test here


# Generated at 2022-06-25 12:12:23.769766
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        assert not True
    except AssertionError:
        test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:12:26.632188
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Y^l${o8}lWw1O'
    strategy_module_0 = StrategyModule(str_0)
    # ValueError: No hosts matched
    strategy_module_0.run()


if __name__ == '__main__':
    test_case_0()
    # test_StrategyModule()

# Generated at 2022-06-25 12:12:27.790260
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:12:29.384590
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Oi@^b<aUHiB:|fuPyQa'
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 12:12:31.301450
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Oi@^b<aUHiB:|fuPyQa'
    strategy_module_0 = StrategyModule(str_0)



if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:12:33.634182
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_arg = 'Oi@^b<aUHiB:|fuPyQa'
    str_ret_expected = 'Oi@^b<aUHiB:|fuPyQa'
    strategy_module_instance = StrategyModule(str_arg)
    str_ret = strategy_module_instance.tqm
    assert str_ret == str_ret_expected


# Generated at 2022-06-25 12:12:34.362024
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   test_case_0()

# Generated at 2022-06-25 12:12:35.214885
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:12:39.997178
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test for constructor of class StrategyModule
    '''
    # Case 0:
    try:
        test_case_0()
    except Exception as e:
        # print(e)
        assert type(e) == AssertionError

# Generated at 2022-06-25 12:13:21.497810
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(['-s', __file__]))

# Generated at 2022-06-25 12:13:22.664435
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except:
        print('Test Failed')
    else:
        print('Test Passed')

# Generated at 2022-06-25 12:13:25.107880
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(str)
    # mock as callable
    a.get_host_pinned = True
    assert a.get_host_pinned() == True


# Generated at 2022-06-25 12:13:27.832323
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    strategy_module_0 = StrategyModule(str)
    assert strategy_module_0._host_pinned == True
    assert strategy_module_0.tqm == str


# Generated at 2022-06-25 12:13:29.427207
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)


# Generated at 2022-06-25 12:13:31.338214
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global_task_queue = ' '
    strategy_module = StrategyModule(global_task_queue)


# Generated at 2022-06-25 12:13:33.960702
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Oi@^b<aUHiB:|fuPyQa'
    strategy_module_0 = StrategyModule(str_0)
    assert strategy_module_0._host_pinned == True

# Generated at 2022-06-25 12:13:34.718641
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:13:35.555415
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Constructor without arguments
    try:
        StrategyModule()
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-25 12:13:42.016535
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Oi@^b<aUHiB:|fuPyQa'
    strategy_module_0 = StrategyModule(str_0)
    assert isinstance(strategy_module_0, StrategyModule)
    assert isinstance(strategy_module_0._host_pinned, bool)
    assert isinstance(strategy_module_0._tqm, str)
    assert isinstance(strategy_module_0._workers, int)
    assert isinstance(strategy_module_0._stats, dict)
    assert isinstance(strategy_module_0._display, Display)
    assert isinstance(strategy_module_0._batch_size, int)
    assert isinstance(strategy_module_0._cur_worker, int)

# Generated at 2022-06-25 12:15:10.295442
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = 'Oi@^b<aUHiB:|fuPyQa'
    strategy_module_1 = StrategyModule(str_1)


# Generated at 2022-06-25 12:15:11.538786
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Test constructor of class StrategyModule')
    # Test with no parameters
    test_case_0()

# Generated at 2022-06-25 12:15:20.173352
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(str_0)
    assert len(strategy_module_0.__dict__['_hosts']) == 0
    assert len(strategy_module_0.__dict__['_unprocessed_pending_results']) == 0
    assert strategy_module_0.__dict__['_default_qsize'] == 0
    assert strategy_module_0.__dict__['_sent_nack'] == False
    assert strategy_module_0.__dict__['_tqm'] == 'Oi@^b<aUHiB:|fuPyQa'
    assert strategy_module_0.__dict__['_loader'] == 'Oi@^b<aUHiB:|fuPyQa'

# Generated at 2022-06-25 12:15:21.906309
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = 'p'
    tqm = host
    strategy_module = StrategyModule(tqm)
    assert not strategy_module._display._verbosity > 1


# Generated at 2022-06-25 12:15:22.596488
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:15:24.727214
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Oi@^b<aUHiB:|fuPyQa'
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 12:15:29.868476
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Oi@^b<aUHiB:|fuPyQa'
    assert type(str_0) is str
    strategy_module_0 = StrategyModule(str_0)
    assert type(strategy_module_0) is StrategyModule
    assert strategy_module_0.__class__.__bases__[0].__name__ == 'FreeStrategyModule'
    assert strategy_module_0._host_pinned == True

test_case_0()
test_StrategyModule()

# Generated at 2022-06-25 12:15:32.950890
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = '<F1{iOj@$HxT"|sWEoai'
    strategy_module_1 = StrategyModule(str_1)
    assert str_1 == strategy_module_1._tqm
    assert strategy_module_1._host_pinned


# Unit Tests for StrategyModule class methods


# Generated at 2022-06-25 12:15:33.921165
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Testing constructor of class StrategyModule')
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:15:41.458039
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  str = 'Oi@^b<aUHiB:|fuPyQa'
  strategy_module = StrategyModule(str)
  if hasattr(strategy_module,'_host_pinned')!=True:
    print("host_pinned is not present")
    return False
  if strategy_module._host_pinned!=True:
    print("host_pinned is not set to true")
    return False
  return True