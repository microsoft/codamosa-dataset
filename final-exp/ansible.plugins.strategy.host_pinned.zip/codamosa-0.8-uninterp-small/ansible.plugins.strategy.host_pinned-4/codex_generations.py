

# Generated at 2022-06-25 12:08:51.157789
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:08:52.608657
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.5
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:08:55.159850
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import pytest
    with pytest.raises(TypeError) as excinfo:
        StrategyModule(float)
    the_exception=excinfo.value
    assert '' == the_exception.args[0]

# Generated at 2022-06-25 12:08:55.635429
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:08:56.903705
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.5
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:08:58.409774
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.5
    strategy_module_0 = StrategyModule(float_0)
# Test signature of StrategyModule.run

# Generated at 2022-06-25 12:09:03.830660
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display_0 = Display()
    float_0 = 0.5
    strategy_module_0 = StrategyModule(float_0)
    assert isinstance(display_0, Display)
    assert isinstance(float_0, float)
    assert isinstance(strategy_module_0, StrategyModule)
    assert strategy_module_0._host_pinned == True
    assert strategy_module_0._display == display_0
    assert strategy_module_0._tqm == float_0
    assert strategy_module_0._runners is None
    assert strategy_module_0._inventory is None
    assert strategy_module_0._variable_manager is None
    assert strategy_module_0._loader is None
    return strategy_module_0
    # Should return StrategyModule object


if __name__ == '__main__':
    test_Str

# Generated at 2022-06-25 12:09:06.136022
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.5
    strategy_module_0 = StrategyModule(float_0)
    field_0 = strategy_module_0._host_pinned
    assert field_0


# Generated at 2022-06-25 12:09:06.787577
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:09:16.466496
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(float_0)

    assert strategy_module_0 is not None
    assert strategy_module_0._host_pinned is True
    assert strategy_module_0._blockers == {}
    assert strategy_module_0.display is not None
    assert strategy_module_0.get_hosts_left_to_run(inventory, play) == []
    assert strategy_module_0.get_tasks_left_to_run(inventory, play) == []
    assert strategy_module_0.queue_task(host, task, task_vars, play_context) == (False, False)
    assert strategy_module_0.add_tasks(inventory, play, play_context, variable_manager, loader, templar) == True

# Generated at 2022-06-25 12:09:19.603039
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.5
    strategy_module_0 = StrategyModule(float_0)
    assert strategy_module_0



# Generated at 2022-06-25 12:09:20.482299
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:09:21.446899
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    pass

# Generated at 2022-06-25 12:09:21.972165
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:09:24.528630
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.5
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:09:26.232466
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.5
    strategy_module_0 = StrategyModule(float_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:09:27.290812
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:09:28.879308
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.5
    strategy_module_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:09:30.336761
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.5
    strategy_module_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:09:31.997868
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.5
    strategy_module_0 = StrategyModule(float_0)


test_case_0()
test_StrategyModule()

# Generated at 2022-06-25 12:09:37.974549
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:09:41.802564
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.5
    strategy_module_0 = StrategyModule(float_0)


if __name__ == '__main__':

    test_case_0()

# Generated at 2022-06-25 12:09:44.035937
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.5
    strategy_module_0 = StrategyModule(float_0)



# Generated at 2022-06-25 12:09:46.928440
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.5
    strategy_module_0 = StrategyModule(float_0)


if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-25 12:09:57.084322
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-25 12:09:58.891133
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:10:01.634216
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    float_0 = 0.5
    strategy_module_0 = StrategyModule(float_0)

    float_0 = 0.5
    strategy_module_0 = StrategyModule(float_0)

    assert strategy_module_0._host_pinned == True

# Generated at 2022-06-25 12:10:02.395474
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:10:04.462642
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.5
    num_0 = StrategyModule(float_0)
    print('Unit Test Case 0 passed')


# Generated at 2022-06-25 12:10:06.463307
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.5
    fl = float_0
    strategy_module_0 = StrategyModule(fl)


# Generated at 2022-06-25 12:10:18.800051
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_1 = 0.5
    strategy_module_1 = StrategyModule(float_1)
    assert isinstance(strategy_module_1, StrategyModule)

test_case_0()

# Generated at 2022-06-25 12:10:20.752777
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.5
    strategy_module_0 = StrategyModule(float_0)

test_case_0()
#test_StrategyModule()

# Generated at 2022-06-25 12:10:21.767382
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(0)


# Generated at 2022-06-25 12:10:23.278596
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_1 = 0.5
    strategy_module_1 = StrategyModule(float_1)


# Unit tests for testing StrategyModule class

# Generated at 2022-06-25 12:10:27.468250
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # in tuple (expected_value, value_to_test)
    l_tests = [
      # if True
      (True, True),
      # if False
      (False, False),
      # if None
      (False, None),
      # if False
      (False, False),
      # if True
      (True, True),
      # if False
      (False, False),
      # if None
      (False, None),
      # if None
      (False, None),
    ]


# Generated at 2022-06-25 12:10:28.180932
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:10:29.331471
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.5
    test_case_0()


# Generated at 2022-06-25 12:10:30.526088
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.5
    test_case_0()

# End of test case for constructor of class StrategyModule

# Generated at 2022-06-25 12:10:33.110587
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# End of test cases for constructor of class StrategyModule

###############################################################################


# Generated at 2022-06-25 12:10:34.173267
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:10:52.325552
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test with a pipeline file
    PIPELINE_FILE = 'tests/files/test_pipeline.xml'
    tqm = TestQueueManager(1, PIPELINE_FILE, 'local')
    strtgy_mod = StrategyModule(tqm)

    # Test with another pipeline file
    PIPELINE_FILE = 'tests/files/test_pipeline_1.xml'
    tqm = TestQueueManager(1, PIPELINE_FILE, 'local')
    strtgy_mod = StrategyModule(tqm)

    # Test with another pipeline file
    PIPELINE_FILE = 'tests/files/test_pipeline_2.xml'
    tqm = TestQueueManager(1, PIPELINE_FILE, 'local')
    strtgy_mod = StrategyModule

# Generated at 2022-06-25 12:10:54.227130
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.5
    strategy_module_0 = StrategyModule(float_0)
    strategy_module_1 = StrategyModule(None)


# Generated at 2022-06-25 12:10:55.149666
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:10:57.395493
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ""
    strategymodule = StrategyModule(tqm)
    assert strategymodule is not None 
    assert type(strategymodule) is StrategyModule 


# Generated at 2022-06-25 12:11:00.848011
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    obj = StrategyModule(tqm)
    assert type(obj) == StrategyModule

# Generated at 2022-06-25 12:11:02.092106
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    test_FreeStrategyModule()
    # TODO: Add more tests here.

# Generated at 2022-06-25 12:11:04.606308
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()
    if(obj._host_pinned):
        print("Host pinned")
    else:
        print("Host unpinned")


# Generated at 2022-06-25 12:11:07.038355
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:11:11.752324
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test for constructor of StrategyModule.
    # Initialize the object for StrategyModule
    tqm = None
    obj_StrategyModule = StrategyModule(tqm)
    # Assertion of test case
    # assert obj_StrategyModule == StrategyModule(tqm)


# Generated at 2022-06-25 12:11:14.617609
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.5
    # check if StrategyModule has been properly constructed
    assert(test_case_0 is StrategyModule)

# Generated at 2022-06-25 12:11:32.867445
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Call constructor method of class StrategyModule
    try:
        test_case_0()
    except Exception as err:
        print("Exception when calling test_case_0()")
        print(err)

# Generated at 2022-06-25 12:11:35.686825
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = None
        StrategyModule(tqm)
        assert True
    except UnboundLocalError as e:
        display.error("UnboundLocalError: %s" % e)
        assert False


# Generated at 2022-06-25 12:11:37.422222
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    test_case_0()
    strategy_module = StrategyModule(tqm)
    strategy_module.__init__(tqm)


# Generated at 2022-06-25 12:11:39.179582
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = test_StrategyModule()
    test_StrategyModule = StrategyModule(tqm)


# Generated at 2022-06-25 12:11:43.579619
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_1 = 0.4
    strategy_0 = StrategyModule(float_1)
    float_2 = 0.2
    float_3 = 0.5
    float_4 = float_2 + float_3
    assert float_4 == strategy_0._wait_on_pending_results, "Wrong value returned"


# Generated at 2022-06-25 12:11:44.368116
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()


# Generated at 2022-06-25 12:11:45.669325
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule_0 = StrategyModule((test_case_0(),))
    strategyModule_0.run()

# Generated at 2022-06-25 12:11:47.796816
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = None
  sm = StrategyModule(tqm)

test_case_0()
test_StrategyModule()

# Generated at 2022-06-25 12:11:49.801528
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    obj = StrategyModule(tqm)
#     assert(obj._host_pinned == True)


# Generated at 2022-06-25 12:11:52.708874
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test with zero arguments
    try:
        StrategyModule()
        assert False
    except TypeError:
        assert True

    # Test with one argument
    try:
        StrategyModule(float_0)
        assert True
    except TypeError:
        assert False

# Generated at 2022-06-25 12:12:15.388192
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Constructor test: Create test StrategyModule.
    '''
    display = Display()
    tqm = TaskQueueManager()
    StrategyModule_obj = StrategyModule(tqm)
    assert True

# Generated at 2022-06-25 12:12:16.651347
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except:
        print(str(traceback.format_exc()))

# Generated at 2022-06-25 12:12:18.602984
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: implement test
    pass


if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:12:20.010111
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    test_strategy = StrategyModule(tqm)
    assert(test_strategy._host_pinned == True)

# Generated at 2022-06-25 12:12:21.098334
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-25 12:12:23.862260
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = object()
    tqm = object()
    strategy_module = StrategyModule(tqm, display)
    assert strategy_module is not None


# Generated at 2022-06-25 12:12:25.991411
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # float_0 = 0.5
    # display = Display()
    tqm = StrategyModule(float_0)
    assert tqm._host_pinned == True
    assert tqm.tqm == float_0


# Generated at 2022-06-25 12:12:27.297884
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

    tqm ="tqm"
    StrategyModule(tqm)
    return


# Generated at 2022-06-25 12:12:28.525403
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# unit tests
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:12:29.270668
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    test_case_1()



# Generated at 2022-06-25 12:12:49.810642
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.5
    strategy_module_0 = StrategyModule(float_0)

test_case_0()
test_StrategyModule()

# Generated at 2022-06-25 12:12:50.863563
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:12:57.138877
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ansible_play_0 = AnsiblePlay(name="test_case", hosts=[], gather_facts="no", vars=[])
    ansible_playbook_0 = AnsiblePlaybook(user="ansible", plays=[ansible_play_0], inventory=None)
    ansible_executor_0 = AnsibleExecutor(playbook=ansible_playbook_0, forks=1, forks_child=1)
    ansible_playbook_executor_0 = AnsiblePlaybookExecutor(ansible_executor_0, ansible_playbook_0)
    test_case_0(ansible_playbook_executor_0)

# Generated at 2022-06-25 12:12:57.815554
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:13:01.021254
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(None)

    assert strategy_module_0._host_pinned == True
    
if __name__ == "__main__":
    test_StrategyModule()
    print('StrategyModule constructor: OK passed all tests')
    test_case_0()

# Generated at 2022-06-25 12:13:03.229964
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Since 'tqm' parameter is a reference to object StrategyModule,
    # so it should be valid before constructing a StrategyModule object
    float_0 = 0.5
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:13:03.874629
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:13:05.832410
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.5
    task_queue_manager_0 = TaskQueueManager(float_0)
    strategy_module_0 = StrategyModule(task_queue_manager_0)


# Generated at 2022-06-25 12:13:06.422670
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:13:07.647803
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Main function
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:13:51.179517
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  float_0 = 0.5
  strategy_module_0 = StrategyModule(float_0)
  assert strategy_module_0._host_pinned == True 


# Generated at 2022-06-25 12:13:54.693497
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
# TEST CASE: test_case_0 function

# Unit test: def test_case_0

# Function: test_case_0
#float_0 = 0.5
#strategy_module_0 = StrategyModule(float_0)
# END OF TEST CASE: test_case_0

# Generated at 2022-06-25 12:13:55.999585
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.5
    strategy_module_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:13:57.823677
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.5
    strategy_module_0 = StrategyModule(float_0)
    assert strategy_module_0._host_pinned == True


# Generated at 2022-06-25 12:13:59.294946
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.5
    strategy_module_0 = StrategyModule(float_0)
    assert True


# Generated at 2022-06-25 12:14:01.067783
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    float_0 = 0.5
    strategy_module_0 = StrategyModule(float_0)

    assert type(strategy_module_0) == StrategyModule


# Generated at 2022-06-25 12:14:01.759391
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:14:05.541424
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    string_0 = "jk@t(ioBGE3fh#HmP^55!mj*wGho4'4>8Djkf35[a5Nl2C0`X?:j@xoELPWM6kD"
    float_0 = 0.6
    strategy_module_0 = StrategyModule(string_0)
    assert strategy_module_0 != None
    strategy_module_0 = StrategyModule(float_0)
    assert strategy_module_0 != None

# Generated at 2022-06-25 12:14:07.272029
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.5
    strategy_module_1 = StrategyModule(float_0)
    assert isinstance(strategy_module_1, StrategyModule)


# Generated at 2022-06-25 12:14:08.956027
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(0)
    assert strategy_module_0._host_pinned


# Generated at 2022-06-25 12:15:41.246279
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:15:42.650608
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    assert strategy_module_0._host_pinned == 1

# Generated at 2022-06-25 12:15:43.923952
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.5
    try:
        strategy_module_0 = StrategyModule(float_0)
    except:
        print("Test failed")

# Generated at 2022-06-25 12:15:44.510942
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(0.5)



# Generated at 2022-06-25 12:15:45.503836
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.5
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:15:47.336318
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    float_0 = 0.5
    strategy_module_0 = StrategyModule(float_0)

    # assert strategy_module_0._host_pinned is boolean
    # assert strategy_module_0._hashed_hosts is dict


# Generated at 2022-06-25 12:15:48.707202
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Test constructor of StrategyModule instantiates StrategyModule object
    '''

    assert_true(test_case_0())

test_case_0()

# Generated at 2022-06-25 12:15:49.294694
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:15:51.678289
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    float_0 = 0.5
    strategy_module_0 = StrategyModule(float_0)
    # self.assertIsInstance(strategy_module_0, StrategyModule)
    test_case = strategy_module_0
    assert type(test_case) == StrategyModule

test_case_0()

# Generated at 2022-06-25 12:15:52.874999
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.5
    strategy_module_0 = StrategyModule(float_0)
