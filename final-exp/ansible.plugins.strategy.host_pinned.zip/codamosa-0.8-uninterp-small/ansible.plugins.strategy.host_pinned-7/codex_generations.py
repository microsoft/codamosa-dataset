

# Generated at 2022-06-25 12:08:50.441458
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:08:53.506421
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xad\xa1\xd1\xea\xaa?\xcb\xb2\xdf\xe7!\x13\xc79\xea\xfa'
    strategy_module_0 = StrategyModule(bytes_0)

# Generated at 2022-06-25 12:08:54.437959
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()



# Generated at 2022-06-25 12:08:55.764212
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    assert StrategyModule(bytes_0)


# Generated at 2022-06-25 12:08:59.605022
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-25 12:09:04.473101
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_4 = StrategyModule(bytes_0)
    return strategy_module_4


# Generated at 2022-06-25 12:09:07.453149
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)



# Generated at 2022-06-25 12:09:10.157697
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    args_0 = {
        'num_hosts': 1,
    }
    display_0 = Display()
    strategy_module_0 = StrategyModule(display_0)

# Generated at 2022-06-25 12:09:10.841331
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:09:15.015079
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:09:28.349618
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Init of class StrategyModule
    display_0 = module_0.Display()

# Generated at 2022-06-25 12:09:29.593945
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    test_1 = StrategyModule(tqm_0)
    assert test_1 != None

# Generated at 2022-06-25 12:09:30.381707
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=(Display()))

# Generated at 2022-06-25 12:09:37.257224
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-25 12:09:41.066188
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm_obj = StrategyModule(test_case_0)
    assert tqm_obj._host_pinned == True

# Generated at 2022-06-25 12:09:44.437609
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    try:
        StrategyModule(tqm)
    except Exception as err:
        print(err)
        
    print('Constructor test passed')
    

# Generated at 2022-06-25 12:09:48.048971
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm_0 = None
    x = StrategyModule(tqm_0)
    assert isinstance(x, StrategyModule)


if __name__ == "__main__":
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:09:49.386543
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert TestStrategyModule.__name__ == 'TestStrategyModule'


# Generated at 2022-06-25 12:09:55.047372
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    (tqm) = None
    try:
        StrategyModule(tqm)
    except TypeError as te:
        print('TypeError raised: ')
        print(te.args)
        assert(0)
    except Exception as e:
        print('Exception raised: ')
        print(e.args)
        assert(0)
    else:
        assert(1)


# Generated at 2022-06-25 12:09:56.825657
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy_module_1 = StrategyModule(tqm)


# Generated at 2022-06-25 12:10:02.825794
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)
    strategy_module_1 = StrategyModule(strategy_module_0)
    assert strategy_module_0 == strategy_module_1
    assert strategy_module_0 is not strategy_module_1


# Generated at 2022-06-25 12:10:07.763222
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)
    assert (strategy_module_0._host_pinned == True)

# Generated at 2022-06-25 12:10:09.507297
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test_StrategyModule")
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:10:10.306681
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:10:19.785831
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)
    # assert Raises(NotImplementedError, strategy_module_0.run)
    assert Raises(NotImplementedError, strategy_module_0.get_hosts)
    bytes_1 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_1 = StrategyModule(bytes_1)
    # assert Raises(NotImplementedError, strategy_module_1.run)

# Generated at 2022-06-25 12:10:20.650538
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:10:21.667003
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # unit test for StrategyModule.__init__
    test_case_0()

# Generated at 2022-06-25 12:10:24.311510
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)
    assert True


# Generated at 2022-06-25 12:10:29.605202
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)
    assert isinstance(strategy_module_0, StrategyModule) is True


# Generated at 2022-06-25 12:10:33.871387
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xae\xbd\xbd\x8c\x9d\x1e\x91\x0c\x06\x98\x80\xe6\x93\xc9\x9d\xae'
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:10:43.137072
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_1 = b'\x82\x8c*\xa2\x09\xe1\x97\x8aw\x9a\x13\x8e\xfb\xfb>\x81R\x82\x8b\x9aw\x9a"\xa2\x0b\xf0T\xcf\xa7E\xba\xfe\xc9\xe1\xf7'
    tqm_0 = bytes_1
    strategy_module_1 = StrategyModule(tqm_0)
    assert not hasattr(strategy_module_1, '_host_pinned')


if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:10:46.839901
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:10:49.838406
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:10:53.515123
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:10:54.168881
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:10:57.475542
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:11:02.413045
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import tempfile, shutil
    try:
        tempdir = tempfile.mkdtemp()
        test_case_0()
    finally:
        shutil.rmtree(tempdir)

# Generated at 2022-06-25 12:11:07.037001
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)
    strategy_module_0._host_pinned = True

# Generated at 2022-06-25 12:11:11.752279
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)

test_case_0()

# Generated at 2022-06-25 12:11:18.579223
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.display('UNIT TESTING  --------- Running test method: test_StrategyModule')
    test_case_0()


if __name__ == "__main__":
    display.display('UNIT TESTING  --------- Starting test cases for class StrategyModule')
    test_StrategyModule()
    display.display('UNIT TESTING  --------- Completed test cases for class StrategyModule')

# Generated at 2022-06-25 12:11:26.192608
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
        bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
        strategy_module_0 = StrategyModule(bytes_0)

# Generated at 2022-06-25 12:11:29.685286
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(None)
    print(strategy_module_0)
    assert(strategy_module_0.get_hosts_left_to_run() == None)


# Generated at 2022-06-25 12:11:31.862322
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except:
        print(len(bytes_0))
        raise  # re-raise the exception

# Generated at 2022-06-25 12:11:37.652708
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_1 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_1 = StrategyModule(bytes_1)
    assert repr(strategy_module_1) == "<StrategyModule(tqm=b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!\"\xfe')>"


# Generated at 2022-06-25 12:11:46.110396
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Arrange
    tqm_0 = b'\xa5eH\x7f\x8b\x8b\x14\xaa\xeaU\x83'

    # Act
    strategy_module_0 = StrategyModule(tqm_0)

    # Assert
    assert strategy_module_0._tqm == tqm_0
    assert strategy_module_0._queue_name == 'serial'
    assert strategy_module_0._enabled == True
    assert strategy_module_0._display.verbosity == 4
    assert strategy_module_0._display.colored == True

# Generated at 2022-06-25 12:11:49.801721
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)

# Generated at 2022-06-25 12:11:58.130129
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    host_list_0 = ['dummy_host']
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    display.verbosity = 4
    display.deprecated('\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe')
    display.display('\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe', color='cyan')
    strategy_module_0 = StrategyModule(bytes_0)

# Generated at 2022-06-25 12:11:59.489184
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule(1)
    assert x is not None

# Generated at 2022-06-25 12:12:01.860564
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule('\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe')


# Generated at 2022-06-25 12:12:04.777145
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'l\x0c\xcd\x1e\x083\xcf\x19\x01\xe5\xce\xb5\x98\xac\x0c\x1f\x1a\x0f6\xad'
    strategy_module_1 = StrategyModule(bytes_0)

# Generated at 2022-06-25 12:12:21.011055
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)
    assert isinstance(strategy_module_0, StrategyModule)
    assert isinstance(strategy_module_0._host_pinned, bool)
    assert isinstance(strategy_module_0._tqm, bytes)
    assert isinstance(strategy_module_0.display, Display)
    assert isinstance(strategy_module_0.number_of_workers, int)



# Generated at 2022-06-25 12:12:21.634131
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-25 12:12:23.332463
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
  strategy_module_0 = StrategyModule(bytes_0)

# Generated at 2022-06-25 12:12:25.211860
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)
    assert strategy_module_0._host_pinned == True



# Generated at 2022-06-25 12:12:27.439021
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:12:29.903370
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:12:33.446010
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)
    assert (strategy_module_0._host_pinned)
    assert not hasattr(strategy_module_0, '_queue')
    assert not hasattr(strategy_module_0, '_tqm')

# Generated at 2022-06-25 12:12:34.204438
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-25 12:12:35.063858
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:12:40.605787
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)

if __name__ == "__main__":
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:13:05.911211
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)
# Testing if the constructor of class StrategyModule throws an exception or not when an incorrect number of parameters are passed
# Case 1: No parameters are passed
    try:
        strategy_module_1 = StrategyModule()
    except TypeError:
        pass
    else:
        assert False, "An exception was not raised for an incorrect number of parameters passed to constructor of class StrategyModule."

# Generated at 2022-06-25 12:13:06.500491
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:13:08.868605
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)
    assert strategy_module_0._host_pinned == True

# Generated at 2022-06-25 12:13:10.228315
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    url_0 = 'Q\x05\x8f\xb0\x9e\xfa\x7fa'
    display_0 = Display()
    strategy_module_0 = StrategyModule(url_0)

# Generated at 2022-06-25 12:13:11.842183
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)

# Generated at 2022-06-25 12:13:13.678158
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 12:13:18.270479
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)
    strategy_module_0.run_play()
    strategy_module_0.cleanup()

if __name__ == "__main__":
    test_StrategyModule()
    test_case_0()

# Generated at 2022-06-25 12:13:22.452797
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)
    # Check type of return value.
    assert(type(strategy_module_0) == StrategyModule)


# Generated at 2022-06-25 12:13:24.413584
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # assert_equal(expected, StrategyModule(tqm))
    assert True # TODO: implement your test here


# Generated at 2022-06-25 12:13:26.610028
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create an instance of class StrategyModule
    strategy_module = StrategyModule()


# Generated at 2022-06-25 12:14:10.773840
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:14:18.516913
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    bytes_1 = b''
    bytes_2 = b'\xb16\x81\x0e\xfc\xbe\xcc\xa6\x9c\x1dYl\xc8\xc6\x06\xfd'
    bytes_3 = b'\xc0\x9cH\xdbF\xac\xfbw\xef\xde\xc8\x0e\xd6\x04\xe5\xae'

# Generated at 2022-06-25 12:14:21.520600
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_1 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_1 = StrategyModule(bytes_1)

test_case_0()
test_StrategyModule()

# Generated at 2022-06-25 12:14:23.297482
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    test_case_0()

test_StrategyModule()
# End of test case

# Generated at 2022-06-25 12:14:27.428663
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ansible_config_0 = ansible.module_utils.basic._ANSIBLE_ARGS
    tqm_0 = TaskQueueManager(ansible_config_0)
    strategy_module_0 = StrategyModule(tqm_0)
    assert isinstance(strategy_module_0, StrategyModule)
    assert isinstance(strategy_module_0, StrategyModule)


# Generated at 2022-06-25 12:14:31.334492
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:14:32.192649
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:14:37.782749
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'+\xe3\x8a\x0f\x9d\xfc\x8a\x1f\x02\xc4\xde\x8f1\xeeX'
    strategy_module_0 = StrategyModule(bytes_0)
    assert type(strategy_module_0) == StrategyModule
    assert strategy_module_0._tqm == bytes_0
    assert strategy_module_0._failed_hosts == {}
    # assert strategy_module_0._last_task_banner == 'dummy'
    assert type(strategy_module_0._stats) == dict
    assert strategy_module_0._final_q is None
    assert strategy_module_0._hosts_left is None
    assert strategy_module_0._cur_worker is None
    assert strategy_

# Generated at 2022-06-25 12:14:39.343836
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Variables
    tqm = null

    # Operation
    strategy_module_0 = StrategyModule(tqm)
    assert isinstance(strategy_module_0, StrategyModule)


# Generated at 2022-06-25 12:14:44.261094
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xa4\x95\xc5\xa4\xc5\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:16:18.183230
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:16:20.550496
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:16:25.205638
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)
    if (not strategy_module_0._host_pinned):
        raise Exception('AssertionError')


# Generated at 2022-06-25 12:16:32.823551
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-25 12:16:35.718163
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)
    assert strategy_module_0._host_pinned == True


# Generated at 2022-06-25 12:16:41.926995
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    data = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module = StrategyModule(data)
    assert hasattr(strategy_module, '_host_pinned') == 1 # hasattr(obj, name)
    assert strategy_module._host_pinned == True
    assert hasattr(strategy_module, '_display') == 1 # hasattr(obj, name)
    assert isinstance(strategy_module._display, Display)
    assert hasattr(strategy_module, '_play_context') == 1 # hasattr(obj, name)
    assert hasattr(strategy_module, '_all_hosts') == 1 # hasattr(obj, name)
    assert has

# Generated at 2022-06-25 12:16:46.488107
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)

# Generated at 2022-06-25 12:16:50.272520
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)
    return strategy_module_0

# Generated at 2022-06-25 12:16:52.227761
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x8a*\xa4\x0b\xe8\xf8\xe3\xbc&\xe4\x14\x15g!"\xfe'
    strategy_module_0 = StrategyModule(bytes_0)
    assert strategy_module_0._host_pinned == True

# Generated at 2022-06-25 12:16:54.138404
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'G'
    strategy_module_0 = StrategyModule(bytes_0)

if __name__ == '__main__':
    import sys
    import pytest
    pytest.main(sys.argv)