

# Generated at 2022-06-25 12:08:50.184613
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:08:52.284322
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as e:
        print('FAIL: %s' % e)
        display.verbose(traceback.format_exc())

# Generated at 2022-06-25 12:08:54.165634
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Test constructor of class StrategyModule')
    test_case_0()
    print('Unit test for constructor of class StrategyModule is finished!')


# Generated at 2022-06-25 12:08:55.874674
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = 'R0}2;CL'
    strategy_module_1 = StrategyModule(str_1)


# Generated at 2022-06-25 12:08:57.918983
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'R0}2;CL'
    strategy_module_0 = StrategyModule(str_0)
    assert isinstance(strategy_module_0, StrategyModule)

# Generated at 2022-06-25 12:08:58.577379
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:08:59.448177
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


test_StrategyModule()

# Generated at 2022-06-25 12:09:01.725312
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Run test for test_case_0
    test_case_0()



# Generated at 2022-06-25 12:09:05.952449
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'R0}2;CL'
    strategy_module_0 = StrategyModule(str_0)
    assert str(type(strategy_module_0)) == "<class 'ansible.plugins.strategy.host_pinned.StrategyModule'>"
    assert strategy_module_0._host_pinned == True


# Generated at 2022-06-25 12:09:09.435866
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception:
        pass
    else:
        raise Exception('Failed to catch exception when testing constructor of class StrategyModule.')

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:09:13.345884
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'R0}2;CL'
    strategy_module_0 = StrategyModule(str_0)



# Generated at 2022-06-25 12:09:15.180579
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:09:16.434390
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Q2.*'
    strategy_module_0 = StrategyModule(str_0)

    pass

# Generated at 2022-06-25 12:09:19.399190
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s=StrategyModule("")

# Generated at 2022-06-25 12:09:22.014642
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'R0}2;CL'
    strategy_module_0 = StrategyModule(str_0)
    assert_equals(strategy_module_0._host_pinned, True)


# Generated at 2022-06-25 12:09:24.963045
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'StrategyModule'
    test_case_0()


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:09:28.037051
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'R0}2;CL'
    strategy_module_0 = StrategyModule(str_0)
    # AssertionError: assert strategy_module_0._host_pinned == True
    

# Generated at 2022-06-25 12:09:29.781041
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module_0 = StrategyModule(tqm)


# Generated at 2022-06-25 12:09:32.590036
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    with pytest.raises(TypeError) as excinfo:
        test_case_0()
    the_exception = excinfo.value
    assert str(the_exception) == 'test_case_0() takes 0 positional arguments but 1 was given'


# Generated at 2022-06-25 12:09:33.638395
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Unit tests for module strategy/host_pinned

# Generated at 2022-06-25 12:09:36.233148
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    obj = StrategyModule(tqm)
    assert obj is not None


# Generated at 2022-06-25 12:09:48.579558
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import __main__
    # If the __main__ module has __file__ attribute it is a script and the directory of the script is added to the system path.
    if getattr(__main__, '__file__', None):
        import os.path
        me = os.path.abspath(__main__.__file__)
        if os.path.isdir(me):
            # __main__ is a directory, use this as path
            root_path = me
        else:
            # __main__ is a script, use the directory containing this script
            root_path = os.path.dirname(me)
        if root_path not in sys.path:
            sys.path.append(root_path)
    import ansible.plugins

    print(dir(ansible.plugins))

# Generated at 2022-06-25 12:09:49.913221
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()

    assert strategy_module._host_pinned is True

# Generated at 2022-06-25 12:09:52.503050
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    var_0 = FreeStrategyModule(None)
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:09:58.851926
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule as strategy_host_pinned_StrategyModule
    # TODO: implement test_case_0 for StrategyModule
    # This test case should be used with the following piece of code:
    #
    # str_0 = 'StrategyModule'
    #
    # 	def __init__(self, tqm):
    # 		super(StrategyModule, self).__init__(tqm)
    # 		self._host_pinned = True



# Generated at 2022-06-25 12:10:03.465326
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule

    # Check if class FreeStrategyModule is derived from class StrategyModule
    assert issubclass(StrategyModule, FreeStrategyModule), "Class StrategyModule derives from class FreeStrategyModule"
    # Check instance attributes
    assert hasattr(StrategyModule, '__init__'), "Class StrategyModule has attribute '__init__'"
    # Call method
    test_case_0()


# Generated at 2022-06-25 12:10:08.079170
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.debug('--- Testing StrategyModule() Test Case')
    display.debug('--- Calling StrategyModule().__init__()')
    tqm_0 = None
    sm_0 = StrategyModule(tqm_0)
    assert sm_0._host_pinned == True


# Generated at 2022-06-25 12:10:09.198082
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    instance = StrategyModule()
    assert isinstance(instance, StrategyModule)

# Generated at 2022-06-25 12:10:13.255733
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = StrategyModule(tqm=None)
    assert str_0.__class__ == StrategyModule

    str_1 = StrategyModule(tqm=None)
    assert str_1.__class__ == StrategyModule
    

# Generated at 2022-06-25 12:10:14.425102
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test = StrategyModule(tqm='tqm')


# Generated at 2022-06-25 12:10:18.419389
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()


# Generated at 2022-06-25 12:10:19.177732
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:10:21.135926
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    str_1 = 'R0}2;CL'
    strategy_module_1 = StrategyModule(str_1)


# Generated at 2022-06-25 12:10:23.430017
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Test constructor of class StrategyModule')
    str_1 = 'R0}2;CL'
    strategy_module_1 = StrategyModule(str_1)
    assert strategy_module_1._host_pinned == True


# Generated at 2022-06-25 12:10:27.043432
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    str_0 = "a\r\n"
    strategy_module_0 = StrategyModule(str_0)




# Generated at 2022-06-25 12:10:28.085655
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print("All unit tests for StrategyModule are passed")

# Generated at 2022-06-25 12:10:29.729460
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'R0}2;CL'
    strategy_module_0 = StrategyModule(str_0)



# Generated at 2022-06-25 12:10:30.419803
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:10:34.821224
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    start_time_0 = time.time()
    test_case_0()
    end_time_0 = time.time()
    print('It took {}s'.format(end_time_0 - start_time_0))

if __name__ == '__main__':
    # test_StrategyModule()
    unittest.main()

# Generated at 2022-06-25 12:10:38.190166
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'R0}2;CL'
    strategy_module_0 = StrategyModule(str_0)
    assert strategy_module_0._host_pinned == True
    assert isinstance(strategy_module_0.display, Display)

# Generated at 2022-06-25 12:10:43.819217
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #assert_equals(expected, StrategyModule(tqm))
    assert True # TODO: implement your test here


# Generated at 2022-06-25 12:10:44.592175
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)


# Generated at 2022-06-25 12:10:49.810643
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: Add actual unit tests when methods are added
    str_0 = 'R0}2;CL'
    strategy_module_0 = StrategyModule(str_0)
    assert (strategy_module_0._tqm == str_0)
    assert (strategy_module_0._play_context == None)
    assert (strategy_module_0._iterator == None)

# Generated at 2022-06-25 12:10:52.514534
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = 'R0}2;CL'
    strategy_module_1 = StrategyModule(str_1)
    assert strategy_module_1._host_pinned == True

# Generated at 2022-06-25 12:10:54.526166
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = 'R0}2;CL'
    strategy_module_1 = StrategyModule(str_1)
    assert(strategy_module_1._host_pinned == True)


# Generated at 2022-06-25 12:10:56.734930
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = 'R0}2;CL'
    strategy_module_1 = StrategyModule(str_1)


# Generated at 2022-06-25 12:11:03.334922
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Get value of argument tqm
    tqm_value_StrategyModule_object = StrategyModule.tqm

    # Test method / function
    assert tqm_value_StrategyModule_object == 'R0}2;CL'
    StrategyModule.tqm = 'R0}2;CL'

# Generated at 2022-06-25 12:11:05.264981
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result = test_case_0()
    assert result == "Expected Result"
    print("Test successful")

# Generated at 2022-06-25 12:11:07.099165
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'P#'
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 12:11:09.292115
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'c%6J1'
    strategy_module_0 = StrategyModule(str_0)
    assert strategy_module_0._host_pinned == True


# Generated at 2022-06-25 12:11:15.703455
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(str)
    assert isinstance(strategy_module_0, StrategyModule)


# Generated at 2022-06-25 12:11:18.803016
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'R0}2;CL'
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 12:11:22.001230
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'R0}2;CL'
    strategy_module_0 = StrategyModule(str_0)
    str_1 = 'R0}2;CL'
    assert strategy_module_0 is not None


# Generated at 2022-06-25 12:11:32.526866
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Assert if correct number of arguments are passed
    with pytest.raises(TypeError) as excinfo:
        strategy_module_0 = StrategyModule()
    assert 'Required argument \'tqm\' (pos 1) not found' in str(excinfo.value)
    # Assert if the argument passed is of correct type
    with pytest.raises(TypeError) as excinfo:
        strategy_module_0 = StrategyModule(10)
    assert 'Argument \'tqm\' passed to the StrategyModule constructor must be an instance of `TQM`, not `int`' in str(excinfo.value)
    # Assert if member variables are initialized with the correct value
    str_0 = 'R0}2;CL'
    strategy_module_0 = StrategyModule(str_0)
    assert strategy_module_0._host

# Generated at 2022-06-25 12:11:36.823734
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # initialization of class object
    str_1 = 'R0}2;CL'
    strategy_module_1 = StrategyModule(str_1)
    assert isinstance(strategy_module_1, FreeStrategyModule)
    assert isinstance(strategy_module_1, StrategyModule)
    assert not isinstance(strategy_module_1, object)
# <end of strategy-test-cases>

# Generated at 2022-06-25 12:11:38.347500
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'R0}2;CL'
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 12:11:41.654423
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'R0}2;CL'
    strategy_module_0 = StrategyModule(str_0)
    assert isinstance(strategy_module_0, StrategyModule)



# Generated at 2022-06-25 12:11:43.898426
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = 'R0}2;CL'
    strategy_module_1 = StrategyModule(str_1)
    assert isinstance(strategy_module_1, StrategyModule)


# Generated at 2022-06-25 12:11:46.311862
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    tqm = object
    strategy_module_0 = StrategyModule(tqm)
    strategy_module_0.display = display
    assert strategy_module_0.name == 'Host Pinned'


# Generated at 2022-06-25 12:11:55.733834
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import datetime
    import time

    start = datetime.datetime.now()
    test_case_0()
    end = datetime.datetime.now()
    duration = end - start
    print(duration)

    str_0 = '1wuK3q)O$}qvb^1vE'
    strategy_module_0 = StrategyModule(str_0)

    start = datetime.datetime.now()
    strategy_module_0.__init__(str_0)
    end = datetime.datetime.now()
    duration = end - start
    print(duration)

    time.sleep(1)

    start = datetime.datetime.now()
    strategy_module_0.__init__(str_0)
    end = datetime.datetime.now()
    duration = end - start

# Generated at 2022-06-25 12:12:08.918520
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = 'XB'
    strategy_module_1 = StrategyModule(str_1)

    assert strategy_module_1 is not None


# Generated at 2022-06-25 12:12:14.334937
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test "StrategyModule" is available.
    assert StrategyModule
    # Test constructor is available.
    assert StrategyModule.__init__
    # Test instance of StrategyModule class is available.
    strategy_module_0 = StrategyModule(str_0)
    assert isinstance(strategy_module_0, StrategyModule)
    # Test __init__ method is working.
    assert strategy_module_0
    # Test __init__() is working.
    assert strategy_module_0.__init__
    # Test __init__() is working.
    assert strategy_module_0._host_pinned == True

# Generated at 2022-06-25 12:12:15.453669
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # case_0: test calling constructor
    test_case_0()


# Generated at 2022-06-25 12:12:17.487540
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Run constructor of class StrategyModule, then store and return the result as test result
    test_case_0()
    display.display('Unit test for StrategyModule constructor pass')

test_StrategyModule()

# Generated at 2022-06-25 12:12:19.163501
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task_queue_manager_0 = 'R0}2;CL'
    strategy_module_0 = StrategyModule(task_queue_manager_0)


# Generated at 2022-06-25 12:12:20.043936
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule(None)


# Generated at 2022-06-25 12:12:24.109430
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    flag = False
    str_0 = 'R0}2;CL'
    strategy_module_0 = StrategyModule(str_0)
    flag = True
    if flag:
        print('test_StrategyModule passed!')


test_StrategyModule()
print('All test cases passed!')

# Generated at 2022-06-25 12:12:25.755693
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'R0}2;CL'
    strategy_module_0 = StrategyModule(str_0)
    assert strategy_module_0 is not None


# Generated at 2022-06-25 12:12:31.022841
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #str = 'R0}2;CL'
    #strategy_module = StrategyModule(str)
    #assert strategy_module._display is not None
    #assert strategy_module._tqm is not None
    #assert strategy_module._inventory is not None
    #assert strategy_module._variable_manager is not None
    #assert strategy_module._loader is not None
    #assert strategy_module._options is not None
    #assert strategy_module._blocked_hosts is not None
    #assert strategy_module._failed_hosts is not None
    #assert strategy_module._pending_results is not None
    #assert strategy_module._stats is not None
    #assert strategy_module._workers is not None
    #assert strategy_module._host_pinned is True
    pass


# Generated at 2022-06-25 12:12:36.934481
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'R0}2;CL'
    strategy_module_0 = StrategyModule(str_0)
    assert isinstance(strategy_module_0, StrategyModule) == True
    assert strategy_module_0.__str__() == '<ansible.plugins.strategy.host_pinned.StrategyModule object at 0x1032b7d10>'
    assert strategy_module_0._host_pinned == True


# Generated at 2022-06-25 12:13:01.075986
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 'tqm'
    tqm_0 = FreeStrategyModule(tqm)
    StrategyModule(tqm_0)
    assert None is not tqm_0
    assert '_host_pinned'
    assert 'R0}2;CL' is tqm_0
    assert None is not True



# Generated at 2022-06-25 12:13:03.996256
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = 'R0}2;CL'
    strategy_module_1 = StrategyModule(str_1)
    assert (strategy_module_1._host_pinned)
    assert (strategy_module_1._tqm) == (str_1)


test_StrategyModule()
test_case_0()

# Generated at 2022-06-25 12:13:04.902953
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule('I0uC')

# Generated at 2022-06-25 12:13:06.869211
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    #test with a non-none string
    str_0 = 'R0}2;CL'
    strategy_module_0 = StrategyModule(str_0)
    assert strategy_module_0.get_host_pinned() == True

# Generated at 2022-06-25 12:13:10.281640
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'host_pinned'
    strategy_module_0 = StrategyModule(str_0)
    assert strategy_module_0.get_host_pinned
    assert not strategy_module_0.get_hosts

# Generated at 2022-06-25 12:13:12.123812
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'R0}2;CL'
    strategy_module_0 = StrategyModule(str_0)

# Generated at 2022-06-25 12:13:15.277670
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = 'R0}2;CL'
    strategy_module_1 = StrategyModule(str_1)


# Generated at 2022-06-25 12:13:16.511488
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Unit test for StrategyModule')
    test_case_0()

# If called from the command line, run the unit tests
if __name__ == '__main__':
  test_StrategyModule()

# Generated at 2022-06-25 12:13:17.560590
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule('')
    assert isinstance(strategy_module_0, StrategyModule)
    assert isinstance(strategy_module_0, FreeStrategyModule)

# Generated at 2022-06-25 12:13:19.093681
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Run main program.
if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:14:03.428918
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Kd1c[4NX'
    strategy_module_0 = StrategyModule(str_0)


if __name__ == "__main__":
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:14:04.712273
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'R0}2;CL'
    strategy_module_0 = StrategyModule(str_0)


# Generated at 2022-06-25 12:14:06.155019
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:14:08.827699
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str1 = 'R0}2;CL'
    strategy_module_1 = StrategyModule(str1)
#    print(strategy_module_1)
#    print(type(strategy_module_1))



# Generated at 2022-06-25 12:14:11.741654
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str = 'R0}2;CL'
    strategy_module = StrategyModule(str)
    assert (strategy_module.__class__.__name__ == 'StrategyModule')

test_case_0()

# Generated at 2022-06-25 12:14:12.194602
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-25 12:14:13.800923
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'R0}2;CL'
    strategy_module_0 = StrategyModule(str_0)

# Generated at 2022-06-25 12:14:21.139202
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'R0}2;CL'
    strategy_module_0 = StrategyModule(str_0)
    assert (strategy_module_0._host_pinned is not None)
    assert (strategy_module_0.get_host_list(None) == [])
    assert (strategy_module_0._tqm is not None)
    assert (strategy_module_0._display is not None)
    assert (strategy_module_0._display_queue == [])
    assert (strategy_module_0.tqm is not None)
    assert (strategy_module_0.display is not None)
    assert (strategy_module_0.name == 'host_pinned')
    assert (strategy_module_0._tqm == strategy_module_0.tqm)


# Generated at 2022-06-25 12:14:21.836105
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
                
if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:14:23.297905
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Running unit test for constructor of class StrategyModule')
    test_case_0()


# Generated at 2022-06-25 12:15:55.802842
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # __init__(tqm)
    test_case_0()


# Generated at 2022-06-25 12:15:56.276778
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:16:02.152043
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # set up
    # call the constructor
    ansible_playbook_0 = 'playbook.yml'
    ansible_run_0 = '127.0.0.1'
    ansible_strategy_0 = 'host_pinned'
    ansible_inventory_0 = 'hosts'
    ansible_host_key_checking_0 = False
    ansible_remote_user_0 = 'root'
    ansible_forks_0 = 0

    str_1 = ansible_run_0 + ',' + ansible_strategy_0 + ',' + ansible_inventory_0 + ',' + ansible_host_key_checking_0 + ',' + ansible_remote_user_0 + ',' + ansible_forks_0
    strategy_module_0 = StrategyModule(str_1)


# Generated at 2022-06-25 12:16:06.984367
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    with pytest.raises(TypeError) as excinfo:
        test_case_0()
    assert "object of type 'NoneType' has no len()" in str(excinfo.value)


# Generated at 2022-06-25 12:16:08.619859
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = 'I]fz4'
    strategy_module_1 = StrategyModule(str_1)



# Generated at 2022-06-25 12:16:10.829541
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'R0}2;CL'
    strategy_module_0 = StrategyModule(str_0)
    assert strategy_module_0._host_pinned == True

# Generated at 2022-06-25 12:16:13.165104
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'R0}2;CL'
    strategy_module_0 = StrategyModule(str_0)
    assert isinstance(strategy_module_0, StrategyModule)
    assert hasattr(strategy_module_0, '_host_pinned')
    assert strategy_module_0._host_pinned


# Generated at 2022-06-25 12:16:13.991728
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:16:14.810208
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_1 = 'R0}2;CL'
    strategy_module_1 = StrategyModule(str_1)

# Generated at 2022-06-25 12:16:16.595670
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    str_0 = 'R0}2;CL'
    strategy_module_0 = StrategyModule(str_0)
