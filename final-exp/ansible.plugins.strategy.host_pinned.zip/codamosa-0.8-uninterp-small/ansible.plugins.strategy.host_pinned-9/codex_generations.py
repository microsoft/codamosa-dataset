

# Generated at 2022-06-25 12:08:51.556195
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2196.0
    strategy_module_0 = StrategyModule(float_0)
    assert isinstance(strategy_module_0, StrategyModule)


# Generated at 2022-06-25 12:08:56.447256
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2196.0
    strategy_module_0 = StrategyModule(float_0)

if __name__ == '__main__':
    import sys
    print("Checking if target is a Python version supported by the strategy plugin")
    if sys.version_info[0] == 2 and sys.version_info[1] >= 6 or sys.version_info[0] >= 3:
        test_case_0()
    else:
        print("Unsupported Python version")
        sys.exit(1)

# Generated at 2022-06-25 12:08:57.686386
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule_0 = StrategyModule(float_0)
    assert StrategyModule_0._host_pinned is True


# Generated at 2022-06-25 12:08:59.753921
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
      test_case_0()
    except:
      print("Exception in user code:")
      print('-' * 60)
      traceback.print_exc(file=sys.stdout)
      print('-' * 60)

# Generated at 2022-06-25 12:09:00.805708
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2196.0
    strategy_module_1 = StrategyModule(float_0)


# Generated at 2022-06-25 12:09:02.597870
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2196.0
    float_1 = -2196.0
    strategy_module_0 = StrategyModule(float_0)
    strategy_module_1 = StrategyModule(float_1)


# Generated at 2022-06-25 12:09:05.541639
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.display("Running test_StrategyModule ..")
    test_case_0()
    display.display("Done with test_StrategyModule")


# Generated at 2022-06-25 12:09:09.785631
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -1803.0
    strategy_module_0 = StrategyModule(float_0)

if __name__ == "__main__":
    for func in dir():
        if func.startswith("test_"):
            print("Executing " + func)
            globals()[func]()
    print("All tests exec'd.")

# Generated at 2022-06-25 12:09:11.004887
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    
# example of running the test
test_StrategyModule()

# Generated at 2022-06-25 12:09:14.032421
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2196.0
    strategy_module_0 = StrategyModule(float_0)

test_case_0()
test_StrategyModule()

# Generated at 2022-06-25 12:09:20.117587
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2196.0
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:09:21.731199
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 2309.0
    StrategyModule(float_0)


# Generated at 2022-06-25 12:09:26.464214
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2196.0
    strategy_module_0 = StrategyModule(float_0)

    assert(strategy_module_0._host_pinned == True)

if __name__ == "__main__":
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:09:27.352350
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:09:28.962400
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2196.0
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:09:33.673034
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm_0 = 0.0
    test_case_0(tqm_0)

PATH = 'ansible/plugins/strategy/host_pinned.py'
if __name__ == '__main__':
    import coverage
    coverage.process_startup()
    try:
        test_StrategyModule()
        print('succesful test')
    except AssertionError as e:
        print('failed test_StrategyModule: ', e)

# Generated at 2022-06-25 12:09:34.900650
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2196.0
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:09:36.315730
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 8.0
    strategy_module_0 = StrategyModule(float_0)
    return

# Generated at 2022-06-25 12:09:38.831681
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2196.0
    strategy_module_0 = StrategyModule(float_0)



# Generated at 2022-06-25 12:09:44.335513
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1077.0
    str_0 = 'jxov1'
    print(test_case_0())
    strategy_module_0 = StrategyModule(float_0)
    assert strategy_module_0._host_pinned == True

test_StrategyModule()

# Generated at 2022-06-25 12:09:49.912951
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Create an instance of the class strategy
    strategy_0 = StrategyModule('tqm')

    # Assert
    assert isinstance(strategy_0,StrategyModule) == True
    assert isinstance(strategy_0,object) == True




# Generated at 2022-06-25 12:09:52.149989
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert test_case_0() == 1

StrategyModule()

# Generated at 2022-06-25 12:09:53.386971
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(None)


# Generated at 2022-06-25 12:09:58.382180
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategymodule = StrategyModule(tqm)

    assert(strategymodule.__init__ == True)
    assert(strategymodule._tqm == True)
    assert(strategymodule._inventory == True)
    assert(strategymodule._loader == True)
    assert(strategymodule._variable_manager == True)
    assert(strategymodule._host_pinned == True)

# Generated at 2022-06-25 12:09:59.600627
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    strategy_module = StrategyModule(display)
    assert strategy_module

# Generated at 2022-06-25 12:10:00.447534
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

StrategyModule()

# Generated at 2022-06-25 12:10:02.432974
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = test_case_0()
    strategymodule = StrategyModule(tqm)


if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:10:05.949006
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # We don't need a real TaskQueueManager for unit tests
    test_tqm = None
    strategy_module = StrategyModule(test_tqm)
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:10:11.806825
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\n[INFO] Running case " + inspect.currentframe().f_code.co_name + "...")
    print("[INFO] Initializing tqm...")
    tqm = Tqm()
    sm = StrategyModule(tqm=tqm)
    assert sm and (type(sm).__name__ == "StrategyModule")
    print("[SUCCESS] StrategyModule initialized successfully.")


# Generated at 2022-06-25 12:10:15.400852
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.0
    float_1 = 1.0
    from ansible.plugins.strategy.free import FreeStrategyModule
    from ansible.utils.display import Display
    display = Display()




test_case_0()

# Generated at 2022-06-25 12:10:21.599501
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.0
    # Execution of '__init__' started
    # Execution of '__init__' ended



# Generated at 2022-06-25 12:10:22.424294
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TaskQueueManager()
    str_0 = StrategyModule(tqm)
    return str_0 != null


# Generated at 2022-06-25 12:10:25.562880
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 0
    test_case_0()
    # Create instance of class StrategyModule
    strategy_module = StrategyModule(tqm)
    # Check if isinstance of class StrategyModule
    assert isinstance(strategy_module, StrategyModule)


# Generated at 2022-06-25 12:10:28.594923
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test constructor with Argument tqm
    strategymodule = StrategyModule(test_case_0())
    if strategymodule._host_pinned != True:
        print("constructor StrategyModule with Argument tqm failed")

# Generated at 2022-06-25 12:10:32.633612
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    ansible = Ansible()
    playbook = Playbook()
    hosts = Hosts()
    strategy = StrategyModule()
    test_case_0()
    test_run_one_host()
    test_run_one_play()
    test_run_playbook()

# Generated at 2022-06-25 12:10:34.317352
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule(float_0)
    except NameError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 12:10:37.399265
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    play_context = None
    loader = None
    variable_manager = None
    strategy = StrategyModule(play_context, loader, variable_manager)
    assert strategy._name == 'pinned'.encode()


# Generated at 2022-06-25 12:10:39.061385
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    name_0 = 'pipeline'
    obj_0 = FreeStrategyModule(name_0)
    test_case_0()


# Generated at 2022-06-25 12:10:40.417407
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as e:
        print(e)

# Generated at 2022-06-25 12:10:43.013112
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(test_case_0())
    return None

test_StrategyModule()

# Generated at 2022-06-25 12:10:48.308078
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 0.0
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-25 12:10:51.752948
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ansible = Ansible()
    ansible.options = _Options()
    ansible.inventory = InventoryManager(Loader())
    tqm = None
    strategyModule = StrategyModule(tqm)
    assert strategyModule is not None


# Generated at 2022-06-25 12:10:54.693034
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.0
    int_0 = 0
    mock_tqm = MockTqm()
    strategy_module_0 = StrategyModule(mock_tqm)
    assert strategy_module_0._host_pinned == True
    del strategy_module_0


# Generated at 2022-06-25 12:10:56.344777
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.0
    tqm = AnsibleQueueManager()
    StrategyModule(tqm)


# Generated at 2022-06-25 12:10:57.595303
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as ex:
        assert(isinstance(ex, NotImplementedError))

# Generated at 2022-06-25 12:11:00.861474
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    Test = StrategyModule(None)
    Test.__init__(None)


# Generated at 2022-06-25 12:11:03.426007
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = test_case_0()
    global StrategyModule
    strategymodule = StrategyModule(tqm)


# Generated at 2022-06-25 12:11:06.229466
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = AnsibleQueueManager(None)
    test = StrategyModule(tqm)

# Unit tests for class StrategyModule: Method: get_host_list

# Generated at 2022-06-25 12:11:10.219691
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Input variabls
    tqm = None
    # Output variables
    stm = StrategyModule(tqm)
    # Check
    assert type(stm) == StrategyModule

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:11:13.492316
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    #tqm = TestQueueManager()

    #StrategyModule(tqm)

test_StrategyModule()

# Generated at 2022-06-25 12:11:19.330319
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #try:
    #    float_0 = 0.0
    #except:
    #    assert False
    pass


# Generated at 2022-06-25 12:11:21.436769
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm_0 = test_case_0()
    strategymodule_0 = StrategyModule(tqm_0)


# Generated at 2022-06-25 12:11:22.665192
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    StrategyModule(tqm)


# Generated at 2022-06-25 12:11:26.731778
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # For test case 0, check if StrategyModule.__init__() works successfully.
    # For test case 0, no arguments are passed to the constructor.
    tqm_0 = None
    StrategyModule_0 = StrategyModule(tqm_0)


# Generated at 2022-06-25 12:11:30.048905
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = None
  test = StrategyModule(tqm)
  assert not test._host_pinned
  #assert that host_pinned is equal to true
  assert test._host_pinned

# Generated at 2022-06-25 12:11:31.266116
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategymodule = StrategyModule(tqm=[])
    return strategymodule


# Generated at 2022-06-25 12:11:33.078778
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:11:38.069029
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Initialize testing flags to zero
    test_case_0()

    # Initialize display to Display()
    display = Display()

    # Define tqm to be a TaskQueueManager object.
    tqm = None

    # Instantiate StrategyModule with tqm
    strategy_module = StrategyModule(tqm)

    # Check that the strategy_module's self._host_pinned is True
    assert strategy_module._host_pinned is True

# Run unit tests for StrategyModule
test_StrategyModule()

# Generated at 2022-06-25 12:11:41.693667
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    f2 = FreeStrategyModule.get_strategy(0.0)
    assert f2 == StrategyModule
    assert f2._host_pinned == True
    #f2 = FreeStrategyModule.get_strategy(1.0)

# Generated at 2022-06-25 12:11:42.789529
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule('tqm')


# Generated at 2022-06-25 12:11:49.578524
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2196.0
    strategy_module_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:11:51.343082
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2196.0
    strategy_module_0 = StrategyModule(float_0)
    return strategy_module_0


# Generated at 2022-06-25 12:11:52.744576
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -4.10980
    strategy_module_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:11:54.305484
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:11:56.059484
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule(float_0)
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-25 12:11:57.389731
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.0
    strategy_module_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:11:58.129201
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(test_case_0())

# Generated at 2022-06-25 12:11:59.727480
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2196.0
    strategy_module_0 = StrategyModule(float_0)



# Generated at 2022-06-25 12:12:00.704071
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    

# Generated at 2022-06-25 12:12:02.632591
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2196.0
    strategy_module_0 = StrategyModule(float_0)
    assert isinstance(strategy_module_0, StrategyModule) == True



# Generated at 2022-06-25 12:12:13.367384
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:12:20.035006
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -1054.0

# Generated at 2022-06-25 12:12:21.265130
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# -- END OF FILE --

# Generated at 2022-06-25 12:12:22.816969
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(float(1))

# Generated at 2022-06-25 12:12:24.240008
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2196.0
    strategy_module_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:12:25.380654
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2026.0
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:12:26.508416
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2196.0
    strategy_module_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:12:27.577646
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -103.0
    strategy_module_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:12:28.603074
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.0
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:12:30.738378
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 2.652895
    StrategyModule_0 = StrategyModule(float_0)

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:12:51.985002
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:12:52.618066
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True




# Generated at 2022-06-25 12:12:53.956928
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:12:55.088322
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2196.0
    assert (isinstance(StrategyModule(float_0), StrategyModule))

# Generated at 2022-06-25 12:12:57.025293
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3655.0
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:12:58.945380
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2196
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:13:00.261655
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create instance for class StrategyModule
    strategy_module_0 = StrategyModule(float)



# Generated at 2022-06-25 12:13:02.325631
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -10.0
    strategy_module_0 = StrategyModule(float_0)
    assert isinstance(strategy_module_0, StrategyModule)
    assert strategy_module_0._tqm == float_0

# Generated at 2022-06-25 12:13:03.581260
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2196.0
    strategy_module_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:13:04.931491
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2193.0
    strategy_module_0 = StrategyModule(float_0)

test_case_0()

# Generated at 2022-06-25 12:13:48.031023
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:13:49.231459
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 148.0
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:13:51.137765
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -4309.0
    strategy_module_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:13:54.058069
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    strategy_module = StrategyModule(display)
    strategy_module.__init__(display)
    # given that we don't have a queue manager, we should not get errors
    assert (strategy_module)


# Generated at 2022-06-25 12:13:55.665191
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return_value_0 = test_case_0()
    assert return_value_0 == None, "Constructor of class StrategyModule return wrong value"

# Generated at 2022-06-25 12:13:59.775871
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Get the value of variable float_0
    float_0 = -2196.0
    # Assign a new value to variable float_0
    float_0 = -1597.0
    # Create an instance of class StrategyModule(float_0)
    strategy_module_0 = StrategyModule(float_0)
    # Assert if instance strategy_module_0 is of type StrategyModule
    assert (isinstance(strategy_module_0, StrategyModule))


# Generated at 2022-06-25 12:14:01.005308
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.display('Test for constructor of class StrategyModule')
    test_case_0()



# Generated at 2022-06-25 12:14:02.197707
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except NotImplementedError:
        print ("badly implemented test case")

# Generated at 2022-06-25 12:14:05.487397
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    f = StrategyModule()
    assert isinstance(f, StrategyModule)
    assert isinstance(f.task, None)
    assert isinstance(f.task_vars, None)
    assert isinstance(f.loader, None)
    assert isinstance(f.inventory, None)
    assert isinstance(f.variables, None)
    assert isinstance(f.display, Display)
    #assert isinstance(f.host_pinned, True)

# Generated at 2022-06-25 12:14:06.652374
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2196.0
    strategy_module_0 = StrategyModule(float_0)
    assert isinstance(strategy_module_0, StrategyModule)


# Generated at 2022-06-25 12:15:38.162968
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2196.0
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:15:40.274054
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    float_0 = -6449.0
    strategy_module_0 = StrategyModule(float_0)



# Generated at 2022-06-25 12:15:44.281418
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test 1 of 3
    float_0 = -2196.0
    strategy_module_0 = StrategyModule(float_0)

    # Test 2 of 3
    float_1 = 46.0
    strategy_module_1 = StrategyModule(float_1)

    # Test 3 of 3
    float_2 = -2.0
    strategy_module_2 = StrategyModule(float_2)


# Generated at 2022-06-25 12:15:45.276498
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2951.0
    strategy_module_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:15:45.890076
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:15:47.516038
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1.94516560863e-05
    strategy_module_0 = StrategyModule(float_0)
    for_loop(strategy_module_0)


# Generated at 2022-06-25 12:15:48.118093
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:15:49.728777
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -10406.65
    strategy_module_0 = StrategyModule(float_0)
    assert isinstance(strategy_module_0, StrategyModule) is True


# Generated at 2022-06-25 12:15:56.922062
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    dict_0 = dict()
    dict_0['a'] = 0.0
    dict_0['a'] = 0.0
    dict_0['a'] = 0.0
    dict_0['a'] = 0.0
    dict_0['a'] = 0.0
    dict_0['a'] = 0.0
    dict_0['a'] = 0.0
    dict_0['a'] = 0.0
    dict_0['a'] = 0.0
    dict_0['a'] = 0.0
    dict_0['a'] = 0.0
    dict_0['a'] = 0.0
    dict_0['a'] = 0.0
    dict_0['a'] = 0.0
    dict_0['a'] = 0.0
    dict_0['a'] = 0.0

# Generated at 2022-06-25 12:15:58.244232
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test case 0
    try:
        test_case_0()
    except:
        assert False
    else:
        assert True

test_StrategyModule()