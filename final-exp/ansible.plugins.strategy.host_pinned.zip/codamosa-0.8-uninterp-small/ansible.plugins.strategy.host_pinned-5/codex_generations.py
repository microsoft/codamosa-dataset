

# Generated at 2022-06-25 12:08:47.928556
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    dict_1 = {}
    strategy_module_1 = StrategyModule(dict_1)
    assert isinstance(strategy_module_1, StrategyModule), "Constructor of class StrategyModule failed"
    print("Test 1 passed")



# Generated at 2022-06-25 12:08:52.463974
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except NameError:
        display.warning('Failed to execute test_case_0()')
    else:
        display.info('Test case for class StrategyModule() constructor passed')

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:08:53.507991
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    dict_0 = {}
    strategy_module_0 = StrategyModule(dict_0)

# Generated at 2022-06-25 12:08:57.088910
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    dict_0 = {}
    strategy_module_0 = StrategyModule(dict_0)
    assert strategy_module_0._host_pinned == True
    assert strategy_module_0._active_hosts == []
    assert strategy_module_0._active_queue == []
    assert strategy_module_0._need_to_wait_for_index_queue == []


# Generated at 2022-06-25 12:08:57.819655
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(1)


# Generated at 2022-06-25 12:08:59.417836
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    dict_0 = {}
    strategy_module_0 = StrategyModule(dict_0)
    assert strategy_module_0._host_pinned == True


# Generated at 2022-06-25 12:09:00.464673
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    dict_0 = {}
    strategy_module_0 = StrategyModule(dict_0)


# Generated at 2022-06-25 12:09:03.409571
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    dict_0 = {}
    strategy_module_0 = StrategyModule(dict_0)
    assert strategy_module_0._host_pinned == True


# Generated at 2022-06-25 12:09:05.210235
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    dict_1 = {}
    strategy_module_1 = StrategyModule(dict_1)


# Generated at 2022-06-25 12:09:06.167484
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    dict_0 = {}
    strategy_module_0 = StrategyModule(dict_0)

# Generated at 2022-06-25 12:09:10.188971
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule()
        print(str_0)
    except Exception:
        print('Test case for class StrategyModule() constructor failed')       

# Test classes

# Generated at 2022-06-25 12:09:11.406578
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print('All test cases for class StrategyModule() constructor passed')


# Generated at 2022-06-25 12:09:14.590658
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print("\nAll unit tests for constructor of class StrategyModule passed")

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:09:16.336473
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print('Unit test passed')
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:09:20.734506
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print("Test for StrategyModule() constructor passed")
    print("===============================================================================================")

test_StrategyModule()

# Generated at 2022-06-25 12:09:22.833414
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case = StrategyModule
    test_case_0()
    print('>> Test for class StrategyModule() constructor passed')


# Generated at 2022-06-25 12:09:25.970545
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print('Unit test for StrategyModule() - Done')

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:09:27.226587
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print('Unit test for constructor of class StrategyModule() passed')

# Generated at 2022-06-25 12:09:28.759406
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:09:34.306532
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('\n\nSTART: Test for constructor of class StrategyModule')
    display = Display()
    display.verbosity = 4
    # Constructor StrategyModule should not raise exception
    try:
        StrategyModule(display)
    except Exception as e:
        str_0 = 'Test case for class StrategyModule() constructor failed. Exception raised: '
        print(str_0 + str(e))
    else:
        print('Test case for class StrategyModule() constructor passed')

# Execute test cases
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:09:36.848988
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print('All test cases for class StrategyModule() constructor passed')



# Generated at 2022-06-25 12:09:44.720810
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class temp():
        def __init__(self):
            self.display = True
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()


# Generated at 2022-06-25 12:09:49.822961
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	try:
		StrategyModule('asd')
	except Exception as e:
		if str(e) == "object of type '_Method' has no len()":
			return 1
		elif str(e) == 'tqm is not defined':
			return 0
		else:
			return 2
	return 3


# Generated at 2022-06-25 12:09:53.801386
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule(None)
    except Exception as e:
        print('Test case for class StrategyModule() constructor failed')
    else:
        print('Test case for class StrategyModule() constructor passed')

test_StrategyModule()

# Generated at 2022-06-25 12:09:55.700962
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print('All Test Cases for StrategyModule passed')

# test_StrategyModule()

# Generated at 2022-06-25 12:09:58.295445
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print("Unit test for class StrategyModule() constructor passed")

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:10:00.182168
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except:
        display.error("Test case for class StrategyModule() constructor failed")

# Generated at 2022-06-25 12:10:01.595674
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:10:03.370652
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    print("\n==> Testing constructor of class StrategyModule")
    test_StrategyModule()

# Generated at 2022-06-25 12:10:09.248428
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Constructing object for class StrategyModule
    tqm = None
    strm = StrategyModule(tqm)
    # Check if the created object is an instance of class StrategyModule
    if isinstance(strm, StrategyModule):
        print("test_case_1: Unit test for class StrategyModule() constructor passed")
    else:
        print("test_case_1: Unit test for class StrategyModule() constructor failed")

test_StrategyModule()

# Generated at 2022-06-25 12:10:13.630231
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print('\nUnit test for StrategyModule class constructor passed')

# Generated at 2022-06-25 12:10:15.026525
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print('StrategyModule unit tests passed')
    print('-'*50)

# Generated at 2022-06-25 12:10:16.976526
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print('All tests for StrategyModule passed')


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:10:18.288246
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    assert True


# Generated at 2022-06-25 12:10:19.040052
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:10:20.444856
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print('Tests for class StrategyModule are passed')


# Generated at 2022-06-25 12:10:21.735008
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Run test for constructor of class StrategyModule
test_StrategyModule()

# Generated at 2022-06-25 12:10:23.002279
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print('All test cases for class StrategyModule() passed')


# Generated at 2022-06-25 12:10:23.831889
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(str_0)


# Generated at 2022-06-25 12:10:28.370346
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy._host_pinned == True
    assert strategy.display == Display()
    assert strategy.get_name() == 'host_pinned'
    assert strategy._tqm == None
    test_case_0()



# Generated at 2022-06-25 12:10:35.141940
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    test_case_0()


# Generated at 2022-06-25 12:10:37.369493
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print("\nUnit test for class StrategyModule() constructor is passed")


# Generated at 2022-06-25 12:10:44.142970
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Initialize TaskQueueManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    # Create a dummy play
    play_source = dict(
        name="Ansible Play 0",
        hosts='localhost',
        gather_facts='no',
        tasks=[]
    )
    play0 = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    # Create the task queue manager and assign the play to

# Generated at 2022-06-25 12:10:45.170860
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print('Test for class StrategyModule passed')

# Generated at 2022-06-25 12:10:47.691802
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    results = dict()

    test_case_0()
    results['test_case_0'] = "PASSED"

    return results


# Generated at 2022-06-25 12:10:49.824012
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print('Test for class StrategyModule() constructor passed')

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:10:51.546343
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm_0 = object()
    test_case_0()


# Generated at 2022-06-25 12:10:53.938897
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule(tqm = None)
        test_case_0()
    except Exception:
        pass


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:10:57.018087
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('====Start test for class StrategyModule====')

    test_case_0()

    print('====End test for class StrategyModule====')

# Start the test
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:11:01.755020
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print("\nTest cases in StrategyModule.py passed")

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:11:06.946195
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print('All test cases for class StrategyModule() constructor passed')

# Generated at 2022-06-25 12:11:08.773544
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule()
    str = 'Tests for class StrategyModule passed'
    print(str)
    return str


# Generated at 2022-06-25 12:11:12.895495
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm_0 = None
        test_case_0()
        print('Unit test for StrategyModule() passed')
    except:
        print('Unit test for StrategyModule() failed')


# Generated at 2022-06-25 12:11:15.186038
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule()
    print('Test passed for test_StrategyModule()')


# Generated at 2022-06-25 12:11:21.902053
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # The constructor of class StrategyModule
    str_0 = """def __init__(self, tqm):
        super(StrategyModule, self).__init__(tqm)
        self._host_pinned = True"""
    return str_0

"""
__init__(self, tqm)
super(StrategyModule, self).__init__(tqm)
self._host_pinned = True
"""


# Generated at 2022-06-25 12:11:24.743738
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\nRunning test for constructor of class StrategyModule()")
    test_case_0()
    print("\nTest for class StrategyModule() constructor passed")

#test_StrategyModule()

# Generated at 2022-06-25 12:11:27.563376
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    return 0

# Unit test execution code
ret = test_StrategyModule()
sys.exit(ret)

# Generated at 2022-06-25 12:11:29.862538
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule("Test")
        test_case_0()
    except:
        print("Test case 0 failed")

# Generated at 2022-06-25 12:11:30.795306
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:11:32.611768
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test_case_0()
    print('Unit test for class StrategyModule() constructor passed')


# Generated at 2022-06-25 12:11:39.107524
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.verbosity = 3
    s = StrategyModule('')
    assert len(s._stats) == 12

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:11:40.705851
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print('Unit test for constructor of class StrategyModule passed')


# Generated at 2022-06-25 12:11:45.260502
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Test for constructor of class StrategyModule')
    try:
        print('Testing for constructor of class StrategyModule with inputs passed')
        StrategyModule(tqm = 1)
        test_case_0()
    except:
        print('Failed to test for constructor of class StrategyModule')
        return
    finally:
        print('Test for constructor of class StrategyModule is complete')
        print('\n')


# Generated at 2022-06-25 12:11:54.544536
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-25 12:11:55.330851
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:11:56.083440
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:11:57.626158
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Testing class StrategyModule() constructor')
    test_case_0()
    print('Test for class StrategyModule() constructor passed')


# Generated at 2022-06-25 12:12:00.021084
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Test case for constructor defined in StrategyModule
    tqm = 0
    strategy_mod = StrategyModule(tqm)
    test_case_0()
    display.display('test_case_0: '+str_0)

test_StrategyModule()

# Generated at 2022-06-25 12:12:02.769580
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule(tqm = None)
    except:
        str_0 = 'Test case for class StrategyModule() constructor failed'
    else:
        str_0 = 'Test case for class StrategyModule() constructor passed'
    return str_0


# Generated at 2022-06-25 12:12:04.026545
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print('Fuction test_StrategyModule() passed')


# Generated at 2022-06-25 12:12:15.825293
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:12:16.861980
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Unit test for constructor of class StrategyModule"""
    pass


# Generated at 2022-06-25 12:12:18.055983
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:12:23.355770
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_name = 'localhost'
    task1 = dict({'action': dict({'module': 'shell', 'args': 'uname -s'}), 'name': 'Test task 1'})
    play1 = dict({'hosts': host_name, 'tasks': [task1]})
    play_source = dict({'host_name': host_name, 'play': play1, 'name': 'Test play 1'})
    tqm = TaskQueueManagerMock(task_queues=[],
                               variable_manager=VariableManagerMock(),
                               loader=DataLoaderMock(),
                               options=OptionsMock(),
                               passwords=PasswordsMock(),
                               stdout_callback=CallbackModuleMock())
    StrategyModule(tqm)
    # test __init__ constructor
    test_case_0()

# Generated at 2022-06-25 12:12:24.421892
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Test class StrategyModule
test_StrategyModule()

# Generated at 2022-06-25 12:12:25.079617
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:12:26.220453
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Testcase for constructor of class StrategyModule
test_StrategyModule()

# Generated at 2022-06-25 12:12:27.722205
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Unit test for the constructor of class StrategyModule
    # Test case for __init__()
    # Result:
    #     Test case passed
    test_case_0()



# Generated at 2022-06-25 12:12:28.914945
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print('Test passed!')

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:12:31.560897
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert hasattr(strategy_module, '_host_pinned'), ('Instance of class StrategyModule() has no attribute '
                                                      '\'_host_pinned\'')
    assert strategy_module._host_pinned, ('Value of the attribute \'_host_pinned\' from instance of class '
                                          'StrategyModule() is not true')

# Generated at 2022-06-25 12:12:44.836779
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('\nTesting StrategyModule constructor')

    # test case for constructor
    test_case_0()
    print('\t',str_0)

    print('\nFinished Testing StrategyModule constructor')

test_StrategyModule()

# Generated at 2022-06-25 12:12:46.751174
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    

# Generated at 2022-06-25 12:12:52.246109
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        print(StrategyModule())
    except:
        str_1 = 'Test case for class StrategyModule() constructor failed'
    else:
        str_0 = 'Test case for class StrategyModule() constructor passed'

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:13:00.711793
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule('tqm')
        print(str_0)
    except AttributeError:
        print('Test case for class StrategyModule() constructor failed')

if __name__ == '__main__':
    test_StrategyModule()

# def __init__(self, tqm):
#     super(StrategyModule, self).__init__(tqm)
#     self._host_pinned = True
#
#
# if __name__ == '__main__':
#     print('Demo of StrategyModule class')
#
#     # Demonstration of the constructor
#     print('\nDemonstration of __init__()')
#     tqm = 'tqm'
#     o = StrategyModule(tqm)
#     print(type(o))

# Generated at 2022-06-25 12:13:01.632820
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    pass


# Generated at 2022-06-25 12:13:02.296543
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.display(str_0)


# Generated at 2022-06-25 12:13:03.085222
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:13:04.201127
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print('Strategy Module constructor test cases passed')


# Generated at 2022-06-25 12:13:05.148830
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test = StrategyModule()
    assert test.__class__ == StrategyModule


# Generated at 2022-06-25 12:13:05.832912
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:13:30.665889
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print('Unit test for class StrategyModule() passed')



# Generated at 2022-06-25 12:13:32.094667
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print("All test case passed for constructor")



# Generated at 2022-06-25 12:13:34.029187
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm != None, \
        'Test case for class StrategyModule() constructor passed'
    print (sm)

# Generated at 2022-06-25 12:13:35.827249
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.info('\nTest case for class StrategyModule() constructor\n')
    test_case_0()
    display.info('\nUnit test for class StrategyModule() constructor passed')

# Generated at 2022-06-25 12:13:36.965314
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:13:38.530338
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Test case for class StrategyModule() constructor passed'


# Generated at 2022-06-25 12:13:39.885586
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':

    test_StrategyModule()

# Generated at 2022-06-25 12:13:40.711930
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(test_case_0())

# Main function

# Generated at 2022-06-25 12:13:42.700654
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Unit test for constructor of class StrategyModule passed'

# Generated at 2022-06-25 12:13:44.525510
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('test_StrategyModule()')
    test_case_0()
    print('Test cases passed')

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:14:30.718011
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.display(str_0)
    test_case_0()

# run unit test
test_StrategyModule()

# Generated at 2022-06-25 12:14:31.663841
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print('Test for class StrategyModule() passed')

# Generated at 2022-06-25 12:14:33.694440
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    print(StrategyModule(tqm))


if __name__ == '__main__':
    print('Test cases:')
    print(test_case_0())

    test_StrategyModule()

# Generated at 2022-06-25 12:14:34.556142
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(StrategyModule)
    print(test_case_0())


# Generated at 2022-06-25 12:14:35.167875
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:14:39.251917
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)
    test_case_0()

# Load all tests in this file (if any)
from ansible.utils.display import Display
from ansible.utils.display import Display
from ansible.utils.display import Display
from ansible.utils.display import Display
from ansible.utils.display import Display
from ansible.utils.display import Display
from ansible.utils.display import Display
from ansible.utils.display import Display
from ansible.utils.display import Display

if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-25 12:14:41.891481
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_object = StrategyModule()
    str_1 = 'Test case for class StrategyModule() constructor passed'
    print(str_1)


# Generated at 2022-06-25 12:14:44.148264
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    print('Test for class StrategyModule() constructor passed')

#test_StrategyModule()

# Generated at 2022-06-25 12:14:44.608093
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:14:45.641986
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module._host_pinned == True
    print('Test case for class StrategyModule() constructor passed')


# Generated at 2022-06-25 12:16:30.100204
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy._host_pinned == True

# Generated at 2022-06-25 12:16:31.495975
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:16:32.243903
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:16:33.701228
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_StrategyModule_tqm = None
    test_case_0()
    return

test_StrategyModule()

# Generated at 2022-06-25 12:16:36.312095
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    # Create instance of class StrategyModule
    obj_StrategyModule = StrategyModule(tqm)
    assert obj_StrategyModule != None
    test_case_0()
    print("Successfully executed class StrategyModule() function tests")

# Unit test of function test_case_0()

# Generated at 2022-06-25 12:16:36.980694
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:16:37.645234
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:16:40.942119
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.display('Test case for class StrategyModule() constructor', color='blue')
    tqm = None
    sm = StrategyModule(tqm)
    try:
        assert(sm)
        test_case_0()
    except AssertionError:
        assert(sm)
    else:
        display.display('Test case for class StrategyModule() constructor failed', color='red')


# Generated at 2022-06-25 12:16:42.546209
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    # print("Unit test for constructor of class StrategyModule passed")

# if __name__ == '__main__':
#     test_StrategyModule()

# Generated at 2022-06-25 12:16:43.512611
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    test_case_0()
    print('Unit test for class StrategyModule() passed')
