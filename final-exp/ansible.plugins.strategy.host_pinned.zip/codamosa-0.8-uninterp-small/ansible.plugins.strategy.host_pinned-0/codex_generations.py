

# Generated at 2022-06-25 12:08:51.794984
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 172.303
    strategy_module_0 = StrategyModule(float_0)

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:08:55.056886
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 352.3837
    strategy_module_0 = StrategyModule(float_0)
    assert isinstance(strategy_module_0, StrategyModule)
    assert isinstance(strategy_module_0, FreeStrategyModule)
    assert isinstance(strategy_module_0, object)



# Generated at 2022-06-25 12:09:01.281557
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 172.303
    ansible_show_custom_stats = False
    use_static_priorities = False
    display.verbosity = 4
    float_0 = 172.303
    ansible_ssh_user = 'ansible'
    ansible_verbosity = 6
    ansible_ask_pass = True
    ansible_become_user = 'ansible'
    ansible_become_method = 'ansible'
    ansible_become_pass = True
    ansible_become = True
    ansible_become_exe = 'ansible'
    ansible_become_flags = 'ansible'
    ansible_playbook_python = 'ansible'
    ansible_shell_type = 'ansible'
    ansible_shell_executable = 'ansible'
   

# Generated at 2022-06-25 12:09:04.349925
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sub_class_variable_0 = False
    try:
        test_case_0()
    except Exception as Exception_0:
        sub_class_variable_0 = True
    assert sub_class_variable_0

# Generated at 2022-06-25 12:09:05.771168
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:09:06.907701
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 172.303
    strategy_module_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:09:09.357218
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Call function test_StrategyModule()
test_StrategyModule()

# Generated at 2022-06-25 12:09:10.091391
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:09:11.579396
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    pass


if __name__ == '__main__':
    # Unit test
    test_StrategyModule()

# Generated at 2022-06-25 12:09:14.032601
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:09:20.158015
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:09:21.392327
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    def test_pass():
        assert True


# Generated at 2022-06-25 12:09:22.400609
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:09:24.917345
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 172.303
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:09:26.735957
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 172.303
    strategy_module_0 = StrategyModule(float_0)
    assert(strategy_module_0._host_pinned == True)

# Generated at 2022-06-25 12:09:31.288352
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create an instance of class StrategyModule
    strategy_module_0 = StrategyModule('float_0')
    # Assert that the __init__() method of class StrategyModule created the instance correctly
    assert(strategy_module_0 != None)
    assert(strategy_module_0._host_pinned == True)


# Generated at 2022-06-25 12:09:32.057243
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:09:34.290283
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 172.303
    strategy_module_0 = StrategyModule(float_0)
    assert strategy_module_0 is not None
    assert strategy_module_0._host_pinned == True


# Generated at 2022-06-25 12:09:35.562084
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 676.39
    strategy_module_1 = StrategyModule(float_0)
    pass

# Generated at 2022-06-25 12:09:37.244402
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 172.303
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:09:41.863432
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 172.303
    strategy_module_0 = StrategyModule(float_0)
    assert hasattr(strategy_module_0, '_strategy_queue') == True
    assert hasattr(strategy_module_0, '_tqm') == True
    assert hasattr(strategy_module_0, '_host_pinned') == True

# Generated at 2022-06-25 12:09:44.856418
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test constructor of class StrategyModule")
    float_0 = 172.303
    strategy_module_0 = StrategyModule(float_0)
    assert True


# Generated at 2022-06-25 12:09:47.692729
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Arrange
    float_0 = 172.303
    # Action
    strategy_module_0 = StrategyModule(float_0)
    # Assert
    pass

# Generated at 2022-06-25 12:09:52.194230
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 172.303
    strategy_module_0 = StrategyModule(float_0)
    # If the content of the return is not None, then it will be executed
    if (StrategyModule):
        assert strategy_module_0.__init__() == None


# Generated at 2022-06-25 12:09:53.428748
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:09:55.250962
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    float_1 = 135.54
    strategy_module_1 = StrategyModule(float_1)

    test_case_0()

# Generated at 2022-06-25 12:10:00.008518
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test without arguments
    try:
        StrategyModule()
    except TypeError:
        assert True
    else:
        assert False
    # Test with valid arguments
    float_1 = float(1.0)
    try:
        StrategyModule(float_1)
    except TypeError:
        assert False
    else:
        assert True

test_StrategyModule()

# Generated at 2022-06-25 12:10:01.271038
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result = StrategyModule(float_0)
    assert result
    assert result._host_pinned
    assert result.tqm == float_0


# Generated at 2022-06-25 12:10:03.371889
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 172.303
    strategy_module_0 = StrategyModule(float_0)
    assert not hasattr(strategy_module_0, '_host_pinned')


# Generated at 2022-06-25 12:10:04.463771
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:10:18.595684
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ansible_playbook_0 = 'filename'
    dict_0 = dict()
    dict_0['ssh_args'] = '-o ControlMaster=auto -o ControlPersist=60s'
    dict_0['become_method'] = 'sudo'
    dict_0['module_name'] = 'setup'
    dict_0['remote_user'] = 'root'
    dict_0['module_args'] = 'filter=ansible_hostname'
    dict_0['inventory'] = dict()
    dict_0['inventory']['hosts'] = 'all'
    dict_0['host_key_checking'] = False
    dict_0['private_key_file'] = '/root/.ssh/id_rsa'
    dict_0['become'] = True
    dict_1 = dict()
    dict_1

# Generated at 2022-06-25 12:10:23.691895
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 172.303
    strategy_module_0 = StrategyModule(float_0)
    assert(strategy_module_0._host_pinned == True)
    assert(strategy_module_0._patched_wrap_async == None)
    assert(strategy_module_0.name == 'host_pinned')
    assert(strategy_module_0.get_host_list == None)
    assert(strategy_module_0.get_failed_hosts == None)
    assert(strategy_module_0._tqm == float_0)

# Generated at 2022-06-25 12:10:25.717883
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule('strict')


# Generated at 2022-06-25 12:10:27.431982
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:10:29.363768
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as exception_0:
        display.display('Exception: ' + str(exception_0))
        assert False


# Generated at 2022-06-25 12:10:30.300624
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:10:32.034315
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:10:33.401716
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    with pytest.raises(TypeError):
        StrategyModule(strategy_module_0)

# Generated at 2022-06-25 12:10:34.174550
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:10:37.552316
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 172.303
    strategy_module_0 = StrategyModule(float_0)
    assert strategy_module_0._host_pinned == True
    assert strategy_module_0._tqm == float_0


# Generated at 2022-06-25 12:10:48.277514
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import test_case_0
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:10:50.134395
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    z = StrategyModule(1.1)
    assert z._host_pinned == True , "The attribute _host_pinned should be True but it is False"

# Generated at 2022-06-25 12:10:52.614271
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 172.303
    strategy_module_0 = StrategyModule(float_0)
    assert(0)


# Generated at 2022-06-25 12:10:53.691521
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:10:59.588481
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # test case 1
    float_0 = 0.9647482723238374
    strategy_module_0 = StrategyModule(float_0)

    # test case 2
    float_0 = 0.973746455272815
    strategy_module_0 = StrategyModule(float_0)

    # test case 3
    float_0 = 0.8032945463382144
    strategy_module_0 = StrategyModule(float_0)

    # test case 4
    float_0 = 0.8674739156122225
    strategy_module_0 = StrategyModule(float_0)

    # test case 5
    float_0 = 0.2584183966172299
    strategy_module_0 = StrategyModule(float_0)

    # test case 6
    float_0 = 0.056534267

# Generated at 2022-06-25 12:11:03.797373
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 192.62
    strategy_module_0 = StrategyModule(float_0)


if __name__ == "__main__":
    # Unit test for constructor of class StrategyModule
    test_StrategyModule()

# Generated at 2022-06-25 12:11:05.357185
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # without: args
    # without: kwargs
    test_case_0()

# Generated at 2022-06-25 12:11:09.525021
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 172.303
    strategy_module_0 = StrategyModule(float_0)
    assert(not hasattr(strategy_module_0, "_host_pinned"))

# Unit tests for pick_host_batch_for_task
# Test case: Test case to check if pick_host_batch_for_task returns a batch size less than the given serial

# Generated at 2022-06-25 12:11:11.707031
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Unit test driver

# Generated at 2022-06-25 12:11:13.806773
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 172.303
    strategy_module_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:11:32.224602
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 172.303
    strategy_module_0 = StrategyModule(float_0)
    assert strategy_module_0._host_pinned == True


# Generated at 2022-06-25 12:11:33.793947
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 172.303
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:11:35.735610
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 172.303
    strategy_module_0 = StrategyModule(float_0)
    assert_true(strategy_module_0._host_pinned)


# Generated at 2022-06-25 12:11:36.680867
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Unit test stubs

# Generated at 2022-06-25 12:11:37.920460
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(float_0)
    assert strategy_module_0._host_pinned == True

# Generated at 2022-06-25 12:11:39.383684
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:11:41.731060
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:11:42.826444
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    tqm = None
    assert Intelligence(tqm)


# Generated at 2022-06-25 12:11:45.527738
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 172.303
    strategy_module_0 = StrategyModule(float_0)
    # AssertionError: Expected False, but got True
    assert False

# Test case
if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:11:51.011063
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create instance of class StrategyModule with argument float_0
    strategy_module_0 = StrategyModule(float_0)



# Run unit tests
if __name__ == '__main__':
    import sys
    import unittest
    suite = unittest.TestLoader().loadTestsFromTestCase(test_case_0)
    unittest.TextTestRunner(verbosity=2).run(suite)
    print("test suite: " + str(suite))

# Generated at 2022-06-25 12:12:34.929717
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(float(1))

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:12:35.959246
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 172.303
    strategy_module_0 = StrategyModule(float_0)
    assert isinstance(strategy_module_0, StrategyModule)


# Generated at 2022-06-25 12:12:37.893768
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:12:42.550311
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.debug('Test test_StrategyModule')
    test_case_0()

# Generated at 2022-06-25 12:12:46.113355
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except:
        print("Exception in user code:")
        print('-' * 60)
        traceback.print_exc(file=sys.stdout)
        print('-' * 60)

# Generated at 2022-06-25 12:12:50.546096
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:12:51.784212
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_1 = 1.94e+2
    strategy_module_1 = StrategyModule(float_1)

# Generated at 2022-06-25 12:12:52.347856
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:12:54.107690
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:12:55.602364
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 148.34
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:14:26.591533
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 1940.836
    assert_equals(StrategyModule(float_0)._host_pinned, True)

if __name__ == "__main__":
    import nose
    nose.runmodule()

# Generated at 2022-06-25 12:14:28.115902
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Case 0:
    ansible_0 = Ansible()
    ansible_0.test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:14:30.877129
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
        assert True
    except AssertionError:
        assert False

    print('Test completed successfully')

# Generated at 2022-06-25 12:14:31.577795
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:14:32.218579
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:14:34.685984
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 150.57
    strategy_module_0 = StrategyModule(float_0)
    float_1 = 160.64
    # self.assertNotEqual(strategy_module_0, float_1, "Returned unexpected value from StrategyModule.test_StrategyModule")


# Generated at 2022-06-25 12:14:36.144408
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 172.303
    strategy_module_0 = StrategyModule(float_0)
    assert_true(strategy_module_0._host_pinned)

# Generated at 2022-06-25 12:14:40.979544
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import copy
    import uuid
    # defined_args = {
    #     "pattern": "test_case_0",
    #     "inventory": uuid.uuid4(),
    #     "subset": {
    #         "test_case_0": uuid.uuid4()
    #     },
    #     "verbosity": 3,
    #     "background": 7,
    #     "host_pattern": "test_case_0",
    #     "only_tags": "test_case_0",
    #     "skip_tags": "test_case_0",
    #     "one_line": True,
    #     "tree": uuid.uuid4(),
    #     "ask_vault_pass": False,
    #     "ask_sudo_pass": False,
    #    

# Generated at 2022-06-25 12:14:42.593216
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("in test_StrategyModule")
    test_case_0()


test_StrategyModule()

# Generated at 2022-06-25 12:14:44.713562
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  float_0 = 172.303
  strategy_module_0 = StrategyModule(float_0)
#test_case_0()
test_StrategyModule()

# Generated at 2022-06-25 12:18:14.812094
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #test_case_0()
    exit(0)

# Generated at 2022-06-25 12:18:15.526399
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_3 = StrategyModule()


# Generated at 2022-06-25 12:18:16.012085
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert False


# Generated at 2022-06-25 12:18:17.394067
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_arg1 = 172.303
    strategy_module_arg1 = StrategyModule(float_arg1)


# Generated at 2022-06-25 12:18:17.982172
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:18:19.369318
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    class TestConstructor(unittest.TestCase):
        def test_0(self):
            test_case_0()
    unittest.main()

# Generated at 2022-06-25 12:18:22.742721
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 172.303
    float_1 = 6.2
    float_2 = 9.7
    float_3 = 0.26
    float_4 = 2.98
    float_5 = 0.5
    float_6 = 0.18
    float_7 = 0.72
    float_8 = 8.9
    float_9 = 1.4
    float_10 = 0.4

    strategy_module_0 = StrategyModule(float_0)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:18:23.626023
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 172.303
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:18:26.336607
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()

test_case_0()
test_StrategyModule()

# Generated at 2022-06-25 12:18:27.535256
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as e:
        display.error(e)