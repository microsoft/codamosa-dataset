

# Generated at 2022-06-25 12:08:54.093298
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Test with nosetests: nosetests --with-doctest -v --doctest-tests -s tests_strategy_host_pinned.py
# Test with py.tests: py.tests -x --doctest-modules --doctest-tests tests_strategy_host_pinned.py

# Generated at 2022-06-25 12:08:58.162079
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    bool_1 = True
    strategy_module_0 = StrategyModule(bool_1)
    # Assert that the constructor of class StrategyModule called the constructor of class FreeStrategyModule
    assert_is_instance(strategy_module_0, FreeStrategyModule)
    assert_is_instance(strategy_module_0, StrategyModule)
    # Call constructor of class StrategyModule with argument bool_0
    test_case_0()

# Generated at 2022-06-25 12:08:58.816248
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  test_case_0()

# Generated at 2022-06-25 12:09:00.369163
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:09:00.989574
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:09:01.586952
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:09:02.624382
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:09:04.574551
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)

# Generated at 2022-06-25 12:09:06.229228
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test with arg, arg type is bool
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)

# Generated at 2022-06-25 12:09:08.935392
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = False
    strategy_module_0 = StrategyModule(bool_0)
    assert strategy_module_0 != None



# Generated at 2022-06-25 12:09:15.374592
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Setup
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)

    #Assertion
    assert(strategy_module_0._host_pinned == True)


# Generated at 2022-06-25 12:09:17.489452
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as err:
        print('test_constructor Exception: ', err)
        assert False

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:09:19.866467
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)

# Generated at 2022-06-25 12:09:21.804235
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)
    assert strategy_module_0._host_pinned


# Generated at 2022-06-25 12:09:22.879066
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:09:23.707240
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    assert True

# Generated at 2022-06-25 12:09:25.432370
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_1 = True
    strategy_module_1 = StrategyModule(bool_1)


# Generated at 2022-06-25 12:09:27.051129
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    value_0 = StrategyModule(bool_0)
    assert value_0 is not None

# Generated at 2022-06-25 12:09:31.882108
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # check that the class under test is StrategyModule
    assert(str(type(StrategyModule))=="<type 'type'>")

    # check that the object inherits from object
    assert(issubclass(StrategyModule, object))

    # check that the object inherits from FreeStrategyModule
    assert(issubclass(StrategyModule, FreeStrategyModule))

    # check init call
    test_case_0()

# Generated at 2022-06-25 12:09:33.252252
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)

# Generated at 2022-06-25 12:09:38.517071
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:09:41.426194
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)


# Generated at 2022-06-25 12:09:43.169475
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)

# Generated at 2022-06-25 12:09:54.011097
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)
    bool_0 = False
    strategy_module_0 = StrategyModule(bool_0)
    strategy_module_0.start_pending_tasks(None)
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)
    strategy_module_0.self_host_list = []
    bool_0 = False
    strategy_module_0 = StrategyModule(bool_0)
    strategy_module_0.self_host_list = []
    bool_0 = False
    strategy_module_0 = StrategyModule(bool_0)
    strategy_module_0.self_host_list = []
    bool_0 = False
    strategy_module_0 = StrategyModule(bool_0)
    strategy_module_0.self_host_list = []
    bool_0

# Generated at 2022-06-25 12:09:55.494860
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:09:57.274110
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_1 = True
    strategy_module_1 = StrategyModule(bool_1)


# Generated at 2022-06-25 12:10:01.327068
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)

    # Assert on the values returned by instance attributes
    assert isinstance(strategy_module_0._host_pinned, bool)
    assert strategy_module_0._host_pinned == True
    assert isinstance(strategy_module_0._play, Play)

# Generated at 2022-06-25 12:10:02.996353
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except Exception as error:
        print(error)
        assert False

# Generated at 2022-06-25 12:10:05.560156
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    test_case_0()
    test_case_1()
    strategy_module_0 = StrategyModule(bool_0)


# Generated at 2022-06-25 12:10:06.375342
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:10:17.598930
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)



# Generated at 2022-06-25 12:10:19.109413
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:10:20.792853
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = bool
    strategy_module_0 = StrategyModule(bool_0)

# Unit test of method strategy of class StrategyModule

# Generated at 2022-06-25 12:10:26.290171
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = 1.268957020805912e-06
    bool_1 = 0.5870390965126677
    bool_2 = 0.8817204436051044
    bool_3 = 0.0
    bool_4 = 0.0
    bool_5 = 0.0
    bool_6 = 0.0
    bool_7 = 0.0
    bool_8 = 0.0
    bool_9 = 0.0
    bool_10 = 0.0
    bool_11 = 0.0
    bool_12 = 0.0
    bool_13 = 0.0
    bool_14 = 0.0
    bool_15 = 0.0
    bool_16 = 0.0
    bool_17 = 0.0
    bool_18 = 0.0
    bool_19 = 0

# Generated at 2022-06-25 12:10:34.931153
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Testing Strategy
# Now we want to test several cases of the strategy.
# For each case, we take a playbook and a hostlist,
# then we check if the hostlist included in the strategy is
# coherent with what we expect for a given strategy.

# case 1
# Playbook :
# - hosts: all
#   tasks:
#     - debug: msg="ok"
#     - pause:
#         seconds: 30
# Hostlist :
# 127.0.0.1 connected
# 127.0.0.2 connected
# 127.0.0.3 connected
#
# Verification :
# Hosts are processed one by one, so the strategy should
# process the hosts in the following order :
# 127.0.0.1 then 127.0.0.2 then 127.0.0.

# Generated at 2022-06-25 12:10:37.738785
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display_0 = Display()
    strategy_module_0 = StrategyModule(display_0)
    assert isinstance(strategy_module_0._host_pinned, bool)

# Generated at 2022-06-25 12:10:38.808202
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)

# Generated at 2022-06-25 12:10:39.948435
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)
    test_case_0()

# Generated at 2022-06-25 12:10:41.945211
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)

# Generated at 2022-06-25 12:10:46.177608
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case = [0]
    for i in test_case:
        print('Running test case: %d' % i)
        globals()['test_case_%d' % i]()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:11:07.600358
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.utils.display
    ansible.utils.display.Display = Display
    import ansible.plugins.strategy.free
    ansible.plugins.strategy.free.FreeStrategyModule = FreeStrategyModule
    import ansible.plugins.strategy.host_pinned
    strategy_module_0 = ansible.plugins.strategy.host_pinned.StrategyModule(False)
    assert strategy_module_0._host_pinned == True

# Generated at 2022-06-25 12:11:09.162388
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)


# Generated at 2022-06-25 12:11:13.856862
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        assert type(strategy_module_0.get_host_list()) is list
        assert strategy_module_0._host_pinned == True
    except NameError:
        print("Name Error")


# Generated at 2022-06-25 12:11:25.058566
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test purpose of this function
    def test_method_0():
        # Test purpose of this function
        def test_method_0_1():
            # Test purpose of this function
            strategy_module_1 = StrategyModule()
            # Test purpose of this function
            def test_method_0_2():
                # Test purpose of this function
                strategy_module_2 = StrategyModule()

    strategy_module_0 = StrategyModule()
    # Test purpose of this function
    def test_method_1():
        # Test purpose of this function
        strategy_module_1 = StrategyModule()
        # Test purpose of this function
        def test_method_2():
            # Test purpose of this function
            strategy_module_2 = StrategyModule()

    # Test purpose of this function

# Generated at 2022-06-25 12:11:26.846334
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Run test cases
test_StrategyModule()

# Generated at 2022-06-25 12:11:27.536393
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Test with default values for arguments
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:11:32.180002
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_1 = True
    setattr(test_case_0, '_tqm', bool_1)
    try:
        StrategyModule()
    except TypeError:
        pass
    except Exception:
        raise


if __name__ == '__main__':
    import pytest
    pytest.main(['-q', __file__])

# Generated at 2022-06-25 12:11:33.751422
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Todo: Implement test
    strategy_module_0 = StrategyModule()


# Generated at 2022-06-25 12:11:35.627668
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)
    assert isinstance(strategy_module_0._host_pinned,bool)



# Generated at 2022-06-25 12:11:36.839941
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:12:01.254464
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Unit test for constructor when 'min' and 'serial' have default values.
    strategy_module_1 = StrategyModule()

    assert strategy_module_1._tqm == None
    assert strategy_module_1._inventory == None
    assert strategy_module_1._variable_manager == None
    assert strategy_module_1._loader == None
    assert strategy_module_1._options == None
    assert strategy_module_1._display == None
    assert strategy_module_1._stdout_callback == None
    assert strategy_module_1._task_queue_manager == None
    assert strategy_module_1._stats == None
    assert strategy_module_1._failed_hosts == None
    assert strategy_module_1._unreachable_hosts == None
    assert strategy_module_1._success_hosts == None
    assert strategy

# Generated at 2022-06-25 12:12:02.273893
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(tqm={})

# Generated at 2022-06-25 12:12:03.446810
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule()
    assert isinstance(strategy_module_1, StrategyModule)

# Generated at 2022-06-25 12:12:04.138837
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule()
    assert True

# Generated at 2022-06-25 12:12:05.045051
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()


# Generated at 2022-06-25 12:12:09.463955
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule()
    assert isinstance(strategy_module_1, StrategyModule)
    assert strategy_module_1.__class__.__name__ == 'StrategyModule'
    assert  isinstance(strategy_module_1._host_pinned, bool)

# Generated at 2022-06-25 12:12:16.552999
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Testing when block based strategy
    strategy_module_1 = StrategyModule()
    assert strategy_module_1._blocked_hosts == dict(), "_blocked_hosts should be a dict"
    assert strategy_module_1._blocker_map == dict(), "_blocker_map should be a dict"
    assert strategy_module_1._host_pinned == True, "_host_pinned should be true when block based strategy"
    # Testing when free based strategy
    strategy_module_2 = StrategyModule()
    assert strategy_module_2._blocked_hosts == dict(), "_blocked_hosts should be a dict"
    assert strategy_module_2._blocker_map == dict(), "_blocker_map should be a dict"

# Generated at 2022-06-25 12:12:17.773289
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule()
    assert strategy_module_1._host_pinned == True

# Generated at 2022-06-25 12:12:18.646749
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()

    assert strategy_module is not None

# Generated at 2022-06-25 12:12:19.849091
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module == strategy_module


# Generated at 2022-06-25 12:13:04.325212
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module.get_host_list() == list()
    assert strategy_module.get_next_task_for_host() == None
    assert strategy_module.get_failed_hosts() == list()
    assert strategy_module.get_unreachable_hosts() == list()
    assert strategy_module.add_tasks() == None
    assert strategy_module.get_alive_workers() == set()
    assert strategy_module.get_worker_pids() == set()
    assert strategy_module.wipe_workers() == None

# Generated at 2022-06-25 12:13:08.097568
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule()
    assert None == strategy_module_1._play_context
    assert None == strategy_module_1._iterator
    assert None == strategy_module_1._inventory
    assert None == strategy_module_1._variable_manager
    assert None == strategy_module_1._all_vars
    assert None == strategy_module_1._templar
    assert None == strategy_module_1._hostvars
    assert None == strategy_module_1._host_pinned

# Generated at 2022-06-25 12:13:09.818420
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    args_0 = {}
    strategy_module_0 = StrategyModule(args_0)

# Generated at 2022-06-25 12:13:11.363968
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    assert strategy_module_0._host_pinned == True

# Generated at 2022-06-25 12:13:12.772716
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        # test_case_0
        test_case_0()
    except Exception as e:
        print('FAIL: test_case_0: ', e)
    else:
        print('PASS: test_case_0')

# Generated at 2022-06-25 12:13:15.886705
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    value = "this is a test"
    assert strategy_module is not None
    assert strategy_module._host_pinned is True
    assert strategy_module._display is not None

# Generated at 2022-06-25 12:13:17.755358
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule()
    assert isinstance(strategy_module_1, StrategyModule)
    strategy_module_1 = StrategyModule("test")
    assert isinstance(strategy_module_1, StrategyModule)

# Generated at 2022-06-25 12:13:18.976936
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule()
    assert strategy_module_1 is not None


# Generated at 2022-06-25 12:13:20.676576
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=1)
    assert True == getattr(strategy_module, '_host_pinned')

# Generated at 2022-06-25 12:13:21.858881
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    assert strategy_module_0._host_pinned == True

# Generated at 2022-06-25 12:14:55.059428
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-25 12:14:56.478607
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Negative test case
    with pytest.raises(Exception):
        strategy_module_1 = StrategyModule()


# Generated at 2022-06-25 12:14:58.865795
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_1 = StrategyModule()
    print ("Test for constructor of class StrategyModule passed")


# Generated at 2022-06-25 12:14:59.859981
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-25 12:15:01.945930
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()
    assert(strategy_module_0.__class__)


# Generated at 2022-06-25 12:15:04.346093
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test function constructor
    try:
        StrategyModule()
        assert True
    except NotImplementedError:
        assert False
    except:
        assert False

# Generated at 2022-06-25 12:15:05.811230
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()
    assert isinstance(s, StrategyModule)

    assert isinstance(s.tqm, FreeStrategyModule)


# Generated at 2022-06-25 12:15:06.425535
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:15:07.233602
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None

# Generated at 2022-06-25 12:15:09.995179
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    inputs = [
        0,
        1,
        2,
        3
    ]
    for input in inputs:
        strategy_module_0 = StrategyModule(input)

# Generated at 2022-06-25 12:16:46.684264
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)


# Generated at 2022-06-25 12:16:48.713273
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # check the functionality of constructor
    test_case_0()

# Run unit test
test_StrategyModule()

# Generated at 2022-06-25 12:16:50.138997
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated by PyAnnotations on 2018-05-29 20:32:05+0100

# Generated at 2022-06-25 12:16:52.408197
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)
    assert isinstance(strategy_module_0, StrategyModule)
    assert not isinstance(strategy_module_0, FreeStrategyModule)


# Generated at 2022-06-25 12:16:53.129911
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    test_case_0()

# Generated at 2022-06-25 12:16:53.801174
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ret_val = None



# Generated at 2022-06-25 12:16:55.678075
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)
    assert isinstance(strategy_module_0, StrategyModule), "Constructor call failed"


# Generated at 2022-06-25 12:16:56.359941
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:16:57.530456
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = True
    strategy_module_0 = StrategyModule(bool_0)
    assert True


# Generated at 2022-06-25 12:16:59.538371
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test_constructor_StrategyModule")
    if (test_case_0()):
        print("Constructor test passed")
    else:
        print("Constructor test failed")

test_StrategyModule()