

# Generated at 2022-06-25 12:08:51.518136
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:08:53.001263
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3879.482
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:08:54.710216
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3879.482
    strategy_module_0 = StrategyModule(float_0)

# vim: set filetype=python

# Generated at 2022-06-25 12:08:55.739769
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Code to call unit tests

# Generated at 2022-06-25 12:08:56.735106
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    # testing
    test_StrategyModule()

# Generated at 2022-06-25 12:08:57.981858
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3879.482
    strategy_module_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:09:01.140332
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Set up test objects
    float_0 = -8909.492
    # Create test class object
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:09:02.085043
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:09:04.607517
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_1 = -5936.95654
    strategy_module_1 = StrategyModule(float_1)


# Generated at 2022-06-25 12:09:05.771192
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Test for constructor of class StrategyModule."""

    test_case_0()


# Generated at 2022-06-25 12:09:09.785607
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test_StrategyModule: " + test_case_0.__doc__)
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:09:10.496387
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:09:13.611471
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test for constructor of class StrategyModule
    test_case_0()

# Colllect all test cases in this file
test_cases = [
                test_case_0,
            ]


# Generated at 2022-06-25 12:09:15.404985
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:09:17.714860
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned as host_pinned
    strategyModule = host_pinned.StrategyModule('tqm')
    print("ok")

if __name__ == "__main__":
    test_StrategyModule()
    pass

# Generated at 2022-06-25 12:09:19.639476
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:09:21.198207
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    test_case_0()

# Verify if the class could be instantiated

# Generated at 2022-06-25 12:09:22.535876
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Test if the implementation of the method is finished

# Generated at 2022-06-25 12:09:25.051965
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    u = StrategyModule()
    # Test for constructor of class StrategyModule.
    test_case_0()


# Generated at 2022-06-25 12:09:26.681705
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:09:30.630109
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
        print('Test for constructor of class StrategyModule successed!')
    except Exception as e:
        print('Test for constructor of class StrategyModule failed!')

# Generated at 2022-06-25 12:09:31.760228
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test_case_0()
    pass


# Generated at 2022-06-25 12:09:34.536591
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
        print("Test of constructor of class StrategyModule done.")
    except:
        print("Test of constructor of class StrategyModule failed.")
    finally:
        print("Testing of constructor of class StrategyModule is ended.")

test_StrategyModule()

# Generated at 2022-06-25 12:09:36.191202
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()
    test_case_0()
    print('\nAll tests are done.\n')

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:09:41.238857
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Remove the exception if the unit test passes
    try:
        test_case_0()
        print("Test case for constructor of class StrategyModule is passed.")
    except:
        print("Test case for constructor of class StrategyModule is failed.")



# Generated at 2022-06-25 12:09:45.951926
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
        display.display("StrategyModule: Constructor works!\n\n", color='green')
    except Exception:
        display.display("StrategyModule: Constructor is broken!\n\n", color='red')

test_StrategyModule()

# Generated at 2022-06-25 12:09:50.905559
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
        display.display("0. constructor of class StrategyModule......................OK")
    except:
        display.display("0. constructor of class StrategyModule......................ERROR")
    try:
        StrategyModule.__doc__
        display.display("1. docstring of StrategyModule................................OK")
    except:
        display.display("1. docstring of StrategyModule................................ERROR")
    try:
        StrategyModule.get_host_list.__doc__
        display.display("2. docstring of get_host_list..................................OK")
    except:
        display.display("2. docstring of get_host_list..................................ERROR")

# Generated at 2022-06-25 12:09:56.421169
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_0 = 'Test for constructor of class StrategyModule.'
    print('STRATEGY_MODULE')
    print(type(StrategyModule))
    print(StrategyModule)
    print('STRATEGY_MODULE')
    print('StrategyModule.__doc__')
    print(StrategyModule.__doc__)
    print('StrategyModule.__doc__')
    print('StrategyModule.__name__')
    print(StrategyModule.__name__)
    print('StrategyModule.__name__')
    print('StrategyModule.__module__')
    print(StrategyModule.__module__)
    print('StrategyModule.__module__')
    print('StrategyModule.__bases__')
    print(StrategyModule.__bases__)

# Generated at 2022-06-25 12:09:57.340921
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:10:01.365129
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #str_1 = 'Unit test for constructor of class StrategyModule.'
    try:
        test_0 = StrategyModule(tqm = 0)
        assert True
    except:
        assert False, 'Test for constructor of class StrategyModule failed.'
    return

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:10:04.688190
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_1 = -3879.482
    strategy_module_1 = StrategyModule(float_1)


test_case_0()
test_StrategyModule()

# Generated at 2022-06-25 12:10:06.026473
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert test_case_0() == None

test_StrategyModule()

# Generated at 2022-06-25 12:10:08.275077
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -6178.796
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:10:09.081946
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:10:10.495523
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3879.482
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:10:13.339538
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_0 = StrategyModule(strategy_module_0)
    test_case_0()

# Generated at 2022-06-25 12:10:21.327211
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3879.482
    strategy_module_0 = StrategyModule(float_0)

    assert isinstance(strategy_module_0.display, object)
    assert hasattr(strategy_module_0.display, 'debug')
    assert hasattr(strategy_module_0.display, 'info')
    assert hasattr(strategy_module_0.display, 'error')
    assert hasattr(strategy_module_0.display, 'banner')
    assert isinstance(strategy_module_0.display, object)
    assert callable(strategy_module_0.display.debug)
    assert callable(strategy_module_0.display.info)
    assert callable(strategy_module_0.display.error)

# Generated at 2022-06-25 12:10:23.129859
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -640.75
    try:
        StrategyModule(float_0)
    except NameError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 12:10:25.819359
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3879.482
    strategy_module_0 = StrategyModule(float_0)
    print(strategy_module_0._tqm)
    print(strategy_module_0._inventory)
    print(strategy_module_0._loader)
    print(strategy_module_0._variable_manager)
    print(strategy_module_0._display)


# Generated at 2022-06-25 12:10:27.420978
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:10:33.906959
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3879.482

    try:
        strategy_module_1 = StrategyModule(float_0)
    except TypeError as e:
        print(e)

test_case_0()
test_StrategyModule()

# Generated at 2022-06-25 12:10:35.905610
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -5733.964
    strategy_module_0 = StrategyModule(float_0)
    assert_true(True)



# Generated at 2022-06-25 12:10:39.569257
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3879.482
    strategy_module_0 = StrategyModule(float_0)
    assert strategy_module_0._host_pinned == True
    assert strategy_module_0._tqm == -3879.482


# Generated at 2022-06-25 12:10:40.469483
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	test_case_0()

# Generated at 2022-06-25 12:10:44.424702
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    test_case_1()

if __name__ == '__main__':
    # Unit test for constructor of class StrategyModule
    test_case_0()
    test_case_1()

# Generated at 2022-06-25 12:10:46.540136
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3879.482
    strategy_module_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:10:47.375733
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:10:48.596565
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.pinned import StrategyModule
    assert callable(StrategyModule)


# Generated at 2022-06-25 12:10:49.543365
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()



# Generated at 2022-06-25 12:10:52.214177
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned_0 = -5431.7570861
    strategy_module_0 = StrategyModule(host_pinned_0)


# Generated at 2022-06-25 12:10:59.509055
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Unit test execution
if __name__ == '__main__':
   test_StrategyModule()

# Generated at 2022-06-25 12:11:02.619669
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:11:04.336519
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:11:06.039587
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule, StrategyModule)


# Generated at 2022-06-25 12:11:10.853753
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2271.43
    assert type(float_0) is float
    assert (type(float_0) is float) == False
    StrategyModule(float_0)
    float_1 = -2694.0279
    assert type(float_1) is float
    assert (type(float_1) is float) == False
    StrategyModule(float_1)


if __name__ == '__main__':
    test_StrategyModule()
    test_case_0()

# Generated at 2022-06-25 12:11:13.385688
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3879.482
    strategy_module_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:11:16.517898
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3879.482
    strategy_module_0 = StrategyModule(float_0)
    assert strategy_module_0!= None

# Generated at 2022-06-25 12:11:19.156103
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -1165.2517
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:11:23.013665
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Testing StrategyModule class constructor...\n')
    float_0 = float()
    float_1 = float()
    float_2 = float()
    float_1 = float(float_0)
    float_1 = float(float_0)
    float_2 = float(float_1)

# Generated at 2022-06-25 12:11:24.394415
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:11:35.797876
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -6740.837
    # Testing for constructor of class StrategyModule

    strategy_module_0 = StrategyModule(float_0)
    # Testing if the object of class StrategyModule is created properly or not

    assert isinstance(strategy_module_0, StrategyModule)


# Generated at 2022-06-25 12:11:40.232113
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import os
    import sys
    import string
    import random
    import tempfile
    from ansible.plugins.strategy import StrategyModule
    from ansible.utils.display import Display
    display = Display()
    try:
        float_1 = -3879.482
        strategy_module_1 = StrategyModule(float_1)
    except Exception as e:
        print(str(e))
    else:
        display.display('Execution successful !')


# Generated at 2022-06-25 12:11:43.200285
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global float_0
    global strategy_module_0

    float_0 = -3879.482
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:11:44.541621
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert strategy_module_0.__class__.__name__ == 'StrategyModule'


# Generated at 2022-06-25 12:11:52.880809
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()

# Generated at 2022-06-25 12:11:55.209103
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3879.482
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:11:56.515196
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3879.482
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:11:57.535495
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(isinstance(test_case_0(), StrategyModule))

# Generated at 2022-06-25 12:11:58.522347
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:11:59.298074
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:12:23.452112
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:12:24.239865
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-25 12:12:25.875572
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3645.06
    strategy_module_0 = StrategyModule(float_0)
    assert strategy_module_0 is not None


# Generated at 2022-06-25 12:12:28.937565
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -1936.985
    strategy_module_0 = StrategyModule(float_0)
    strategy_module_0.get_hosts_left_to_run()
    strategy_module_0.save_load_cache()
    strategy_module_0.run()
    test_case_0()
    test_run()


# Generated at 2022-06-25 12:12:31.798630
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    testing = 'test_StrategyModule'
    display.v(testing)
    test_case_0()
    display.v(testing + ' completed')
    return True


# Unit test

# Generated at 2022-06-25 12:12:34.333143
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        # Call method constructor of class StrategyModule
        test_case_0()
    except BaseException as e:
        print('Caught exception: ' + str(e))
        assert False
    else:
        assert True

# Generated at 2022-06-25 12:12:35.137125
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(0)


# Generated at 2022-06-25 12:12:38.353928
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3879.482
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:12:43.533926
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  float_0 = -3879.482
  strategy_module_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:12:49.368550
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    float_0 = float(0.0)
    float_1 = float(-2.0)
    float_2 = float(2.0)
    float_3 = float(1.0)
    float_4 = float(-1.0)
    float_5 = float(-0.4)
    float_6 = float(0.4)
    float_7 = float(-0.1)
    float_8 = float(0.1)
    float_9 = float(-0.8)
    float_10 = float(0.8)

    test_case_0()

    test_case_1(float_0)
    test_case_1(float_1)
    test_case_1(float_2)
    test_case_1(float_3)
    test_case_1(float_4)

# Generated at 2022-06-25 12:13:35.174507
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3899.79
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:13:36.415451
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   float_0 = 6601.37
   strategy_module_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:13:41.604524
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 2.151
    strategy_module_0 = StrategyModule(float_0)
    float_1 = -8.19
    strategy_module_0 = StrategyModule(float_1)
    float_2 = -25.12
    strategy_module_0 = StrategyModule(float_2)
    float_3 = 56.58
    strategy_module_0 = StrategyModule(float_3)
    float_4 = -74.09
    strategy_module_0 = StrategyModule(float_4)
    float_5 = -48.487
    strategy_module_0 = StrategyModule(float_5)

test_StrategyModule()

# Generated at 2022-06-25 12:13:43.746029
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3879.482
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:13:45.023431
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        float_0 = 0.210249
        test_case_0()
    except: pass


# Generated at 2022-06-25 12:13:46.456757
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    err = None
    try:
        test_case_0()
    except Exception as e:
        err = e
    assert err is None


# Generated at 2022-06-25 12:13:48.062229
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(float())


# Generated at 2022-06-25 12:13:49.258375
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 5982.453
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:13:55.333463
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import re
    import random
    random_0 = random.randint(1, 100)
    if (((len(re.findall('[a-z]', 'c')) != 0) or (len(re.findall('[a-z]', 'b')) != 0)) and ((len(re.findall('[a-z]', 'd')) != 0) or (len(re.findall('[a-z]', 'b')) != 0))):
        return random_0
    else:
        return None


# Generated at 2022-06-25 12:13:56.323468
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


test_StrategyModule()

# Generated at 2022-06-25 12:15:41.742514
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -5233.48
    assert_equal(1, StrategyModule(float_0)._host_pinned)
    float_1 = -1343.03
    assert_equal(0, StrategyModule(float_1)._host_pinned)
    float_2 = -1834.19
    assert_equal(1, StrategyModule(float_2)._host_pinned)

if __name__ == '__main__':
    test_StrategyModule()
    test_case_0()

# Generated at 2022-06-25 12:15:43.543223
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3879.482
    strategy_module_0 = StrategyModule(float_0)
    assert strategy_module_0._host_pinned == True

# Generated at 2022-06-25 12:15:44.998540
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3879.482
    strategy_module_0 = StrategyModule(float_0)
    assert(strategy_module_0 == float_0)


# Generated at 2022-06-25 12:15:45.785900
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:15:46.792842
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Make sure the unit test is running in verbose mode
    assert(True)


# Generated at 2022-06-25 12:15:47.792855
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3879.482
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:15:48.822031
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -246.512
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:15:56.580448
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import sys
    import imp
    import argparse

    filename = 'strategy_plugins/host_pinned.py'
    with open(filename, 'rb') as fobj:
        module = imp.load_module('strategy_plugins.host_pinned', fobj, filename, ('.py', 'rb', imp.PY_SOURCE))

    with open(filename, 'rb') as fobj:
        code = compile(fobj.read(), filename, 'exec')
        ns = {}
        eval(code, ns, ns)
        sys.modules['strategy_plugins.host_pinned'] = module

    parser = argparse.ArgumentParser(description='Runs Ansible in a Docker container.')
    parser.add_argument('--private-key',
        type=str,
        required=True)
    parser.add_

# Generated at 2022-06-25 12:15:57.763768
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3879.482
    strategy_module_0 = StrategyModule(float_0)
    return strategy_module_0.__init__


# Generated at 2022-06-25 12:15:58.938206
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3879.482
    strategy_module_0 = StrategyModule(float_0)

    assert (strategy_module_0._host_pinned == True)