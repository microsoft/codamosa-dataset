

# Generated at 2022-06-25 12:08:51.724549
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:08:58.875936
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_1 = 54.6
    strategy_module_0 = StrategyModule(float_1)
    int_0 = 0
    assert not (strategy_module_0.get_hosts(int_0) is not None)
    int_1 = -1
    assert not (strategy_module_0.get_next_task_for_host(int_1) is not None)
    int_2 = -1
    assert not (strategy_module_0.get_next_playbook_task_for_host(int_2) is not None)
    int_3 = 0
    assert not (strategy_module_0.get_failed_hosts(int_3) is not None)
    int_4 = 0

# Generated at 2022-06-25 12:08:59.897600
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:09:05.036967
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_instance = StrategyModule
    # AvailableHosts - Instance Variable:
    #       Dictionary of host -> bool, True means available
    assert isinstance(strategy_module_instance.AvailableHosts, dict)

    # TotalHosts - Instance Variable:
    #       Total number of hosts
    assert isinstance(strategy_module_instance.TotalHosts, int)

    # HostQueue - Instance Variable:
    #       Queue of hosts waiting to start
    assert isinstance(strategy_module_instance.HostQueue, list)

    # HostsDone - Instance Variable:
    #       Hosts that are done in the current iteration
    assert isinstance(strategy_module_instance.HostsDone, list)

    # HostsToDo - Instance Variable:
    #       Hosts that still need to be processed in the current

# Generated at 2022-06-25 12:09:05.771225
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	test_case_0()

# Generated at 2022-06-25 12:09:10.278331
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Check if test_case_0 is executed
    if test_case_0() is True:
        return True
    else:
        return False

if __name__ == "__main__":
    print("Unit test for constructor of class StrategyModule")
    if test_StrategyModule() is True:
        print("Pass")
    else:
        print("Fail")
    print()

# Generated at 2022-06-25 12:09:18.574998
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()
    float_0 = float()

# Generated at 2022-06-25 12:09:19.736181
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:09:24.344464
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3470.19512
    strategy_module_0 = StrategyModule(float_0)
    assert isinstance(strategy_module_0, StrategyModule)
    assert isinstance(strategy_module_0, FreeStrategyModule)

test_case_0()
test_StrategyModule()

# Generated at 2022-06-25 12:09:28.428784
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -8297.330
    strategy_module_0 = StrategyModule(float_0)
    assert strategy_module_0._name is not None
    assert strategy_module_0.get_name() == 'host_pinned'
    assert strategy_module_0.get_host_list() == []


# Generated at 2022-06-25 12:09:35.294157
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 8377.369
    strategy_module_0 = StrategyModule(float_0)
    float_1 = -91544.1
    strategy_module_0 = StrategyModule(float_1)
    float_2 = -33.9194
    strategy_module_0 = StrategyModule(float_2)
    float_3 = -20.7325
    strategy_module_0 = StrategyModule(float_3)
    float_4 = 0.479
    strategy_module_0 = StrategyModule(float_4)

if __name__ == '__main__':
    test_StrategyModule()

    test_case_0()

# Generated at 2022-06-25 12:09:36.467494
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3470.19512
    strategy_module_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:09:38.980379
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 68.97
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:09:40.277306
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # === Start of StrategyModule tests ===

    # === End of StrategyModule tests ===
    pass


# Generated at 2022-06-25 12:09:42.394114
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_1 = -1891.50749
    strategy_module_1 = StrategyModule(float_1)


# Generated at 2022-06-25 12:09:44.488752
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3470.37
    strategy_module_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:09:45.628397
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:09:47.600495
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task_queue_manager_0 = TaskQueueManager()

    StrategyModule(task_queue_manager_0)

# Generated at 2022-06-25 12:09:50.223813
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    # Unit test for constructor of class StrategyModule
    test_StrategyModule()
# End

# Generated at 2022-06-25 12:09:53.968149
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(None)
    assert strategy_module_0._host_pinned == True
    assert strategy_module_0._initialize_task_queue()
# unit test for method get_next_task_lockfree

# Generated at 2022-06-25 12:09:56.026711
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:09:57.592768
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    float_0 = 8997.125168
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:10:01.892990
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3470.19512
    strategy_module_1 = StrategyModule(float_0)
    assert strategy_module_1._host_pinned == True
    assert type(strategy_module_1) == StrategyModule

# def main():
#     test_StrategyModule()

# if __name__ == "__main__":
#     main()

# Generated at 2022-06-25 12:10:05.303350
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -4901.133501
    strategy_module_0 = StrategyModule(float_0)
    assert(strategy_module_0._tqm is not None)

test_case_0()
test_StrategyModule()
print('Success!')

# Generated at 2022-06-25 12:10:09.773437
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3932.11234
    strategy_module_0 = StrategyModule(float_0)
    # Throws an error if a class instance is created
    with pytest.raises(AttributeError):
        strategy_module_0.__init__()
    return

test_case_0()
test_StrategyModule()

# Generated at 2022-06-25 12:10:11.661534
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3470.19512
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:10:17.572197
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    serial_0 = 500
    float_0 = float(serial_0)
    strategy_module_0 = StrategyModule(float_0)

if __name__ == '__main__':
    serial_0 = 500
    float_0 = float(serial_0)
    strategy_module_0 = StrategyModule(float_0)
    #print("strategy_module_0 = " + str(strategy_module_0))

    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:10:18.565101
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:10:22.136176
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = float('0')
    float_1 = float('inf')
    float_2 = float('-inf')
    float_3 = float('nan')
    assert math.isnan(float_3) == True
    assert math.isinf(float_1) == True
    assert math.isinf(float_2) == True
    test_case_0()

# Generated at 2022-06-25 12:10:23.832286
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3470.19512
    strategy_module_0 = StrategyModule(float_0)
    assert type(strategy_module_0) == StrategyModule


# Generated at 2022-06-25 12:10:27.987617
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:10:31.373348
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3470.19512
    strategy_module_0 = StrategyModule(float_0)
    assert str(strategy_module_0) == 'StrategyModule(tqm={:g})'.format(-3470.19512)


# Generated at 2022-06-25 12:10:33.618502
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -168.18505859375
    strategy_module_0 = StrategyModule(float_0)
    # TEST CASE 0
    test_case_0()

# Generated at 2022-06-25 12:10:37.282745
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    cmd = 'ansible-playbook site.yml --check --connection=local --inventory 127.0.0.1, -e hosts=generic1 --module-path tester-0.0.1-py3.6.egg'
    os.system(cmd)
    assert True

# Generated at 2022-06-25 12:10:39.640029
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -6915.8
    strategy_module_0 = StrategyModule(float_0)

if __name__ == '__main__':
    test_StrategyModule()
    test_case_0()

# Generated at 2022-06-25 12:10:42.062628
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3470.19512
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:10:44.150177
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -882.4037
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:10:45.171242
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:10:47.375670
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -1450.93333
    strategy_module_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:10:49.222597
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3470.19512
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:10:55.141727
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_1 = -1233.0316
    strategy_module_1 = StrategyModule(float_1)
    string_0 = strategy_module_1.get_name()
# AssertionError: 'host_pinned' != 'free'
    assert string_0 == 'host_pinned'


# Generated at 2022-06-25 12:11:00.207892
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-25 12:11:01.756344
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3470.19512
    test_case_0()


# Generated at 2022-06-25 12:11:02.777845
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:11:04.471431
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(float).__init__.__globals__['_host_pinned'] == True

# Generated at 2022-06-25 12:11:05.664396
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    collector_0 = test_case_0()

# Generated at 2022-06-25 12:11:07.427935
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.0
    strategy_module_0 = StrategyModule(float_0)
    assert True

# Generated at 2022-06-25 12:11:08.610558
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(1)

# Generated at 2022-06-25 12:11:10.215838
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Call test_case_0
    test_case_0()



# Generated at 2022-06-25 12:11:13.435508
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Constructor with arguments
    float_0 = 1.0
    strategy_module_1 = StrategyModule(float_0)


# Generated at 2022-06-25 12:11:22.576995
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -6534.05147
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:11:28.057390
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3470.19512
    strategy_module_0 = StrategyModule(float_0)
    assert strategy_module_0._host_pinned is True
    assert strategy_module_0._batches is not None
    assert strategy_module_0._tqm is not None
    assert strategy_module_0.name == 'host_pinned'


# Generated at 2022-06-25 12:11:30.016666
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 12349.3464
    StrategyModule(float_0)


# Generated at 2022-06-25 12:11:31.266674
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:11:33.751330
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Unit test for __init__ method of class StrategyModule
    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:11:34.814934
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case = test_case_0
    test_case()

# Generated at 2022-06-25 12:11:35.819279
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3470.19512
    StrategyMo

# Generated at 2022-06-25 12:11:38.674171
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3470.19512
    strategy_module_0 = StrategyModule(float_0)
    boolean_0 = strategy_module_0._host_pinned
    boolean_1 = StrategyModule(float_0)._host_pinned
    assert boolean_0 == boolean_1
    assert boolean_0 == True

# Generated at 2022-06-25 12:11:39.925235
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()


# Generated at 2022-06-25 12:11:43.161666
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    float_0 = -3470.19512
    strategy_module_0 = StrategyModule(float_0)
    assert strategy_module_0._host_pinned == True, 'assertion failed'


# Generated at 2022-06-25 12:12:04.221932
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 6689.6007
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:12:06.488819
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule('')

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:12:09.537649
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_2 = -2368.57381
    assert len(strategy_module_0.__init__) == 1
    assert isinstance(strategy_module_0.__init__, (int, float, complex))

# Generated at 2022-06-25 12:12:11.684470
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3470.19512
    strategy_module_0 = StrategyModule(float_0)


if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:12:13.755078
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3470.19512
    strategy_module_0 = StrategyModule(float_0)



if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:12:14.896715
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Unit test suite for module StrategyModule

# Generated at 2022-06-25 12:12:16.157998
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test for constructor of class StrategyModule

    # Test for constructor of class StrategyModule
    test_case_0()

# Generated at 2022-06-25 12:12:17.422810
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        test_case_0()
    except:
        display.error("Failed to construct StrategyModule")

# Generated at 2022-06-25 12:12:19.336574
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


if __name__ == "__main__":
    # This is not a truly unit test, but it shows that the program does not crash
    test_StrategyModule()

# Generated at 2022-06-25 12:12:21.266047
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -7446.85
    strategy_module_0 = StrategyModule(float_0)
    assert(strategy_module_0._host_pinned == True)

# Generated at 2022-06-25 12:13:02.065821
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(-3470.19512)


test_case_0()

# Generated at 2022-06-25 12:13:03.583973
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3470.19512
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:13:04.261528
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:13:05.509675
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == True


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:13:06.528423
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -430.35
    strategy_module_0 = StrategyModule(float_0)

# Generated at 2022-06-25 12:13:07.777656
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -2489.14194
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:13:09.561662
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:13:12.156480
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        # initialize the object
        strategy_module_0 = StrategyModule(float(-43.29711))
    except Exception as err:
        # print the exception message
        print(err)

test_StrategyModule()

# Generated at 2022-06-25 12:13:14.994419
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -9940.85929
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:13:16.216338
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3470.19512
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:14:39.102617
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert test_case_0() == None,\
        'Constructor of class StrategyModule failed'


# Generated at 2022-06-25 12:14:40.259685
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3470.19512
    strategy_module_0 = StrategyModule(float_0)
    assert isinstance(strategy_module_0, StrategyModule)


# Generated at 2022-06-25 12:14:41.891979
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:14:45.486359
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3470.19512
    assert (str(type(strategy_module_0))) == "<class '__main__.StrategyModule'>"
    assert (strategy_module_0.tqm) == float_0
    assert (strategy_module_0._host_pinned)


# Generated at 2022-06-25 12:14:46.751228
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 7733.39
    strategy_module_0 = StrategyModule(float_0)
    assert isinstance(strategy_module_0, object)


# Generated at 2022-06-25 12:14:48.166525
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:14:55.291350
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3055.13
    strategy_module_0 = StrategyModule(float_0)
    assert(str(type(strategy_module_0)) == "<class 'ansible.plugins.strategy.host_pinned.StrategyModule'>")

# Generated at 2022-06-25 12:14:57.399028
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3470.19512
    StrategyModule_0 = StrategyModule(float_0)
    assert StrategyModule_0._host_pinned == True

test_case_0()
test_StrategyModule()

# Generated at 2022-06-25 12:14:59.245941
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:15:00.676049
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:18:12.420217
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:18:13.405057
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

test_case_0()
test_StrategyModule()

# Generated at 2022-06-25 12:18:17.630218
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''class StrategyModule
    '''
    float_0 = -3470.19512
    strategy_module_0 = StrategyModule(float_0)
    str_0 = str(strategy_module_0)

    # __init__
    float_0 = -3470.19512
    strategy_module_0 = StrategyModule(float_0)

    # calc_forks
    int_0 = strategy_module_0.calc_forks()
    assert int_0 == 40

    # calc_serial
    int_0 = strategy_module_0.calc_serial()
    assert int_0 == 9

    # calc_loop
    int_0 = strategy_module_0.calc_loop()
    assert int_0 == -3470

    # get_host_list
    dict_0 = strategy_module

# Generated at 2022-06-25 12:18:18.859716
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule(14.330000000000002)
    assert isinstance(strategy_module_0._host_pinned,bool)

# Generated at 2022-06-25 12:18:19.782362
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # "Escape" parameter is not used in constructor
    # Constructor is just a placeholder
    pass


# Generated at 2022-06-25 12:18:21.667038
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = 0.690971363
    strategy_module_0 = StrategyModule(float_0)
    assert strategy_module_0._host_pinned is True

# Test case for method StrategyModule.run
# Test case for setup_queues

# Generated at 2022-06-25 12:18:22.446631
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:18:27.736412
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -822.02604
    strategy_module_0 = StrategyModule(float_0)
    strategy_module_0.run_play(strategy_module_0.play)
    strategy_module_0.cleanup()


# Generated at 2022-06-25 12:18:29.767620
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    float_0 = -3470.19512
    strategy_module_0 = StrategyModule(float_0)


# Generated at 2022-06-25 12:18:30.419919
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  test_case_0()