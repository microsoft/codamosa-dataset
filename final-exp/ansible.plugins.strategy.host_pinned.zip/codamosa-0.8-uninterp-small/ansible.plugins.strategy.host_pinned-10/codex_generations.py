

# Generated at 2022-06-25 12:08:51.968105
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xf5\xba\x84\xf3\x03\xddo'
    strategy_module_0 = StrategyModule(bytes_0)
    assert strategy_module_0._host_pinned == True

# Generated at 2022-06-25 12:08:59.076173
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()
    bool_21 = bool()
    bool_22 = bool()
    bool_23 = bool()
    bool_24 = bool()

# Generated at 2022-06-25 12:09:09.504059
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-25 12:09:15.543339
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xf5\xba\x84\xf3\x03\xddo'
    StrategyModule(bytes_0)
    bytes_1 = b'\x02\xdb\xfe\xf9\x02\xdc\xfa\x05\x1a\xcf\x82\xfa\x0b\x16\x83\xf9\x06\x1c\x1a'
    StrategyModule(bytes_1)


# Generated at 2022-06-25 12:09:17.198701
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_1 = b'\xa3\x92\xb6\x8a\x1f\x1ej'
    strategy_module_1 = StrategyModule(bytes_1)

# Generated at 2022-06-25 12:09:19.520047
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-25 12:09:22.581416
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xf5\xba\x84\xf3\x03\xddo'
    strategy_module_0 = StrategyModule(bytes_0)
    assert strategy_module_0._host_pinned == True

# Generated at 2022-06-25 12:09:32.023506
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x1b\xcb\xd5\x84\x9e\x90\x82\x88\xc2\xbe\xb7=\x0cF\x9e\x9b\x81\x1c'
    bytes_1 = b'\xdf\x05\x1b_\x9a\xaa\x1a\x8a\xba'
    bytes_2 = b'\xeb\xa6\x9a\x1a\xd0\\\xa2\x8c\xab\r'
    bytes_3 = b'\x99\x13\xe4\x92\x15\xdc\xb5\x90\xfa\xe4v\x9d\xd2'

# Generated at 2022-06-25 12:09:37.915109
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.__init__ import StrategyModule
    from ansible.plugins.loader import strategy_loader
    from ansible.parsing.plugin_docs import read_docstring
    from ansible.utils.display import Display
    print("Testing StrategyModule class constructor")
    details = read_docstring(strategy_loader._get_all_classes()[0], verbose=False)
    assert details['doc'] == 'Executes tasks on each host without interruption'
    assert details['name'] == 'host_pinned'
    assert details['short_description'] == 'Executes tasks on each host without interruption'
    assert details['version_added'] == '2.7'
    assert details['author'] == 'Ansible Core Team'


# Generated at 2022-06-25 12:09:41.756902
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xf5\xba\x84\xf3\x03\xddo'
    strategy_module_0 = StrategyModule(bytes_0)

# Generated at 2022-06-25 12:09:50.429931
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xf5\xba\x84\xf3\x03\xddo'
    strategy_module_0 = StrategyModule(bytes_0)
    str_0 = str(strategy_module_0)
    assert (str_0 == "<ansible.plugins.strategy.host_pinned.StrategyModule object at 0x7f34cc094a58>")
    assert (strategy_module_0._host_pinned == True)
    assert (strategy_module_0._tqm == bytes_0)


# Generated at 2022-06-25 12:09:54.771030
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    strategy_module_0 = StrategyModule(None)
    assert type(strategy_module_0.display) is Display


# Generated at 2022-06-25 12:09:58.808056
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x98\xa8\x80\xca\xdf\x9bs\xb9\x9c'
    strategy_module_0 = StrategyModule(bytes_0)

    # Note that this test case will not be run if the class is not implemented

    return


# Generated at 2022-06-25 12:10:02.432902
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xf5\xba\x84\xf3\x03\xddo'
    strategy_module_0 = StrategyModule(bytes_0)
    tqm_0 = strategy_module_0.get_tqm()
    assert tqm_0 == bytes_0


# Generated at 2022-06-25 12:10:08.312589
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xd3\xde\x00\xcc\x83\x81\x12\x89\xfb\xb8\x1f\x96\x06\xbd\x8f\xa6\x5f\xf5\xed\xc8\xad\x95\x1f\x90\x9d\x04\xac'
    strategy_module_0 = StrategyModule(bytes_0)

# Generated at 2022-06-25 12:10:17.788296
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x1d\xed\xf0\xd9~\xe6\x97'
    strategy_module_0 = StrategyModule(bytes_0)
    strategy_module_0.run_queue()
    buffer_0 = b'\x95\xb8\x83\xf27\x9a\xde\x9d\x1a\xfd\xafQA\x8a'
    strategy_module_0.hosts_left(buffer_0)
    long_0 = strategy_module_0.get_host_pinned()
    assert long_0 == 1
    strategy_module_0.hosts_left(buffer_0)
    long_0 = strategy_module_0.get_host_pinned()
    assert long_0 == 1
    dict_0 = dict()

# Generated at 2022-06-25 12:10:18.768056
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:10:20.055460
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # with pytest.raises(TypeError):
    #     StrategyModule(object())
    assert True

# Generated at 2022-06-25 12:10:22.203471
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xf5\xba\x84\xf3\x03\xddo'
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:10:24.735714
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xf5\xba\x84\xf3\x03\xddo'
    strategy_module_1 = StrategyModule(bytes_0)
    assert strategy_module_1._host_pinned == True

test_case_0()
test_StrategyModule()

# Generated at 2022-06-25 12:10:28.901581
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(test_StrategyModule, '_host_pinned') == True
    assert hasattr(test_StrategyModule, '_host_key') == False

# Generated at 2022-06-25 12:10:32.109332
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xf5\xba\x84\xf3\x03\xddo'
    strategy_module_0 = StrategyModule(bytes_0)



# Generated at 2022-06-25 12:10:40.468140
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xc9\x1b;\xdf\xdc\xe5\xea'
    strategy_module_0 = StrategyModule(bytes_0)

    bytes_0 = b'\x8d\xb1\t?\xbb\x1f\x10\x9c'
    strategy_module_0 = StrategyModule(bytes_0)

    bytes_1 = b'\x8d\xb1\t?\xbb\x1f\x10\x9c'
    strategy_module_0 = StrategyModule(bytes_1)

    bytes_0 = b'\xa5\xfe\xd5\xcd\x87\xfa\xcd'
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:10:44.697912
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xf5\xba\x84\xf3\x03\xddo'
    strategy_module_0 = StrategyModule(bytes_0)
    assert strategy_module_0._host_pinned == True


# Generated at 2022-06-25 12:10:48.241343
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xf5\xba\x84\xf3\x03\xddo'
    strategy_module_0 = StrategyModule(bytes_0)
    assert (strategy_module_0._host_pinned == True)


# Generated at 2022-06-25 12:10:54.501764
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xf5\xba\x84\xf3\x03\xddo'
    strategy_module_0 = StrategyModule(bytes_0)
    assert strategy_module_0._tqm is bytes_0
    assert strategy_module_0._send_to_queue is None
    assert strategy_module_0._host_pinned is True
    assert strategy_module_0._play is None
    assert strategy_module_0._iterator is None
    assert strategy_module_0._block is None
    assert strategy_module_0._count_tasks is None

# Generated at 2022-06-25 12:10:55.597795
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule, object)


# Generated at 2022-06-25 12:10:58.828361
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xf5\xba\x84\xf3\x03\xddo'
    strategy_module_0 = StrategyModule(bytes_0)
    assert hasattr(strategy_module_0, '_host_pinned'), "You broke StrategyModule. Need to add self._host_pinned"
    assert strategy_module_0._host_pinned == True, "You broke StrategyModule. Need to initialize self._host_pinned to True"

# Generated at 2022-06-25 12:11:01.645703
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x03\xd0'
    strategy_module_0 = StrategyModule(bytes_0)

# Generated at 2022-06-25 12:11:06.193680
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xf5\xba\x84\xf3\x03\xddo'
    strategy_module_0 = StrategyModule(bytes_0)
    assert isinstance(strategy_module_0, StrategyModule)

if __name__ == '__main__':
    pass

# Generated at 2022-06-25 12:11:12.325438
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    test_case_0()

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:11:18.445103
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\x0c\xab\xf7\x1b\x94\xaeA'
    strategy_module_0 = StrategyModule(bytes_0)
    assert strategy_module_0
    assert isinstance(strategy_module_0, StrategyModule)


# Generated at 2022-06-25 12:11:21.309150
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x95\xe1\xc2\xd7y\x01\xf3\x80'
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:11:22.195612
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:11:24.017691
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:11:27.857741
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xf5\xba\x84\xf3\x03\xddo'
    strategy_module_0 = StrategyModule(bytes_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:11:33.457755
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x93J\xce\x8c\x9fy\x02|'
    strategy_module_0 = StrategyModule(bytes_0)
    assert ((strategy_module_0.run_handlers is True) and ( (not (strategy_module_0.run_tasks is True)) and (not (strategy_module_0.last_task_banner is True))))



# Generated at 2022-06-25 12:11:34.958085
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Testing if constructor of class StrategyModule is working properly or not
    test_case_0()


# Generated at 2022-06-25 12:11:43.273490
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xf5\xba\x84\xf3\x03\xddo'
    strategy_module_0 = StrategyModule(bytes_0)
    assert isinstance(strategy_module_0, StrategyModule) is True
    assert strategy_module_0._tqm == bytes_0
    assert isinstance(strategy_module_0.display, Display) is True
    assert strategy_module_0._host_pinned is True
    assert strategy_module_0._play_context is None
    assert strategy_module_0._iterator is None
    assert strategy_module_0._final_q is None
    assert strategy_module_0._new_stdin is None
    assert strategy_module_0._final_q_lock is None
    assert strategy_module_0._var_cache is None
    assert strategy

# Generated at 2022-06-25 12:11:44.353574
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:11:56.852028
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  bytes_0 = b'\xf5\xba\x84\xf3\x03\xddo'
  strategy_module_0 = StrategyModule(bytes_0)

# Generated at 2022-06-25 12:11:58.650076
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xf5\xba\x84\xf3\x03\xddo'
    assert_equal(test_case_0(), None)

# Generated at 2022-06-25 12:11:59.394266
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:12:01.556682
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x88\xaf'
    strategy_module_0 = StrategyModule(bytes_0)
    assert (strategy_module_0._host_pinned is True)

# Generated at 2022-06-25 12:12:02.553333
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:12:03.504124
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_0 = StrategyModule()


# Generated at 2022-06-25 12:12:11.817631
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # bytes_0 = b'\xf5\xba\x84\xf3\x03\xddo'
    # strategy_module_0 = StrategyModule(bytes_0)

    assert True == True

    # assertBytesEqual(strategy_module_0._host_pinned, b'\xb6U\x1f\x0c\x12\x8f\x1b\xde\x12\x8b\x8a\x15\xe1\x9d\x1f\xef')
    #assertIsInstance(strategy_module_0, StrategyModule)
    #assertEqual(strategy_module_0, strategy_module_0)
    #assertIsNone(strategy_module_0)

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-25 12:12:18.753350
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xf5\xba\x84\xf3\x03\xddo'
    # calling constructor of class 'StrategyModule' without necessary arguments
    strategy_module_1 = StrategyModule(bytes_0)
    bytes_1 = b'\xd3m\xe8\x9f\xbf\xd7\x1a\x19'
    bytes_2 = b'\x1b\xa3\x00\x9b\x95\xa9\x0b'
    # calling constructor of class 'StrategyModule' with all arguments
    strategy_module_2 = StrategyModule(bytes_1, bytes_2)
    bytes_3 = b'\xf5\xba\x84\xf3\x03\xddo'
    # calling constructor of class 'StrategyModule' without necessary

# Generated at 2022-06-25 12:12:26.421684
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xe5\x1dN\x90\x9e\xfc\x84'
    strategy_module_0 = StrategyModule(bytes_0)

if __name__ == '__main__':
    format_bytes = b'\xf3\x80\x87\xe8\xdf\x88\x9b'
    format_str = b'\xf3\x80\x87\xe8\xdf\x88\x9b'.decode()

# Generated at 2022-06-25 12:12:30.049458
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x1c\x1e\x8b\x93\xd5\x7f-\xab\xcb'
    strategy_module_0 = StrategyModule(bytes_0)
    assert getattr(strategy_module_0, '_host_pinned') is True


# Generated at 2022-06-25 12:12:59.142352
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x02\xc7\x82\x03\xdd4\x93\xa7\xf5\xc0\xe6\x82\xc5\x84\xae'
    strategy_module_0 = StrategyModule(bytes_0)
    my_vars_0 = strategy_module_0.get_host_pins()
    assert my_vars_0 == {}, my_vars_0
    bytes_1 = b'\x97'
    strategy_module_1 = StrategyModule(bytes_1)
    my_vars_1 = strategy_module_1.get_host_pins()
    assert my_vars_1 == {}, my_vars_1
    bytes_2 = b'\x97'
    strategy_module_2 = StrategyModule(bytes_2)


# Generated at 2022-06-25 12:13:00.879375
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_1 = b'"\x10\xa4\xd3\xa0\x90S\x1f'
    pass # TODO: implement your test here


# Generated at 2022-06-25 12:13:03.346694
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    with mock.patch.object(StrategyModule, '__init__', return_value=None) as mock_init:
        mock_init.assert_called_with(b'\xf5\xba\x84\xf3\x03\xddo')


# Generated at 2022-06-25 12:13:05.986335
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    var_1 = bytes(bytearray([16, 22, 49, 36, 10, 235, 243, 253, 63, 102, 55, 232, 168, 128, 175, 145]))
    var_2 = StrategyModule(var_1)
    assert isinstance(var_2, StrategyModule) == True


# Generated at 2022-06-25 12:13:06.986360
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:13:08.757577
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'>\xd0\x18\x0b\x87\xd5\x12\xf9\xcf\xd1'
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:13:10.568423
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x0fI\x1b\x1a\x0f'
    strategy_module_0 = StrategyModule(bytes_0)
    try:
        strategy_module_0.run()
    except Exception as e:
        display.warning(str(e))

# Generated at 2022-06-25 12:13:11.932164
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-25 12:13:16.213626
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    with pytest.raises(TypeError) as excinfo:
        test_case_0()
    the_exception = excinfo.value
    assert 'argument 1 must be a _io.TextIOWrapper, not bytes' in str(the_exception)

# Generated at 2022-06-25 12:13:18.040434
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xf5\xba\x84\xf3\x03\xddo'
    strategy_module_0 = StrategyModule(bytes_0)
    assert bytes_0 is not None


# Generated at 2022-06-25 12:14:02.529157
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)


# Generated at 2022-06-25 12:14:05.734164
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # given
    bytes_0 = b'\xf5\xba\x84\xf3\x03\xddo'
    # when
    strategy_module_0 = StrategyModule(bytes_0)
    # then
    assert bool(strategy_module_0) is True


# Generated at 2022-06-25 12:14:07.425341
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xf5\xba\x84\xf3\x03\xddo'
    assert isinstance(StrategyModule(bytes_0), StrategyModule)

# Generated at 2022-06-25 12:14:13.395876
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x98\x9a\xdd\x15\xdc\xc5\xd7\x1e\xba\x8d\xcf\x9b6\x84\xc0\x98\xf4'
    strategy_module_0 = StrategyModule(bytes_0)
    str_0 = strategy_module_0.run()
    print(str_0)

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:14:16.304781
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xc0\x9f\xa2\xfb\x0e\x8f\xa2'
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:14:17.949309
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Unit test for constructor of class StrategyModule
    """
    assert True

if __name__ == '__main__':
    test_case_0()
    test_StrategyModule()

# Generated at 2022-06-25 12:14:18.635489
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

# Generated at 2022-06-25 12:14:26.245086
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xa7\xbe\xef\xcf\xdd%j\x0e\xe8'
    strategy_module_0 = StrategyModule(bytes_0)
    assert(strategy_module_0.worker_pool is not None)
    assert(strategy_module_0.loader is not None)
    assert(strategy_module_0.inventory is not None)
    assert(strategy_module_0.variable_manager is not None)
    assert(strategy_module_0.display is not None)
    assert(strategy_module_0.stats is not None)
    assert(strategy_module_0._inventory_has_hosts(bytes_0))
    assert(strategy_module_0._tqm is not None)

# Generated at 2022-06-25 12:14:28.022837
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_1 = b'\xf5\xba\x84\xf3\x03\xddo'
    assert isinstance(StrategyModule(bytes_1), StrategyModule)

# Generated at 2022-06-25 12:14:30.755367
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'z\x85\xbd\xef'
    strategy_module_0 = StrategyModule(bytes_0)

# Generated at 2022-06-25 12:16:07.966115
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()

test_StrategyModule()

# Generated at 2022-06-25 12:16:10.840910
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = Mock()
    strategy_module_0 = StrategyModule(tqm)
    # This should not return anything but it does return None
    #assert strategy_module_0 == None

# unit test for get_host_list of class StrategyModule

# Generated at 2022-06-25 12:16:12.780334
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xf5\xba\x84\xf3\x03\xddo'
    # test constructor with valid argument
    assert test_case_0()
    # test constructor with invalid argument
    # TypeError: __init__() takes exactly 2 arguments (0 given)

# Generated at 2022-06-25 12:16:15.533825
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\x9b\x98\xb7!\xba\x8e\x81'
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:16:17.252359
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xf5\xba\x84\xf3\x03\xddo'
    #Test for constructor of class StrategyModule
    assert StrategyModule(bytes_0)


# Generated at 2022-06-25 12:16:21.053887
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module_name_0 = '0\xac\xc7\xaa\x1b\xf3\x16'
    bytes_0 = b'\x8bM\xfe\xd2\x98\xe7\x8c\xf5 as\xbf\x93\xd6\x1c\x9e\xfe\xd4'
    strategy_module_0 = StrategyModule(bytes_0)
    assert len(strategy_module_0.get_hosts()) == 0


# Generated at 2022-06-25 12:16:29.727671
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-25 12:16:30.406519
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_case_0()


# Generated at 2022-06-25 12:16:32.603385
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bytes_0 = b'\xf5\xba\x84\xf3\x03\xddo'
    strategy_module_0 = StrategyModule(bytes_0)


# Generated at 2022-06-25 12:16:35.023113
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test with a global variable
    bytes_0 = b'\xf5\xba\x84\xf3\x03\xddo'
    strategy_module_0 = StrategyModule(bytes_0)
    assert hasattr(strategy_module_0, 'tqm')