

# Generated at 2022-06-23 13:02:04.931909
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert getattr(StrategyModule,'__init__')('tqm') != None

# Generated at 2022-06-23 13:02:14.830549
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned

    # mock tqm object
    class Object(object):
        pass

    object = Object()
    object.display = Display()
    object.forks = 5

# Generated at 2022-06-23 13:02:18.114103
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'ansible tqm'
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned is True

# Generated at 2022-06-23 13:02:19.882493
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test'
    strategy = StrategyModule(tqm)
    assert strategy._tqm == 'test'

# Generated at 2022-06-23 13:02:29.715658
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm._host_pinned
    assert sm._tqm == tqm
    assert sm._inventory == tqm._inventory
    assert sm._play_context == tqm._play_context
    assert sm._all_hosts == tqm._inventory.get_hosts()
    assert sm._work_queue == tqm.get_work_queue()
    assert sm._final_q == tqm._final_q
    assert sm._loader == tqm._loader
    assert sm._variable_manager == tqm._variable_manager
    assert sm._fail_queue == tqm._failed_hosts


# Generated at 2022-06-23 13:02:31.754601
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(0)
    assert obj._host_pinned == True

# Generated at 2022-06-23 13:02:34.672618
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule class.")

test_StrategyModule()

# Generated at 2022-06-23 13:02:37.410224
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert(s is not None)
    assert(s._host_pinned)

# Generated at 2022-06-23 13:02:38.629850
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:02:41.194118
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm=None)
    assert sm._host_pinned is True

# Generated at 2022-06-23 13:02:44.358622
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    test_strategy_module = StrategyModule(tqm)
    test_strategy_module._host_pinned


# Generated at 2022-06-23 13:02:48.159127
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    st=StrategyModule(12)
    assert(isinstance(st, StrategyModule))
    assert(st._host_pinned == True)


# Generated at 2022-06-23 13:02:50.809919
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:02:54.610738
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = Mock()
    strategy = MyStrategyModule(tqm)
    assert isinstance(strategy, StrategyModule)
    assert isinstance(strategy, FreeStrategyModule)
    assert strategy._host_pinned is True



# Generated at 2022-06-23 13:02:56.504955
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule(tqm)
    StrategyModule(tqm)
    return True

# Generated at 2022-06-23 13:03:05.596459
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from units.mock.loader import DictDataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager

    global display
    display = Display()

    loader = DictDataLoader({})
    play = Play.load({}, loader=loader, variable_manager=VariableManager())
    inventory = play.get_variable_manager().get_inventory()
    hostvars = inventory._hosts

    # test StrategyModule.__init__()

# Generated at 2022-06-23 13:03:12.123794
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.plugins.loader import connection_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import available_vars

    host = 'testhost_stratmod'


# Generated at 2022-06-23 13:03:14.228319
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(1)
    assert a._host_pinned is True


# Generated at 2022-06-23 13:03:14.839901
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:03:17.632673
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=TestTqm())
    assert strategy_module._host_pinned == True

# Please note the function and class definitions below are only used for unit tests and not used in execution

# Generated at 2022-06-23 13:03:19.145518
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__.__doc__


## Unit test for main execution of module

# Generated at 2022-06-23 13:03:20.527170
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Generated at 2022-06-23 13:03:22.697285
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	module = StrategyModule("tqm")
	result = module._host_pinned
	assert_equal(result, True)


# Generated at 2022-06-23 13:03:23.570521
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  assert StrategyModule

# Generated at 2022-06-23 13:03:25.299123
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)._host_pinned == True

# Generated at 2022-06-23 13:03:27.553146
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule('tqm')
    assert obj is not None
    assert obj._host_pinned is not False

# Generated at 2022-06-23 13:03:29.333117
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj_StrategyModule = StrategyModule()
    obj_StrategyModule._host_pinned = True


# Generated at 2022-06-23 13:03:30.828239
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:03:32.914399
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:03:36.382156
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Initialize Strategy Module object
    myTest = StrategyModule(None)
    print("Host Pinned: %s" % (myTest._host_pinned))


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:03:40.049328
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(None, None, None, None, None, None)
    StrategyModule(tqm)

# Generated at 2022-06-23 13:03:42.379564
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from mock import Mock
    from ansible.plugins.strategy.host_pinned import StrategyModule
    assert StrategyModule is not None
    tqm = Mock()
    StrategyModule(tqm)

# Generated at 2022-06-23 13:03:46.367619
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module.tqm == None
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:03:47.478168
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 13:03:50.577269
# Unit test for constructor of class StrategyModule
def test_StrategyModule():     # noqa
    # Dummy test to demonstrate the requiremenets of code coverage.
    # "pass" is a Python no-op. It does nothing.
    # Still, it is a valid Python statement, so we can include it in a suite.
    pass

# Generated at 2022-06-23 13:03:58.568316
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    hosts = {
        'localhost': {
            'name': 'localhost',
            'vars': {}
        }
    }

    tqm = FakeTaskQueueManager(hosts)
    strategy = StrategyModule(tqm)
    assert strategy._tqm == tqm
    assert strategy._host_pinned is True
    assert strategy.get_host_list() == ['localhost']
    assert strategy.get_failed_hosts() == {}
    assert strategy.get_variable_manager()


# Generated at 2022-06-23 13:04:00.059306
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule('tqm')
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:04:01.091110
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 13:04:02.162796
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1 == 1, 'Test not implemented'

# Generated at 2022-06-23 13:04:06.321038
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    tqm = None
    assert isinstance(ansible.plugins.strategy.host_pinned.StrategyModule(tqm), ansible.plugins.strategy.host_pinned.StrategyModule)

# Generated at 2022-06-23 13:04:08.338113
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:04:15.604403
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestClass(object):
        def __init__(self):
            self.fake_strategy_module = StrategyModule(TestClass)

        def __repr__(self):
            return self.fake_strategy_module.__repr__()

        def __str__(self):
            return self.fake_strategy_module.__str__()

        def get_host_list(self):
            return self.fake_strategy_module.get_host_list()

        def get_failed_hosts(self):
            return self.fake_strategy_module.get_failed_hosts()

        def get_changed_hosts(self):
            return self.fake_strategy_module.get_changed_hosts()

        def get_unreachable_hosts(self):
            return self.fake_strategy

# Generated at 2022-06-23 13:04:16.580270
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:04:18.150523
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Unit test function test_display_ok

# Generated at 2022-06-23 13:04:26.808431
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock
    import __main__ as main
    from ansible.plugins.strategy.host_pinned import StrategyModule as host_pinned
    from ansible.playbook.task_include import TaskInclude

    task_queue_manager = mock.MagicMock()
    task_queue_manager._hosts = mock.MagicMock()
    task_queue_manager._hosts.get.return_value = mock.MagicMock()
    task_queue_manager._hosts.get.return_value._play_context = mock.MagicMock()
    task_queue_manager._hosts.get.return_value._play_context.serial = 2
    include = TaskInclude()
    include.static = True
    include.tags = dict()
    include.tags['all'] = True
    include.tags['include'] = True


# Generated at 2022-06-23 13:04:30.104420
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy as strategy

    tqm = strategy.load_strategy_plugin('host_pinned')
    print(type(tqm))
    assert tqm == StrategyModule

# Generated at 2022-06-23 13:04:31.309854
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(object()) is not None

# Generated at 2022-06-23 13:04:33.384980
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    arg1 = [1]
    arg1.append(2)
    assert arg1 == [1,2]

# Generated at 2022-06-23 13:04:33.994008
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:04:44.398235
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule as _StrategyModule
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory
    from ansible.executor import module_common
    from ansible.utils.display import Display
    from ansible.utils.color import colorize, hostcolor
    from ansible.tqm import TaskQueueManager
    from ansible.utils.listify import listify_lookup_plugin_terms
    module_loader, temp_path, data_path, loader, module_name, shared_loader_obj = module_common._load_params()

# Generated at 2022-06-23 13:04:44.838855
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:04:45.465539
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:04:46.046171
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:04:47.927303
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm={})
    assert s._host_pinned is True

# Generated at 2022-06-23 13:04:48.354484
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-23 13:04:49.667808
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule("display")
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:04:50.471264
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:04:51.403002
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Generated at 2022-06-23 13:04:51.979973
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:04:52.628893
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:04:56.602259
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
        Unit test for constructor of class StrategyModule
    '''
    strategy = StrategyModule(None)
    assert strategy, "Failed to create StrategyModule object"
    assert strategy._host_pinned, "Failed to set _host_pinned to True"


# Generated at 2022-06-23 13:04:59.732362
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    tqm = None
    s = StrategyModule(tqm)
    print("Tested constructor of class StrategyModule")


# Generated at 2022-06-23 13:05:00.281790
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:05:02.649162
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 123
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:05:08.959701
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule()
    assert module._host_pinned == True
    assert module._play_name == 'Ansible Play'
    assert module._new_play is None
    assert module._cur_serial == 0
    assert module._inventory is None
    assert module._variable_manager is None
    assert module._loader is None
    assert module._tqm._stats is None



# Generated at 2022-06-23 13:05:10.443598
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__bases__ == (FreeStrategyModule,)

# Generated at 2022-06-23 13:05:12.111891
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-23 13:05:13.951849
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:05:14.639591
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert(strategy._host_pinned == True)

# Generated at 2022-06-23 13:05:16.067177
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned

# Generated at 2022-06-23 13:05:24.870152
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Tqm(object):
        def __init__(self):
            self.stats = {
                'dark': 0,
                'failures': 0,
                'ok': 0,
                'processed': 0,
                'skipped': 0,
                'changed': 0,
                'unreachable': 0
            }
            self._final_q = []
            self._old_stdout = sys.stdout


        def get_failed_hosts(self):
            return []

        def send_callback(self, host):
            pass

        def cleanup(self):
            pass

    tqm = Tqm()
    x = StrategyModule(tqm)
    assert x._host_pinned == True
    assert x.get_host_list(tqm) == tqm.inventory.get_

# Generated at 2022-06-23 13:05:26.435672
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=str)
    assert strategy._host_pinned is True

# Generated at 2022-06-23 13:05:27.300269
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
        StrategyModule()


# Generated at 2022-06-23 13:05:28.673350
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm)
    assert sm
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:05:29.709119
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(type('tqm', (), {}))

# Generated at 2022-06-23 13:05:31.064568
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    obj = StrategyModule(tqm)
    assert obj._host_pinned is True

# Generated at 2022-06-23 13:05:31.591983
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:05:33.046492
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_object = StrategyModule()
    assert strategy_module_object is not None


# Generated at 2022-06-23 13:05:36.071551
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import host_pinned

    strategy = host_pinned.StrategyModule(None)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:05:38.079808
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(1)
    assert module._host_pinned == True

# Generated at 2022-06-23 13:05:44.309747
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    print("Testing strategy.host_pinned")
    obj = StrategyModule(0)
    if obj._host_pinned:
        print("Success")
        return 0
    else:
        print("Failure")
        return 1

if __name__ == '__main__':
    import sys
    sys.exit(test_StrategyModule())

# Generated at 2022-06-23 13:05:45.261403
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)

# Generated at 2022-06-23 13:05:47.149957
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert True == strategy._host_pinned

# Generated at 2022-06-23 13:05:53.945721
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   # Test Class instantiation
   print("Test: Instantiation of StrategyModule Class ...")
   tqm = None
   s = StrategyModule(tqm)
   print("\tTest Result: PASSED")

   # Test _host_pinned
   print("Test: _host_pinned of class StrategyModule ...")
   result = s._host_pinned
   assert result == True

   print("\tTest Result: PASSED")

# Generated at 2022-06-23 13:05:55.395906
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:06:03.233148
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult

    test_host = Host(name="test_host")
    test_host.vars = dict(ansible_connection='local')
    test_host.set_variable('ansible_connection', 'local')
    test_host.set_variable('ansible_python_interpreter', '/usr/bin/python3')

    test_group = Group(name="test_group")
    test_group.add_host(test_host)

    test_inventory = Inventory()
    test_inventory.add_group

# Generated at 2022-06-23 13:06:05.158869
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(None)
    assert a._host_pinned == True

# Generated at 2022-06-23 13:06:07.347560
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule(tqm)
    assert mod._host_pinned == True

# Generated at 2022-06-23 13:06:07.939400
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-23 13:06:09.761044
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned

# Generated at 2022-06-23 13:06:12.227172
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm=None
    strategy=StrategyModule(tqm)
    # print (type(strategy))
    assert (strategy._host_pinned)

# Generated at 2022-06-23 13:06:16.311258
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.parsing.yaml.objects import AnsibleUnicode

    tqm = AnsibleUnicode('tqm')
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:06:19.656141
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "tqm"
    sm = StrategyModule(tqm)
    assert sm._tqm == tqm
    assert sm._host_pinned == True


# Generated at 2022-06-23 13:06:20.522399
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm = "foo")

# Generated at 2022-06-23 13:06:21.516696
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  StrategyModule()
  # obj = StrategyModule()

# Generated at 2022-06-23 13:06:23.589316
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-23 13:06:24.775561
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)



# Generated at 2022-06-23 13:06:25.860332
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm

# Generated at 2022-06-23 13:06:28.346463
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = StrategyModule(tqm='tqm')
    assert tqm._host_pinned

# Generated at 2022-06-23 13:06:36.541790
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"

# Generated at 2022-06-23 13:06:40.087341
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    a = ansible.plugins.strategy.host_pinned.StrategyModule(tqm=None)
    if isinstance(a, object) is False:
        raise AssertionError('Error while instantiating StrategyModule()')

# Generated at 2022-06-23 13:06:40.984530
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(StrategyModule)
    StrategyModule

# Generated at 2022-06-23 13:06:43.713249
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    some_tqm = 'the queue manager'
    strategy = StrategyModule(some_tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:06:45.858212
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule(tqm='tqm')


# Generated at 2022-06-23 13:06:48.391790
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a mock TQM
    obj_tqm = test_utils.MockTQM()
    # Call the constructor
    obj_strategy = StrategyModule(obj_tqm)
    # Check the results
    assert obj_strategy is not None
    assert obj_strategy._host_pinned == True

# Generated at 2022-06-23 13:06:50.359910
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MagicMock()
    strategy_module = StrategyModule(tqm)
    assert strategy_module

# unit test for function choose_host_queue

# Generated at 2022-06-23 13:06:51.093774
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:06:54.650919
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)
    assert isinstance(strategy, StrategyModule)
    assert isinstance(strategy, FreeStrategyModule)


# Test the behavior of a serial strategy

# Generated at 2022-06-23 13:06:57.280327
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    data = dict(foo = 'bar')
    tqm = type('tqm', (object,), data)()
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:07:05.604097
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager

    class Bunch(object):
        def __init__(self, adict):
            self.__dict__.update(adict)


# Generated at 2022-06-23 13:07:08.728113
# Unit test for constructor of class StrategyModule
def test_StrategyModule():  # noqa
    tqm = mock.MagicMock()
    a = StrategyModule(tqm)
    assert a._host_pinned() == True

# Generated at 2022-06-23 13:07:19.440564
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestData:
        class TestTQM:
            class TestOptions:
                serial = 2

        test_tqm = TestTQM()
        test_tqm.options = TestOptions()
        test_sm = StrategyModule(test_tqm)
        assert test_sm._host_pinned
        test_sm.display = display

    # Test with all defaults
    test_data = TestData()
    test_data.test_sm._initialize_processes(3)
    test_data.test_sm._start_new_batch(test_data.test_tqm.options.serial)
    test_data.test_sm._print_batch_time(3)
    test_data.test_sm._wait_on_pending_results(test_data.test_tqm, False)


# Generated at 2022-06-23 13:07:21.419582
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert isinstance(strategy_module._host_pinned, bool)


# Generated at 2022-06-23 13:07:28.097152
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """This is a test for the constructor method of the StrategyModule class"""
    # Test 1: Invalid task manager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.vars import AnsibleVars
    display = Display()
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
    )
    free_strategy = FreeStrategyModule(tqm)
    assert free_strategy is not None
    # Test 2: Valid task manager
    vars_manager = AnsibleVars(loader=None, hash_behaviour='replace')
    vars_manager.extra

# Generated at 2022-06-23 13:07:36.930457
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    
    from ansible.plugin import strategy_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host, Group
    from ansible.playbook.play import Play

    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-23 13:07:37.905084
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None) is not None

# Generated at 2022-06-23 13:07:38.364201
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-23 13:07:44.655217
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import os
    import ansible.plugins.strategy

    # Assert that the strategy is loaded
    assert 'host_pinned' in ansible.plugins.strategy.STRATEGIES

    # Assert that the correct strategy is loaded
    assert ansible.plugins.strategy.STRATEGIES['host_pinned'] == StrategyModule

    tqm = None
    strategy = StrategyModule(tqm)

    # Assert that the underlying strategy is Host Pinned
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:07:47.408254
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Tqm(object):
        host_pinned = True

    s = StrategyModule(Tqm)
    assert s._host_pinned == True
    assert s._current_serial_info == {}

# Generated at 2022-06-23 13:07:49.153336
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global display
    display = Display()
    assert StrategyModule(display).__class__ is StrategyModule

# Generated at 2022-06-23 13:07:49.761954
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:07:52.155009
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("taskqueue_manager")
    result = strategy_module._host_pinned
    assert result == True

# Generated at 2022-06-23 13:07:53.726352
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(1)
    assert a._host_pinned is True

# Generated at 2022-06-23 13:07:54.345815
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:07:54.950403
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule != None

# Generated at 2022-06-23 13:07:55.710405
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:07:59.282190
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class _task_queue_manager:
        def __init__(self):
            self.display = Display()

    tqm = _task_queue_manager()
    strategy = StrategyModule(tqm)
    assert isinstance(strategy, StrategyModule)

# Generated at 2022-06-23 13:08:00.801383
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None, None)
    assert sm._host_pinned

# Generated at 2022-06-23 13:08:02.223155
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'



# Generated at 2022-06-23 13:08:03.130745
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule(tqm)

# Generated at 2022-06-23 13:08:04.521713
# Unit test for constructor of class StrategyModule
def test_StrategyModule():    
    stm = StrategyModule(None)
    assert stm is not None

# Generated at 2022-06-23 13:08:07.930447
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.listify import listify_lookup_plugin_terms

    terms = listify_lookup_plugin_terms('', [], [])
    display = Display()
    tqm = terms + display

    module = StrategyModule(tqm)

    assert module is not None

# Generated at 2022-06-23 13:08:14.718950
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True
    assert strategy.tqm == None
    assert strategy._blocked_hosts == None
    assert strategy._send_vars == None
    assert strategy._pending_results == None
    assert strategy._workers == None
    assert strategy._stats == None
    assert strategy._display == None


# Generated at 2022-06-23 13:08:15.339347
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule()

# Generated at 2022-06-23 13:08:17.388493
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)

# Generated at 2022-06-23 13:08:22.038205
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        # Test with wrong parameter
        StrategyModule("tqm")
    except:
        pass
    # Test with good parameter
    test_strategy_module = StrategyModule(42)
    assert test_strategy_module is not None
# End of unit test for constructor of class StrategyModule


# Generated at 2022-06-23 13:08:25.297078
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display_ = Display()
    display_.verbosity = 2
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:08:26.803683
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule('testtqm')

    assert sm._host_pinned == True

# Generated at 2022-06-23 13:08:31.545009
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule(tqm=None)
    assert repr(x) == '<ansible.plugins.strategy.host_pinned.StrategyModule object at 0x7f5c5b5a5b50>'
    assert x._host_pinned
    assert x._last_play

# Generated at 2022-06-23 13:08:33.104704
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule.__name__ == "StrategyModule")

# Generated at 2022-06-23 13:08:34.556813
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:08:35.761681
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)

# Generated at 2022-06-23 13:08:37.340476
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)
    assert True

# Generated at 2022-06-23 13:08:38.526770
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert ' module ' in StrategyModule.__doc__

# Generated at 2022-06-23 13:08:39.448236
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert False, "Require test for StrategyModule()"

# Generated at 2022-06-23 13:08:50.883445
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import collections
    import Queue
    import ansible.plugins.loader as plugins
    import ansible.playbook.role.definition as role_defs

    loader = plugins.PluginLoader(
        'strategy',
        'free',
        'strategy_plugins',
        'strategy_free',
        'free_strategy_module'
    )

    # object to store global variables for test
    mock_tqm = collections.namedtuple('mock_tqm', ['shared_loader_obj', 'inventory', 'variable_manager',
                                                   'loader', 'options', 'passwords',
                                                   'stdout_callback', 'stats', 'failed_hosts',
                                                   'run_handlers', 'run_tasks', 'callback_loader'])

    # test constructor with required parameters
    mock_t

# Generated at 2022-06-23 13:08:51.617669
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:08:53.972354
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MagicMock()
    strategyModule = StrategyModule(tqm)
    assert strategyModule._host_pinned == True

# Generated at 2022-06-23 13:08:57.751766
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class_instance = StrategyModule('tqm')
    assert hasattr(class_instance, '_host_pinned')
    assert class_instance._host_pinned == True
    

# Generated at 2022-06-23 13:08:59.913761
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)
    _StrategyModule = StrategyModule()
    assert isinstance(_StrategyModule, StrategyModule)

# Generated at 2022-06-23 13:09:01.448019
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(1)
    assert sm._host_pinned is True

# Generated at 2022-06-23 13:09:02.084917
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-23 13:09:04.120998
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    name = "name"
    obj = StrategyModule(name)
    assert obj._host_pinned

# Generated at 2022-06-23 13:09:05.763141
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned

# Generated at 2022-06-23 13:09:10.989083
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    tqm = TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        options=options,
        passwords=passwords,
        stdout_callback=results_callback,
    )
    sm = StrategyModule(tqm)
    assert sm._host_pinned is True

# Generated at 2022-06-23 13:09:17.441629
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\n#### In host_pinned.py, testing variable display of class StrategyModule ####\n")
    StrategyModule.__init__(StrategyModule, tqm)
    print(StrategyModule)

    print("Passing variable tqm through constructor of class StrategyModule")
    print("\n#### End In host_pinned.py, testing variable display of class StrategyModule ####\n")


if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-23 13:09:18.727940
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy=StrategyModule()
    

# Generated at 2022-06-23 13:09:20.812538
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    assert obj != None

# Generated at 2022-06-23 13:09:24.104473
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    d = Display()
    assert(d is not None)

# Here is where the bulk of logic should reside.
# This is a stub class to work around Ansible being
# an incredibly ugly code base.

# Generated at 2022-06-23 13:09:25.313982
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm = 1)

# Generated at 2022-06-23 13:09:34.883684
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=DataLoader(), sources='localhost,'),
        variable_manager=VariableManager(),
        loader=DataLoader(),
    )
    strategy = StrategyModule(tqm)
    assert isinstance(strategy, StrategyModule)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:09:35.931264
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:09:36.966296
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule('test')
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:09:44.177492
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:09:49.371964
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Stub to create a class object StrategyModule
    class SubStrategyModule(StrategyModule):
        def __init__(self, tqm):
            super(StrategyModule, self).__init__(tqm)
            self._host_pinned = True

    # Call constructor __init__(self, tqm)
    sub_strategy = SubStrategyModule()
    assert sub_strategy._host_pinned

# Generated at 2022-06-23 13:09:52.027779
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == FreeStrategyModule.__doc__
    assert StrategyModule.__init__.__doc__ == FreeStrategyModule.__init__.__doc__

# Generated at 2022-06-23 13:09:53.187531
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:09:57.398323
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.utils.display import Display
    from ansible.plugins.strategy.host_pinned import StrategyModule
    display = Display()
    sm = StrategyModule(display)
    # Test for Host_pinned valus
    assert sm._host_pinned

# Generated at 2022-06-23 13:09:58.690903
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    assert StrategyModule
    assert StrategyModule

# Generated at 2022-06-23 13:10:00.195910
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    t = StrategyModule(None)
    assert t



# Generated at 2022-06-23 13:10:02.647956
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert(strategy_module._host_pinned == True)

# Generated at 2022-06-23 13:10:06.709694
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    import ansible.plugins.strategy.host_pinned
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy.host_pinned import FreeStrategyModule

    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-23 13:10:08.498473
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    assert StrategyModule

# Generated at 2022-06-23 13:10:18.614752
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    from ansible.plugins.strategy.host_pinned import StrategyModule as HostPinnedStrategyModule
    from ansible.plugins.strategy.host_pinned import __doc__ as HostPinnedStrategyModule_doc
    class TestStrategyModule(unittest.TestCase):
        def setUp(self):
            # self.assertEqual(HostPinnedStrategyModule.__doc__, HostPinnedStrategyModule_doc)
            self.strategy_module_args = {
                "tqm": None,
            }
            self.strategy_module = HostPinnedStrategyModule(**self.strategy_module_args)

# Generated at 2022-06-23 13:10:21.310219
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    tqm = StrategyModule(None)
    assert tqm.get_host_pinned() is False

# Generated at 2022-06-23 13:10:21.917577
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:10:24.484803
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test StrategyModule")
    p = StrategyModule()
    assert (p != None)
    assert (str(type(p)) == "<class 'ansible.plugins.strategy.host_pinned.StrategyModule'>")



# Generated at 2022-06-23 13:10:25.675464
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:10:27.821850
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule("tqm")
    assert obj._host_pinned is True

# Generated at 2022-06-23 13:10:30.589041
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)
    assert isinstance(strategy, FreeStrategyModule)
    assert strategy._host_pinned is True

# Generated at 2022-06-23 13:10:39.921926
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    s = ansible.plugins.strategy.host_pinned.StrategyModule(None)
    assert isinstance(s, ansible.plugins.strategy.host_pinned.StrategyModule), "StrategyModule is not instance of ansible.plugins.strategy.host_pinned.StrategyModule"
    assert isinstance(s, ansible.plugins.strategy.free.StrategyModule), "StrategyModule is not instance of ansible.plugins.strategy.free.StrategyModule"
    assert s._host_pinned == True, "StrategyModule._host_pinned is not True"

# Generated at 2022-06-23 13:10:42.435522
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_StrategyModule = StrategyModule(tqm)
    assert test_StrategyModule._host_pinned == True


# Generated at 2022-06-23 13:10:43.567500
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:10:44.624952
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm="tqm")


# Generated at 2022-06-23 13:10:45.652575
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  return StrategyModule

# Generated at 2022-06-23 13:10:47.206638
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {u'example': [u'example']}
    StrategyModule(tqm)

# Generated at 2022-06-23 13:10:47.822171
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:10:49.264845
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy is not None


# Generated at 2022-06-23 13:10:53.860521
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class MockTQM(object):
        pass
    tqm = MockTQM()
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned is True

# Generated at 2022-06-23 13:10:54.471104
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:10:55.576691
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-23 13:10:56.495867
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:10:57.850775
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:11:00.842071
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule
    StrategyModule(tqm)


# Generated at 2022-06-23 13:11:02.342686
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-23 13:11:03.987945
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)

# Generated at 2022-06-23 13:11:05.286311
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None

# Generated at 2022-06-23 13:11:07.600536
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule(None)
    assert strategyModule is not None
    assert strategyModule._host_pinned == True

# Generated at 2022-06-23 13:11:17.223567
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Testing instantiation of StrategyModule
    try:
        from ansible.playbook.play_context import PlayContext
        from ansible.runner.task_result import TaskResult
        from ansible.inventory.host import Host
        from ansible.inventory.group import Group
        # Instantiation of tqm object
        __tqm = TaskQueueManager(
            inventory=Inventory(host_list=['localhost']),
            variable_manager=VariableManager(),
            loader=DataLoader(),
            options=Options(),
            passwords=None,
            stdout_callback="default",
        )
        # Installation of StrategyModule object
        __StrategyModule__ = StrategyModule(__tqm)
    except:
        return False
    # Testing instantiation of FreeStrategyModule object

# Generated at 2022-06-23 13:11:23.288738
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Unit: test_StrategyModule() -> test the constructor of class StrategyModule

    :return: 
    """
    # tqm = TaskQueueManager()
    strategy_instance = StrategyModule(None)

    assert isinstance(strategy_instance, StrategyModule)
    assert strategy_instance._host_pinned is True


# Generated at 2022-06-23 13:11:24.921778
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    assert isinstance(display, Display)

# Generated at 2022-06-23 13:11:26.313870
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-23 13:11:27.119186
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:11:32.363007
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor import task_queue_manager

    tqm = task_queue_manager.TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None,
    )
    StrategyModule(tqm)

# Generated at 2022-06-23 13:11:35.115527
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule("tqm")
    assert module._host_pinned is True

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-23 13:11:36.281627
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__('self')

# Generated at 2022-06-23 13:11:37.514326
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)

# Generated at 2022-06-23 13:11:44.305194
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    strategy = ansible.plugins.strategy.host_pinned.StrategyModule
    assert issubclass(strategy, FreeStrategyModule), "Inheritance check"
    assert strategy.__name__ == 'StrategyModule', "Name check"
    assert strategy.__module__ == __name__, "Module check"

# Generated at 2022-06-23 13:11:53.269809
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.task.debug import ActionModule as DebugActionModule
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host as CliHost

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='''host_list:
host1 ansible_connection=local
host2 ansible_connection=local
host3 ansible_connection=local''')

# Generated at 2022-06-23 13:11:55.800334
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm=None)
    assert s._host_pinned is True

# Generated at 2022-06-23 13:12:03.404810
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True
    assert strategy._current_serialized_batch == []
    assert strategy._current_serial_index == 0
    assert strategy._serial_tasks_count == 0
    assert strategy._display == display
    assert strategy._tqm == tqm
    assert strategy._batch_size == 1
    assert strategy._iterating_players == {}
    assert strategy._play_is_serialized == False
