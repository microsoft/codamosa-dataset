

# Generated at 2022-06-23 13:02:04.819698
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule('test')
    assert module._host_pinned is True

# Generated at 2022-06-23 13:02:07.120639
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ''
    strategy_object = StrategyModule(tqm)
    assert strategy_object._host_pinned == True

# Generated at 2022-06-23 13:02:08.660902
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule({})
    assert module._host_pinned

# Generated at 2022-06-23 13:02:09.478692
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:02:10.286437
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None) is not None

# Generated at 2022-06-23 13:02:11.461565
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:02:13.429865
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True, "StrategyModule should have been True"

# Generated at 2022-06-23 13:02:18.114477
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global display
    display = Display()
    s = StrategyModule(None)
    if isinstance(s, StrategyModule):
        assert(true)
        assert(isinstance(s, FreeStrategyModule))
    else:
        assert(false)

# Generated at 2022-06-23 13:02:20.541187
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  assert isinstance(FreeStrategyModule, object)
  assert issubclass(StrategyModule, FreeStrategyModule)
  strategy = StrategyModule(tqm='tqm')
  assert isinstance(strategy, StrategyModule)

# Generated at 2022-06-23 13:02:23.934888
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule) and \
            "Host pinned" in StrategyModule.DOCUMENTATION

# Generated at 2022-06-23 13:02:25.567017
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(),"StrategyModule constructor failed"


# Generated at 2022-06-23 13:02:27.482026
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule(None)
    assert isinstance(tqm, FreeStrategyModule)

# Generated at 2022-06-23 13:02:29.619188
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    obj=StrategyModule(None)

# Generated at 2022-06-23 13:02:32.353478
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    TASK_QUEUE_MANAGER = None #TODO - fix this!
    TEST_STRATEGY = StrategyModule(TASK_QUEUE_MANAGER)
    assert TEST_STRATEGY._host_pinned == True

# Generated at 2022-06-23 13:02:38.254531
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = {'host': "test_host", 'port': 22, 'variables': {'ansible_user': "user_test"}}
    tqm = {'hosts': [host], 'pattern': 'all', 'forks': 10}
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned

# Generated at 2022-06-23 13:02:40.741670
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule
    assert sm.__name__=="StrategyModule"



# Generated at 2022-06-23 13:02:42.745954
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm = None)
    assert(s._host_pinned)

# Generated at 2022-06-23 13:02:44.388770
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: write unit test for class StrategyModule
    assert True

# Generated at 2022-06-23 13:02:46.231020
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '__init__')

# Generated at 2022-06-23 13:02:49.015177
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = Mock()
    sm = StrategyModule(test_tqm)
    assert sm._host_pinned



# Generated at 2022-06-23 13:02:50.654917
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None) is not None


# Unit tests for class StrategyModule methods

# Generated at 2022-06-23 13:02:51.753006
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None

# Generated at 2022-06-23 13:02:53.039617
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:02:55.120094
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    s = StrategyModule(tqm = None)
    assert s._host_pinned == True

# Generated at 2022-06-23 13:02:57.186091
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule("tqm")
    assert hasattr(strategy, '_host_pinned')
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:02:59.449680
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__ is not FreeStrategyModule.__init__

# Generated at 2022-06-23 13:03:07.778306
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-23 13:03:18.128219
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from tests.unit.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    # tasks: initialize variables and options
    variable_manager = VariableManager()
    loader = DictDataLoader({})

    inventory = InventoryManager(loader=loader, sources=['127.0.0.1'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-23 13:03:21.237412
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    sm = StrategyModule(tqm)
    assert sm.tqm == tqm
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:03:22.187059
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)._host_pinned == True

# Generated at 2022-06-23 13:03:23.080529
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:03:28.083043
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = dict()
    tqm['_workers'] = 1
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True
    assert strategy._display.verbosity == 3
    assert strategy._tqm['_workers'] == 1
    assert strategy._serial == None

# Generated at 2022-06-23 13:03:30.777831
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule.__init__")
    assert StrategyModule(None)._host_pinned == True

# Generated at 2022-06-23 13:03:31.635548
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:03:32.246611
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:03:37.544430
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from collections import namedtuple
    from ansible.executor.task_queue_manager import TaskQueueManager

    tqm = TaskQueueManager(None, None)
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned, "expected _host_pinned=True"

# Generated at 2022-06-23 13:03:38.126419
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:03:40.709122
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ Create an instance of Strategy Module """
    test_strategy_obj = StrategyModule(None)
    assert test_strategy_obj is not None, "Strategy Module instance creation failed"
    return True

# Generated at 2022-06-23 13:03:42.878089
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = mock.MagicMock()
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:03:45.501244
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule(tqm = None)
    StrategyModule(tqm)

# Generated at 2022-06-23 13:03:47.103183
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:03:49.089278
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    #to do: detail tests for StrategyModule class


# Generated at 2022-06-23 13:03:49.657038
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:03:50.962547
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:03:52.360415
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm) is not None

# Generated at 2022-06-23 13:03:55.194382
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule), \
        "Class 'StrategyModule' should be a subclass of class 'FreeStrategyModule'"

# Generated at 2022-06-23 13:03:55.930713
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:03:59.435297
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.free import Tqm
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(display, None).executor

    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:04:01.297819
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  module = StrategyModule(tqm = None)
  assert module is not None

  assert module._host_pinned == True

# Generated at 2022-06-23 13:04:02.774334
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule('')
    assert s._host_pinned is True

# Generated at 2022-06-23 13:04:06.505564
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm_mock = MagicMock()
    strategy = StrategyModule(tqm_mock)
    assert strategy is not None
    assert strategy._host_pinned == True
    assert strategy.tqm == tqm_mock

# Generated at 2022-06-23 13:04:08.509115
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:04:10.453281
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = None
  sm = StrategyModule(tqm)
  assert sm._host_pinned == True

# Generated at 2022-06-23 13:04:11.325946
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:04:13.710331
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:04:15.848962
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
        print("Testing constructor of class StrategyModule")
        tqm=StrategyModule('tqm')
        assert tqm is not None

# Generated at 2022-06-23 13:04:25.688887
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("********** test_StrategyModule *************")
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    
    class TaskQueueManagerMock(TaskQueueManager):
        def __init__(self, inventory, variable_manager, loader, display, options, passwords, stdout_callback=None):
            super(TaskQueueManagerMock, self).__init__(inventory, variable_manager, loader, display, options, passwords, stdout_callback)
            self.Tray = TrayMock()
    

# Generated at 2022-06-23 13:04:27.085364
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(True)

# End of unit test 


# Generated at 2022-06-23 13:04:34.146349
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest

    class Mytest(unittest.TestCase):
        def test_strategy_module(self):
            class MockTqm:
                pass
            tqm = MockTqm()
            strategy_module = StrategyModule(tqm)
            assert strategy_module.__class__.__name__ == 'StrategyModule'
            assert strategy_module._host_pinned == True
    mytest = Mytest()
    mytest.test_strategy_module()

# Generated at 2022-06-23 13:04:35.218389
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-23 13:04:37.681447
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = True
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True


# Generated at 2022-06-23 13:04:40.425845
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_obj = StrategyModule()
    if strategy_module_obj._host_pinned != True:
        raise Exception("StrategyModule not constructed properly.")

# Generated at 2022-06-23 13:04:42.372239
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    h = StrategyModule(tqm=42)
    assert h._host_pinned == True

# Generated at 2022-06-23 13:04:44.618848
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm = None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:04:45.040516
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  t = StrategyModule()

# Generated at 2022-06-23 13:04:46.259229
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm)


# Generated at 2022-06-23 13:04:46.993838
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:04:48.659315
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strat = StrategyModule(tqm)

# Generated at 2022-06-23 13:04:51.587137
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    class TQM:
        hosts = None

        class Inventory:
            host_dict = {}

    tqm = TQM()

    strategy_module = StrategyModule(tqm)

    assert strategy_module

# Generated at 2022-06-23 13:04:53.128508
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    StrategyModule(tqm)

# Generated at 2022-06-23 13:05:03.720527
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import context
    from ansible.executor.task_queue_manager import TaskQueueManager


# Generated at 2022-06-23 13:05:05.823758
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    data = '{"name": "test", "description": "test", "short_description": "test"}'
    data = json.loads(data)
    tqm = TaskQueueManager(data)
    strategy_object = StrategyModule(tqm)
    assert strategy_object._host_pinned == True

# Generated at 2022-06-23 13:05:08.642815
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = True
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned is True

# Generated at 2022-06-23 13:05:10.124990
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__
    assert True


# Generated at 2022-06-23 13:05:10.802515
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:05:12.497796
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:05:15.972536
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create instance of class StrategyModule
    module = StrategyModule('tqm')

    # Assertion: Assert that the value of _host_pinned attribut.
    assert module._host_pinned is True

# Generated at 2022-06-23 13:05:17.390042
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule("test")
    assert obj.tqm == "test"
    assert obj._host_pinned == True

# Generated at 2022-06-23 13:05:18.825953
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule('tqm')
    assert obj._host_pinned is True


# Generated at 2022-06-23 13:05:21.145030
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    strategy_module_instance = StrategyModule(tqm)
    assert strategy_module_instance._host_pinned == True

# Generated at 2022-06-23 13:05:24.717883
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    def ret_tqm():
        return ""
    
    tqm = ret_tqm()

    check = StrategyModule(tqm)

    assert(check._host_pinned == True)
    assert(check._tqm.__str__() == "")

# Generated at 2022-06-23 13:05:26.606901
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule(None)
    assert x._host_pinned == True, '_host_pinned value should be True'

# Generated at 2022-06-23 13:05:27.142152
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  assert True

# Generated at 2022-06-23 13:05:28.239587
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule("tqm")
    assert s._host_pinned is True

# Generated at 2022-06-23 13:05:29.626288
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)


# Test for TaskExecutor

# Generated at 2022-06-23 13:05:30.838364
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__(StrategyModule, tqm) == None

# Generated at 2022-06-23 13:05:31.714926
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None

# Generated at 2022-06-23 13:05:32.857265
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  StrategyModule( tqm = 'test' )


# Generated at 2022-06-23 13:05:34.576220
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  assert StrategyModule.get_name() == 'host_pinned'

# Generated at 2022-06-23 13:05:36.974291
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tm = StrategyModule(None)
    assert tm._host_pinned == True

# ====== END OF TEST ====================================================================

# Generated at 2022-06-23 13:05:42.976308
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "TEST_TQM"
    strategy = StrategyModule(tqm)
    assert strategy.name == 'host_pinned'
    assert strategy.get_host_list() == strategy.get_original_host_list()
    assert strategy.check_tqm_enough_hosts() == True


# Generated at 2022-06-23 13:05:46.418274
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.loader import strategy_loader
    strategy_loader.add('host_pinned', StrategyModule)
    assert strategy_loader._strategy_plugins['host_pinned']

# Generated at 2022-06-23 13:05:49.600494
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    strategy_module = StrategyModule(None)
    assert type(strategy_module) == StrategyModule
    assert strategy_module._host_pinned == True

# Tests for class StrategyModule

# Generated at 2022-06-23 13:05:52.861941
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    stm = StrategyModule(tqm=None)
    assert('_host_pinned' in stm.__dict__)
    assert stm._host_pinned

# Generated at 2022-06-23 13:05:56.911042
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class tqm:
        def __getattr__(self, name):
            return tqm
        def __call__(self, *args, **kwargs):
            return tqm
    class tqm_iterator:
        def __init__(self, name, d):
            self.name = name
            self.d = d
        def __iter__(self):
            return self
        def __next__(self):
            # FIXME: Improve this
            k = list(self.d.keys())[0]
            v = self.d[k]
            del self.d[k]
            return v
    class tqm_variables:
        def __init__(self, name):
            self.name = name
        def __getitem__(self, key):
            return self.name

# Generated at 2022-06-23 13:05:57.552578
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()

# Generated at 2022-06-23 13:05:59.318448
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned



# Generated at 2022-06-23 13:06:01.797624
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(0)
    print(sm._host_pinned)

test_StrategyModule()

# Generated at 2022-06-23 13:06:04.049751
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    result = StrategyModule(tqm)
    assert result._host_pinned == True


# Generated at 2022-06-23 13:06:07.195118
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strat_obj = StrategyModule(None)
    assert strat_obj._host_pinned == True

# Generated at 2022-06-23 13:06:17.783141
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.errors import AnsibleError
    from ansible.parsing.dataloader import DataLoader

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    loader = DataLoader()

# Generated at 2022-06-23 13:06:19.657582
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert True

# Generated at 2022-06-23 13:06:21.994556
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    assert obj._host_pinned is True
    assert obj._tqm is None
    assert obj.display is not None
    assert obj.tqm is None
    assert obj._name == 'host_pinned'

# Generated at 2022-06-23 13:06:23.704786
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()
    assert s._host_pinned




# Generated at 2022-06-23 13:06:24.812406
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    assert StrategyModule(tqm) is not None

# Generated at 2022-06-23 13:06:25.914861
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned = StrategyModule()

# Generated at 2022-06-23 13:06:28.837483
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {'tqm': 1}
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned

# Generated at 2022-06-23 13:06:38.843939
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import imp
    import sys
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    sys.argv = ["ansible-playbook","test_StrategyModule.yml"]
    loader = DataLoader()
    options = None
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, host_list='/etc/ansible/hosts')
    variable_manager.set_inventory(inventory)
    passwords = dict()

# Generated at 2022-06-23 13:06:40.303130
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    inst = StrategyModule(tqm)
    assert inst._host_pinned

# Generated at 2022-06-23 13:06:40.855201
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-23 13:06:41.859524
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm)

# Generated at 2022-06-23 13:06:43.759955
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:06:44.942265
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:06:45.363092
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule('')

# Generated at 2022-06-23 13:06:48.413647
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy_module = StrategyModule(tqm)
    assert(strategy_module._host_pinned is True)
    assert(strategy_module.name == 'host_pinned')

# Generated at 2022-06-23 13:06:51.911751
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("*** test_StrategyModule() ***")
    tqm = object
    strategy = StrategyModule(tqm)
    assert isinstance(strategy, StrategyModule)
    print("StrategyModule unit test ok")

# Unit test main
if __name__ == '__main__':
    test_StrategyModule()
    print("*** StrategyModule unit tests done ***")

# Generated at 2022-06-23 13:06:54.596601
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm) == super(StrategyModule, StrategyModule(tqm)).__init__(tqm)

# Generated at 2022-06-23 13:06:58.798759
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned.StrategyModule

    test_tqm = None
    strategy = ansible.plugins.strategy.host_pinned.StrategyModule.StrategyModule(test_tqm)

    assert(strategy._host_pinned == True)

# Generated at 2022-06-23 13:06:59.934743
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('tqm')

# Generated at 2022-06-23 13:07:00.434306
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:07:01.450057
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #host_pinned
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-23 13:07:09.263039
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    from ansible.executor.task_queue_manager import TaskQueueManager

    class TestTaskQueueManager(TaskQueueManager):
        """
        Class for unit testing.
        """
        pass

    tqm = TestTaskQueueManager('test_host')
    strategy = StrategyModule(tqm)

    assert strategy._host_pinned


# Run with `python -m ansible.plugins.strategy.pinned`

# Generated at 2022-06-23 13:07:11.078133
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    assert FreeStrategyModule
    assert StrategyModule.__mro__ == (StrategyModule, FreeStrategyModule, object)


# Generated at 2022-06-23 13:07:18.205295
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.playbook.task_queue_manager import TaskQueueManager
    from ansible.utils.display import Display
    strategy_module=StrategyModule(tqm=TaskQueueManager())
    assert strategy_module._host_pinned == True
    assert strategy_module._tqm == TaskQueueManager
    assert strategy_module._display == Display
    assert strategy_module._inventory == None
    assert strategy_module._variable_manager == None

# Generated at 2022-06-23 13:07:19.599199
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert (strategy_module._host_pinned == True)

# Generated at 2022-06-23 13:07:20.149306
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:07:23.074222
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule('')
    assert isinstance(strategy, StrategyModule)
    assert isinstance(strategy, FreeStrategyModule)
    assert strategy._host_pinned is True
    assert strategy.tqm is ''

# Generated at 2022-06-23 13:07:23.922103
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   assert class_test()._host_pinned == True

# Generated at 2022-06-23 13:07:27.124624
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'

# Generated at 2022-06-23 13:07:28.730048
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    S = StrategyModule('tqm')
    assert S._host_pinned

# Generated at 2022-06-23 13:07:31.332724
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule
    sm = StrategyModule(tqm)
    assert sm.__class__.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:07:41.378940
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # setup test env
    import ansible.constants as C
    import ansible.utils.connection as connection
    saved_ansible_connection = C.ANSIBLE_CONNECTION
    saved_ansible_connetion_plugins = C.DEFAULT_CONNECTION_PLUGIN_PATH
    saved_ansible_python_interpreter = C.DEFAULT_PYTHON_INTERPRETER
    saved_ansible_ssh_executable = C.DEFAULT_EXECUTABLE
    saved_ansible_ssh_args = C.DEFAULT_ARGS
    saved_ansible_ssh_additional_args = C.DEFAULT_SSH_ADDITIONAL_ARGS
    saved_ansible_playbook_basedir = C.DEFAULT_BASEDIR
    saved_ansible_playbook_hostvars_based

# Generated at 2022-06-23 13:07:43.028836
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ != None
    assert StrategyModule.__module__ == "ansible.plugins.strategy.host_pinned"

# Generated at 2022-06-23 13:07:48.311611
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.utils.plugins import module_finder
    from ansible.executor.task_queue_manager import TaskQueueManager
    plugin = module_finder.get('strategy', 'host_pinned')
    plugin = plugin()
    assert isinstance(plugin, StrategyModule)
    assert isinstance(plugin._host_pinned, bool)

# Generated at 2022-06-23 13:07:48.935077
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:07:50.596441
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(tqm="TQM")
    assert a._host_pinned == True


# Generated at 2022-06-23 13:07:52.744306
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:07:53.342847
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(True)

# Generated at 2022-06-23 13:07:55.261284
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule(tqm=None)
    assert x._host_pinned == True

# Generated at 2022-06-23 13:07:56.442690
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 13:07:57.096906
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:08:03.397497
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# class StrategyModuleTestCase(unittest.TestCase):
#
#     def setUp(self):
#         self.strategy = StrategyModule()
#
#     def tearDown(self):
#         self.book = None
#
#     def test_StrategyModule(self):
#         pass
#
#         #self.assertRaises(TypeError, self.strategy.__init__)
#
# def test_suite():
#     from unittest import TestLoader
#     return TestLoader().loadTestsFromTestCase(StrategyModuleTestCase)
#
#

# Generated at 2022-06-23 13:08:04.774324
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert not StrategyModule.__init__.__self__



# Generated at 2022-06-23 13:08:05.313191
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:08:06.078947
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule._host_pinned == True

# Generated at 2022-06-23 13:08:07.957404
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = []
    StrategyModule(tqm)

# Generated at 2022-06-23 13:08:18.229721
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_my_tests = StrategyModule(tqm = [{'strategy_my_tests':'strategy_my_tests'}])
    assert strategy_my_tests._tqm == [{'strategy_my_tests':'strategy_my_tests'}]
    assert strategy_my_tests._processes == 5
    assert strategy_my_tests._priorities == {}
    assert strategy_my_tests._inventory == None
    assert strategy_my_tests._batch_size == 0
    assert strategy_my_tests._display == None
    assert strategy_my_tests._loader == None
    assert strategy_my_tests._variable_manager == None
    assert strategy_my_tests._all_vars == None
    assert strategy_my_tests._host_pinned == True


# Generated at 2022-06-23 13:08:19.852321
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  sm = StrategyModule(None)
  assert(type(sm) == StrategyModule)

# Generated at 2022-06-23 13:08:21.592125
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule('tqm')
    assert a is not None

# Generated at 2022-06-23 13:08:32.676858
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestStrategyModule(StrategyModule):
        pass

    import json
    import sys

    file_name = 'sample_inventory'
    base_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    inventory_file = os.path.join(base_dir, 'test/integration/inventory')
    print('inventory_dir: %s' % inventory_file)
    print(os.path.isfile(inventory_file))

    inventory_file_name = inventory_file + '/' + file_name

    print('opening JSON file %s' % (inventory_file_name))
    with open(inventory_file_name) as json_data:
        inventory_data = json.load(json_data)
        print(inventory_data)


# Generated at 2022-06-23 13:08:35.428495
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm="Test")
    assert obj

# Generated at 2022-06-23 13:08:37.024220
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # pylint: disable=line-too-long
    assert True

# Generated at 2022-06-23 13:08:42.845116
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Setup
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    from ansible.plugins.strategy import StrategyModule
    from ansible.utils.display import Display
    display = Display()
    tqm = "tqm"
    strategy = StrategyModule(tqm)

    # Exercise
    strategy._host_pinned = True

    # Verify
    assert(hasattr(strategy, "_host_pinned"))
    assert(strategy._host_pinned is True)
    assert(isinstance(strategy, StrategyModule))

# Generated at 2022-06-23 13:08:52.800029
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\nTesting constructor StrategyModule()")
    tqm = None
    sm = StrategyModule(tqm)
    print("Testing if __init__ sets tqm to None")
    print(sm._tqm is None)
    assert(sm._tqm is None)
    print("Testing if __init__ _host_pinned is True")
    print(sm._host_pinned)
    assert(sm._host_pinned is True)
    print("Testing if __init__ _blockers is empty")
    print(len(sm._blockers) == 0)
    assert(len(sm._blockers) == 0)
    print("Successfully tested StrategyModule constructor\n")


# Generated at 2022-06-23 13:08:56.549276
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    tqm = 1

    print(StrategyModule(tqm))
    print(StrategyModule._host_pinned)


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:09:02.237505
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    TQM = namedtuple('TQM', '_unreachable_hosts _failed_hosts callbacks hosts variables')
    tqm_obj = TQM(
        _unreachable_hosts=[],
        _failed_hosts=[],
        callbacks=None,
        hosts=None,
        variables={}
    )

    sm = StrategyModule(tqm_obj)
    assert sm._host_pinned

# Generated at 2022-06-23 13:09:04.705321
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"
    assert hasattr(StrategyModule, "__init__")


# Generated at 2022-06-23 13:09:08.544163
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {'_initial_errors' : '_initial_errors'}
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True



# Generated at 2022-06-23 13:09:11.400971
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    strategy_module = StrategyModule(None)
    assert strategy_module is not None
    assert strategy_module._host_pinned is True

# Generated at 2022-06-23 13:09:13.275026
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
     strategy = StrategyModule(tqm=None)
     assert isinstance(strategy, StrategyModule)

# Generated at 2022-06-23 13:09:15.439879
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)


# Generated at 2022-06-23 13:09:20.208251
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    t = 'test'
    ans = StrategyModule(t)
    assert ans._host_pinned == True
    assert ans.tqm == t
    assert ans._block_hosts == {}
    assert ans._pending_hosts == set([])

# Generated at 2022-06-23 13:09:20.927734
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:09:22.832988
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    ansible.plugins.strategy.host_pinned

# Generated at 2022-06-23 13:09:25.801611
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm)
    assert hasattr(strategy_module, 'tqm') == True
    del(strategy_module)

# Generated at 2022-06-23 13:09:30.729396
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print ("#########In Strategy Module class##########")
    tqm = "test_tqm"
    strategy_module = StrategyModule(tqm)
    assert strategy_module._tqm == "test_tqm"

# Generated at 2022-06-23 13:09:31.591987
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-23 13:09:33.484025
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    instance = StrategyModule(tqm)
    assert instance._host_pinned == True

# Generated at 2022-06-23 13:09:36.056828
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-23 13:09:36.538192
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:09:38.017302
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned

# Generated at 2022-06-23 13:09:40.304842
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    name = "host_pinned"
    tqm = "create and run task queue manager"
    assert StrategyModule(tqm) is not None

# Generated at 2022-06-23 13:09:42.314542
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None  # type: DictStrAny
    strategy = StrategyModule(tqm)


# Generated at 2022-06-23 13:09:44.295486
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = dict()
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:09:47.221864
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(None, None, None, None)
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:09:48.448347
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:09:56.663383
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from mock import Mock
    tqm = Mock()
    tqm.hostvars = {
        'localhost': {
            'ansible_all_ipv4_addresses': [],
            'ansible_all_ipv6_addresses': [],
        }
    }
    tqm.all_hosts = ['localhost']
    tqm.inventory.get_hosts.return_value = ['localhost']
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:09:59.469755
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global display
    sm = StrategyModule(display)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:10:02.076846
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(test_legacy_tqm_class)
    assert strategy_module._host_pinned


# Generated at 2022-06-23 13:10:04.068345
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule("tqm")
    assert x._host_pinned == True

# Generated at 2022-06-23 13:10:10.876548
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    hostname = 'localhost'
    port = 22
    username = 'ansible'
    password = 'ansible'
    strategy = StrategyModule()
    host = Host(hostname, port, username, password)
    tr = TaskResult(host, dict(contacted=dict(hostname=hostname, port=port, username=username, password=password)))
    assert strategy._hosts_left == strategy._inventory.get_hosts(pattern='all')
    strategy._tqm._stats.compute(tr, crash=True)
    assert strategy._hosts_left == strategy.pattern_labels_to_hosts


# Generated at 2022-06-23 13:10:12.306619
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tm = StrategyModule(None)
    assert tm is not None


# Generated at 2022-06-23 13:10:13.758489
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 13:10:24.161622
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import sys
    from ansible.utils.display import Display
    from ansible.plugins.strategy import get_strategy

    tqm = get_strategy('Free')

    # FIXME: This test cannot just trivially be ported over to unittests, since the constructor
    #        and all methods of the tqm object instantiated by get_strategy() are protected.
    #        Until that is fixed in Ansible, the test remains here.

    # StrategyModule.__init__(StrategyModule, tqm)
    sys.modules['__main__'].__dict__['_host_pinned'] = True
    # sys.modules['__main__'].__dict__['_hosts_waiting_on_others'] = []
    sys.modules['__main__'].__dict__['display'] = Display()

# Generated at 2022-06-23 13:10:26.330741
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ''
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned is True

# Generated at 2022-06-23 13:10:27.114039
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  assert True

# Generated at 2022-06-23 13:10:29.696119
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned = StrategyModule()
    assert host_pinned._host_pinned == True


# Generated at 2022-06-23 13:10:30.281584
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-23 13:10:32.413728
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-23 13:10:37.109680
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM:
        def __init__(self):
            self.options = ""
            self.inventory = ""

    tqm = TestTQM()
    strategy = StrategyModule(tqm)

    assert(strategy._host_pinned == True)

# Generated at 2022-06-23 13:10:39.945647
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tm = StrategyModule(None)
        if tm is not None:
            print("True")
    except:
        print("False")
test_StrategyModule()

# Generated at 2022-06-23 13:10:50.054713
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-23 13:10:53.600280
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    assert obj._host_pinned is True, '_host_pinned is incorrect'

# Generated at 2022-06-23 13:10:54.974220
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    m = StrategyModule(None)
    assert isinstance(m, StrategyModule)

# Generated at 2022-06-23 13:11:01.468315
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.strategy.host_pinned import StrategyModule as Host_pinnedStrategyModule
    tqm = StrategyModule(strategy='host_pinned'.split())
    assert isinstance(tqm, Host_pinnedStrategyModule)

# Generated at 2022-06-23 13:11:02.546247
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:11:05.668864
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test_tqm'
    x = StrategyModule(tqm)
    assert x._host_pinned == True


# Generated at 2022-06-23 13:11:06.962771
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule('tqm')

# Generated at 2022-06-23 13:11:08.987177
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    cls = StrategyModule(None)
    assert cls._host_pinned
    assert not cls._host_pinned

# Generated at 2022-06-23 13:11:10.897709
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test StrategyModule constructor
    assert StrategyModule(tqm='foo')

# Test checks for _host_pinned parameter

# Generated at 2022-06-23 13:11:12.190463
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert hasattr(strategy, '_host_pinned')

# Generated at 2022-06-23 13:11:13.540103
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    val = StrategyModule(None)
    assert val._host_pinned == True

# Generated at 2022-06-23 13:11:15.315198
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)._host_pinned
    assert StrategyModule(None) is not None

# Generated at 2022-06-23 13:11:17.002129
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm._host_pinned is True
    assert sm._tqm is None

# Generated at 2022-06-23 13:11:19.440011
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    strategy = StrategyModule(None)
    assert strategy._host_pinned == True

test_StrategyModule()

# Generated at 2022-06-23 13:11:23.209670
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == '''\
    StrategyModule class loads the necessary strategy plugins for executing tasks and delegating to other systems.
'''.replace('\n', '')


# Generated at 2022-06-23 13:11:25.802657
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    FreeStrategyModule(tqm="value1")
    StrategyModule(tqm="value1")

# Generated at 2022-06-23 13:11:27.057794
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-23 13:11:32.319048
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = "localhost"
    display = Display()
    variable_manager = None
    loader = None
    options = None
    passwords = None
    stdout_callback = None
    stats = None
    tqm = None
    StrategyModule(tqm, host, variable_manager, loader, options, passwords, stdout_callback, display, stats)

# Generated at 2022-06-23 13:11:34.591942
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    result = StrategyModule(tqm)
    assert result._host_pinned is True

# Generated at 2022-06-23 13:11:36.859809
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule(tqm)
    strategy = StrategyModule(tqm)
    assert strategy is not None


# Generated at 2022-06-23 13:11:38.680518
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-23 13:11:50.462074
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# # Unit test for __init__() of class StrategyModule
# def test_StrategyModule_init(mocker):
#     pass
#
# # Unit test for __init__() of class StrategyModule
# def test_StrategyModule_calculate_batch_size(mocker):
#     pass
#
# # Unit test for run() of class StrategyModule
# def test_StrategyModule_run(mocker):
#     pass
#
# # Unit test for get_host_list() of class StrategyModule
# def test_StrategyModule_get_host_list(mocker):
#     pass
#
# # Unit test for get_next_batch() of class StrategyModule
# def test_StrategyModule_get_next_batch(mocker):
#     pass
#
# # Unit test for get_failed_

# Generated at 2022-06-23 13:11:51.997115
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    StrategyModule(tqm)

# Generated at 2022-06-23 13:11:57.184263
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    assert StrategyModule(tqm)._host_pinned

# Unit test added as workaround for a pytest bug in pytest-4.4.0
# See: https://github.com/pytest-dev/pytest/issues/5377

# Generated at 2022-06-23 13:12:00.768261
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TaskQueueManager(None, None)
    strategymodule = StrategyModule(tqm)
    assert strategymodule.display == Display()
    assert strategymodule._host_pinned == True

# Generated at 2022-06-23 13:12:02.511378
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule(tqm = None)

# Generated at 2022-06-23 13:12:06.680998
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    a = ansible.plugins.strategy.host_pinned.StrategyModule(tqm='tqm')
    assert a is not None
