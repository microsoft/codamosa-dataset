

# Generated at 2022-06-23 13:02:06.274002
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Entering {}".format(__file__))
    class TQM(object):
        def __init__(self):
            self.inventory = None
            self.variable_manager = None
            self.loader = None
            self.options = None
            self.default_vars = None
            self.host_pinned = None

    tqm = TQM()
    strategy = StrategyModule(tqm)

    assert strategy._host_pinned
    assert strategy._tqm.host_pinned

    #print("Exiting {}".format(__file__))

# Generated at 2022-06-23 13:02:09.751103
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager()
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None

# Generated at 2022-06-23 13:02:10.299125
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:02:12.648382
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    StrategyModule(tqm)

# Generated at 2022-06-23 13:02:19.187344
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.tqm import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.plugins.loader import strategy_loader
    from ansible.playbook import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display
    from ansible.module_utils.common.collections import ImmutableDict
    display = Display()

# Generated at 2022-06-23 13:02:21.419413
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None
    assert StrategyModule.__init__ is not None

# Generated at 2022-06-23 13:02:25.886563
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.strategy.host_pinned import StrategyModule

    tqm = StrategyModule(tqm)
    assert tqm._host_pinned == True

# Generated at 2022-06-23 13:02:27.759117
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert isinstance(strategy_module, StrategyModule)


# Generated at 2022-06-23 13:02:28.915432
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('In test_StrategyModule')
    assert True == True

# Generated at 2022-06-23 13:02:30.460247
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert s is not None

# Generated at 2022-06-23 13:02:32.568943
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_object = StrategyModule(tqm)
    host_pinned = getattr(strategy_object, '_host_pinned', None)
    assert host_pinned == True

# Generated at 2022-06-23 13:02:34.023192
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  assert False

# Generated at 2022-06-23 13:02:42.110032
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    import ansible.plugins.strategy as strategy_plugins
    import ansible.plugins as plugins
    import ansible.plugins.loader as plugin_loader

    TASK_QUEUE_MANAGER = 'dummy'   # ansible.executor.task_queue_manager.TaskQueueManager
    STRATEGY = 'free'
    STRATEGY_PATH = plugins.action._get_strategy_path(STRATEGY)

    loader = plugin_loader.PluginLoader(
        strategy_plugins,
        'ansible.plugins.strategy',
        C.CONFIG_SECTION_STRATEGY,
        'strategy')

    plugin = plugin_loader.get(loader, STRATEGY)

# Generated at 2022-06-23 13:02:44.240727
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(tqm=None)
    assert a._host_pinned is True

# Generated at 2022-06-23 13:02:45.678324
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:02:48.415482
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Test(object):
        def __init__(self):
            self._host_pinned = True
    Test()


# Generated at 2022-06-23 13:02:50.802748
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #Arrange
    testobj = StrategyModule(None)

    #Assert
    assert testobj is not None
    assert testobj._host_pinned == True

# Generated at 2022-06-23 13:02:53.978109
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {"tqm": 1234}
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:03:01.319875
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print ('test constructor')
    strategymodule = StrategyModule(None)
    assert isinstance(strategymodule, StrategyModule)
    assert hasattr(strategymodule, 'tqm')
    assert hasattr(strategymodule, 'strategy')
    assert hasattr(strategymodule, 'name')
    assert isinstance(strategymodule, FreeStrategyModule)
    assert strategymodule.name == 'host_pinned'
    assert strategymodule.strategy == 'host_pinned'
    assert strategymodule.host_pinned

# Generated at 2022-06-23 13:03:04.167487
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MagicMock()
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned is True

# Generated at 2022-06-23 13:03:07.665253
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Test that the constructor of class StrategyModule is properly defined.
    """
    tqm = None
    o = StrategyModule(tqm)
    assert o.__class__.__name__ == 'StrategyModule'


# Generated at 2022-06-23 13:03:18.048745
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback="null",
    )

    play_context = PlayContext()
    play_context.network_os = 'default'
    play_context.remote_addr = None
    play_context.port = None
    play_context.remote_user = None
    play_context.password = None
    play_context.private_key_file = None
    play_context.connection = 'local'
    play_context.timeout = 10

# Generated at 2022-06-23 13:03:23.809057
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # mock class
    class TQM():
        _workers = 0
        def __init__(self):
            self.__dict__.update(self.__class__.__dict__)
    # test
    sm = StrategyModule(TQM())
    assert sm._host_pinned == True

if __name__ == '__main__':
    # execute unit tests
    test_StrategyModule()

# Generated at 2022-06-23 13:03:27.501757
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    tqm = None
    host_pinned = StrategyModule(tqm)
    assert host_pinned.__class__.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:03:28.451366
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result = StrategyModule()
    assert True

# Generated at 2022-06-23 13:03:34.371541
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # call the constructor of class StrategyModule
    tqm = 'StrategyModule'
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None

    # test the function of run
    for x in strategy_module.run():
        assert x is None

    assert strategy_module.get_host_pinned()

# Generated at 2022-06-23 13:03:41.242794
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import mock
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible import constants as C
    class TestTQM(object):
        def __init__(self):
            self.hostvars = dict()
            self.stats = dict()
            self.host_pinned = True
            self.options = C.config
            self.options = C.config
            self.serial = 1
    test_obj = StrategyModule(TestTQM())
    assert test_obj._host_pinned is True


# Generated at 2022-06-23 13:03:44.576546
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Test StrategyModule constructor
    '''
    taget = StrategyModule("test_tqm")
    assert taget
    return taget.run


# Generated at 2022-06-23 13:03:45.164095
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule(tqm))


# Generated at 2022-06-23 13:03:47.640398
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Test StrategyModule constructor')
    assert StrategyModule('tqm')
    print('Test StrategyModule constructor is passed')


# Generated at 2022-06-23 13:03:48.448240
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 13:03:50.065477
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from mock import MagicMock
    tmq = MagicMock()
    StrategyModule(tmq)

# Generated at 2022-06-23 13:03:51.441740
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__



# Generated at 2022-06-23 13:03:54.328657
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Check __init__() is working correctly
    from ansible.plugins.strategy.host_pinned import StrategyModule
    assert StrategyModule is not None

# Generated at 2022-06-23 13:03:55.877351
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: implement test for constructor of class StrategyModule
    assert True == True

# Generated at 2022-06-23 13:03:59.273298
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)
    assert StrategyModule.__name__ == "StrategyModule"
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''

# Generated at 2022-06-23 13:04:00.736192
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'




# Generated at 2022-06-23 13:04:01.533577
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test = StrategyModule()
    assert test._host_pinned

# Generated at 2022-06-23 13:04:05.790234
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert hasattr(StrategyModule,'_host_pinned')
    assert StrategyModule._host_pinned == True

# Generated at 2022-06-23 13:04:07.464192
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "Test tqm"
    sm = StrategyModule(tqm)
    assert sm

# Generated at 2022-06-23 13:04:08.382572
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None


# Generated at 2022-06-23 13:04:09.589956
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a=StrategyModule('test')
    assert a._host_pinned == True

# Generated at 2022-06-23 13:04:10.438360
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	pass


# vim: set noexpandtab:

# Generated at 2022-06-23 13:04:12.433097
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_strategy=StrategyModule("this is a tqm")
    #Now test that the constructor did the right thing...
    assert my_strategy._host_pinned is True

# Generated at 2022-06-23 13:04:23.041626
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import strategy_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_executor import TaskExecutor

    host_list = list()
    host_list.append(Host('testhost1', groups=['group1']))
    host_list.append(Host('testhost2', groups=['group2']))
    host_list.append(Host('testhost3', groups=['group3']))
    task_list = list()
    task_list.append(Task())

# Generated at 2022-06-23 13:04:24.656226
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module != None
    display.display("Test StrategyModule constructor passed!")


# Generated at 2022-06-23 13:04:36.558687
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.loader import success
    from ansible.utils.display import Display
    from ansible.utils.color import stringc
    from ansible.utils.unicode import to_unicode
    from ansible.errors import AnsibleError
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    try:
        display.columns = 100
    except (AttributeError, ValueError):
        pass
    display.verbosity = 3

    def host_pinned():
        loader = DataLoader()
        variable_manager = VariableManager()

# Generated at 2022-06-23 13:04:44.777716
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    # Define a tqm for unit testing
    tqm = TaskQueueManager(
          inventory=InventoryManager(loader=DataLoader(), sources=''),
          variable_manager=VariableManager(),
          loader=DataLoader(),
          options=None,
          passwords=None,
    )
    # Call constructor of StrategyModule
    s = StrategyModule(tqm)
    assert s._host_pinned == True


# Generated at 2022-06-23 13:04:45.774932
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)

# Generated at 2022-06-23 13:04:48.068471
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:04:58.958107
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import threading
    from ansible.plugins.loader import connection_loader

    class _DummyConnection(object):
        def __init__(self, transport):
            self.transport = transport
            self.connected = threading.Event()

        def close(self):
            self.connected.clear()

    class _DummyTransport(object):
        def __init__(self, transport):
            pass

        def __str__(self):
            return 'dummy'

    display.verbosity = 3

    tqm = object()
    tqm._unreachable_hosts = tqm._stats = {}

    sm = StrategyModule(tqm)

    connection_loader.register('dummy', _DummyConnection)
    connection_loader.set_defaults('dummy')

# Generated at 2022-06-23 13:05:01.740210
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class A():
        def __init__(self):
            self.host_pinned = True
    a = A()
    __module__.StrategyModule(a)

# Generated at 2022-06-23 13:05:03.035360
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule('tqm')
    assert strategy._host_pinned is True

# Generated at 2022-06-23 13:05:05.010250
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule( tqm = None)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:05:07.906231
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    temp = StrategyModule(tqm)

    print(temp._host_pinned)

#test_StrategyModule()

# Generated at 2022-06-23 13:05:09.365410
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    assert isinstance(display, Display)

# Generated at 2022-06-23 13:05:19.724544
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass
#
# ansible/plugins/strategy/host_pinned.py
#
# (c) 2012-2014, Michael DeHaan <michael.dehaan@gmail.com>
#
# This file is part of Ansible
#
# Ansible is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# Ansible is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along

# Generated at 2022-06-23 13:05:20.939847
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm)
    assert s._host_pinned == True

# Generated at 2022-06-23 13:05:23.444429
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(None, None)
    StrategyModule(tqm)

# Generated at 2022-06-23 13:05:26.776142
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    TASK_QUEUE_MANAGER = True
    strategy_class = StrategyModule(TASK_QUEUE_MANAGER)
    assert (isinstance(strategy_class, StrategyModule))
    assert (strategy_class._host_pinned)

# Generated at 2022-06-23 13:05:28.282517
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    host_pinned = strategy._host_pinned
    assert host_pinned == True

# Generated at 2022-06-23 13:05:30.377698
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "test_tqm"
    stategy = StrategyModule(tqm)
    assert stategy._host_pinned == True

# Generated at 2022-06-23 13:05:31.251670
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)._host_pinned

# Generated at 2022-06-23 13:05:31.801123
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:05:32.933148
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm={})



# Generated at 2022-06-23 13:05:44.870950
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # import default libs
    import sys
    import uuid
    # import test libs
    from ansible.plugins.strategy.host_pinned import StrategyModule
    class FakeTqm:
        def __init__(self, name):
            self.name = name
            self.tags = set()
            self.skipped_hosts = dict()
            self.fail_hosts = dict()
            self.stats = dict()
            self.hostvars = dict()
    FakeTqm.defaullt_vars = dict(
        ansible_play_batch=None,
        ansible_play_hosts=None,
        ansible_play_hosts_all=[],
        ansible_play_residual=None
    )

# Generated at 2022-06-23 13:05:48.022200
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert (strategy_module._host_pinned == True)

# Unit test failure case of constructor of class StrategyModule

# Generated at 2022-06-23 13:05:53.595150
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned as hps # pylint: disable=import-error
    tqm = 'TQM'
    test_object = hps.StrategyModule(tqm)
    assert test_object._host_pinned == True
    assert test_object._tqm == 'TQM'

# Generated at 2022-06-23 13:05:55.447381
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '__init__')
    assert callable(StrategyModule.__init__)

# Generated at 2022-06-23 13:05:56.247093
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule("tqm")
    assert s._host_pinned == True

# Generated at 2022-06-23 13:05:56.680230
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(True)

# Generated at 2022-06-23 13:05:58.270735
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned


# Generated at 2022-06-23 13:06:00.945458
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    strategy_module = StrategyModule(display)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:06:04.004512
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test for constructor of class StrategyModule
    '''
    strategy_module = StrategyModule(Display())
    assert isinstance(strategy_module, StrategyModule)


# Generated at 2022-06-23 13:06:06.099491
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:06:07.796606
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule
    # test_StrategyModule() executed with success
    return True

# Generated at 2022-06-23 13:06:10.798369
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    taskQueueManager = None
    strategy_obj = StrategyModule(taskQueueManager)
    assert hasattr(strategy_obj, '_host_pinned')

# Generated at 2022-06-23 13:06:13.414237
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """This is a testing method for ansible.plugins.strategy.host_pinned.StrategyModule"""
    # Need to set the following variable in order to run the test.
    tqm = {}
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:06:15.318196
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    assert obj._host_pinned == True


# Generated at 2022-06-23 13:06:15.950026
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:06:16.542755
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule([])

# Generated at 2022-06-23 13:06:24.475444
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    def get_hosts(pattern):
        host = Host(name="testhost")
        host.set_variable("ansible_connection", "local")
        return [host]

    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=DataLoader(), sources=[""]),
        variable_manager=VariableManager(),
        loader=DataLoader(),
        options=None,
        passwords={},
        stdout_callback=None,
    )
    host_pinned = Strategy

# Generated at 2022-06-23 13:06:35.216594
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=None, sources=['localhost']),
        variable_manager=VariableManager(loader=None, inventory=InventoryManager(loader=None, sources=['localhost'])),
        loader=None,
        options=None,
        passwords=None,
    )
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned


# Test strategy execution:

# Generated at 2022-06-23 13:06:37.015431
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from mock import MagicMock
    tqm = MagicMock()
    StrategyModule(tqm)

# Generated at 2022-06-23 13:06:39.693086
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test for constructor of class StrategyModule.
    '''
    obj = StrategyModule(tqm=None)

    assert obj._host_pinned is True

# Generated at 2022-06-23 13:06:43.808194
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = type('TestQueryManager', (object,), {'in_playbook_vars': [{'hosts': {'localhost': {'hostname': 'localhost'}}}]})()
    assert isinstance(StrategyModule(tqm), StrategyModule)

# Generated at 2022-06-23 13:06:45.962971
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(True)
    assert(sm._host_pinned == True)

# Generated at 2022-06-23 13:06:47.786524
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('tqm')
    assert( strategy_module )


# Generated at 2022-06-23 13:06:48.364045
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:06:48.967600
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:06:50.761473
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  StrategyModule('tqm')

  display.display(u'StrategyModule: test_StrategyModule')
  return

# Generated at 2022-06-23 13:06:51.996350
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-23 13:06:54.532291
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'TestQueueManager'

    strate_mod = StrategyModule(tqm)

    assert strate_mod is not None


# Generated at 2022-06-23 13:06:55.974437
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('This test is not executable')
    assert False



# Generated at 2022-06-23 13:06:57.400978
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm._host_pinned

# Generated at 2022-06-23 13:07:00.233761
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    sm = StrategyModule(tqm)
    actual = sm._host_pinned
    assert actual is True, 'Expected: True, Actual: %s' % actual

# Generated at 2022-06-23 13:07:01.779450
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule(None)
    assert strategyModule._host_pinned == True



# Generated at 2022-06-23 13:07:04.069608
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)

    #Check if variable _host_pinned is True
    assert (strategy_module._host_pinned == True)



# Generated at 2022-06-23 13:07:06.459783
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    assert StrategyModule(display)._host_pinned == True

# Generated at 2022-06-23 13:07:07.005796
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(1)

# Generated at 2022-06-23 13:07:07.738300
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:07:08.424791
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert len(display.display) == 1

# Generated at 2022-06-23 13:07:09.013658
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:07:10.221395
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test = StrategyModule('')
    assert test._host_pinned == True

# Generated at 2022-06-23 13:07:11.545994
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm)
    assert sm._host_pinned is True

# Generated at 2022-06-23 13:07:19.798139
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTqm(object):
        hosts = 'test'
        def get_inventory(self):
            return self
        def get_host_vars(self, host, new_vvars=None, include_hostvars=False):
            return self
        def get_vars(self, play=None, host=None, task=None, include_hostvars=False):
            return self
    tqm = TestTqm()
    test_strategymodule = StrategyModule(tqm)
    assert test_strategymodule.host_pinned == True

# Generated at 2022-06-23 13:07:21.419893
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """This is a constructor test. It will detect changes in the constructor of class StrategyModule"""
    pass

# Generated at 2022-06-23 13:07:21.964844
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule([])

# Generated at 2022-06-23 13:07:28.524411
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    class TestStrategyModule(unittest.TestCase):
        def setUp(self):
            self.strategymodule = StrategyModule(tqm=None)
            self.strategymodule._host_pinned = True

        def test_strategymodule_str_output(self):
            self.assertEqual(str(self.strategymodule), "HostPinned")
    unittest.main()

# Generated at 2022-06-23 13:07:30.067171
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__(StrategyModule(tqm))



# Generated at 2022-06-23 13:07:32.097337
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    obj = StrategyModule(tqm)
    assert obj._host_pinned == True

# Generated at 2022-06-23 13:07:42.446121
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import collections
    import ansible.plugins
    import ansible.plugins.strategy
    #import ansible.plugins.strategy.host_pinned
    import ansible.utils

    #Create instances of ansible.plugins.strategy.host_pinned.StrategyModule
    play = collections.namedtuple('Play', 'tags')
    play = play(tags = dict())
    host = collections.namedtuple('VariableManager', 'vars')
    task = collections.namedtuple('Task', 'name tags')
    tqm = collections.namedtuple('Tqm', 'host_list options variable_manager loader')

# Generated at 2022-06-23 13:07:46.320968
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    temp_strategy = StrategyModule(tqm=None)
    if not temp_strategy:
        print('Failed to create temp_strategy')

    if temp_strategy._host_pinned != True:
        print('Failed to set _host_pinned')

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:07:47.087976
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(None), StrategyModule)

# Generated at 2022-06-23 13:07:48.540552
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Unit test for class StrategyModule
    """
    assert True

# Generated at 2022-06-23 13:07:49.845806
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule.__name__ == "StrategyModule")

# Generated at 2022-06-23 13:07:51.607089
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:07:52.894516
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
        assert callable(StrategyModule)

# Generated at 2022-06-23 13:07:56.592066
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # check created StrategyModule:
    assert StrategyModule
    # check parent StrategyModule
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-23 13:07:58.913033
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = DummyTQM()
    sm = StrategyModule(tqm)
    assert sm._host_pinned is True


# Generated at 2022-06-23 13:08:08.137609
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import context
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    context.CLIARGS = context.CLIARGS._replace(verbosity=3, listtags=True, listtasks=True, listhosts=True)

    inventory = InventoryManager(
        loader=None,
        sources=['localhost', 'otherhost'],
    )

    strategy_module = StrategyModule(TaskQueueManager())

# Generated at 2022-06-23 13:08:10.535117
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    assert obj._host_pinned



# Generated at 2022-06-23 13:08:13.882978
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy import linear
    strategy_plugin = linear.StrategyModule(tqm)
    strategy_plugin.free()

# Generated at 2022-06-23 13:08:20.754887
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-23 13:08:21.805140
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    

# Generated at 2022-06-23 13:08:23.378384
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule(None)
    assert mod is not None

# Generated at 2022-06-23 13:08:25.581213
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create object of class StrategyModule
    # assert if object created successfully
    assert StrategyModule(None)

# Generated at 2022-06-23 13:08:27.847735
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_object = StrategyModule(1)
    assert test_object
    assert test_object._host_pinned == True

# Generated at 2022-06-23 13:08:30.206445
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:08:30.810926
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:08:32.311064
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test for constructor of class StrategyModule
    '''
    assert True

# Generated at 2022-06-23 13:08:35.488339
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# test for function _wait_on_pending_results

# Generated at 2022-06-23 13:08:37.463942
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_StrategyModule = StrategyModule()
    assert test_StrategyModule._host_pinned == True

# Generated at 2022-06-23 13:08:45.871919
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.loader
    from ansible.utils.collection_loader import AnsibleCollectionRef
    from ansible.utils.collection_loader import AnsibleCollectionRefInventory

    tqm = AnsibleCollectionRefInventory()
    ansible_collections_namespace = AnsibleCollectionRef('')
    strategy_plugins_path = ansible_collections_namespace.collections_loader._plugins_paths['strategy']

    strategy_plugins = ansible.plugins.loader.find_plugins(strategy_plugins_path)
    for plugin_name in strategy_plugins:
        plugin_class = ansible.plugins.loader.strategy_loader.get(plugin_name)

        # FIXME: we need to figure out how to mock tqm
        #strategy = plugin_class(tqm)
        #assert strategy.

# Generated at 2022-06-23 13:08:47.219991
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_strategy = StrategyModule(tqm)

# Generated at 2022-06-23 13:08:47.889120
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:08:48.455563
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-23 13:08:49.038640
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:08:50.616034
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned

# Generated at 2022-06-23 13:08:52.717788
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm="no tqm set")

# Generated at 2022-06-23 13:08:53.802349
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == FreeStrategyModule.__doc__

# Generated at 2022-06-23 13:09:04.710108
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.playbook.play import Play
    from ansible.playbook import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.facts import Facts
    from ansible.executor.task_queue_manager import TaskQueueManager

    host_list = [
        'localhost',
    ]

    inventory = InventoryManager(loader=None, sources=host_list)

    variable_manager = VariableManager(loader=None, inventory=inventory)


# Generated at 2022-06-23 13:09:10.653684
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a faked tqm
    import types
    tqm = types.SimpleNamespace()

    # Initialize the class StrategyModule
    strategy_module = StrategyModule(tqm)

    # Test if the StrategyModule object's _host_pinned is the same as the original one
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:09:15.855496
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(None, None, None, None, None, None, None)
    strategy_module = StrategyModule(tqm)

    assert strategy_module._host_pinned == True
    assert strategy_module._blocked_hosts == dict()
    assert strategy_module._display == display

# Generated at 2022-06-23 13:09:19.708504
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    SM = StrategyModule(tqm)

    # Test whether the constructor sets the right values
    print(SM._host_pinned)
    assert SM._host_pinned == True

# Generated at 2022-06-23 13:09:22.568901
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule('')
    print(strategy._host_pinned)

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-23 13:09:23.803779
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()



# Generated at 2022-06-23 13:09:24.498998
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-23 13:09:25.096709
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:09:33.405263
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TaskQueueManager(inventory=None)
    tqm.get_hosts_remaining(host=None)
    tqm.get_hosts_remaining('all')
    tqm._queue_empty()
    tqm.get_active_queue_jobs()
    tqm.schedule_queue_job('host', 'task', True)
    tqm.finished_pending_results()
    tqm.clear_notified_tasks(host)
    tqm.send_callback('host', 'task', True)
    tqm.clear_failed_hosts()
    tqm.get_failed_hosts()
    tqm.get_inventory()
    tqm._inventory = {}
    tqm.get_workers()

# Generated at 2022-06-23 13:09:33.979834
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:09:38.053511
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'TQM'
    strategymodule = StrategyModule(tqm)
    assert strategymodule._tqm == tqm
    assert strategymodule._host_pinned == True

# Generated at 2022-06-23 13:09:41.489302
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
        strategy = StrategyModule()
        assert strategy._result_q.qsize() == 0
        assert strategy._progress_q.qsize() == 0
        assert strategy._step == 0
        assert strategy._host_pinned == True

# Generated at 2022-06-23 13:09:42.614174
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule("tqm")
    assert sm._host_pinned is True

# Generated at 2022-06-23 13:09:43.123724
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:09:44.683312
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is True
    assert StrategyModule is True
    assert StrategyModule is True

# Generated at 2022-06-23 13:09:46.119274
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('tqm')

# Generated at 2022-06-23 13:09:56.791675
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.callbacks
    import ansible.inventory
    import ansible.playbook
    from ansible.executor import task_queue_manager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    loader = DataLoader()
    inv = ansible.inventory.Inventory(loader, [])
    variable_manager = VariableManager(loader=loader, inventory=inv)
    cbs = [ansible.callbacks.DefaultRunnerCallbacks()]
    pb = ansible.playbook.PlayBook(
        playbook='',
        callbacks=cbs,
        runner_callbacks=cbs,
        stats=cbs,
        inventory=inv,
        variable_manager=variable_manager,
        loader=loader,
    )
    tqm = task_

# Generated at 2022-06-23 13:09:58.376696
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule('a')

# Generated at 2022-06-23 13:09:59.687470
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()


# Generated at 2022-06-23 13:10:04.067408
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager

    tqm = TaskQueueManager(None, None, None, None, None, None, None, None)
    assert StrategyModule(tqm) is not None

# Generated at 2022-06-23 13:10:04.625292
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    temp = StrategyModule()

# Generated at 2022-06-23 13:10:09.563167
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    assert issubclass(ansible.plugins.strategy.host_pinned.StrategyModule,
                      ansible.plugins.strategy.free.StrategyModule)
    strategy_module = ansible.plugins.strategy.host_pinned.StrategyModule(None)
    assert strategy_module._host_pinned

# Generated at 2022-06-23 13:10:10.910003
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-23 13:10:11.909103
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('tqm')

# Generated at 2022-06-23 13:10:13.318769
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tm = StrategyModule('test')
    assert tm._host_pinned == True

# Generated at 2022-06-23 13:10:23.812539
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Unit test not ready yet.
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    # Define a play
    play_source = dict(
    name = "Ansible Play",
    hosts = 'all',
    gather_facts = 'no',
    tasks = [
        dict(action=dict(module='debug', args=dict(msg='Hello World!')))
    ])
    play = Play.load(play_source, variable_manager=None, loader=None)
    # Create a host with a task queue manager
    host = Host(name="my_host")

# Generated at 2022-06-23 13:10:25.924276
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True


# Generated at 2022-06-23 13:10:27.264921
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    assert StrategyModule.__doc__ is not None

# Generated at 2022-06-23 13:10:30.189772
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = free.tqm
    s = StrategyModule(tqm)
    assert s._host_pinned == True

# Generated at 2022-06-23 13:10:30.821525
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:10:34.181122
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module._host_pinned == True
    assert strategy_module._keep_in_order == False

# Generated at 2022-06-23 13:10:44.223240
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.batch import Batch
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.templating import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import callback_loader, strategy_loader

    from collections import namedtuple


# Generated at 2022-06-23 13:10:47.659481
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Call the constructor:
    s = StrategyModule(None)
    # Assert we got the correct class:
    assert s == StrategyModule(None)

# Generated at 2022-06-23 13:10:50.809904
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy import add_tqm_attribute

    my_tqm = None
    s = StrategyModule(my_tqm)
    add_tqm_attribute(s)
    assert(s.get_tqm() == my_tqm)

# Generated at 2022-06-23 13:10:54.520045
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert len(StrategyModule.__doc__) > 0
    tqm = None
    str_mod = StrategyModule(tqm)
    assert str_mod is not None

# Generated at 2022-06-23 13:10:55.155918
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:10:56.693546
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-23 13:10:58.359434
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:11:01.126604
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass
# Unit test of method _wait_on_pending_results of class StrategyModule

# Generated at 2022-06-23 13:11:08.856963
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    tqm = TaskQueueManager(None, None, None, None, None, None, None, None, None, None, None, None)

    # _host_pinned is True when _host_pinned is added to StrategyModule()
    strategy_module = StrategyModule(tqm)
    assert hasattr(strategy_module, '_host_pinned')

# Generated at 2022-06-23 13:11:10.100569
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test that the constructor works as expected
    assert StrategyModule(tqm=None)

# Generated at 2022-06-23 13:11:14.016013
# Unit test for constructor of class StrategyModule
def test_StrategyModule(): # Test class StrategyModule::__init__(self, tqm)
    """ Unit test for StrategyModule constructor """
    try:
        StrategyModule(tqm)
    except Exception as e:
        print("Kindly check the below error:")
        print(e)
        assert False


# Generated at 2022-06-23 13:11:15.361360
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:11:16.321476
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)

# Generated at 2022-06-23 13:11:16.911004
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:11:21.723584
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy.host_pinned import StrategyModule
    x = TaskQueueManager()
    assert isinstance(StrategyModule(x), StrategyModule)

# Generated at 2022-06-23 13:11:24.626562
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    try:
        tqm = StrategyModule(tqm)
        assert tqm._host_pinned is True
    except Exception as e:
        print ("Exception thrown in test_StrategyModule")

# Generated at 2022-06-23 13:11:26.672739
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule('tqm')
    assert x._host_pinned == True

# Generated at 2022-06-23 13:11:27.436368
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:11:28.733429
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__

# Generated at 2022-06-23 13:11:29.537324
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:11:30.871237
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = FreeStrategyModule("foo")
        return 0
    except NameError:
        return 1


# Generated at 2022-06-23 13:11:33.575713
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm = None)
    assert strategy._host_pinned == True


# Generated at 2022-06-23 13:11:37.084941
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # This is not a standalone module, so we just test the constructor.
    tqm = None
    hs = StrategyModule(tqm)
    assert hs._host_pinned == True
    assert hs._tqm is None

# Generated at 2022-06-23 13:11:37.931559
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)



# Generated at 2022-06-23 13:11:40.212593
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule(tqm=FreeStrategyModule)
    assert tqm is not None

# Generated at 2022-06-23 13:11:41.629195
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   assert StrategyModule(tqm = None)

# Generated at 2022-06-23 13:11:44.241945
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_strategy_module = StrategyModule("test")
    assert test_strategy_module._host_pinned

# Generated at 2022-06-23 13:11:49.027212
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_object = StrategyModule('tqm')

    # Check if the strategy_object is an instance of class StrategyModule
    assert isinstance(strategy_object, StrategyModule)

    # Check if the _host_pinned variable is set to True
    assert strategy_object._host_pinned == True

# Generated at 2022-06-23 13:11:51.998688
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """This function will unit test for constructor of class StrategyModule"""

    tqm = None

    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:12:02.342933
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import collections

    tqm = collections.namedtuple('tqm', ['hostvars', 'primary_hosts'])

    tqm.hostvars = collections.namedtuple('hostvars', ['host1', 'host2', 'host3'])

    tqm.hostvars.host1 = {}
    tqm.hostvars.host2 = {}
    tqm.hostvars.host3 = {}

    tqm.primary_hosts = [ 'host1', 'host2', 'host3' ]
    tqm.host_pinned = True

    ans = StrategyModule(tqm)
    assert ans._host_pinned