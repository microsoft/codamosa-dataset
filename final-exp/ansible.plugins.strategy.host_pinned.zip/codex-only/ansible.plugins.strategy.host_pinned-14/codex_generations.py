

# Generated at 2022-06-23 13:02:04.444813
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# TODO: This is just a placeholder, need to implement this
test_StrategyModule()

# Generated at 2022-06-23 13:02:05.165248
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:02:06.985814
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned is True

# Generated at 2022-06-23 13:02:08.318692
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    SUT = StrategyModule
    assert(SUT != None)
    pass

# Generated at 2022-06-23 13:02:10.216813
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:02:12.052815
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"

# Generated at 2022-06-23 13:02:14.253980
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  print("Testing strategy module")
  print(StrategyModule)

if __name__ == '__main__':
  test_StrategyModule()

# Generated at 2022-06-23 13:02:16.670580
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager('host_pinned')
    st = StrategyModule(tqm)
    assert st._host_pinned

# Generated at 2022-06-23 13:02:18.043614
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.doc == 'host_pinned strategy'

# Generated at 2022-06-23 13:02:19.062394
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-23 13:02:21.799052
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_queue_manager import TaskQueueManager
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-23 13:02:26.901580
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    s = ansible.plugins.strategy.host_pinned.StrategyModule('tqm')
    assert(str(type(s)) == "<class 'ansible.plugins.strategy.host_pinned.StrategyModule'>")

# Generated at 2022-06-23 13:02:28.035714
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return True


# Generated at 2022-06-23 13:02:29.283340
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule() != None

# Generated at 2022-06-23 13:02:36.690877
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    play_context = PlayContext()
    play_context._tqm = TaskQueueManager(loader, play_context, None, None)
    play = Play().load(dict(name='Test Play', hosts='all', gather_facts='no'), loader=loader, variable_manager=None, loader_cache=None)

# Generated at 2022-06-23 13:02:37.655169
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm = None)
    assert s._host_pinned


# Generated at 2022-06-23 13:02:38.878719
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(1)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:02:41.718626
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   # Test that StrategyModule is a subclass of FreeStrategyModule
   assert issubclass(StrategyModule, FreeStrategyModule)



# Generated at 2022-06-23 13:02:43.829365
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.display import Display
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    display = Display()
    StrategyModule = FreeStrategyModule(display)
    assert StrategyModule._host_pinned == True
    return StrategyModule._host_pinned

# Generated at 2022-06-23 13:02:46.179671
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Given
    tqm = ""
    # When
    strategy_module = StrategyModule(tqm)
    # Then
    assert strategy_module is not None

# Generated at 2022-06-23 13:02:47.366633
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(StrategyModule)

# Generated at 2022-06-23 13:02:50.573869
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned is True
    assert strategy_module._display is not None


# Generated at 2022-06-23 13:02:52.143984
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test = StrategyModule('Test')
    assert test._host_pinned == True

# Generated at 2022-06-23 13:02:54.608782
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategyModule = StrategyModule(tqm)
    assert(strategyModule)


# Generated at 2022-06-23 13:02:56.504497
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a=StrategyModule(tqm=None)
    assert a._host_pinned == True

# Generated at 2022-06-23 13:03:03.477088
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    host_pinned_strategy = StrategyModule('tqm')
    # test if strategy_loader is called
    assert strategy_loader.all() == {'host_pinned': host_pinned_strategy}
    # test if constructor of superclass is called
    assert type(host_pinned_strategy) == FreeStrategyModule

# Generated at 2022-06-23 13:03:09.929394
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    tqm = TaskQueueManager( inventory = None, variable_manager = None, loader = None, options = None, passwords = None, stdout_callback = None)
    s = StrategyModule(tqm)
    tr = TaskResult(host = None, task = None, return_data = dict(contacted = dict(), dark = dict()))

# Generated at 2022-06-23 13:03:11.807458
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule('TQM')
    assert module._host_pinned



# Generated at 2022-06-23 13:03:18.048063
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from unittest import TestCase, SkipTest, skip
    import ansible.plugins.strategy.host_pinned as strategy_module
    try:
        tqm = None
        strategy_module.StrategyModule(tqm)
    except Exception as e:
        raise Exception('Failed to create instance of StrategyModule: %s %s' % (type(e), e))

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:03:19.597026
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = Display()
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:03:21.651235
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock
    import __main__
    tqm = mock.MagicMock()
    StrategyModule(tqm)

# Generated at 2022-06-23 13:03:23.369206
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ''' test_StrategyModule(tqm) '''
    pass

# Generated at 2022-06-23 13:03:24.052016
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-23 13:03:26.477878
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:03:31.643381
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test_task_queue_manager'
    # Instantiation with args
    strategy_module_args = StrategyModule(tqm)
    assert isinstance(strategy_module_args, StrategyModule)
    # Assert that variables initialized properly
    assert strategy_module_args._host_pinned == True
    assert strategy_module_args._tqm == tqm
    assert strategy_module_args._display == display
    assert strategy_module_args._global_vars == []
    assert strategy_module_args._inventory == None
    assert strategy_module_args._inventory_update == False
    assert strategy_module_args._variables == {}
    assert strategy_module_args._depth == 0
    assert strategy_module_args._loader == None
    assert strategy_module_args._final_done_callback != None


# Generated at 2022-06-23 13:03:34.611309
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModeule")
    try:
        from intileryAnsible.plugins_intilery.strategy.host_pinned import StrategyModule
        strategy_module = StrategyModule(None)
        assert type(strategy_module) == StrategyModule
        print("Passed constructor of class StrategyModule")
    except:
        print("Failed constructor of class StrategyModule")


# Generated at 2022-06-23 13:03:43.255147
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    options = dict(inventory=['test/units/plugins/strategy/inventory.yaml'],
                   playbook='test/units/plugins/strategy/playbook.yaml',
                   extra_vars=[{}],
                   connection='local',
                   forks=10)
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=options['inventory'])

# Generated at 2022-06-23 13:03:44.135722
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:03:47.640502
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('tqm')
    assert strategy_module.__class__.__name__ == "StrategyModule"
    assert strategy_module._host_pinned == True


# Generated at 2022-06-23 13:03:48.449306
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:03:53.868996
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'ansible.executor.task_queue_manager.TaskQueueManager'

# Generated at 2022-06-23 13:03:54.884189
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:03:56.674464
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:03:58.277140
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:04:01.858407
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Initialize Strategy Module
    strategy_module = StrategyModule(tqm=None)
    assert_equals(strategy_module._host_pinned, True)
    assert_equals(strategy_module.display, Display())

# Generated at 2022-06-23 13:04:03.842642
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_objects = StrategyModule(tqm)
    assert test_objects._host_pinned == True

# Generated at 2022-06-23 13:04:05.158737
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module is not None
    assert strategy_module._host_pinned is True

# Generated at 2022-06-23 13:04:06.335976
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ""
    strategy_module = StrategyModule(tqm)
    assert not strategy_module is None

# Generated at 2022-06-23 13:04:07.747320
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "abc"
    obj = StrategyModule(tqm)
    assert obj._host_pinned == True

# Generated at 2022-06-23 13:04:08.967792
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)



# Generated at 2022-06-23 13:04:10.754531
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm1 = FreeStrategyModule(tqm)
    assert tqm1.__init__ is not None

# Generated at 2022-06-23 13:04:13.210634
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm._host_pinned is True

# Generated at 2022-06-23 13:04:15.319685
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:04:15.956162
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:04:17.718141
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:04:18.740953
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)

# Generated at 2022-06-23 13:04:19.108136
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:04:21.002758
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert s.get_host_pinned() is True


# Generated at 2022-06-23 13:04:21.562190
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:04:22.497078
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)

# Generated at 2022-06-23 13:04:23.764494
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:04:28.316800
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock
    # use mock object to replace entire tqm module in test
    mock_tqm = mock.MagicMock()

    strategyModule = StrategyModule(mock_tqm)
    # Test constructor of class StrategyModule
    assert strategyModule._host_pinned is True

# Generated at 2022-06-23 13:04:30.151157
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(1)
    assert strategy._host_pinned

# Generated at 2022-06-23 13:04:30.766714
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:04:32.335998
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_mod = StrategyModule(None)
    assert strategy_mod

# Generated at 2022-06-23 13:04:36.778664
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class MockTqm:
        def __init__(self):
            self.host_pinned = False
    tqm = MockTqm()
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:04:40.424352
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global display
    display = Display()
    strategy_m = StrategyModule(tqm=None)
    assert strategy_m._host_pinned == True
    assert strategy_m._display == display

# Generated at 2022-06-23 13:04:47.289631
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    inst = StrategyModule(None)
    assert isinstance(inst._tqm, object)
    assert not inst._tqm is None
    #assert isinstance(inst._inventory, object)
    #assert inst._inventory is None
    assert isinstance(inst._variable_manager, object)
    assert not inst._variable_manager is None
    assert isinstance(inst._loader, object)
    assert not inst._loader is None
    assert inst._host_pinned is True


# Generated at 2022-06-23 13:04:50.045301
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task_queue_manager = object()
    strategy_module = StrategyModule(task_queue_manager)
    assert strategy_module._host_pinned == True


# Generated at 2022-06-23 13:04:51.932090
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x=StrategyModule("test")
    #assert x==True
    print("Constructor test passed!")



# Generated at 2022-06-23 13:04:57.653208
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager

    tqm = None

    host_pinned = StrategyModule(tqm)

    assert host_pinned._host_pinned is True


# Generated at 2022-06-23 13:04:58.392869
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule('tqm')

# Generated at 2022-06-23 13:04:59.010918
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:05:01.065893
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:05:08.480856
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    class TestTqm:
        def __init__(self):
            self.host_pinned = True
            self.host_done = True
            self.serial_strategy = True

    testtqm = TestTqm()
    test_strategy_module = StrategyModule(testtqm)
    assert test_strategy_module._host_pinned == True
    assert test_strategy_module._host_done == True
    assert test_strategy_module._serial_strategy == True

# Generated at 2022-06-23 13:05:09.112064
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:05:14.158173
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    display.verbosity = 3
    display.color = 'never'
    display.columns = 80
    display.stdout = {}
    display.stdout['has_color'] = False
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:05:20.526447
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Call the constructor of class StrategyModule and make sure an assertException is raised
    # We can't use the constructor of class StrategyModule, since there is no TaskQueueManager() available
    assertException = False
    try:
        strategyModule = StrategyModule(None)
        assertException = True
    except AssertionError as e:
        if str(e) == "TaskQueueManager is required":
            assertException = False
    assert assertException == False

    # Call the constructor of class StrategyModule and make sure an exception is NOT raised
    strategyModule = StrategyModule(TaskQueueManager())
    assert strategyModule is not None

# Generated at 2022-06-23 13:05:21.386316
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__

# Generated at 2022-06-23 13:05:21.952272
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:05:22.948934
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 13:05:26.982353
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Testing with the sample data given in the description
    # Variables used for the test
    # tqm = "Test Queue Manager"
    tqm = "Test Queue Manager"
    # Create object of class StrategyModule
    testObject = StrategyModule(tqm)
    # Assert result
    assert testObject._host_pinned == True

# Generated at 2022-06-23 13:05:30.547037
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass
"""
    tqm = ''
    strategy_module = StrategyModule(tqm)
    assert isinstance(strategy_module, StrategyModule)
"""

if __name__ == '__main__':
    import sys, pytest
    pytest.main(sys.argv)

# Generated at 2022-06-23 13:05:35.289782
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__module__ == "ansible.plugins.strategy.host_pinned"
    assert StrategyModule.__name__ == "StrategyModule"
    assert StrategyModule.__init__.__module__ == "ansible.plugins.strategy.host_pinned"
    assert StrategyModule.__init__.__name__ == "StrategyModule"
    assert StrategyModule.__init__.__qualname__ == "StrategyModule.__init__"
    assert StrategyModule._host_pinned

# Generated at 2022-06-23 13:05:38.095938
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned as host_pinned
    host_pinned.StrategyModule("test_tqm")

# Generated at 2022-06-23 13:05:40.628054
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestCls(StrategyModule):
        pass

    tqm = TestCls(None)
    assert tqm._host_pinned == True

# Generated at 2022-06-23 13:05:43.738293
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy
    assert strategy._host_pinned

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:05:50.831119
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned as strategy_host_pinned
    from ansible.plugins.strategy import StrategyBase
    from ansible.utils.display import Display
    from ansible.playbook import Playbook
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host

    # Create a fake TQM
    fake_variable_manager = MagicMock()

    fake_loader = MagicMock()

    fake_inventory = MagicMock()
    fake_inventory.get_hosts.return_value = [ Host(name='fake_host') ]

    fake_variable_manager = MagicMock()
    fake_passwords = MagicMock()


# Generated at 2022-06-23 13:05:53.019608
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {'_inventory': '''
        [all:vars]
        ansible_ssh_user=root
        [master]
        master.example.com
        [slave]
        slave1.example.com
    '''}
    StrategyModule(tqm)

# Generated at 2022-06-23 13:06:00.269761
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Initialize the object
    tqm = None
    obj = StrategyModule(tqm)
    # Check if the instance is correctly initialized
    assert obj is not None
    assert isinstance(obj, StrategyModule)

    assert obj._tqm == tqm
    assert obj._inventory is None
    assert obj._play is None
    assert obj._variable_manager is None
    assert obj._loader is None
    assert isinstance(obj._display, Display)
    assert obj._strategy == "host_pinned"
    assert obj._host_pinned is True

# Generated at 2022-06-23 13:06:00.899901
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:06:02.821476
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm = None)
    assert strategy._host_pinned


# Generated at 2022-06-23 13:06:08.780505
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager('inventory.ini',None,True,None,None,None,None)
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned
    assert strategy_module._tqm == tqm

# Generated at 2022-06-23 13:06:12.498912
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    with mock.patch('ansible.utils.display.Display') as display:
        tqm = mock.MagicMock()
        StrategyModule(tqm)
        assert display.called
    return True

# Generated at 2022-06-23 13:06:14.243091
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)._host_pinned

# Generated at 2022-06-23 13:06:21.326655
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# ansible.plugins.strategy_plugins.host_pinned.StrategyModule

# ansible.plugins.strategy_plugins.host_pinned.StrategyModule.run

# ansible.plugins.strategy_plugins.host_pinned.StrategyModule.__init__

# ansible.plugins.strategy_plugins.host_pinned.StrategyModule.__init__.test_StrategyModule

# ansible.plugins.strategy_plugins.host_pinned.StrategyModule.__init__.test_StrategyModule.test_init

# Generated at 2022-06-23 13:06:24.246374
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = FreeStrategyModule(None)
    assert type(module) == FreeStrategyModule
    assert module._host_pinned == True

# Generated at 2022-06-23 13:06:25.688536
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule('x')
        assert True
    except:
        assert False

# Generated at 2022-06-23 13:06:27.122892
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)

# Generated at 2022-06-23 13:06:30.614377
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    temp_tqm = 'temp_tqm'
    test_StrategyModule = StrategyModule(temp_tqm)
    assert test_StrategyModule._host_pinned == True

# Generated at 2022-06-23 13:06:34.179889
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    #assert StrategyModule(tqm='tqm')._tqm == 'tqm'
    assert StrategyModule(tqm='tqm')._host_pinned is True

# Generated at 2022-06-23 13:06:36.935144
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    strategy_module = StrategyModule("tqm")
    tqm = strategy_module._tqm

    assert tqm == "tqm"



# Generated at 2022-06-23 13:06:38.709980
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   strategy_module = StrategyModule()
   assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:06:39.288745
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:06:41.377205
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = {}

    sm = StrategyModule(test_tqm)
    assert sm._host_pinned


# Generated at 2022-06-23 13:06:42.011982
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:06:43.033241
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:06:46.473079
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TaskQueueManager()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.__class__.__name__ == "StrategyModule"

# Generated at 2022-06-23 13:06:49.427706
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    my_instance = StrategyModule(tqm)
    assert my_instance is not None

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:07:00.144128
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from collections import namedtuple
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,', 'otherhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 13:07:07.627688
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    
    from ansible.parsing.mod_args import ModuleArgsParser

    module_args_parser = ModuleArgsParser(None, None, None)

    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.plugins.loader import action_loader

    task = Task("Set up webservers", "shell", "/etc/ansible/facts.d/h.sh")
    task._parent = Block()
    task2 = Task

# Generated at 2022-06-23 13:07:09.017957
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule != FreeStrategyModule
    FreeStrategyModule()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:07:10.152187
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule('test')
    except Exception:
        assert False, "There is an error in constructor of class StrategyModule"

# Generated at 2022-06-23 13:07:18.021797
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create object of class StrategyModule
    print("\nStart test_StrategyModule")
    strategy_object = StrategyModule("tqm")
    # check whether self._host_pinned is true
    assert strategy_object._host_pinned is True
    print("Check whether self._host_pinned is true")
    print("test_StrategyModule complete")
    #assert strategy_object.__repr__() == "StrategyModule(tqm)
    #assert strategy_object.__str__() == "StrategyModule(tqm)

# Generated at 2022-06-23 13:07:20.742374
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    name = 'host_pinned'
    tqm = None

    strategy_module = StrategyModule(tqm)
    assert strategy_module.name == name
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:07:22.709289
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True


# Generated at 2022-06-23 13:07:23.840223
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule("tqm")

    assert sm._host_pinned == True

# Generated at 2022-06-23 13:07:25.070196
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm = 'test')

# Generated at 2022-06-23 13:07:28.736075
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:07:31.328059
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__.__class__.__name__ == 'function'
    assert StrategyModule._host_pinned == True

# Generated at 2022-06-23 13:07:32.103600
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-23 13:07:32.652579
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:07:33.487620
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:07:36.487355
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    new_strategy = StrategyModule("tqm")
    assert new_strategy

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:07:38.838681
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    strategy_module = StrategyModule(None)
    assert strategy_module is not None
    assert strategy_module._host_pinned is True

# Generated at 2022-06-23 13:07:39.444841
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:07:43.872097
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    The constructor of class StrategyModule should set the variable `_host_pinned` to True.
    '''
    import ansible.plugins.strategy.host_pinned as strategy_module
    # Instantiate the class
    strategy_module_obj = strategy_module.StrategyModule([])
    assert strategy_module_obj._host_pinned

# Generated at 2022-06-23 13:07:44.737016
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:07:45.547390
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()


# Generated at 2022-06-23 13:07:47.664037
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    test_var = StrategyModule(tqm)
    assert type(test_var) == StrategyModule
    assert test_var._host_pinned == True

# Generated at 2022-06-23 13:07:51.709085
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule
    test = StrategyModule

    obj = tqm(tqm)
    assert obj == tqm
    obj = test(tqm)
    assert obj.tqm == obj
    assert obj.name == 'host_pinned'



# Generated at 2022-06-23 13:07:54.702548
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule._host_pinned == True

# Generated at 2022-06-23 13:07:55.886293
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(), StrategyModule)

# Generated at 2022-06-23 13:07:59.014105
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'TestQueueManager'
    s = StrategyModule(tqm)
    assert s._host_pinned == True

# Test strategy with pinned hosts in a very simple playbook:

# Generated at 2022-06-23 13:07:59.631138
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:08:00.701459
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule('tqm')

# Generated at 2022-06-23 13:08:02.131426
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm='test')



# Generated at 2022-06-23 13:08:03.441899
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=tqm) is not None

# Generated at 2022-06-23 13:08:11.017168
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from collections import namedtuple
    from ansible.playbook.task import Task

    fake_loader = namedtuple('fake_loader', 'path_exists list_directory filter_loader')
    fake_variable_manager = namedtuple('fake_variable_manager', 'extra_vars')
    fake_inventory = namedtuple('fake_inventory', 'hosts get_hosts get_host get_groups get_group get_basedir')
    fake_playbook = namedtuple('fake_playbook', 'get_loader get_variable_manager get_inventory basedir get_hosts')
    fake_task = namedtuple('fake_task', 'name get_name get_path get_role get_loader get_vars get_args')

    sm = StrategyModule(fake_task_queue_manager)
    assert sm is not None

# Generated at 2022-06-23 13:08:12.583890
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:08:21.912074
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_instance = StrategyModule('test_tqm')
    assert test_instance._tqm == 'test_tqm'
    assert test_instance._workers == 1
    assert test_instance._queue == 'main'
    assert test_instance._current_worker == 0
    assert test_instance._inventory == None
    assert test_instance._variable_manager == None
    assert isinstance(test_instance._display, Display)
    assert test_instance._host_pinned == True
    assert test_instance._hosts_left == []
    assert test_instance._hosts_left_count == 0
    assert test_instance._hosts_max_batch == None
    assert test_instance._hosts_batch_count == 0
    assert test_instance._hosts_queue == []
    assert test_instance._hosts_done == []

# Generated at 2022-06-23 13:08:23.550700
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert display.columns == 0
    assert display.verbosity == 0

# Generated at 2022-06-23 13:08:24.238296
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:08:25.819547
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    StrategyModule(None)

# Generated at 2022-06-23 13:08:26.984866
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-23 13:08:28.891218
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:08:29.504047
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:08:35.112503
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '__init__')
    assert callable(StrategyModule.__init__)
    assert StrategyModule.__init__.__code__.co_argcount == 2
    assert StrategyModule.__init__.__code__.co_varnames[0] == 'self'

# Generated at 2022-06-23 13:08:36.380422
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)

# Generated at 2022-06-23 13:08:37.540679
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1 == 1

# Generated at 2022-06-23 13:08:39.783605
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor")
    tqm=None
    res = StrategyModule(tqm)
    assert res != None
    print("Done testing constructor")

# Generated at 2022-06-23 13:08:40.426260
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-23 13:08:43.253152
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    strategy_module = StrategyModule(tqm=None)

# Generated at 2022-06-23 13:08:44.298921
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:08:44.914325
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:08:46.115384
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert (StrategyModule(tqm))


# Generated at 2022-06-23 13:08:52.449933
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from unit.test_loader import DictDataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    
    # Create an inventory file, and add host in the inventory
    inventory = InventoryManager(loader=DictDataLoader({'plugin': 'host_pinned','hosts': {'example.com': {}}}),
                                 sources='localhost,')
    variable_manager = VariableManager(loader=DictDataLoader({'plugin': 'host_pinned'}),
                                       inventory=inventory)
    
    # Create a taskqueuemanager object
    tqm = TaskQueue

# Generated at 2022-06-23 13:08:53.549031
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(3)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:08:54.782175
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert not StrategyModule.__init__.__doc__

# Generated at 2022-06-23 13:09:05.378763
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import strategy_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars
    from ansible.vars.reserved import Reserved

    loader = DataLoader()
    play_context = PlayContext()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_iterator = Play

# Generated at 2022-06-23 13:09:06.575422
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()
    assert obj._host_pinned == True


# Generated at 2022-06-23 13:09:09.906530
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("TaskQueuingManager Object")
    assert strategy_module
    assert strategy_module._host_pinned is True
    assert strategy_module._host_finished == []

# Generated at 2022-06-23 13:09:12.353490
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(StrategyModule)
    print(StrategyModule.__doc__)
    print(StrategyModule.__init__.__doc__)
    print(test_StrategyModule.__doc__)

test_StrategyModule()

# Generated at 2022-06-23 13:09:15.199791
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == FreeStrategyModule.__doc__
    assert StrategyModule.__init__.__doc__ == FreeStrategyModule.__init__.__doc__

# Generated at 2022-06-23 13:09:17.392344
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    obj = StrategyModule('task_queue_manager')
    assert obj._host_pinned == True
    assert isinstance(obj, FreeStrategyModule)

# Generated at 2022-06-23 13:09:22.261516
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test'
    strats = StrategyModule(tqm)
    assert not strats is None
    print ('Unit test for constructor of class StrategyModule passed!')

# Unit test to check the usage of '_host_pinned' attribute

# Generated at 2022-06-23 13:09:24.951382
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned as strategy_host_pinned
    strategy_host_pinned.StrategyModule('tqm')

# Generated at 2022-06-23 13:09:25.888830
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 13:09:30.386122
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = Ansible()
    strategy = StrategyModule(tqm)
    assert strategy.__class__.__name__ == "StrategyModule"
    assert strategy.get_host_pinned()


# Generated at 2022-06-23 13:09:30.975189
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:09:35.881075
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Unit Test Method."""
    host_pinned_strategy = StrategyModule('test')
    assert host_pinned_strategy._host_pinned
    assert not host_pinned_strategy._failed_hosts
    assert not host_pinned_strategy._done_hosts
    assert not host_pinned_strategy._unreachable_hosts
    assert not host_pinned_strategy._work_queue

# Generated at 2022-06-23 13:09:36.612243
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == True

# Generated at 2022-06-23 13:09:45.322286
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import sys
    from ansible.plugins.strategy import get_strategy
    from ansible.executor import play_context
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    options = play_context.PlayContext()
    options.become_user="root"
    options.become=True
    options.forks=1
    tqm=None
    loader=DataLoader()
    passwords=dict()
    results_callback=None
    inventory=Inventory(loader=loader, variable_manager=VariableManager(), host_list='/home/vagrant/openshift-ansible/inventory')
    sys.argv=['ansible-playbook','-i','localhost,']

# Generated at 2022-06-23 13:09:47.897138
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test 1:
    # Check that the object is initialized as it should
    #    test_object = StrategyModule(tqm)
    return True


# Generated at 2022-06-23 13:09:48.896976
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   StrategyModule(None)


# Generated at 2022-06-23 13:09:50.409547
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategymodule = StrategyModule()
    assert strategymodule.__class__.__name__ == "StrategyModule"

# Generated at 2022-06-23 13:09:50.777201
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule("")

# Generated at 2022-06-23 13:09:51.948201
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    if StrategyModule.is_test_mode():
        StrategyModule()

# Generated at 2022-06-23 13:09:55.192455
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('test_StrategyModule')
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:10:00.805261
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''Unit test for the constructor of class StrategyModule'''

    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    from ansible.utils.display import Display
    from ansible.executor.task_queue_manager import TaskQueueManager

    tqm = TaskQueueManager()
    strategy = FreeStrategyModule(tqm)

    assert strategy._host_pinned is False

# Generated at 2022-06-23 13:10:02.868754
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ''' test for constructor of class StrategyModule'''



# Generated at 2022-06-23 13:10:04.023629
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Generated at 2022-06-23 13:10:04.918699
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).__init__

# Generated at 2022-06-23 13:10:05.465822
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1 == 1

# Generated at 2022-06-23 13:10:06.665532
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None

# Generated at 2022-06-23 13:10:13.838336
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-23 13:10:16.266177
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    aa = StrategyModule(None)
    #makes sure aa is an object of class StrategyModule
    assert type(aa) == StrategyModule

# Generated at 2022-06-23 13:10:17.757826
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule("Test")
    assert vars(obj) is not None

# Generated at 2022-06-23 13:10:18.921820
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 13:10:20.760044
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    s = StrategyModule(tqm)
    assert s._host_pinned == True

# Generated at 2022-06-23 13:10:21.414635
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   pass

# Generated at 2022-06-23 13:10:23.104652
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule("")
    assert module._host_pinned

# Generated at 2022-06-23 13:10:24.752404
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    StrategyModule(tqm)


# Generated at 2022-06-23 13:10:26.921372
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:10:27.693401
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-23 13:10:33.778130
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Choosing sequential strategy to avoid concurrent execution of tasks
    tqm = FreeStrategyModule("sequential")
    # Creating an instance of class StrategyModule
    strategy_object = StrategyModule(tqm)
    # Asserting if the constructor of the class StrategyModule returned an instance of the class
    assert isinstance(strategy_object, StrategyModule)
    # Asserting if the constructor of the class StrategyModule returned an instance of the class
    # StrategyModule inherits from class FreeStrategyModule
    assert isinstance(strategy_object, FreeStrategyModule)

# Generated at 2022-06-23 13:10:35.740405
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    lst = [1,2,3]
    val = StrategyModule(lst)
    assert val._host_pinned==True

# Generated at 2022-06-23 13:10:36.187586
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	pass

# Generated at 2022-06-23 13:10:40.920894
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    strategy_instance = ansible.plugins.strategy.host_pinned.StrategyModule(tqm=None)
    assert strategy_instance is not None

# Generated at 2022-06-23 13:10:43.030972
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("strategy_module")
    assert(strategy_module._host_pinned == True)

# Generated at 2022-06-23 13:10:45.266012
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm.set_options(forks=1, host_pinned=True)
    StrategyModule(tqm)


# Generated at 2022-06-23 13:10:47.225946
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule("tqm")

# Generated at 2022-06-23 13:10:49.371300
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    a = ansible.plugins.strategy.host_pinned.StrategyModule(None)
    assert a._host_pinned == True

# Generated at 2022-06-23 13:10:50.357403
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:10:50.891560
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-23 13:10:52.067527
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:10:53.915753
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('tqm') is not None


# Generated at 2022-06-23 13:10:55.238996
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = {}
  StrategyModule(tqm)

# Generated at 2022-06-23 13:10:57.935731
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule.__init__.__doc__)

# Generated at 2022-06-23 13:11:01.324318
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned as strategy_host_pinned
    sm = strategy_host_pinned.StrategyModule(tqm=None)
    return sm

if __name__ == '__main__':
    sm = test_StrategyModule()

# Generated at 2022-06-23 13:11:02.283454
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:11:03.564494
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(1)

# Generated at 2022-06-23 13:11:05.253557
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert len(strategy) == 1
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:11:07.536200
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'

# Generated at 2022-06-23 13:11:11.248788
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    tqm = AnsibleTaskQueueManager()
    strategy = StrategyModule(tqm)
    assert strategy is not None
    assert strategy._host_pinned
    assert strategy._tqm == tqm
    assert strategy._name == 'host_pinned'



# Generated at 2022-06-23 13:11:11.784196
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:11:14.267456
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule([])
    assert module.__class__.__name__ == 'StrategyModule'
    assert module._host_pinned == True
    assert module._tqm == []

# Generated at 2022-06-23 13:11:22.357580
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest

    class TestStrategyModule(unittest.TestCase):

        def test__init__(self):
            import mock
            import ansible.plugins.task.dummy
            tqm = mock.MagicMock()
            tqm._initialize_processes.return_value = None
            tqm._finalize_processes.return_value = None
            tqm.done_hosts = []
            tqm._send_internal_inventory.return_value = None
            tqm._send_internal_task_start.return_value = None
            sm = StrategyModule(tqm)

            # Ensure that constructor calls _initialize_processes()

# Generated at 2022-06-23 13:11:26.736956
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    def host_all_done(self):
        return True

    strategy = StrategyModule(None)
    strategy._wait_on_pending_results = host_all_done
    strategy._tqm = None

    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:11:29.178277
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    m = StrategyModule(tqm=None)
    assert m._host_pinned == True

# Generated at 2022-06-23 13:11:30.837915
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert(strategy._host_pinned == True)

# Generated at 2022-06-23 13:11:31.440326
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:11:33.970776
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm = None)
    assert strategy_module._host_pinned

# Generated at 2022-06-23 13:11:36.440912
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned_ob = StrategyModule()
    assert hasattr(host_pinned_ob, '_host_pinned')

# Generated at 2022-06-23 13:11:42.406008
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''Create a StrategyModule object, then check its attributes are initialized correctly.
    '''
    from ansible.plugins.strategy.host_pinned import StrategyModule
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module._tqm is None
    assert strategy_module._display is not None
    assert strategy_module._inventory is None
    assert strategy_module._variable_manager is None
    assert strategy_module._loader is None
    assert strategy_module._final_q is not None
    assert strategy_module._blocked_hosts is not None
    assert strategy_module._workers is not None
    assert strategy_module._connection_info is not None
    assert strategy_module._notified_handlers is not None
    assert strategy_module._fail_queue is not None

# Generated at 2022-06-23 13:11:52.659960
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task_queue_manager = None
    strategy = StrategyModule(task_queue_manager)
    assert strategy._display is not None

# Test that free strategy is also loaded
from ansible.plugins.strategy import get_strategy_loader
assert 'free' in get_strategy_loader()

from ansible.utils.display import Display
display = Display()
from six import iteritems
from ansible.parsing.dataloader import DataLoader
from ansible.vars.manager import VariableManager
from ansible.inventory.manager import InventoryManager
from ansible.playbook.play import Play
from ansible.executor.task_queue_manager import TaskQueueManager
from ansible.executor.playbook_executor import PlaybookExecutor
#from ansible.plugins import strategy_loader
import ansible.constants as C

pass

# Generated at 2022-06-23 13:11:56.196950
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:11:58.220603
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert isinstance(strategy_module, StrategyModule)

# Generated at 2022-06-23 13:12:01.124247
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Execution of test_StrategyModule ...')
    tqm = None
    sm = StrategyModule(tqm)


# Tests that run on this file

# Generated at 2022-06-23 13:12:02.543854
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule.__init__()


# Generated at 2022-06-23 13:12:05.063880
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    host_pinned = StrategyModule(tqm)

    assert host_pinned._host_pinned == True