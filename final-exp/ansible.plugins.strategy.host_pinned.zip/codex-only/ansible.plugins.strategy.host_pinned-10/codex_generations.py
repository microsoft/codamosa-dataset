

# Generated at 2022-06-23 13:02:02.249406
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #print(dir(StrategyModule))
    assert StrategyModule.__name__ == "StrategyModule"

# Generated at 2022-06-23 13:02:05.333311
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from mock import Mock
    tqm = Mock()
    s = StrategyModule(tqm)
    assert(s._host_pinned)

# Generated at 2022-06-23 13:02:08.044482
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    sm = StrategyModule(tqm)
    assert sm.tqm == tqm
    assert sm._host_pinned == True


# Generated at 2022-06-23 13:02:08.882166
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-23 13:02:10.606587
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    assert obj.get_host_pinned() == True

# Generated at 2022-06-23 13:02:14.098691
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tm = FreeStrategyModule(tqm=None)
    sm = StrategyModule(tqm=tm)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:02:18.847876
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.utils.display import Display
    display = Display()
    task_queue_manager = 0
    strategy_module = StrategyModule(task_queue_manager)

# Generated at 2022-06-23 13:02:20.922205
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_module = StrategyModule('host_pinned')
    assert my_module._host_pinned == True

# Generated at 2022-06-23 13:02:23.821522
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned is True

# Generated at 2022-06-23 13:02:33.804795
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import playbook

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler

    from ansible.inventory.manager import InventoryManager

    from ansible.vars.manager import VariableManager

    from ansible.executor.task_queue_manager import TaskQueueManager

    #playbook_path = os.path.join(os.path.dirname(__file__), '../../examples/host_pinned.yml')
    #pbex = PlaybookExecutor(playbooks=[playbook_path], inventory=inventory, variable_manager=variable_manager, loader=loader, options=options, passwords=dict())


# Generated at 2022-06-23 13:02:34.623250
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True, "It works!"

# Generated at 2022-06-23 13:02:35.927034
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule('tqm')

# Generated at 2022-06-23 13:02:37.301216
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule('tqm')
    assert strategy._host_pinned == True


# Generated at 2022-06-23 13:02:38.222668
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

test_StrategyModule()

# Generated at 2022-06-23 13:02:41.424404
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'ansible.executor.task_queue_manager.TaskQueueManager()'
    test = StrategyModule(tqm)
    assert type(test) == StrategyModule

# Generated at 2022-06-23 13:02:44.138298
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    tqm = FreeStrategyModule(tqm)
    self._host_pinned = True
    return

# Generated at 2022-06-23 13:02:45.929907
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule("self") == None

# Generated at 2022-06-23 13:02:49.997687
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test'
    str_mod = StrategyModule(tqm)
    assert str_mod.tqm == tqm
    assert type(str_mod) == StrategyModule


# Generated at 2022-06-23 13:02:51.679131
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    x = StrategyModule(tqm)
    assert x._host_pinned == True



# Generated at 2022-06-23 13:02:52.367368
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	pass



# Generated at 2022-06-23 13:02:54.764323
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    arg1 = None
    arg2 = None
    obj = StrategyModule(arg1, arg2)
    assert obj is not None

# Generated at 2022-06-23 13:02:55.651577
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:02:56.286785
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-23 13:03:00.881349
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy_module = StrategyModule(tqm)
    assert strategy_module._tqm == tqm
    assert strategy_module.get_name() == 'host_pinned'
    assert strategy_module.get_host_pinned() == True

# Generated at 2022-06-23 13:03:03.021125
# Unit test for constructor of class StrategyModule
def test_StrategyModule():  
    x = StrategyModule(tqm="tqm")


# Generated at 2022-06-23 13:03:04.712056
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:03:05.277535
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModu

# Generated at 2022-06-23 13:03:05.723578
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:03:06.903296
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:03:08.401750
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'


# Generated at 2022-06-23 13:03:10.744685
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    test_strategy_module = StrategyModule(tqm)
    assert test_strategy_module._host_pinned == True

# Generated at 2022-06-23 13:03:12.217287
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm='tqm')._host_pinned

# Generated at 2022-06-23 13:03:14.277683
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global StrategyModule

    StrategyModule = StrategyModule(tqm=None)

    assert StrategyModule is not None

# Generated at 2022-06-23 13:03:15.672568
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"


# Generated at 2022-06-23 13:03:16.771434
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)

# Generated at 2022-06-23 13:03:18.103104
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule(tqm=None)
    assert isinstance(mod._host_pinned, bool)

# Generated at 2022-06-23 13:03:20.526895
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create the object and ensure that _host_pinned is set to True
    obj = StrategyModule(None)
    assert obj._host_pinned

# Generated at 2022-06-23 13:03:23.319345
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    t_StrategyModule = StrategyModule("tqm")
    assert t_StrategyModule._host_pinned == True


# Generated at 2022-06-23 13:03:25.860176
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule()
    assert a._host_pinned == True, 'Default value of _host_pinned does not match'

# Generated at 2022-06-23 13:03:27.161845
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    assert FreeStrategyModule
    assert Display
    strategyModule = StrategyModule()
    assert(strategyModule)

# Generated at 2022-06-23 13:03:29.599087
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = {'host1': 'localhost'}
    opts = {'hosts': host}
    tqm = {'opts': opts, 'hosts': host}
    sm = StrategyModule(tqm)
    assert sm._host_pinned is True


# Generated at 2022-06-23 13:03:31.238022
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('in StrategyModule test_strategy')

# Generated at 2022-06-23 13:03:32.040381
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:03:33.455808
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule("")
    assert sm._host_pinned is True

# Generated at 2022-06-23 13:03:34.675481
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule, object)

# Generated at 2022-06-23 13:03:36.071853
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  ansible.plugins.strategy.host_pinned.StrategyModule()

# Generated at 2022-06-23 13:03:37.720883
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test with tqm = None
    StrategyModule(tqm = None)

# Generated at 2022-06-23 13:03:39.294475
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_obj = StrategyModule("tqm")
    assert strategy_module_obj is not None

# Generated at 2022-06-23 13:03:40.701803
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tm = StrategyModule(None)
    assert tm._host_pinned == True
# End of unit test

# Generated at 2022-06-23 13:03:41.608492
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 13:03:47.772980
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Options():
        def __init__(self):
            self.serial = 0
            self.forks = 5
    class TQM():
        def __init__(self):
            self._options = Options()
            self._inventory = None
            self._workers = []
            self._callbacks = None
            self._final_q = None
    return StrategyModule(TQM())

# Generated at 2022-06-23 13:03:48.927621
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert getattr(StrategyModule, '_host_pinned', False)

# Generated at 2022-06-23 13:03:50.960579
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:03:53.379330
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = []
  sm = StrategyModule(tqm)
  assert sm._host_pinned == True

# Generated at 2022-06-23 13:04:04.671336
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Make sure the required methods are present
assert hasattr(StrategyModule, "get_host_list"), \
    "StrategyModule is missing get_host_list method"
assert hasattr(StrategyModule, "get_next_task_lock"), \
    "StrategyModule is missing get_next_task_lock method"
assert hasattr(StrategyModule, "get_next_playbook_lock"), \
    "StrategyModule is missing get_next_playbook_lock method"
assert hasattr(StrategyModule, "_queue_task"), \
    "StrategyModule is missing _queue_task method"
assert hasattr(StrategyModule, "_wait_on_pending_results"), \
    "StrategyModule is missing _wait_on_pending_results method"

# Generated at 2022-06-23 13:04:06.085725
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-23 13:04:06.746604
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:04:07.687071
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_StrategyModule(object)
    pass

# Generated at 2022-06-23 13:04:08.746756
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    assert obj._host_pinned == True

# Generated at 2022-06-23 13:04:09.961821
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    foo = StrategyModule
    assert foo.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:04:14.183152
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = unittest.mock.Mock()
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None
    assert strategy_module._tqm is tqm


# Generated at 2022-06-23 13:04:24.451511
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.callback.default import CallbackModule
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    play_source =  dict(
        name = "Ansible Play 0",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )
    play = Play().load(play_source, variable_manager={}, loader=None)
    tqm = None

# Generated at 2022-06-23 13:04:26.713631
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:04:27.253916
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:04:30.201625
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #test_strategy_module = StrategyModule()
    #assert test_strategy_module is not None
    assert StrategyModule


# unit test for testing the above class

# Generated at 2022-06-23 13:04:31.820267
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-23 13:04:34.766732
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategyModule = StrategyModule(tqm)
    assert strategyModule._host_pinned == True
    assert strategyModule._tqm == tqm

# Generated at 2022-06-23 13:04:35.872696
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-23 13:04:36.615098
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:04:40.882609
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    original_display = StrategyModule.display
    try:
        StrategyModule.display = display
        sm_obj = StrategyModule(tqm=None)
        assert sm_obj._host_pinned == True
    finally:
        StrategyModule.display = original_display

# Generated at 2022-06-23 13:04:41.582667
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:04:48.447094
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_queue_manager import TaskQueueManager
    mgr = TaskQueueManager(
        inventory='tests/inventory',
        hosts_file='tests/hosts_file',
        options=None,
        loader=None,
        variable_manager=None,
        stdout_callback='default',
    )
    strategyModule = StrategyModule(tqm=mgr)
    assert strategyModule._host_pinned is True

# Generated at 2022-06-23 13:04:49.786454
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:04:51.313258
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global StrategyModule
    StrategyModule.__init__(self, tqm)

# Generated at 2022-06-23 13:04:53.595816
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    tqm = TaskQueueManager(None, None, None)
    s = StrategyModule(tqm)
    assert s


# Generated at 2022-06-23 13:04:55.450163
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock
    m = mock.MagicMock()
    StrategyModule(tqm=m)



# Generated at 2022-06-23 13:04:56.964888
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MagicMock()
    StrategyModule(tqm)

# Generated at 2022-06-23 13:04:58.855804
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'


# Generated at 2022-06-23 13:04:59.473940
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  StrategyModule()

# Generated at 2022-06-23 13:05:01.343776
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MagicMock()
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned is True

# Generated at 2022-06-23 13:05:02.748210
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-23 13:05:04.330103
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)._host_pinned



# Generated at 2022-06-23 13:05:08.010301
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Instantiate the class
    tqm = object()
    class_instance = StrategyModule(tqm)
    assert class_instance._host_pinned == True
    assert class_instance._display == display

# Generated at 2022-06-23 13:05:09.072778
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    return strategy_module._host_pinned


# Generated at 2022-06-23 13:05:19.364361
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible import context
    options = context.CLIARGS

    loader = DataLoader()  # Takes care of finding and reading yaml, json and ini files
    variable_manager = VariableManager()  # Stores variables from all the different places

    # Load inventory_manager
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager

# Generated at 2022-06-23 13:05:22.853151
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule("test")
    return_val = StrategyModule(tqm)
    # Successful construction of class StrategyModule
    assert(return_val._host_pinned==True)


# vim: set expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-23 13:05:24.501518
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm = None)
    assert module._host_pinned == True

# Generated at 2022-06-23 13:05:26.776081
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test constructor of class StrategyModule
    print("Testing constructor of class StrategyModule")
    assert StrategyModule(tqm = "test")
    return


# Generated at 2022-06-23 13:05:27.930578
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy
    assert strategy._host_pinned == 1

# Generated at 2022-06-23 13:05:29.279963
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:05:30.839292
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm)

# Generated at 2022-06-23 13:05:32.972001
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = mock.MagicMock()
    obj = StrategyModule(tqm)


if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-23 13:05:34.617045
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing Strategy Module")
    a = StrategyModule(tqm)
    a

# Generated at 2022-06-23 13:05:36.213375
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    sm = StrategyModule(tqm)

# Generated at 2022-06-23 13:05:38.203291
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'



# Generated at 2022-06-23 13:05:41.142843
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    TQM = type('TQM', (object,), {})
    strategy_module = StrategyModule(TQM())
    strategy_module.__init__()

# Generated at 2022-06-23 13:05:44.215703
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == FreeStrategyModule.__doc__, 'StrategyModule.__doc__ needs to be the same as FreeStrategyModule.__doc__'

# Generated at 2022-06-23 13:05:47.686324
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager('/home/matthias/ansible/lib/ansible/executor/tasks.py')
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned is True

# Generated at 2022-06-23 13:05:48.377318
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:05:49.016371
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule()

# Generated at 2022-06-23 13:05:51.963661
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(None)
    assert module._host_pinned is True

# Unit tests for class StrategyModule methods

# Generated at 2022-06-23 13:06:00.546589
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins
    print(ansible.plugins.strategy.host_pinned.StrategyModule)
    #import ansible.plugins.strategy.host_pinned
    #print(ansible.plugins.strategy.host_pinned.StrategyModule)
    #print(ansible.plugins.strategy.host_pinned.__name__)
    from ansible.plugins.strategy.host_pinned import StrategyModule
    print(StrategyModule)
    #print(StrategyModule.__name__)
    #s = StrategyModule()
    #s.run()


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:06:02.456287
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    obj = StrategyModule(tqm)
    assert obj._host_pinned == True

# Generated at 2022-06-23 13:06:05.065184
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #TODO: Should do an actual test
    tqm = {'max_hosts':0}
    strategymodule = StrategyModule(tqm)

# Generated at 2022-06-23 13:06:06.160998
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    m = StrategyModule(tqm='tqm')
    assert m._host_pinned  # pylint: disable=protected-access

# Generated at 2022-06-23 13:06:09.120166
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    strategy = StrategyModule( tqm = None )
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:06:12.003362
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    tqm = 'tqm'
    strategy_module = StrategyModule( tqm)
    assert strategy_module._host_pinned

# Generated at 2022-06-23 13:06:16.461760
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test object creation without any parameter
    strategy_obj = StrategyModule()
    assert strategy_obj.__init__() == None

    # test object creation with a parameter
    strategy_obj2 = StrategyModule(tqm)
    assert strategy_obj2.__init__(tqm) == None

# Generated at 2022-06-23 13:06:18.148345
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {'something': 'something else'}
    StrategyModule(tqm)

# Generated at 2022-06-23 13:06:19.768784
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(Display())
    assert module is not None
    module.__init__(Display()) # calling the constructor twice is an error here

# Generated at 2022-06-23 13:06:25.615140
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import sys
    import copy
    import ansible
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyModule

    class TestOptions(object):
        def __init__(self):
            self.connection = 'local'
            self.module_path = None
            self.forks = 5
            self.become = False
            self.become_method = None
            self.become_user = None
            self.check = False
            self.listhosts = None
            self.listtasks = None
            self.listtags

# Generated at 2022-06-23 13:06:27.071775
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:06:27.889962
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:06:29.018961
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 13:06:32.380206
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module_test = StrategyModule(1)
    assert module_test._host_pinned
    assert module_test._batch_size == 1
    assert module_test._active_hosts == {}
    assert module_test._tqm.run_state == {}


# Generated at 2022-06-23 13:06:40.811916
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # import modules
    import json
    import sys
    from collections import namedtuple

    from ansible.plugins.strategy.host_pinned import StrategyModule

    # create namedtuple objects to replace object created by the test module
    Options = namedtuple('Options', ['listtags', 'listtasks', 'listhosts', 'syntax', 'connection','module_path', 'forks', 'remote_user', 'private_key_file', 'ssh_common_args', 'ssh_extra_args', 'sftp_extra_args', 'scp_extra_args', 'become', 'become_method', 'become_user', 'verbosity', 'check', 'diff'])

# Generated at 2022-06-23 13:06:41.804327
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-23 13:06:46.877456
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Test:
        def __init__(self):
            self.args = []

    tqm = Test()
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None
    assert strategy_module._host_pinned is True

# Generated at 2022-06-23 13:06:47.489072
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:06:54.838622
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Init tqm
    import sys
    import os

    import ansible.constants as C
    import ansible.context
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.stats import AggregateStats
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_group_vars
    from ansible.utils.vars import load_host_vars
    from ansible.utils.vars import load_vars
    from ansible.utils.display import Display

    display = Display()

    ansible.context.CLIARGS = {}

# Generated at 2022-06-23 13:06:55.874394
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)



# Generated at 2022-06-23 13:06:56.469855
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:06:59.456099
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    strategy_module = StrategyModule()

# Generated at 2022-06-23 13:07:01.057065
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__


if __name__ == '__main__':
    # Run this unit test independently
    test_StrategyModule()

# Generated at 2022-06-23 13:07:01.897439
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)

# Generated at 2022-06-23 13:07:04.403785
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    display.debug("Constructor of class StrategyModule works correctly")

# Generated at 2022-06-23 13:07:05.469281
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:07:09.276927
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.verbosity = 3
    tqm = MagicMock()
    x = StrategyModule(tqm)
    assert x.tqm == tqm
    assert x._host_pinned == True

# Generated at 2022-06-23 13:07:13.948603
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global display
    display = Display()
    display.verbosity = 2
    temporary_tqm_object = StrategyModule('test')
    try:
        assert temporary_tqm_object._host_pinned == True
    except AssertionError:
        if display.verbosity >= 2:
            print( "Unit test for constructor failed." )
        return False
    if display.verbosity >= 2:
        print( "Unit test for constructor passed." )
    return True

# Generated at 2022-06-23 13:07:16.904205
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm)
    construct_test = (module._host_pinned)
    assert construct_test == True


# Generated at 2022-06-23 13:07:17.887829
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule("tqm")

# Generated at 2022-06-23 13:07:18.485618
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:07:20.493821
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    result = StrategyModule(tqm)
    assert result._host_pinned
    assert result is not None

# Generated at 2022-06-23 13:07:21.062127
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:07:22.188702
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule("test_tqm")

# Generated at 2022-06-23 13:07:23.580516
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test = StrategyModule(tqm="tqm")
    assert test._host_pinned == True

# Generated at 2022-06-23 13:07:24.792673
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm

# Generated at 2022-06-23 13:07:28.373415
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule('tqm')
    assert strategy._host_pinned == True
    assert hasattr(strategy, '_host_pinned')

# Generated at 2022-06-23 13:07:29.670785
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__

    host_pinned = True
    module = StrategyModule(host_pinned)
    assert isinstance(module, StrategyModule)

# Generated at 2022-06-23 13:07:32.847202
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule 
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert(strategy_module is not None)



# Generated at 2022-06-23 13:07:36.241438
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy._name == 'host_pinned'
    assert strategy._host_pinned == True
    assert strategy._supports_check_mode == False


# Generated at 2022-06-23 13:07:36.836625
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:07:38.619027
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:07:41.364868
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    strategy_module = StrategyModule(tqm)
    assert strategy_module._tqm == tqm

# Generated at 2022-06-23 13:07:44.165548
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule()
    assert a._host_pinned == True
    assert a._blocked_hosts == []
    assert a._pending_results == []
    assert a._display == Display()


# Generated at 2022-06-23 13:07:53.587662
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution
    import ansible.plugins.loader as plugins
    import ansible.inventory.manager as inventory
    import ansible.vars.manager

    display = Display()

    # AnsibleOptions
    #from ansible.utils.display import Display
    #from ansible.options import Options
    #from ansible.parsing.dataloader import DataLoader
    #from ansible.vars.manager import VariableManager
    #from ansible.inventory.manager import InventoryManager
    #from ansible.play

# Generated at 2022-06-23 13:08:04.004120
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import sys
    import random
    random.seed(1)
    sys.path.append('/test')
    import __main__ as test_main
    test_main.DEFAULT_RANDOMIZE_PATHS = False
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True
    assert strategy._batch_size == 'all'
    assert strategy._display == Display()
    assert strategy._tqm == None
    assert strategy._inventory == None
    assert strategy._variable_manager == None
    assert strategy._loader == None
    assert strategy._pending_results == 0
    assert strategy._loading_failures_per_host == {}
    assert strategy._host_pinned == True
    assert strategy._blockers == set()
    assert strategy._running_finalizers == set

# Generated at 2022-06-23 13:08:06.659780
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert isinstance(strategy, StrategyModule)
    assert isinstance(strategy, FreeStrategyModule)
    assert strategy._host_pinned

# Generated at 2022-06-23 13:08:09.397343
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "tqm"
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:08:10.068249
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:08:12.734529
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ''
    test = StrategyModule(tqm)
    assert test._host_pinned == True
    return

# Generated at 2022-06-23 13:08:13.397371
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:08:14.656089
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(1).__init__(1) == None


# Generated at 2022-06-23 13:08:17.030913
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ansible.utils.plugins.strategy_loader.get('StrategyModule', 'setup')
    StrategyModule(tqm)


# Generated at 2022-06-23 13:08:17.940363
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm="tqm")

# Generated at 2022-06-23 13:08:19.183987
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert not StrategyModule.__init__

# Generated at 2022-06-23 13:08:20.728364
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    TestStrategyModule = StrategyModule()
    assert TestStrategyModule

# Generated at 2022-06-23 13:08:24.070667
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #test_StrategyModule is the unit test 
    #which is using unittest
    import unittest

    unittest.TestCase.assertRaises = assertRaises
    unittest.main(module='test_host_pinned')


if __name__ == '__main__':
    #import doctest
    #doctest.testmod()
    unittest.main()

# Generated at 2022-06-23 13:08:34.345734
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from builtins import dict
    from builtins import object
    from ansible import constants as C
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    class FakeHost():
        def __init__(self, name):
            self.name = name
        def get_name(self):
            return self.name
    class FakeVarMgr():
        def __init__(self):
            self.vars_cache = dict()
        def get_vars(self, host=None):
            if host:
                return self.get_vars(host=None)
            else:
                return self.vars_cache

# Generated at 2022-06-23 13:08:37.380199
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Unit test for constructor of class StrategyModule
    """
    d = Display()
    sm = StrategyModule(d)
    assert sm._host_pinned == True



# Generated at 2022-06-23 13:08:39.277222
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FakePlayContext()
    StrategyModule(tqm)


# Generated at 2022-06-23 13:08:41.340902
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x_StrategyModule = StrategyModule(tqm=None)
    assert x_StrategyModule != None, 'Object should not be None'

# Generated at 2022-06-23 13:08:47.669824
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

#    def __init__(self, tqm):
#        super(StrategyModule, self).__init__(tqm)
#        self._host_pinned = True
#        self.display = Display()

    tqm = None
    d = Display()
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:08:48.421509
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None) is not None

# Generated at 2022-06-23 13:08:58.792366
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  strategy_module = StrategyModule('')
  assert strategy_module._host_pinned
  assert strategy_module._callbacks == {}
  assert strategy_module._display == display
  assert strategy_module._finalized == False
  assert strategy_module._inventory == ''
  assert strategy_module._loader == ''
  assert strategy_module._module_vars == {}
  assert strategy_module._play_context == {}
  assert strategy_module._play
  assert strategy_module._play_vars == {}
  assert strategy_module._pending_results == []
  assert strategy_module._subset
  assert strategy_module._task_queue == []
  assert strategy_module._var_cache == {}
  assert strategy_module._variable_manager == ''


# Generated at 2022-06-23 13:08:59.738926
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule("tqm")._host_pinned

# Generated at 2022-06-23 13:09:01.379258
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:09:02.377806
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert (strategy_module._host_pinned == True)

# Generated at 2022-06-23 13:09:03.074838
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule()

# Generated at 2022-06-23 13:09:08.146469
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import __main__

    tqm = {}
    sm = StrategyModule(tqm)

    assert sm.tqm == {}
    assert sm._keep_remote_files == False
    assert sm._host_pinned == True
    assert sm._unreachable_limit == 3
    assert sm._recursion_limit == 10
    assert sm._display == display
    assert sm._current_words == 'a'



# Generated at 2022-06-23 13:09:10.581160
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = []
    obj = StrategyModule(tqm)
    assert obj._host_pinned == True

# Generated at 2022-06-23 13:09:11.859397
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-23 13:09:12.539953
# Unit test for constructor of class StrategyModule
def test_StrategyModule(): 
    pass

# Generated at 2022-06-23 13:09:13.103236
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:09:15.195276
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:09:16.064623
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('tqm') != None

# Generated at 2022-06-23 13:09:18.369117
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    m = StrategyModule(tqm=None)
    assert m._host_pinned is True


# Generated at 2022-06-23 13:09:21.694888
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    try:
        sm = StrategyModule(tqm)
        test_result = True
    except:
        test_result = False
    assert test_result

# Generated at 2022-06-23 13:09:22.314588
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:09:23.555292
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 13:09:32.577636
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.strategy.host_pinned import StrategyModule as Host_pinnedStrategyModule

    from ansible import constants as C
    from ansible.plugins.loader import callback_loader, module_loader

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    from ansible.inventory.manager import InventoryManager

    from ansible.vars.manager import VariableManager

    #########
    # basic checks
    assert issubclass(StrategyModule, object)
    assert issubclass(Host_pinnedStrategyModule, StrategyModule)

    ##########
    # implement test class
   

# Generated at 2022-06-23 13:09:34.454573
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:09:36.052735
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert (isinstance(FreeStrategyModule(), StrategyModule))

# Generated at 2022-06-23 13:09:38.881988
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager('ansible', 'host_pinned')
    sm = StrategyModule(tqm)
    assert sm is not None

# Generated at 2022-06-23 13:09:41.296130
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = True
    strategy_m = StrategyModule(tqm)
    assert strategy_m._host_pinned == True

# Generated at 2022-06-23 13:09:43.170311
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:09:44.739033
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test for constructor of class StrategyModule
    '''
    assert StrategyModule

# Generated at 2022-06-23 13:09:49.852721
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.utils.display import Display
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    StrategyModule(Display())
    assert FreeStrategyModule()

# Generated at 2022-06-23 13:09:53.067097
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule_instance = StrategyModule("tqm")
    assert isinstance(strategyModule_instance, StrategyModule)
    assert strategyModule_instance.__class__.__name__ == 'StrategyModule'
    assert strategyModule_instance._host_pinned == True

# Generated at 2022-06-23 13:09:56.326699
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'testObj'
    test_strat = StrategyModule(tqm)
    assert test_strat._host_pinned == True

# Generated at 2022-06-23 13:09:58.942364
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned is True

# Generated at 2022-06-23 13:09:59.694114
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:10:02.401579
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    st=StrategyModule("TestA")
    print("class StrategyModule constructor test done")


# Unit test of class StrategyModule

# Generated at 2022-06-23 13:10:06.543279
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test for sub class of an abstract class
    assert issubclass(StrategyModule, FreeStrategyModule)

    task_queue_manager = None
    strategy = StrategyModule(task_queue_manager)
    # Test attribute of class StrategyModule
    assert strategy._host_pinned is True

# Generated at 2022-06-23 13:10:07.630089
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule(tqm)

# Generated at 2022-06-23 13:10:09.277688
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Tests global variables
    assert isinstance(display, Display)

# Generated at 2022-06-23 13:10:11.011587
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm=None)
    assert module._host_pinned is True

# Generated at 2022-06-23 13:10:13.219351
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)._host_pinned == True
    assert FreeStrategyModule(None)._host_pinned == False

# Generated at 2022-06-23 13:10:15.157587
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned

# Generated at 2022-06-23 13:10:22.893941
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Declare variables for testing
    display = Display()
    tqm = None
    
    # Call constructor with valid arguments
    strategy_module = StrategyModule(tqm)

    # Call constructor with invalid arguments
    try:
        strategy_module = StrategyModule()
    except TypeError:
        pass
    else:
        assert False
    
    try:
        strategy_module = StrategyModule(1)
    except TypeError:
        pass
    else:
        assert False

if __name__ == '__main__':
    # Call unit tests
    test_StrategyModule()

# Generated at 2022-06-23 13:10:23.523820
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:10:34.060579
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-23 13:10:36.746807
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    StrategyModule._load_plugins()
    assert 'host_pinned' in StrategyModule._strategy_plugins

# Generated at 2022-06-23 13:10:37.877900
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:10:38.837606
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(1)

# Generated at 2022-06-23 13:10:41.497420
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__mro__ == (StrategyModule, FreeStrategyModule, object)

# Generated at 2022-06-23 13:10:43.388388
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule('test')
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:10:44.705989
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)



# Generated at 2022-06-23 13:10:45.957377
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-23 13:10:48.244693
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__ != FreeStrategyModule.__init__
    assert StrategyModule.__init__.__doc__ == FreeStrategyModule.__init__.__doc__
    assert StrategyModule.__init__.__module__ == FreeStrategyModule.__init__.__module__

# Generated at 2022-06-23 13:10:48.835541
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-23 13:10:52.610434
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Constructs a StrategyModule object and returns it.
    """
    strategy = StrategyModule(tqm="test")
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:10:54.418482
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    obj = StrategyModule(tqm)

# Generated at 2022-06-23 13:10:56.205651
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  strategy = StrategyModule(None)
  assert strategy._host_pinned

# Generated at 2022-06-23 13:10:59.612468
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test_Stratagem_Module_instance_creation()
    tqm = 'tqm'
    StrategyModule(tqm)

# Generated at 2022-06-23 13:11:00.436585
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-23 13:11:01.052628
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:11:01.850900
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	assert True == True

# Generated at 2022-06-23 13:11:02.797606
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:11:12.804003
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    import ansible.plugins.strategy.host_pinned
    import ansible.playbook.task_queue_manager
    import ansible.constants
    import ansible.playbook.play
    import ansible.playbook.block
    import ansible.playbook.role


# Generated at 2022-06-23 13:11:13.773050
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(1)

# Generated at 2022-06-23 13:11:22.012204
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block 
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueue

# Generated at 2022-06-23 13:11:24.068135
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   strategy_module = StrategyModule("tqm")
   assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:11:30.272955
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from collections import namedtuple

    class Tqm():
        def __init__(self):
            self.hostvars = {}

    tqm = Tqm()

    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned is True, "host_pinned is True"

# Generated at 2022-06-23 13:11:31.620599
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = []
    StrategyModule(tqm)

# Generated at 2022-06-23 13:11:34.101995
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    my_StrategyModule = StrategyModule()
    assert isinstance(my_StrategyModule._host_pinned, bool)

# Generated at 2022-06-23 13:11:34.766946
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:11:36.668245
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm = 'test')
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:11:37.402150
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:11:38.811377
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:11:39.944409
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule.__init__)

# Generated at 2022-06-23 13:11:41.811454
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strat = StrategyModule(None)
    assert strat._host_pinned == True

# Generated at 2022-06-23 13:11:46.887449
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #Instantiate a fake Task Queue Manager.
    tqm = None
    #Instantiate the Strategy Module
    strategy_module = StrategyModule(tqm)
    #Test to see if initializations were populated
    assert strategy_module._host_pinned

# Generated at 2022-06-23 13:11:50.726602
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.executor.task_queue_manager
    StrategyModule(ansible.executor.task_queue_manager.TaskQueueManager(0, 'default', 0))

# Generated at 2022-06-23 13:11:53.093534
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned as strategy
    s = strategy.StrategyModule(None)
    assert s._host_pinned


# Generated at 2022-06-23 13:11:55.607890
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    strategy = StrategyModule('Test')
    assert (strategy)

# Generated at 2022-06-23 13:11:56.392623
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:12:05.903552
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import json
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from six import StringIO
    
    stdout_save = StringIO()
    
    # Create inventory
    inventory = Inventory(
        loader=None,
        variable_manager=None,
        host_list=['localhost']
    )
    
    # Create variable manager
    variable_manager = None
    
    # Create options