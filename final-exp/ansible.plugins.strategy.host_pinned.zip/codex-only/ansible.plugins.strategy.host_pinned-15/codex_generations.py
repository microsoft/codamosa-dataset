

# Generated at 2022-06-23 13:01:59.902088
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-23 13:02:02.249123
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:02:13.258502
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import callback_loader


# Generated at 2022-06-23 13:02:19.406294
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ Test to ensure args are processed correctly """
    tqm = MagicMock()
    tqm._hosts_remaining_results = ["success"]
    display = MagicMock()

    # inventory with one host
    inventory = MagicMock()
    inventory.get_hosts.return_value = ["host1"]

    # play with two tasks
    play = MagicMock()
    play.get_variable_manager.return_value = "variable_manager"
    play.tasks = ["task1", "task2"]

    # task1 has two handlers
    task1 = MagicMock()
    task1.notify = ["handler1", "handler2"]

    play.tasks = [task1]

    strategyModule = StrategyModule(tqm)

# Generated at 2022-06-23 13:02:20.569975
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    pass

# Generated at 2022-06-23 13:02:24.916803
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule


if __name__ == '__main__':
    from ansible.plugins.strategy.host_pinned import StrategyModule
    t = StrategyModule()

# Generated at 2022-06-23 13:02:26.994680
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule()

# Generated at 2022-06-23 13:02:27.706194
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:02:30.741998
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test StrategyModule.__init__()
    tqm = nodata
    strategy = StrategyModule(tqm)
    # Check attributes
    assert strategy._host_pinned

# Generated at 2022-06-23 13:02:39.182322
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.config.manager import ConfigManager
    from ansible.playbook.play import Play
    inventory = ConfigManager().get_inventory_for_hosts('localhost')
    play_source = dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='debug', args=dict(msg='{{inventory_hostname}}: Hello world!'))),
            dict(action=dict(module='debug', args=dict(msg='{{inventory_hostname}}: Goodbye cruel world!'))),
        ]
    )
    play = Play().load(play_source, variable_manager=inventory.get_variable_manager(), loader=inventory.get_loader())
   

# Generated at 2022-06-23 13:02:42.146784
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None
    assert StrategyModule.__init__ is not None
    assert StrategyModule.show_custom_stats is not None

# Generated at 2022-06-23 13:02:45.712510
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ansible.utils.module_docs.AnsibleModuleDocs()
    strategy = StrategyModule(tqm)
    assert strategy.__class__.__name__ == 'StrategyModule'


# Generated at 2022-06-23 13:02:47.138297
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a=StrategyModule
    assert a is not None

# Generated at 2022-06-23 13:02:56.451869
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy import linear
    import ansible.plugins.strategy
    import ansible.plugins.strategy_plugins

    # Get current hash value of ansible.plugins.strategy
    original_strategy_hash = None
    try:
        original_strategy_hash = linear.__hash__
    except AttributeError:
        pass

    # Get current hash value of ansible.plugins.strategy_plugins
    original_strategy_plugins_hash = None
    try:
        original_strategy_plugins_hash = ansible.plugins.strategy_plugins.__hash__
    except AttributeError:
        pass

    # Create a StrategyModule object
    obj = StrategyModule(object())

    # Check if StrategyModule is a subclass of

# Generated at 2022-06-23 13:03:05.311500
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.config.manager
    config_manager = ansible.config.manager.ConfigManager()
    config_manager._read_config_data(dict())
    config_manager._read_config_data(config_manager.definitions)
    config_manager._read_config_data({'strategy_plugins': 'host_pinned'})
    config_manager._finalize()
    tqm = TaskQueueManager(inventory=None, variable_manager=None, loader=None, options=config_manager.options, passwords=None, stdout_callback=None)
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:03:08.568840
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True, \
        "strategy_plugins.host_pinned.StrategyModule.__init__() sets _host_pinned to True"

# Generated at 2022-06-23 13:03:10.030860
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule('dummy')
    assert s._host_pinned is True

# Generated at 2022-06-23 13:03:16.105802
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = dict(
        stats=dict(
            hosts=dict(
                one=dict(),
                two=dict(),
            ),
        ),
        callback=dict(
            one=dict(),
            two=dict(),
        ),
        queue_items=dict(
            one=dict(),
            two=dict(),
        ),
    )
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:03:16.620678
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:03:17.957680
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(1)
    assert strategy._host_pinned == True
    assert strategy._display is not None

# Generated at 2022-06-23 13:03:21.790067
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert hasattr(strategy, 'tqm')
    assert hasattr(strategy, '_host_pinned')
    assert strategy._host_pinned == True


# unit test for main function

# Generated at 2022-06-23 13:03:22.508371
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:03:26.431946
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"
    assert StrategyModule.__module__ == "ansible.plugins.strategy.host_pinned"
    assert not hasattr(StrategyModule, "_host_pinned")



# Generated at 2022-06-23 13:03:27.502425
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:03:32.039444
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    free_strategy_mock = FreeStrategyModule(display)
    strategy_module_mock = StrategyModule(free_strategy_mock)
    assert strategy_module_mock._host_pinned == True

# Generated at 2022-06-23 13:03:33.469561
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module.__class__.__name__ == 'StrategyModule'
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:03:34.148833
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:03:35.167535
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)

# Generated at 2022-06-23 13:03:38.248905
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    hosts = [1,2,3,4,5]
    task_queue_manager = {}
    strategy_obj = StrategyModule(task_queue_manager)
    assert strategy_obj._host_pinned is True

# Generated at 2022-06-23 13:03:38.797928
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-23 13:03:41.315929
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
#Initialize the class object for StrategyModule
    strategy_obj = StrategyModule("tqm")
    if isinstance(strategy_obj._host_pinned, bool):
        assert True
    else:
        assert False

# Generated at 2022-06-23 13:03:44.236436
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = Ansible()
    strategy = get_strategy_instance(tqm, 'pinned')
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:03:47.375447
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.name == 'host_pinned'
    assert strategy._host_pinned

# Generated at 2022-06-23 13:03:48.967582
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()
    assert obj is not None, "Unable to instantiate StrategyModule()"


# Generated at 2022-06-23 13:03:52.809004
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    st1 = StrategyModule(tqm = None)
    assert st1._host_pinned == True
    assert st1._inventory == None
    assert st1._iterator == None
    assert st1._tqm == None

# Generated at 2022-06-23 13:03:59.658767
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from mock import MagicMock
    strategy = StrategyModule(tqm=MagicMock())
    strategy.tqm = MagicMock()
    strategy.tqm.send_callback = MagicMock()
    strategy.tqm.terminated.is_set = MagicMock(return_value=False)
    strategy.display = MagicMock()
    strategy._host_pinned = MagicMock()
    return strategy

# Generated at 2022-06-23 13:04:00.306574
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-23 13:04:01.756647
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule('tqm')
    assert sm._host_pinned is True

# Generated at 2022-06-23 13:04:03.249016
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    print()

# Generated at 2022-06-23 13:04:04.961078
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy.host_pinned import display
    a = StrategyModule(display)
    assert a._host_pinned

# Generated at 2022-06-23 13:04:07.157631
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    params = dict(
        tqm=None
    )
    obj = StrategyModule(**params)
    assert obj != None

# Generated at 2022-06-23 13:04:09.924406
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTQM():
      def __init__(self, inventory):
          self.inventory = inventory
    tqm = FakeTQM("inventory")
    StrategyModule(tqm)

# Generated at 2022-06-23 13:04:11.065385
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule()
    assert module is not None


# Generated at 2022-06-23 13:04:12.796132
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(None), StrategyModule)

# Generated at 2022-06-23 13:04:13.520323
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:04:15.925092
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = dict()
    tqm.tqm = dict()
    tqm.tqm.stats = dict()
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True


# Generated at 2022-06-23 13:04:25.676695
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.utils.display
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    import ansible.plugins.strategy.host_pinned
    import ansible.playbook.task_queue_manager
    import ansible.playbook.play
    import ansible.inventory.host

    class Mock_task_queue_manager:
        def __init__(self):
            self.inventory = ansible.inventory.Inventory(host_list=[])
            self.variable_manager = ansible.vars.VariableManager()
            self.variable_manager.set_inventory(self.inventory)
            self.loader = ansible.parsing.dataloader.DataLoader()
            self.passwords = {}
            self.stdout_callback = ansible.utils.display.Display()

# Generated at 2022-06-23 13:04:36.962523
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'

# Generated at 2022-06-23 13:04:39.137511
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test = StrategyModule("test")
    assert test._host_pinned == True

# Generated at 2022-06-23 13:04:47.110400
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    class dummy_tqm(object):
        def __init__(self):
            self.initial_fail_percentage = 5
            self.stats = {}
            self.inventory = None
            self.batch_size = 10
            self.batch = []
            self.cur_tqm_iteration = 0
            self.cur_batch_iteration = 0
            self.global_timeout = None
            self.default_timeout = None
            self.display = None
            self.timeout_timer = None
            self.cleanup_animation = None
            self.terminated = False
            self.failed_hosts = {}
            self.stats = {'dark': {}, 'failures': {}, 'processed': {}}
            self.vars_plugins = []
            self.hostvars = {}

# Generated at 2022-06-23 13:04:48.446797
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm={})

# Generated at 2022-06-23 13:04:49.784576
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    t = StrategyModule('')
    assert(t._host_pinned)

# Generated at 2022-06-23 13:04:52.455948
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    myClass = StrategyModule(1)
    assert myClass._host_pinned == True

# Generated at 2022-06-23 13:04:53.469835
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy is not None, "Create StrategyModule failed."
    if not strategy:
        raise AssertionError("Create StrategyModule failed.")
    return strategy

# Generated at 2022-06-23 13:05:03.720268
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import load_extra_vars
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = variable_manager.loader

    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)
    loader.set_variable_manager(variable_manager)
    variable_manager.extra_vars = load_extra_vars(loader, options=dict())

    inventory.subset('all')
    sm = StrategyModule(TaskQueueManager(inventory=inventory, variable_manager=variable_manager))
    assert sm._host_pinned

# Generated at 2022-06-23 13:05:04.527260
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ''
    StrategyModule(tqm)


# Generated at 2022-06-23 13:05:05.462200
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-23 13:05:06.172704
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:05:08.427339
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('tqm')
    assert strategy_module._host_pinned is True

# Generated at 2022-06-23 13:05:09.464333
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert FreeStrategyModule()

# Generated at 2022-06-23 13:05:15.786383
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule("TQM")
    print("StrategyModule: " + str(strategyModule))
    print("StrategyModule(TQM): " + str(strategyModule.__init__("TQM")))
    print("get_host_pinned: " + str(strategyModule.get_host_pinned()))
    
# main function to start the unit test

# Generated at 2022-06-23 13:05:16.458248
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule()
    x.__init__()

# Generated at 2022-06-23 13:05:17.968533
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global StrategyModule
    '''If StrategyModule constructor executes sucessfully, test should pass'''
    strategy = StrategyModule(None)
    assert strategy is not None

# Generated at 2022-06-23 13:05:21.225114
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    tqm = ansible.plugins.strategy.host_pinned.StrategyModule(tqm)


# Make sure the constructor can be called
test_StrategyModule()

# Generated at 2022-06-23 13:05:22.612338
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'


# Generated at 2022-06-23 13:05:24.288564
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule()
    assert a.__class__.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:05:25.546211
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)



# Generated at 2022-06-23 13:05:27.102244
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    # Fill additional test code here


# Generated at 2022-06-23 13:05:27.931392
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm = None)



# Generated at 2022-06-23 13:05:29.032380
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    assert obj != None


# Generated at 2022-06-23 13:05:29.668848
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:05:32.194138
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test StrategyModule constructor
    tqm = MagicMock()
    strategy = StrategyModule(tqm)
    assert isinstance(strategy, StrategyModule)
    assert strategy._host_pinned


# Generated at 2022-06-23 13:05:34.020869
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert (StrategyModule)

# Generated at 2022-06-23 13:05:35.058238
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-23 13:05:36.163806
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ''' constructor for class StrategyModule '''
    pass

# Generated at 2022-06-23 13:05:38.152323
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm = None)


# Generated at 2022-06-23 13:05:40.679020
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "tqm"
    assert (StrategyModule(tqm)._tqm == "tqm")

# Generated at 2022-06-23 13:05:41.725058
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()


# Generated at 2022-06-23 13:05:42.774106
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:05:43.790222
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 13:05:50.883523
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor import play_iterator
    from ansible.utils.vars import merge_hash
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import InventoryManager
    from ansible.vars.reserved import Reserved

    hosts_file = 'host_pinned.yml'
    inventory = InventoryManager(loader=None, sources=[hosts_file])

    reserved_vars = Reserved(inventory=inventory)
    var_manager = HostVars(loader=None, inventory=inventory, version_info=reserved_vars)

# Generated at 2022-06-23 13:05:51.889834
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module is not None


# Generated at 2022-06-23 13:05:53.595323
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(object())
    assert(obj._host_pinned == True)

# Generated at 2022-06-23 13:05:56.846041
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Test_StrategyModule:
        host_pinned = True
        
    tqm = Test_StrategyModule()
    try:
        StrategyModule(tqm)
    except:
        assert False

# Generated at 2022-06-23 13:05:57.817024
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-23 13:05:58.888059
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True is not False # Replace with meaningful tests

# Generated at 2022-06-23 13:06:00.269861
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_object = StrategyModule("test_host")
    assert test_object != None


# Generated at 2022-06-23 13:06:03.770500
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Test StrategyModule...')
    # Test 1
    strategy_module = StrategyModule(None)
    if strategy_module._host_pinned is True:
        print('Test 1 passed!')
    else:
        print('Test 1 failed!')

# Generated at 2022-06-23 13:06:07.348348
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    
    # instantiate object
    obj = StrategyModule(tqm)
    
    # test
    assert obj._host_pinned is True

# Generated at 2022-06-23 13:06:08.730992
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__bases__[0] == FreeStrategyModule

# Generated at 2022-06-23 13:06:12.046981
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    class TestTqm:
        def __init__(self, display):
            self.display = display
    tqm = TestTqm(display)

    assert StrategyModule(tqm)

# Generated at 2022-06-23 13:06:16.849373
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ This unit test will test the constructor of this class.
    """
    tqm = object()
    stm = StrategyModule(tqm)
    assert(stm._host_pinned == True)

# Make coding more python3-ish
from __future__ import (absolute_import, division, print_function)
__metaclass__ = type

# Generated at 2022-06-23 13:06:18.194863
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule(None)
    assert mod._host_pinned == True

# Generated at 2022-06-23 13:06:19.268639
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sem = StrategyModule(True)
    assert sem._host_pinned == True

# Generated at 2022-06-23 13:06:21.647603
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    stm = StrategyModule(tqm='tqm')
    assert(stm.ORDER_PLAYBOOK == 2)
    assert(stm.ORDER_HOST == 1)
    assert(stm.ORDER_TASK == 0)

# Generated at 2022-06-23 13:06:31.857113
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import pytest
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager 
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    tqm = TaskQueueManager(None, None, None, None, None, None, None, None, None, None, None, False)
    sm = StrategyModule(tqm)
    assert sm  # this is a workaround because pytest skips the test if no assert is present
    assert type(sm) == StrategyModule
    assert isinstance(sm, FreeStrategyModule)

# Generated at 2022-06-23 13:06:32.460290
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-23 13:06:35.114433
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = DummyTQM()
    s = StrategyModule(tqm)
    assert s._host_pinned

# Create a dummy TaskQueueManager object

# Generated at 2022-06-23 13:06:41.206545
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    current_directory = os.path.dirname(os.path.abspath(__file__))
    sys.path.append(current_directory + "/../../")
    from strategy.host_pinned import StrategyModule
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import fragment_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import shell_loader
    from ansible.plugins.loader import test_loader

# Generated at 2022-06-23 13:06:47.538295
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import __main__
    setattr(__main__, '__file__', '/test/ansible/terminal.py') 
    from ansible.plugins.strategy.host_pinned import StrategyModule
    tqm = TQM()
    StrategyModule(tqm)

# Make it happen
if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-23 13:06:49.613724
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    method = StrategyModule
    module = method(tqm={})
    assert module.__init__(tqm={}) == None

# Generated at 2022-06-23 13:06:52.901494
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == """Executes tasks on each host without interruption"""

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-23 13:06:54.751851
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__  == 'Default Strategy Module'

# Generated at 2022-06-23 13:07:00.717835
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager

    display = Display()
    options = None
    variable_manager = None
    loader = None
    passwords = None
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=variable_manager,
        loader=loader,
        options=options,
        passwords=passwords,
        stdout_callback=None,
    )
    StrategyModule(tqm)

# Generated at 2022-06-23 13:07:02.098755
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(tqm = 0)
    assert a._host_pinned == True


# Generated at 2022-06-23 13:07:06.705586
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class tqm:
        def __init__(self):
            self.host_pinned = True
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:07:08.552973
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == FreeStrategyModule.__doc__

# Generated at 2022-06-23 13:07:09.481929
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)._host_pinned

# Generated at 2022-06-23 13:07:16.193728
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.task import Task

    host_list = [{'hostname': '10.0.0.1'}]
    inventory = InventoryManager(loader=DataLoader(), sources=host_list)
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

# Generated at 2022-06-23 13:07:18.942130
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ret = StrategyModule()
    assert hasattr(ret,"_display") is True
    assert hasattr(ret,"_tqm") is True


# Generated at 2022-06-23 13:07:20.573024
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test = StrategyModule('Test')
    assert (test._host_pinned == True)
        

# Generated at 2022-06-23 13:07:22.255815
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:07:23.333171
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule(None)
    assert mod._host_pinned == True

# Generated at 2022-06-23 13:07:23.841603
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert FreeStrategyModule

# Generated at 2022-06-23 13:07:29.728340
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None

    # Test case where tqm is None
    strategy_module = StrategyModule(tqm)
    assert(strategy_module)

    # Test case where tqm is not None
    tqm = "test"
    strategy_module = StrategyModule(tqm)
    assert(strategy_module)

# Generated at 2022-06-23 13:07:32.611536
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    _tqm = None
    _strategy_module = StrategyModule(_tqm)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:07:35.506823
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    aa = StrategyModule.__init__("strategy/host_pinned/__init__.py")
    assert aa is None, "StrategyModule init is not none"

# Generated at 2022-06-23 13:07:36.484367
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()



# Generated at 2022-06-23 13:07:40.305046
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM(object):
        def __init__(self):
            self.has_queue = True
    tqm = TestTQM()
    smodule = StrategyModule(tqm)
    assert smodule._host_pinned == True

# Generated at 2022-06-23 13:07:41.666334
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(callable(StrategyModule))


# Generated at 2022-06-23 13:07:43.028409
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned is True

# Generated at 2022-06-23 13:07:44.614809
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule(1)
    assert x._host_pinned == True


# Generated at 2022-06-23 13:07:47.407785
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule

    module = StrategyModule(tqm=None)
    assert module._host_pinned


# Unit convenience test for class StrategyModule

# Generated at 2022-06-23 13:07:49.529094
# Unit test for constructor of class StrategyModule
def test_StrategyModule(): 
    a = StrategyModule("a")
    assert a._host_pinned == True
    assert a._cleanup_processes == True

# Generated at 2022-06-23 13:07:50.829704
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)


StrategyModule.register()

# Generated at 2022-06-23 13:07:53.885099
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task import Task

    tqm = Task()
    str_module = StrategyModule(tqm)

    assert str_module is not None

# Generated at 2022-06-23 13:08:01.698466
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import ansible.utils.plugin_docs as plugin_docs
    import ansible.plugins.strategy.host_pinned

    class TestFreeStrategyModule(unittest.TestCase):

        def test_constructor(self):
            tqm = dict()
            tqm['_final_q'] = False
            tqm['_failed_hosts'] = False
            tqm['_stats'] = False
            tqm['_inventory'] = False
            tqm['_variable_manager'] = False
            tqm['_loader'] = False
            tqm['_options'] = False
            tqm['_stdout_callback'] = False
            tqm['_allowed_hosts'] = False
            tqm['_blocked_hosts'] = False
            t

# Generated at 2022-06-23 13:08:03.636222
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        st = StrategyModule("tqm")
        assert st._host_pinned == True
    except Exception as e:
        print("StrategyModule unit test failed")
        assert False

# Generated at 2022-06-23 13:08:04.462527
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)

# Generated at 2022-06-23 13:08:08.133027
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    setup_mock = {
        '_workers': 1,
        '_connection_info': {},
        '_loader': None,
        '_inventory': {},
        '_variable_manager': None
    }
    inst_strategymodule = StrategyModule(setup_mock)
    assert True is inst_strategymodule._host_pinned

# Generated at 2022-06-23 13:08:10.534930
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = '1121'
    obj = StrategyModule(tqm)
    assert obj

# Generated at 2022-06-23 13:08:12.105881
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule('obj')
    assert obj._host_pinned == True

# Generated at 2022-06-23 13:08:12.633412
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  assert True

# Generated at 2022-06-23 13:08:13.249705
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__

# Generated at 2022-06-23 13:08:15.204480
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('tqm')
    assert hasattr(strategy_module, '_host_pinned')
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:08:17.256871
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)

# Generated at 2022-06-23 13:08:18.751218
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

    assert StrategyModule._host_pinned is True

# Generated at 2022-06-23 13:08:21.297010
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    data = FreeStrategyModule()
    assert not data._host_pinned
    assert data._tqm


# Generated at 2022-06-23 13:08:23.828436
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned as strategy_host_pinned
    strategy_host_pinned.StrategyModule(None)

# Generated at 2022-06-23 13:08:25.200497
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()
    assert s == ''

# Generated at 2022-06-23 13:08:27.071159
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)
    assert isinstance(FreeStrategyModule(), StrategyModule)

# Generated at 2022-06-23 13:08:27.946848
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:08:29.150848
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 13:08:30.158098
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__()

# Generated at 2022-06-23 13:08:32.231927
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    obj.__init__(tqm=None)
    assert obj._host_pinned == True

# Generated at 2022-06-23 13:08:34.814851
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy is not None

# Generated at 2022-06-23 13:08:37.671362
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule()._name == 'host_pinned', "name should be free"
    assert StrategyModule()._host_pinned == True, "host_pinned should be True"

# Generated at 2022-06-23 13:08:39.234429
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule('tqm')
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:08:42.022224
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from mock import MagicMock
    tqm = MagicMock()
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:08:47.627245
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # The test needs to setup a task queue manager.
    tqm = None
    assert StrategyModule(tqm) is not None

if __name__ == '__main__':
    # Command line argument is `--test-module` which causes basic test to be run
    # The test needs to setup a task queue manager.
    test_StrategyModule()

# Generated at 2022-06-23 13:08:51.057140
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = []
    obj = StrategyModule(tqm)
    assert isinstance(obj, StrategyModule)
    assert isinstance(obj, FreeStrategyModule)
    assert obj._host_pinned is True


# Generated at 2022-06-23 13:08:54.537635
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of StrategyModule class")
    try:
        StrategyModule("")
    except:
        print("Failed to initialize. Parameter tqm required.")
    else:
        print("Passed")

# Generated at 2022-06-23 13:08:56.790319
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:08:58.049743
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 13:08:58.715044
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:09:07.993657
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test for
    # @staticmethod
    # def check_implicit_imports(var, lookup_plugins, module_utils, force=False):
    from ansible.errors import AnsibleError
    from ansible.module_utils import basic
    module_utils = basic.AnsibleModule(argument_spec={})

    # test for
    # def __init__(self, tqm):
    #     self._host_pinned = True
    #     super(StrategyModule, self).__init__(tqm)
    #     # Implicit, but important: call_queue.unblocked_hosts is set to
    #     # list of hosts that have finished with the current task.
    #     self.call_queue = WorkerQueue(tqm,
    #                                   self.tqm._inventory.get_

# Generated at 2022-06-23 13:09:09.282971
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:09:11.028342
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert type(strategy) == StrategyModule
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:09:12.872391
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule('tqm')
    assert sm.__class__.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:09:17.296594
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.utils.display import Display

    display = Display()

    test_StrategyModule = StrategyModule(tqm={})
    assert test_StrategyModule._host_pinned == True

    print("Unit test for constructor of class StrategyModule")

# Generated at 2022-06-23 13:09:20.421005
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned is True

test_StrategyModule()

# Generated at 2022-06-23 13:09:23.976841
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None).__str__() == '<ansible.plugins.strategy.host_pinned.StrategyModule object at 0x000001E5C50F9AC8>'



# Generated at 2022-06-23 13:09:26.406250
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create StrategyModule object
    my_object = StrategyModule("tqm_object")

    # Ensure correct type for StrategyModule object
    assert isinstance(my_object, StrategyModule)


# Generated at 2022-06-23 13:09:27.110037
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-23 13:09:29.294937
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-23 13:09:30.433279
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule('hello')
    assert s

# Generated at 2022-06-23 13:09:33.392462
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class tqm:
        def __init__(self):
            self._host_pinned = True
    StrategyModule(tqm)
# ./test_StrategyModule



# Generated at 2022-06-23 13:09:35.918654
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQMClass(object):
        pass
    tqm = TQMClass()
    strategyModule = StrategyModule(tqm)
    assert strategyModule._host_pinned == True


# Generated at 2022-06-23 13:09:38.249540
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule, object)
    assert isinstance(StrategyModule, FreeStrategyModule)


# Generated at 2022-06-23 13:09:42.499289
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy import STRATEGY_PLUGINS
    sm = StrategyModule('test')
    assert sm._host_pinned == True
    assert sm is STRATEGY_PLUGINS['host_pinned']

# Generated at 2022-06-23 13:09:44.989495
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == """Executes tasks on each host without interruption"""
    assert StrategyModule.__module__ == "ansible.plugins.strategy.host_pinned"

# Generated at 2022-06-23 13:09:47.547070
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MockTQM()
    assert(StrategyModule(tqm)._host_pinned)


# Generated at 2022-06-23 13:09:48.990959
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:09:57.071958
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class tqm():
        class inventory():
            pass
    strategy = StrategyModule(tqm)
    assert type(strategy) == StrategyModule
    assert strategy._host_pinned == True

#import pdb; pdb.set_trace()

    """
    This module is an alternative to the default strategy plugin that
    has a linear approach to host execution, as opposed to the default
    C(free) strategy module which allows hosts to be processed in any order.
    """

    #---------------------------------------------------------------
    # main loop
    #---------------------------------------------------------------

    # TODO: some of this can probably be moved back to the base class, would
    #       be good to do some more refactoring there


# Generated at 2022-06-23 13:09:58.881044
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule("test")
    assert sm._host_pinned is True

# Generated at 2022-06-23 13:10:00.872948
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    tqm = None
    module = StrategyModule(tqm)

# Generated at 2022-06-23 13:10:01.433631
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__ is not None

# Generated at 2022-06-23 13:10:03.663250
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)

# Generated at 2022-06-23 13:10:07.248914
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-23 13:10:08.262184
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  pass

# Generated at 2022-06-23 13:10:10.786702
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Instantiate the class
    classObj = StrategyModule()
    # Check the type/class of the object
    assert isinstance(classObj, StrategyModule) == True

# Generated at 2022-06-23 13:10:11.816358
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm)
    assert sm

# Generated at 2022-06-23 13:10:12.459006
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:10:16.986690
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Test constructor with a bare minimally viable TaskQueueManager
    taskqm = TaskQueueManager('/tmp/ansible', 1, 'root', None, None, False, False, 2, True, 2)
    StrategyModule(taskqm)

# Generated at 2022-06-23 13:10:17.603172
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:10:18.350125
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:10:19.430500
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(None), StrategyModule)

# Generated at 2022-06-23 13:10:21.258974
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule(None)
    assert strategyModule._host_pinned is True



# Generated at 2022-06-23 13:10:22.986781
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True


# Generated at 2022-06-23 13:10:23.570295
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:10:29.444989
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy import StrategyBase
    the_strategy=StrategyModule(tqm)
    if not isinstance(the_strategy,StrategyBase):
        raise Exception("StrategyModule is not a subclass of StrategyBase")

# Generated at 2022-06-23 13:10:30.722386
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:10:38.214482
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ Creating instance of class StrategyModule """
    strategy_module_obj = StrategyModule("tqm")
    assert strategy_module_obj._display is not None
    assert strategy_module_obj.tqm is not None
    assert strategy_module_obj._stats is not None
    assert strategy_module_obj._inventory is not None
    assert strategy_module_obj._iterator is not None
    assert strategy_module_obj._host_pinned is not None

# Generated at 2022-06-23 13:10:40.506834
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ""
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:10:47.525000
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor import task_queue_manager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    tqm = task_queue_manager.TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
    )
    assert StrategyModule(tqm)

# Generated at 2022-06-23 13:10:48.912206
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm=None
    obj=StrategyModule(tqm)
    assert obj._host_pinned == True

# Generated at 2022-06-23 13:10:50.767780
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    fsm = FreeStrategyModule()
    assert fsm


# Generated at 2022-06-23 13:10:53.710051
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  print(StrategyModule.__doc__)
  print(StrategyModule.__init__.__doc__)

# Generated at 2022-06-23 13:10:55.725363
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm = None)
    print(obj)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:10:58.718380
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module
    assert strategy_module._host_pinned

# Generated at 2022-06-23 13:11:02.787120
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

if __name__ == '__main__':
    my_object = StrategyModule(None)
    test_StrategyModule()

# Generated at 2022-06-23 13:11:12.768835
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    hosts = ['localhost', 'other_localhost']
    loader = DataLoader()
    inventory = Inventory(loader=loader, host_list=hosts)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 13:11:15.637801
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'



# Generated at 2022-06-23 13:11:16.233208
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:11:23.621463
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.vars.json_query import JsonQuery
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from collections import namedtuple
    from ansible.executor.play_iterator import PlayIterator

    # Constructor requires these args
    variable_manager = VariableManager()
    loader = 'test_loader'

    # Create a task
    task = Task()

    # Create a play context
    play_context = PlayContext()

    # Create a play

# Generated at 2022-06-23 13:11:32.493325
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor import task_queue_manager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=None, sources=['localhost,'])
    variable_manager = VariableManager(loader=None, inventory=inventory)

    tqm = task_queue_manager.TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=None,
    )
    StrategyModule(tqm)

# Generated at 2022-06-23 13:11:33.927526
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert_true = True


# Generated at 2022-06-23 13:11:40.166191
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Use task_queue_manager.TaskQueueManager() to create an instance of TaskQueueManager
    # because Ansible.TQM.TQM class is private
    from ansible.executor import task_queue_manager
    tqm = task_queue_manager.TaskQueueManager()

    # Create an instance of StrategyModule class
    strategy = StrategyModule(tqm)

    # Check that field _host_pinned is assigned correctly
    assert strategy._host_pinned == True

    # Check that field _tqm is assigned correctly
    assert strategy._tqm == tqm

# Generated at 2022-06-23 13:11:46.040704
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Without the following pylint disable, pylint complains about
    # access to protected member _host_pinned of class StrategyModule
    # which is instantiated for the unit test. pylint: disable=W0212
    assert not StrategyModule.__init__(None)._host_pinned

# Generated at 2022-06-23 13:11:48.653602
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO not sure how to test module member
    pass

# Generated at 2022-06-23 13:11:51.751990
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    module = StrategyModule(tqm)
    assert module._host_pinned == True

# Unit test to test the method get_hosts_remaining

# Generated at 2022-06-23 13:11:53.971399
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj1 = StrategyModule(tqm=None, lossy=False)
    assert obj1._host_pinned == True

# Generated at 2022-06-23 13:11:57.182547
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-23 13:11:58.647694
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule, type)

# Generated at 2022-06-23 13:11:59.425582
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True