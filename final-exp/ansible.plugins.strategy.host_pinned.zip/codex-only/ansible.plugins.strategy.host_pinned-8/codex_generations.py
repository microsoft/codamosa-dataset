

# Generated at 2022-06-23 13:02:05.004121
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(None), StrategyModule)


# Generated at 2022-06-23 13:02:06.816851
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    fsm = StrategyModule(tqm)
    assert fsm._host_pinned == True

# Generated at 2022-06-23 13:02:09.225237
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert s._host_pinned

# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-23 13:02:11.793595
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    parameter_name = strategy._host_pinned
    expected_result = True
    assert parameter_name == expected_result


# Generated at 2022-06-23 13:02:14.404382
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mock_tqm = None
    strategy_module = StrategyModule(mock_tqm)
    assert strategy_module is not None
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:02:15.648028
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__

# Generated at 2022-06-23 13:02:18.149260
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm)
    assert s._host_pinned

# Generated at 2022-06-23 13:02:20.142837
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Constructor test of class StrategyModule
    """
    tqm = "Test"
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:02:20.862310
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:02:21.674482
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return True

# Generated at 2022-06-23 13:02:32.605664
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    myStrategyModule = StrategyModule(None)
    assert (myStrategyModule._host_pinned == True)    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    # What will be the output of the following code?
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    # A) A
    # B) B
    # C) C
    # D) D
"""

"""
    # Which of the following regular expression will match a string which starts with a line of text, the actual word "foo"
    # followed by any number of characters and ends with a new line?
    

# Generated at 2022-06-23 13:02:33.389957
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:02:36.164925
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager()
    tqm.strategy = StrategyModule(tqm)
    assert tqm.strategy._host_pinned

# Generated at 2022-06-23 13:02:36.655429
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == True

# Generated at 2022-06-23 13:02:43.102963
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    modules_mock = {}
    plugins_mock = {}
    display_mock = Display()
    display_mock.verbosity = 1
    gather_facts_mock = False        
    task_queue_manager_mock = {}
    task_queue_manager_mock.host_list = []
    task_queue_manager_mock.module_vars = {}
    task_queue_manager_mock.play = {}
    task_queue_manager_mock.play.handlers = {}
    task_queue_manager_mock.play.handler_blocks = []
    task_queue_manager_mock.play.tasks = []
    task_queue_manager_mock.play.blocks = []
    task_queue_manager_mock.shared_loader_obj = {}
    task_queue_manager_

# Generated at 2022-06-23 13:02:45.040213
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "foo"
    strategy = StrategyModule(tqm)
    assert strategy == strategy

# Generated at 2022-06-23 13:02:47.020462
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    temp = StrategyModule(object)
    assert temp._host_pinned == True



# Generated at 2022-06-23 13:02:47.653447
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:02:50.446809
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:02:53.814281
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    n = StrategyModule(1)
    assert n.__class__.__name__ == 'StrategyModule'
    assert n._host_pinned == True

# Generated at 2022-06-23 13:03:03.912111
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = object()
  strategy_module = StrategyModule(tqm)
  assert strategy_module._tqm == tqm
  assert strategy_module._host_pinned == True
  assert strategy_module._batch_size == 0
  assert strategy_module._inventory is None
  assert strategy_module._variable_manager is None
  assert strategy_module._loader is None
  assert strategy_module._play_context is None
  assert strategy_module._all_vars_push_done is True
  assert strategy_module._step is False
  assert strategy_module._cleanup_on_error is True
  assert strategy_module._notified_handlers is None
  assert strategy_module._started_at_load is True
  assert strategy_module._last_activity is None
  assert strategy_module._last_banner is None


# Generated at 2022-06-23 13:03:06.241321
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    test_strategy = StrategyModule(tqm)
    assert(test_strategy._host_pinned == True)

# Generated at 2022-06-23 13:03:07.321362
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__

# Generated at 2022-06-23 13:03:09.679005
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:03:12.363616
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class tqm:
        class hosts:
            pass
        inventory = []
        stats = []

    test = StrategyModule(tqm)
    assert not test._host_pinned

# Generated at 2022-06-23 13:03:12.799160
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:03:17.965812
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test constructor!")
    print("\tIf this test gives error, fix the code to pass this test!")
    strategy = StrategyModule(tqm=None)
    result = strategy._host_pinned
    assert result == True, "Result of '_host_pinned' is " + str(result) + ", which is not True!"
    print("\tPass!")


# Generated at 2022-06-23 13:03:29.201010
# Unit test for constructor of class StrategyModule
def test_StrategyModule(): 
    from ansible.playbook import Play
    from ansible.playbook import PlayBook
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play as PlayObject
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.tactic.free import TacticModule as FreeTacticModule
    from ansible.executor.task_manager import TaskManager
    from ansible.executor.tqm import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars.hostvars import HostVars


# Generated at 2022-06-23 13:03:31.784110
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)


# Generated at 2022-06-23 13:03:34.522567
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module._tqm is None
    assert strategy_module._host_pinned is True

# Generated at 2022-06-23 13:03:36.291032
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:03:37.944642
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  a = StrategyModule("tqm")
  assert a != None


# Generated at 2022-06-23 13:03:39.178573
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)

# Generated at 2022-06-23 13:03:41.056170
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module is not None
    assert strategy_module._host_pinned is True

# Generated at 2022-06-23 13:03:44.287114
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    strategy_module = StrategyModule(tqm)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:03:46.666124
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm=None)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:03:49.252535
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  a = StrategyModule()
  try:
    assert a._host_pinned == True
  except AssertionError:
    print('Error: AssertionError')

# Generated at 2022-06-23 13:03:51.391903
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test for the constructor of class StrategyModule
    # Test for the creation of StrategyModule class
    assert StrategyModule

# Generated at 2022-06-23 13:03:54.680737
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    test_object = StrategyModule(None)
    assert hasattr(test_object, '_host_pinned')

# Generated at 2022-06-23 13:03:56.893731
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert(s)
    assert(s._host_pinned)

# Generated at 2022-06-23 13:03:57.512865
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:04:00.636628
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM():
        host_pinned = True
    tqm = TQM()
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:04:03.542940
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned as hostpy
    obj = hostpy.StrategyModule(None)
    obj._host_pinned = True

# Generated at 2022-06-23 13:04:04.327966
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:04:08.295930
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule), "StrategyModule is not subclass of FreeStrategyModule."
    strategy_module = StrategyModule(test_StrategyModule)
    assert isinstance(strategy_module, StrategyModule), "Argument of StrategyModule constructor is not an instance of StrategyModule"

# Generated at 2022-06-23 13:04:12.649890
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert len(StrategyModule.__bases__) == 1
    assert len(StrategyModule.__init__.__code__.co_varnames) == 3
    assert StrategyModule(tqm={})._host_pinned == True

# Generated at 2022-06-23 13:04:14.464430
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    result = StrategyModule(tqm)
    assert result is not None

# Generated at 2022-06-23 13:04:15.411916
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"

# Generated at 2022-06-23 13:04:16.380898
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:04:18.352344
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:04:19.683833
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).__dict__ == FreeStrategyModule(None).__dict__

# Generated at 2022-06-23 13:04:23.433542
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    tm = TaskQueueManager(None,None)
    assert isinstance(StrategyModule(tm),StrategyModule)


# Generated at 2022-06-23 13:04:24.901449
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    strategy = StrategyModule(tqm)


# Generated at 2022-06-23 13:04:26.503365
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm = None)

# Generated at 2022-06-23 13:04:28.167637
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(None)
    assert isinstance(a,StrategyModule)
    

# Generated at 2022-06-23 13:04:32.128360
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_list = ['host1', 'host2']
    tqm = None

    strategy = StrategyModule(tqm)

    # StrategyModule __init__() should set _host_pinned to True.
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:04:42.632566
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  from ansible.playbook import PlayBook
  from ansible.playbook.play import Play
  from ansible.executor.task_queue_manager import TaskQueueManager
  from ansible.executor.playbook_executor import PlaybookExecutor
  from ansible.parsing.dataloader import DataLoader
  PlaybookExecutor.load_callbacks()

  abc='./test.yml'
  loader = DataLoader()
  playbooks = [abc]
  variable_manager = VariableManager()
  inventory = Inventory(loader=loader, variable_manager=variable_manager,  host_list='/etc/ansible/hosts')
  variable_manager.set_inventory(inventory)
  playbook = PlayBook.load(playbooks[0], variable_manager=variable_manager, loader=loader)
  pbex

# Generated at 2022-06-23 13:04:44.365694
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    return StrategyModule

# Generated at 2022-06-23 13:04:45.362411
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)

# Generated at 2022-06-23 13:04:47.246325
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    assert FreeStrategyModule(tqm)
    assert StrategyModule(tqm)

# Generated at 2022-06-23 13:04:50.602964
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #free_strategy_module = FreeStrategyModule()
    host_pinned_strategy_module = StrategyModule()
    assert isinstance(host_pinned_strategy_module, StrategyModule)

# Generated at 2022-06-23 13:04:51.417648
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:04:52.398777
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-23 13:04:56.812710
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert(strategy_module is not None)
    assert(strategy_module._host_pinned is True)

if __name__ == '__main__':
    # Unit test for constructor of class StrategyModule
    test_StrategyModule()

# Generated at 2022-06-23 13:05:05.835187
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule('test')
    assert hasattr(strategy, '_tqm')
    assert hasattr(strategy, '_inventory')
    assert hasattr(strategy, '_variables')
    assert hasattr(strategy, '_loader')
    assert hasattr(strategy, '_display')
    assert hasattr(strategy, '_run_handlers')
    assert hasattr(strategy, '_run_tasks')
    assert hasattr(strategy, '_final_q')
    assert hasattr(strategy, '_failed_hosts')
    assert hasattr(strategy, '_stats')
    assert hasattr(strategy, '_host_pinned')
    assert hasattr(strategy, '_host_failed_checked')

# Generated at 2022-06-23 13:05:07.380237
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)


# Generated at 2022-06-23 13:05:14.970507
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    StrategyModule(tqm)

# Unit tests for function display, function __init__, class StrategyModule
if __name__ == "__main__":
    import sys, os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from test_utils import AnsibleFailTest, ModuleTestCase
    test_case = ModuleTestCase(module=__file__)
    test_case.run()

# Generated at 2022-06-23 13:05:15.972792
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(FreeStrategyModule(Display()))

# Generated at 2022-06-23 13:05:16.645692
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None) is not None

# Generated at 2022-06-23 13:05:17.894313
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned is True

# Generated at 2022-06-23 13:05:18.708662
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Test StrategyModule')



# Generated at 2022-06-23 13:05:20.318800
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule
    assert a is not None

# Generated at 2022-06-23 13:05:21.224943
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert (StrategyModule != None)

# Generated at 2022-06-23 13:05:23.038717
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy
    assert strategy._host_pinned

# Generated at 2022-06-23 13:05:25.560567
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of StrategyModule.")
    test_strategy_module = StrategyModule(None)
    assert test_strategy_module._host_pinned

# Generated at 2022-06-23 13:05:27.422002
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True
    assert hasattr(sm, 'display')

# Generated at 2022-06-23 13:05:33.138102
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(FreeStrategyModule, StrategyModule)
    assert object.__eq__(FreeStrategyModule, StrategyModule)
    assert FreeStrategyModule.__name__ == 'StrategyModule'
    assert FreeStrategyModule.__doc__ == 'Constructor of class StrategyModule'
    instance = FreeStrategyModule(tqm=None)

# Generated at 2022-06-23 13:05:36.117481
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    FakeTQM = 'FakeTQM'
    strategy_module = StrategyModule(FakeTQM)

    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:05:38.525586
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert(strategy_module._host_pinned == True)

# Generated at 2022-06-23 13:05:39.191022
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:05:40.021152
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-23 13:05:41.513605
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__bases__ == (FreeStrategyModule,)

# Generated at 2022-06-23 13:05:45.269551
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()

    # Test that strategy is derived from objects
    assert(isinstance(strategy, object))

    # Test that strategy is derived from FreeStrategyModule
    assert(isinstance(strategy, FreeStrategyModule))



# Generated at 2022-06-23 13:05:48.327896
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global display
    display = Display()

    tqm = dict()
    strategy_module = StrategyModule(tqm)
    assert strategy_module.get_host_pinned() == True

# Generated at 2022-06-23 13:05:50.067895
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm.fully_serial == "FAILED"

# Generated at 2022-06-23 13:05:50.707492
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:06:01.033851
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Test with no verbosity
    display.verbosity = 0
    s = StrategyModule(tqm=None)
    if s._host_pinned is True:
        print('Test passed: expected True got True')
    else:
        print('Test failed: expected True got False')
    if display.verbosity == 0:
        print('Test passed: verbosity did not change')
    else:
        print('Test failed: verbosity changed')

    # Test with verbosity 'vvv'
    display.verbosity = 4
    s = StrategyModule(tqm=None)
    if s._host_pinned is True:
        print('Test passed: expected True got True')
    else:
        print('Test failed: expected True got False')

# Generated at 2022-06-23 13:06:04.095474
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    class tqm:
        def __init__(self):
            self.host_pinned = True

    strategy_module = StrategyModule(tqm())
    assert strategy_module._host_pinned


# Generated at 2022-06-23 13:06:08.779900
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    FreeStrategyModule.__init__(StrategyModule, tqm=0)
    StrategyModule.__init__(StrategyModule, tqm=0)
    assert hasattr(StrategyModule, '_host_pinned')

# Generated at 2022-06-23 13:06:19.788243
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from collections import namedtuple
    from ansible.plugins.strategy.free import StrategyModule
    from ansible.plugins.strategy import StrategyBase

    assert issubclass(StrategyModule, StrategyBase)

    test_tqm = namedtuple("test_tqm", ["threads", "stats", "failed_hosts", "ok_hosts", "dark_hosts", "processed_hosts", "host_pinned"])
    test_tqm.threads = 2
    test_tqm.stats = {}
    test_tqm.failed_hosts = set()
    test_tqm.ok_hosts = set()
    test_tqm.dark_hosts = set()
    test_tqm.processed_hosts = set()
    test_tqm.host

# Generated at 2022-06-23 13:06:25.657170
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.plugins.loader import module_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    class TestTaskQueueManager(TaskQueueManager):
        def __init__(self, inventory, variable_manager, loader, options, passwords, stdout_callback=None, run_additional_callbacks=True, run_tree=False):
            self._inventory = inventory
            self._variable_manager = variable_manager
            self._loader = loader
            self._options = options


# Generated at 2022-06-23 13:06:27.560347
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test = StrategyModule("test")
    assert(test._host_pinned == True)

# Generated at 2022-06-23 13:06:28.783822
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-23 13:06:31.534817
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''

# Generated at 2022-06-23 13:06:32.137379
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:06:34.223668
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ Check if the constructor of class StrategyModule is working properly by passing in a valid argument """
    x = StrategyModule(None)
    assert x is not None

# Generated at 2022-06-23 13:06:35.386235
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert self._host_pinned is True

# Generated at 2022-06-23 13:06:37.447788
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj1 = StrategyModule(list)
    assert isinstance(obj1, StrategyModule)

# Test cases for StrategyModule class

# Generated at 2022-06-23 13:06:40.222707
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    assert(ansible.plugins.strategy.host_pinned.StrategyModule('test') is not None)

# Generated at 2022-06-23 13:06:43.132669
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('Test')
    assert strategy_module.__class__.__name__ == 'StrategyModule'
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:06:46.164075
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_object = StrategyModule("tqm")
    assert strategy_module_object is not None, "strategy_module_object is null"

# Generated at 2022-06-23 13:06:47.593693
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module is not None

# Generated at 2022-06-23 13:06:48.922986
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    m = StrategyModule(None)
    assert m._host_pinned == True

# Generated at 2022-06-23 13:06:50.315789
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned is True

# Generated at 2022-06-23 13:06:51.540777
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 13:06:52.951357
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(), FreeStrategyModule)

# Generated at 2022-06-23 13:07:02.511968
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import sys
    import json
    import mock
    import ansible.plugins.strategy.host_pinned
    import ansible.module_utils.connection
    import ansible.module_utils.network.common.utils
    import ansible.module_utils.network.common.netconf
    from collections import namedtuple

    from ansible.plugins.strategy.host_pinned import StrategyModule as StrategyModule

    tqm = mock.Mock()
    strategyModule = StrategyModule(tqm)
    # assert that strategyModule._host_pinned is True
    assert strategyModule._host_pinned
    assert strategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    # assert strategyModule.__version__ is None
    # assert strategyModule.__author__ == 'Ansible Core Team'

# Generated at 2022-06-23 13:07:04.400195
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-23 13:07:06.707526
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Unit test for constructor of class StrategyModule"""
    assert StrategyModule

# Generated at 2022-06-23 13:07:08.560800
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule(None)
    assert mod._host_pinned == True

# Generated at 2022-06-23 13:07:09.242038
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)

# Generated at 2022-06-23 13:07:09.671783
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:07:13.185321
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import constants as C
    from ansible.executor.task_queue_manager import TaskQueueManager
    C.FORKS = 10
    TQM = TaskQueueManager()

    strategy_module = StrategyModule(TQM)
    assert True

# Generated at 2022-06-23 13:07:16.951429
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result = StrategyModule(tqm=True)
    assert result._host_pinned == True, "Test 1 of StrategyModule: Failed, value of variable _host_pinned is incorrect."


# Generated at 2022-06-23 13:07:22.554631
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   '''
   Test:
       creates a StrategyModule object with a task queue manager

   Condition:
       Initiate StrategyModule object with a task queue manager
   '''

   class TaskQueueManager:
      '''
      Test:
         task queue manager
      Condition:
         initiate task queue manager
      '''
      def __init__(self):
         self.stats = {}


   tqm = TaskQueueManager()
   sm = StrategyModule(tqm)


# Generated at 2022-06-23 13:07:24.663757
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(StrategyModule.__name__)
    print(dir(StrategyModule))
    print(StrategyModule.__doc__)

#test_StrategyModule()

# Generated at 2022-06-23 13:07:27.841888
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule(1)
    except:
        print('StrategyModule must be constructed with TaskQueueManager')

# Generated at 2022-06-23 13:07:31.031712
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned is True
    assert strategy_module.tqm is tqm


# Generated at 2022-06-23 13:07:31.781018
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:07:32.553210
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

StrategyModule.register()

# Generated at 2022-06-23 13:07:33.070743
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule("")

# Generated at 2022-06-23 13:07:38.057815
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import host_pinned
    from ansible.plugins.strategy import free
    host_pinned.display = free.display
    assert issubclass(host_pinned.StrategyModule, free.StrategyModule)
    assert hasattr(host_pinned.StrategyModule, '__init__')

# Generated at 2022-06-23 13:07:39.899319
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(1)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:07:49.198793
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create instance of StrategyModule class
    # with tqm = ansible.executor.task_queue_manager.TaskQueueManager(). 
    # tqm = ansible.executor.task_queue_manager.TaskQueueManager() 
    # is called in ansible.playbook.PlaybookExecutor.run(), 
    # which is called in ansible.bin.ansible_playbook.main()
    # The fact that the constructor of class StrategyModule is called 
    # for only one time is verified in ansible/test/unit/test_ansible.py, 
    # function test_local_playbook_execution_with_host_pinned_strategy.
    strategy_module = StrategyModule(tqm='tqm')
    strategy_module.__init__(tqm='tqm')

# Generated at 2022-06-23 13:07:51.314086
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
# End of constructor test.


# Generated at 2022-06-23 13:07:52.571842
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule().__init__()


# Generated at 2022-06-23 13:07:53.357255
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule("strategy")
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:08:01.360500
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  from ansible.plugins.strategy import StrategyModule
  from ansible.utils.display import Display
  from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule

  display = Display()
  class strategy_mock():
      def __init__():
          self._host_pinned = True

  strategy_instance = StrategyModule(strategy_mock)
  assert(isinstance(strategy_instance, StrategyModule))
  assert(isinstance(strategy_instance, FreeStrategyModule))
  assert(strategy_instance._host_pinned)

# Generated at 2022-06-23 13:08:09.743495
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    import ansible.plugins.connection as connection
    from ansible.inventory.host import Host
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.facts import ModuleDataFactCollector
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible import context
    import ansible.constants as C
    import os
    import sys

    display.verbosity = 3
    context.CLIARGS = {'connection': 'smart'}
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'ansible_connection': 'local'}

# Generated at 2022-06-23 13:08:13.829699
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule
    except NameError:
        assert False, "Unable to find class StrategyModule"
    else:
        assert True

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:08:15.076963
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm)
    assert  obj._host_pinned == True


# Generated at 2022-06-23 13:08:17.470041
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  strategy = StrategyModule("tqm")


# Generated at 2022-06-23 13:08:27.805314
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from collections import namedtuple
    from ansible.plugins.strategy import add_tqm_methods
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor import task_queue_manager
    from ansible.utils.display import Display
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule

    class FakeOption(object):
        def __init__(self, module):
            self.module = module

    def FakeExecOptions(**kwargs):
        class FakeExecOptions(object):
            def __init__(self, **kwargs):
                self.__dict__.update(kwargs)

        return FakeExecOptions(**kwargs)

    tqm = task_queue_manager.TaskQueue

# Generated at 2022-06-23 13:08:28.390920
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:08:29.554156
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Generated at 2022-06-23 13:08:31.449265
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:08:32.119797
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:08:32.947883
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:08:35.537406
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule("")
    assert strategyModule._host_pinned

# Generated at 2022-06-23 13:08:37.503888
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule.__init__(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:08:38.399317
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:08:39.985089
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule(tqm=None)
    assert x._host_pinned == True

# Generated at 2022-06-23 13:08:44.594989
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    tqm = TestTqm()
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True
    assert strategy._tqm == tqm


# Generated at 2022-06-23 13:08:45.483680
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 13:08:46.363041
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"

# Generated at 2022-06-23 13:08:49.781490
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_tqm = TestTQM()
    my_StrategyModule = StrategyModule(my_tqm)

    assert my_StrategyModule._host_pinned == True
    assert my_StrategyModule.version == 2


# Generated at 2022-06-23 13:08:54.658279
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()
    # check if the object is an instance of the class
    assert isinstance(obj, StrategyModule), "Object is not an instance of the class"
    # check if the object is initialized with a variable equal to the expected value
    assert obj._host_pinned == True, "Object is initialized with an different value for the variable than expected"


# Generated at 2022-06-23 13:09:05.299536
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.utils.display import Display
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    inventory_manager = InventoryManager(loader=loader, sources=['tests/lib/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory_manager)
   

# Generated at 2022-06-23 13:09:06.845901
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule("test_value")
    assert x._host_pinned == True


# Generated at 2022-06-23 13:09:09.713107
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ansible.executor.task_queue_manager.TaskQueueManager(inventory=inventory, variable_manager=variable_manager, loader=loader, options=options, passwords=None, stdout_callback=options.stdout_callback)
    assert StrategyModule(tqm)

# Generated at 2022-06-23 13:09:11.796528
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    results = StrategyModule('tqm')
    assert results._host_pinned == True

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:09:12.482462
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-23 13:09:18.777606
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    my_play = Play()
    my_tqm = TaskQueueManager(None, None, None, None, None, None, None, None, None, None)

    my_strategy_module = StrategyModule(my_tqm)

    assert my_strategy_module._host_pinned == True

# Generated at 2022-06-23 13:09:24.343714
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strateget_module = StrategyModule(tqm)
    assert(strateget_module._host_pinned == True)
    assert(strateget_module._blockers == {})
    assert(strateget_module._tqm == tqm)
    assert(strateget_module.display == display)

# Generated at 2022-06-23 13:09:33.129387
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned as strategy_module
    import ansible.plugins.strategy as strategy_mod
    import ansible.utils.display as display
    import ansible.plugins as plugin
    from ansible.utils.sentinel import Sentinel
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.process.result import ResultProcess
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task


# Generated at 2022-06-23 13:09:35.083937
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    test = StrategyModule(tqm)
    assert test is not None, "Cannot create the StrategyModule object"

# Generated at 2022-06-23 13:09:37.572595
# Unit test for constructor of class StrategyModule
def test_StrategyModule():  # noqa
    #assert StrategyModule() is not None
    assert True == True  # just for test

# Generated at 2022-06-23 13:09:39.614883
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_obj = StrategyModule(tqm=None)
    assert strategy_obj is not None

# Generated at 2022-06-23 13:09:41.145279
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm =1)

# Generated at 2022-06-23 13:09:50.408957
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-23 13:09:50.965531
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1 == 1

# Generated at 2022-06-23 13:09:53.029265
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_obj=StrategyModule(tqm=None)
    results=strategy_obj._host_pinned
    print(results)
test_StrategyModule()

# Generated at 2022-06-23 13:09:54.317716
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:09:56.143583
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    new_strategy = StrategyModule("tqm")
    assert new_strategy._host_pinned == True

# Generated at 2022-06-23 13:10:06.585767
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    Options = namedtuple('Options', ['listtags', 'listtasks', 'listhosts', 'syntax', 'connection','module_path', 'forks', 'remote_user', 'private_key_file', 'ssh_common_args', 'ssh_extra_args', 'sftp_extra_args', 'scp_extra_args', 'become', 'become_method', 'become_user', 'verbosity', 'check', 'diff'])

# Generated at 2022-06-23 13:10:07.259249
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:10:11.711785
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM:
        class Options:
            _jobs_per_host = 2
            _forks = 2
            _host_pinned = True
    s = StrategyModule(TQM)
    assert s._host_pinned is True
    assert s.name == 'host_pinned'

# Generated at 2022-06-23 13:10:12.313373
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:10:16.373474
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Executes tasks on each host without interruption'
    assert StrategyModule.__dict__ == dict()
    strategyModule = StrategyModule('tqm')
    assert strategyModule is not None

# Generated at 2022-06-23 13:10:23.781778
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import context
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(
        inventory=context.CLIARGS['inventory'],
        variable_manager=context.CLIARGS['variable_manager'],
        loader=context.CLIARGS['loader'],
        options=context.CLIARGS['options'],
        passwords=None,
    )
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned is True, 'The constructor of class StrategyModule should set _host_pinned=True'

# Generated at 2022-06-23 13:10:24.902188
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule("strategy")

# Generated at 2022-06-23 13:10:25.687636
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-23 13:10:27.303157
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule()
    assert mod

# Generated at 2022-06-23 13:10:30.589163
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned

# Generated at 2022-06-23 13:10:32.349012
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-23 13:10:33.007324
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:10:34.978568
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm._host_pinned

# Generated at 2022-06-23 13:10:35.555810
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  pass

# Generated at 2022-06-23 13:10:37.189832
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm="tqm object")
    assert sm._host_pinned == True
    assert sm._tqm == "tqm object"

# Generated at 2022-06-23 13:10:42.322378
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    tqm = object()
    strategy = StrategyModule(tqm)
    assert isinstance(strategy, FreeStrategyModule)
    assert strategy._host_pinned

# Generated at 2022-06-23 13:10:44.101724
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)._host_pinned == True

# Generated at 2022-06-23 13:10:48.260559
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import PlayBook
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory import Inventory

    strategy_module = StrategyModule(tqm)

# Generated at 2022-06-23 13:10:48.831422
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:10:49.857090
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert not StrategyModule(None).host_pinned

# Generated at 2022-06-23 13:10:52.827212
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(object)
    assert sm._host_pinned == True


# Generated at 2022-06-23 13:10:53.813642
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:10:58.281316
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ssh = StrategyModule(None)
    if ssh._host_pinned == True:
        pass
    else:
        raise("StrategyModule failed")


# class StrategyModule:
#
#     def __init__(self, tqm):
#         self._tqm               = tqm
#         self._inventory         = tqm.get_inventory()
#         self._workers           = tqm.get_workers()
#         self._notified_handlers = []
#         self._final_q           = Queue()
#         self._blocked_hosts     = defaultdict(dict)
#         self._pending_results   = []
#         self._display           = Display()
#
#         self._initialize_terminated_hosts()
#
#         if not self._tqm.listhost

# Generated at 2022-06-23 13:11:01.084751
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule('tqm')
    assert module._host_pinned


# Generated at 2022-06-23 13:11:04.939690
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    print(strategy_module)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:11:05.736141
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:11:12.006042
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    from ansible.plugins.strategy.host_pinned import StrategyModule as pinStrategyModule
    tqm = object()
    free_stg_class = FreeStrategyModule(tqm)
    pin_stg_class = pinStrategyModule(tqm)

    assert free_stg_class._host_pinned == False
    assert pin_stg_class._host_pinned == True

# Generated at 2022-06-23 13:11:13.027758
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:11:15.784540
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_strategy = StrategyModule({})
    assert test_strategy._host_pinned == True

# Generated at 2022-06-23 13:11:17.111091
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

__all__ = ['StrategyModule', 'test_StrategyModule']

# Generated at 2022-06-23 13:11:25.937503
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.utils.module_docs as mod_docs
    import ansible.plugins.strategy.host_pinned as s_host_pinned
    import ansible.plugins.strategy.free as s_free
    reload(s_host_pinned)
    reload(s_free)

    # Call constructor
    tqm = None
    sm = s_host_pinned.StrategyModule(tqm)

    # Test arguments
    assert isinstance(sm, s_free.StrategyModule)
    assert sm._host_pinned == True
    assert sm._tqm == None

    # Test optional arguments
    assert sm._display.verbosity == 3

# Generated at 2022-06-23 13:11:32.275312
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule("test")
# Checking if tqm is null
    assert s._tqm is not None
# Checking if display is null and if it is an instance of Display class
    assert s.display is not None
    assert isinstance(s.display, Display)
# Checking if host_pinned is set to True
    assert s._host_pinned is True

# Unit test to test the next_task method

# Generated at 2022-06-23 13:11:35.471009
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''Create instance of class StrategyModule'''

    display = Display()
    obj = StrategyModule(display)
    return obj

result = test_StrategyModule()

print(result)

# Generated at 2022-06-23 13:11:36.161605
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	pass

# Generated at 2022-06-23 13:11:43.915900
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.loader import default_loader
    from ansible.plugins.strategy import strategy_loader

    # Initialize strategy module
    tqm = default_loader.load_from_file('host_pinned', strategy_loader)
    strategy = tqm._initialize_processes(2)

    # Assert that all attributes are set correctly
    assert strategy._host_pinned
    assert strategy._tqm
    assert strategy._work_queue

# Generated at 2022-06-23 13:11:44.705010
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-23 13:11:46.519597
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    results = ansible.plugins.strategy.host_pinned.StrategyModule(ansible.plugins.strategy.host_pinned.tqm)
    assert results._should_unfreeze_callbacks == False

# Generated at 2022-06-23 13:11:50.248633
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_obj = StrategyModule("test_tqm")
    assert test_obj._host_pinned == True


# Generated at 2022-06-23 13:11:52.456648
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)._host_pinned == True
    assert FreeStrategyModule(None)._host_pinned == False

# Generated at 2022-06-23 13:11:54.983751
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert hasattr(strategy, '_host_pinned')

# Generated at 2022-06-23 13:12:03.479412
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    tqm['_initial_variable_manager'] = {}
    tqm['_inventory'] = {}
    tqm['_play_context'] = {}
    tqm['_updated_vars'] = {}
    tqm['_task_queues'] = {}
    tqm['_failed_hosts'] = {}
    tqm['_stats'] = {}
    tqm['_tqm_variables'] = {}
    obj = StrategyModule(tqm)
    assert obj is not None
    assert obj._host_pinned == True