

# Generated at 2022-06-23 13:02:02.582370
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule("tqm")
    assert module

# Tests that the module is calling the super constructor correctly. This test will fail with the module is
# changed to not call the super constructor.

# Generated at 2022-06-23 13:02:04.586850
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(FreeStrategyModule, '__init__')

# Generated at 2022-06-23 13:02:08.217283
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Incomplete constructor with tqm
    strategy = StrategyModule(tqm=None)
    assert strategy != None

    # Using the completed constructor
    strategy = StrategyModule(tqm=None)
    assert strategy != None



# Generated at 2022-06-23 13:02:08.886508
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:02:09.394625
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:02:10.513461
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:02:11.943718
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	pass

# Generated at 2022-06-23 13:02:14.752108
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module
    assert isinstance(strategy_module, StrategyModule)
    assert strategy_module._host_pinned is True


# Generated at 2022-06-23 13:02:18.043289
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create an object of class StrategyModule with tqm as a parameter
    tqm = object()
    assert  StrategyModule(tqm)

# Generated at 2022-06-23 13:02:19.061870
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = True
    assert StrategyModul

# Generated at 2022-06-23 13:02:30.076547
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task=dict()
    task["pause"]=0
    task["name"]="dummy"
    task["action"]=dict()
    action=dict()
    action["module"]="dummy"
    task["action"]["module"]="dummy"
    task["action"]["args"]=dict()
    task["action"]["args"]["_raw_params"]="dummy"
    task["action"]["args"]["_uses_shell"]=False
    task["action"]["args"]["_executable"]=None
    task["action"]["args"]["chdir"]=None
    class top:
        def get_host_variables(self,host):
            return dict()
        def get_vars(self):
            return dict()

# Generated at 2022-06-23 13:02:39.085239
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("tqm")
    assert strategy_module.ITER_KEYS == FreeStrategyModule.ITER_KEYS
    assert strategy_module.HOST_KEYS == FreeStrategyModule.HOST_KEYS
    assert strategy_module.OK_KEY == "ok"
    assert strategy_module.FAILED_KEY == "failed"
    assert strategy_module.UNREACHABLE_KEY == "unreachable"
    assert strategy_module.ITER_STATE == FreeStrategyModule.ITER_STATE
    assert strategy_module.HOST_STATE == FreeStrategyModule.HOST_STATE
    assert strategy_module.HOST_RESULTS == FreeStrategyModule.HOST_RESULTS
    assert strategy_module.ITER_RESULTS == FreeStrategyModule.ITER_RESULTS
    assert strategy_module.R

# Generated at 2022-06-23 13:02:41.193811
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm)
    print('Host pinned is True')

# Generated at 2022-06-23 13:02:42.443484
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule, object)

# Generated at 2022-06-23 13:02:45.263476
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__bases__ == (FreeStrategyModule,)
    assert StrategyModule.__init__.__func__ is not FreeStrategyModule.__init__.__func__

# Generated at 2022-06-23 13:02:45.879438
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:02:51.245530
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule")
    print("Testing __init__(self, tqm)")
    tqm = {}
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True
    print("Testing __init__(self, tqm) - Passed")



# Generated at 2022-06-23 13:02:53.650836
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()
    assert obj.__class__.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:02:55.908527
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MagicMock()
    obj = StrategyModule(tqm)
    assert obj._host_pinned is True

# Generated at 2022-06-23 13:02:57.014222
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# test method for class StrategyModule

# Generated at 2022-06-23 13:03:06.263669
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == FreeStrategyModule.__doc__


DOCUMENTATION = '''
    name: linear
    short_description: Executes tasks in order on all hosts
    description:
        - Task execution is as linear as possible, hosts are still run in batches of C(forks) to prevent resource starvation.
          New hosts are started as soon as previous host finishes the play.
          This strategy is ideal if you want a very predictable execution order.
          For example if you have a play that creates a filesystem on a host and then the next task requires you to
          reboot the host, you may use this strategy to make sure the host is finished with the play before it gets rebooted.
    version_added: "2.7"
    author: Ansible Core Team
'''


from ansible.plugins.strategy.linear import StrategyModule as LinearStrategy

# Generated at 2022-06-23 13:03:08.730525
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned == True
    print('Constructor test successful')

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:03:10.278833
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    d = StrategyModule(None)
    assert d._host_pinned == True

# Generated at 2022-06-23 13:03:15.974064
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert type(StrategyModule) == type

    display = Display()

    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=DataLoader()),
        variable_manager=VariableManager(),
        loader=DataLoader(),
        options=Options(),
        passwords=None,
        display=display
    )

    host_pinned = StrategyModule(tqm)
    assert host_pinned._host_pinned

# Generated at 2022-06-23 13:03:16.847295
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()
    assert not s

# Generated at 2022-06-23 13:03:17.885322
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-23 13:03:20.955246
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "tqm"
    my_object = StrategyModule(tqm)
    assert my_object.tqm == "tqm"
    assert my_object._host_pinned == True

# Generated at 2022-06-23 13:03:33.456091
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host, Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.module_utils._text import to_text
    from ansible import context
    import pytest

    fake_loader = DataLoader()


# Generated at 2022-06-23 13:03:34.624629
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    StrategyModule()

# Generated at 2022-06-23 13:03:36.336395
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm = None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:03:37.987360
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm=None)



# Generated at 2022-06-23 13:03:39.886634
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)
    assert StrategyModule(None)._host_pinned == True



# Generated at 2022-06-23 13:03:40.341637
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:03:42.106330
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm = 'dummy_tqm')
    assert(strategy_module._host_pinned == True)

# Generated at 2022-06-23 13:03:43.876501
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm='test')

# Generated at 2022-06-23 13:03:45.128975
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '__init__')

# Generated at 2022-06-23 13:03:46.006561
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:03:46.667971
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:03:47.549407
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-23 13:03:53.126328
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("TESTING: StrategyModule")
    tqm = object
    strategyModule = StrategyModule(tqm)
    assert strategyModule._host_pinned == True
    assert strategyModule._batch_size == 1
    assert strategyModule._tqm == tqm
    assert strategyModule.display == display
    assert strategyModule.name == 'host_pinned'


# Generated at 2022-06-23 13:03:54.224988
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = StrategyModule("")

# Generated at 2022-06-23 13:03:57.725645
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert isinstance(strategy_module, StrategyModule)
    assert isinstance(strategy_module, FreeStrategyModule)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:04:06.876494
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    try:
        s = StrategyModule(None)
        assert s._host_pinned == True
        assert s._display.verbosity == 3
        assert s._tqm == None
        assert s._inventory == None
        assert s._variable_manager == None
        assert s._loader == None
        assert s._play_context == None
        assert s._all_hosts == None
        assert s._unreachable_hosts == []
        assert s._failed_hosts == []
    except Exception as e:
        print("Error in constructor of class StrategyModule")
        print(e)
        assert False



# Generated at 2022-06-23 13:04:07.889306
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule("tqm")
    assert s._host_pinned

# Generated at 2022-06-23 13:04:09.193498
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)._host_pinned == True



# Generated at 2022-06-23 13:04:10.189546
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1==1


# Generated at 2022-06-23 13:04:13.663504
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a StrategyModule object
    obj = StrategyModule(tqm = 'tqm')

    # Check the initialization of the StrategyModule object
    assert obj._host_pinned == True

# Generated at 2022-06-23 13:04:15.365737
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm="tqm")
    assert s
    assert s._host_pinned == True

# Generated at 2022-06-23 13:04:18.100665
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm=Test_tqm
    g=StrategyModule(tqm)

# Constructor of class Test_tqm

# Generated at 2022-06-23 13:04:20.195201
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert(strategy_module._host_pinned == True)
    assert(strategy_module._display == Display())

# Generated at 2022-06-23 13:04:22.813751
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    TASK_QUEUE_MANAGER = None
    strategy = StrategyModule(TASK_QUEUE_MANAGER)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:04:24.050510
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == FreeStrategyModule.__doc__

# Generated at 2022-06-23 13:04:26.236928
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-23 13:04:27.896297
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm = "test")
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:04:30.919112
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm="tqm")
    assert obj._host_pinned is True

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:04:33.645626
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test constructor of class StrategyModule
    strategy_module = StrategyModule('tqm')
    assert strategy_module._host_pinned

# Generated at 2022-06-23 13:04:34.662640
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-23 13:04:44.749752
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.inventory import Inventory
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.cli import CLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-23 13:04:46.092725
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    s = StrategyModule(tqm)

# Generated at 2022-06-23 13:04:46.694464
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:04:48.488088
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert(s)



# Generated at 2022-06-23 13:04:49.829576
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule('Test')
    assert module._host_pinned is True

# Generated at 2022-06-23 13:05:01.112066
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    options = {}
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 13:05:02.077403
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # TODO: implement any required unit tests
    pass

# Generated at 2022-06-23 13:05:02.651227
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    t = StrategyModule()

# Generated at 2022-06-23 13:05:14.627239
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from copy import deepcopy
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor


    HOSTS = [
        "fake_host1",
        "fake_host2",
        "fake_host3"
    ]
    EXTRA_VARS = [
        "extra_var1",
        "extra_var2",
        "extra_var3",
    ]

    group = Group("fake_group")
    for host in HOSTS:
        new_host = Host(host)
        group.add_host(new_host)


# Generated at 2022-06-23 13:05:16.068434
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned

# Generated at 2022-06-23 13:05:24.873429
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from units.mock.loader import DictDataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    loader = DictDataLoader({'ping.yml': '''---
- hosts: all
  tasks:
    - ping:
'''})
    play_source =  dict(name = "AnsiballZ Mock Play",
                        hosts = 'all',
                        gather_facts = 'no',
                        tasks = [dict(action=dict(module='ping', args=''))])
    play = Play().load(play_source, loader=loader, variable_manager=None, loader_cache=None)

# Generated at 2022-06-23 13:05:28.525891
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy_host_pinned as strategy_host_pinned
    strategy_host_pinned.display = object()
    tqm = object()
    strategy_host_pinned.StrategyModule(tqm)
    assert strategy_host_pinned.StrategyModule.__mro__[1] is strategy_host_pinned.FreeStrategyModule

# Generated at 2022-06-23 13:05:31.003336
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    StrategyModule(None)
    ansible.plugins.strategy.host_pinned.StrategyModule(None)

# Generated at 2022-06-23 13:05:31.970482
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule(None)._host_pinned == True)

# Generated at 2022-06-23 13:05:41.397457
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    from ansible.plugins.strategy.host_pinned import StrategyModule
    tqm = None

    assert issubclass(StrategyModule, FreeStrategyModule)
    strategyModule = StrategyModule(tqm)
    assert strategyModule is not None
    assert strategyModule._host_pinned

    from ansible.plugins.strategy.host_pinned import StrategyModule

    tqm = None

    assert issubclass(StrategyModule, FreeStrategyModule)
    strategyModule = StrategyModule(tqm)
    assert strategyModule is not None
    assert strategyModule._host_pinned

# Generated at 2022-06-23 13:05:42.874129
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = StrategyModule()


# Generated at 2022-06-23 13:05:44.636910
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  strategy_module = StrategyModule(tqm)
  assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:05:45.856713
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('test')
    assert strategy_module._host_pinned

# Generated at 2022-06-23 13:05:47.577544
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm = None)
    assert strategy_module
    assert strategy_module._host_pinned

# Generated at 2022-06-23 13:05:48.673829
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule('test')


# Generated at 2022-06-23 13:05:51.549373
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm._host_pinned



# Generated at 2022-06-23 13:05:54.044709
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    test_strategy_module = StrategyModule(tqm)
    assert test_strategy_module._host_pinned

# Generated at 2022-06-23 13:05:54.690508
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:05:55.297684
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-23 13:05:56.903573
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    fsm = StrategyModule()
    assert fsm._host_pinned is True

# Generated at 2022-06-23 13:05:59.090126
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm = ["test_tqm"])

    assert obj._host_pinned == True

# Generated at 2022-06-23 13:06:00.945602
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-23 13:06:01.556075
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:06:03.376409
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)


StrategyModule.cleanup('host_pinned')

# Generated at 2022-06-23 13:06:06.314273
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned == True


# Generated at 2022-06-23 13:06:08.833869
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str_obj = StrategyModule()
    assert str_obj._host_pinned == True
    assert isinstance(str_obj, FreeStrategyModule) is True

# Generated at 2022-06-23 13:06:10.263610
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert False, "Test not implemented"

# Generated at 2022-06-23 13:06:12.315750
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test 1: Test if class can be constructed")
    if StrategyModule:
        assert True
    else:
        assert False

# Generated at 2022-06-23 13:06:14.144694
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm="default")


# Generated at 2022-06-23 13:06:15.855802
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert isinstance(sm._host_pinned, bool)

# Generated at 2022-06-23 13:06:16.369675
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert False is False

# Generated at 2022-06-23 13:06:18.058778
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    print(strategy._host_pinned)

# Generated at 2022-06-23 13:06:18.589341
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-23 13:06:24.334838
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy as strategy
    from collections import namedtuple
    FakeTqm = namedtuple('FakeTqm', ['host_queue'])
    tqm = FakeTqm(
        host_queue=namedtuple('FakeHostQueue', ['task_queue'])(
            task_queue=[
                namedtuple('FakeTaskQueue', ['serial_groups'])(
                    serial_groups=[
                        namedtuple('FakeSerialGroup', ['tasks'])(
                            tasks=[
                                namedtuple('FakeTask', ['serial'])(serial='')
                            ]
                        )
                    ]
                )
            ]
        )
    )
    assert strategy.host_pinned.StrategyModule(tqm)

# Generated at 2022-06-23 13:06:24.973003
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-23 13:06:26.795430
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)._host_pinned == True

# Generated at 2022-06-23 13:06:30.304163
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Unit test for constructor of class StrategyModule
    """
    strategyModule = StrategyModule(tqm=None)
    assert strategyModule._host_pinned == True

# Generated at 2022-06-23 13:06:31.672903
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule(None)
    assert strategyModule._host_pinned == True

# Generated at 2022-06-23 13:06:32.644045
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass # This class has no constructor

# Generated at 2022-06-23 13:06:34.316431
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=1)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:06:36.050158
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule()
    assert StrategyModule(tqm)

# Generated at 2022-06-23 13:06:36.544439
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:06:37.847524
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    assert obj._host_pinned == True


# Generated at 2022-06-23 13:06:40.984426
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global display
    display = Display()
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy is not None
    assert strategy.__doc__ is not None
    assert strategy.name is not None

# Generated at 2022-06-23 13:06:45.239596
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    try:
        assert StrategyModule(tqm)
    except:
        assert False, "StrategyModule() constructor failed"
    else:
        assert True


# Generated at 2022-06-23 13:06:45.859057
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:06:47.283473
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    m = StrategyModule(tqm)
    assert m._host_pinned == True

# Generated at 2022-06-23 13:06:47.875909
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert (StrategyModule)


# Generated at 2022-06-23 13:06:48.476248
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule("") is not None


# Generated at 2022-06-23 13:06:48.958395
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:06:50.085410
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    st = StrategyModule(1)
    assert st._host_pinned is True

# Generated at 2022-06-23 13:06:51.745550
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(1)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:06:53.935224
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sample = StrategyModule(tqm="tqm")
    sample._host_pinned == True
    return sample

test = test_StrategyModule()

# Generated at 2022-06-23 13:06:54.891712
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-23 13:06:57.957932
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_obj = StrategyModule(tqm)
    host_pinned_value = strategy_obj._host_pinned
    assert host_pinned_value is True

# Generated at 2022-06-23 13:07:01.553582
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned == True


if __name__ == '__main__':
    import pytest
    pytest.main()

# Generated at 2022-06-23 13:07:06.749952
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        from ansible.plugins.strategy.host_pinned import StrategyModule
        strategy_obj = StrategyModule()
    except:
        print("Could not create StrategyModule object")
        assert 1
    else:
        print("StrategyModule object created")
        assert 0

# Generated at 2022-06-23 13:07:08.972260
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    assert isinstance(obj._host_pinned, bool)

# Generated at 2022-06-23 13:07:10.866095
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    TQM = "TQM"
    strategy = StrategyModule(TQM)
    assert strategy._host_pinned == True


# Generated at 2022-06-23 13:07:11.502754
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:07:13.942990
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None
    strategy = StrategyModule('tqm')
    assert strategy is not None
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:07:19.168759
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from collections import namedtuple
    from ansible.plugins.strategy.host_pinned import StrategyModule
    tqm = namedtuple('TQM', ['host_pinned'])
    tqm.host_pinned = 'host_pinned'
    strategyModule = StrategyModule(tqm)


# Generated at 2022-06-23 13:07:23.680806
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.display import Display
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    tqm = {'_inventory': {}, '_options': {}, '_variables': {}, 'basedir': '', 'callbacks': {}, 'stats': {}}
    FreeStrategyModule(tqm)
    StrategyModule(tqm)

# Generated at 2022-06-23 13:07:24.538791
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  StrategyModule(tqm)

# Generated at 2022-06-23 13:07:29.370573
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from mock import MagicMock
    tqm = MagicMock()
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned is True

# Generated at 2022-06-23 13:07:34.324761
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class test_tqm(object):
        def __init__(self):
            self.fifo = 0
            self.serial = 10
            self.stats = {
                                              }
            self.cur_serial = 1

    test_strategyModule = StrategyModule(test_tqm)
    assert test_strategyModule._host_pinned == True


# Generated at 2022-06-23 13:07:40.350487
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    from unittest import TestCase
    from ansible.plugins.strategy.host_pinned import StrategyModule
    import ansible.plugins.strategy.free
    class TestStrategyModule(TestCase):
        def test_strategy_pinned(self):
            StrategyModule(ansible.plugins.strategy.free.StrategyModule)
    test = TestStrategyModule()
    test.test_strategy_pinned()

# Generated at 2022-06-23 13:07:42.862608
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Instantiate a strategy object
    strategy_object = StrategyModule("")
    # Test if object is an instance of class StrategyModule
    assert isinstance(strategy_object, StrategyModule)

# Generated at 2022-06-23 13:07:45.344393
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM:
        pass
    t = TQM()
    p = StrategyModule(t)
    assert p._host_pinned is True

# Generated at 2022-06-23 13:07:46.470470
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = object()
  StrategyModule(tqm)


# Generated at 2022-06-23 13:07:47.158523
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-23 13:07:48.936653
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test successful")

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:07:59.734199
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import  __init__
    from ansible.executor import  task_queue_manager
    from ansible.inventory import  inventory
    from ansible.vars import  variable_manager
    inven = inventory.Inventory(__init__.DEFAULT_HOST_LIST)
    variable_manager = variable_manager.VariableManager(inven)

# Generated at 2022-06-23 13:08:01.656835
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    tqm = object()
    res = StrategyModule(tqm)
    assert res._host_pinned is True

# Generated at 2022-06-23 13:08:02.951930
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm='') # constructor test


# Generated at 2022-06-23 13:08:03.981611
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-23 13:08:05.794081
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)
    assert strategy is not None
    assert strategy._host_pinned == True




# Generated at 2022-06-23 13:08:06.297867
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:08:08.165172
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   strategy_module = StrategyModule()
   assert strategy_module is not None


# Generated at 2022-06-23 13:08:11.419055
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Init StrategyModule with None should raise exception
    try:
        StrategyModule(None)
    except Exception as e:
        assert type(e) == TypeError



# Generated at 2022-06-23 13:08:12.814247
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule.__init__(FreeStrategyModule(tqm=None), tqm=None))


# Generated at 2022-06-23 13:08:15.633781
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    assert isinstance(StrategyModule(tqm), StrategyModule)
    assert isinstance(StrategyModule(tqm), FreeStrategyModule)

# Generated at 2022-06-23 13:08:17.025829
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:08:22.945644
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(
        inventory = None,
        variable_manager = None,
        loader = None,
        options = None,
        passwords = None,
        stdout_callback = None,
    )

    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned

# Generated at 2022-06-23 13:08:25.249321
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm = 'some tqm')
    assert s._host_pinned

# Generated at 2022-06-23 13:08:28.838976
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    list_of_tqm = [(1,2,3), (4,5,6)]
    for tqm in list_of_tqm:
        StrategyModule(tqm)


# Generated at 2022-06-23 13:08:31.810114
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    a = ansible.plugins.strategy.host_pinned.StrategyModule(tqm = 0)
    assert a._host_pinned == True

# Generated at 2022-06-23 13:08:35.304227
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test_tqm'
    x = StrategyModule(tqm)
    assert x._host_pinned == True

# Generated at 2022-06-23 13:08:37.293495
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  display = Display()
  tqm = TaskQueueManager(Display())
  StrategyModule(tqm)

# Generated at 2022-06-23 13:08:39.967527
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Test constructor of class StrategyModule
    '''
    tqm = None
    assert StrategyModule(tqm)

# Generated at 2022-06-23 13:08:41.876085
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule("tqm")
    assert module._host_pinned is True

# end of StrategyModule class

# Generated at 2022-06-23 13:08:44.721618
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   tqm = None
   test_obj = StrategyModule(tqm)
   assert test_obj != None

# Generated at 2022-06-23 13:08:45.302879
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:08:45.827089
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:08:47.585241
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule(None)
    assert x._host_pinned

# Generated at 2022-06-23 13:08:52.717498
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # assert that display is a global variable in module StrategyModule
    assert ('display' in dir(StrategyModule))
    # assert that display is an instance of the class Display
    assert (isinstance(display, Display))
    # assert that StrategyModule is a subclass of FreeStrategyModule
    assert (issubclass(StrategyModule, FreeStrategyModule))
    # assert that class StrategyModule has a constructor
    assert (callable(StrategyModule))
    # assert that class StrategyModule has a __init__ function
    assert (hasattr(StrategyModule, "__init__"))
    # assert that __init__ function of class StrategyModule is a constructor
    assert (StrategyModule.__init__.__objclass__ is StrategyModule)

# Generated at 2022-06-23 13:08:53.802856
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy is not None

# Generated at 2022-06-23 13:08:55.785470
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tmp = StrategyModule(tqm='tqm')
    assert tmp._host_pinned == True

# Generated at 2022-06-23 13:08:57.216521
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(1) != None

# Generated at 2022-06-23 13:08:58.004018
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:08:59.021501
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('tqm')

# Generated at 2022-06-23 13:09:01.476516
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    
    obj = StrategyModule(tqm)
    assert obj._host_pinned == True
    assert obj._display == display

# Generated at 2022-06-23 13:09:04.439532
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Create a StrategyModule object with
    # required args
    strategy_obj = StrategyModule('tqm')
    assert strategy_obj._host_pinned == True

# Generated at 2022-06-23 13:09:11.030071
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    display = Display()
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule

    class TestStrategyModule(FreeStrategyModule):

        def __init__(self, tqm):
            super(StrategyModule, self).__init__(tqm)
            self._host_pinned = True

    strategy_class = TestStrategyModule(display)
    assert strategy_class is not None

# Generated at 2022-06-23 13:09:14.751635
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = 'free'
    display = Display()
    strategy_module = StrategyModule(strategy, display)
    assert strategy_module is not None
    assert strategy_module.get_type() == 'host_pinned'

# Generated at 2022-06-23 13:09:16.782885
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    # pylint: disable=unused-variable,unused-argument
    sm = StrategyModule(tqm)

# Generated at 2022-06-23 13:09:18.163956
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    m = StrategyModule()
    assert m != None

# Generated at 2022-06-23 13:09:20.605433
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("tqm")
    assert(strategy_module._host_pinned == True)

# Generated at 2022-06-23 13:09:21.695975
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule()
    assert a is not None

# Generated at 2022-06-23 13:09:24.095695
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule   
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:09:25.722288
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    c = StrategyModule('test_tqm')
    assert c.get_host_pinned() == True

# Generated at 2022-06-23 13:09:33.754127
# Unit test for constructor of class StrategyModule
def test_StrategyModule():


    import unittest
    from ansible.plugins.strategy.free import StrategyModule

    class TestStrategyModule(unittest.TestCase):

        def setUp(self):
            self.strategy_module = StrategyModule(tqm=None)

        def tearDown(self):
            self.strategy_module = None

        def test_constructor(self):
            self.assertequals(self.strategy_module._host_pinned, True)

    unittest.main()

# Generated at 2022-06-23 13:09:36.372612
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module

# Generated at 2022-06-23 13:09:38.496482
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    m_task = StrategyModule()
    assert m_task._host_pinned is True #pylint: disable=protected-access

# Generated at 2022-06-23 13:09:39.203223
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:09:42.499569
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {'name': 'test_tqm'}
    test = StrategyModule(tqm)
    assert test is not None
    assert test._host_pinned == True
    assert test._tqm == tqm

# Generated at 2022-06-23 13:09:50.759917
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = '192.168.112.100'
    ip_addr = '192.168.112.100'
    port = 22
    uid = 'root'
    groups = ['test_group']
    hostname = 'test'
    vm_type = 'vmware'
    vm_uuid = 'test'
    vm_name = 'test'
    vm_state = 'test'
    vm_provider = 'test'
    is_local = True
    TaskQueueManager = MockTaskQueueManager()
    strategy_module_obj = StrategyModule(TaskQueueManager)
    assert strategy_module_obj != None
    assert strategy_module_obj._host_pinned == True

#Mock class

# Generated at 2022-06-23 13:09:55.467569
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(mock.MagicMock())
    assert strategy_module._host_pinned == True
    assert strategy_module._tqm
    assert strategy_module._inventory
    assert strategy_module._loader
    assert strategy_module._variable_manager
    assert strategy_module._strategy_lock
    assert strategy_module._name
    assert strategy_module._failed_hosts
    assert strategy_module._unreachable_hosts
    assert strategy_module._done

# Generated at 2022-06-23 13:09:57.588985
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)
    assert not strategy is None, "Strategy is not created"


# Generated at 2022-06-23 13:10:00.732127
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    test = ansible.plugins.strategy.host_pinned.StrategyModule(None)
    assert test._host_pinned == True

# Generated at 2022-06-23 13:10:02.750040
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert s._host_pinned == True



# Generated at 2022-06-23 13:10:03.664617
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == True

# Generated at 2022-06-23 13:10:08.458941
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import collections
    import ansible.plugins.strategy.host_pinned
    display = ansible.utils.display.Display()
    tqm = collections.namedtuple('TQM', 'display')
    a = ansible.plugins.strategy.host_pinned.StrategyModule(tqm(display))
    assert a._host_pinned == True


# Generated at 2022-06-23 13:10:09.070941
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:10:11.562482
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    assert obj._host_pinned is True

if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-23 13:10:12.160728
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:10:13.572565
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned

# Generated at 2022-06-23 13:10:15.090955
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = StrategyModule()
    assert host.host_pinned == True

# Generated at 2022-06-23 13:10:15.788372
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:10:18.308525
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.current_screen = None
    tqm = "tqm"
    StrategyModule(tqm)
    display.current_screen = None
    assert True

# Generated at 2022-06-23 13:10:19.379116
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '__init__')

# Generated at 2022-06-23 13:10:22.756044
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    tqm = 'tqm'
    strategy_module = StrategyModule(tqm)
    assert(strategy_module._host_pinned)

# Generated at 2022-06-23 13:10:24.275450
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm=None)
    assert module._host_pinned == True

# Generated at 2022-06-23 13:10:25.064204
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:10:26.665007
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule != None)

# Generated at 2022-06-23 13:10:29.748483
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    mod = ansible.plugins.strategy.host_pinned.StrategyModule(None)

# Generated at 2022-06-23 13:10:40.626175
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """

    :return:
    """
    import json
    import mock
    import unittest

    try:
        from ansible.plugins.strategy_plugins.host_pinned import StrategyModule
    except ImportError as e:
        raise unittest.SkipTest("Failed to load strategy_plugins.host_pinned module: %s" % e)

    class TQM(object):
        """
        Fake task queue manager
        """
        def __init__(self):
            self._stats = None
            self._final_q = None
            self._failed_hosts = None
            self._unreachable_hosts = None
            self._inventory = None

        @property
        def stats(self):
            return self._stats

        @stats.setter
        def stats(self, stats):
            self._stats

# Generated at 2022-06-23 13:10:43.682702
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(), StrategyModule)

# example code to check if StrategyModule works
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:10:50.733110
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    strategy_host_pinned.py
    This file is the 'test_StrategyModule' function in the strategy_host_pinned.py file.
    It tests the constructor of the class StrategyModule defined in the 'free' strategy plugin
    which is extended in this strategy plugin.
    :return:
    """
    from collections import namedtuple
    from ansible.plugins.strategy.free import StrategyModule
    tqm = namedtuple("tqm", ["_final_q"])(
        namedtuple("_final_q", ["empty"])(False)
    )
    host_pinned = StrategyModule(tqm)
    assert host_pinned._tqm is tqm
    assert not host_pinned._tqm._final_q.empty

# Generated at 2022-06-23 13:10:52.065754
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:10:54.317118
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm="tqm")
    assert strategy_module is not None

# Generated at 2022-06-23 13:10:56.090472
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.deprecated("Testing StrategyModule")
    StrategyModule(None)

# Generated at 2022-06-23 13:11:05.625231
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import context
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.display import Display
    import os

    display = Display()
    basedir = os.path.split(__file__)[0]
    if not basedir:
        basedir = '.'

    context.CLIARGS = {}
    context.CLIARGS['inventory'] = os.path.join(basedir, '../inventory')
    context.CLIARGS['module_path'] = os.path.join(basedir, '../library')
    context.CLIARGS['forks'] = 20


# Generated at 2022-06-23 13:11:06.899179
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule("tqm")

# Generated at 2022-06-23 13:11:16.535901
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.loader import module_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible import context

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["127.0.0.1"])
    play_source =  dict(name = "Ansible Play",
                        hosts = 'localhost',
                        gather_facts = 'no',
                        tasks = [
                            dict(action=dict(module='debug', args=dict(msg='Hello World')))
                            ]
                        )

    play = Play

# Generated at 2022-06-23 13:11:18.383451
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None  # type: TaskQueueManager
    module = StrategyModule(tqm)
    assert module._host_pinned is True
    pass

# Generated at 2022-06-23 13:11:21.829832
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned


# Generated at 2022-06-23 13:11:22.803751
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 13:11:28.347274
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy import add_tqm_attribute
    tqm = add_tqm_attribute(object())
    x = StrategyModule(tqm)
    assert x._host_pinned is True

# Generated at 2022-06-23 13:11:34.305477
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {'_non_uniform_objs':{'test_display':1}}
    sm = StrategyModule(tqm)
    assert sm._queue == 'linear'
    assert sm._display == 'test_display'
    assert sm._play_context == None
    assert sm._batch_size == None
    assert sm._variable_manager == None
    assert sm._strategy == None
    assert sm._iterator == None
    assert sm._host_pinned



# Generated at 2022-06-23 13:11:36.360390
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("tqm")
    assert strategy_module._host_pinned is True

# Generated at 2022-06-23 13:11:39.759723
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(None)
    assert obj._host_pinned == True


# ==============================================================================
# == Execute strategy
# ==============================================================================


# Generated at 2022-06-23 13:11:40.629197
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:11:51.512060
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-23 13:12:03.404715
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.playbook
    import ansible.playbook.task
    import ansible.playbook.play
    import ansible.runner
    import ansible.inventory
    import ansible.callbacks
    import ansible.stats
    import ansible.vars
    import ansible.utils.template
    import ansible.errors
    import ansible.constants

    import os, tempfile, sys
    from ansible.module_utils.hashivault import hashivault_argspec

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    pb = ansible.playbook.PlayBook()

    class FakeHost(Host):
        def __init__(self, hostname, port=None):
            self.hostname = hostname
            self.port = port