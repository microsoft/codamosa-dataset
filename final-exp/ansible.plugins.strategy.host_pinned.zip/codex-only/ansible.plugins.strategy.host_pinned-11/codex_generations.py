

# Generated at 2022-06-23 13:02:04.355665
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:02:05.050433
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:02:06.375920
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm._host_pinned

# Generated at 2022-06-23 13:02:08.382528
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 0
    s = StrategyModule(tqm)
    assert s._host_pinned is True

# Generated at 2022-06-23 13:02:10.476961
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ''' Unit test for constructor of class StrategyModule '''
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:02:11.943609
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:02:13.099030
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)

# Generated at 2022-06-23 13:02:14.733645
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tdict = {} #faked tqm
    strategy = StrategyModule(tdict)
    assert(strategy._host_pinned == True)

# Generated at 2022-06-23 13:02:17.260530
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  assert StrategyModule


from ansible.plugins.strategy.host_pinned import StrategyModule

# Generated at 2022-06-23 13:02:19.067914
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test Strategy Module Constructor")
    temp = StrategyModule(None)
    print("Test Strategy Module Constructor is completed")


# Generated at 2022-06-23 13:02:21.799585
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ''' Test class constructor '''
    free_strategy = StrategyModule(None)
    assert free_strategy._host_pinned == True

# Generated at 2022-06-23 13:02:23.462076
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-23 13:02:25.881151
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Tests the constructor of class StrategyModule
    tqm = StrategyModule('tqm')
    assert tqm._host_pinned == True

# Generated at 2022-06-23 13:02:27.317289
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-23 13:02:27.984854
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:02:29.674535
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule()
    assert(x._host_pinned == True)

# Generated at 2022-06-23 13:02:32.384350
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '_host_pinned')
    assert StrategyModule._host_pinned is True
    assert hasattr(StrategyModule, 'display')
    assert isinstance(StrategyModule.display, Display)

# Generated at 2022-06-23 13:02:34.378359
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)


# Generated at 2022-06-23 13:02:45.550523
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        from ansible.plugins.strategy.host_pinned import StrategyModule
        from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
        assert issubclass(StrategyModule, FreeStrategyModule)
        assert StrategyModule.__name__ == "StrategyModule"
    except (ImportError, AssertionError) as e:
        display.error(e)

# Generated at 2022-06-23 13:02:46.359986
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:02:50.573972
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    tqm = Tqm(inventory=None, variable_manager=None, loader=None, options=None, passwords=None)

    strategy = StrategyModule(tqm)

    assert strategy._host_pinned == True



# Generated at 2022-06-23 13:02:51.697271
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Generated at 2022-06-23 13:02:57.706692
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor import task_queue_manager
    # Create a TaskQueueManager with the StrategyModule
    tqm = task_queue_manager.TaskQueueManager(strategy='host_pinned',
                                              inventory='./inventory',
                                              variable_manager='./group_vars',
                                              loader=None,
                                              passwords=dict(),
                                              stdout_callback='foo')
    strategy_module = tqm._update_strategy_class('host_pinned')
    assert strategy_module._host_pinned is True

# Generated at 2022-06-23 13:02:59.702394
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm = 'some_tqm')

# Generated at 2022-06-23 13:03:01.033035
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:03:03.168336
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test = StrategyModule('tqm')
    assert test._host_pinned == True

# Generated at 2022-06-23 13:03:04.117555
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)

# Generated at 2022-06-23 13:03:05.498469
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    foo = StrategyModule()
    print(foo)
    assert True

# Generated at 2022-06-23 13:03:07.363322
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:03:08.514658
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ll = StrategyModule()
    assert ll

# Generated at 2022-06-23 13:03:09.575854
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule()
    assert a is not None

# Generated at 2022-06-23 13:03:14.532970
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    brain = StrategyModule(tqm={})
    tmp = brain._host_pinned
    assert tmp


# Load the strategy into the main namespace so it can be used by ansible-playbook
# and ansible-project
# noinspection PyUnresolvedReferences
from ansible.plugins.strategy.host_pinned import *

# Generated at 2022-06-23 13:03:16.283025
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    display.assertEqual(strategy._host_pinned, True)

# Generated at 2022-06-23 13:03:19.228026
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = DummyTqm()
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True
    assert sm._display.display == True
    assert sm._display.verbosity == 0

# Dummy TestQueueManager class for unit testing

# Generated at 2022-06-23 13:03:23.569567
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor import task_result_strategy_plugin
    tqm = task_result_strategy_plugin.TaskResultStrategyModule()
    assert StrategyModule(tqm)
    #assert StrategyModule(tqm)._host_pinned == True


# Generated at 2022-06-23 13:03:24.245154
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return True

# Generated at 2022-06-23 13:03:33.052547
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # creating a mock object of class Display
    mock_display = Display()
    # creating a mock object of class TQM
    mock_tqm = TQM(inventory=None, variable_manager=None, loader=None, options=None, passwords=None, stdout_callback=None)
    # creating a object of class StrategyModule with mocked objects
    object_StrategyModule = StrategyModule(mock_tqm)
    # checking for the value of self._host_pinned
    assert object_StrategyModule._host_pinned == True

# Generated at 2022-06-23 13:03:33.657032
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == True

# Generated at 2022-06-23 13:03:34.876413
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None) is not None

# Generated at 2022-06-23 13:03:43.423708
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from collections import namedtuple
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common._collections_compat import MutableMapping
    # create the TQM object that runs it all

# Generated at 2022-06-23 13:03:44.134926
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:03:48.614610
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
      Test StrategyModule class constructor
    """
    # Test default case:
    display.verbosity = 99
    try:
        tqm = True
        ans = StrategyModule(tqm)
        assert ans
        assert ans._host_pinned
    finally:
        display.verbosity = 0

# Generated at 2022-06-23 13:03:52.756376
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert not sm._host_pinned
    sm = StrategyModule(None)
    assert sm._host_pinned

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:03:53.869274
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-23 13:03:54.884702
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)

# Generated at 2022-06-23 13:03:56.674619
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    assert StrategyModule(tqm)

# Generated at 2022-06-23 13:03:58.950961
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #Unit test case#
    assert StrategyModule.__init__.__doc__ == FreeStrategyModule.__init__.__doc__

# Generated at 2022-06-23 13:04:00.019348
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 13:04:01.948153
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert isinstance(s,StrategyModule)


# Generated at 2022-06-23 13:04:03.544364
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule(tqm="")
    assert x._host_pinned == True

# Generated at 2022-06-23 13:04:05.124201
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_StrategyModule = StrategyModule()
    assert test_StrategyModule

# Generated at 2022-06-23 13:04:08.966928
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import context
    from ansible.executor.task_queue_manager import TaskQueueManager

    context.CLIARGS = ImmutableDict()
    tqm = TaskQueueManager(context.CLIARGS)

    sm = StrategyModule(tqm)
    assert sm._host_pinned

# Generated at 2022-06-23 13:04:10.453570
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm1 = StrategyModule(None)
    assert sm1 is not None


# Generated at 2022-06-23 13:04:12.746049
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    fake_tqm = {}
    sm = StrategyModule(fake_tqm)

# Generated at 2022-06-23 13:04:13.857102
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__

# Generated at 2022-06-23 13:04:16.379979
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    new_strat = StrategyModule()
    assert(new_strat._host_pinned)

test_StrategyModule()

# Generated at 2022-06-23 13:04:18.352563
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm=None)
    assert s._host_pinned == True

# Generated at 2022-06-23 13:04:19.315179
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    assert True

# Generated at 2022-06-23 13:04:21.617327
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert isinstance(strategy_module, StrategyModule)

# Generated at 2022-06-23 13:04:22.904576
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    StrategyModule(tqm)

# Generated at 2022-06-23 13:04:24.066817
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm=None
    strategy_module= StrategyModule(test_tqm)

# Generated at 2022-06-23 13:04:26.920544
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule("test")

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:04:30.252986
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    obj = StrategyModule(tqm)
    param_host_pinned = obj._host_pinned
    assert param_host_pinned == True

# Generated at 2022-06-23 13:04:32.232425
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__.__code__.co_argcount == 2  # testing the constructor of class StrategyModule

# Generated at 2022-06-23 13:04:33.939575
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule('')
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:04:36.404212
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #This is not working yet.  Need to figure out how to set up a task queue manager for testing
    StrategyModule(tqm)

# Generated at 2022-06-23 13:04:37.013326
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:04:38.099220
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = Dummy()
    module = StrategyModule(tqm)
    assert module._host_pinned



# Generated at 2022-06-23 13:04:39.705435
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-23 13:04:40.966416
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# End of unit test

# Generated at 2022-06-23 13:04:43.800742
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    StrategyModule(tqm)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:04:45.599832
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule("""tqm""")
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:04:47.880746
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule('sm')
    assert sm._host_pinned == True



# Generated at 2022-06-23 13:04:58.704027
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    StrategyModule(tqm)

if __name__ == "__main__":
	setting = {}
	setting['inventory'] = 'localhost,127.0.0.1,'
	setting['module_name'] = 'host_pinned'
	setting['forks'] = 5
	setting['become'] = None
	setting['become_method'] = None
	setting['become_user'] = None
	setting['check'] = False
	setting['diff'] = False
	setting['private_key_file'] = None
	setting['remote_user'] = 'root'
	setting['ssh_common_args'] = None
	setting['ssh_extra_args'] = None
	setting['sftp_extra_args'] = None
	setting['scp_extra_args'] = None
	

# Generated at 2022-06-23 13:05:03.816841
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestHost:
        def __init__(self, name):
            self.name = name

    class TestTaskQueueManager:
        def __init__(self, hosts):
            self.hosts = hosts

    tqm_obj = TestTaskQueueManager([TestHost('localhost')])
    strategy_module_obj = StrategyModule(tqm_obj)
    assert strategy_module_obj._host_pinned is True

# Generated at 2022-06-23 13:05:05.372364
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '__init__')


# Generated at 2022-06-23 13:05:10.905837
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = {'_unreachable_hosts':set(), '_wrapped':'', '_final_state_stats':{}, '_play_context':{'become':False}, '_stats':{'processed':{}}}
  strategy = StrategyModule(tqm)
  assert strategy._host_pinned == True

# Generated at 2022-06-23 13:05:13.798525
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test StrategyModule constructor
    # Create a new StrategyModule class
    strategy_module = StrategyModule(None)


# Generated at 2022-06-23 13:05:15.738716
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ss = StrategyModule(None)
    assert ss._host_pinned == True


# Generated at 2022-06-23 13:05:20.782131
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy.host_pinned import StrategyModule

    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None,
    )
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned

# Generated at 2022-06-23 13:05:27.700164
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Test case for following function:
        StrategyModule.__init__(self, tqm)
    """
    tqm = test()
    StrategyModule(tqm)

"""
The following code is for testing the class StrategyModule with pytest
"""
import os
import sys
import pytest
from unittest.mock import create_autospec

sys.modules['ansible'] = create_autospec(sys.modules['ansible'])
sys.modules['ansible.plugins.strategy.free'] = create_autospec(sys.modules['ansible.plugins.strategy.free'])


# Generated at 2022-06-23 13:05:29.701087
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins
    # Test with default values
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module._host_pinned


# Generated at 2022-06-23 13:05:31.303540
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_strategy_module = StrategyModule(tqm=None)
    assert my_strategy_module._host_pinned == True

# Generated at 2022-06-23 13:05:35.330099
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    from ansible.plugins.strategy import get_strategy
    from ansible.executor.task_queue_manager import TaskQueueManager
    strategy = get_strategy('host_pinned')
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback='default',
        run_tree=False,
        terms=[],
        strategy=strategy
    )
    assert isinstance(tqm, TaskQueueManager)


# Test StrategyModule class with assert statements

# Generated at 2022-06-23 13:05:42.563061
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)
    assert hasattr(StrategyModule, '__init__')
    assert callable(StrategyModule.__init__)
    StrategyModule( tqm=None )
    return True

if __name__ == '__main__':
    if not test_StrategyModule():
        raise RuntimeError('Unit test of StrategyModule failed')
    else:
        print('Unit test of StrategyModule succeeded')

# Generated at 2022-06-23 13:05:45.089181
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    test = StrategyModule(tqm)
    assert(test._host_pinned is True)


# assert(test._host_pinned is True)

# Generated at 2022-06-23 13:05:46.298458
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-23 13:05:52.322693
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host,Group
    host = Host(name='dummy')
    host.set_variable('ansible_python_interpreter', '/usr/bin/python3')

    group1 = Group(name='group1')
    host.add_group(group1)
    group2 = Group(name='group2')
    host.add_group(group2)

    inventory = InventoryManager

# Generated at 2022-06-23 13:05:54.918787
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule

    # Test data
    tqm = ('[StrategyModule.__init__()] tqm = %s')

    tqm = StrategyModule(tqm)

    assert tqm is not None
    assert tqm == ('[StrategyModule.__init__()] tqm = %s')


# Generated at 2022-06-23 13:05:55.551575
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:05:56.033144
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule('test_StrategyModule')

# Generated at 2022-06-23 13:05:58.270366
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert(strategy_module._host_pinned)

# Generated at 2022-06-23 13:06:03.376343
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    tqm = None
    s = StrategyModule(tqm)
    assert s._host_pinned == True


# Generated at 2022-06-23 13:06:12.046722
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('### In StrategyModule unit test')
    from ansible.plugins.loader import strategy_loader

    strategy_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../../test/units/strategy/'))

    tqm = FakeTQManager({'strategy': 'host_pinned'})

    strategy = strategy_loader.get('host_pinned', tqm)

    assert strategy._host_pinned is True
    print('### StrategyModule unit test finished')


# Generated at 2022-06-23 13:06:20.286751
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Args():
        forks = 5
        serial = 3
    class tqm():
        hosts = ['127.0.0.1', '127.0.0.2', '127.0.0.3']
        args = Args()
    strategy = StrategyModule(tqm)
    assert strategy.host_pinned == True
    assert strategy.hosts_left == ['127.0.0.1', '127.0.0.2', '127.0.0.3']
    assert strategy.serial == 3
    assert strategy.forks == 5
    return True



# Generated at 2022-06-23 13:06:21.846812
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(object)
    assert strategy
    assert isinstance(strategy, FreeStrategyModule)
    assert strategy.display

# Generated at 2022-06-23 13:06:22.914485
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None) is not None

# Generated at 2022-06-23 13:06:24.351750
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-23 13:06:25.859675
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(isinstance(StrategyModule, type))



# Generated at 2022-06-23 13:06:26.797923
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:06:31.114959
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.debug('Entering test_StrategyModule')
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True
    display.debug('Exiting test_StrategyModule')

# Generated at 2022-06-23 13:06:32.457867
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:06:33.442741
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Generated at 2022-06-23 13:06:34.743841
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '_host_pinned') == True

# Generated at 2022-06-23 13:06:36.085191
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule, object)

# Generated at 2022-06-23 13:06:37.294339
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule(None)
    assert x
# end of test_StrategyModule

# Generated at 2022-06-23 13:06:39.138656
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    res = StrategyModule()
    assert(res._host_pinned == True)


# Generated at 2022-06-23 13:06:50.415607
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestStrategyModule(StrategyModule):
        def __init__(self, tqm):
            super(StrategyModule, self).__init__(tqm)
            self._host_pinned = True


# Generated at 2022-06-23 13:06:51.886245
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:06:53.716461
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__.startswith("Executes tasks on each host without interruption")

# Generated at 2022-06-23 13:06:54.751179
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule, type)

# Generated at 2022-06-23 13:06:55.772510
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True        #  No assert test required

# Generated at 2022-06-23 13:06:58.009863
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    test = StrategyModule(tqm=None)
    assert test._host_pinned is True

# Generated at 2022-06-23 13:06:59.705974
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:07:07.322035
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    # Create two mocks: Ansible to check arguments to API calls of StrategyModule
    # A second mock is needed to test the constructor of StrategyModule
    from mock import MagicMock
    # Create a mock of Ansible that will return a strategy module when the strategy API is called
    ansible_mock = MagicMock()
    ansible_mock.strategy = "TestStrategy"
    # Set side_effects in ansible_mock:
    ansible_mock.side_effect = \
        lambda strategy: StrategyModule(ansible_mock) if strategy == "TestStrategy" else None
    # Create a mock of TaskQueueManager
    tqm_mock = MagicMock(TaskQueueManager)
    # Create an instance of StrategyModule
    strategy_

# Generated at 2022-06-23 13:07:09.206574
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    unit test for StrategyModule class
    '''
    x = StrategyModule('tqm')
    assert x._host_pinned, "_host_pinned is not true"
    return x

# Generated at 2022-06-23 13:07:15.983974
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # initialize variable
    result = []
    # initialize class
    tqm = object
    test_class = StrategyModule(tqm)
    # check required function
    # check required attribute
    result.append(hasattr(test_class, "_host_pinned"))
    # check class name
    assert StrategyModule.__name__ == "StrategyModule"
    # check super class name
    assert StrategyModule.__bases__[0].__name__ == "FreeStrategyModule"
    # check required function
    assert callable(test_class.schedule)
    # check required function
    assert callable(test_class.get_next_task_lock)
    # check required function
    assert callable(test_class.get_next_task_lock)
    # check required function

# Generated at 2022-06-23 13:07:18.759545
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    result = StrategyModule(tqm)
    assert result is not None
    assert result._host_pinned is True

# Generated at 2022-06-23 13:07:19.350730
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:07:20.276769
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm = "value")

# Generated at 2022-06-23 13:07:21.197685
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-23 13:07:21.888498
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:07:28.321873
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = InventoryManager(loader=loader, sources=['localhost,'])

    play_context = PlayContext()
    play_context.network_os = 'default'
    play_context.remote_addr = None

# Generated at 2022-06-23 13:07:28.756084
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy == StrategyModule

# Generated at 2022-06-23 13:07:31.733728
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    Tqm = object
    tqm = Tqm
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned

# Generated at 2022-06-23 13:07:32.834755
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Executes tasks on each host without interruption
    '''
    pass

# Generated at 2022-06-23 13:07:34.796352
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:07:44.820417
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-23 13:07:45.662910
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(42)
    assert strategy

# Generated at 2022-06-23 13:07:48.060979
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Executing constructor test for class StrategyModule")
    strategy_obj = StrategyModule(None)
    assert strategy_obj._host_pinned


# Generated at 2022-06-23 13:07:49.154785
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:07:53.539085
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # NOTE: This is just a sample test.
    # You can edit this to add more test cases.
    #
    # For example:
    # tqm = AnsibleTest(["some_module"])
    # strategyModule = StrategyModule(tqm)
    # assert strategyModule is not None
    pass

# Generated at 2022-06-23 13:07:55.986892
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_strategy_module = StrategyModule(tqm=None)
    assert isinstance(test_strategy_module, StrategyModule)


# Generated at 2022-06-23 13:08:05.977466
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# class AnsibleTaskQueueManager(object):
#
#     def __init__(self):
#         return
#
#     def _finalize(self):
#         display.debug("finalizing queue manager")
#         return
#
#     def close(self):
#         return
#
#     def run(self):
#         return
#
#     def _next_play(self):
#         return
#
#     def _setup_global_vars(self):
#         return
#
#     def get_variable_manager(self):
#         return
#
#     def get_loader(self):
#         return
#
#     def get_inventory(self):
#         return
#


#
# def test_StrategyModule_init():
#     tqm = Ans

# Generated at 2022-06-23 13:08:08.621918
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:08:11.028176
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm=None)
    assert s._host_pinned == True

# Generated at 2022-06-23 13:08:19.548392
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = PLAYBOOK1
    strategy_module = StrategyModule(tqm)
    assert strategy_module.tqm == PLAYBOOK1
    assert strategy_module.display == Display()
    assert strategy_module._host_pinned == True

PLAYBOOK1 = "playbook1"

# Generated at 2022-06-23 13:08:21.174655
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass
# vim: set et sts=4 ts=4 sw=4 ft=python :

# Generated at 2022-06-23 13:08:22.163323
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_instance = StrategyModule(tqm=None)

# Generated at 2022-06-23 13:08:25.017131
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Dummy args for testing
    tqm = None
    module = StrategyModule(tqm)
    assert(module._host_pinned == True)

# Generated at 2022-06-23 13:08:26.944456
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    class TestStrategyModule(StrategyModule):
        pass

    assert TestStrategyModule(object())._host_pinned

# Generated at 2022-06-23 13:08:33.391547
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned = True
    tqm = {'defaults': {
            'strategy_plugins': '',
            'strategy': 'host_pinned',
            'strategy_dict': {'host_pinned': {'defaults': {'strategy': 'host_pinned'}}}}}
    strategy_instance = StrategyModule(tqm)
    assert strategy_instance._host_pinned == host_pinned
    assert strategy_instance._tqm == tqm

# Generated at 2022-06-23 13:08:37.714983
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule('tqm')
    if sm._host_pinned != True:
        print("Failed to initialize class StrategyModule")
        sys.exit(1)

# end of test StrategyModule


# Generated at 2022-06-23 13:08:40.872303
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test StrategyModule.__init__()
    tqm = 'tqm'
    strategy = StrategyModule(tqm)

    # Test StrategyModule._host_pinned
    assert strategy._host_pinned == True


# Generated at 2022-06-23 13:08:44.508029
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = []
    strategy_object = StrategyModule(tqm)
    assert strategy_object._host_pinned == True

# Generated at 2022-06-23 13:08:45.674376
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert s.get_host_pinned() is True

# Generated at 2022-06-23 13:08:48.245935
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    testObj = StrategyModule(tqm_inst)
    assert testObj._host_pinned == True
    assert testObj.tqm == tqm_inst


# Generated at 2022-06-23 13:08:49.960158
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__module__ == "ansible.plugins.strategy.host_pinned"

# Generated at 2022-06-23 13:08:58.440627
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == "Task execution is as fast as possible per host in batch as defined by C(serial) (default all).\n          Ansible will not start a play for a host unless the play can be finished without interruption by tasks for another host,\n          i.e. the number of hosts with an active play does not exceed the number of forks.\n          Ansible will not wait for other hosts to finish the current task before queuing the next task for a host that has finished.\n          Once a host is done with the play, it opens it's slot to a new host that was waiting to start.\n          Other than that, it behaves just like the \"free\" strategy."
    assert StrategyModule.__init__.__doc__ == "Initialize the strategy module, which applies to all hosts."

# Generated at 2022-06-23 13:08:59.385149
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule('tqm')
    assert s

# Generated at 2022-06-23 13:09:02.373202
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    obj = StrategyModule(tqm)
    assert obj is not None
    assert hasattr(obj, '_host_pinned')
    assert obj._host_pinned == True

# Generated at 2022-06-23 13:09:04.003811
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule('foobar')
    assert strategy is not None

# Generated at 2022-06-23 13:09:05.721514
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategyModule = StrategyModule(tqm)
    assert strategyModule._host_pinned == True

# Generated at 2022-06-23 13:09:07.546596
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule()
    assert module._host_pinned is True

# Generated at 2022-06-23 13:09:09.725904
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_instance = StrategyModule('tqm')
    assert test_instance

# Generated at 2022-06-23 13:09:10.424453
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test that class can be instantiated.
    StrategyModule("tqm")

# Generated at 2022-06-23 13:09:12.973221
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True
    assert strategy.get_host_pinned_value() == strategy._host_pinned
	
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:09:22.107560
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    '''
    Constructor for the class StrategyModule
    '''
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_executor import TaskExecutor

    tqm = TaskQueueManager(None, None, None, None, None, None, None, None, None)
    strategy = StrategyModule(tqm)
    assert (strategy is not None)

    tqm._number_of_instances = 3
    assert (strategy._number_of_instances == 3)

# Generated at 2022-06-23 13:09:26.232691
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = get_host(None)
    task = get_task(None)
    tqm = get_tqm(task, host)
    strategy = StrategyModule(tqm)
    assert strategy is not None
    return strategy

# test method of class StrategyModule

# Generated at 2022-06-23 13:09:26.936274
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:09:28.448293
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None) is not None

# Generated at 2022-06-23 13:09:30.703568
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ''' test class StrategyModule '''

    m = StrategyModule(None)
    assert  m._host_pinned == True

# Generated at 2022-06-23 13:09:32.698670
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule()
    c = StrategyModule(tqm)

    assert c._host_pinned == True

# Generated at 2022-06-23 13:09:33.889088
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__



# Generated at 2022-06-23 13:09:37.075737
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(None)
    assert module._host_pinned, '_host_pinned should be True'

# Generated at 2022-06-23 13:09:38.675917
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)


# Generated at 2022-06-23 13:09:39.374706
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:09:41.179628
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None) is not None


# Generated at 2022-06-23 13:09:42.922112
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module is not None
    assert strategy_module._host_pinned is True

# Generated at 2022-06-23 13:09:44.449052
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule(None)

# unit test for free

# Generated at 2022-06-23 13:09:45.998680
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule(tqm = None)
    assert mod._host_pinned == True

# Generated at 2022-06-23 13:09:47.265688
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule('default')
    assert s._host_pinned == True

# Generated at 2022-06-23 13:09:49.910460
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Test for constructor of class StrategyModule
        :return:
    """
    tqm = ""
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned

# Generated at 2022-06-23 13:09:50.411155
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:09:50.764694
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:09:51.948767
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(hasattr(StrategyModule, '__init__'))

# Generated at 2022-06-23 13:10:00.156685
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    context = PlayContext()
    play = Play.load(dict(
        name = "Ansible Play",
        hosts = 'webservers',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='setup', args=''))
        ]
    ), variable_manager=None, loader=None)
    tqm = None

# Generated at 2022-06-23 13:10:01.308174
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 13:10:04.276070
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_obj = StrategyModule(tqm)
    assert strategy_module_obj._host_pinned == True, "Host pinned is not true"

# Generated at 2022-06-23 13:10:05.477337
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	assert StrategyModule.__init__

# Generated at 2022-06-23 13:10:06.775990
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert(strategy._host_pinned == True)

# Generated at 2022-06-23 13:10:08.158757
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Generated at 2022-06-23 13:10:09.118470
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-23 13:10:19.742172
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import collections
    from ansible.parsing.dataloader import DataLoader

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyModule

    # Since the api is constructed for CLI it expects certain options to always be set, named tuple 'fakes' the args parsing options object

# Generated at 2022-06-23 13:10:21.413198
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test'
    StrategyModule(tqm)



# Generated at 2022-06-23 13:10:27.271151
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.utils.vars import AnsibleVars
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VarsManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator

    class Tqm(TaskQueueManager):
        def __init__(self, inventory=None, variable_manager=None, loader=None, options=None, passwords=None, stdout_callback=None):
            self.inventory = inventory
            self

# Generated at 2022-06-23 13:10:28.977940
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule({})
    assert(obj._host_pinned)

# Generated at 2022-06-23 13:10:30.982457
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm = True)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:10:34.366389
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert_constructor_for_module_type(StrategyModule, 'ansible.plugins.strategy.host_pinned.StrategyModule')

# Generated at 2022-06-23 13:10:36.089389
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule

# end of constructor test


# Generated at 2022-06-23 13:10:38.422169
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm is not None
    assert sm._host_pinned is True


# Generated at 2022-06-23 13:10:40.378684
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MockTQM()
    StrategyModule(tqm)


# Generated at 2022-06-23 13:10:42.612439
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    tqm = None
    test_object = StrategyModule(tqm)
    assert test_object._host_pinned == True

# Generated at 2022-06-23 13:10:44.243326
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(None)
    assert a._host_pinned == True

# Generated at 2022-06-23 13:10:44.930333
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert False

# Generated at 2022-06-23 13:10:48.496785
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'FreeStrategyModule'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'

# Generated at 2022-06-23 13:10:49.125906
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:10:52.921478
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test StrategyModule constructor
    pStratMdl = StrategyModule('')
    assert pStratMdl._host_pinned == True
    # Test StrategyModule constructor

# Generated at 2022-06-23 13:10:54.278287
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	pass


# Generated at 2022-06-23 13:10:54.917528
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:10:57.251082
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert(s._host_pinned)

# Generated at 2022-06-23 13:10:59.645108
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule()
    assert x
    x = StrategyModule(tqm=None)
    assert x

# Generated at 2022-06-23 13:11:01.969191
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Tqm:
        pass
    tqm = Tqm()
    s = StrategyModule(tqm)
    assert s._host_pinned # This is the only consequence of the StrategyModule constructor

# Generated at 2022-06-23 13:11:02.734702
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Intentionally pass
    assert True

# Generated at 2022-06-23 13:11:09.794855
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module_obj = StrategyModule(tqm)
    assert (strategy_module_obj.__class__.__name__ == 
            "StrategyModule")
    assert (strategy_module_obj.__doc__ == 
            "Host Pinned module. Executes tasks on each host without interruption")

# Create instance of class StrategyModule for unit testing
strategy_module_obj = StrategyModule(None)


# Generated at 2022-06-23 13:11:11.146319
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #assert_true(False, msg='Test not implemented')
    pass

# Generated at 2022-06-23 13:11:12.036684
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 'StrategyModule' in globals()



# Generated at 2022-06-23 13:11:12.602960
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:11:14.368956
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned

# Generated at 2022-06-23 13:11:16.773373
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"
    assert StrategyModule.__doc__ == "Executes tasks on each host without interruption"



# Generated at 2022-06-23 13:11:23.483757
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.connection.local import Connection
    from ansible.playbook.play_context import PlayContext

    myTqm=object()
    strategyModule = StrategyModule(myTqm)

    assert(strategyModule._host_pinned)
    assert(strategyModule._tqm == myTqm)

# Generated at 2022-06-23 13:11:25.275993
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TQM
    StrategyModule(tqm)


# Generated at 2022-06-23 13:11:26.612149
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from mock import Mock
    StrategyModule(Mock())

# Generated at 2022-06-23 13:11:29.562659
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    class_strategyModule = StrategyModule(tqm)
    assert class_strategyModule._host_pinned

# Generated at 2022-06-23 13:11:31.851285
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule
    assert sm
    assert sm._host_pinned == True, "Host_pinned is not set to True"

# Generated at 2022-06-23 13:11:33.453062
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(tqm)
    assert isinstance(a._host_pinned, bool)
    assert a._host_pinned == True



# Generated at 2022-06-23 13:11:34.144008
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:11:34.826461
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == True

# Generated at 2022-06-23 13:11:37.018589
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    tqm = None

    sm = StrategyModule(tqm)
    print(sm)

test_StrategyModule()

# Generated at 2022-06-23 13:11:46.842239
# Unit test for constructor of class StrategyModule
def test_StrategyModule(): # pylint: disable=invalid-name
    '''
    strategy_host_pinned _init_ test method
    :return: None
    '''
    from ansible.utils.display import Display
    from ansible.plugins.strategy import StrategyModule
    display = Display()
    tqm = {}
    strategy_module = StrategyModule(tqm)
    assert isinstance(strategy_module, StrategyModule)
    assert isinstance(strategy_module._tqm, dict)
    assert isinstance(strategy_module._display, Display)

# Generated at 2022-06-23 13:11:49.327346
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    assert StrategyModule(tqm)


# Generated at 2022-06-23 13:11:50.523880
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule.__init__

# Generated at 2022-06-23 13:11:51.405122
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:11:53.783625
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule(2)
    assert tqm._host_pinned == True

# Generated at 2022-06-23 13:11:58.018561
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class tqm():
        pass
    tqm1 = tqm()
    tqm1._initial_passwords = {}
    strategy_module = StrategyModule(tqm1)

# Generated at 2022-06-23 13:11:59.293879
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None

# Generated at 2022-06-23 13:12:00.812862
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm='tqm')


# Generated at 2022-06-23 13:12:02.031147
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()