

# Generated at 2022-06-23 13:02:01.688972
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned = StrategyModule(tqm='tqm')
    assert host_pinned._host_pinned is True

# Generated at 2022-06-23 13:02:05.684759
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned is True

# vim: set filetype=python:

# Generated at 2022-06-23 13:02:06.195320
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:02:06.942087
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 13:02:14.805466
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import mock

    class fake_class:
        pass

    mock_task = fake_class()
    mock_task.register = mock.MagicMock()
    mock_task.notify = mock.MagicMock()

    class test_StrategyModule(unittest.TestCase):
        def test_init(self):
            mock_tqm = fake_class()
            mock_tqm.RUN_OK = fake_class()
            mock_tqm.RUN_OK = 0
            mock_tqm.RUN_ERROR = fake_class()
            mock_tqm.RUN_ERROR = 1
            mock_tqm.RUN_FAILED_HOSTS = fake_class()

# Generated at 2022-06-23 13:02:15.420523
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:02:18.343200
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm=None)
    assert module._host_pinned



# Generated at 2022-06-23 13:02:25.971357
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy import show_pinned_hosts, strategy_loader
    tqm = strategy_loader.get('show_pinned_hosts', tqm)
    strategymodule = StrategyModule(tqm)
    print(strategymodule)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:02:27.345710
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule('test')
    assert mod._host_pinned

# Generated at 2022-06-23 13:02:29.420419
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {"_final_q": None}
    strategyModule = StrategyModule(tqm)
    assert strategyModule._host_pinned == True


# Generated at 2022-06-23 13:02:31.139538
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Generated at 2022-06-23 13:02:34.168637
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__.__doc__ == '\n    '

# Generated at 2022-06-23 13:02:35.710104
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_object = StrategyModule(tqm={})
    assert strategy_object._host_pinned == True

# Generated at 2022-06-23 13:02:36.504996
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-23 13:02:37.166983
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule

# Generated at 2022-06-23 13:02:38.410762
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strat = StrategyModule(None)
    assert strat._host_pinned == True

# Generated at 2022-06-23 13:02:39.864608
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert (StrategyModule.__doc__ is not None)

# Generated at 2022-06-23 13:02:42.446453
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # a = StrategyModule() # will throw exception as no tqm arg
    tqm = None
    a = StrategyModule(tqm)

# Generated at 2022-06-23 13:02:46.218921
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    tqm = FreeStrategyModule('tqm')
    strategy_module = StrategyModule(tqm)
    assert (strategy_module._host_pinned == True)

# Generated at 2022-06-23 13:02:50.447108
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule(tqm)
    test_strategy = StrategyModule(tqm)
    #assert test_strategy.tqm == tqm
    assert test_strategy._host_pinned == True

# Generated at 2022-06-23 13:02:52.143943
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Set up an object StrategyModule class 
    assert StrategyModule


# Generated at 2022-06-23 13:02:54.910877
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestStrategyModule(StrategyModule):
        pass
    tsm = TestStrategyModule(None)
    assert tsm.get_host_pinned() == True

# Generated at 2022-06-23 13:02:55.435051
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:02:57.014545
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_object = StrategyModule(tqm = None)
    assert strategy_object._host_pinned is True

# Generated at 2022-06-23 13:03:02.670439
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    # Create an instance of class StrategyModule, and test if the value of attribute _host_pinned is True
    obj = StrategyModule(tqm = None)
    assert obj._host_pinned == True, "The object's _host_pinned attribute should be True after calling the constructor"
    print("Class StrategyModule is initialized correctly")

test_StrategyModule()

# Generated at 2022-06-23 13:03:03.457772
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:03:04.757499
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm)
    assert sm._host_pinned

# Generated at 2022-06-23 13:03:10.174885
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("******************* test_StrategyModule *******************")
    # Create a FakeTqm object
    fake_tqm = FakeTqm()
    # Instantiate StrategyModule
    sm = StrategyModule(fake_tqm)
    # Check if attribute _host_pinned is set to True
    assert sm._host_pinned


# Mock class for _TQM

# Generated at 2022-06-23 13:03:13.480650
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True
    assert isinstance(strategy, FreeStrategyModule) == True


# Generated at 2022-06-23 13:03:14.075414
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:03:15.485598
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = test_tqm
    StrategyModule(tqm)

# Generated at 2022-06-23 13:03:16.459389
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule("tqm") is not None

# Generated at 2022-06-23 13:03:18.099401
# Unit test for constructor of class StrategyModule
def test_StrategyModule():  
    from ansible.plugins.strategy.host_pinned import StrategyModule
    tm = StrategyModule(None)
    assert tm._host_pinned

# Generated at 2022-06-23 13:03:25.348951
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    Playbook = type('Playbook', (object,), {})

    Play = type('Play', (object,), {})

    Options = type('Options', (object,), {})

    module_loader = type('module_loader', (object,), {})

    # create fake tqm
    tqm = type('tqm', (object,), {'__init__': lambda self: setattr(self, '_tqm', self)})()

    StrategyModule.__init__(tqm)

# Generated at 2022-06-23 13:03:28.047027
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned == True
    assert strategy.tqm == None

# Generated at 2022-06-23 13:03:31.135059
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_instance = StrategyModule(tqm)
    assert strategy_instance._host_pinned == True

# Generated at 2022-06-23 13:03:36.437793
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_object = StrategyModule("Test Object")
    # Check if input is of type object
    assert isinstance(test_object, object)

    # Check if input is a instance of given class type
    assert isinstance(test_object, StrategyModule)

    # Check if input is a instance of given parent class type
    assert isinstance(test_object, FreeStrategyModule)

# Generated at 2022-06-23 13:03:38.178505
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm)
    assert obj._host_pinned == True
    assert obj._host_pinned == True
    assert obj._host_pinned == True

# Generated at 2022-06-23 13:03:39.049778
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-23 13:03:40.624529
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        assert True
    except AssertionError:
        raise AssertionError()

# Generated at 2022-06-23 13:03:42.421325
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm=None)
    assert hasattr(sm,'_host_pinned') and sm._host_pinned == True

# Generated at 2022-06-23 13:03:46.815002
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    test_tqm = None
    strategy_obj = StrategyModule(test_tqm)
    assert strategy_obj._host_pinned == True

# Generated at 2022-06-23 13:03:47.832953
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-23 13:03:53.379418
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    TASK_QUEUE_MANAGER = 'task_queue_manager'
    STRATEGY_MODULE = 'strategy_module'
    strategy_module = StrategyModule(TASK_QUEUE_MANAGER)
    assert strategy_module._tqm == TASK_QUEUE_MANAGER
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:03:55.810562
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert (StrategyModule.__doc__ != None)
    assert (StrategyModule.__init__.__doc__ != None)

# Generated at 2022-06-23 13:03:57.912401
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("tqm")
    assert strategy_module._host_pinned == True


# Generated at 2022-06-23 13:03:59.809950
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule(tqm=None)
    assert tqm._host_pinned == True

# Generated at 2022-06-23 13:04:00.203257
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    asser

# Generated at 2022-06-23 13:04:01.246842
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"

# Generated at 2022-06-23 13:04:02.320733
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-23 13:04:03.002635
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:04:04.724721
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule()
    assert a._host_pinned == True

# Generated at 2022-06-23 13:04:14.183610
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''Unit test for constructor StrategyModule.
    '''
    import ansible.utils.display

    class TestDisplay(ansible.utils.display.Display):
        def __init__(self):
            self.verbosity = 4

    class TestTaskQueueManager:
        '''Create fake TaskQueueManager to use as input to StrategyModule.
        '''
        def __init__(self):
            self.display = TestDisplay()
            self.stats = {}

    test_tqm = TestTaskQueueManager()
    test_strategy_module = StrategyModule(test_tqm)
    assert not test_strategy_module.run_handlers is None
    #assert test_strategy_module.get_changed_hosts is None
    assert test_strategy_module.display is not None
    assert test_strategy_module

# Generated at 2022-06-23 13:04:16.850451
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule('tqm')
    assert sm.get_host_pinned() == True, "Host pinned is not True"

# Generated at 2022-06-23 13:04:18.688941
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module._host_pinned

# Generated at 2022-06-23 13:04:24.172374
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "dummy_tqm"
    strategy_obj = StrategyModule(tqm)
    assert strategy_obj._host_pinned == True
    assert strategy_obj._batch_size == 1
    assert strategy_obj._inventory is None
    assert strategy_obj._failed_hosts == {}
    assert strategy_obj._unreachable_hosts == {}
    assert strategy_obj._tqm is "dummy_tqm"

# Generated at 2022-06-23 13:04:30.151704
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager()
    strategy_module = StrategyModule(tqm)

    assert (strategy_module is not None)
    assert (isinstance(strategy_module, StrategyModule))

# Generated at 2022-06-23 13:04:31.717542
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    g = StrategyModule()
    assert g._host_pinned == True

# Generated at 2022-06-23 13:04:34.250451
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm='this is a test')
    assert obj._host_pinned == True


# Generated at 2022-06-23 13:04:35.769869
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:04:40.017099
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)
    assert StrategyModule.__init__.__doc__ is None
    strategy_module = StrategyModule('tqm')
    assert isinstance(strategy_module, StrategyModule)

# Generated at 2022-06-23 13:04:40.475363
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule()

# Generated at 2022-06-23 13:04:40.934001
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:04:43.395828
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:04:52.306375
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global __file__
    import os
    import ansible.plugins.loader as plug_loader
    filename = os.path.basename(__file__)
    filename = os.path.splitext(filename)[0]
    plug_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../../plugins/strategy'))
    print('--- Testing %s ---' % filename)
    strategy_plugins = plug_loader.all('strategy')
    strategy = strategy_plugins.get(filename)
    strategy.__init__(tqm=None)

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-23 13:04:53.799926
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm._host_pinned

# Generated at 2022-06-23 13:04:56.599076
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule.__new__(StrategyModule)
    a.__init__('tqm')

    assert(a._host_pinned == True)

# Generated at 2022-06-23 13:04:59.318512
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_module = StrategyModule("tqm")
    print("%s" % test_module)
    assert test_module._host_pinned

# Generated at 2022-06-23 13:05:00.538729
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned

# Generated at 2022-06-23 13:05:02.798773
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_strategymodule = StrategyModule("tqm");
    assert test_strategymodule._host_pinned == True


# Generated at 2022-06-23 13:05:03.381217
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:05:04.579183
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 13:05:05.721060
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule(tqm)

# Generated at 2022-06-23 13:05:08.114539
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result = StrategyModule(tqm=None)
    assert result._host_pinned == True

# Generated at 2022-06-23 13:05:12.392729
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    desc = "Executes tasks on each host without interruption"
    desired_object = StrategyModule()
    assert_equal(type(desired_object.__init__()), type(None),"Executes tasks on each host without interruption")
    return desired_object


# Generated at 2022-06-23 13:05:14.626962
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_instance = StrategyModule(None)
    assert isinstance(strategy_instance, StrategyModule)

# Generated at 2022-06-23 13:05:22.691429
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult

    play = Play().load({
        'name': 'test play',
        'hosts': 'all',
        'gather_facts': 'no',
        'tasks': [
            {'action': {'module': 'debug', 'args': {'msg': '{{ hostvars[inventory_hostname]["test_var"]}}'}}},
        ]
    }, variable_manager={'hostvars': {'example.org': {'test_var': 'success'}}}, loader=None)

# Generated at 2022-06-23 13:05:24.675297
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    instance = StrategyModule(tqm)
    assert instance._host_pinned == True


# Generated at 2022-06-23 13:05:31.136607
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Values to feed into StrategyModule
    task_queue_manager = "sampleTaskQueueManager"

    # Call constructor of class StrategyModule
    # Normally, task_queue_manager will be set to "sampleTaskQueueManager"
    # However, this test uses a mock of task_queue_manager
    strategyModule = StrategyModule(task_queue_manager)
    print(str(strategyModule))
    print(str(type(strategyModule)))

    # Set the value of task_queue_manager to the constructor of class StrategyModule
    task_queue_manager = strategyModule
    print(str(task_queue_manager))
    print(str(type(task_queue_manager)))

# Generated at 2022-06-23 13:05:31.678707
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:05:35.375404
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test start")
    obj = StrategyModule(True)
    if not isinstance(obj, StrategyModule):
        raise AssertionError("Expected type StrategyModule, but got type %s" % type(obj))
    if obj._host_pinned != True:
        raise AssertionError("Expected _host_pinned = True, but got %s" % str(obj._host_pinned))

# Generated at 2022-06-23 13:05:38.632213
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import plugins
    strategy = plugins.strategy.host_pinned.StrategyModule(tqm=None)
    assert strategy._host_pinned is True

# Generated at 2022-06-23 13:05:39.927342
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:05:42.667127
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)

    assert(isinstance(strategy, FreeStrategyModule))

# Generated at 2022-06-23 13:05:44.822177
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule('tqm')
    assert s._host_pinned == True
    assert s._play_context is None

# Generated at 2022-06-23 13:05:45.728861
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("In StrategyModule")

# Generated at 2022-06-23 13:05:46.573246
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(True)

# Generated at 2022-06-23 13:05:48.928271
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy is not None
    assert strategy._host_pinned is True

# Generated at 2022-06-23 13:05:50.258235
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__



# Generated at 2022-06-23 13:06:00.756827
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.executor.stats import AggregateStats
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    context = PlayContext()
    context._host_pinned = True
    stats = AggregateStats()
    host = Host(name="localhost")
    group = Group(name="group")
    group.add_host(host)

# Generated at 2022-06-23 13:06:12.924000
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import constants as C
    from ansible.context import AnsibleContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    context = AnsibleContext(loader=loader)
    variable_manager = VariableManager(context)
    inventory = InventoryManager(
        loader=loader,
        variable_manager=variable_manager,
        host_list=C.DEFAULT_HOST_LIST)
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-23 13:06:14.852411
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Testing for class StrategyModule

# Generated at 2022-06-23 13:06:17.691247
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('') == StrategyModule(''), "StrategyModule('') should return StrategyModule('')"
    assert StrategyModule('') == '', "StrategyModule('') should return ''"



# Generated at 2022-06-23 13:06:24.681459
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    tqm = TaskQueueManager(
        inventory=PlaybookExecutor([Play()]).inventory,
        variable_manager=PlaybookExecutor([Play()]).variable_manager,
        loader=PlaybookExecutor([Play()]).loader,
        passwords=PlaybookExecutor([Play()]).passwords,
        stdout_callback='default',
    )
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:06:36.293622
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from collections import namedtuple
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_queue_manager import TaskQueueManagerFactory
    from ansible.executor.process.worker import WorkerProcess
    from ansible.executor.stats import AggregateStats
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.shlex import shlex_split
    from ansible.vars.manager import VariableManager
    import logging
    import os
    import shutil
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    
    # Create a dummy inventory

# Generated at 2022-06-23 13:06:37.796646
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    s = StrategyModule(tqm)
    assert isinstance(s, StrategyModule)

# Generated at 2022-06-23 13:06:38.672313
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:06:39.784695
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__

# Generated at 2022-06-23 13:06:41.378052
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(None)
    assert module._host_pinned == True


# Generated at 2022-06-23 13:06:42.831386
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm='tqm')

# Generated at 2022-06-23 13:06:46.267830
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule(tqm=None)
    except Exception:
        assert False, "Failed to create instance of StrategyModule class"


# Generated at 2022-06-23 13:06:47.477536
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    tqm = ""
    StrategyModule(tqm)


# Generated at 2022-06-23 13:06:49.568019
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  #Constructor should not take more then one argument
  assert StrategyModule.__init__.__code__.co_argcount == 2

# Generated at 2022-06-23 13:06:55.721283
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule(None)
    assert mod._host_pinned == True
    assert mod._inventory is None
    assert mod._tqm is None
    assert mod._workers is None
    assert mod._result_queue is None
    assert mod._progress_queue is None
    assert mod._loader is None
    assert mod._variable_manager is None
    assert mod._strategy is None
    assert mod._options is None

# Generated at 2022-06-23 13:06:59.827745
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class AnsibleTaskQueueManager:
        def __init__(self):
            self.options = None
    strategy_module = StrategyModule(AnsibleTaskQueueManager())
    assert strategy_module

# Generated at 2022-06-23 13:07:00.575515
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-23 13:07:01.840580
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned = StrategyModule(tqm)
    assert host_pinned._host_pinned == True

# Generated at 2022-06-23 13:07:02.361811
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:07:06.670640
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned as host_pinned
    host_pinned = host_pinned.StrategyModule()



# Generated at 2022-06-23 13:07:08.508534
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule(None)
    assert x._host_pinned == True

# Generated at 2022-06-23 13:07:09.764596
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule('tqm')
    assert module._host_pinned



# Generated at 2022-06-23 13:07:12.917257
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert hasattr(strategy_module, '_host_pinned')
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:07:14.744001
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	tqm = StrategyModule(None)
	assert tqm.__class__.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:07:18.439862
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test object without parameters
    set_module = StrategyModule()
    assert set_module != None

    # Test object with parameters
    set_module = StrategyModule(tqm)
    assert set_module != None

# Generated at 2022-06-23 13:07:21.501129
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = True
        StrategyModule(tqm)
    except UnboundLocalError:
        pass
    except Exception as e:
        assert False, 'StrategyModule::__init__: Exception: %s' % e

# Generated at 2022-06-23 13:07:22.299568
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    st = StrategyModule(tqm)

# Generated at 2022-06-23 13:07:23.479583
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule('tqm')
    assert x._host_pinned



# Generated at 2022-06-23 13:07:27.576285
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True
    assert sm._tqm == None
    assert sm._display == Display()

# Generated at 2022-06-23 13:07:29.869733
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy is not None
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:07:30.614880
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    assert StrategyModule.__init__ is not None

# Generated at 2022-06-23 13:07:32.572098
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    obj = StrategyModule(tqm)
    assert obj._host_pinned is True

# Generated at 2022-06-23 13:07:34.439811
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """This is a constructor test case"""
    strategy = StrategyModule(tqm=str)
    assert strategy is not None

# Generated at 2022-06-23 13:07:35.654001
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:07:36.685525
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   assert StrategyModule(tqm) == None

# Generated at 2022-06-23 13:07:38.842062
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert hasattr(strategy, '_host_pinned')
    assert strategy._host_pinned == True


# Generated at 2022-06-23 13:07:39.319403
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:07:48.745134
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory import Inventory

    class Options():
        module_path = 'path'
        connection = 'connection'
        remote_user = 'remote_user'
        private_key_file = 'key'
        ssh_common_args = 'args'
        ssh_extra_args = 'extra args'
        sftp_extra_args = 'sftp extra args'
        scp_extra_args = 'scp extra args'
        become = False
        become_method = 'become_method'
        become_user = 'become_user'
        verb

# Generated at 2022-06-23 13:07:50.021757
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-23 13:07:50.978089
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule(1)
    assert mod

# Generated at 2022-06-23 13:07:53.490725
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    t1 = StrategyModule(None)
    assert t1 is not None
    assert t1._host_pinned == True

# End of unit test

# Generated at 2022-06-23 13:07:54.191775
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1==1

# Generated at 2022-06-23 13:08:04.656827
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    test_loader = DataLoader()
    test_inventory = InventoryManager(loader=test_loader, sources=['localhost,'])
    test_variable_manager = VariableManager(loader=test_loader, inventory=test_inventory)
    play_context = PlayContext()

# Generated at 2022-06-23 13:08:05.125650
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:08:07.062208
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"
    assert FreeStrategyModule.__name__ == "FreeStrategyModule"

# Generated at 2022-06-23 13:08:09.508601
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    
    obj = StrategyModule(1)
    assert obj, "Insufficient data to instantiate StrategyModule"

# Generated at 2022-06-23 13:08:10.863692
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True
    return True

# Generated at 2022-06-23 13:08:12.842207
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 0
    obj = StrategyModule(tqm)
    assert(isinstance(obj, StrategyModule))

# Generated at 2022-06-23 13:08:16.990675
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    import sys

    # A hack to load a testable name space
    sys.modules['__main__'].__file__ = 'ansible'

    from ansible.plugins.strategy.host_pinned import StrategyModule

    testable_class = StrategyModule(None)
    assert testable_class._host_pinned

# Generated at 2022-06-23 13:08:19.368970
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = unittest.mock.Mock()
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:08:20.909582
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm= 'Test') is not None

# Generated at 2022-06-23 13:08:24.857914
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"
    from ansible.plugins.strategy.free import StrategyModule
    assert StrategyModule.__name__ == "StrategyModule"
    obj = StrategyModule()
    assert obj.__class__.__name__ == "StrategyModule"

# Generated at 2022-06-23 13:08:34.651281
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule as StrategyModuleImpl
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    options = {'verbosity': 3}
    inventory = InventoryManager(loader=DataLoader(), sources=['localhost, '])
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)

# Generated at 2022-06-23 13:08:35.431366
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:08:36.239430
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:08:39.389280
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module_obj = StrategyModule(tqm)
    assert strategy_module_obj._host_pinned == True

# Generated at 2022-06-23 13:08:41.055418
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:08:46.325778
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == FreeStrategyModule.__doc__
    assert StrategyModule.__init__.__doc__ == FreeStrategyModule.__init__.__doc__
    assert hasattr(StrategyModule, 'display')
    assert hasattr(StrategyModule, '_host_pinned')

# Generated at 2022-06-23 13:08:47.450796
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   strategyObj = StrategyModule(None)

# Generated at 2022-06-23 13:08:50.061367
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    from ansible.plugins.strategy.host_pinned import StrategyModule as HPStrategyModule
    module = HPStrategyModule(None)
    assert module._host_pinned is True


# Generated at 2022-06-23 13:08:51.411224
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:08:53.381882
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = StrategyModule.__init__(StrategyModule)
    assert tqm is not None

# Generated at 2022-06-23 13:08:55.413844
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Create a simple test of StrategyModule"""
    display.display("Test StrategyModule constructor")

    assert True

# Generated at 2022-06-23 13:08:56.906508
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()


# Generated at 2022-06-23 13:08:57.355180
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:08:58.439094
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyHostPinned= StrategyModule()
    assert strategyHostPinned._host_pinned

# Generated at 2022-06-23 13:09:01.051229
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTqm(object):
        def get_hosts(self, pattern=None):
            return ['host1']
    obj = StrategyModule(TestTqm())
    assert obj._host_pinned

# Generated at 2022-06-23 13:09:02.080419
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    newStrategyModule = StrategyModule("tqm")
    assert newStrategyModule._host_pinned == True

# Generated at 2022-06-23 13:09:06.279753
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    #Create a test_tqm.
    test_tqm = FreeStrategyModule([])
    #Create instance of class StrategyModule.
    test_strategy = StrategyModule(test_tqm)
    #Check if we get the right display
    assert test_strategy.display.display == 'test'

# Generated at 2022-06-23 13:09:07.425890
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-23 13:09:10.027833
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(None)
    assert module._host_pinned
    assert hasattr(module, 'run')

# Generated at 2022-06-23 13:09:11.451552
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_obj = StrategyModule(tqm="test")
    assert test_obj._host_pinned == True

# Generated at 2022-06-23 13:09:12.138756
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:09:13.571727
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule()
    assert module._host_pinned == True

# Generated at 2022-06-23 13:09:15.861662
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()
    assert obj._host_pinned == True

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-23 13:09:17.392667
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:09:19.133018
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    assert StrategyModule(tqm) is not None

# Generated at 2022-06-23 13:09:21.644425
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm._host_pinned == True
    assert sm._batch_size == 1

# Generated at 2022-06-23 13:09:23.707653
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm=None
    obj=StrategyModule(tqm)
    assert not obj.get_host_list()

# Generated at 2022-06-23 13:09:24.298609
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:09:26.233022
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:09:29.744133
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    hosts = ['host1', 'host2']
    t = FreeStrategyModule(hosts)
    assert t._host_pinned == True

# Generated at 2022-06-23 13:09:32.659176
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Constructor of StrategyModule class
    """
    obj = StrategyModule(tqm=None)
    assert obj._host_pinned == True, '_host_pinned should be set to True by default'

# Generated at 2022-06-23 13:09:34.885059
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test with default args
    c1 = StrategyModule(None)
    assert c1._host_pinned == True



# Generated at 2022-06-23 13:09:39.835143
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # StrategyModule works only if QueueManager exists
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(None, None, None, None, None, None)
    StrategyModule(tqm)

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-23 13:09:41.257890
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:09:50.512247
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible import context
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C


    # create a dummy task

# Generated at 2022-06-23 13:09:51.635528
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    TASK_QUEUE_MANAGER = 1
    StrategyModule(TASK_QUEUE_MANAGER)

# Generated at 2022-06-23 13:10:00.041840
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"

# Generated at 2022-06-23 13:10:02.340221
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('test')
    assert strategy_module._host_pinned == True


# Generated at 2022-06-23 13:10:03.436370
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:10:05.298091
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    strategy = StrategyModule({'host_pinned': True})
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:10:06.886979
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    FooStrategyModule = StrategyModule(None)
    assert FooStrategyModule._host_pinned

# Generated at 2022-06-23 13:10:09.430051
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    taskQueueManager = {1,2}
    strategyModule = StrategyModule(taskQueueManager)
    assert strategyModule._host_pinned is True

# Generated at 2022-06-23 13:10:10.389315
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(1)._host_pinned == True

# Generated at 2022-06-23 13:10:10.959771
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:10:12.356940
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == FreeStrategyModule.__doc__

# Generated at 2022-06-23 13:10:16.000104
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # instantiate class StrategyModule()
    tqm = "tqm"
    strategy_obj = StrategyModule(tqm)
    # check if the strategy_obj is instance of class StrategyModule
    assert isinstance(strategy_obj,StrategyModule)

# Generated at 2022-06-23 13:10:25.676915
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    class Host:
        def get_name(self):
            return 'localhost'

    class TaskExecutor:
        def __init__(self):
            self.host = Host()

    class TaskQueueManager:
        def __init__(self):
            self._inventory = InventoryManager(host_list=[])
            self._variable_manager = VariableManager()
            self._loader = None

        def add_task(self, task):
            pass

# Generated at 2022-06-23 13:10:27.302572
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Generated at 2022-06-23 13:10:29.026969
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()
    assert(obj._host_pinned == True)

# Generated at 2022-06-23 13:10:38.406891
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(1)
    assert a is not None
    assert a._display is not None
    assert a._tqm is not None
    assert a._result_q is not None
    assert a._workers is not None
    assert a._notified_handlers is not None
    assert a._final_q is not None
    assert a._inventory is not None
    assert a._loader is not None
    assert a._variable_manager is not None
    assert a._loader is not None
    assert a._results is not None
    assert a._callbacks is not None
    assert a._host_pinned is True

    assert a._task_q is None
    assert a._host_vars is None
    assert a._host_name_var is None
    assert a._host_pinned is True

# Generated at 2022-06-23 13:10:40.379700
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert (strategy_module is not None)


# Generated at 2022-06-23 13:10:42.322872
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    K = StrategyModule
    k = K(None)
    assert(isinstance(k, K))

# Generated at 2022-06-23 13:10:52.486860
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    # test for abstract class
    assert issubclass(StrategyModule, FreeStrategyModule)
    assert isinstance(StrategyModule, object)
    assert not issubclass(StrategyModule, object)
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '\n    Host Pinned Strategy Plugin\n    '
    assert hasattr(StrategyModule, '__init__')
    assert StrategyModule.__init__.__doc__ == ' '
    assert hasattr(StrategyModule, 'get_next_task_lock')
    assert StrategyModule.get_next_task_lock.__doc__ == ' '
    assert hasattr(StrategyModule, 'run')
    assert StrategyModule.run.__doc__ == ' '


# Generated at 2022-06-23 13:10:55.407785
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'a sample task queue manager'
    strategy = StrategyModule(tqm)
    assert tqm == strategy._tqm



# Generated at 2022-06-23 13:10:56.376303
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:10:57.748705
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:10:58.774566
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm='')

# Generated at 2022-06-23 13:11:03.087408
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import sys
    import imp
    import ansible
    plugin_utils_path = ansible.__path__[0] + '/plugins/strategy/host_pinned.py'
    m = imp.load_source('strategy_host_pinned', plugin_utils_path)

    assert m.StrategyModule

# Generated at 2022-06-23 13:11:05.126220
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:11:10.268781
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    try:
        strategy_module = StrategyModule()
        assert(False)
    except TypeError as e:
        assert(str(e) == "__init__() missing 1 required positional argument: 'tqm'")
    except:
        assert(False)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:11:11.950868
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    new_strategy = StrategyModule(None)
    assert new_strategy._host_pinned == True


# Generated at 2022-06-23 13:11:12.978565
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 13:11:21.475476
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # mock some objects
    from ansible.playbook.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.parsing.dataloader import DataLoader

    def get_variable_manager(self):
        return self.variable_manager

    setattr(TaskQueueManager, 'get_variable_manager', get_variable_manager)

    tqm._unreachable_hosts = dict()
    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    result = TaskResult(host=DummyHost(), task=dict())

    strategy = StrategyModule(tqm)
    assert strategy._tqm is tqm

# Generated at 2022-06-23 13:11:22.578456
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__  # use your library here

# Generated at 2022-06-23 13:11:24.291306
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm)
    assert module._host_pinned == True

# Generated at 2022-06-23 13:11:34.983973
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    import units.modules.utils as utils
    from ansible.plugins.strategy import StrategyModule

    host = Host(name="test1", port=22)
    host.set_variable("ansible_ssh_pass", "pass")
    host.set_variable("ansible_connection", "ssh")
    host.set_variable("ansible_ssh_user", "user")

# Generated at 2022-06-23 13:11:38.095777
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    test_strategy_module = StrategyModule(tqm)
    assert(test_strategy_module.tqm == tqm)
    assert(test_strategy_module._host_pinned == True)


# Generated at 2022-06-23 13:11:39.801607
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)

# Generated at 2022-06-23 13:11:43.448277
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  from ansible.plugins.strategy.host_pinned import StrategyModule
  tqm = 'tqm'
  StrategyModule(tqm)


# Generated at 2022-06-23 13:11:46.431633
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_strategy= StrategyModule(tqm=None)
    assert isinstance(test_strategy, StrategyModule)

# Generated at 2022-06-23 13:11:48.772476
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule(tqm=None)

# Generated at 2022-06-23 13:11:53.025044
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm1 = StrategyModule(tqm="tqm1")
    # Expected result: True
    assert sm1._host_pinned == True
    sm2 = StrategyModule(tqm="tqm2")
    # Expected result: True
    assert sm2._host_pinned == True

# Generated at 2022-06-23 13:12:01.735029
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import context
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.utils.queuemanager import QueueManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    queue_manager = QueueManager(tqm=TaskQueueManager(tqm_out_callback=None))
    context.CLIARGS = {'module_path': 'modules'}
    strategy = StrategyModule(tqm=queue_manager)

    assert strategy._host_pinned == True