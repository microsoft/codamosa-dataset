

# Generated at 2022-06-23 13:02:05.763714
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    from ansible.utils.display import Display
    display = Display()

    tqm = Display()
    result = StrategyModule(tqm)

    assert isinstance(result,FreeStrategyModule)
    assert hasattr(result, '_host_pinned')
    assert result._host_pinned == True

# Generated at 2022-06-23 13:02:07.620037
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('tqm')
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:02:09.157732
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result = StrategyModule(tqm)
    assert result is not None

# Generated at 2022-06-23 13:02:09.913714
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:02:18.272329
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule, type)
    assert issubclass(StrategyModule, FreeStrategyModule)
    strategy = StrategyModule()
    assert isinstance(strategy._host_pinned, bool)
    assert isinstance(strategy._hostname_to_hostqueue, dict)
    assert isinstance(strategy._name, str)
    assert isinstance(strategy._tqm, TaskQueueManager)
    assert isinstance(strategy._workers, list)
    assert isinstance(strategy._cur_worker, int)
    assert isinstance(strategy._num_workers, int)
    assert isinstance(strategy._max_workers, int)
    assert isinstance(strategy._cur_worker, int)
    assert isinstance(strategy._max_hosts, int)

# Generated at 2022-06-23 13:02:25.567326
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTQM:
      pass
    test_tqm = TestTQM()
    test_strategy_module = StrategyModule(test_tqm)
    assert(test_strategy_module.tqm == test_tqm)
    assert(test_strategy_module._host_pinned == True)
    assert(test_strategy_module._blocked_hosts == {})

# Generated at 2022-06-23 13:02:28.950119
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    assert StrategyModule.__bases__[0].__name__ == 'FreeStrategyModule'
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule._host_pinned is True

# Generated at 2022-06-23 13:02:29.851378
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)

# Generated at 2022-06-23 13:02:38.951859
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    from ansible.plugins.strategy.host_pinned import StrategyModule
    assert issubclass(StrategyModule, FreeStrategyModule)
    assert StrategyModule != FreeStrategyModule
    assert StrategyModule.__doc__ is not None
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.get_host_list() == StrategyModule.get_host_list()
    assert StrategyModule.should_pause_playbook() == StrategyModule.should_pause_playbook()
    assert StrategyModule._configure_play() == StrategyModule._configure_

# Generated at 2022-06-23 13:02:41.347948
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:02:47.598034
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.strategy.host_pinned import StrategyModule as host_pinned
    print("- host_pinned.py: Testing StrategyModule constructor")
    assert issubclass(host_pinned, StrategyModule)
    assert host_pinned.__init__ != StrategyModule.__init__
    print("- host_pinned.py: StrategyModule constructor test passed")

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:02:50.404688
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule.__name__ == "StrategyModule")
    assert(StrategyModule.__module__ == "strategy.host_pinned")

# Generated at 2022-06-23 13:02:54.765282
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Setup
    results = []
    task_queue_manager = StrategyModule(results)

    # Assertion
    assert task_queue_manager is not None
    assert task_queue_manager._host_pinned is True
    assert task_queue_manager._play is not None

# Generated at 2022-06-23 13:02:55.909437
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None

# Generated at 2022-06-23 13:02:56.581166
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:02:59.020064
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    m = StrategyModule("tqm")
    assert m._host_pinned is True

# Generated at 2022-06-23 13:02:59.912087
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:03:02.084059
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned


# Generated at 2022-06-23 13:03:04.010153
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-23 13:03:06.747238
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None 
    strategy = StrategyModule(tqm)
    assert isinstance(strategy, StrategyModule), \
        "StrategyModule constructor test failed."

# Generated at 2022-06-23 13:03:08.194225
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(1)
    assert strategy._host_pinned is True

# Generated at 2022-06-23 13:03:08.812326
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:03:13.429037
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strMod = StrategyModule(tqm=None)
    assert 'StrategyModule' in str(strMod)
    assert 'StrategyModule' in str(strMod.__dict__)
    assert '_host_pinned' in str(strMod.__dict__)
    assert strMod._host_pinned

# Generated at 2022-06-23 13:03:19.832796
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import context
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(
        inventory=context.CLIARGS['inventory'],
        variable_manager=context.CLIARGS['variable_manager'],
        loader=context.CLIARGS['loader'],
        options=context.CLIARGS['options'],
        passwords=context.CLIARGS['passwords'],
    )
    host_pinned = StrategyModule(tqm)
    assert host_pinned._host_pinned == True

# Generated at 2022-06-23 13:03:22.696576
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = StrategyModule(tqm)
    assert host._batch() == 1
    assert host._display.verbosity >= 0

# test_StrategyModule()

# Generated at 2022-06-23 13:03:26.295297
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule()
    assert a._host_pinned
    assert a._host_tasks_map
    assert a._host_check_interval
    assert a._host_checks
    assert a._host_notified

# Generated at 2022-06-23 13:03:27.400825
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1 == 1

# Generated at 2022-06-23 13:03:28.503468
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == FreeStrategyModule.__doc__

# Generated at 2022-06-23 13:03:37.778059
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.worker import WorkerProcess
    from ansible.utils.display import Display

    display = Display()
    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        passwords=None,
        stdout_callback=display.display,
        use_task_cache=False,
        task_executor='strategy',
        host_pinned=True
    )
    strategy = StrategyModule(tqm)

    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:03:39.273622
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'


# Generated at 2022-06-23 13:03:39.914041
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:03:41.190742
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module._host_pinned is True

# Generated at 2022-06-23 13:03:43.380984
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule()
    display = Display()
    StrategyModule(tqm)

# Generated at 2022-06-23 13:03:44.576775
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"

# Generated at 2022-06-23 13:03:46.329215
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTQM:
        pass
    ft = FakeTQM()
    sm = StrategyModule(ft)
    # assert that we can only use the class StrategyModule
    assert isinstance(sm, StrategyModule)

# Generated at 2022-06-23 13:03:49.537148
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(None, None, None, None, None)
    StrategyModule(tqm)

# Generated at 2022-06-23 13:03:51.292032
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned

# Generated at 2022-06-23 13:03:51.891907
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:03:53.023960
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    result = StrategyModule

# Generated at 2022-06-23 13:03:54.531033
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    StrategyModule(tqm)

# Generated at 2022-06-23 13:03:57.204744
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = dict()
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned

# Generated at 2022-06-23 13:03:59.508860
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   # Initialise host_pinned variable
   host_pinned = 'Yes'

   assert host_pinned == 'Yes'


# Generated at 2022-06-23 13:04:00.937338
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=[1])
    assert strategy._host_pinned

# Generated at 2022-06-23 13:04:09.176019
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy import StrategyBase
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    import pytest
    executor = TaskQueueManager(None, None, None, None)
    sm = StrategyModule(executor)
    assert isinstance(sm, StrategyBase), "StrategyModule is instance of StrategyBase"
    assert isinstance(sm, FreeStrategyModule), "StrategyModule is instance of FreeStrategyModule"

# Generated at 2022-06-23 13:04:14.503815
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTqm:
        def __init__(self):
            self.send_callback = None
            self.stats = None
            self.stdout_callback = None
            self.options = None
    tqm = TestTqm()
    try:
        strategy = StrategyModule(tqm)
        assert strategy.get_name() == "host_pinned"
        assert strategy._host_pinned is True
    except Exception as e:
        print("\nException when instantiating strategy_host_pinned.py: %s" % e)
        raise

# Generated at 2022-06-23 13:04:15.089770
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:04:16.431081
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)

# Generated at 2022-06-23 13:04:17.565595
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:04:19.402631
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    ansible_strategy = StrategyModule(tqm)
    assert ansible_strategy

# Generated at 2022-06-23 13:04:27.587007
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestAnsibleTQM(object):
        def __init__(self):
            self.stats = TestAnsibleStats()
            self.inventory = None
            self.stdout_callback = TestAnsibleCallback()
            self._notified_handlers = {}

        def add_notified_handler(self, handler):
            pass

    class TestAnsibleStats(object):
        def __init__(self):
            self.people = {}

    class TestAnsibleCallback(object):
        def __init__(self):
            self.disabled = True

        def v2_on_file_diff(self, result):
            pass

    class TestAnsibleOptions(object):
        def __init__(self):
            self.listtags = False
            self.listtasks = False
            self.listhost

# Generated at 2022-06-23 13:04:29.749481
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """StrategyModule - constructor"""
    strategy = StrategyModule(None)
    assert strategy._host_pinned is True

# Generated at 2022-06-23 13:04:31.297880
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=tqm1)



# Generated at 2022-06-23 13:04:33.385337
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(1)
    assert strategy_module.get_host_pinned()

# Generated at 2022-06-23 13:04:34.404341
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-23 13:04:35.920296
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test = StrategyModule({})
    assert test._host_pinned == True

# Generated at 2022-06-23 13:04:37.879739
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test_tqm'
    StrategyModule(tqm)

# Generated at 2022-06-23 13:04:39.240036
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:04:40.306263
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    q = StrategyModule()
    assert q is not None

# Generated at 2022-06-23 13:04:40.792576
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:04:41.497071
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:04:42.731489
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-23 13:04:44.570233
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # no exception is a good sign
    test_StrategyModule()

# Generated at 2022-06-23 13:04:46.395824
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:04:48.217424
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.display("%s" % StrategyModule.process_count)


# Generated at 2022-06-23 13:04:50.468452
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Instantiate a StrategyModule to test
    test_StrategyModule = StrategyModule(None)
    assert test_StrategyModule._host_pinned == True

# Generated at 2022-06-23 13:04:52.624391
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    fake_tqm = [1,2,3]
    sm = StrategyModule(fake_tqm)
    assert sm._host_pinned is True

# Generated at 2022-06-23 13:04:53.595045
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 13:04:54.639833
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)


# Generated at 2022-06-23 13:04:59.874324
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  # Test constructor without tqm
  strategy_module = StrategyModule()
  # Test constructor with tqm
  tqm = ''
  strategy_module = StrategyModule(tqm)
  # Test constructor with tqm
  tqm = 'test'
  strategy_module = StrategyModule(tqm)


# Generated at 2022-06-23 13:05:02.278764
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    for s in ['free', 'linear', 'debug', 'meta', 'default']:
        assert s in StrategyModule.__bases__[0]._strategies
# test ends

# Generated at 2022-06-23 13:05:05.908052
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("-------- Testcase for StrategyModule --------")
    name = 'host_pinned'
    strategy_module = StrategyModule()
    assert strategy_module._host_pinned == True

# Test for _make_batches_parallel

# Generated at 2022-06-23 13:05:07.485833
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 13:05:09.766834
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    fake_tqm = [None]
    sm = StrategyModule(fake_tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:05:10.904533
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:05:11.756893
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	pass

# Generated at 2022-06-23 13:05:17.484725
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    TASK = {'name': 'TESTTASK'}
    TASKQUEUE_MANAGER = {'var': 'FOOVAR'}
    strategy_module = StrategyModule(TASKQUEUE_MANAGER)
    assert strategy_module._tqm['var'] == TASKQUEUE_MANAGER['var']
    assert strategy_module._host_pinned is True

# Generated at 2022-06-23 13:05:18.941644
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule
    # Test class instantiation
    assert isinstance(module, StrategyModule)

# Generated at 2022-06-23 13:05:20.121710
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('tqm')

# Generated at 2022-06-23 13:05:21.349139
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert(s._host_pinned == True)

# Generated at 2022-06-23 13:05:22.411298
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: implement unit test for constructor of class StrategyModule
    pass

# Generated at 2022-06-23 13:05:23.292923
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:05:24.201298
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-23 13:05:27.779398
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test with tqm = None
    result = StrategyModule(tqm = None)
    assert result._host_pinned
    # Test with tqm = not None
    result = StrategyModule(tqm = 2)
    assert result._host_pinned

# Test of class FreeStrategyModule

# Generated at 2022-06-23 13:05:28.278532
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-23 13:05:30.043750
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule), "Is a subclass of FreeStrategyModule"

# Generated at 2022-06-23 13:05:31.589486
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:05:32.738913
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-23 13:05:38.096341
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager('/path/to/inventory', '/usr/bin/ansible-playbook', '/usr/bin/ansible', '/usr/bin/ansible-config')
    StrategyModule(tqm)

# Generated at 2022-06-23 13:05:42.719349
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM():
        pass
    s = StrategyModule(TQM())
    if not isinstance(s, StrategyModule):
        raise AssertionError("s is not instance of StrategyModule")
    assert s._host_pinned == True
    assert s._display == display

# Generated at 2022-06-23 13:05:47.723478
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Negative test case: Constructor throws exception for strategy module
    display.display("Verify if StrategyModule constructor throws exception for strategy module")
    try:
        obj = StrategyModule(tqm)
    except:
        print("StrategyModule constructor throws exception for strategy module")
        assert(True)
        return
    print("Negative Test case failed: StrategyModule constructor does not throws exception for strategy module")
    assert(False)

# Generated at 2022-06-23 13:05:49.853044
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ Create an instance of StrategyModule """
    strategy = StrategyModule(None)
    assert strategy._host_pinned

# Generated at 2022-06-23 13:05:51.647928
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-23 13:05:54.583090
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.loader import action_loader
    from ansible.plugins.strategy.host_pinned import StrategyModule

    stategy_obj = StrategyModule(tqm)

# Generated at 2022-06-23 13:05:56.570138
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=strategy_module_test_tqm) is not None



# Generated at 2022-06-23 13:05:57.969010
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mystrat = StrategyModule()
    assert mystrat is not None

# Generated at 2022-06-23 13:06:02.075081
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(None,None,None, None, None)
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:06:04.561996
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    stm = StrategyModule.__new__(StrategyModule)
    stm.__init__(None)
    assert stm is not None

# Generated at 2022-06-23 13:06:07.309529
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:06:12.877333
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    free_strategy = FreeStrategyModule(tqm)
    assert free_strategy is not None
    assert free_strategy._host_pinned is False
    host_pinned_strategy = StrategyModule(tqm)
    assert host_pinned_strategy is not None
    assert host_pinned_strategy._host_pinned is True

# Generated at 2022-06-23 13:06:14.039416
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None


# Generated at 2022-06-23 13:06:15.756325
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test test_StrategyModule in class StrategyModule")
    print("\n")


# Generated at 2022-06-23 13:06:18.342097
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Unit test for constructor will be done when StrategyModule is used in the execution
    # Please refer to test/integration/targets/host_pinned.yml for the testing
    pass



# Generated at 2022-06-23 13:06:19.165835
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Generated at 2022-06-23 13:06:20.993979
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"
    assert StrategyModule.__doc__ == 'This is a base ansible strategy module for other modules to inherit from'

# Generated at 2022-06-23 13:06:21.749902
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)

# Generated at 2022-06-23 13:06:22.577719
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:06:24.764390
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule()


if __name__ == '__main__':
	test_StrategyModule()

# Generated at 2022-06-23 13:06:25.380471
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:06:27.296770
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule('dummy')
    assert a._host_pinned == True

# Generated at 2022-06-23 13:06:28.119354
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:06:30.561814
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule('test')
    assert isinstance(s, StrategyModule)



# Generated at 2022-06-23 13:06:32.643804
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule(tqm)
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:06:35.937758
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        ans_instance = StrategyModule('Ansible')
    except NameError:
        raise Exception("Failed to instantiate StrategyModule")
# Instantiate the class to use it's methods
ans_instance = StrategyModule('Ansible')


# Generated at 2022-06-23 13:06:37.493469
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned is True
    assert strategy.name == 'host_pinned'

# Generated at 2022-06-23 13:06:39.017053
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__ is not FreeStrategyModule.__init__

# Generated at 2022-06-23 13:06:41.156000
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned is True

# Generated at 2022-06-23 13:06:46.267840
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm = DummyTQM())
    assert isinstance(strategy, StrategyModule)
    assert strategy._host_pinned == True
    assert strategy.name == 'host_pinned'

# Dummy Class for testing StrategyModule Constructor

# Generated at 2022-06-23 13:06:50.364470
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    from ansible_runner import Runner
    from ansible_runner.display import Display

    display_obj = Display()
    runner_obj = Runner(display=display_obj)

    strategy_obj = StrategyModule(runner_obj)
    assert strategy_obj._host_pinned == True


# Generated at 2022-06-23 13:06:54.440570
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create an instance of Ansible to fake out StrategyModule
    tqm = object()
    strategy_module = StrategyModule(tqm)
    # Assert default _host_pinned is True
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:06:58.661369
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy.host_pinned import StrategyModule
    tqm = TaskQueueManager(None, None)
    strategy = StrategyModule(tqm)
    assert strategy.get_host_pinned()

# Generated at 2022-06-23 13:07:00.503008
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm=None)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:07:03.513879
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    TQM = 'test_tqm'
    test_StrategyModule = StrategyModule(TQM)
    assert test_StrategyModule._tqm == 'test_tqm'
    assert isinstance(test_StrategyModule._display, Display)
    assert test_StrategyModule._host_pinned is True


# Generated at 2022-06-23 13:07:13.098737
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # import library
    import ansible.plugins.strategy.host_pinned as host_pinned

    # create object
    obj = host_pinned.StrategyModule(None)

    from ansible.plugins.strategy.host_pinned import StrategyModule
    assert isinstance(obj, StrategyModule) is True

# unit tests
from ansible.plugins.strategy.host_pinned import StrategyModule
from units.mock.loader import DictDataLoader
from units.mock.path import mock_unfrackpath_noop
from units.mock.path import mock_unfrackpath_success
import pytest


# Generated at 2022-06-23 13:07:14.541826
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("")
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:07:15.108504
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:07:19.168820
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '__init__')
    strategy_module = StrategyModule(None)
    assert hasattr(strategy_module, '_host_pinned')
    assert strategy_module._host_pinned == True



# Generated at 2022-06-23 13:07:21.155775
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # FIXME: Fix the test with proper initialisation.
    # Currently this test is just for the coverage
    assert StrategyModule is not None

# Generated at 2022-06-23 13:07:24.388035
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host1 = 'localhost'
    host2 = 'localhost'
    host3 = 'localhost'
    hosts = [host1, host2, host3]
    tqm = FreeStrategyModule(hosts)
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:07:27.462002
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).__init__() == None
    assert StrategyModule(None)._host_pinned == True

# Generated at 2022-06-23 13:07:28.959259
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of class StrategyModule")
    assert StrategyModule("Test") is not None

# Generated at 2022-06-23 13:07:31.548388
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_obj = StrategyModule(None)
    assert strategy_obj._host_pinned == True
    assert strategy_obj.batched_queue_items is None

# Generated at 2022-06-23 13:07:32.649069
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)._host_pinned == True


# Generated at 2022-06-23 13:07:33.149623
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule()

# Generated at 2022-06-23 13:07:34.802456
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule('test')
    assert s._host_pinned == True

# Generated at 2022-06-23 13:07:35.515387
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(''), StrategyModule)

# Generated at 2022-06-23 13:07:38.110145
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    s = StrategyModule(tqm)
    assert s._host_pinned

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:07:39.544735
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert s._host_pinned

# Generated at 2022-06-23 13:07:41.586549
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    myclass = StrategyModule(tqm)
    assert myclass



# Generated at 2022-06-23 13:07:44.041885
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    s = StrategyModule(tqm=('hi'))
    assert s._host_pinned == True

# Generated at 2022-06-23 13:07:45.856898
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.debug("Testing StrategyModule")
    tqm = {}
    strategy = StrategyModule(tqm)

# Generated at 2022-06-23 13:07:47.956747
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption\n'''

# Generated at 2022-06-23 13:07:50.105038
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"
    assert FreeStrategyModule.__name__ == "FreeStrategyModule"

# Generated at 2022-06-23 13:07:52.993794
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module is not None
    assert isinstance(strategy_module, StrategyModule)
    assert strategy_module._host_pinned is True

# Generated at 2022-06-23 13:07:54.497979
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned is True

# Generated at 2022-06-23 13:07:55.654787
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm = None)

# Generated at 2022-06-23 13:07:56.691924
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO
    assert True

# Generated at 2022-06-23 13:07:59.861983
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FakeTQM()
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True # pylint: disable=protected-access



# Generated at 2022-06-23 13:08:01.757051
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    s = StrategyModule(tqm)
    assert s is not None

# Generated at 2022-06-23 13:08:03.891711
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	import unittest
	class TestStrategyModule(unittest.TestCase):
		def test_constructor(self):
			self.assertTrue(StrategyModule)
	unittest.main()


# Generated at 2022-06-23 13:08:04.567422
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == True

# Generated at 2022-06-23 13:08:05.935255
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strtegy_class = StrategyModule(None)
    assert strtegy_class._host_pinned == True

# Generated at 2022-06-23 13:08:09.135262
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test constructor of class StrategyModule
    try:
        StrategyModule(None)
    except:
        display.error("Failed to create instance of class StrategyModule")



# Generated at 2022-06-23 13:08:11.362620
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# unit test for method _initialize_processes of class StrategyModule

# Generated at 2022-06-23 13:08:19.702673
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.verbosity = 4
    tqm = None
    obj1 = StrategyModule(tqm)
    obj1.get_host_list()

    try:
        obj1._check_name_conflict(["test_host"], "test_play")
    except AttributeError:
        pass

    try:
        obj1._check_name_conflict(["test_host"], "test_play")
    except AttributeError:
        pass

    obj1.add_tuple_to_queue(("test_host","test_play"))
    obj1.add_tuple_to_queue(("test_host","test_play"))
    obj1.queue_empty()
    obj1.queue_size()
    obj1.run_handlers(["test_host"], "test_play")
    obj1.get

# Generated at 2022-06-23 13:08:21.355194
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(FreeStrategyModule(None))


# Generated at 2022-06-23 13:08:21.817494
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:08:23.836362
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '__init__')
    assert hasattr(StrategyModule, 'display')

# Generated at 2022-06-23 13:08:26.516865
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule.name == 'host_pinned') and (StrategyModule.short_description == 'Executes tasks on each host without interruption')

# Generated at 2022-06-23 13:08:28.245398
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(1) == StrategyModule(1)



# Generated at 2022-06-23 13:08:29.781781
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule('tqm')
    if not isinstance(obj, StrategyModule):
        raise Exception('is not a StrategyModule')
    if not obj._host_pinned:
        raise Exception('_host_pinned is not set')

# Generated at 2022-06-23 13:08:32.276871
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule(tqm = "tqm")
    assert StrategyModule(tqm = tqm) == {"tqm": "tqm"}

# Generated at 2022-06-23 13:08:34.217242
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule == type(StrategyModule(0))

# Generated at 2022-06-23 13:08:40.379903
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm)
    assert(s._host_pinned)

# Usage: python -m ansible.plugins.strategy.host_pinned.StrategyModule
if __name__ == '__main__':
    from ansible.utils.display import Display
    display = Display()
    display.display('StrategyModule is being tested...')
    test_StrategyModule()
    display.display('StrategyModule tested OK.')

# Generated at 2022-06-23 13:08:42.363568
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule(tqm=1)
    assert x._host_pinned == True

# Generated at 2022-06-23 13:08:53.519334
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    assert StrategyModule.__mro__ == (StrategyModule, FreeStrategyModule, object)

# Generated at 2022-06-23 13:09:01.060151
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    try:
        tqm = StrategyModule(tqm)
    except Exception as e:
        print(str(e))
        assert False

test_StrategyModule()

# When the parent class of StrategyModule, i.e. FreeStrategyModule, is executed
# it returns an object. This test case runs in the StrategyModule constructor
# and instantiate the parent class. As result, a class is returned.

# To test StrategyModule, a Test class has to be written and StrategyModule has
# to be instantiated there.

# Generated at 2022-06-23 13:09:02.079960
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned = StrategyModule("tqm")
    host_pinned.__init__("tqm")

# Generated at 2022-06-23 13:09:02.771053
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:09:04.748752
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm = None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:09:05.954928
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:09:06.605018
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:09:08.010686
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule(tqm='tqm')
    except:
        pass

# Generated at 2022-06-23 13:09:10.636804
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__bases__ == (FreeStrategyModule,)
    assert StrategyModule.__init__.__func__ != FreeStrategyModule.__init__.__func__
    assert hasattr(StrategyModule, '_host_pinned')
    assert StrategyModule._host_pinned is True
    assert not hasattr(StrategyModule, 'host_pinned')
    assert StrategyModule.host_pinned is None

# Generated at 2022-06-23 13:09:12.146226
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)


# Generated at 2022-06-23 13:09:13.102305
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('tqm')

# Generated at 2022-06-23 13:09:13.784887
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_mod = StrategyModule(None)
    assert strategy_mod._host_pinned

# Generated at 2022-06-23 13:09:15.807884
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None
# end of Test

# Generated at 2022-06-23 13:09:16.729819
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:09:27.056688
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TaskQueueManager():
        pass
    tqm = TaskQueueManager()
    test = StrategyModule(tqm)
    assert test.worker_pool is None
    assert test.is_serial is False
    assert test.alive is True
    assert test.has_task_result is False
    assert test.is_block_notified is False
    assert test.num_lock is None
    assert test.need_lock_release is False
    assert test.results_lock is None
    assert test.pool_name is None
    assert test.iterator is None
    assert test.name is 'host_pinned'
    assert test._host_pinned is True
    assert test.default_vars is None

# Generated at 2022-06-23 13:09:31.291371
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestTqm:
        def __init__(self):
            self.display = Display()

    strategy = StrategyModule(TestTqm())
    assert strategy._host_pinned

# Generated at 2022-06-23 13:09:33.530705
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned == True, "_host_pinned should be True"

# Generated at 2022-06-23 13:09:37.241117
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_obj = StrategyModule()
    assert strategy_obj._host_pinned is True, "Host_pinned should be True"

# Generated at 2022-06-23 13:09:39.724341
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:09:40.831379
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-23 13:09:42.266375
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm = "test")
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:09:42.768667
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-23 13:09:46.649743
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import sys
    import mock
    # Check constructor
    test_class = StrategyModule(mock.MagicMock())
    assert test_class._host_pinned == True
    test_class.__del__()
    del sys.modules['ansible.plugins.strategy.host_pinned']

# Generated at 2022-06-23 13:09:49.447314
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    strategy = StrategyModule(None)
    assert strategy is not None
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:09:57.331854
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ check if the constructor for StrategyModule works as intended.
    This test depicts the scenario where IT IS A MULTI-MACHINE SCENARIO.
    """
    one_finished_host = '127.0.0.1'
    hosts = [one_finished_host,
             '127.0.0.2', '127.0.0.3', '127.0.0.4']

    def build_host_list(hosts, one_finished_host):
        all_hosts = []

# Generated at 2022-06-23 13:10:07.310709
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create an object of (empty) class HostVars
    class HostVars:
        pass
    # Create an object of (empty) class HostVars
    class HostQueue:
        def __init__(self):
            self.hosts = []
            self.active = []
    # Create an object of (empty) class TaskQueueManager
    class TaskQueueManager:
        def __init__(self):
            self.hostvars = HostVars()
            self.host_pinned = True
            self.inventory = None
            self.inventory_links = {}
            self.variable_manager = None
            self.loader = None
            self.options = None
            self.stdout_callback = None
            self.stats = None
            self.passwords = None
            self.callback_loader = None
            self.shared_loader

# Generated at 2022-06-23 13:10:09.430434
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Check that StrategyModule constructor sets default value
    strategy = StrategyModule(tqm=None)

    assert strategy

# Generated at 2022-06-23 13:10:11.209759
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule('test_tqm')
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:10:12.610471
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    obj = StrategyModule(tqm)

# Generated at 2022-06-23 13:10:15.360188
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategyModule = StrategyModule(tqm)
    assert strategyModule._host_pinned is True
    assert strategyModule._hosts_left is None

# Generated at 2022-06-23 13:10:16.930264
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule('test')
    b = True
    assert a._host_pinned == b

# Generated at 2022-06-23 13:10:18.501991
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)
    result = strategy._host_pinned
    assert result == True

# Generated at 2022-06-23 13:10:19.124104
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:10:20.954558
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    assert obj._host_pinned == True

# Generated at 2022-06-23 13:10:27.559143
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test'
    obj = StrategyModule(tqm)
    assert obj._host_pinned == True
    assert obj._tqm == 'test'
    assert obj.CHANGED_HOSTS == []
    assert obj.UNREACHABLE_HOSTS == []
    assert obj.FAILED_HOSTS == []
    assert obj.DEFAULT_TIMEOUT == 30
    assert obj.DEFAULT_POLL_INTERVAL == 15
    assert obj.HOST_STATE_KEYS == ['updated', 'failed', 'pending', 'skipped', 'changed', 'dark', 'ignored', 'ok']


# Generated at 2022-06-23 13:10:28.351082
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:10:30.905478
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module_obj = StrategyModule(tqm="test")
    strategy_module_obj._host_pinned


# Generated at 2022-06-23 13:10:32.761917
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 13:10:35.174398
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('tqm')
    assert(strategy_module._host_pinned == True)

# Generated at 2022-06-23 13:10:37.350399
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule({})
    assert tqm._host_pinned == True

# Generated at 2022-06-23 13:10:46.155879
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible import context
    from ansible.vars.hostvars import HostVars

    host = "localhost"
    m_TaskExecutor = TaskExecutor(host)
    m_PlaybookExecutor

# Generated at 2022-06-23 13:10:48.214410
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module is not None
    assert strategy_module._host_pinned is True

# Generated at 2022-06-23 13:10:49.224005
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()


# Generated at 2022-06-23 13:10:53.253930
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None, "StrategyModule class is expected not to be None"

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:10:56.029052
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    host_pinned = ansible.plugins.strategy.host_pinned.StrategyModule()
    assert host_pinned._host_pinned

# Generated at 2022-06-23 13:10:59.503570
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ite = StrategyModule('tqm')
    assert hasattr(ite, '_host_pinned')
    assert ite._host_pinned

# Generated at 2022-06-23 13:11:00.672771
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule("")
    assert strategyModule._host_pinned == True

# Generated at 2022-06-23 13:11:04.504309
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    Test case to check the module strategy_host_pinned.StrategyModule
    """
    module = StrategyModule()
    assert module is not None, "Failed to create the StrategyModule object"

# Generated at 2022-06-23 13:11:06.316129
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # assert that constructor of super was called
    assert StrategyModule


# Generated at 2022-06-23 13:11:10.219984
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    global strategy_instance
    strategy_instance = StrategyModule('tqm', 1)
    assert strategy_instance.tqm == 'tqm'
    assert strategy_instance.batch_size == 1

# Generated at 2022-06-23 13:11:16.412249
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert type(strategy) is StrategyModule
    assert strategy.tqm == None
    assert strategy._batch_size == 0
    assert strategy._current_batch == []
    assert strategy._inventory is None
    assert strategy._workers == 2
    assert strategy._notified_handlers.keys() == ['all', 'failed']

# unit test for function get_host_batch that takes a hosts iterator, fetches host from iterator and puts into a list

# Generated at 2022-06-23 13:11:19.199433
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    options = {}
    loader = True
    variable_manager = True
    tqm = True
    test_object = StrategyModule(tqm)
    result = isinstance(test_object, StrategyModule)
    assert(result == True)

# Generated at 2022-06-23 13:11:22.066754
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule("tqm")
    assert module.get_host_pinned() == True

# Generated at 2022-06-23 13:11:23.047955
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:11:24.348371
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-23 13:11:27.372861
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('tqm')
    assert strategy_module
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:11:31.116939
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test'
    strategy_module = StrategyModule(tqm)
    assert strategy_module.tqm == 'test'
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:11:33.411241
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None
# End of unit test for class StrategyModule

# Generated at 2022-06-23 13:11:38.256787
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    sm = StrategyModule(tqm)
    assert sm._tqm == tqm
    assert sm._host_pinned == True
    assert sm._batch is None
    assert sm._batch_size == 0
    assert sm._inventory is None
    assert sm._workers == list()
    assert isinstance(sm._display, Display)

# Generated at 2022-06-23 13:11:50.210614
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import sys
    import os
    import pdb
    sys.path.append(os.path.dirname(os.path.dirname(__file__)))
    from lib.utils.parsing import parse_kv
    from lib import cli
    from lib.ansible_internal_host_pinned import run

    display = Display()
    Display.verbosity = 4


# Generated at 2022-06-23 13:11:50.814418
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:11:52.851666
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock
    tqm = mock.MagicMock()
    x = StrategyModule(tqm)
    assert x._host_pinned == True

# Generated at 2022-06-23 13:11:55.868819
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ Test if constructor of class StrategyModule works properly. """
    tqm = "tqm"
    StrategyModule(tqm)

# Generated at 2022-06-23 13:11:57.116910
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    s = StrategyModule(tqm)
    assert s._host_pinned is True

# Generated at 2022-06-23 13:12:06.144165
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader

    yaml_data = """
        - hosts: localhost
          tasks:

            - name: test
              shell: /bin/false
              ignore_errors: yes
              register: result
              changed_when: false
              failed_when: false

            - name: handler
              shell: /bin/false
            - meta: end_play
    """

    my