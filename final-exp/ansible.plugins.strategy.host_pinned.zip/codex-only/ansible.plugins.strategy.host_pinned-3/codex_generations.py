

# Generated at 2022-06-23 13:02:09.870596
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ scenario: Test StrategyModule constructor
    Given:
        ansible-playbook run with arbitrary debug options
    When:
        StrategyModule initialized
    Then:
        class StrategyModule is initialized
    """
    # Setup
    # Ansible options
    ansible_options = None
    # Ansible inventory
    inventory = None
    # Class instantiation
    # AnsibleLoader instead of AnsibleLoader() to keep it independent of configuration files

# Generated at 2022-06-23 13:02:10.436227
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:02:11.896368
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:02:14.137476
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('tqm')
    assert strategy_module is not None
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:02:17.263008
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule(tqm=None)
    assert strategyModule._host_pinned == True

# Generated at 2022-06-23 13:02:17.945313
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(0)

# Generated at 2022-06-23 13:02:20.671504
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    from ansible.executor.task_queue_manager import TaskQueueManager as TQM

    tqm = TQM(None)

    strategy_module = StrategyModule(tqm)

    assert strategy_module._host_pinned == True



# Generated at 2022-06-23 13:02:21.547239
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:02:23.220101
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None) is not None

# Generated at 2022-06-23 13:02:25.383740
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_object = StrategyModule(tqm = True)
    assert test_object is not None


# Generated at 2022-06-23 13:02:28.330189
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    testStrategyModuleObject = StrategyModule(None)
    assert testStrategyModuleObject._host_pinned == True, "test_StrategyModule in host_pinned.py has failed"

# Generated at 2022-06-23 13:02:30.779080
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:02:31.505347
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:02:34.432820
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)



# Generated at 2022-06-23 13:02:37.223545
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy.display == Display()
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:02:43.137378
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy import get_strategy_object
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    ansible_dir = '../../../../../'
    playbook_path = ansible_dir + 'test/units/callback/sample_playbook.yml'
    playbook = Playbook.load(playbook_path, variable_manager=None, loader=None)
    host_list = '../../../../../test/units/inventory/test_hosts'

# Generated at 2022-06-23 13:02:52.759612
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned as host_pinned
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vault import VaultLib
    from ansible.parsing.vault import VaultSecret

    platforms = ["all"]
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

    loader = DataLoader()

# Generated at 2022-06-23 13:02:54.911216
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TaskQueueManager()
    stg = StrategyModule(tqm)
    assert stg._host_pinned


# Generated at 2022-06-23 13:02:57.067759
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Constructor of StrategyModule class")
    tqm = None
    StrategyModule(tqm)

# Test method of StrategyModule class

# Generated at 2022-06-23 13:03:00.509814
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  strategy_module = StrategyModule(FreeStrategyModule.tqm)
  assert hasattr(strategy_module,'_host_pinned')


# Generated at 2022-06-23 13:03:01.977227
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = None
    assert(StrategyModule(test_tqm)._host_pinned == True)

# Generated at 2022-06-23 13:03:05.055537
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock
    tqm = mock.Mock()
    myStrategyModule = StrategyModule(tqm)
    assert myStrategyModule.get_host_pinned() == True

# Generated at 2022-06-23 13:03:07.117268
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    create = StrategyModule(tqm)
    assert create.__init__(tqm)

# Generated at 2022-06-23 13:03:13.017271
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    data = '{"ansible_ssh_host": "172.16.0.1", "inventory_hostname": "test", "groups": ["dbservers", "webservers"]}'
    data = '{"original_host": "%s", "hostname": "test", "task": {"hostvars": {"original_host": "%s"}}}' % (data, data)
    StrategyModule(data)

# Generated at 2022-06-23 13:03:18.127942
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from six import add_metaclass
    from ansible.plugins.loader import StrategyModuleLoader
    from ansible.plugins.strategy import StrategyBase

    @add_metaclass(StrategyModuleLoader)
    class MockStrategyModule(StrategyBase):
        pass

    StrategyModule(MockStrategyModule)

# Generated at 2022-06-23 13:03:19.015453
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule("ansible")

# Generated at 2022-06-23 13:03:20.395198
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(None), StrategyModule)

# Generated at 2022-06-23 13:03:21.330557
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
        assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:03:23.368655
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("tqm")
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:03:25.098814
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module_tqm = StrategyModule
    assert module_tqm



# Generated at 2022-06-23 13:03:26.477119
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__ is not FreeStrategyModule.__init__

# Generated at 2022-06-23 13:03:29.068399
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    l=StrategyModule('tqm')
    assert(l._host_pinned)
    return 0


# Generated at 2022-06-23 13:03:30.983203
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 13:03:31.922595
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    #assert isinstance(tqm, None)


# Generated at 2022-06-23 13:03:33.699431
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert_equal(strategy_module._host_pinned, True)

# Generated at 2022-06-23 13:03:35.268215
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:03:37.632456
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:03:38.881652
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    S = StrategyModule(None)
    assert S._host_pinned == True

# Generated at 2022-06-23 13:03:39.741591
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)

# Generated at 2022-06-23 13:03:40.256101
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:03:50.248660
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pattern = 'all'
    forks = 3
    serial = 2
    pickup_contrib = True # not tested here
    subset = None
    run_tree = False # not tested here
    inventory = None # not tested here
    variable_manager = None # not tested here
    loader = None # not tested here
    options = None # not tested here
    stdout_callback = None # not tested here
    
    tqm = AnsibleTaskQueueManager(
        inventory = inventory,
        variable_manager = variable_manager,
        loader = loader,
        options = options,
        stdout_callback = stdout_callback,
        passwords = None,
        run_tree = run_tree,
    )
    strategyModule = StrategyModule(tqm)
    assert strategyModule._host_pinned

    display.verbosity = 3

# Generated at 2022-06-23 13:03:53.917590
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  obj = FreeStrategyModule()
  if obj.__class__.__name__ != "StrategyModule":
    raise AssertionError("Constructor of class StrategyModule not working correctly")

# Generated at 2022-06-23 13:03:54.932896
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(1)

# Generated at 2022-06-23 13:04:01.705018
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  strategy_module = StrategyModule(0)
  assert strategy_module._host_pinned == True
  assert strategy_module._inventory == None
  assert strategy_module._variable_manager == None
  assert strategy_module._workers == None
  assert strategy_module._notified_handlers == None
  assert strategy_module._shared_loader_obj == None
  assert strategy_module._play_context == None
  assert strategy_module._loader == None
  assert strategy_module._final_q == None

# Generated at 2022-06-23 13:04:03.738753
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ this is to test the constructor of the class """
    obj = StrategyModule(True)
    assert obj != None

# Generated at 2022-06-23 13:04:08.338119
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from collections import namedtuple
    mock_tqm = namedtuple('mock_tqm', ['host_pinned'])
    mock_tqm_obj = mock_tqm(host_pinned=True)
    test_StrategyModule = StrategyModule(mock_tqm_obj)
    assert hasattr(test_StrategyModule, '_host_pinned')
    assert test_StrategyModule._host_pinned == True

# Generated at 2022-06-23 13:04:12.118079
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == isinstance(StrategyModule(None), StrategyModule)
    assert False == isinstance(StrategyModule(None), FreeStrategyModule)
    assert True == isinstance(StrategyModule(None), object)

# Generated at 2022-06-23 13:04:22.904874
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible import constants as C
    from ansible.plugins.strategy import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.executor.play_iterator import PlayIterator

    # Set options to the value required for the StrategyModule constructor
    options = dict()
    options['listhosts'] = None
    options['listtasks'] = False
    options['listtags'] = False
    options['syntax'] = False
    options['connection'] = C.DEFAULT_TRANSPORT
    options['module_path'] = None
    options['forks'] = 5
    options['remote_user'] = C.DEFAULT_REMOTE_USER
    options['private_key_file'] = C.DE

# Generated at 2022-06-23 13:04:25.329304
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == FreeStrategyModule.__doc__
    assert StrategyModule.__init__.__doc__ == FreeStrategyModule.__init__.__doc__
test_StrategyModule()

# Generated at 2022-06-23 13:04:36.817261
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C
    tqm = TaskQueueManager(inventory=None, variable_manager=None, loader=None, options=C.config, passwords=None, stdout_callback=None, run_additional_callbacks=C.DEFAULT_LOAD_CALLBACK_PLUGINS, run_tree=False, playbook=None)

    s = StrategyModule(tqm)

    assert s._host_pinned == True
    assert s._blocked_hosts == set()
    assert s._stats is not None
    assert s._show_custom_stats is False
    assert s._worker_q is not None
    assert s._workers is not None
    assert s._attempted_hosts is not None
    assert s._done_host

# Generated at 2022-06-23 13:04:39.381150
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__(StrategyModule) == FreeStrategyModule.__init__(FreeStrategyModule)

# Generated at 2022-06-23 13:04:40.867737
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:04:41.582331
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule()

# Generated at 2022-06-23 13:04:42.822005
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)


# Generated at 2022-06-23 13:04:44.926149
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    b = StrategyModule(tqm)
    assert b._host_pinned
    assert b._tqm

# Generated at 2022-06-23 13:04:48.752598
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils import plugin_docs
    import ansible.plugins.strategy.host_pinned
    assert plugin_docs.get(ansible.plugins.strategy.host_pinned)
    assert callable(StrategyModule)

# Generated at 2022-06-23 13:04:49.328401
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:04:51.977882
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_list = [2]
    test = StrategyModule(host_list)
    assert test._tqm == host_list
    assert hasattr(test, '_host_pinned')

# Generated at 2022-06-23 13:04:52.728590
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:05:03.442713
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__
    assert StrategyModule.__bases__ == (FreeStrategyModule,)
    assert StrategyModule.__init__.__module__ == 'ansible.plugins.strategy.host_pinned'
    assert StrategyModule.__init__.__name__ == 'StrategyModule'
    assert StrategyModule.__init__.__doc__
    assert StrategyModule.__init__.__dict__['__annotations__']['tqm'] == 'TaskQueueManager'

    assert StrategyModule.get_host_pinned.__module__ == 'ansible.plugins.strategy.host_pinned'

# Generated at 2022-06-23 13:05:04.185625
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    c1 = StrategyModule()
    #print(c1)

# Generated at 2022-06-23 13:05:05.129321
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)


if __name__=='__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:05:10.647127
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule('tqm')
    obj.__init__('tqm')

# test for constructor of class StrategyModule
#def test_StrategyModule_constructor():
#    from ansible.plugins.strategy.host_pinned import StrategyModule
#    assert StrategyModule.__init__ is not None

# test for display var

# Generated at 2022-06-23 13:05:12.753100
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create the instance of the class
    strategy = StrategyModule('tqm')

    assert strategy._host_pinned is True

# Generated at 2022-06-23 13:05:15.431627
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ''
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned is True

# Generated at 2022-06-23 13:05:17.451900
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = True
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:05:19.687691
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    assert isinstance(obj, object)
    assert obj._host_pinned == True

# Generated at 2022-06-23 13:05:22.141721
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule()
    assert hasattr(x, '_host_pinned')
    assert isinstance(x._host_pinned, bool)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:05:30.564993
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_plugins = {}
    mock_loader = True
    mock_shared_loader_obj = True
    mock_inventory = True
    mock_variable_manager = True
    mock_all_vars = True
    mock_host_list = True
    mock_module_vars = True
    mock_module_utils = True
    mock_play_context = True
    mock_new_stdin = True
    mock_command_loader = True
    mock_connection_loader = True
    mock_shell_loader = True
    mock_module_loader = True
    mock_action_loader = True
    mock_cache = True
    mock_stdout_callback = True
    mock_stats = True
    mock_fail_host_event = True


# Generated at 2022-06-23 13:05:35.631564
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    import ansible.plugins.callbacks
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.play_context
    import ansible.playbook.block
    import ansible.utils.vars
    import ansible.template
    import ansible.executor.task_queue_manager
    import ansible.executor.playbook_executor
    import ansible.inventory.host
    import ansible.inventory.group
    import ansible.utils.display
    import ansible.vars
    import ansible.vars.manager

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-23 13:05:36.216717
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 13:05:36.881715
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 13:05:38.932352
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)

# Generated at 2022-06-23 13:05:48.584138
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import random
    import socket
    import string
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.callback import CallbackBase

    class ResultCallback(CallbackBase):
        """A sample callback plugin used for performing an action as results come in.
        """

# Generated at 2022-06-23 13:05:59.805304
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.playbook
    import ansible.plugins
    import ansible.utils.display
    from collections import namedtuple
    OPTIONS = namedtuple('Options', ['host_key_checking', 'forks', 'check', 'become', 'become_method', 'become_user', 'listhosts', 'listtasks', 'listtags', 'syntax', 'module_path', 'remote_user', 'private_key_file', 'ssh_common_args', 'ssh_extra_args', 'sftp_extra_args', 'scp_extra_args', 'become_extra_args', 'verbosity', 'connection', 'timeout', 'accelerate_timeout', 'accelerate_connect_timeout', 'accelerate_daemon_timeout', 'accelerate_multi_key', 'diff', 'gathering'])

# Generated at 2022-06-23 13:06:02.407239
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   tqm = None
   strategy_module = StrategyModule(tqm)
   assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:06:08.284722
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    options = []
    passwords = {}
    tqm = ""
    s = StrategyModule(tqm)
    try:
        assert expected_host_pinned == s._host_pinned
    except AssertionError:
        print("Assertion failed")


if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-23 13:06:10.111297
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule('')
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:06:20.528175
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import sys
    import json
    from io import StringIO

    monkeypatch = MonkeyPatch()

# Generated at 2022-06-23 13:06:22.330766
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert display.verbosity == 3
    assert display.columns == 0

# Generated at 2022-06-23 13:06:22.875844
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:06:24.298032
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Generated at 2022-06-23 13:06:29.496306
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    import ansible.plugins.strategy
    inst = ansible.plugins.strategy.host_pinned.StrategyModule(
        ansible.plugins.strategy.host_pinned.StrategyModule
    )
    assert inst._host_pinned == True

# Generated at 2022-06-23 13:06:32.556084
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__mro__ == (StrategyModule, object)
    assert StrategyModule.show_custom_stats
    assert StrategyModule._host_pinned

# Generated at 2022-06-23 13:06:33.903392
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(None)
    assert a._host_pinned == True



# Generated at 2022-06-23 13:06:36.681544
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Testing constructor')
    # Create StrategyModule object
    sm = StrategyModule(tqm)
    # Assert that object was created
    assert sm is not None

# Generated at 2022-06-23 13:06:37.424900
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-23 13:06:42.831911
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 'Ansible' in StrategyModule.__doc__
    assert 'Version' in StrategyModule.__doc__
    assert 'Author' in StrategyModule.__doc__
    assert 'short_description' in StrategyModule.__doc__
    assert 'description' in StrategyModule.__doc__
    # Actually executing super class constructor on StrategyModule
    StrategyModule(tqm)


# Generated at 2022-06-23 13:06:43.915557
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('tqm')

# Generated at 2022-06-23 13:06:45.641135
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-23 13:06:51.091354
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.utils.display import Display
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule

    display = Display()
    tqm = None
    strategy = StrategyModule(tqm)
    assert(type(strategy) is StrategyModule)
    assert(type(strategy) is FreeStrategyModule)

# Generated at 2022-06-23 13:06:51.797439
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
     assert StrategyModule

# Generated at 2022-06-23 13:06:57.696282
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create a fake tqm for the test
    class FakeTQM():
        def __init__(self):
            self.name = 'FakeTQM'
    fake_tqm = FakeTQM()
    s = StrategyModule(fake_tqm)

# ensure we can publish a file under this name
from ansible.plugins.strategy.host_pinned import StrategyModule

# Generated at 2022-06-23 13:07:01.132025
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import os
    import ansible.cli
    import ansible.plugins.strategy.host_pinned
    ansible.plugins.strategy.host_pinned.StrategyModule(ansible.cli.CLI.base_parser(os.getcwd()))

# Generated at 2022-06-23 13:07:05.351812
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TQM:
        def get_host_list(self):
            return ['host']
        def get_failed_hosts(self):
            return []
    assert StrategyModule(TQM())._host_pinned == True

# Generated at 2022-06-23 13:07:07.652881
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module


# Generated at 2022-06-23 13:07:08.334009
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__module__ == __name__

# Generated at 2022-06-23 13:07:09.736272
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    options = [1,2,3]
    strategys = StrategyModule(options)
    assert strategys._host_pinned == True

# Generated at 2022-06-23 13:07:10.606617
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(None), StrategyModule)

# Generated at 2022-06-23 13:07:13.451940
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        import ansible.plugins.strategy.host_pinned
        StrategyModule(None)
    except:
        print('StrategyModule is not defined')


# Generated at 2022-06-23 13:07:16.189784
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global display
    tqm = {'display': display}
    assert StrategyModule(tqm)._host_pinned == True

# Generated at 2022-06-23 13:07:18.208670
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_class = StrategyModule('tqm')
    assert strategy_class._host_pinned == True

# Generated at 2022-06-23 13:07:19.888013
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    str = StrategyModule(None)
    assert str._host_pinned == True


# Generated at 2022-06-23 13:07:20.331291
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:07:22.483055
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    module = StrategyModule(tqm)
    assert module is not None

# Generated at 2022-06-23 13:07:23.009905
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:07:24.547269
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ""
    obj = StrategyModule(tqm)
    assert obj._host_pinned is True

# Generated at 2022-06-23 13:07:27.686137
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule("StrategyModule")
    assert module._host_pinned == True



# Generated at 2022-06-23 13:07:29.166905
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule(tqm = None)
    assert x

# Generated at 2022-06-23 13:07:30.690361
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  strategy = StrategyModule(None)
  assert strategy._host_pinned == True

# Generated at 2022-06-23 13:07:31.549162
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:07:36.100489
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor import task_queue_manager
    from ansible.plugins.strategy.host_pinned import *

    # Constructor without fail
    strategy_instance = StrategyModule(task_queue_manager.TaskQueueManager())

    # Test _host_pinned attribute
    assert strategy_instance._host_pinned == True

# Generated at 2022-06-23 13:07:38.314756
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule('tqm')
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:07:40.554141
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = test_class(Runner)
    test = StrategyModule(tqm)
    assert test._host_pinned == True

# Generated at 2022-06-23 13:07:42.023356
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule(None)
    assert True == strategyModule._host_pinned


# Generated at 2022-06-23 13:07:43.439107
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_obj = StrategyModule('tqm')
    assert strategy_obj._host_pinned == True

# Generated at 2022-06-23 13:07:45.304185
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, StrategyModule) == True

# Generated at 2022-06-23 13:07:48.584582
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create a strategy module object
    sm = StrategyModule(None)
    #strategy module object should inherit class FreeStrategyModule
    assert isinstance(sm, FreeStrategyModule)
    # test initial value of _host_pinned
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:07:49.892636
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule(tqm)
    assert x._host_pinned == True

# Generated at 2022-06-23 13:07:50.461597
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:07:52.993770
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule("tqm")
    assert module._number_of_hosts == 0
    assert module._host_pinned == True

# Generated at 2022-06-23 13:07:53.593631
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:07:56.038492
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    def test_StrategyModule(self):
        obj = StrategyModule(tbd)
        self.assertIsInstance(obj, StrategyModule)

# Generated at 2022-06-23 13:07:57.906173
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm=None)
    assert sm._host_pinned == True



# Generated at 2022-06-23 13:07:59.372783
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule("test")
    assert module._host_pinned

# Generated at 2022-06-23 13:08:02.453100
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy = StrategyModule(tqm)
    assert strategy._tqm == tqm
    assert strategy._display == display
    assert strategy._host_pinned

# Generated at 2022-06-23 13:08:05.893142
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_object = StrategyModule(tqm=None)
    print(strategy_object._host_pinned)
    assert strategy_object.__class__.__name__ == 'StrategyModule'

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:08:07.266849
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule == StrategyModule.__init__('tqm')

# Generated at 2022-06-23 13:08:09.603510
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s_m = StrategyModule('tqm')
    assert(s_m._host_pinned == True)

# Generated at 2022-06-23 13:08:10.974099
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule, "StrategyModule instantiated"

# Generated at 2022-06-23 13:08:12.106127
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 13:08:14.871168
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(None, None, None, None, 1)
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True
    print('Strategy Module constructor test passed')


# Generated at 2022-06-23 13:08:18.481696
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()

# Generated at 2022-06-23 13:08:19.190130
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:08:20.729165
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == FreeStrategyModule.__doc__

# Generated at 2022-06-23 13:08:29.490132
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.boolean import boolean

    class dummy_tqm(object):
        class dummy_inventory_manager(object):
            class dummy_loader(object):
                class dummy_inventory(object):
                    class dummy_host(object):
                        def __init__(self):
                            self.name = "localhost"


# Generated at 2022-06-23 13:08:30.992278
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)


# Generated at 2022-06-23 13:08:31.668794
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:08:35.108915
# Unit test for constructor of class StrategyModule
def test_StrategyModule():  # constructor
    module = StrategyModule(tqm=None)
    assert isinstance(module, StrategyModule)



# Generated at 2022-06-23 13:08:37.160311
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    instance = StrategyModule("tqm")
    assert instance._host_pinned is True



# Generated at 2022-06-23 13:08:39.864953
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == FreeStrategyModule.__doc__

# Generated at 2022-06-23 13:08:41.461507
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule(tqm=None)
    assert tqm is not None

# Generated at 2022-06-23 13:08:44.886312
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Unit test to compare if two objects are equal and returns True if they are equal and False if they are not equal.

# Generated at 2022-06-23 13:08:45.411307
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:08:48.194795
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "Test1"
    assert StrategyModule(tqm)._tqm == "Test1"
    assert StrategyModule(tqm)._host_pinned == True

# Generated at 2022-06-23 13:08:49.894827
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:08:51.258342
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)._host_pinned == True

# Generated at 2022-06-23 13:08:52.148314
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:08:53.549839
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy._host_pinned is True

# Generated at 2022-06-23 13:09:04.081371
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  strategy = StrategyModule(tqm='tqm')
  assert strategy._host_pinned is True
  assert strategy._tqm == 'tqm'
  assert strategy._inventory is None
  assert strategy._failure_limit == 0
  assert strategy._display is not None
  assert strategy._display.__class__.__name__ == 'Display'
  assert strategy._options is None
  assert strategy._loader is None
  assert strategy._variable_manager is None
  assert strategy._host_states is None
  assert strategy._notified_handlers is None
  assert strategy._listeners is None
  assert strategy._stats is None
  assert strategy._blocked_hosts is None
  assert strategy._cur_serial_failures == {}
  assert strategy._serial == 0


# Generated at 2022-06-23 13:09:06.379284
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    o = StrategyModule(tqm=None)
    assert o._host_pinned == True
    assert o._display is not None
    assert o._tqm is None

# Generated at 2022-06-23 13:09:13.806719
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule as Host_pinnedStrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    host_list = ['localhost', 'remote']
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=host_list)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 13:09:16.623389
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "tqm"
    ans_module = StrategyModule(tqm)
    assert ans_module._tqm == "tqm"

# Generated at 2022-06-23 13:09:17.444216
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:09:20.521307
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:09:21.953337
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule('tqm')
    assert strategyModule is not None

# Generated at 2022-06-23 13:09:25.652139
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    import ansible.plugins.strategy.host_pinned as strategy_host_pinned

    assert strategy_host_pinned.StrategyModule.__bases__[0].__name__ == 'FreeStrategyModule'



# Generated at 2022-06-23 13:09:31.018828
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager()
    strategy = StrategyModule(tqm)
    assert(strategy._host_pinned)

# Generated at 2022-06-23 13:09:32.303083
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule()
    assert x._host_pinned == True

# Generated at 2022-06-23 13:09:33.844354
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None

# Generated at 2022-06-23 13:09:36.373197
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule.__init__, object) == True


# Generated at 2022-06-23 13:09:37.244777
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:09:37.909166
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:09:39.975933
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'hello'
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:09:41.566598
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategymodule = StrategyModule(tqm)

# Generated at 2022-06-23 13:09:45.322377
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    tqm = dict()
    tqm['_host_pinned'] = True
    sm = ansible.plugins.strategy.host_pinned.StrategyModule(tqm)
    assert sm._host_pinned



# Generated at 2022-06-23 13:09:50.830290
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Tests the StrategyModule constructor"""

    class MockTQM:
        pass

    tqm = MockTQM()
    tqm.hostvars = {}

    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned is True



# Generated at 2022-06-23 13:09:52.616342
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule(tqm=None)
    except Exception as e:
        print("Exception thrown: ", e)


# Generated at 2022-06-23 13:09:54.888032
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:09:56.121002
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned is True

# Generated at 2022-06-23 13:10:06.585255
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from lib.tqm import TQM

    class TestStrategyModule(unittest.TestCase):
        @classmethod
        def setUpClass(self):
            self.tqm = TQM()
            self.tqm._tqm_data['inventory'].hosts = [1, 2]
            self.tqm._tqm_data['variable_manager']._extra_vars = {"ansible_ssh_host": "127.0.0.1"}

# Generated at 2022-06-23 13:10:07.217463
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:10:08.979327
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    temp_tmq = "tmq"
    StrategyModule(temp_tmq)

# Generated at 2022-06-23 13:10:10.291085
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test for StrategyModule
    '''
    pass

# Generated at 2022-06-23 13:10:12.560383
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule()
    assert module is not None
    assert module.__class__.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:10:23.202900
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned as strategy
    from ansible.plugins.strategy import StrategyBase
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.strategy.host_pinned import StrategyModule as HostPinnedStrategyModule
    import ansible.playbook.play
    from ansible.playbook.play_context import PlayContext

    def test():
        assert StrategyBase is not None
        assert StrategyModule is not None
        assert HostPinnedStrategyModule is not None

        test_hosts = ['hostA', 'hostB', 'hostC', 'hostD', 'hostE']

# Generated at 2022-06-23 13:10:25.806591
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned



# Generated at 2022-06-23 13:10:27.952718
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule("local")
    assert sm._host_pinned is True

# Generated at 2022-06-23 13:10:28.727989
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:10:30.828810
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    obj = StrategyModule(tqm)
    assert obj._host_pinned is True

# Generated at 2022-06-23 13:10:35.710145
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	''' Unit test for constructor of class StrategyModule '''
	strategymodule = StrategyModule()
	assert strategymodule is not None

if __name__ == '__main__':
	# Unit test for constructor of class StrategyModule
	test_StrategyModule()

# Generated at 2022-06-23 13:10:36.641399
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-23 13:10:37.817738
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    st1 = StrategyModule("tqm")
    assert st1._host_pinned is True

# Generated at 2022-06-23 13:10:39.552165
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm="tqm")

    assert sm._host_pinned is True

# Generated at 2022-06-23 13:10:42.128487
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = Object()
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:10:43.991750
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)
# Done testing constructor of class StrategyModule

# Generated at 2022-06-23 13:10:45.583934
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = None
  instance = StrategyModule(tqm)
  assert instance._host_pinned == True



# Generated at 2022-06-23 13:10:47.286751
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert "StrategyModule"


# Generated at 2022-06-23 13:10:48.535022
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(1)
    assert sm._host_pinned



# Generated at 2022-06-23 13:10:55.725542
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    from ansible.plugins.strategy import host_pinned
    assert ansible.plugins.strategy.host_pinned.StrategyModule == host_pinned.StrategyModule
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy import host_pinned
    s = host_pinned.StrategyModule(None)

# Generated at 2022-06-23 13:10:58.196141
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module is not None

# Generated at 2022-06-23 13:11:01.656814
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule.test_StrategyModule()
    assert sm.__class__.__name__ == "StrategyModule"
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:11:07.094133
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("In test_StrategyModule()")
    strategy = StrategyModule("tqm")
    assert strategy is not None
    assert strategy._host_pinned is True
    print("    ****    PASS    ****")

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:11:16.660297
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import  mock
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.playbook.task_queue_manager import TaskQueueManager
    task_queue_manager = mock.Mock(spec=TaskQueueManager)
    strategy_module = StrategyModule(task_queue_manager)
    task_queue_manager.callback.set_options.assert_called_once_with(allow_parallel=True, on_any_unreachable=None, on_any_failed=None, on_any_failed_or_unreachable=None)
    strategy_module._host_pinned is True
    task_queue_manager.hostvars.assert_called_once()
    assert strategy_module._hostvars == task_queue_manager.hostvars()


# Generated at 2022-06-23 13:11:17.225252
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:11:19.797750
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule({})
    assert strategy_module._host_pinned

# Generated at 2022-06-23 13:11:23.088134
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule('test')
    assert sm._host_pinned == True
    assert sm.__class__.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:11:26.128842
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule({})
    assert sm._host_pinned
    print('Unit test for constructor of class StrategyModule: OK')


# Generated at 2022-06-23 13:11:35.757039
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.strategy import StrategyModule


# Generated at 2022-06-23 13:11:38.176775
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test instanciation of class StrategyModule
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None
    assert strategy_module._host_pinned is True

# Generated at 2022-06-23 13:11:44.368831
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy.__class__ == StrategyModule
    assert strategy._display is not None
    assert strategy._play_context is not None
    assert strategy._tqm is None
    assert strategy._failed_hosts is not None
    assert strategy._unreachable_hosts is not None
    assert strategy._stats is not None

# Generated at 2022-06-23 13:11:47.449502
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of StrategyModule")
    strategy = StrategyModule(None)
    print("Constructor of StrategyModule tested")
    return strategy

# Generated at 2022-06-23 13:11:49.560485
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm='tqm') == None

# Generated at 2022-06-23 13:11:50.728064
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule("tqm")


# Generated at 2022-06-23 13:11:52.282686
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule([ "localhost" ])
    assert strategy._host_pinned

# Generated at 2022-06-23 13:11:53.426174
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Generated at 2022-06-23 13:11:55.095718
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(1)

# Generated at 2022-06-23 13:11:56.394035
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   # TODO
   assert True == True

# Generated at 2022-06-23 13:11:57.301306
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule()
    StrategyModule(tqm)

# Generated at 2022-06-23 13:11:58.921669
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()
    assert s._host_pinned == True



# Generated at 2022-06-23 13:12:00.902863
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   # creating an object for StrategyModule class
   sm = StrategyModule.StrategyModule()
   print(sm)

# Generated at 2022-06-23 13:12:02.888645
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=FreeStrategyModule(tqm=None))