

# Generated at 2022-06-23 13:02:03.856435
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm = None) is not None


# Generated at 2022-06-23 13:02:09.506561
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.constants as C
    import json
    import os
    import sys
    import yaml
    import ansible.utils.vars
    import ansible.utils.unicode
    import ansible.executor.process.worker
    import ansible.vars.manager

    C.HOST_KEY_CHECKING = False
    # change the constants as we want
    C.DEFAULT_PRIVATE_KEY_FILE = 'id_rsa'
    C.DEFAULT_HOST_LIST = 'inventory'
    C.DEFAULT_FORKS = 5
    C.DEFAULT_MODULE

# Generated at 2022-06-23 13:02:10.434212
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule()
    print('Hello')

# Generated at 2022-06-23 13:02:13.978474
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Ansible 2.7.0
    # test simple usage
    m = StrategyModule('test')
    assert m is not None
    assert m._host_pinned is True

# Generated at 2022-06-23 13:02:15.571109
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    TQM = []
    test_strategy = StrategyModule(TQM)
    assert test_strategy._host_pinned == True

# Generated at 2022-06-23 13:02:18.956122
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # We have to pass a tqm to StrategyModule method
    tqm = None
    StrategyModule(tqm)


# Generated at 2022-06-23 13:02:23.721361
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Check the StrategyModule class inheritance and its public methods
    assert issubclass(StrategyModule, FreeStrategyModule)
    assert callable(StrategyModule.__init__)
#

# vim: ft=python et ts=4 sw=4

# Generated at 2022-06-23 13:02:26.555845
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("\ntest_StrategyModule: ")
    x = StrategyModule("test_StrategyModule")
    assert x._host_pinned == True

# Generated at 2022-06-23 13:02:27.110391
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:02:30.180896
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Created instance of class StrategyModule()
    strategy_module =  StrategyModule()
    # Checking if StrategyModule() instance is created properly
    assert isinstance(strategy_module, StrategyModule)

# Generated at 2022-06-23 13:02:32.030570
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj1 = StrategyModule()
    assert obj1._host_pinned is True

# Generated at 2022-06-23 13:02:35.515469
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)._host_pinned == True


# vim: set et fileencoding=utf-8 :

# Generated at 2022-06-23 13:02:36.015956
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:02:37.413322
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm='tqm')
    assert strategy._host_pinned

# Generated at 2022-06-23 13:02:39.179998
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_StrategyModule = StrategyModule()
    print (type(my_StrategyModule))
    print (my_StrategyModule._host_pinned)

# Generated at 2022-06-23 13:02:41.609360
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    s = StrategyModule(tqm)
    assert s._host_pinned == True

# Generated at 2022-06-23 13:02:44.677307
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule('tqm')
    assert strategy
    assert strategy.tqm == 'tqm'
    assert strategy.host_pinned


# Generated at 2022-06-23 13:02:47.298457
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned = StrategyModule("tqm")
    host_pinned._host_pinned

# Generated at 2022-06-23 13:02:47.991807
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:02:51.280442
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = "test_tqm"
    strategy_module = StrategyModule(test_tqm)
    assert strategy_module._tqm == "test_tqm"

# Generated at 2022-06-23 13:02:59.093302
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # testing __init__ function
    assert strategy_module.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:03:07.522079
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned as host_pinned
    from ansible.executor.task_queue_manager import TaskQueueManager as Tqm
    from ansible.inventory.manager import InventoryManager as Im
    from ansible.vars.manager import VariableManager as Vm
    from ansible.parsing.dataloader import DataLoader as Dl
    from ansible.playbook.play import Play as Pl
    from ansible.executor.playbook_executor import PlaybookExecutor as Pbe
    from ansible.executor.task_executor import TaskExecutor as Te
    from ansible.utils.vars import AnsibleVars
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars

# Generated at 2022-06-23 13:03:09.016326
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm = None)


# Generated at 2022-06-23 13:03:10.084924
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__

# Generated at 2022-06-23 13:03:11.101034
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=(0,))

# Generated at 2022-06-23 13:03:12.513573
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(display)
    assert(a._host_pinned == True)

# Generated at 2022-06-23 13:03:14.175294
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	#Fails without assert
    assert StrategyModule.__init__


# Generated at 2022-06-23 13:03:19.468400
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule) ,"inheritance issue"
    assert StrategyModule.__doc__ == 'Executes tasks on each host without interruption' ,"__doc__ issue"
    assert StrategyModule.__name__ == 'StrategyModule' ,"__name__ issue"
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned' ,"__module__ issue"
    assert StrategyModule._host_pinned == True ,"_host_pinned issue"



# Generated at 2022-06-23 13:03:20.866574
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm)

# Generated at 2022-06-23 13:03:24.193968
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("In test_StrategyModule()")
    tqm = true
    test_StrategyModule = StrategyModule(tqm)
    assert test_StrategyModule._host_pinned == True

# Generated at 2022-06-23 13:03:36.249091
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C

    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='setup', args=''), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )


# Generated at 2022-06-23 13:03:41.816237
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
    This test case tests the constructor of the class StrategyModule
    """
    # Calling the default constructor
    strategy_obj = StrategyModule(None)

    # Calling the constructor in which we pass 
    # the instance of tqm i.e TaskQueueManager
    strategy_obj = StrategyModule(strategy_obj)

    # Asserting whether the setter method set the
    # private attribute _host_pinned to True
    assert strategy_obj._host_pinned == True

# Generated at 2022-06-23 13:03:42.342598
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == True

# Generated at 2022-06-23 13:03:44.806717
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule("tqm")
    assert module._host_pinned == True

# Generated at 2022-06-23 13:03:48.653814
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''Test constructor of class StrategyModule'''

    # Construct object of class StrategyModule
    res = StrategyModule()

    # Tests
    assert isinstance(res._host_pinned, bool)
    if __name__ == '__main__':
        test_StrategyModule()

# Generated at 2022-06-23 13:03:51.838073
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ''' Unit test to confirm if StrategyModule is working properly'''
    test_strategy_module = StrategyModule()
    assert(test_strategy_module.__init__()) == None



# Generated at 2022-06-23 13:03:54.328868
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule.__init__(StrategyModule, 'tqm')
    assert x is not None

# Generated at 2022-06-23 13:03:57.406574
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("tqm")
    assert(strategy_module._host_pinned == True), "Ansible 'host_pinned' strategy module."

# Generated at 2022-06-23 13:03:58.421688
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__

# Generated at 2022-06-23 13:04:01.145499
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test the creation of StrategyModule object
    strategy = StrategyModule('tqm_test')
    assert strategy._host_pinned == True, 'StrategyModule object not created'

# Generated at 2022-06-23 13:04:07.288370
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    import ansible.plugins.strategy.host_pinned as host_pinned_strategy_module
    from ansible.plugins.strategy import StrategyBase

    strategy = StrategyBase()
    strategy_module = host_pinned_strategy_module.StrategyModule(strategy)
    assert strategy_module != None
    assert strategy_module._host_pinned == True
    assert strategy_module._tqm == strategy

# Basic unit test for strategy

# Generated at 2022-06-23 13:04:08.549274
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule("tqm")
    assert(strategy._host_pinned)

# Generated at 2022-06-23 13:04:11.027008
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass
    # assert os.path.exists("/tmp")
'''
if __name__ == "__main__":
    result = test_StrategyModule()
    print(result)
'''

# Generated at 2022-06-23 13:04:14.040702
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strat_module = StrategyModule(tqm="tqm")
    assert strat_module._host_pinned

# Unit Test for execute()

# Generated at 2022-06-23 13:04:16.530966
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display.debug("Constructor of StrategyModule")
    selected_strategy = StrategyModule("task")
    assert selected_strategy is not None

# Generated at 2022-06-23 13:04:18.100707
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    StrategyModule(tqm)

# Generated at 2022-06-23 13:04:20.634138
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__, "No docstring in StrategyModule"
    assert StrategyModule.__init__.__doc__, "No docstring in StrategyModule.__init__"

# Generated at 2022-06-23 13:04:22.821603
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule("tqm")
    # Test the constructor of class StrategyModule.
    assert isinstance(obj, StrategyModule) is True

# Test class StrategyModule with the mock data provided in the test.

# Generated at 2022-06-23 13:04:23.490552
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-23 13:04:26.435309
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    t = {}
    strategy = StrategyModule(t)
    t['_host_pinned'] == True

# Generated at 2022-06-23 13:04:28.075694
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test")
    StrategyModule()

#Unit test for constructor of class FreeStrategyModule

# Generated at 2022-06-23 13:04:29.137307
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(1)._host_pinned == True

# Generated at 2022-06-23 13:04:31.872612
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing constructor of StrategyModule")
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert True

# Generated at 2022-06-23 13:04:32.902491
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 13:04:39.238469
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    hosts_to_unreach = ['once','twice','thrice']
    hosts_to_unreach = []
    tqm = PlaybookExecutor(hosts_to_unreach, hosts_to_unreach, hosts_to_unreach, hosts_to_unreach)
    StrategyModule(tqm)
# End of test case


# Generated at 2022-06-23 13:04:44.720878
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Define a function called test_StrategyModule
    '''
    assert issubclass(StrategyModule, FreeStrategyModule) is True
    assert StrategyModule.__module__ == FreeStrategyModule.__module__
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Default strategy module, which just queues all tasks'

# Generated at 2022-06-23 13:04:49.956423
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestStrategyModule(StrategyModule):
        def __init__(self, tqm):
            super(StrategyModule, self).__init__(tqm)
            self._host_pinned = True
    assert(isinstance(TestStrategyModule, StrategyModule))
    assert(isinstance(TestStrategyModule, FreeStrategyModule))



# Generated at 2022-06-23 13:04:52.259311
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    m = StrategyModule
    assert m.__name__ == " StrategyModule"
    m = StrategyModule
    assert m.__name__ == " StrategyModule"

# Generated at 2022-06-23 13:04:54.172184
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_class = StrategyModule(tqm)
    assert my_class._host_pinned == True

# Generated at 2022-06-23 13:04:55.244164
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Generated at 2022-06-23 13:04:56.395637
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-23 13:04:57.022886
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:04:59.730838
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """
      Test constructor of class StrategyModule
    """
    strategy = StrategyModule()
    assert strategy is not None, "Fail: StrategyModule constructor"

# Generated at 2022-06-23 13:05:01.339256
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(None)
    assert isinstance(a, StrategyModule)

# Generated at 2022-06-23 13:05:02.400866
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1 == 1


# Generated at 2022-06-23 13:05:06.528243
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Setup a test StrategyModule object for unit testing
    from ansible.playbook.task_queue_manager import TaskQueueManager
    from ansible.executor.task_queue_manager import TaskQueueManager as ExecutorTaskQueueManager
    from ansible.plugins.strategy.host_pinned import StrategyModule
    tqm = TaskQueueManager()
    tqm._stdout_callback = ExecutorTaskQueueManager._display.display
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned

# Generated at 2022-06-23 13:05:08.905919
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MagicMock()
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:05:18.970830
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption
        - Task execution is as fast as possible per host in batch as defined by C(serial) (default all).
          Ansible will not start a play for a host unless the play can be finished without interruption by tasks for another host,
          i.e. the number of hosts with an active play does not exceed the number of forks.
          Ansible will not wait for other hosts to finish the current task before queuing the next task for a host that has finished.
          Once a host is done with the play, it opens it's slot to a new host that was waiting to start.
          Other than that, it behaves just like the "free" strategy.
        version_added: "2.7"
        author: Ansible Core Team
    '''

# Generated at 2022-06-23 13:05:26.961160
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class tqm:
        callback = None
        callbacks = None
        stats = None
        stdout_callback = None
        stdout_callbacks = None
        basedir = None
        inventory = None
        variable_manager = None
        loader = None
        passwords = None
        forks = None
        timeout = None
        remote_user = None
        remote_port = None
        become_method = None
        become_user = None
        become_ask_pass = None
        module_name = None
        play = None
        extra_vars = None
        extra_vars_q = None
        private_key_file = None
        context = None
        version_warning = None
        asynchronous = None
        output_path = None
        max_fail_pct = None
        nocolor = None
        module_v

# Generated at 2022-06-23 13:05:29.333496
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    Tqm = display
    s = StrategyModule(Tqm)
    assert s._host_pinned == True

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:05:30.547350
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned

# Generated at 2022-06-23 13:05:32.320592
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  tqm = None
  strategy_module = StrategyModule(tqm)
  assert strategy_module
  assert(isinstance(strategy_module, StrategyModule))

# Generated at 2022-06-23 13:05:35.327444
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ans_strategy = StrategyModule(tqm={})
    assert ans_strategy.get_host_pinned() == True

# Generated at 2022-06-23 13:05:37.260795
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModuleInstance = StrategyModule('tqm')
    assert strategyModuleInstance._host_pinned == True

# Generated at 2022-06-23 13:05:40.282106
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TaskQueueManager()
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:05:40.937818
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:05:45.139426
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_data = dict()
    test_data["status"] = True
    test_data["msg"] = "Successfully initiated the object"

    assert test_data["status"] == True
    assert test_data["msg"] == "Successfully initiated the object"

# Generated at 2022-06-23 13:05:45.540740
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule()

# Generated at 2022-06-23 13:05:47.864665
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule("the_tqm")
    assert strategy is not None
    assert strategy._host_pinned

# Generated at 2022-06-23 13:05:48.875353
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-23 13:05:52.812802
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class mock_tqm(object):
        hosts = {}
        workers = 0
    tqm = mock_tqm()
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:05:53.420909
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:05:54.478450
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    cur_obj = StrategyModule()

# Generated at 2022-06-23 13:05:55.875275
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = []
    StrategyModule(tqm)

# Generated at 2022-06-23 13:05:58.808238
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager

    assert TaskQueueManager._strategy_plugins[b'host_pinned'] == StrategyModule

# Generated at 2022-06-23 13:06:01.251756
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    expected_host_pinned = True
    tqm = ""
    obj = StrategyModule(tqm)
    actual_host_pinned = obj._host_pinned
    assert actual_host_pinned == expected_host_pinned

# Generated at 2022-06-23 13:06:01.849150
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:06:02.566299
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:06:06.821295
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    import ansible.plugins.strategy.free
    assert issubclass(StrategyModule, ansible.plugins.strategy.free.StrategyModule)

# Generated at 2022-06-23 13:06:08.236498
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None) is not None


# Generated at 2022-06-23 13:06:13.889477
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    from ansible.utils.display import Display

    test = unittest.TestCase()

    class TestTqm:
        def __init__(self):
            self.display = Display()

    tqm = TestTqm()
    strategy = StrategyModule(tqm)
    test.assertTrue(strategy._host_pinned)

# Generated at 2022-06-23 13:06:15.228774
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-23 13:06:18.058787
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned as host_pinned
    t = type('Test', (object,), {'tqm':{}})
    host_pinned.StrategyModule(t)

# Generated at 2022-06-23 13:06:18.860234
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule




# Generated at 2022-06-23 13:06:19.604441
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('tqm') != None

# Generated at 2022-06-23 13:06:20.332554
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Must return None with no failed test
    pass

# Generated at 2022-06-23 13:06:23.049095
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ''' test_StrategyModule
    Test the constructor of the class StrategyModule
    '''
    # tqm = TODO
    strategy_module = StrategyModule(tqm)

# Generated at 2022-06-23 13:06:25.225492
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module._host_pinned == True


# Generated at 2022-06-23 13:06:27.122981
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategyModule = StrategyModule(tqm)
    assert True

# Generated at 2022-06-23 13:06:28.837461
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm='tqm') != None

# Generated at 2022-06-23 13:06:30.409484
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Class exists
    assert StrategyModule


# Generated at 2022-06-23 13:06:32.948764
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Load the strategy module as a global variable so that it can be used in tests that do not use the strategy plugin loader
global_strategy_module = StrategyModule

# Generated at 2022-06-23 13:06:34.316205
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Test suite for class StrategyModule

# Generated at 2022-06-23 13:06:36.701223
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test instantiating class StrategyModule
    fake_tqm = "tqm"
    strag = StrategyModule(fake_tqm)
    assert strag._host_pinned == True

# Generated at 2022-06-23 13:06:38.070120
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.loader import get_all_plugin_loaders
    print(get_all_plugin_loaders())

# Generated at 2022-06-23 13:06:39.484022
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-23 13:06:42.675975
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    Tqm = type('Tqm', (object,), dict())
    tqm = Tqm()
    strategy = StrategyModule(tqm)
    assert isinstance(strategy, StrategyModule)

# Generated at 2022-06-23 13:06:43.348950
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:06:44.939815
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)

# Generated at 2022-06-23 13:06:45.801391
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TestTqm()
    StrategyModule(tqm)


# Generated at 2022-06-23 13:06:48.035037
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import __main__
    # Set value for global _host_pinned as True
    __main__._host_pinned = True


# Generated at 2022-06-23 13:06:49.381735
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule('test')
    assert module._host_pinned

# Generated at 2022-06-23 13:06:53.471949
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(None)
    StrategyModule(tqm)

# unit test
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:06:57.201530
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == '''
    Executes tasks on each host without interruption
    '''

    tqm = object()
    s = StrategyModule(tqm)
    assert s._queue_name == 'host_pinned'
    assert s._host_pinned is True
    assert s._tqm is tqm

# Generated at 2022-06-23 13:06:58.941976
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert s is not None
    assert s._host_pinned is True

# Generated at 2022-06-23 13:07:00.233301
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1 == 1, "StrategyModule: constructor test fail"

# Generated at 2022-06-23 13:07:02.061053
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    assert StrategyModule(tqm) is not None

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:07:03.318005
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(123456)._host_pinned

# Generated at 2022-06-23 13:07:06.459420
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True
    assert strategy._tqm is None

# Generated at 2022-06-23 13:07:10.023367
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = AnsibleTaskQueueManager(inventory=None, variable_manager=None, loader=None, options=None, passwords=None)
    test_strategy = StrategyModule(tqm)
    assert test_strategy._host_pinned is True

# Generated at 2022-06-23 13:07:11.679605
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:07:14.648425
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Constructor initializes _host_pinned to true
    strategy_module = StrategyModule(tqm = None)
    assert strategy_module._host_pinned

# Generated at 2022-06-23 13:07:18.344362
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    display.verbosity = 4
    display.color = 'yes'
    display.columns = 80
    display.display("test_StrategyModule")


# Generated at 2022-06-23 13:07:20.361525
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = Mock()
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned is True


# Generated at 2022-06-23 13:07:28.159935
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # pylint: disable=unused-argument,invalid-name
    def dm_factory(loader, task_name, task_args, shared_loader_obj=None):
        return None

    task_queue_manager = FakeTaskQueueManager(None, None, None, None, None, None, None, None, dm_factory)
    strategy = StrategyModule(task_queue_manager)

    assert strategy._host_pinned, 'Expected host_pinned to be True'



# Generated at 2022-06-23 13:07:31.594779
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True, "strategy should have an attribute _host_pinned set to True"


# Generated at 2022-06-23 13:07:33.783155
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    tqm = None
    strategy_module = StrategyModule(tqm)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:07:36.784790
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''StrategyModule() returns a new instance with correct members'''
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:07:39.802629
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.display import Display
    from ansible.plugins.strategy.host_pinned import StrategyModule
    display = Display()
    tqm = ""
    StrategyModule(tqm)

# Generated at 2022-06-23 13:07:41.968317
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule('tqm')
    assert obj is not None
    assert obj._host_pinned == True

# Generated at 2022-06-23 13:07:42.585943
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:07:44.573833
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MockTqm()
    strategyModule = StrategyModule(tqm)
    assert strategyModule._host_pinned == True

# Generated at 2022-06-23 13:07:46.143586
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   assert StrategyModule(1)._host_pinned 

# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-23 13:07:47.284674
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Testing StrategyModule')
    assert True

# Generated at 2022-06-23 13:07:54.445848
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    host_pinned = ansible.plugins.strategy.host_pinned.StrategyModule(None)
    assert host_pinned._host_pinned

#

# Generated at 2022-06-23 13:07:55.996112
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = mock.MagicMock()
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True


# Generated at 2022-06-23 13:07:57.090849
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 13:07:57.825438
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__

# Generated at 2022-06-23 13:08:00.168120
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm='tqm')
    assert obj._host_pinned
    assert obj._tqm == 'tqm'

# Generated at 2022-06-23 13:08:00.853983
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-23 13:08:03.120205
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Construction test for class StrategyModule...',end='')
    sm = StrategyModule('tqm')
    assert(sm._host_pinned)
    print('Passed.')


# Generated at 2022-06-23 13:08:04.821270
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_obj = StrategyModule("test_val")
    assert test_obj._host_pinned == True

# Generated at 2022-06-23 13:08:08.675161
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class MyTQM():
        def __init__(self):
            self.stats = None
            self.host_pinned = False

        def get_host_list(self):
            return [1,2,3]

    tqm = MyTQM()
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:08:09.510160
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:08:11.303243
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:08:16.828325
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        __import__('ansible.plugins.strategy.host_pinned')
    except Exception as e:
        print(e)
        raise AssertionError('no ansible.plugins.strategy.host_pinned')
    strategy_module = StrategyModule(object())
    assert strategy_module._host_pinned is True


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:08:18.240795
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule(None)
    assert strategyModule._host_pinned == True

# Generated at 2022-06-23 13:08:19.497135
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()

# Generated at 2022-06-23 13:08:22.290223
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FakeTqm()
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned is True


# Mock of class TaskQueueManager: 

# Generated at 2022-06-23 13:08:25.109275
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_plugin = StrategyModule(tqm)
    assert (strategy_plugin._host_pinned == True)

# Generated at 2022-06-23 13:08:26.990712
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:08:28.896026
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestStrategyModule(StrategyModule):
        pass



# Generated at 2022-06-23 13:08:30.461341
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert True

# Generated at 2022-06-23 13:08:34.033796
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Arrange
    tqm = "tqm"

    # Act
    result = StrategyModule(tqm)

    # Assert
    assert result._host_pinned == True

# Generated at 2022-06-23 13:08:37.630542
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # tqm = TaskQueueManager(inventory=InventoryManager(loader=DataLoader()), variable_manager=VariableManager(), loader=DataLoader())
    # strategy = StrategyModule(tqm)
    # return strategy
    pass

# Generated at 2022-06-23 13:08:39.868784
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "Test"
    strategy_obj = StrategyModule(tqm)
    assert strategy_obj.get_host_pinned()

# Generated at 2022-06-23 13:08:41.020321
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule({})
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:08:41.972363
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:08:44.803813
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TaskQueueManager()
    sm = StrategyModule(tqm)
    assert sm._host_pinned

# Generated at 2022-06-23 13:08:46.102581
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm=None)
    assert not module._host_pinned

# Generated at 2022-06-23 13:08:47.609204
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:08:49.798507
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager

    manager = TaskQueueManager(None,None)
    strategy = StrategyModule(manager)

    # Check if variable is initialized correctly
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:08:54.427318
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FakeTQM('host_pinned')
    print(str(StrategyModule(tqm)))
    print('StrategyModule has property _host_pinned: {}'.format(StrategyModule._host_pinned))
    assert StrategyModule._host_pinned, 'StrategyModule has property _host_pinned'


# Generated at 2022-06-23 13:08:55.455748
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:08:56.968265
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Generated at 2022-06-23 13:08:58.656371
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TODO: Improve test
    strategy = StrategyModule()
    assert strategy

# Generated at 2022-06-23 13:09:01.252525
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'test_StrategyModule_tqm'
    result = StrategyModule(tqm)
    assert result.tqm == 'test_StrategyModule_tqm'

# Generated at 2022-06-23 13:09:02.270778
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:09:03.910551
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule('tqm')
    assert s._host_pinned

# Generated at 2022-06-23 13:09:05.964288
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule("tqm")
    assert obj is not None
    assert obj._host_pinned
    assert obj._tqm is not None

# Generated at 2022-06-23 13:09:07.746170
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule()
    x = StrategyModule(tqm)


# Generated at 2022-06-23 13:09:08.604951
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:09:11.143786
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_queue_manager import TaskQueueManager
    s = StrategyModule(TaskQueueManager())
    assert s is not None

# Generated at 2022-06-23 13:09:11.805483
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:09:17.036040
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule.get_tqm()
    stm = StrategyModule(tqm)
    assert stm._host_pinned == True
    assert stm._counters == {}
    assert stm._tqm_unreachable_hosts == {}
    assert stm._inventory is None
    assert stm._display is not None

# Generated at 2022-06-23 13:09:19.240387
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule('localhost')
    assert strategy._host_pinned == True



# Generated at 2022-06-23 13:09:19.838535
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(None), StrategyModule)

# Generated at 2022-06-23 13:09:22.688312
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Test(StrategyModule):
        def __init__(self):
            tqm = None
            super(StrategyModule, self).__init__(tqm)

    Test()

# Generated at 2022-06-23 13:09:28.686753
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module
    assert strategy_module._host_pinned == True


# Load the strategy module as a global variable (used by ansible.cli.playbook)
class_name = 'StrategyModule'
# Note: we want to block the free module to prevent a dependency on the
# strategy plugin in the free module being loaded.
_ = FreeStrategyModule     # noqa

# Generated at 2022-06-23 13:09:30.703356
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_StrategyModule = StrategyModule(tqm)
    return test_StrategyModule


# Generated at 2022-06-23 13:09:38.719133
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class DummyQueue(object):
        def __init__(self):
            self.stats = {}
            self.pool = []
            self.filtered_hosts = {}

    class DummyTQM(object):
        def __init__(self):
            self.hostvars = {}
            self.runners = {}
            self.inventory = None
            self.notified_handlers = {}
            self.failed_hosts = []
            self.queue = DummyQueue()
            self.stats = {}
            self.cache = None
            self.variable_manager = {}
            self.stdout_callback = None
            self.options = None
            self.passwords = []
            self.callback = None

    dtqm = DummyTQM()
    s = StrategyModule(dtqm)
    assert s

# Generated at 2022-06-23 13:09:40.947425
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(tqm=None)
    assert a._host_pinned is True

# Generated at 2022-06-23 13:09:41.762201
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None) != None

# Generated at 2022-06-23 13:09:42.884235
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule()
    assert mod._host_pinned == True

# Generated at 2022-06-23 13:09:45.406539
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule((1,2,3,4,5))
    assert strategy_module._host_pinned == True


__all__ = ['StrategyModule']

# Generated at 2022-06-23 13:09:47.144751
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)


# Generated at 2022-06-23 13:09:48.798299
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-23 13:09:49.710903
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__

# Generated at 2022-06-23 13:09:50.324459
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:09:52.503163
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = "test task queue manager"
    strategy_module = StrategyModule(test_tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:09:53.314509
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:09:55.883443
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    Strategy = StrategyModule()
    assert Strategy is not None
    assert hasattr(Strategy, "_host_pinned")

# Generated at 2022-06-23 13:09:56.591223
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  assert True

# Generated at 2022-06-23 13:10:00.048116
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__.__doc__ == "test doc for StrategyModule.__init__"
    assert StrategyModule.__init__.__name__ == "__init__"

# Generated at 2022-06-23 13:10:01.650369
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:10:03.364890
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm="tqm")

# Generated at 2022-06-23 13:10:13.623134
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.display import Display
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    display = Display()
    display.verbosity = 3
    options = dict()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = Variable

# Generated at 2022-06-23 13:10:15.616377
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   tqm = 0
   s = StrategyModule(tqm)
   assert s._host_pinned == True

# Generated at 2022-06-23 13:10:17.552330
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    Str = StrategyModule(tqm=object)
    assert hasattr(Str,'_host_pinned')

# Generated at 2022-06-23 13:10:18.298821
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule()

# Generated at 2022-06-23 13:10:23.574430
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_strategy_obj = StrategyModule(True)
    assert test_strategy_obj._host_pinned is True
    assert test_strategy_obj.host_state is not None
    assert test_strategy_obj.get_host_state_fields() == ['task_host']
    assert test_strategy_obj.get_task_queue_keys() == ['task_host']


# Generated at 2022-06-23 13:10:25.319879
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TaskQueueManager(None)
    StrategyModule(tqm)

# Generated at 2022-06-23 13:10:29.749734
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm
    assert sm._host_pinned
    assert sm._display.display(msg='strategy.host_pinned: test_StrategyModule succeeded') == None

# Generated at 2022-06-23 13:10:30.328954
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 13:10:36.017471
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    assert type(ansible.plugins.strategy.host_pinned.StrategyModule(None)) == ansible.plugins.strategy.host_pinned.StrategyModule

# make sure the constructor can be invoked
test_StrategyModule()

# Generated at 2022-06-23 13:10:36.749045
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:10:43.253797
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    args = '''
        name: host_pinned
        short_description: Executes tasks on each host without interruption
        description:
        - Task execution is as fast as possible per host in batch as defined by C(serial) (default all).
        version_added: "2.7"
        author: Ansible Core Team
    '''
    doc = {
        'name': 'host_pinned',
        'short_description': 'Executes tasks on each host without interruption',
        'description': 'Task execution is as fast as possible per host in batch as defined by C(serial) (default all).',
        'version_added': '2.7',
        'author': 'Ansible Core Team'
    }
    StrategyModule.__init__(doc)

# Generated at 2022-06-23 13:10:50.499887
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager

    inventory = InventoryManager(loader=None, sources='')
    variable_manager = None
    loader = None
    tqm = TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        passwords=None,
        stdout_callback=None,
    )
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned



# Generated at 2022-06-23 13:10:53.431006
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   tqm = TaskQueueManager(None)
   StrategyModule(tqm)


# Generated at 2022-06-23 13:10:54.840830
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:10:57.991185
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_object = StrategyModule(tqm = 'tqm')
    assert my_object._host_pinned == True

# Generated at 2022-06-23 13:11:01.243761
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  sm = StrategyModule(tqm = None)
  assert(sm != None)
  assert(sm._host_pinned == True)

# Generated at 2022-06-23 13:11:02.714788
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    st = StrategyModule(None)


# Generated at 2022-06-23 13:11:04.241437
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned


# Generated at 2022-06-23 13:11:08.100814
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "test"
    test_object = StrategyModule(tqm)
    assert isinstance(test_object, StrategyModule)
    assert test_object._host_pinned == True

# Generated at 2022-06-23 13:11:09.414298
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    assert StrategyModule

# Generated at 2022-06-23 13:11:10.648469
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule(None)
    assert x._host_pinned == True

# Generated at 2022-06-23 13:11:12.720921
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ''' Test StrategyModule class constructor '''

    tqm = object()
    StrategyModule(tqm)



# Generated at 2022-06-23 13:11:13.808263
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert strategy_instance is not None



# Generated at 2022-06-23 13:11:16.337020
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule(tqm)
    assert tqm is not None
    assert tqm._host_pinned is True


# Generated at 2022-06-23 13:11:17.542823
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
        global display
        assert display.__class__.__name__ == 'Display'

# Generated at 2022-06-23 13:11:18.407239
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:11:24.828992
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # tqm = TaskQueueManager
    # Create an empty tqm object
    tqm = None
    # Returns an instance of class FreeStrategyModule
    # with tqm = None
    s = FreeStrategyModule(tqm)
    # Expected output
    # <ansible.plugins.strategy.free.StrategyModule object at 0x7f7e52f6e8d0>
    print(s)


# Generated at 2022-06-23 13:11:25.892110
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:11:27.181204
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None


# Generated at 2022-06-23 13:11:29.113741
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    foo = StrategyModule(None)
    assert foo._host_pinned

# Generated at 2022-06-23 13:11:31.529657
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    free_strategy_module = StrategyModule(tqm)
    assert free_strategy_module._host_pinned

# Generated at 2022-06-23 13:11:36.631493
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test_StrategyModule():")
    sm = StrategyModule(None)
    assert sm._host_pinned == True, "StrategyModule._host_pinned should be True, got %s" % repr(sm._host_pinned)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:11:39.062605
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned == True


# Generated at 2022-06-23 13:11:41.303907
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    job = StrategyModule(tqm='')
    assert job._host_pinned == True

# Generated at 2022-06-23 13:11:43.916238
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=1)
    assert obj._host_pinned == True

# Generated at 2022-06-23 13:11:46.384897
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:11:50.686352
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  from ansible.plugins.strategy import host_pinned
  strategy = StrategyModule(tqm)
  assert strategy is not None
  assert strategy._host_pinned is True

# Generated at 2022-06-23 13:11:51.882343
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule, object)

# Generated at 2022-06-23 13:11:54.045215
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module._host_pinned is True

# Generated at 2022-06-23 13:12:02.724185
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=DataLoader()),
        variable_manager=None,
        loader=DataLoader(),
        options=None,
        passwords=None,
        stdout_callback=None,
    )
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned is True    # pylint: disable=protected-access