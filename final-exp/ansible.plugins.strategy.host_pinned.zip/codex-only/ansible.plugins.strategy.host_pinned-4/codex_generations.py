

# Generated at 2022-06-23 13:02:01.179759
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule({})
    assert sm._host_pinned is True

# Generated at 2022-06-23 13:02:03.448261
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    t = StrategyModule('Test')
    assert t._host_pinned == True

# Generated at 2022-06-23 13:02:04.757030
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Generated at 2022-06-23 13:02:10.414391
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test_StrategyModule: Testing StrategyModule constructor")
    SM_obj = StrategyModule(None)
    if SM_obj._host_pinned != True:
        print("test_StrategyModule: StrategyModule constructor FAILED")
        raise Exception("test_StrategyModule: StrategyModule constructor FAILED")
    print("test_StrategyModule: StrategyModule constructor PASSED")
# test_StrategyModule ends

# Generated at 2022-06-23 13:02:14.546537
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    mock_tqm = "mock_tqm"
    mock_tqm.stats = dict()
    mock_tqm.pattern = dict()
    sm = StrategyModule(mock_tqm)

    assert sm._display is not None

# Generated at 2022-06-23 13:02:18.342987
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    print(sm._host_pinned)
    assert(True)

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:02:19.277952
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:02:25.429399
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = type('tqm', (object,), {'shared_loader_obj': None,
                                   '_workers': 1,
                                   '_final_q': None,
                                   '_new_stdout_handler': None})()
    obj = StrategyModule(tqm)
    assert obj._host_pinned == True

# Generated at 2022-06-23 13:02:26.323350
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-23 13:02:27.572012
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule()
    assert a._host_pinned == True

# Generated at 2022-06-23 13:02:30.182876
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sModule = StrategyModule(tqm)
    assert sModule._host_pinned == True


# Generated at 2022-06-23 13:02:32.341088
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = StrategyModule(tqm=None)
    assert host._host_pinned is True

# Generated at 2022-06-23 13:02:33.958584
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from mock import MagicMock
    tqm = MagicMock()
    StrategyModule(tqm)

# Generated at 2022-06-23 13:02:35.471884
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module._host_pinned

# Generated at 2022-06-23 13:02:37.489420
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    t = StrategyModule
    # check if t is of type object
    assert isinstance(t, object)

# Generated at 2022-06-23 13:02:41.088804
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyDirectory
    from ansible.executor.task_queue_manager import TaskQueueManager

    sd = StrategyDirectory()
    strategy = sd.get_strategy('host_pinned')
    assert strategy == StrategyModule
    tqm = TaskQueueManager(None, None, None, None, None, strategy, None, None)
    assert tqm.strategy._host_pinned

# Generated at 2022-06-23 13:02:41.666149
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule("test")

# Generated at 2022-06-23 13:02:42.926550
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    myInstance = StrategyModule()

# Generated at 2022-06-23 13:02:44.138436
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(1)
    return


# Generated at 2022-06-23 13:02:49.068710
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == FreeStrategyModule.__doc__
    assert StrategyModule.__init__.__doc__ == FreeStrategyModule.__init__.__doc__
    assert StrategyModule._host_pinned == True



# Generated at 2022-06-23 13:02:50.694854
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	a = StrategyModule(1)
	assert a.name == 'host_pinned'

# Generated at 2022-06-23 13:02:58.799695
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    task = {}
    queue = {}
    hosts = {'all': {'hostname': 'alldevices'}}
    variable_manager = {}
    loader = {}

# Generated at 2022-06-23 13:03:00.127831
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)
    assert True

# Generated at 2022-06-23 13:03:01.327532
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned = StrategyModule()

# Generated at 2022-06-23 13:03:08.403703
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global display
    display = Display()
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy import StrategyModule as new_super
    from ansible.plugins.strategy.free import StrategyModule as old_super
    tqm = None
    sm = StrategyModule(tqm)
    str(sm)
    assert isinstance(sm, new_super)
    assert isinstance(sm, old_super)

# Generated at 2022-06-23 13:03:18.576273
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        import unittest
    except ImportError:
        print('unittest module not found. skipping tests')
        return

    class TestStrategyModule(unittest.TestCase):

        def test_constructor_without_tqm_argument(self):
            try:
                StrategyModule()
            except Exception as e:
                self.assertEqual(type(e), TypeError)

        def test_constructor_with_tqm_argument(self):
            try:
                StrategyModule(object())
            except Exception as e:
                self.assertEqual(type(e), TypeError)


# Generated at 2022-06-23 13:03:25.144987
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test construct
    testStrategyModule = StrategyModule('tqm')
    assert 'tqm' == testStrategyModule._tqm
    assert 'ansible.plugins.strategy.free.StrategyModule' == testStrategyModule._original_path
    assert  True == testStrategyModule._host_pinned
    assert  False == testStrategyModule._needs_static_workers

    # Test get_hosts_remaining
    # Test run()

# Generated at 2022-06-23 13:03:28.219262
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy
    import ansible.plugins.strategy.host_pinned
    assert ansible.plugins.strategy.host_pinned.StrategyModule is StrategyModule

# Generated at 2022-06-23 13:03:30.877971
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm)
    assert obj._host_pinned == True


# Generated at 2022-06-23 13:03:31.811472
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('tqm')
    assert(strategy_module._host_pinned)

# Generated at 2022-06-23 13:03:37.900213
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import Mock
    tqm = Mock()
    strategy= StrategyModule(tqm)   # Test with tqm as argument

    assert strategy._host_pinned == True
    return


# Executes the code when run directly (not included in unit test)
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:03:40.826185
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    def new_class(name, parents, dct):
        return type(name, parents, dct)

    tqm = new_class("dummy", (), {})
    strategy_module = StrategyModule(tqm)
    assert strategy_module != None

# Generated at 2022-06-23 13:03:50.751904
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TaskQueueManager:
        def __init__(self, inventory):
            self.inventory = inventory
            self.default_vars = []
            self.extra_vars = {}
            self.options = {}
            self.variable_manager = []

    class InventoryManager:
        def __init__(self):
            self.inventory = None

    class HostGroup:
        def __init__(self, name):
            self.name = name

    class Host:
        def __init__(self, hostname):
            self.hostname = hostname

    class LocalGroup:
        def get_hosts(self):
            return ['host1']

    class HostGroup:
        def __init__(self, name):
            self.name = name
            self._hosts = []


# Generated at 2022-06-23 13:03:53.688580
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = True
    strategy = StrategyModule(tqm)

    assert strategy._host_pinned == True


# Generated at 2022-06-23 13:03:56.734358
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == 'Host_pinned strategy plugin.\n    This is the default.'
# Test end

# Generated at 2022-06-23 13:03:57.814961
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule("this is tqm")

# Generated at 2022-06-23 13:04:00.106776
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test_StrategyModule")
    tqm = None
    obj = StrategyModule(tqm)


# Generated at 2022-06-23 13:04:05.176295
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.utils.boolean import boolean
    tqm = None
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True
    assert boolean(sm._batch_size)
    assert sm._batch_size == 10

# Generated at 2022-06-23 13:04:12.526013
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  import unittest
  import ansible.plugins.strategy.host_pinned as host_pinned
  
  class TestStrategyModule(unittest.TestCase):
    def setUp(self):
      pass

    def tearDown(self):
      pass

    def test_constructor(self):
      self.assertIsInstance(host_pinned.StrategyModule(None), host_pinned.StrategyModule)

  suite = unittest.TestLoader().loadTestsFromTestCase(TestStrategyModule)
  unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-23 13:04:13.615690
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 13:04:14.945264
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert s._host_pinned

# Generated at 2022-06-23 13:04:17.208852
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = StrategyModule(tqm)
    assert tqm._host_pinned == True
    return True

# Generated at 2022-06-23 13:04:17.823965
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:04:19.213568
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    with pytest.raises(SystemExit):
        StrategyModule(None)

# Generated at 2022-06-23 13:04:20.148315
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_StrategyModule = StrategyModule()

# Generated at 2022-06-23 13:04:22.405533
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """This is the constructor of class StrategyModule"""
    tqm = "abhishek"
    strategy_module = StrategyModule(tqm)

# Generated at 2022-06-23 13:04:23.854961
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_host_pinned = True
    strategy_module_init = StrategyModule(test_host_pinned)
    assert test_host_pinned == strategy_module_init._host_pinned

# Generated at 2022-06-23 13:04:35.873718
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_queue_manager import TaskQueueManager
    from ansible.playbook import Playbook
    from ansible.executor.task_queue_manager import TaskQueueManager as ExecutorTaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    tqm = TaskQueueManager()
    pbex = PlaybookExecutor(playbooks=[], inventory=None, variable_manager=None, loader=None, options=None, passwords=None)
    strategy = StrategyModule(tqm)
    assert not strategy.tqm is None
    assert isinstance(strategy.tqm, ExecutorTaskQueueManager)
    assert isinstance(strategy.display, Display)
    assert not strategy.tqm is None
    assert strategy._host_pinned is not None

# Generated at 2022-06-23 13:04:38.980302
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

if __name__ == '__main__':
    import sys
    import pytest
    pytest.main(sys.argv)

# Generated at 2022-06-23 13:04:42.570013
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TaskQueueManager:
        class Play():
            def __init__(self):
                self.serial = 9

        def __init__(self):
            self.current_play = self.Play()

    TaskQueueManager = TaskQueueManager()
    strategy_module = StrategyModule(TaskQueueManager)

    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:04:45.533940
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    print(strategy.__doc__)
    print(strategy._host_pinned)

if __name__ == "__main__":
    test_StrategyModule()

# Generated at 2022-06-23 13:04:51.684904
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_tqm = 'my_tqm'
    strategy_module = StrategyModule(my_tqm)
    assert strategy_module._tqm == my_tqm
    assert strategy_module._display == display
    assert isinstance(strategy_module._iterator, FreeStrategyModule._iterator) # FreeStrategyModule._iterator is an instance of type <type 'super'>
    assert strategy_module._host_pinned

# Generated at 2022-06-23 13:04:56.075337
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Testing constructor of class StrategyModule')
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy is not None
    assert strategy.get_name() == 'host_pinned'
    assert strategy.get_host_pinned() == True
    print('Done')


# Generated at 2022-06-23 13:04:57.120576
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)._host_pinned

# Generated at 2022-06-23 13:05:00.545577
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # This test is for the constructor

    # Constructor of class
    mod = StrategyModule(tqm="tqm")
    # Assert instance
    assert mod._host_pinned == True

# Generated at 2022-06-23 13:05:03.685491
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mybool = False
    try:
        from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
        FreeStrategyModule(mybool)
    except:
        mybool = True
    assert mybool == False

# Generated at 2022-06-23 13:05:04.533507
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-23 13:05:08.716841
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.logger import configure_logging

    tqm = TaskQueueManager(
        inventory=InventoryManager(loader=DataLoader(), sources=['localhost']),
        variable_manager=VariableManager(loader=DataLoader()),
        loader=DataLoader(),
        stdout_callback="null",
    )
    sm = StrategyModule(tqm)
    print(sm._host_pinned)
    assert sm._host_pinned
# END Unit test for constructor of class StrategyModule

# Generated at 2022-06-23 13:05:10.234284
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TQM
    StrategyModule(tqm)

# Generated at 2022-06-23 13:05:11.960572
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule()
    assert module._host_pinned == True

# Generated at 2022-06-23 13:05:21.228552
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        import queue
    except ImportError:
        import Queue as queue

    # Mocking of class QueueManager
    class QueueManager():
        def __init__(self, inventory, variable_manager, loader, options, passwords, stdout_callback=None):
            self._inventory = inventory
            self._variable_manager = variable_manager
            self._loader = loader
            self._options = options
            self._passwords = passwords
            self._stdout_callback = stdout_callback
            self._pending_results = 0
            self._workers_count = 5
            self._final_q = queue.Queue()
            self._failed_hosts = {}
            self._unreachable_hosts = {}
            self._stats = None
            self._callbacks = []

    # Mocking of class AnsibleOptions

# Generated at 2022-06-23 13:05:21.903820
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:05:27.380899
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    strategy_module = StrategyModule(tqm)
    assert hasattr(strategy_module, '_host_pinned')
    assert strategy_module._host_pinned is not None
    assert strategy_module._host_pinned == True
    assert strategy_module._tqm == tqm
    assert hasattr(strategy_module, '_display')
    assert strategy_module._display is not None
    assert strategy_module._display == display

# Generated at 2022-06-23 13:05:29.666694
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == '''\
    This is the "host_pinned" strategy, which runs one host at a time until all hosts are complete.
    '''

# Generated at 2022-06-23 13:05:31.889514
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global display
    display = Display()

    assert  callable(StrategyModule)
    assert'strategy.host_pinned'==StrategyModule.__module__



# Generated at 2022-06-23 13:05:37.574517
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.strategy.host_pinned import StrategyModule as Host_pinnedModule
    from ansible.plugins.callback import CallbackBase
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    test_name = "test_StrategyModule"

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    loader

# Generated at 2022-06-23 13:05:40.423477
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module.__class__.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:05:41.042139
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:05:43.739122
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)
    assert hasattr(StrategyModule, '_host_pinned')

# Generated at 2022-06-23 13:05:45.539332
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()
    assert type(s) == StrategyModule, "Failed to create StrategyModule."
    assert s._host_pinned == True, "Failed to set _host_pinned."

# Generated at 2022-06-23 13:05:46.070992
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:05:49.544040
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # test StrategyModule initialization
    pass

if __name__ == '__main__':
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-23 13:05:50.159061
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule()

# Generated at 2022-06-23 13:05:50.756212
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:05:55.642549
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = object()
    tqm = object()
    strategy_module = StrategyModule(tqm)
    assert type(strategy_module) == StrategyModule
    assert strategy_module._tqm == tqm
    assert strategy_module._host_pinned == True
test_StrategyModule()

# Generated at 2022-06-23 13:05:58.604387
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = True
    print("Test constructor of class StrategyModule")
    strategy_module = StrategyModule(tqm)
    assert(strategy_module._host_pinned == True)

# Generated at 2022-06-23 13:06:01.242223
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule.__new__(StrategyModule)
    assert module._host_pinned == True


# Generated at 2022-06-23 13:06:01.850948
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:06:04.974932
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    Unit test for the constructor of the class StrategyModule.
    '''
    strategy_module = StrategyModule(None)
    assert strategy_module is not None

# Generated at 2022-06-23 13:06:07.694751
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(tqm = None)
    assert s._host_pinned == True


# Generated at 2022-06-23 13:06:09.956778
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('tqm')
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:06:20.406631
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    class tqm():
        def __init__(self):
            self.cur_tqm_count = 0
            self.play_context = dict(aggregate=None, serial=None)
            self.inventory = dict(basedir=None, host_list=[], cache=dict(expired=False, _play_hosts=[]))
            self.host_list = []
            self.hostvars = dict()
            self.stats = dict(dark=dict(), processed=dict(), fail_hosts=dict(), contacted=dict(), failed=dict(), ok=dict(), skipped=dict(), unreachable=dict())

# Generated at 2022-06-23 13:06:22.490498
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    strategyModule = StrategyModule(tqm)
    assert strategyModule._host_pinned

# Generated at 2022-06-23 13:06:24.246396
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-23 13:06:25.277452
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)


# Generated at 2022-06-23 13:06:36.768958
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from collections import namedtuple
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-23 13:06:37.840344
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm={})
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:06:49.335156
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    def get_host_result(host):
        return {'contacted': {}, 'dark': {}}
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host_list = [Host(name='localhost', port=22)]
    group = Group(name='ungrouped')
    group.add_host(host_list[0])
    inventory.add_group(group)
    inventory

# Generated at 2022-06-23 13:06:50.757021
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned

# Generated at 2022-06-23 13:06:53.212084
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # fixme:
    # tqm = Mock()
    # StrategyModule(tqm)
    assert True

# Generated at 2022-06-23 13:06:54.649697
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned is True

# Generated at 2022-06-23 13:06:56.075476
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    assert_equals(StrategyModule.__name__, 'StrategyModule')

# Generated at 2022-06-23 13:06:56.668053
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()

# Generated at 2022-06-23 13:06:59.607716
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert s._host_pinned == True

# Generated at 2022-06-23 13:07:01.484092
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    strategy_obj = StrategyModule(TaskQueueManager())
    assert ( strategy_obj._host_pinned )

# Generated at 2022-06-23 13:07:05.429029
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    strategy_object = ansible.plugins.strategy.host_pinned.StrategyModule(tqm = None)
    assert True

# Generated at 2022-06-23 13:07:06.543616
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:07:17.752950
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.inventory.host import Host

# Generated at 2022-06-23 13:07:19.797896
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule("tqm")
    assert hasattr(strategy, '_host_pinned')
    assert strategy._host_pinned is True

# Generated at 2022-06-23 13:07:20.237741
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:07:21.504668
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm)
    assert strategy != None

# Generated at 2022-06-23 13:07:22.745989
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned is True

# Generated at 2022-06-23 13:07:27.846475
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Instantiate StrategyModule with valid arguments.
    tqm = 'test_tqm'
    strategy_module = StrategyModule(tqm)
    # Check if the object is instance of class 'StrategyModule'
    assert isinstance(strategy_module, StrategyModule)


# Generated at 2022-06-23 13:07:29.727805
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# This test executes the StrategyModule constructor with a test queue manager.
# No exception is raised.

# Generated at 2022-06-23 13:07:30.884220
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)

# Generated at 2022-06-23 13:07:32.447713
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)

# vi: expandtab ts=4 sw=4

# Generated at 2022-06-23 13:07:33.687234
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)

    StrategyModule.__init__()


# Generated at 2022-06-23 13:07:35.505885
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = StrategyModule()
    assert tqm._host_pinned is True

# Generated at 2022-06-23 13:07:37.658612
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = unittest.mock.MagicMock()
    StrategyModule(tqm)
    # Pending verification of patch in setuptools

# Generated at 2022-06-23 13:07:38.663064
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule(None)
    assert mod._host_pinned == True

# Generated at 2022-06-23 13:07:42.479663
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    # display = Display()
    tqm = None
    strategy_module = StrategyModule(tqm)
    # display.display(strategy_module._host_pinned)
    assert strategy_module._host_pinned

# Generated at 2022-06-23 13:07:45.579835
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ Test if StrategyModule constructor works as expected
    """
    tqm = None
    stm = StrategyModule(tqm)
    assert stm._host_pinned is True

# Generated at 2022-06-23 13:07:47.021335
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned

# Generated at 2022-06-23 13:07:47.977341
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 13:07:51.312581
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test for constructor of class StrategyModule")
    # initial entry of tqm is not important as it is not used in the constructor
    test_object = StrategyModule(None)
    assert test_object._host_pinned == True

# Generated at 2022-06-23 13:07:54.298924
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # setUp
    tqm = True
    # test
    strategy = StrategyModule(tqm)
    # Asserts
    assert(strategy._host_pinned)

# Generated at 2022-06-23 13:07:56.290470
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    aa = StrategyModule()
    assert isinstance(aa,StrategyModule)

test_StrategyModule()

# Generated at 2022-06-23 13:08:00.269300
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    args = None
    import ansible.plugins.strategy.host_pinned as host_pinned

    tqm = host_pinned.StrategyModule(args)
    assert tqm is not None
    assert isinstance(tqm, host_pinned.StrategyModule)

# Generated at 2022-06-23 13:08:00.908334
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-23 13:08:01.504468
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:08:02.296248
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy is not None

# Generated at 2022-06-23 13:08:07.928976
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_play = {}
    my_play['name'] = "dummy"
    my_play['hosts'] = "localhost,"
    my_play['roles'] = ""
    my_play['tasks'] = ""
    my_play['vars'] = ""
    play = dict(my_play=my_play)
    tqm = {}
    s_m = StrategyModule(tqm)
    assert s_m.get_hosts_left_to_run() is None

# Generated at 2022-06-23 13:08:11.194887
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MagicMock()
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True



# Generated at 2022-06-23 13:08:13.188117
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule(tqm=None)
    assert a
    assert a._host_pinned


# Generated at 2022-06-23 13:08:18.412308
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-23 13:08:19.996262
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(tqm = None), StrategyModule)

# Generated at 2022-06-23 13:08:21.696295
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Test to see if we can create an instance our class
    strategy_module = StrategyModule()
    assert strategy_module is not None

# Generated at 2022-06-23 13:08:22.702220
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule == StrategyModule

# Generated at 2022-06-23 13:08:25.063969
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sModule = StrategyModule(tqm)
    assert sModule is not None

# Generated at 2022-06-23 13:08:25.678559
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:08:26.803687
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:08:33.391612
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "tqm"
    strategy = StrategyModule(tqm)
    assert strategy._display is None
    assert strategy._tqm is "tqm"
    assert strategy._batch_size is 0
    assert strategy._inventory is None
    assert strategy._variable_manager is None
    assert strategy._loader is None
    assert strategy._stdout_callback is None
    assert strategy._display.verbosity is 0
    assert strategy._host_pinned is True



# Generated at 2022-06-23 13:08:43.095382
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.errors import AnsibleError, AnsibleOptionsError
    from ansible import constants as C
    from ansible.module_utils._text import to_bytes
    from ansible.plugins.strategy import StrategyModule
    from ansible.utils.display import Display
    from ansible.utils.sentinel import Sentinel
    tqm = Sentinel()
    #self = ansible.plugins.strategy.host_pinned.StrategyModule(tqm)
    #assert isinstance(self, ansible.plugins.strategy.host_pinned.StrategyModule)
    #self = ansible.plugins.strategy.host_pinned.StrategyModule(tqm)
    #assert isinstance(self, ansible.plugins.strategy.host_pinned.StrategyModule)
    #self = ansible.plugins.strategy

# Generated at 2022-06-23 13:08:44.678397
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 13:08:47.285487
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    bogus_tqm = ""
    strag_obj = StrategyModule(bogus_tqm)
    assert strag_obj._host_pinned == True

# Generated at 2022-06-23 13:08:48.595472
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule('tqm')
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:08:49.593546
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-23 13:08:53.435311
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    s = ansible.plugins.strategy.host_pinned.StrategyModule(None)
    assert isinstance(s, ansible.plugins.strategy.host_pinned.StrategyModule)


# Generated at 2022-06-23 13:08:56.177229
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:08:56.907951
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:08:58.972477
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
        strategy_module = StrategyModule(tqm=[])
        assert(strategy_module._host_pinned)

# Generated at 2022-06-23 13:09:07.154760
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule

    strategy_module = StrategyModule(tqm=None)

    assert strategy_module._host_pinned is True
    assert strategy_module.description is not None
    assert strategy_module.get_host_list is not None
    assert strategy_module.hosts is not None
    assert strategy_module.run_handlers_on_host is not None
    assert strategy_module.run_tasks_on_host is not None
    assert strategy_module.run_tasks is not None
    assert strategy_module.wait_on_pending_results is not None

# Generated at 2022-06-23 13:09:08.167547
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(1)



# Generated at 2022-06-23 13:09:08.899443
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:09:10.952020
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy is not None


# Generated at 2022-06-23 13:09:13.686374
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	tqm = FreeStrategyModule(tqm)
	assert StrategyModule(tqm) is not None, 'StrategyModule constructor is returning None'

# Generated at 2022-06-23 13:09:14.520900
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm = None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:09:19.382349
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm)
    assert type(module) == StrategyModule
    assert type(module._display) == Display

if __name__ == '__main__':
    # Unit test
    import sys
    sys.path.append('/Users/karlcow/scratch/git/ansible_test')
    from mock_tqm import MockTQM
    test_StrategyModule()

    print('Unit test completed successfully')

# Generated at 2022-06-23 13:09:20.084584
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__=="StrategyModule"

# Generated at 2022-06-23 13:09:22.054699
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned is True

# Generated at 2022-06-23 13:09:26.531500
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.display import Display
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    display = Display()
    tqm = TaskQueueManager(display, None, None)
    StrategyModule(tqm)

# Generated at 2022-06-23 13:09:30.530761
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module is not None
    assert strategy_module._host_pinned is True

# Generated at 2022-06-23 13:09:35.805662
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Tqm():
        def __init__(self):
            self.hostvars = {}
            self.inventory = {}
            self.loader = {}
            self.variable_manager = {}
            self.options = {}
            self.settings = {}
    tqm = Tqm()
    strategy_instance = StrategyModule(tqm)
    if strategy_instance._host_pinned:
        print ('host_pinned is true')

# Generated at 2022-06-23 13:09:37.857116
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = StrategyModule('tqm')
    assert tqm._host_pinned

# Generated at 2022-06-23 13:09:38.509681
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:09:40.836627
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Instantiate a class 'StrategyModule' object
    # TODO:
    # 1. Check if the constructor is called without any arguments
    assert True

# Generated at 2022-06-23 13:09:41.993589
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:09:43.116852
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule


# Generated at 2022-06-23 13:09:46.696113
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module._host_pinned == True
    assert strategy_module._factor == 1
    assert strategy_module._batch_size == None
    assert strategy_module._play_has_tasks == False

# Generated at 2022-06-23 13:09:49.096248
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm=None)
    assert sm._host_pinned is True

# Generated at 2022-06-23 13:09:49.954356
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:09:51.948156
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    t = StrategyModule([])
    assert t._host_pinned == True

# Generated at 2022-06-23 13:09:53.546253
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("I am here")

# Generated at 2022-06-23 13:09:57.069772
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = TQM()
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True
    print("StrategyModule constructor test passed!")

# Module for the host_pinned strategy

# Generated at 2022-06-23 13:09:58.376892
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)



# Generated at 2022-06-23 13:09:59.686942
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)._host_pinned == True

# Generated at 2022-06-23 13:10:02.403930
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    args = {
        'tqm': 10
    }
    obj = StrategyModule(**args)
    assert obj._host_pinned == True

# Generated at 2022-06-23 13:10:05.213705
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    assert StrategyModule


# Make sure the constructor can execute without throwing an exception

# Generated at 2022-06-23 13:10:08.356656
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    obj = ansible.plugins.strategy.host_pinned.StrategyModule("test")
    assert hasattr(obj, "_host_pinned")

# Generated at 2022-06-23 13:10:14.374315
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == ''' Executes tasks on each host without interruption '''
    assert StrategyModule.__init__.__doc__ == ''' '''
    assert StrategyModule.__init__.__dict__ == dict()
    assert StrategyModule.__init__.__code__.co_varnames == ('self', 'tqm')
    assert StrategyModule.__init__.__code__.co_argcount == 2
    assert StrategyModule.__init__.__defaults__ == (None,)
    assert StrategyModule.__init__.__kwdefaults__ == None
    assert StrategyModule.__init__.__annotations__ == {}
    assert StrategyModule.__init__.__globals__ == globals()
    assert StrategyModule.__init__.__closure__ == None


# Generated at 2022-06-23 13:10:15.103399
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule()

# Generated at 2022-06-23 13:10:16.673249
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert True


# Generated at 2022-06-23 13:10:18.709423
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module is not None


# Generated at 2022-06-23 13:10:22.173443
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.utils.queue import Queue

    q = Queue('test')

    # cannot instantiate base class
    with pytest.raises(TypeError):
        s = StrategyModule(q)

# Generated at 2022-06-23 13:10:23.472173
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(1)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:10:25.086156
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('') is not None


# Generated at 2022-06-23 13:10:25.812303
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:10:28.480657
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule()")
    w = StrategyModule(tqm = None)
    assert w._host_pinned

# Generated at 2022-06-23 13:10:29.952167
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  assert callable(StrategyModule)

# Generated at 2022-06-23 13:10:38.867116
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import ansible.plugins.strategy.host_pinned
    from ansible.utils.display import Display
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule

    display = Display()

    class TestStrategyModule(unittest.TestCase):

        def test_StrategyModule(self):
            strategy_module = StrategyModule(tqm)
            
            self.assertIsInstance(strategy_module, StrategyModule)
            self.assertIsInstance(strategy_module, FreeStrategyModule)
            
    unittest.main()

# Generated at 2022-06-23 13:10:41.844299
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    strategy = ansible.plugins.strategy.host_pinned.StrategyModule(None)
    assert strategy._host_pinned

# Generated at 2022-06-23 13:10:43.761213
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   t = FreeStrategyModule()
   assert t is not None

# Generated at 2022-06-23 13:10:45.126555
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule('tqm')
    assert (sm._host_pinned is True)

# Generated at 2022-06-23 13:10:47.226284
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Generated at 2022-06-23 13:10:50.294368
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    strategy = StrategyModule(tqm)

    assert(strategy._host_pinned == True)
    assert(strategy._tqm == tqm)
    assert(strategy.get_name() == 'host_pinned')
    assert(strategy.get_host_list() == [])

# Generated at 2022-06-23 13:10:55.880938
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import host_pinned
    class TestTQM():
        def __init__(self):
            self.host_pinned = True

    tqm = TestTQM()
    hpm = host_pinned.StrategyModule(tqm)
    assert hpm._host_pinned

# Generated at 2022-06-23 13:10:57.746143
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule()


# Generated at 2022-06-23 13:11:00.752879
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module._host_pinned

# Generated at 2022-06-23 13:11:08.163061
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import host_pinned
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    objtask = Task()
    obj = TaskQueueManager(None, None, None, None, None)
    obj.playbook = True
    obj_module = host_pinned.StrategyModule(obj)
    assert obj_module.get_hosts('a') == []

# Generated at 2022-06-23 13:11:09.251437
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule(1))

# Generated at 2022-06-23 13:11:10.480168
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule(1)
    assert mod._host_pinned is True

# Generated at 2022-06-23 13:11:14.078447
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    TASK_QUEUE_MANAGER = 'tqm'
    obj = StrategyModule(TASK_QUEUE_MANAGER)
    assert isinstance(obj, StrategyModule)
    assert obj._host_pinned == True

# Generated at 2022-06-23 13:11:15.111143
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:11:16.149630
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 1 == 1, "Failed"

# Generated at 2022-06-23 13:11:16.728041
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:11:17.626470
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print(StrategyModule)


# Generated at 2022-06-23 13:11:21.724205
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test constructor of class StrategyModule
    strategyModule = StrategyModule(None)
    assert isinstance(strategyModule, StrategyModule)
    assert isinstance(strategyModule, FreeStrategyModule)

# Generated at 2022-06-23 13:11:23.444350
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test = StrategyModule('test')
    assert test._host_pinned is True


# Generated at 2022-06-23 13:11:24.124223
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:11:25.714963
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(object()).__class__ == StrategyModule

# Generated at 2022-06-23 13:11:26.930076
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule({}), StrategyModule)

# Generated at 2022-06-23 13:11:29.376643
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm='')
    assert strategy_module._host_pinned is True

# Generated at 2022-06-23 13:11:31.346377
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    obj = StrategyModule(tqm)
    assert (obj._host_pinned == True)

# Generated at 2022-06-23 13:11:34.423876
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FakeTqm()
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned



# Generated at 2022-06-23 13:11:36.441487
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule("tqm")
    assert mod._host_pinned == True


# Generated at 2022-06-23 13:11:36.937373
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:11:37.627790
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:11:38.540917
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:11:39.246682
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()

# Generated at 2022-06-23 13:11:43.848031
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  display_object = Display()
  fake_tqm = {'stats': {}}
  strategy_module = StrategyModule(fake_tqm)
  assert strategy_module
  assert strategy_module._host_pinned is True

# Generated at 2022-06-23 13:11:48.138241
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption\n'''
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'

# Generated at 2022-06-23 13:11:49.921386
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(hasattr(StrategyModule, '_host_pinned'))

# Generated at 2022-06-23 13:11:51.626406
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-23 13:11:52.352347
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:12:03.847780
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    class test_tqm:
        def __init__(self):
            self.callback_loader = "callback_loader"
            self.stats = "stats"
            self.inventory = "inventory"
            self.variable_manager = "variable_manager"
            self.loader = "loader"
            self.shared_loader_obj = "shared_loader_obj"
            self.host_dones = ["host_dones"]
            self.host_dones_lock = "host_dones_lock"
            self.dep_subset = "dep_subset"
            self.dep_subset_lock = "dep_subset_lock"
            self.task_queue = "task_queue"
            self.task_queue_lock = "task_queue_lock"
            self.unreachable_