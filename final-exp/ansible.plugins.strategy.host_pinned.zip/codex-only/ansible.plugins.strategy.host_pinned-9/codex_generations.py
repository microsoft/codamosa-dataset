

# Generated at 2022-06-23 13:02:04.889339
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class Test():
        _host_pinned = True
        name = 'strategy-name'
    strategy_module = StrategyModule(Test())


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:02:05.572943
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()

# Generated at 2022-06-23 13:02:06.077285
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:02:06.817653
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:02:09.264307
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm='tqm')

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:02:10.611063
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:02:18.675792
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    import sys
    import os
    import mock
    sys.modules['ansible'] = mock.Mock()
    sys.modules['ansible.plugins'] = mock.Mock()
    sys.modules['ansible.plugins.strategy'] = mock.Mock()
    sys.modules['ansible.plugins.strategy.free'] = mock.Mock()
    sys.modules['ansible.plugins.strategy.free.StrategyModule'] = mock.Mock()
    sys.modules['ansible.plugins.strategy.free.StrategyModule']._host_pinned = mock.Mock()

# Generated at 2022-06-23 13:02:24.916886
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule

    class MockTQM(object):
        def __init__(self):
            self.hostvars = {}

    strategy_module = StrategyModule(MockTQM())
    assert strategy_module is not None
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:02:25.724140
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:02:28.721482
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm = "tqm")
    assert strategy_module._host_pinned
    assert strategy_module._batch_size == 1

# Generated at 2022-06-23 13:02:31.312858
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module_object = StrategyModule(tqm)
    assert strategy_module_object
    assert strategy_module_object._host_pinned == True

# Generated at 2022-06-23 13:02:34.263041
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy is not None

# Generated at 2022-06-23 13:02:38.900051
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy.free import StrategyModule
    test_strategy = StrategyModule(TaskQueueManager())
    assert type(test_strategy) == StrategyModule
    assert type(test_strategy._host_pinned) == bool


# Generated at 2022-06-23 13:02:44.584711
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Create a new instance of FreeStrategyModule and check that attribute host_pinned is set to True
    tqm = FreeStrategyModule(tqm)
    if tqm._host_pinned is True:
        pass
        #print("unit test: constructor: succeeds")
    else:
        print("unit test: constructor: fails")

# Generated at 2022-06-23 13:02:48.796562
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm._host_pinned == True, "Only 1 host should be processed at a time"
    assert sm._play_context is None, "Play context should be null"

# Generated at 2022-06-23 13:02:50.490207
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()
    assert hasattr(obj, '_host_pinned')

# Generated at 2022-06-23 13:02:52.759558
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    st = StrategyModule(tqm = None)
    assert st._host_pinned == True

# Generated at 2022-06-23 13:02:53.977116
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-23 13:02:57.121988
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    hosts = {'test' : {}}
    tqm = DummyTQM(hosts)
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True


# Generated at 2022-06-23 13:02:59.105156
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-23 13:03:01.401642
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    teststrategy = StrategyModule('tqm')
    assert hasattr(teststrategy, '_host_pinned')
    assert teststrategy._host_pinned

# Generated at 2022-06-23 13:03:03.336169
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)

# Generated at 2022-06-23 13:03:14.138353
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # I created mock tqm for this unittest because
    # I did not want to use the tqm of run_playbook.py
    # I did not want to modify the tqm of run_playbook.py
    # I did not want to use the tqm of run_ad_hoc.py
    # I did not want to modify the tqm of run_ad_hoc.py
    # So I created this mock tqm below.
    class tqm:
        @staticmethod
        def get_dead_hosts():
            dead_hosts = []
            return dead_hosts

        @staticmethod
        def get_active_hosts():
            active_hosts = {}
            return active_hosts

        @staticmethod
        def get_failed_hosts():
            failed_hosts

# Generated at 2022-06-23 13:03:15.925126
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    obj = StrategyModule("tqm")
    obj.__init__("tqm")



# Generated at 2022-06-23 13:03:17.433433
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned



# Generated at 2022-06-23 13:03:17.924613
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:03:20.953809
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'

# Make sure the constructor can be called

# Generated at 2022-06-23 13:03:22.664654
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned

# Generated at 2022-06-23 13:03:25.450928
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module
    assert strategy_module._host_pinned

# Generated at 2022-06-23 13:03:27.359241
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    module = StrategyModule(tqm)


# Generated at 2022-06-23 13:03:28.785207
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)
# End unit test for constructor of class StrategyModule

# Generated at 2022-06-23 13:03:32.142275
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
        t_instance = {"key": "value"}
        myobj = StrategyModule(t_instance)
        assert myobj._host_pinned

# Generated at 2022-06-23 13:03:32.944460
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(isinstance(StrategyModule(None), StrategyModule))

# Generated at 2022-06-23 13:03:35.485934
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategyModule = StrategyModule('tqm')
    assert(strategyModule._host_pinned == True)

# Run module tests if we're called as a script
if __name__ == '__main__':
    import pytest
    pytest.main([__file__, '-v', '-s'])

# Generated at 2022-06-23 13:03:41.047722
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class HostTest:
        def __init__(self, name):
            self.name = name
    hosts = [HostTest("host1"), HostTest("host2"), HostTest("host3"), HostTest("host4")]
    class TaskQueueManagerTest:
        def __init__(self, hosts, job_count=0, forks=0):
            self.hosts = hosts
            self.job_count = job_count
            self.forks = forks
    tqm = TaskQueueManagerTest(hosts)
    s = StrategyModule(tqm)
    assert s._host_pinned == True

# Generated at 2022-06-23 13:03:48.222733
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    #TODO: create temporary file with data and read it
    tqm = TaskQueueManager(host_list=['localhost'])
    StrategyModule(tqm = tqm)

if __name__ == '__main__':
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-23 13:03:50.152686
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    free_strategy_module = StrategyModule(tqm)
    assert free_strategy_module._host_pinned is True

# Generated at 2022-06-23 13:03:53.326619
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test with tqm
    strategy_mod = StrategyModule(None)
    assert strategy_mod.get_host_pinned() == True

# Generated at 2022-06-23 13:03:55.660708
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = ''
    a = StrategyModule(tqm)
    assert a._host_pinned == True
    assert a._display == display

# Generated at 2022-06-23 13:03:56.506344
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    return StrategyModule()

# Generated at 2022-06-23 13:03:57.963470
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule("")
    assert obj._host_pinned == True

# Generated at 2022-06-23 13:04:00.255405
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    free_strategy = FreeStrategyModule(tqm=None)
    assert free_strategy.__class__.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:04:01.704669
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(str)
    assert obj._host_pinned == True

# Generated at 2022-06-23 13:04:02.375869
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:04:04.525370
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    mod = StrategyModule(tqm=None)
    assert mod._host_pinned

# Generated at 2022-06-23 13:04:06.319380
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(None)
    print(module._host_pinned)

# test_StrategyModule()

# Generated at 2022-06-23 13:04:07.457647
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    temp_tqm = 0
    StrategyModule(temp_tqm)

# Generated at 2022-06-23 13:04:08.673461
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert(sm)


# Generated at 2022-06-23 13:04:13.211512
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Testing StrategyModule method:')
    # Test default constructor.
    print('Test1')
    strategyModule = StrategyModule()
    # Test constructor with empty object.
    print('Test2')
    strategyModule = StrategyModule()

# Generated at 2022-06-23 13:04:17.821785
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.loader import strategy_loader
    import ansible.plugins.strategy.host_pinned

    strategy = strategy_loader.get('host_pinned', None)
    strategy_obj = strategy()

    assert type(strategy_obj) is StrategyModule
    assert strategy_obj._host_pinned is True

# Generated at 2022-06-23 13:04:19.587737
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:04:20.539072
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)


# Generated at 2022-06-23 13:04:25.688339
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == True
# import unittest
# class TestStrategyModule(unittest.TestCase):
#   def setUp(self):
#       print("In setUp")
#       self.foo = StrategyModule()
#   def test_start(self):
#       print("In start")
#       result = self.foo.StrategyModule(self)
#       self.assertEqual(result, "something")

#   def test_run(self):
#       print("In run")
#       result = self.foo.StrategyModule(self)
#       self.assertEqual(result, "something")

#   def test_cleanup(self):
#       print("In cleanup")
#       result = self.foo.StrategyModule(self)
#       self.assertEqual(result, "something")


# Generated at 2022-06-23 13:04:27.850781
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    _test = StrategyModule(tqm)
    #assertEqual(_test.tqm, tqm)

# Generated at 2022-06-23 13:04:33.732577
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        tqm = NullTQM()
        tqm.result_q = NullQ()
        tqm.cleanup_q = NullQ()
        tqm.dependency_q = NullQ()
        test_ansible_module = StrategyModule(tqm)
        return True
    except Exception:
        return False


# Generated at 2022-06-23 13:04:36.195763
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    stgy = StrategyModule("tqm")
    assert stgy._host_pinned == True, "Failed to create object for class StrategyModule"

# Generated at 2022-06-23 13:04:37.682337
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert not StrategyModule("tqm")


# Generated at 2022-06-23 13:04:39.752595
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
        strategy = StrategyModule()
        assert strategy._host_pinned == True

# Generated at 2022-06-23 13:04:41.537378
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from mock import Mock
    tqm = Mock()
    strategy = StrategyModule(tqm)
    assert strategy._host_pinned

# Generated at 2022-06-23 13:04:42.418850
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:04:48.268905
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule.__bases__ == (FreeStrategyModule,))
    #class StrategyModule contains 2 methods
    assert(len(StrategyModule.__dict__) == 2)
    #first method is inherited from FreeStrategyModule
    assert('__init__' in StrategyModule.__dict__)

# Unit test to check whether StrategyModule is a subclass of FreeStrategyModule.

# Generated at 2022-06-23 13:04:49.580998
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host = {}
    task = {}
    return StrategyModule(host,task)

# Generated at 2022-06-23 13:04:50.734206
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm=None)

# Generated at 2022-06-23 13:04:53.753494
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned as host_pinned
    tqm = host_pinned.StrategyModule(host_pinned)
    assert tqm._host_pinned is True

# Generated at 2022-06-23 13:04:54.412495
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:04:55.907032
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert not StrategyModule.__init__(StrategyModule) 


# Generated at 2022-06-23 13:04:56.549093
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:04:59.667776
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned


# Unit test to check if StrategyModule returns correct value for host_pinned( variable)

# Generated at 2022-06-23 13:05:00.900582
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()
    assert obj._host_pinned == True

# Generated at 2022-06-23 13:05:01.427371
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:05:04.579467
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True


# Code coverage of StrategyModule is currently broken
# def test_StrategyModule_code_coverage():
#     s = StrategyModule(None)
#     assert s.__init__(None) == None

# Generated at 2022-06-23 13:05:08.275861
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    strategy_obj = ansible.plugins.strategy.host_pinned.StrategyModule(None)
    assert strategy_obj._host_pinned == True

# Generated at 2022-06-23 13:05:09.316357
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule("tqm")

# Generated at 2022-06-23 13:05:19.687923
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from collections import namedtuple
    Options = namedtuple('Options', ['connection', 'module_path', 'forks', 'become', 'become_method', 'become_user',
                                     'check', 'listhosts', 'listtasks', 'listtags', 'syntax', 'verbosity', 'diff'])
    options = Options(connection='smart', module_path=None, forks=10, become=False, become_method=None,
                      become_user=None, check=False, listhosts=None, listtasks=None, listtags=None,
                      syntax=None, verbosity=None, diff=False)

# Generated at 2022-06-23 13:05:20.455512
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:05:21.770624
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'unittest'
    StrategyModule(tqm)

# Generated at 2022-06-23 13:05:29.701510
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # FIXME: The two following imports are absolute, simply to work around
    # the following error:
    # ImportError: attempted relative import with no known parent package
    # See: https://stackoverflow.com/questions/14132789/relative-imports-for-the-billionth-time
    from ansible_collections.ansible.community.tests.unit.mock.tqm import TqmMock
    from ansible_collections.ansible.community.tests.unit.plugins.strategy.host_pinned.test_host_pinned import StrategyModule
    from ansible.playbook.play import Play

    play = Play()
    tqm = TqmMock(play)
    assert StrategyModule(tqm)

# Generated at 2022-06-23 13:05:30.922597
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned

# Generated at 2022-06-23 13:05:31.464939
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:05:32.933405
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("this is tqm")
    assert strategy_module._host_pinned

# Generated at 2022-06-23 13:05:34.238617
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)._host_pinned == True

# Generated at 2022-06-23 13:05:35.784882
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:05:36.782596
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None)._host_pinned is True

# Generated at 2022-06-23 13:05:38.783934
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-23 13:05:40.935686
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule()
    assert_equal(x.__name__, "host_pinned")

# Generated at 2022-06-23 13:05:49.584518
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    dict = {}
    dict['playbook'] = {}
    dict['playbook']['become_user'] = 'root'
    dict['playbook']['become'] = True
    dict['playbook']['become_method'] = 'sudo'
    dict['tqm'] = {}
    dict['tqm']['stats'] = {}
    dict['tqm']['stats']['dark'] = []
    dict['tqm']['stats']['dark'].append('moocow')
    dict['tqm']['stats']['dark'].append('aoeu')
    dict['tqm']['stats']['dark'].append('foobar')
    dict['tqm']['stdout_callback'] = 'default'

# Generated at 2022-06-23 13:05:50.611406
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm = None)

# Generated at 2022-06-23 13:05:55.598601
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from tests.unit.fake_taskqueue_manager import FakeTaskQueueManager
    tqm = FakeTaskQueueManager()
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned is True



# Generated at 2022-06-23 13:05:56.202449
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	pass

# Generated at 2022-06-23 13:05:59.008052
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  import mock
  tqm = mock.Mock()
  strategy = StrategyModule(tqm)
  assert strategy._host_pinned == True


# Generated at 2022-06-23 13:06:01.288956
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('tqm')._host_pinned == True

# Generated at 2022-06-23 13:06:01.899266
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:06:03.721743
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    TaskQueueManager()
    StrategyModule('Test')

# Generated at 2022-06-23 13:06:04.750553
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:06:07.044380
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert getattr(StrategyModule, '__init__') is not None

# Generated at 2022-06-23 13:06:17.691690
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.fork import AnsibleFork
    from ansible.utils.loader import DataLoader
    from ansible.parsing.dataloader import DataLoader

    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(inventory=None)
    tqm.loader = DataLoader()
    tqm.display = Display()
    tqm.display.verbosity = 0
    tqm.stdout_callback = 'default'
    hosts_pinned = StrategyModule(tqm)
    if hosts_pinned._host_pinned == True:
        print(">> test_Strategy_hosts_pinned_constructor: OK")
    else:
        print(">> test_Strategy_hosts_pinned_constructor: KO")

# Generated at 2022-06-23 13:06:19.918386
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    obj = StrategyModule(10)
    assert obj is not None

# Generated at 2022-06-23 13:06:21.038359
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:06:23.870448
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy.tqm is None
    assert strategy._host_pinned is True

# Generated at 2022-06-23 13:06:25.378376
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(1)

    assert s._host_pinned == True

# Generated at 2022-06-23 13:06:36.854892
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.display import Display
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor

# Generated at 2022-06-23 13:06:37.611586
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("test_StrategyModule")
    assert True

# Generated at 2022-06-23 13:06:40.724302
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import sys
    mod = sys.modules[__name__]
    strategy = StrategyModule(mod)
    assert(hasattr(strategy, '_host_pinned')) == True

# test for StrategyModule class

# Generated at 2022-06-23 13:06:52.309352
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.utils.hashing import md5s
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import ansible.constants as C
    options = C.load_config_file()
    options['inventory'] =  os.path.dirname(__file__) + "/../../../test/units/module_utils/ansible_test_inventory"
    options['listhosts'] = True
    options['listtasks'] = True
    options['listtags'] = True
    options['syntax'] = True
    options['connection'] = 'local'

# Generated at 2022-06-23 13:06:54.909036
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_obj = StrategyModule(tqm)
    assert strategy_obj._host_pinned == True

# Generated at 2022-06-23 13:06:55.711763
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule != None


# Generated at 2022-06-23 13:06:56.440764
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:06:58.286158
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    strategy = StrategyModule(None)

    assert strategy != None
    assert strategy._host_pinned


# Generated at 2022-06-23 13:06:59.211361
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 13:07:04.433953
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	tqm = ''
	strategy = StrategyModule(tqm)
	ret = strategy
	if ret:
		print("The StrategyModule is created successful.")
	else:
		print("The StrategyModule is not created.")

# test_StrategyModule()
'''
# Test code
if __name__ == '__main__':
	tqm = ''
	strategy = StrategyModule(tqm)
	ret = strategy
	if ret:
		print("The StrategyModule is created successful.")
	else:
		print("The StrategyModule is not created.")
'''

# Generated at 2022-06-23 13:07:07.609351
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   # Test StrategyModule and its parent class are successfully imported.
    strategy_module = StrategyModule()
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:07:08.599513
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:07:09.198001
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:07:11.079356
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = '''task_queue_manager'''
    StrategyModule(tqm)

# Test for function get_hosts_remaining

# Generated at 2022-06-23 13:07:13.496922
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=tqm)
    assert strategy_module._host_pinned == True


# Generated at 2022-06-23 13:07:14.602835
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule() is None

# Generated at 2022-06-23 13:07:15.200023
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:07:16.291934
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:07:17.564456
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert type(StrategyModule) == type

# Generated at 2022-06-23 13:07:18.852128
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:07:20.138818
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my = StrategyModule(tqm=None)
    assert my._host_pinned == True

# Generated at 2022-06-23 13:07:24.049673
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    assert issubclass(StrategyModule, FreeStrategyModule)
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''

# Generated at 2022-06-23 13:07:24.935268
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)

# Generated at 2022-06-23 13:07:27.742097
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(None)
    assert module._host_pinned == True

# Generated at 2022-06-23 13:07:36.736219
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-23 13:07:38.521793
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_object = StrategyModule(None)
    assert strategy_object._host_pinned == True

# Generated at 2022-06-23 13:07:39.529836
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None

# Generated at 2022-06-23 13:07:41.289879
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm)
    assert obj is not None

# Generated at 2022-06-23 13:07:41.916284
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-23 13:07:42.857851
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 13:07:44.816334
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print('Testing the constructor of StrategyModule class...')
    stg = StrategyModule()
    print(str(stg._host_pinned))

# Generated at 2022-06-23 13:07:45.625976
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()
    print(s)

# Generated at 2022-06-23 13:07:48.602833
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_tqm = list()
    test_s = StrategyModule(test_tqm)
    assert test_s
    assert test_s._host_pinned == True
# end of test_StrategyModule


# Generated at 2022-06-23 13:07:49.893998
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:07:54.037095
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ Test behavior of constructor of class StrategyModule
    
    test_StrategyModule creates a StrategyModule object with its constructor and checks 
    if the value of self._host_pinned is True
    """
    sm = StrategyModule("tqm")
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:07:55.045190
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)

# Generated at 2022-06-23 13:07:57.902401
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    global display
    sm = StrategyModule(Display())
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:08:00.223806
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=42)
    assert hasattr(strategy, 'get_host_list')


# Generated at 2022-06-23 13:08:00.853821
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:08:02.634353
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)
    pass

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:08:03.222789
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    StrategyModule(None)

# Generated at 2022-06-23 13:08:04.013209
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:08:05.252247
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    foo = StrategyModule(None)
    assert foo._host_pinned == True

# Generated at 2022-06-23 13:08:06.423851
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule('tqm')
    assert s._host_pinned == True

# Generated at 2022-06-23 13:08:08.160613
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()
    assert obj._host_pinned == True

# Generated at 2022-06-23 13:08:10.978384
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule) == True
    assert StrategyModule.__init__(FreeStrategyModule) == None

# Generated at 2022-06-23 13:08:13.393971
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert hasattr(s, '_host_pinned')
    assert s._host_pinned


# Generated at 2022-06-23 13:08:14.029773
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:08:15.751845
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # check if strategy module is created with proper values
    tqm = ansible.utils.vars.VariableManager()
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:08:17.022784
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-23 13:08:17.940365
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule is not None

# Generated at 2022-06-23 13:08:19.184158
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)

# Generated at 2022-06-23 13:08:27.474583
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    tqm = ansible.executor.task_queue_manager.TaskQueueManager(
        inventory=ansible.inventory.Inventory(host_list=['dummy']),
        variable_manager=ansible.vars.VariableManager(),
        loader=ansible.parsing.dataloader.DataLoader(),
        options=None,
        passwords=None,
        stdout_callback=None,
        run_additional_callbacks=False,
        run_tree=False,
    )
    strategy = StrategyModule(tqm)
    assert strategy

# Generated at 2022-06-23 13:08:28.472788
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(callable(StrategyModule))

# Generated at 2022-06-23 13:08:29.000490
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None) != None

# Generated at 2022-06-23 13:08:30.408977
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-23 13:08:31.116086
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:08:34.216925
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(1)
    assert isinstance(strategy, StrategyModule)
    assert isinstance(strategy._host_pinned, bool)

# Generated at 2022-06-23 13:08:39.061541
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned = True
    class Foo:
        def __init__(self, tqm):
            self._host_pinned = True
    StrategyModule = Foo
    strategy_module = StrategyModule(host_pinned)
    print(strategy_module)


# test_StrategyModule()

# Generated at 2022-06-23 13:08:40.776254
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm._host_pinned

# Generated at 2022-06-23 13:08:46.402578
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # DummyTaskQueueManager() not instantiated, as it will raise SystemExit.
    # When instantiated, it will be rechecked before merge.
    instance = StrategyModule(None)
    assert isinstance(instance, StrategyModule)
    assert isinstance(instance, FreeStrategyModule)

# Unit test only if method name starts with 'test_'

# Generated at 2022-06-23 13:08:48.382768
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = MockTaskQueueManager()
    strategy = StrategyModule(tqm)
    assert strategy.get_host_pinned() == True


# Generated at 2022-06-23 13:08:48.944999
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == True

# Generated at 2022-06-23 13:08:50.964850
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert 'StrategyModule' == StrategyModule.__name__

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:08:53.899931
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

        # Test creating StrategyModule object
        try:
            StrategyModule("")
        except:
            raise Exception("Creation of StrategyModule object failed")


# Generated at 2022-06-23 13:08:55.456500
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(0)
    assert sm
    return

# Generated at 2022-06-23 13:08:59.204507
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    '''
    This is a fake unit test. It does not test any functionality, but just shows
    how you can add a unit test for your strategy.
    '''
    # To be implemented later ...
    assert True

# Generated at 2022-06-23 13:08:59.894210
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:09:01.187331
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True



# Generated at 2022-06-23 13:09:02.202771
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    strategy = StrategyModule(display)
    assert strategy._host_pinned



# Generated at 2022-06-23 13:09:02.902042
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()
    assert obj._host_pinned == True

# Generated at 2022-06-23 13:09:11.720200
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import shared_loader_obj
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    from ansible.executor.task_queue_manager import unsynced_module_executor
    #from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy import StrategyModule

    #from ansible.plugins.strategy.host_pinned import

# Generated at 2022-06-23 13:09:12.792591
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)

# Generated at 2022-06-23 13:09:14.850411
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm=None)
    assert sm._host_pinned == True


# Generated at 2022-06-23 13:09:16.109324
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__(StrategyModule, tqm=None) is None

# Generated at 2022-06-23 13:09:18.481541
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = True
    obj = StrategyModule(tqm)
    assert obj._host_pinned == True

# Generated at 2022-06-23 13:09:20.109822
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"

# Generated at 2022-06-23 13:09:21.873213
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned = StrategyModule(tqm)
    assert host_pinned._host_pinned

# Generated at 2022-06-23 13:09:23.954979
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule('test_tqm')
    assert module is not None
    assert module._host_pinned is True

# Generated at 2022-06-23 13:09:27.255961
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class TestStrategyModule(StrategyModule):
        def __init__(self, tqm):
            super(TestStrategyModule, self).__init__(tqm)
            self._host_pinned = True
    tqm = None
    strategy = TestStrategyModule(tqm)
    assert strategy.get_host_list() == []

# Generated at 2022-06-23 13:09:30.340832
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule(None)
    except:
        assert False, 'Failed to create instance of StrategyModule'

# Generated at 2022-06-23 13:09:32.699333
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy import StrategyBase
    assert issubclass(StrategyModule, StrategyBase)

# Generated at 2022-06-23 13:09:34.584360
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)
    pass

# vim: set et ts=8 sw=4 sts=4 :

# Generated at 2022-06-23 13:09:37.532250
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule(True)
    assert tqm.get_host_pinned() == True


# Generated at 2022-06-23 13:09:39.549379
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned is True

# Generated at 2022-06-23 13:09:41.063439
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__

# Generated at 2022-06-23 13:09:50.335393
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    assert issubclass(StrategyModule, StrategyModule)

    import mock
    import ansible
    import ansible.plugins
    import ansible.plugins.strategy

    tqm_mock = mock.MagicMock()
    tqm_mock.__class__.__name__ = 'MockTQMClass'


# Generated at 2022-06-23 13:09:51.273003
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule, object)

# Generated at 2022-06-23 13:09:55.807966
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy.free import StrategyModule
    
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-23 13:09:57.342710
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule("tqm")

# Generated at 2022-06-23 13:09:59.336346
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule("Test")
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:09:59.895063
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:10:08.190585
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("executing unit test for constructor of class StrategyModule")
    class TestStrategyModule(StrategyModule):
        def __init__(self, tqm):
            super(StrategyModule, self).__init__(tqm)
            print(self._host_pinned)
    # Create test_strategy_module object of class StrategyModule and call the constructor
    test_strategy_module = TestStrategyModule(1)

# call test_StrategyModule() method when test_strategy_module.py is called in command line
if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:10:08.782022
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:10:09.717034
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule("tqm")

# Generated at 2022-06-23 13:10:11.166130
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy

# Generated at 2022-06-23 13:10:13.012593
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategyModule = StrategyModule(tqm)
    assert strategyModule._host_pinned is True

# Generated at 2022-06-23 13:10:14.441267
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule()
    assert type(a) is StrategyModule

# Generated at 2022-06-23 13:10:17.756734
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    tqm = TaskQueueManager(None,'localhost', '', None, None)
    a = StrategyModule(tqm)

# Generated at 2022-06-23 13:10:20.539180
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Test function with fake tqm
    class FakeTqm():
        def run(self):
            return 0

    st = StrategyModule(FakeTqm())



# Generated at 2022-06-23 13:10:21.963081
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
        plugin = StrategyModule(None)
        assert plugin._host_pinned == True

# Generated at 2022-06-23 13:10:23.872822
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    obj = StrategyModule(tqm)
    assert obj is not None
    del obj
    del tqm

# Generated at 2022-06-23 13:10:25.442163
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(tqm=1)
    assert module._tqm == 1

# Generated at 2022-06-23 13:10:33.598553
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    tqm = TaskQueueManager(
            inventory=InventoryManager(
                sources=['./test/inventory']),
            variable_manager=VariableManager(),
            loader=None,
            options=None,
            passwords=None,
            stdout_callback="default",
            run_tree=False,
        )
    s = StrategyModule(tqm)
    assert s._host_pinned is True

# Generated at 2022-06-23 13:10:34.479928
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FakeTQM()
    StrategyModule(tqm)


# Generated at 2022-06-23 13:10:34.993555
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:10:36.846991
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__bases__ == (FreeStrategyModule,)
    assert StrategyModule._host_pinned == True

# Generated at 2022-06-23 13:10:38.254948
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule()
    assert strategy._host_pinned is True

# Generated at 2022-06-23 13:10:38.890677
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:10:46.045459
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    from ansible.plugins import strategy_loader
    from ansible.plugins.loader import action_loader, cache_loader, callback_loader, connection_loader, lookups_loader
    from ansible.plugins.loader import module_loader, shell_loader, strategy_loader, test_loader
    from ansible.plugins.strategy import StrategyBase
    from ansible.plugins.strategy_loader import get_strategy

    from ansible.utils.display import Display

    strategy_plugins = strategy_loader.all()

    assert 'host_pinned' in strategy_plugins

    strategy_plugin = strategy_loader.get('linear')
    assert isinstance(strategy_plugin, StrategyModule)



# Generated at 2022-06-23 13:10:46.897971
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(None)
    assert module

# Generated at 2022-06-23 13:10:47.946396
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule.__init__()


# Generated at 2022-06-23 13:10:48.926341
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm={})


# Generated at 2022-06-23 13:10:51.619629
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:11:01.023696
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    assert FreeStrategyModule
    assert StrategyModule.__init__
    assert FreeStrategyModule.__init__
    assert StrategyModule.__init__.__name__ == "__init__"
    assert FreeStrategyModule.__init__.__name__ == "__init__"
    sm = StrategyModule(None)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:11:02.593510
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(1)



# Generated at 2022-06-23 13:11:07.790706
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    _tqm, _loader, _options, _variable_manager, _inventory = None, None, None, None, None
    _Scenario().test_StrategyModule(_tqm, _loader, _options, _variable_manager, _inventory)


# Scenario test case for StrategyModule

# Generated at 2022-06-23 13:11:09.540663
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_object = StrategyModule('tqm')
    assert strategy_object._host_pinned == True

# Generated at 2022-06-23 13:11:11.920786
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__module__ == "ansible.plugins.strategy.host_pinned"
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''

# Generated at 2022-06-23 13:11:12.469316
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:11:13.107055
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:11:14.462811
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule()
    print(x.__doc__)

# Generated at 2022-06-23 13:11:16.545451
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:11:17.207561
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm._host_pinned == True


# Generated at 2022-06-23 13:11:21.678573
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    test_instance = StrategyModule(tqm)
    assert test_instance
    assert test_instance.__class__.__name__ == "StrategyModule"


# Generated at 2022-06-23 13:11:24.006451
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == "StrategyModule"
    assert StrategyModule.__module__ == "__main__"
    assert callable(StrategyModule)

# Generated at 2022-06-23 13:11:26.433717
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = {}
    sm = StrategyModule(tqm)
    assert sm._host_pinned

# Generated at 2022-06-23 13:11:28.214950
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = []
    StrategyModule(tqm)

# Generated at 2022-06-23 13:11:30.978740
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    assert issubclass(StrategyModule, StrategyModule) is True


# Generated at 2022-06-23 13:11:32.613192
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__

# Generated at 2022-06-23 13:11:33.969060
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__

# Generated at 2022-06-23 13:11:37.048161
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    tqm = ansible.plugins.strategy.host_pinned.StrategyModule('test')
    assert tqm._host_pinned == True

# Generated at 2022-06-23 13:11:40.924197
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import collections
    tqm = collections.namedtuple('Test_tqm', 'all_hosts')()
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned

# Generated at 2022-06-23 13:11:42.979672
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert not StrategyModule(None)._host_pinned

# Generated at 2022-06-23 13:11:44.846767
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    TQM()
#
# Adding a base class for unit test
#

# Generated at 2022-06-23 13:11:46.303078
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:11:49.133653
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = dict()
    sm = StrategyModule(tqm)
    assert sm

# Generated at 2022-06-23 13:11:52.079347
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert strategy_module is not None
    assert strategy_module._host_pinned is not True
    assert strategy_module._tqm is not None

# Generated at 2022-06-23 13:11:53.191122
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(None).__init__

# Generated at 2022-06-23 13:11:55.233061
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    st = StrategyModule()
    assert st._host_pinned

# Generated at 2022-06-23 13:11:57.245574
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = []
    StrategyModule(tqm)

# Generated at 2022-06-23 13:11:58.921607
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # construct an object of class StrategyModule by calling the constructor
    StrategyModule()

# Generated at 2022-06-23 13:12:00.524604
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-23 13:12:02.793167
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
   tqm = None
   StrategyModule(tqm)