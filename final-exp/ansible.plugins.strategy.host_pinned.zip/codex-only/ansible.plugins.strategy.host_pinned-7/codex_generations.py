

# Generated at 2022-06-23 13:02:04.109386
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:02:06.873130
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True
    assert strategy._next_task_lock == None
    assert strategy._task_queue == None

# Generated at 2022-06-23 13:02:10.400163
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    argument = {}
    strategy = StrategyModule(argument)

    # Assert type of member variable '_host_pinned'
    assert isinstance(strategy._host_pinned, bool)
    # Assert default value of member variable '_host_pinned'
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:02:13.937154
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm)
    assert sm._host_pinned

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:02:14.494338
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:02:18.020815
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        StrategyModule()
    except NameError as e:
        assert True
    except Exception as e:
        assert False


# Generated at 2022-06-23 13:02:19.573010
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm
    assert sm._host_pinned

# Generated at 2022-06-23 13:02:20.247281
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:02:23.028871
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule()
    assert(strategy_module._host_pinned == True)

# Generated at 2022-06-23 13:02:26.013590
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class tqm:
        def __init__(self):
            self.__name = 'tqm'
    assert StrategyModule(tqm())._host_pinned

# Generated at 2022-06-23 13:02:27.066119
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(0)

# Generated at 2022-06-23 13:02:31.170772
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule), "StrategyModule should be a subclass of FreeStrategyModule"
    sm = StrategyModule(tqm=None)
    assert sm._host_pinned is True, "_host_pinned should be True"


# Generated at 2022-06-23 13:02:34.680641
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_stategy = StrategyModule(tqm)
    assert test_stategy._host_pinned == True

# Generated at 2022-06-23 13:02:35.596332
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:02:37.595054
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule("tqm")
    assert strategy_module._host_pinned == True


# Generated at 2022-06-23 13:02:39.084214
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert s._host_pinned == True
    assert s._tqm == None

# Generated at 2022-06-23 13:02:40.796992
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule("tqm")

# Generated at 2022-06-23 13:02:42.267047
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm)._host_pinned == True

# Generated at 2022-06-23 13:02:42.937794
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True # TODO: implement your test here

# Generated at 2022-06-23 13:02:47.096020
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Constructor: It is not possible to use assertIsInstance() on variables
    # declared as class attributes.  As a result, the following test is
    # commented out.
    #
    # sm = StrategyModule()
    # assertIsInstance(sm, StrategyModule)
    # assertIsInstance(sm, FreeStrategyModule)
    pass

# Generated at 2022-06-23 13:02:47.765485
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:02:49.835626
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Test for inheritance of class FreeStrategyModule

# Generated at 2022-06-23 13:02:51.031038
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        strategy = StrategyModule('ssh')
    except:
        assert True

# Generated at 2022-06-23 13:02:52.143351
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()
    assert True

# Generated at 2022-06-23 13:02:55.723728
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)

    assert(strategy._host_pinned == True)

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()

# Generated at 2022-06-23 13:02:59.365009
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule(tqm=0)
    sm = StrategyModule(tqm=tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:03:00.282497
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:03:04.536097
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_list = ['host1','host2','host3']
    tqm = Mock( return_value=host_list )
    StrategyModule(tqm)


# Unit test to determine if host_pinned is set to True

# Generated at 2022-06-23 13:03:06.564810
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert s.get_host_pinned() == True


# Generated at 2022-06-23 13:03:08.050498
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "test_tqm"
    StrategyModule(tqm)

# Generated at 2022-06-23 13:03:18.318567
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import Playbook
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory import Inventory

    # Create a task queue manager
    tqm = PlaybookExecutor(
        playbooks=[Playbook.load('./test/test_module.yml', variable_manager='ansible')],
        inventory=Inventory('./test/hosts'),
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None
    )
    assert tqm is not None
    assert hasattr(tqm, '_tasks') is True

    # Create strategy module
    sm = StrategyModule(tqm)
    assert sm.display is not None
    assert isinstance(sm.display, Display)
    assert sm._tq

# Generated at 2022-06-23 13:03:19.228040
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass


# Generated at 2022-06-23 13:03:21.696941
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import host_pinned
    assert issubclass(host_pinned.StrategyModule, FreeStrategyModule)

# Generated at 2022-06-23 13:03:23.898543
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module
    assert isinstance(strategy_module, StrategyModule)

# Generated at 2022-06-23 13:03:27.604560
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  class tqm:
    def __init__(self):
      self.host_pinned = True
  t = StrategyModule(tqm)
  assert t._host_pinned == True

# Generated at 2022-06-23 13:03:29.025836
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy = StrategyModule(tqm)
    strategy._host_pinned = True
    assert True

# Generated at 2022-06-23 13:03:33.953300
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    from ansible.plugins.strategy.host_pinned import StrategyModule as HostPinnedStrategyModule
    assert HostPinnedStrategyModule.__base__ == FreeStrategyModule



# Generated at 2022-06-23 13:03:37.321531
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'Test'
    test_strategymodule = StrategyModule(tqm)
    result = test_strategymodule._host_pinned
    assert result == True


# Generated at 2022-06-23 13:03:38.026255
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert isinstance(StrategyModule(None), StrategyModule)

# Generated at 2022-06-23 13:03:40.037483
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule('tqm')
    assert sm._host_pinned == True


# Generated at 2022-06-23 13:03:42.856010
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.strategy.host_pinned import StrategyModule as TestModule
    sm = StrategyModule(tqm=None)
    assert isinstance(sm, TestModule)
    assert sm._host_pinned

# Generated at 2022-06-23 13:03:51.872452
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.errors import AnsibleError
    from ansible.utils.display import Display
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.play_iterator import PlayIterator
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block

    display = Display()
    loader = DataLoader()

# Generated at 2022-06-23 13:03:53.023669
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:03:55.342854
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print (StrategyModule.__doc__)
    StrategyModule()


# unit tests require executable code, so create a function that will serve as the main()

# Generated at 2022-06-23 13:03:56.396816
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    st = StrategyModule('tqm')
    assert st._host_pinned == True


# Generated at 2022-06-23 13:04:02.782367
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    class TestPlay:
        pass
    play = TestPlay()
    setattr(play, 'hosts', 'localhost')
    setattr(play, 'tasks', [])
    setattr(play, 'post_tasks', [])
    setattr(play, 'roles', [])
    setattr(play, 'block', Block())
    setattr(play, 'handlers', [])
    setattr(play, 'default_vars', dict())
    setattr(play, 'vars_prompt', dict())
    setattr(play, 'vars_files', [])
    setattr(play, 'role_names', [])
    play_context = PlayContext()

# Generated at 2022-06-23 13:04:08.297085
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = dict(
        hosts=['host1', 'host2'],
        show_custom_stats=True,
        stats=dict(processed={}, ok={}, failures={}, dark={}, ignored={}, rescued={}, skipped={}),
    )
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# Unit tests for free strategy module

# Generated at 2022-06-23 13:04:09.506174
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# vim: set expandtab shiftwidth=4 softtabstop=4 :

# Generated at 2022-06-23 13:04:12.188698
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(None)
    print (sm, sm.get_host_pinned())
    assert sm.get_host_pinned() is True

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:04:12.906492
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'

# Generated at 2022-06-23 13:04:14.701681
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    tqm = object()
    strategy = StrategyModule(tqm)
    assert strategy._tqm == tqm

# Generated at 2022-06-23 13:04:19.729499
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm =
        {
            "callback": object(),
            "stats": object(),
            "stdout_callback": object(),
            "runner": object(),
            "inventory": object(),
            "variable_manager": object(),
            "loader": object(),
            "options": object(),
            "passwords": object()
        })

# Generated at 2022-06-23 13:04:20.995480
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = "test_tqm"
    strategy = StrategyModule(tqm)
    assert type(strategy) == StrategyModule
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:04:23.042448
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule()
    assert(a._host_pinned == True)

# Unit tests for methods in class StrategyModule

# Generated at 2022-06-23 13:04:24.229419
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    my_StrategyModule = StrategyModule()
    assert my_StrategyModule._host_pinned == True

# Generated at 2022-06-23 13:04:25.991865
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:04:37.118771
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.constants import DEFAULT_FORKS
    from ansible.playbook.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyModule

    forks = DEFAULT_FORKS # make static forks
    tqm = TaskQueueManager(forks=forks) # constructor of TaskQueueManager
    strategy_module = StrategyModule(tqm) # call the constructor of StrategyModule
    assert strategy_module._host_pinned == True # validate the host_pinned is equal to True, _host_pinned is a instance variable of StrategyModule
    # test the constructor of the super class FreeStrategyModule
    assert strategy_module._batch == forks # validate the batch
    assert strategy_module._display == display # validate the display
    assert strategy_module._loader == tqm._loader # validate the loader

# Generated at 2022-06-23 13:04:37.735232
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:04:40.181569
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_StrategyModule = StrategyModule("tqm")
    assert test_StrategyModule._host_pinned == True

# Generated at 2022-06-23 13:04:42.417101
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object()
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True


# Generated at 2022-06-23 13:04:45.818021
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    x = StrategyModule(None)
    assert x._host_pinned
    assert x._push_special_task(None, None)
    assert x._pop_special_task(None, None)

# Generated at 2022-06-23 13:04:48.110635
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned = StrategyModule(None)
    assert host_pinned._host_pinned == True

# Generated at 2022-06-23 13:04:49.065867
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule()

# Generated at 2022-06-23 13:04:50.962760
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(True)
    assert(sm.get_host_pinned() == True)

# Generated at 2022-06-23 13:04:56.553927
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    # Make code compatible for python 2 and 3
    import sys
    if sys.version_info[0] == 2:
        import __builtin__ as builtins
    else:
        import builtins
    builtins.__dict__['display'] = display
    # Method call
    StrategyModule(tqm)


# Generated at 2022-06-23 13:04:58.857432
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule(None)
    assert s == 'host_pinned'
    assert s._host_pinned == True

# Generated at 2022-06-23 13:05:00.235044
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(None)
    assert module._host_pinned == True

# Generated at 2022-06-23 13:05:01.100810
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ != None



# Generated at 2022-06-23 13:05:02.521325
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule()
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:05:06.406674
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import unittest
    import sys

    class StrategyModuleTest(unittest.TestCase):
        def setUp(self):
            self.test = StrategyModule(None)
        def test_constructor(self):
            self.assertEqual(self.test._host_pinned, True)
    
    suite = unittest.TestLoader().loadTestsFromModule(StrategyModuleTest())
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-23 13:05:07.643405
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('tqm')


# Generated at 2022-06-23 13:05:08.357258
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule('tqm')
    assert strategy._host_pinned == True

# Generated at 2022-06-23 13:05:12.215881
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """Unit test for constructor of class StrategyModule"""
    if not display.verbosity:
        display.verbosity = 3
    tqm = 0
    my_obj = StrategyModule(tqm)
    assert my_obj is not None

# Generated at 2022-06-23 13:05:14.056148
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-23 13:05:15.534690
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)

# Generated at 2022-06-23 13:05:16.119974
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:05:17.294718
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = FreeStrategyModule(tqm)
    assert StrategyModule.host_pinned == True

# Generated at 2022-06-23 13:05:18.078548
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert (StrategyModule(None))

# Generated at 2022-06-23 13:05:20.039437
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = []
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:05:22.431917
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global display
    display = Display()
    s = StrategyModule(None)
    assert s._host_pinned == True


# vim: set et ts=4 sw=4 :

# Generated at 2022-06-23 13:05:24.157390
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = StrategyModule(tqm)
    assert tqm._host_pinned == True

# Generated at 2022-06-23 13:05:26.095091
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strategy_instance = StrategyModule(tqm)
    assert strategy_instance._host_pinned == True

# Generated at 2022-06-23 13:05:26.982108
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-23 13:05:29.917749
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.plugins.strategy.free import StrategyModule as FreeStrategyModule
    assert issubclass(StrategyModule, FreeStrategyModule)
    strategy_module = StrategyModule()
    assert strategy_module

# Generated at 2022-06-23 13:05:36.511665
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    strat = StrategyModule(tqm)
    assert strat._host_pinned == True
    assert strat._tqm == None
    assert strat._inventory == None
    assert strat._variable_manager == None
    assert strat._loader == None
    assert strat._shared_loader_obj == None
    assert strat._notified_handlers == None
    assert strat._play_context == None
    assert strat._cur_notified_handler == None
    assert strat._cur_notified_result == None
    assert strat._final_q == None
    assert strat._failed_hosts_q == None
    assert strat._done_hosts_q == None
    assert strat._unreachable_hosts_q == None
    assert strat._blocked_hosts == None

# Generated at 2022-06-23 13:05:40.019891
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Unit test: construction
    #
    # Create a strategy
    #
    # Ensure the strategy created is not empty
    assert StrategyModule(None) is not None

# Generated at 2022-06-23 13:05:41.884593
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Testing StrategyModule constructor")
    obj = StrategyModule(None)
    assert obj != None
    print("Test passed")

# Generated at 2022-06-23 13:05:43.637023
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__ is not FreeStrategyModule.__init__

# Generated at 2022-06-23 13:05:44.195405
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:05:44.786094
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-23 13:05:45.685427
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 13:05:47.137141
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    print("Test constructor of class StrategyModule")
    obj = StrategyModule(None)
    assert obj != None

# Generated at 2022-06-23 13:05:53.119440
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Prepare test
    test_tqm = "test_tqm"
    test_module = StrategyModule(test_tqm)
    # Perform test
    assert test_module._host_pinned == True
    assert test_module.name == 'host_pinned'
    assert test_module._tqm == "test_tqm"


# Generated at 2022-06-23 13:05:58.512648
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.play_iterator import PlayIterator
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import cache_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import shell_loader

# Generated at 2022-06-23 13:06:00.847148
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy is not None


# Generated at 2022-06-23 13:06:03.130211
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert not StrategyModule.__init__
    s = StrategyModule(tqm=True)
    assert s


# Generated at 2022-06-23 13:06:15.270666
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Define some variables.
    display = Display()
    queue = Queue()
    variable_manager = None
    loader = None
    options = Options()
    passwords = dict(vault_pass='secret')
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost,')
    tqm = TaskQueueManager(
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        options=options,
        passwords=passwords,
        stdout_callback=display.display,
    )

    # Try to initialize the StrategyModule class.
    try:
        StrategyModule(tqm)
    except Exception as exception:
        # Print error message and exit.
        print(exception)
        print(traceback.format_exc())
        exit(1)

# Generated at 2022-06-23 13:06:16.266750
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '__init__')

# Generated at 2022-06-23 13:06:17.226069
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ is not None

# Generated at 2022-06-23 13:06:17.828973
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:06:18.420280
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:06:20.559936
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True
    return strategy

# Unit test

# Generated at 2022-06-23 13:06:26.028516
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule

    class TestTQM(object):
        def __init__(self):
            self.send_callback = None
    tqm = TestTQM()

    sm = StrategyModule(tqm)
    assert sm is not None
    assert sm._host_pinned is True

# Generated at 2022-06-23 13:06:37.294685
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible

    for f in ['/', '../', '../../']:
        if os.path.exists(f + 'test_host_pinned.py'):
            break
    sys.path.insert(0, f)

    #from test_host_pinned import FakeTQM

    tqm = FakeTQM()
    sm = StrategyModule(tqm)
    assert sm._host_pinned

# Generated at 2022-06-23 13:06:38.110036
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)



# Generated at 2022-06-23 13:06:40.260229
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    res = StrategyModule(tqm)
    assert res._host_pinned

# Generated at 2022-06-23 13:06:41.156034
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(tqm)

# Generated at 2022-06-23 13:06:43.508818
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule('test') # here 'test' is the tqm
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:06:46.064269
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    assert obj._host_pinned == True


# Generated at 2022-06-23 13:06:46.675013
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:06:47.928105
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__name__ == 'StrategyModule'
    assert StrategyModule.__module__ == 'ansible.plugins.strategy.host_pinned'

# Generated at 2022-06-23 13:06:48.531920
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert type(StrategyModule) == type



# Generated at 2022-06-23 13:06:50.269641
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj_StrategyModule = StrategyModule("tqm")
    assert obj_StrategyModule._host_pinned == True


# Generated at 2022-06-23 13:06:51.761401
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  display = Display()
  tqm = {"_tqm": display}
  assert StrategyModule.__init__(tqm) == True

# Generated at 2022-06-23 13:06:52.749379
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:06:54.183229
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-23 13:06:54.804341
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:06:55.270975
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:06:59.375603
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    a = StrategyModule('a')
    assert a is not None

# vim: expandtab fileencoding=utf-8 tabstop=4 shiftwidth=4 autoindent smartindent

# Generated at 2022-06-23 13:07:07.068475
# Unit test for constructor of class StrategyModule

# Generated at 2022-06-23 13:07:09.316760
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    host_pinned_obj = StrategyModule(None)
    assert host_pinned_obj._host_pinned == True

# Generated at 2022-06-23 13:07:14.742521
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__, "No docstring in StrategyModule class"
    assert StrategyModule.__init__.__doc__, "No docstring in __init__ function"
    assert StrategyModule.run.__doc__, "No docstring in run function"
    assert StrategyModule.get_next_task_lockfree.__doc__, "No docstring in get_next_task_lockfree function"

# Generated at 2022-06-23 13:07:17.706577
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Instantiate the executor
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:07:19.753108
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule(tqm=None)
    assert obj.__init__(tqm=None) == None


# Generated at 2022-06-23 13:07:20.999385
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert hasattr(StrategyModule, '_host_pinned')

# Generated at 2022-06-23 13:07:23.474545
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    class FakeTQM(object):
        pass
    tqm = FakeTQM()
    strategy_module = StrategyModule(tqm)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:07:30.588582
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = dict()
    tqm['_diff'] = False
    tqm['_inventory'] = list()
    tqm['_play_context'] = "play_context"
    tqm['_variable_manager'] = "variable_manager"
    strategy_module = StrategyModule(tqm)
    assert strategy_module


if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:07:33.730938
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import ansible.plugins.strategy.host_pinned
    strategy = ansible.plugins.strategy.host_pinned.StrategyModule('test')
    assert strategy is not None
    assert strategy._host_pinned is True

# Generated at 2022-06-23 13:07:44.124652
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.role.include import RoleInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.factory import ProcessFactory
    from ansible.module_utils.basic import AnsibleModule
    from ansible.parsing.dataloader import DataLoader

    import os
    import shutil
    import sys
    import tempfile

    # Prepare the test setup
    # Create a temp

# Generated at 2022-06-23 13:07:47.568828
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()
    sm = StrategyModule(display)
    result = sm._host_pinned
    expected = True
    assert result == expected, "test_StrategyModule( constructor ) failed - expected {0}, got {1}".format( result, expected )

# Generated at 2022-06-23 13:07:48.099351
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:07:49.935541
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = object
    strategy = StrategyModule(tqm)
    print(strategy)

# Generated at 2022-06-23 13:08:00.906595
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.loader import strategy_loader, add_directory
    from ansible.plugins.strategy.copy import StrategyModule as copy_StrategyModule
    from ansible.plugins.strategy.debug import StrategyModule as debug_StrategyModule
    from ansible.plugins.strategy.free import StrategyModule as free_StrategyModule
    from ansible.plugins.strategy.linear import StrategyModule as linear_StrategyModule
    from ansible.plugins.strategy.many_loop import StrategyModule as many_loop_StrategyModule
    from ansible.plugins.strategy.smart import StrategyModule as smart_StrategyModule
    from ansible.plugins.strategy.one_by_one import StrategyModule as one_by_one_StrategyModule

# Generated at 2022-06-23 13:08:02.316448
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    module = StrategyModule(None)
    assert module._host_pinned

# Generated at 2022-06-23 13:08:05.798490
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    res = StrategyModule(23)
    assert(res._host_pinned == True)
    assert(res._tqm == 23)
    assert(res._inventory == None)
    assert(res._play == None)
    assert(res._variables == None)
    assert(res._loader == None)

# Generated at 2022-06-23 13:08:07.184990
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = None
    sm = StrategyModule(tqm)
    assert sm

# Generated at 2022-06-23 13:08:11.673357
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'tqm'
    strategy_instance = StrategyModule(tqm)
    if not strategy_instance._host_pinned:
        print("StrategyModule object instantiation did not work")
        assert False



# Generated at 2022-06-23 13:08:12.734420
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule


# Generated at 2022-06-23 13:08:13.889389
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # TBD
    assert True

# Generated at 2022-06-23 13:08:14.930224
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule('tqm')


# Generated at 2022-06-23 13:08:19.062003
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

    tqm = None
    sm = StrategyModule(tqm)
    assert sm._host_pinned

    sm = FreeStrategyModule(tqm)
    assert not sm._host_pinned

# Generated at 2022-06-23 13:08:20.605308
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()
    assert s._host_pinned == True

# Generated at 2022-06-23 13:08:26.983619
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    global tqm
    tqm = {}
    obj = StrategyModule(tqm) 
    # assert obj._play.play_hosts == hosts_list, "test_StrategyModule: host list test failed"
    # assert obj._play.tasks == tasks_list, "test_StrategyModule: task list test failed"
    assert obj._host_pinned == True, "test_StrategyModule: host pinned test failed"

test_StrategyModule()

# Generated at 2022-06-23 13:08:29.304920
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True


# Generated at 2022-06-23 13:08:30.991687
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)



# Generated at 2022-06-23 13:08:41.960230
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory import Inventory
    import ansible.constants as C
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=['jumper'])
    variable_manager = VariableManager()

# Generated at 2022-06-23 13:08:49.982535
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    inventory = InventoryManager(loader=None, sources="/etc/ansible/hosts")
    variable_manager.set_inventory(inventory)
    tqm = TaskQueueManager(inventory=inventory, variable_manager=variable_manager, loader=None, passwords=None)
    StrategyModule(tqm)

# Generated at 2022-06-23 13:08:52.530900
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_strategyModule = StrategyModule(None)
    assert test_strategyModule is not None

# Generated at 2022-06-23 13:08:54.223843
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    c = StrategyModule()
    assert c.__class__.__name__ == 'StrategyModule'
    assert c._host_pinned == True

# Generated at 2022-06-23 13:08:55.724193
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule
    assert sm(tqm) is not None

# Generated at 2022-06-23 13:08:56.691632
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None)

# Generated at 2022-06-23 13:09:01.924005
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy import StrategyModule
    from ansible.plugins.strategy.host_pinned import StrategyModule as HostPinnedStrategyModule
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import strategy_loader
    import ansible.plugins.loader as plugin_loader
    import ansible.plugins as plugins
    import ansible.executor.task_queue_manager as task_queue_manager
    import ansible.executor.process.worker as worker
    import ansible.module_utils.urls as urls
    import ansible.module_utils.six as six

    strategy = StrategyModule(task_queue_manager.TaskQueueManager())
    cs = HostPinnedStrategyModule(task_queue_manager.TaskQueueManager())

    assert isinstance(strategy, StrategyModule)

# Generated at 2022-06-23 13:09:04.484159
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # Test that an object is created of type StrategyModule()
    strategy_obj = StrategyModule()
    assert strategy_obj is not None

# Generated at 2022-06-23 13:09:05.456436
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:09:07.543865
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(tqm=None)
    assert strategy_module is not None
    assert strategy_module._host_pinned is True


# Generated at 2022-06-23 13:09:11.417004
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    test_strategy = StrategyModule(0)
    assert test_strategy is not None
    assert isinstance(test_strategy, StrategyModule)
    assert isinstance(test_strategy, FreeStrategyModule)


# Generated at 2022-06-23 13:09:19.033253
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    import mock
    import unittest
    import ansible.plugins
    from ansible.plugins.strategy.host_pinned import StrategyModule

    mock_tqm = mock.MagicMock()
    mock_tqm.__class__ = 'mock'
    mock_tqm.display = display = mock.MagicMock()
    assert isinstance(mock_tqm, object)
    target = StrategyModule(mock_tqm)
    assert isinstance(target.display, mock.MagicMock)


# Generated at 2022-06-23 13:09:21.540050
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    test_module = StrategyModule(tqm)
    assert isinstance(test_module, StrategyModule)

# Generated at 2022-06-23 13:09:22.569172
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()


# Unit test

# Generated at 2022-06-23 13:09:24.202499
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm = StrategyModule(tqm)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:09:26.488441
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule(tqm=None) is not None

if __name__ == '__main__':
    test_StrategyModule()

# Generated at 2022-06-23 13:09:29.200109
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule({})
    assert True == strategy_module._host_pinned

# Generated at 2022-06-23 13:09:29.792634
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:09:30.929807
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)

# Generated at 2022-06-23 13:09:32.566117
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ Test the constructor method of class StrategyModule """
    tqm = None
    StrategyModule(tqm)

# Generated at 2022-06-23 13:09:33.413984
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:09:35.314628
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__.__module__ == 'ansible.plugins.strategy.host_pinned'



# Generated at 2022-06-23 13:09:35.807058
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule()

# Generated at 2022-06-23 13:09:37.201590
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()
    assert obj

# Generated at 2022-06-23 13:09:37.854170
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:09:39.544335
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
  sm = StrategyModule(None)
  assert sm._host_pinned == True

# Generated at 2022-06-23 13:09:42.614603
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategymodule = StrategyModule(tqm=None)
    assert strategymodule._host_pinned == True

# vim: set expandtab tabstop=4 shiftwidth=4 softtabstop=4:

# Generated at 2022-06-23 13:09:51.989489
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule()
    assert obj != None

StrategyModule.calculate_block_list = FreeStrategyModule.calculate_block_list
StrategyModule.get_next_task_lock = FreeStrategyModule.get_next_task_lock
StrategyModule.count_unblocked_hosts_in_play = FreeStrategyModule.count_unblocked_hosts_in_play
StrategyModule.wipe_blocked_hosts = FreeStrategyModule.wipe_blocked_hosts
StrategyModule.is_task_included = FreeStrategyModule.is_task_included
StrategyModule.get_failed_hosts = FreeStrategyModule.get_failed_hosts
StrategyModule.remove_active_host = FreeStrategyModule.remove_active_host
StrategyModule.populate

# Generated at 2022-06-23 13:09:56.253715
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # create an object of the class being tested
    strategy_module = StrategyModule(None)
    # check if object has the right value of _host_pinned
    assert strategy_module._host_pinned is True

# Generated at 2022-06-23 13:09:58.815558
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__(StrategyModule, tqm='tqm') == None


# Generated at 2022-06-23 13:09:59.972645
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert callable(StrategyModule)

# Generated at 2022-06-23 13:10:00.677514
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:10:03.418533
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	StrategyModule(tqm = None)
	
# test for the method __init__ in class StrategyModule	

# Generated at 2022-06-23 13:10:05.963870
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module= StrategyModule(tqm= None)
    # Check if constructor set the variable _host_pinned to True
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:10:07.474020
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    display = Display()

    #Test constructor
    assert FreeStrategyModule()

# Generated at 2022-06-23 13:10:18.349171
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.executor import task_queue_manager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash

    host = Host(name="test-host")
    group = Group(name="test-group")
    group.add_host(host)
    inventory = Inventory(loader=DataLoader())
    inventory.add_group(group)


# Generated at 2022-06-23 13:10:19.141908
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule("tqm")

# Generated at 2022-06-23 13:10:21.152567
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from mock import Mock
    strategy_module = StrategyModule(Mock())
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:10:27.431389
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    from ansible.plugins.strategy.host_pinned import StrategyModule
    mock_tqm = []
    strategy_module = StrategyModule(mock_tqm)

    assert strategy_module._tqm == mock_tqm
    assert strategy_module._batch_size == 1
    assert strategy_module._inventory == None
    assert strategy_module._variables == None
    assert strategy_module._loader == None
    assert strategy_module._host_pinned == True
    assert strategy_module._play_context == None
    assert strategy_module._all_vars_of_children == None

# Generated at 2022-06-23 13:10:28.217922
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:10:30.502041
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(tqm=None)
    assert strategy._host_pinned == True


# Generated at 2022-06-23 13:10:34.306107
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    ret = StrategyModule("tqm")
    assert ret._host_pinned == True

# vim:set noet ts=4 sts=4 sw=4 tw=79

# Generated at 2022-06-23 13:10:36.017904
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    element=StrategyModule(tqm=None)
    assert element._host_pinned

# Generated at 2022-06-23 13:10:38.700956
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True == True


# Done
# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-23 13:10:42.071001
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    try:
        assert StrategyModule.__doc__
        assert StrategyModule.__init__
    except AssertionError as e:
        print('Test for constructor of class StrategyModule failed!')
        raise e

# Generated at 2022-06-23 13:10:43.954316
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    s = StrategyModule()
    assert s._host_pinned == True

# Generated at 2022-06-23 13:10:45.803921
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert issubclass(StrategyModule, FreeStrategyModule)
    sm = StrategyModule(tqm=None)
    assert sm._host_pinned == True

# Generated at 2022-06-23 13:10:47.652725
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_obj = StrategyModule('tqm')
    assert hasattr(strategy_obj, '_host_pinned') and strategy_obj._host_pinned == True

# Generated at 2022-06-23 13:10:48.755043
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    """ Test StrategyModule constructor """

    strategy_module = StrategyM

# Generated at 2022-06-23 13:10:49.366758
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:10:52.339320
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert(StrategyModule)


# unit test for method __init__ of class StrategyModule

# Generated at 2022-06-23 13:10:55.276535
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    tqm = 'none'
    strategy_module = StrategyModule(tqm)
    assert isinstance(strategy_module, StrategyModule)
    assert strategy_module._host_pinned

# Generated at 2022-06-23 13:10:57.930722
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategymodule = StrategyModule(tqm)
    assert strategymodule._host_pinned

# Generated at 2022-06-23 13:10:59.232154
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule._host_pinned == True

# Generated at 2022-06-23 13:11:00.711366
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-23 13:11:02.714921
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    obj = StrategyModule('tqm')
    assert obj is not None

# Generated at 2022-06-23 13:11:03.848161
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    Strategy_obj = StrategyModule(tqm)

# Generated at 2022-06-23 13:11:06.763412
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    TASK_QUEUE_MANAGER = Any()
    strategy_module = StrategyModule(TASK_QUEUE_MANAGER)
    assert strategy_module._host_pinned == True



# Generated at 2022-06-23 13:11:16.450460
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["testing/inventory"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    display = Display()
    Options = None
    variable_manager.extra_vars = {'hosts': 'webservers'}
    passwords = dict()


# Generated at 2022-06-23 13:11:17.131931
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule
    StrategyModule()

# Generated at 2022-06-23 13:11:20.314719
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
	a=StrategyModule(1)

# Test that method StrategyModule.__init__() returns an instance of class StrategyModule

# Generated at 2022-06-23 13:11:22.666229
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module = StrategyModule(None)
    assert strategy_module._host_pinned == True

# Generated at 2022-06-23 13:11:28.215690
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    sm1 = StrategyModule()
    assert sm1._host_pinned == True
    assert sm1.get_host_list() == []
    assert sm1.get_next_task_lockfree() == None
    assert sm1.push_task_result() == None
    assert sm1.run() == None

# Generated at 2022-06-23 13:11:29.629832
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy_module=StrategyModule(tqm)

# Generated at 2022-06-23 13:11:30.402735
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:11:32.406319
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    # we expect at least one argument
    assert StrategyModule


# Check if we can import the ansible.module_utils.six library

# Generated at 2022-06-23 13:11:33.301273
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass

# Generated at 2022-06-23 13:11:34.420260
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    pass



# Generated at 2022-06-23 13:11:35.121579
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert True

# Generated at 2022-06-23 13:11:36.896933
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    strategy = StrategyModule(None)
    assert strategy._host_pinned == True
    assert strategy.display.verbosity == 3

# Generated at 2022-06-23 13:11:38.021549
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule

# Generated at 2022-06-23 13:11:44.778657
# Unit test for constructor of class StrategyModule
def test_StrategyModule():

    # Arrange
    tqm = None

    # Act
    strategy = StrategyModule(tqm)

    # Assert
    expected_host_pinned = True
    actual_host_pinned = strategy._host_pinned
    assert actual_host_pinned == expected_host_pinned, "Constructor of class StrategyModule did not set the variable '_host_pinned' correctly"

# Generated at 2022-06-23 13:11:46.615265
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule



# Generated at 2022-06-23 13:11:48.771704
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule
    

# Generated at 2022-06-23 13:11:49.502553
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    StrategyModule(None)

# Generated at 2022-06-23 13:11:50.686428
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__init__()


# Generated at 2022-06-23 13:11:52.244004
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    from ansible.plugins.strategy.host_pinned import StrategyModule


# Generated at 2022-06-23 13:11:55.670491
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    assert StrategyModule.__doc__ == '''Executes tasks on each host without interruption'''
    t = StrategyModule(tqm)
    assert t._host_pinned == True

# Generated at 2022-06-23 13:12:05.551728
# Unit test for constructor of class StrategyModule
def test_StrategyModule():
    hostname = '127.0.0.1'
    play_context = {
        'become': False,
        'become_method': 'sudo',
        'become_user': None,
        'connection': 'smart',
        'diff': False,
        'forks': 10,
        'inventory': None,
        'limit': None,
        'remote_user': 'root',
        'serial': False,
        'tags': None,
        'verbosity': 0,
        'version': None
    }
    inventory = None
    variable_manager = None
    loader = None
    callback = None
    options = None
    shared_loader_obj = None
    variable_manager = None
    loader = None
    display = None
    options = None
    tqm = None