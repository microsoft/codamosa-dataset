

# Generated at 2022-06-25 08:26:21.972625
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    callback_module_0 = CallbackModule()
    result_0 = RunnerResult()
    result_0.__init__()
    result_0._task = 'setup'
    result_0._host = 'ansible-tower'
    result_0._result = {}
    result_0._result['ansible_job_id'] = '704025819169.4420'
    result_0._result['attempts'] = 1
    result_0._result['changed'] = False
    result_0._result['invocation'] = {'module_args': {'_raw_params': '', '_uses_shell': False, '_tunnel': None, 'command': 'echo 12345', 'creates': None, 'executable': None, 'removes': None, 'warn': True}, 'module_name': 'command'}


# Generated at 2022-06-25 08:26:25.219102
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_skipped(None)


# Generated at 2022-06-25 08:26:35.566110
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-25 08:26:38.537706
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    task_0 = Task()
    result_0 = Result(task_0)
    callback_module_0 = CallbackModule(display_ok_hosts = False)
    callback_module_0.v2_runner_item_on_ok(result_0)
    assert len(callback_module_0._last_task_banner) == len('00000000-0000-0000-0000-000000000000')


# Generated at 2022-06-25 08:26:43.076413
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = Result(host='host_0', task='task_0', task_result=None, role_name=None)
    result_0._host = 'host_0'
    result_0._task = 'task_0'
    try:
        callback_module_0.v2_runner_on_failed(result=result_0)
    except AttributeError:
        raise AssertionError(result_0._task)
    except NameError:
        raise AssertionError(result_0._task)


# Generated at 2022-06-25 08:26:51.484548
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_1 = CallbackModule()
    # set_options sets value for an argument with default value
    callback_module_1.set_options(display_skipped_hosts=True)
    assert callback_module_1._display.verbosity == 0
    callback_module_1.set_options(display_ok_hosts=False)
    assert callback_module_1.check_mode_markers == False
    callback_module_1.set_options(display_failed_stderr=True)
    assert callback_module_1.display_failed_stderr == True
    callback_module_1.set_options(show_custom_stats=True)
    assert callback_module_1.show_custom_stats == True
    callback_module_1.set_options(display_skipped_hosts=False)


# Generated at 2022-06-25 08:26:54.144793
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module = CallbackModule()
    callback_module.set_options()
    callback_module.show_custom_stats = True
    callback_module.show_custom_stats = False



# Generated at 2022-06-25 08:27:04.008803
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    display_0 = CallbackModule_Display(None)
    runner_result_0 = RunnerResult()
    runner_result_0._task = dict()
    runner_result_0._task['action'] = 'a string'
    runner_result_0._task['name'] = 'a string'
    runner_result_0._result = dict()
    runner_result_0._result['_ansible_no_log'] = False
    runner_result_0._host = dict()
    runner_result_0._host['name'] = 'a string'
    runner_result_0._host['id'] = 'a string'
    runner_result_0._host['uuid'] = 'a string'
    runner_result_0._host['hostname'] = 'a string'
    runner

# Generated at 2022-06-25 08:27:07.134179
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    task_name = 'Ansible Async Task'
    ansible_job_id = 'ansible_job_id'
    started = 'started'
    finished = 'finished'
    result = Result(task_name, ansible_job_id, started, finished)
    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_on_async_poll(result)


# Generated at 2022-06-25 08:27:14.361245
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # initialize callback module and display
    callback_module_0 = CallbackModule()
    callback_module_0._display = Display()
    callback_module_0._display.verbosity = 2

    # create result object
    result_0 = Result()
    result_0._task = Task()
    result_0._host = Host()
    result_0._host.get_name = lambda: 'host'
    result_0._task.action = 'setup'    # action of task
    result_0._result = {'changed': True, 'failed': True, 'msg': 'Task failed!', 'exception': 'Task failed!'}

    # method to test
    callback_module_0.v2_runner_on_failed(result_0)

    # assert result
    # TODO: assert output


# Generated at 2022-06-25 08:28:09.703528
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    # Create CallbackModule object
    callback_module_1 = CallbackModule()

    # Create a result object containing information about the runner
    result_1 = AnsibleResult(result_data={"invocation": {"module_name": ""}})

    # Call method
    result = callback_module_1.v2_runner_on_failed(result=result_1)
    assert result is None



# Generated at 2022-06-25 08:28:14.013013
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    play = MagicMock()
    play.get_name.return_value = 'test1'
    callback_module_1 = CallbackModule()
    callback_module_1.v2_playbook_on_play_start(play)
    callback_module_1.v2_playbook_on_include('test')


# Generated at 2022-06-25 08:28:19.294735
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    callback_module = CallbackModule()
    # Note that we need to mock the real AnsibleTaskResult class, which means we need to mock the real
    # AnsibleHostResult class and AnsibleTask class.
    result = MagicMock()
    result.task_name = 'The Name of The Task'
    result._task = MagicMock()
    result._host = MagicMock()
    result._host.get_name.return_value = 'The Name of The Host'
    result._result = dict([('retries', 2), ('attempts', 1)])
    callback_module.v2_runner_retry(result)


# Generated at 2022-06-25 08:28:28.421162
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    # Test case for method v2_runner_item_on_failed
    # Test case for no result
    # Test case for no task
    # Test case for no host
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    result = AnsibleUnsafeText("""{
        "failed": true,
        "msg": "Could not find the requested service systemd: ssh: (systemd:ssh)",
        "changed": false,
        "unreachable": true
    }""")

    host = AnsibleUnsafeText("localhost")


# Generated at 2022-06-25 08:28:36.964800
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    # Create objects
    callback_module_0 = CallbackModule()
    result_0 = ansible_module_runner.Result(host=None, task=None, result=None)

    # Check (un)reachability
    callback_module_0._last_task_banner = "1"
    callback_module_0._task_type_cache = {}
    callback_module_0.display_skipped_hosts = False
    callback_module_0.v2_runner_on_skipped(result_0)
    callback_module_0.display_skipped_hosts = True


# Generated at 2022-06-25 08:28:38.783101
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    callback_module_0 = CallbackModule()
    play_0 = Play()
    callback_module_0.v2_playbook_on_play_start(play_0)


# Generated at 2022-06-25 08:28:41.822614
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    # test with no arguments
    callback_module_v2_runner_on_async_failed_t0 = CallbackModule()
    callback_module_v2_runner_on_async_failed_t0.v2_runner_on_async_failed()


# Generated at 2022-06-25 08:28:46.739697
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    import mock
    import random

    callback_module_0 = CallbackModule()

    result_0 = mock.MagicMock()
    result_0._task = mock.MagicMock()
    result_0._host = mock.MagicMock()
    result_0._host.get_name.return_value = "fake host"
    result_0.task_name = random.choice(['UNIT TESTING', 'Unit Testing'])
    result_0._result = {'item': 'bananas', 'UNIT_TESTING_STATE': 'FAIL'}

    callback_module_0.v2_runner_item_on_skipped(result_0)


# Generated at 2022-06-25 08:28:52.764491
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    callback_module_0 = CallbackModule()
    # task_action = None
    # result = None
    # task_name = None
    # task_args = None
    # task_kwargs = None
    # task_name_0 = None
    # task_args_0 = None
    # task_kwargs_0 = None
    # task_vars = None
    # host = None
    # play_context = None
    # play_context_0 = None
    # result_0 = None
    # host_label = None
    # msg = None
    # color = None
    # color_0 = None
    # self._run_is_verbose = None
    # self._dump_results = None
    # print("\n-- v2_runner_item_on_ok --\n")
    # callback

# Generated at 2022-06-25 08:29:04.283911
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    #
    #     A TEST PLAN
    #
    #     I will create a CallbackModule instance and set its options
    #     by calling set_options method.
    #
    cb_module_0 = CallbackModule()
    #
    #     Set CallbackModule.check_mode_markers option to False
    #
    assert cb_module_0.check_mode_markers == True
    cb_module_0.set_options(check_mode_markers=False)
    assert cb_module_0.check_mode_markers == False
    #
    #     Set CallbackModule.display_failed_stderr option to True
    #
    assert cb_module_0.display_failed_stderr == False

# Generated at 2022-06-25 08:31:18.943776
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()
    context.CLIARGS = {'args': ['h1'], 'verbosity': True}
    callback_module_1.v2_playbook_on_start('playbook')


# Generated at 2022-06-25 08:31:21.981806
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    str_0 = 'CallbackModuleTest0.yml'
    mock_playbook_0 = create_autospec(Playbook, instance=True)
    callback_module_0.v2_playbook_on_start(mock_playbook_0)


# Generated at 2022-06-25 08:31:27.829119
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_1 = CallbackModule()
    callback_module_1.set_options(merge_hash={'1':2, '3':4})
    key_set_1 = {'1', '3'}
    assert key_set_1 == set(callback_module_1._options.keys())
    value_set_1 = {2, 4}
    assert value_set_1 == set(callback_module_1._options.values())
    callback_module_2 = CallbackModule()
    callback_module_2.set_options({'1': 2, '3': 4})
    key_set_2 = {'1', '3'}
    assert key_set_2 == set(callback_module_2._options.keys())
    value_set_2 = {2, 4}
    assert value_set

# Generated at 2022-06-25 08:31:31.019713
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    c = CallbackModule()
    c.v2_runner_on_async_ok(result)
    if not result._result['ansible_job_id']:
        return False
    return True


# Generated at 2022-06-25 08:31:33.779164
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    callback_module = CallbackModule()
    mock_play = MagicMock()
    mock_play.check_mode = False
    def _get_name():
        return "test_play_name"
    mock_play.get_name = _get_name
    callback_module.v2_playbook_on_play_start(mock_play)


# Generated at 2022-06-25 08:31:38.968328
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    callback_module_1 = CallbackModule()
    result_1 = Result()
    result_1.task_name = 'task_name_1'
    result_1._task = '_task_1'
    result_1._result = {'retries': 10, 'attempts': 0, 'exception': 'exception_1'}
    callback_module_1.v2_runner_retry(result_1)


# Generated at 2022-06-25 08:31:43.288696
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Create stub for class Playbook()
    class Playbook_obj(object):
        def _file_name(self):
            return 'test_value_0'
    Playbook_obj = Playbook_obj()
    callback_module_0 = CallbackModule(playbook=Playbook_obj)
    print(callback_module_0.v2_playbook_on_start(Playbook_obj))


# Generated at 2022-06-25 08:31:50.283240
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    callback_module_0 = CallbackModule()

    # Test for the case when 'ansible_job_id' is present in result._result
    result_0 = None
    result_0._host.get_name.return_value = "test"
    result_0._result = { 'ansible_job_id': "test" }
    result_0._result.get.return_value = "test"

    callback_module_0.v2_runner_on_async_failed(result_0)

    # Test for the case when 'ansible_job_id' is not present in result._result,
    # but 'async_result' is present and contains 'ansible_job_id'
    result_1 = None
    result_1._host.get_name.return_value = "test"
    result_1._

# Generated at 2022-06-25 08:31:54.006624
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    callback_module_1 = CallbackModule()
    host_0 = Host()
    task_0 = TaskInclude()
    result_tuple_0 = callback_module_1.v2_runner_on_start(host_0, task_0)
    del callback_module_1
    del host_0
    del task_0
    del result_tuple_0


# Generated at 2022-06-25 08:32:00.465316
# Unit test for method v2_on_file_diff of class CallbackModule