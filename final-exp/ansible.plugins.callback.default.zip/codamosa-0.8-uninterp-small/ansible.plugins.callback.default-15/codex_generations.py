

# Generated at 2022-06-25 08:26:21.642481
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    # GIVEN
    callback_module_0 = CallbackModule()
    result_0 = MockTaskResult()

    # WHEN
    callback_module_0.v2_runner_on_async_ok(result_0)

    # THEN
    # Check if method v2_runner_on_async_ok was called properly
    callback_module_0._display.display.assert_called_with("ASYNC OK on %s: jid=%s" % (result_0._host.get_name(), result_0._result.get('ansible_job_id')), color=C.COLOR_DEBUG)


# Generated at 2022-06-25 08:26:29.929578
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():

    # Setup
    callback_module = CallbackModule()
    # Create object of class CallbackModule.
    callback_module.__init__()

    # Create object for class Result
    result = {}
    result = Result()

    # Create object for class Task
    task = {}
    task = Task()

    # Manipulate object for class Task
    task.no_log = True

    # Create object for class TaskInclude
    task_include = {}
    task_include = TaskInclude()

    result._task = task
    result._task = task_include


# Generated at 2022-06-25 08:26:36.616907
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    result_0 = {
        '_diff': {
            'after': 'hello\n',
            'before': 'world\n'
        },
        '_ansible_no_log': False,
        'changed': True
    }

    callback_module_0 = CallbackModule()
    callback_module_0.v2_on_file_diff(result_0)

if __name__ == "__main__":
    test_CallbackModule_v2_on_file_diff()

# Generated at 2022-06-25 08:26:42.675675
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    task_name = 'foo'
    host_address = 'bar'
    host_name = 'baz'
    ansible_job_id = 'job_id'
    started = '2018/05/11'
    finished = '2018/05/12'
    
    task = Task()
    task.name = task_name
    host = Host()
    host.name = host_name
    host.address = host_address
    
    result = Result()
    result.task_name = task_name
    result._task = task
    result._host = host
    
    result._result = dict()
    result._result['ansible_job_id'] = ansible_job_id
    result._result['started'] = started
    result._result['finished'] = finished
    
    callback_module = CallbackModule()

# Generated at 2022-06-25 08:26:43.651579
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:26:54.689498
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-25 08:27:02.856054
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    callback_module_0 = CallbackModule()
    task = Task()
    task._uuid = '36397a59-9953-4c4e-b469-4a4c4d4f9db4'
    task._role = None
    task._task_deps = []
    task._block = None
    task._role_name = ''
    task._play = Play()
    task._play._playbook = Playbook()
    task._play._playbook._loader = None
    task._play._playbook.inventory = Inventory()

# Generated at 2022-06-25 08:27:08.111870
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.plugins import PluginLoader

    # con = ansible.plugins.connection.local.LocalConnection()
    con = ansible.plugins.connection.paramiko_ssh.Connection( 2 , 1 )
    options = namedtuple('options', ['connection', 'module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'diff', 'remote_user'])

# Generated at 2022-06-25 08:27:09.722203
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    callback_module_0.set_options(['verbosity=2'])
    assert callback_module_0.verbosity == 2;


# Generated at 2022-06-25 08:27:14.243704
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    option1 = 'option1'
    value1 = 'value1'
    option2 = 'option2'
    value2 = 'value2'
    options = {option1:value1, option2:value2}
    callback_module_0.set_options(options)


# Generated at 2022-06-25 08:28:30.380413
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    callback_module_0 = CallbackModule()
    host_0 = Host(name='localhost')
    task_0 = Task()
    callback_module_0.v2_runner_on_start(host=host_0, task=task_0)


# Generated at 2022-06-25 08:28:39.195894
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    '''
    Unit test for method v2_runner_item_on_failed of class CallbackModule
    '''

    callback_module_0 = CallbackModule()

    Bunch_0 = collections.namedtuple('Bunch', 'orig_result set_callee loading blocked')


# Generated at 2022-06-25 08:28:41.784086
# Unit test for method v2_playbook_on_stats of class CallbackModule

# Generated at 2022-06-25 08:28:45.267387
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    result = Result()
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_item_on_failed(result)


# Generated at 2022-06-25 08:28:50.947338
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_on_unreachable("host", "result_dict")


# Generated at 2022-06-25 08:29:02.596342
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    """
    Code Coverage Note:
    Tests for v2_runner_on_unreachable of class CallbackModule

    """
    print("Testing method v2_runner_on_unreachable of class CallbackModule")
    callback_module_instance = CallbackModule()
    result_0 = dict()
    result_0['ansible_job_id'] = 'ansible_job_id_0'
    result_0['changed'] = False
    result_0['failures'] = set()
    result_0['parsed'] = False
    result_0['skipped'] = set()
    result_0['stat'] = dict()
    result_0['stat']['exists'] = False
    result_0['stat']['isdir'] = False
    result_0['stat']['ischr'] = False


# Generated at 2022-06-25 08:29:09.493611
# Unit test for method v2_runner_item_on_failed of class CallbackModule

# Generated at 2022-06-25 08:29:17.988682
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    import mock
    import os
    import tempfile
    import yaml

    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    # Mock objects
    mock_loader = mock.create_autospec(DataLoader)
    mock_variable_manager = mock.create_autospec(VariableManager)
    mock_host = mock.create_autospec(Host)
    mock_hostvars = mock.create_autospec(HostVars)

    # Create temporary file to use as dummy playbook
    fd, temp_fp = tempfile.mkstemp()
    os.close(fd)

    # Create a temp directory to use as dummy path_

# Generated at 2022-06-25 08:29:19.491252
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_item_on_failed("failed")


# Generated at 2022-06-25 08:29:22.569331
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    callback_module_0 = CallbackModule()
    task_0 = Task()
    result_0 = RunnerResult()
    result_0._task = task_0
    callback_module_0.display_skipped_hosts = bool()
    callback_module_0.v2_runner_on_skipped(result_0)


# Generated at 2022-06-25 08:30:18.030140
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:30:19.742398
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    test_case_0()

if __name__ == '__main__':
    test_CallbackModule_set_options()

# Generated at 2022-06-25 08:30:26.491222
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    # Creating test objects
    callback_module_1 = CallbackModule()
    fake_stats_1 = FakeStats()

    # Testing without assertions
    callback_module_1.show_custom_stats = False
    fake_stats_1.custom = None
    callback_module_1.v2_playbook_on_stats(fake_stats_1)

    callback_module_1.show_custom_stats = False
    fake_stats_1.custom = {}
    callback_module_1.v2_playbook_on_stats(fake_stats_1)

    callback_module_1.show_custom_stats = True
    fake_stats_1.custom = None
    callback_module_1.v2_playbook_on_stats(fake_stats_1)

    callback_module_1.show_custom_stats = True

# Generated at 2022-06-25 08:30:35.554989
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    mock_host_0 = Mock()
    mock_host_0._host = "localhost"
    mock_host_0.get_name = Mock(return_value=mock_host_0._host)
    mock_result_0 = Mock()
    mock_result_0._host = mock_host_0
    mock_result_0._result = {
        "ansible_job_id": "async_failed_job_id",
        "async_result": {
            "ansible_job_id": "async_failed_job_id_in_result"
        }
    }

    callback_module_0 = CallbackModule()
    result_0 = callback_module_0.v2_runner_on_async_failed(mock_result_0)


# Generated at 2022-06-25 08:30:44.457274
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    # instantiate callback module
    callback_module_0 = CallbackModule()
    # instantiate result object
    # get host object
    # set flag to enable running of skipped tasks
    # set flag to display verbosity
    # create task result object
    # set item to 'test'
    # set task name to 'test task name'
    # create dictionary object
    # set string object
    # set string object
    # set string object
    # set string object
    # set flag to dict object
    # set string object
    # set string object
    # set boolean object to dict object
    # set dict object to item
    # invoke method
    callback_module_0.v2_runner_on_skipped(
       result_0
    )

# Generated at 2022-06-25 08:30:47.085760
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    callback_module_1 = CallbackModule()
    # This is just a placeholder, as this method is empty
    assert 0 == callback_module_1.v2_playbook_on_stats(None)


# Generated at 2022-06-25 08:30:53.813449
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # The test case is also used to check the output format.
    # According to the output format, the test case is complex.

    # Test case:
    callback_module_1 = CallbackModule()
    callback_module_1.v2_playbook_on_start(playbook=None)

    # Expected output:
    # PLAYBOOK:
    #
    # ARGS:
    #
    # Option 1:
    # Positional arguments:
    # check:
    # connection: smart
    # forks: None
    # listhosts:
    # listtasks:
    # listtags:
    # syntax:
    # private_key_file:
    # step:
    # su:
    # sudo:
    # sudo_user:
    # user:
    # verbosity:

    # Option 2:


# Generated at 2022-06-25 08:30:58.363202
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    result = Result()
    result._host = Host()
    result._host.name = '127.0.0.1'
    result._result = dict()
    result._result['retries'] = 3
    result._result['attempts'] = 1
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_retry(result)


# Generated at 2022-06-25 08:31:05.446627
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
	# Init
        # Init
    callback_module_0 = CallbackModule()
    result_0 = Mock()
    result_0.exception = "an exception"
    expected  = "An exception occurred during task execution. The full traceback is:"
    res = callback_module_0.v2_runner_on_unreachable(result_0)
    assert(res==expected)


# Generated at 2022-06-25 08:31:07.414183
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_on_start(None, None)


# Generated at 2022-06-25 08:31:55.210451
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:32:01.540439
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    callback_module_0 = CallbackModule()
    # test initializing the playbook
    callback_module_0.init_playbook()
    # test initializing the play
    callback_module_0.init_play()
    # test generating the path of task

# Generated at 2022-06-25 08:32:02.510171
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    # v2_playbook_on_include(included_file)
    pass


# Generated at 2022-06-25 08:32:04.834094
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    print('TestCase: CallbackModule v2_runner_on_start')
    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_on_start(host=None,task=None)


# Generated at 2022-06-25 08:32:09.809764
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    result = Result()

    # Test for verbosity level 1
    context.CLIARGS = {'verbosity': 1}
    context.CLIARGS['display_skipped_hosts'] = False
    result._host = FakeHost("TEST_HOST_0")
    result._task = FakeTask("TEST_TASK_0", 'TEST_ACTION')
    result._result = {'skipped': False, 'msg': "Example message"}
    callback_module_1 = CallbackModule()
    callback_module_1._task_type_cache = {result._task._uuid: 'TEST_TASK_TYPE_0'}
    callback_module_1._last_task_banner = "TEST_TASK_UUID_BANNER_0"
    callback_module_1.v2

# Generated at 2022-06-25 08:32:21.041354
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    callback_module_0 = CallbackModule()
    stat = Stats()
    inventory = Inventory(loader=None, variables=None, host_list=None)
    play_source = {'name': '', 'hosts': 'localhost, remotehost', 'gather_facts': 'no', 'tasks': [{'action': {'__ansible_module__': 'test_module', '__ansible_arguments__': [], '__ansible_action__': 'test_module'}, 'register': 'test'}]}
    play = Play().load(play_source, variable_manager=None, loader=None)
    tqm = None
    callback_module_0.v2_playbook_on_stats(stats=stat)

# Generated at 2022-06-25 08:32:29.324615
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module = CallbackModule()
    # option is not defined
    callback_module.set_options(option=None, value='foo')
    assert callback_module.display_failed_stderr == False
    assert callback_module.display_skipped_hosts == False
    assert callback_module.display_ok_hosts == True
    assert callback_module.show_custom_stats == False
    assert callback_module.show_ignore_tags == False
    assert callback_module.show_only_tags == False
    assert callback_module.show_ignore_only_tags == False
    assert callback_module.skip_tags_on_retry == False
    assert callback_module.check_mode_markers == False
    assert callback_module.last_task_banner == False
    assert callback_module.show_task_defaults

# Generated at 2022-06-25 08:32:32.282839
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    # Define empty result to test the method
    result = ""
    # Create the object
    callback_module_0 = CallbackModule()
    # Call the method to test it
    callback_module_0.v2_runner_on_unreachable(result)


# Generated at 2022-06-25 08:32:34.967989
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    # Ask for a callback module object with verbosity = 1
    callback_module_0 = CallbackModule(display=CallbackModuleDisplay())
    # Pre-processing
    handler_0 = {}
    host_0 = "10.69.128.224"
    # Invoke call
    callback_module_0.v2_playbook_on_notify(handler_0, host_0)
    # Post-processing
    # No post-processing


# Generated at 2022-06-25 08:32:35.714663
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    pass


# Generated at 2022-06-25 08:33:36.488175
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    callback_module_0 = CallbackModule()
    result_0 = Result(host=Host(name='localhost'), task=None, task_result='2', retries=2, attempts=1)
    try:
        callback_module_0.v2_runner_retry(result_0)
    except:
        return False
    return True

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 08:33:45.490721
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    callback_module_0 = CallbackModule()
    pb_v2_playbook_running = type('pb_v2_playbook_running', (object,), {'DEFAULT_NAME': 'name_2312062640', 'dir': '/dir_123203743'})
    pb_v2_play = type('pb_v2_play', (object,), {'_variable_manager': {}, '_file_name': 'file_name_1954640140'})

# Generated at 2022-06-25 08:33:50.347203
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    def test_case():
        runner_result = Result()
        runner_result.task_name = 'test_task_name'
        runner_result._task = 'test_task'
        runner_result._host = Host('test_host', port=22)
        runner_result._result = {'attempts': 2, 'retries': 3}
        callback_module = CallbackModule()
        callback_module.display = Display()
        callback_module.v2_runner_retry(runner_result)

    test_case()


# Generated at 2022-06-25 08:33:52.460053
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook = ansible.parsing.dataloader.DataLoader()
    callback_module_0.v2_playbook_on_start(playbook)


# Generated at 2022-06-25 08:33:58.577394
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_unreachable(result=None)


# Generated at 2022-06-25 08:34:09.941484
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    callback_module_0 = CallbackModule()
    ansible_result = AnsibleResult()
    ansible_result.hosts = {'localhost': {}}
    ansible_result.hosts['localhost']['hostname'] = 'localhost'
    ansible_result.hosts['localhost']['ipv4'] = '127.0.0.1'
    ansible_result.hosts['localhost']['ipv6'] = '::1'
    ansible_result.hosts['localhost']['inventory_hostname'] = 'localhost'
    ansible_result.hosts['localhost']['module_name'] = 'ping'
    ansible_result.hosts['localhost']['playbook_filename'] = 'playbook.yml'

# Generated at 2022-06-25 08:34:15.601525
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    print('Test: CallbackModule: v2_runner_retry.')
    callback_module_1 = CallbackModule()
    result = Result()
    result.task_name = 'ping'
    result._task = 'ping'
    result._host = Host('host_1')
    result._result = {'attempts': 1, 'retries': 2}
    callback_module_1.v2_runner_retry(result)


# Generated at 2022-06-25 08:34:17.296511
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    return callback_module_0.v2_playbook_on_start(None)


# Generated at 2022-06-25 08:34:23.054880
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_1 = CallbackModule()
    result = Result(None, 
                    'localhost',
                    'localhost',
                    {
                            'changed': True,
                            'rc': 0,
                            'failed': False,  # failed: 表示模块执行成功还是失败
                            'warnings': [],
                            'msg': 'success'  # msg: 模块执行成功后的信息
                    },
                    'ansible.module_name')
    callback_module_1.v2_runner_on_ok(result=result)



# Generated at 2022-06-25 08:34:26.176870
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    # test_case_1: Invoke v2_runner_on_async_failed with no parameters
    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_on_async_failed()


# Generated at 2022-06-25 08:35:32.827199
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    callback_module_0 = CallbackModule()

    # backup old attr
    old_included_file = getattr(callback_module_0, 'included_file', None)

    # test case begin
    callback_module_0.included_file = None
    # test code begin
    callback_module_0.v2_playbook_on_include(callback_module_0.included_file)
    # test code end

    # restore old attr
    if old_included_file is not None:
        setattr(callback_module_0, 'included_file', old_included_file)


# Generated at 2022-06-25 08:35:44.226396
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # create test object of result
    result_0 = Result(None, None, None)
    result_0._result = {
        'changed':False,
        'rc':0,
        'stderr':'',
        'stderr_lines':[
            ''
        ],
        'stdout':'',
        'stdout_lines':[
            ''
        ]
    }

    # create test object of callback module
    callback_module_0 = CallbackModule()

    # set the object of callback module to the object of result
    result_0._task = callback_module_0
    result_0._host = callback_module_0
    result_0._task._uuid = callback_module_0._last_task_banner

    # call v2_runner_on_ok of callback module
    callback_module