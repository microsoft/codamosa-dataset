

# Generated at 2022-06-25 08:26:15.352054
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    fake_result = FakeResult()
    fake_result._task = FakeTask('test_task')
    fake_result._result = {'stderr':'Error:', 'msg':'failure message', 'failed':True}

    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_item_on_failed(fake_result)

if __name__ == '__main__':
    test_CallbackModule_v2_runner_item_on_failed()

# vim: ai et ts=4 sts=4 sw=4 ft=python fileencoding=utf-8

# Generated at 2022-06-25 08:26:18.191836
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    task_result_0 = TaskResult()
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:26:29.166700
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    print("Running CallbackModule_v2_runner_item_on_failed")
    callback_module_1 = CallbackModule()
    result = {'_ansible_verbose_always': True}
    result['_ansible_verbose_override'] = True
    result['_ansible_verbose_override'] = True

# Generated at 2022-06-25 08:26:38.834980
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    # Run the program for 1 try
    for tries in range(0,1):
        # Create the expected result:
        expected_result = dict()
        expected_result['stdout'] = ''
        expected_result['stderr'] = ''
        # Create a callback_module_1 instance:
        callback_module_1 = CallbackModule()
        # Create the result:
        result = dict()
        # Create the host:
        host = dict()
        host['name'] = 'test_host_0'
        # Create the task instance:
        task = dict()
        # Create the task_instance:
        task_instance = dict()
        # Call the v2_runner_on_unreachable method of callback_module_1 instance:

# Generated at 2022-06-25 08:26:41.927673
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    result = MockResult()
    result._result = {'changed': True}

    callback_module_0 = CallbackModule()
    callback_module_0._last_task_banner = 1
    callback_module_0._last_task_name = 'MOCK TASK NAME'

    callback_module_0.v2_runner_on_ok(result)


# Generated at 2022-06-25 08:26:52.422500
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    callback_module_1 = CallbackModule()
    s = StringIO()
    callback_module_1._display = Display(verbosity=0, stdout_handle=s)
    callback_module_1._last_task_banner = 0
    class task(object):
        def __init__(self):
            self.no_log = False
            self.action = 'shell'
            self.args = {}
            self._uuid = 0
    result = task()

# Generated at 2022-06-25 08:26:57.628236
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    callback_module_0 = CallbackModule()
    result_0 = Mock()
    result_0._host = Mock()
    result_0._host.get_name.side_effect = lambda : 'ansible-controller'
    result_0._result = {'ansible_job_id': '129'}
    callback_module_0.v2_runner_on_async_failed(result_0)


# Generated at 2022-06-25 08:26:59.647186
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    callback_module_1 = CallbackModule()
    handler_1 = dict()
    host_1 = dict()
    callback_module_1.v2_playbook_on_notify(handler_1, host_1)


# Generated at 2022-06-25 08:27:01.448806
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    callback_module = CallbackModule()
    display = CallbackModule.display
    callback_module.v2_runner_retry(None)



# Generated at 2022-06-25 08:27:06.070696
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    callback_module_0 = CallbackModule()
    class Test:
        task = Test_task_0
        def __init__(self, task):
            self.task = task
            self._result = {}
    class Test_task_0():
        def __init__(self):
            self.action = 'test_action'
    class Test_host_0():
        def get_name(self):
            return 'test_host_name'
    callback_module_0.v2_runner_item_on_failed(Test(Test_task_0()))


# Generated at 2022-06-25 08:27:30.976119
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():

    callback_module_1 = CallbackModule()

    result = MockResult()

    callback_module_1.v2_runner_on_unreachable(result)


# Generated at 2022-06-25 08:27:33.625815
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    callback_module_0 = CallbackModule()
    result_0 = {}
    result_0 = result_0
    callback_module_0.v2_runner_on_async_failed(result_0)


# Generated at 2022-06-25 08:27:35.579275
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_retry(None, None)


# Generated at 2022-06-25 08:27:45.681632
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    import mock
    import pytest
    import os
    import sys
    import imp
    import six
    import ansible.playbook.play_context
    import ansible.constants
    result = mock.Mock()
    result.task_name = 'ping'
    result._task = 'ping'
    result._host = 'localhost'
    result._result = dict()
    result._result['retries'] = 5
    result._result['attempts'] = 1
    result._result['retry_files_save_path'] = '/tmp'
    result._result['invocation'] = dict()
    result._result['invocation']['module_name'] = 'ping'
    result._result['invocation']['module_args'] = 'hello'
    result._result['invocation']['module_complex_args']

# Generated at 2022-06-25 08:27:48.244665
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    callback_module = CallbackModule()
    expected = None
    actual = None
    assert expected == actual, "Result mismatch: expected=%s actual=%s" % (expected, actual)


# Generated at 2022-06-25 08:27:50.492930
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    unittest.installHandler()
    callback_module_object = CallbackModule()
    result = Result()
    callback_module_object.v2_runner_on_unreachable(result)


# Generated at 2022-06-25 08:28:00.555081
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    callback_module_1 = CallbackModule()
    result = collections.namedtuple('Result', ['_host', '_result'])
    result_1 = result(collections.namedtuple('Host', ['get_name'])('test_host'),
                                                                 {'ansible_job_id': 'test_job_id'})
    callback_module_1.v2_runner_on_async_failed(result_1)
    assert callback_module_1.get_display().display_buffer == "[test_host]: 'ASYNC FAILED on %s: jid=%s' '%s' '%s'\n" % (
        'test_host', 'test_job_id', C.COLOR_DEBUG, '\x1b[30;1m')

# Generated at 2022-06-25 08:28:12.188628
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    print("Testing v2_runner_on_skipped  of class CallbackModule")
    print("---------------------------------------------------")
    
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.secret_loader import SecretLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.display import Display
    from collections import namedtuple
    import os
    import datetime
    import pytest
    import sys

    #Change the current working directory to an ansible playbook

# Generated at 2022-06-25 08:28:19.536422
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.plugins.strategy import StrategyBase
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars

# Generated at 2022-06-25 08:28:28.488430
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    
    # Create a "fake" result
    result_module_1 = Mock()
    
    result_module_1.return_value.task_name = 'test task name'
    result_module_1.return_value.result = 'test result'
    result_module_1.return_value.exception = Exception('test exception')
    
    # result.task_name is the name of the individual task
    # result.result is the result of the task
    # result.exception contains the traceback of the exception that was raised during execution of the task
    # result._result contains the actual result in a serializable format and result.result is just the formatted string
    
    result_module_1.return_value._host = Mock()
    
    # result._host is an instance of Host

# Generated at 2022-06-25 08:28:59.446762
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    callback_module_1 = CallbackModule()
    result = Result()
    result.host = 'test_host'
    result.task = task2 = Task()
    task2.name = 'test_task'
    task2.action = 'test_action'
    result.task.loop = 'test_loop'
    result.result._result = dict()
    result.result._result['item'] = 'test_item'
    result.result._result['changed'] = True
    callback_module_1.v2_runner_item_on_ok(result)


# Generated at 2022-06-25 08:29:01.730049
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    callback_module_0 = CallbackModule()
    result = object()
    callback_module_0.v2_runner_on_skipped(result)


# Generated at 2022-06-25 08:29:06.454690
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    callback_module_0 = CallbackModule()
    task_obj = Task()
    result_obj = Result()
    host_obj = Host("localhost")
    result_obj._task = task_obj
    result_obj._host = host_obj
    result_obj._result['retries'] = 3
    result_obj._result['attempts'] = 2
    callback_module_0.v2_runner_retry(result_obj)


# Generated at 2022-06-25 08:29:09.479193
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    callback_module_0 = CallbackModule()
    result = Result()
    result._host = Host(name='localhost00')
    callback_module_0.v2_runner_item_on_skipped(result)


# Generated at 2022-06-25 08:29:17.667879
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    '''
    Test that method v2_runner_on_unreachable of class CallbackModule returns an OK status
    '''
    callback_module_0 = CallbackModule()
    result_0 = TaskResult()

    result_0._host = Host()
    result_0._host.name = "localhost"

    result_0._task = Task()
    result_0._task.action = "copy"

    result_0._result = dict()

    result_0._result['msg'] = "FAILED!"
    result_0._result['unreachable'] = False
    result_0._result['msg_type'] = "failed"

    callback_module_0.v2_runner_on_unreachable(result_0)

    return 0


# Generated at 2022-06-25 08:29:23.054190
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    result_0 =(
        'FAILED - RETRYING: [localhost]: xxx (1 retries left).\n'
        + 'FAILED - RETRYING: [localhost]: yyy (2 retries left).\n'
    )

    result_1 =(
        'FAILED - RETRYING: [localhost]: xxx (1 retries left).\n'
        + 'FAILED - RETRYING: [localhost]: yyy (2 retries left).\n'
        + 'FAILED - RETRYING: [localhost]: zzz (3 retries left).\n'
        + 'FAILED - RETRYING: [localhost]: www (4 retries left).\n'
    )


# Generated at 2022-06-25 08:29:27.876228
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    callback_module_1 = CallbackModule()
    class TestClass:
        def __init__(self):
            self.name = 'test'
    handler_1 = TestClass()
    host_1 = 'test host'
    callback_module_1.v2_playbook_on_notify(handler_1, host_1)


# Generated at 2022-06-25 08:29:35.507693
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:29:37.692899
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    result = None
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_item_on_ok(result)


# Generated at 2022-06-25 08:29:40.687755
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    callback_module = CallbackModule()
    callback_module.v2_runner_item_on_skipped(CreateResult(host='local_host'))


# Generated at 2022-06-25 08:30:45.625293
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    callback_module = CallbackModule()

if __name__ == '__main__':
    # test_case_0()
    test_CallbackModule_v2_runner_item_on_failed()

# Generated at 2022-06-25 08:30:52.686151
# Unit test for method v2_on_file_diff of class CallbackModule

# Generated at 2022-06-25 08:30:56.914554
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    callback_module_0 = CallbackModule()
    # v2_playbook_on_include return value is not checked as it prints to screen
    callback_module_0.v2_playbook_on_include( "included_file" )


# Generated at 2022-06-25 08:30:59.156222
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(object)


# Generated at 2022-06-25 08:31:06.507383
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    callback_module_1 = CallbackModule()
    task_1 = TaskInclude()
    task_1._hosts = [Host('test_host_0', VariableManager())]
    task_1._filename = "test_file"
    task_1._vars = dict()
    callback_module_1.v2_playbook_on_include(task_1)


# Generated at 2022-06-25 08:31:10.629315
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module = CallbackModule()
    options = {'verbosity': 'verbose'}
    callback_module.set_options(options)
    print('verbosity is %d' % callback_module.verbosity)
    callback_module.set_options(dict())
    print('verbosity is %d' % callback_module.verbosity)


# Generated at 2022-06-25 08:31:19.159768
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():

    callback_module_0 = CallbackModule()

    stats_0 = dict()
    stats_0['ok'] = 1
    stats_0['unreachable'] = 0
    stats_0['failed'] = 0
    stats_0['skipped'] = 0
    stats_0['changed'] = 0
    stats_0['rescued'] = 0
    stats_0['ignored'] = 0
    stats_0['processed'] = dict()
    stats_0['processed']['host1'] = dict()
    stats_0['processed']['host2'] = dict()
    stats_1 = dict()
    stats_1['ok'] = 0
    stats_1['unreachable'] = 1
    stats_1['failed'] = 0
    stats_1['skipped'] = 0

# Generated at 2022-06-25 08:31:24.651957
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    callback_module_1 = CallbackModule()
    class Host:
        def get_name(self):
            return 'host'

    class Task:
        def __init__(self):
            self.action = 'action'

    class Result:
        def __init__(self, task, host):
            self._host = host
            self._task = task
            self._result = dict(
                failed=True,
                changed=False,
                msg='error message'
            )

    task = Task()
    host = Host()
    result = Result(task, host)
    callback_module_1.v2_runner_item_on_failed(result)


# Generated at 2022-06-25 08:31:25.532252
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():

    callback_module_0 = CallbackModule()

    callback_module_0.set_options()


# Generated at 2022-06-25 08:31:34.503227
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    # No action is taken if the file being included is empty
    callback_module_1 = CallbackModule()
    included_file_1 = IncludedFile()
    included_file_1._filename = 'test_file'
    included_file_1._hosts = []
    included_file_1._vars = {}
    callback_module_1.v2_playbook_on_include(included_file_1)
    # v2_playbook_on_include prints the filename and the hosts if the file is
    # not empty and there are hosts for the included file
    callback_module_2 = CallbackModule()
    included_file_2 = IncludedFile()
    included_file_2._filename = 'test_file'
    included_file_2._hosts = []

# Generated at 2022-06-25 08:34:35.954433
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    callback_module_0 = CallbackModule()
    result_0 = Result()
    result_0.task_name = 'ls'
    result_0._host = Host()
    result_0._host.get_name = lambda: 'localhost'
    result_0._result = {'retries': 3, 'attempts': 1}
    callback_module_0.v2_runner_retry(result_0)


# Generated at 2022-06-25 08:34:39.158063
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    CallbackModule().v2_playbook_on_start(playbook=None)

# Generated at 2022-06-25 08:34:48.222840
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Test with success result
    callback_module_0 = CallbackModule()
    print('v2_runner_on_ok: ', end='')
    result = {
        "_result": {
            "changed": False
        },
        "_task": {
            "action": "show status",
        },
        "_host": {
            "get_name": lambda s: "192.168.100.100"
        }
    }
    callback_module_0.v2_runner_on_ok(result)
    print('OK')
    # Test with failure result
    callback_module_1 = CallbackModule()
    print('v2_runner_on_ok: ', end='')

# Generated at 2022-06-25 08:34:53.423051
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    result_0 = Result(task=None, host=None, result={'diff': {'before_header': '<', 'after_header': '>', 'before': 'hi', 'after': 'hello'}})
    callback_module_0.v2_on_file_diff(result_0)


# Generated at 2022-06-25 08:35:01.732270
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    test_object = CallbackModule()

    #Test case for reachable host
    result = MagicMock()
    result.host.get_name.return_value = "host1"
    result._host.get_name.return_value = "host1"

    #Test case when host is unreachable
    result.host.get_name.return_value = "host1"
    result._host.get_name.return_value = "host1"
    result._task.action.return_value = "ping"
    result._result = {u'unreachable': True, u'msg': u'destination host unreachable', u'changed': True}

    test_object.v2_runner_on_unreachable(result)

    #Test for no summary
    result._task.action.return_value = ""
    test_

# Generated at 2022-06-25 08:35:07.410026
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    host = "TEST_HOST"
    jid = 0
    started = "2018-03-02T10:03:30Z"
    finished = "2018-03-02T10:03:31Z"
    result = namedtuple('Result', '_host _result')
    result_0 = result("TEST_HOST", {"ansible_job_id":0, "started":"2018-03-02T10:03:30Z", "finished":"2018-03-02T10:03:31Z"})
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_async_poll(result_0)


# Generated at 2022-06-25 08:35:12.142220
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module = CallbackModule()
    callback_module.v2_on_file_diff(result)


# Generated at 2022-06-25 08:35:14.474362
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    # Setup test data
    included_file = TASK_RESULT_DATA['included_file']

    # Init test callback module
    callback_module = CallbackModule()

    # Test when result._task instanceof TaskInclude
    callback_module.v2_playbook_on_include(included_file)



# Generated at 2022-06-25 08:35:21.501407
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    callback_module_0 = CallbackModule()
    result = ResultAttrs()

    class Host:
        def get_name(self):
            return 'host'

    from ansible.vars.hostvars import HostVars
    class Task:
        def __init__(self):
            self.hostvars = HostVars(Host())

    result_task = Task()
    result._task = result_task
    result._result = dict()
    result._result['ansible_job_id'] = '1'

    callback_module_0.v2_runner_on_async_failed(result)

    result._result['ansible_job_id'] = None
    result._result['async_result'] = dict()

# Generated at 2022-06-25 08:35:28.838845
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    assert hasattr(CallbackModule, 'v2_playbook_on_play_start'), 'CallbackModule does not implement v2_playbook_on_play_start'
    # Assertion fails because v2_playbook_on_play_start() is an abstract method and an implementation is required
    #assert False, 'Test failed'
