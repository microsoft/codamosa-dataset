

# Generated at 2022-06-25 08:26:07.355421
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    callback_module_0 = CallbackModule()
    included_file_0 = included_file()
    callback_module_0.v2_playbook_on_include(included_file_0)


# Generated at 2022-06-25 08:26:08.973565
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    pass


# Generated at 2022-06-25 08:26:21.973481
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():

    callback_module_1 = CallbackModule()

    class Groups(object):
        '''Callable class for the groups property of Host.'''

        def __init__(self):
            self.groups = ['group1', 'group2']

        def __call__(self):
            '''Get the list of groups for the test Host.'''
            return self.groups

    class Host(object):
        '''Simple class for the test Host object.'''

        def __init__(self, name):
            self.name = name
            self.groups = Groups()

    class Result(object):
        '''Simple class for the Result object.'''

        def __init__(self, host, task, result):
            self._host = host
            self._task = task
            self._result = result


# Generated at 2022-06-25 08:26:25.987603
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    callback_module_0 = CallbackModule()
    result_0 = object
    assert(None == callback_module_0.v2_runner_item_on_skipped(result_0))


# Generated at 2022-06-25 08:26:35.567788
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    callback_module_1 = CallbackModule()
    fake_result = create_ansible_result_object(
                        dict(
                            ansible_job_id='ansible_job_id_1',
                            ansible_async_id='ansible_async_id_1',
                            async_result=dict(
                                ansible_job_id='ansible_job_id_2',
                                ansible_async_id='ansible_async_id_2'
                            )
                        ),
                        dict(
                            get_name=lambda: 'host_1'
                        )
                    )
    callback_module_1.v2_runner_on_async_failed(fake_result)


# Generated at 2022-06-25 08:26:40.845447
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module = CallbackModule()
    result = Result()
    result._task = Task()
    result._task.loop = False
    result._result = dict()
    result._result['diff'] = dict()
    result._result['diff']['after'] = textwrap.dedent("""\
        --- before.txt	2018-12-23 23:03:03.362284686 +0000
        +++ after.txt	2018-12-23 23:03:03.362284686 +0000
        @@ -1,3 +1,3 @@
         foo
        -bar
        +baz
        """)
    result._result['changed'] = True
    callback_module.v2_on_file_diff(result)


# Generated at 2022-06-25 08:26:42.439813
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    callback_module_0 = CallbackModule()
    print(callback_module_0.v2_runner_on_async_failed())


# Generated at 2022-06-25 08:26:44.983372
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    # Object instantiation
    options = dict()
    callback_module_1 = CallbackModule()
    # Execution
    callback_module_1.set_options(options)

if __name__ == "__main__":
    import nose
    nose.main(defaultTest=__name__)

# Generated at 2022-06-25 08:26:54.030859
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    runner_retry_result = Result()
    runner_retry_result.task_name = 'task name'
    runner_retry_result._task = 'task'
    runner_retry_result._host.get_name = 'host name'
    runner_retry_result._result = { 'attempts' : 4, 'retries' : 6 }
    runner_retry_result._result['changed'] = True

    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_retry(runner_retry_result)

# Generated at 2022-06-25 08:27:00.341556
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    callback_module = CallbackModule()
    stats = type('', (object,), {})()
    stats.custom = {}
    stats.summarize = lambda x: {'failures': 0, 'rescued': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0, 'changed': 0, 'ignored': 0}
    callback_module.v2_playbook_on_stats(stats)

if __name__ == '__main__':
    test_case_0()
    test_CallbackModule_v2_playbook_on_stats()

# Generated at 2022-06-25 08:27:27.564796
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Arrange
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:27:36.081226
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    # Create instance of class CallbackModule
    callback_module = CallbackModule()
    # Create instance of class Host
    host = Host(name='test_callback_module_v2_runner_on_start_host')
    # Create instance of class Task
    task = Task(action='test_callback_module_v2_runner_on_start_task')
    # Set the log_path attribute to a string
    callback_module.log_path = 'test_callback_module_v2_runner_on_start_log_path'
    # Set the show_per_host_start attribute to a boolean
    callback_module.show_per_host_start = True
    # Call method v2_runner_on_start of class CallbackModule
    callback_module.v2_runner_on_start(host, task)

# Unit

# Generated at 2022-06-25 08:27:42.940468
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    cb_obj = CallbackModule()
    handler = Handler()
    handler.set_loader(DictDataLoader({}))
    handler.set_variable_manager(VariableManager())
    handler.set_name("test_handler")
    host = "test_host"

    cb_obj.v2_playbook_on_notify(handler, host)

# Generated at 2022-06-25 08:27:49.076382
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    assert callback_module_0.set_options(display_skipped_hosts=True) is None
    assert callback_module_0.set_options(display_ok_hosts=True) is None
    assert callback_module_0.set_options(display_failed_stderr=True) is None
    assert callback_module_0.set_options(show_custom_stats=True) is None
    assert callback_module_0.set_options(check_mode_markers=True) is None


# Generated at 2022-06-25 08:27:52.850734
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    callback_module_0 = CallbackModule()
    runner_0 = RunnerResult()
    runner_0._result = {}

    callback_module_0.v2_runner_on_unreachable(runner_0)


# Generated at 2022-06-25 08:27:59.863516
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    callback_module_0 = CallbackModule()
    result_0 = RunnerResult()
    result_0._host = Host(name='saltmaster')
    result_0._result = {u'started': datetime.datetime(2017, 8, 19, 4, 27, 39, tzinfo=datetime.timezone.utc), u'ansible_facts': {}, u'finished': 0, u'ansible_job_id': u'null'}
    callback_module_0.v2_runner_on_async_poll(result=result_0)


# Generated at 2022-06-25 08:28:07.916348
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():

    # setup class for unit test
    class TestCallbackModule(CallbackModule):
        def __init__(self):
            CallbackModule.__init__(self)
            self._task = None
            self._result = None

        def _get_diff(self, diff):
            return CallbackModule._get_diff(self, diff)

    # setup results
    results = dict(failed=False, changed=True, diff=dict(before="aa", after="bb"))

    # setup task
    task = Task()
    task._uuid = "test_task_0"
    task._role = None
    task.action = "test_action_0"
    task.args = dict()
    task.check_mode = False
    task.loop = False
    task.no_log = False
    task.notify = dict()
   

# Generated at 2022-06-25 08:28:13.863970
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    # Initialize a test task_include
    task_filename = 'ansible/playbooks/ping.yml'
    task_hosts = ['localhost', '127.0.0.1']
    test_task = TaskInclude(task_filename, task_hosts)

    # Initialize a test callback module
    callback_module = CallbackModule()

    # Execute target function
    callback_module.v2_playbook_on_include(test_task)


# Generated at 2022-06-25 08:28:17.847366
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    #callback_module_1 = CallbackModule()
    #callback_module_1.v2_runner_retry()
    callback_module_1 = CallbackModule()
    #result = callback_module_1.v2_runner_retry(result='result')
    #print("result is {0}".format(result))
    callback_module_1.v2_runner_retry(result='result')


# Generated at 2022-06-25 08:28:28.037770
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    test_run_stats = {}
    test_run_stats['ok'] = 0
    test_run_stats['changed'] = 0
    test_run_stats['unreachable'] = 0
    test_run_stats['skipped'] = 0
    test_run_stats['failed'] = 0
    test_run_stats['rescued'] = 0
    test_run_stats['ignored'] = 0

    test_stats = type('test_stats', (), dict());
    test_stats.host = "host_1"
    test_stats.summarize = lambda self, host: test_run_stats

    test_case_0_callback_module = CallbackModule()
    test_case_0_callback_module.v2_playbook_on_stats(test_stats)


# Generated at 2022-06-25 08:29:13.010302
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_1 = CallbackModule()

    #case 0: test when result._result does not have changed key
    host_1 = MagicMock()
    host_1.get_name.return_value = "192.168.1.101"
    task_1 = MagicMock()
    task_1.action = "ping"
    result_1 = MagicMock()
    result_1._result = {"status": "good", "result": {"up": 0, "down": 0}}
    result_1._host = host_1
    result_1._task = task_1

    callback_module_1.v2_runner_on_ok(result_1)

    #case 1: test when result._result has changed key, and changed == True
    host_2 = MagicMock()
    host_2.get_name

# Generated at 2022-06-25 08:29:17.525566
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    case_0_stats = {
        'ok': 1,
        'changed': 1,
        'unreachable': 0,
        'failures': 0,
        'skipped': 2,
        'rescued': 0,
        'ignored': 0,
    }
    case_0_processed = {
        'localhost': case_0_stats,
    }
    case_0_stats_obj = Statistics()


# Generated at 2022-06-25 08:29:22.918569
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    callback_module_0 = CallbackModule()


# Generated at 2022-06-25 08:29:28.265968
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    # TODO: this test is not complete.
    # Mock objects
    result = Mock()
    result._result = {'changed': False}
    # Test
    testName = "Test case v2_runner_item_on_ok"
    print(testName)
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_item_on_ok(result)


# Generated at 2022-06-25 08:29:35.769060
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    callback_module_0 = CallbackModule()
    class Tag0(object):
        def get_name(self):
            return 'tag0'
    class Tag1(object):
        def get_name(self):
            return 'tag1'
    result_0 = MockResult()
    result_0._host = Tag0()

# Generated at 2022-06-25 08:29:44.361110
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    if not os.path.exists('./test/test_data/test_file.txt'):
        raise FileNotFoundError('Cannot find test file')
    callback_module_1 = CallbackModule()
    temp_1 = dict()
    temp_1['_filename'] = 'test/test_data/test_file.txt'
    temp_1['_hosts'] = ['test']
    temp_1['_vars'] = dict()
    included_file = IncludeFile(temp_1)
    callback_module_1.v2_playbook_on_include(included_file=included_file)


# Generated at 2022-06-25 08:29:51.510146
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    result = Mock()
    result.task_name = 'Setup'
    result.changed = False
    result.task_action = 'Setup'
    result._host = Mock()
    result._host.get_name.return_value = 'test'
    result._task = Mock()
    result._task.action = 'Setup'
    result._task.loop = False

# Generated at 2022-06-25 08:30:02.974235
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    test_data = {}
    test_case = {}
    test_case[u'check_mode'] = False
    test_case[u'name'] = u'all'
    test_case[u'_vv'] = None

# Generated at 2022-06-25 08:30:09.543194
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    print("\n" + __file__ + " " + str(getframeinfo(currentframe()).lineno) + ": " + inspect.stack()[0][3] + "()")

    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_stats(None)


# Generated at 2022-06-25 08:30:12.587471
# Unit test for method v2_playbook_on_play_start of class CallbackModule

# Generated at 2022-06-25 08:30:59.050049
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    callback_module_0 = CallbackModule()
    assert 'display_skipped_hosts' in callback_module_0.__dict__
    assert callback_module_0.display_skipped_hosts == True
    assert 'check_mode_markers' in callback_module_0.__dict__
    assert callback_module_0.check_mode_markers == True
    assert '__callbacks_loaded' in callback_module_0.__dict__
    assert callback_module_0.__callbacks_loaded == False


# Generated at 2022-06-25 08:31:09.940745
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    # Setup fixture
    callback_module = CallbackModule()
    callback_module.display_skipped_hosts = True
    callback_module._last_task_banner = '1234567890'
    callback_module._print_task_banner = mock.MagicMock()
    callback_module._run_is_verbose = mock.MagicMock()
    result = mock.MagicMock()
    result._task = mock.MagicMock()
    result._task.action = 'mock action'
    result._task._uuid = '1234567890'
    result._host = mock.MagicMock()

# Generated at 2022-06-25 08:31:18.915898
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-25 08:31:24.957303
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    # AnsibleModuleTestCase_0
    AnsibleModuleTestCase_0 = AnsibleModule(argument_spec=dict())

    # AnsibleTask_0
    AnsibleTask_0 = AnsibleTask(name='Dummy Task', action='Dummy Action', args='Dummy Args', register='Dummy Register', delegate_to='Dummy Delegate To', concerning='Dummy Concerning task')
    # AnsibleTask_0._uuid = '3cb7adf8-8a38-11e6-80c1-fa163e506c8c'
    # AnsibleTask_0._block = None
    # AnsibleTask_0._task_include = None
    # AnsibleTask_0._role = None
    # AnsibleTask_0._parent = None
    # AnsibleTask_0._attributes = {}

    # Ans

# Generated at 2022-06-25 08:31:30.804888
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    test_case_0()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 08:31:39.697591
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    #
    # Create a mock object for the class 'CallbackModule'
    #
    mock_callback_module = mock.create_autospec(CallbackModule, spec_set=True)
    mock_callback_module.__dict__ = {"_display": None,
                                     "_last_task_banner": None,
                                     "_task_type_cache": None}
    #
    # Create a mock object for the class 'Playbook'
    #
    mock_playbook = mock.create_autospec(Playbook, spec_set=True)
    mock_playbook_dict = {"_file_name": "test_playbook"}
    mock_playbook.__dict__ = mock_playbook_dict
    #
    # Call method v2_playbook_on_start of class CallbackModule
    #
    callback_module

# Generated at 2022-06-25 08:31:47.389227
# Unit test for method v2_runner_item_on_ok of class CallbackModule

# Generated at 2022-06-25 08:31:53.751740
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # This test case check whether the the host value is properly set in the ansible result objects.
    # python_task = PythonTask(module_name='ping', module_args={})
    # runner_on_ok_result = runner_on_ok(host=None, result=python_task.run(None))

    # When host is None or invalid
    callback_module_0 = CallbackModule()
    ansible_result_object_0 = ansible_result(changed=True, failed=False, skipped=False, unreachable=False)
    # This method should return None since host is not initialized.
    assert callback_module_0.v2_runner_on_ok(host=None, result=ansible_result_object_0) is None



# Generated at 2022-06-25 08:31:59.784778
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_1 = CallbackModule()

    # Test cases:
    result = Result(host=None, task=None, task_result=None, task_fields=None, play=None, play_context=None, play_result=None, is_failed=None, is_skipped=None)
    result._result = {}
    result._task = Task()
    callback_module_1.v2_on_file_diff(result)

    result._result = {}
    result._task = Task()
    callback_module_1.v2_on_file_diff(result)

    result._result = {}
    result._task = Task()
    callback_module_1.v2_on_file_diff(result)


# Generated at 2022-06-25 08:32:06.983562
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    class TestResult(object):
        def __init__(self):
            self.attempts = 0
            self.result = {
                'ansible_job_id': 'test_job_id',
                'started': 'test_start',
                'finished': 'test_finished'
            }

    class TestHost(Host):
        def __init__(self):
            Host.__init__(self)
            
        def get_name(self):
            return 'test_host'

    test_result = TestResult()
    test_host = TestHost()
    test_result._host = test_host

    # Create a Mock object for the display property
    mock_display = Mock()

    callback_module_0 = CallbackModule()
    callback_module_0._display = mock_display


# Generated at 2022-06-25 08:34:17.673528
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    callback_module_0 = CallbackModule()
    class FakeIncludedFile(object):
        def __init__(self):
            self._filename = None
            self._hosts = []
            self._vars = None
    included_file_0 = FakeIncludedFile() # type: FakeIncludedFile()
    included_file_0._filename = 'test'
    callback_module_0.v2_playbook_on_include(included_file_0)

# Generated at 2022-06-25 08:34:21.516514
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import unittest

    test_case = unittest.TestCase('__init__')
    callback_module_0 = CallbackModule()
    result_0 = Result()

    # Place your initialization code here
    callback_module_0.v2_on_file_diff(result_0)

    test_case.assertEqual(callback_module_0.v2_on_file_diff(result_0), None)


# Generated at 2022-06-25 08:34:24.950645
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    global callback_module_0

    result_0 = None
    # Variable result_0 contains the last received result. Set it from the test.
    callback_module_0.v2_runner_on_skipped(result=result_0)


# Generated at 2022-06-25 08:34:28.044247
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    callback_module_0 = CallbackModule()
    result_0 = Mock()
    result_0.task_name = 'task_name_0'
    result_0.host = 'host_0'
    result_0.attempts = 2
    result_0.retries = 5
    callback_module_0.v2_runner_retry(result_0)


# Generated at 2022-06-25 08:34:34.417199
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    callback_module_0 = CallbackModule()
    result_0 = Result()
    result_0._host = 'test_host'
    result_0._result = ''
    callback_module_0.v2_runner_on_async_poll(result_0)


# Generated at 2022-06-25 08:34:44.000588
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    callback_module_1 = CallbackModule()
    task_result = Mock()
    task_result.attrs = dict()
    task_result.attrs["_host"] = "host name"
    task_result.attrs["_result"] = dict()
    task_result.attrs["_result"]["ansible_job_id"] = "job id"
    task_result.attrs["_result"]["started"] = "started"
    task_result.attrs["_result"]["finished"] = "finished"
    callback_module_1.v2_runner_on_async_poll(task_result)


# Generated at 2022-06-25 08:34:49.940109
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    from ansible.utils.vars import combine_vars
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    playbook = None
    host = None
    task = None
    n = 0

# Generated at 2022-06-25 08:34:51.882169
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    callback_module_0 = CallbackModule()
    result = Result()
    callback_module_0.v2_runner_item_on_failed(result);

# Generated at 2022-06-25 08:35:00.074319
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()

    assert (callback_module_0._display.verbosity > 1)
    assert (not (context.CLIARGS['args']))
    assert (not (context.CLIARGS['ask_pass']))
    assert (not (context.CLIARGS['ask_su_pass']))
    assert (not (context.CLIARGS['ask_vault_pass']))
    assert (not (context.CLIARGS['become']))
    assert (not (context.CLIARGS['become_method']))
    assert (not (context.CLIARGS['become_user']))
    assert (not (context.CLIARGS['check']))
    assert (not (context.CLIARGS['connection']))

# Generated at 2022-06-25 08:35:03.289517
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    callback_module_0.set_options(display_ok_hosts=False, display_skipped_hosts=False)
    assert (callback_module_0.display_ok_hosts == False)
    assert (callback_module_0.display_skipped_hosts == False)
