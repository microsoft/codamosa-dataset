

# Generated at 2022-06-25 08:26:14.409746
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
  # Input
  result = None

  # Execute the tested method
  CallbackModule().v2_runner_item_on_failed(result)


# Generated at 2022-06-25 08:26:16.544548
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_playbook_on_stats()


# Generated at 2022-06-25 08:26:27.773910
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Define expected
    expected = {"msg": "All items completed", "item": "", "invocation": {"module_name": "win_ping", "module_args": {}}, "result": {"changed": False, "failed": False, "rc": 0, "delta": "0:00:00.015481", "stdout": "pong", "stdout_lines": ["pong"], "warnings": []}, "changed": False}

    # Initialize test class
    callback_module_0 = CallbackModule()

    # Set up test input

# Generated at 2022-06-25 08:26:37.604767
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    callback_module_0 = CallbackModule()
    result_0 = Result()
    result_0.host = ""
    result_0.task_name = ""
    result_0.task_action = ""
    result_0.task_args = []
    result_0.is_changed = False
    result_0._result = {}
    result_0.async_val = 0
    result_0.is_failed = False
    result_0.task_fields = {}
    result_0._task = Task()
    result_0.task_items = {}
    result_0.__slots__ = []


# Generated at 2022-06-25 08:26:39.229359
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    result_0 = Result()
    callback_module_0.v2_on_file_diff(result_0)


# Generated at 2022-06-25 08:26:40.928633
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_on_file_diff(result = None)


# Generated at 2022-06-25 08:26:42.885848
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = RunnerResult()
    var_0 = callback_module_0.v2_runner_item_on_ok(result_0)


# Generated at 2022-06-25 08:26:44.363760
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    callback_module_0 = CallbackModule()

    var_0 = callback_module_0.v2_runner_on_skipped()



# Generated at 2022-06-25 08:26:48.077323
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    callback_module_0 = CallbackModule()
    result_0 = RunnerResult()
    callback_module_0.v2_runner_on_async_failed(result_0)


# Generated at 2022-06-25 08:26:50.467950
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    callback_module_0 = CallbackModule()
    play_0 = Play()
    callback_module_0.v2_playbook_on_play_start(self=callback_module_0, play=play_0)


# Generated at 2022-06-25 08:27:09.794797
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_item_on_failed(result='')


# Generated at 2022-06-25 08:27:18.686342
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    task_name="test_task"
    task_action="test_action"
    task=Task(name=task_name, action=task_action)
    task_hosts=["192.168.0.1","192.168.0.2"]
    task._hosts = task_hosts
    task_return = {"192.168.0.1":{"ok":1,"changed":1,"unreachable":1,"failed":1,"skipped":1,"rescued":1,"ignored":1},"192.168.0.2":{"ok":1,"changed":1,"unreachable":1,"failed":1,"skipped":1,"rescued":1,"ignored":1}}
    task._result = task_return
    callback_module_0=CallbackModule()
    callback_module_0.v2_runner_on_ok

# Generated at 2022-06-25 08:27:24.622245
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    callback_module_0 = CallbackModule()
    assert isinstance(callback_module_0, CallbackModule)

    callback_module_0.set_options(display_ok_hosts=False, display_failed_stderr=True, display_skipped_hosts=False, display_task_input=False)
    assert callback_module_0.get_option('display_ok_hosts') == False
    assert callback_module_0.get_option('display_failed_stderr') == True
    assert callback_module_0.get_option('display_skipped_hosts') == False
    assert callback_module_0.get_option('display_task_input') == False

    assert callback_module_0.display_ok_hosts == False

# Generated at 2022-06-25 08:27:29.156316
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    try:
        callback_module_0 = CallbackModule()

        result_0 = Result(
            host=result_host,
            task=result_task,
            result=result_result,
            _task_fields=result__task_fields
        )

        # Call test target
        callback_module_0.v2_runner_item_on_failed(result=result_0)
    finally:
        # Teardown test environment
        teardown_test_environment()


# Generated at 2022-06-25 08:27:36.495302
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():

    result = Container()
    result.task = Container()
    result.task.loop = True
    result.task.action = 'script'
    result.task._uuid = 'test'

# Generated at 2022-06-25 08:27:37.473866
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
   pass

# Generated at 2022-06-25 08:27:38.772874
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    pass


# Generated at 2022-06-25 08:27:48.005238
# Unit test for method v2_runner_on_async_poll of class CallbackModule

# Generated at 2022-06-25 08:27:50.297512
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    callback_module_1 = CallbackModule()
    result_1 = Result()
    callback_module_1.v2_runner_on_unreachable(result_1)


# Generated at 2022-06-25 08:27:53.507875
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook_0 = Playbook()
    callback_module_0.v2_playbook_on_start(playbook_0)

# Generated at 2022-06-25 08:28:18.724809
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    callback_module_test_object = CallbackModule()
    hosts_with_statuses = []
    hosts_with_statuses.append(Result('ok','ok'))
    hosts_with_statuses.append(Result('nok','nok'))
    hosts_with_statuses.append(Result('changed','changed'))
    hosts_with_statuses.append(Result('failed','failed'))
    hosts_with_statuses.append(Result('unreachable','unreachable'))
    hosts_with_statuses.append(Result('unreachable_host','unreachable_host'))

    for host in hosts_with_statuses:
        callback_module_test_object.v2_runner_on_start(host)


# Generated at 2022-06-25 08:28:21.216934
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    assert callback_module_0.set_options()


# Generated at 2022-06-25 08:28:29.566276
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    import pprint, datetime
    from collections import OrderedDict
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.module_utils._text import to_text
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase

# Generated at 2022-06-25 08:28:38.693434
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    mock_result = mock.Mock()
    mock_result.task_name = "test_name_0"
    mock_result.changed = True
    mock_result.__getitem__.side_effect = [mock_result.task_name, mock_result.changed]
    callback_module_0 = CallbackModule()
    callback_module_0._dump_results = lambda: "test_str_0"
    callback_module_0.v2_runner_on_ok(mock_result)
    assert callback_module_0._last_task_banner == "test_name_0"
    assert callback_module_0._task_type_cache[mock_result._uuid] == "test_type_0"
    assert callback_module_0.display_skipped_hosts == False
    assert callback_

# Generated at 2022-06-25 08:28:48.633063
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_1 = CallbackModule()
    callback_module_1.set_options({'verbosity': '0'})
    assert callback_module_1._display.verbosity == 0

    callback_module_2 = CallbackModule()
    callback_module_2.set_options({'verbosity': '1'})
    assert callback_module_2._display.verbosity == 1

    callback_module_3 = CallbackModule()
    callback_module_3.set_options({'verbosity': '2'})
    assert callback_module_3._display.verbosity == 2

    callback_module_4 = CallbackModule()
    callback_module_4.set_options({'verbosity': '3'})
    assert callback_module_4._display.verbosity == 3


# Generated at 2022-06-25 08:28:58.652037
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    stats_0 = Stats()
    stats_0.processed = {k: v for k, v in [(u'host_0', Counter({u'ok': 0, u'changed': 0, u'failures': 0, u'skipped': 0, u'unreachable': 0, u'rescued': 0, u'ignored': 0}))]}
    callback_module_0.v2_playbook_on_stats(stats_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 08:29:04.663963
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    callback_module_0 = CallbackModule()
    class Include(object):
        def __init__(self):
            self._filename = "filename"
            self._hosts = ["host"]
            self._vars = None
    included_file = Include()
    callback_module_0.v2_playbook_on_include(included_file)

if __name__ == '__main__':
    test_case_0()
    test_CallbackModule_v2_playbook_on_include()

# Generated at 2022-06-25 08:29:07.628493
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    # v2_runner_on_start_0 test
    host_0 = Host()
    task_0 = PlayBook()
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_start(host_0, task_0)


# Generated at 2022-06-25 08:29:10.730456
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    result = "FAILED - RETRYING"
    callback_module_1 = CallbackModule()
    assert result in callback_module_1.v2_runner_retry(result)



# Generated at 2022-06-25 08:29:15.365396
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    callback_module_0 = CallbackModule()
    class MockResult(object):
        def __init__(self):
            self.task_name = None
            self.task_tags = None
            self.task_action = None
            self.task_args = None
            self.task_loop = None
            self.task_items = None
            self.task_vars = None
            self.task_path = None
            self.task_path_relative = None
            self.task_playbook = None
            self.task_play = None
            self.task_play_path = None
            self.task_playbook_path = None
            self.task_hosts = None
            self.task_nocache = None
            self.task_role_name = None
            self.task_role_path = None
           

# Generated at 2022-06-25 08:30:12.171485
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    host = 'www.github.com'
    action = 'git pull'
    task = 'some task'
    result = 'some result'
    hostvars = {}
    task_uuid = 'some uuid'
    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_on_skipped(host, action, task, result, hostvars, task_uuid)


# Generated at 2022-06-25 08:30:21.141918
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    options = {'default_callback': 'minimal', 'display_failed_stderr': True,
               'display_skipped_hosts': True, 'verbosity': 0, 'show_custom_stats': True,
               'check_mode_markers': False, 'display_ok_hosts': True, 'host_key_checking': True}
    result = {'_task': '', '_host': '', '_result': {'failed_when_result': False, 'item_label': None,
                                                    'msg': 'hello'}}

    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_on_failed(result)

    callback_module_2 = CallbackModule(display=Display())
    callback_module_2.v2_runner_on_failed(result)



# Generated at 2022-06-25 08:30:27.452664
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    new_result_0 = Result()
    new_result_0._host = 'ubuntu 8.04'
    new_result_0._task = Task()
    new_result_0._task.action = 'command'
    new_result_0._task.no_log = False
    new_result_0._task.rerun_failed_hosts = False
    new_result_0._result = {'changed': False, '_ansible_no_log': False, '_ansible_item_result': True, '_ansible_parsed': True, '_ansible_ignore_errors': None, 'stdout': '', '_ansible_verbose_always': True, '_ansible_delegated_vars': {}, 'warnings': []}

# Generated at 2022-06-25 08:30:32.077407
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    callback_module = CallbackModule()
    task = ansible.playbook.task.Task()
    result = ansible.runner.ResultObj(task, dict())
    result._host = ansible.inventory.host.Host("localhost")
    callback_module.v2_runner_on_async_ok(result)


# Generated at 2022-06-25 08:30:41.346743
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    @patch('callback_plugins.default_display.DefaultDisplay.display')
    def test_case_1(display_mock):
        callback_module_1 = CallbackModule()
        stats_1 = MagicMock()
        stats_1.processed = {'host1': None, 'host2': None, 'host3': None}
        stats_1.summarize = MagicMock(return_value={'ok': 0, 'changed': 5, 'unreachable': 3, 'failed': 10, 'skipped': 0, 'rescued': 0, 'ignored': 0})
        callback_module_1.v2_playbook_on_stats(stats_1)

# Generated at 2022-06-25 08:30:43.391499
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_ok(result=None)


# Generated at 2022-06-25 08:30:47.944753
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    runner_result = dict(_task=object(), _host=object())
    runner_result['exception'] = object()
    runner_result['exception_traceback'] = None
    runner_result['_ansible_verbose_always'] = False
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(runner_result)


# Generated at 2022-06-25 08:30:50.890512
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    # Create instance of class CallbackModule
    callback_module = CallbackModule()

    # Create instance of class Result
    result = Result()

    # Call method v2_runner_on_unreachable
    callback_module.v2_runner_on_unreachable(result)


# Generated at 2022-06-25 08:30:55.074297
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_on_file_diff(NewFileDiff_0)
    callback_module_0.v2_on_file_diff(NewFileDiff_1)


# Generated at 2022-06-25 08:30:59.050159
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    callback_module_1 = CallbackModule()
    result_0 = RunnerResult()
    task_0 = Task()
    host_0 = Host('test')
    task_0._host = host_0
    result_0._task = task_0
    callback_module_1.v2_runner_on_unreachable(result_0)


# Generated at 2022-06-25 08:32:59.970780
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    callback_module_0 = CallbackModule()
    args = (stats, )

    # Call method v2_playbook_on_stats
    callback_module_0.v2_playbook_on_stats(*args)


# Generated at 2022-06-25 08:33:07.203127
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    # Arrange
    callback_module_0 = CallbackModule()
    result_0 = Result()
    result_1 = Result()
    result_1._host = Host()
    result_1._host.get_name = lambda: 'host_name'
    result_1._task = Task()
    result_1._task._uuid = 'task_uuid'
    result_1._task.no_log = False
    result_1._task.action = 'action_string'
    result_1._task.loop = False
    result_1._result = dict()
    result_1._result['changed'] = False
    result_1._result['diff'] = 'diff_string'
    result_1._result['unreachable'] = False
    result_1._result['stdout'] = 'stdout_string'
   

# Generated at 2022-06-25 08:33:08.771270
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    r = Result()
    callback_module_0.v2_runner_on_ok(r)


# Generated at 2022-06-25 08:33:18.496144
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-25 08:33:20.495581
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    try:
        test_case_0()
    except Exception as e:
        print('TestCase 0: %s' % e)

if __name__ == '__main__':
    test_CallbackModule_v2_runner_item_on_ok()

# Generated at 2022-06-25 08:33:30.351465
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    # Create a result object
    result = Mock()
    result.failed = True
    result.task_name = "t_task_name"
    # Create a dummy host object
    host = Mock()
    host.get_name.return_value = "t_host"
    # Add the host object to the result object
    result._host = host
    # Create a dummy attempt and retry object
    result._result = {'attempts': 1, 'retries': 2}
    # Initialize the output
    output = None
    with patch('sys.stdout', new=io.StringIO()) as captured_stdout:
        callback_module_0 = CallbackModule()
        # Actual call
        callback_module_0.v2_runner_retry(result)
        # Check the output

# Generated at 2022-06-25 08:33:36.038111
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    '''
    Unit test for method v2_runner_retry of class callback.CallbackModule

    @returns: None

    @author: Roy Nielsen
    '''
    callback_module = CallbackModule()
    results = Result(host=Host('host'), task="task", return_data={"attempts": 0, "retries": 0})
    results.task_name = "task"
    results._task = "task"
    callback_module.v2_runner_retry(results)



# Generated at 2022-06-25 08:33:38.856061
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    import mock
    callback_module_0 = CallbackModule()
    callback_module_0.display = mock.Mock()
    callback_module_0.v2_runner_on_async_ok(mock.sentinel.result_0)


# Generated at 2022-06-25 08:33:47.772810
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback = CallbackModule()
    kwargs = {"disable_convert_data": True}
    callback.set_options(**kwargs)
    assert callback.disable_convert_data == True



# Generated at 2022-06-25 08:33:50.431337
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    callback_module = CallbackModule()
    stats = Stats()
    callback_module.v2_playbook_on_stats(stats)

if __name__ == "__main__":
    test_case_0()
    test_CallbackModule_v2_playbook_on_stats()