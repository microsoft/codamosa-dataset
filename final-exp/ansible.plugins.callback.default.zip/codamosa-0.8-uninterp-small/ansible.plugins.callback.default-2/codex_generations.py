

# Generated at 2022-06-25 08:26:13.578891
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    callback_module_0.v2_runner_item_on_skipped(result)


# Generated at 2022-06-25 08:26:16.082747
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    callback_module_0 = CallbackModule()
    result_0 = RunnerResult()
    result_0._host = Host("192.168.0.1")
    callback_module_0.v2_runner_on_unreachable(result_0)


# Generated at 2022-06-25 08:26:21.440213
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    callback_module_1 = CallbackModule(display_skipped_hosts=True, display_ok_hosts=False)
    test_host_1 = 'localhost'
    test_task_1 = Task()
    test_task_1.action = 'action_test'
    callback_module_1.v2_runner_on_start(test_host_1, test_task_1)


# Generated at 2022-06-25 08:26:25.042044
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    TextTestRunner(verbosity=1).run(TestLoader().loadTestsFromTestCase(Test_CallbackModule_v2_on_file_diff))


# Generated at 2022-06-25 08:26:31.090017
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Create an object of class CallbackModule
    callback_module_0 = CallbackModule()

    # Create an object of class PlaybookExecutor
    playbook_executor_0 = PlaybookExecutor()

    # Call method v2_playbook_on_start of class CallbackModule
    callback_module_0.v2_playbook_on_start(playbook_executor_0)

    # Test assertion
    print('Test assertion: ' + str(True))


# Generated at 2022-06-25 08:26:40.430219
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    # Create a fixture for class CallbackModule
    callback_module_0 = CallbackModule()
    # Create a mock for class Object
    obj_0 = MagicMock()
    # Create a mock for class Object
    obj_1 = MagicMock()
    # Create an instance of the ResultsCollector class
    results_collector_0 = ResultsCollector()
    # Initialize the variable callback_module_0._display
    callback_module_0._display = results_collector_0
    # Assign the variable _dumper to attribute stdout
    results_collector_0.stdout = callback_module_0.playbook._dumper
    # Assign the variable _log_only_when_piped to attribute _log_only_when_piped
    results_collector_0._log_only_when_piped = obj_

# Generated at 2022-06-25 08:26:48.669366
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    print("\nNow in method test_CallbackModule_v2_runner_on_unreachable")
    callback_module = CallbackModule()

    task = Task()
    task.action = 'TEST_ACTION'
    task.name = 'TEST_TASK_NAME'
    task.tags = ['TEST_TAG']
    task.file_name = 'TEST_FILENAME'
    task.module_name = 'TEST_MODULENAME'
    task.module_args = 'TEST_MODULEARGS'
    task.args = 'TEST_ARGS'
    task.set_loader(DictDataLoader({}))
    task.no_log = False
    task.always_run = False
    task.any_errors_fatal = False
    task.ignore_errors = False
   

# Generated at 2022-06-25 08:26:57.207782
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    callback_module_0 = CallbackModule()
    task_0 = Task()

    result_0 = Result(host=None, task=task_0, return_value={'msg': 'An unknown error occurred'})
    callback_module_0.v2_runner_item_on_failed(result_0)
    
    result_1 = Result(host=None, task=task_0, return_value={'msg': 'An unknown error occurred', 'stdout': 'hello world!'})
    callback_module_0.v2_runner_item_on_failed(result_1)



# Generated at 2022-06-25 08:27:01.229718
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    # Test Point: method v2_runner_item_on_skipped
    callback_module_0 = CallbackModule()
    from ansible.executor.task_result import TaskResult
    result = TaskResult("test001", "test002")
    result._result = "test003"
    callback_module_0.v2_runner_item_on_skipped(result)


# Generated at 2022-06-25 08:27:07.827169
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    callback_module_1 = CallbackModule()
    result = {}

    result['_task'] = {}
    result['_task']['action'] = 'debug'
    result['_result'] = {}
    result['_result']['_ansible_parsed'] = True
    result['_result']['failed'] = True
    result['_result']['_ansible_ignore_errors'] = False
    result['_result']['_ansible_no_log'] = False
    result['_result']['_ansible_verbose_always'] = False
    result['_result']['msg'] = 'this is a message'
    result['_result']['_ansible_item_result'] = False
    result['_result']['_ansible_diff'] = False

# Generated at 2022-06-25 08:27:34.790254
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    task_name = 'test_CallbackModule_v2_playbook_on_stats'
    file_name = task_name + '.txt'
    var_file_name = task_name + '.vars'
    data = [{'host': 'host1', 'ok': 1, 'changed': 1, 'unreachable': 1, 'failures': 1, 'skipped': 1, 'ignored': 1, 'rescued': 1}, {'host': 'host2', 'ok': 1, 'changed': 1, 'unreachable': 1, 'failures': 1, 'skipped': 1, 'ignored': 1, 'rescued': 1}]

# Generated at 2022-06-25 08:27:36.591873
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    callback_module = CallbackModule()
    callback_module.v2_runner_item_on_skipped("hello")


# Generated at 2022-06-25 08:27:41.717757
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    callback_module_1 = CallbackModule()
    stats = AnsiblePlaybookStats(0, {})
    callback_module_1.v2_playbook_on_stats(stats)


if __name__ == '__main__':
    test_case_0()
    test_CallbackModule_v2_playbook_on_stats()

# Generated at 2022-06-25 08:27:44.417905
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    callback_module = CallbackModule()
    ansible_result = create_ansible_result()
    callback_module.v2_runner_item_on_ok(result=ansible_result)


# Generated at 2022-06-25 08:27:46.381336
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    test_case_0()

if __name__ == '__main__':
    test_CallbackModule_v2_playbook_on_play_start()

# Generated at 2022-06-25 08:27:53.267307
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    callback_module_0 = CallbackModule()
    result._result = {}
    result._task = {}
    result.task_name = 'rsync'
    result._host = None
    result._task._uuid = 'c3d67b82498c0986b9e74b5a5b5f5cff'
    result._task.action = 'rsync'
    result._task.no_log = False
    result._task.check_mode = False
    result._result['exception'] = AnsibleError('Exception message')
    result._result['_ansible_verbose_always'] = True
    result._result['stderr'] = 'stderr message'
    result._result['stdout'] = 'stdout message'
    result._result['stdout_lines'] = 'stdoutlines'
   

# Generated at 2022-06-25 08:28:01.839016
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()
    playbook_1 = playbook.PlayBook('playbook_1')
    task_1 = task.Task()
    task_2 = task.Task()
    task_3 = task.Task()
    task_4 = task.Task()
    task_5 = task.Task()
    task_6 = task.Task()
    task_7 = task.Task()
    task_8 = task.Task()
    task_9 = task.Task()
    task_10 = task.Task()
    task_11 = task.Task()
    task_12 = task.Task()
    task_13 = task.Task()
    task_14 = task.Task()
    task_15 = task.Task()
    task_15.set_name('task_15')

# Generated at 2022-06-25 08:28:12.270797
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    from ansible.plugins.callback import CallbackBase
    from collections import namedtuple
    import json
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    class MockResult:
        def __init__(self):
            self._host = None
            self._task = None
            self._result = dict()

        def __setattr__(self, name, value):
            self.__dict__[name] = value

    class MockStats:
        def __init__(self):
            self.processed = dict()
            self.completed = dict()
            self.failures = dict()

# Generated at 2022-06-25 08:28:19.586946
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    callback_module_1 = CallbackModule()
    result_object_1 = AnsibleResult()
    result_object_1.task_name = "Test task name"
    result_object_1.changed = False
    result_object_1.task_action = "Test task action"
    result_object_1.host = "Test host"
    result_object_1.result = {"Test dictionary"}
    result_object_1.task_name = "Test task name"
    result_object_1.task_name = "Test task name"
    result_object_1.task_name = "Test task name"
    result_object_1.task_name = "Test task name"
    result_object_1.task_name = "Test task name"
    result_object_1.task_name = "Test task name"


# Generated at 2022-06-25 08:28:23.912590
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # init
    callback_module_0 = CallbackModule()

    # test
    try:
        callback_module_0.v2_playbook_on_start(None)
    except Exception as e:
        print(e)
    else:
        print('no exception thrown')



# Generated at 2022-06-25 08:28:52.915337
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():

    callback_module_1 = CallbackModule()

    # 1. In case of 'TaskInclude', the message is shown
    result_1a = FakeResult()
    result_1a._task = FakeTaskInclude()
    result_1a._task._filename = "included_file_name"
    result_1a._hosts = ["host_1", "host_2", "host_3"]
    result_1a._result = {}

    callback_module_1.v2_playbook_on_include(result_1a)

    # 2. In case of action, the message is not shown
    result_1b = FakeResult()
    result_1b._task = FakeAction()
    result_1b._task._filename = "original_file_name"

# Generated at 2022-06-25 08:29:02.514441
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    # Intialize a RunnerResult object
    host = MagicMock()
    host.name = "test"
    task = MagicMock(name="Ansible")
    runner = RunnerResult(host, task, {}, False)
    # Set the task name
    runner.task_name = "Test Task"
    # Add a fake result code
    runner._result = {
        "result": {
            "attempts": 3,
            "retries": 3,
        }
    }
    # Run the test case
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_retry(runner)


# Generated at 2022-06-25 08:29:06.222057
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    result_1 = Result(host='hostname', task='dummy_task')
    result_1._result = {
        'stdout': 'line 1',
        'stderr': 'line 2'
    }
    callback_module_1.v2_runner_on_failed(result_1)


# Generated at 2022-06-25 08:29:09.672099
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    callback_module_0 = CallbackModule()
    included_file_0 = './test/testfile'
    result = callback_module_0.v2_playbook_on_include(included_file_0)
    assert result == None


# Generated at 2022-06-25 08:29:18.122628
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    # Create a class of type AnsibleHost
    ansible_host_0 = AnsibleHost()

    ansible_host_0.name = 'localhost'

    # Create a class of type TaskExecution
    task_execution_0 = TaskExecution()

    # Create a class of type TaskResult
    task_result_0 = TaskResult()
    task_result_0.stdout = ''
    task_result_0.stderr = ''

    # Create a class of type CallbackModule
    callback_module_0 = CallbackModule()

    task_result_0.async_result = {}

    # Invoke method
    callback_module_0.v2_runner_on_async_poll(task_result_0)

    # No exception should be raised
    assert True





# Generated at 2022-06-25 08:29:21.746073
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    callback_module_0 = CallbackModule()
    result = mock.Mock()

    result.task_name = C.DEFAULT_TASK_NAME
    result._task = C.DEFAULT_TASK_NAME
    result._result = { 'failed': True, 'ansible_job_id': 'test', 'ansible_facts': {}, 'changed': True, 'ansible_result_dir': 'test', 'ansible_facts_diff': {} }

    callback_module_0.v2_runner_retry(result)


# Generated at 2022-06-25 08:29:28.396000
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    # Test case configuration
    runner_result = dict()
    # The following 'try except' statement is used for skip the test if the skipped condition is satisfied.
    try:
        #skip the test if the condition is satisfied.
        pass
    except SkipTest as e:
        pass
    else:
        # The following 'try except' statement is used for skip the test if the configuration is not satisfied.
        try:
            callback_module_0.v2_runner_on_failed(runner_result)
        except (TypeError, ValueError) as e:
            print('test_CallbackModule_v2_runner_on_failed Exception happens.  Skip the test.\n')
        else:
            raise AssertionError('Configuration error, please check the config.py or input parameters.')



# Generated at 2022-06-25 08:29:34.118907
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = Result()

    result_0._result = {'changed': True, 'failed': False, 'item': 'fstab'}
    result_0._host = Host()
    result_0._task = Task()
    result_0._task.action = 'lineinfile'
    result_0._task.no_log = False
    result_0._task.loop = False

    callback_module_0.v2_runner_item_on_ok(result_0)


# Generated at 2022-06-25 08:29:44.829212
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    runner_on_ok_result = Mock()
    runner_on_ok_result._host.get_name.return_value = 'test'
    runner_on_ok_result._result = {'changed': None, 'warnings': None, 'msg': 'abc'}

    runner_on_ok_result._task.action = 'test'
    runner_on_ok_result._task.no_log = False
    runner_on_ok_result.task_name = 'test'

    callback_module = CallbackModule()
    callback_module.display_ok_hosts = True
    callback_module.v2_runner_item_on_ok(runner_on_ok_result)
    
    runner_on_failed_result = Mock()

# Generated at 2022-06-25 08:29:51.674054
# Unit test for method v2_playbook_on_play_start of class CallbackModule

# Generated at 2022-06-25 08:31:00.854661
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    with patch('ansible.plugins.callback.CallbackBase.display'):
        callback_module_0 = CallbackModule()
        display = callback_module_0.display
        task_0 = Mock()
        result_0 = Mock()
        result_0.result = {'changed': False, 'item': u'sssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss', 'invocation': {'module_name': u'ping', 'module_args': u''}, '_ansible_item_result': True, '_ansible_parsed': True}
        result_0.task = task_0
        result_1 = Mock()

# Generated at 2022-06-25 08:31:07.538140
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    print("\nrunning test_CallbackModule_v2_playbook_on_play_start...")
    play = Play()
    test_case_0.v2_playbook_on_play_start(play)

if __name__ == "__main__":
    # Unit tests for callback module
    test_case_0 = CallbackModule()
    test_CallbackModule_v2_playbook_on_play_start()

# Generated at 2022-06-25 08:31:10.415293
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    callback_module_1 = CallbackModule()
    host_0 = None
    task_0 = None
    callback_module_1.v2_runner_on_start(host_0, task_0)



# Generated at 2022-06-25 08:31:17.331273
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    # Test with set_options(options=dict())
    options = {}
    pre_options = callback_module_0.options
    callback_module_0.set_options(options=options)
    assert(pre_options != callback_module_0.options)
    # Test with set_options(options=dict())
    options = {}
    pre_options = callback_module_0.options
    callback_module_0.set_options(options=options)
    assert(pre_options == callback_module_0.options)


# Generated at 2022-06-25 08:31:19.847556
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    callback_module_0 = CallbackModule()
    cb_self = callback_module_0
    handler = Handler()
    host = ResultMessage()
    cb_self.v2_playbook_on_notify(handler, host)


# Generated at 2022-06-25 08:31:21.883909
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    playbook = PlayBook(playbook_path=playbook_path_0, callbacks=callback_module_0, runner_callbacks=callback_module_0)
    playbook.run()


# Generated at 2022-06-25 08:31:25.913318
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    result = Result()
    result._result = {
        "exception": "The error message",
        "msg": "The error message",
        "failed": True,
        "parsed": False
    }
    result._task = dict()
    result._task.action = 'command'
    callback_module = CallbackModule()
    callback_module.display_failed_stderr = False
    callback_module.v2_runner_item_on_failed(result)


# Generated at 2022-06-25 08:31:31.132067
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    result = {}
    callback_module = CallbackModule()
    callback_module.v2_runner_item_on_ok(result)


# Generated at 2022-06-25 08:31:39.572850
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    callback_module_0 = CallbackModule()

    # parameters
    result_0 = {
        "exception": "boom",
        "msg": "boom!",
        "_ansible_item_label": "item",
        "invocation": {
            "module_args": {"_raw_params": "command",
                            "markup": "cheetah",
                            "trim": "space"},
            "module_name": "command"}
    }

    try:
        callback_module_0.v2_runner_on_unreachable(result_0)
    except:
        traceback.print_exc()
        error_happens = True
    else:
        error_happens = False

    assert not error_happens

# Generated at 2022-06-25 08:31:42.336517
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    callback_module_0 = CallbackModule()
    result_0 = None
    result_1 = callback_module_0.v2_runner_on_async_ok(result_0)
    assert result_1 is None


# Generated at 2022-06-25 08:34:09.704595
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module = CallbackModule()
    callback_module.v2_on_file_diff("ansible.utils.unicode.AnsiballZ_template")


# Generated at 2022-06-25 08:34:18.232962
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    # Initialize the mock object
    mock_included_file = MagicMock()

    # Assign a return value for method get_filename
    mock_included_file.get_filename.return_value = 'some_filename'

    # Assign a return value for method get_hosts
    mock_included_file.get_hosts.return_value = ['host1', 'host2']

    # Assign a return value for method get_vars
    mock_included_file.get_vars.return_value = {'var1':'value1', 'var2':'value2'}

    callback_module_1 = CallbackModule()

# Generated at 2022-06-25 08:34:19.054996
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    pass


# Generated at 2022-06-25 08:34:25.033969
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module = CallbackModule()
    options = dict(
        show_custom_stats = True,
        display_skipped_hosts = False,
        display_ok_hosts = True,
        display_failed_stderr = False,
        show_per_host_start = False,
        check_mode_markers = False,
    )
    callback_module.set_options(options)
    assert callback_module.show_custom_stats == True
    assert callback_module.display_skipped_hosts == False
    assert callback_module.display_ok_hosts == True
    assert callback_module.display_failed_stderr == False
    assert callback_module.show_per_host_start == False
    assert callback_module.check_mode_markers == False
    assert callback_module.verbosity

# Generated at 2022-06-25 08:34:29.256680
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():

    # Create a mock result object
    class mock_result_0(object):
        def __init__(self, url=None, host=None):
            self.url = url or 'https://mock.example.com/mock/job/id'
            self.host = host or 'mock_host'

            self.async_result = {
                'api_job_id' : self.url
            }

    callback_module_0 = CallbackModule()

    result_0 = mock_result_0()

    callback_module_0.v2_runner_on_async_failed(result_0)

# Generated at 2022-06-25 08:34:34.640633
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    result = callback_module_0.set_options(direct={u'dest': u'/etc/ansible_sshpass', u'owner': u'test_owner', u'mode': u'0660'})
    assert result == None


# Generated at 2022-06-25 08:34:46.222336
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    result = Result()
    callback_module_0 = CallbackModule()
    host = Host()
    task = Task()
    task.action = '...'
    task.loop = '...'
    task.delegate_to = '...'
    task.delegate_facts = '...'
    task.environment = '...'
    task.name = '...'
    task.tags = '...'
    task.args = '...'
    task.any_errors_fatal = '...'
    task.become = '...'
    task.become_method = '...'
    task.become_user = '...'
    task.become_flags = '...'
    task.changed_when = '...'
    task.check_mode = '...'
    task.connection = '...'


# Generated at 2022-06-25 08:34:56.045584
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    json_path = './test/json/v2_runner_on_ok_data.json'
    with open(json_path, 'r') as f:
        result_json = json.load(f)

    module_name = "./test/modules/debug_module.py"
    tmp_module_file = "./test/modules/debug_module.py"


# Generated at 2022-06-25 08:35:03.738065
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    # Create an instance of class CallbackModule
    callback_module_1 = CallbackModule()

    # Create an instance of class Host
    host_1 = Host('localhost')

    # Create an instance of class Result

# Generated at 2022-06-25 08:35:09.870815
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Load up a fake result
    result = AnsibleResult()
    result._result['changed'] = False
    result._result['redirected'] = False
    result._result['_ansible_no_log'] = False
    result._result['_ansible_verbose_always'] = False
    result._result['item'] = {}
    result._task = AnsibleTask()
    result._task._uuid = '123456789'
    result._task.action = 'shell'
    result._task.no_log = False
    result._task.args = {}
    result._host.get_name.return_value = 'localhost'

    # Initialize the callback
    callback_module_0 = CallbackModule()
    callback_module_0.display_ok_hosts = True
    callback_module_0._last_task