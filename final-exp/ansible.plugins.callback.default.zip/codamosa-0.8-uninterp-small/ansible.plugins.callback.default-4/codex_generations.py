

# Generated at 2022-06-25 08:26:10.040732
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    callback_module_0 = CallbackModule()
    result_0 = Result()

# Generated at 2022-06-25 08:26:15.351511
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    callback_module_0 = CallbackModule()
    result_0 = RunnerResult()
    callback_module_0.v2_runner_on_unreachable(result_0)


# Generated at 2022-06-25 08:26:20.818146
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    # Attempts to get the async job ID. If the job does not finish before the async timeout value, the ID may be within the unparsed 'async_result' dict.
    callback_module_0 = CallbackModule()

    # Tests for argument result of type dict
    # Tests for argument result of type dict
    # Tests for argument result of type dict
    # Tests for argument result of type dict


# Generated at 2022-06-25 08:26:28.763030
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    """
    Test that a playbook can be executed
    """
    # Create a new instance of "CallbackModule" class
    callback_module_instance = CallbackModule()
    # Create a new instance of "Playbook" class
    playbook_instance = Playbook()

    try:
        callback_module_instance.v2_playbook_on_start(playbook_instance)
    except Exception as e:
        print("v2_playbook_on_start")
        print("Exception: " + str(e))
        assert False


# Generated at 2022-06-25 08:26:38.477136
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    var_0 = set_options()
    var_0.add_option(dest='display_skipped_hosts', default=False, help="show skipped hosts", action='store_true')
    var_0.add_option(dest='display_ok_hosts', default=True, help="show ok hosts", action='store_true')
    var_0.add_option(dest='show_custom_stats', default=False, help='Show custom stats', action='store_true')
    var_0.add_option(dest='show_path_paste', default=False, help="Show the path to the task on the target host", action='store_true')

# Generated at 2022-06-25 08:26:40.252310
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    callback_module_0 = CallbackModule()
    var_0 = callback_v2_playbook_on_include()


# Generated at 2022-06-25 08:26:48.461529
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    mock_callback_module_instance = Mock(spec=CallbackModule)
    result = Mock(spec=Result)
    callback_mock_0 = Mock(spec=type(callback_module_0))
    mock_callback_module_instance.get_option.return_value = callback_mock_0.get_option()
    mock_callback_module_instance.display_ok_hosts = callback_mock_0.display_ok_hosts
    mock_callback_module_instance._last_task_banner = callback_mock_0._last_task_banner
    mock_callback_module_instance._print_task_banner = callback_mock_0._print_task_banner
    mock_callback_module_instance._last_task_name = callback_mock_0._last_task_name
    mock_callback

# Generated at 2022-06-25 08:26:56.346863
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    callback_module_0 = CallbackModule()
    handler_0 = object()
    host_0 = object()
    # ASAN buid failed with 'callback_module_0.v2_playbook_on_notify(handler_0, host_0)'
    # The problem is probably caused by 'callback_module_0' with uninitialized memory in case
    # 'class CallbackModule' with all fields being zero initialized.
    callback_module_0.v2_playbook_on_notify(handler_0, host_0)


# Generated at 2022-06-25 08:26:59.518636
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    arg_0 = callback_module_0
    arg_1 = callback_v2_playbook_on_start()
    ret_0 = arg_0.v2_playbook_on_start(arg_1)
    print(ret_0)


# Generated at 2022-06-25 08:27:04.255207
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create an instance of class CallbackModule with default arguments
    callback_module_0 = CallbackModule()
    # Create an instance of class Result
    result_0 = Result()
    # Call method v2_runner_on_failed of class CallbackModule on instance callback_module_0 with argument result_0
    # Method should not throw exception
    callback_module_0.v2_runner_on_failed(result_0)



# Generated at 2022-06-25 08:27:28.870996
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    result = Mock()
    result.task_name = "TASK NAME TASK NAME"
    result.task_action = 'task action'

# Generated at 2022-06-25 08:27:31.969728
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()
    callback_module_1.v2_playbook_on_start()


# Generated at 2022-06-25 08:27:39.644055
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    import ansible.plugins.callback.json
    callback_module = ansible.plugins.callback.json.CallbackModule()
    import ansible.plugins.callback.default
    default_callback_module = ansible.plugins.callback.default.CallbackModule()
    import ansible.playbook.play
    play = ansible.playbook.play.Play()
    import ansible.playbook.task
    task = ansible.playbook.task.Task()
    import ansible.playbook.block
    block = ansible.playbook.block.Block()
    import ansible.runner.return_data
    result = ansible.runner.return_data.ReturnData()
    callback_module.v2_runner_on_start(host='127.0.0.1', task=task)
    callback_module.v2_playbook_

# Generated at 2022-06-25 08:27:42.468369
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    try:
        callback_module_0.v2_playbook_on_start("playbook")
    except:
        pass


# Generated at 2022-06-25 08:27:44.532149
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()

    callback_module_0.set_options({
        "show_custom_stats": False
        })


# Generated at 2022-06-25 08:27:47.759412
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # call function v2_runner_on_ok with valid args
    callback_module_0 = CallbackModule()
    result_0 = AnsibleResult()
    callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:27:52.255696
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    callback_module_1 = CallbackModule()
    class Temp:
        pass
    ansible_job_id = '1'
    host = Temp()
    host.get_name = lambda: 'localhost'

    result = Temp()
    result.ansible_job_id = 1
    result._host = host
    result._result = {'ansible_job_id': ansible_job_id}

    callback_module_1.v2_runner_on_async_ok(result)


# Generated at 2022-06-25 08:27:53.408287
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    test_case_0()

# Generated at 2022-06-25 08:27:59.040653
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    # test setup
    module_callback_0 = CallbackModule()
    test_include_file = IncludeFile(None, None, None, None)

    # perform unit test
    module_callback_0.v2_playbook_on_include(test_include_file)

    # save test results
    with open('results.pkl', 'wb') as output:
        pickle.dump(module_callback_0, output)


# Generated at 2022-06-25 08:28:05.092651
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    assert callback_module_0 is not None
    assert isinstance(callback_module_0, CallbackModule)
    option_values = dict()
    option_values['verbosity'] = '3'
    callback_module_0.set_options(option_values)


# Generated at 2022-06-25 08:28:24.888491
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    callback_module_0 = CallbackModule()
    test_host_0 = Host(name='test_host_0')
    test_task_0 = Task(name='test_task_0')
    callback_module_0.v2_runner_on_start(test_host_0, test_task_0)


# Generated at 2022-06-25 08:28:27.017898
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    callback_module_1 = CallbackModule()
    result = Result(None)
    callback_module_1.v2_runner_retry(result)


# Generated at 2022-06-25 08:28:31.001252
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    callback_module = CallbackModule()
    callback_module.display_skipped_hosts = True
    result = Result()
    result._host = Host()
    result._host.get_name = lambda: "test_host"
    result._task = Task()
    result._task.action = "test_action"
    result._result = "test_result"
    callback_module.v2_runner_item_on_skipped(result)


# Generated at 2022-06-25 08:28:33.505634
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_1 = CallbackModule()
    callback_module_1.set_options()


# Generated at 2022-06-25 08:28:39.109786
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    print ("\n===== CallbackModule_set_options =====\n")

    option_results = {
        "show_custom_stats": True,
        "show_hidden": False,
        "show_skipped": True,
        "skip_tags": [],
        "start_at_task": "",
        "step": False,
        "verbosity": 0
    }

    cb = CallbackModule()
    cb.set_options(option_results)
    
    print ("\n===== END OF CallbackModule_set_options =====\n")


# Generated at 2022-06-25 08:28:43.630402
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_include('test_on_include_filename')

# Generated at 2022-06-25 08:28:46.269730
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    callback_module = CallbackModule()
    callback_module.v2_playbook_on_play_start("play")


# Generated at 2022-06-25 08:28:50.287267
# Unit test for method v2_playbook_on_start of class CallbackModule

# Generated at 2022-06-25 08:28:55.095811
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    callback_module = CallbackModule()
    callback_module.v2_runner_item_on_skipped("reslut")
    assert callback_module.display_skipped_hosts == True
    assert callback_module.display_ok_hosts == True


# Generated at 2022-06-25 08:28:59.273989
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    callback_module_1 = CallbackModule()
    result = None # TODO: implement test
    callback_module_1.v2_runner_on_skipped(result)


# Generated at 2022-06-25 08:29:41.928260
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    callback_module_0 = CallbackModule()

    # Variable 'handler' (line 289)
    # Set to an object of one of the following types:
    #     ActionBase
    handler = ''
    # Variable 'host' (line 290)
    # Set to an object of one of the following types:
    #     Host
    #     Inventory
    host = ''

    # Call method v2_playbook_on_notify of class CallbackModule
    callback_module_0.v2_playbook_on_notify(handler, host)

    # Cleanup test
    try:
        del callback_module_0
    except NameError:
        pass


# Generated at 2022-06-25 08:29:49.344626
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    print('%s' % 'test_CallbackModule_v2_runner_item_on_failed')
    callback_module_0 = CallbackModule()
    result_0 = Mock()
    result_0._task = Mock()
    result_0._task.action = 'action_0'
    result_0._result = {'_ansible_no_log': False, '_ansible_item_result_counter': 0, '_ansible_parsed': True}
    result_0._result['stdout_lines'] = ['stdout_lines_0']
    result_0._result['warnings'] = []
    result_0._host = Mock()
    result_0._host.get_name = Mock()
    result_0._host.get_name.return_value = 'host_name_0'
    result_

# Generated at 2022-06-25 08:29:52.241476
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    callback_module_1 = CallbackModule()
    callback_module_1._last_task_banner = 'abc'
    result = {
        '_host': 'host1',
        '_task': {
            'action': 'action1'
        }
    }
    callback_module_1.v2_runner_item_on_failed(result)


# Generated at 2022-06-25 08:30:00.329084
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    path_name = "/Users/stella/Dropbox/ansible_git/ansible/test/sanity/targets/module_included_1/playbooks/main.yml"
    vars_ = {}
    hosts = ["localhost"]
    callback_module = CallbackModule()
    callback_module.v2_playbook_on_include(IncludedFile(path_name, vars_, hosts))


# Generated at 2022-06-25 08:30:07.575463
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    import sys
    import os
    import tempfile

    #test_ansible_directory = os.getcwd()
    test_ansible_directory = os.path.join( os.path.dirname(os.path.realpath(__file__)) , "..")

# Generated at 2022-06-25 08:30:13.519447
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    stats_0 = {"skipped": 0, "ok": 0, "changed": 0, "dark": {"skipped": 0, "ok": 0, "changed": 0, "failures": 0}, "failures": 0, "processed": {"skipped": 0, "ok": 0, "changed": 0, "failures": 0}}
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_stats(stats_0)


# Generated at 2022-06-25 08:30:15.006902
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    callback_module_1 = CallbackModule()
    result_2 = 'result'
    CallbackModule.v2_runner_item_on_ok(callback_module_1, result_2)


# Generated at 2022-06-25 08:30:21.754483
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    callback_module_0 = CallbackModule()
    module_0 = AnsibleModule()
    module_0._hosts = set()
    module_0._vars = dict()
    module_0._options = dict()
    module_0._options['_ansible_verbosity'] = 2
    module_0._options['_ansible_check_mode'] = False
    module_0._options['_ansible_no_log'] = False
    module_0._options['_ansible_debug'] = False
    module_0._options['_ansible_remote_tmp'] = './test/tmp'
    module_0._options['_ansible_remote_tmp_exec_tmpdir'] = './test/tmp'
    module_0._options['_ansible_diff'] = False

# Generated at 2022-06-25 08:30:23.752017
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    callback_module_0 = CallbackModule()
    result_0 = Result()
    assert callback_module_0.v2_runner_item_on_skipped(result_0) is None


# Generated at 2022-06-25 08:30:29.426472
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():

    class MockForClass(object):
        def __init__(self, task, result):
            self._task = task
            self._result = result

    class MockForResult(object):
        def __init__(self, task, result):
            self._task = task
            self._result = result

    class MockForTask(object):
        def __init__(self, loop, action, name):
            self.loop = loop
            self.action = action
            self.name = name
            self._uuid = 'task_id_001'

    callback_module = CallbackModule()
    callback_module.display = Display(verbosity=0)
    callback_module.display_ok_hosts = True
    callback_module.display_skipped_hosts = True
    callback_module.last_task_banner = None



# Generated at 2022-06-25 08:31:07.196638
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(None)


# Generated at 2022-06-25 08:31:12.248047
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    callback_module_0 = CallbackModule()
    with patch('ansible.plugins.callback.CallbackModule.v2_playbook_on_play_start') as start_mock:
        callback_module_0.v2_playbook_on_play_start({'name': 'test_play_name', 'check_mode': True})
        start_mock.assert_called_once_with({'name': 'test_play_name', 'check_mode': True})


# Generated at 2022-06-25 08:31:21.413250
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    #test_module_0 = CallbackModule()
    test_module_0 = HostVars()
    test_result_0 = Result(
        host = Host(
            name = "192.168.1.1"
        ),
        task = Task(
            action = "ping"
        ),
        result = {
            "failed" : True
        }
    )
    test_module_0.v2_runner_on_failed(test_result_0)
    print(test_module_0.task_ok)
    print(test_module_0.task_failed)

# Generated at 2022-06-25 08:31:26.660816
# Unit test for method v2_runner_on_async_poll of class CallbackModule

# Generated at 2022-06-25 08:31:31.376653
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    callback_module_1 = CallbackModule()
    result = mock.MagicMock()
    callback_module_1.v2_runner_on_skipped(result)


# Generated at 2022-06-25 08:31:40.071768
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    # to keep tests running
    import sys
    sys.path.insert(0, "/usr/lib/python2.7/dist-packages/ansible/plugins")
    import action
    import ansible.constants as C
    from ansible.compat.tests import unittest

    class TestActionModule(unittest.TestCase):

        @mock.patch('ansible.plugins.action.ActionBase.run')
        def test_notify(self, mock_run):
            options = {'dest': '/tmp/test.txt'}
            options['content'] = 'something'
            action = action.ActionModule(task=None, connection=None, play_context=None, loader=None,
                                         templar=None, shared_loader_obj=None)

# Generated at 2022-06-25 08:31:42.943970
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    callback_module = CallbackModule()
    result = Result()
    callback_module.v2_runner_on_async_poll(result)
    assert callback_module.v2_runner_on_async_poll.__doc__


# Generated at 2022-06-25 08:31:47.897917
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    callback_module_0 = CallbackModule()
    mock_host_0 = Mock(name='host_0')
    mock_task_0 = Mock(name='task_0')
    mock_host_0.get_name.return_value = 'mock_host_name_0'
    mock_task_0.get_name.return_value = 'mock_task_name_0'
    callback_module_0.v2_runner_on_start(mock_host_0, mock_task_0)


# Generated at 2022-06-25 08:31:54.650870
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    from ansible.parsing import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.hostvars import HostVars

    callback_module_1 = CallbackModule()
    callback_module_1.display_skipped_hosts = True
    callback_module_1._last_task_banner = 0
    callback_module_1._last_task_name = "test-task-name"

    class StubHost(Host):
        def get_name(self):
            return "test-host-name"

# Generated at 2022-06-25 08:31:58.699752
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    callback_module_1 = CallbackModule()

    class RunnerResult(object):
        def __init__(self, task_name, _result, async_val):
            self._result = _result
            self.task_name = task_name
            self.is_async = async_val

    task = RunnerResult('test_task_name', {'changed': False}, False)
    callback_module_1.v2_runner_item_on_ok(task)


# Generated at 2022-06-25 08:33:02.941520
# Unit test for method v2_playbook_on_play_start of class CallbackModule

# Generated at 2022-06-25 08:33:04.493454
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    callback_module = CallbackModule()
    host = None
    task = None

    callback_module.v2_runner_on_start(host, task)



# Generated at 2022-06-25 08:33:09.885075
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    ansible_options = dict()
    ansible_options['check_mode'] = True
    ansible_options['verbosity'] = 9
    ansible_options['action_plugins'] = []
    ansible_options['connection_plugins'] = []
    ansible_options['loop_plugins'] = []
    ansible_options['shell_plugins'] = []
    ansible_options['strategy_plugins'] = []
    ansible_options['cache_plugins'] = []
    ansible_options['test_plugins'] = []
    ansible_options['fragment_plugins'] = []

    callback_module = CallbackModule()
    callback_module.set_options(ansible_options)


# Generated at 2022-06-25 08:33:19.018241
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():

    # create a fake result object with extra information
    result = FakeResult(
        task_name='test_task',
        host=FakeHost('hostname'),
        _result={
                'failed': True,
                'retries': 3,
                'attempts': 1
            }
    )

    # case 0: test result is failed but retries are still available
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_retry(result)

    # case 1: result is failed and no more retries are available
    result._result['attempts'] = 3
    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_retry(result)

if __name__ == '__main__':
    # test_case_0()
    test

# Generated at 2022-06-25 08:33:20.376555
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    callback_module = CallbackModule()
    callback_module.v2_runner_on_start('localhost', 'task_1')


# Generated at 2022-06-25 08:33:30.233181
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    callback_module_0 = CallbackModule()
    # <class 'ansible.vars.manager.VariableManager'> type object
    variable_manager_0 = VariableManager()
    loader_0 = DataLoader()
    # AnsibleLoader type object
    inventory_0 = Inventory(loader=loader_0, variable_manager=variable_manager_0)
    # <class 'ansible.playbook.play_context.PlayContext'> type object
    play_context_0 = PlayContext()
    # <class 'ansible.playbook.task.Task'> type object
    task_0 = Task()
    # <class 'ansible.inventory.host.Host'> type object
    host_0 = Host(name='test-server')
    # <class 'ansible.executor.task_result.TaskResult'> type object
    result_0 = Task

# Generated at 2022-06-25 08:33:32.398903
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    callback_module_0 = CallbackModule()
    stats_0 = Stats()
    callback_module_0.v2_playbook_on_stats(stats_0)


# Generated at 2022-06-25 08:33:41.010713
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    work_dir = 'files/playbook_on_include'
    # Create test files and directories in the work_dir
    print('Create test files and directories in the work_dir')
    with open(work_dir + '/hosts','w') as f:
        f.write('localhost\n')
        f.close()
    with open(work_dir + '/main.yml','w') as f:
        f.write('---\n- include: include1.yml var=val')
        f.close()
    with open(work_dir + '/include1.yml','w') as f:
        f.write('name: "it works"')
        f.close()
    os.chdir(work_dir)
    # Perform test
    print('Perform test')

# Generated at 2022-06-25 08:33:49.392848
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    task = Task()
    conf = Config()
    conf.options = {'ansible_connection': 'local', 'name': 'skip_tags_tags'}
    task.name = 'Test'
    task.args = conf
    task.action = 'setup'
    task.set_loader(None)

    host = Host('127.0.0.1')
    host_name = host.name

    result = Result(host_name, task)
    result._result = {'changed': False, 'skipped': True}
    result._task = task
    result._host = host
    callback_module = CallbackModule()
    callback_module.v2_playbook_on_task_start(task)

    stats = Stats()
    stats.summarize = MagicMock()
    stats.summarize.return_value

# Generated at 2022-06-25 08:33:52.113511
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    tmp_s = StringIO()
    sys.stdout = tmp_s
    callback_module_1 = CallbackModule()
    tmp_s.truncate(0)
    tmp_s.seek(0)
    res = sys.stdout.read()
    assert (res == "")
    

# Generated at 2022-06-25 08:35:39.402189
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_item_on_ok({'_result': {}, '_task': {'action': 'test action', 'no_log': True}, '_host': {'get_name': lambda: 'get_name'}})


# Generated at 2022-06-25 08:35:43.459775
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()
    options = {}
    result = callback_module_0.set_options(options)
    assert isinstance(result, object) is False
