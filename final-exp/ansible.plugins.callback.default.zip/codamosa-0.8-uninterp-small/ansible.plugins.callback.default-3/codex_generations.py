

# Generated at 2022-06-25 08:26:28.941941
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    class Mock_display(object):
        def __init__(self):
            self.displayed = ""
        def display(self, msg, color=None, stderr=False, log_only=False, screen_only=False):
            self.displayed = msg

    class Mock_result(object):
        def __init__(self):
            self.task_name = "Mock_task"
            self._task = "Mock_task"
        def _run_is_verbose(self, verbosity=0):
            return True

    mock_result = Mock_result()
    mock_result._result = dict()
    mock_result._result["attempts"] = 1
    mock_result._result["retries"] = 3

    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:26:32.494618
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    task_name = 'task1'
    host_label = 'host_label_1'
    result = Result(host='host1', task_name=task_name)
    result._result['retries'] = 3
    result._result['attempts'] = 1
    result._run_is_verbose = lambda x, verbosity=None: True
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_retry(result)


# Generated at 2022-06-25 08:26:36.403859
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    _result = {
        'invocation': {'module_name': 'setup', 'module_args': ''}
    }
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_unreachable(None, _result)


# Generated at 2022-06-25 08:26:38.003294
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    test_case_0()

###############################################################################
# Main function.
###############################################################################


# Generated at 2022-06-25 08:26:45.094294
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    # Test #0
    CallbackModule().v2_runner_on_start(
        host=None
        , task=None
    )
    # Test #1
    CallbackModule().v2_runner_on_start(
        host=object
        , task=object
    )
    # Test #2
    CallbackModule().v2_runner_on_start(
        host=type
        , task=type
    )
    # Test #3
    CallbackModule().v2_runner_on_start(
        host=str
        , task=str
    )
    # Test #4
    CallbackModule().v2_runner_on_start(
        host=int
        , task=int
    )
    # Test #5

# Generated at 2022-06-25 08:26:47.374051
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()


# Generated at 2022-06-25 08:26:51.010137
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Setup test
    result = Result(None, dict())

    # Expected result
    expected_result = 0

    # Call function that uses test_case_0
    result = callback_module_0.v2_runner_on_failed(result)

    # Error if result != expected_result
    assert result == expected_result, "Error in v2_runner_on_failed"


# Generated at 2022-06-25 08:26:52.689837
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    callback_module_1 = CallbackModule()
    callback_module_1.display_skipped_hosts = False
    callback_module_1.display_skipped_hosts = True


# Generated at 2022-06-25 08:27:00.796090
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    callback_module_0 = CallbackModule()
    test_case_0.v2_playbook_on_include_0 = None

    # Set up mock object named 'task_include_0'
    task_include_0 = mock.Mock()
    task_include_0.run.return_value = None
    task_include_0._filename = None
    task_include_0._hosts = None
    task_include_0._vars = None

    def test_target():
        callback_module_0.v2_playbook_on_include(task_include_0)

    test_case_0.v2_playbook_on_include_0 = test_target

    test_case_0.v2_playbook_on_include_0()


# Generated at 2022-06-25 08:27:04.872227
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    result_0 = FakeResult()
    result_0._task = FakeTask()
    result_0._result = 'foo'
    result_0._result['diff'] = "diff"
    result_0._task.loop = True
    result_0._result['changed'] = False
    callback_module_0.v2_on_file_diff(result_0)
    assert 'foo' == result_0._result


# Generated at 2022-06-25 08:28:00.155063
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    print('>>> test_CallbackModule_v2_playbook_on_start')
    # prepare parameters
    playbook = 0

    # call method
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook)
    
    # check result
    print('<<< test_CallbackModule_v2_playbook_on_start')


# Generated at 2022-06-25 08:28:07.955826
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    runner_result = MagicMock(spec=Result)
    runner_result._host.get_name.return_value = "host"
    runner_result._host.name = "host"
    runner_result._host.get_vars.return_value = {}
    runner_result._result = {"unreachable": True}

    runner_result.task_name = "task_name"

    callback_module = CallbackModule()
    callback_module._display = MagicMock(spec=Display, colorize=Mock())
    callback_module._last_task_banner = 1
    callback_module._task_type_cache = {}

    callback_module.v2_runner_on_unreachable(runner_result)

    runner_result._host.get_name.assert_called_once()

# Generated at 2022-06-25 08:28:16.697759
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    callback_module_0 = CallbackModule()

    class Host:
        def get_name(self):
            return(None)

    class Result:
        def __init__(self, host, result):
            self._host = host
            self._result = result

    callback_module_0.v2_runner_on_async_failed(Result(Host(), {'ansible_job_id': None, 'async_result': {'ansible_job_id': None}}))
    callback_module_0.v2_runner_on_async_failed(Result(Host(), {'ansible_job_id': 'async_job_id', 'async_result': {'ansible_job_id': None}}))

# Generated at 2022-06-25 08:28:24.372556
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    callback_module = CallbackModule()
    AsyncResult = namedtuple('AsyncResult', 'host, result')
    host = Host(name='bogus.host')
    result = dict(ansible_job_id=42, async_result=dict(ansible_job_id=54))
    async_result = AsyncResult(host=host, result=result)
    callback_module.v2_runner_on_async_failed(async_result)


# Generated at 2022-06-25 08:28:27.763880
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    class test_v2_runner_item_on_ok(unittest.TestCase):
        def test_Callable_Instance(self):
            self.assertIsInstance(CallbackModule().v2_runner_item_on_ok, Callable)
    unittest.main()


# Generated at 2022-06-25 08:28:30.913165
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():

    callback_module_1 = CallbackModule()
    class result():
        task_name = "test1"
        host_label = "test2"
        results = "test3"
        action ="test4"

    result_1 = result()

    callback_module_1.v2_runner_item_on_failed(result_1)


# Generated at 2022-06-25 08:28:35.286146
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    callback_module_0 = CallbackModule()
    play = MagicMock()
    callback_module_0.v2_playbook_on_play_start(play)

    # One property has changed
    assert callback_module_0._play == play


# Generated at 2022-06-25 08:28:43.957558
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    # Arrange
    callback_module_0 = CallbackModule()
    result_0 = Result()
    result_0._host = None
    result_0._result = {}
    result_0._task = None
    result_0._task_fields = None
    result_0._task_include = None
    result_0.exception = None
    result_0.failed = False
    result_0.task_name = None
    result_0.task_action = None
    result_0.task_args = {}
    result_0.task_ds = None    
    # Act
    callback_module_0.v2_runner_retry(result_0)
    # Assert



# Generated at 2022-06-25 08:28:46.794879
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    callback_module_0 = CallbackModule()
    import ansible.plugins.callback.default
    TaskResult = ansible.plugins.callback.default.TaskResult

    runner_result_0 = TaskResult('example')

    callback_module_0.v2_runner_on_skipped(runner_result_0)



# Generated at 2022-06-25 08:28:52.819792
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()

    result_1 = Result()
    result_1._host = Host()
    result_1._host.name = 'controller'
    result_1.task_name = 'ping'
    result_1.task_action = 'ping'

    result_1._result = {}
    result_1._result['stderr'] = 'Could not resolve hostnames'
    result_1._result['stdout'] = ''
    result_1._result['rc'] = 0
    result_1._result['stdout_lines'] = []
    result_1._result['changed'] = True
    result_1._result['stderr_lines'] = ['Could not resolve hostnames']
    result_1._result['failed'] = True

# Generated at 2022-06-25 08:30:56.875700
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook = None
    callback_module = CallbackModule()
    callback_module.v2_playbook_on_start(playbook)


# Generated at 2022-06-25 08:31:07.985368
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():

    # create a mock result object 
    res = mock.Mock()
    res._task = mock.Mock()
    res._result = {
            "changed": False,
            "diff": {
                "after": "",
                "before": "",
                "before_header": "",
                "after_header": ""
                }
            }

    # create a mock task object
    task = mock.Mock()
    task.loop = False
    #assign task to result object
    res._task = task

    callback_module_v2_on_file_diff = CallbackModule()

    # test case : with diff
    res._result["diff"] = "diff_value"
    callback_module_v2_on_file_diff.v2_on_file_diff(res)

    # test case : with

# Generated at 2022-06-25 08:31:10.301476
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    callback_module = CallbackModule()
    callback_module.v2_runner_on_async_failed({'_host':Mock(spec=ansible.inventory.host.Host)})

# Generated at 2022-06-25 08:31:19.098957
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    task_name = "unit_test_task_name"
    host_label = "unit_test_host_label"
    result_retries = 3
    result_attempts = 2
    unit_test_result = MockResult(task_name, host_label, result_retries, result_attempts)
    callback_module_v2_runner_retry_test_0 = CallbackModule()
    callback_module_v2_runner_retry_test_0.v2_runner_retry(unit_test_result)
    assert callback_module_v2_runner_retry_test_0.v2_runner_retry_result == \
           "FAILED - RETRYING: [" + host_label + "]: " + task_name + " (1 retries left)."


# Generated at 2022-06-25 08:31:25.530492
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    # If 'class' is not in attrs at all, set_options should set the value in the _options element to the default
    # value for that option.
    callback_module = CallbackModule()
    callback_module.set_options({})
    assert callback_module._options == {
        'display_skipped_hosts': True,
        'display_ok_hosts': True,
        'show_custom_stats': False,
        'display_failed_stderr': False,
        'display_verbosity': True,
        'show_per_host_start': False,
    }

    # If an option is present in the attrs element, set_options should set the value in the _options element to
    # the value in the attrs element.
    callback_module = CallbackModule()
    callback_module.set_

# Generated at 2022-06-25 08:31:30.909639
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Execute method under test and record results
    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_on_failed(
        result=None
    )


# Generated at 2022-06-25 08:31:33.159908
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    test_case_0()

if __name__ == "__main__":
    test_CallbackModule_v2_playbook_on_start()

# Generated at 2022-06-25 08:31:37.287463
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    callback_module_0 = CallbackModule()
    result = RunnerResult()
    result._host = RunnerResult()
    result._host.get_name = MagicMock(return_value='get_name')
    callback_module_0.v2_runner_on_unreachable(result)


# Generated at 2022-06-25 08:31:42.709482
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    callback_module_0 = CallbackModule()
    result_0 = mock.Mock()
    result_0.attached_to_host.return_value = 'mock-result.attached_to_host'
    result_0._host.get_name.return_value = 'mock-result._host.get_name'
    result_0._result.get.return_value = 'mock-result._result.get'
    callback_module_0.v2_runner_on_async_poll(result_0)


# Generated at 2022-06-25 08:31:46.866140
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    callback_module = CallbackModule()
    result = Result()

    # first case, when result is None
    result._result = None
    result._task = TaskInclude()

    # second case, when result is not None
    result._result = {}
    result._result['changed'] = True
    result._task = TaskInclude()
    callback_module.v2_runner_item_on_ok(result)


# Generated at 2022-06-25 08:34:43.025999
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()
    callback_module_1.v2_playbook_on_start(playbook=None)


# Generated at 2022-06-25 08:34:46.514586
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    # test case 1
    global callback_module_0
    callback_module_0.v2_runner_on_start(self=callback_module_0, host=None, task=None)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 08:34:54.369785
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    print('Method v2_runner_on_async_poll')
    test_result = Result()
    test_task = Task()
    test_task.set_name('test task')
    test_task.set_action('test action')
    test_result._result = {
        'ansible_job_id': 'notNone',
        'started': 'notNone',
        'finished': 'notNone'
    }
    test_result._task = test_task
    test_callback_module = CallbackModule()
    test_callback_module.v2_runner_on_async_poll(test_result)


# Generated at 2022-06-25 08:34:56.526594
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_notify(Handler(), Host())


# Generated at 2022-06-25 08:35:02.222297
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    runner_result = RunnerResult()
    runner_result._host = Host('host')
    runner_result._task = TaskInclude()
    runner_result._result = dict()

    callback_module_1 = CallbackModule()
    runner_result._result['unreachable'] = 0

    with patch('sys.stderr', new=StringIO()) as fakeOutput:
        callback_module_1.v2_runner_item_on_failed(runner_result)
        assert fakeOutput.getvalue() == "failed: [host]\n"


# Generated at 2022-06-25 08:35:03.228831
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    assert False, "Test case not implemented"


# Generated at 2022-06-25 08:35:09.360575
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    # Setting up test environment
    campaign = Campaign(name = 'Test Campaign')
    test = Test(name = 'Test Test')
    test.save()
    campaign.tests.append(test)
    campaign.save()

    playbook = PlaybookFile(name = 'Test Playbook')
    playbook.mainPath = BASE_DIR + '../../sshtunnel/playbooks/ssh_tunnel.yml'
    playbook.save()
    test.playbooks.append(playbook)
    test.save()

    callback_module_0 = CallbackModule()
    play_0 = Play()

    # Call the method to be tested
    callback_module_0.v2_playbook_on_play_start(play_0)

    # Verify the results
    assert True



# Generated at 2022-06-25 08:35:19.646898
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    # Create a "host"
    host = Host(name = "localhost")
    # Create a "task"
    task = Task()
    # Create a "result"
    result = Result()
    # Assign the "host" to the result
    result._host = host
    # Assign the task to the result
    result._task = task
    # Create a "stats" object
    stats = Stats()
    # Set "ok" field of the "stats" object
    stats.ok = {
        host.name: 1
    }
    # Set "changed" field of the "stats" object
    stats.changed = {
        host.name: 2
    }
    # Set "unreachable" field of the "stats" object
    stats.unreachable = {
        host.name: 3
    }
    # Set "

# Generated at 2022-06-25 08:35:30.210276
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    callback_module_0 = CallbackModule()
    result = Result()
    result._host = Host()
    result.task_name = u'module name'
    result._result = dict()
    result._result['attempts'] = 0
    result._result['retries'] = -1
    result._result['verbosity'] = 2
    callback_module_0.v2_runner_retry(result)


# Generated at 2022-06-25 08:35:31.847018
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_1 = CallbackModule()
    callback_module_1.set_options()
