

# Generated at 2022-06-25 08:26:15.294943
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    class mock_result_0():
        def __init__(self):
            self._host = 'host_0'
            self._task = mock_task_0()
            self._result = dict()
            self._result['changed'] = False
        def get_name(self):
            return 'mock_result'
        def __str__(self):
            return 'mock_result'
    class mock_task_0():
        def __init__(self):
            self.action = 'mock_task_action'
        def get_name(self):
            return 'mock_task'
        def __str__(self):
            return 'mock_task'
    class mock_display_0():
        def __init__(self):
            self.verbosity = 0

# Generated at 2022-06-25 08:26:16.743907
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()



# Generated at 2022-06-25 08:26:28.026421
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
	import json
	from ansible_api_exe import AnsibleRunner, AnsibleResult
	from ansible_config import resource_config
	
	raw_result = json.load(open(resource_config.get("playbook_result", "test_data_v2_runner_on_unreachable")))
	def test_runner_on_unreachable(self):
		self._v2_runner_on_unreachable(AnsibleResult(raw_result))
		
	callback_module_0 = CallbackModule()
	callback_module_0.v2_runner_on_unreachable = test_runner_on_unreachable
	callback_module_0.v2_runner_on_unreachable()
	

# Generated at 2022-06-25 08:26:31.076489
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    # Test target
    callback_module = CallbackModule()
    result = type('', (object,), {})()
    result.host = type('', (object,), {'name': 'localhost'})()
    result._result = {}
    callback_module.v2_runner_on_unreachable(result)
    assert callback_module._last_task_banner == None
    assert callback_module._last_task_name == None


# Generated at 2022-06-25 08:26:34.178566
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    result_0 = RunnerResult()
    callback_module_0.v2_runner_on_ok(result_0)



# Generated at 2022-06-25 08:26:35.194789
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    pass


# Generated at 2022-06-25 08:26:40.297511
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    callback_module_0 = CallbackModule()

    result_0 = Result()
    result_0._host = None
    result_0._result = {
        'ansible_job_id': '1',
        'started': '2019-6-28 08:05:10',
        'finished': '2019-6-28 08:05:20'
    }

    callback_module_0.v2_runner_on_async_poll(result_0)


# Generated at 2022-06-25 08:26:48.503999
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():

    # Create a mock task and result object:
    # --> The filename is 'filename_0'.
    # --> The hosts are host_0 and host_1.
    # --> The variables will be assigned to a dictionary which is empty.
    mock_task = mock.Mock()
    mock_task._filename = 'filename_0'
    mock_task._hosts = ['host_0', 'host_1']
    mock_task._vars = dict()

    # Create a mock callback object
    callback_module_0 = CallbackModule()
    callback_module_0._display = mock.Mock()

    # Call the method
    callback_module_0.v2_playbook_on_include(mock_task)

    # Check the result
    # --> The display.display() method of the _display object should be called once.
   

# Generated at 2022-06-25 08:26:59.044945
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    result_0 = {'before': '', 'after': '\n'}
    result_0['changed'] = True
    result_0['diff'] = {'before_header': '', 'after_header': '\n'}
    result_0['diff']['before'] = ''
    result_0['diff']['after'] = ''
    result_0['invocation'] = {'module_args': {'_raw_params': '', '_uses_shell': False, '_tmp_path': '', '_raw_params': '', '_uuid': '', 'creates': '', 'removes': '', 'chdir': '', '_diff': True}}
    result_0['item'] = ''

# Generated at 2022-06-25 08:27:05.142231
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    t0 = time.time()

    # Create test data
    stats = dict()

    # Create an instance of CallbackModule and call method v2_playbook_on_stats
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_stats(stats)

    t1 = time.time()

    # Print execution time
    print(" %f seconds " % (t1 - t0))

if __name__ == '__main__':
    cProfile.run('test_case_0()', '/tmp/profile_results')
    # test_case_0()

# Generated at 2022-06-25 08:27:39.094598
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    task_callback_0 = CallbackModulePlaybookTask()
    host__result_0 = dict()
    host_0 = StatRecord()
    host__result_0["message"] = 'message_1'
    host__result_0["message"] = 'message_2'
    host__result_0["changed"] = 'changed_3'
    host__result_0["changed"] = 'changed_4'
    host__result_0["filename"] = 'filename_5'
    host__result_0["filename"] = 'filename_6'
    host__result_0["checksum"] = 'checksum_7'
    host__result_0["checksum"] = 'checksum_8'
    host__result_0["_ansible_no_log"] = '_ansible_no_log_9'
    host__result_

# Generated at 2022-06-25 08:27:43.331366
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():

    test_dict = {'stderr': ''}
    test_function = CallbackModule().v2_runner_item_on_failed

    try:
        test_function('', '', '', '', '', test_dict, '')
    except:
        return True

    return False


# Generated at 2022-06-25 08:27:44.300651
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    test_case_0()


# Generated at 2022-06-25 08:27:47.244955
# Unit test for method v2_runner_on_skipped of class CallbackModule

# Generated at 2022-06-25 08:27:49.708337
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    """
    Unit test for method v2_runner_item_on_skipped of class CallbackModule
    """
    # TODO: implement test
    return
    
    
    
    

# Generated at 2022-06-25 08:27:53.561674
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    class_instance_0 = callback_module_0
    playbook = type('', (), {})
    class_instance_0.v2_playbook_on_start(playbook)


# Generated at 2022-06-25 08:27:56.403979
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook=None)


# Generated at 2022-06-25 08:28:02.389457
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():

    mock = ansible.utils.plugins.module_loader.find_plugin('CallbackModule')

    mock = Mock(return_value = 'passed')
    def mock_v2_runner_item_on_ok(*args, **kwargs):
        print('\n', 'in the test_v2_runner_item_on_ok', '\n')
        return mock()
    mock.side_effect = mock_v2_runner_item_on_ok
    CallbackModule.v2_runner_item_on_ok = mock
    test_case_0()
    #assert mock.return_value == 'passed'


# Generated at 2022-06-25 08:28:05.433784
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    callback_module_0 = CallbackModule()
    play_0 = Play()
    play_0.vars = dict()
    callback_module_0.v2_playbook_on_play_start(play_0)


# Generated at 2022-06-25 08:28:14.315023
# Unit test for method v2_runner_on_unreachable of class CallbackModule

# Generated at 2022-06-25 08:28:46.666001
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    # Setup
    callback_module_0 = CallbackModule()
    result = MagicMock()
    # Invocation
    callback_module_0.v2_runner_on_async_poll(result)
    # Verification
    # We don't verify that the output was written to stdout, because
    # the magic mock doesn't support that.


# Generated at 2022-06-25 08:28:48.571389
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    # setup
    stats0 = Stats()

    # test
    callback_module_0.v2_playbook_on_stats(stats0)

    # cleanup - none necessary
    assert(True)


# Generated at 2022-06-25 08:28:51.862342
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook = Playbook()
    callback_module_0.v2_playbook_on_start(playbook)



# Generated at 2022-06-25 08:29:03.447023
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    callback_module_1 = CallbackModule()
    context.CLIARGS['check'] = False
    context.CLIARGS['verbosity'] = 1
    result = RunnerResult()
    result._host = Host()
    result._host.get_name = lambda: 'host'
    result._result = {'stdout': 'stdout', 'stderr': 'stderr', 'msg': 'msg'}
    callback_module_1.v2_runner_on_unreachable(result)
    assert callback_module_1._last_task_banner == None
    assert callback_module_1._last_task_name == None
    assert callback_module_1._task_type_cache == {}
    assert callback_module_1.show_custom_stats == True
    assert callback_module_1.display_ok_

# Generated at 2022-06-25 08:29:06.251981
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    print("\n")

    result = {}
    result['_host'] = "192.168.1.1"
    result['changed'] = True

    callback_module = CallbackModule()
    callback_module.v2_runner_on_ok(result)


# Generated at 2022-06-25 08:29:12.086672
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():    
    # Test case 1 - success
    task_name = "task_name"
    host_name = "host_name"
    display_name = "display_name"
    ansible_version = "ansible_version"
    action = "action"

    result = {
        "unreachable": False,
        "skipped": False,
        "changed": True,
        "failed": True,
        "ansible_facts": {
            "_ansible_version": ansible_version
        },
        "msg": "msg"        
    }

    task = Task()
    task.action = action
    task.set_name(task_name)
    task._uuid = "default_uuid"
    task._parent = None

    host = Host(display_name)

# Generated at 2022-06-25 08:29:16.035167
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    '''
    Unit test for method v2_playbook_on_play_start of class CallbackModule
    '''
    callback_module_0 = CallbackModule()

    play = dict()
    play.update({
        'name': 'test',
        'check_mode': 0
    })

    callback_module_0.v2_playbook_on_play_start(play)

# Generated at 2022-06-25 08:29:22.854134
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    import json

    # Ansible all -i hosts -m ping
    hosts_file = 'hosts'
    with open(hosts_file, 'r') as f:
        source = f.read()
    hosts = source.split('\n')
    if hosts[len(hosts) - 1] == '':
        hosts = hosts[:len(hosts) - 1]
    inventory

# Generated at 2022-06-25 08:29:24.832951
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = CallbackModule()
    result_0 = Result()
    callback_module_0.v2_runner_on_failed(result_0)


# Generated at 2022-06-25 08:29:30.804771
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    from ansible.plugins.callback.default import CallbackModule
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    variable_manager = VariableManager()
    loader = DataLoader()
    options = Options()
    callback_module_0 = CallbackModule0()
    callback_module_1 = CallbackModule1()
    callback_module_2 = CallbackModule2()
    callback_module_3 = CallbackModule3()
    callback_module_4 = CallbackModule4()
    callback_module_5 = CallbackModule5()
    callback_module_6 = CallbackModule6()

# Generated at 2022-06-25 08:30:46.376811
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    callback_module_0 = CallbackModule()
    result = namedtuple('result', ['_task', '_host', '_result', '_result'])
    task = namedtuple('task', ['_uuid', 'action'])
    result._task = task('UUID_0', 'SOMETHING')
    result._host._name = 'HOST_NAME'
    result._result = {'local_action': 'rsync', '_ansible_item_label': 'ITEM_LABEL'}
    result._result.update({'stderr': 'STDERR', 'msg': 'MESSAGE'})
    callback_module_0.v2_runner_item_on_failed(result)


# Generated at 2022-06-25 08:30:53.314527
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():

    # Create a mock object of class TaskResult()
    task_result_mock = mock.Mock(spec=TaskResult)

    # create a mock object of class RunnerResult()
    runner_result_mock = mock.Mock(spec=RunnerResult)

    # set '_host.get_name()' of runner result to return a fake host name
    runner_result_mock._host.get_name.return_value = "FAKE_HOST"

    # set '_result' of runner result to be the mock object of class TaskResult()
    runner_result_mock._result = task_result_mock

    callback_module = CallbackModule()

    # Test RunnerResult() object passed as argument to method v2_runner_on_async_failed doesn't have
    # an 'ansible_job_id' key
   

# Generated at 2022-06-25 08:30:56.630089
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    handler = None
    host = 'localhost'
    callback_module = CallbackModule()
    callback_module.v2_playbook_on_notify(handler, host)


# Generated at 2022-06-25 08:31:07.882662
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():

    # test case 0
    callback_module_0 = CallbackModule()
    class result_0:
        _task = True
        _result = {}
    result_0._task = True
    result_0._result = {}
    result_0._result['changed'] = False
    callback_module_0.display_ok_hosts = True
    callback_module_0.v2_runner_item_on_ok(result_0)

    # test case 1
    callback_module_1 = CallbackModule()
    class result_1:
        _task = True
        _result = {}
    result_1._task = True
    result_1._result = {}
    result_1._result['changed'] = False
    callback_module_1.display_ok_hosts = False
    callback_module_1.v2_

# Generated at 2022-06-25 08:31:15.342419
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_0 = CallbackModule()
    playbook = playbook.Playbook()

    # Case 1:
    # Normal case, no issue expected
    callback_module_0.v2_playbook_on_start(playbook)

    # Case 2:
    # CallbackModule._display.verbosity < 1, no issue expected
    callback_module_0._display.verbosity = 0
    callback_module_0.v2_playbook_on_start(playbook)


# Generated at 2022-06-25 08:31:17.804581
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    callback_module_0 = CallbackModule()
    result_0 = Result()
    callback_module_0.v2_runner_on_unreachable(result=result_0)


# Generated at 2022-06-25 08:31:24.025234
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    result_1 = Result()
    result_1._result = {'changed': False, 'diff': 'diff data'}
    result_1._task = Task()
    callback_module_0._last_task_banner = None
    callback_module_0._last_task_name = None
    callback_module_0._task_cache = {}
    callback_module_0._task_type_cache = {}
    callback_module_0._play = Play()
    callback_module_0._play._variable_manager = VariableManager()
    callback_module_0.task = None
    callback_module_0.task_name = None
    callback_module_0.task_start = None
    callback_module_0.task_state = None
    callback_module_0.task_

# Generated at 2022-06-25 08:31:28.355985
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_1 = CallbackModule()
    result = Mock()
    result.task_name = 'task_name'
    result._host = 'localhost'
    result._result = {
        'failed' : True,
        'results_file' : "testcase",
        'exception' : 'Test case exception',
        'traceback' : 'Test case traceback',
    }
    callback_module_1.v2_runner_on_failed(result)

if __name__ == '__main__':
    test_case_0()
    test_CallbackModule_v2_runner_on_failed()

# Generated at 2022-06-25 08:31:29.365436
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    conte

# Generated at 2022-06-25 08:31:36.495376
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():

    from mock import Mock
    from ansible import constants as C
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play

    callback_module = CallbackModule()
    result = Mock()
    result._host = Mock()
    result._result = dict(ansible_job_id='')
    #result._result = dict()
    result._result['async_result'] = dict(ansible_job_id='')
    #result._result['async_result'] = dict()

    callback_module.v2_runner_on_async_failed(result)


# Generated at 2022-06-25 08:34:01.178749
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    runner_result = RunnerResult()
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_skipped(result=runner_result)


# Generated at 2022-06-25 08:34:12.076591
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    callback_module_0 = CallbackModule()
    action_0 = ActionBase()
    attr_0 = {'_result': {'invocation': {'module': 'copy', 'module_name': 'copy', 'module_args': '', 'module_complex_args': {}, 'module_kwargs': {}}}}
    task_0 = Task()
    result_0 = Result(task=task_0, host=attr_0)
    # Tests if it is ok to read the attribute of result_0._result
    assert_true(hasattr(result_0, '_result'))
    # Tests if attr_0 is the same as result_0._result
    assert_true(attr_0['_result'] == result_0._result)

    # Tests if the invocation module is equal to "copy"
    # Then the action

# Generated at 2022-06-25 08:34:16.490839
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    callback_module_0 = CallbackModule()
    task = Task()

    # Call v2_runner_on_unreachable method to check if message is properly printed
    result = Result()._replace(task=task, _host=Host(), _result={"msg": "This is a message"})
    callback_module_0.v2_runner_on_unreachable(result)


# Generated at 2022-06-25 08:34:19.020554
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    callback_module_0 = CallbackModule()
    result_0 = Result(host=None, task=None, result=None, _task_fields=None)
    callback_module_0.v2_runner_item_on_skipped(result_0)

# Generated at 2022-06-25 08:34:20.989191
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    playbook_0 = Playbook()
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_play_start(playbook_0)


# Generated at 2022-06-25 08:34:31.859941
# Unit test for method v2_runner_item_on_failed of class CallbackModule

# Generated at 2022-06-25 08:34:42.649415
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    test_case_0()
    # 初始化一个结果字典
    result_0 = dict()
    result_0['ansible_job_id'] = u'1725846158968.52'
    result_0['_ansible_no_log'] = False
    result_0['changed'] = False
    result_0['_ansible_verbose_always'] = True
    result_0['_ansible_parsed'] = True
    result_0['_ansible_item_result'] = True
    result_0['_ansible_ignore_errors'] = None
    result_0['invocation'] = dict()
    result_0['invocation']['module_name'] = u'ping'

# Generated at 2022-06-25 08:34:45.485824
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    buf = StringIO()
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook=None)


# Generated at 2022-06-25 08:34:51.231050
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    result = _Result()
    result._task = _Task()
    result._task.loop = True
    result._result = {'results': [{'diff': "diff content", 'changed': True}]}
    callback_module_0.v2_on_file_diff(result)


# Generated at 2022-06-25 08:34:59.470988
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()

    class MockSettings(object):
        def __init__(self):
            self.default_cb_name = 'default_cb_name'
            self.display_failed_stderr = 'display_failed_stderr'
            self.action_colors = 'action_colors'
            self.display_skipped_hosts = 'display_skipped_hosts'
            self.display_ok_hosts = 'display_ok_hosts'
            self.check_mode_markers = 'check_mode_markers'
            self.show_custom_stats = 'show_custom_stats'
            self.show_per_host_start = 'show_per_host_start'

    settings = MockSettings()