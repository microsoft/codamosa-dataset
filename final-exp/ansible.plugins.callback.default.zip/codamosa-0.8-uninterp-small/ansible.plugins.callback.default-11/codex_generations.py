

# Generated at 2022-06-25 08:26:05.885575
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    test_case_0()

test_CallbackModule_v2_runner_item_on_ok()

# Generated at 2022-06-25 08:26:08.057400
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    result = None
    try:
        test_case_0()
        result = True
    except:
        result = False
    return result

# Generated at 2022-06-25 08:26:13.386916
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():

    callback_module_0 = CallbackModule()
    result_0 = object()
    result_0.task_name='task_name'
    callback_module_0.v2_runner_on_unreachable(result_0)

    # Validate that the v2_runner_on_unreachable function returns None
    # assert callback_module_0.v2_runner_on_unreachable(result_0) is None


# Generated at 2022-06-25 08:26:16.584178
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    callback_module = CallbackModule()
    assert callback_module.v2_runner_on_unreachable is not None
    callback_module.v2_runner_on_unreachable()


# Generated at 2022-06-25 08:26:27.879314
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    callback_module_0 = CallbackModule()
    # test for the first play's start
    play_0 = Play()
    play_0._hosts = "hosts"
    play_0._variable_manager = "variable_manager"
    play_0._loader = "loader"
    play_0._tasks = "tasks"
    play_0._handlers = "handlers"
    play_0._default_vars = "default_vars"
    play_0._role_names = "role_names"
    play_0._task_include = "task_include"
    play_0._task_errors = "task_errors"
    play_0._name = "name"
    play_0._play_hosts = "play_hosts"
    play_0._order_number = "order_number"

# Generated at 2022-06-25 08:26:33.131072
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    callback_module = CallbackModule()
    class TestTaskMeta(object):
        no_log = False
        check_mode = False
    class TestTask(object):
        action = "copy"
        _uuid = "222222"
        _task_meta = TestTaskMeta()

    class TestResult(object):
        task = TestTask()
        host = "TestHost"

# Generated at 2022-06-25 08:26:35.612326
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    pass


if __name__=='__main__':
    # test_case_0()
    test_CallbackModule_v2_on_file_diff()

# Generated at 2022-06-25 08:26:37.240134
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()
    callback_module.v2_runner_on_failed({})


# Generated at 2022-06-25 08:26:38.852057
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    callback_module = CallbackModule()
    task = TaskInclude()
    callback_module.v2_playbook_on_include(task)


# Generated at 2022-06-25 08:26:45.972761
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import unittest
    # Test case 0
    testcase_0 = TestCase_0()
    testcase_0.test_CallbackModule_v2_runner_on_failed()

    # Test case 1
    testcase_1 = TestCase_1()
    testcase_1.test_CallbackModule_v2_runner_on_failed()

    # Test case 2
    testcase_2 = TestCase_2()
    testcase_2.test_CallbackModule_v2_runner_on_failed()

    # Test case 3
    testcase_3 = TestCase_3()
    testcase_3.test_CallbackModule_v2_runner_on_failed()

    # Test case 4
    testcase_4 = TestCase_4()
    testcase_4.test_CallbackModule_v2_runner_on_failed

# Generated at 2022-06-25 08:27:13.761724
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()
    callback_module._handle_error = MagicMock(return_value=None)
    result = MagicMock()
    callback_module.v2_runner_on_failed(result)
    callback_module._handle_error.assert_called_once()
    callback_module.v2_runner_on_failed(result)
    callback_module._handle_error.assert_called_once()


# Generated at 2022-06-25 08:27:17.037382
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():

    # Arrange
    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule()

    # Act
    callback_module_0.v2_runner_on_async_failed(callback_module_1)

    # Assert



# Generated at 2022-06-25 08:27:20.547593
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create a new instance of the CallbackModule class
    callback_module_0 = CallbackModule()
    # Create a new instance of the Result class
    result_0 = Result()
    # Call method v2_runner_on_ok of CallbackModule with arguments result_0
    callback_module_0.v2_runner_on_ok(result_0)


# Generated at 2022-06-25 08:27:29.213882
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    callback_module_0.display.verbosity = 2
    callback_module_0.display.output = 'asdasd'

    ############################################################################################
    # Test case 0 (normal call):
    ############################################################################################
    test_case = 0

    # Set up a dummy result object
    result = {'changed': False, 'diff': ''}
    task_0 = {}

    # Call function v2_on_file_diff
    callback_module_0.v2_on_file_diff(result, task_0)

    # Check attributes

    # Check if method v2_on_file_diff of class CallbackModule calls v2_on_file_diff on display object

# Generated at 2022-06-25 08:27:34.091497
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Test for when diff is not present in result._result

    # Create an instance of AnsibleTaskResult, a faux object
    # for the purposes of the unit test.  The AnsibleTaskResult
    # object contains an AnsibleTask object and a dictionary
    # containing result data.
    result = AnsibleTaskResult()

    # Add an AnsibleTask object to the result object.
    result._task = MagicMock()

    # Add a dictionary of result data to the result object.
    result._result = {}

    callback = CallbackModule()
    callback.v2_on_file_diff(result)


# Generated at 2022-06-25 08:27:38.836328
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    # Test: Check a non-verbose result
    result = StubResult(task_name='setup', retries=1, attempts=1)
    callback_module = CallbackModule()
    callback_module.v2_runner_retry(result)

    # Test: Check a verbose result
    result = StubResult(task_name='setup', retries=1, attempts=1)
    callback_module = CallbackModule(verbosity=2)
    callback_module.v2_runner_retry(result)

test_case_0()
test_CallbackModule_v2_runner_retry()

# Generated at 2022-06-25 08:27:44.082642
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module = CallbackModule()
    result = Result(dict())
    result._task = Task(dict())
    result._task.loop = True
    result._result = dict()
    result._result["diff"] = [{"before": "test1", "after": "test2"}]
    result._result["changed"] = True
    callback_module.v2_on_file_diff(result)


# Generated at 2022-06-25 08:27:51.776378
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    callback_module_0 = CallbackModule()
    stats_1 = Stats()
    # Unit: 'ok': 5, 'changed': 6, 'unreachable': 7, 'failures': 8, 'skipped': 9, 'rescued': 10, 'ignored': 11,
    # Case 1: 'ok': 5, 'changed': 6, 'unreachable': 7, 'failures': 8, 'skipped': 9, 'rescued': 10, 'ignored': 11,
    stats_1.ok = 5
    stats_1.changed = 6
    stats_1.unreachable = 7
    stats_1.failures = 8
    stats_1.skipped = 9
    stats_1.rescued = 10
    stats_1.ignored = 11
    ans_1 = callback_module_0.v2_

# Generated at 2022-06-25 08:27:54.465814
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    callback_module = CallbackModule()
    callback_module.v2_runner_on_async_ok(result=None)


# Generated at 2022-06-25 08:27:57.257963
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()
    result = Result()
    callback_module_0.v2_on_file_diff(result)
    assert False


# Generated at 2022-06-25 08:28:26.269980
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    name = 'test_name'
    result = {'retries':3, 'attempts':2, 'task_name':name}
    class TestHost(object):
        def get_name(self):
            return 'testHost'

    class TestTask(object):
        def __init__(self):
            self.name = name

    class TestResult(object):
        def __init__(self):
            self._host = TestHost()
            self._task = TestTask()
            self._result = result

    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_retry(TestResult())


# Generated at 2022-06-25 08:28:29.997612
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    callback_module_0 = CallbackModule()
    test_result_0 = Result()
    test_result_0._host = Host()
    test_result_0._result = {}
    test_result_0._task = Task()
    test_result_0._task.action = 'ping'
    callback_module_0.v2_runner_item_on_skipped(test_result_0)


# Generated at 2022-06-25 08:28:37.242274
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    callback_module = CallbackModule()

    # test v2_runner_item_on_ok: Check that the msg contains the module and the result of the module.
    # test case 1: Check if the msg contains the module and the result
    # of the module
    result = MockResult()
    result._task = MockTask()
    result._result = {'changed': False, 'item': 'WebServer'}
    result._task.action = "setup"
    result._host = MockHost()
    callback_module.v2_runner_item_on_ok(result)



# Generated at 2022-06-25 08:28:43.141665
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import mock
     
    m_CallbackModule_GetOption = CallbackModule.get_option
    m_CallbackModule_GetOption.return_value = True
    
    m_CallbackModule_GetDiff = CallbackModule._get_diff
    m_CallbackModule_GetDiff.return_value = ""
    
    m_CallbackModule_DumpResults = CallbackModule._dump_results
    m_CallbackModule_DumpResults.return_value = ""
    
    m_CallbackModule_LastTaskBanner = CallbackModule._last_task_banner
    m_CallbackModule_LastTaskBanner = 0

    m_result_task_loop = mock.MagicMock(return_value=True)
    m_result_result_changed = mock.MagicMock(return_value=True)

    m_result_result_results = mock

# Generated at 2022-06-25 08:28:44.994725
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    #  Initialize callback_module_0
    callback_module_0 = CallbackModule()
    #  Call method set_options of callback_module_0
    callback_module_0.set_options()


# Generated at 2022-06-25 08:28:50.451572
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    # Test case 0:
    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule()


# Generated at 2022-06-25 08:29:00.469087
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    callback_module = CallbackModule()
    stats = Stats()
    stats.processed = {'host_0' : {'failures' : 0, 'ok' : 2, 'changed' : 0, 'skipped' : 0, 'unreachable' : 0, 'rescued' : 0, 'ignored' : 0}}
    stats.custom = {'host_0': {'a': 0, 'b': 1}, '_run': {'c': 0, 'd': 1}}
    callback_module.show_custom_stats = True
    callback_module.v2_playbook_on_stats(stats)


# Generated at 2022-06-25 08:29:07.139271
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    # Initializing variables
    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule()

    host = CallbackBase()
    handler = CallbackBase()
    display = CallbackBase()

    # TODO: uncomment when implemented in Ansible
    # callback_module_0.v2_playbook_on_notify(handler, host)

    # TODO: uncomment when implemented in Ansible
    # callback_module_1.v2_playbook_on_notify(handler, host)


# Generated at 2022-06-25 08:29:09.479952
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module = CallbackModule()
    callback_module.set_options({'show_custom_stats': 'yes'})
test_CallbackModule_set_options()



# Generated at 2022-06-25 08:29:17.952826
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    result = Result()
    result._host = Host()
    result._host.set_name('localhost')
    result._result = dict()
    result._result['cmd'] = 'ls -l'
    result._result['invocation'] = dict()
    result._result['invocation']['module_args'] = dict()
    result._result['invocation']['module_args']['warn'] = False
    result._result['changed'] = False
    result._result['rc'] = 2
    result._result['stderr'] = 'Error: command not found.'
    result._result['stdout'] = ''

    callback_module_0 = CallbackModule()
    callback_module_0.display_failed_stderr = False
    callback_module_0.v2_runner_item_on_failed(result)

   

# Generated at 2022-06-25 08:30:19.051443
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    callback_module_0 = CallbackModule()
    callback_module_0._display.display = mock.MagicMock()
    callback_module_0._run_is_verbose = mock.MagicMock()
    callback_module_0._dump_results = mock.MagicMock()
    callback_module_0._display.verbosity = mock.MagicMock()


# Generated at 2022-06-25 08:30:25.208816
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    callback_module_0 = CallbackModule()
    result_0 = PlayCallbacks()
    result_0._result = {'retries': 2, 'attempts': 1}
    result_0._task = 'task'
    result_0.task_name = 'task_name'
    callback_module_0.v2_runner_retry(result_0)
    result_0._result = {'retries': 2, 'attempts': 1}
    result_0._task = 'task'
    result_0.task_name = 'task_name'
    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_retry(result_0)


# Generated at 2022-06-25 08:30:31.642270
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    from ansibledemotest.test_results import TestResults
    callback_module = CallbackModule()
    callback_module.set_options(C.config.load_options())
    callback_module.v2_runner_item_on_ok(TestResults.test_results['test_0'])


# Generated at 2022-06-25 08:30:33.718036
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    callback_module = CallbackModule()
    result = mock.Mock()
    callback_module.v2_runner_on_async_failed(result)



# Generated at 2022-06-25 08:30:43.350255
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():

    callback_module = CallbackModule()

    class Result(object):

        def __init__(self, host, task):
            self._host = host
            self._task = task

    class Host(object):

        def __init__(self, name):
            self.name = name

        def get_name(self):
            return self.name

    class Task(object):

        def __init__(self, name):
            self.name = name

    callback_module.display.verbosity = 1
    callback_module.v2_runner_on_unreachable(Result(Host('localhost'), Task('task name')))

    callback_module.display.verbosity = 2
    callback_module.v2_runner_on_unreachable(Result(Host('localhost'), Task('task name')))

    callback_module.display.verb

# Generated at 2022-06-25 08:30:46.707761
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    # Test for method v2_playbook_on_stats(stats) -> None
    # test for getting only the ok values
    callback_module = CallbackModule()
    stats = FakeStats()
    callback_module.v2_playbook_on_stats(stats)


# Generated at 2022-06-25 08:30:48.816728
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    callback_module_object = CallbackModule()
    result = None
    callback_module_object.v2_runner_item_on_ok(result)

# Generated at 2022-06-25 08:30:51.479667
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_item_on_failed(None)


# Generated at 2022-06-25 08:31:01.036407
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    expected_include_file = 'test.yml'
    dummy_hosts = []

    callback_module = CallbackModule()

    callback_module._display = TerminalDisplay()
    callback_module._display.verbosity = 0
    callback_module._display.display = mock.MagicMock()

    included_file = mock.MagicMock()
    included_file._filename = expected_include_file
    included_file._hosts = dummy_hosts

    callback_module.v2_playbook_on_include(included_file)

    # assert that the display method is called one time with the expected
    # message

# Generated at 2022-06-25 08:31:04.820851
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    # TODO: Implement unit test


# Generated at 2022-06-25 08:32:06.953255
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    c = FakeCallbacks()
    c.v2_runner_retry(FakePlaybookResult())


# Generated at 2022-06-25 08:32:11.605352
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    callback_module = CallbackModule()
    result = Stub_result()
    callback_module.v2_runner_retry(result)


# Generated at 2022-06-25 08:32:17.021160
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_include("on_include")
    callback_module_1 = CallbackModule()
    callback_module_1.v2_playbook_on_include("on_include")


# Generated at 2022-06-25 08:32:20.236281
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    callback_module_0 = CallbackModule()
    stats_0 = ansible_module_utils.ansible_stats.AnsibleStats()
    callback_module_0.show_custom_stats = True
    callback_module_0.v2_playbook_on_stats(stats=stats_0)


# Generated at 2022-06-25 08:32:21.204052
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module = CallbackModule()


# Generated at 2022-06-25 08:32:25.884859
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    callback_module = CallbackModule()
    result_0 = Result()
    result_0._host = Result()
    result_0._host.get_name = lambda : 'localhost'
    result_0._task = 'setup'
    result_0._result = dict(failed=False, retries=5, attempts=0)
    callback_module.v2_runner_retry(result_0)


# Generated at 2022-06-25 08:32:27.444405
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    # TODO: Implements test
    pass


# Generated at 2022-06-25 08:32:31.288376
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module = CallbackModule()
    task = mock.Mock(spec=Task)
    result = mock.Mock(spec=Result)
    result._result = {'diff': [
            {'after': 'bar', 'before': 'foo', 'after_header': 'header'}
        ]}
    result._task = task
    result._task.loop = False
    callback_module.v2_on_file_diff(result)


# Generated at 2022-06-25 08:32:32.746111
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    global stats
    stats = Stats()
    return stats.processed.items()


# Generated at 2022-06-25 08:32:38.820179
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    test_args = [{'_tqm': None, '_filename': 'test_filename', '_hosts': [1,2]},
                 {'_tqm': None, '_filename': 'test_filename1', '_hosts': [1,2]},
                 {'_tqm': None, '_filename': 'test_filename2', '_hosts': [1,2]},
                 {'_tqm': None, '_filename': 'test_filename3', '_hosts': [1,2]},
                 {'_tqm': None, '_filename': 'test_filename4', '_hosts': [1,2]}]
    result = CallbackModule().v2_playbook_on_include(test_args[0])
    result = CallbackModule().v2_play

# Generated at 2022-06-25 08:34:47.945913
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:34:53.891779
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    runner_result_0 = RunnerResult()
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_failed(runner_result_0)

    runner_result_1 = RunnerResult()
    runner_result_1.results = {"default": "default"}
    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_on_failed(runner_result_1)


# Generated at 2022-06-25 08:34:58.735389
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module = CallbackModule()
    runner_on_ok_return = callback_module.v2_runner_on_ok(1,2)

# Generated at 2022-06-25 08:34:59.613463
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    pass


# Generated at 2022-06-25 08:35:01.763343
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    callback_module_0.v2_runner_on_ok(__test_case_data__['instance']._result)


# Generated at 2022-06-25 08:35:13.521238
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    import ansible.parsing.dataloader
    import ansible.playbook.play
    import ansible.playbook.play_context
    import ansible.playbook.task
    import ansible.playbook.include

    playbook_path = os.path.join("..", "..", "examples", "ansible.cfg")
    data_loader = ansible.parsing.dataloader.DataLoader()
    play_context = ansible.playbook.play_context.PlayContext()
    play_source = dict(name="Ansible Play", hosts="localhost", gather_facts="no", tasks=[])
    play = ansible.playbook.play.Play().load(play_source, data_loader, play_context)

    test_task = ansible.playbook.task.Task()
    test_task

# Generated at 2022-06-25 08:35:20.257600
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module = CallbackModule()
    callback_module.set_options(check_mode_markers=True,
                                display_skipped_hosts=True, display_failed_stderr=True, show_custom_stats=True,
                                display_ok_hosts=True)
    assert callback_module.check_mode_markers == True
    assert callback_module.display_skipped_hosts == True
    assert callback_module.display_failed_stderr == True
    assert callback_module.show_custom_stats == True
    assert callback_module.display_ok_hosts == True


# Generated at 2022-06-25 08:35:29.017740
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    # Given
    callback_module_0 = CallbackModule()
    callback_module_1 = CallbackModule()

    # When

    # Then
    assert(callback_module_0.v2_runner_item_on_skipped(result) == None)
    assert(callback_module_1.v2_runner_item_on_skipped(result) == None)

# Generated at 2022-06-25 08:35:35.897341
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    # Setup
    def inner_test_callback_v2_runner_on_ok(result, expected_color):
        callback_module = CallbackModule()
        callback_module._last_task_banner = result._task._uuid + "fails"
        callback_module._last_task_name = result._task.get_name()
        callback_module._last_task_path = result._task._role_path

        def get_name():
            return "foundone"

        def get_path():
            return "foundone"

        def get_uuid():
            return "founduuid"

        # Monkey patch for class Task to avoid errors
        Task.get_name = get_name
        Task.get_path = get_path
        Task.get_uuid = get_uuid
        Task.no_log = False

# Generated at 2022-06-25 08:35:45.968558
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    callback_module_0 = CallbackModule()
    callback_module_0.display_skipped_hosts = False
    result_0 = PlayResult()
    result_0._result = {'changed': False, 'item': 'testing'}

    task_0 = Task()
    task_0._uuid = '0'
    result_0._task = task_0

    host_0 = Host()
    host_0.name = "host_name"
    result_0._host = host_0
    callback_module_0.v2_runner_item_on_skipped(result_0)

    callback_module_0.display_skipped_hosts = True
    callback_module_0.v2_runner_item_on_skipped(result_0)

# Unit Test for method v2_on_file