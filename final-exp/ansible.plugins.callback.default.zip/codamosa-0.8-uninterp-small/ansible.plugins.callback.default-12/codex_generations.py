

# Generated at 2022-06-25 08:26:07.027149
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Construct a mock result object
    result = mock.Mock()

    # Create an instance of CallbackModule
    callback_module_1 = CallbackModule()

    # Invoke method
    callback_module_1.v2_runner_on_ok(result)


# Generated at 2022-06-25 08:26:11.578656
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    callback_module_0 = CallbackModule()
    result = DummyClass()
    assert(not callback_module_0._tqm.terminated)
    callback_module_0.v2_runner_on_async_ok(result)
    assert(not callback_module_0._tqm.terminated)


# Generated at 2022-06-25 08:26:15.698285
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    test_module = CallbackModule()
    class_name = "Play"
    play_name = "test-play-name"
    class Play:
        def get_name(self):
            return play_name
    test_module.v2_playbook_on_play_start(Play())
    print(test_module._play.get_name())
    assert test_module._play.get_name() == play_name


# Generated at 2022-06-25 08:26:19.758264
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    # Test the method with an empty result
    callback_module_1 = CallbackModule()
    callback_module_1.v2_runner_on_start('192.168.1.1', 'playbook')
    # Make sure the output is correct
    assert True



# Generated at 2022-06-25 08:26:29.482870
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    # Create objects
    runner_result = RunnerResult("_host", "_task", "_result", "_is_conditional")
    runner_result._host.name = "a"
    runner_result._task.action = "b"
    runner_result._result = "c"
    runner_result._is_conditional = False

    callback_module_0 = CallbackModule()
    callback_module_0._dump_results_0 = "d"
    callback_module_0.display_skipped_hosts = True
    callback_module_0._last_task_banner = "e"
    callback_module_0.v2_runner_item_on_skipped(runner_result)



# Generated at 2022-06-25 08:26:34.408313
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_1 = CallbackModule()
    result_1 = type('result', (object,), {"_task": "task", "_result": {"diff": "diff"}})
    result_1._result["changed"] = True
    callback_module_1.v2_on_file_diff(result_1)


# Generated at 2022-06-25 08:26:42.441637
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    callback_module_0 = TestCallbackModule()
    result_0 = RunnerResults()
    result_0._result = {}
    result_0._result['exception'] = 'exception_0'
    result_0._result['exception_type'] = 'exception_type_0'
    result_0._result['module_stdout'] = 'module_stdout_0'
    result_0._result['msg'] = 'msg_0'
    result_0._result['stderr_lines'] = 'stderr_lines_0'
    result_0._result['stdout_lines'] = 'stdout_lines_0'
    result_0._task = Task()
    result_0._task._role = Role()
    result_0._task._role._role_name = 'role_0'
    result_0

# Generated at 2022-06-25 08:26:53.130557
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module_0 = CallbackModule()

    # Declare local variables and constants
    _task_uuid_val_0 = 'a'
    _task_uuid_val_1 = 'b'
    _task_uuid_val_2 = 'a'
    _task_uuid_val_3 = '1'
    _task_uuid_val_4 = 'b'
    play_uuid_val_0 = '1'
    _task_uuid_val_5 = '0'
    _task_uuid_val_6 = '0'
    play_uuid_val_1 = '2'
    play_uuid_val_2 = '3'
    play_uuid_val_3 = '4'
    _task_uuid_val_7 = '2'
    play

# Generated at 2022-06-25 08:27:03.913606
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    # Arrange
    callback_module_0 = CallbackModule()
    stats = PlaybookStats()
    stats.processed = collections.OrderedDict(
        [('host_1', Mock()), ('host_2', Mock())]
    )
    stats.summarize = Mock(side_effect=(
        dict(ok=1, changed=0, unreachable=0, failures=0, skipped=0, rescued=0, ignored=0),
        dict(ok=0, changed=0, unreachable=0, failures=1, skipped=0, rescued=0, ignored=0)
    ))
    with patch('ansible_collections.ansible.community.plugins.callback.human_log.CallBackModule.display') as mock_display:
        mock_display.banner = Mock()
        mock_display.display = Mock()

# Generated at 2022-06-25 08:27:05.839069
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    callback_module_0 = CallbackModule()
    play_0 = Play()
    callback_module_0.v2_playbook_on_play_start(play_0)
    assert True


# Generated at 2022-06-25 08:27:56.981580
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:28:00.918144
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    # TODO: put test code here
    # Example
    callback_module_0 = CallbackModule()
    playbook_0 = playbook_0_object()
    callback_module_0.v2_playbook_on_play_start(playbook_0)

if __name__ == "__main__":
    test_CallbackModule_v2_playbook_on_play_start()

# Generated at 2022-06-25 08:28:11.552730
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    callback_module_1 = CallbackModule()
    task = Task()
    task._uuid = '98875608-8c4b-4d5c-ab5f-39e8b1a038e9'
    task._role = None
    task._parent = None
    task._play = None
    task._play_context = None
    task._item = None
    task._loader = None
    task.action = 'ping'
    task.args = {}
    task.set_loader(Mock())
    result = CallbackResult(host=Host(), task=task)
    result._result = {'changed': False}

    callback_module_1.v2_runner_on_skipped(result)


# Generated at 2022-06-25 08:28:15.805501
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    callback_module_0 = CallbackModule()
    playbook = AnsiblePlaybook()
    callback_module_0.v2_playbook_on_play_start(playbook)

if __name__ == '__main__':

    test_case_0()
    test_CallbackModule_v2_playbook_on_play_start()

# Generated at 2022-06-25 08:28:20.804872
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():

    playbook = None
    result = FakeResult()
    callback_module = CallbackModule()
    callback_module.display_skipped_hosts = True
    callback_module.v2_runner_item_on_skipped(result)


# Generated at 2022-06-25 08:28:29.291832
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    callback_module_0 = CallbackModule()

# Generated at 2022-06-25 08:28:33.083020
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    callback_module_1 = CallbackModule()
    playbook_2 = Playbook()
    callback_module_1.v2_playbook_on_start(playbook_2)


# Generated at 2022-06-25 08:28:37.853791
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    print("\n########## Test CallbackModule.v2_runner_on_start ##########")
    callback_module = CallbackModule()
    host = "192.168.1.1"
    task = "task1"
    callback_module.v2_runner_on_start(host, task)


# Generated at 2022-06-25 08:28:40.968958
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    callback_module_0 = CallbackModule()
    result = {}
    callback_module_0.v2_runner_item_on_ok(result)

    assert callback_module_0 is not None


# Generated at 2022-06-25 08:28:48.638184
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    # Local variables used in the test
    result = None

    # CheckCallbackModule is a class (see above)
    callback_module_0 = CheckCallbackModule()
    result = Result(host='hostname_0', task='task_0', task_result={'task_result_key_0': 'task_result_value_0'})
    result.task_name = 'result_task_name_0'
    result._task = Task(name='task_1')
    result._task.check_mode = False
    result.changed = False
    callback_module_0.v2_runner_item_on_skipped(result)


# Generated at 2022-06-25 08:30:32.036489
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    callback_module_1 = CallbackModule()

    # case 0:
    test_case_0()


test_CallbackModule_v2_playbook_on_notify()

# Generated at 2022-06-25 08:30:41.299093
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    test_host_name = 'host_name'
    test_job_id = 'job_id'
    test_started = 'started'
    test_finished = 'finished'
    test_result = {
        'ansible_job_id': test_job_id,
        'started': test_started,
        'finished': test_finished
    }

    class TestHost(object):
        def get_name(self):
            return test_host_name

    class TestResult(object):
        def __init__(self, async_result):
            self._result = async_result

    test_result_object = TestResult(test_result)

    test_display_object = Display()
    callback_module_0 = CallbackModule(display=test_display_object)
    message = 'ASYNC POLL on ' + test

# Generated at 2022-06-25 08:30:47.652966
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    callback_module = CallbackModule()
    class Task():
        def __init__(self):
            self._uuid = 0
            self.name = ''
    class Result():
        def __init__(self):
            self._result = {}
            self.task = Task()
            self._host = {}
    result = Result()
    result.task.name = 'test task'
    result._result['retries'] = 1
    callback_module.v2_runner_retry(result)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 08:30:50.441026
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module_0 = CallbackModule()
    #callback_module_0.v2_runner_on_ok(None)

if __name__ == '__main__':
    #test_case_0()
    test_CallbackModule_v2_runner_on_ok()

# Generated at 2022-06-25 08:30:55.974175
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    task = 'tasks/ping.yml'
    playbook = PlaybookExecutor(playbooks=[task], inventory=inventory, variable_manager=variable_manager, loader=loader, options=options, passwords=passwords)
    playbook._tqm._stdout_callback = CallbackModule()
    playbook.run()


# Generated at 2022-06-25 08:31:05.115390
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    # Create an instance of CallbackModule
    callback_module = CallbackModule()

    # Create a valid result object
    result = Result()

    # Invoke the v2_runner_on_failed() method
    callback_module.v2_runner_on_failed(result)


if __name__ == "__main__":
    test_case_0()
    test_CallbackModule_v2_runner_on_failed()

# Generated at 2022-06-25 08:31:09.076483
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Create a simple playbook
    playbook = Playbook()
    playbook._file_name = '/Users/sotameki/Projects/ansible/test/integration/targets/test_file_1.yml'

    # Call v2_playbook_on_start of class CallbackModule
    callback_module_0 = CallbackModule()
    callback_module_0.v2_playbook_on_start(playbook)


# Generated at 2022-06-25 08:31:15.455361
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():

    # Create new instance of fake result
    result = FakeResult()
    # Create new instance of fake task
    task = FakeTask()
    result._task = task
    result._host = FakeHost()

    # Create new instance of class CallbackModule
    callback_module = CallbackModule()

    # Call method v2_runner_on_skipped of class CallbackModule
    callback_module.v2_runner_on_skipped(result)


# Generated at 2022-06-25 08:31:20.023550
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    callback_module_0 = CallbackModule()
    result_0 = {'task_name': 'foo0', 'attempts': 1}
    result_0['retries'] = 2
    callback_module_0.v2_runner_retry(result_0)
    result_1 = {'task_name': 'foo1', 'attempts': 1}
    result_1['retries'] = 2
    callback_module_0.v2_runner_retry(result_1)


# Generated at 2022-06-25 08:31:25.955367
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():

    callback_module_1 = CallbackModule()

    # test_case_1
    result_1 = Result(task=Task(), host=Host("localhost"), result={"changed": True, "diff": {"before": "before value", "after": "after value"}})
    callback_module_1.v2_on_file_diff(result_1)

    # test_case_2
    result_2 = Result(task=Task(), host=Host("localhost"), result={"changed": False, "diff": {"before": "before value", "after": "after value"}})
    callback_module_1.v2_on_file_diff(result_2)

    # test_case_3
    result_3 = Result(task=Task(), host=Host("localhost"), result={"changed": False, "diff": None})
    callback_

# Generated at 2022-06-25 08:33:45.771732
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    callback_module_0 = CallbackModule()
    callback_module_0._display.verbosity = 3
    handler_0 = Handler()
    host_0 = 'host_0'
    callback_module_0.v2_playbook_on_notify(handler_0, host_0)


# Generated at 2022-06-25 08:33:52.415575
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    callback_module_1 = CallbackModule()
    assert callback_module_1.display_skipped_hosts
    assert not callback_module_1.display_ok_hosts
    assert not callback_module_1.display_failed_stderr
    assert callback_module_1.show_custom_stats
    assert callback_module_1.check_mode_markers
    assert not callback_module_1.show_per_host_start
    assert not callback_module_1._last_task_banner
    assert not callback_module_1._last_task_name
    assert not callback_module_1._play
    assert callback_module_1._task_type_cache == { }
    assert not callback_module_1._last_task_path
    assert not callback_module_1._play_context

    result = FakeResult

# Generated at 2022-06-25 08:34:00.376603
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    playbook = PlaybookExecutor("./ansible_code/test/test_playbook.yml", [VariableManager(), HostVariableManager()])
    callback_module = CallbackModule()
    stats = playbook._tqm._stats
    callback_module.v2_playbook_on_stats(stats)

if __name__ == "__main__":

    test_case_0()
    test_CallbackModule_v2_playbook_on_stats()

# Generated at 2022-06-25 08:34:05.829862
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    print('--------- test_CallbackModule_v2_runner_on_async_poll()-------------')
    test_case_0()


'''
-----------test_CallbackModule_v2_runner_on_async_poll()-------------

'''
## -------------------------------------------------------------------------------

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 08:34:15.163876
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from sample_plugins.callback.SampleCallbackModule import SampleCallbackModule
    from ansible.vars import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    def _load_callbacks(self):
        '''
        Loads callbacks dynamically based on configuration and plugins
        '''

        callback_plugins = [os.path.basename(x) for x in os.listdir(self.callback_plugins)
                      if os.path.isdir(os.path.join(self.callback_plugins, x))]

        for callback_plugin in callback_plugins:
            if callback_plugin not in C.DEFAULT_CALLBACK_PLUGINS:
                sys.path.insert(0, self.callback_plugins)

# Generated at 2022-06-25 08:34:17.472915
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    callback_module_0 = CallbackModule()
    # Test that the task is skipped if the host is already cached and the result is already cached.
    # This is not possible to test currently.
    pass


# Generated at 2022-06-25 08:34:19.375215
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module = CallbackModule()
    callback_module.set_options({"verbose": 3})

    assert callback_module._display.verbosity == 3


# Generated at 2022-06-25 08:34:31.578861
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    assert len(set_options) == 10
    assert 'verbosity' in set_options
    assert set_options['verbosity'] == ['0', '1', '2', '3', '4', '5']
    assert 'display' in set_options
    assert set_options['display'] == CallbackBase.display_options
    assert 'show_custom_stats' in set_options
    assert set_options['show_custom_stats'] == ['on', 'off']
    assert 'display_failed_stderr' in set_options
    assert set_options['display_failed_stderr'] == ['on', 'off']
    assert 'display_skipped_hosts' in set_options
    assert set_options['display_skipped_hosts'] == ['on', 'off']

# Generated at 2022-06-25 08:34:36.859086
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    callback_module_1 = CallbackModule()

    result_0 = mock(Result)
    callback_module_1.v2_runner_on_async_poll(result_0)

    assert callback_module_1._display.display.call_count == 1
    arg_0 = callback_module_1._display.display.call_args_list[0][0][0]
    assert arg_0 == 'ASYNC POLL on %s: jid=%s started=%s finished=%s' % (result_0._host.get_name(), result_0._result.get('ansible_job_id'), result_0._result.get('started'), result_0._result.get('finished'))

# Generated at 2022-06-25 08:34:45.058071
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback_module = CallbackModule()
    class Task():
        def __init__(self):
            self.loop=None
            self._uuid=1
            self.action='test'
    class Result():
        def __init__(self):
            self._host=Host('testhost')
            self._task=Task()
    callback_module.v2_runner_on_ok(Result())
