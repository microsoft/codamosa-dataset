

# Generated at 2022-06-17 10:39:17.000023
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    # Setup
    callback = CallbackModule()
    result = Mock()
    result._host = Mock()
    result._host.get_name.return_value = 'localhost'
    result._result = {
        'msg': 'test message'
    }

    # Exercise
    callback.v2_runner_on_unreachable(result)

    # Verify
    assert callback._display.display.call_count == 1
    assert callback._display.display.call_args[0][0] == "UNREACHABLE! => {'msg': 'test message'}"
    assert callback._display.display.call_args[1]['color'] == 'red'
    assert callback._display.display.call_args[1]['stderr'] == True


# Generated at 2022-06-17 10:39:26.567553
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    # Test with a mock object
    mock_included_file = Mock()
    mock_included_file._filename = "test_filename"
    mock_included_file._hosts = ["test_host1", "test_host2"]
    mock_included_file._vars = "test_vars"
    mock_self = Mock()
    mock_self._display = Mock()
    mock_self._display.display = Mock()
    mock_self._get_item_label = Mock()
    mock_self._get_item_label.return_value = "test_item_label"
    CallbackModule.v2_playbook_on_include(mock_self, mock_included_file)
    assert mock_self._display.display.call_count == 1
    assert mock_self._get_item_label

# Generated at 2022-06-17 10:39:36.304744
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    # Test with a valid playbook
    playbook = PlaybookExecutor(playbooks=['test_playbook.yml'], inventory=None, variable_manager=None, loader=None, options=None, passwords=None)
    callback = CallbackModule()
    callback.v2_playbook_on_play_start(playbook)
    assert callback._play == playbook
    # Test with an invalid playbook
    playbook = PlaybookExecutor(playbooks=['test_playbook.yml'], inventory=None, variable_manager=None, loader=None, options=None, passwords=None)
    callback = CallbackModule()
    callback.v2_playbook_on_play_start(playbook)
    assert callback._play != playbook


# Generated at 2022-06-17 10:39:45.091602
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    # Test with no exception
    result = Mock()
    result.task_name = 'task_name'
    result._host = 'host'
    result._result = {'changed': False, 'failed': False, 'skipped': False, 'unreachable': False}
    result._task = 'task'
    result._task.action = 'action'
    result._task.loop = False
    result._task.no_log = False
    result._task.check_mode = False
    result._task.args = {'a': 'b'}
    result._task.get_name.return_value = 'get_name'
    result._task._uuid = '_uuid'
    result._task.loop_with_items = False
    result._task.loop_args = {'a': 'b'}
    result._

# Generated at 2022-06-17 10:39:55.349597
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    # Create an instance of CallbackModule
    cb = CallbackModule()
    # Create an instance of RunnerResult
    result = RunnerResult()
    # Create an instance of TaskResult
    task_result = TaskResult()
    # Create an instance of Task
    task = Task()
    # Create an instance of Host
    host = Host()
    # Create an instance of Play
    play = Play()
    # Create an instance of PlayContext
    play_context = PlayContext()
    # Create an instance of Playbook
    playbook = Playbook()
    # Create an instance of PlaybookExecutor
    playbook_executor = PlaybookExecutor()
    # Create an instance of PlaybookCLI
    playbook_cli = PlaybookCLI()
    # Create an instance of PlaybookCLI
    cli = PlaybookCLI()
    # Create an

# Generated at 2022-06-17 10:40:06.795415
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    # Create a mock object for the AnsibleOptions class
    mock_ansible_options = mock.Mock()
    # Create a mock object for the Display class
    mock_display = mock.Mock()
    # Create a mock object for the CallbackModule class
    mock_callback_module = mock.Mock()
    # Create a mock object for the CallbackModule class
    mock_callback_module = mock.Mock()
    # Create a mock object for the CallbackModule class
    mock_callback_module = mock.Mock()
    # Create a mock object for the CallbackModule class
    mock_callback_module = mock.Mock()
    # Create a mock object for the CallbackModule class
    mock_callback_module = mock.Mock()
    # Create a mock object for the CallbackModule class

# Generated at 2022-06-17 10:40:17.523764
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    # Test with a result that has a job ID
    result = Mock()
    result._host = Mock()
    result._host.get_name.return_value = 'hostname'
    result._result = {'ansible_job_id': '12345'}
    callback = CallbackModule()
    callback.v2_runner_on_async_failed(result)
    assert callback._display.display.call_count == 1
    assert callback._display.display.call_args == call("ASYNC FAILED on hostname: jid=12345", color=C.COLOR_DEBUG)

    # Test with a result that has a job ID in the async_result dict
    result = Mock()
    result._host = Mock()
    result._host.get_name.return_value = 'hostname'

# Generated at 2022-06-17 10:40:30.520580
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    # Test with no exception
    result = Mock()
    result._result = {'failed': False, 'changed': False}
    result._host = Mock()
    result._host.get_name.return_value = 'localhost'
    result._task = Mock()
    result._task.action = 'shell'
    result._task.no_log = False
    result._task._uuid = '123'
    result._task.loop = False
    result._task.check_mode = False
    result._task.get_name.return_value = 'task name'
    result._task._role = Mock()
    result._task._role._role_path = '/path/to/role'
    result._task._role._role_name = 'role name'
    result._task._role._parent_role = Mock()
    result._task._

# Generated at 2022-06-17 10:40:37.692547
# Unit test for method v2_playbook_on_play_start of class CallbackModule

# Generated at 2022-06-17 10:40:42.209002
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    # Test with no exception
    result = Mock()
    result.task_name = 'test_task'
    result._host = 'test_host'
    result._result = {'changed': False, 'failed': False}
    result._task = Mock()
    result._task.action = 'test_action'
    result._task._uuid = 'test_uuid'
    result._task.no_log = False
    result._task.loop = False
    result._task.check_mode = False
    result._task.get_name.return_value = 'test_task'
    result._task.args = {'test_arg': 'test_value'}
    callback = CallbackModule()
    callback.v2_runner_item_on_failed(result)

# Generated at 2022-06-17 10:41:11.619897
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    # Test with no options
    callback = CallbackModule()
    callback.set_options({})
    assert callback.show_custom_stats == False
    assert callback.display_skipped_hosts == False
    assert callback.display_ok_hosts == True
    assert callback.display_failed_stderr == True
    assert callback.display_skipped_hosts == False
    assert callback.show_custom_stats == False
    assert callback.check_mode_markers == True
    assert callback.show_task_output == True
    assert callback.show_per_host_start == True

    # Test with all options
    callback = CallbackModule()

# Generated at 2022-06-17 10:41:16.750352
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-17 10:41:26.189544
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    # Test with no stats
    callback = CallbackModule()
    stats = MagicMock()
    stats.processed = {}
    callback.v2_playbook_on_stats(stats)
    assert callback._display.display.call_count == 1
    assert callback._display.display.call_args_list[0][0][0] == 'PLAY RECAP'
    assert callback._display.display.call_args_list[0][1]['screen_only'] == True
    assert callback._display.display.call_args_list[0][1]['log_only'] == False
    assert callback._display.display.call_args_list[0][1]['color'] == None

    # Test with stats
    callback = CallbackModule()
    stats = MagicMock()

# Generated at 2022-06-17 10:41:39.511915
# Unit test for method v2_runner_item_on_failed of class CallbackModule

# Generated at 2022-06-17 10:41:52.185762
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    # Test with no async_result
    result = Mock()
    result._host = Mock()
    result._host.get_name.return_value = 'test_host'
    result._result = {'ansible_job_id': 'test_job_id'}
    callback = CallbackModule()
    callback.v2_runner_on_async_failed(result)
    assert callback._display.display.call_count == 1
    assert callback._display.display.call_args[0][0] == "ASYNC FAILED on test_host: jid=test_job_id"
    assert callback._display.display.call_args[1]['color'] == C.COLOR_DEBUG

    # Test with async_result
    result = Mock()
    result._host = Mock()

# Generated at 2022-06-17 10:42:04.119816
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-17 10:42:14.870155
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_executor import TaskExecutor
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.conditional import Conditional
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-17 10:42:24.011077
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a mock object
    mock_result = Mock()
    mock_result.task_name = "test_task_name"
    mock_result._host = "test_host"
    mock_result._task = "test_task"
    mock_result._result = {
        "changed": False,
        "failed": True,
        "msg": "test_msg",
        "stderr": "test_stderr",
        "stdout": "test_stdout",
        "stdout_lines": ["test_stdout_line"],
        "warnings": ["test_warning"]
    }

    # Create a CallbackModule object
    callback_module = CallbackModule()

    # Call the method
    callback_module.v2_runner_on_failed(mock_result)

    # Assert the result


# Generated at 2022-06-17 10:42:37.458171
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    # Create an instance of CallbackModule
    cb = CallbackModule()
    # Create an instance of Result
    result = Result()
    # Create an instance of Task
    task = Task()
    # Create an instance of Host
    host = Host()
    # Create an instance of Play
    play = Play()
    # Create an instance of PlayContext
    play_context = PlayContext()
    # Create an instance of Playbook
    playbook = Playbook()
    # Create an instance of PlaybookExecutor
    playbook_executor = PlaybookExecutor()
    # Create an instance of PlaybookCLI
    playbook_cli = PlaybookCLI()
    # Create an instance of PlaybookCLI
    cli = PlaybookCLI()
    # Create an instance of Options
    options = Options()
    # Create an instance of CLI
    cl

# Generated at 2022-06-17 10:42:48.709369
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    # Test with a valid result
    result = Result(host=Host('localhost'), task=Task(action='shell', args={'_raw_params': 'ls'}), result={'ansible_job_id': '12345'})
    callback = CallbackModule()
    callback.v2_runner_on_async_ok(result)
    assert callback._display.display_messages[0] == "ASYNC OK on localhost: jid=12345"
    assert callback._display.display_colors[0] == C.COLOR_DEBUG
    assert callback._display.display_screen_only[0] == False
    assert callback._display.display_log_only[0] == False
    assert callback._display.display_messages[1] == ""
    assert callback._display.display_colors[1] == None

# Generated at 2022-06-17 10:43:18.504002
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create an instance of CallbackModule
    cb = CallbackModule()
    # Create an instance of RunnerResult
    result = RunnerResult()
    # Create an instance of Runner
    runner = Runner()
    # Create an instance of Host
    host = Host()
    # Create an instance of Task
    task = Task()
    # Create an instance of ActionBase
    action = ActionBase()
    # Create an instance of TaskResult
    task_result = TaskResult()
    # Create an instance of Result
    result_result = Result()
    # Create an instance of PlayContext
    play_context = PlayContext()
    # Create an instance of Play
    play = Play()
    # Create an instance of Playbook
    playbook = Playbook()
    # Create an instance of PlaybookExecutor
    playbook_executor = PlaybookExecutor()
   

# Generated at 2022-06-17 10:43:30.724622
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    # Create an instance of CallbackModule
    callback_module_obj = CallbackModule()
    # Create an instance of Result
    result_obj = Result()
    # Create an instance of Host
    host_obj = Host()
    # Create an instance of Task
    task_obj = Task()
    # Create an instance of TaskResult
    task_result_obj = TaskResult()
    # Create an instance of Runner
    runner_obj = Runner()
    # Create an instance of Play
    play_obj = Play()
    # Create an instance of PlayContext
    play_context_obj = PlayContext()
    # Create an instance of Playbook
    playbook_obj = Playbook()
    # Create an instance of PlaybookExecutor
    playbook_executor_obj = PlaybookExecutor()
    # Create an instance of PlaybookCLI
    playbook_

# Generated at 2022-06-17 10:43:40.947483
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-17 10:43:50.644143
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    # Test with no async_result
    result = Mock()
    result._host = Mock()
    result._host.get_name.return_value = 'host'
    result._result = {'ansible_job_id': 'jid'}
    callback = CallbackModule()
    callback.v2_runner_on_async_failed(result)
    assert callback.display.display.call_args_list == [call('ASYNC FAILED on host: jid', color=C.COLOR_DEBUG)]

    # Test with async_result
    result = Mock()
    result._host = Mock()
    result._host.get_name.return_value = 'host'
    result._result = {'async_result': {'ansible_job_id': 'jid'}}
    callback = CallbackModule()
    callback

# Generated at 2022-06-17 10:43:58.454248
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    result = Mock()
    result.task_name = 'task_name'
    result._task = '_task'
    result._host = Mock()
    result._host.get_name.return_value = 'host_name'
    result._result = {'retries': 1, 'attempts': 0}
    callback = CallbackModule()
    callback.v2_runner_retry(result)
    assert callback._display.display.call_count == 1
    assert callback._display.display.call_args[0][0] == 'FAILED - RETRYING: [host_name]: task_name (1 retries left).'
    assert callback._display.display.call_args[0][1] == {'color': 'debug'}


# Generated at 2022-06-17 10:44:06.111284
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    # create an instance of the CallbackModule class
    cb = CallbackModule()
    # create an instance of the Result class
    result = Result()
    # create an instance of the Task class
    task = Task()
    # create an instance of the Host class
    host = Host()
    # create an instance of the Play class
    play = Play()
    # create an instance of the PlayContext class
    play_context = PlayContext()
    # create an instance of the Runner class
    runner = Runner()
    # create an instance of the Options class
    options = Options()
    # create an instance of the VariableManager class
    variable_manager = VariableManager()
    # create an instance of the Inventory class
    inventory = Inventory()
    # create an instance of the Playbook class
    playbook = Playbook()
    # create an instance of the Play

# Generated at 2022-06-17 10:44:07.458228
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback = CallbackModule()
    assert callback.set_options() == None


# Generated at 2022-06-17 10:44:13.269582
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    # Test with no args
    cb = CallbackModule()
    cb.v2_runner_on_skipped(None)
    # Test with args
    cb = CallbackModule()
    cb.v2_runner_on_skipped(None)

# Generated at 2022-06-17 10:44:24.948237
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroup
    from ansible.vars.hostvars import HostVarsGroups
    from ansible.vars.hostvars import HostVarsAll
    from ansible.vars.hostvars import HostVarsAllGroups
    from ansible.vars.hostvars import HostVarsAllGroupVars

# Generated at 2022-06-17 10:44:30.984488
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    # Create an instance of CallbackModule
    cb = CallbackModule()
    # Create a mock object for result
    result = MagicMock()
    # Create a mock object for host
    host = MagicMock()
    # Set the return value of method get_name of mock object host
    host.get_name.return_value = 'localhost'
    # Set the attribute _host of mock object result
    result._host = host
    # Set the attribute _result of mock object result
    result._result = {'ansible_job_id': '12345'}
    # Call method v2_runner_on_async_failed of CallbackModule
    cb.v2_runner_on_async_failed(result)
    # Assert the method display of mock object _display of CallbackModule is called

# Generated at 2022-06-17 10:45:15.392150
# Unit test for method v2_runner_on_unreachable of class CallbackModule

# Generated at 2022-06-17 10:45:28.074230
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Test with no arguments
    args = []
    if PY3:
        args.append(b'')
    else:
        args.append('')
    # Call method
    # Method is not callable
    # args[0] is a positional argument
    # args[1] is a keyword argument
    with pytest.raises(TypeError) as excinfo:
        CallbackModule.v2_playbook_on_start(*args, **{})
    assert 'v2_playbook_on_start() takes exactly 2 arguments (1 given)' in str(excinfo.value)
    # Test with one argument
    args = []
    if PY3:
        args.append(b'')
    else:
        args.append('')
    # Call method
    # Method is not callable
    # args[

# Generated at 2022-06-17 10:45:39.489039
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Test with a file that does not exist
    result = Mock()
    result._task = Mock()
    result._task.loop = False
    result._result = {'diff': '', 'changed': False}
    callback = CallbackModule()
    callback.v2_on_file_diff(result)
    # Test with a file that does exist
    result = Mock()
    result._task = Mock()
    result._task.loop = False
    result._result = {'diff': '', 'changed': True}
    callback = CallbackModule()
    callback.v2_on_file_diff(result)
    # Test with a file that does exist and is in a loop
    result = Mock()
    result._task = Mock()
    result._task.loop = True

# Generated at 2022-06-17 10:45:49.136530
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    # Create an instance of CallbackModule
    cb = CallbackModule()
    # Create an instance of Result
    result = Result()
    # Create an instance of Host
    host = Host()
    # Set the host name
    host.name = "localhost"
    # Set the host to the result
    result._host = host
    # Set the result
    result._result = {'ansible_job_id': '12345'}
    # Call the method
    cb.v2_runner_on_async_failed(result)
    # Assert that the method displays the correct message
    assert cb._display.display.call_args_list[0][0][0] == "ASYNC FAILED on localhost: jid=12345"

# Generated at 2022-06-17 10:45:50.554726
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    stats = None
    callback_module = CallbackModule()
    callback_module.v2_playbook_on_stats(stats)

# Generated at 2022-06-17 10:46:02.129270
# Unit test for method v2_runner_item_on_failed of class CallbackModule

# Generated at 2022-06-17 10:46:13.572423
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    # Create an instance of CallbackModule
    cb = CallbackModule()

    # Create an instance of Result
    result = Result()

    # Create an instance of Host
    host = Host()

    # Create an instance of Task
    task = Task()

    # Create an instance of TaskResult
    task_result = TaskResult()

    # Set attributes of Result
    result._host = host
    result._task = task
    result._result = task_result

    # Set attributes of TaskResult
    task_result['retries'] = 3
    task_result['attempts'] = 1

    # Test the method v2_runner_retry of CallbackModule
    cb.v2_runner_retry(result)


# Generated at 2022-06-17 10:46:24.450851
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    # Test with no async_result
    result = {
        'ansible_job_id': '1234567890',
        'started': '2018-01-01T00:00:00Z',
        'finished': '2018-01-01T00:00:00Z',
    }
    host = 'testhost'
    cb = CallbackModule()
    cb.v2_runner_on_async_failed(result, host)
    assert cb.display.display_messages[0] == 'ASYNC FAILED on testhost: jid=1234567890'

    # Test with async_result

# Generated at 2022-06-17 10:46:34.751091
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    # Create an instance of CallbackModule
    cb = CallbackModule()
    # Create an instance of AnsibleStats
    stats = AnsibleStats()
    # Create an instance of Host
    host = Host('localhost')
    # Add the host to the stats
    stats.processed[host] = {}
    # Call method v2_playbook_on_stats of CallbackModule
    cb.v2_playbook_on_stats(stats)
    # Assert that the method v2_playbook_on_stats of CallbackModule
    # is called with the correct arguments
    assert cb.v2_playbook_on_stats.call_count == 1
    assert cb.v2_playbook_on_stats.call_args == call(stats)

# Generated at 2022-06-17 10:46:43.417387
# Unit test for method v2_runner_on_unreachable of class CallbackModule

# Generated at 2022-06-17 10:47:26.540938
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    # Test for method v2_runner_item_on_failed(self, result)
    # Tests for v2_runner_item_on_failed
    # Test when verbosity is 0
    # Test when verbosity is 1
    # Test when verbosity is 2
    # Test when verbosity is 3
    # Test when verbosity is 4
    # Test when verbosity is 5
    # Test when verbosity is 6
    # Test when verbosity is 7
    # Test when verbosity is 8
    # Test when verbosity is 9
    # Test when verbosity is 10
    pass


# Generated at 2022-06-17 10:47:39.165329
# Unit test for method v2_playbook_on_include of class CallbackModule

# Generated at 2022-06-17 10:47:46.069272
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    # Create a mock object
    mock_result = MagicMock()
    mock_result.task_name = 'task_name'
    mock_result._host = '_host'
    mock_result._result = {'ansible_job_id': 'ansible_job_id', 'started': 'started', 'finished': 'finished'}
    # Create a CallbackModule object
    cb = CallbackModule()
    # Call the method
    cb.v2_runner_on_async_poll(mock_result)
    # Check if the method was called
    assert mock_result.v2_runner_on_async_poll.called

# Generated at 2022-06-17 10:47:50.820690
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    # Test with valid data
    callback = CallbackModule()
    callback.v2_playbook_on_include(included_file=None)
    assert True


# Generated at 2022-06-17 10:48:02.092856
# Unit test for method v2_runner_on_ok of class CallbackModule

# Generated at 2022-06-17 10:48:12.567726
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    result = Mock()
    result.task_name = None
    result._task = 'task'
    result._result = {'retries': 2, 'attempts': 1}
    result._host = Mock()
    result._host.get_name.return_value = 'host'
    callback = CallbackModule()
    callback.v2_runner_retry(result)
    assert callback._display.display.call_count == 1
    assert callback._display.display.call_args[0][0] == "FAILED - RETRYING: [host]: task (1 retries left)."
    assert callback._display.display.call_args[1]['color'] == C.COLOR_DEBUG


# Generated at 2022-06-17 10:48:24.470157
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    result = Mock()
    result.task_name = 'task_name'
    result._task = '_task'
    result._result = {'retries': 1, 'attempts': 1}
    result._host = Mock()
    result._host.get_name.return_value = 'host_name'
    callback = CallbackModule()
    callback.v2_runner_retry(result)
    assert callback._display.display.call_count == 1
    assert callback._display.display.call_args[0][0] == 'FAILED - RETRYING: [host_name]: task_name (0 retries left).'
    assert callback._display.display.call_args[1]['color'] == 'yellow'


# Generated at 2022-06-17 10:48:36.144821
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    # Test with no args
    cb = CallbackModule()
    result = Mock()
    result._host = Mock()
    result._host.get_name.return_value = 'host'
    result._result = {'msg': 'msg'}
    cb.v2_runner_on_unreachable(result)
    assert cb._last_task_banner == None
    assert cb._last_task_name == None
    assert cb._task_type_cache == {}
    assert cb.display_failed_stderr == False
    assert cb.display_ok_hosts == True
    assert cb.display_skipped_hosts == True
    assert cb.show_custom_stats == False
    assert cb.check_mode_markers == True
    assert cb._play == None


# Generated at 2022-06-17 10:48:41.735478
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    # Test with a valid result
    result = Mock()
    result._task = Mock()
    result._task.action = 'action'
    result._result = {'changed': False, 'skipped': True, 'skip_reason': 'reason'}
    result._host = Mock()
    result._host.get_name.return_value = 'host'
    callback = CallbackModule()
    callback.display_skipped_hosts = True
    callback.v2_runner_item_on_skipped(result)
    assert callback._last_task_banner == result._task._uuid
    assert callback._task_type_cache == {result._task._uuid: 'TASK'}
    assert callback._last_task_name == None
    assert callback._last_task_banner == result._task._uuid