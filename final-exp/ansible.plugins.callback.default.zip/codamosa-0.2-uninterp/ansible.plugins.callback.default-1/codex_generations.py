

# Generated at 2022-06-17 10:39:17.081381
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    # Test with no arguments
    cb = CallbackModule()
    cb.v2_playbook_on_play_start(play=None)
    assert cb._play is None
    assert cb._last_task_banner is None
    assert cb._last_task_name is None
    assert cb._task_type_cache == {}
    assert cb._task_path_cache == {}
    assert cb._task_name_cache == {}
    assert cb._task_uuid_cache == {}
    assert cb._task_uuid_count == {}
    assert cb._task_uuid_displayed == {}
    assert cb._last_task_uuid is None
    assert cb._last_task_path is None
    assert cb._last_task_name is None
    assert cb

# Generated at 2022-06-17 10:39:28.643158
# Unit test for method v2_runner_item_on_skipped of class CallbackModule

# Generated at 2022-06-17 10:39:35.109621
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Create an instance of CallbackModule
    cb = CallbackModule()
    # Create an instance of Result
    result = Result()
    # Create an instance of Task
    task = Task()
    # Set the attribute '_task' of 'result' to 'task'
    result._task = task
    # Set the attribute '_result' of 'result' to 'diff'
    result._result = 'diff'
    # Set the attribute 'changed' of 'result._result' to 'False'
    result._result['changed'] = False
    # Set the attribute '_last_task_banner' of 'cb' to 'task._uuid'
    cb._last_task_banner = task._uuid
    # Set the attribute '_display' of 'cb' to an instance of Display
    cb._display = Display()
   

# Generated at 2022-06-17 10:39:46.454397
# Unit test for method v2_runner_on_skipped of class CallbackModule

# Generated at 2022-06-17 10:39:51.919880
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    # Test with valid input
    # Test with invalid input
    pass


# Generated at 2022-06-17 10:40:01.786537
# Unit test for method v2_runner_on_start of class CallbackModule

# Generated at 2022-06-17 10:40:13.821427
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    # Test with no args
    args = []
    if PY2:
        args.append(str(""))
    else:
        args.append("")
    # Pass empty args
    args.append({})
    # Pass args with required values
    args[1] = {
        'play': {
            'name': 'test_play',
            'check_mode': False
        }
    }
    # Pass args with all values
    args[2] = {
        'play': {
            'name': 'test_play',
            'check_mode': False
        }
    }
    # Pass args with empty play
    args[3] = {
        'play': {
        }
    }
    # Pass args with empty play name

# Generated at 2022-06-17 10:40:23.579557
# Unit test for method v2_runner_item_on_failed of class CallbackModule

# Generated at 2022-06-17 10:40:34.604024
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Create an instance of CallbackModule
    cb = CallbackModule()
    # Create an instance of RunnerResult
    result = RunnerResult()
    # Create an instance of Host
    host = Host()
    # Create an instance of Task
    task = Task()
    # Create an instance of TaskResult
    task_result = TaskResult()
    # Create an instance of TaskResult
    task_result.changed = True
    # Create an instance of TaskResult
    task_result.task = task
    # Create an instance of TaskResult
    task_result.host = host
    # Create an instance of TaskResult
    task_result.result = {'changed': True}
    # Create an instance of TaskResult
    task_result.task_name = "test_task_name"
    # Create an instance of TaskResult
    task_result.task

# Generated at 2022-06-17 10:40:40.936749
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    # Test with a mock object
    mock_self = Mock()
    mock_self.get_option.return_value = False
    mock_self.check_mode_markers = False
    mock_self._display = Mock()
    mock_self._display.verbosity = 0
    mock_self._display.banner.return_value = None
    mock_play = Mock()
    mock_play.get_name.return_value = "play"
    mock_play.check_mode = False
    CallbackModule.v2_playbook_on_play_start(mock_self, mock_play)
    mock_self.get_option.assert_called_once_with('show_custom_stats')
    mock_self._display.banner.assert_called_once_with("PLAY [play]")

# Generated at 2022-06-17 10:41:01.856106
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    # Create an instance of CallbackModule
    cb = CallbackModule()
    # Create an instance of Host
    host = Host()
    # Create an instance of Task
    task = Task()
    # Call method v2_runner_on_start of CallbackModule
    cb.v2_runner_on_start(host, task)


# Generated at 2022-06-17 10:41:11.715417
# Unit test for method v2_playbook_on_stats of class CallbackModule

# Generated at 2022-06-17 10:41:23.872631
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    # Test with no options
    cb = CallbackModule()
    cb.set_options({})
    assert cb.show_custom_stats == False
    assert cb.display_skipped_hosts == False
    assert cb.display_ok_hosts == True
    assert cb.display_failed_stderr == True
    assert cb.display_skipped_hosts == False
    assert cb.check_mode_markers == True
    assert cb.show_custom_stats == False
    assert cb.show_task_output == False
    assert cb.show_per_host_start == False
    assert cb.show_per_host_task == False

    # Test with all options
    cb = CallbackModule()

# Generated at 2022-06-17 10:41:37.109367
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    # Test with a mock object
    mock_self = Mock()
    mock_play = Mock()
    mock_play.get_name.return_value = 'test_play'
    mock_play.check_mode = False
    mock_self._play = None
    mock_self._display = Mock()
    mock_self._display.banner.return_value = None
    mock_self.check_mode_markers = True
    callback_module.CallbackModule.v2_playbook_on_play_start(mock_self, mock_play)
    assert mock_self._play == mock_play
    assert mock_self._display.banner.call_count == 1
    assert mock_self._display.banner.call_args_list[0][0][0] == 'PLAY [test_play]'
    # Test with a

# Generated at 2022-06-17 10:41:50.829792
# Unit test for method v2_playbook_on_stats of class CallbackModule

# Generated at 2022-06-17 10:41:59.439562
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    # Test with no parameters
    result = Mock()
    result.task_name = None
    result._task = None
    result._result = {'retries': 0, 'attempts': 0}
    result._host = Mock()
    result._host.get_name.return_value = 'host'
    callback = CallbackModule()
    callback.v2_runner_retry(result)
    assert callback._display.display.call_count == 1
    assert callback._display.display.call_args_list[0][0][0] == 'FAILED - RETRYING: [host]: None (0 retries left).'
    assert callback._display.display.call_args_list[0][0][1] == {'color': 'debug'}
    callback._display.display.reset_mock()

    # Test with

# Generated at 2022-06-17 10:42:04.612866
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    # Create an instance of CallbackModule without specifying a 'display' parameter
    callback_module = CallbackModule()
    # Create an instance of Result
    result = Result(host=None, task=None, task_result=None)
    # Create an instance of Host
    host = Host(name='test_host')
    # Set the '_host' attribute of 'result' to the new Host instance
    result._host = host
    # Create a dictionary
    result_dict = {'ansible_job_id': 'test_job_id', 'started': 'test_started', 'finished': 'test_finished'}
    # Set the '_result' attribute of 'result' to the new dictionary
    result._result = result_dict
    # Call method v2_runner_on_async_poll of callback_module instance

# Generated at 2022-06-17 10:42:17.348394
# Unit test for method v2_runner_on_unreachable of class CallbackModule

# Generated at 2022-06-17 10:42:21.223635
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Test with no args
    cb = CallbackModule()
    cb.v2_on_file_diff(None)
    # Test with args
    cb = CallbackModule()
    cb.v2_on_file_diff(None)


# Generated at 2022-06-17 10:42:36.545623
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Test with no arguments
    args = []
    if PY3:
        args_obj = mock.MagicMock()
    else:
        args_obj = mock.MagicMock(spec=dict)
    args_obj.verbosity = 1
    args_obj.check = False
    args_obj.listhosts = None
    args_obj.listtasks = None
    args_obj.listtags = None
    args_obj.syntax = None
    args_obj.connection = 'ssh'
    args_obj.module_path = None
    args_obj.forks = 5
    args_obj.remote_user = None
    args_obj.private_key_file = None
    args_obj.ssh_common_args = None
    args_obj.ssh_extra_args = None

# Generated at 2022-06-17 10:43:18.787626
# Unit test for method v2_runner_item_on_failed of class CallbackModule

# Generated at 2022-06-17 10:43:22.419102
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    # Create a mock object
    mock_result = Mock()

    # Create a instance of CallbackModule
    callback_module = CallbackModule()

    # Call method v2_runner_retry of CallbackModule
    callback_module.v2_runner_retry(mock_result)


# Generated at 2022-06-17 10:43:25.313997
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    # Test with no parameters
    result = Mock()
    result._host = Mock()
    result._host.get_name.return_value = 'host'
    result._result = {'ansible_job_id': 'jid'}
    callback = CallbackModule()
    callback.v2_runner_on_async_ok(result)
    assert callback._display.display.call_count == 1
    assert callback._display.display.call_args == call("ASYNC OK on host: jid", color=C.COLOR_DEBUG)


# Generated at 2022-06-17 10:43:37.841944
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-17 10:43:48.772416
# Unit test for method v2_playbook_on_include of class CallbackModule

# Generated at 2022-06-17 10:43:57.806645
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create an instance of CallbackModule
    cb = CallbackModule()
    # Create an instance of RunnerResult
    result = RunnerResult()
    # Create an instance of TaskResult
    task_result = TaskResult()
    # Create an instance of Task
    task = Task()
    # Create an instance of Host
    host = Host()
    # Create an instance of Play
    play = Play()
    # Create an instance of PlayContext
    play_context = PlayContext()
    # Create an instance of Playbook
    playbook = Playbook()
    # Create an instance of PlaybookExecutor
    playbook_executor = PlaybookExecutor()
    # Create an instance of PlaybookCLI
    playbook_cli = PlaybookCLI()
    # Create an instance of Options
    options = Options()
    # Create an instance of CLI
    cli

# Generated at 2022-06-17 10:44:08.206776
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create an instance of CallbackModule
    cb = CallbackModule()
    # Create an instance of Result
    result = Result()
    # Create an instance of Host
    host = Host()
    # Create an instance of Task
    task = Task()
    # Create an instance of TaskInclude
    task_include = TaskInclude()
    # Create an instance of Play
    play = Play()
    # Create an instance of PlayContext
    play_context = PlayContext()
    # Create an instance of Playbook
    playbook = Playbook()
    # Create an instance of PlaybookExecutor
    playbook_executor = PlaybookExecutor()
    # Create an instance of PlaybookCLI
    playbook_cli = PlaybookCLI()
    # Create an instance of Options
    options = Options()
    # Create an instance of CLI
    cli

# Generated at 2022-06-17 10:44:17.397159
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Test with no arguments
    result = dict(
        _host=dict(
            get_name=lambda: 'test_host'
        ),
        _result=dict(
            changed=False
        ),
        _task=dict(
            action='test_action'
        )
    )
    cb = CallbackModule()
    cb.v2_runner_on_ok(result)
    assert cb._last_task_banner == None
    assert cb._last_task_name == None
    assert cb._task_type_cache == dict()
    assert cb.display_ok_hosts == True
    assert cb.display_skipped_hosts == True
    assert cb.display_failed_stderr == True
    assert cb.show_custom_stats == True
    assert cb

# Generated at 2022-06-17 10:44:25.206595
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Test with a file diff result
    result = Mock()
    result._task = Mock()
    result._task.loop = False
    result._result = {'changed': True, 'diff': {'before': 'before', 'after': 'after'}}
    callback = CallbackModule()
    callback.v2_on_file_diff(result)
    # Test with a file diff result in a loop
    result = Mock()
    result._task = Mock()
    result._task.loop = True
    result._result = {'results': [{'changed': True, 'diff': {'before': 'before', 'after': 'after'}}]}
    callback = CallbackModule()
    callback.v2_on_file_diff(result)
    # Test with a file diff result in a loop with no diff
    result = Mock()
   

# Generated at 2022-06-17 10:44:31.198735
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    # Test with no stats.custom
    stats = Stats()
    stats.processed = {'host1': {'ok': 1, 'changed': 2, 'unreachable': 3, 'failures': 4, 'skipped': 5, 'rescued': 6, 'ignored': 7}}
    callback = CallbackModule()
    callback.v2_playbook_on_stats(stats)
    assert callback._display.display.call_count == 2
    assert callback._display.display.call_args_list[0][0][0] == 'host1 : 1 2 3 4 5 6 7'
    assert callback._display.display.call_args_list[0][1]['color'] == 'green'
    assert callback._display.display.call_args_list[0][1]['screen_only'] == True
    assert callback._display

# Generated at 2022-06-17 10:45:15.232967
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    # Test with a mock object
    mock_play = MagicMock()
    mock_play.get_name.return_value = 'test_play'
    mock_play.check_mode = False
    mock_display = MagicMock()
    mock_display.verbosity = 1
    mock_display.banner.return_value = None
    mock_display.display.return_value = None
    mock_callback = CallbackModule(display=mock_display)
    mock_callback.check_mode_markers = False
    mock_callback.v2_playbook_on_play_start(mock_play)
    mock_display.banner.assert_called_with('PLAY [test_play]')
    mock_display.display.assert_not_called()
    # Test with a mock object
    mock_play = Magic

# Generated at 2022-06-17 10:45:28.038117
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    # Create an instance of CallbackModule
    cb = CallbackModule()
    # Create an instance of Result
    result = Result()
    # Create an instance of Task
    task = Task()
    # Create an instance of Host
    host = Host()
    # Create an instance of TaskResult
    task_result = TaskResult()
    # Create an instance of TaskInclude
    task_include = TaskInclude()
    # Create an instance of Playbook
    playbook = Playbook()
    # Create an instance of Play
    play = Play()
    # Create an instance of PlayContext
    play_context = PlayContext()
    # Create an instance of Options
    options = Options()
    # Create an instance of VariableManager
    variable_manager = VariableManager()
    # Create an instance of Inventory
    inventory = Inventory()
    # Create an instance of

# Generated at 2022-06-17 10:45:34.888806
# Unit test for method v2_runner_on_start of class CallbackModule

# Generated at 2022-06-17 10:45:42.699883
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    # Test with a valid play
    play = Play()
    play._ds = dict(name='test_play')
    callback = CallbackModule()
    callback.v2_playbook_on_play_start(play)
    assert callback._play == play
    assert callback._last_task_banner == None
    assert callback._last_task_name == None
    assert callback._task_type_cache == {}
    assert callback._task_path_cache == {}
    assert callback._task_name_cache == {}
    assert callback._task_uuid_cache == {}
    assert callback._task_uuid_count == {}
    assert callback._last_task_uuid == None
    assert callback._last_task_path == None
    assert callback._last_task_name == None
    assert callback._last_task_banner == None


# Generated at 2022-06-17 10:45:47.885463
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    result = Mock()
    result.task_name = 'task_name'
    result._task = '_task'
    result._result = {'retries': 1, 'attempts': 1}
    result._host = '_host'
    callback = CallbackModule()
    callback.v2_runner_retry(result)
    assert callback.v2_runner_retry(result) == None


# Generated at 2022-06-17 10:46:00.065994
# Unit test for method v2_runner_item_on_ok of class CallbackModule

# Generated at 2022-06-17 10:46:03.577401
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Create an instance of CallbackModule
    cb = CallbackModule()
    # Create an instance of Playbook
    pb = Playbook()
    # Call method v2_playbook_on_start of CallbackModule
    cb.v2_playbook_on_start(pb)


# Generated at 2022-06-17 10:46:14.652109
# Unit test for method v2_playbook_on_stats of class CallbackModule

# Generated at 2022-06-17 10:46:21.561342
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    result = Mock()
    result.task_name = 'task_name'
    result._task = '_task'
    result._result = {'retries': 1, 'attempts': 1}
    result._host = Mock()
    result._host.get_name.return_value = 'host'
    callback = CallbackModule()
    callback.v2_runner_retry(result)
    assert callback._display.display.call_count == 1
    assert callback._display.display.call_args[0][0] == "FAILED - RETRYING: [host]: task_name (0 retries left)."
    assert callback._display.display.call_args[0][1] == 'debug'
    assert callback._display.display.call_args[0][2] == True
    assert callback._display.display.call_

# Generated at 2022-06-17 10:46:27.831100
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    # Test with valid input
    cb = CallbackModule()
    play = Play()
    cb.v2_playbook_on_play_start(play)
    assert cb._play == play


# Generated at 2022-06-17 10:47:32.266075
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create a new instance of CallbackModule
    cb = CallbackModule()
    # Create a new instance of Result
    result = Result()
    # Create a new instance of Task
    task = Task()
    # Create a new instance of Host
    host = Host()
    # Create a new instance of Play
    play = Play()
    # Create a new instance of PlayContext
    play_context = PlayContext()
    # Create a new instance of Playbook
    playbook = Playbook()
    # Create a new instance of PlaybookExecutor
    playbook_executor = PlaybookExecutor()
    # Create a new instance of PlaybookCLI
    playbook_cli = PlaybookCLI()
    # Create a new instance of CLI
    cli = CLI()
    # Create a new instance of Options
    options = Options()
    # Create a new

# Generated at 2022-06-17 10:47:41.019072
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    # Test with a valid result
    result = dict(
        _host=dict(
            get_name=lambda: 'test_host'
        ),
        _task=dict(
            action='test_action'
        ),
        _result=dict(
            get=lambda key, default=None: 'test_result' if key == 'changed' else default
        )
    )
    callback = CallbackModule()
    callback.display_skipped_hosts = True
    callback.v2_runner_item_on_skipped(result)
    assert callback._last_task_banner == result['_task']['_uuid']
    assert callback._display.display.call_count == 2

# Generated at 2022-06-17 10:47:51.452821
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Test with no args
    result = dict()
    result['_host'] = dict()
    result['_host']['get_name'] = lambda: 'hostname'
    result['_result'] = dict()
    result['_result']['changed'] = False
    result['_task'] = dict()
    result['_task']['action'] = 'action'
    result['_task']['loop'] = False
    result['_task']['_uuid'] = 'uuid'
    result['_task']['get_name'] = lambda: 'taskname'
    result['_task']['check_mode'] = False
    result['_task']['no_log'] = False
    result['_task']['args'] = dict()

# Generated at 2022-06-17 10:47:59.238095
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Test with no args
    args = []
    if PY3:
        args_obj = mock.MagicMock()
    else:
        args_obj = mock.MagicMock(spec=dict)
    args_obj.__getitem__.side_effect = lambda name: args[name]
    args_obj.__contains__.side_effect = lambda name: name in args
    args_obj.get.side_effect = lambda name, failobj: args.get(name, failobj)
    context_obj = mock.MagicMock()
    context_obj.CLIARGS = args_obj

# Generated at 2022-06-17 10:48:11.086537
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    stats = {
        'ok': {
            'host1': {
                'ok': 1,
                'changed': 1,
                'unreachable': 1,
                'failures': 1,
                'skipped': 1,
                'rescued': 1,
                'ignored': 1
            },
            'host2': {
                'ok': 1,
                'changed': 1,
                'unreachable': 1,
                'failures': 1,
                'skipped': 1,
                'rescued': 1,
                'ignored': 1
            }
        }
    }
    callback = CallbackModule()
    callback.v2_playbook_on_stats(stats)
    assert True


# Generated at 2022-06-17 10:48:16.748289
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    result = Mock()
    result.task_name = 'task_name'
    result._task = '_task'
    result._result = {'retries': 1, 'attempts': 1}
    result._host = '_host'
    callback = CallbackModule()
    callback.v2_runner_retry(result)
    assert callback._display.display.call_count == 1
    assert callback._display.display.call_args[0][0] == 'FAILED - RETRYING: [_host]: task_name (0 retries left).'
    assert callback._display.display.call_args[1]['color'] == 'debug'

# Generated at 2022-06-17 10:48:23.977227
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create an instance of CallbackModule
    cb = CallbackModule()
    # Create a fake result
    result = FakeResult()
    # Call method v2_runner_on_failed
    cb.v2_runner_on_failed(result)
    # Assert
    assert cb._last_task_banner == result._task._uuid
    assert cb._last_task_name == result._task.get_name().strip()
    assert cb._task_type_cache == {result._task._uuid: 'TASK'}
    assert cb._last_task_banner == result._task._uuid
    assert cb._last_task_name == result._task.get_name().strip()

# Generated at 2022-06-17 10:48:36.116991
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    # Create an instance of CallbackModule
    cb = CallbackModule()
    # Create an instance of Result
    result = Result()
    # Create an instance of Task
    task = Task()
    # Create an instance of Host
    host = Host()
    # Create an instance of Play
    play = Play()
    # Create an instance of PlayContext
    play_context = PlayContext()
    # Create an instance of Playbook
    playbook = Playbook()
    # Create an instance of PlaybookExecutor
    playbook_executor = PlaybookExecutor()
    # Create an instance of PlaybookCLI
    playbook_cli = PlaybookCLI()
    # Create an instance of Options
    options = Options()
    # Create an instance of CLI
    cli = CLI()
    # Create an instance of Runner
    runner = Runner()
    #