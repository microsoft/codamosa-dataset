

# Generated at 2022-06-21 03:45:02.682861
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    CALLBACK_MODULE = CallbackModule()
    handler = Handler()
    host = MagicMock(name="host")
    return_value = CALLBACK_MODULE.v2_playbook_on_notify(handler, host)
    assert return_value == None


if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-21 03:45:10.679096
# Unit test for method v2_playbook_on_no_hosts_remaining of class CallbackModule
def test_CallbackModule_v2_playbook_on_no_hosts_remaining():
    myplaybook = Playbook()
    mytest = AnsibleTask(playbook=myplaybook)
    mytest.init_test("test_CallbackModule_v2_playbook_on_no_hosts_remaining", ["test_add_tasks_1"], [])
    mytest.test_vars['ansible_show_custom_stats'] = False
    mytest.test_vars['ansible_check_mode'] = False
    mycallback = CallbackModule()
    mycallback.v2_playbook_on_no_hosts_remaining(mytest.test_tasks[0])
    assert mytest.test_result['changed'] == 0

# Generated at 2022-06-21 03:45:19.845591
# Unit test for method v2_playbook_on_no_hosts_remaining of class CallbackModule
def test_CallbackModule_v2_playbook_on_no_hosts_remaining():
    my_callbackModule = CallbackModule()
    my_playbook = mock.Mock()
    my_playbook.host_pattern.return_value = 'host_pattern'
    my_playbook.role_names.return_value = 'role_names'
    my_playbook.play_basedir.return_value = 'play_basedir'
    my_playbook.vars.return_value = 'vars'
    my_my_return_value = my_callbackModule.v2_playbook_on_no_hosts_remaining(my_playbook)
    assert my_my_return_value == None

# Generated at 2022-06-21 03:45:20.816821
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
  pass

# Generated at 2022-06-21 03:45:29.794747
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    from ansible import utils
    from ansible.plugins.callback.human_log import CallbackModule
    
    callback = CallbackModule()
    
    class Host():
        def __init__(self, name):
            self.name = name
        def get_name(self):
            return self.name

    utils.plugins = Mock()
    class Result():
        def __init__(self, host, task):
            self._host = Host(host)
            self._task = Task()
            self._task.action = 'Mocked action'
            self._result = {
                'failed': True,
                'msg': 'Mocked error'
            }
    result = Result('TestHost', 'TestTask')
    callback.v2_runner_on_unreachable(result)


# Generated at 2022-06-21 03:45:31.331680
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    # just a stub test
    pass

# Generated at 2022-06-21 03:45:35.775115
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    jln = CallbackModule()
    jln.v2_runner_item_on_skipped(result)
test_CallbackModule_v2_runner_item_on_skipped()


# Generated at 2022-06-21 03:45:43.917011
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
  fake_host = Host('fake_host')
  fake_task = TaskDisableFastTemplate()
  fake_result = dict(changed=False)

  class FakeCallbackModule(CallbackModule):
    blank_lines = 0
    lines = []
    msgs = []
    ok_hosts = []
    results = []

    def _dump_results(self, result):
      self.results.append(result)
      return 'Fake results'

  callback = FakeCallbackModule()
  callback.set_options({'display_ok_hosts': True})
  callback.v2_runner_item_on_ok(Result(fake_host, fake_task, fake_result))

  assert callback.lines == [
      u'ok: [fake_host] => (item=None) => Fake results'] * 2
  assert callback.ok_hosts

# Generated at 2022-06-21 03:45:51.366292
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():

    # Arrange
    playbook = MagicMock()
    playbook._filename = "test_mock"
    host = MagicMock()
    host.name = "test_host"
    playbook._hosts = []
    playbook._hosts.append(host)
    included_file = MagicMock()
    included_file._hosts = []
    included_file._hosts.append(host)
    included_file._filename = "included_test.yml"
    included_file._vars = dict()

    callback_module = CallbackModule()
    callback_module._display = MockDisplay()
    callback_module._dump_results = MagicMock()
    callback_module._dump_results.return_value = "results"

    # Act

# Generated at 2022-06-21 03:46:01.239505
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    # 
    # test with verbosity of 0 and display_ok_hosts of True
    # 
    config.display_ok_hosts = True
    config.verbosity = 0
    runner = AnsibleRunner(hosts=['localhost'], tasks=[])
    Runner._low_level_execute_command = Mock(return_value=(0, "", ""))
    callback = CallbackModule()
    result = runner.run_task({'action': 'setup'})
    callback.v2_runner_item_on_ok(result)
    assert callback.display_ok_hosts
    assert callback._last_task_banner is None
    assert callback._play is None
    
    
    
    
    # 
    # test with verbosity of 1 and display_ok_hosts of True
    # 

# Generated at 2022-06-21 03:46:19.890588
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    pass

# Generated at 2022-06-21 03:46:23.633182
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    """Test v2_runner_on_failed method of CallbackModule class"""
    module = CallbackModule()
    callback = ResultsCollector()
    module.v2_runner_on_failed(callback)

# Generated at 2022-06-21 03:46:34.778051
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Make a mock task
    mock_task = Task();
    # Make a mock host
    mock_host = Host();
    # Make a mock result
    mock_result = {
        'changed': False,
        'failed': False,
        'skipped': False,
        'ignore_errors': False,
        'verbose_override': False,
        '_ansible_verbose_always': True,
        '_ansible_no_log': False,
    }
    # Object under test
    objectUnderTest = CallbackModule(display=None)
    # Call the v2_runner_on_ok method of the object under test
    returnedValue = objectUnderTest.v2_runner_on_ok(result=mock_result, host=mock_host, task=mock_task)

# Generated at 2022-06-21 03:46:46.702107
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    cb = CallbackModule()
    result = dict(
        _task=dict(name=None)
    )
    cb._task_start(result['_task'])
    cb.v2_runner_on_start(result['_task'], result)
    assert cb._last_task_name == ''
    assert cb._last_task_name == cb._last_task_banner
    del cb

    cb = CallbackModule()
    result = dict(
        _task=dict(name='test')
    )
    cb._task_start(result['_task'])
    cb.v2_runner_on_start(result['_task'], result)
    assert cb._last_task_name == 'test'
    assert cb._last_task_name == cb

# Generated at 2022-06-21 03:46:49.715916
# Unit test for method v2_playbook_on_no_hosts_remaining of class CallbackModule
def test_CallbackModule_v2_playbook_on_no_hosts_remaining():
    cb = CallbackModule()
    cb.v2_playbook_on_no_hosts_remaining('test value')
    assert(cb._last_task_banner == 'test value')


# Generated at 2022-06-21 03:47:02.084257
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    class MockClass(object):
        def __init__(self, name):
            self.name = name
        def get_name(self):
            return self.name
        def get_task_result_file(self, host):
            return 'cb_task_' + host
        
    host = MockClass('localhost')
    task = MockClass('task_name')
    result = {}
    result['_ansible_verbose_override'] = True
    result['_ansible_no_log'] = True

    import ansible.module_utils
    tmpdir = ansible.module_utils.mk_tmp_path()
    callback = CallbackModule(display=None, options=None)
    callback.tmpdir = tmpdir
    callback.v2_runner_on_failed(host, task, result)

# Generated at 2022-06-21 03:47:13.409155
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    runner_result = {'ansible_check_mode': True, 'ansible_job_id': '1034304701', 'ansible_no_log': False, 'changed': False, 'failed': False, 'results_file': '~/.ansible_async/1034304701', 'started': 1, 'status': 'successful'}
    task = AnsibleTask('host', 'fake', True, runner_result)
    # Instantiate class module
    callback = CallbackModule()
    # Call tested method
    callback.v2_runner_on_start(task.host, task)

# Generated at 2022-06-21 03:47:22.748611
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():

    # Test the results of the calling AnsibleModule
    # 
    # We expect a specific traceback message
    # 
    # Args:
    #    None
    # 
    # Kwargs:
    #    None
    # 
    # Returns:
    #    None

    # create an instance of the Ansible exit_json class to pass back the result
    # The arguments provided are the set of defaults.
    result = AnsibleExitJson()

    # set default arguments
    result.args = {}
    result.args['async_result'] = {}
    result.args['async_result']['ansible_job_id'] = '61260.79928'

    # reset the stdout buffer
    sys.stdout = io.BytesIO()
    # create an instance of our class to test
    cbm

# Generated at 2022-06-21 03:47:34.034901
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Create a callback module
    callback = CallbackModule()
    # Create a playbook
    playbook = Playbook('./etc/ansible/roles/mock-role-with-files/mock-playbook.yml')
    # Create the CLI arguments

# Generated at 2022-06-21 03:47:41.694619
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    # Test CallbackModule class handling of callback events
    run = unittest.mock.MagicMock()
    host = unittest.mock.MagicMock()
    host.get_name.return_value = 'blah.example.org'
    task = unittest.mock.MagicMock()
    task.action = 'setup'
    result = unittest.mock.MagicMock()
    display = unittest.mock.MagicMock()
    display.verbosity = 0
    display.columns = 80
    callback = CallbackModule(run, display)
    callback.v2_runner_on_start(host, task)
    output = run.call_args[0][0]
    assert re.match('Gathering Facts', output)


# Generated at 2022-06-21 03:48:30.998748
# Unit test for method v2_playbook_on_include of class CallbackModule

# Generated at 2022-06-21 03:48:33.242310
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert(Callbacks() != None)

if __name__ == '__main__':
    test_CallbackModule()

# Generated at 2022-06-21 03:48:44.610691
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    # Arrange
    result = {}
    result.__dict__ = {'_host': {'name': 'host_name'}}
    task = {'action': 'action_name'}
    task.__dict__ = {'_uuid': 'task_uuid', 'name': 'task_name'}
    opts = {}
    opts.__dict__ = {'verbosity': 'verbosity', 'show_per_host_start': 'show_per_host_start'}
    caps = {}
    caps.__dict__ = {'task_uuid_var': 'task_uuid_var'}
    InstCallbackJSON = CallbackModule()
    InstCallbackJSON.v2_runner_on_start(result)
    InstCallbackJSON.v2_runner_on_start(result, task)
    InstCallback

# Generated at 2022-06-21 03:48:47.675846
# Unit test for method v2_playbook_on_no_hosts_matched of class CallbackModule
def test_CallbackModule_v2_playbook_on_no_hosts_matched():
    result = CallbackModule.v2_playbook_on_no_hosts_matched('test')
    assert result is None


# Generated at 2022-06-21 03:48:53.370368
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    module = get_module_with_params(
        load_fixture('callback_plugin/v2_on_file_diff/params.json'))
    result = load_fixture('callback_plugin/v2_on_file_diff/result.json')
    try:
        module.v2_on_file_diff(result)
    except Exception as e:
        pytest.fail('Test Failed: %s' % str(e))



# Generated at 2022-06-21 03:48:55.526269
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    cm = CallbackModule()
    host = object()
    task = object()
    cm.v2_runner_on_start(host, task)

# Generated at 2022-06-21 03:48:58.012451
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    callback = CallbackModule()
    import ansible.plugins.callback.default
    handler = ansible.plugins.callback.default.CallbackModule()
    host='localhost'
    callback.v2_playbook_on_notify( handler, host)

    assert True



# Generated at 2022-06-21 03:49:07.824812
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    # test default variable creation
    cb = CallbackModule()
    assert cb.__class__.__name__ == 'CallbackModule'

    result = Mock()
    result._host.get_name.return_value = 'hostname'
    result._result.get.return_value = 'job_id'
    cb._display.display.return_value = None
    cb.v2_runner_on_async_ok(result)
    cb._display.display.assert_called_with(
        'ASYNC OK on hostname: jid=job_id',
        color=C.COLOR_DEBUG
    )


# Generated at 2022-06-21 03:49:19.460048
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    result = Mock()

# Generated at 2022-06-21 03:49:26.716518
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    from ansible.callbacks import CallbackModule

    name = 'localhost'

# Generated at 2022-06-21 03:51:07.469154
# Unit test for method v2_playbook_on_handler_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_handler_task_start():
    # Test with ansible
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.color import stringc
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    class MockDisplay(object):
        def __init__(self):
            self.verbosity = 1

# Generated at 2022-06-21 03:51:09.855260
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    # Test empty input
    assert( 'TODO' == 'TODO' )



# Generated at 2022-06-21 03:51:17.962484
# Unit test for method v2_playbook_on_no_hosts_remaining of class CallbackModule
def test_CallbackModule_v2_playbook_on_no_hosts_remaining():
    # Dummy result
    result = DummyResult()
    # Dummy environment and task
    env = DummyEnvironment()
    task = DummyTask()

    # Testing with different verbosities
    for i in range(4):
        test_callback = CallbackModule(display=DummyDisplay(verbosity=i))
        test_callback.v2_playbook_on_no_hosts_remaining(result)
        # If i is different than 3, the test fails.
        assert i == 3

    # Testing with a task
    test_callback = CallbackModule(display=DummyDisplay(verbosity=1))
    test_callback.v2_playbook_on_task_start(task=task, environment=env)
    test_callback.v2_playbook_on_no_hosts_remaining(result)


# Generated at 2022-06-21 03:51:28.424450
# Unit test for method v2_playbook_on_handler_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_handler_task_start():
    pass

############
# Test main #
############

# setup logging
logger = logging.getLogger('test')
ch = logging.StreamHandler()
logger.addHandler(ch)
logger.setLevel(logging.DEBUG)

if __name__ == '__main__':

    # debug logging
    #logging.basicConfig(level=logging.DEBUG)

    # test settings
    # settings from default callback plugin
    settings = {
        'show_custom_stats': True,
        'show_header': True,
        'show_skipped_hosts': True,
        'verbosity': 4
    }

    # settings from display plugin

# Generated at 2022-06-21 03:51:34.341025
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    import unittest2 as unittest
    import ansible
    import ansible.playbook.play_context
    import ansible.vars
    import ansible.inventory.host
    import ansible.inventory.group
    import ansible.inventory.inventory
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackModule
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import callback_loader
    import os
    import json
    import __

# Generated at 2022-06-21 03:51:42.968125
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
  with patch(
    "ansible.plugins.callback.human_log.logpath"
  ) as logpath_mock:
    logpath_mock.return_value = "/tmp/ansible-log"

# Generated at 2022-06-21 03:51:47.077633
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    obj = CallbackModule()
    obj._get_diff = MagicMock()
    obj._dump_results = MagicMock()
    obj.display_failed_stderr = None
    result = MagicMock()
    obj.v2_runner_on_unreachable(result)
    assert not obj._get_diff.called
    assert obj._dump_results.called
    assert obj.v2_runner_on_unreachable(result) is None


# Generated at 2022-06-21 03:51:49.333615
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    '''
    v2_playbook_on_task_start is a public method defined in CallbackModule class.
    This method starts a task and gets current task  information.
    '''
    pass # no need to write test case for this method since nothing is returned by this method

# Generated at 2022-06-21 03:51:55.767896
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    ansible.utils.template.AnsibleUndefined = "AnsibleUndefined"
    callback = CallbackModule()
    callback.v2_playbook_on_task_start(ansible.utils.template.AnsibleUndefined)
    callback.runner_on_failed(ansible.utils.template.AnsibleUndefined, ansible.utils.template.AnsibleUndefined, ansible.utils.template.AnsibleUndefined)



# Generated at 2022-06-21 03:52:01.064818
# Unit test for method v2_playbook_on_no_hosts_matched of class CallbackModule
def test_CallbackModule_v2_playbook_on_no_hosts_matched():
    runner_results = [
        {'contacted': {},
         'dark': {'127.0.0.2': {'msg': 'Failed to connect to the host via ssh.'}}
         }
    ]

    hosts = ['127.0.0.1', '127.0.0.2']
    for host in hosts:
        ansible_host = Mock()
        ansible_host.get_name.return_value = host
        for runner_result in runner_results:
            callback = Mock()
            playbook = Mock()
            playbook.hosts.return_value = hosts
            callback_module = CallbackModule()
            callback_module.v2_playbook_on_stats = Mock()
            callback_module.v2_playbook_on_stats.return_value = None
            callback_module.v2_

# Generated at 2022-06-21 03:53:58.708777
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    callback = CallbackModule()
    # The actual test case
    assert True == True

# Generated at 2022-06-21 03:54:03.804093
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    # Test 1: create a test object of CallbackModule
    test_1 = CallbackModule()
    # Test 2: create test input 'result'
    test_2 = None
    # Test 3: assert the result of function v2_runner_item_on_failed and the test case judgement result
    assert test_1.v2_runner_item_on_failed(result) == False


# Generated at 2022-06-21 03:54:05.322879
# Unit test for method v2_playbook_on_cleanup_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_cleanup_task_start():
    v2_playbook_on_cleanup_task_start()

# Generated at 2022-06-21 03:54:08.231896
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
  print("In test_CallbackModule_v2_runner_item_on_skipped()")
  #TODO: Test code here
  #assert 0 == 1
  assert True == True



# Generated at 2022-06-21 03:54:12.784962
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    callback = CallbackModule()
    callback.v2_runner_on_ok(
        Mock(
            _host=Mock(get_name=Mock(return_value='foo')),
            _task=Mock(name='bar'),
            _result=Mock(
                get=Mock(
                    side_effect=[True, 123]
                )
            )
        )
    )

# Generated at 2022-06-21 03:54:20.645296
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    # callback = CallbackModule()
    # assert ???? == callback.v2_runner_on_skipped(???)

    # If you want to check the code coverage of this method, uncomment the code
    # below and run the ut.py script in the root directory of the project.
    #
    # import ut
    # ut.do_coverage(globals().get('CallbackModule'))
    pass


# Generated at 2022-06-21 03:54:26.126352
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-21 03:54:29.385161
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    # Instanciate an callback module
    callbackModule = CallbackModule()
    # Call the method v2_runner_on_async_ok

# Generated at 2022-06-21 03:54:32.625870
# Unit test for method v2_playbook_on_no_hosts_remaining of class CallbackModule
def test_CallbackModule_v2_playbook_on_no_hosts_remaining():
    cb = CallbackModule()
    result = dict()
    try:
        cb.v2_playbook_on_no_hosts_remaining(result)
    except SystemExit:
        pass


# Generated at 2022-06-21 03:54:36.105979
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    from ansible.executor.task_result import TaskResult
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from collections import namedtuple
    # Setup
    callback = CallbackModule(display=None)
    result = TaskResult(task=None, host=None, task_fields=dict(changed=False, failed=False))
    # Exercise
    callback.v2_runner_item_on_ok(result)