

# Generated at 2022-06-21 03:44:52.508316
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    from ansible.plugins.callback import CallbackModule
    callback = CallbackModule()
    callback.v2_runner_on_async_ok()

# Generated at 2022-06-21 03:44:57.379758
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    callback = CallbackModule()
    handler = mock.Mock(get_name=mock.Mock(return_value="handler"))
    host = "host"
    callback.v2_playbook_on_notify(handler, host)
    assert callback._display.display.call_count == 1
    callback._display.display.assert_called_with("NOTIFIED HANDLER handler for host")


# Generated at 2022-06-21 03:45:05.242220
# Unit test for method v2_playbook_on_no_hosts_matched of class CallbackModule
def test_CallbackModule_v2_playbook_on_no_hosts_matched():
    from ansible.playbook.task import Task

    patcher1 = patch('ansible.plugins.callback.CallbackModule._get_task_banner')
    patcher2 = patch('ansible.plugins.callback.CallbackModule._display.display')
    patcher3 = patch('ansible.plugins.callback.CallbackModule._display.banner')
    patcher4 = patch('ansible.plugins.callback.CallbackModule._get_item_label')
    patcher5 = patch('ansible.plugins.callback.CallbackModule.host_label')
    patcher6 = patch('ansible.plugins.callback.CallbackModule._get_diff')
    patcher7 = patch('ansible.playbook.play.Play')
    patcher8 = patch('ansible.playbook.play_context.PlayContext')

# Generated at 2022-06-21 03:45:18.986832
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    play = MagicMock()
    obj = CallbackModule()
    obj._display.banner = MagicMock()
    obj._task_type_cache = {}
    obj.check_mode_markers = False
    play.check_mode = False
    play.get_name.return_value = 'fake'
    obj.v2_playbook_on_play_start(play)
    obj._display.banner.assert_called_with('PLAY [fake]')

    obj._task_type_cache = {}
    obj.check_mode_markers = True
    play.check_mode = True
    play.get_name.return_value = None
    obj.v2_playbook_on_play_start(play)
    obj._display.banner.assert_called_with('PLAY [CHECK MODE]')


# Generated at 2022-06-21 03:45:24.156510
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    options = {'show_per_host_start': True}
    callback = CallbackModule(display=None, options=options)
    callback.v2_runner_on_start(host='myhost', task=None)
    assert True


# Generated at 2022-06-21 03:45:30.589578
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
  import mock
  import ansible
  ansible.utils.basic.ANSIBLE_VERSION = '1.8.4'
  cb = CallbackModule()
  result = mock.MagicMock()
  result._result={}
  res={'failed': 0, 'changed': True}
  result._result.update(res)
  result._task = mock.MagicMock()
  result._task._uuid = '123'
  cb._last_task_banner = '123'

  self = mock.MagicMock()
  cb.v2_runner_item_on_ok(result)


# Generated at 2022-06-21 03:45:35.843032
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback = ansible.plugins.callback.CallbackModule()
    result = ansible.executor.task_result.TaskResult(host=object(), task=object(), task_fields=dict())
    ansible.utils.unsafe_proxy.UnsafeProxy({'diff': ['--- /home/user/test.txt\n+++ /home/user/test.txt\n', '- line 2\n', '+ other line 2\n', '']})
    assert callback.v2_on_file_diff(result._result)


# Generated at 2022-06-21 03:45:46.370580
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    mock = MagicMock()
    mock._task = "testtask"
    mock._result = {"test": True}
    mock._host = "testhost"
    cb = CallbackModule()
    cb.host_label = MagicMock()
    cb.host_label.return_value = "testhost"
    cb.v2_runner_on_unreachable(mock)
    assert cb._last_task_banner == None
    assert cb._last_task_name == None
    assert cb._task_type_cache == {}


# Generated at 2022-06-21 03:45:56.174976
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    cb = CallbackModule('/path/to/playbook.yml')
    task = {'action':'An example task, to test the CallbackModule',
            'tags':['example', 'test'],
            'name':'A task',
            'args':'',
            'check_mode':'',
            }
    cb.v2_playbook_on_task_start(task)


# Generated at 2022-06-21 03:46:01.577569
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    bootstrap_ansible()
    action('generate_fake_result')
    action('exec_module')
    # TEST CASES
    # test case 1.
    play = Mock()
    stats = Mock()
    stats.custom = {}
    stats.summarize = Mock(return_value='OK')
    stats.processed = {'ALL': 'OK'}
    play.check_mode = True
    cbm = CallbackModule()
    cbm.check_mode_markers = True
    cbm.show_custom_stats = False
    cbm.display_ok_hosts = True
    cbm.v2_playbook_on_stats(stats)

# Generated at 2022-06-21 03:46:41.636829
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    # Setup
    logger = logging.getLogger('test')
    retval = mock.Mock()

    callback_module = CallbackModule(logger)
    result = mock.Mock()
    result._host.get_name.return_value = 'host'
    result._result = {'async_result': {'ansible_job_id': 'jid'}}

    # Exercise
    callback_module.v2_runner_on_async_failed(result)

    # Verify
    logger.debug.assert_called_once_with('ASYNC FAILED on host: jid')

    # Cleanup
    logging.shutdown()
    reload(logging)

if __name__ == '__main__':
    test_CallbackModule_v2_runner_on_async_failed()

# Generated at 2022-06-21 03:46:49.716235
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    # Create a (mock) task result which will be passed to the method to be tested.

    module_result = {
      'changed': True, 
      'invocation': {
        'module_name': 'command'
      }, 
      'rc': 0, 
      'stderr': '', 
      'stdout': '\n'
    }
    task_result = Mock(
      _result=module_result, 
      _task=Mock(
        action=None, 
        loop=None, 
        name='test_task', 
        no_log=False, 
        notify=False, 
        rescue=None
      )
    )

# Generated at 2022-06-21 03:46:50.631520
# Unit test for method v2_playbook_on_no_hosts_remaining of class CallbackModule
def test_CallbackModule_v2_playbook_on_no_hosts_remaining():
    pass

# Generated at 2022-06-21 03:46:53.613653
# Unit test for method v2_playbook_on_no_hosts_matched of class CallbackModule
def test_CallbackModule_v2_playbook_on_no_hosts_matched():
    result = CallbackModule()
    result.v2_playbook_on_no_hosts_matched([])

# Generated at 2022-06-21 03:46:56.132799
# Unit test for method v2_playbook_on_handler_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_handler_task_start():
    callback_module = AnsibleJsonCallbackModule()
    callback_module.v2_playbook_on_handler_task_start(task)

# Generated at 2022-06-21 03:46:59.815134
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    c = CallbackModule()
    c.v2_runner_item_on_skipped(result)
    
    
    # Display skipped hosts, but only if the task is actually being displayed

# Generated at 2022-06-21 03:47:07.740299
# Unit test for method v2_playbook_on_no_hosts_remaining of class CallbackModule
def test_CallbackModule_v2_playbook_on_no_hosts_remaining():
    import mock
    import collections
    import ansible.playbook.play_context

    mock_play_context = mock.Mock(ansible.playbook.play_context.PlayContext)
    mock_play_context.check_mode = False
    mock_play_context.notify = []
    mock_play_context.only_tags = []
    mock_play_context.tags = []
    mock_play_context.force_handlers = False
    mock_play_context.verbosity = 0
    mock_play_context.step = None
    mock_play_context.start_at_task = None
    mock_play_context.remote_user = 'root'
    mock_play_context.connection = 'smart'
    mock_play_context.port = None

# Generated at 2022-06-21 03:47:14.138417
# Unit test for method v2_playbook_on_handler_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_handler_task_start():
    handler_task = object()
    obj = CallbackModule()
    obj._print_task_banner = MagicMock()
    obj.v2_playbook_on_handler_task_start(handler_task=handler_task)
    obj._print_task_banner.assert_called_once_with(handler_task)


# Generated at 2022-06-21 03:47:19.324184
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    obj = CallbackModule()
    result = Mock()
    result._task = Mock()
    result._task.action = 'command'
    result._result = {}
    result._result['diff'] = 'diff'
    result._result['changed'] = True
    obj.v2_on_file_diff(result)
    result._result['changed'] = False
    obj.v2_on_file_diff(result)

# Generated at 2022-06-21 03:47:25.387453
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    """Test CallbackModule.v2_playbook_on_notify """

    # Setup mock data for testing
    mock_self = setup_mock_data(self=None, stats=None, verbosity=None)

    # Test
    with pytest.raises(TypeError):
        mock_self.v2_playbook_on_notify()

# Generated at 2022-06-21 03:48:05.525851
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    from ansible.plugins.callback import CallbackModule
    from ansible.module_utils._text import to_bytes
    from ansible.utils.display import Display
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    callback_module = CallbackModule()
    callback_module._play = None
    callback_module._playbook = None
    callback_module._display = Display()
    callback_module._display._output_lock = None
    callback_module._display._log_only = None
    callback_module._display._screen_only = None
    callback_module._display.verbosity = 1
    callback_module._display.columns = 80
    callback_module._display.output = []
    callback_module._display.verbosity = 1
    callback_module._

# Generated at 2022-06-21 03:48:06.502500
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    pass

# Generated at 2022-06-21 03:48:14.881591
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    # test object initialization
    item = Mock()
    result = Mock()
    result.host = "host"
    result._host = None
    item.action = "action"
    result._result = {'stderr': "stderr", 'stdout': "stdout", 'stdout_lines': 'stdout_lines', 'warnings': "warnings"}
    result._task = "task"
    result._task.action = 'action'
    result._result['exception'] = Exception('Exception message')
    callback = CallbackModule()
    # calling the method under test
    callback.v2_runner_item_on_failed(result)

# Generated at 2022-06-21 03:48:22.205371
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    ''' unit test for method v2_playbook_on_play_start of class CallbackModule '''
    fake_play = FakePlay()
    fake_play._uuid = "fake_uuid"

    test_obj = CallbackModule()
    test_obj._play = fake_play
    test_obj._task_type_cache["fake_uuid"] = "fake_task_type"
    test_obj._last_task_name = "fake_last_task_name"
    test_obj._last_task_banner = "fake_last_task_banner"
    test_obj._last_task_path = "fake_last_task_path"
    test_obj.check_mode_markers = False
    test_obj.display_skipped_hosts = True
    test_obj.display_ok_

# Generated at 2022-06-21 03:48:31.739398
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    bcm = CallbackModule()
    assert bcm.disabled is True
    assert bcm.display is None
    assert bcm.display_ok_hosts is True
    assert bcm.display_failed_stderr is True
    assert bcm.display_skipped_hosts is True
    assert bcm.display_custom_stats is True
    assert bcm.check_mode_markers is False
    assert bcm._last_task_banner is None
    assert bcm._task_type_cache is {}
    assert bcm._last_task_name is None
    assert bcm._play is None
    assert bcm._task is None
    assert bcm._host is None
    assert bcm.show_custom_stats is True
    assert bcm.stdout_callback_whitelist is None


# Generated at 2022-06-21 03:48:43.475887
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    """
    Test the method CallbackModule.set_options with valid and invalid data.
    """

    #
    # Test CallbackModule.set_options with valid data.
    #

    # Create an instance of MockLogger.
    mock_logger = MockLogger()

    # Create an instance of MockDisplay.
    mock_display = MockDisplay()

    # Create an instance of CallbackModule.
    callback = CallbackModule(
        logger=mock_logger,
        display=mock_display,
        verbosity=0,
        show_custom_stats=True,
        listtags=False,
        listtasks=False,
        listhosts=False,
        step=None,
        start_at_task=None,
    )

    # Call method CallbackModule.set_options with valid data.


# Generated at 2022-06-21 03:48:53.530010
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    my_args = {}
    my_args['verbosity'] = 0
    __callback__ = CallbackModule(my_args)
    my_stats = {}
    my_stats['ok'] = 0
    my_stats['changed'] = 0
    my_stats['unreachable'] = 0
    my_stats['skipped'] = 0
    my_stats['failed'] = 0
    fake_processed = []
    fake_processed.append('foo')
    fake_processed.append('bar')
    my_stats['processed'] = fake_processed
    __callback__.v2_playbook_on_stats(my_stats)


# Generated at 2022-06-21 03:49:00.790933
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    import json

    # Test with item, action and result
    cb = CallbackModule()
    res_str = '{"changed": false, "item": "example"}'
    res_dict = json.loads(res_str)
    res = Result(host=None, task='test_task', action='test_command', result=res_dict)
    msg = cb.v2_runner_on_unreachable(res)
    assert msg == 'unreachable: [example]'
    assert cb.display_failed_stderr is False

    # Test with failed task at higher verbosity
    cb = CallbackModule()
    res_str = '{"changed": false, "item": "example"}'
    res_dict = json.loads(res_str)

# Generated at 2022-06-21 03:49:12.161604
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    # Tests for method v2_playbook_on_notify.
    #
    # If a handler is called on a host, this method will be called with the
    # handler as the first argument and the host on which the handler was
    # triggered as the second argument

    self = CallbackModule()

    # self.set_options({u'v2_playbook_on_notify.class': "CallbackModule"})
    # self.set_options({u'v2_playbook_on_notify.method1.class': "CallbackModule"})
    # self.set_options({u'v2_playbook_on_notify.method1.name': "v2_playbook_on_notify"})

    self.v2_playbook_on_notify(object(), object())

    return True

# Generated at 2022-06-21 03:49:23.068236
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.runner import Runner
    from ansible import inventory
    from ansible import callbacks
    from ansible import utils

    host_list = [inventory.host.Host(name='127.0.0.1')]
    myInv = inventory.Inventory(host_list)

    runner_cb = callbacks.DefaultRunnerCallbacks()
    playbook_cb = callbacks.DefaultPlaybookCallbacks()
    stats = callbacks.AggregateStats()
    runner_cb = callbacks.PlaybookRunnerCallbacks(verbose=utils.VERBOSITY)

    pc = playbook.PlayContext()

# Generated at 2022-06-21 03:50:50.064967
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
   c = CallbackModule()
   c.v2_runner_on_start('host', 'task')
   assert True

# Generated at 2022-06-21 03:50:53.881178
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    callback = CallbackModule()
    result = Mock(**{'_host.get_name.return_value': 'localhost', '_task.action': 'test', '_result.get.return_value': 'skipped'})
    callback.v2_runner_on_skipped(result)


# Generated at 2022-06-21 03:50:58.781213
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    test = CallbackModule()
    result = ansible.utils.unsafe_proxy.UnsafeProxy({'exception': None, 'msg': '', 'contacted': {}})
    result._host = None
    test.v2_runner_on_unreachable(result)


# Generated at 2022-06-21 03:51:05.747608
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    c = CallbackModule(Display())
    result = type('testresult', (object,), dict(
        _task = type('testtask', (object,), dict(
            action = 'testaction'
        )),
        _result = dict(
            changed = False,
            failed = False,
            msg = 'testmessage',
            skipped = False,
            stdout = 'testoutput',
            stderr = 'testoutput',
            content = 'testcontent',
            diff = 'testdiff',
            changed_when = True,
            failed_when = True,
            skip_reason = 'testskipping',
        ),
        _host = type('testhost', (object,), dict(
            name = 'testhost',
            get_name = lambda self: self.name
        ))
    ))
    c._task_start

# Generated at 2022-06-21 03:51:15.586977
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    """Test v2_playbook_on_stats method of CallbackModule"""

    module = ansible.plugins.callback.CallbackModule()

    class FakeStats(object):
        processed = dict()

        def summarize(self, host):
            return dict()

    stats = FakeStats()
    stats.processed = {
        'localhost': dict(),
        '127.0.0.1': dict()
    }
    module.v2_playbook_on_stats(stats)

    module.show_custom_stats = True

    stats.custom = dict()
    stats.custom['_run'] = dict()
    module.v2_playbook_on_stats(stats)

    stats.custom['custom_host'] = dict()
    module.v2_playbook_on_stats(stats)

    stats.custom = None
   

# Generated at 2022-06-21 03:51:17.554242
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    """Test case for ``CallbackModule.set_options`` method."""
    # CallbackModule.set_options(display=None)
    pass


# Generated at 2022-06-21 03:51:21.777639
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    # unit test for v2_runner_on_start() of class CallbackModule

    # create instance of class CallbackModule
    cb_mdl = CallbackModule()
    # create object of class Host()
    host = Host()
    # create object of class Task()
    task = Task()

    # check output of v2_runner_on_start()
    cb_mdl.v2_runner_on_start(host, task)


# Generated at 2022-06-21 03:51:29.173022
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    """
    GIVEN: 
        Class CallbackModule and the following arguments:
        result
    WHEN: 
        Calling method v2_runner_on_skipped()
    THEN: 
        Evaluate assert statement(s)
    """
    # Arrange
    callback_module = CallbackModule()
    result = object()
    callback_module.display_skipped_hosts = False

    # Act
    callback_module.v2_runner_on_skipped(result)

    # Assert
    # no assert statement(s)

# Generated at 2022-06-21 03:51:32.839670
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    
    from ansible.callbacks import CallbackModule
    from ansible.parsing.dataloader import DataLoader

    callback = CallbackModule()
    loader = DataLoader()
    callback.v2_runner_on_async_poll(result)


# Generated at 2022-06-21 03:51:39.591022
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    # Test v2_runner_retry of class CallbackModule
    # Test setup
    callback = CallbackModule()
    
    # Test body
    result = mock.Mock()
    result.retries = 2
    result.attempts = 1
    callback.v2_runner_retry(result)
    
    # Test teardown
    del result 
    del callback 


if __name__ == "__main__":
    # Unit test for method v2_runner_retry of class CallbackModule
    test_CallbackModule_v2_runner_retry()