

# Generated at 2022-06-21 03:45:00.470261
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    '''test for method `v2_runner_item_on_ok` '''
    output = sys.stdout
    fake_result = MagicMock()
    fake_result._result = Mock()
    fake_result._result.get = Mock(return_value=True)
    fake_result._result.get('changed', False)
    fake_result._task = MagicMock()
    fake_result._task.action = "REPLACE"

    cm = CallbackModule(display=MagicMock())
    cm._clean_results = Mock()
    cm._dump_results = Mock(return_value="")
    cm._run_is_verbose = Mock(return_value=True)
    cm.display_ok_hosts = Mock(return_value=True)

# Generated at 2022-06-21 03:45:06.011117
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    msg = "ASYNC POLL on %s: jid=%s started=%s finished=%s"
    result = RunnerResult(host=Host("hostname"), task=Task(), result=dict(ansible_job_id="jobid", started="start_time", finished="end_time"))
    my_callback = CallbackModule()
    my_callback.v2_runner_on_async_poll(result)
    assert my_callback.log_lines[0] == msg % ("hostname", "jobid", "start_time", "end_time")


# Generated at 2022-06-21 03:45:08.701367
# Unit test for method v2_playbook_on_no_hosts_remaining of class CallbackModule
def test_CallbackModule_v2_playbook_on_no_hosts_remaining():
    callbackModule = CallbackModule()
    try:
        callbackModule.v2_playbook_on_no_hosts_remaining()
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-21 03:45:20.775733
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.executor.task_result import TaskResult
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    import ansible.plugins
    from ansible.plugins.loader import callback_loader

    callback = callback_loader.get('human_readable')
    PlayContext._create_global_context()
    play = Play()
    play.hostvars = {}
    play._variable_manager = VariableManager()
    task = Task()
    task.action = "ping"
    task.name = "Killer Queen"

    result = TaskResult(host=HOST, task=task, return_data={"failed": True, "msg": "I AM ERROR"})
    callback.v2_runner_on_failed(result)


# Generated at 2022-06-21 03:45:30.230741
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    result = None

    result = "abcd"
    c = CallbackModule()
    c.v2_on_file_diff(result)
    assert c._last_task_banner == "abcd", "v2_on_file_diff: result is wrong"

    result = None
    c = CallbackModule()
    c.v2_on_file_diff(result)
    assert c._last_task_banner == "abcd", "v2_on_file_diff: result is wrong"

    result = ""
    c = CallbackModule()
    c.v2_on_file_diff(result)
    assert c._last_task_banner == "", "v2_on_file_diff: result is wrong"

    result = 0
    c = CallbackModule()
    c.v2_

# Generated at 2022-06-21 03:45:36.256685
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    """
    Unreachable
    """
    test_object = CallbackModule()
    result = result.copy()
    test_object.v2_runner_on_unreachable(result)
    assert test_object.unreachable_hosts == set(['testhost'])

# Generated at 2022-06-21 03:45:46.268082
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    result=Mock()
    result._host=Mock()
    result._host.get_name.return_value='localhost'
    result._result={
        'ansible_job_id': 1
    }
    callback=CallbackModule()
    callback.v2_runner_on_async_ok(result)
    result._host.get_name.assert_called_once_with()
    assert isinstance(result._result, dict)
    assert result._result['ansible_job_id']==1


# Generated at 2022-06-21 03:45:51.447319
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    # setUp
    callback_module = CallbackModule()
    
    
    # test
    callback_module.v2_runner_on_start("host", "task")
    
    # tearDown
    # nothing to do



# Generated at 2022-06-21 03:45:53.544267
# Unit test for method v2_playbook_on_no_hosts_remaining of class CallbackModule
def test_CallbackModule_v2_playbook_on_no_hosts_remaining():
    c = CallbackModule()
    assert c.v2_playbook_on_no_hosts_remaining() == None
    assert c.v2_playbook_on_no_hosts_remaining() == None
    

# Generated at 2022-06-21 03:45:57.629774
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    with pytest.raises(AnsibleError) as excinfo:
        raise AnsibleError("")
    assert 'AnsibleError("")' in str(excinfo.value)

# Generated at 2022-06-21 03:46:34.536670
# Unit test for method v2_playbook_on_no_hosts_remaining of class CallbackModule
def test_CallbackModule_v2_playbook_on_no_hosts_remaining():
    # Initialize cb object with test values
    cb = CallbackModule()
    # Get expected result
    results = {
            "plays": [],
            "msg": "No hosts matched",
        }
    assert results == cb.v2_playbook_on_no_hosts_remaining(playbook={"name":"Test","hosts":["test.example.org"]})

# Generated at 2022-06-21 03:46:42.382603
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # prepare arguments
    config = {'result_field': 'result'}

    # initialize CallbackModule
    callbackmodule = CallbackModule(event_stream=None, result_field=config['result_field'])

    # test static methods
    if callbackmodule.check_plugin_version():
        print("check_plugin_version(): PASS")
    else:
        print("check_plugin_version(): FAIL")

    if callbackmodule.supports_check_mode():
        print("supports_check_mode(): PASS")
    else:
        print("supports_check_mode(): FAIL")

    if callbackmodule.supports_async():
        print("supports_async(): PASS")
    else:
        print("supports_async(): FAIL")


# Generated at 2022-06-21 03:46:53.582707
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    callback = CallbackModule()
    callback.display_skipped_hosts = True
    result = createMock(['_result', '_task'])
    result._result = {'exception': "My error"}
    result._task = createMock(['action'])
    result._task.action = "mockAction"
    callback.display = MagicMock()
    callback.v2_runner_item_on_skipped(result)
    callback.display.display.assert_called_once_with("skipping: [None] => (item=[u'a', u'b', u'c']) => {u'exception': u'My error'}", color=7)
    callback.display.clear_mock()
    callback.display_skipped_hosts = False

# Generated at 2022-06-21 03:46:58.089442
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    runner_result = {"result":None,"msg":"line 1\nline2"}
    runner = Runner()
    ret = CallbackModule(runner).v2_runner_on_failed(runner_result)
    assert ret == None



# Generated at 2022-06-21 03:46:59.909854
# Unit test for method v2_playbook_on_handler_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_handler_task_start():
    """Test for method v2_playbook_on_handler_task_start of class CallbackModule."""


# Generated at 2022-06-21 03:47:08.011167
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    # Test that v2_runner_on_async_ok sets the correct self._check_mode
    mod = CallbackModule()
    mod._check_mode = True
    mod._display.verbosity = 1
    result = namedtuple('Result', 'host job_id')
    result._host = namedtuple('Host', 'name')
    result._host.name = 'fakehost'
    result._result = {'ansible_job_id': '12345'}
    mod.v2_runner_on_async_ok(result)
    assert(mod._check_mode is False)
    expected_out = "ASYNC OK on fakehost: jid=12345"
    out, err = capsys.readouterr()
    assert(expected_out in out)


# Generated at 2022-06-21 03:47:18.104276
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    # begin example test_CallbackModule_v2_playbook_on_task_start
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import ansible.constants as C

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-21 03:47:28.988695
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    module = get_module_instance(CallbackModule)
    module._display = Display()
    module.host_label = host_label_mock = Mock()
    module.host_label_mock.return_value = 'host1'
    module._run_is_verbose = _run_is_verbose_mock = Mock()
    module._run_is_verbose_mock.return_value = ''
    module._dump_results = _dump_results_mock = Mock()
    module._dump_results_mock.return_value = 'mock_result'
    result = FakeResult()
    result.task_name = 'task_name'
    result._task = '_task'
    result._host = FakeHost()

# Generated at 2022-06-21 03:47:31.894833
# Unit test for method v2_playbook_on_no_hosts_remaining of class CallbackModule
def test_CallbackModule_v2_playbook_on_no_hosts_remaining():
    callback_module = CallbackModule()
    message = "Test message"
    try:
        callback_module.v2_playbook_on_no_hosts_remaining(message)
    except SystemExit:
        pass
    except Exception as e:
        assert False, "Not triggered the expected exception"
    else:
        assert True, "Did not trigger any exception"

# Generated at 2022-06-21 03:47:33.506935
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
  # AssertionError: None
  assert False, "Unimplemented test method v2_runner_on_async_failed in class CallbackModule"



# Generated at 2022-06-21 03:48:12.068698
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    # Declare the output variable
    out = StringIO()
    # Create a CallbackModule class object
    c = CallbackModule(play=play)
    # Set module_utils/basic.py._ANSIBLE_ARGS instance variable to a known value
    setattr(_ANSIBLE_ARGS, 'verbosity', 0)
    # Call the method we want to test
    c.v2_runner_on_skipped(result)
    # Check the results
    assert True

# Generated at 2022-06-21 03:48:20.667327
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback = CallbackModule()

# Generated at 2022-06-21 03:48:28.851920
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    host = "example.org"
    result_ansible_job_id = "example_job_id"
    callback = CallbackModule()
    result = result_mock()
    result._result = {"ansible_job_id": result_ansible_job_id}
    result._host = host
    callback.v2_runner_on_async_ok(result)
    assert "ASYNC OK on %s: jid=%s" % (host, result_ansible_job_id) in callback.display_msg

# Generated at 2022-06-21 03:48:40.335387
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    # Test for method v2_playbook_on_notify(self, handler, host)
    #
    #  Ensure that CallbackModule is correctly instantiated so that all
    #  callbacks are invoked.
    #
    #  With:
    #   - verbosity = 0
    #   - show_custom_stats = False
    #   - display_skipped_hosts = True
    #
    #  Expect:
    #   - display("NOTIFIED HANDLER %s for %s" % (handler.get_name(), host), color=C.COLOR_VERBOSE, screen_only=True)
    #   - to be invoked.
    #
    cbm = CallbackModule(display=Display(), show_custom_stats=False, verbosity=0, display_skipped_hosts=True)
    cbm

# Generated at 2022-06-21 03:48:51.543083
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    from ansible.parsing.dataloader import DataLoader
    from ansible.cli.adhoc import AdHocCLI as cli_AdHocCLI
    from ansible.plugins.callback import CallbackBase as callback_CallbackBase
    from ansible.executor.task_queue_manager import TaskQueueManager as executor_TaskQueueManager
    from ansible.vars.manager import VariableManager as vars_VariableManager
    from ansible.inventory.manager import InventoryManager as inventory_InventoryManager
    from ansible.playbook.play import Play as playbook_Play
    from ansible.executor.playbook_executor import PlaybookExecutor as executor_PlaybookExecutor
    from ansible.playbook import Playbook as playbook_Playbook
    from ansible.playbook.block import Block as playbook_Block

# Generated at 2022-06-21 03:48:52.842577
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    print("Test: v2_playbook_on_include")






# Generated at 2022-06-21 03:49:00.311866
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    print("In Test set_options")
    from ansible.callbacks import CallbackModule
    from ansible.module_utils.facts.namespace import prefix as fact_ns_prefix
    from ansible.utils.display import Display
    from ansible.utils.color import colorize, hostcolor

    display = Display()
    display.verbosity = 4 # Message type: Verbose
    display.columns = 5 # Integer size of the terminal
    display.set_debug() # Set debug class to True
    display.set_verbosity(display.verbosity) # Set verbosity to display value
    ansi_colors = display._options['ANSIBLE_FORCE_COLOR'] == 'true' # Boolean value for ANSIBLE_FORCE_COLOR = true
    #ansi_colors = display._options.get('ANSIBLE_FORCE_COLOR')

# Generated at 2022-06-21 03:49:05.541694
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    ansible_runner = AnsibleRunner()
    ansible_runner.verbosity=1
    ansible_runner.callback_plugin = CallbackModule()
    ansible_runner.callback_plugin.v2_runner_item_on_failed(True)

# Generated at 2022-06-21 03:49:08.076242
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    pass


# Generated at 2022-06-21 03:49:13.108963
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    from ansible.plugins.callback import CallbackBase
    x = CallbackBase()

    # Case 1 : option value is present
    options = {
        'succeeded': True, 
        'failed': True, 
        'skipped': True
    }
    x.set_options(options)
    assert x.show_custom_stats == True


# Generated at 2022-06-21 03:50:05.692592
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    _host = 'host'
    _result = 'result'
    _task = 'task'
    _task._uuid = 'uuid'
    _task.action = 'action'

    result = Result(_host, _result, _task)
    result._result = {'_ansible_parsed': False, '_ansible_no_log': False,
                      '_ansible_item_result_counter': 1,
                      '_ansible_verbose_always': False}

    # First set the mute_display to False
    cb = CallbackModule()
    cb.mute_display = False
    cb.display_skipped_hosts = True
    assert not cb.display_skipped_hosts

    # Now set the mute_display to True and we can't call task_start()
    c

# Generated at 2022-06-21 03:50:10.401353
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    callback_module = CallbackModule()
    play = get_test_instance(dict(), module='ansible.parsing.dataloader.DataLoader')
    callback_module.v2_playbook_on_play_start(play)
    assert callback_module._play._attributes == {'name':None,'vars':{},'hosts':[]}



# Generated at 2022-06-21 03:50:13.615328
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    from ansible.plugins.callback import CallbackBase
    from ansible.module_utils.six import iteritems

    cb = CallbackModule()
    cb.__init__()
    fake_include = FakeInclude()
    cb.v2_playbook_on_include(fake_include)


# Generated at 2022-06-21 03:50:14.373397
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # assert True
    return True


# Generated at 2022-06-21 03:50:23.837306
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    # For the test.
    import AnsibleHandler
    import UnitTestParser

    # Get the class.
    callback_plugin = UnitTestParser.get_plugin_instance('notify')

    # Create an instance of the AnsibleHandler and add it to the callback_plugin.
    handler = AnsibleHandler.AnsibleHandler(
        name = 'notify',
        action = 'notify',
        event = 'notify',
        tags = ['notify'],
    )
    callback_plugin.add_handler(handler)

    # Create an instance of the Result.
    result = AnsibleHandler.Result(
        task = AnsibleHandler.Task(name='Install', action='notify', event='notify'),
    )

    # Call the v2_playbook_on_notify method.
    callback_plugin.v2_play

# Generated at 2022-06-21 03:50:26.213859
# Unit test for method v2_playbook_on_handler_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_handler_task_start():
    c = CallbackModule()
    c.v2_playbook_on_handler_task_start(None)
    assert c._last_task_banner is None

# Generated at 2022-06-21 03:50:32.441967
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    from ansible.plugins.callback.human_log import CallbackModule
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.handler import Handler
    from ansible.playbook.include import Include
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.errors import AnsibleParserError

    # Construct a host
    hosts = [
    	"test_host"
    ]
    # Create host inventory

# Generated at 2022-06-21 03:50:33.147302
# Unit test for method v2_playbook_on_cleanup_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_cleanup_task_start():
    pass

# Generated at 2022-06-21 03:50:44.244688
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    fqn = '%s.%s' % (__name__, test_CallbackModule_v2_runner_on_async_ok.__name__)
    out = '%s.out' % fqn
    # Monkey patch display class to capture output to out file
    CallbackModule.display = CallbackModuleDisplay(out)
    cb = CallbackModule()
    result = Mock()
    result._host = Mock()
    result._host.get_name.return_value = 'host'
    result._result = {'ansible_job_id': 'jobid'}
    cb.v2_runner_on_async_ok(result)
    with open(out, 'r') as f:
        assert f.read() == "ASYNC OK on host: jid=jobid\n"


#

# Generated at 2022-06-21 03:50:50.209031
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.manager import InventoryManager
    t = Task()
    t.action = 'shell'
    t.args = dict(msg='Hello world')
    
    c = CallbackBase()
    c.display = Display()
    c.v2_runner_on_ok(t)

# Generated at 2022-06-21 03:52:42.547327
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    host = "test_host"
    jid = "123456"
    result = Mock()
    result.get_name.return_value = host
    result._result = {}
    result._result['ansible_job_id'] = jid
    callback.v2_runner_on_async_ok(result)
    # Inspect the colorization and the notice message
    assert callback._display.display.call_args[0][0] == "ASYNC OK on %s: jid=%s" % (host, jid)
    assert callback._display.display.call_args[1]['color'] == C.COLOR_DEBUG

# Generated at 2022-06-21 03:52:46.752785
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    task = {
        'event': 'runner_on_ok',
        'type': 'task',
        'task_action': 'setup',
        'task_name': 'Gathering Facts'
    }
    callback = CallbackModule()
    callback.v2_playbook_on_task_start(task)

# Generated at 2022-06-21 03:52:53.225010
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    """
    Test method v2_playbook_on_start of class CallbackModule.
    """
    from ansible import constants as C
    import os
    import tempfile
    playbook_name = 'playbook.yaml'
    temp_dir = tempfile.mkdtemp()
    test_playbook = os.path.join(temp_dir, playbook_name)
    open(test_playbook, 'a').close()
    test_display = Display()
    test_stats = mock.Mock()
    test_custom_stats = 'test'
    test_show_custom_stats = True
    test_check_mode_markers=True
    args = {}
    args['args'] = 'test'
    context.CLIARGS = args

# Generated at 2022-06-21 03:53:03.070888
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    c = CallbackModule()
    c._last_task_banner = '6f1ce6e0-f47d-4b4c-b4b6-4d6fef338a03'
    c._display = CallbackModule_display()
    c._display.display = MagicMock()
    c._get_diff = MagicMock()
    c._get_diff.return_value = '+   "name": "test_test"\n'
    t = Task()
    t._uuid = '6f1ce6e0-f47d-4b4c-b4b6-4d6fef338a03'
    t.action = 'set_fact'
    t.check_mode = False

# Generated at 2022-06-21 03:53:04.243802
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    pass


# Generated at 2022-06-21 03:53:12.671278
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback = CallbackModule()

# Generated at 2022-06-21 03:53:15.996328
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    CallbackModule = CallbackModule()
    host = "localhost"
    CallbackModule.display_skipped_hosts = True
    result = AnsibleResult(host=host, task="task", task_args=dict(), task_action=dict(), is_changed=False, is_failed=False)
    result._result = "running"
    CallbackModule.v2_runner_on_skipped(result)
    assert result._result == 'running'


# Generated at 2022-06-21 03:53:16.614823
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    pass

# Generated at 2022-06-21 03:53:19.523385
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    """
    This test should pass, as the set_options method should take no
    arguments.
    """
    callback = CallbackModule()
    callback.set_options()



# Generated at 2022-06-21 03:53:23.526397
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    mock_task = mock.Mock()
    callback = CallbackModule()
    callback.v2_playbook_on_task_start(mock_task)
    