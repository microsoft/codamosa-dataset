

# Generated at 2022-06-21 03:45:08.061968
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    result_instance = Result()

# Generated at 2022-06-21 03:45:10.219706
# Unit test for method v2_playbook_on_handler_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_handler_task_start():
    cb = CallbackModule()
    cb.v2_playbook_on_handler_task_start("foo")
    assert "foo" == "foo"


# Generated at 2022-06-21 03:45:20.916181
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    import json
    import os
    import shutil
    import tempfile
    from ansible.utils.vars import combine_vars
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    dummy_passwords = {
        'https_pass'  : 'PASSWORD',
        'ansible_winrm_pass' : 'PASSWORD',
    }
    loader = DataLoader()
    # Manager needs to know where to load modules from
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])

# Generated at 2022-06-21 03:45:29.605614
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Test that playbooks with only changed actions are counted as changed.
    changed_actions = {'changed': 1}
    test_obj = CallbackModule()
    test_obj.v2_playbook_on_stats(changed_actions)
    assert test_obj.v2_playbook_on_start(changed_actions) == 'PLAY RECAP\n'

test_obj = CallbackModule()
assert test_obj.v2_playbook_on_start(test_obj) == 'PLAY RECAP\n'

print(test_obj.v2_playbook_on_start(test_obj))

print(test_obj.v2_playbook_on_start(test_obj))


# Generated at 2022-06-21 03:45:30.553670
# Unit test for method v2_playbook_on_no_hosts_remaining of class CallbackModule
def test_CallbackModule_v2_playbook_on_no_hosts_remaining():
    assert True == True

# Generated at 2022-06-21 03:45:33.859262
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    """
    Testv2_playbook_on_notify of method CallbackModule
    """
    assert True

# Generated at 2022-06-21 03:45:39.802323
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():

    cb = CallbackModule()

    result = Result(None, 'ok')
    cb.v2_runner_item_on_skipped(result)
    assert cb.display_skipped_hosts == False
    assert cb.get_option('show_per_host_start') == True
    assert cb.get_option('no_log') == False
    

# Generated at 2022-06-21 03:45:40.644067
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    pass


# Generated at 2022-06-21 03:45:44.860990
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():

    # Cylinder
    print("\nCylinder")
    env_path = os.path.abspath(os.path.join(__file__, "..", ".."))
    os.environ["ANSIBLE_CONFIG"] = "/home/selenium/git/ansible/hacking/test/units/modules/linux-system-roles/galaxy/collection_requirements.yml"
    os.environ["ANSIBLE_LIBRARY"] = env_path + "/library"
    os.environ["ANSIBLE_FILTER_PLUGINS"] = env_path + "/plugins/filter"
    os.environ["ANSIBLE_STDOUT_CALLBACK"] = "stdout_json"
    os.environ["ANSIBLE_ACTION_PLUGINS"] = env_path + "/plugins/action"

# Generated at 2022-06-21 03:45:49.716618
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    result = Mock()
    result._result = {}
    result._host = Mock()
    result._host.get_name = Mock()
    result._host.get_name.return_value = "localhost"

    callbackModule = CallbackModule()
    callbackModule.v2_runner_on_async_failed(result)

    output, error = capsys.readouterr()
    assert "ASYNC FAILED on localhost: jid=None" in output
    assert not error

# Generated at 2022-06-21 03:46:21.542855
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.task_include
    import ansible.playbook.handler
    import ansible.template
    import ansible.inventory.manager
    import ansible.vars.manager
    import ansible.executor.task_queue_manager
    import ansible.cli
    import ansible.utils.display
    import ansible.parsing.dataloader
    import sys

    # Prepare test variables
    if 0:  # Just to make it easy to import in ipython
        import ansible.cli
        import ansible.inventory
        import ansible.parsing.dataloader
        import ansible.playbook
        import ansible.utils.display
        import ansible.vars

# Generated at 2022-06-21 03:46:32.666371
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    options = namedtuple('Options', ['listtags', 'listtasks', 'listhosts', 'syntax', 'connection','module_path', 'forks', 'remote_user', 'private_key_file', 'ssh_common_args', 'ssh_extra_args', 'sftp_extra_args', 'scp_extra_args', 'become', 'become_method', 'become_user', 'verbosity', 'check', 'diff'])
    options = options

# Generated at 2022-06-21 03:46:40.855011
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import ansible.plugins.callback.default
    b_module = ansible.plugins.callback.default.CallbackModule()
    class_name = "CallbackModule"
    method_name = "v2_on_file_diff"
    
    # Setup test environment
    set_module_args({})
    my_ansible = Ansible()
    my_ansible.loader._module_cache.clear()
    my_ansible.loader._module_cache_file_mutex.clear()
    my_ansible.loader._module_cache_file.clear()
    my_ansible.loader._module_cache_scenario.clear()
    my_ansible.loader._module_cache_term.clear()
    my_ansible.loader._module_requests.clear()
    my_ansible.loader._module_utils_paths

# Generated at 2022-06-21 03:46:51.000818
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    import pytest
    from ansible.plugins.callback.default import CallbackModule
    from ansible.executor.task_result import TaskResult

    result = TaskResult(host=FakeHost(), task=FakeTask())
    callback = CallbackModule()

    with pytest.raises(TypeError) as excinfo:
        callback.v2_runner_on_ok(result=result)
    assert 'result must have a _result attribute of type dict' in str(excinfo)

    result._result = {'exception': 'faked exception'}
    with pytest.raises(TypeError) as excinfo:
        callback.v2_runner_on_ok(result=result)
    assert 'result must have a _host attribute of type Host' in str(excinfo)

    # test the scenario where host is not a Host instance.


# Generated at 2022-06-21 03:47:02.778986
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    results = get_test_results('test_callback_plugin')
    results_test = results['test_callback_plugin']

    # TODO: notify_action
    # TODO: runner_retry
    # TODO: runner_on_ok
    # TODO: runner_on_error
    # TODO: runner_on_skipped
    # TODO: runner_on_unreachable

    # test runner_on_async_failed
    host = load_vars(results_test['runner_on_async_failed'])['inventory_hostname']
    result = load_result(results_test['runner_on_async_failed'])
    callbackModule = CallbackModule()
    for i in range(1, 10):
        callbackModule.v2_runner_on_async_failed(result)
   

# Generated at 2022-06-21 03:47:15.568583
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    module = __import__('ansible.plugins.callback.human_log')
    class_ = getattr(module, 'CallbackModule')
    obj = class_()
    x = AnsibleV2CallbackModule()
    x._display = obj._display
    x.show_custom_stats = obj.show_custom_stats
    x.display_ok_hosts = obj.display_ok_hosts

    result = AnsibleResult()
    result.host = '127.0.0.1'
    result._task = AnsibleTask()
    result._task.action = 'test'
    result._result = {
        'test1':'test1',
        'test2':'test2'
    }

    x.v2_playbook_on_include(result)


# Generated at 2022-06-21 03:47:25.528724
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    stats = StatsModule()
    ans = CallbackModule()
    class Host():
        def __init__(self, name):
            self.name = name
    class Result():
        def __init__(self, task, host, result):
            self._task = task
            self._host = host
            self._result = result

    # test host with all stat
    h1 = Host('h1')
    r1 = Result(None, h1, {'ok':2, 'changed':1, 'unreachable':2, 'failures':3, 'skipped':4, 'rescued':5, 'ignored':6})

# Generated at 2022-06-21 03:47:29.927603
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    my_callback = CallbackModule()
    task = Task('foo', {}, {}, 'play')
    my_callback.v2_playbook_on_task_start(task)
    assert my_callback._last_task_banner == task._uuid


# Generated at 2022-06-21 03:47:38.243374
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    stats = MockStats()
    playbook = MockPlaybook()
    playbook._file_name = 'playbook.yml'
    callback = CallbackModule()
    callback.v2_playbook_on_stats(stats)
    assert callback.show_custom_stats == True
    assert callback.check_mode_markers == True
    assert callback.show_task_output == False
    assert callback.show_task_path == False
    assert callback.display_skipped_hosts == True
    assert callback.display_ok_hosts == True
    assert callback.display_failed_stderr == False
    
    
    
    
    
    

# Generated at 2022-06-21 03:47:43.550524
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    '''
    Unit test for method v2_runner_on_failed of class CallbackModule
    '''
    myModule = CallbackModule()
    
    class Object(object):
        def __init__(self):
            self.result = {'failed': True}
            self.task_name = 'test'
            self.host = '127.0.0.1'
            self.__name__ = ''
            self.color = '0'
            self.stderr = '1'
            self.verbosity = 2
    result = Object()
    myModule.v2_runner_on_failed(result)

# Generated at 2022-06-21 03:48:26.110981
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    pass



# Generated at 2022-06-21 03:48:32.504191
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import ansible.plugins.callback.default
    result = self.runner_results
    self.display.banner(str(result._result))
    if self._display.verbosity < 3 and 'diff' in result._result and result._result['diff']:
        diff = '\n'.join(result._result['diff'])
        #self._display.display(diff, color=C.COLOR_SKIP)
        self._last_task_banner = self._display.current_task_name
    self._display.display(result.get_result(), color=C.COLOR_ERROR, log_only=True)


# Generated at 2022-06-21 03:48:42.801003
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    runner = fake_api.Runner(create_dirs=True)
    runner.run()
    result = runner.results_summary
    result.update({'ansible_job_id': u'59891.67116', 'started': 1459379050.553909, 'finished': 1459379052.574993})
    callback_module = CallbackModule(show_custom_stats=True)
    callback_module.v2_runner_on_async_poll(result)
    assert callback_module.output == 'ASYNC POLL on localhost: jid=59891.67116 started=1459379050.553909 finished=1459379052.574993'

# Generated at 2022-06-21 03:48:53.529318
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    from ansible.utils.color import stringc
    from ansible.utils.display import Display
    from ansible.plugins.callback import CallbackModule
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    callback_module = CallbackModule(display=Display())
    callback_module.v2_on_any(host=None, result=None, task=None, task_result=None, play_result=None, included_file=None)
    callback_module.v2_on_any(host=None, result=None, task=None, task_result=None, play_result=None, included_file=None)
    callback_module.v2_runner_on_async_failed(result=None)
    callback_module.v2_runner_on

# Generated at 2022-06-21 03:48:58.786175
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    # Setup
    m_display = MagicMock(Display)
    options = {'display_custom_stats': True, 'show_custom_stats': True, 'verbosity': 0}
    m_display.verbosity = 0
    # Call function under test
    callback = CallbackModule(display=m_display)
    callback.set_options(options)
    # Assert
    assert callback.show_custom_stats == True
    assert callback.display_custom_stats == True


# Generated at 2022-06-21 03:49:11.075807
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    host_result_map = {
                        "localhost" : "failed"
                      }
    ansible_result_object_map = {
                                    "localhost" : {
                                                                        "unreachable": False,
                                                                        "skipped": False,
                                                                        "failed": True,
                                                                        "changed": False,
                                                                        "msg": "test message",
                                                                    }
                                }
    ansible_play_object = ({"playbook_name" : "test.yml"
                            })
    ansible_task_object = ({"task_name" : "task name"
                            })
    ansible_host_object = ({"host_name" : "localhost"
                            })

    class TestHost:
        def __init__(self):
            self.get

# Generated at 2022-06-21 03:49:22.271473
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    mock_result = Mock()
    mock_result._task = Mock()
    mock_result._task.loop = False
    mock_result._result = {'changed': True}
    mock_result._host = Mock()
    mock_result._host.get_name.return_value = 'localhost'
    mock_self = Mock()
    mock_self._last_task_banner = 0
    mock_self._clean_results = Mock()
    mock_self._run_is_verbose = Mock()
    mock_self._run_is_verbose.return_value = False
    mock_self._dump_results = Mock()
    mock_self._dump_results.return_value = 'ok'
    mock_self._task_start = Mock()
    mock_self._last_task_name = None
    mock_self._display

# Generated at 2022-06-21 03:49:25.217556
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    assert TestCallbackModule().v2_runner_item_on_skipped('result') == None
    
    

# Generated at 2022-06-21 03:49:28.374805
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    result = Result(host=None, task=None, result={"ansible_job_id": "1", "started": "2018-09-24 08:21:57.918620", "finished": "2018-09-24 08:22:16.736398"}, _host=None, _task=None)
    CallbackModule.v2_runner_on_async_poll(CallbackModule, result)

# Generated at 2022-06-21 03:49:34.956462
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    callback = CallbackModule()
    result = Result("localhost", "test_module")
    result._task = Task("test_module", "localhost")
    result._result = {
        "failed": True,
        "msg": "Task run failed",
        "module_stdout": "test",
        "module_stderr": "test"
    }
    callback.v2_runner_item_on_failed(result)



# Generated at 2022-06-21 03:50:43.472962
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    inventory = InventoryManager(loader=None, sources='')
    variable_manager = VariableManager(loader=None, inventory=inventory)
    loader = DataLoader()
    cb = TestCallbackModule()
    task = Task()
    task._uuid = "test"
    task.check_mode = False
    task.no_log = False
    task.action = "test"
    task.loop = False
    task.args = {}
    task.set_loader(loader)
    task.set_variable_manager(variable_manager)

    cb.v2_playbook_on_task_start(task)

    assert cb._last_task_name == "test"
    assert cb._last_task_banner == "test"

# TODO: unit test for method v2_playbook_on_stats
#

# Generated at 2022-06-21 03:50:50.171283
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    # Establish a null connection to fake a transport
    connection = Connection('ssh')
    # Create a fake ansible playbook
    pb = Playbook()
    # Create fake task
    task = Task()
    # Create fake result
    result = TaskResult(host=connection, task=task, return_data={"message":"fake result"})
    # Create instance of CallbackModule
    cb = CallbackModule()
    # Display skipped tasks
    cb.display_skipped_hosts = True
    # Check if task is skipped
    cb.v2_runner_item_on_skipped(result)
    assert True

# Generated at 2022-06-21 03:50:57.090258
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    runner_result_mock = mock.create_autospec(RunnerResult)
    runner_result_mock.result = {}
    runner_result_mock.host = {}
    runner_result_mock.host.name = 'localhost'
    runner_result_mock.task_name = 'Test Playbook'
    runner_result_mock.action = 'ping'
    runner_result_mock.task_uuid = 'test-task-uuid'
    runner_result_mock._uuid = 'test-task-uuid'
    runner_result_mock._task = mock.create_autospec(Task)

    callback_module = CallbackModule()
    callback_module.v2_runner_on_failed(runner_result_mock)



# Generated at 2022-06-21 03:51:05.366120
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    with patch('ansible.plugins.callback.default.display') as mocked_display:
        instance = mocked_display.return_value
        instance.display.return_value = None
        verbosity = 3
        config = {'verbosity': verbosity}
        obj = CallbackModule()
        obj.set_options(direct={'verbosity': verbosity})
        obj.set_options(direct=config)
        obj.v2_runner_retry(result=MagicMock(attempts=1, task_name='TaskName', _task='Task', _host='Host', _result={'retries': 2, 'attempts': 1}))
        assert mocked_display.call_count == 1

# Generated at 2022-06-21 03:51:12.364076
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    host_label='localhost'
    result=lambda:'string'
    result.task_name='string'
    result._task='string'
    result._result=lambda:'string'
    result._result['retries']='string'
    result._result['attempts']='string'
    item=lambda:'string'
    item.item='string'
    result._result=item
    ansible.plugins.callback.CallbackModule.v2_runner_retry(host_label,result)

# Generated at 2022-06-21 03:51:15.513979
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    '''
    Unit test for method CallbackModule::v2_runner_on_async_poll
    '''
    # setup parameters
    result=object()
    # execute testing function
    callbackmodule.v2_runner_on_async_poll(result)


# Generated at 2022-06-21 03:51:22.496228
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    callback = CallbackModule()
    stats = Mock()
    stats.processed = Mock(return_value={'10.0.0.1': {'ok': 1, 'changed': 2, 'unreachable': 3, 'failures': 4, 'skipped': 5, 'rescued': 6, 'ignored': 7}})
    stats.summarize = Mock(return_value={'ok': 1, 'changed': 2, 'unreachable': 3, 'failures': 4, 'skipped': 5, 'rescued': 6, 'ignored': 7})
    callback.v2_playbook_on_stats(stats)
    assert(callback._display.display.call_count == 2)
    assert(stats.summarize.call_count == 1)
    assert(hostcolor.call_count == 1)

# Generated at 2022-06-21 03:51:29.634383
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    callbackModule = CallbackModule()
    test_result = AnsibleResult()
    test_result._host = Host()
    test_result._host.name = "test"
    test_result._result = {"ansible_job_id": "12345"}
    callbackModule.v2_runner_on_async_failed(test_result)

    # AssertionError: DEBUG ok: [test] => {u'ansible_job_id': u'12345'} => {u'ansible_job_id': u'12345'}


# Generated at 2022-06-21 03:51:39.117164
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    """
    Unit test for method v2_runner_item_on_skipped of class CallbackModule
    """

    # Setup test object
    c = CallbackModule()

    # Setup Mock objects
    m_result = MagicMock()
    m_display = MagicMock()
    attribute_side_effects = [
        MagicMock(return_value=m_display),
        m_result
    ]
    m_display.verbosity = 0
    m_result.task_name.return_value = 'test_task_name'
    m_result.host.get_name.return_value = 'test_host'
    m_result.action = 'test_action'
    m_result.task_action = 'test_task_action'
    m_result._task_fields.return_value = 0
    m_

# Generated at 2022-06-21 03:51:46.725231
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    def test_template(previous_task_name):
        m_self = Mock(
            display_ok_hosts = True,
            display_skipped_hosts = True,
            _task_type_cache = {},
            _last_task_banner = '',
            _last_task_name = previous_task_name,
            _print_task_banner  = Mock(return_value=None),
        )
        m_task = Mock(
            get_name = Mock(return_value='test_task_name'),
            no_log = False,
            _uuid = 'test_task_uuid'
        )
        m_task._is_free_form = Mock(return_value=False)
        callback = CallbackModule()

# Generated at 2022-06-21 03:52:58.472268
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    # let's check that notify() works as expected
    callback = CallbackModule()
    handler = "foo"
    host = "bar"
    # Notify the user.
    callback.v2_playbook_on_notify(handler, host)
    # Test that the method was called properly.


# Generated at 2022-06-21 03:53:00.407191
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    """
    Unit test for CallbackModule constructor
    """
    callback = CallbackModule()
    assert callback

# Generated at 2022-06-21 03:53:09.131746
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    """
    Test that the CallbackModule correctly handles a v2_runner_on_start action.
    """
    cbk = CallbackModule()
    
    cbk._display = FakeDisplay()
    cbk._task_type_cache = TaskTypeCache()

    # Test with a show_per_host_start option set to True
    cbk.set_options({'show_per_host_start': True})

    h = FakeHost("fake_host")
    t = FakeTask("fake_task_name")

    cbk.v2_runner_on_start(h, t)

    assert cbk._display._messages[0] == "[started fake_task_name on fake_host]"
    assert cbk._display._colors[0]   == C.COLOR_OK

    # Test with

# Generated at 2022-06-21 03:53:15.807783
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    host_name = {
        "host": {
            "name": "1.1.1.1",
            "ansible_host": "1.1.1.1"
        }
    }

# Generated at 2022-06-21 03:53:25.181313
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    #get the object of CallbackModule
    obj = CallbackModule()
    #get a mock.Mock object of result
    result = mock.Mock()
    #result.task.loop = False
    result.task.loop = True
    result._host.get_name.return_value = 'host_name'
    #result._result.get.return_value = False
    result._result.get.return_value = True
    result._task.action = 'action'
    result._result = {'diff':'diff','changed':True}
    #result._task._uuid = '_uuid'
    result._task._uuid = '_uuid1'
    #test method when result.task.loop is False
    #obj.v2_runner_item_on_ok(result)
    #test method when result

# Generated at 2022-06-21 03:53:31.512528
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    result = None
    result._task_name = "Some task name"
    result._host = "192.168.0.1"
    result._result = {
        "retries": 10,
        "attempts": 5,
    }
    CallbackModule().v2_runner_retry(result)
    print(get_stdout())
    assert_stdout_equal("FAILED - RETRYING: [192.168.0.1]: Some task name (5 retries left).\n")


# Generated at 2022-06-21 03:53:42.081722
# Unit test for method v2_playbook_on_handler_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_handler_task_start():
    def mock_new_playbook():
        playbook_ = Mock()
        playbook_.is_playbook = False
        playbook_.name = Mock()
        playbook_.name.strip = Mock(side_effect=[False,"test"])
        playbook_.check_mode = False
        return playbook_

    callback_module_ = CallbackModule()
    handler = Mock()
    task = Mock()
    task.get_name = Mock(return_value = "test")
    handler.loop = False
    callback_module_._last_task_name = "test"
    callback_module_._last_task_banner = "test"
    outcome = callback_module_._print_task_banner(task)
    assert outcome == False
    assert not callback_module_._last_task_banner == "test"


# Generated at 2022-06-21 03:53:52.206082
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    # Test 1: No arguments given.
    cb1 = CallbackModule()
    assert cb1.display_ok_hosts == True, 'display_ok_hosts should be True'
    assert cb1.display_failed_stderr == True, 'display_failed_stderr should be True'
    assert cb1.display_skipped_hosts == True, 'display_skipped_hosts should be True'
    assert cb1.display_check_mode_details == True, 'display_check_mode_details should be True'
    assert cb1.display_snippets == True, 'display_snippets should be True'

    # Test 2: Two arguments given.
    cb2 = CallbackModule()

# Generated at 2022-06-21 03:53:53.959570
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    callback = CallbackModule()
    host = HostVars()
    handler = AnsibleHandler()
    callback.v2_playbook_on_notify(handler, host)

# Generated at 2022-06-21 03:53:55.424962
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    # TODO: Write unit test for method v2_runner_on_unreachable of class CallbackModule
    pass 