

# Generated at 2022-06-23 09:23:45.115310
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    fake_task_name = 'fake_task_name'
    fake_task = FakeTask(fake_task_name)
    display = FakeDisplay()
    callback_module = CallbackModule(display=display)
    callback_module.v2_playbook_on_task_start(fake_task)
    assert display.last_item == 'TASK: [%s]' % fake_task_name


# Generated at 2022-06-23 09:23:47.723301
# Unit test for method v2_playbook_on_cleanup_task_start of class CallbackModule

# Generated at 2022-06-23 09:23:58.513084
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    cb = CallbackModule()
    handler = Handler()
    handler.get_name = MagicMock()
    host = "localhost"
    cb.v2_playbook_on_notify(handler, host)
    handler.get_name.assert_called_once_with()
    cb._display.display.assert_called_once_with("NOTIFIED HANDLER %s for %s" % (handler.get_name(), host), color=C.COLOR_VERBOSE, screen_only=True)

    # Verify that the call to v2_playbook_on_notify() is silent if verbosity is not > 1
    cb = CallbackModule()
    cb.v2_playbook_on_notify(handler, host)
    cb._display.display.assert_not_called()

 

# Generated at 2022-06-23 09:24:03.829712
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    result = mock.Mock()
    result.task_name = 'foo'
    result._task = 'bar'
    result._result = {'retries': 1, 'attempts': 1}
    result._host = mock.Mock()
    result._host.get_name.return_value = 'abc'
    cb = CallbackModule()
    cb.v2_runner_retry(result)
    result.task_name = None
    cb.v2_runner_retry(result)


# Generated at 2022-06-23 09:24:16.090489
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    # Test CallbackModule::v2_playbook_on_stats
    stats = mock.Mock(spec_set=dict)
    stats.processed = {'host1': {'test': 'test'}, 'host2': {'test': 'test'}}
    stats.summarize = lambda x: {'ok': 1, 'changed':2, 'unreachable':3, 'failures':4, 'skipped':5, 'rescued':6, 'ignored':7}
    stats.custom = {'_run': {'test': 'test'}, 'host1': {'test': 'test'}}
    fake_display = FakeDisplay()

    callback = CallbackModule()
    callback._display = fake_display
    callback.show_custom_stats = True


# Generated at 2022-06-23 09:24:17.842375
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    obj = CallbackModule()
    assert obj


# Generated at 2022-06-23 09:24:29.932544
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    # unit test for testing the set_options method of CallbackModule
    # For this test, we need to set all options for the CallbackModule
    # since the set_options method is a catch all for setting all options
    # for the callback module class.  Since we set all the options by
    # calling set_options, there is not much to test.  We basically
    # confirm that set_options was called and that it set all the proper
    # variables
    #
    # We instantiate CallbackModule here and then test that the proper values
    # were set when set_options was called
    callback = CallbackModule()
    # test our variables

# Generated at 2022-06-23 09:24:37.448569
# Unit test for method v2_runner_item_on_skipped of class CallbackModule

# Generated at 2022-06-23 09:24:44.114945
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    result = Mock()
    result._host = Mock()
    result._host.get_name.return_value = "host"
    result._result = Mock()
    result._result.get.return_value = "job_id"
    dummy = CallbackModule()
    dummy.v2_runner_on_async_ok(result)


# Generated at 2022-06-23 09:24:50.105033
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    # Without arguments
    # Arrange
    args = MagicMock()
    args.verbosity = 0
    args.diff = False
    args.check = False
    args.syntax = False
    args.inventory_path = None
    args.inventory = None
    args.listhosts = None
    args.subset = None
    args.module_paths = None
    args.extra_vars = None
    args.forks = 1
    args.ask_pass = False
    args.private_key_file = None
    args.remote_user = None
    args.connection = 'smart'
    args.timeout = 10
    args.ssh_common_args = None
    args.sftp_extra_args = None
    args.scp_extra_args = None

# Generated at 2022-06-23 09:24:52.535423
# Unit test for method v2_playbook_on_handler_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_handler_task_start():
    cbm = CallbackModule()
    cbm.v2_playbook_on_handler_task_start(Task())


# Generated at 2022-06-23 09:25:02.338445
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    mock_result = create_autospec(ResultCallback)
    mock_result._host = Mock(spec=Host)
    mock_result._host.get_name.return_value = 'foo'
    mock_result._result = {'ansible_job_id': '5700',
                           'started': '2016-12-22T21:29:00-00:00',
                           'finished': '2016-12-22T21:30:00-00:00'}
    mock_display = Mock(spec=Call)
    mock_display.display.return_value = None

    mock_callback_module = CallbackModule(mock_display)
    mock_callback_module.v2_runner_on_async_poll(mock_result)
    mock_callback_module.display_ok_hosts = False


# Generated at 2022-06-23 09:25:10.169073
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    task = create_ansible_task()
    task.set_name('name of task')
    task.set_uuid('uuid of task')
    task.set_type('action')
    task.set_action('ping')
    task.set_loop(False)
    task.set_no_log(False)
    task.set_check_mode(False)
    callback = CallbackModule()

    expected_display = 'TASK [name of task] \n'
    actual_display = callback.v2_playbook_on_task_start(task)
    assert expected_display == actual_display


# Generated at 2022-06-23 09:25:13.562013
# Unit test for method v2_playbook_on_no_hosts_remaining of class CallbackModule
def test_CallbackModule_v2_playbook_on_no_hosts_remaining():
    # create the object under test
    cb_obj = CallbackModule()

    # call the method under test
    cb_obj.v2_playbook_on_no_hosts_remaining(None)
    
    

# Generated at 2022-06-23 09:25:15.786878
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    callbackModule = CallbackModule()
    callbackModule.v2_playbook_on_task_start("task")

# Generated at 2022-06-23 09:25:20.348302
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    test_instance = CallbackModule()
    try:
        test_instance.v2_playbook_on_start()
    except Exception as e:
        assert True
    finally:
        del test_instance
        assert True


# Generated at 2022-06-23 09:25:30.632404
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    inventory_filename='../inventory.ini'
    variable_filename='../group_vars/all/vars.yml'
    host='all'
    module='command'
    args='echo hello'
    forks=10
    check_mode=False
    d=TestCallbackModule(inventory_filename,variable_filename,host,module,args,forks,check_mode)
    task_name=module
    is_conditional=False
    d.task_name=task_name
    d.v2_playbook_on_task_start(task_name, is_conditional)
    assert d.task_name==task_name


# Generated at 2022-06-23 09:25:34.927901
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    callback_module = CallbackModule()
    included_file = {
        '_hosts': [
            {'name': '127.0.0.1'},
         ],
         '_filename': 'roles/test/main.yml',
         '_vars': {}
    }

# Generated at 2022-06-23 09:25:41.052159
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    # test_CallbackModule_v2_runner_item_on_ok()
    # check if this function is coverd by test.
    # ansible/test/units/callback_plugins/test_default.py
    # This function is coverd by test.
    pass

CallbackModule = CallbackModule

# Generated at 2022-06-23 09:25:46.147614
# Unit test for method v2_playbook_on_handler_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_handler_task_start():
    with patch('ansible.utils.unicode.is_unicode') as mock_is_unicode:
        with patch('ansible.plugins.callback.log_plays.Timer') as mock_timer:
            with patch('ansible.plugins.callback.log_plays.codecs') as mock_codecs:
                with patch('ansible.plugins.callback.log_plays.os') as mock_os:
                    mock_is_unicode.return_value = False
                    mock_codecs.open.return_value.write.return_value = False
                    mock_os.access.return_value = False
                    mock_os.W_OK.return_value = False
                    mock_os.write.return_value = False
                    mock_os.close.return_value = False
                    mock_timer.return_value.elapsed

# Generated at 2022-06-23 09:25:54.892997
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    cb=CallbackModule()
    cb.display_skipped_hosts=True
    result=Mock()
    result._result={}
    cb.v2_runner_on_skipped(result)
import unittest
from mock import Mock
from mock import patch
from ansible.parsing.ajson import AnsibleJSONEncoder
from ansible.plugins.callback import CallbackBase
from ansible.plugins.callback import CallbackModule
from ansible.utils.json import to_json
from ansible.utils.json import to_nice_json
from ansible.utils.json import to_safe
from ansible.utils.unicode import to_unicode

import ansible.plugins.callback.json



# Generated at 2022-06-23 09:26:02.732899
# Unit test for method v2_playbook_on_no_hosts_remaining of class CallbackModule
def test_CallbackModule_v2_playbook_on_no_hosts_remaining():
    test_host = Mock()
    test_host.get_name.return_value = 'test_host'
    test_task = Mock()
    test_task.action = 'test_action'
    test_task.loop = None
    test_task._uuid = 'test_uuid'
    test_task.get_name.return_value = 'test_task'
    test_task._parent = Mock()
    test_task._parent.get_name.return_value = 'include'
    test_task._host = test_host
    test_result = Mock()
    test_result.is_changed.return_value = False
    test_result._task = test_task
    test_result._result = {'changed': False}
    test_result._host = test_host

# Generated at 2022-06-23 09:26:15.026082
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    '''Unit test for method v2_runner_on_async_ok of class CallbackModule
    '''
    mock_obj = MagicMock()
    mock_obj.v2_on_file_diff = Mock()
    mock_obj.v2_runner_item_on_ok = Mock()
    mock_obj.v2_runner_item_on_failed = Mock()
    mock_obj.v2_runner_item_on_skipped = Mock()
    mock_obj.v2_playbook_on_start = Mock()
    mock_obj.v2_playbook_on_notify = Mock()
    mock_obj.v2_playbook_on_no_hosts_matched = Mock()
    mock_obj.v2_playbook_on_no_hosts_remaining = Mock()
    mock

# Generated at 2022-06-23 09:26:15.675437
# Unit test for method v2_playbook_on_cleanup_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_cleanup_task_start():
    pass

# Generated at 2022-06-23 09:26:16.968282
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    pass
# Test for method template of class CallbackModule

# Generated at 2022-06-23 09:26:22.459794
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    # create an instance of the CallbackModule class to test
    cb = CallbackModule()
    # mock host and task to test method with
    task = mock.Mock()
    host = mock.Mock()
    # execute method
    cb.v2_runner_on_start(host, task)

# Generated at 2022-06-23 09:26:34.945935
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    # Some typical arguments that might be passed to this module
    args = {}
    args['retry_files_enabled'] = True
    args['show_custom_stats'] = True
    args['always_show_masked_values'] = True
    args['display_skipped_hosts'] = True
    args['display_ok_hosts'] = True
    args['check_mode_markers'] = True
    args['display_failed_stderr'] = True
    args['callback_whitelist'] = None
    args['show_per_host_start'] = True
    class DummyActionBase:
        def __init__(self, vars):
            self.action = 'dummy action'
            self.vars = vars

# Generated at 2022-06-23 09:26:35.488608
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    pass

# Generated at 2022-06-23 09:26:42.730001
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    module = CallbackModule()
    host = Host(name='test_host')
    task = Task()
    task.action = 'fakeAction'
    result = Result(host=host, task=task, task_result='Succeeded')
    result._result = {'fakeField': 'fakeValue'}
    module.v2_runner_item_on_ok(result)
    assert module._last_task_name == 'fakeAction'
    assert module._last_task_banner is None
    assert module._task_type_cache == {result._task._uuid: result._task._role_name}


# Generated at 2022-06-23 09:26:49.480813
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    test_task = FakeTask()
    test_host = FakeHost()
    test_result = FakeResult()
    test_item = FakeItem()
    fake_display =  FakeDisplay()
    fake_plugin = CallbackModule(display=fake_display)
    fake_plugin.v2_playbook_on_task_start(test_task, test_host)

# Generated at 2022-06-23 09:27:01.105522
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    #Setup
    class Result:
        pass
    class AnsibleTask:
        def __init__(self):
            self.action = '''shell'''
    class AnsibleHost:
        def __init__(self):
            self.name = '''ok'''
    class AnsibleTaskResult:
        def __init__(self):
            self.action = '''shell'''

# Generated at 2022-06-23 09:27:08.217766
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    runner_item_on_failed_obj = CallbackModule()
    runner_item_on_failed_obj.v2_runner_item_on_failed(result)

# Generated at 2022-06-23 09:27:10.087613
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    C = CallbackModule()
    C.v2_playbook_on_start(playbook())



# Generated at 2022-06-23 09:27:12.654706
# Unit test for method v2_playbook_on_cleanup_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_cleanup_task_start():
  return True

# Generated at 2022-06-23 09:27:20.795614
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    cb = CallbackModule()
    cb.set_options({'verbosity': 3, 'show_custom_stats': False, 'show_per_host_start': False, 'display_ok_hosts': True, 'display_skipped_hosts': True, 'display_failed_stderr': True, 'check_mode_markers': True})
    
    cb.v2_playbook_on_play_start({"name": "test"})
    

# Generated at 2022-06-23 09:27:24.282121
# Unit test for method v2_playbook_on_handler_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_handler_task_start():
    callback = CallbackModule()
    task = Task()
    callback.v2_playbook_on_handler_task_start(task)
    assert callback._task_type_cache[task._uuid] == 'RUNNING HANDLER'

# Generated at 2022-06-23 09:27:32.374556
# Unit test for method v2_playbook_on_cleanup_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_cleanup_task_start():
    cb = CallbackModule({}, display=DummyDisplay())
    cb.v2_playbook_on_cleanup_task_start({"name": "test_name", "uuid": "test_uuid"})
    assert cb._last_task_name == "test_name"
    assert cb._last_task_banner == "test_uuid"
    assert cb._task_type_cache["test_uuid"] == "CLEANUP TASK"


# Generated at 2022-06-23 09:27:38.297496
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook._SHARED_LOADER = False
    playbook.set_loader(DictDataLoader({}))
    display = Display()
    callback = CallbackModule(display)

# Generated at 2022-06-23 09:27:44.262905
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    """
    Test: v2_playbook_on_play_start function of CallbackModule class
    """
    callback = CallbackModule()
    play = Play()
    callback.v2_playbook_on_play_start(play)
    assert callback._play == play
    assert callback._last_task_name == None
    assert callback._last_task_banner == None


# Generated at 2022-06-23 09:27:47.683367
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    """Test that set options updates the instance variables correctly"""
    # setup
    obj = CallbackModule()
    # Exercise
    obj.set_options({'show_custom_stats': True})
    # Verify
    assert obj.show_custom_stats == True
    # Cleanup - none necessary



# Generated at 2022-06-23 09:27:57.269710
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
  from ansible.executor.task_result import TaskResult
  from ansible.plugins.callback import CallbackBase
  from ansible.playbook.task_include import TaskInclude
  from ansible.playbook.play import Play
  from ansible.playbook.block import Block
  from ansible.playbook.role import Role
  from ansible.playbook.task import Task
  from ansible.template import Templar
  from ansible.vars.manager import VariableManager
  variable_manager = VariableManager()

# Generated at 2022-06-23 09:28:08.550537
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    '''unit test for method v2_playbook_on_notify'''
    from ansible.utils.color import stringc
    from ansible.plugins.callback import CallbackBase
    from ansible.parsing.yaml.objects import AnsibleUnicode
    
    cb = CallbackModule()
    
    # TODO: test for all cases
    # 1) cb.display.verbosity > 1
    # 2) cb.display.verbosity <= 1
    cb.display = CallbackBase()
    cb.display.verbosity = 2
    handler = AnsibleUnicode('handler')
    host = AnsibleUnicode('host')

# Generated at 2022-06-23 09:28:12.249695
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    # Execute method with sample data
    cb = CallbackModule()
    play = Dummy()
    cb.v2_playbook_on_play_start(play)
    # Assertions
    assert cb._play == play


# Generated at 2022-06-23 09:28:23.487610
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    my_playbook_name = 'my_playbook'
    my_playbook_contents_for_test = """---
- name: test
  hosts: localhost
  tasks:
    - name: test
      debug:
        msg: 'this is a test message'
"""
    # Initialize a callback
    callback = CallbackModule()
    # Initialize a playbook
    my_playbook = Playbook.load(my_playbook_name,my_playbook_contents_for_test,variable_manager=None,loader=None)
    # Call the method to test
    callback.v2_playbook_on_start(my_playbook)
    assert not my_playbook.check_mode

# Generated at 2022-06-23 09:28:32.904584
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
	result = {'ansible_job_id': '793976.12', 'started': 0.0, 'finished': 1.0}
	host = {'name': '127.0.0.1'}

	c = CallbackModule()
	c._display = CallbackModule.Display()
	c._display.display = Mock()

	c.v2_runner_on_async_failed(host, result)

	c._display.display.assert_called_with('ASYNC FAILED on 127.0.0.1: jid=793976.12', color=None)


# Generated at 2022-06-23 09:28:40.142067
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    # Instantiate the class
    import pprint
    cl = CallbackModule()
    # Get the argspec for the function
    args = inspect.getargspec(cl.v2_runner_item_on_failed)
    # Remove self from the list because we already have it
    args[0].remove('self')
    # Set the result to a known value
    result = 'hello, world'
    kwargs = {
    }
    # Get the return value
    got = cl.v2_runner_item_on_failed(result, **kwargs)
    # Ensure that we got what we expected
    assert(got.strip() == 'failed: [localhost] (item=None) => hello, world'.strip())
    # Do it again with other args
    # Get the argspec for the function
    args = inspect.getargspec

# Generated at 2022-06-23 09:28:41.694151
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    pytest.skip('Not implemented')

# Generated at 2022-06-23 09:28:51.090082
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    # Setting up mock ansible objects
    result = Result({'invocation': {'module_args': {'name': 'localhost'}}, 'async_result': {'ansible_job_id': 'N/A'}}, None)
    result._result = {'ansible_job_id': 'N/A'}
    result._result['invocation'] = {'module_args': {'name': 'localhost'}}
    result._host = Host(compile_hostpattern('localhost'))
    result.task_name = 'shell'
    # Setup the callback module
    callback = CallbackModule()
    # Execute the callback module method
    callback.v2_runner_on_async_ok(result)

# Generated at 2022-06-23 09:28:58.750631
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    c = CallbackModule()
    c.display_ok_hosts = True
    c.display_skipped_hosts = True
    result = Mock()
    result._host = Mock(get_name="HostName")
    result._result = {'msg':"message"
                      , 'changed':True
                      }
    result._task = Mock(action="action")
    c.v2_runner_on_skipped(result)
    #



# Generated at 2022-06-23 09:28:59.452831
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    assert True

# Generated at 2022-06-23 09:29:11.865619
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():

    # Create a new instance of our plugin class and prepare it for testing
    callback = CallbackModule()
    callback.set_options()
    callback._load_name_cache()
    callback._display = Display()

    # Prepare mock object for result._host.get_name()
    result_host_get_name_mock = mocker.patch('ansible.plugins.callback.CallbackModule._host.get_name')
    result_host_get_name_mock.return_value = 32

    # Prepare mock object for result._result.get('ansible_job_id')
    result_result_get_mock = mocker.patch('ansible.plugins.callback.CallbackModule._result.get')
    result_result_get_mock.return_value = 0

    # Prepare for an unexpected call to result._result.get('started')

# Generated at 2022-06-23 09:29:24.755284
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # See: https://docs.ansible.com/ansible/2.7/playbooks_debugger.html
    options = {}
    options['verbosity'] = 2
    options['show_custom_stats'] = True
    options['display_skipped_hosts'] = False
    options['display_ok_hosts'] = False
    options['display_failed_stderr'] = True
    options['show_per_host_start'] = True
    options['check_mode_markers'] = False
    # The following options are not tested here
    options['callback_whitelist'] = []
    options['display_skipped_hosts'] = True
    options['display_ok_hosts'] = True
    options['display_failed_stderr'] = True
    options['show_per_host_start'] = True


# Generated at 2022-06-23 09:29:27.277843
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    instance = CallbackModule()
    handler = None
    host = None
    

# Generated at 2022-06-23 09:29:37.686699
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    '''
    Unit test for method v2_playbook_on_include
    of class ansible.plugins.callback.CallbackModule
    '''
    # From local variable _test_examples in test/units/callback_plugins/test_default.py
    my_included_file = IncludedFile()
    my_included_file._hosts = [Host()]
    my_included_file._hosts[0].name = u'localhost'
    my_included_file._filename = u'/tmp/test.yml'
    my_included_file._vars = {u'key1': u'value1'}
    callback.v2_playbook_on_include(included_file=my_included_file)


# Generated at 2022-06-23 09:29:50.034500
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():

    # Setup data for test
    def mock_get_task_uuid(obj):
        return 'mocked_uuid'

    def mock_get_item_label(obj, results):
        return 'mocked_item_label'

    def mock_get_diff(obj, results):
        return 'mocked_diff'

    def mock_run_is_verbose(obj, result):
        return 'mocked_run_is_verbose'

    def mock_display_failed_stderr(obj):
        return 'mocked_display_failed_stderr'

    def mock_handle_warnings(obj, result):
        return 'mocked_handle_warnings'

    def mock_dump_results(obj, results):
        return 'mocked_dump_results'


# Generated at 2022-06-23 09:29:58.421198
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    """This method unit tests CallbackModule class constructor 
    """
    temp_stdout = sys.stdout
    sys.stdout = open(os.devnull, "w")

    temp_stderr = sys.stderr
    sys.stderr = open(os.devnull, "w")

    if os.path.exists("/tmp/ansible.log"):
        os.remove("/tmp/ansible.log")

    # Test for the constructor of the CallbackModule
    callbackmodule = CallbackModule(display_ok_hosts = True, display_skipped_hosts = True, display_failed_stderr = True)
    # Test for the constructor with error
    callbackmodule = CallbackModule()

    sys.stdout = temp_stdout
    sys.stderr = temp_stderr

# Generated at 2022-06-23 09:30:10.907669
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    inst = CallbackModule()
    assert hasattr(inst, 'v2_runner_on_async_failed')
    assert isinstance(inst.v2_runner_on_async_failed, types.MethodType)
    assert hasattr(inst, 'v2_runner_on_async_ok')
    assert isinstance(inst.v2_runner_on_async_ok, types.MethodType)
    assert hasattr(inst, 'v2_runner_on_async_poll')
    assert isinstance(inst.v2_runner_on_async_poll, types.MethodType)
    assert hasattr(inst, 'v2_runner_retry')
    assert isinstance(inst.v2_runner_retry, types.MethodType)

# Generated at 2022-06-23 09:30:18.090403
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    filepath = os.path.realpath(__file__)
    test_file = os.path.join(os.path.dirname(filepath),
                             "data",
                             "playbook_on_include.yml")
    ansible_playbook = ansible.cli.CLI(['ansible-playbook',
                                        '--tags', 'test_include',
                                        '--check', '-i', test_file],
                                        sys.stdin)
    ansible_playbook.parse()
    ansible_playbook.run()


# Generated at 2022-06-23 09:30:23.045931
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    test_class = CallbackModule()
    # For coverage.  play_success is not a thing
    stats = namedtuple('Stats', 'play_success')
    test_class.v2_playbook_on_stats(stats)
    assert True


# Generated at 2022-06-23 09:30:32.275081
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    from ansible import constants as C
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.module_utils._text import to_text

    host = Host(name="test")
    group = Group(name="test")
    group.add_host(host)
    play_source =  dict(
        name = "Ansible Play 1",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )
    play

# Generated at 2022-06-23 09:30:37.384288
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    results = dict(
        _task="TaskName",
        _host="HostName",
        _result=dict(failed=False, skipped=True, changed=False)
    )
    CallbackModule.v2_runner_on_skipped(results)


# Generated at 2022-06-23 09:30:38.352864
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    assert False # TODO: implement your test here


# Generated at 2022-06-23 09:30:49.755197
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    cbm = CallbackModule()
    params = {}
    cbm.set_options(params)
    assert isinstance(cbm.display_ok_hosts, bool)
    assert isinstance(cbm.display_failed_stderr, bool)
    assert isinstance(cbm.show_custom_stats, bool)
    assert isinstance(cbm.display_skipped_hosts, bool)
    assert isinstance(cbm.display_task_custom, bool)
    assert isinstance(cbm.display_invocation, bool)
    assert isinstance(cbm.check_mode_markers, bool)
    assert isinstance(cbm.no_log, bool)

# Generated at 2022-06-23 09:30:55.334116
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    # Set up object
    callback = CallbackModule()
    host = Host('server')
    result = {'ansible_job_id': 'job-id'}
    result = Result(host, result)
    # Invoke method
    callback.v2_runner_on_async_ok(result)

# Generated at 2022-06-23 09:30:58.620537
# Unit test for method v2_playbook_on_no_hosts_remaining of class CallbackModule
def test_CallbackModule_v2_playbook_on_no_hosts_remaining():
    # TODO: add test
    assert False


# Generated at 2022-06-23 09:31:00.732763
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    '''
    Instantiate the CallbackModule class
    '''

    callback = CallbackModule()
    assert callback

# Generated at 2022-06-23 09:31:15.528574
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    # Create an instance of CallbackModule class
    cb_obj = CallbackModule()
    # Create a dummy result object
    result = ResultTask(host=Host(name='test_host'))
    # Create a dummy task object
    task = Task()
    # Set 'display_skipped_hosts' to True
    cb_obj.display_skipped_hosts = True
    # Set 'display_ok_hosts' to True
    cb_obj.display_ok_hosts = True
    # Set '_last_task_banner'
    cb_obj._last_task_banner = result._task._uuid
    # Set '_task_type_cache'
    cb_obj._task_type_cache = {}
    # Set '_last_task_name'
    cb_obj._

# Generated at 2022-06-23 09:31:22.292364
# Unit test for method v2_playbook_on_stats of class CallbackModule

# Generated at 2022-06-23 09:31:32.384268
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    # Parses result from Ansible run
    fake_result = {
        "ansible_job_id": "jid",
        "async_result": {
            "ansible_job_id": "jid",
            "started": "2017-12-14T18:57:20.924657Z",
            "finished": "2017-12-14T19:02:20.924657Z",
            "results_file": "/home/vagrant/.ansible_async/3708905276.2574"
        }
    }

    # Mock class for the Host result object
    class HostResultMock:
        def __init__(self, host_name):
            self._host = {'name': host_name}

        def get_name(self):
            return self._host['name']

    # Mock

# Generated at 2022-06-23 09:31:35.830231
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():

    import mock
    from ansible.plugins.callback import CallbackModule

    mc = mock.patch('ansible.plugins.callback.CallbackModule')

    c = CallbackModule()
    c.v2_runner_on_async_failed(result)

    assert mc is not None



# Generated at 2022-06-23 09:31:40.264830
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    cb = CallbackModule()
    result = mock.Mock()
    result._host.get_name.return_value = 'host'
    result._result = { 'ansible_job_id': 'jid', 'started': 'started', 'finished': 'finished' }
    cb.v2_runner_on_async_poll(result)

# test_CallbackModule_v2_runner_on_async_poll()


# Generated at 2022-06-23 09:31:46.269091
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback_module_new = callback_plugins.CallbackModule()
    new_args = dict()
    new_args['check'] = True
    new_args['verbosity'] = 3
    new_args['timeout'] = '5'
    new_args['tree'] = '.'
    new_args['listhosts'] = 'all'
    new_args['syntax'] = True
    new_args['diff'] = 'True'
    new_args['show_custom_stats'] = 'True'
    new_args['check_mode_markers'] = 'False'
    new_args['show_per_host_start'] = 'False'
    new_args['display_skipped_hosts'] = 'True'
    new_args['display_ok_hosts'] = 'False'

# Generated at 2022-06-23 09:31:49.668857
# Unit test for method v2_playbook_on_no_hosts_matched of class CallbackModule
def test_CallbackModule_v2_playbook_on_no_hosts_matched():
    cb = CallbackModule()
    task = AnsibleTask()
    assert cb.v2_playbook_on_no_hosts_matched(task) == None

# Generated at 2022-06-23 09:32:01.500648
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    runner_on_ok_object = ansible.plugins.callback.CallbackModule()
    host_label_object = ansible.plugins.callback.CallbackModule()
    host_label_object.host_label()
    runner_on_ok_object._clean_results()
    runner_on_ok_object._dump_results()
    runner_on_ok_object._handle_warnings()
    runner_on_ok_object._last_task_banner
    runner_on_ok_object._last_task_name
    runner_on_ok_object._run_is_verbose()
    runner_on_ok_object._task_type_cache
    runner_on_ok_object._display
    runner_on_ok_object._play
    runner_on_ok_object.banner()
    runner_on_ok_object

# Generated at 2022-06-23 09:32:05.579570
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    """
    Test method v2_playbook_on_notify of class CallbackModule
    """
    # Initialize object
    ansible_callback = initialize_ansible_callback()

    # Create a handler object
    handler = Mock()

    # Get host name
    host = socket.gethostname()

    # Test method with parameter
    ansible_callback.v2_playbook_on_notify(handler, host)



# Generated at 2022-06-23 09:32:11.919967
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    stats = Stats()
    stats.processed = {"host": {'ok': 1, 'changed': 1, 'unreachable': 1, 'failures': 1, 'skipped': 1, 'rescued': 1, 'ignored': 1}}
    playbook = PlaybookExecutor(playbooks=[], inventory=None, variable_manager=None, loader=None, options=None, passwords=None)
    callback_module = CallbackModule()
    callback_module.show_custom_stats = False
    callback_module.v2_playbook_on_stats(stats)
    return None


# Generated at 2022-06-23 09:32:20.680936
# Unit test for method v2_playbook_on_no_hosts_remaining of class CallbackModule
def test_CallbackModule_v2_playbook_on_no_hosts_remaining():
  playbook_result = PlaybookResult( 'test', [ ], [ ], [ ], [ ], [ ], None )
  callback = CallbackModule( [ ] )
  callback.v2_playbook_on_no_hosts_remaining( playbook_result )
  assert callback.playbook_result == playbook_result, 'Expected attribute playbook_result to be %s, but is %s' % ( str(playbook_result), str(callback.playbook_result) )
  assert callback.playbook_on_no_hosts_remaining == True, 'Expected attribute playbook_on_no_hosts_remaining to be %s, but is %s' % ( str(True), str(callback.playbook_on_no_hosts_remaining) )

# Generated at 2022-06-23 09:32:26.328006
# Unit test for method v2_playbook_on_no_hosts_matched of class CallbackModule
def test_CallbackModule_v2_playbook_on_no_hosts_matched():
    # Test with an arbitrary parameter
    cb = CallbackModule()
    cb.v2_playbook_on_no_hosts_matched(hosts)
    # Test with an arbitrary parameter
    cb = CallbackModule()
    cb.v2_playbook_on_no_hosts_matched(task)
    # Test with an arbitrary parameter
    cb = CallbackModule()
    cb.v2_playbook_on_no_hosts_matched(playbook)


# Generated at 2022-06-23 09:32:36.553192
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    class MockOptions(object):
        display_changed_only = False

    class MockTask(object):
        def __init__(self, no_log=False, action='action'):
            self.no_log = no_log
            self.action = action

    class MockResult(object):
        def __init__(self, host, task, changed=False, diff=None, ignored=None, warnings=None, result=None):
            self._host = host
            self._task = task
            self._result = {'changed': changed, 'diff': diff, 'ignored': ignored, 'warnings': warnings, 'results': result}  # pylint: disable=redefined-builtin

    class MockHost(object):
        def __init__(self, name):
            self.name = name


# Generated at 2022-06-23 09:32:42.372418
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
  # Instantiation of a class from ansible.plugins.callback.human_log
  human_log = ansible.plugins.callback.human_log.CallbackModule()

  # Instantiation of a class from ansible.playbook.play
  play_obj = ansible.playbook.play.Play()

  # Calling a method of a object
  human_log.v2_playbook_on_start(playbook=play_obj)



# Generated at 2022-06-23 09:32:43.706786
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    v2_runner_retry(False)


# Generated at 2022-06-23 09:32:50.592445
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackModule
    from ansible.inventory.manager import InventoryManager

    # create a mock for each of the required objects
    stdout_write = Mock(spec_set=sys.stdout.write)
    playbook = Mock(spec=Play)
    task = Mock(spec=Task)
    task_queue_manager = Mock(spec=TaskQueueManager)
    inventory = Mock(spec=InventoryManager)
    callback = CallbackModule()
    callback.set_options(direct={'verbosity': True})
    callback.set_options(stdout_callback=stdout_write)

    # need to mock stdout_write.

# Generated at 2022-06-23 09:32:51.412765
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    pass

# Generated at 2022-06-23 09:32:55.297554
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    handler = Handler()
    host = Host('localhost')
    callback = CallbackModule()
    callback.v2_playbook_on_notify(handler, host)


# Generated at 2022-06-23 09:32:58.089123
# Unit test for method v2_playbook_on_cleanup_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_cleanup_task_start():
    #pass
    # test for different object type
    # test for same object
    # test for boolean return
    pass


# Generated at 2022-06-23 09:33:02.102027
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    # Test with no parameters
    # but these values where provided
    result_result = {}
    assert CallbackModule().v2_runner_on_async_failed({'_host': {'get_name': lambda:'host'}, '_result': result_result}) == None



# Generated at 2022-06-23 09:33:14.729828
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    # Creating an instance of the CallbackModule class
    callbackmodule_instance = CallbackModule()
    # Creating a mock for 'playbook'
    playbook = mock.Mock()
    # Defining a test for the v2_playbook_on_play_start method
    def test(self, playbook, msg='PLAY', checkmsg=''):
        # Creating an instance of the mock class
        result = mock.Mock()
        # Setting the mock object attribute 'get_name' to the callable mock object
        result.get_name = mock.Mock(return_value='PLAY')
        # Setting the mock object attribute 'check_mode' to the callable mock object
        result.check_mode = mock.Mock(return_value=False)
        # Calling the v2_playbook_on_play_start method on the created instance
       

# Generated at 2022-06-23 09:33:15.892582
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    pass
# end def



# Generated at 2022-06-23 09:33:17.808735
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    CallbackModule.v2_runner_on_async_failed(None,None)


# Generated at 2022-06-23 09:33:23.273222
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    body = caller()
    body.v2_runner_on_async_ok(TestCall(TestPlaybookRunner()))
    assert body._display.display.called
    # Test for alternate form of display
    body._display.display.called = False
    body._display.display.call_count = 0
    body.v2_runner_on_async_ok(TestCall(TestPlaybookRunner(), verbosity=1))
    assert not body._display.display.called


# Generated at 2022-06-23 09:33:23.849235
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
  pass

# Generated at 2022-06-23 09:33:35.767977
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    Filename = 'test_CallbackModule_v2_playbook_on_include.yml'
    playbook_file = open(Filename, 'w')
    playbook_file.close()

# Generated at 2022-06-23 09:33:37.205116
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    # TODO:
    pass


# Generated at 2022-06-23 09:33:50.485123
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    host = mock()
    task = mock()
    obj = CallbackModule()
    obj.display_skipped_hosts = True
    obj.display_ok_hosts = True
    obj.show_custom_stats = True
    obj.show_per_host_start = True
    obj.show_check_mode_results = True
    obj.show_check_mode_summary = True
    obj.check_mode_markers = True
    obj.display_failed_stderr = True
    obj.show_verbose_check_mode_summary = True
    obj.display_fatal_deprecation_warnings = True
    obj.show_nested_check_mode_summary = True
    obj.add_tasks = True
    obj.v2_runner_on_start(host, task)
    assert obj