

# Generated at 2022-06-23 09:23:48.936834
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    cb = CallbackModule()
    cb.set_options(task_output_live=False, display_skipped_hosts=True)
    assert cb.task_output_live == False
    assert cb.display_skipped_hosts == True


# Generated at 2022-06-23 09:23:59.295095
# Unit test for method v2_playbook_on_no_hosts_remaining of class CallbackModule

# Generated at 2022-06-23 09:24:03.672135
# Unit test for method v2_playbook_on_cleanup_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_cleanup_task_start():
    # Set up mock objects
    mock_task = Task()
    mock_task._uuid = ('dummy', 'task')

    callback = CallbackModule()
    callback._task_type_cache = {}
    callback._task_type_cache[('dummy', 'task')] = 'CLEANUP TASK'
    callback._last_task_banner = ('dummy', 'task')

    callback.v2_playbook_on_cleanup_task_start(mock_task)

# Generated at 2022-06-23 09:24:08.360565
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():

    display_messages = []
    class _Display(object):
        def __init__(self):
            self.verbosity = 2

        def display(self, msg, log_only=False, color=None, screen_only=False):
            display_messages.append(msg)

        def banner(self, msg):
            pass

    stats = dict(
        ok=dict(
            foo=1,
            bar=2
        )
    )
    callback_plugin = CallbackModule()
    callback_plugin._display = _Display()
    callback_plugin.show_custom_stats = True
    callback_plugin.v2_playbook_on_stats(stats)
    assert 'PLAY RECAP' in display_messages[0]


# Generated at 2022-06-23 09:24:19.741616
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    """
    Test callback set_options. This should set the values of options listed
    in the `C.ANSIBLE_CALLBACK_WHITELIST` to their defaults.
    """
    # Setup a CallbackModule
    callback = CallbackModule()

    # Setup options as a mock object. These should be set to defaults.
    options = {
        'display_ok_hosts': False,
        'display_skipped_hosts': False,
        'display_failed_stderr': True,
        'show_custom_stats': False,
        'check_mode_markers': False,
        'verbosity': 0,
        'extra_verbosity': 0,
        'display_changed_only': False
    }

    # Set the options for the callback
    callback.set_options(options)

    assert callback.display

# Generated at 2022-06-23 09:24:22.262181
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
  callback_module1 = CallbackModule()
  callback_module1.v2_runner_retry()

# Generated at 2022-06-23 09:24:33.080163
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    play = Play()
    play.extra_vars = {}
    play.inventory = Inventory(loader=DictDataLoader({'plugin': 'yaml', '_loader_cache': {}, '_options': {'host_list': '/Users/agarwal/PycharmProjects/ifconfigme/ifconfigme/ansible/hosts'}}))


# Generated at 2022-06-23 09:24:41.785408
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    class StubResult(object):
        def __init__(self):
            self._result = {}
        @property
        def is_changed(self):
            return True
    result = StubResult()
    result._result = {'exception': Exception('test exception')}
    result._result['exception'] = Exception('test exception')

    class StubTask(object):
        def __init__(self):
            self._uuid = 'task_uuid'
            self.action = 'test_action'
    result._task = StubTask()

    plugin = CallbackModule()
    plugin.display_failed_stderr = True
    plugin.v2_runner_on_failed(result)
    assert result._result['exception'] is not None


# Generated at 2022-06-23 09:24:44.921612
# Unit test for method v2_playbook_on_no_hosts_remaining of class CallbackModule
def test_CallbackModule_v2_playbook_on_no_hosts_remaining():
    my_obj = CallbackModule()
    testargs = {}
    testargs['play'] = {}
    testargs['play']['hosts'] = {}
    my_obj.v2_playbook_on_no_hosts_remaining(**testargs)
    assert my_obj._display.banner.call_count == 1


# Generated at 2022-06-23 09:24:48.984564
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    """
    unit test for method: CallbackModule._v2_runner_on_async_failed
    """
    module = CallbackModule()
    mock_result = Mock()
    module.v2_runner_on_async_failed(mock_result)
    assert module.v2_runner_on_async_failed(mock_result) == None


# Generated at 2022-06-23 09:24:56.362096
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    sample = [
                {'diff': '1c1' , 'changed': True},
                {'diff': '2c2' , 'changed': True},
                {'diff': '3c3' , 'changed': True},
                {'diff': '4c4' , 'changed': True},
            ]
    sample2 = [
                {'diff': '1c1' , 'changed': True},
                {'diff': '2c2' , 'changed': True},
                {'diff': '3c3' , 'changed': True},
                {'diff': '4c4' , 'changed': True},
            ]

# Generated at 2022-06-23 09:25:05.096717
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    cb = CallbackModule()
    result = Mock()
    result._task = Mock()
    result._result = {'diff': 'foo'}
    cb.v2_on_file_diff(result)
    cb.v2_playbook_on_play_start(None)

    result._result = {'changed': False}
    cb.v2_on_file_diff(result)

    result._result = {'changed': True}
    cb.v2_on_file_diff(result)
    cb.v2_on_file_diff(result)

    result._result = {'changed': False}
    result._task.loop = True
    result._result['results'] = [{'changed': False}]
    cb.v2_on_file_diff(result)

   

# Generated at 2022-06-23 09:25:14.162754
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    runner = MagicMock()
    runner.host = "TestHost"
    runner.result = dict()
    result = dict()
    result['async_result'] = dict()
    runner.result = result
    runner.result['async_result']['ansible_job_id'] = "test1234"
    
    runner2 = MagicMock()
    runner2.host = "TestHost"
    runner2.result = dict()
    runner2.result['ansible_job_id'] = "test1234"
    
    runner3 = MagicMock()
    runner3.host = "TestHost"
    runner3.result = dict()
    runner3.result['ansible_job_id'] = "test1234"
    runner3.result['async_result'] = dict()
    runner3.result

# Generated at 2022-06-23 09:25:24.721699
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Test with two examples:
    # 1. result._task.loop is True, but result._result doesn't contain a 'diff' key
    # 2. result._task.loop is False, which is a typical case
    #    result._result contains a 'diff' key
    #    res['changed'] is False
    #    res['diff'] is empty
    args = {'action': 'set_facts', '_ansible_verbose_always': True}
    result = DummyResult(args, 'hostname1', '127.0.0.1', True)


# Generated at 2022-06-23 09:25:26.393158
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    # pylint: disable=R0204
    assert True



# Generated at 2022-06-23 09:25:34.097596
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    cb = CallbackModule()
    handler = Host()
    host = Host()
    cb.v2_playbook_on_notify(handler, host)

if __name__ == '__main__':
    import sys
    import doctest

    print(get_excerpt(__doc__, globals()))

    # Run all doctests in this module
    doctest.testmod()

    # Run all unit tests in this module
    unittest.main()

    # Run a single unit test
    # cb = CallbackModule()
    # test_CallbackModule_v2_playbook_on_notify(cb)
    sys.exit()

# Generated at 2022-06-23 09:25:35.712258
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    callback = CallbackModule()
    assert callback


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 09:25:41.052535
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    # There are no arguments for this method
    # Create the object
    c = CallbackModule()
    # The first argument is result 
    result = object()
    # Now call the method
    c.v2_runner_on_async_ok(result)

# Generated at 2022-06-23 09:25:45.173079
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # set up test
    stdout = StringIO()
    event_queue = Queue()
    results = dict(failed=False, changed=False, skipped=False)
    result = dict(ansible_play_hosts=dict(host=dict(name="host")))
    callback = CallbackModule(display=Display(verbosity=0), event_queue=event_queue)
    # perform test
    callback.v2_runner_on_ok(result=result)
    # verify results
    assert not results['failed']
    assert not results['changed']
    assert not results['skipped']
    return


# Generated at 2022-06-23 09:25:48.907899
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    callback = CallbackModule()
    result = FakeResult()
    callback.v2_runner_on_unreachable(result)
    assert callback.get_option('show_custom_stats') is True


# Generated at 2022-06-23 09:25:54.413450
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    task = Mock()
    stats = Mock()
    host = Mock()
    t = Mock()
    stats.processed.keys.return_value = [host]
    stats.summarize.return_value = t
    callback = CallbackModule()
    callback.v2_playbook_on_stats(stats)
    task.assert_called_once_with(host, t)

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-23 09:25:56.390370
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    from ansible.plugins.callback import CallbackModule
    cm = CallbackModule()
    cm.v2_runner_on_unreachable(1)

# Generated at 2022-06-23 09:25:59.299048
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    c = CallbackModule()
    c.set_options()

# Generated at 2022-06-23 09:26:07.056831
# Unit test for method v2_playbook_on_handler_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_handler_task_start():
    """Test v2_playbook_on_handler_task_start of callback_default"""
    # expected argument types
    task = MagicMock(spec=Task)
    # v2_playbook_on_handler_task_start
    callback_default_obj = CallbackModule()
    callback_default_obj._task_start(task, prefix='RUNNING HANDLER')
    # tests
    task.get_name.assert_called_with()
    callback_default_obj._display.banner.assert_called_with("RUNNING HANDLER [%s]" % task.get_name.return_value)



# Generated at 2022-06-23 09:26:14.876975
# Unit test for method v2_playbook_on_handler_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_handler_task_start(): 
    """ 
    Test method v2_playbook_on_handler_task_start of class CallbackModule 
    """ 
 
    ################################################################################
    # Call the method under test
    ################################################################################
     
    print("TEST: v2_playbook_on_handler_task_start of class CallbackModule")
    cbM = CallbackModule()
    cbM.v2_playbook_on_handler_task_start(None)
 
    
    


# Generated at 2022-06-23 09:26:22.829261
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    from ansible import context
    from ansible.utils.display import Display
    from ansible.plugins.callback import CallbackBase

    context.CLIARGS = {}
    displayer = Display()

    class CallbackModule(CallbackBase):
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'TEST'

        def v2_runner_item_on_ok(self, result):
            host_label = self.host_label(result)
            if isinstance(result._task, TaskInclude):
                return
            elif result._result.get('changed', False):
                if self._last_task_banner != result._task._uuid:
                    self._print_task_banner(result._task)

                msg = 'changed'

# Generated at 2022-06-23 09:26:32.267496
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    result = dict()
    result['_host'] = dict()
    result['_host']['get_name'] = lambda : 'localhost'
    result['_result'] = dict()
    result['_result']['ansible_job_id'] = u'123456'
    result['_result']['started'] = datetime.now()
    result['_result']['finished'] = datetime.now()
    callback = CallbackModule()
    callback.v2_runner_on_async_poll(result)


# Generated at 2022-06-23 09:26:35.729605
# Unit test for method v2_playbook_on_no_hosts_matched of class CallbackModule
def test_CallbackModule_v2_playbook_on_no_hosts_matched():
    
    
    from ansible.plugins.callback import CallbackBase

    ansible_instance = ansible.plugins.callback.CallbackBase()

    ansible_instance.v2_playbook_on_no_hosts_matched()

# Generated at 2022-06-23 09:26:44.119598
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    import ansible.playbook.play_context
    import ansible.context
    import ansible.vars.hostvars
    
    context.CLIARGS = ImmutableDict(connection='smart', module_path=None, forks=10, become=None,
                                           become_method=None, become_user=None, check=False, diff=False, syntax=None,
                                           start_at_task=None)
    ansible.context.CLIARGS = ImmutableDict(connection='smart', module_path=None, forks=10, become=None,
                                           become_method=None, become_user=None, check=False, diff=False, syntax=None,
                                           start_at_task=None)
    ansible.context.DEFAULT_LOCAL_TMP = '/tmp'


# Generated at 2022-06-23 09:26:54.710468
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    ######################################################################
    # This test method uses the real logic for the method
    # v2_playbook_on_play_start of class CallbackModule
    ######################################################################
    from ansible.plugins.callback.default import CallbackModule
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    class my_play(Play):
        def __init__(self):
            super(my_play, self).__init__()
            self._entities = []
            self.vars = {}
        def get_name(self):
            return "my_play"

    result = CallbackModule()

    # Verify that the play_start method works correctly for a play without
    # a name
    play2 = my_play()
    result.v2_playbook_on_

# Generated at 2022-06-23 09:27:10.722168
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

    # Attempt 1
    x = {'item': {'None': 'None'}, '_host': {'get_name': MagicMock(return_value='mock_host')}, '_task': {'action': 'mock_action'}, '_result': {'changed': False}}
    y = {'item': {'None': 'None'}, '_host': {'get_name': MagicMock(return_value='mock_host')}, '_task': {'action': 'mock_action'}, '_result': {'changed': True}}
    z = {'item': {}, '_host': {'get_name': MagicMock(return_value='mock_host')}, '_task': {'action': 'mock_action'}, '_result': {'changed': False}}

# Generated at 2022-06-23 09:27:17.213517
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    # Replace print() with typing
    class TestClass(object):
        def display(self, msg):
            print(msg)
    TestModule = TestClass()
    TestModule.v2_runner_on_skipped(None)

    TestModule.display_skipped_hosts = True
    TestModule.v2_runner_on_skipped(None)



# Generated at 2022-06-23 09:27:18.869241
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    c = CallbackModule()
    c.v2_runner_item_on_failed(None)


# Generated at 2022-06-23 09:27:20.429372
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    obj = CallbackModule()
    obj.set_options()



# Generated at 2022-06-23 09:27:25.181245
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    CallbackModule.set_options(options)
    assert options['display_skipped_hosts'] == True
    assert options['display_failed_stderr'] == True
    assert options['show_custom_stats'] == False
    assert options['display_ok_hosts'] == True
    assert options['show_per_host_start'] == True


# Generated at 2022-06-23 09:27:29.395239
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    c = CallbackModule()
    assert c.v2_on_file_diff(None) == None

if __name__ == '__main__':
    test_CallbackModule_v2_on_file_diff()

# Generated at 2022-06-23 09:27:30.506737
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
	pass


# Generated at 2022-06-23 09:27:40.092214
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    import ansible.plugins.callback
    G = globals()
    inst = AnsibleCallbacks(G['display'])
    print(dir(inst))
    cb = CallbackModule(G['display'])
    inst = cb
    assert inst is not None
    assert cb is not None

if __name__ == '__main__':
    import sys
    import inspect
    import ansible.utils.display
    display = ansible.utils.display.Display()
    display.screen_only = True
    debug = False
    if debug:
        for name, obj in inspect.getmembers(CallbackModule):
            if inspect.ismethod(obj):
                if name.startswith('v2_'):
                    print >>sys.stderr, 'testing %s' % name

# Generated at 2022-06-23 09:27:46.957214
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    cb = CallbackModule()
    result = Mock()
    result._host = Mock()
    result._result = dict(ansible_job_id='1')
    result._host.get_name.return_value = 'host1'
    cb.v2_runner_on_async_ok(result)
    assert cb.stdout[0][0] == 'ASYNC OK on host1: jid=1'
    assert cb.stdout[0][1] == dict(color=C.COLOR_DEBUG)

# Generated at 2022-06-23 09:27:54.962295
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    fake_self = CallbackModule()
    fake_playbook = Playbook()
    fake_playbook._file_name = "/dev/null"
    fake_playbook._playbook_basedir = "/dev/null"
    fake_display = Display()
    fake_self._display = fake_display
    fake_self.v2_playbook_on_start(fake_playbook)
    assert fake_self._last_task_banner is None
    assert fake_self._last_task_name is None
    assert fake_self._task_type_cache == {}
    assert fake_self.show_custom_stats is False
    assert fake_self.display_ok_hosts is True
    assert fake_self.display_skipped_hosts is True
    assert fake_self.display_failed_stderr is False
   

# Generated at 2022-06-23 09:27:56.834727
# Unit test for method v2_playbook_on_cleanup_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_cleanup_task_start():
    callback_module = CallbackModule()
    callback_module.v2_playbook_on_cleanup_task_start(task=dict())

# Generated at 2022-06-23 09:28:04.327900
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    for value in [False, True]:
        print('\tTesting v2_runner_on_start with value=%s' % value)
        results = CallbackModule(show_per_host_start=value).v2_runner_on_start(1, 'test')
        print('\t\tResults: %s' % results)
        assert(results in [' [started test on 1]', ''])

# Generated at 2022-06-23 09:28:14.997692
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    # Without options
    instance = CallbackModule()
    assert isinstance(instance, CallbackModule)
    assert not instance.show_custom_stats
    assert instance.display_ok_hosts
    assert instance.display_skipped_hosts
    assert instance.display_faileds_stderr
    assert instance.display_ok_hosts
    assert not instance.display_snipped_context
    assert instance.display_section_titles
    assert not instance.check_mode_markers

    # With options

# Generated at 2022-06-23 09:28:18.981651
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    pb = Playbook()
    pb.check_mode = True
    cm = CallbackModule(pb)
    assert cm.check_mode_markers == True


# Generated at 2022-06-23 09:28:27.214656
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    result = {}
    result['invocation'] = {'module_name': 'ping'}
    result['_host'] = 'testhost'
    result['_task'] = 'testtask'
    result['_result'] = {'changed': True}
    # An instance of fileobject
    stdout_mock = mock.Mock()

    # An instance of class CallbackModule
    callbackModule_mock = mock.Mock(spec=CallbackModule)
    callbackModule_mock.get_option.return_value = True
    callbackModule_mock.display.verbosity = 2
    callbackModule_mock.verbose_always = False
    callbackModule_mock._results_cache = {}
    callbackModule_mock._results_cache['testhost'] = {'testtask': result}
    callbackModule_mock._last

# Generated at 2022-06-23 09:28:29.483130
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    result = FakeResult()
    result.task_name = "task1"
    result._result = dict(attempts = 2, retries = 5)
    result._host = "host1"
    CallbackModule().v2_runner_retry(result)
    pass


# Generated at 2022-06-23 09:28:38.539412
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    cb = CallbackModule()
    r1 = Mock()
    r2 = Mock()
    results = {'a': r1, 'b': r2}
    def sum(h):
        return results[h]
    stats = Mock()
    stats.summarize = sum
    stats.processed = {'a', 'b'}
    stats.custom = None
    with patch.object(cb, '_display') as mock_display:
        cb.v2_playbook_on_stats(stats)

# Generated at 2022-06-23 09:28:44.908996
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    my_callback = CallbackModule()
    assert my_callback._last_task_banner == None
    assert my_callback.disabled == False
    assert my_callback.display_ok_hosts == False
    assert my_callback.display_skipped_hosts == False
    assert my_callback.display_failed_stderr == False
    assert my_callback.show_custom_stats == False


# Generated at 2022-06-23 09:28:49.056552
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    try:
        test_instance = CallbackModule()
        test_instance.v2_runner_on_ok()
        assert 0
    except NotImplementedError:
        assert 1

test_CallbackModule_v2_runner_on_ok()


# Generated at 2022-06-23 09:29:01.199998
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    from ansible.plugins.callback.default import CallbackModule
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_context import PlayContext
    context = PlayContext()
    host = Mock()
    result = TaskResult(host, 'some_task')
    setattr(result, '_result', dict(
        ansible_job_id='1234567',
        async_result={'ansible_job_id': '1234567'}
    ))
    setattr(result, '_task', 'some_task')
    msg = 'ASYNC FAILED on localhost: jid=1234567'
    callback = CallbackModule()
    with patch.object(CallbackModule, '_display') as mock_method:
        callback.v2_runner_on_async_failed

# Generated at 2022-06-23 09:29:01.793470
# Unit test for method v2_playbook_on_no_hosts_matched of class CallbackModule
def test_CallbackModule_v2_playbook_on_no_hosts_matched():
    pass

# Generated at 2022-06-23 09:29:13.172573
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    result = Stub()

    class obj_ShellModule(object):
        def __init__(self, *args, **kwargs):
            pass

    class obj_Base(object):
        def __init__(self, *args, **kwargs):
            pass

    class obj_Host(object):
        def __init__(self, *args, **kwargs):
            pass

        def get_name(self):
            return "test"

    result.task_name = "test"
    result._task = obj_ShellModule()
    result._host = obj_Host()
    result._result = {
        "failed": False,
        "parsed": True,
        "exception": {},
        "warnings": [],
        "_ansible_no_log": False
    }


# Generated at 2022-06-23 09:29:25.397331
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    import json
    import mock
    import pytest
    
    from ansible.plugins.callback import CallbackBase

    x = CallbackModule()
    with mock.patch("ansible.plugins.callback.CallbackBase.display", autospec=True) as mock_display:
        with mock.patch("ansible.plugins.callback.CallbackBase.display", autospec=True) as mock_handle_exception:
            def _mock_handle_exception(self, result, *args, **kwargs):
                raise IOError("test")
                print("mocked error")
            mock_handle_exception.side_effect = _mock_handle_exception
            #mock_handle_exception.side_effect = lambda self, result, *args, **kwargs: raise IOError("test")

# Generated at 2022-06-23 09:29:36.078118
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    from ansible.utils.display import Display
    display = Display()
    res = ansible.plugins.callback.CallbackModule(display=display)
    args = {}
    setattr(args, 'display_skipped_hosts', 'False')
    setattr(args, 'display_ok_hosts', 'True')
    res._set_options(args)
    
    # hello, results
    results = {'invocation': {'module_args': 'args'}, 'item': 'world'}
    result = Result(host=Host(name='localhost'), task=Task(), returncode=0, results=results)
    
    assert not res.display_skipped_hosts
    assert res.display_ok_hosts
    res.v2_runner_on_skipped(result=result)
    assert res._last_task

# Generated at 2022-06-23 09:29:38.557169
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    pass # TODO


# Generated at 2022-06-23 09:29:40.416908
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    pass

CallbackModule = CallbackModule()

# Generated at 2022-06-23 09:29:44.067047
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    global callback
    callback = CallbackModule()
    callback.v2_playbook_on_task_start(2)
    assert callback.last_task_banner == 2

# Generated at 2022-06-23 09:29:44.875068
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    pass

# Generated at 2022-06-23 09:29:54.950216
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from collections import namedtuple
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    loader = DataLoader()

# Generated at 2022-06-23 09:29:56.699893
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    runner_item_on_ok()

# Generated at 2022-06-23 09:30:06.010458
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    data = { 
        "host": "host", 
        "task": "task", 
        "msg": "msg"
    }

    msg = "changed: [host] => (item=msg)"
    color = "COLOR_CHANGED"
    stderr = "stdout_lines"
    msg_type = "stderr"
    try:
        raise AnsibleError()
    except AnsibleError:
        to_unicode = utils.to_unicode(msg)
        display.display(to_unicode, color=color, stderr=stderr, screen_only=False, log_only=False)

    msg = "changed: [host] => (item=msg)"
    color = "COLOR_CHANGED"
    stderr = "stdout_lines"

# Generated at 2022-06-23 09:30:17.208404
# Unit test for method v2_playbook_on_stats of class CallbackModule

# Generated at 2022-06-23 09:30:23.508337
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    import ansible.plugins.callback.default

    callback = ansible.plugins.callback.default.CallbackModule()
    p = MagicMock()
    callback.v2_runner_on_async_ok(p)

    # postive test cases
    assert 1 == 1

    # negative test cases
    assert 1 == 1


# Generated at 2022-06-23 09:30:33.821483
# Unit test for method v2_playbook_on_handler_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_handler_task_start():
    import ansible_collections.ansible.community.tests.unit.compat.mock as mock
    from ansible_collections.ansible.community.plugins.callback.default import CallbackModule
    
    cb = CallbackModule()
    task = mock.MagicMock()
    task.no_log = False
    task._task.action = u'mock_action'
    task._task.loop = False
    task._task._uuid = u'mock_uuid'
    task._task.name = u'mock_name'
    mock_display = mock.MagicMock()
    mock_display.verbosity = 0
    cb._display = mock_display
    
    assert cb._last_task_banner == None
    assert cb._last_task_name == None
    cb.v2_

# Generated at 2022-06-23 09:30:46.216186
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():

    playbook = AnsiblePlaybook()
    play = AnsiblePlay()
    play.set_path('/AnsiblePlaybook/AnsiblePlay')
    playbook.add_ansible_play(play)
    task = TaskInclude()
    play.add_task(task)
    task.set_name('some_task')
    play._tasks_in_play.append(task)

    # test without context.CLIARGS['display_skipped_hosts']
    context.CLIARGS = {}
    context.CLIARGS['display_skipped_hosts'] = False
    cm = CallbackModule()
    assert not cm.display_skipped_hosts
    assert not cm.display_ok_hosts
    assert not cm.show_custom_stats
    assert not cm.check_mode_markers

# Generated at 2022-06-23 09:30:47.241470
# Unit test for method v2_playbook_on_cleanup_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_cleanup_task_start():
    pass

# Generated at 2022-06-23 09:30:56.203927
# Unit test for method v2_playbook_on_no_hosts_matched of class CallbackModule
def test_CallbackModule_v2_playbook_on_no_hosts_matched():
    from ansible.vars import VariableManager
    from ansible.playbook.task import Task
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    # create a callback module
    callback = CallbackModule()
    callback._display = Display()
    # create a task
    variable_manager = VariableManager()
    loader = DataLoader()
    options = Options()
    options.connection='local'
    options.module_path=['/to/mymodules']
    options.forks=10
    options.become=None
    options.become_method=None
    options.become_user=None
    options.verbosity=3

# Generated at 2022-06-23 09:31:06.003008
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    def test_ansible_exit_json(*args, **kwargs):
        if 'changed' not in kwargs:
            kwargs['changed'] = False
        raise AnsibleExitJson(kwargs)

    def test_ansible_fail_json(*args, **kwargs):
        kwargs['failed'] = True
        raise AnsibleFailJson(kwargs)

    class Mock(object):

        def __init__(self, *args, **kwargs):
            pass

        @classmethod
        def return_value_class(cls):
            return Mock

        def __call__(self, *args, **kwargs):
            return Mock()


# Generated at 2022-06-23 09:31:09.473830
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    # Input param preparation
    # Any normal execution path is acceptable
    # Output param preparation
    # Any normal return is acceptable
    # Test
    actual = CallbackModule(display=None, options=None)
    actual.v2_runner_on_start(None, None)
    # Verification
    # No verification needed in this case



# Generated at 2022-06-23 09:31:11.952911
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook = None
    callback_module = CallbackModule()
    callback_module.v2_playbook_on_start(playbook)



# Generated at 2022-06-23 09:31:18.787482
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    args = {}
    result_obj = {} 
    result_obj['ansible_job_id'] = MagicMock()
    result_obj['started'] = MagicMock()
    result_obj['finished'] = MagicMock()
    # Preparing mocks
    callback = CallbackModule(**args)
    callback.display = MagicMock()
    callback.display.display = MagicMock()
    # Making call
    callback.v2_runner_on_async_poll(result_obj)
    # Now testing
    assert callback.display.display.call_count == 1
    # Extracting parameters passed while making call
    actual_args = callback.display.display.call_args_list
    # Extracting the call arguments
    actual_args, actual_kwargs = actual_args[0]
    # we are only interested

# Generated at 2022-06-23 09:31:19.529908
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    """
    Test scenario: 
    """
    pass

# Generated at 2022-06-23 09:31:22.181303
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    cb = CallbackModule()
    cb.v2_runner_on_start(host=None, task=None)
    

# Generated at 2022-06-23 09:31:25.820124
# Unit test for method v2_playbook_on_no_hosts_remaining of class CallbackModule
def test_CallbackModule_v2_playbook_on_no_hosts_remaining():
    failed = False
    try:
        CallbackModule.v2_playbook_on_no_hosts_remaining()
    except NotImplementedError:
        failed = True

    assert failed



# Generated at 2022-06-23 09:31:28.273425
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    """
    CallbackModule.v2_playbook_on_stats(stats)
    """
    pass


# Generated at 2022-06-23 09:31:36.651283
# Unit test for method v2_playbook_on_no_hosts_matched of class CallbackModule
def test_CallbackModule_v2_playbook_on_no_hosts_matched():
    # testing the default values of class
    #def __init__(self,display):
    #print("begin test_CallbackModule_v2_playbook_on_no_hosts_matched")

    #create a callback class instance
    callback=CallbackModule()

    #test the default values of class
    assert callback._task_type_cache == {}
    assert callback.task_fields == {}
    assert callback.playbook.filename == None
    assert callback._last_task_banner == 0
    assert callback.runner_queue == None
    assert callback.play_queue == None

# Generated at 2022-06-23 09:31:44.533744
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    callback = CallbackModule()
    result = {'changed': True}
    task = Task(action='module', args={'name': 'debug', 'msg': 'ok'})

    class Host:
        def __init__(self):
            self._name = 'host'

        def get_name(self):
            return self._name

    host = Host()
    callback.v2_runner_item_on_ok(Result(host=host, result=result, task=task))



# Generated at 2022-06-23 09:31:49.476783
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    m = CallbackModule()
    retV = m.v2_playbook_on_start('test')
    if not isinstance(retV, type(None)):
        raise AssertionError("v2_playbook_on_start() should return None, but %r." % retV)
    # TODO: test the display in method v2_playbook_on_start()

# Generated at 2022-06-23 09:32:01.500800
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    '''
    Unit tests to test the v2_runner_on_unreachable method of CallbackModule.
    '''
    out = {}
    module, instance = get_module_instance_pair(CallbackModule, out, display=DummyDisplay())
    result = {}
    attrs = {
        '_task': Mock(),
        '_host': Mock(),
        '_result': result,
    }
    result['unreachable'] = False
    runner_result = get_runner_result(attrs)
    module.v2_runner_on_unreachable(runner_result)
    assert out.getvalue() == ''
    result['unreachable'] = True
    result['msg'] = "msg"
    module.v2_runner_on_unreachable(runner_result)
    assert 'msg' in out

# Generated at 2022-06-23 09:32:03.506697
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    obj = CallbackModule()
    assert isinstance(obj, CallbackModule)
    
if __name__ == '__main__':
    test_CallbackModule()

# Generated at 2022-06-23 09:32:04.288494
# Unit test for constructor of class CallbackModule
def test_CallbackModule():
    assert True


# Generated at 2022-06-23 09:32:08.856952
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    def v2_runner_on_ok(result):
        pass
    cb = CallbackModule(display=Display())
    cb.v2_runner_on_ok = v2_runner_on_ok
    cb.v2_runner_on_ok(result=None)

# Generated at 2022-06-23 09:32:17.336904
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
  from ansible.plugins.callback import CallbackModule
  from ansible.playbook.handler import Handler
  from ansible.inventory.host import Host

  # success test case
  c0 = CallbackModule()
  h1 = Handler(name='test',action='test')
  h1.set_name('test')
  h2 = Host(name='test.example.com')
  c0.v2_playbook_on_notify(handler=h1, host=h2)

if __name__ == "__main__":
  main()

# Generated at 2022-06-23 09:32:26.075299
# Unit test for method v2_playbook_on_stats of class CallbackModule

# Generated at 2022-06-23 09:32:32.798844
# Unit test for method v2_playbook_on_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_task_start():
    # SUT
    from callback_plugins.default import CallbackModule

    # Test setup
    task = mock.MagicMock()

    # Exercise function
    cm = CallbackModule()
    cm.v2_playbook_on_task_start(task)

    # Assertions
    task.get_name.assert_called_once_with()

# Generated at 2022-06-23 09:32:44.991097
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    """unit test of method v2_runner_item_on_ok of class CallbackModule"""

# Generated at 2022-06-23 09:32:48.888599
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    assert False



# Generated at 2022-06-23 09:33:01.118406
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():  
    # Test with a mocked display
    class MockedDisplay(object):
        def __init__(self):
            self.called_methods = []

        def display(self, msg, color):
            self.called_methods.append(dict(method='display', msg=msg, color=color))

    display = MockedDisplay()
    callback = CallbackModule()
    callback.display = display
    # Create a mocked item

# Generated at 2022-06-23 09:33:14.604869
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    import pytest
    import __main__
    runner = __main__.Actions()
    runner.check = False
    runner.verbosity = 2
    runner.step = True
    runner.start_at_task = None
    runner.tags = ['all']
    runner.skip_tags = []
    runner.inventory = '/home/ansible/ansible/production'
    runner.listhosts = None
    runner.subset = None
    runner.extra_vars = []
    runner.forks = 5
    runner.ask_vault_pass = False
    runner.vault_password_files = []
    runner.vault_ids = []
    runner.remote_user = 'root'
    runner.private_key_file = None
    runner.remote_pass = None
    runner.module_path = None


# Generated at 2022-06-23 09:33:23.979104
# Unit test for method v2_playbook_on_stats of class CallbackModule

# Generated at 2022-06-23 09:33:26.333418
# Unit test for method v2_playbook_on_no_hosts_remaining of class CallbackModule
def test_CallbackModule_v2_playbook_on_no_hosts_remaining():
    test_object = CallbackModule()
    assert test_object.v2_playbook_on_no_hosts_remaining() == None


# Generated at 2022-06-23 09:33:29.801285
# Unit test for method v2_playbook_on_handler_task_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_handler_task_start():
    module = CallbackModule()
    # Test positive case
    # TODO: I'm not sure what the parameters of the task should be.
    task = ''
    module.v2_playbook_on_handler_task_start(task)
    assert True


# Generated at 2022-06-23 09:33:35.858677
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
  # stub
  class Stub(object):
    pass
  result = Stub()
  result._task = Stub()
  result._task.no_log = False
  result._host = Stub()
  result._host.get_name = lambda: 'host-name'

  # create object
  callback_module = CallbackModule()

  # call method
  callback_module.set_options()


# Generated at 2022-06-23 09:33:43.993338
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    from collections import namedtuple
    from ansible import constants as C
    from ansible.utils.color import stringc
    from ansible.plugins.callback import CallbackBase
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    kwargs = { 
        'play': Play().load({
            'name': 'test',
            'hosts': 'localhost',
            'gather_facts': 'no',
            'tasks': [
                { 'action': { 'module': 'shell', 'args': 'whoami' } }
            ]
        }, DataLoader())            
    }
    play = namedtuple('Play_123', kwargs.keys())(*kwargs.values())