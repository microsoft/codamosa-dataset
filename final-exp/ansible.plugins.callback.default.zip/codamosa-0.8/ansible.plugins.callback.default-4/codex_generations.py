

# Generated at 2022-06-11 13:26:31.355952
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from random import randint
    from random import choice
    import inspect
    import tempfile
    import json
    import pytest

    # This test's purpose is to test that the correct message is output when
    # the v2_playbook_on_play_start method is called.
    # This method is passed a play object, and the play object has some attributes.
    # We want to test that all possible values of those attributes are printed out correctly.
    # To do this, we make a play object, set the attributes to some value, and test the output of
    # the v2_playbook_on_play_start method when called with

# Generated at 2022-06-11 13:26:34.080417
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    # setup
    self = CallbackModule()
    result = DefaultRunnerResult()
    # action
    self.v2_runner_on_skipped(result)
    # assert
    assert True

# Generated at 2022-06-11 13:26:35.389475
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    v2_on_file_diff(result)


# Generated at 2022-06-11 13:26:48.327581
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    import ansible.callbacks
    import ansible.playbook.task
    import ansible.utils.unsafe_proxy
    #import ansible.vars
    cb = ansible.callbacks.CallbackModule()
    stats = ansible.utils.unsafe_proxy.SafeUnsafeProxy('stats', 'stats')
    stats._tqm = ansible.utils.unsafe_proxy.SafeUnsafeProxy('_tqm', '_tqm')
    stats._tqm._stats = ansible.utils.unsafe_proxy.SafeUnsafeProxy('_stats', '_stats')
    stats._tqm._stats.processed = { 'host1': {}, 'host2': {} }
    task_name = ansible.utils.unsafe_proxy.SafeUnsafeProxy('task_name', 'task_name')


# Generated at 2022-06-11 13:26:58.699152
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    from __main__ import CallbackModule
    from ansible import constants as C
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.cli import CLI
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    import pytest
    import json
    import os
    import tempfile
    global hostvars
    hostvars = dict()

# Generated at 2022-06-11 13:27:05.374559
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    import ansible.callbacks as callbacks
    c = callbacks.CallbackModule()
    assert c.get_option('show_custom_stats') is None
    assert c.options.show_custom_stats is None

    # Run set_options()
    c.set_options(module_options={'show_custom_stats': True})
    assert c.get_option('show_custom_stats') is True
    assert c.options.show_custom_stats is True

# Generated at 2022-06-11 13:27:18.060442
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.display import Display
    from ansible.plugins import callback_loader, connection_loader
    import six
    import sys

    if six.PY3:
        from io import StringIO
    else:
        from StringIO import StringIO

    # Create a temporary directory to use for testing.
    test_dir = temp

# Generated at 2022-06-11 13:27:20.458581
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    b_module = CallbackModule()
    result = "result"
    b_module.v2_runner_on_failed(result)

# Generated at 2022-06-11 13:27:29.970578
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    import pytest
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    ci = CallbackModule()
    ci._disable_check_mode()
    ci._display = Display()
    sample_stats = {
        "processed": {
            "127.0.0.1": {
                "ok": 10,
                "failures": 0,
                "changed": 3,
                "skipped": 0,
                "unreachable": 0,
                "rescued": 0,
                "ignored": 0
            }
        }
    }
    ci.v2_playbook_on_stats(sample_stats)

    included_file = TaskIn

# Generated at 2022-06-11 13:27:37.537169
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    callback = CallbackModule()
    class MockTask(object):
        def __init__(self):
            self._uuid = "1"
    class MockResult(object):
        def __init__(self):
            self._task = MockTask()
            self._host = "localhost"
            self._result = {
                "changed": True,
                "invocation": {
                    "module_args": "no_log=True"
                },
                "warnings": [],
                "truncated": False,
                "msg": "Something"
            }
    class MockHost(object):
        def __init__(self):
            self.name = "localhost"
    ansible_host = MockHost()
    result = MockResult()
    result._host = ansible_host

# Generated at 2022-06-11 13:28:06.169682
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    playbook = ANSIBLE_LIB_DIR + '/test/test_playbook.yml'
    ansible_playbook_wrapper(playbook)

if __name__ == '__main__':
    test_CallbackModule_v2_playbook_on_stats()



# Generated at 2022-06-11 13:28:16.270182
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    cb = CallbackModule()
    result = cb.v2_runner_on_async_poll(result)
    print(result)

if __name__ == '__main__':
    test_CallbackModule_v2_runner_on_async_poll()
 


# Generated at 2022-06-11 13:28:28.133003
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    #test_dir = os.path.dirname(os.path.realpath(__file__))
    #sys.path.append(test_dir)
    test_dir = os.getcwd()+"/tests"
    print("test_dir: "+test_dir)
    #print("test_dir: "+test_dir)
    from ansible.playbook.play_context import PlayContext
    playbook = PlayContext()
    file_name = test_dir+"/handlers/test_handler_test.yml"
    included_file = test_dir+"/handlers/test_handler.yml" 
    included_file = {"_filename": included_file, "_hosts": ["127.0.0.1"]}
    print("included_file: "+str(included_file))

# Generated at 2022-06-11 13:28:40.184337
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    import mock
    import sys

    m_stats = mock.Mock()
    m_stats.summarize = mock.Mock(return_value={'changed':1,'failures':0,'ok':2,'skipped':0,'unreachable':0})
    m_stats.processed = {'test_host':['12345','67890','13579']}
    m_stats.custom = {'test_host':{'test_key':'test_val'}}
    #m_stats.custom = {'test_host':{'test_key':'test_val'},'_run':['12345','67890','13579']}
    m_display = mock.Mock()
    m_display.display = mock.Mock()
    m_display.columns = 80

# Generated at 2022-06-11 13:28:42.319291
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    my_callback = CallbackModule()
    my_callback.v2_runner_retry(result='')


# Generated at 2022-06-11 13:28:48.330448
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # Create an instance of CallbackModule without instantiating the underlying object
    module = CallbackModule()

    # Create a MagicMock to replace "display.banner()"
    mock_display = MagicMock()

    # Assign Mock to "display" in CallbackModule
    module.set_display(mock_display)

    # Create a MagicMock to replace "playbook._file_name"
    mock_playbook = MagicMock()
    mock_playbook.file_name = "playbook1.yml"

    # Call method v2_playbook_on_start()
    module.v2_playbook_on_start(mock_playbook)

    # Ensure that "display.banner()" is called
    mock_display.banner.assert_called_with("PLAYBOOK: playbook1.yml")


# Generated at 2022-06-11 13:28:51.965210
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    callback_module = CallbackModule()
    result = Result()
    assert callback_module.v2_runner_on_async_failed(result) == None, 'Unit test for v2_runner_on_async_failed failed.'


# Generated at 2022-06-11 13:29:03.340757
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    argv = [
        "ansible",
        "-i", "hosts",
        "-m", "ping",
        "all",
        "--ask-sudo-pass",
    ]
    sys.argv = argv
    # To test this callback module, we need an Ansible Play object
    pb = Playbook()
    pb._host_pattern = "all"
    pb._host_list = [
        Host("localhost"),
        Host("localhost"),
        ]

    # Ansible Play object has the PlayBookExecutor object
    pb._executor = PlayBookExecutor(pb)
    # And the PlayBookExecutor object has the Play object
    play = pb._executor._play
    play._playbook = pb

    # And the Play object has the TaskQueueManager object
    play._task_queue

# Generated at 2022-06-11 13:29:06.914101
# Unit test for method v2_runner_on_skipped of class CallbackModule

# Generated at 2022-06-11 13:29:18.797569
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    options = dict(
        connection='ssh',
        module_path='/path/to/mymodules',
        forks=10,
        become=None,
        become_method=None,
        become_user=None,
        check=False,
        diff=False,
        host_key_checking=True,
        listhosts=None,
        listtasks=None,
        listtags=None,
        syntax=None,
        subset=None,
        sudo_user=None,
        vault_password_file='/path/to/vault_password_file',
        verbosity=0)
    mock_display = create_autospec(Display)
    mock_display.display.return_value = True
    inventory = InventoryManager(loader=None, sources=[])

# Generated at 2022-06-11 13:30:17.235577
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    '''Test method v2_on_file_diff of class CallbackModule'''
    
    # Unittest setup
    class CallbackModule(object):
        pass
    class MockDisplay(object):
        def __init__(self):
            self.displayed = []
        def display(self, s, **kwargs):
            self.displayed.append(s)
    class MockTask(object):
        def __init__(self):
            self.action = 'file'
            self.loop = True
    class MockResult(object):
        def __init__(self):
            self._task = MockTask()

# Generated at 2022-06-11 13:30:20.735173
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    # Set up mock objects
    callback = CallbackModule()
    host = mock.MagicMock()
    task = mock.MagicMock()

    # Call method under test
    callback.v2_runner_on_start(host, task)


# Generated at 2022-06-11 13:30:26.042814
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # create an instance of the callback module
    callback_module = CallbackModule()
    # create a mock playbook class
    playbook_mock = MockPlaybook()
    # call the v2_playbook_on_start method with the mock playbook
    callback_module.v2_playbook_on_start(playbook_mock)


# Generated at 2022-06-11 13:30:29.098184
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
  # Test parameters
  result = ""

  # Unit test implementation
  # Test implementation here

  # Evaluation of the unit test results
  assert True

# Generated at 2022-06-11 13:30:42.090949
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    import yaml
    # Create an empty config object (we don't care about it)
    try:
        config = yaml.load("""
                            defaults: {}
                            """)
    except AttributeError:
        config = yaml.safe_load("""
                                defaults: {}
                                """)

    # Create an empty result object
    result = type('obj', (object,), {"_task": {}, "_result": {}})()
    result._result = x = {'invocation': {'module_name': 'setup'}}

    # Create the mock objects needed to test the method
    self = type('obj', (object,), {"_display": type('obj', (object,), {'display': lambda x: print(x)})(),
                                   "display_skipped_hosts": False})

# Generated at 2022-06-11 13:30:43.555108
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    _playbook_on_play_start()
    pass


# Generated at 2022-06-11 13:30:46.028144
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    result = AnsibleResult(host, task, return_data, task_fields)
    runner = CallbackModule()
    runner.v2_runner_retry(result)

# Generated at 2022-06-11 13:30:56.433824
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    cliargs = dict(connection='ssh', forks=5, for_socket=1, become=True, become_method='sudo', become_user='root', check=False, diff=False, extra_vars=dict(), flush_cache=False, force_handlers=False, inventory='/etc/ansible/hosts', module_path='/etc/ansible/library', vault_password_files='', verbosity=True, version=True, vault_password=None, private_key_file='/root/.ssh/id_rsa', create_remote_tmp=True, remote_tmp='tmp', module_name='command', module_args='/bin/echo hello', remote_user='root')
    variable_manager = mock.Mock()
    variable_manager.get_vars.return_value = {}
    variable_manager.extra_vars

# Generated at 2022-06-11 13:31:02.205409
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    stats = mock.Mock()
    callback = TestCallbackModule()
    callback.v2_playbook_on_stats(stats)
    assert callback.display_custom_stats

    stats = mock.Mock()
    callback = TestCallbackModule(show_custom_stats=False)
    callback.v2_playbook_on_stats(stats)
    assert not callback.display_custom_stats

# Generated at 2022-06-11 13:31:09.546834
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Create instance of class under test
    cb = CallbackModule()
    path = '~/ansible-test/test-repo/test-repo.ansible/test/integration/targets/test/test_duties_in_role/ansible/roles/role1/tasks/main.yml'
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    cb.v2_on_file_diff(AnsibleUnsafeText(path))
    pass


# Generated at 2022-06-11 13:32:02.892945
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    # Get a stracktrace for the exception
    try:
        testobj = CallbackModule()
        testobj.v2_playbook_on_play_start(play)
    except Exception as e:
        # If an exception occurred, show traceback
        traceback.print_exc()

# Generated at 2022-06-11 13:32:07.538026
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
	play = dict(name="play1")
	playinfo = dict(check_mode=True, check_mode_markers=True)
	cb = CallbackModule()
	cb.v2_playbook_on_play_start(play)
	print(cb._last_task_banner)


# Generated at 2022-06-11 13:32:17.461691
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Pass
    print('Test 1')
    hct = helpers.create_host_config_template(host_name_prefix='host')
    group_name = helpers.create_group(host_config_template=hct)
    task_name = helpers.create_task(group_name=group_name, action_name='ping')
    job = helpers.run_task(task_name)
    uuid = job.get('ansible_job_id')
    job = helpers.wait_for_job(uuid)
    helpers.delete_group(group_name)
    helpers.delete_host_config_template(hct['id'])
    helpers.delete_action(action_name='ping')
    assert job.get('status') == 'successful'

    # Pass
    print('Test 2')
    hct = helpers

# Generated at 2022-06-11 13:32:28.011125
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    # object under test
    callback = CallbackModule()

    # set up
    #
    # fake out the playbook
    class Playbook:
        def __init__(self):
            self._file_name = "playbook.yaml"


    # test
    #
    # output goes to a stream we can capture
    saved_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out

        # invoke method being tested
        callback.v2_playbook_on_start(Playbook())

        # double check
        assert "PLAYBOOK: playbook.yaml" in out.getvalue(), "callback.v2_playbook_on_start() did not print the playbook name"

    finally:
        # tear down
        sys.stdout = saved_stdout

    return



# Generated at 2022-06-11 13:32:31.631684
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    """
    Test method v2_runner_on_skipped of class CallbackModule
    """
    # Initialize callback module
    _CallbackModule = CallbackModule()
    _CallbackModule.v2_runner_on_skipped(None)

# Generated at 2022-06-11 13:32:33.705343
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    # Create a fixture
    #assert False
    pass # TODO: implement your test here


# Generated at 2022-06-11 13:32:41.698074
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    class MockTask:
        def __init__(self, a):
            self.action = a
    class MockResult:
        def __init__(self, h, t, r):
            self._host = h
            self._task = t
            self._result = r
    #
    # Created by: https://mockaroo.com/
    #

# Generated at 2022-06-11 13:32:49.978532
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    ansible_module = MagicMock()
    self = CallbackModule(ansible_module)
    result = MagicMock()
    result._host.get_name.return_value = "Test Host"
    result._result = {"unreachable": True}
    self.v2_runner_on_unreachable(result)
    self._display.display.assert_called_with("FAILED - RETRYING: [Test Host]: Test Playbook (1 retries left).",
                                             color=COLOR_DEBUG)


# Generated at 2022-06-11 13:32:56.835715
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    _result = {'invocation': {'module_name': 'command', 'module_args': "ifconfig"}}
    _task = 'task'
    _host = 'host'

    callback = CallbackModule()
    callback.v2_on_any(_result, 'on_any')

if __name__ == '__main__':
    test_CallbackModule_v2_runner_item_on_failed()

# Generated at 2022-06-11 13:33:02.519375
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback = CallbackModule()
    r = FakeResult()
    r._result = {'changed': False, 'diff': {"before": "line1\nline2\n", "after": "line1\nline2\n"}}
    r._task = FakeTask()
    callback.v2_on_file_diff(r)
    assert not callback.get_diff()
    r._result = {'changed': True, 'diff': {"before": "line1\nline2\n", "after": "line9\nline2\n"}}
    callback.v2_on_file_diff(r)
    assert callback.get_diff()
    r._result = {'changed': True, 'diff': {"before": "line1\nline2\n", "after": "line1\nline2\n"}}


# Generated at 2022-06-11 13:34:45.463509
# Unit test for method v2_runner_item_on_skipped of class CallbackModule

# Generated at 2022-06-11 13:34:52.315382
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    config = makeFakeConfig('tests/fixtures/hosts_commandline')
    fakeLoader = DictDataLoader({})
    cb = CallbackModule(config)
    cb.v2_playbook_on_include({"_filename" : "/Users/slink/Projects/ansible/ansible/hacking/test-module ", "_hosts": ["localhost"], "_vars": {} })
    cb.v2_playbook_on_include({"_filename" : "tests/fixtures/playbooks/include_playbook.yml", "_hosts": ["localhost"], "_vars": {} })

# Generated at 2022-06-11 13:34:53.729566
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    c = CallbackModule()
    c.v2_runner_on_unreachable({'msg': 'hello'})

# Generated at 2022-06-11 13:34:56.716598
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    """CallbackModule.set_options() does nothing.

    Unit test for CallbackModule.set_options().

    """
    callback_module = CallbackModule()

    callback_module.set_options()

# Generated at 2022-06-11 13:34:57.630132
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    assert True  

# Generated at 2022-06-11 13:35:01.229444
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    """
    Test v2_runner_on_skipped method from CallbackModule class
    """
    # Test default values
    callbacks = CallbackModule()
    callbacks.v2_runner_on_skipped(True)
    assert True

# Generated at 2022-06-11 13:35:11.446863
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    params = dict(
        display_skipped_hosts=True
    )
    cb = CallbackModule(**params)
    cb._task_fields = {}
    result = AnsibleResult(
        host=AnsibleHost(name="localhost", port=22,
                        variables={"ansible_connection": "local"}),
        task=AnsibleTask(name="task1", action="copy", kwargs={}),
        result=dict(skipped=True)
    )
    cb.v2_runner_item_on_skipped(result)



# Generated at 2022-06-11 13:35:12.916804
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    instance = CallbackModule()
    result = instance.set_options({'stats': '[changed:3,failed:2,ok:1,unreachable:0]'})


# Generated at 2022-06-11 13:35:18.074326
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    stats = Mock(processed = {'192.168.99.241': {'failures': 0, 'ok': 1, 'skipped': 0, 'changed': 0, 'unreachable': 0, 'rescued': 0, 'ignored': 0}})
    callback = CallbackModule()
    callback.v2_playbook_on_stats(stats)
    
test_CallbackModule_v2_playbook_on_stats()


# Generated at 2022-06-11 13:35:27.260609
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    # 1. Arrange
    handler = MagicMock()
    handler.get_name.return_value = 'handler'
    host = 'host'
    cb_mod = CallbackModule()
    cb_mod._display = MagicMock()
    cb_mod._display.verbosity = 2
    cb_mod._display.display = MagicMock()

    # 2. Act
    cb_mod.v2_playbook_on_notify(handler, host)

    # 3. Assert
    cb_mod._display.display.assert_called_once_with(
        "NOTIFIED HANDLER handler for host", 
        color=C.COLOR_VERBOSE, 
        screen_only=True
    )
