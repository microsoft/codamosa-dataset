

# Generated at 2022-06-11 13:26:14.275855
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    # Arguments:
    #    host,task => _host,_task

    obj = CallbackModule()
    obj.v2_runner_on_start('_host','_task')
    obj.v2_runner_on_start(host='_host',task='_task')
    obj.v2_runner_on_start('_host',task='_task')

# Generated at 2022-06-11 13:26:19.469399
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():

    class test_instance:

        display_skipped_hosts = True
        display_ok_hosts = False
        display_arguments = True
        display_failed_stderr = True

        def _get_diff(self, diff):
            return True

        def _clean_results(self, result, task_action):
            return True

        def _handle_exception(self, result, use_stderr=False):
            return True

        def _get_item_label(self, result):
            return True

        def _run_is_verbose(self, result):
            return True

        def _dump_results(self, result):
            return True

        def _print_task_path(self, task):
            return True

    # Set host_label in context

# Generated at 2022-06-11 13:26:31.896810
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    source = payload_source
    result = payload_result
    
    # Defines the local variable 'result'

# Generated at 2022-06-11 13:26:43.434566
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    # Creating objects
    cliargs = MagicMock(spec=dict)
    config = MagicMock(spec=dict)
    cli = MagicMock(spec=dict)
    callback = MagicMock(spec=CallbackModule)

    # Calling method
    callback.v2_runner_on_failed(result)

    # Getting the mocked results
    assert callback.v2_runner_on_failed(result)
    callback.display(msg)
    callback.v2_runner_on_failed(result)
    callback._clean_results(result._result, result._task.action)
    callback._handle_exception(result._result, use_stderr=callback.display_failed_stderr)

# Generated at 2022-06-11 13:26:45.936217
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    result = {}
    callback = CallbackModule()
    callback.v2_runner_on_async_poll(result)


# Generated at 2022-06-11 13:26:50.036929
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    self=CallbackModule()
    self.display_skipped_hosts()
    self._last_task_banner()
    self.display_ok_hosts()
    self._last_task_banner()

# Generated at 2022-06-11 13:26:52.187488
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Set up
    # Run the method
    # Assert the result
    pass


# Generated at 2022-06-11 13:26:53.365687
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    pass


# Generated at 2022-06-11 13:26:55.874878
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    # Test if stats value is passed correctly
    if(passed):
        print("Passed")
    else:
        print("Failed")
            

# Generated at 2022-06-11 13:27:04.655848
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # ensure param diff is an instance of AnsibleDiff
    # create an instance of the CallbackModule class
    call_obj = CallbackModule()

    # Create a new AnsibleTaskResult object
    ans_obj = AnsibleTaskResult()

    # set the value of result objects _result
    result_dict = {}
    result_dict['changed'] = False
    ans_obj._result = result_dict

    # Create an instance of AnsibleDiff class
    ans_diff_obj = AnsibleDiff()
    ans_diff_obj.diff = ['---', '+++', '@@ -4 +4 @@', '-   True', '+   False']

    # Create a new AnsibleTaskResult object
    ans_obj = AnsibleTaskResult()

    # set the value of result objects _result
    result_dict = {}

# Generated at 2022-06-11 13:27:31.528948
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    cb = CallbackModule()
    cb.set_options(None)
    cb.set_options({'display_skipped_hosts': 'True'})
    cb.set_options({'display_skipped_hosts': 'False'})
    cb.set_options({'display_ok_hosts': 'True'})
    cb.set_options({'display_ok_hosts': 'False'})
    cb.set_options({'show_custom_stats': 'True'})
    cb.set_options({'show_custom_stats': 'False'})
    cb.set_options({'verbosity': '1'})
    cb.set_options({'verbosity': '2'})
    cb.set_options({'verbosity': '3'})
    c

# Generated at 2022-06-11 13:27:39.056762
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    """
    v2_runner_on_unreachable
    """

    # From Ansible 2.4
    callback = CallbackModule()

# Generated at 2022-06-11 13:27:39.633089
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    pass

# Generated at 2022-06-11 13:27:41.367614
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
	stats = {}

	callback = CallbackModule()
	callback.v2_playbook_on_stats(stats)



# Generated at 2022-06-11 13:27:49.696081
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    from ansible.vars import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import os
    import tempfile
    import shutil


# Generated at 2022-06-11 13:28:01.501001
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    pass # can't instantiate abstract class CallbackModule with abstract methods v2_on_any, v2_on_file_diff, v2_on_setup, v2_runner_on_failed, v2_runner_on_ok, v2_runner_on_skipped, v2_runner_retry, v2_runner_on_unreachable, v2_on_stats, v2_on_async_poll, v2_on_async_ok, v2_on_async_failed, v2_on_cleanup_task_start, v2_on_handler_task_start, v2_playbook_on_import_for_host, v2_playbook_on_not_import_for_host, v2_playbook_on_play_start, v2_playbook_on_stats, v2

# Generated at 2022-06-11 13:28:03.108885
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
  # Instance initialization
  cb = CallbackModule()

  # The following call mustn't raise an exception
  cb.v2_playbook_on_stats({})

# Generated at 2022-06-11 13:28:13.780606
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C

    play_source =  dict(
        name = "Ansible Play v2_runner_on_failed",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls fjkdlsajfdlx request_invalid_name')),
            dict(action=dict(module='debug', args=dict(msg='{{request_invalid_name}}')))
         ]
    )

    play = Play().load(play_source, variable_manager=None, loader=None)
    tqm = None
    callback = CallbackModule()

# Generated at 2022-06-11 13:28:23.121380
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    # This test was generated programmatically. Please do not edit it.
    if not is_local():
        return
    import ansible_runner
    import ansible_runner.interface

    # Initialize mock variables
    cmd_result = ansible_runner.interface.CommandResult(rc=None, stdout="", stderr="", start_line=None, end_line=None)
    result = ansible_runner.interface.Result(host=None, event=None, task=None, result=None, event_data=None, task_data=None, start_line=None, end_line=None)

    # Call the method under test

# Generated at 2022-06-11 13:28:28.183695
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
  # Create instance of our own class
  v = CallbackModule()
  # Create instance of Ansible class
  playbook = Ansible()
  # Pass correct argument to method v2_playbook_on_start
  v.v2_playbook_on_start(playbook)
  assert True 


# Generated at 2022-06-11 13:28:56.198762
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    test_input = {
        "_host": "non_empty_string",
        "_result": {
            "ansible_job_id": "non_empty_string",
            "async_result": {
                "ansible_job_id": "non_empty_string"
            }
        }
    }

    out = Mock()
    callback_object = CallbackModule(display=out, options=None)
    callback_object.v2_runner_on_async_failed(test_input)
    expected_out = [call("ASYNC FAILED on non_empty_string: jid=non_empty_string", color='255')]
    assert out.method_calls == expected_out


# Generated at 2022-06-11 13:28:57.361950
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    pass

# Generated at 2022-06-11 13:29:00.928479
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():

    cb = CallbackModule()
    cb.open_lock_file = mock.MagicMock(return_value=None)
    cb.v2_playbook_on_play_start(None)


# Generated at 2022-06-11 13:29:11.735700
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    
    class ResultCallback(CallbackBase):
        def v2_runner_on_ok(self, result, **kwargs):
            task_output = result._result.get('stdout_lines', result._result.get('stdout', ''))
            print(task_output)

    
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'hosts': 'localhost'}
    inventory

# Generated at 2022-06-11 13:29:15.702143
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    my_inst = CallbackModule()
    result = my_inst.v2_playbook_on_play_start(play=None)
    assert result is None


# Generated at 2022-06-11 13:29:25.955954
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    c = CallbackModule()

    # case 1 - task_name [uninitialized]
    result = Mock(
        _result = {
            "msg" : "this is a failed result"
        },
        _task = Mock(
            action = "foo"
        )
    )
    msg = "failed: foo"
    expected = Exception(msg)
    try:
        c.v2_runner_on_failed(result)
    except Exception as e:
        assert e.message == expected.message

    # case 2 - task_name [initialized]
    result = Mock(
        _result = {
            "msg" : "this is a failed result"
        },
        _task = Mock(
            action = "foo"
        ),
        task_name = "bar"
    )
    msg = "failed: bar"

# Generated at 2022-06-11 13:29:29.600607
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    result = mock.MagicMock()
    result.task_name = 'test'
    result.host_name = 'test'
    result._result = dict(changed=True)
    cb = CallbackModule()
    cb.v2_runner_item_on_ok(result)

# Generated at 2022-06-11 13:29:42.868133
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    class MockDisplay:
        def __init__(self):
            self.log_only_msgs = []
            self.screen_only_msgs = []

            self.verbosity = 3

        def display(self, msg, color = None, stderr = False,
                          screen_only = False, log_only = False,
                          runner_on = False):
            if screen_only:
                self.screen_only_msgs.append(msg)
            elif log_only:
                self.log_only_msgs.append(msg)
            else:
                raise Exception("unexpected display call")

        def banner(self, msg, color = None):
            pass

        def display_progress(self, percentage, message=''):
            pass


# Generated at 2022-06-11 13:29:46.934052
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    host_name = 'localhost'
    task = 'set_fact'
    host = Host(name=host_name)

    callback_module = CallbackModule()
    callback_module.v2_runner_on_start(host=host, task=task)


# Generated at 2022-06-11 13:29:55.148612
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    p = Play()
    t = Task()
    r = Result(host=None, task=t)
    c = CallbackModule()
    # Test case 1 - when c.display_ok_hosts is True
    c.display_ok_hosts = True
    result = c.v2_runner_item_on_skipped(r)
    assert result == None
    # Test case 2 - when c.display_ok_hosts is False
    c.display_ok_hosts = False
    result = c.v2_runner_item_on_skipped(r)
    assert result == None

# Generated at 2022-06-11 13:30:22.344209
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    print("\nRunning test for method v2_runner_item_on_skipped of class CallbackModule")
    # Create instance of class CallbackModule with default args
    callback = CallbackModule(display=None, options=None)
    # Create C.BaseV2Result instance
    result = C.BaseV2Result()
    # Set different results
    result._result = {"changed": "True", "msg": "results1"}
    result._host = C.Host(name="host1")
    result._task = "task1"
    callback.v2_runner_item_on_skipped(result=result)
    result._result = {"changed": "False", "msg": "results2"}
    result._host = C.Host(name="host2")
    result._task = "task2"
    callback.v2_runner

# Generated at 2022-06-11 13:30:35.125917
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
  cb = CallbackModule()
  result = mock.MagicMock()
  result._host = mock.MagicMock()
  result._host.get_name.return_value = "MyHost"
  result._result = {}
  # Test with display_skipped_hosts=True
  cb.display_skipped_hosts = True
  cb.v2_runner_item_on_skipped(result)
  assert cb.display_skipped_hosts is True
  # Test with display_skipped_hosts=False
  cb.display_skipped_hosts = False
  cb.v2_runner_item_on_skipped(result)
  assert cb.display_skipped_hosts is False
  # Test with display_skipped_hosts=False
  # and result._

# Generated at 2022-06-11 13:30:46.365264
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    c = CallbackModule

# Generated at 2022-06-11 13:30:49.827211
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook = Playbook.Playbook()
    callback = CallbackModule()
    callback.v2_playbook_on_start(playbook)
    assert callback.v2_playbook_on_start(playbook) == None


# Generated at 2022-06-11 13:30:55.080472
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():

    # Create an instance of CallbackModule
    callback_module = CallbackModule()

    # Create mock objects
    result = Mock()
    result._host = Mock()
    result._host._name = 'test_host'

    # Call method v2_runner_on_failed
    callback_module.v2_runner_on_failed(result)


# Generated at 2022-06-11 13:30:58.246816
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    cb = CallbackModule(display=Display())
    result = {'changed': True}
    assert cb.v2_runner_item_on_ok('', result) == None


# Generated at 2022-06-11 13:30:59.444588
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    pass
    

# Generated at 2022-06-11 13:31:04.524206
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    s = 'ok=1    changed=0    unreachable=0    failed=0    \nok=1    changed=0    unreachable=0    failed=0    '
    expected = s.split('\n')
    m = CallbackModule()
    res = m.v2_playbook_on_stats(vars(sys))
    assert_equals(res, expected)

# Generated at 2022-06-11 13:31:10.125709
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    # Test for set options
    cls = CallbackModule()
    cls.set_options()
    assert cls.check_mode_markers == False
    assert cls.show_custom_stats == True
    assert cls.display_skipped_hosts == True
    assert cls.display_ok_hosts == True
    assert cls.display_failed_stderr == True


# Generated at 2022-06-11 13:31:15.489001
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
  from ansible.plugins.callback import CallbackModule
  callbackModule = CallbackModule(display=DummyDisplay(), verbosity=0)
  callbackModule.v2_runner_on_ok(DummyResult())
  assert 'ok: [localhost] =>' == callbackModule._display.messages[0], "CallbackModule.v2_runner_on_ok didn't add messages to the display as expected"


# Generated at 2022-06-11 13:31:57.936099
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    test_obj = CallbackModule()
    result = {
        "_host":{
            "name":"localhost",
            "vars":{},
            "groups":{}
        },
        "_result":{
            "ansible_job_id":"None"
        }
    }
    returned_message = test_obj.v2_runner_on_async_failed(result)
    assert returned_message == None


# Generated at 2022-06-11 13:32:09.777809
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    callback_module = CallbackModule({}, {})
    test_host = type('test_host', (), {})()
    test_host.name = 'test_host_name'

    test_task = type('test_task', (), {})()
    test_task.action = 'test_action'
    test_task.loop = False
    test_task_result = {
        'diff': {
            'before': 'test_before',
            'after': 'test_after',
            'before_header': 'test_before_header',
            'after_header': 'test_after_header'
        },
        'changed': True
    }

    test_result = type('test_result', (), {})()
    test_result._result = test_task_result
    test_result._task = test_task
    test

# Generated at 2022-06-11 13:32:13.165282
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    with mock.patch('builtins.open') as mock_open:
        mock_open.side_effect = IOError
        c = CallbackModule()
        c.v2_playbook_on_start(mock_open)


# Generated at 2022-06-11 13:32:20.659521
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_result import TaskResult
    from ansible.executor.play_iterator import PlayIterator
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.include import RoleInclude

    # Mock task object
    class MockTask:
        def __init__(self, action, loop, no_log):
            self.action = action
            self.loop = loop
            self.no_log = no_log

    # Mock task_result object
    class MockTaskResult:
        def __init__(self, host, task, result):
            self

# Generated at 2022-06-11 13:32:22.372905
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    notify = CallbackModule()
    notify.v2_playbook_on_include("included_file")

# Generated at 2022-06-11 13:32:33.181788
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():

   # run Ansible filters with input_data
    input_data = ''
   # run Ansible with modules_extra (templates, actions, lookups)
    os.makedirs('/tmp/ansible-tmp-1534785594.2-182112144750880', exist_ok=True)

# Generated at 2022-06-11 13:32:41.460758
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    host_label = '10.10.10.1'
    result = dict()
    result['failed'] = True
    result['stdout'] = 'Failed'
    result['module'] = 'command'
    result['command'] = '/bin/sh'
    result['msg'] = 'non-zero return code'
    result['cmd'] = 'sh'
    result['changed'] = True
    result['rc'] = 1
    result['stderr'] = ''
    result['stdout_lines'] = [u'Failed']
    result['invocation'] = dict()
    result['invocation']['module_name'] = 'command'
    result['invocation']['module_args'] = 'ls -al'
    result['_ansible_parsed'] = True

# Generated at 2022-06-11 13:32:48.951963
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    # Setup the class
    callback_module = CallbackModule()
    
    # Setup test data
    result = Mock(**{'_host.get_name.return_value': 'example.com', '_task.action': 'some_action'})
    
    # Run method
    callback_module.v2_runner_on_skipped(result)
    
    # Verify test data
    # Assert the test result is false
    assert False
    
    

# Generated at 2022-06-11 13:32:52.072951
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    callback = CallbackModule()
    stats = {'processed': {}}
    callback.v2_playbook_on_stats(stats)

# Generated at 2022-06-11 13:33:02.905019
# Unit test for method v2_runner_on_async_poll of class CallbackModule

# Generated at 2022-06-11 13:34:29.902749
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    # Test a scenario when there was no errors, ansible_stats is an empty dictionary and ansible_custom_stats is not empty
    # Input:
    #    <class 'ansible.vars.manager.VarsManager'>
    #    {'ignored': 0, 'failures': 0, 'ok': dictionary, 'changed': dictionary, 'status': dictionary, 'unreachable':dictionary, 'Skipped': dictionary}
    #    {<some_string>: <some_string>}
    res = CallbackModule()
    res.show_custom_stats = True

# Generated at 2022-06-11 13:34:30.550792
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    pass

# Generated at 2022-06-11 13:34:31.128960
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    pass

# Generated at 2022-06-11 13:34:40.776327
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    # unit test for method v2_runner_on_async_failed of class CallbackModule
    from ansible.plugins.callback.default import CallbackModule
    from ansible.playbook.task import Task
    from ansible.executor.task_result import TaskResult, HostResult, TaskResultCollection
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import callback_loader, connection_loader, fragment_loader, module_loader, strategy_loader
    #from ansible.plugins.strategy.linear import StrategyModule as StrategyModule_linear
    from ansible.utils.context_objects import AnsibleContext
    AnsibleContext.init

# Generated at 2022-06-11 13:34:41.802090
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    pass


# Generated at 2022-06-11 13:34:42.680465
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    pass


# Generated at 2022-06-11 13:34:50.128684
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    import unittest

    import ansible.utils
    class TestClass(unittest.TestCase):

        def setUp(self):
            self.test_class = CallbackModule()
            # Test class state

        def tearDown(self):
            pass

        def test_callback(self):
            # self.test_class.v2_playbook_on_stats(obj)
            pass

    class MockStats(object):
        def __init__(self):
            self.processed = {}
            self.custom = {}

        def summarize(self, host):
            return {'ok': 1, 'failures': 2, 'changed': 3, 'unreachable': 4, 'skipped': 5}

    class MockHost(object):
        def __init__(self, name):
            self.name = name


# Generated at 2022-06-11 13:34:50.676930
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    pass

# Generated at 2022-06-11 13:34:57.201128
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    leader_display = LeaderDisplay()
    leader_display.display("", screen_only=True)
    assert leader_display.screen_only_output[-1] == ""

    task_result = TaskResult()
    callbackmodule = CallbackModule(display=leader_display, task_results=task_result)
    result = Result()
    callbackmodule.v2_runner_on_unreachable(result=result)

    assert leader_display.screen_only_output[-1] == "[WARNING]: HOST UNREACHABLE or timed out: default(192.168.0.3)"



# Generated at 2022-06-11 13:35:10.194686
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    display = Mock()
    callback = CallbackModule(display)
    # Call method v2_runner_item_on_skipped
    result = Mock()
    result._result = {'skipped': False}
    result._task = Mock()
    result._task.action = 'dosomething'
    callback.v2_runner_item_on_skipped(result)
    # Now check if method v2_runner_item_on_skipped did call method display of class Mock
    assert display.call_count == 0
    # Summary:
    # Method display of class Mock has been called 0 times.
    # Call method v2_runner_item_on_skipped
    result = Mock()
    result._result = {'skipped': True}
    result._task = Mock()
    result._task.action = 'dosomething'
   