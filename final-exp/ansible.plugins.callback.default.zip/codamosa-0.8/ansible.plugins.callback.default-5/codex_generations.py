

# Generated at 2022-06-11 13:26:29.085579
# Unit test for method v2_runner_on_ok of class CallbackModule

# Generated at 2022-06-11 13:26:38.084111
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Initialize test data
    callback_module = CallbackModule()
    result = TaskResult()
    # Set callback_module.last_task_banner to _last_task_banner, _last_task_banner called in _print_task_banner
    callback_module.last_task_banner = callback_module._last_task_banner
    # Set result._task to _task, _task called in _print_task_banner
    result._task = callback_module._task
    callback_module.check_mode = True
    callback_module._print_task_banner = _print_task_banner
    # Set result._result['diff'] to diff
    diff = {'before': 'before', 'after': 'after', 'before_header': 'before_header'}
    result._result['diff'] = diff

# Generated at 2022-06-11 13:26:51.308405
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Get the class object of the callback module
    callback_module_class = CallbackModule

    # Initiate the callback module object
    callback_module_instance = callback_module_class()

    # Create a result object
    task = AnsibleTask()
    result = AnsibleResult(task)

    # Set the attributes for the result object
    result._task = task
    result._task.loop = False
    result._result = {}
    result._result['changed'] = True
    result._result['diff'] = ""
    result._result['diff'].append("diff --git a/playbooks/all.yml b/playbooks/all.yml")
    result._result['diff'].append("+++ b/playbooks/all.yml")
    result._result['diff'].append("@@ -1,6 +1,6 @@")

# Generated at 2022-06-11 13:26:57.135874
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():    
    # Initializing instance of CallbackModule(dummy_args)
    callbackmodules_inst = CallbackModule(dummy_args)

    # Initializing instance of Result(dummy_args)
    result_inst = Result(dummy_args)

    # Testing method v2_runner_item_on_skipped of class CallbackModule
    callbackmodules_inst.v2_runner_item_on_ok(result_inst)

# Generated at 2022-06-11 13:27:07.662024
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    from ansible_collections.testns.testcoll.plugins.modules import test_async
    result = dict(invocation=dict(module_args='echo hi'))
    pm = test_async.AsyncModule()
    pm._exec_module(result, dict())
    assert result.get('ansible_job_id') is not None
    hostname = 'localhost'
    pm.poll(result)
    result['started'] = time.time()
    result['finished'] = time.time()
    pb = CallbackModule()
    pb._display.verbosity = 1
    pb.v2_runner_on_async_poll(result)
    assert pb.last_task_banner == result['ansible_job_id']
    pb._display.verbosity = 10
    pb.v2

# Generated at 2022-06-11 13:27:20.084157
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # Test arguments and return value.
    result = {"_result": {"diff": "hello world", "changed": True, "_task": "task", "_host": "host"}}
    callback = CallbackModule()
    callback.v2_runner_item_on_ok = MagicMock()
    callback._get_diff = MagicMock(return_value=True)
    callback._print_task_banner = MagicMock()
    assert callback.v2_on_file_diff(result) == None

    result = {"_result": {"diff": "hello world", "changed": False, "_task": "task", "_host": "host"}}
    callback = CallbackModule()
    callback.v2_runner_item_on_ok = MagicMock()
    callback._get_diff = MagicMock(return_value=True)
   

# Generated at 2022-06-11 13:27:29.729724
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    from ansible.executor.task_result import TaskResult
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    class MockDisplay(object):
        def __init__(self):
            self.screen_output = []
            self.logged_output = []
        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            if msg is None:
                msg = ''
            msg = msg.rstrip("\r\n")
            msg += "\n"
            self.screen_output.append(msg)

# Generated at 2022-06-11 13:27:32.518046
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    host=None
    result=None
    callback=CallbackModule()
    callback.v2_runner_on_unreachable(result)
    # AssertionError: True is not False
    assert True == False


# Generated at 2022-06-11 13:27:40.055177
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    """
    This function is for testing v2_runner_on_failed callback of class CallbackModule.
    
    Here we are going to test the following things,
    
    :return: None
    """
    import tempfile
    import os
    import shutil
    import stat

    # create a temp directory
    temp_dir = tempfile.mkdtemp()
    os.chmod(temp_dir, stat.S_IRWXU)

    # test cases

# Generated at 2022-06-11 13:27:40.909006
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    pass



# Generated at 2022-06-11 13:28:05.313156
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    cb = CallbackModule()
    r_host = Host('hostname')
    r_task = Task()
    r_result = Result(host=r_host, task=r_task, _result=dict(changed=True))
    cb.v2_runner_on_ok(r_result)

# Generated at 2022-06-11 13:28:07.776242
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    """
    Test function v2_runner_on_async_poll of class CallbackModule
    
    
    """




# Generated at 2022-06-11 13:28:13.346334
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    runner_results = {'contacted': {'foo': {'failed': False, 'changed': False}, 'bar': {'failed': True, 'changed': True}}}
    display = Display()
    playbook = Playbook()
    play = Play()
    c = CallbackModule(runner_results, display, playbook, play)
    assert c.v2_playbook_on_play_start(play) is None


# Generated at 2022-06-11 13:28:19.475851
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    instance = CallbackModule(Display(), Options(None, None, None))
    result = {
        "_result": {
            "changed": False,
            "invocation": {
                "module_args": "",
                "module_name": ""
            }
        },
        "_task": {
            "action": "fail",
            "loop": "",
            "name": "",
            "tags": "",
            "vars": ""
        },
        "_host": {
            "name": "",
        }
    }
    instance.v2_runner_item_on_failed(result)


# Generated at 2022-06-11 13:28:26.955274
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    test_callback_module = CallbackModule()
    test_task_result = TaskResult(task=Task(), host=Host(name="test_host"))
    test_task_result._result = {"changed": True}
    test_task_result._task.action = "test_action"
    test_task_result._task.no_log = True

    test_callback_module.v2_runner_on_ok(test_task_result)


# Generated at 2022-06-11 13:28:33.377796
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    result = {'foo':'bar'}
    task = Task()
    task._uuid = 'testValue'
    task._task_fields['action'] = 'PING'
    callback = CallbackModule()

    result['_task'] = task
    callback.v2_runner_on_skipped(result)

    assert callback.display_skipped_hosts == False


# Generated at 2022-06-11 13:28:42.792999
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    runner_results = dict(contacted=dict(host=dict(foo='bar')))
    stats = dict(contacted=dict(host=dict(ok=1, fail=1)))
    pb = dict(Playbook=dict(name="test.yml"))
    for verbosity in (0, 1, 2):
        TestModule = get_runner_callback_module(False, runner_results, stats, pb, verbosity)
        instance = TestModule()
        from ansible.playbook import Playbook
        class DummyPlaybook():
            _file_name = "test.yml"
        instance.v2_playbook_on_start(DummyPlaybook())


# Generated at 2022-06-11 13:28:43.490604
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    pass

# Generated at 2022-06-11 13:28:51.548895
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    c = CallbackModule()
    c._display = Display()
    result = mock.MagicMock()
    result._host = mock.MagicMock()
    result._host.name = 'test_host'
    result._result = { 'ansible_job_id': u'test_jid', 'started': u'test_started', 'finished': u'test_finished' }
    c._display.verbosity = 0
    with mock.patch.object(c._display, 'display') as mock_display:
        c.v2_runner_on_async_poll(result)
        assert mock_display.called


# Generated at 2022-06-11 13:28:59.446712
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    runner = Mock()
    host = Mock()
    runner.host = host
    result = Mock()
    result.task_name = 'MockTask'
    result.host = 'MockHost'
    result._result = {}
    result._host = 'MockHost'
    result._task = 'MockTask'
    result._play = 'MockPlay'
    result._play_context = {}
    callback = CallbackModule()
    assert callback.v2_runner_on_async_ok(result) is None



# Generated at 2022-06-11 13:29:39.736008
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    result = ('ok', 'ok')
    cb = CallbackModule()
    assert cb.v2_on_file_diff(result) == None

# Generated at 2022-06-11 13:29:51.054245
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    hosts = [
        {
            "hostname": "127.0.0.1"
        }
    ]
    tasks = [
        {
            "name": "pass",
            "action": {
                "module": "shell",
                "args": "echo hello"
            },
            "async": 1,
            "poll": 0
        }
    ]
    inventory = InventoryManager(hosts=hosts)
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    callback = CallbackModule()
    play_context = PlayContext()
    playbook = PlaybookExecutor(
        playbooks=["test.yml"],
        inventory=inventory,
        variable_manager=variable_manager,
        loader=loader,
        options=None,
        passwords={})
   

# Generated at 2022-06-11 13:29:59.816877
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    module = CallbackModule()
    # Stats
    from ansible.utils.stats import AggregateStats
    stats = AggregateStats()
    stats.compute(dict())
    # Play
    from ansible.playbook.play import Play
    play = Play().load({}, variable_manager=dict(), loader=dict())
    module.play = play
    # Runner
    from ansible.runner.return_data import ReturnData

# Generated at 2022-06-11 13:30:12.938682
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    from ansible.plugins.callback import CallbackBase
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()

    test_inventory = Inventory(loader=DataLoader(), variable_manager=variable_manager, host_list=['host_one'])

    test_class = CallbackBase()


# Generated at 2022-06-11 13:30:14.662045
# Unit test for method v2_runner_on_unreachable of class CallbackModule

# Generated at 2022-06-11 13:30:23.001269
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    # set up object for testing
    def raise_on_log_invocation(msg):
        raise Exception('log method should not be invoked')

    display = Display()
    playbook_cb = CallbackModule()
    playbook_cb._display = display
    playbook_cb._log_invocation_count = 0
    playbook_cb.log = raise_on_log_invocation
    play = Play()

    # execute test
    playbook_cb.v2_playbook_on_play_start(play)
    assert playbook_cb._play == play

    assert display.verbosity == 0
    assert display._display_msg_priv == ['PLAY']
    assert display._display_invocation_count == 1
    assert display._display_msg_pub == []


# Generated at 2022-06-11 13:30:36.049519
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-11 13:30:39.832851
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    def test_template(self, play):
        play.get_name().strip()
        play.check_mode
        self.check_mode_markers
        self._display.banner()



# Generated at 2022-06-11 13:30:48.841654
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    # Stub
    args = {}
    options = {}
    ansible_playbook = Mock(PlaybookExecutor, spec=PlaybookExecutor)
    runner = Mock(Runner, spec=Runner)
    runner.results = []
    result = Mock(TaskResult, spec=TaskResult)
    result.task = Mock(Task, spec=Task)
    result.task.action = 'ping'
    result.task.no_log = False
    result._result = {'changed': False}
    result._task = Mock(Task, spec=Task)
    result._host = Mock(Host, spec=Host)
    result._host.get_name = Mock(name='get_name')
    result._host.get_name.return_value = 'host.example.com'
    # Test

# Generated at 2022-06-11 13:30:53.779279
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    include = CallbackModule()
    include.v2_playbook_on_include('/path/to/playbook.yml')
    #assert include.v2_playbook_on_include('/path/to/playbook.yml') == print('included: /path/to/playbook.yml for')


# Generated at 2022-06-11 13:32:21.451038
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    selected_hosts = []
    for result in results:
        if result['item']['name'] == 'Allow SSH access via the loopback interface':
            selected_hosts.append(result)
    
    
    for result in selected_hosts:
        print(result)
        callback = CallbackModule()
        callback.v2_runner_on_async_poll(result)


# Generated at 2022-06-11 13:32:32.244026
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():

    # Testing output for a scenario, where Ansible retries a task for a remote host
    # A remote host, for which a task is being retried was previously known to Ansible, and exists in the inventory.

    result = Result()
    result.task_name = "Testing Retry"
    result._task = "Testing Retry"
    result._attempts = 1
    result._result["retries"] = 3
    result._result["attempts"] = 0
    result._result["failed"] = True
    result._result["changed"] = True
    result._result["msg"] = "The Task failed"
    result.host = EndPoint("server.com", 0, "server.com", 0)
    result._host = EndPoint("server.com", 0, "server.com", 0)

# Generated at 2022-06-11 13:32:35.129447
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    callback = CallbackModule()
    callback.v2_runner_item_on_ok("ok")
    assert "v2_runner_item_on_ok" not in context

# Generated at 2022-06-11 13:32:41.331259
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    class CallbackModule(object):
        def v2_playbook_on_include(self, included_file):
            msg = 'included: %s for %s' % (included_file._filename, ", ".join([h.name for h in included_file._hosts]))
            label = self._get_item_label(included_file._vars)
            if label:
                msg += " => (item=%s)" % label
            self._display.display(msg, color=C.COLOR_SKIP)
    
    # create instance of class CallbackModule
    cb = CallbackModule()


# Generated at 2022-06-11 13:32:43.697926
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    my_CallbackModule = CallbackModule()
    my_CallbackModule.v2_playbook_on_play_start()

# Generated at 2022-06-11 13:32:46.078500
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    test = CallbackModule()
    test.v2_runner_on_ok(None)

# Generated at 2022-06-11 13:32:51.136605
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    """
    Test method v2_runner_on_skipped of class CallbackModule
    """
    callback = CallbackModule()
    mock_result = Mock()
    #call method
    callback.v2_runner_on_skipped(result=mock_result)


# Generated at 2022-06-11 13:33:02.233698
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    class UnitTestCallbackModule(CallbackBase):
        CALLBACK_VERSION = 2.0
        CALLBACK_TYPE = 'stdout'
        CALLBACK_NAME = 'unit_test'

        def v2_runner_on_async_poll(self, result):
            host = result._host.get_name()
            jid = result._result.get('ansible_job_id')
            started = result._result.get('started')
            finished = result._result.get('finished')
            self.display.display(
                'ASYNC POLL on %s: jid=%s started=%s finished=%s' % (host, jid, started, finished),
                color=C.COLOR_DEBUG
            )
    options = context.CLIARGS
    plugin = UnitTestCallbackModule()
    display = Display()
   

# Generated at 2022-06-11 13:33:06.465249
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    """
  Example test for method v2_runner_retry of class CallbackModule
  """
    import pytest
    from mock import patch

    from ansibleplaybookgrapher.callback.ansible_callback_module import CallbackModule
    result = None
    callback_module = CallbackModule()
    with pytest.raises(NotImplementedError):
        callback_module.v2_runner_retry(result)



# Generated at 2022-06-11 13:33:09.466814
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    e = CallbackModule()
    assert e.v2_on_file_diff(result=None) == None #TODO need to mock 'result'
