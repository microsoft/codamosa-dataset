

# Generated at 2022-06-11 13:26:31.680967
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    from ansible.plugins.callback import CallbackModule
    from ansible.module_utils.six import string_types
    from collections import namedtuple
    from ansible.errors import AnsibleError

    host = namedtuple('host', ['name'])
    task = namedtuple('task', ['tags', 'name', 'action'])
    result = namedtuple('result', ['task', '_host', '_task', '_result'])

    host = host(name='127.0.0.1')
    task = task(tags=set(), name='task_name', action='action_name')

    expected = ('failed: [%s] %s: '%(host.name, task.action))
    expected += ('%s'%(task.name))

# Generated at 2022-06-11 13:26:43.142629
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    class Mock(object):
        def __init__(self, stats):
            self.stats = stats

    stats = analyser.stat.AnalyserStat()
    stats.increment_failed(['a', 'b'])
    stats.increment_ok(['a', 'c'])
    stats.increment_unreachable(['d'])
    # stats.processed = {'a': {'ok': 1, 'changed': 1, 'unreachable': 1, 'failures': 1, 'skipped': 1, 'rescued': 1, 'ignored': 1}, 'b': {'ok': 1}, 'c': {'ok': 1}, 'd': {'unreachable': 1}}
    stats.add_custom_stat('test', {'a': 1, 'b': 2})
    stats.add_custom

# Generated at 2022-06-11 13:26:49.551943
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    CallbackModule = AnsibleCallbackModule()
    # self = <ansible.plugins.callback.AnsibleCallbackModule object at 0x7f5a5e8cd0f0>
    # result = <ansible.executor.task_result.TaskResult object at 0x7f5a5f3a3a20>
    CallbackModule.v2_runner_retry(result)

# Generated at 2022-06-11 13:26:59.457002
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    args = {}
    inst = CallbackModule()
    host = {
        "name": "test_host"
    }
    result = {
        "_result": {
            "changed": True
        },
        "task": {
            "name": "test_task"
        }
    }
    result_no_change = {
        "_result": {
            "changed": False
        },
        "task": {
            "name": "test_task_no_change"
        }
    }
    inst._last_task_name = None
    inst._last_task_banner = None
    inst._task = None
    # Test with a changed task
    inst.v2_runner_on_ok(host, result)
    # The method will print a message, that includes the task name
    assert inst._last_

# Generated at 2022-06-11 13:27:04.946261
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    result = mock.MagicMock()
    result.is_changed = True
    result.host = mock.MagicMock()
    result.host.name = 'hostname'
    result.task = mock.MagicMock()
    result.task.name = 'taskname'
    cb = CallbackModule()
    cb.v2_runner_on_ok(result)

# Generated at 2022-06-11 13:27:10.065015
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    # Given
    # create test object
    obj = CallbackModule()
    # create test variables
    included_file = object()
    
    # When
    obj.v2_playbook_on_include(included_file)
    
    # Then
    #assert result is None

# Generated at 2022-06-11 13:27:22.227592
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    from ansible.callbacks import CallbackModule
    from ansible.playbook.play import Play
    from ansible.utils.plugin_docs import get_docstring
    import pytest
    import textwrap
    # Get doc test for class CallbackModule
    test_class_docstring = get_docstring(CallbackModule)
    # Get doc test for v2_playbook_on_play_start method of class CallbackModule
    test_func_docstring = get_docstring(CallbackModule.v2_playbook_on_play_start)
    # Get the doc test for the class
    test_class_docstring = get_docstring(CallbackModule)
    # Run the test of the class only if the class test succeeds
    if test_class_docstring:
        # Run the doc test for the given method
        test_func_

# Generated at 2022-06-11 13:27:31.291398
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    module = AnsibleModule()
    AnsibleModule_instance = AnsibleModule(argument_spec=dict())
    stats = AnsibleModule_instance.params['stats']
    # Test expected exception raised
    # test of the _get_diff method
    def _get_diff(self, diff):
        diff = {}
        while True:
            try:
                diff.update(dict.__getattribute__(diff,'_diff'))
            except AttributeError:
                break
        return diff
    # test of the _dump_results method
    def _dump_results(self, result, indent=None, sort_keys=True, keep_invocation=False):
        result = AnsibleModule_instance._get_diff(result)
        indent = None
        sort_keys = True
        keep_invocation = False
        # All result keys stating

# Generated at 2022-06-11 13:27:33.244298
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback = CallbackModule()
    callback.set_options({'option_name': 'option_value'})
    assert callback.option_name == 'option_value'


# Generated at 2022-06-11 13:27:38.111392
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    '''
    Unit test for method v2_playbook_on_notify of class CallbackModule
    '''

# Generated at 2022-06-11 13:28:08.620156
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    from ansible.plugins import callback_loader

    failed = False

    def _is_private(key):
        return key.startswith('_') or key.startswith('v2_')

    for callback_plugin in callback_loader.all():
        callback = callback_plugin()
        if hasattr(callback, 'v2_runner_item_on_skipped'):
            try:
                callback.v2_runner_item_on_skipped(None)
            except Exception:
                if os.environ.get('ANSIBLE_UNIT_TEST_DEBUG'):
                    raise
                else:
                    print('Method v2_runner_item_on_skipped failed for %s, with exception:' % callback_plugin)
                    traceback.print_exc()
                    failed = True

    if failed:
        raise Assert

# Generated at 2022-06-11 13:28:12.267189
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    module = CallbackModule()
    result = MagicMock()
    module.v2_runner_on_skipped(result)
    module.v2_runner_on_skipped.called_once_with(result)

# Generated at 2022-06-11 13:28:19.277466
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    # setup
    vars = dict(diff=dict(after=dict(name='/home/stacy/file.txt', state='file', checksum='da39a3ee5e6b4b0d3255bfef95601890afd80709', mode='0644'), before=dict(state=None)), changed=True)
    task = MagicMock()
    result = Result(host=MagicMock(), task=task, task_result=vars)
    cb = CallbackModule(display=MagicMock())

    # test
    cb.v2_on_file_diff(result)

    # assert
    cb._display.display.assert_called()


# Generated at 2022-06-11 13:28:22.122514
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    any_instance = CallbackModule()
    assert any_instance.v2_runner_retry(None) == None

# Generated at 2022-06-11 13:28:34.158249
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    play = {'id': '4', 'playbook_uuid': '1d86c8f7-ab42-4d91-8a4a-4c4cdd4e6e2b', 'play_uuid': '0febb9a9-30e3-4d43-a1b0-deffc6a39d29', 'name': 'install_mongodb'}
    play = Play().load(play, variable_manager=VariableManager(), loader=None)
    cliargs = {'check': False, 'vault_password': 'secret'}
    context.CLIARGS = cliargs

    display = Display()
    playbook = PlaybookExecutor([], playbook=None)

    callback = CallbackModule(display=display, playbook=playbook)
    callback.v2_playbook

# Generated at 2022-06-11 13:28:44.585690
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    c = CallbackModule()
    c.set_options({'skip_task': {'skip_task': 'freeplay'}})
    assert c.skip_task == 'freeplay'

    c = CallbackModule()
    c.set_options({
        'stats': {'stats': 'freeplay'},
        'show_custom_stats': {'show_custom_stats': 'freeplay'},
        'skip_task': {'skip_task': 'freeplay'},
        'show_task': {'show_task': 'freeplay'},
        'show_timing': {'show_timing': 'freeplay'},
    })
    assert c.stats == 'freeplay'
    assert c.show_custom_stats == 'freeplay'
    assert c.skip_task == 'freeplay'
    assert c

# Generated at 2022-06-11 13:28:46.331685
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
        CallbackModule.v2_runner_on_start(None, None, None)


# Generated at 2022-06-11 13:28:46.962608
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    pass

# Generated at 2022-06-11 13:28:58.122055
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    import sys
    import unittest

    class Mock_result(object):
        def __init__(self):
            self._task = Mock_task()
            self._result = {
                'changed': False,
                'diff': {}
            }
            self.tags = []
            self.module_name = 'test'
            self.__module_realpath__ = 'test/test'

    class Mock_task(object):
        def __init__(self):
            self.action = 'changed'
            self.loop = False
            self._uuid = 'test'

    class Mock_display(object):
        def __init__(self):
            self.verbosity = 3
            self.COLOR_OK = 'COLOR_OK'
            self.COLOR_CHANGED = 'COLOR_CHANGED'
            self.COLOR

# Generated at 2022-06-11 13:29:09.137384
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    my_ansible = AnsibleRunner(
        os.environ["MOLECULE_INVENTORY_FILE"])
    my_ansible.get({
        'path': '/',
    })
    p = Play().load(
        dict(
            name="Test play",
            hosts="all",
            gather_facts="yes",
            tasks=[
                dict(action=dict(module="debug", args=dict(msg="Hello World!"))),
            ],
        ),
        variable_manager=my_ansible._variable_manager,
        loader=my_ansible._loader,
    )
    results_callback = ResultCallback()
    callback_plugins=[results_callback]

# Generated at 2022-06-11 13:29:42.634125
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():

    # Setup mock objects
    mock_self = MagicMock()
    mock_self.get_option.return_value = False
    mock_self._display.verbosity = 3
    mock_playbook = MagicMock()
    mock_playbook._file_name = 'test_file_name'

    # Execute code to be tested
    test_callback_plugin = CallbackModule()
    test_callback_plugin.v2_playbook_on_start(playbook=mock_playbook)

    # Assert that mocked objects function as expected
    mock_self.get_option.assert_called_with('show_custom_stats')
    mock_self._display.banner.assert_called_with('PLAYBOOK: test_file_name')

# Generated at 2022-06-11 13:29:45.581836
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    p = CallbackModule()
    try:
        p.v2_playbook_on_stats(None)
    except:
        assert False

# Generated at 2022-06-11 13:29:55.971703
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    data = {}
    data['action'] = 'run-shell'
    data['stage'] = 'building'
    data['msg'] = 'some content'
    data['task'] = 'task1'
    data['hostname'] = 'localhost'
    data['failed'] = False
    data['changed'] = True
    data['results'] = {'action' : 'run-shell', 'stage' : 'building', 'msg' : 'some content', 'task' : 'task1', 'hostname' : 'localhost', 'failed' : False, 'changed' : True}

# Generated at 2022-06-11 13:29:58.571501
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook = MagicMock()
    callback_module = CallbackModule()
    callback_module._display.verbosity = 2
    callback_module.v2_playbook_on_start(playbook)


# Generated at 2022-06-11 13:30:01.679658
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    stats = None
    
    # FIXME: unit test for CallbackModule.v2_playbook_on_stats
    raise NotImplementedError()

# Generated at 2022-06-11 13:30:14.662908
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    # Test CallbackModule.v2_runner_on_start()
    my_playbook = Playbook()
    my_playbook.vars['test_var1'] = 'value1'
    my_playbook.vars['test_var2'] = {'test_key1': 'test_value1', 'test_key2': 'test_value2'}
    my_playbook.vars['test_var3'] = ['test_value1', 'test_value2']
    my_task = Task()
    my_task.name = 'my_task'
    my_task.action = 'my_action'
    # Test with 'show_per_host_start' set to True
    my_callback = CallbackModule(show_per_host_start=True)
    my_callback.v2_playbook_

# Generated at 2022-06-11 13:30:17.082730
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
  callback = CallbackModule()
  result = Result()
  result.task_name = "test_task"
  result._task = "test_task"
  result._result = {'retries': 1, 'attempts': 1}
  assert callback.v2_runner_retry(result) is None


# Generated at 2022-06-11 13:30:27.427576
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    test = os.path.abspath(os.path.dirname(__file__)) + '/test_playbook_on_play_start.yaml'
    load_yaml = yaml.load(open(test, 'r').read())
    play = Play.load(load_yaml[0], variable_manager=variable_manager, loader=loader)
    callback = CallbackModule()
    callback.v2_playbook_on_play_start(play)
    sys.stdout.seek(0)
    output = sys.stdout.read()
    assert output == '\033[0;33mPLAY [gathering facts]\033[0m\n'



# Generated at 2022-06-11 13:30:30.719243
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    with pytest.raises(NotImplementedError):
        obj = CallbackModule()
        obj.v2_playbook_on_notify(handler, host)


# Generated at 2022-06-11 13:30:37.122419
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    callback = CallbackModule()
    options = {'stdout_callback': 'default', 'verbosity': 0}
    callback.set_options(options)
    assert callback._display.verbosity == 0
    assert callback.display_ok_hosts == True
    assert callback.display_skipped_hosts == False
    assert callback.display_failed_stderr == False


# Generated at 2022-06-11 13:31:19.339818
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    CallbackModule = callback_plugins.default.CallbackModule
    callback_plugins.default.CallbackModule = TestCallbackModule

# Test functions for method v2_runner_on_unreachable of class CallbackModule

# Generated at 2022-06-11 13:31:29.266119
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    from ansible.plugins.callback.default import CallbackModule
    from ansible.config.manager import make_context, ConfigManager
    config_manager = ConfigManager()
    config_manager.initialize()
    plugin = CallbackModule()
    plugin.set_options()
    assert plugin._options == {
        'show_custom_stats': True,
        'show_ipv4': True,
        'show_ipv6': False,
        'show_skipped_hosts': True,
        'use_verbose_ole_formatter': False,
        'verbose': True,
        'verbosity': 3,
        'warnings': True
    }

# Generated at 2022-06-11 13:31:31.474204
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    pytest.skip("TODO: implement this")

# Generated at 2022-06-11 13:31:43.275921
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    # Loading CallbackModule and creating an instance of it
    dummy_instance = CallbackModule()
    # Creating a 'Mock' object that mimics a 'play' object
    dummy_play = Mock()
    dummy_play.check_mode = False
    dummy_play.get_name.return_value = u'Playbook'
    # Creating a 'Mock' object for 'display' (which is obtained as attribute from dummy_instance)
    dummy_instance.display = Mock(Display)
    # Creating a 'Mock' object for 'banner' (which is obtained as attribute from 'dummy_instance.display')
    dummy_instance.display.banner = Mock()
    # Calling the method under test with a 'Mock' object that mimics a 'play' object

# Generated at 2022-06-11 13:31:52.197675
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    play = Play()
    tqm = None
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader,variable_manager,host_list=[])
    cb = CallbackModule()
    inventory.get_hosts = MagicMock(return_value = [host])
    play.hosts = [host]
    result = MagicMock()

# Generated at 2022-06-11 13:32:03.350880
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    from ansible.plugins.callback.default import CallbackModule
    from collections import namedtuple

    display = namedtuple("display", ['verbosity'])
    display.verbosity = 4
    runner_result = namedtuple("runner_result", ['_task', '_result', '_host'])
    task_item = namedtuple("task_item", ['action'])
    host_item = namedtuple("host_item", ['get_name'])
    host_item.get_name = lambda: "myhost"
    callback = CallbackModule(display)
    assert callback.v2_runner_item_on_skipped(runner_result(task_item(action="action"), {"result": "result"}, host_item()))._task.action == "action"
    assert callback.v2_runner_item_on_sk

# Generated at 2022-06-11 13:32:14.384897
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    PlaybookCLIRunner = ansible.executor.playbook_executor.PlaybookCLIRunner

# Generated at 2022-06-11 13:32:21.355157
# Unit test for method set_options of class CallbackModule

# Generated at 2022-06-11 13:32:27.116113
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    # Given, When
    result = Mock()
    result.task_name = 'task_name'
    result._task = 'task'
    result._result = {'retries': 2, 'attempts': 1}
    # When
    callbackmodule = CallbackModule()
    result_message = callbackmodule.v2_runner_retry(result)
    # Then
    assert result_message is None


# Generated at 2022-06-11 13:32:37.610021
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    # this test is not a good example; at least not currently because it is a
    # unittest test of a pytest-style test (assert). It's here to get the
    # pytest coverage checker to run over the test/unit/callback_plugins/test_log_plays.py file
    # so that the unittests are also run. It can be fixed later.
    obj = CallbackModule(display=None)
    result = Mock()
    result._result = {'changed': True}
    result._host = 'hostname'
    result._task = Mock()
    result._task.action = 'action'
    obj.v2_runner_item_on_ok(result)
    result._result = {'changed': False}
    obj.v2_runner_item_on_ok(result)

# Generated at 2022-06-11 13:34:02.688667
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    pass



# Generated at 2022-06-11 13:34:06.807573
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    playbook = AnsiblePlaybook()
    callback = CallbackModule(playbook)
    playbook.cliargs = {'args': ['1','2','3'], 'check': False}
    callback.v2_playbook_on_start(playbook)


# Generated at 2022-06-11 13:34:07.498385
# Unit test for method v2_on_file_diff of class CallbackModule
def test_CallbackModule_v2_on_file_diff():
    pass

# Generated at 2022-06-11 13:34:09.050576
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    pass # TODO

# Generated at 2022-06-11 13:34:18.729202
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    result = self._play.get_variable_manager().get_vars(self._play.get_loader(), [], [])
    result._host = Host('localhost', self._tqm._inventory.get_host('localhost'))
    result._task = Task()
    result._result = dict(ansible_job_id='12345')
    result._task.retries = 2
    result._task.loop = False
    result._task.action = 'ping'
    result._task.args = dict()
    result._task.check_mode = False

    # Run the callback method
    self._callback.v2_runner_on_async_poll(result)

    # Print method call and any remaining output to stdout
    print(self._callback._stdout.getvalue().rstrip())
    self._callback._stdout.seek

# Generated at 2022-06-11 13:34:27.651202
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    result = {}
    result['_result'] = {}
    result['_task'] = {}
    result['_task']['action'] = 'ping'
    result['_task']['loop'] = None
    result['_task']['loop_args'] = {}
    result['_task']['loop_args']['_raw_params'] = {}
    result['_host'] = {'name':'host1'}
    result['_result']['stdout_lines'] = []
    result['_result']['stdout'] = ""
    result['_result']['warnings'] = []
    result['_result']['changed'] = False
    result['_result']['_ansible_no_log'] = False
    result['_result']['failed'] = False

# Generated at 2022-06-11 13:34:32.442393
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    host_name = 'compute01'
    result = Result()
    result._host = host_name
    result._result = {'ansible_job_id': '2043286072', 'started': 1, 'finished': 2}
    result._task = 'name'
    original_cb = PlaybookCallbacks()
    original_cb.v2_runner_on_async_poll(result)

# Generated at 2022-06-11 13:34:41.922320
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # setup 
    from pprint import pprint as pp

    from test.unit.callback_plugins.test_helper import TestCallbackBase
    from test.unit.callback_plugins.test_helper import DummyResult


    class TestCallbackModule(CallbackModule):
     
        def __init__(self, display=None, options=None):
            super(TestCallbackModule, self).__init__(display, options)

            self.display = display
            self.options = options
            self.result = None
      
        def v2_runner_on_ok(self, result, *args, **kwargs):

            print >> sys.stderr, '### v2_runner_on_ok'
            
            print >> sys.stderr, '### self.result:'

# Generated at 2022-06-11 13:34:48.293482
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    display_skipped_hosts = True
    _last_task_banner = uuid()
    result = TestResult(host='localhost', task=u'set_fact', result=u"hello world")
    result._result = {}
    result._task = Task()
    result._task.action = 'debug'
    callback = CallbackModule()
    callback.display_skipped_hosts = display_skipped_hosts
    callback._last_task_banner = _last_task_banner
    try:
        callback.v2_runner_item_on_skipped(result)
    except Exception as e:
        print(e)



# Generated at 2022-06-11 13:34:51.229025
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    obj = CallbackModule()
    result = FakeRunnerResult()
    obj.v2_playbook_on_play_start(play=FakePlaybook())
    obj.display_skipped_hosts = False
    obj.v2_runner_item_on_skipped(result=result)