

# Generated at 2022-06-11 13:26:18.617765
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    # Setup
    new_module = CallbackModule()
    new_callback_module = CallbackModule()
    # new_callback_module.get_option = MagicMock()
    result = MagicMock()
    result._host = MagicMock()
    result._host.get_name = MagicMock()

    # Exercise
    # Assertion
    try:
        new_module.v2_runner_item_on_ok(new_callback_module, result)
    except SystemExit:
        pytest.fail("Test v2_runner_item_on_ok failed")
    else:
        assert True


# Generated at 2022-06-11 13:26:31.213314
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    # Arrange
    result = fakeresult()

    # Act
    callbackModule = CallbackModule()
    callbackModule.v2_runner_on_async_poll(result)

    # Assert
    temp = 'ASYNC POLL on FAKEHOST: jid=FAKEJID started=FAKESTARTED finished=FAKEFINISHED'
    assert callbackModule._display.display.call_args[0][0] == temp
    assert callbackModule._display.display.call_args[1]['color'] == C.COLOR_DEBUG
    assert callbackModule._display.display.call_args[1]['log_only'] == False
    assert callbackModule._display.display.call_args[1]['screen_only'] == False
    assert callbackModule._display.display.call_args[1]['log_only'] == False

# Generated at 2022-06-11 13:26:33.861081
# Unit test for method v2_runner_item_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_item_on_skipped():
    obj = CallbackModule()
    obj.display_skipped_hosts = False
    result = object()
    obj.v2_runner_item_on_skipped(result)



# Generated at 2022-06-11 13:26:42.542341
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    _self = mock.Mock()
    _include = mock.Mock()

    def get_name(): return '_test'

    _include._filename = 'test.yml'
    _include._hosts = ['test']
    _include._vars = 'test'
    C = CallbackModule() 
    C.get_option = lambda x: None
    
    C.v2_playbook_on_include(_self, _include)
    assert _self.display.display.call_count == 1


# Generated at 2022-06-11 13:26:47.027136
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    global result, ansible_playbook, ansible_runner
    ansible_playbook = AnsiblePlaybook()
    ansible_runner = AnsibleRunner()
    result = ansible_runner.run(ansible_playbook)
    print(result)


# Generated at 2022-06-11 13:26:57.709066
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    callback = CallbackModule()
    result = {'item': 'test_item'}
    task = TaskInclude('test_task')
    host = Host('test_host')
    # method must exist
    assert hasattr(callback, 'v2_runner_on_skipped'), \
        "Method v2_runner_on_skipped() missing in the CallbackModule"
    # method must take 4 arguments (self, result, task, host)
    arg_count = len(inspect.getargspec(getattr(callback, 'v2_runner_on_skipped'))[0])
    assert arg_count == 4, \
        "Method v2_runner_on_skipped() must take 4 arguments (%d given)" % arg_count


# Generated at 2022-06-11 13:27:08.721219
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    '''
    Callback Module: set options
    '''

    # Mocking the ANSIRESET environment variable
    # This environment variable is used to set a tty mode
    # In this case, we want to disable it
    monkeypatch.setenv('ANSIBLE_FORCE_COLOR', 'true')

    # Mocking the ANSIBLE_FORCE_COLOR environment variable
    # This environment variable is used to set a tty mode
    # In this case, we want to disable it
    monkeypatch.setenv('ANSIBLE_NOCOLOR', 'true')

    # Mocking the ANSIBLE_NOCOLOR environment variable
    # This environment variable is used to set a tty mode
    # In this case, we want to disable it
    monkeypatch.setenv('ANSIBLE_CALLBACK_WHITELIST', 'white')

# Generated at 2022-06-11 13:27:21.153865
# Unit test for method v2_playbook_on_play_start of class CallbackModule

# Generated at 2022-06-11 13:27:29.473094
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    # mock data
    runner = MockRunner()
    result = MockResult()
    result._host = MockHost()
    result._host.get_name.return_value = "host"
    result._result = dict()
    result._result['ansible_job_id'] = "ansible_job_id"
    callback = CallbackModule()

    # v2_runner_on_async_failed is called
    callback.v2_runner_on_async_failed(result)

    # test assertions
    result_msg = 'ASYNC FAILED on host: jid=ansible_job_id'
    assert result_msg == callback._display.display.call_args_list[0][0][0]

# Generated at 2022-06-11 13:27:34.196687
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # Mock the task result
    task_result = mock.Mock()
    task_result.get.return_value = ""
    # Mock the task
    task = mock.Mock()
    task.action = 'shell'
    task.loop = False
    task.no_log = False
    task._uuid = 'random_string'
    task.get_name.return_value = 'task_name'
    task.check_mode = False
    # Mock the inventory
    inventory = mock.Mock()
    inventory.get_variable.return_value = ""
    # Mock the host
    host = mock.Mock()
    host.get_name.return_value = 'host_name'
    host.vars = {}
    # Mock the display
    display = mock.Mock()
    display.check_mode_

# Generated at 2022-06-11 13:28:05.899477
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    result = {'ansible_job_id': '123456789', 'started': 'yyyy-mm-dd hh:mm:ss', 'finished': 'yyyy-mm-dd hh:mm:ss'}
    host = 'host'
    c = CallbackModule()
    c.v2_runner_on_async_poll(result, host)


# Generated at 2022-06-11 13:28:16.060665
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    from ansible.plugins.callback.default import CallbackModule
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.process.worker import WorkerProcess
    from ansible.utils.listify import listify_lookup_plugin_terms
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play

# Generated at 2022-06-11 13:28:27.748982
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    '''
    Unit test for method v2_runner_on_ok of class CallbackModule
    '''
    mock_ans_run = Mock()
    mock_ans_run.get_option.return_value = 1
    mock_ans_run.display.verbosity = 1
    mock_ans_run.display.colorized_output = False
    mock_ans_run.display._dump_results.side_effect = ["dumped_result"]
    mock_ans_run.display.display.side_effect = ["dumped_result"]

    mock_result = Mock()
    mock_result._host = Mock()
    mock_result._host.get_name = Mock(return_value = "mock_name")
    mock_result._task = Mock()
    mock_result._task.action = "action"
    mock_result

# Generated at 2022-06-11 13:28:39.848809
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    '''
    CallbackModule.v2_playbook_on_stats() Test
    '''
    # Testing with this test case
    hosts = ['1.2.3.4', '5.6.7.8']

    # Test without custom stats
    stats = test_results_parser.create_fake_stats(hosts)
    callback_module = CallbackModule()
    callback_module.v2_playbook_on_stats(stats)

# Generated at 2022-06-11 13:28:41.383922
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    res = dict(started=0, finished=0)
    cb = CallbackModule()
    cb.v2_runner_on_async_ok(res)
    assert True



# Generated at 2022-06-11 13:28:44.053191
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    # Display skipped hosts not configured
    config.CallbackModule.display_skipped_hosts = False
    config.CallbackModule.v2_runner_on_skipped(mock.MagicMock())


# Generated at 2022-06-11 13:28:54.367683
# Unit test for method v2_runner_on_start of class CallbackModule
def test_CallbackModule_v2_runner_on_start():
    os.environ['ANSIBLE_VERBOSITY'] = '0'
    callback = CallbackModule()    
    task = Task()
    task._uuid = u'39a6f04f-3b62-4bef-973c-a708b5a5d542'
    task._role = None
    task._task_fields['action'] = 'shell'
    task._task_fields['args'] = {}
    task._task_fields['delegate_to'] = None
    task._task_fields['name'] = u'set_fact'
    task._task_fields['register'] = ''
    task._task_fields['when'] = None
    task.loop = None    
    host = Host()
    host.name = 'test'
    host.get_name = lambda : 'test'
        


# Generated at 2022-06-11 13:29:05.759764
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    # CallbackModule - v2_playbook_on_notify
    # Ensure the output of the unit test is correct for the success and failure conditions
    # Return a tuple (status,out,err), where out is the output of the action, and err is the error string or None if no error happened.
    result = (False, False)
    # Verify the test output matches the expected output
    assert result == (True, True), "Test with assertion"


    # CallbackModule - v2_playbook_on_notify
    # Ensure the output of the unit test is correct for the success and failure conditions
    # Return a tuple (status,out,err), where out is the output of the action, and err is the error string or None if no error happened.
    result = (False, False)
    # Verify the test output matches the expected output
    assert result

# Generated at 2022-06-11 13:29:10.213670
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
  create_mock = MagicMock(return_value=Mock())
  with patch.object(CallbackModule, 'create_file', create_mock):
    callback = CallbackModule()
    result = Mock()
    callback.v2_runner_on_async_failed(result)


# Generated at 2022-06-11 13:29:21.943211
# Unit test for method v2_runner_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_ok():
    # 1. Setup
    # 1a. Create a test object
    test_obj = CallbackModule()
    
    # 1b. Create a test result
    test_result=Result(host=None, task=None, result={})
    
    # 1c. Mock a display
    mock_display_instance=MagicMock(spec=Display)
    mock_display_instance.display=MagicMock(return_value=None)
    test_obj._display=mock_display_instance
    
    # 1d. Mock a marked banner
    mock_banner_instance=MagicMock(spec=Banner)
    mock_banner_instance.display=MagicMock(return_value=None)
    test_obj._play=mock_banner_instance
    
    # 2. Exercise
    test_obj.v2

# Generated at 2022-06-11 13:29:51.475402
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    from ansible import constants as C
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.compat.six import StringIO
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.playbook_executor import PlaybookExecutionContext
    from ansible.executor.task_queue_manager import TaskQueueManager

# Generated at 2022-06-11 13:29:55.061707
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    cb = CallbackModule()
    stats = stats()
    cb.v2_playbook_on_stats(stats)
    assert len(cb.cb._display.display.call_args_list) == 0


# Generated at 2022-06-11 13:29:58.295977
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    # FIXME: build a result object
    result = None
    # Setup args
    # Setup kwargs
    assert isinstance(_cb_plugin, CallbackModule)
    _cb_plugin.v2_runner_on_async_ok(result)

# Generated at 2022-06-11 13:30:09.589492
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    from .test.lib.test_runner import test_runner, test_result

    cb = CallbackModule()
    stats = test_stats()
    stats.processed['test_host'] = test_result()
    stats.summarize('test_host')

    cb.v2_playbook_on_stats(stats)

    cb._display.display.assert_any_call(
        u'test_host : ', color=C.COLOR_SKIP, screen_only=True)
    cb._display.display.assert_any_call(
        "", screen_only=True)

    cb._display.display.assert_any_call(
        u"            : ", color=None, log_only=True)



# Generated at 2022-06-11 13:30:20.694239
# Unit test for method v2_runner_item_on_failed of class CallbackModule

# Generated at 2022-06-11 13:30:24.734531
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
  fake_result = mock.Mock()
  callback_module = CallbackModule()
  callback_module.display_skipped_hosts = True
  callback_module.v2_runner_on_skipped(fake_result)


# Generated at 2022-06-11 13:30:38.240467
# Unit test for method v2_runner_on_failed of class CallbackModule

# Generated at 2022-06-11 13:30:48.024125
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    config = dict(STDOUT_CALLBACK='default')


# Generated at 2022-06-11 13:30:58.615080
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    class MockDisplay(CallbackModule):
        def __init__(self):
            self.verbosity = 1
    
    MockDisplay.display = Mock()
    callback = MockDisplay()
    
    # Test with jid
    result = Mock(spec=dict)
    result._result = {"ansible_job_id":76}
    result._host = Mock(spec=dict)
    result._host.get_name.return_value = "mock_host"
    callback.v2_runner_on_async_failed(result)
    
    # Test without jid
    result = Mock(spec=dict)
    result._result = {"async_result":{"ansible_job_id":76}}
    result._host = Mock(spec=dict)

# Generated at 2022-06-11 13:31:03.528722
# Unit test for method v2_playbook_on_stats of class CallbackModule
def test_CallbackModule_v2_playbook_on_stats():
    callbackModule = CallbackModule()
    stats = {"processed":{"test" :{"":1,"":2,"":3,"":4,"":5,"":6,"":7}}}
    callbackModule.v2_playbook_on_stats(stats=stats)

test_CallbackModule_v2_playbook_on_stats()


# Generated at 2022-06-11 13:31:19.958885
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    pass


# Generated at 2022-06-11 13:31:23.521409
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    reload(callback_plugin)
    a = callback_plugin.CallbackModule()
    result = callback_plugin.Result()
    a.v2_runner_on_unreachable(result)

# Generated at 2022-06-11 13:31:35.371219
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    my_class = CallbackModule()
    my_class._display.verbosity = 1
    print("Test case 1: STARTED = [1,2,3] FINISHED = [1,2]")
    result = Mock()
    result._result = {'started': "[1,2,3]", 'finished': "[1,2]"}
    result._host = Mock()
    result._host.get_name = Mock(return_value = "MyHost")
    my_class.v2_runner_on_async_poll(result)
    print("")
    print("Test case 2: STARTED = [1,2,3] FINISHED = [1,2,3]")
    result = Mock()

# Generated at 2022-06-11 13:31:37.987079
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    cb = CallbackModule();
    cb.v2_runner_on_failed()



# Generated at 2022-06-11 13:31:48.418719
# Unit test for method v2_playbook_on_start of class CallbackModule

# Generated at 2022-06-11 13:31:54.603418
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    test = dict(result = dict(
      _host = dict(
        get_name = lambda self: "hostname"
      ),
      _task = dict(
        action = "action",
      ),
      _result = dict(
        changed = False,
      ),
    ))
    cb = CallbackModule()
    cb.v2_runner_item_on_ok(test['result'])

    # Test output format
    # TODO


# Generated at 2022-06-11 13:31:58.990598
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    print("Test: test_CallbackModule_set_options")
    # Check that the method prints its arguments
    with patch('sys.stdout', new=StringIO()) as fake_out:
        CallbackModule().set_options()
        assert fake_out.getvalue() == """No arguments parsed.
"""

# Generated at 2022-06-11 13:32:07.233613
# Unit test for method v2_runner_item_on_ok of class CallbackModule
def test_CallbackModule_v2_runner_item_on_ok():
    # Test if the display method is called when the class is instanciated
        callback = CallbackModule()
        #Test if the display method is called with the correct parameters 
        #when the 'v2_runner_item_on_ok' method is called
        callback.display = MagicMock()
        callback.v2_runner_item_on_ok(MagicMock())
        callback.display.assert_called_with('ok: [localhost] => (item=MagicMock) => {}', color=u'green')

 

# Generated at 2022-06-11 13:32:11.538176
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    module = CallbackModule()
    fake_playbook = FakePlaybook()
    module.v2_playbook_on_start(fake_playbook)

if __name__ == '__main__':
    test_CallbackModule_v2_playbook_on_start()

# Generated at 2022-06-11 13:32:12.527742
# Unit test for method set_options of class CallbackModule
def test_CallbackModule_set_options():
    pass


# Generated at 2022-06-11 13:32:29.483330
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    result = object
    callback = CallbackModule()
    callback.v2_runner_on_async_ok(result)


# Generated at 2022-06-11 13:32:39.433985
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook import Play
    from ansible.playbook.play import PlayContext
    from ansible.playbook.included_file import IncludedFile
    import pprint
    from ansible.utils.color import stringc
    
    
    options = namedtuple('Options', ['host_key_checking'])
    options.host_key_checking = False
    loader = DataLoader()
    variable_manager = VariableManager()
    passwords = {}
    

# Generated at 2022-06-11 13:32:49.814850
# Unit test for method v2_runner_item_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_item_on_failed():
    try:
        result = dict()
        result['_task'] = dict()
        result['_task']['action'] = 'test'
        result['_result'] = {"failed": False, "parsed": True, "item": "", "changed": False}
        result['_host'] = dict()
        result['_host']['name'] = 'test'
        testCallbackModule = CallbackModule()
        assert testCallbackModule.v2_runner_item_on_failed(result) == None
    except Exception as e:
        print(e)
        return False
    return True  

if __name__ == '__main__':
    test_CallbackModule_v2_runner_item_on_failed()
    print('Test success.')

# Generated at 2022-06-11 13:32:56.825175
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    # Setup
    callback_plugin = CallbackModule()
    handler = Handler()
    host = Host()

    # Exercise
    callback_plugin.v2_playbook_on_notify(handler, host)

    # Verify
    expected = ('NOTIFIED HANDLER {} for {}'.format(handler.get_name(), host))
    assert expected in callback_plugin.results

    # Cleanup - none necessary




# Generated at 2022-06-11 13:33:05.806266
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    # Testing for scenario where jid is not present in result in method v2_runner_on_async_failed of class CallbackModule
    # Not a real test - only prints out log messages.
    #######################################################################################################################

    # Setup mock ansible host
    host = MagicMock()
    host.get_name.return_value = 'test_host'

    # Setup mock ansible resul
    result = MagicMock()
    result._host = host

    #result._result = {'async_result': {'ansible_job_id': '1'}}

    # Setup printed log message
    expected = 'ASYNC FAILED on test_host: jid=1'

    # Instantiate mock ansible display
    display = MagicMock()
    display.display.return_value = None

    # Set up callback

# Generated at 2022-06-11 13:33:11.883211
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    capfd, logs = capsys.readouterr()
    # Define a class instance and feed it with (made-up) data
    my_obj = CallbackModule()
    my_obj.v2_runner_on_async_failed(result)
    # Capture what is printed to stdout
    out, err = capfd.readouterr()
    # Test-specific assertations go here
    assert out == "expected output"

# Generated at 2022-06-11 13:33:17.387240
# Unit test for method v2_runner_on_async_ok of class CallbackModule
def test_CallbackModule_v2_runner_on_async_ok():
    obj = CallbackModule()
    mock_result = MagicMock()
    mock_result._host = 'Host'
    mock_result._result = {'ansible_job_id': 'Job id'}
    
    obj.v2_runner_on_async_ok(mock_result)
    assert obj.verbose == 0



# Generated at 2022-06-11 13:33:22.213387
# Unit test for method v2_runner_on_async_poll of class CallbackModule
def test_CallbackModule_v2_runner_on_async_poll():
    module = CallbackModule()
    result = dict()
    result['ansible_job_id'] = 2
    result['started'] = 3
    result['finished'] = 4
    host = dict()
    host["name"] = "test_host"
    module.v2_runner_on_async_poll(result, host)


# Generated at 2022-06-11 13:33:27.656244
# Unit test for method v2_runner_on_unreachable of class CallbackModule
def test_CallbackModule_v2_runner_on_unreachable():
    '''
    This is a unit test for method "v2_runner_on_unreachable" of the
    AnsibleCallback module
    '''
    cb = CallbackModule()
    result = Mock()
    result._host.get_name.return_value = 'host'
    cb.v2_runner_on_unreachable(result)
    assert result.called

# Generated at 2022-06-11 13:33:38.819813
# Unit test for method v2_playbook_on_notify of class CallbackModule
def test_CallbackModule_v2_playbook_on_notify():
    from collections import namedtuple
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import merge_hash
    from ansible.utils.vars import combine_vars

# Generated at 2022-06-11 13:34:09.316970
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    # Set options
    try:
        Options.display_ok_hosts = False
        Options.display_skipped_hosts = False
        Options.show_custom_stats = False
        Options.check_mode_markers = False
    except Exception as e:
        raise Exception(e)
    # Set display
    try:
        Display.verbosity = 0
    except Exception as e:
        raise Exception(e)
    # Instantiate CallbackModule
    try:
        cb = CallbackModule()
    except Exception as e:
        raise Exception(e)

    # Check for correct behavior

# Generated at 2022-06-11 13:34:10.116053
# Unit test for method v2_playbook_on_play_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_play_start():
    pass

# Generated at 2022-06-11 13:34:15.536352
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    callback = CallbackModule()
    result = AnsibleResult()
    result_task_name = 'dummy_task_name'
    result._task = result_task_name
    result.task_name = result_task_name
    result._result = {'attempts': 2, 'retries': 5}
    callback.v2_runner_retry(result)
    assert True

# Generated at 2022-06-11 13:34:22.732025
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
  cbm = CallbackModule()
  def test_v2_playbook_on_include(cbm):
    filename = 'test_filename'
    hosts = ['test_host_1', 'test_host_2']
    vars = {'test_key_1': 'test_value_1', 'test_key_2': 'test_value_2'}

    test_included_file = types.SimpleNamespace()
    test_included_file._filename = filename
    test_included_file._hosts = hosts
    test_included_file._vars = vars

    orig_get_item_label = cbm._get_item_label
    cbm._get_item_label = lambda *args, **kwargs: 'test_label'

    orig_display = cbm._display.display
    c

# Generated at 2022-06-11 13:34:27.263358
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    cb = CallbackModule()
    result = type('Result', (object,), {})
    setattr(result, 'task_name', 'test')
    setattr(result, '_task', 'test')
    result._result = {'retries': 1, 'attempts': 1}
    cb.v2_runner_retry(result)

# Generated at 2022-06-11 13:34:32.409922
# Unit test for method v2_runner_on_async_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_async_failed():
    class FakeResult:
        def __init__(self):
            self._host = "fakehost"
            self._result = {"ansible_job_id": "fakejobid"}
    result = FakeResult()
    callback_module = CallbackModule()
    callback_module._display.display = lambda msg: msg
    # Call the method
    callback_module.v2_runner_on_async_failed(result)

# Generated at 2022-06-11 13:34:41.842863
# Unit test for method v2_runner_item_on_ok of class CallbackModule

# Generated at 2022-06-11 13:34:45.469671
# Unit test for method v2_playbook_on_start of class CallbackModule
def test_CallbackModule_v2_playbook_on_start():
    """
      Tests `CallbackModule.v2_playbook_on_start`.
    """
    # Should have no error if no `playbook` is provided
    # Arrange
    cbm = CallbackModule()
    # Act
    cbm.v2_playbook_on_start(None)
    # Assert
    assert True
test_CallbackModule_v2_playbook_on_start()


# Generated at 2022-06-11 13:34:53.220199
# Unit test for method v2_runner_on_failed of class CallbackModule
def test_CallbackModule_v2_runner_on_failed():
    # Create instance of class under test
    cb = CallbackModule(display=Display())
    # Create mock object
    result = Mock()
    result._task = Mock()
    result._result = dict()
    result._task.action = "shell"
    # Run method
    cb.v2_runner_on_failed(result)
    # Get 'calls' variable from mock object
    _v2_runner_on_failed_calls = result._display.error.mock_calls
    # Check calls to mock object
    assert len(_v2_runner_on_failed_calls) == 1

# Generated at 2022-06-11 13:35:04.652020
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    from ansible.plugins.callback import CallbackModule
    from ansible.template import Templar
    from __main__ import display
    from ansible.vars.manager import VariableManager
    from ansible.vars import Variable
    import unittest

    class Dummy(unittest.TestCase):
        def setUp(self):
            self.display = display
            self.runner_on_skipped = CallbackModule()
            self.runner_on_skipped.set_options({'display_skipped_hosts': True, 'display_ok_hosts': False})
            self.runner_on_skipped.set_play_context({'verbosity': 2})
            self.runner_on_skipped.play = MagicMock()
            self.runner_on_skipped.play._ds = {'verbosity': 2}

# Generated at 2022-06-11 13:35:27.257613
# Unit test for method v2_playbook_on_include of class CallbackModule
def test_CallbackModule_v2_playbook_on_include():
	playbook = Mock(get_name=Mock(return_value='{{ playbook_name }}'))
	callback = CallbackModule()
	callback.v2_playbook_on_include(playbook)


# Generated at 2022-06-11 13:35:37.326588
# Unit test for method v2_runner_retry of class CallbackModule
def test_CallbackModule_v2_runner_retry():
    # Create an instance of CallbackModule with default arguments
    obj = CallbackModule()
    # Create an instance of __main__.Result for obj.v2_runner_retry()
    # Mock attributes for the instance of __main__.Result
    result = create_autospec(Result)
    result.task_name = False
    result._task = False
    result._host.get_name.return_value = False
    result._result['retries'] = True
    result._result['attempts'] = True
    # Call method v2_runner_retry of CallbackModule with arguments
    # result
    return_value = obj.v2_runner_retry(result)
    # Assert return_value is None
    assert return_value is None


# Generated at 2022-06-11 13:35:45.801952
# Unit test for method v2_runner_on_skipped of class CallbackModule
def test_CallbackModule_v2_runner_on_skipped():
    # Test with display_skipped_hosts set to 1, 0 and -1
    # The result should be the same irrespective
    # of the setting of display_skipped_hosts
    host_modules=['main', 'other']