

# Generated at 2022-06-18 02:06:23.066078
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return not is_even(value)

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return not is_positive(value)

    def is_zero(value):
        return value == 0

    def is_not_zero(value):
        return not is_zero(value)

    def is_zero_or_positive(value):
        return is_zero(value) or is_positive(value)

    def is_zero_or_negative(value):
        return is_zero(value) or is_negative(value)

    def is_zero_or_even(value):
        return is_zero(value) or is_even(value)


# Generated at 2022-06-18 02:06:26.507274
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4]) == [2, 4]



# Generated at 2022-06-18 02:06:37.482505
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]

# Generated at 2022-06-18 02:06:38.743429
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-18 02:06:41.157336
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 2) == 2
    assert find([1, 2, 3, 4], lambda x: x == 5) is None



# Generated at 2022-06-18 02:06:52.266094
# Unit test for function cond
def test_cond():
    def is_even(x):
        return x % 2 == 0

    def is_odd(x):
        return x % 2 != 0

    def is_positive(x):
        return x > 0

    def is_negative(x):
        return x < 0

    def is_zero(x):
        return x == 0

    def double(x):
        return x * 2

    def triple(x):
        return x * 3

    def quadruple(x):
        return x * 4

    def quintuple(x):
        return x * 5

    def sextuple(x):
        return x * 6

    def septuple(x):
        return x * 7

    def octuple(x):
        return x * 8

    def nonuple(x):
        return x * 9


# Generated at 2022-06-18 02:06:55.765579
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-18 02:07:02.215763
# Unit test for function memoize
def test_memoize():
    @memoize
    def factorial(n):
        if n == 0:
            return 1
        return n * factorial(n - 1)

    assert factorial(5) == 120
    assert factorial(4) == 24
    assert factorial(3) == 6
    assert factorial(2) == 2
    assert factorial(1) == 1
    assert factorial(0) == 1



# Generated at 2022-06-18 02:07:07.969044
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b, c: a + b + c)(1)(2)(3) == 6
    assert curry(lambda a, b, c: a + b + c)(1, 2)(3) == 6
    assert curry(lambda a, b, c: a + b + c)(1)(2, 3) == 6
    assert curry(lambda a, b, c: a + b + c)(1, 2, 3) == 6



# Generated at 2022-06-18 02:07:14.336342
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6]) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6]) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6]) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6]) == [2, 4, 6]


# Generated at 2022-06-18 02:07:23.279920
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-18 02:07:26.151783
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda x: x == 6) is None



# Generated at 2022-06-18 02:07:33.388583
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]
    assert curried_map(lambda x: x + 1)([1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]



# Generated at 2022-06-18 02:07:40.940245
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6



# Generated at 2022-06-18 02:07:50.716346
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b, c: a + b + c)(1)(2)(3) == 6
    assert curry(lambda a, b, c: a + b + c)(1, 2)(3) == 6
    assert curry(lambda a, b, c: a + b + c)(1, 2, 3) == 6
    assert curry(lambda a, b, c: a + b + c, 2)(1, 2)(3) == 6
    assert curry(lambda a, b, c: a + b + c, 2)(1)(2, 3) == 6
    assert curry(lambda a, b, c: a + b + c, 2)(1, 2, 3) == 6
    assert curry(lambda a, b, c: a + b + c, 3)(1, 2, 3) == 6

# Generated at 2022-06-18 02:07:57.923053
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6]) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6]) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6]) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6]) == [2, 4, 6]


# Generated at 2022-06-18 02:08:06.703211
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
    assert curried_map(increase)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 3, 4, 5, 6, 7, 8, 9, 10, 11]



# Generated at 2022-06-18 02:08:14.122675
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3])

# Generated at 2022-06-18 02:08:16.364544
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)



# Generated at 2022-06-18 02:08:17.796354
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-18 02:08:38.459565
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def is_zero(value):
        return value == 0

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    def is_zero_or_positive(value):
        return value >= 0

    def is_zero_or_negative(value):
        return value <= 0

    def is_zero_or_even(value):
        return value == 0 or value % 2 == 0

    def is_zero_or_odd(value):
        return value == 0 or value % 2 != 0

    def is_positive_or_even(value):
        return value > 0 or value % 2 == 0


# Generated at 2022-06-18 02:08:41.042956
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4], lambda x: x == 5) is None



# Generated at 2022-06-18 02:08:49.639564
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]

# Generated at 2022-06-18 02:08:54.688561
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    def is_zero(value):
        return value == 0

    def is_zero_or_positive(value):
        return value >= 0

    def is_zero_or_negative(value):
        return value <= 0

    def is_one(value):
        return value == 1

    def is_two(value):
        return value == 2

    def is_three(value):
        return value == 3

    def is_four(value):
        return value == 4

    def is_five(value):
        return value == 5


# Generated at 2022-06-18 02:09:04.710467
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-18 02:09:11.772552
# Unit test for function cond
def test_cond():
    def is_even(x):
        return x % 2 == 0

    def is_odd(x):
        return not is_even(x)

    def is_positive(x):
        return x > 0

    def is_negative(x):
        return x < 0

    def is_zero(x):
        return x == 0

    def is_not_zero(x):
        return not is_zero(x)

    def is_zero_or_positive(x):
        return is_zero(x) or is_positive(x)

    def is_zero_or_negative(x):
        return is_zero(x) or is_negative(x)

    def is_zero_or_even(x):
        return is_zero(x) or is_even(x)


# Generated at 2022-06-18 02:09:21.277336
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]
    assert curried_map(increase)([1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]
    assert curried_map(increase, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 3, 4, 5, 6, 7, 8, 9, 10, 11]

# Generated at 2022-06-18 02:09:25.128731
# Unit test for function memoize
def test_memoize():
    def fib(n):
        if n < 2:
            return n
        return fib(n - 1) + fib(n - 2)

    fib = memoize(fib)
    assert fib(10) == 55
    assert fib(10) == 55



# Generated at 2022-06-18 02:09:27.489011
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-18 02:09:30.542814
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda x: x == 6) is None



# Generated at 2022-06-18 02:09:46.599125
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]


# Generated at 2022-06-18 02:09:49.834837
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda x: x == 6) is None


# Generated at 2022-06-18 02:09:54.231919
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-18 02:10:05.825602
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4]) == [3, 4]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4, 5]) == [3, 4, 5]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4, 5, 6]) == [3, 4, 5, 6]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4, 5, 6, 7]) == [3, 4, 5, 6, 7]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4, 5, 6, 7, 8]) == [3, 4, 5, 6, 7, 8]

# Generated at 2022-06-18 02:10:07.507738
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-18 02:10:13.394078
# Unit test for function memoize
def test_memoize():
    def add(x):
        return x + 1

    memoized_add = memoize(add)
    assert memoized_add(1) == 2
    assert memoized_add(1) == 2
    assert memoized_add(2) == 3
    assert memoized_add(2) == 3
    assert memoized_add(1) == 2
    assert memoized_add(2) == 3



# Generated at 2022-06-18 02:10:21.633421
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]

# Generated at 2022-06-18 02:10:32.070127
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]

# Generated at 2022-06-18 02:10:34.951252
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-18 02:10:42.336308
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1, '1')
    assert not eq(1, None)
    assert not eq(None, 1)
    assert eq(None, None)
    assert eq('1', '1')
    assert not eq('1', '2')
    assert not eq('1', 1)
    assert not eq('1', None)
    assert not eq(None, '1')
    assert eq(None, None)
    assert eq(True, True)
    assert not eq(True, False)
    assert not eq(True, 1)
    assert not eq(True, '1')
    assert not eq(True, None)
    assert not eq(None, True)
    assert eq(None, None)
    assert eq(False, False)
   

# Generated at 2022-06-18 02:11:09.715026
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    add_memoized = memoize(add)

    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3

    assert add_memoized(2, 3) == 5
    assert add_memoized(2, 3) == 5
    assert add_memoized(2, 3) == 5
    assert add_memoized(2, 3) == 5



# Generated at 2022-06-18 02:11:16.272990
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-18 02:11:22.404066
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1, '1')
    assert not eq(1, None)
    assert not eq(None, 1)
    assert eq(None, None)
    assert eq('1', '1')
    assert not eq('1', '2')
    assert not eq('1', 1)
    assert not eq('1', None)
    assert not eq(None, '1')
    assert eq(None, None)



# Generated at 2022-06-18 02:11:24.993406
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda x: x == 10) is None



# Generated at 2022-06-18 02:11:33.851919
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3])

# Generated at 2022-06-18 02:11:39.837602
# Unit test for function cond
def test_cond():
    def is_even(x):
        return x % 2 == 0

    def is_odd(x):
        return x % 2 != 0

    def is_zero(x):
        return x == 0

    def is_positive(x):
        return x > 0

    def is_negative(x):
        return x < 0

    def is_zero_or_negative(x):
        return x <= 0

    def is_zero_or_positive(x):
        return x >= 0

    def is_zero_or_even(x):
        return x == 0 or x % 2 == 0

    def is_zero_or_odd(x):
        return x == 0 or x % 2 != 0

    def is_positive_or_even(x):
        return x > 0 and x % 2 == 0


# Generated at 2022-06-18 02:11:44.952941
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0)([1, 3, 5, 7]) == []
    assert curried_filter(lambda x: x % 2 == 0)([2, 4, 6, 8]) == [2, 4, 6, 8]



# Generated at 2022-06-18 02:11:55.578339
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(2, 2) == 4
    assert memoized_add(2, 2) == 4
    assert memoized_add(2, 2) == 4
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(2, 2) == 4
    assert memoized_add(2, 2) == 4
    assert memoized_add(2, 2) == 4
    assert memoized

# Generated at 2022-06-18 02:11:59.251891
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-18 02:12:07.858999
# Unit test for function cond
def test_cond():
    def is_even(number: int) -> bool:
        return number % 2 == 0

    def is_odd(number: int) -> bool:
        return number % 2 == 1

    def is_zero(number: int) -> bool:
        return number == 0

    def is_positive(number: int) -> bool:
        return number > 0

    def is_negative(number: int) -> bool:
        return number < 0

    def is_one(number: int) -> bool:
        return number == 1

    def is_two(number: int) -> bool:
        return number == 2

    def is_three(number: int) -> bool:
        return number == 3

    def is_four(number: int) -> bool:
        return number == 4


# Generated at 2022-06-18 02:13:03.322013
# Unit test for function cond
def test_cond():
    def is_even(x):
        return x % 2 == 0

    def is_odd(x):
        return x % 2 == 1

    def is_positive(x):
        return x > 0

    def is_negative(x):
        return x < 0

    def is_zero(x):
        return x == 0

    def is_one(x):
        return x == 1

    def is_two(x):
        return x == 2

    def is_three(x):
        return x == 3

    def is_four(x):
        return x == 4

    def is_five(x):
        return x == 5

    def is_six(x):
        return x == 6

    def is_seven(x):
        return x == 7

    def is_eight(x):
        return x == 8



# Generated at 2022-06-18 02:13:08.362674
# Unit test for function curry
def test_curry():
    def add(a, b, c):
        return a + b + c

    assert curry(add)(1)(2)(3) == 6
    assert curry(add, 2)(1, 2)(3) == 6
    assert curry(add, 3)(1, 2, 3) == 6
    assert curry(add, 4)(1, 2, 3, 4) == 10



# Generated at 2022-06-18 02:13:10.552561
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)



# Generated at 2022-06-18 02:13:12.973505
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 2) == 2
    assert find([1, 2, 3, 4], lambda x: x == 5) is None



# Generated at 2022-06-18 02:13:18.530515
# Unit test for function cond
def test_cond():
    def is_even(x):
        return x % 2 == 0

    def is_odd(x):
        return x % 2 == 1

    def is_positive(x):
        return x > 0

    def is_negative(x):
        return x < 0

    def is_zero(x):
        return x == 0

    def increase(x):
        return x + 1

    def decrease(x):
        return x - 1

    def zero(x):
        return 0

    def test_function(x):
        return cond([
            (is_even, increase),
            (is_odd, decrease),
            (is_positive, zero),
            (is_negative, zero),
            (is_zero, zero),
        ])(x)

    assert test_function(1) == 0

# Generated at 2022-06-18 02:13:20.542510
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(2)) == 2
    assert find([1, 2, 3], eq(4)) is None



# Generated at 2022-06-18 02:13:30.758243
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized

# Generated at 2022-06-18 02:13:33.708616
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x % 2 == 0) == 2
    assert find([1, 2, 3, 4], lambda x: x % 2 == 1) == 1
    assert find([1, 2, 3, 4], lambda x: x == 5) is None



# Generated at 2022-06-18 02:13:44.466936
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def is_zero(value):
        return value == 0

    def is_negative(value):
        return value < 0

    def is_positive(value):
        return value > 0

    def is_zero_or_negative(value):
        return value <= 0

    def is_zero_or_positive(value):
        return value >= 0

    def is_one(value):
        return value == 1

    def is_two(value):
        return value == 2

    def is_three(value):
        return value == 3

    def is_four(value):
        return value == 4

    def is_five(value):
        return value == 5


# Generated at 2022-06-18 02:13:46.733838
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1, '1')
    assert not eq(1, None)



# Generated at 2022-06-18 02:15:39.299834
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-18 02:15:44.638418
# Unit test for function memoize
def test_memoize():
    def add(x):
        return x + 1

    memoized_add = memoize(add)

    assert memoized_add(1) == 2
    assert memoized_add(1) == 2
    assert memoized_add(2) == 3
    assert memoized_add(2) == 3
    assert memoized_add(1) == 2



# Generated at 2022-06-18 02:15:49.129528
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4, 5]) == [3, 4, 5]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4, 5]) == [3, 4, 5]
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4, 5]) == [3, 4, 5]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4, 5]) == [3, 4, 5]


# Generated at 2022-06-18 02:15:53.215725
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)
    assert eq(1, 1, 1)
    assert not eq(1, 1, 2)



# Generated at 2022-06-18 02:15:59.543442
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 1) == 1
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 3) == 3
    assert find([1, 2, 3], lambda x: x == 4) is None
    assert find([1, 2, 3], lambda x: x == 5) is None
    assert find([1, 2, 3], lambda x: x == 6) is None



# Generated at 2022-06-18 02:16:05.683678
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6]) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6]) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6]) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6]) == [2, 4, 6]


# Generated at 2022-06-18 02:16:10.816438
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6

