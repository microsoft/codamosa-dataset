

# Generated at 2022-06-18 02:06:24.721114
# Unit test for function memoize
def test_memoize():
    def add(x, y):
        return x + y

    add_memoized = memoize(add)
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memo

# Generated at 2022-06-18 02:06:35.447137
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)
    assert eq(1, 1, 1)
    assert not eq(1, 1, 2)
    assert eq(1, 1, 1, 1)
    assert not eq(1, 1, 1, 2)
    assert eq(1, 1, 1, 1, 1)
    assert not eq(1, 1, 1, 1, 2)
    assert eq(1, 1, 1, 1, 1, 1)
    assert not eq(1, 1, 1, 1, 1, 2)
    assert eq(1, 1, 1, 1, 1, 1, 1)
    assert not eq(1, 1, 1, 1, 1, 1, 2)

# Generated at 2022-06-18 02:06:41.509383
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 1) == 1
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 3) == 3
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-18 02:06:51.940368
# Unit test for function memoize
def test_memoize():
    def test_function(argument):
        return argument + 1

    memoized_test_function = memoize(test_function)

    assert memoized_test_function(1) == 2
    assert memoized_test_function(1) == 2
    assert memoized_test_function(2) == 3
    assert memoized_test_function(2) == 3
    assert memoized_test_function(1) == 2
    assert memoized_test_function(2) == 3
    assert memoized_test_function(3) == 4
    assert memoized_test_function(3) == 4
    assert memoized_test_function(1) == 2
    assert memoized_test_function(2) == 3
    assert memoized_test_function(3) == 4



# Generated at 2022-06-18 02:06:56.977694
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)



# Generated at 2022-06-18 02:07:04.947053
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)
    assert eq(1, 1, 1)
    assert not eq(1, 1, 2)
    assert eq(1)(1)(1)
    assert not eq(1)(1)(2)
    assert eq(1, 1, 1, 1)
    assert not eq(1, 1, 1, 2)
    assert eq(1)(1)(1)(1)
    assert not eq(1)(1)(1)(2)



# Generated at 2022-06-18 02:07:13.693061
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized

# Generated at 2022-06-18 02:07:17.025354
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda x: x == 10) is None



# Generated at 2022-06-18 02:07:26.112977
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-18 02:07:28.042371
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4]) == [2, 4]



# Generated at 2022-06-18 02:07:44.339838
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]

# Generated at 2022-06-18 02:07:50.221822
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x == 1, lambda x: x + 1),
        (lambda x: x == 2, lambda x: x + 2),
        (lambda x: x == 3, lambda x: x + 3),
    ])(1) == 2
    assert cond([
        (lambda x: x == 1, lambda x: x + 1),
        (lambda x: x == 2, lambda x: x + 2),
        (lambda x: x == 3, lambda x: x + 3),
    ])(2) == 4
    assert cond([
        (lambda x: x == 1, lambda x: x + 1),
        (lambda x: x == 2, lambda x: x + 2),
        (lambda x: x == 3, lambda x: x + 3),
    ])(3) == 6



# Generated at 2022-06-18 02:07:59.006514
# Unit test for function cond
def test_cond():
    def is_even(x):
        return x % 2 == 0

    def is_odd(x):
        return x % 2 == 1

    def is_zero(x):
        return x == 0

    def is_positive(x):
        return x > 0

    def is_negative(x):
        return x < 0

    def is_zero_or_positive(x):
        return x >= 0

    def is_zero_or_negative(x):
        return x <= 0

    def is_one(x):
        return x == 1

    def is_two(x):
        return x == 2

    def is_three(x):
        return x == 3

    def is_four(x):
        return x == 4

    def is_five(x):
        return x == 5


# Generated at 2022-06-18 02:08:02.989983
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-18 02:08:05.335884
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)



# Generated at 2022-06-18 02:08:07.986074
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 2) == 2
    assert find([1, 2, 3, 4], lambda x: x == 5) is None



# Generated at 2022-06-18 02:08:15.084259
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 == 1

    def is_zero(value):
        return value == 0

    def is_one(value):
        return value == 1

    def is_two(value):
        return value == 2

    def is_three(value):
        return value == 3

    def is_four(value):
        return value == 4

    def is_five(value):
        return value == 5

    def is_six(value):
        return value == 6

    def is_seven(value):
        return value == 7

    def is_eight(value):
        return value == 8

    def is_nine(value):
        return value == 9

    def is_ten(value):
        return value == 10



# Generated at 2022-06-18 02:08:16.644421
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-18 02:08:18.215657
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4], lambda x: x == 5) is None



# Generated at 2022-06-18 02:08:24.451830
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-18 02:08:40.713652
# Unit test for function cond
def test_cond():
    def is_even(x):
        return x % 2 == 0

    def is_odd(x):
        return x % 2 == 1

    def is_zero(x):
        return x == 0

    def is_positive(x):
        return x > 0

    def is_negative(x):
        return x < 0

    def is_zero_or_positive(x):
        return x >= 0

    def is_zero_or_negative(x):
        return x <= 0

    def is_one(x):
        return x == 1

    def is_two(x):
        return x == 2

    def is_three(x):
        return x == 3

    def is_four(x):
        return x == 4

    def is_five(x):
        return x == 5


# Generated at 2022-06-18 02:08:49.484272
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def is_zero(value):
        return value == 0

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    def is_zero_or_positive(value):
        return is_zero(value) or is_positive(value)

    def is_zero_or_negative(value):
        return is_zero(value) or is_negative(value)

    def is_zero_or_even(value):
        return is_zero(value) or is_even(value)

    def is_zero_or_odd(value):
        return is_zero(value) or is_odd(value)


# Generated at 2022-06-18 02:08:59.417767
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq(1, 1, 1) == True
    assert eq(1, 1, 2) == False
    assert eq(1, 1, 1, 1) == True
    assert eq(1, 1, 1, 2) == False
    assert eq(1, 1, 1, 1, 1) == True
    assert eq(1, 1, 1, 1, 2) == False
    assert eq(1, 1, 1, 1, 1, 1) == True
    assert eq(1, 1, 1, 1, 1, 2) == False
    assert eq(1, 1, 1, 1, 1, 1, 1) == True
    assert eq(1, 1, 1, 1, 1, 1, 2) == False

# Generated at 2022-06-18 02:09:05.833822
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-18 02:09:08.851341
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-18 02:09:12.765299
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-18 02:09:21.959239
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def is_zero(value):
        return value == 0

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    def is_zero_or_positive(value):
        return is_zero(value) or is_positive(value)

    def is_zero_or_negative(value):
        return is_zero(value) or is_negative(value)

    def is_zero_or_even(value):
        return is_zero(value) or is_even(value)

    def is_zero_or_odd(value):
        return is_zero(value) or is_odd(value)


# Generated at 2022-06-18 02:09:28.150966
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5]) == [2, 4]



# Generated at 2022-06-18 02:09:30.324303
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-18 02:09:42.056916
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]

# Generated at 2022-06-18 02:10:07.677247
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return not is_even(value)

    def is_zero(value):
        return value == 0

    def is_one(value):
        return value == 1

    def is_two(value):
        return value == 2

    def is_three(value):
        return value == 3

    def is_four(value):
        return value == 4

    def is_five(value):
        return value == 5

    def is_six(value):
        return value == 6

    def is_seven(value):
        return value == 7

    def is_eight(value):
        return value == 8

    def is_nine(value):
        return value == 9


# Generated at 2022-06-18 02:10:10.175322
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4]) == [3, 4]



# Generated at 2022-06-18 02:10:12.140506
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)


# Generated at 2022-06-18 02:10:20.374766
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return not is_even(value)

    def is_zero(value):
        return value == 0

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    def is_zero_or_positive(value):
        return is_zero(value) or is_positive(value)

    def is_zero_or_negative(value):
        return is_zero(value) or is_negative(value)

    def is_positive_or_negative(value):
        return is_positive(value) or is_negative(value)

    def is_zero_or_even(value):
        return is_zero(value) or is_even(value)


# Generated at 2022-06-18 02:10:31.059033
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3])

# Generated at 2022-06-18 02:10:40.414428
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3])

# Generated at 2022-06-18 02:10:49.380420
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return not is_even(value)

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    def is_zero(value):
        return value == 0

    def get_even(value):
        return 'even'

    def get_odd(value):
        return 'odd'

    def get_positive(value):
        return 'positive'

    def get_negative(value):
        return 'negative'

    def get_zero(value):
        return 'zero'

    assert cond([
        (is_even, get_even),
        (is_odd, get_odd),
    ])(2) == 'even'


# Generated at 2022-06-18 02:10:54.366067
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3])([4, 5, 6]) == [2, 3, 4, 5, 6, 7]
    assert curried_map(increase)([1, 2, 3])([4, 5, 6]) == [2, 3, 4, 5, 6, 7]
    assert curried_map(increase)([1, 2, 3])([4, 5, 6])([7, 8, 9]) == [2, 3, 4, 5, 6, 7, 8, 9, 10]


# Generated at 2022-06-18 02:10:57.324080
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-18 02:11:07.152959
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4]) == [3, 4]
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4]) == [3, 4]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4]) == [3, 4]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4]) == [3, 4]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4]) == [3, 4]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4]) == [3, 4]

# Generated at 2022-06-18 02:11:44.146429
# Unit test for function memoize
def test_memoize():
    def add(x):
        return x + 1

    memoized_add = memoize(add)
    assert memoized_add(1) == 2
    assert memoized_add(1) == 2
    assert memoized_add(2) == 3
    assert memoized_add(2) == 3
    assert memoized_add(1) == 2
    assert memoized_add(2) == 3



# Generated at 2022-06-18 02:11:54.482234
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]

# Generated at 2022-06-18 02:12:03.645385
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3])

# Generated at 2022-06-18 02:12:07.567167
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-18 02:12:16.899601
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized

# Generated at 2022-06-18 02:12:18.024265
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4], lambda x: x == 5) is None



# Generated at 2022-06-18 02:12:20.026241
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)



# Generated at 2022-06-18 02:12:27.610287
# Unit test for function cond
def test_cond():
    def is_even(x):
        return x % 2 == 0

    def is_odd(x):
        return x % 2 != 0

    def is_zero(x):
        return x == 0

    def is_positive(x):
        return x > 0

    def is_negative(x):
        return x < 0

    def is_zero_or_positive(x):
        return x >= 0

    def is_zero_or_negative(x):
        return x <= 0

    def is_one(x):
        return x == 1

    def is_two(x):
        return x == 2

    def is_three(x):
        return x == 3

    def is_four(x):
        return x == 4

    def is_five(x):
        return x == 5


# Generated at 2022-06-18 02:12:30.015766
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-18 02:12:37.231410
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 == 1

    def is_zero(value):
        return value == 0

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    def is_zero_or_positive(value):
        return value >= 0

    def is_zero_or_negative(value):
        return value <= 0

    def is_one(value):
        return value == 1

    def is_two(value):
        return value == 2

    def is_three(value):
        return value == 3

    def is_four(value):
        return value == 4

    def is_five(value):
        return value == 5


# Generated at 2022-06-18 02:13:53.134351
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1, '1')



# Generated at 2022-06-18 02:13:56.238855
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    add_memoized = memoize(add)

    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3



# Generated at 2022-06-18 02:14:04.953117
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]



# Generated at 2022-06-18 02:14:12.709240
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def is_zero(value):
        return value == 0

    def double(value):
        return value * 2

    def triple(value):
        return value * 3

    def quadruple(value):
        return value * 4

    def quintuple(value):
        return value * 5

    def sextuple(value):
        return value * 6

    def septuple(value):
        return value * 7

    def octuple(value):
        return value * 8

    def nonuple(value):
        return value * 9

    def decuple(value):
        return value * 10

    def undecuple(value):
        return value * 11


# Generated at 2022-06-18 02:14:15.273325
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)

    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(2, 3) == 5
    assert memoized_add(2, 3) == 5
    assert memoized_add(1, 2) == 3



# Generated at 2022-06-18 02:14:24.581919
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]

# Generated at 2022-06-18 02:14:32.763924
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)

    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized

# Generated at 2022-06-18 02:14:35.691028
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)



# Generated at 2022-06-18 02:14:38.453991
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)
    assert eq(1, 1, 1)
    assert not eq(1, 1, 2)



# Generated at 2022-06-18 02:14:43.747248
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 2) == 2
    assert find([1, 2, 3, 4], lambda x: x == 5) is None
    assert find([1, 2, 3, 4], lambda x: x == 1) == 1
    assert find([1, 2, 3, 4], lambda x: x == 4) == 4

