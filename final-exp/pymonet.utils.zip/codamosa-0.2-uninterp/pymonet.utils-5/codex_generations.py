

# Generated at 2022-06-18 02:06:15.442496
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)



# Generated at 2022-06-18 02:06:17.281403
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-18 02:06:23.314893
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 3) == 4
    assert memoized_add(1, 3) == 4
    assert memoized_add(1, 3) == 4
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3



# Generated at 2022-06-18 02:06:28.430050
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6



# Generated at 2022-06-18 02:06:39.641846
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return not is_even(value)

    def is_zero(value):
        return value == 0

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    def is_zero_or_positive(value):
        return is_zero(value) or is_positive(value)

    def is_zero_or_negative(value):
        return is_zero(value) or is_negative(value)

    def is_zero_or_even(value):
        return is_zero(value) or is_even(value)

    def is_zero_or_odd(value):
        return is_zero(value) or is_odd(value)


# Generated at 2022-06-18 02:06:52.225987
# Unit test for function cond
def test_cond():
    def is_even(x):
        return x % 2 == 0

    def is_odd(x):
        return x % 2 != 0

    def is_positive(x):
        return x > 0

    def is_negative(x):
        return x < 0

    def is_zero(x):
        return x == 0

    def is_one(x):
        return x == 1

    def is_two(x):
        return x == 2

    def is_three(x):
        return x == 3

    def is_four(x):
        return x == 4

    def is_five(x):
        return x == 5

    def is_six(x):
        return x == 6

    def is_seven(x):
        return x == 7

    def is_eight(x):
        return x == 8



# Generated at 2022-06-18 02:07:05.122013
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3])

# Generated at 2022-06-18 02:07:09.765289
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized

# Generated at 2022-06-18 02:07:16.498758
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 0)([1, 2, 3]) == [1, 2, 3]
    assert curried_filter(lambda x: x > 0)([-1, -2, -3]) == []
    assert curried_filter(lambda x: x > 0)([]) == []
    assert curried_filter(lambda x: x > 0)([-1, 2, -3]) == [2]
    assert curried_filter(lambda x: x > 0)([-1, -2, 3]) == [3]
    assert curried_filter(lambda x: x > 0)([-1, 2, 3]) == [2, 3]
    assert curried_filter(lambda x: x > 0)([1, -2, 3]) == [1, 3]

# Generated at 2022-06-18 02:07:25.989838
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return not is_even(value)

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return not is_positive(value)

    def is_zero(value):
        return value == 0

    def is_not_zero(value):
        return not is_zero(value)

    def is_zero_or_positive(value):
        return is_zero(value) or is_positive(value)

    def is_zero_or_negative(value):
        return is_zero(value) or is_negative(value)

    def is_zero_or_even(value):
        return is_zero(value) or is_even(value)


# Generated at 2022-06-18 02:07:38.653378
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]
    assert curried_map(lambda x: x + 1)([1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]
    assert curried_map(lambda x: x + 1, [1, 2, 3, 4, 5, 6]) == [2, 3, 4, 5, 6, 7]

# Generated at 2022-06-18 02:07:44.213478
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6



# Generated at 2022-06-18 02:07:49.965464
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-18 02:07:52.069186
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4]) == [3, 4]



# Generated at 2022-06-18 02:07:58.072159
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6



# Generated at 2022-06-18 02:08:08.389307
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x == 0, lambda x: 'zero'),
        (lambda x: x % 2 == 0, lambda x: 'even'),
        (lambda x: x % 2 != 0, lambda x: 'odd')
    ])(0) == 'zero'
    assert cond([
        (lambda x: x == 0, lambda x: 'zero'),
        (lambda x: x % 2 == 0, lambda x: 'even'),
        (lambda x: x % 2 != 0, lambda x: 'odd')
    ])(2) == 'even'

# Generated at 2022-06-18 02:08:12.276611
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 3) == 4
    assert memoized_add(1, 3) == 4
    assert memoized_add(1, 2) == 3



# Generated at 2022-06-18 02:08:21.351284
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1, '1')
    assert not eq(1, None)
    assert not eq(None, 1)
    assert eq(None, None)
    assert not eq(1, [1])
    assert not eq([1], 1)
    assert eq([1], [1])
    assert not eq([1], [2])
    assert not eq([1, 2], [1])
    assert not eq([1], [1, 2])
    assert eq([1, 2], [1, 2])
    assert not eq([1, 2], [2, 1])
    assert not eq([1, 2], [1, 2, 3])
    assert not eq([1, 2, 3], [1, 2])

# Generated at 2022-06-18 02:08:32.197674
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 == 1

    def is_zero(value):
        return value == 0

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    def is_zero_or_positive(value):
        return value >= 0

    def is_zero_or_negative(value):
        return value <= 0

    def is_one(value):
        return value == 1

    def is_two(value):
        return value == 2

    def is_three(value):
        return value == 3

    def is_four(value):
        return value == 4

    def is_five(value):
        return value == 5


# Generated at 2022-06-18 02:08:35.900899
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)
    assert not eq(1, 2, 3)
    assert not eq(1)(2, 3)



# Generated at 2022-06-18 02:08:48.945450
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    def is_zero(value):
        return value == 0

    def is_not_zero(value):
        return value != 0

    def is_zero_or_positive(value):
        return value >= 0

    def is_zero_or_negative(value):
        return value <= 0

    def is_zero_or_even(value):
        return value == 0 or value % 2 == 0

    def is_zero_or_odd(value):
        return value == 0 or value % 2 != 0

    def is_positive_or_even(value):
        return

# Generated at 2022-06-18 02:08:53.046640
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 1) == 1
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 3) == 3
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-18 02:08:56.915554
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)
    assert not eq(1, 2, 3)
    assert not eq(1, 2, 3)(1, 2, 3)



# Generated at 2022-06-18 02:08:59.975401
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-18 02:09:09.392740
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def is_zero(value):
        return value == 0

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    def is_zero_or_positive(value):
        return value >= 0

    def is_zero_or_negative(value):
        return value <= 0

    def is_positive_or_negative(value):
        return value != 0

    def is_zero_or_positive_or_negative(value):
        return True

    def is_zero_or_positive_or_negative_or_even(value):
        return True


# Generated at 2022-06-18 02:09:19.487477
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 == 1

    def is_zero(value):
        return value == 0

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    def is_zero_or_positive(value):
        return value >= 0

    def is_zero_or_negative(value):
        return value <= 0

    def is_one(value):
        return value == 1

    def is_two(value):
        return value == 2

    def is_three(value):
        return value == 3

    def is_four(value):
        return value == 4

    def is_five(value):
        return value == 5


# Generated at 2022-06-18 02:09:23.406942
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)



# Generated at 2022-06-18 02:09:30.133085
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def is_zero(value):
        return value == 0

    def double(value):
        return value * 2

    def triple(value):
        return value * 3

    def identity(value):
        return value

    def test_cond_function(value):
        return cond([
            (is_even, double),
            (is_odd, triple),
            (is_zero, identity),
        ])(value)

    assert test_cond_function(0) == 0
    assert test_cond_function(1) == 3
    assert test_cond_function(2) == 4
    assert test_cond_function(3) == 9
    assert test_cond_function(4) == 8

# Generated at 2022-06-18 02:09:33.952907
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda x: x == 10) is None



# Generated at 2022-06-18 02:09:44.268888
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]

# Generated at 2022-06-18 02:09:57.719175
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6]) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6]) == [2, 4, 6]


# Generated at 2022-06-18 02:10:00.597585
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 2) == 2
    assert find([1, 2, 3, 4], lambda x: x == 5) is None



# Generated at 2022-06-18 02:10:07.103179
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(2, 3) == 5
    assert memoized_add(2, 3) == 5
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3



# Generated at 2022-06-18 02:10:08.836321
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1, '1')



# Generated at 2022-06-18 02:10:18.332538
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]

# Generated at 2022-06-18 02:10:21.992241
# Unit test for function memoize
def test_memoize():
    def factorial(n):
        if n == 0:
            return 1
        return n * factorial(n - 1)

    factorial = memoize(factorial)
    assert factorial(5) == 120
    assert factorial(5) == 120
    assert factorial(5) == 120



# Generated at 2022-06-18 02:10:25.984797
# Unit test for function curry
def test_curry():
    def add(a, b):
        return a + b

    assert curry(add)(1)(2) == 3
    assert curry(add, 2)(1, 2) == 3
    assert curry(add, 2)(1)(2) == 3
    assert curry(add, 1)(1) == 2



# Generated at 2022-06-18 02:10:33.249797
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6



# Generated at 2022-06-18 02:10:36.592256
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4], lambda x: x == 5) is None



# Generated at 2022-06-18 02:10:44.073344
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4, 5]) == [3, 4, 5]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4, 5]) == [3, 4, 5]
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4, 5]) == [3, 4, 5]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4, 5]) == [3, 4, 5]


# Generated at 2022-06-18 02:11:14.898964
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3])

# Generated at 2022-06-18 02:11:24.730314
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return not is_even(value)

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    def is_zero(value):
        return value == 0

    def is_not_zero(value):
        return not is_zero(value)

    def is_zero_or_positive(value):
        return is_zero(value) or is_positive(value)

    def is_zero_or_negative(value):
        return is_zero(value) or is_negative(value)

    def is_zero_or_even(value):
        return is_zero(value) or is_even(value)


# Generated at 2022-06-18 02:11:28.965373
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z, 3)(1)(2)(3) == 6



# Generated at 2022-06-18 02:11:36.557334
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    def is_zero(value):
        return value == 0

    def is_not_zero(value):
        return value != 0

    def is_zero_or_positive(value):
        return value >= 0

    def is_zero_or_negative(value):
        return value <= 0

    def is_zero_or_odd(value):
        return value % 2 != 0 or value == 0

    def is_zero_or_even(value):
        return value % 2 == 0 or value == 0

    def is_positive_or_odd(value):
        return

# Generated at 2022-06-18 02:11:46.637289
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4, 5]) == [3, 4, 5]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4, 5]) == [3, 4, 5]
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4, 5]) == [3, 4, 5]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4, 5]) == [3, 4, 5]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4, 5]) == [3, 4, 5]

# Generated at 2022-06-18 02:11:57.386993
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4, 5]) == [3, 4, 5]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4, 5]) == [3, 4, 5]
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4, 5]) == [3, 4, 5]
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4, 5]) == [3, 4, 5]
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4, 5]) == [3, 4, 5]

# Generated at 2022-06-18 02:11:59.727455
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1, '1')
    assert eq('1', '1')



# Generated at 2022-06-18 02:12:02.453018
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-18 02:12:11.518132
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)

    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized

# Generated at 2022-06-18 02:12:20.173776
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    def is_zero(value):
        return value == 0

    def is_zero_or_positive(value):
        return value >= 0

    def is_zero_or_negative(value):
        return value <= 0

    def is_zero_or_even(value):
        return value == 0 or value % 2 == 0

    def is_zero_or_odd(value):
        return value == 0 or value % 2 != 0

    def is_zero_or_positive_or_even(value):
        return value == 0 or value % 2 == 0 or value > 0

# Generated at 2022-06-18 02:13:09.815762
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-18 02:13:14.128731
# Unit test for function curry
def test_curry():
    def add(x, y):
        return x + y

    assert curry(add)(1, 2) == 3
    assert curry(add, 2)(1, 2) == 3
    assert curry(add)(1)(2) == 3
    assert curry(add, 2)(1)(2) == 3



# Generated at 2022-06-18 02:13:22.200838
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6]) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6]) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6]) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6]) == [2, 4, 6]


# Generated at 2022-06-18 02:13:25.948589
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda x: x == 6) is None



# Generated at 2022-06-18 02:13:27.854682
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4]) == [3, 4]



# Generated at 2022-06-18 02:13:35.999555
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def is_zero(value):
        return value == 0

    def is_one(value):
        return value == 1

    def is_two(value):
        return value == 2

    def is_three(value):
        return value == 3

    def is_four(value):
        return value == 4

    def is_five(value):
        return value == 5

    def is_six(value):
        return value == 6

    def is_seven(value):
        return value == 7

    def is_eight(value):
        return value == 8

    def is_nine(value):
        return value == 9

    def is_ten(value):
        return value == 10



# Generated at 2022-06-18 02:13:43.374696
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 2) == 2
    assert find([1, 2, 3, 4], lambda x: x == 5) is None
    assert find([1, 2, 3, 4], lambda x: x == 1) == 1
    assert find([1, 2, 3, 4], lambda x: x == 4) == 4
    assert find([1, 2, 3, 4], lambda x: x == 0) is None



# Generated at 2022-06-18 02:13:46.280736
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 2) == 2
    assert find([1, 2, 3, 4], lambda x: x == 5) is None



# Generated at 2022-06-18 02:13:54.700443
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4]) == [3, 4]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4]) == [3, 4]
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [3, 4, 5, 6, 7, 8, 9, 10]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [3, 4, 5, 6, 7, 8, 9, 10]


# Generated at 2022-06-18 02:13:57.498807
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1, '1')
    assert not eq(1, None)
    assert not eq(None, 1)
    assert eq(None, None)

