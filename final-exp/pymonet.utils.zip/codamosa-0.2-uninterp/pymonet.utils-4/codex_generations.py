

# Generated at 2022-06-18 02:06:17.568682
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-18 02:06:24.663585
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda x: x == 6) is None
    assert find([1, 2, 3, 4, 5], lambda x: x % 2 == 0) == 2
    assert find([1, 2, 3, 4, 5], lambda x: x % 2 == 1) == 1
    assert find([1, 2, 3, 4, 5], lambda x: x > 3) == 4
    assert find([1, 2, 3, 4, 5], lambda x: x < 3) == 1



# Generated at 2022-06-18 02:06:35.355170
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]

# Generated at 2022-06-18 02:06:41.029408
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4]) == [3, 4]
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4]) == [3, 4]



# Generated at 2022-06-18 02:06:50.014568
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6]) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6]) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6]) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6]) == [2, 4, 6]


# Generated at 2022-06-18 02:06:55.923763
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-18 02:06:59.044074
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4], lambda x: x == 5) is None



# Generated at 2022-06-18 02:07:09.674741
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x == 1, lambda x: x + 1),
        (lambda x: x == 2, lambda x: x + 2),
        (lambda x: x == 3, lambda x: x + 3),
    ])(1) == 2
    assert cond([
        (lambda x: x == 1, lambda x: x + 1),
        (lambda x: x == 2, lambda x: x + 2),
        (lambda x: x == 3, lambda x: x + 3),
    ])(2) == 4
    assert cond([
        (lambda x: x == 1, lambda x: x + 1),
        (lambda x: x == 2, lambda x: x + 2),
        (lambda x: x == 3, lambda x: x + 3),
    ])(3) == 6

# Generated at 2022-06-18 02:07:16.420938
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3])

# Generated at 2022-06-18 02:07:25.907442
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3])

# Generated at 2022-06-18 02:07:42.446100
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized

# Generated at 2022-06-18 02:07:52.247243
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x == 0, lambda x: 'zero'),
        (lambda x: x % 2 == 0, lambda x: 'even'),
        (lambda x: x % 2 == 1, lambda x: 'odd')
    ])(0) == 'zero'
    assert cond([
        (lambda x: x == 0, lambda x: 'zero'),
        (lambda x: x % 2 == 0, lambda x: 'even'),
        (lambda x: x % 2 == 1, lambda x: 'odd')
    ])(1) == 'odd'

# Generated at 2022-06-18 02:07:58.506417
# Unit test for function cond
def test_cond():
    def is_even(number):
        return number % 2 == 0

    def is_odd(number):
        return not is_even(number)

    def is_positive(number):
        return number > 0

    def is_negative(number):
        return not is_positive(number)

    def is_zero(number):
        return number == 0

    def is_one(number):
        return number == 1

    def is_two(number):
        return number == 2

    def is_three(number):
        return number == 3

    def is_four(number):
        return number == 4

    def is_five(number):
        return number == 5

    def is_six(number):
        return number == 6

    def is_seven(number):
        return number == 7


# Generated at 2022-06-18 02:08:08.965890
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized

# Generated at 2022-06-18 02:08:10.842247
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-18 02:08:15.882667
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)



# Generated at 2022-06-18 02:08:23.205174
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def is_zero(value):
        return value == 0

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    def is_zero_or_positive(value):
        return value >= 0

    def is_zero_or_negative(value):
        return value <= 0

    def is_one(value):
        return value == 1

    def is_two(value):
        return value == 2

    def is_three(value):
        return value == 3

    def is_four(value):
        return value == 4

    def is_five(value):
        return value == 5


# Generated at 2022-06-18 02:08:34.389712
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def double(value):
        return value * 2

    def triple(value):
        return value * 3

    def quadruple(value):
        return value * 4

    assert cond([
        (is_even, double),
        (is_odd, triple),
    ])(2) == 4
    assert cond([
        (is_even, double),
        (is_odd, triple),
    ])(3) == 9
    assert cond([
        (is_even, double),
        (is_odd, triple),
    ])(4) == 8

# Generated at 2022-06-18 02:08:41.755661
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def is_zero(value):
        return value == 0

    def is_one(value):
        return value == 1

    def is_two(value):
        return value == 2

    def is_three(value):
        return value == 3

    def is_four(value):
        return value == 4

    def is_five(value):
        return value == 5

    def is_six(value):
        return value == 6

    def is_seven(value):
        return value == 7

    def is_eight(value):
        return value == 8

    def is_nine(value):
        return value == 9

    def is_ten(value):
        return value == 10



# Generated at 2022-06-18 02:08:50.109884
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def is_zero(value):
        return value == 0

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    def is_one(value):
        return value == 1

    def is_two(value):
        return value == 2

    def is_three(value):
        return value == 3

    def is_four(value):
        return value == 4

    def is_five(value):
        return value == 5

    def is_six(value):
        return value == 6

    def is_seven(value):
        return value == 7

    def is_eight(value):
        return value == 8



# Generated at 2022-06-18 02:09:01.958907
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6



# Generated at 2022-06-18 02:09:11.072436
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 == 1

    def increase(value):
        return value + 1

    def decrease(value):
        return value - 1

    def identity(value):
        return value

    assert cond([
        (is_even, increase),
        (is_odd, decrease),
    ])(0) == 1
    assert cond([
        (is_even, increase),
        (is_odd, decrease),
    ])(1) == 0
    assert cond([
        (is_even, increase),
        (is_odd, decrease),
    ])(2) == 3
    assert cond([
        (is_even, increase),
        (is_odd, decrease),
    ])(3) == 2

# Generated at 2022-06-18 02:09:12.529667
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-18 02:09:21.815008
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    def is_zero(value):
        return value == 0

    def is_zero_or_positive(value):
        return value >= 0

    def is_zero_or_negative(value):
        return value <= 0

    def is_zero_or_even(value):
        return value == 0 or is_even(value)

    def is_zero_or_odd(value):
        return value == 0 or is_odd(value)

    def is_positive_or_even(value):
        return is_positive(value) or is_even(value)

   

# Generated at 2022-06-18 02:09:25.316961
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)

    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3



# Generated at 2022-06-18 02:09:27.488807
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)

    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3



# Generated at 2022-06-18 02:09:39.191143
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]

# Generated at 2022-06-18 02:09:44.856475
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-18 02:09:52.698400
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6



# Generated at 2022-06-18 02:09:59.153609
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    add_memoized = memoize(add)
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memo

# Generated at 2022-06-18 02:10:17.847743
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized

# Generated at 2022-06-18 02:10:27.051619
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3])

# Generated at 2022-06-18 02:10:37.531487
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized

# Generated at 2022-06-18 02:10:46.945004
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([]) == []
    assert curried_map(lambda x: x + 1, []) == []
    assert curried_map(lambda x: x + 1)([1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]
    assert curried_map(lambda x: x + 1, [1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]



# Generated at 2022-06-18 02:10:48.863978
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1, 1, 1)
    assert not eq(1, 1, 2)



# Generated at 2022-06-18 02:10:54.242165
# Unit test for function memoize
def test_memoize():
    def add(x, y):
        return x + y

    add_memoized = memoize(add)
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memoized(1, 2) == 3
    assert add_memo

# Generated at 2022-06-18 02:11:02.934291
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6



# Generated at 2022-06-18 02:11:13.204518
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized

# Generated at 2022-06-18 02:11:20.068712
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(2, 2) == 4
    assert memoized_add(2, 2) == 4
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(2, 2) == 4
    assert memoized_add(2, 2) == 4
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(2, 2) == 4
    assert memoized_add(2, 2) == 4


# Unit test

# Generated at 2022-06-18 02:11:24.466378
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)
    assert eq(1, 1, 1)
    assert not eq(1, 1, 2)
    assert eq(1)(1)(1)
    assert not eq(1)(1)(2)



# Generated at 2022-06-18 02:11:52.654144
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x == 1, lambda x: x + 1),
        (lambda x: x == 2, lambda x: x + 2),
        (lambda x: x == 3, lambda x: x + 3),
    ])(1) == 2
    assert cond([
        (lambda x: x == 1, lambda x: x + 1),
        (lambda x: x == 2, lambda x: x + 2),
        (lambda x: x == 3, lambda x: x + 3),
    ])(2) == 4
    assert cond([
        (lambda x: x == 1, lambda x: x + 1),
        (lambda x: x == 2, lambda x: x + 2),
        (lambda x: x == 3, lambda x: x + 3),
    ])(3) == 6

# Generated at 2022-06-18 02:11:56.000968
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-18 02:11:59.674908
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-18 02:12:03.836397
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)

    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3



# Generated at 2022-06-18 02:12:10.127413
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6



# Generated at 2022-06-18 02:12:14.521772
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x % 2 == 0) == 2
    assert find([1, 2, 3, 4], lambda x: x % 2 == 1) == 1
    assert find([1, 2, 3, 4], lambda x: x > 4) is None
    assert find([], lambda x: x > 4) is None



# Generated at 2022-06-18 02:12:22.536410
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3])

# Generated at 2022-06-18 02:12:25.175613
# Unit test for function memoize
def test_memoize():
    def factorial(n):
        if n == 0:
            return 1
        return n * factorial(n - 1)

    factorial = memoize(factorial)
    assert factorial(5) == 120
    assert factorial(5) == 120



# Generated at 2022-06-18 02:12:30.173880
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda x: x == 6) is None
    assert find([1, 2, 3, 4, 5], lambda x: x % 2 == 0) == 2
    assert find([1, 2, 3, 4, 5], lambda x: x % 2 == 1) == 1
    assert find([1, 2, 3, 4, 5], lambda x: x % 2 == 0) == 2
    assert find([1, 2, 3, 4, 5], lambda x: x % 2 == 1) == 1
    assert find([1, 2, 3, 4, 5], lambda x: x % 2 == 0) == 2

# Generated at 2022-06-18 02:12:31.576125
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-18 02:13:16.100983
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 5) is None



# Generated at 2022-06-18 02:13:18.879695
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4], lambda x: x == 5) is None



# Generated at 2022-06-18 02:13:24.105863
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3



# Generated at 2022-06-18 02:13:33.340160
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized

# Generated at 2022-06-18 02:13:38.197923
# Unit test for function memoize
def test_memoize():
    def add(x):
        return x + 1

    memoized_add = memoize(add)
    assert memoized_add(1) == 2
    assert memoized_add(1) == 2
    assert memoized_add(2) == 3
    assert memoized_add(2) == 3
    assert memoized_add(1) == 2
    assert memoized_add(2) == 3



# Generated at 2022-06-18 02:13:47.058328
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]

# Generated at 2022-06-18 02:13:56.227198
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]

# Generated at 2022-06-18 02:14:02.620307
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 == 1

    def is_zero(value):
        return value == 0

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    def is_zero_or_positive(value):
        return value >= 0

    def is_zero_or_negative(value):
        return value <= 0

    def is_one(value):
        return value == 1

    def is_two(value):
        return value == 2

    def is_three(value):
        return value == 3

    def is_four(value):
        return value == 4

    def is_five(value):
        return value == 5


# Generated at 2022-06-18 02:14:05.421278
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x % 2 == 0, lambda x: x + 1),
        (lambda x: x % 2 == 1, lambda x: x + 2),
    ])(1) == 3



# Generated at 2022-06-18 02:14:12.936736
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def is_zero(value):
        return value == 0

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    def is_zero_or_positive(value):
        return value >= 0

    def is_zero_or_negative(value):
        return value <= 0

    def is_one(value):
        return value == 1

    def is_two(value):
        return value == 2

    def is_three(value):
        return value == 3

    def is_four(value):
        return value == 4

    def is_five(value):
        return value == 5


# Generated at 2022-06-18 02:16:10.181410
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return not is_even(value)

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return not is_positive(value)

    def is_zero(value):
        return value == 0

    def is_not_zero(value):
        return not is_zero(value)

    def is_zero_or_positive(value):
        return is_zero(value) or is_positive(value)

    def is_zero_or_negative(value):
        return is_zero(value) or is_negative(value)

    def is_positive_or_negative(value):
        return is_positive(value) or is_negative(value)


# Generated at 2022-06-18 02:16:18.498327
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 3) == 4
    assert memoized_add(1, 3) == 4
    assert memoized_add(1, 3) == 4
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 3) == 4
    assert memoized_add(1, 3) == 4
    assert memoized_add(1, 3) == 4

