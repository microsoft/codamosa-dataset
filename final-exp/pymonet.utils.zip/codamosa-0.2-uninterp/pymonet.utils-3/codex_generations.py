

# Generated at 2022-06-18 02:06:19.266147
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda x: x == 6) is None



# Generated at 2022-06-18 02:06:25.471196
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6



# Generated at 2022-06-18 02:06:36.374893
# Unit test for function cond
def test_cond():
    def is_even(number):
        return number % 2 == 0

    def is_odd(number):
        return number % 2 == 1

    def is_zero(number):
        return number == 0

    def is_negative(number):
        return number < 0

    def is_positive(number):
        return number > 0

    def is_zero_or_negative(number):
        return number <= 0

    def is_zero_or_positive(number):
        return number >= 0

    def is_one(number):
        return number == 1

    def is_two(number):
        return number == 2

    def is_three(number):
        return number == 3

    def is_four(number):
        return number == 4

    def is_five(number):
        return number == 5


# Generated at 2022-06-18 02:06:39.750707
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-18 02:06:46.333461
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x % 2 == 0) == 2
    assert find([1, 2, 3, 4], lambda x: x % 2 == 1) == 1
    assert find([1, 2, 3, 4], lambda x: x > 4) is None



# Generated at 2022-06-18 02:06:55.279080
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 == 1

    def is_zero(value):
        return value == 0

    def is_negative(value):
        return value < 0

    def is_positive(value):
        return value > 0

    def is_zero_or_negative(value):
        return value <= 0

    def is_zero_or_positive(value):
        return value >= 0

    def is_zero_or_positive_or_negative(value):
        return value == 0 or value > 0 or value < 0

    def is_zero_or_positive_and_negative(value):
        return value == 0 or (value > 0 and value < 0)


# Generated at 2022-06-18 02:07:03.648272
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6



# Generated at 2022-06-18 02:07:10.802248
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6]) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6]) == [2, 4, 6]


# Generated at 2022-06-18 02:07:12.262348
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1, None)
    assert not eq(None, 1)
    assert eq(None, None)



# Generated at 2022-06-18 02:07:21.746981
# Unit test for function cond
def test_cond():
    def is_even(number: int) -> bool:
        return number % 2 == 0

    def is_odd(number: int) -> bool:
        return number % 2 != 0

    def is_zero(number: int) -> bool:
        return number == 0

    def is_positive(number: int) -> bool:
        return number > 0

    def is_negative(number: int) -> bool:
        return number < 0

    def is_zero_or_positive(number: int) -> bool:
        return is_zero(number) or is_positive(number)

    def is_zero_or_negative(number: int) -> bool:
        return is_zero(number) or is_negative(number)


# Generated at 2022-06-18 02:07:30.303747
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x % 2 == 0) == 2
    assert find([1, 2, 3, 4], lambda x: x > 4) is None
    assert find([{'a': 1}, {'a': 2}, {'a': 3}], lambda x: x['a'] == 2) == {'a': 2}



# Generated at 2022-06-18 02:07:41.054250
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4]) == [3, 4]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4]) == [3, 4]
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [3, 4, 5, 6, 7, 8, 9, 10]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [3, 4, 5, 6, 7, 8, 9, 10]

# Generated at 2022-06-18 02:07:47.545203
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-18 02:07:56.771186
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]

# Generated at 2022-06-18 02:07:58.738915
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda x: x == 6) is None



# Generated at 2022-06-18 02:08:03.639276
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)
    assert eq(1, 1, 1)
    assert not eq(1, 1, 2)



# Generated at 2022-06-18 02:08:06.310978
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 2) == 2
    assert find([1, 2, 3, 4], lambda x: x == 5) is None



# Generated at 2022-06-18 02:08:13.832513
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    def is_zero(value):
        return value == 0

    def is_not_zero(value):
        return value != 0

    def is_zero_or_negative(value):
        return value <= 0

    def is_zero_or_positive(value):
        return value >= 0

    def is_zero_or_even(value):
        return value % 2 == 0 or value == 0

    def is_zero_or_odd(value):
        return value % 2 != 0 or value == 0


# Generated at 2022-06-18 02:08:18.108591
# Unit test for function curry
def test_curry():
    def add(a, b, c):
        return a + b + c

    assert curry(add)(1)(2)(3) == 6
    assert curry(add, 2)(1, 2)(3) == 6
    assert curry(add, 1)(1)(2, 3) == 6
    assert curry(add, 0)(1, 2, 3) == 6



# Generated at 2022-06-18 02:08:21.714070
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)

    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3



# Generated at 2022-06-18 02:08:30.961917
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)


# Generated at 2022-06-18 02:08:39.930912
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized

# Generated at 2022-06-18 02:08:41.909530
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4]) == [3, 4]



# Generated at 2022-06-18 02:08:50.133171
# Unit test for function cond
def test_cond():
    def is_even(x):
        return x % 2 == 0

    def is_odd(x):
        return x % 2 == 1

    def is_zero(x):
        return x == 0

    def is_positive(x):
        return x > 0

    def is_negative(x):
        return x < 0

    def is_zero_or_positive(x):
        return x >= 0

    def is_zero_or_negative(x):
        return x <= 0

    def is_one(x):
        return x == 1

    def is_two(x):
        return x == 2

    def is_three(x):
        return x == 3

    def is_four(x):
        return x == 4

    def is_five(x):
        return x == 5


# Generated at 2022-06-18 02:08:55.261353
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def is_zero(value):
        return value == 0

    def is_negative(value):
        return value < 0

    def is_positive(value):
        return value > 0

    def double(value):
        return value * 2

    def triple(value):
        return value * 3

    def quadruple(value):
        return value * 4

    def quintuple(value):
        return value * 5

    def sextuple(value):
        return value * 6

    def septuple(value):
        return value * 7

    def octuple(value):
        return value * 8

    def nonuple(value):
        return value * 9


# Generated at 2022-06-18 02:08:59.062101
# Unit test for function memoize
def test_memoize():
    @memoize
    def add(x):
        return x + 1

    assert add(1) == 2
    assert add(1) == 2
    assert add(2) == 3
    assert add(2) == 3



# Generated at 2022-06-18 02:09:02.429348
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3



# Generated at 2022-06-18 02:09:04.213420
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-18 02:09:11.587505
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def is_zero(value):
        return value == 0

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    def is_zero_or_positive(value):
        return value >= 0

    def is_zero_or_negative(value):
        return value <= 0

    def is_one(value):
        return value == 1

    def is_two(value):
        return value == 2

    def is_three(value):
        return value == 3

    def is_four(value):
        return value == 4

    def is_five(value):
        return value == 5


# Generated at 2022-06-18 02:09:18.808359
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6



# Generated at 2022-06-18 02:09:43.832842
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1, 1, 1)
    assert not eq(1, 1, 2)
    assert not eq(1, 2, 1)
    assert not eq(1, 2, 2)
    assert eq(1, 1, 1, 1)
    assert not eq(1, 1, 1, 2)
    assert not eq(1, 1, 2, 1)
    assert not eq(1, 1, 2, 2)
    assert not eq(1, 2, 1, 1)
    assert not eq(1, 2, 1, 2)
    assert not eq(1, 2, 2, 1)
    assert not eq(1, 2, 2, 2)
    assert eq(1, 1, 1, 1, 1)

# Generated at 2022-06-18 02:09:45.260003
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-18 02:09:48.042260
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-18 02:09:55.243759
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-18 02:09:58.075584
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-18 02:10:07.031030
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z, 3)(1, 2, 3) == 6
    assert curry(lambda x, y, z: x + y + z, 2)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z, 1)(1, 2, 3) == 6
    assert curry(lambda x, y, z: x + y + z, 0)(1, 2, 3) == 6



# Generated at 2022-06-18 02:10:16.805874
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def is_zero(value):
        return value == 0

    def is_negative(value):
        return value < 0

    def is_positive(value):
        return value > 0

    def is_positive_even(value):
        return is_positive(value) and is_even(value)

    def is_positive_odd(value):
        return is_positive(value) and is_odd(value)

    def is_negative_even(value):
        return is_negative(value) and is_even(value)

    def is_negative_odd(value):
        return is_negative(value) and is_odd(value)


# Generated at 2022-06-18 02:10:19.807241
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)



# Generated at 2022-06-18 02:10:27.298354
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x == 1, lambda x: x + 1),
        (lambda x: x == 2, lambda x: x + 2),
    ])(1) == 2
    assert cond([
        (lambda x: x == 1, lambda x: x + 1),
        (lambda x: x == 2, lambda x: x + 2),
    ])(2) == 4
    assert cond([
        (lambda x: x == 1, lambda x: x + 1),
        (lambda x: x == 2, lambda x: x + 2),
    ])(3) is None



# Generated at 2022-06-18 02:10:31.695267
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4]) == [2, 4]


# Generated at 2022-06-18 02:11:05.843307
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-18 02:11:15.987220
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized

# Generated at 2022-06-18 02:11:18.693062
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-18 02:11:21.056051
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4]) == [2, 4]



# Generated at 2022-06-18 02:11:25.147544
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)
    assert eq(1, 1, 1)
    assert not eq(1, 1, 2)
    assert eq(1, 1, 1, 1)
    assert not eq(1, 1, 1, 2)



# Generated at 2022-06-18 02:11:27.756258
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1, '1')
    assert not eq(1, None)



# Generated at 2022-06-18 02:11:30.060589
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda x: x == 6) is None



# Generated at 2022-06-18 02:11:33.602885
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z, t: x + y + z + t)(1)(2)(3)(4) == 10



# Generated at 2022-06-18 02:11:35.544385
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)



# Generated at 2022-06-18 02:11:37.720823
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-18 02:12:45.676103
# Unit test for function cond
def test_cond():
    def is_even(x):
        return x % 2 == 0

    def is_odd(x):
        return not is_even(x)

    def is_positive(x):
        return x > 0

    def is_negative(x):
        return not is_positive(x)

    def is_zero(x):
        return x == 0

    def is_not_zero(x):
        return not is_zero(x)

    def is_zero_or_positive(x):
        return is_zero(x) or is_positive(x)

    def is_zero_or_negative(x):
        return is_zero(x) or is_negative(x)

    def is_zero_or_even(x):
        return is_zero(x) or is_even(x)


# Generated at 2022-06-18 02:12:54.149734
# Unit test for function cond
def test_cond():
    def is_even(value: int) -> bool:
        return value % 2 == 0

    def is_odd(value: int) -> bool:
        return value % 2 != 0

    def is_zero(value: int) -> bool:
        return value == 0

    def increase(value: int) -> int:
        return value + 1

    def decrease(value: int) -> int:
        return value - 1

    def return_zero(value: int) -> int:
        return 0

    def cond_test(value: int) -> int:
        return cond([
            (is_even, increase),
            (is_odd, decrease),
            (is_zero, return_zero)
        ])(value)

    assert cond_test(2) == 3
    assert cond_test(1) == 0
    assert cond_test

# Generated at 2022-06-18 02:13:04.001755
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]

# Generated at 2022-06-18 02:13:08.728784
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-18 02:13:15.386088
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-18 02:13:20.346721
# Unit test for function memoize
def test_memoize():
    def add(x):
        return x + 1

    memoized_add = memoize(add)
    assert memoized_add(1) == 2
    assert memoized_add(1) == 2
    assert memoized_add(2) == 3
    assert memoized_add(2) == 3
    assert memoized_add(1) == 2



# Generated at 2022-06-18 02:13:22.623368
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1, '1')



# Generated at 2022-06-18 02:13:32.226595
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x % 2 == 0, lambda x: x + 1),
        (lambda x: x % 2 == 1, lambda x: x - 1),
    ])(1) == 0
    assert cond([
        (lambda x: x % 2 == 0, lambda x: x + 1),
        (lambda x: x % 2 == 1, lambda x: x - 1),
    ])(2) == 3
    assert cond([
        (lambda x: x % 2 == 0, lambda x: x + 1),
        (lambda x: x % 2 == 1, lambda x: x - 1),
    ])(3) == 2

# Generated at 2022-06-18 02:13:35.064082
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda x: x == 6) is None



# Generated at 2022-06-18 02:13:45.148331
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def is_zero(value):
        return value == 0

    def is_one(value):
        return value == 1

    def is_two(value):
        return value == 2

    def is_three(value):
        return value == 3

    def is_four(value):
        return value == 4

    def is_five(value):
        return value == 5

    def is_six(value):
        return value == 6

    def is_seven(value):
        return value == 7

    def is_eight(value):
        return value == 8

    def is_nine(value):
        return value == 9

    def is_ten(value):
        return value == 10

