

# Generated at 2022-06-18 02:06:23.578878
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]

# Generated at 2022-06-18 02:06:26.972710
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5]) == [2, 4]


# Generated at 2022-06-18 02:06:35.529546
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4]) == [3, 4]
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4]) == [3, 4]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4, 5, 6]) == [3, 4, 5, 6]
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4, 5, 6]) == [3, 4, 5, 6]



# Generated at 2022-06-18 02:06:43.744647
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6])([]) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6])([1, 2, 3]) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6])([1, 2, 3, 4, 5, 6]) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6])([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6]


# Generated at 2022-06-18 02:06:49.977028
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)

    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 3) == 4
    assert memoized_add(1, 3) == 4
    assert memoized_add(1, 3) == 4



# Generated at 2022-06-18 02:06:55.125591
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6



# Generated at 2022-06-18 02:06:58.866002
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda x: x == 7) is None



# Generated at 2022-06-18 02:07:09.221759
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6
    assert curry(lambda x, y, z: x + y + z, 3)(1, 2, 3) == 6
    assert curry(lambda x, y, z: x + y + z, 2)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z, 1)(1, 2, 3) == 6



# Generated at 2022-06-18 02:07:11.982748
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x % 2 == 0) == 2
    assert find([1, 2, 3, 4, 5], lambda x: x % 2 == 1) == 1
    assert find([1, 2, 3, 4, 5], lambda x: x % 2 == 3) is None



# Generated at 2022-06-18 02:07:16.459913
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6]) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6]) == [2, 4, 6]


# Generated at 2022-06-18 02:07:23.654712
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)



# Generated at 2022-06-18 02:07:33.528753
# Unit test for function memoize
def test_memoize():
    def add(x):
        return x + 1

    memoized_add = memoize(add)
    assert memoized_add(1) == 2
    assert memoized_add(1) == 2
    assert memoized_add(2) == 3
    assert memoized_add(2) == 3
    assert memoized_add(1) == 2
    assert memoized_add(2) == 3
    assert memoized_add(3) == 4
    assert memoized_add(3) == 4
    assert memoized_add(2) == 3
    assert memoized_add(3) == 4
    assert memoized_add(1) == 2
    assert memoized_add(2) == 3
    assert memoized_add(3) == 4
    assert memoized_add(4) == 5
    assert memoized_add

# Generated at 2022-06-18 02:07:38.432773
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)



# Generated at 2022-06-18 02:07:46.383242
# Unit test for function memoize
def test_memoize():
    def factorial(n):
        if n == 0:
            return 1
        return n * factorial(n - 1)

    factorial_memoized = memoize(factorial)
    assert factorial_memoized(5) == 120
    assert factorial_memoized(5) == 120
    assert factorial_memoized(5) == 120
    assert factorial_memoized(5) == 120
    assert factorial_memoized(5) == 120
    assert factorial_memoized(5) == 120
    assert factorial_memoized(5) == 120
    assert factorial_memoized(5) == 120
    assert factorial_memoized(5) == 120
    assert factorial_memoized(5) == 120
    assert factorial_memoized(5) == 120

# Generated at 2022-06-18 02:07:56.252469
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3])

# Generated at 2022-06-18 02:07:59.772449
# Unit test for function memoize
def test_memoize():
    def fn(a):
        return a + 1

    memoized_fn = memoize(fn)
    assert memoized_fn(1) == 2
    assert memoized_fn(1) == 2
    assert memoized_fn(2) == 3
    assert memoized_fn(2) == 3
    assert memoized_fn(1) == 2



# Generated at 2022-06-18 02:08:03.720034
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]



# Generated at 2022-06-18 02:08:06.062867
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)



# Generated at 2022-06-18 02:08:13.649729
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]

# Generated at 2022-06-18 02:08:16.231799
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)



# Generated at 2022-06-18 02:08:21.937163
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-18 02:08:25.338879
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-18 02:08:32.539415
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6



# Generated at 2022-06-18 02:08:40.797341
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def is_zero(value):
        return value == 0

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    def is_zero_or_positive(value):
        return value >= 0

    def is_zero_or_negative(value):
        return value <= 0

    def is_one(value):
        return value == 1

    def is_two(value):
        return value == 2

    def is_three(value):
        return value == 3

    def is_four(value):
        return value == 4

    def is_five(value):
        return value == 5


# Generated at 2022-06-18 02:08:44.235141
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda x: x == 6) is None



# Generated at 2022-06-18 02:08:50.935772
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]

# Generated at 2022-06-18 02:08:59.219297
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6]) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6]) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6]) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6]) == [2, 4, 6]


# Generated at 2022-06-18 02:09:01.862017
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-18 02:09:06.235568
# Unit test for function memoize
def test_memoize():
    def test_fn(argument):
        return argument + 1

    memoized_fn = memoize(test_fn)
    assert memoized_fn(1) == 2
    assert memoized_fn(1) == 2
    assert memoized_fn(2) == 3
    assert memoized_fn(2) == 3



# Generated at 2022-06-18 02:09:08.887078
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4], lambda x: x == 5) is None



# Generated at 2022-06-18 02:09:22.291338
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized

# Generated at 2022-06-18 02:09:29.812140
# Unit test for function cond
def test_cond():
    def is_even(x):
        return x % 2 == 0

    def is_odd(x):
        return x % 2 == 1

    def is_positive(x):
        return x > 0

    def is_negative(x):
        return x < 0

    def is_zero(x):
        return x == 0

    def is_not_zero(x):
        return x != 0

    def is_zero_or_negative(x):
        return x <= 0

    def is_zero_or_positive(x):
        return x >= 0

    def is_zero_or_even(x):
        return x % 2 == 0 or x == 0

    def is_zero_or_odd(x):
        return x % 2 == 1 or x == 0

    def is_positive_or_even(x):
        return

# Generated at 2022-06-18 02:09:35.136914
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6



# Generated at 2022-06-18 02:09:44.979157
# Unit test for function cond
def test_cond():
    def is_even(x):
        return x % 2 == 0

    def is_odd(x):
        return x % 2 != 0

    def is_positive(x):
        return x > 0

    def is_negative(x):
        return x < 0

    def is_zero(x):
        return x == 0

    def add_one(x):
        return x + 1

    def sub_one(x):
        return x - 1

    def multiply_by_two(x):
        return x * 2

    def divide_by_two(x):
        return x / 2

    def identity(x):
        return x


# Generated at 2022-06-18 02:09:48.828016
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)
    assert eq(1, 1, 1)
    assert not eq(1, 1, 2)



# Generated at 2022-06-18 02:09:57.625387
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 == 1

    def is_zero(value):
        return value == 0

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    def double(value):
        return value * 2

    def triple(value):
        return value * 3

    def identity(value):
        return value

    def zero():
        return 0

    def error():
        raise Exception('Unknown value')


# Generated at 2022-06-18 02:10:01.438750
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1, '1')
    assert not eq(1, None)
    assert not eq(None, 1)
    assert eq(None, None)



# Generated at 2022-06-18 02:10:04.350629
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4]) == [2, 4]



# Generated at 2022-06-18 02:10:08.233535
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-18 02:10:14.617271
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x % 2 == 0, lambda x: x // 2),
        (lambda x: x % 2 == 1, lambda x: x * 3 + 1)
    ])(3) == 10
    assert cond([
        (lambda x: x % 2 == 0, lambda x: x // 2),
        (lambda x: x % 2 == 1, lambda x: x * 3 + 1)
    ])(4) == 2



# Generated at 2022-06-18 02:10:30.971281
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-18 02:10:37.923233
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4, 5]) == [3, 4, 5]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4, 5]) == [3, 4, 5]
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4, 5]) == [3, 4, 5]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4, 5]) == [3, 4, 5]



# Generated at 2022-06-18 02:10:43.383166
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)
    assert eq(1, 1, 1)
    assert not eq(1, 2, 1)
    assert eq(1)(1)(1)
    assert not eq(1)(2)(1)



# Generated at 2022-06-18 02:10:51.411766
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized

# Generated at 2022-06-18 02:11:02.983996
# Unit test for function memoize
def test_memoize():
    def fib(n):
        if n < 2:
            return n
        return fib(n - 1) + fib(n - 2)

    fib = memoize(fib)
    assert fib(10) == 55
    assert fib(10) == 55
    assert fib(10) == 55
    assert fib(10) == 55
    assert fib(10) == 55
    assert fib(10) == 55
    assert fib(10) == 55
    assert fib(10) == 55
    assert fib(10) == 55
    assert fib(10) == 55
    assert fib(10) == 55
    assert fib(10) == 55
    assert fib(10) == 55
    assert fib(10) == 55
    assert fib(10) == 55
    assert fib(10) == 55
    assert fib(10) == 55

# Generated at 2022-06-18 02:11:07.483816
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x % 2 == 0) == 2
    assert find([1, 2, 3, 4], lambda x: x % 2 == 1) == 1
    assert find([1, 2, 3, 4], lambda x: x % 2 == 3) is None



# Generated at 2022-06-18 02:11:16.999555
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x == 0, lambda x: 'zero'),
        (lambda x: x % 2 == 0, lambda x: 'even'),
        (lambda x: True, lambda x: 'odd')
    ])(0) == 'zero'
    assert cond([
        (lambda x: x == 0, lambda x: 'zero'),
        (lambda x: x % 2 == 0, lambda x: 'even'),
        (lambda x: True, lambda x: 'odd')
    ])(1) == 'odd'
    assert cond([
        (lambda x: x == 0, lambda x: 'zero'),
        (lambda x: x % 2 == 0, lambda x: 'even'),
        (lambda x: True, lambda x: 'odd')
    ])(2) == 'even'



# Generated at 2022-06-18 02:11:22.442445
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == curried_map(lambda x: x + 1)([1, 2, 3])



# Generated at 2022-06-18 02:11:28.738101
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(1), [1, 2, 3]) == [1]
    assert curried_filter(eq(1), [2, 3]) == []
    assert curried_filter(eq(1), []) == []
    assert curried_filter(eq(1))([1, 2, 3]) == [1]
    assert curried_filter(eq(1))([2, 3]) == []
    assert curried_filter(eq(1))([]) == []


# Generated at 2022-06-18 02:11:36.396563
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def is_zero(value):
        return value == 0

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    def is_zero_or_positive(value):
        return is_zero(value) or is_positive(value)

    def is_zero_or_negative(value):
        return is_zero(value) or is_negative(value)

    def is_zero_or_even(value):
        return is_zero(value) or is_even(value)

    def is_zero_or_odd(value):
        return is_zero(value) or is_odd(value)


# Generated at 2022-06-18 02:11:56.932836
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)



# Generated at 2022-06-18 02:12:00.032035
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-18 02:12:05.872626
# Unit test for function cond
def test_cond():
    def is_even(x):
        return x % 2 == 0

    def is_odd(x):
        return x % 2 == 1

    def is_positive(x):
        return x > 0

    def is_negative(x):
        return x < 0

    def is_zero(x):
        return x == 0

    def is_one(x):
        return x == 1

    def is_two(x):
        return x == 2

    def is_three(x):
        return x == 3

    def is_four(x):
        return x == 4

    def is_five(x):
        return x == 5

    def is_six(x):
        return x == 6

    def is_seven(x):
        return x == 7

    def is_eight(x):
        return x == 8



# Generated at 2022-06-18 02:12:09.540726
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)
    assert eq(1, 1, 1)
    assert not eq(1, 1, 2)



# Generated at 2022-06-18 02:12:12.175292
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4], lambda x: x == 5) is None



# Generated at 2022-06-18 02:12:20.732038
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def is_zero(value):
        return value == 0

    def increase(value):
        return value + 1

    def decrease(value):
        return value - 1

    def double(value):
        return value * 2

    def half(value):
        return value / 2

    def identity(value):
        return value

    def cond_test(value):
        return cond([
            (is_even, double),
            (is_odd, increase),
            (is_zero, identity),
        ])(value)

    assert cond_test(2) == 4
    assert cond_test(1) == 2
    assert cond_test(0) == 0


# Generated at 2022-06-18 02:12:28.250122
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]

# Generated at 2022-06-18 02:12:32.875443
# Unit test for function cond
def test_cond():
    def is_even(number):
        return number % 2 == 0

    def is_odd(number):
        return number % 2 != 0

    def is_positive(number):
        return number > 0

    def is_negative(number):
        return number < 0

    def is_zero(number):
        return number == 0

    def is_one(number):
        return number == 1

    def is_two(number):
        return number == 2

    def is_three(number):
        return number == 3

    def is_four(number):
        return number == 4

    def is_five(number):
        return number == 5

    def is_six(number):
        return number == 6

    def is_seven(number):
        return number == 7

    def is_eight(number):
        return number == 8



# Generated at 2022-06-18 02:12:42.371331
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized

# Generated at 2022-06-18 02:12:51.987478
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x > 0, lambda x: x + 1),
        (lambda x: x < 0, lambda x: x - 1),
        (lambda x: x == 0, lambda x: x)
    ])(0) == 0

    assert cond([
        (lambda x: x > 0, lambda x: x + 1),
        (lambda x: x < 0, lambda x: x - 1),
        (lambda x: x == 0, lambda x: x)
    ])(-1) == -2

    assert cond([
        (lambda x: x > 0, lambda x: x + 1),
        (lambda x: x < 0, lambda x: x - 1),
        (lambda x: x == 0, lambda x: x)
    ])(1) == 2



# Generated at 2022-06-18 02:13:36.334745
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x == 0, lambda x: 'zero'),
        (lambda x: x % 2 == 0, lambda x: 'even'),
        (lambda x: x % 2 != 0, lambda x: 'odd')
    ])(0) == 'zero'
    assert cond([
        (lambda x: x == 0, lambda x: 'zero'),
        (lambda x: x % 2 == 0, lambda x: 'even'),
        (lambda x: x % 2 != 0, lambda x: 'odd')
    ])(1) == 'odd'

# Generated at 2022-06-18 02:13:41.720765
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x == 1, lambda x: x + 1),
        (lambda x: x == 2, lambda x: x + 2),
        (lambda x: x == 3, lambda x: x + 3),
    ])(1) == 2
    assert cond([
        (lambda x: x == 1, lambda x: x + 1),
        (lambda x: x == 2, lambda x: x + 2),
        (lambda x: x == 3, lambda x: x + 3),
    ])(2) == 4
    assert cond([
        (lambda x: x == 1, lambda x: x + 1),
        (lambda x: x == 2, lambda x: x + 2),
        (lambda x: x == 3, lambda x: x + 3),
    ])(3) == 6

# Generated at 2022-06-18 02:13:47.538093
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def is_zero(value):
        return value == 0

    def is_negative(value):
        return value < 0

    def is_positive(value):
        return value > 0

    def is_zero_or_positive(value):
        return value >= 0

    def is_zero_or_negative(value):
        return value <= 0

    def is_one(value):
        return value == 1

    def is_two(value):
        return value == 2

    def is_three(value):
        return value == 3

    def is_four(value):
        return value == 4

    def is_five(value):
        return value == 5


# Generated at 2022-06-18 02:13:56.600328
# Unit test for function memoize
def test_memoize():
    def sum_of_squares(a, b):
        return a * a + b * b

    memoized_sum_of_squares = memoize(sum_of_squares)
    assert memoized_sum_of_squares(3, 4) == 25
    assert memoized_sum_of_squares(3, 4) == 25
    assert memoized_sum_of_squares(3, 4) == 25
    assert memoized_sum_of_squares(3, 4) == 25
    assert memoized_sum_of_squares(3, 4) == 25
    assert memoized_sum_of_squares(3, 4) == 25
    assert memoized_sum_of_squares(3, 4) == 25
    assert memoized_sum_of_squares(3, 4) == 25
   

# Generated at 2022-06-18 02:13:58.196309
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-18 02:14:00.184425
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]



# Generated at 2022-06-18 02:14:03.556405
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda x: x == 7) is None



# Generated at 2022-06-18 02:14:08.822014
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)

    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3



# Generated at 2022-06-18 02:14:14.975867
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]

# Generated at 2022-06-18 02:14:16.537526
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-18 02:16:15.149497
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x > 0, lambda x: x + 1),
        (lambda x: x < 0, lambda x: x - 1),
        (lambda x: x == 0, lambda x: x)
    ])(1) == 2
    assert cond([
        (lambda x: x > 0, lambda x: x + 1),
        (lambda x: x < 0, lambda x: x - 1),
        (lambda x: x == 0, lambda x: x)
    ])(-1) == -2
    assert cond([
        (lambda x: x > 0, lambda x: x + 1),
        (lambda x: x < 0, lambda x: x - 1),
        (lambda x: x == 0, lambda x: x)
    ])(0) == 0

