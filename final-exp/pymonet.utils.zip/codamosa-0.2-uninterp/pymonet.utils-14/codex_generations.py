

# Generated at 2022-06-18 02:06:13.694561
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-18 02:06:15.926917
# Unit test for function curry
def test_curry():
    def add(a, b):
        return a + b

    add_curry = curry(add)
    assert add_curry(1)(2) == 3
    assert add_curry(1, 2) == 3



# Generated at 2022-06-18 02:06:18.175570
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-18 02:06:24.663897
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3

    memoized_add = memoize(add, key=lambda a, b: a == b)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 1) == 2
    assert memoized_add(1, 1) == 2



# Generated at 2022-06-18 02:06:26.715341
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-18 02:06:38.424038
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x == 1, lambda x: x + 1),
        (lambda x: x == 2, lambda x: x + 2),
        (lambda x: x == 3, lambda x: x + 3),
    ])(1) == 2
    assert cond([
        (lambda x: x == 1, lambda x: x + 1),
        (lambda x: x == 2, lambda x: x + 2),
        (lambda x: x == 3, lambda x: x + 3),
    ])(2) == 4
    assert cond([
        (lambda x: x == 1, lambda x: x + 1),
        (lambda x: x == 2, lambda x: x + 2),
        (lambda x: x == 3, lambda x: x + 3),
    ])(3) == 6



# Generated at 2022-06-18 02:06:44.725289
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z, a: x + y + z + a)(1)(2)(3)(4) == 10
    assert curry(lambda x, y, z, a, b: x + y + z + a + b)(1)(2)(3)(4)(5) == 15
    assert curry(lambda x, y, z, a, b, c: x + y + z + a + b + c)(1)(2)(3)(4)(5)(6) == 21

# Generated at 2022-06-18 02:06:49.412362
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)



# Generated at 2022-06-18 02:06:50.964948
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-18 02:06:58.223258
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3])

# Generated at 2022-06-18 02:07:12.489984
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]
    assert curried_map(lambda x: x + 1)([1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]
    assert curried_map(lambda x: x + 1, [1, 2, 3, 4, 5, 6]) == [2, 3, 4, 5, 6, 7]

# Generated at 2022-06-18 02:07:22.186020
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]

# Generated at 2022-06-18 02:07:24.848393
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-18 02:07:26.472070
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3



# Generated at 2022-06-18 02:07:36.855148
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def is_zero(value):
        return value == 0

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    def is_zero_or_positive(value):
        return value >= 0

    def is_zero_or_negative(value):
        return value <= 0

    def is_zero_or_even(value):
        return value == 0 or value % 2 == 0

    def is_zero_or_odd(value):
        return value == 0 or value % 2 != 0

    def is_positive_or_even(value):
        return value > 0 or value % 2 == 0


# Generated at 2022-06-18 02:07:42.377495
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-18 02:07:44.922221
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 2) == 2
    assert find([1, 2, 3, 4], lambda x: x == 5) is None



# Generated at 2022-06-18 02:07:47.161174
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-18 02:07:50.024242
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 2) == 2
    assert find([1, 2, 3, 4], lambda x: x == 5) is None



# Generated at 2022-06-18 02:07:52.862695
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4], lambda x: x == 5) is None



# Generated at 2022-06-18 02:08:08.310316
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-18 02:08:10.882315
# Unit test for function curry
def test_curry():
    def add(x, y):
        return x + y

    assert curry(add)(1)(2) == 3
    assert curry(add, 2)(1, 2) == 3
    assert curry(add, 2)(1)(2) == 3



# Generated at 2022-06-18 02:08:20.013995
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x == 0, lambda x: 'zero'),
        (lambda x: x % 2 == 0, lambda x: 'even'),
        (lambda x: x % 2 != 0, lambda x: 'odd')
    ])(0) == 'zero'
    assert cond([
        (lambda x: x == 0, lambda x: 'zero'),
        (lambda x: x % 2 == 0, lambda x: 'even'),
        (lambda x: x % 2 != 0, lambda x: 'odd')
    ])(1) == 'odd'

# Generated at 2022-06-18 02:08:24.634685
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 2) == 2
    assert find([1, 2, 3, 4], lambda x: x == 5) is None
    assert find([1, 2, 3, 4], lambda x: x == 1) == 1
    assert find([1, 2, 3, 4], lambda x: x == 4) == 4


# Generated at 2022-06-18 02:08:35.083043
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)

    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized

# Generated at 2022-06-18 02:08:42.157096
# Unit test for function cond
def test_cond():
    def is_even(value: int) -> bool:
        return value % 2 == 0

    def is_odd(value: int) -> bool:
        return not is_even(value)

    def is_zero(value: int) -> bool:
        return value == 0

    def is_positive(value: int) -> bool:
        return value > 0

    def is_negative(value: int) -> bool:
        return value < 0

    def is_zero_or_positive(value: int) -> bool:
        return is_zero(value) or is_positive(value)

    def is_zero_or_negative(value: int) -> bool:
        return is_zero(value) or is_negative(value)


# Generated at 2022-06-18 02:08:45.202212
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6



# Generated at 2022-06-18 02:08:51.365063
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 5)([1, 2, 3, 4, 5, 6, 7]) == [6, 7]
    assert curried_filter(lambda x: x > 5)([1, 2, 3, 4, 5]) == []
    assert curried_filter(lambda x: x > 5)([]) == []
    assert curried_filter(lambda x: x > 5)([6, 7]) == [6, 7]
    assert curried_filter(lambda x: x > 5)([6]) == [6]
    assert curried_filter(lambda x: x > 5)([7]) == [7]
    assert curried_filter(lambda x: x > 5)([5]) == []
    assert curried_filter(lambda x: x > 5)([4]) == []
    assert curried_filter

# Generated at 2022-06-18 02:09:01.674582
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]

# Generated at 2022-06-18 02:09:08.588595
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 3) == 4
    assert memoized_add(1, 3) == 4
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 3) == 4
    assert memoized_add(1, 3) == 4



# Generated at 2022-06-18 02:09:26.316132
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)

    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3



# Generated at 2022-06-18 02:09:31.255595
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(2, 2) == 4
    assert memoized_add(2, 2) == 4
    assert memoized_add(1, 2) == 3



# Generated at 2022-06-18 02:09:33.859586
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-18 02:09:36.402066
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-18 02:09:39.450129
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda x: x == 7) is None



# Generated at 2022-06-18 02:09:42.097751
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)



# Generated at 2022-06-18 02:09:44.344095
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 2) == 2
    assert find([1, 2, 3, 4], lambda x: x == 5) is None



# Generated at 2022-06-18 02:09:52.148435
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6



# Generated at 2022-06-18 02:09:58.904843
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x == 0, lambda x: x + 1),
        (lambda x: x == 1, lambda x: x + 2),
        (lambda x: x == 2, lambda x: x + 3),
    ])(0) == 1
    assert cond([
        (lambda x: x == 0, lambda x: x + 1),
        (lambda x: x == 1, lambda x: x + 2),
        (lambda x: x == 2, lambda x: x + 3),
    ])(1) == 3
    assert cond([
        (lambda x: x == 0, lambda x: x + 1),
        (lambda x: x == 1, lambda x: x + 2),
        (lambda x: x == 2, lambda x: x + 3),
    ])(2) == 5



# Generated at 2022-06-18 02:10:08.603107
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]

# Generated at 2022-06-18 02:10:30.210676
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)


# Generated at 2022-06-18 02:10:39.281048
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def is_zero(value):
        return value == 0

    def is_negative(value):
        return value < 0

    def is_positive(value):
        return value > 0

    def is_zero_or_negative(value):
        return value <= 0

    def is_zero_or_positive(value):
        return value >= 0

    def is_one(value):
        return value == 1

    def is_two(value):
        return value == 2

    def is_three(value):
        return value == 3

    def is_four(value):
        return value == 4

    def is_five(value):
        return value == 5


# Generated at 2022-06-18 02:10:46.318953
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-18 02:10:52.127761
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z, 3)(1, 2, 3) == 6
    assert curry(lambda x, y, z: x + y + z, 2)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z, 1)(1, 2, 3) == 6
    assert curry(lambda x, y, z: x + y + z, 0)(1, 2, 3) == 6



# Generated at 2022-06-18 02:11:03.722656
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]
    assert curried_map(increase)([1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]
    assert curried_map(increase, [1, 2, 3, 4, 5, 6]) == [2, 3, 4, 5, 6, 7]
    assert curried_map(increase)([1, 2, 3, 4, 5, 6]) == [2, 3, 4, 5, 6, 7]
    assert cur

# Generated at 2022-06-18 02:11:06.287182
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-18 02:11:16.343628
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(1), [1, 2, 3]) == [1]
    assert curried_filter(eq(1), []) == []
    assert curried_filter(eq(1), [2, 3]) == []
    assert curried_filter(eq(1), [1, 1, 1]) == [1, 1, 1]
    assert curried_filter(eq(1), [1, 2, 3, 1, 2, 3]) == [1, 1]
    assert curried_filter(eq(1), [1, 2, 3, 1, 2, 3, 1, 2, 3]) == [1, 1, 1]

# Generated at 2022-06-18 02:11:21.862996
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-18 02:11:31.043514
# Unit test for function memoize
def test_memoize():
    def factorial(n):
        if n == 0:
            return 1
        return n * factorial(n - 1)

    factorial = memoize(factorial)
    assert factorial(5) == 120
    assert factorial(5) == 120
    assert factorial(5) == 120
    assert factorial(5) == 120
    assert factorial(5) == 120
    assert factorial(5) == 120
    assert factorial(5) == 120
    assert factorial(5) == 120
    assert factorial(5) == 120
    assert factorial(5) == 120
    assert factorial(5) == 120
    assert factorial(5) == 120
    assert factorial(5) == 120
    assert factorial(5) == 120
    assert factorial(5) == 120
    assert factorial(5)

# Generated at 2022-06-18 02:11:36.311829
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4]) == [3, 4]
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4]) == [3, 4]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4, 5, 6]) == [3, 4, 5, 6]
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4, 5, 6]) == [3, 4, 5, 6]


# Generated at 2022-06-18 02:12:42.884411
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)



# Generated at 2022-06-18 02:12:52.415143
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)

    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized

# Generated at 2022-06-18 02:12:54.412482
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1, '1')



# Generated at 2022-06-18 02:12:59.570063
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x % 2 == 0) == 2
    assert find([1, 2, 3, 4], lambda x: x % 2 == 1) == 1
    assert find([1, 2, 3, 4], lambda x: x % 2 == 3) is None
    assert find([], lambda x: x % 2 == 0) is None



# Generated at 2022-06-18 02:13:03.565435
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4, 5]) == [3, 4, 5]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4, 5]) == [3, 4, 5]
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4, 5]) == [3, 4, 5]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4, 5]) == [3, 4, 5]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4, 5]) == [3, 4, 5]

# Generated at 2022-06-18 02:13:07.567887
# Unit test for function memoize
def test_memoize():
    def factorial(n):
        if n == 0:
            return 1
        return n * factorial(n - 1)

    factorial = memoize(factorial)
    assert factorial(5) == 120
    assert factorial(5) == 120



# Generated at 2022-06-18 02:13:15.540129
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6]) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6]) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0)([1, 3, 5, 7]) == []
    assert curried_filter(lambda x: x % 2 == 0, [1, 3, 5, 7]) == []
    assert cur

# Generated at 2022-06-18 02:13:22.481242
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6



# Generated at 2022-06-18 02:13:32.143839
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized

# Generated at 2022-06-18 02:13:42.305747
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)

    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3



# Generated at 2022-06-18 02:15:26.127471
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3



# Generated at 2022-06-18 02:15:32.999867
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return not is_even(value)

    def is_zero(value):
        return value == 0

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    def is_zero_or_positive(value):
        return is_zero(value) or is_positive(value)

    def is_zero_or_negative(value):
        return is_zero(value) or is_negative(value)

    def is_positive_or_negative(value):
        return is_positive(value) or is_negative(value)

    def is_zero_or_even(value):
        return is_zero(value) or is_even(value)


# Generated at 2022-06-18 02:15:41.795921
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]

# Generated at 2022-06-18 02:15:45.171378
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3



# Generated at 2022-06-18 02:15:50.965924
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1, '1')
    assert not eq(1, None)
    assert not eq(None, 1)
    assert eq(None, None)
    assert not eq(1, [1])
    assert not eq([1], 1)
    assert eq([1], [1])
    assert not eq([1], [2])
    assert not eq([1, 2], [1])
    assert not eq([1], [1, 2])
    assert not eq([1, 2], [2, 1])
    assert eq([1, 2], [1, 2])
    assert not eq([1, 2], [1, 2, 3])
    assert not eq([1, 2, 3], [1, 2])

# Generated at 2022-06-18 02:16:00.876306
# Unit test for function memoize
def test_memoize():
    def add(x, y):
        return x + y

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized

# Generated at 2022-06-18 02:16:04.712973
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == curried_map(increase)([1, 2, 3])



# Generated at 2022-06-18 02:16:10.440213
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]