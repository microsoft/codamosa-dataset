

# Generated at 2022-06-12 05:36:12.541570
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-12 05:36:21.445858
# Unit test for function cond
def test_cond():
    def greater_than_five(number):
        return number > 5

    def greater_than_ten(number):
        return number > 10

    def return_true(number):
        return True

    def return_false(number):
        return False

    def return_nothing(number):
        pass

    def return_true_lambda(number):
        return lambda: True

    assert cond([(greater_than_five, return_true)])(5) is False
    assert cond([(greater_than_five, return_true)])(6) is True
    assert cond([(greater_than_five, return_false), (greater_than_ten, return_true)])(5) is False

# Generated at 2022-06-12 05:36:30.788186
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x, y: x == y, lambda x, y: 'a + b'),
        (lambda x, y: x * y == 1, lambda x, y: 'a * b'),
        (lambda x, y: x - y > 0, lambda x, y: 'a - b')
    ])(1, 2) == 'a - b'
    assert cond([
        (lambda x, y: x == y, lambda x, y: 'a + b'),
        (lambda x, y: x * y == 1, lambda x, y: 'a * b'),
        (lambda x, y: x - y > 0, lambda x, y: 'a - b')
    ])(1, 1) == 'a + b'

# Generated at 2022-06-12 05:36:32.912558
# Unit test for function eq
def test_eq():
    assert eq(1)(1)
    assert not eq(1)(2)



# Generated at 2022-06-12 05:36:37.405390
# Unit test for function find
def test_find():
    print('=== Test for function find ===')
    # Test for find element
    assert find([1, 2, 3], lambda x: x == 2) == 2
    print('Test for find element - passed')

    # Test for not find element
    assert find([1, 2, 3], lambda x: x == 4) is None
    print('Test for not find element - passed')



# Generated at 2022-06-12 05:36:48.164331
# Unit test for function cond
def test_cond():
    is_even = lambda n: n % 2 == 0
    is_odd = lambda n: n % 2 == 1
    is_one = lambda n: n == 1
    is_two = lambda n: n == 2

    assert cond([(is_even, lambda n: 'even'), (is_odd, lambda n: 'odd')])(1) == 'odd'
    assert cond([(is_even, lambda n: 'even'), (is_one, lambda n: 'one')])(1) == 'one'
    assert cond([(is_two, lambda n: 'two'), (is_two, lambda n: 'two')])(1) is None
    assert 2 == cond([(is_even, lambda n: 2), (is_odd, lambda n: 1)])(2)



# Generated at 2022-06-12 05:36:51.363855
# Unit test for function eq
def test_eq():
    assert False == eq(1, 2)
    assert True == eq(1, 1)
    assert True == eq(1, 1)



# Generated at 2022-06-12 05:36:56.247685
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5]) == [2, 4]



# Generated at 2022-06-12 05:37:04.935558
# Unit test for function cond
def test_cond():
    """
    Test for function cond
    """
    print('test_cond')
    print(cond([
        (lambda x: x, lambda x: x + 1),
        (lambda x: x < 0, lambda x: -x),
        (lambda x: True, lambda x: x),
    ])(1))  # 2
    print(cond([
        (lambda x: x, lambda x: x + 1),
        (lambda x: x < 0, lambda x: -x),
        (lambda x: True, lambda x: x),
    ])(-1))  # 1
    print(cond([
        (lambda x: x, lambda x: x + 1),
        (lambda x: x < 0, lambda x: -x),
        (lambda x: True, lambda x: x),
    ])(0))  # 0



# Generated at 2022-06-12 05:37:11.429932
# Unit test for function curried_filter
def test_curried_filter():
    a_list = [1, 2, 3, 4, 5, 6, 7]
    b_list = [2, 4, 6]
    c_list = [1, 3, 7]

    func = lambda x: x % 2 == 0

    curried_filter_func = curried_filter(func, a_list)
    assert curried_filter_func == b_list

    curried_filter_func = curried_filter(func)(a_list)
    assert curried_filter_func == b_list
    assert curried_filter(func)(a_list) == curried_filter(func)(a_list)



# Generated at 2022-06-12 05:37:20.260709
# Unit test for function curry
def test_curry():
    a = curry(lambda x, y: x + y)
    b = a(1)
    c = b(2)
    assert c == 3



# Generated at 2022-06-12 05:37:24.772089
# Unit test for function find
def test_find():
    """ Test find function """
    assert find([], lambda item: True) is None
    assert find([1, 2, 3], eq(3)) == 3
    assert find([1, 2, 3], eq(4)) is None



# Generated at 2022-06-12 05:37:28.040607
# Unit test for function eq
def test_eq():
    assert eq(5)(5)
    assert not eq(5)(4)
    assert not eq(4)(5)



# Generated at 2022-06-12 05:37:32.330718
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x > 1, lambda x: x),
        (lambda x: x == 0, lambda x: 1),
        (lambda x: True, lambda x: 0),
    ])(2) == 2
    assert cond([
        (lambda x: x > 1, lambda x: x),
        (lambda x: x == 0, lambda x: 1),
        (lambda x: True, lambda x: 0),
    ])(0) == 1
    assert cond([
        (lambda x: x > 1, lambda x: x),
        (lambda x: x == 0, lambda x: 1),
        (lambda x: True, lambda x: 0),
    ])(-1) == 0

    print('test for function cond - ok')



# Generated at 2022-06-12 05:37:38.716617
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x * 2)([1, 2, 3]) == [2, 4, 6]
    assert curried_map(lambda x: x * 2, [1, 2, 3]) == [2, 4, 6]



# Generated at 2022-06-12 05:37:40.591052
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(2))([1, 2, 3, 4]) == [2]



# Generated at 2022-06-12 05:37:52.222125
# Unit test for function cond
def test_cond():
    is_contains_two = lambda list: 2 in list
    is_contains_three = lambda list: 3 in list
    is_contains_four = lambda list: 4 in list
    is_not_contains_five = lambda list: not (5 in list)
    is_contains_five = lambda list: 5 in list

    def get_two(list):
        return 2

    def get_three(list):
        return 3

    def get_four(list):
        return 4

    assert cond([
        (is_contains_two, get_two),
        (is_contains_three, get_three),
        (is_contains_four, get_four)
    ])([1, 2, 3, 4, 5]) == 2

# Generated at 2022-06-12 05:37:54.779521
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(
        lambda x: x > 3,
        [1, 2, 3, 4, 5]
    ) == [4, 5]



# Generated at 2022-06-12 05:38:01.817767
# Unit test for function eq
def test_eq():
    """
    Test function to check if two value is the same.

    :param first_value: variable to compare
    :type first_value: Any
    :param second_value: variable to compare
    :type second_value: Any
    :returns: are values equal?
    :rtype: Boolean
    """
    assert eq(1, 1) is True, "The 1 and 1 are not equal"
    assert eq(2, 3) is False, "The 2 and 3 are equal"
    assert eq({1: "2"}, {1: "2"}) is True, "The objects are not equal"
    assert eq({1: "2"}, {1: "3"}) is False, "The objects are equal"



# Generated at 2022-06-12 05:38:03.908629
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False



# Generated at 2022-06-12 05:38:10.140944
# Unit test for function curried_map
def test_curried_map():
    list_of_numbers = [1, 2, 3, 4]
    result = curried_map(lambda x: x * 2, list_of_numbers)
    assert result == [2, 4, 6, 8]



# Generated at 2022-06-12 05:38:16.710989
# Unit test for function find
def test_find():
    assert find([1], lambda item: item == 1) == 1
    assert find([1, 2, 3, 4], lambda item: item == 2) == 2
    assert find([1, 2, 3, 4], lambda item: item == 4) == 4
    assert find([], lambda item: True) is None
    assert find([1], lambda item: item == 2) is None
    assert find([1, 2, 3, 4], lambda item: item == 5) is None
    assert find([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], lambda item: item < 5) == 1
    assert find([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], lambda item: item > 5) == 6

# Generated at 2022-06-12 05:38:23.577193
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == memoized_add(1, 2)
    assert memoized_add(1, 2) == add(1, 2)
    assert memoized_add(2, 3) == add(2, 3)
    assert len(memoized_add.__closure__[0].cell_contents) == 2



# Generated at 2022-06-12 05:38:28.270988
# Unit test for function curried_map
def test_curried_map():
    assert [1, 2, 3] == curried_map(identity)([0, 1, 2])
    assert [1, 2, 3] == curried_map(increase)([0, 1, 2])
    assert [1, 2, 3] == curried_map(lambda x: x + 1)([0, 1, 2])



# Generated at 2022-06-12 05:38:31.233754
# Unit test for function find
def test_find():
    assert find([2, 3, 4, 5], lambda x: x == 3) == 3
    assert find([2, 4, 6, 8], lambda x: x % 2) == None



# Generated at 2022-06-12 05:38:33.668103
# Unit test for function find
def test_find():
    assert find(list(range(10)), eq(5)) == 5
    assert find(list(range(10)), eq(10)) is None



# Generated at 2022-06-12 05:38:37.336673
# Unit test for function curried_map
def test_curried_map():
    print('test_curried_map')
    print(curried_map(lambda x: x * 2)([1, 2, 3]))



# Generated at 2022-06-12 05:38:38.064129
# Unit test for function eq
def test_eq():
    assert eq(1, 1)



# Generated at 2022-06-12 05:38:46.150257
# Unit test for function curry
def test_curry():
    def add(x, y):
        return x + y

    assert curry(add, 2)(1, 2) == 3
    assert curry(add, 2)(1)(2) == 3
    assert curry(add, 2)(1, 2, 3) == 3
    assert curry(add, 2)(1)(2, 3) == 3
    assert curry(add)(1, 2) == 3
    assert curry(add)(1)(2) == 3
    assert curry(add)(1)(2, 3) == 3


# Unit tests for function identity

# Generated at 2022-06-12 05:38:47.231136
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)


# Generated at 2022-06-12 05:38:57.163530
# Unit test for function find
def test_find():
    assert find(
        [1, 2, 3, 4, 5],
        lambda item: item > 3
    ) == 4

    assert find(
        [1, 2, '3', '4', 5],
        lambda item: type(item) == int
    ) == 1

    assert find(
        [1, 2, 3, 4, 5],
        lambda item: item > 6
    ) is None

# Generated at 2022-06-12 05:38:59.991677
# Unit test for function eq
def test_eq():
    """
    Test of function eq
    """
    assert eq(1, 1) is True
    assert eq(1, 2) is False



# Generated at 2022-06-12 05:39:04.588999
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq("asd", "asd") == True
    assert eq("asd", "asd1") == False



# Generated at 2022-06-12 05:39:09.618747
# Unit test for function curried_map
def test_curried_map():

    lst = [1, 2, 3]

    # Need to define curried_map outside of lambda to be used in lambda.
    # Otherwise the curried_map would be instantiated every time lambda is called.
    # This is the same problem as in curried_filter.
    result = curried_map(lambda x: x + x)(lst)
    assert result == [2, 4, 6]



# Generated at 2022-06-12 05:39:17.124218
# Unit test for function cond
def test_cond():
    def test_increase_value(value):
        return cond([
            [eq(value), identity],
            [eq(2), increase],
            [eq(3), increase],
            [eq(4), increase]
        ])

    assert test_increase_value(1) == 1
    assert test_increase_value(2) == 3
    assert test_increase_value(3) == 4
    assert test_increase_value(4) == 5



# Generated at 2022-06-12 05:39:23.799845
# Unit test for function cond
def test_cond():
    def is_positive(v) -> bool:
        return v > 0

    def is_negative(v) -> bool:
        return v < 0

    def is_zero(v) -> bool:
        return v == 0

    @cond([
        (is_positive, lambda v: v + 1),
        (is_negative, lambda v: v - 1),
        (is_zero,      lambda v: v),
    ])
    def next(x):
        pass

    assert next(-1) == -2
    assert next(0) == 0
    assert next(1) == 2



# Generated at 2022-06-12 05:39:25.699019
# Unit test for function eq
def test_eq():
    assert(eq(3,3) == True)
    assert(eq(3,4) == False)


# Generated at 2022-06-12 05:39:29.310949
# Unit test for function curried_map
def test_curried_map():
    items = [1, 2, 3, 4, 5]
    expected = [2, 3, 4, 5, 6]
    items_map = curried_map(increase)
    assert items_map(items) == expected



# Generated at 2022-06-12 05:39:37.569810
# Unit test for function memoize
def test_memoize():
    """
    Tests for correctness of memoize function.
    """
    class Counter(object):
        def __init__(self):
            super(Counter, self).__init__()
            self.count = 0

        def inc(self):
            self.count += 1
            return self.count

    counter = Counter()

    test_fn = lambda x: counter.inc()

    memoized_fn = memoize(test_fn)

    assert memoized_fn(1) == 1 and counter.count == 1
    assert memoized_fn(2) == 2 and counter.count == 2
    assert memoized_fn(1) == 1 and counter.count == 2
    assert memoized_fn(2) == 2 and counter.count == 2

# Generated at 2022-06-12 05:39:48.490935
# Unit test for function cond
def test_cond():
    condition_list = [(lambda x: x > 5, lambda x: x + 1),
                    (lambda x: x > 10, lambda x: x + 2),
                    (lambda x: x > 15, lambda x: x + 3),
                    (lambda x: x > 20, lambda x: x + 4)]
    assert cond(condition_list)(1) == 2, "wrong value"
    assert cond(condition_list)(6) == 7, "wrong value"
    assert cond(condition_list)(11) == 13, "wrong value"
    assert cond(condition_list)(16) == 19, "wrong value"
    assert cond(condition_list)(21) == 25, "wrong value"
    assert cond(condition_list)(30) is None, "wrong value"

# Generated at 2022-06-12 05:40:03.633372
# Unit test for function curry
def test_curry():
    def test(x1, y1, z1):
        return x1 + y1 + z1
    test = curry(test)
    assert test(1, 2, 3) == 6
    assert test(1, 2)(3) == 6
    assert test(1)(2)(3) == 6
    assert test(1)(2, 3) == 6
    assert test(1, 2, 3) == 6
    assert test(1)(2)(3) == 6


# Generated at 2022-06-12 05:40:09.314262
# Unit test for function memoize
def test_memoize():
    timesInvoked = 0

    @memoize
    def work(x):
        nonlocal timesInvoked
        timesInvoked += 1
        return x + 1

    work(1)
    assert timesInvoked == 1

    work(1)
    assert timesInvoked == 1

    work(2)
    assert timesInvoked == 2

    work(2)
    assert timesInvoked == 2

# Generated at 2022-06-12 05:40:13.213816
# Unit test for function memoize
def test_memoize():

    def add(value):
        sleep(0.5)
        return value + 1

    memoized_add = memoize(add)

    assert memoized_add(1) == 2
    assert memoized_add(1) == 2

# Generated at 2022-06-12 05:40:15.288361
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-12 05:40:18.454114
# Unit test for function curried_filter
def test_curried_filter():
    @curry
    def filterer(a, b):
        return a == b

    assert curried_filter(filterer(2))([1, 2, 3, 2, 1]) == [2, 2]



# Generated at 2022-06-12 05:40:24.110560
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3)(4) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3, 4) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3)(4) == 6



# Generated at 2022-06-12 05:40:28.371928
# Unit test for function curried_map
def test_curried_map():
    """
    Unit test for function curried_map
    """
    double = lambda x: x * 2
    l = [1, 2, 3, 4, 5]
    assert curried_map(double, l) == [2, 4, 6, 8, 10]
    assert curried_map(lambda x: x == 2, l) == [False, True, False, False, False]



# Generated at 2022-06-12 05:40:34.503625
# Unit test for function cond
def test_cond():
    conditions = [
        (lambda x: x > 0, lambda x: x + 1),
        (lambda x: x == 0, lambda x: x)
    ]
    result = cond(conditions)
    assert result(10) == 11
    assert result(0) == 0
    assert result(-3) == None



# Generated at 2022-06-12 05:40:38.640457
# Unit test for function curry
def test_curry():
    # Function f and g are equivalent
    def f(x, y, z):
        return x + y + z

    g = curry(lambda x, y, z: x + y + z)

    assert f(1, 2, 3) == g(1, 2, 3)



# Generated at 2022-06-12 05:40:42.898037
# Unit test for function memoize
def test_memoize():
    items = []
    memoized_fn = memoize(lambda x: x * 2)
    for item in range(10):
        items.append(memoized_fn(item))
    assert(items == [0, 2, 4, 6, 8, 10, 12, 14, 16, 18])


if __name__ == "__main__":
    test_memoize()

# Generated at 2022-06-12 05:41:03.635051
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)

    # unit test with currying
    assert eq(1)(1)


# Generated at 2022-06-12 05:41:05.543994
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(1), [0, 1, 2]) == [1]



# Generated at 2022-06-12 05:41:13.693949
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 3, range(10)) == [4, 5, 6, 7, 8, 9]
    assert curried_filter(lambda x: x == 3, range(10)) == [3]
    assert curried_filter(lambda x: x % 3 == 0, range(10)) == [0, 3, 6, 9]
    assert curried_filter(lambda x: x % 2 == 1, range(10)) == [1, 3, 5, 7, 9]


# Generated at 2022-06-12 05:41:16.609833
# Unit test for function curried_filter
def test_curried_filter():
    def isEvenNumber(num):
        return num % 2 == 0

    assert curried_filter(isEvenNumber)([1, 2, 3, 4]) == [2, 4]



# Generated at 2022-06-12 05:41:20.183138
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6



# Generated at 2022-06-12 05:41:25.746057
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x * 2)([1, 2, 3, 4, 5]) == [2, 4, 6, 8, 10]
    assert curried_map(lambda x: x * 2, [1, 2, 3, 4, 5]) == [2, 4, 6, 8, 10]
    assert curried_map(lambda x: x * 2)([1, 2, 3, 4, 5]) == curried_map(lambda x: x * 2, [1, 2, 3, 4, 5])


# Generated at 2022-06-12 05:41:32.912483
# Unit test for function curry
def test_curry():
    @curry
    def sum_curried(a, b):
        return a + b

    assert sum_curried(1)(2) == 3

    assert sum_curried(1, 2) == 3

    assert sum_curried(1, 2)(3) == 3

    @curry
    def sum_curried(a, b, c):
        return a + b + c

    assert sum_curried(1, 2)(3) == 6



# Generated at 2022-06-12 05:41:41.693526
# Unit test for function memoize
def test_memoize():
    @memoize
    def average(iterable):
        return sum(iterable) / len(iterable)

    assert average([1, 2, 3, 4]) == 2.5
    assert average([1, 2, 3, 4]) == 2.5
    assert average([1, 2, 3, 4, 5]) == 3.0
    assert average([2, 3, 4, 5]) == 3.5
    assert average([1, 2, 3, 4, 5]) == 3.0
    assert average([1, 2, 3, 4]) == 2.5

    assert average([1, 2, 3, 4, 5, 4, 3, 2, 1]) == 3.0



# Generated at 2022-06-12 05:41:47.720256
# Unit test for function cond
def test_cond():
    test_list = [
        (lambda x: x == 'a', lambda x: print('a')),
        (lambda x: x == 'b', lambda x: print('b')),
       ]
    # Should return function that print 'a'
    print_a = cond(test_list)
    print_a('a')
    # Should return function that print 'b'
    print_b = cond(test_list)
    print_b('b')
    # Should return None
    print_c = cond(test_list)
    print_c('c')


if __name__ == '__main__':
    test_cond()

# Generated at 2022-06-12 05:41:51.322701
# Unit test for function curry
def test_curry():
    @curry
    def curried_add(a, b):
        return a + b
    assert curried_add(1)(2) == 3
    assert curried_add(1)('b') == '1b'



# Generated at 2022-06-12 05:42:42.180318
# Unit test for function curried_filter
def test_curried_filter():
    """
    Test of curried_filter.
    """
    assert curried_filter(lambda x: x > 0, [1, -1, 3, 4]) == [1, 3, 4]



# Generated at 2022-06-12 05:42:48.747769
# Unit test for function cond
def test_cond():
    assert cond(())(2) is None
    assert cond([(lambda x: x > 0, lambda x: print('positive')),
                 (lambda x: x < 0, lambda x: print('negative')), ])(2) == print('positive')
    assert cond([(lambda x: x > 0, lambda x: print('positive')),
                 (lambda x: x < 0, lambda x: print('negative')), ])(-2) == print('negative')

test_cond()



# Generated at 2022-06-12 05:42:53.169260
# Unit test for function memoize
def test_memoize():
    @memoize
    def double(value):
        return value * 2

    @memoize
    def triple(value):
        return value * 3

    assert 6 == triple(2)
    assert 4 == double(2)
    assert 6 == triple(2)
    assert 4 == double(2)

# Generated at 2022-06-12 05:43:04.483594
# Unit test for function cond
def test_cond():
    def test_compose(*args):
        return args

    def test_add_10(x):
        return x + 10

    def test_add_5(x):
        return x + 5

    def test_add_3(x):
        return x + 3

    def test_sub_5(x):
        return x - 5

    def test_sub_10(x):
        return x - 10

    def test_sub_3(x):
        return x - 3

    def test_is_positive(number):
        return number >= 0

    def test_is_negative(number):
        return number < 0

    new_function = cond([
        (test_is_positive, test_sub_10),
        (test_is_negative, test_sub_3),
    ])

    assert new_function(3)

# Generated at 2022-06-12 05:43:10.228712
# Unit test for function curry
def test_curry():
    concated_value = identity

    for i in range(10):
        concated_value = curry(lambda x, y: x + y, 1)(concated_value)

    assert concated_value(10) == '01234567890123456789012345678901234567890123456789'

    assert curry(lambda x: x + 1, 1)()(1) == 2



# Generated at 2022-06-12 05:43:13.021650
# Unit test for function curried_map
def test_curried_map():

    curried_map_increase = curried_map(increase)

    assert curried_map_increase([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-12 05:43:21.741973
# Unit test for function cond
def test_cond():
    def is_one(value):
        return value == 1
    def is_two(value):
        return value == 2
    def is_three(value):
        return value == 3

    def add_one(value):
        return value + 1
    def add_two(value):
        return value + 2
    def add_three(value):
        return value + 3

    assert cond([
        (is_one, add_one),
        (is_two, add_two),
        (is_three, add_three)
    ])(1) == 2

# Generated at 2022-06-12 05:43:30.689883
# Unit test for function curried_filter
def test_curried_filter():
    collection = range(5)
    # From left to right
    assert curried_filter(None, collection) == curried_filter(None)(collection)
    # we can make next call
    assert curried_filter(None)(collection) == curried_filter(None, collection)

    # And finally we can move with curried_filter(None)
    assert compose(
        collection,
        curried_filter(None)
    ) == collection

    # Check results
    assert compose(
        collection,
        curried_filter(lambda v: v % 2 == 0)
    ) == [0, 2, 4]



# Generated at 2022-06-12 05:43:32.337421
# Unit test for function eq
def test_eq():
    assert eq(1, 2) is False
    assert eq(1, 1) is True
    assert eq(1, 1, 1) is True



# Generated at 2022-06-12 05:43:35.754097
# Unit test for function find
def test_find():

    def is_not_two(value):
        return value != 2

    # Check find on non-empty list
    assert find([0, 1, 2], is_not_two) == 0

    # Check find on empty list
    assert find([], is_not_two) is None



# Generated at 2022-06-12 05:44:18.548331
# Unit test for function curried_filter
def test_curried_filter():
    numbers = curried_map(lambda x: x - 1, [1, 2, 3, 4])
    assert curried_filter(lambda x: x % 2, numbers)([1, 2, 3, 4]) == [2, 4]



# Generated at 2022-06-12 05:44:23.158062
# Unit test for function memoize
def test_memoize():
    """
    Unit test for function memoize.
    """
    from math import pow

    @memoize
    def square(x: int) -> int:
        return pow(x, 2)

    assert square(3) == 3 ** 2
    assert square(3) == 3 ** 2



# Generated at 2022-06-12 05:44:28.813147
# Unit test for function curried_filter
def test_curried_filter():
    list_0 = range(5)
    gt_2 = curried_filter(lambda x: x > 2)
    even = curried_filter(lambda x: x % 2 == 0)

    assert gt_2(list_0) == [x for x in list_0 if x > 2]
    assert even(list_0) == [x for x in list_0 if x % 2 == 0]



# Generated at 2022-06-12 05:44:36.540809
# Unit test for function memoize
def test_memoize():
    memoize_test_fn = lambda x: x ** 2
    memoize_test_fn_memoized = memoize(memoize_test_fn)

    assert memoize_test_fn_memoized(3) == 9
    assert memoize_test_fn_memoized(3) == 9
    assert memoize_test_fn_memoized(4) == 16
    assert memoize_test_fn_memoized(4) == 16
    assert memoize_test_fn_memoized(4) == 16

    # if key is changed, the result should be taked from cache
    memoize_test_fn_memoized = memoize(memoize_test_fn, lambda x, y: False)
    assert memoize_test_fn_memoized(3) == 9
    assert memoize_

# Generated at 2022-06-12 05:44:41.305281
# Unit test for function curried_map
def test_curried_map():
    collection = [i for i in range(3)]
    double = curried_map(lambda x: x * 2)
    assert double(collection) == [0, 2, 4]
    assert curried_map(increase)(collection) == [1, 2, 3]
    assert curried_map(identity)(collection) == collection



# Generated at 2022-06-12 05:44:45.823552
# Unit test for function curried_filter
def test_curried_filter():
    assert curry(lambda x: x, 1)(1) == 1
    assert curry(lambda x, y: x + y, 1)(1) == 2
    assert curry(lambda x, y, z: [x, y, z], 3)(1, 2, 3) == [1, 2, 3]



# Generated at 2022-06-12 05:44:52.827224
# Unit test for function curried_map
def test_curried_map():
    def add_one(item):
        return item + 1

    def double(item):
        return item * 2

    def in_range(start: int, end: int):
        def result(item: int):
            return start <= item <= end

        return result

    assert curried_map(add_one)([1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]
    print('test_curried_map() - Success')



# Generated at 2022-06-12 05:44:55.435151
# Unit test for function find
def test_find():
    assert find(
        ['one', 'two', 'three', 'four'],
        eq('two')
    ) == 'two'

    assert find(
        ['one', 'two', 'three', 'four'],
        eq('five')
    ) is None



# Generated at 2022-06-12 05:45:02.360238
# Unit test for function memoize
def test_memoize():
    def f(n):
        return n * n

    f_memoized = memoize(f)
    assert f_memoized(6) == 36
    assert f_memoized(6) == 36
    assert f_memoized(7) == 49
    assert f_memoized(7) == 49
    assert f_memoized(6) == 36



# Generated at 2022-06-12 05:45:08.057808
# Unit test for function cond
def test_cond():
    """
    >>> cond([
    ...     (lambda x: x % 2 != 0, lambda x: x*3),
    ...     (lambda x: x % 2 == 0, lambda x: x*2)
    ... ])(1)
    3
    >>> cond([
    ...     (lambda x: x % 2 != 0, lambda x: x*3),
    ...     (lambda x: x % 2 == 0, lambda x: x*2)
    ... ])(2)
    4
    """


if __name__ == "__main__":
    import doctest
    doctest.testmod()