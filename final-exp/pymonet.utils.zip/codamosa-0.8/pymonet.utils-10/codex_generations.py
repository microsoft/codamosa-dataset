

# Generated at 2022-06-12 05:36:18.202343
# Unit test for function find
def test_find():
    # Test1
    assert find([1, 2, 3], eq(1)) == 1

    # Test2
    assert find(["a", "b", "c"], eq("a")) == "a"

    # Test3
    assert find([{"a": 1}, {"a": 2}], lambda item: item["a"] == 1) == {"a": 1}

    # Test4
    assert find([], eq("a")) is None

    # Test5
    assert find([{"a": 1}, {"a": 2}], lambda item: item["a"] == 3) is None


# Generated at 2022-06-12 05:36:24.268695
# Unit test for function curried_filter
def test_curried_filter():
    # given
    collection = [1, 2, 3, 4, 5]

    # when
    filter_function = curried_filter(lambda item: item % 2 == 0)
    filtered_collection = filter_function(collection)

    # then
    assert filtered_collection == [2, 4]


# Generated at 2022-06-12 05:36:28.515055
# Unit test for function cond
def test_cond():
    f = cond([
        (eq(2), lambda x: x ** 2),
        (eq(3), lambda x: x ** 3),
    ])

    assert f(2) == 4
    assert f(3) == 27



# Generated at 2022-06-12 05:36:32.817731
# Unit test for function find
def test_find():
    assert find([], identity) is None
    assert find([], eq(1)) is None
    assert find([1], eq(1)) is not None
    assert find([1], eq(2)) is None


# Generated at 2022-06-12 05:36:36.644153
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-12 05:36:45.590985
# Unit test for function curried_filter
def test_curried_filter():
    """
    Here is an example of how curried_filter can be used:

    >>> curried_filter(lambda x: x % 2 == 0)([1, 10, 2, 5])
    [10, 2]

    >>> curried_filter(lambda x: x % 2 == 0, [1, 10, 2, 5])
    [10, 2]

    >>> curried_filter(lambda x: x % 2 == 0)(range(10))
    [0, 2, 4, 6, 8]

    >>> curried_filter(lambda x: x % 2 == 0, range(10))
    [0, 2, 4, 6, 8]
    """
    pass



# Generated at 2022-06-12 05:36:50.083782
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-12 05:36:53.222332
# Unit test for function curried_filter
def test_curried_filter():
    print(curried_filter(lambda x: x % 2 == 0)([1,2,3,4,5,6,7,8,9,10]))


# Generated at 2022-06-12 05:36:59.025918
# Unit test for function memoize
def test_memoize():
    def add(number, number2=0):
        return number1 + number2
    # Create add function which takes one argument.
    addOne = memoize(curry(add, 2)(1))
    assert addOne(1) == 2
    assert addOne(2) == 3
    assert addOne(1) == 2
    assert addOne(1) == 2



# Generated at 2022-06-12 05:37:06.089760
# Unit test for function cond
def test_cond():
    def cond_f1(a: int) -> bool:
        return a < 2

    def cond_f2(a: int) -> bool:
        return a < 3

    def cond_f3(a: int) -> bool:
        return a > 1

    def cond_f4(a: int) -> bool:
        return a > 2

    def test_execute_f1(a: int) -> str:
        return 'execute_f1'

    def test_execute_f2(a: int) -> str:
        return 'execute_f2'

    def test_execute_f3(a: int) -> str:
        return 'execute_f3'

    def test_execute_f4(a: int) -> str:
        return 'execute_f4'


# Generated at 2022-06-12 05:37:16.981301
# Unit test for function cond
def test_cond():
    assert cond([
        (eq(1), identity),
        (eq(2), increase),
        (eq(3), identity)
    ])(2) == 3

    assert cond([
        (eq(1), identity),
        (eq(2), increase),
        (eq(3), identity)
    ])(3) == 3

    assert cond([
        (eq(1), identity),
        (eq(2), increase),
        (eq(3), identity)
    ])(4) is None



# Generated at 2022-06-12 05:37:21.032797
# Unit test for function memoize
def test_memoize():
    def expensive_function(argument):
        return argument + 1

    fn = memoize(expensive_function)

    assert fn(1) == 2
    assert fn(1) == 2
    assert fn(2) == 3
    assert fn(1) == 2


# Generated at 2022-06-12 05:37:29.181762
# Unit test for function eq
def test_eq():
    """
    Function for testing eq

    :returns: 'OK' if all tests passed, otherwise 'Failed'
    :rtype: str
    """
    # Test right flow
    if eq(1, 1):
        # Test type of arguments
        if not eq('a', 'a'):
            return 'Test failed'
        # Test if function is curried
        if not eq(1)(1):
            return 'Test failed'
        # Test if function is curried and second argument is filled
        if not eq(1, 1)():
            return 'Test failed'
        return 'Ok'
    return 'Test failed'



# Generated at 2022-06-12 05:37:40.959416
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x > 0, lambda x: x + 1),
        (lambda x: x < 0, lambda x: x - 1),
        (lambda x: x == 0, lambda x: 0),
    ])(0) == 0
    assert cond([
        (lambda x: x > 0, lambda x: x + 1),
        (lambda x: x < 0, lambda x: x - 1),
        (lambda x: x == 0, lambda x: 0),
    ])(-1) == -2
    assert cond([
        (lambda x: x > 0, lambda x: x + 1),
        (lambda x: x < 0, lambda x: x - 1),
        (lambda x: x == 0, lambda x: 0),
    ])(1) == 2

# Generated at 2022-06-12 05:37:46.406325
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-12 05:37:48.339791
# Unit test for function curried_filter
def test_curried_filter():
    assert(curried_filter(eq(1))([1, 2, 3]) == [1])



# Generated at 2022-06-12 05:37:50.786881
# Unit test for function eq
def test_eq():
    assert eq(2, 2)
    assert not eq(1, 2)



# Generated at 2022-06-12 05:37:54.913138
# Unit test for function cond
def test_cond():
    """
    Test for function cond

    :returns: None
    """
    assert cond([
        (lambda x: x % 2 == 0, increase),
        (lambda x: x % 3 == 0, lambda x: x * 2),  # noqa E731
    ])(3) == 6



# Generated at 2022-06-12 05:37:59.705798
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [1, 2, 3]
                       ) == [1, 2, 3]
    assert curried_map(identity, []
                       ) == []
    assert curried_map(increase, [1, 2, 3]
                       ) == [2, 3, 4]
    assert curried_map(increase, []
                       ) == []


# Generated at 2022-06-12 05:38:03.231691
# Unit test for function find
def test_find():
    # Given
    collection = list(range(0, 10))
    fn = lambda argument: argument == 5

    # When
    result = find(collection, fn)

    # Then
    assert result == 5



# Generated at 2022-06-12 05:38:14.176705
# Unit test for function cond
def test_cond():

    cond_function = cond([
        ((lambda number: number % 2 == 0), (lambda number: 'even')),
        ((lambda number: number % 2 == 1), (lambda number: 'odd')),
    ])
    assert cond_function(0) == 'even'
    assert cond_function(1) == 'odd'
    assert cond_function(2) == 'even'
    assert cond_function(3) == 'odd'
    assert cond_function(4) == 'even'



# Generated at 2022-06-12 05:38:16.670318
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 1) == 1
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-12 05:38:21.480271
# Unit test for function find
def test_find():
    """
    Unit test for function find.
    """
    # Find one element in list
    assert find([0, 1, 2, 3], eq(1)) == 1

    # Find none elements in list
    assert find([0, 1, 2, 3], eq(4)) is None


# Generated at 2022-06-12 05:38:29.612416
# Unit test for function memoize
def test_memoize():
    import time

    @memoize
    def heavy_calculation(argument):
        time.sleep(5)
        return argument

    start_time_1 = time.clock()
    heavy_calculation(10)
    end_time_1 = time.clock()

    start_time_2 = time.clock()
    heavy_calculation(10)
    end_time_2 = time.clock()

    diff_1 = end_time_1 - start_time_1
    diff_2 = end_time_2 - start_time_2

    assert(diff_1 > diff_2)

# Generated at 2022-06-12 05:38:36.859735
# Unit test for function memoize
def test_memoize():
    assert memoize(increase)(1) == 2
    assert memoize(increase)(1) == 2
    assert memoize(increase)(2) == 3
    assert memoize(increase, eq)(2) == 3
    assert memoize(increase, eq)(2) == 3
    assert memoize(increase, eq)(1) == 2
    assert memoize(identity, eq)(1) == 1
    assert memoize(identity, eq)(1) == 1

# Generated at 2022-06-12 05:38:45.194813
# Unit test for function memoize
def test_memoize():
    from time import sleep

    count = 0

    @memoize
    def f(x):
        nonlocal count
        count += 1
        sleep(1)
        return x ** 2

    assert f(2) == 4, 'First call'
    assert count == 1, 'First call was performed'
    assert f(3) == 9, 'Second call'
    assert count == 2, 'Second call was performed'
    assert f(2) == 4, 'Check memoize'
    assert count == 2, 'No new call was performed'
    print('memoize ok!')



# Generated at 2022-06-12 05:38:49.638447
# Unit test for function memoize
def test_memoize():
    from time import time, sleep

    @memoize
    def elapsed_time():
        last_time = time()
        sleep(0.0001)
        return time() - last_time

    assert elapsed_time() == elapsed_time()


if __name__ == '__main__':
    test_memoize()

# Generated at 2022-06-12 05:38:55.455059
# Unit test for function find
def test_find():
    """
    Unit test for function find().
    """
    assert(find([1, 2, 3], lambda x: x == 3) == 3)
    assert(find([1, 2, 3], lambda x: x == 4) is None)
    assert(find([], lambda x: x == 3) is None)



# Generated at 2022-06-12 05:38:56.939753
# Unit test for function eq
def test_eq():
    assert(eq(2, 2) == True)
    assert(eq(1, 2) == False)



# Generated at 2022-06-12 05:39:07.516584
# Unit test for function find
def test_find():
    lis = [
        {'name': 'Piter', 'age': '21'},
        {'name': 'Olga', 'age': '20'},
        {'name': 'Ivanov', 'age': '22'},
        {'name': 'Olga', 'age': '18'},
    ]
    search_name = 'Olga'
    search_age = '20'
    result = find(lis, lambda item: item['name'] == 'Olga' and item['age'] == '20')
    assert result == {'name': 'Olga', 'age': '20'}
    print('Ok!\n')


# Generated at 2022-06-12 05:39:14.613116
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-12 05:39:17.618210
# Unit test for function eq
def test_eq():
    assert eq(1, 2) == False
    assert eq(1, 1) == True
    assert eq(1, '1') == False



# Generated at 2022-06-12 05:39:22.939897
# Unit test for function memoize
def test_memoize():
    """
    Unit test for function memoize (self-test).
    """
    n = 1


    @memoize
    def fib(n):
        return n if n < 2 else fib(n - 1) + fib(n - 2)


    while True:
        print(fib(n))
        n += 1
        time.sleep(0.5)


if __name__ == "__main__":
    test_memoize()

# Generated at 2022-06-12 05:39:30.671505
# Unit test for function cond
def test_cond():
    def larger_than(value):
        return lambda x: x > value

    def less_than_or_eq(value):
        return lambda x: x <= value

    def multiply(value):
        return lambda x: x * value

    def divide(value):
        return lambda x: x // value

    solution = cond([
        (larger_than(5), multiply(5)),
        (less_than_or_eq(5), multiply(2)),
    ])

    assert solution(10) == 50
    assert solution(4) == 8



# Generated at 2022-06-12 05:39:36.843816
# Unit test for function cond
def test_cond():

    def is_one(value):
        return value == 1

    def is_two(value):
        return value == 2

    @cond([
        (is_one, lambda x: 'one'),
        (is_two, lambda x: 'two'),
    ])
    def return_as_string(value):
        return value

    assert return_as_string(1) == 'one'
    assert return_as_string(2) == 'two'
    assert return_as_string(3) == 3



# Generated at 2022-06-12 05:39:43.465655
# Unit test for function memoize
def test_memoize():
    def test_fibonacci(value: int) -> int:
        if (value == 0):
            return 0
        if (value == 1):
            return 1
        return test_fibonacci(value - 1) + test_fibonacci(value -2)

    fibonacci = memoize(test_fibonacci)
    assert fibonacci(10) == 55



# Generated at 2022-06-12 05:39:48.267221
# Unit test for function find
def test_find():
    data = [1, 2, 3, 4, 5]
    assert find(data, lambda x: x == 3) == 3
    assert find(data, lambda x: x == 4) == 4
    assert find(data, lambda x: x == 5) == 5
    assert find(data, lambda x: x == 6) is None



# Generated at 2022-06-12 05:39:51.234640
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(filter_odd, [1, 2, 3, 4, 5]) == [1, 3, 5]



# Generated at 2022-06-12 05:39:57.064756
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False
    assert eq(1, '1') is False
    assert eq(1, '1')(1) is False
    assert eq(1, '1')(2) is False
    assert eq('1')('1') is True
    assert eq(False)(False) is True
    assert eq([1, 2], [1, 2]) is True



# Generated at 2022-06-12 05:40:03.682154
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6



# Generated at 2022-06-12 05:40:23.215537
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x[0] == "a", lambda x: "aa"),
        (lambda x: x[0] == "b", lambda x: "bb"),
    ])("a") == "aa"
    assert cond([
        (lambda x: x[0] == "a", lambda x: "aa"),
        (lambda x: x[0] == "b", lambda x: "bb"),
    ])("c") is None
    assert cond([
        (lambda x: x[0] == "a", lambda x: "aa"),
        (lambda x: x[0] == "b", lambda x: "bb"),
    ])("b") == "bb"


# Generated at 2022-06-12 05:40:24.675366
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b, c: a + b + c)(1)(2)(3) == 6

# Generated at 2022-06-12 05:40:27.479026
# Unit test for function cond
def test_cond():
    print('Test cond function')
    print(cond([
        (lambda x: x % 2 == 0, lambda x: x * x),
        (lambda x: x % 2 == 1, lambda x: x + 2)
    ])(9))



# Generated at 2022-06-12 05:40:30.126183
# Unit test for function find
def test_find():
    assert find(["a", "b", "c"], lambda x: x == "b") == "b"



# Generated at 2022-06-12 05:40:34.612219
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)
    assert eq(1)('1')
    assert not eq('1')(1)



# Generated at 2022-06-12 05:40:42.837655
# Unit test for function curried_map
def test_curried_map():
    increment = lambda x: x + 1
    assert curried_map(increment)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increment, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increment)([1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]
    assert curried_map(increment, [1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]
    assert curried_map(increment, []) == []



# Generated at 2022-06-12 05:40:49.446559
# Unit test for function find
def test_find():
    print('This is test for function find:', end='\n\n')
    find_test_list = [
        {'id': 'first', 'data': '11'},
        {'id': 'second', 'data': '22'},
        {'id': 'third', 'data': '33'},
    ]
    find_test_key = lambda x: x['id'] == 'second'

    print('List to search: \n\t', find_test_list, sep='')
    print('Key to search: \n\t', find_test_key, sep='')
    print('Result of searching: \n\t', find(find_test_list, find_test_key), sep='')

# Generated at 2022-06-12 05:40:52.316177
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(0, 1)



# Generated at 2022-06-12 05:41:01.798814
# Unit test for function memoize
def test_memoize():
    """
    Unit test for function memoize
    """
    def identity(value: T) -> T:
        """
        Return first argument.

        :param value:
        :type value: Any
        :returns:
        :rtype: Any
        """
        return value

    memoized = memoize(identity)
    cached = memoized("value")
    assert cached == "value"

    assert id(memoized("value")) == id(cached)
    assert memoized("value2") != "value"
    assert memoized("value2") == "value2"
    assert memoized("value2", eq) == "value2"
    assert memoized("value2", eq) == "value2"
    assert memoized("value2", eq) == "value2"



# Generated at 2022-06-12 05:41:03.746536
# Unit test for function curry
def test_curry():
    assert curry(eq)(1, 1) == True
    assert curry(eq)(1)(1) == True


# Generated at 2022-06-12 05:41:16.542193
# Unit test for function curried_map
def test_curried_map():
    increment = lambda x: x + 1
    collection = [1, 2, 3]
    new_collection = curried_map(increment)(collection)

    assert new_collection == [2, 3, 4]



# Generated at 2022-06-12 05:41:23.678638
# Unit test for function curry
def test_curry():
    @curry
    def add(x, y):
        return x + y
    assert add(2)(3) == add(2, 3)
    assert add(2)(3)(4)(5)(6)(7)(8)(9)(10)(11)(12) == 75
    assert add(2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12) == 75


# Generated at 2022-06-12 05:41:29.154255
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x == 0, lambda x: 'Zero'),
        (lambda x: x % 2 == 1, lambda x: 'Odd'),
        (lambda x: x % 2 == 0, lambda x: 'Even'),
    ])(2) == 'Even'


# Generated at 2022-06-12 05:41:31.492483
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-12 05:41:33.083235
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 3]
    result = curried_filter(eq(2))(collection)
    assert result == [2]

# Generated at 2022-06-12 05:41:34.798424
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5]) == [2, 4]



# Generated at 2022-06-12 05:41:37.748796
# Unit test for function eq
def test_eq():
    assert eq(2, 3) == False
    assert eq(2, 2) == True
    assert eq(2)(2) == True



# Generated at 2022-06-12 05:41:43.379993
# Unit test for function cond
def test_cond():
    true = lambda: True
    false = lambda: False
    identity = lambda value: value
    identity1 = lambda value: value
    identity2 = lambda value: value
    print(cond([(true, identity1), (false, identity2)])(1))
    print(cond([(false, identity1), (true, identity2)])(1))
    print(cond([(true, identity1), (true, identity2)])(1))



# Generated at 2022-06-12 05:41:45.225397
# Unit test for function memoize
def test_memoize():
    assert memoize(increase)(10) == increase(10)
    assert memoize(increase)(10) == increase(10)



# Generated at 2022-06-12 05:41:49.413931
# Unit test for function curry
def test_curry():
    f_curry = curry(lambda a, b, c: a + b + c)
    assert f_curry(1)(2)(3) == f_curry(1, 2)(3) == f_curry(1)(2, 3) == f_curry(1, 2, 3) == 6



# Generated at 2022-06-12 05:42:11.874523
# Unit test for function eq
def test_eq():
    # We test two conditions for function to be curried
    test_true_condition = eq(1)(1)
    assert test_true_condition is True

    test_false_condition = eq(1)(2)
    assert test_false_condition is False



# Generated at 2022-06-12 05:42:16.083350
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda v: v, (lambda v: v)),
        (lambda v: True, (lambda v: v + 1))
    ])(1) == 1
    assert cond([
        (lambda v: v, (lambda v: v)),
        (lambda v: True, (lambda v: v + 1))
    ])(0) == 1



# Generated at 2022-06-12 05:42:25.188209
# Unit test for function cond
def test_cond():
    def fn1(a):
        return a > 1

    def fn2(a):
        return a > 2

    def fn3(a):
        return a * 2

    def fn4(a):
        return a * 3

    def fn5(a):
        return a * 4

    function = cond([
        (fn1, fn3),
        (fn2, fn4),
    ])

    assert function(3) == fn3(3)
    assert function(4) == fn4(4)

    function = cond([
        (fn1, fn3),
        (fn2, fn4),
        (fn5, fn5),
    ])

    assert function(3) == fn3(3)
    assert function(4) == fn4(4)
    assert function(5) == fn5(5)




# Generated at 2022-06-12 05:42:30.893835
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert curried_map(increase, [1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]
    assert curried_map(increase)([1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]



# Generated at 2022-06-12 05:42:34.295970
# Unit test for function eq
def test_eq():
    assert eq(1, 2) == False
    assert eq(1, 1) == True
    assert eq(1)(1) == True
    assert eq(1)(2) == False
    print('Test eq: OK')


# Generated at 2022-06-12 05:42:43.473154
# Unit test for function curry
def test_curry():
    assert curried_map(lambda x: x + 1, [1, 2]) == [2, 3]
    assert curried_map(lambda x: x + 1, [1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]
    assert curried_map(lambda x: x[:-1], ['string1', 'string2', 'string3']) == ['strin', 'strin', 'strin']
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]



# Generated at 2022-06-12 05:42:54.197848
# Unit test for function curry
def test_curry():
    add2 = curry(lambda x, y: x + y)
    assert (add2(1)(1) == 2)
    assert (add2(2)(2) == 4)
    assert (add2(3)(3) == 6)

    mul3 = curry(lambda x, y, z: x * y * z)
    assert (mul3(1)(1)(1) == 1)
    assert (mul3(2)(2)(2) == 8)
    assert (mul3(3)(3)(3) == 27)

    pow2 = curry(lambda x, y: x ** y)
    assert (pow2(2)(2) == 4)
    assert (pow2(3)(3) == 27)
    assert (pow2(4)(4) == 256)



# Generated at 2022-06-12 05:43:02.486678
# Unit test for function memoize
def test_memoize():
    assert memoize(lambda a: a + 1)(3) == 4
    assert memoize(lambda a: a + 1)(3) == 4
    assert memoize(lambda a: a + 1)(4) == 5

    fn_with_side_effect = lambda a: a + 1
    memoized = memoize(fn_with_side_effect)

    assert memoized(3) == 4
    assert fn_with_side_effect.__name__ == '<lambda>'
    assert memoized.__name__ == 'memoized'



# Generated at 2022-06-12 05:43:12.235258
# Unit test for function cond
def test_cond():
    def is_even(x):
        return x % 2 == 0

    def is_odd(x):
        return x % 2 == 1

    def is_greater_than_10(x):
        return x > 10

    def increase_by_1(x):
        return x + 1

    def increase_by_2(x):
        return x + 2

    def multiply_by_2(x):
        return x * 2

    def compose_functions(*functions):
        return lambda v: functools.reduce(lambda f, g: g(f), functions, v)

    increase = compose_functions(increase_by_2, increase_by_1)


# Generated at 2022-06-12 05:43:21.596339
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1,2,3,4]) == [2,4]
    assert curried_filter(lambda x: x[0] == 'e', ['ear', 'nose', 'mouth']) == ['ear','mouth']
    assert curried_filter(lambda x: x ** 2, [1,2,3,4]) == [1,4,9,16]
    assert curried_filter(lambda x: x[0] == 'e', ['ear', 'nose', 'mouth']) == ['ear', 'mouth']


# Generated at 2022-06-12 05:44:34.694246
# Unit test for function find
def test_find():
    some_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    found_item = find(lambda x: x % 2 == 1)(some_list)

    if found_item != 1:
        raise Exception('Wrong result of function find')


# Generated at 2022-06-12 05:44:36.575540
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-12 05:44:40.678531
# Unit test for function memoize
def test_memoize():
    @memoize
    def sum(*args):
        return reduce(operator.add, args)

    assert sum(1, 2, 3) == 6
    assert sum(1, 3, 3) == 7


if __name__ == '__main__':
    test_memoize()

# Generated at 2022-06-12 05:44:48.069248
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)(tuple([1, 2, 3])) == (2, 3, 4)
    assert curried_map(increase)({'a': 1, 'b': 2, 'c': 3}) == {'a': 2, 'b': 3, 'c': 4}
    assert curried_map(increase)((1, 2, 3)) == (2, 3, 4)



# Generated at 2022-06-12 05:44:52.391798
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4]) == [3, 4]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4, 3, 2]) == [3, 4, 3]



# Generated at 2022-06-12 05:44:57.265120
# Unit test for function memoize
def test_memoize():
    def length(word):
        x = 0
        for letter in word:
            x += 1
        return x

    length = memoize(length)
    assert length('hello') == 5
    assert length('world') == 5

    def length(word):
        x = 0
        for letter in word:
            x += 1
        return x

    length = memoize(length, eq)
    assert length('hello') == 5
    assert length('world') == 5



# Generated at 2022-06-12 05:45:03.236621
# Unit test for function curried_filter
def test_curried_filter():
    data = [1, 2, 3, 4, 5]
    pass_test = curried_filter(lambda x: x % 2 == 0)
    result = curried_filter(lambda x: x > 3, data)
    assert pass_test(data) == [2, 4]
    assert result == [4, 5]



# Generated at 2022-06-12 05:45:07.675541
# Unit test for function find
def test_find():
    """
    Test of find

    :returns: True or AssertionError
    :rtype: Boolean
    """
    assert find([], identity) is None
    assert find([1], eq(1)) == 1
    assert find([1], eq(2)) is None
    assert find([2, 1], eq(1)) == 1
    assert find(['a', 'b', 'c'], eq('b')) == 'b'
    return True



# Generated at 2022-06-12 05:45:11.391530
# Unit test for function cond
def test_cond():
    def test_function(arg):
        return cond([
            (eq(arg), curry(lambda arg: arg + 1)),
            (eq(arg), curry(lambda arg: arg * 2)),
        ])

    assert test_function(1) == 2
    assert test_function(2) == 4



# Generated at 2022-06-12 05:45:20.159464
# Unit test for function find
def test_find():
    test_data = [
        ((0, [1, 2, 3]), None),
        ((1, [1, 2, 3]), 1),
        ((2, [1, 2, 3]), 2),
        ((3, [1, 2, 3]), 3),
        ((4, [1, 2, 3]), None),
    ]
    for test_input, expected_result in test_data:
        actual_result = find(*test_input)
        assert actual_result == expected_result, "{} != {} for {}".format(
            actual_result, expected_result, test_input)
    print("Unit test for function find - PASSED")
