

# Generated at 2022-06-12 05:36:12.814056
# Unit test for function memoize
def test_memoize():
    def mul2(a):
        return a * 2


    # Test multiply by 2
    assert 2 == mul2(1)
    assert 4 == mul2(2)
    assert 6 == mul2(3)

    mul2_cached = memoize(mul2)

    # Test cached multiply by 2
    assert 2 == mul2_cached(1)
    assert 4 == mul2_cached(2)
    assert 6 == mul2_cached(3)
    assert 2 == mul2_cached(1)
    assert 4 == mul2_cached(2)
    assert 6 == mul2_cached(3)

    def plus3(a):
        return a + 3


    # Test plus 3
    assert 4 == plus3(1)
    assert 5 == plus3(2)
    assert 6 == plus

# Generated at 2022-06-12 05:36:19.039593
# Unit test for function cond
def test_cond():
    @cond([
        (lambda number: number == 1, identity),
        (lambda number: number == 0, lambda number1: number1 + 2),
        (lambda number: number == 3, lambda number1: number1 - 2),
    ])
    def cond_test(number: int) -> int:
        return None

    assert cond_test(1) == 1
    assert cond_test(0) == 2
    assert cond_test(3) == 1



# Generated at 2022-06-12 05:36:23.436637
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(2)) == 2
    assert find(['a', 'b', 'ba'], eq('ba')) == 'ba'
    assert find([1, 2, 3], eq(4)) is None

# Generated at 2022-06-12 05:36:28.065150
# Unit test for function curried_filter
def test_curried_filter():
    assert(curried_filter(eq(1))([1, 2, 3, 4, 1]) == [1, 1])
    assert(curried_filter(eq(1))([2, 3, 4]) == [])
    assert(curried_filter(eq(2))([2, 3, 4]) == [2])


# Generated at 2022-06-12 05:36:33.223269
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x*2, [1, 2, 3]) == [2, 4, 6]
    assert curried_map(lambda x: x*x, [1, 2, 3]) == [1, 4, 9]
    mapper = curried_map(lambda x: x*2)
    assert mapper([1, 2, 3]) == [2, 4, 6]
    assert mapper([1, 2, 3, 4]) == [2, 4, 6, 8]


# Generated at 2022-06-12 05:36:37.957021
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 3), 3
    assert find([1, 2, 3, 4], lambda x: x == 5) is None


# Generated at 2022-06-12 05:36:43.302634
# Unit test for function curry
def test_curry():
    assert curry(add)(1)(2) == 3
    assert curry(add, 3)(1, 2, 3) == 6
    assert curry(add, 3)(1)(2, 3) == 6



# Generated at 2022-06-12 05:36:48.987435
# Unit test for function memoize
def test_memoize():
    import time

    @memoize
    def time_consuming_function(key):
        time.sleep(2)
        return (key * 9)**2

    assert time_consuming_function(5) == 1125
    assert time_consuming_function(5) == 1125
    assert time_consuming_function(10) == 10000
    assert time_consuming_function(10) == 10000

# Generated at 2022-06-12 05:36:54.411739
# Unit test for function find
def test_find():
    lst = [5, 4, 3, 2, 1]
    assert find(lst, lambda x: x == 3) == 3
    assert find(lst, lambda x: x % 2 == 0) == 4
    assert find(lst, lambda x: x > 5) is None



# Generated at 2022-06-12 05:37:03.954011
# Unit test for function find
def test_find():
    # Find by eq
    assert find([1, 2, 3, 4], eq(3)) == 3

    # Find by eq in list
    assert find(
        [
            [1, 2, 3],
            [2, 3, 4],
            [3, 4, 5]
        ],
        eq([2, 3, 4])
    ) == [2, 3, 4]

    # Find by eq in list in list

# Generated at 2022-06-12 05:37:10.316710
# Unit test for function curried_map
def test_curried_map():
    assert eq(
        curried_map(lambda item: item + 2)([1, 2, 3]),
        [3, 4, 5]
    )
    print('Test for curried_map is passed successfully')



# Generated at 2022-06-12 05:37:17.344499
# Unit test for function memoize
def test_memoize():
    @memoize
    def add(x, y):
        return x + y

    assert add(1, 1) == add(1, 1)
    assert add(2, 3) == add(2, 3)
    assert add(1, 1) != add(1, 2)

    @memoize
    def multiply(x, y):
        return x * y

    assert multiply(2, 3) == 6
    assert multiply(2, 3) == multiply(2, 3)
    assert multiply(2, 3) == multiply(2, 4)



# Generated at 2022-06-12 05:37:24.242435
# Unit test for function cond
def test_cond():
    assert cond([(eq(0), identity),
                 (eq(1), increase)])(1) == 2
    assert cond([(eq(0), identity),
                 (eq(1), increase),
                 (eq(2), increase)])(1) == 2
    assert cond([(eq(0), identity),
                 (eq(1), increase),
                 (eq(2), increase)])(2) == 3


# Unit tests for function compose

# Generated at 2022-06-12 05:37:29.001467
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda n: n % 2 == 0)((n for n in range(100))) == [n for n in range(100) if n % 2 == 0]
    assert curried_filter(lambda n: n % 2 == 0)([1, 2, 3]) == [2]
    assert curried_filter(lambda n: n % 2 == 0)((1, 2, 3)) == (2,)



# Generated at 2022-06-12 05:37:34.230851
# Unit test for function find
def test_find():
    result = find([1, 2, 3, 4], lambda x: x > 3)
    assert result == 4
    assert result is not None
    assert result != None

    result = find([1, 2, 3, 4], lambda x: x > 4)
    assert result is None
    assert result == None


# Generated at 2022-06-12 05:37:37.113611
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], identity) == 1
    assert find([1, 2, 3, 4], increase) is None

# Unit tests for function eq

# Generated at 2022-06-12 05:37:42.375483
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq(1, 1, 1) == True
    assert eq(1, 1, 2) == False
    assert eq(1)(1) == True
    eq1 = eq(1)
    assert eq1(1) == True
    assert eq1(2) == False



# Generated at 2022-06-12 05:37:48.116538
# Unit test for function memoize
def test_memoize():
    """
    This is Unit test for function memoize.

    :return: pass
    """
    def fn(arg):
        """
        Function for test memoize function.

        :param arg:
        :return:
        """
        nonlocal counter
        counter += 1
        return arg

    counter = 0
    memoized = memoize(fn)
    memoized('1')
    memoized('2')
    memoized('3')
    memoized('1')
    memoized('1')
    memoized('1')
    memoized('2')
    memoized('2')
    memoized('2')
    memoized('3')
    memoized('3')
    memoized('3')
    assert counter == 3

# Generated at 2022-06-12 05:37:54.464841
# Unit test for function find
def test_find():
    assert find([], eq(5)) is None
    assert find([1, 2, 3, 4], eq(5)) is None
    assert find([1, 2, 3, 4, 5], eq(5)) == 5

    add1 = lambda x: x + 1
    double = lambda x: x * 2
    assert compose(5, add1, double)(3) == 8
    assert pipe(3, double, add1)(5) == 8



# Generated at 2022-06-12 05:38:02.278001
# Unit test for function cond
def test_cond():
    # Create first and second condition functions
    condition_fn_1 = lambda value: value == 1
    condition_fn_2 = lambda value: value == 2

    # Create first and second execute functions
    execute_fn_1 = lambda value: value + 2
    execute_fn_2 = lambda value: value + 3

    # Create combined functions
    combined_fn_1 = cond([(condition_fn_1, execute_fn_1)])
    combined_fn_2 = cond([(condition_fn_2, execute_fn_2)])

    # Create list of above combined functions
    fn_list = [combined_fn_1, combined_fn_2]

    # Get combined function witch condition function return truly value
    get_combined_fn = find(fn_list, lambda fn: fn(2) == 5)

    assert get_comb

# Generated at 2022-06-12 05:38:10.900875
# Unit test for function cond
def test_cond():
    def is_even(x):
        return x % 2 == 0
    def is_odd(x):
        return not is_even(x)

    assert cond([
        (is_even, increase),
        (is_odd, identity)
    ])(1) == 1

    assert cond([
        (is_even, increase),
        (is_odd, identity)
    ])(2) == 3



# Generated at 2022-06-12 05:38:13.401541
# Unit test for function find
def test_find():
    collection = [1, 2, 3, 4]
    assert find(collection, lambda item: item == 5) is None
    assert find(collection, lambda item: item == 4) == 4



# Generated at 2022-06-12 05:38:15.598835
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-12 05:38:18.430456
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 3, 4, 5]
    assert curried_filter(lambda item: item > 3, collection) == [4, 5]



# Generated at 2022-06-12 05:38:26.714426
# Unit test for function cond
def test_cond():
    def is_even(number):
        return number % 2 == 0

    def is_odd(number):
        return number % 2 != 0

    def add(number):
        return number + 1

    def multiply(number):
        return number * 2

    counter = 0
    cases = [
        (is_even, add),
        (is_odd, multiply),
    ]
    result = cond(cases)
    while counter < 5:
        assert result(counter) == counter + 1
        counter += 1
    while counter < 10:
        assert result(counter) == counter * 2
        counter += 1

# Generated at 2022-06-12 05:38:33.842117
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x == 'foo',
         lambda: 'return foo'),
        (lambda x: x == 'bar',
         lambda: 'return bar')
    ])('foo') == 'return foo'

    assert cond([
        (lambda x: x == 'foo',
         lambda: 'return foo'),
        (lambda x: x == 'bar',
         lambda: 'return bar')
    ])('bar') == 'return bar'

    assert cond([
        (lambda x: x == 'foo',
         lambda: 'return foo'),
        (lambda x: x == 'bar',
         lambda: 'return bar')
    ])('baz') == None

# Generated at 2022-06-12 05:38:37.050682
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]



# Generated at 2022-06-12 05:38:39.294258
# Unit test for function curried_map
def test_curried_map():
    curried_map_increase = curried_map(increase)
    assert curried_map_increase([1, 2, 3, 4]) == [2, 3, 4, 5]



# Generated at 2022-06-12 05:38:48.756699
# Unit test for function memoize
def test_memoize():
    global i
    to_power = lambda x, y: x ** y
    to_power = curry(to_power)
    to_power = memoize(to_power)

    i = 0

    def log(argument, result):
        global i
        assert argument == result, "argument " + str(argument) + " and result " + str(result)

        i += 1

    for i in range(0, i + 10):
        log(i, to_power(i)(i))

    assert i == 10


if __name__ == '__main__':
    test_memoize()

# Generated at 2022-06-12 05:38:53.383967
# Unit test for function cond
def test_cond():
    hello = lambda x: 'Hello ' + x
    say_hello = cond([
        (eq(True), hello),
        (eq(False), identity),
    ])
    assert say_hello("Python") == "Hello Python"
    assert say_hello(False) == False



# Generated at 2022-06-12 05:39:00.800564
# Unit test for function memoize
def test_memoize():
    calls = 0

    @memoize
    def increment(value):
        nonlocal calls
        calls += 1
        return value + 1

    assert calls == 0
    assert increment(1) == 2
    assert calls == 1
    assert increment(2) == 3
    assert calls == 2
    assert increment(2) == 3
    assert calls == 2



# Generated at 2022-06-12 05:39:06.791866
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda x: x % 2 == 0) == 2
    assert find([1, 2, 3, 4, 5], lambda x: x > 5) is None

test_find()


# Generated at 2022-06-12 05:39:11.835668
# Unit test for function memoize
def test_memoize():
    import time

    @memoize
    def heavy_function(argument):
        time.sleep(2)
        return argument

    start = time.time()
    assert heavy_function(1) == 1
    stop = time.time()
    heavy_function_time = stop - start

    start = time.time()
    assert heavy_function(1) == 1
    stop = time.time()
    cached_heavy_function_time = stop - start

    assert cached_heavy_function_time < heavy_function_time


# Generated at 2022-06-12 05:39:13.161076
# Unit test for function eq
def test_eq():
    assert eq(1, 1)



# Generated at 2022-06-12 05:39:15.036032
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-12 05:39:18.069055
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(0, False)



# Generated at 2022-06-12 05:39:21.124028
# Unit test for function memoize
def test_memoize():
    add = memoize(lambda x: x + 1)
    assert add(1) == 2
    assert add(1) == 2


if __name__ == '__main__':
    test_memoize()

# Generated at 2022-06-12 05:39:25.496775
# Unit test for function find
def test_find():
    collection = [1, 2, 3]
    key = lambda x: x == 2

    assert find(collection, key) == 2

    key = lambda x: x == 4

    assert find(collection, key) is None

# Generated at 2022-06-12 05:39:35.996980
# Unit test for function cond
def test_cond():
    """
    1) Test cond with three-item input list
    2) Test cond with empty input list
    """
    # 1) Test cond with three-item input list
    first_condition = cond([
        ((lambda a: a > 0), (lambda a: lambda b: a * b)),
        ((lambda a: a < 0), (lambda a: lambda b: 1 / (a * b))),
        ((lambda a: a == 0), (lambda: lambda: 1))
    ])

    assert first_condition(2)(3) == 6
    assert first_condition(-2)(3) == -0.3333333333333333
    assert first_condition(0)(3) == 1
    # 2) Test cond with empty input list
    second_condition = cond([])

    assert second_condition == None


# Generated at 2022-06-12 05:39:47.642679
# Unit test for function cond
def test_cond():
    assert eq(cond([
        (identity, identity),
        (identity, identity),
    ])(1), identity(1))
    assert eq(cond([
        (identity, identity),
        (identity, identity),
        (identity, identity),
    ])(1), identity(1))
    assert eq(cond([
        (identity, identity),
    ])(1), identity(1))
    assert eq(cond([
        (identity, compose(identity, identity)),
        (identity, identity),
        (identity, identity),
    ])(1), identity(1))
    assert eq(cond([
        (identity, identity),
        (identity, compose(identity, identity)),
        (identity, identity),
    ])(1), identity(1))

# Generated at 2022-06-12 05:39:53.221049
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-12 05:39:55.822966
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x >= 0, [-1, -2, 1, 2]) == [1, 2]


# Generated at 2022-06-12 05:39:58.692171
# Unit test for function eq
def test_eq():
    assert eq(1, 2) == False
    assert eq(1, 1) == True
    assert eq(1, 1, 2) == False



# Generated at 2022-06-12 05:40:02.421429
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]



# Generated at 2022-06-12 05:40:10.065289
# Unit test for function cond
def test_cond():
    assert cond([(lambda n: n == 0, lambda n: 'water freezes at 0°C'),
                 (lambda n: n == 100, lambda n: 'water boils at 100°C'),
                 (lambda n: True, lambda n: 'nothing special happens at {0}°C'.format(n))])(0) == 'water freezes at 0°C'
    assert cond([(lambda n: n == 0, lambda n: 'water freezes at 0°C'),
                 (lambda n: n == 100, lambda n: 'water boils at 100°C'),
                 (lambda n: True, lambda n: 'nothing special happens at {0}°C'.format(n))])(100) == 'water boils at 100°C'

# Generated at 2022-06-12 05:40:15.587516
# Unit test for function memoize
def test_memoize():
    @memoize
    def factorial(n):
        if n == 0:
            return 1
        else:
            return n * factorial(n - 1)

    assert factorial(0) == 1
    assert factorial(1) == 1
    assert factorial(10) == 3628800
    assert factorial(10) == 3628800



# Generated at 2022-06-12 05:40:20.121854
# Unit test for function memoize
def test_memoize():
    x = 0

    def increase_x():
        nonlocal x
        x += 1
        return x

    increase_x_memoized = memoize(increase_x)

    assert increase_x() == 1
    assert increase_x() == 2
    assert increase_x_memoized() == 3
    assert increase_x_memoized() == 3



# Generated at 2022-06-12 05:40:25.529574
# Unit test for function eq
def test_eq():
    test_values = [
        {'a': 2, 'b': 2},
        {'a': 3, 'b': 3},
        {'a': 2, 'b': 3},
        {'a': 3, 'b': 2}
    ]
    for test_value in test_values:
        assert (
            eq(test_value['a'], test_value['b']) == (test_value['a'] == test_value['b'])
        )



# Generated at 2022-06-12 05:40:27.562100
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False
    assert eq(1)
    assert not (eq(1)(2))



# Generated at 2022-06-12 05:40:34.089525
# Unit test for function curried_map
def test_curried_map():
    assert list(map(increase, [1, 2, 3])) == [2, 3, 4]
    assert list(curried_map(increase)([1, 2, 3])) == [2, 3, 4]
    assert list(curried_map(increase, [1, 2, 3])) == [2, 3, 4]



# Generated at 2022-06-12 05:40:44.692142
# Unit test for function curried_filter
def test_curried_filter():
    """
    Test function curried_filter.

    :returns:
    :rtype:
    """
    assert ([1, 2, 3, 4, 5] == curried_filter(lambda x: x < 6)([1, 2, 3, 4, 5, 6]))
    assert ([1, 2, 3, 4, 5] == curried_filter(lambda x: x < 6)([1, 2, 3, 4, 5, 6]))


# Generated at 2022-06-12 05:40:48.801775
# Unit test for function curried_filter
def test_curried_filter():
    curried_filter_is_instance_of_int = curried_filter(lambda x: isinstance(x, int))
    assert [0, 1, 2] == curried_filter_is_instance_of_int([0, '1', 2])



# Generated at 2022-06-12 05:40:52.251653
# Unit test for function curried_map
def test_curried_map():
    result = curried_map(lambda x: x + 1, [1, 2, 3])
    assert result == [2, 3, 4]


# Generated at 2022-06-12 05:40:57.793723
# Unit test for function eq
def test_eq():
    # Check for case when both object equal
    assert eq(1, 1) is True
    # Check for case when objects are not equal
    assert eq(1, 2) is False
    # Check for case when argument is None
    assert eq(1, None) is False
    # Check for case when both argument are None
    assert eq(None, None) is True



# Generated at 2022-06-12 05:41:03.685515
# Unit test for function find
def test_find():
    collection: List[Tuple[str, int]] = [('a', 1), ('b', 2), ('c', 3)]
    key: Callable[[Tuple[str, int]], bool] = lambda item: item[1] == 2
    assert find(collection, key) == ('b', 2)
    assert find(collection, lambda item: item[1] == 4) is None



# Generated at 2022-06-12 05:41:07.602701
# Unit test for function cond
def test_cond():
    # Example of usage:
    print((cond([
        (lambda x: x < 0, lambda x: x ** 2),
        (lambda x: x > 0, lambda x: x + 1),
        (lambda x: x == 0, lambda x: x),
    ])(0)))
    # print: 0



# Generated at 2022-06-12 05:41:14.907343
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x % 2 == 0, lambda x: 'even'),
        (lambda x: True, lambda x: 'odd'),
    ])(0) == 'even'
    assert cond([
        (lambda x: x % 2 == 0, lambda x: 'even'),
        (lambda x: True, lambda x: 'odd'),
    ])(1) == 'odd'



# Generated at 2022-06-12 05:41:20.727994
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1,2,3]) == [1,2,3]
    assert curried_map(increase)([1,2,3]) == [2,3,4]


# Generated at 2022-06-12 05:41:22.494829
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4, 5]) == [3, 4, 5]


# Generated at 2022-06-12 05:41:24.066839
# Unit test for function eq
def test_eq():
    assert eq(2, 2) is True
    assert eq(2, 3) is False



# Generated at 2022-06-12 05:41:35.415583
# Unit test for function memoize
def test_memoize():
    def test_memoize_func(a):
        return a

    memoized_func = memoize(test_memoize_func)
    assert memoized_func(1) == 1
    assert memoized_func(1) == 1
    assert memoized_func(2) == 2
    assert memoized_func(2) == 2



# Generated at 2022-06-12 05:41:43.561673
# Unit test for function cond
def test_cond():
    def match(value):
        return cond([
            (lambda x: x == 1, lambda x: "one"),
            (lambda x: x == 2, lambda x: "two"),
            (lambda x: x == 3, lambda x: "three"),
            (lambda x: x == 4, lambda x: "four"),
        ])(value)

    assert match(1) == "one"
    assert match(2) == "two"
    assert match(3) == "three"
    assert match(4) == "four"
    assert match(5) is None



# Generated at 2022-06-12 05:41:45.895145
# Unit test for function memoize
def test_memoize():
    def func(value):
        return value**2 + 1

    func = memoize(func)

    assert func(100) == 100**2 + 1
    assert func(100) == 100**2 + 1

# Generated at 2022-06-12 05:41:49.814656
# Unit test for function cond
def test_cond():
    assert cond(
        [(eq(1), lambda: 1), (eq(2), lambda: 2)]
    )(2) == 2

    assert cond(
        [(eq(1), lambda: 1), (eq(2), lambda: 2)]
    )(1) == 1



# Generated at 2022-06-12 05:41:51.467966
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2]) == [1, 2]



# Generated at 2022-06-12 05:41:56.026017
# Unit test for function eq
def test_eq():
    assert True == eq(1, 1)
    assert False == eq(1, 2)
    assert True == eq(eq(1, 1), eq(1, 1))
    assert True == eq(eq(1, 1))(eq(1, 1))



# Generated at 2022-06-12 05:41:58.666642
# Unit test for function curried_map
def test_curried_map():
    mapped_increased = curried_map(increase)

    assert mapped_increased([1, 2, 3]) == [2, 3, 4]
    assert mapped_increased([]) == []



# Generated at 2022-06-12 05:42:04.987698
# Unit test for function curry
def test_curry():
    assert identity(1) == 1
    assert increase(1) == 2
    assert eq(1, 1) is True
    assert increase == curry(lambda x: x + 1)(1)
    assert (curried_map(lambda x: x + 1) ==
            curried_map(lambda x: x + 1, [1, 2, 3]))
    assert (curried_filter(lambda x: x % 2 == 0) ==
            curried_filter(lambda x: x % 2 == 0, [1, 2, 3]))



# Generated at 2022-06-12 05:42:10.754229
# Unit test for function curried_filter
def test_curried_filter():
    test_list = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    even_checker = lambda x: x % 2 == 0
    even_filtered_list = curried_filter(even_checker, test_list)
    another_even_filtered_list = curried_filter(even_checker)(test_list)
    assert (even_filtered_list == [2, 4, 6, 8])
    assert (even_filtered_list == another_even_filtered_list)



# Generated at 2022-06-12 05:42:14.113155
# Unit test for function cond
def test_cond():
    test_list = [
        (True, lambda *args: 'first'),
        (False, lambda *args: 'second'),
        (True, lambda *args: 'third'),
    ]
    f = cond(test_list)
    assert f(1) == 'first', "Error on function cond"



# Generated at 2022-06-12 05:42:27.715771
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4]) == [2, 4]

#Unit test for function curried_map

# Generated at 2022-06-12 05:42:32.981672
# Unit test for function cond
def test_cond():
    """
    >>> t = cond([
    ...     (lambda x: x > 0, lambda x: x),
    ...     (lambda x: x < 0, lambda x: -x)
    ... ])
    >>> print(t(1))
    1
    >>> print(t(0))
    0
    >>> print(t(-1))
    1
    """

# Generated at 2022-06-12 05:42:41.602369
# Unit test for function eq
def test_eq():
    assert eq(3, 3)
    assert not eq(3, 4)
    assert not eq(3, '3')
    assert not eq(3, [3])
    assert eq("3", "3")
    assert eq("1", 1)
    assert eq(list([1, 2]), list([1, 2]))
    assert not eq(list([1, 2]), [1, 2])
    assert eq(tuple([1, 2]), (1, 2))
    assert eq(tuple([1, 2]), tuple([1, 2]))
    assert eq(tuple([1, 2]), (1, 2))



# Generated at 2022-06-12 05:42:43.334301
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False



# Generated at 2022-06-12 05:42:48.435263
# Unit test for function curried_filter
def test_curried_filter():
    numbers = [1, 2, 3, 4]

    def greater_than(collection, value):
        return [item for item in collection if item > value]

    greater_than_2 = curried_filter(lambda value: value > 2)

    assert greater_than(numbers, 2) == greater_than_2(numbers)


# Generated at 2022-06-12 05:42:50.155770
# Unit test for function eq
def test_eq():
    assert (eq(1, 1))
    assert (not eq(1, 2))


# Generated at 2022-06-12 05:42:55.577398
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], eq(2)) == 2, 'Find 2 in [1, 2, 3, 4, 5]'
    assert find([1, 2, 3, 4, 5], eq(10)) is None, 'Find undefined in [1, 2, 3, 4, 5]'
    assert find([], eq(10)) is None, 'Find item in empty list'
    print('All find tests passed successfully!')



# Generated at 2022-06-12 05:42:57.998348
# Unit test for function curried_map
def test_curried_map():
    mapping = curried_map(lambda x: x + 1)
    assert mapping([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-12 05:43:04.526317
# Unit test for function memoize
def test_memoize():
    # count how many times this function will be invoke
    counter = [0]

    @memoize
    def memoizeTest(a, b):
        counter[0] += 1
        return a + b

    assert counter[0] == 0

    assert memoizeTest(3, 5) == 8

    assert counter[0] == 1

    assert memoizeTest(3, 5) == 8

    assert counter[0] == 1



# Generated at 2022-06-12 05:43:12.652153
# Unit test for function curried_map
def test_curried_map():

    map_id = curried_map(identity)

    assert map_id([1, 2, 3]) == [1, 2, 3]

    add1 = lambda x: x + 1
    add2 = lambda x: x + 2

    assert compose(
        range(1, 10),
        curried_map(add1),
        curried_map(add2)
    ) == [4, 5, 6, 7, 8, 9, 10, 11, 12]

    assert pipe(
        range(1, 10),
        curried_map(add1),
        curried_map(add2)
    ) == [4, 5, 6, 7, 8, 9, 10, 11, 12]


# Generated at 2022-06-12 05:43:30.222039
# Unit test for function find
def test_find():
    assert find([1], eq(1)) == 1
    assert find([2, 3, 4], eq(2)) == 2
    assert find([2, 3, 4], eq(4)) == 4
    assert find([2, 3, 4], eq(5)) is None



# Generated at 2022-06-12 05:43:33.038656
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda i: i == 2) == 2
    assert find([1, 2, 3], lambda i: i == 4) is None



# Generated at 2022-06-12 05:43:36.155502
# Unit test for function curried_map
def test_curried_map():
    assert curried_map([1, 2, 3, 4, 5], increase)(1, 2, 3) == [2, 3, 4, 5, 6]



# Generated at 2022-06-12 05:43:38.088772
# Unit test for function eq
def test_eq():
    assert eq(3, 3)
    assert not eq(3, 4)


# Generated at 2022-06-12 05:43:40.829002
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 1, 4], eq(2)) == 2
    assert find([1, 2, 3, 1, 4], eq(9)) is None



# Generated at 2022-06-12 05:43:45.318615
# Unit test for function cond
def test_cond():
    def condition_mapper(value) -> bool:
        return value % 2 == 0

    def execute_mapper(value) -> int:
        return value * 2

    cond_mapper = cond([
        (condition_mapper, execute_mapper),
        (lambda x: True, increase)
    ])

    assert cond_mapper(1) == 2
    assert cond_mapper(2) == 4


test_cond()

# Generated at 2022-06-12 05:43:54.167963
# Unit test for function curry
def test_curry():
    # Curry and memorize functions
    curried_eq = curry(eq)
    curried_identity = curry(identity)
    curried_compute = curry(lambda x, y, z: x + y + z)

    # Test for eq function
    assert curried_eq(4)(4) is True
    assert curried_eq(4)(5) is False

    # Test for identity
    assert curried_identity(4) == 4

    # Test for memorized function
    memorized_eq = curry(memoize(eq, curried_eq))
    memorized_identity = curry(memoize(identity, curried_identity))

    # Test for memorized eq function
    assert memorized_eq(4)(4) is True
    assert memorized_eq(4)(5) is False

# Generated at 2022-06-12 05:43:56.790496
# Unit test for function curry
def test_curry():
    square = curry(lambda x, y: x * y)
    assert square(2, 3) == 6
    assert square(2)(3) == 6



# Generated at 2022-06-12 05:43:59.723639
# Unit test for function curry
def test_curry():
    assert curry(max)(1, 2) == 2
    assert curry(max, 3)(1, 2, 3) == 3
    assert curry(max, 3)(1, 2, 3, 4) == 3



# Generated at 2022-06-12 05:44:02.699662
# Unit test for function eq
def test_eq():
    eq_func = eq(3)
    assert eq_func(3) is True
    assert eq_func(10) is False



# Generated at 2022-06-12 05:44:27.270392
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda a: True)([1, 2, 3]) == [1, 2, 3]
    assert curried_filter(lambda a: False)([1, 2, 3]) == []
    assert curried_filter(lambda a: a < 3)([1, 2, 3]) == [1, 2]
    assert curried_filter(lambda a: a < 3)(list(range(10))) == [0, 1, 2]



# Generated at 2022-06-12 05:44:31.682993
# Unit test for function eq
def test_eq():
    # eq(1,1) -> True
    assert eq(1, 1)()

    # eq(1, 2) -> False
    assert not eq(1, 2)()

    # eq(1, 1, 2) -> False
    assert not eq(1, 1, 2)()


# Generated at 2022-06-12 05:44:38.125889
# Unit test for function cond
def test_cond():
    def add(x, y):
        return x + y
    def mul(x, y):
        return x * y

    fn = cond([
        (lambda x: x % 2 == 0, lambda x, y: add(x, y)),
        (lambda x: x % 2 == 1, lambda x, y: mul(x, y))
    ])
    assert fn(2, 3) == 5
    assert fn(3, 5) == 15



# Generated at 2022-06-12 05:44:41.130803
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(identity, [1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-12 05:44:42.682483
# Unit test for function eq
def test_eq():
    res = eq(1, 1)
    assert res



# Generated at 2022-06-12 05:44:48.290296
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x % 2 == 0) == 2
    assert find([4, 3, 7, 5], lambda x: x < 5) == 3
    assert find(['abc', 'def', 'ghi', 'jkl'], lambda x: x[-1] in 'aeiou') == 'ghi'



# Generated at 2022-06-12 05:44:50.702405
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-12 05:44:58.714115
# Unit test for function memoize
def test_memoize():
    """Check cache functionality
    """
    # In this example fn return square of argument
    fn = lambda x: x * x
    # Invoke function after memoize
    square = memoize(fn)  # Function square(x) is equal square(x) = fn(x)

    assert(square(3) == 9)  # Invoke square and save result in cache
    assert(square(3) == 9)  # Invoke square and check if result is taken from cache
    assert(square(4) == 16)  # Invoke square and save result in cache
    assert(square(4) == 16)  # Invoke square and check if result is taken from cache
    assert(square(3) == 9)  # Invoke square and check if result is taken from cache
    assert(square(4) == 16)  # Invoke square and check if result

# Generated at 2022-06-12 05:45:02.458093
# Unit test for function curried_filter
def test_curried_filter():
    """
    Test curried_filter function.

    :returns: result of test
    :rtype: bool
    """
    return curried_filter(eq(2), [1, 2, 3]) == [2]



# Generated at 2022-06-12 05:45:03.869944
# Unit test for function eq
def test_eq():
    args = [1, 2]
    assert eq(*args) is False



# Generated at 2022-06-12 05:45:23.853420
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda item: item == 2) == 2
    assert find([1, 2, 3], lambda item: item == 4) is None
    assert find([1, 2, 3], lambda item: item == 0) is None


# Generated at 2022-06-12 05:45:26.962017
# Unit test for function find
def test_find():
    collection = [1, 2, 3, 4, 5]
    assert find(collection, lambda x: x < 3) is not None
    assert find(collection, lambda x: x > 5) is None

# Generated at 2022-06-12 05:45:29.710356
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 3)([1,2,3,4,5]) == [4,5]



# Generated at 2022-06-12 05:45:38.588286
# Unit test for function memoize
def test_memoize():

    def test_fn(a):
        time.sleep(1)
        return a

    memoized_test_fn = memoize(test_fn)

    start_time = time.time()
    memoized_test_fn(1)
    first_execution_time = time.time() - start_time

    start_time = time.time()
    memoized_test_fn(1)
    second_execution_time = time.time() - start_time

    assert first_execution_time > 0.9 and second_execution_time < 0.1


# Generated at 2022-06-12 05:45:47.860232
# Unit test for function cond
def test_cond():
    def is_even(num: int) -> bool:
        return num % 2 == 0

    def is_odd(num: int) -> bool:
        return not is_even(num)

    def is_negative(num: int) -> bool:
        return num < 0

    def is_positive(num: int) -> bool:
        return not is_negative(num)

    def even_string(num: int) -> str:
        return 'even'

    def odd_string(num: int) -> str:
        return 'odd'

    def negative_string(num: int) -> str:
        return 'negative'

    def positive_string(num: int) -> str:
        return 'positive'


# Generated at 2022-06-12 05:45:51.330586
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6



# Generated at 2022-06-12 05:45:52.835365
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-12 05:46:00.197882
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(0.0, 0)
    assert not eq('a', 'b')
    assert eq('a', 'a')
    assert eq([1, 2], [1, 2])
    assert not eq([1, 2], [2, 1])
    assert eq(('a', 'b'), ('a', 'b'))
    assert eq({'a': 'b'}, {'a': 'b'})


# Generated at 2022-06-12 05:46:04.531974
# Unit test for function memoize
def test_memoize():
    x = 0
    @memoize
    def fn():
        nonlocal x
        x += 1
        return x

    assert fn() == 1
    assert x == 1
    assert fn() == 1
    assert x == 1


if __name__ == '__main__':  # pragma: no-cover
    test_memoize()