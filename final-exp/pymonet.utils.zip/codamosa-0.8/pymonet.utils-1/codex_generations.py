

# Generated at 2022-06-12 05:36:14.039466
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], eq(2)) == 2
    assert find([1, 2, 3, 4], eq(5)) is None



# Generated at 2022-06-12 05:36:19.003335
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], eq(5)) is None
    assert find([1, 2, 3, 4], eq(4)) == 4
    assert find([0, 1, 2, 3, 4], eq(0)) == 0
    assert find([0, 1, 2, 3, 4], eq(4)) == 4


test_find()


# Generated at 2022-06-12 05:36:26.617407
# Unit test for function find
def test_find():
    assert find([], eq(None)) is None
    assert find([1, 2, 3], eq(None)) is None
    assert find([1, 2, 3], eq(1)) == 1
    assert find([1, 2, 3], eq(2)) == 2
    assert find([1, 2, 3], eq(3)) == 3
    assert find([1, 2, 3], eq(4)) is None
    assert find([1, 2, 3], eq(5)) is None



# Generated at 2022-06-12 05:36:31.996548
# Unit test for function memoize
def test_memoize():
    step = 0

    @memoize
    def fn(value):
        nonlocal step
        step += 1
        return value

    assert step == 0

    fn(1)
    assert step == 1

    fn(2)
    assert step == 2

    fn(1)
    assert step == 2



# Generated at 2022-06-12 05:36:37.123999
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda number: number > 2)([1, 2, 3, 4]) == [3, 4]



# Generated at 2022-06-12 05:36:40.790866
# Unit test for function find
def test_find():
    test_list = [1, 3, 5, 7, 9]
    assert find(test_list, lambda value: value == 5) == 5
    assert find(test_list, lambda value: value == 4) is None

test_find()

# Generated at 2022-06-12 05:36:44.815996
# Unit test for function curry
def test_curry():
    def add(a, b, c, d):
        return a + b + c + d

    f = curry(add, 4)
    assert f(1)(2)(3)(4) == 10
    assert f(1)(2)(3)(5) == 11


# Generated at 2022-06-12 05:36:46.666925
# Unit test for function eq
def test_eq():
    assert not eq(1)(2)
    assert eq(2)(2)



# Generated at 2022-06-12 05:36:53.673578
# Unit test for function eq
def test_eq():
    """Test function eq."""
    assert eq(1, 1)
    assert eq([1, 2, 3], [1, 2, 3])
    assert not eq(1, 2)
    assert not eq([1, 2, 3], [1, 2, 4])
    assert eq(0)(0)
    assert eq([1, 2, 3])([1, 2, 3])
    assert not eq(0)(1)
    assert not eq([1, 2, 3])([1, 2, 4])
    assert not eq(1)(2)
    assert not eq([1, 2, 3])([1, 2, 4])


# Generated at 2022-06-12 05:37:02.088491
# Unit test for function cond
def test_cond():
    list_of_two_item_tuples = [
        (lambda x: x == 1, lambda x: 'first'),
        (lambda x: x == 2, lambda x: 'second'),
        (lambda x: x == 3, lambda x: 'third')
    ]
    assert cond(list_of_two_item_tuples)(1) == 'first'
    assert cond(list_of_two_item_tuples)(2) == 'second'
    assert cond(list_of_two_item_tuples)(3) == 'third'
    assert cond(list_of_two_item_tuples)(4) is None


# Generated at 2022-06-12 05:37:08.001520
# Unit test for function memoize
def test_memoize():
    f = memoize(lambda x: x ** 2)
    assert f(2) == 4
    assert f(2) == 4
    assert f(2) == 4
    assert f(2) == 4


# Generated at 2022-06-12 05:37:12.223335
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq('1', 1) == False


# Generated at 2022-06-12 05:37:14.761307
# Unit test for function memoize
def test_memoize():
    @memoize
    def add(a):
        return a + 1

    for x in range(1, 10):
        assert add(x) == x + 1

# Generated at 2022-06-12 05:37:20.305230
# Unit test for function memoize
def test_memoize():
    """
    Test for function ``memoize``.
    """
    fn = memoize(len)
    assert fn([1, 2, 3]) == 3
    assert fn([1, 2]) == 2
    assert fn([1, 2, 3]) == 3
    assert fn([1, 2]) == 2
    assert fn([1]) == 1
    assert fn([]) == 0



# Generated at 2022-06-12 05:37:24.818675
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(2, 2)
    assert not eq(1, 2)(1)
    assert eq(1, 1)(1)



# Generated at 2022-06-12 05:37:31.734918
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4])(0) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4])(1) == [1, 3]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4])(3) == []


# Generated at 2022-06-12 05:37:40.580524
# Unit test for function memoize
def test_memoize():
    def sum_to_n2(n):
        return n * (n + 1) / 2

    memoized_sum_to_n2 = memoize(sum_to_n2)
    assert memoized_sum_to_n2(10) == sum_to_n2(10)

    # make sure cache works
    assert memoized_sum_to_n2(10) == sum_to_n2(10)

    # make sure cache works for different arguments
    assert memoized_sum_to_n2(11) == sum_to_n2(11)


# Generated at 2022-06-12 05:37:44.851912
# Unit test for function memoize
def test_memoize():

    @memoize
    def factorial(num):
        if num == 0:
            return 1
        return num * factorial(num - 1)

    assert factorial(6) == 720
    assert factorial(6) == 720
    assert factorial(6) == 720
    assert factorial(2000) == "Too Big Number"

test_memoize()



# Generated at 2022-06-12 05:37:50.402613
# Unit test for function memoize
def test_memoize():
    @memoize
    def fibonacci(index):
        if index < 2:
            return index
        return fibonacci(index - 1) + fibonacci(index - 2)

    assert fibonacci(10) == 55
    assert fibonacci(5) == 5
    assert fibonacci(10) == 55

# Generated at 2022-06-12 05:37:59.883885
# Unit test for function find
def test_find():
    """
    Unit test for function find
    """

# Generated at 2022-06-12 05:38:11.672669
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3])([2, 2]) == [2, 2]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3])([]) == []
    assert curried_filter(lambda x: x % 2 == 1, [1, 2, 3])([]) == []
    assert curried_filter(lambda x: x % 2 == 1, [1, 2, 3])([1]) == [1]


# Generated at 2022-06-12 05:38:14.937318
# Unit test for function curried_filter
def test_curried_filter():
    assert eq(
        curried_filter(
            lambda x: x % 2 == 0,
            [1, 2, 3, 4, 5]
        ),
        [2, 4]
    )



# Generated at 2022-06-12 05:38:20.184393
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x%2==0, []) == []
    assert curried_filter(lambda x: x%2==0, [1,3,5]) == []
    assert curried_filter(lambda x: x%2==0, [1,2,3,4,5,6]) == [2,4,6]



# Generated at 2022-06-12 05:38:24.970134
# Unit test for function curried_map
def test_curried_map():
    """
    Map given function over collection.

    :returns:
    :rtype: None
    """
    assert curried_map(increase)(range(5)) == [1, 2, 3, 4, 5]
    assert curried_map(increase, range(5)) == [1, 2, 3, 4, 5]



# Generated at 2022-06-12 05:38:27.912218
# Unit test for function find
def test_find():
    original_collection = [1, 2, 3, 4, 5]
    key = lambda x: x == 3
    assert find(original_collection, key) == 3



# Generated at 2022-06-12 05:38:32.163781
# Unit test for function find
def test_find():
    # Check for correct work in correct case
    assert(find(["a", "b", "c", "d"], lambda x: x == "c")) == "c"
    # Check for correct work in False case
    assert(find(["a", "b", "c", "d"], lambda x: x == "z")) is None


# Generated at 2022-06-12 05:38:37.289429
# Unit test for function find
def test_find():
    assert find([10, 20, 30, 40], lambda e: e % 2 == 0) == 10
    assert find([10, 20, 30, 40], lambda e: e % 2 == 1) == 20
    assert find([10, 20, 30, 40], lambda e: e == 50) is None



# Generated at 2022-06-12 05:38:42.692329
# Unit test for function eq
def test_eq():
    assert eq(5, 2 + 3)
    assert not eq(5, 2 + 5)
    assert eq(eq(2, 3), False)
    assert eq(eq(2, 2), True)
    assert not eq(eq(2, 2), False)
    curried_eq = eq(4)
    assert curried_eq(4)
    assert not curried_eq(5)



# Generated at 2022-06-12 05:38:47.586366
# Unit test for function eq
def test_eq():
    assert eq(1, 2) is False
    assert eq(1, 1) is True
    assert eq(1, 1, 2) is False
    eq_curried = eq(1)
    assert eq_curried(2) is False
    assert eq_curried(1) is True



# Generated at 2022-06-12 05:38:49.477713
# Unit test for function eq
def test_eq():
    # Positive for two equal values
    assert eq(1, 1) is True
    # Positive for two not equal values
    assert eq(1, 2) is False



# Generated at 2022-06-12 05:39:02.392965
# Unit test for function find
def test_find():
    names = ['Bob', 'Alice', 'Robert', 'Jimmy', 'Bob']
    assert find(names, lambda name: name == 'Bob') == 'Bob'
    assert find(names, lambda name: name.endswith('ert')) == 'Robert'
    assert find(names, lambda name: name.startswith('Tad')) is None



# Generated at 2022-06-12 05:39:10.006433
# Unit test for function curried_map
def test_curried_map():
    assert eq(curried_map(identity)([]), [])
    assert eq(curried_map(identity)([1]), [1])
    assert eq(curried_map(identity)([1, 2]), [1, 2])
    assert eq(curried_map(increase)([1]), [2])
    assert eq(curried_map(increase)([1, 2]), [2, 3])
    assert eq(compose(
        [1, 2],
        curried_map(increase)
    ), [2, 3])



# Generated at 2022-06-12 05:39:16.110163
# Unit test for function curry
def test_curry():
    def a(x, y, z):
        return x + y + z

    f = curry(a)
    assert f(1)(2)(3) == 6

    g = curry(a, 2)
    assert g(1)(2) == 3

    h = curry(a, 3)
    assert h(1, 2, 3) == 6



# Generated at 2022-06-12 05:39:19.045521
# Unit test for function find
def test_find():
    collection = list(range(10))
    assert find(collection, lambda x: x == 6) == 6
    assert find(collection, lambda x: x == 11) is None



# Generated at 2022-06-12 05:39:23.876646
# Unit test for function memoize
def test_memoize():
    @memoize
    def memoized_fn(x):
        return x + 1

    assert memoized_fn(1) == 2
    assert memoized_fn(1) == 2
    assert memoized_fn(2) == 3
    assert memoized_fn(2) == 3

# Generated at 2022-06-12 05:39:29.603940
# Unit test for function memoize
def test_memoize():
    def dummy_fib(n: int) -> int:
        if n == 1 or n == 2:
            return 1
        return dummy_fib(n - 1) + dummy_fib(n - 2)

    fib = memoize(dummy_fib)
    assert fib(1) == 1
    assert fib(2) == 1
    assert fib(3) == 2
    assert fib(4) == 3

# Generated at 2022-06-12 05:39:30.992029
# Unit test for function memoize
def test_memoize():
    assert memoize(identity(True))() is True



# Generated at 2022-06-12 05:39:35.763864
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 1) == 1
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 3) == 3
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-12 05:39:40.975521
# Unit test for function curried_map
def test_curried_map():
    """
    Function to test curried_map function,
    that function return mapped collection.
    """
    collection = [1, 2, 3, 4]
    expected = [2, 3, 4, 5]
    assert curried_map(lambda x: x + 1, collection) == expected



# Generated at 2022-06-12 05:39:43.035525
# Unit test for function find
def test_find():
    # Find item in list
    assert find([1, 2, 3], compose(curry(bool)(2), eq)) == 2
    assert find([1, 2, 3], compose(curry(bool)(4), eq)) is None



# Generated at 2022-06-12 05:40:05.156200
# Unit test for function curried_filter
def test_curried_filter():
    list_of_numbers = range(1, 20)
    assert curried_filter(lambda x: x % 5 == 0, list_of_numbers) == [5, 10, 15]
    assert curried_filter(lambda x: x % 5 == 0)(list_of_numbers) == [5, 10, 15]
    assert curried_filter(lambda x: x % 5 == 0)(list_of_numbers) == [5, 10, 15]



# Generated at 2022-06-12 05:40:13.494492
# Unit test for function memoize
def test_memoize():
    counter = {'count': 0}
    def f(arg):
        counter['count'] += 1
        return 'result'

    memoized_f = memoize(f)

    assert memoized_f(1) == 'result'
    assert memoized_f(1) == 'result'
    assert counter['count'] == 1

    assert memoized_f(2) == 'result'
    assert counter['count'] == 2
    assert memoized_f(2) == 'result'
    assert counter['count'] == 2



# Generated at 2022-06-12 05:40:18.157555
# Unit test for function curried_filter
def test_curried_filter():
    """
    Unit test for function curried_filter
    """
    collection = list(range(11))
    filterer = lambda value: value >= 5
    curried_filterer = curried_filter(filterer)
    assert curried_filterer(collection) == [5, 6, 7, 8, 9, 10]


# Generated at 2022-06-12 05:40:21.943856
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(2)) == 2
    assert find(['a', 'b'], eq('a')) == 'a'
    assert find([1, 2, 3], eq(4)) is None
    assert find([1, 2, 3], eq(2.0)) is None



# Generated at 2022-06-12 05:40:24.653393
# Unit test for function curry
def test_curry():
    curry_func = curry(lambda x, y, z: x + y + z)
    curry_func_1 = curry_func(1)
    assert curry_func_1(2)(3) == 6



# Generated at 2022-06-12 05:40:33.247763
# Unit test for function cond
def test_cond():
    def _is_even(x) -> bool:
        return x % 2 == 0

    def _is_odd(x) -> bool:
        return x % 2 != 0

    test_value = 4
    assert (
        cond([(_is_even, lambda x: x + 1), (_is_odd, lambda x: x + 2)])(test_value)
        == 5
    )
    test_value = 5
    assert (
        cond([(_is_even, lambda x: x + 1), (_is_odd, lambda x: x + 2)])(test_value)
        == 7
    )

# Generated at 2022-06-12 05:40:43.792556
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, []) == []
    assert curried_map()([1, 2, 3])(identity) == [1, 2, 3]
    assert curried_map()([1, 2, 3])(increase) == [2, 3, 4]
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([]) == []


# Generated at 2022-06-12 05:40:53.237195
# Unit test for function memoize
def test_memoize():
    from time import time
    print("\nTest function memoize()")
    def noop(value):
        pass

    def expensive_function(n):
        for i in range(1000000):
            noop(i)
        return 'some result!'

    # Time how long it takes to execute fibonacci(n)
    def fibonacci(n):
        if n < 2:
            return n
        return fibonacci(n - 2) + fibonacci(n - 1)

    # Time how long it takes to execute fibonacci_memo(n)
    memoized_fibonacci = memoize(fibonacci)

    start_time = time()
    print("fibonacci(7):", fibonacci(7))
    print("Time it took to calculate:", time() - start_time)



# Generated at 2022-06-12 05:40:55.992751
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x > 2) == 3
    assert find([1, 2, 3], lambda x: x > 3) is None

# Generated at 2022-06-12 05:41:01.487319
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(None)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([]) == []
    assert curried_map(increase)(None) == None



# Generated at 2022-06-12 05:41:40.240689
# Unit test for function curry
def test_curry():
    add = curry(lambda x, y: x + y)
    add5 = add(5)

    assert add5(10) == 15
    assert add5(2) == 7
    assert add(2)(3) == 5


# Generated at 2022-06-12 05:41:43.115130
# Unit test for function cond
def test_cond():
    cond_list = [
        (lambda x: x > 0, lambda x: "x > 0"),
        (lambda x: x == 0, lambda x: "x == 0"),
        (lambda x: x < 0, lambda x: "x < 0"),
    ]
    assert cond(cond_list)(1) == "x > 0"
    assert cond(cond_list)(0) == "x == 0"
    assert cond(cond_list)(-1) == "x < 0"



# Generated at 2022-06-12 05:41:46.604222
# Unit test for function memoize
def test_memoize():
    # noinspection PyShadowingNames
    def memoize_test_function(argument):
        return argument + 1

    memoized_fn = memoize(memoize_test_function)
    assert memoized_fn(1) == 2
    assert memoized_fn(1) == 2
    assert memoized_fn(2) == 3

# Generated at 2022-06-12 05:41:57.170603
# Unit test for function memoize
def test_memoize():
    l = [1, 2, 3, 4, 5]

    add_three_memoized = memoize(
        lambda x: x + 3,
        key=eq
    )

    assert add_three_memoized(3) == 6
    assert add_three_memoized(1) == 4
    assert add_three_memoized(2) == 5
    assert add_three_memoized(3) == 6

    assert map(add_three_memoized, l) == [4, 5, 6, 7, 8]

    identity_memoized = memoize(identity, key=eq)
    assert identity_memoized(3) == 3
    assert identity_memoized(1) == 1
    assert identity_memoized(2) == 2
    assert identity_memoized(3)

# Generated at 2022-06-12 05:42:01.265849
# Unit test for function cond
def test_cond():
    condition_list = [
        (lambda x: x % 2 == 0, lambda x: x / 2),
        (lambda x: x % 2 != 0, lambda x: 3 * x + 1),
    ]
    assert cond(condition_list)(2) == 1
    assert cond(condition_list)(3) == 10


# Generated at 2022-06-12 05:42:09.788763
# Unit test for function cond
def test_cond():
    """
    Test function cond.
    cond get list of two-item tuples,
    first is condition_function, second is execute_function.
    Returns this execute_function witch first condition_function return truly value.
    """

    def is_true(value):
        """
        Return true if value is truly.

        :param value:
        :type value: Boolean
        :returns:
        :rtype: Boolean
        """
        return value

    def print_true():
        """
        Print true.

        :returns:
        :rtype: None
        """
        print(True)
        return None

    def print_false():
        """
        Print false.

        :returns:
        :rtype: None
        """
        print(False)
        return None


# Generated at 2022-06-12 05:42:12.388117
# Unit test for function curry
def test_curry():
    add = lambda x, y: x + y
    add1 = curry(add)(1)
    add2 = curry(add)(2)
    assert add1(40) == 41
    assert add2(40) == 42

# Generated at 2022-06-12 05:42:20.577509
# Unit test for function cond
def test_cond():
    is_one = lambda x: x == 1
    is_two = lambda x: x == 2
    is_three = lambda x: x == 3

    add_one = lambda x: x + 1
    add_two = lambda x: x + 2
    add_three = lambda x: x + 3

    add_one_or_two_or_three = cond([
        (is_one, add_one),
        (is_two, add_two),
        (is_three, add_three)
    ])

    assert add_one_or_two_or_three(1) == 2
    assert add_one_or_two_or_three(2) == 4
    assert add_one_or_two_or_three(3) == 6
    assert add_one_or_two_or_three(4) == None

# Generated at 2022-06-12 05:42:22.219523
# Unit test for function curry
def test_curry():
    def func(a, b, c):
        return a + b + c
    assert curry(func)(1, 2, 3) == 6



# Generated at 2022-06-12 05:42:33.498296
# Unit test for function memoize
def test_memoize():
    def _sum(value):
        """
        Test function for memoize.
        Return sum of digits in value

        :param value: value to count sum
        :type value: int
        :returns: sum of digits in value
        :rtype: int
        """
        return sum([int(digit) for digit in str(value)])

    _sum_memoized = memoize(_sum)

    assert _sum_memoized(1) == 1
    assert _sum_memoized(1) == 1
    assert _sum_memoized(2) == 2
    assert _sum_memoized(2) == 2
    assert _sum_memoized(12) == 3
    assert _sum_memoized(12) == 3
    assert _sum_memoized(22) == 4
    assert _sum_

# Generated at 2022-06-12 05:43:17.818952
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x == 0)([0, 1, 0]) == [0, 0]


# Generated at 2022-06-12 05:43:23.454616
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(True)([True, False, True]) == [True, True]
    assert curried_filter(True, [True, False, True]) == [True, True]
    assert curried_filter(lambda x: x, [True, False, True]) == [True, True]
    assert curried_filter(lambda x: not x)([True, False, True]) == [False]


# Generated at 2022-06-12 05:43:27.699371
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(
        lambda x: x % 2 == 0,
        [1, 2, 3, 4, 5, 6, 7, 8]
    ) == [2, 4, 6, 8]



# Generated at 2022-06-12 05:43:31.518169
# Unit test for function curry
def test_curry():
    assert curry(increase, 2)(1) == 2
    assert curry(increase, 2)(1, 1) == 2
    assert curry(increase)(1) == 2
    assert curry(increase)(1, 2) == 3



# Generated at 2022-06-12 05:43:42.485017
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x < 0, lambda x: 'less than zero'),
        (lambda x: x < 2, lambda x: 'less than two'),
        (lambda x: x < 3, lambda x: 'less than three')
    ])(-1) == 'less than zero'

    assert cond([
        (lambda x: x < 0, lambda x: 'less than zero'),
        (lambda x: x < 2, lambda x: 'less than two'),
        (lambda x: x < 3, lambda x: 'less than three')
    ])(0) == 'less than two'


# Generated at 2022-06-12 05:43:44.403288
# Unit test for function curried_filter
def test_curried_filter():
    collection = ["one", "two", "three"]
    result = curried_filter(lambda item: len(item) > 3)(collection)
    assert result == ["three"]



# Generated at 2022-06-12 05:43:50.178046
# Unit test for function memoize
def test_memoize():
    @memoize
    def double(a):
        print('double called')
        return a*2

    print(double(3))
    print(double(3))
    print(double(3))
    print(double(3))
    print(double(3))
    print(double(3))
    print(double(3))


test_memoize()

# Generated at 2022-06-12 05:43:50.836241
# Unit test for function eq
def test_eq():
    eq(3,3)


# Generated at 2022-06-12 05:44:00.369051
# Unit test for function cond
def test_cond():
    def is_int(value):
        return type(value) == int

    def is_float(value):
        return type(value) == float

    def is_str(value):
        return type(value) == str

    def int_to_str(value):
        return str(value)

    def float_to_str(value):
        return str(value)

    def str_to_str(value):
        return value

    def int_plus_5(value):
        return value + 5

    def float_plus_5(value):
        return value + 5

    def str_plus_5(value):
        return value + str(5)

    def int_to_float(value):
        return float(value)

    def float_to_float(value):
        return value


# Generated at 2022-06-12 05:44:04.273828
# Unit test for function find
def test_find():
    assert (find([1, 2, 3], lambda x: x == 2) == 2)
    assert (find([1, 2, 3], lambda x: x == 5) is None)



# Generated at 2022-06-12 05:44:39.696606
# Unit test for function curried_filter
def test_curried_filter():
    """
    test_curried_filter
    """
    a = curried_filter(lambda x: x > 10, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12])
    b = [11, 12]
    assert a == b



# Generated at 2022-06-12 05:44:43.933747
# Unit test for function memoize
def test_memoize():
    assert memoize(identity, key=eq(1))(1) == 1
    assert memoize(identity, key=eq)(1) == 1
    assert memoize(identity)(3) == 3
    assert memoize(increase)(1) == 2
    assert memoize(increase)(1) == 2


# Generated at 2022-06-12 05:44:52.827294
# Unit test for function memoize
def test_memoize():
    def product(number):
        return number * 10

    assert product(1) == 10
    assert product(2) == 20

    memoized_product = memoize(product)

    assert memoized_product(1) == 10
    assert memoized_product(1) == 10

    assert product(2) == 20
    assert memoized_product(2) == 20
    assert memoized_product(2) == 20

    assert memoized_product(3) == 30
    assert memoized_product(3) == 30

    print('Test for memoize passed!')


if __name__ == '__main__':
    test_memoize()

# Generated at 2022-06-12 05:44:54.609584
# Unit test for function find
def test_find():
    lst = [1, 2, 3, 4, 5]
    assert find(lst, eq(1)) == 1
    assert find(lst, eq(0)) is None



# Generated at 2022-06-12 05:44:58.606682
# Unit test for function memoize
def test_memoize():
    l = []
    @memoize
    def f(n):
        l.append(1)
        return n

    assert f(1) == 1
    assert len(l) == 1
    assert f(1) == 1
    assert len(l) == 1
    assert f(2) == 2
    assert len(l) == 2
    assert f(2) == 2
    assert len(l) == 2


# Generated at 2022-06-12 05:45:04.721678
# Unit test for function curried_map
def test_curried_map():
    assert [1, 2, 3] == curried_map(identity)([1, 2, 3])
    assert [2, 3, 4] == curried_map(increase)([1, 2, 3])
    assert [2, 3, 4] == curried_map(increase, [1, 2, 3])
    assert [2, 3, 4] == curried_map(lambda x: x + 1, [1, 2, 3])



# Generated at 2022-06-12 05:45:13.988995
# Unit test for function cond
def test_cond():
    """
    Unit test for function cond.
    """
    def execute_function(input_value):
        return input_value + 1

    def is_equal(input_value, value):
        return input_value == value

    cond_function = cond([
        (partial(is_equal, 1), execute_function),
        (partial(is_equal, 2), execute_function),
        (partial(is_equal, 3), execute_function),
        (partial(is_equal, 4), execute_function),
        (partial(is_equal, 5), execute_function)
    ])

    assert cond_function(1) == execute_function(1)
    assert cond_function(2) == execute_function(2)
    assert cond_function(3) == execute_function(3)
    assert cond_function(4) == execute_

# Generated at 2022-06-12 05:45:16.367340
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-12 05:45:19.133412
# Unit test for function find
def test_find():
    items = [1, 2, 3, 4, 5]

    assert find(items, lambda item: item == 3) == 3
    assert find(items, lambda item: item == 10) is None



# Generated at 2022-06-12 05:45:23.339707
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False
    assert eq(1)(1) is True
    assert eq(1)(2) is False

