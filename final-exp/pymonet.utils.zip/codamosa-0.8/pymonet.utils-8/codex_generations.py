

# Generated at 2022-06-12 05:36:13.101024
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3, 4]) == [2, 3, 4, 5]



# Generated at 2022-06-12 05:36:13.783785
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False



# Generated at 2022-06-12 05:36:20.231249
# Unit test for function cond
def test_cond():
    # Arrange
    sample_list = [
        (lambda value: value == 1, lambda value: 'one'),
        (lambda value: value == 2, lambda value: 'two'),
        (lambda value: value == 3, lambda value: 'three'),
    ]

    # Act
    sample_fn = cond(sample_list)

    # Assert
    assert sample_fn(1) == 'one'
    assert sample_fn(2) == 'two'
    assert sample_fn(3) == 'three'



# Generated at 2022-06-12 05:36:22.527055
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 0)([-1, 0, 1, 2]) == [1, 2]

# Generated at 2022-06-12 05:36:24.582340
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-12 05:36:27.284001
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq('a', 'b')
    assert not eq(1, 2)


# Generated at 2022-06-12 05:36:33.198325
# Unit test for function eq
def test_eq():
    """
    Unit test for function eq
    """
    assert eq(1, 1)
    assert eq(0, 0)
    assert not eq(0, 1)
    assert not eq(1, 0)



# Generated at 2022-06-12 05:36:38.866292
# Unit test for function find
def test_find():
    assert find([{'a': 1}, {'a': 2}], lambda item: item['a'] == 1) == {'a': 1}
    assert find([{'a': 1}, {'a': 2}], lambda item: item['a'] == 3) is None



# Generated at 2022-06-12 05:36:43.763774
# Unit test for function curried_filter
def test_curried_filter():
    # Test curried_filter with args 6, [1,2,3,4,5,6,7,8,9]
    assert curried_filter(6)([1, 2, 3, 4, 5, 6, 7, 8, 9]) == [6]

    # Test curried_filter with args [1,2,3,4,5,6,7,8,9], 6
    assert curried_filter([1, 2, 3, 4, 5, 6, 7, 8, 9])(6) == [6]



# Generated at 2022-06-12 05:36:46.574527
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-12 05:36:54.844845
# Unit test for function curry
def test_curry():
    def add(x, y):
        return x + y

    assert curry(add)(2, 3) == 5



# Generated at 2022-06-12 05:36:59.675876
# Unit test for function find
def test_find():
    # arrange
    collection: List[Tuple[Any, Any]] = [(1, False), (2, True), (3, True)]
    key = lambda x: x[1]

    # act
    result = find(collection, key)

    # assert
    assert result is collection[1]



# Generated at 2022-06-12 05:37:05.297770
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x * x)([1, 2, 3, 4]) == [1, 4, 9, 16]
    assert list(map(lambda x: x * x, [1, 2, 3, 4])) == [1, 4, 9, 16]


# Generated at 2022-06-12 05:37:10.492098
# Unit test for function memoize
def test_memoize():
    test_counter = 0

    def test_function(argument):
        nonlocal test_counter
        test_counter += 1
        return argument

    memoized_test_function = memoize(test_function, eq)

    first_call_result = memoized_test_function(1)
    assert test_counter == 1
    second_call_result = memoized_test_function(1)
    assert test_counter == 1 and first_call_result == second_call_result



# Generated at 2022-06-12 05:37:15.710383
# Unit test for function find
def test_find():
    assert find([1, 2, 4, 5], eq(1)) == 1
    assert find([1, 2, 4, 5], eq(2)) == 2
    assert find([1, 2, 4, 5], eq(4)) == 4
    assert find([1, 2, 4, 5], eq(5)) == 5
    assert find([1, 2, 4, 5], eq(3)) is None



# Generated at 2022-06-12 05:37:19.216029
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x % 2 == 0) == 2
    assert find([1, 2, 3, 4], lambda x: x > 5) is None



# Generated at 2022-06-12 05:37:20.983717
# Unit test for function eq
def test_eq():
    assert eq('a', 'a')
    assert not eq('a', 'b')



# Generated at 2022-06-12 05:37:27.043896
# Unit test for function memoize
def test_memoize():
    assert memoize(lambda x: x + 1)(1) == 2, 'Function memoize should return new function'
    assert memoize(lambda x: x + 2)(2) == 4,\
        'Function memoize should check if there argument in cache'
    assert memoize(lambda x: x + 2)(3) == 5,\
        'Function memoize should cache arguments'



# Generated at 2022-06-12 05:37:34.847896
# Unit test for function curry
def test_curry():
    def a(x):
        return x + 1

    def b(x, y):
        return x + y

    def c(x, y, z):
        return x + y + z

    assert a(1) == 2
    assert b(1, 2) == 3
    assert c(1, 2, 3) == 6

    assert curry(a)(1) == 2
    assert curry(b)(1)(2) == 3
    assert curry(c)(1)(2)(3) == 6



# Generated at 2022-06-12 05:37:36.919768
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-12 05:38:06.484868
# Unit test for function memoize
def test_memoize():
    def test(a, b):
        return a + b

    test_key = (1, 2)
    test_value = 3
    mem_test = memoize(test)
    assert mem_test(test_key) == test_value
    assert mem_test(test_key) == test_value
    test_key = (2, 3)
    test_value = 5
    assert mem_test(test_key) == test_value



# Generated at 2022-06-12 05:38:12.882506
# Unit test for function memoize
def test_memoize():
    from time import time

    @memoize
    def fib(n):
        # time.sleep(0.2)
        if n == 0 or n == 1:
            return n
        return fib(n - 1) + fib(n - 2)

    start = time()
    fib(12)
    print(round(time() - start, 3))

    start = time()
    fib(12)
    print(round(time() - start, 3))



# Generated at 2022-06-12 05:38:18.957593
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3]) == [2]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3]) == [2]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4]) == [2, 4]



# Generated at 2022-06-12 05:38:21.482146
# Unit test for function curried_map
def test_curried_map():
    map_curried = curried_map(increase)
    assert map_curried([1, 2]) == [2, 3]



# Generated at 2022-06-12 05:38:31.644865
# Unit test for function curry
def test_curry():
    def sum_three_args(a, b, c):
        return a + b + c
    assert curry(sum_three_args)(1)(1)(1) == 3
    assert curry(sum_three_args)(1, 1)(1) == 3
    assert curry(sum_three_args)(1, 1, 1) == 3
    assert curry(sum_three_args, 2)(1, 1) == 3
    assert curry(sum_three_args, 2)(1)(1) == 3
    assert curry(sum_three_args, 3)(1, 1, 1) == 3
    assert curry(sum_three_args, 3)(1, 1)(1) == 3
    assert curry(sum_three_args, 3)(1)(1)(1) == 3

# Generated at 2022-06-12 05:38:41.460620
# Unit test for function memoize
def test_memoize():
    # initiate sample test objects
    object1 = {}
    object2 = {}

    @memoize
    def test_single_argument(argument):
        argument['test'] = 'test'
        return argument

    # function should save result for fist call
    print(test_single_argument(object1))
    # and then return cached value
    print(test_single_argument(object1))
    # and then return function result again
    print(test_single_argument(object2))

    @memoize(lambda x, y: y == x['test'])
    def test_multi_arguments(argument, key):
        return argument[key]

    # function should save result for fist call
    print(test_multi_arguments(object1, 'test'))
    # and then return cached value

# Generated at 2022-06-12 05:38:45.041464
# Unit test for function find
def test_find():
    assert find(range(5), eq(2)) == 2
    assert find(range(5), eq(10)) is None



# Generated at 2022-06-12 05:38:47.585767
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(3)) == 3
    assert find([1, 2, 3], eq(4)) is None


# Generated at 2022-06-12 05:38:49.477583
# Unit test for function curried_map
def test_curried_map():
    curried = curried_map(lambda x: x * x)
    assert curried([1, 2, 3]) == [1, 4, 9]



# Generated at 2022-06-12 05:38:59.405203
# Unit test for function memoize
def test_memoize():
    def fn(argument) -> int:
        def fib(n):
            if n <= 2:
                return 1
            else:
                return fib(n - 1) + fib(n - 2)

        return fib(argument)

    memoized_fn = memoize(fn)
    assert memoized_fn(1) == 1
    assert memoized_fn(2) == 1
    assert memoized_fn(3) == 2
    assert memoized_fn(4) == 3
    assert memoized_fn(5) == 5
    assert memoized_fn(6) == 8
    assert memoized_fn(6) == 8
    assert memoized_fn(5) == 5
    assert memoized_fn(4) == 3
    assert memoized_fn(3) == 2
    assert memoized_fn(2) == 1


# Generated at 2022-06-12 05:39:14.759238
# Unit test for function curried_map
def test_curried_map():
    assert compose(
        [1, 2, 3, 4],
        curried_map(increase),
        curried_map(increase),
        curried_map(increase),
    ) == [4, 5, 6, 7]



# Generated at 2022-06-12 05:39:20.339207
# Unit test for function find
def test_find():
    collection = [1, 2, 3, 4]
    eq_three = find(collection, lambda x: x == 3)
    eq_six = find(collection, lambda x: x == 6)

    assert eq_three is 3, 'Should find 3'
    assert eq_six is None, 'Should not find 6'



# Generated at 2022-06-12 05:39:26.766464
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x+1, [1, 2, 3, 4]) == [2, 3, 4, 5]



# Generated at 2022-06-12 05:39:29.609310
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq('1', '1')
    assert not eq('1', 1)



# Generated at 2022-06-12 05:39:34.475898
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x > 2) == 3
    assert find([1, 2, 3, 4, 5], lambda x: x == 2) == 2
    assert find([1, 2, 3, 4, 5], lambda x: x == 6) is None



# Generated at 2022-06-12 05:39:38.579184
# Unit test for function find
def test_find():
    assert(find([1, 2, 3, 4, 5], eq(2)) == 2)
    assert(find([1, 2, 3, 4, 5], eq(6)) is None)



# Generated at 2022-06-12 05:39:40.053325
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1]) == [1]



# Generated at 2022-06-12 05:39:42.838064
# Unit test for function curry
def test_curry():
    @curry
    def multiply(x, y=1):
        return x * y

    assert multiply(10) == 10
    assert multiply(10, 2) == 20
    assert multiply(10)(2) == 20
    assert multiply(10, y=3) == 30
    assert multiply(10)(y=3) == 30



# Generated at 2022-06-12 05:39:47.802918
# Unit test for function curried_map
def test_curried_map():
    """
    Test function curried_map. Should return list.

    :returns: None
    :rtype: None
    """
    test_list = [1, 2, 3, 4, 5]
    assert(curried_map(increase, test_list) == [2, 3, 4, 5, 6])



# Generated at 2022-06-12 05:39:52.404924
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(3)) == 3, 'find function with basis test failed'
    assert find([2, 4, 6, 8], eq(5)) is None, 'find function with invalid argument test failed'



# Generated at 2022-06-12 05:40:19.495067
# Unit test for function curry
def test_curry():
    array = [1, 2, 3]
    filter_fn = filter
    map_fn = map

    curried_filter_fn = curry(filter)
    assert curried_filter_fn(lambda x: x % 2 == 0)(array) == filter_fn(lambda x: x % 2 == 0, array)

    curried_map_fn = curry(map)
    assert curried_map_fn(increase)(array) == map_fn(increase, array)



# Generated at 2022-06-12 05:40:22.247851
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(curried_map(increase))([[1, 2, 3], [2, 3, 1]]) == [[2, 3, 4], [3, 4, 2]]



# Generated at 2022-06-12 05:40:28.532431
# Unit test for function curried_filter
def test_curried_filter():
    """
    Test for function curried_filter.

    :returns:
    :rtype:
    """

    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4]) == [2, 4]
    assert curried_filter(lambda x: x % 3 == 0, [1, 2, 3, 4]) == [3]
    assert curried_filter(lambda x: x % 4 == 0, [1, 2, 3, 4]) == [4]
    assert curried_filter(lambda x: x % 5 == 0, [1, 2, 3, 4]) == []



# Generated at 2022-06-12 05:40:32.567224
# Unit test for function find
def test_find():
    arr = [1, 2, 3, 4, 5]
    res = find(arr, eq(4))
    assert res == 4, "Test for function find failed"
    print("Test for function find passed")



# Generated at 2022-06-12 05:40:40.897829
# Unit test for function find
def test_find():
    """
    Unit test for function find.

    :returns: A tuple of the test result and a string message.
    :type test: (Boolean, String)
    """
    test_list = [1, 2, 3, 4, 5]
    assert find(test_list, lambda x: x % 2 == 0) == 2
    assert find(test_list, lambda x: x >= 4) == 4
    assert find(test_list, lambda x: x <= 2) == 1
    assert find(test_list, lambda x: x == 6) is None
    return True, "test_find() passed!"



# Generated at 2022-06-12 05:40:44.305210
# Unit test for function curry
def test_curry():
    def sum(a, b):
        return a + b

    curried_sum = curry(sum)
    test_curried_sum = curried_sum(1)(2)
    assert (test_curried_sum == 3)


# Generated at 2022-06-12 05:40:46.830626
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 5)([2, 3, 5, 7, 8, 12]) == [7, 8, 12]



# Generated at 2022-06-12 05:40:52.847505
# Unit test for function eq
def test_eq():
    assert eq(10, 10) is True
    assert eq(10, 5) is False
    assert eq([1, 2, 3], [1, 2, 3]) is True
    assert eq({"a": "A"}, {"a": "A"}) is True
    assert eq({"a": "A"}, {"a": "B"}) is False
    assert eq({"a": "A"}, {"b": "A"}) is False
    assert eq({"a": "A", "b": "B"}, {"b": "B"}) is False



# Generated at 2022-06-12 05:40:55.260682
# Unit test for function find
def test_find():
    assert find([0, 1, 2], eq(0)) == 0
    assert find([0, 1, 2], eq(4)) is None


# Generated at 2022-06-12 05:41:03.610142
# Unit test for function cond
def test_cond():
    # cond get list of two-item tuples,
    # first is condition_function, second is execute_function.
    # Returns this execute_function witch first condition_function return truly value.

    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return not is_even(value)

    def add(value):
        return value + 1

    def subtract(value):
        return value - 1

    # cond depends on value was even or odd
    # and return add or subtract function
    # check even
    cond_even_or_add = cond([
        (is_even, add),
        (is_odd, subtract),
    ])
    # check odd

# Generated at 2022-06-12 05:41:49.562816
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([], lambda x: x == 2) is None


if __name__ == '__main__':
    test_find()
    print('all tests is passed')

# Generated at 2022-06-12 05:41:51.923753
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-12 05:41:57.990904
# Unit test for function curried_filter
def test_curried_filter():
    print("\nTest curried_filter")
    filter_string_even_values = curried_filter(lambda x: x % 2 == 0)
    filter_string_even_values_test = filter_string_even_values(["1", "2", "3", "4"])
    print("\tTest curried_filter, result - ", filter_string_even_values_test)
    assert filter_string_even_values_test == ["2", "4"]



# Generated at 2022-06-12 05:42:01.863614
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x % 2 == 0) == 2
    assert find(["a", "b", "c"], lambda x: x == "d") is None
    assert find(["a", "b", "c"], lambda x: x == "a") == "a"



# Generated at 2022-06-12 05:42:03.968693
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 3, 4]
    result = curried_filter(lambda x: x % 2 == 0, collection)
    assert result == [2, 4]



# Generated at 2022-06-12 05:42:08.699431
# Unit test for function memoize
def test_memoize():
    def fib(n):
        if n == 0 or n == 1:
            return n
        return fib(n - 1) + fib(n - 2)

    memoized_fib = memoize(fib)
    assert memoized_fib(32) == 2178309
    assert fib(32) != 2178309


if __name__ == "__main__":
    test_memoize()

# Generated at 2022-06-12 05:42:12.496526
# Unit test for function memoize
def test_memoize():
    count = 0

    @memoize
    def inc_count(value):
        nonlocal count
        count += 1
        return value + count

    assert inc_count(1) == 2
    assert inc_count(1) == 2
    assert inc_count(1) == 2
    assert inc_count(2) == 3
    assert count == 2

# Generated at 2022-06-12 05:42:16.049732
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)

    eq_1 = eq(1)
    assert eq_1(1)
    assert not eq_1(2)

    eq_1_1 = eq_1(1)
    assert eq_1_1()



# Generated at 2022-06-12 05:42:17.657026
# Unit test for function eq
def test_eq():
    eq_func = eq(1, 1)
    eq_func = eq(1)
    eq_func = eq(1)



# Generated at 2022-06-12 05:42:27.409086
# Unit test for function memoize
def test_memoize():
    import time
    import random
    import datetime
    def slow(number):
        time.sleep(3)
        return number
    def fast(number):
        time.sleep(1)
        return number
    def sleep(duration: datetime.timedelta):
        time.sleep(duration.total_seconds())
    memoized_slow = memoize(slow)
    memoized_fast = memoize(fast)
    start_time = datetime.datetime.now()
    memoized_fast(random.choice([1, 2, 3, 4, 5]))
    mem_fast_time = datetime.datetime.now() - start_time
    print('memoized_fast time: {}'.format(mem_fast_time))

    start_time = datetime.datetime.now()

# Generated at 2022-06-12 05:43:15.075218
# Unit test for function find
def test_find():
    """
    test for function find
    """
    fruits = ['apple', 'orange', 'pineapple']

    assert find(fruits, lambda fruit: fruit == 'orange') == 'orange'
    assert find(fruits, lambda fruit: fruit == 'strawberry') is None
    assert find(fruits, eq('strawberry')) is None



# Generated at 2022-06-12 05:43:24.913584
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x < 0, lambda x: -x),
        (lambda x: x == 0, lambda x: x),
        (lambda x: x > 0, lambda x: x * 2),
    ])(-2) == 2
    assert cond([
        (lambda x: x < 0, lambda x: -x),
        (lambda x: x == 0, lambda x: x),
        (lambda x: x > 0, lambda x: x * 2),
    ])(0) == 0
    assert cond([
        (lambda x: x < 0, lambda x: -x),
        (lambda x: x == 0, lambda x: x),
        (lambda x: x > 0, lambda x: x * 2),
    ])(2) == 4



# Generated at 2022-06-12 05:43:35.395251
# Unit test for function memoize
def test_memoize():
    # Test for lambda
    f = memoize(lambda x: x)
    assert f(1) == 1 and f(2) == 2

    # Test for memoize and eq keys
    f = memoize(lambda x: x, key=eq)
    assert f(1) == 1 and f(1) == 1 and f(2) == 2 and f(2) == 2

    # Test for memoize and lambda keys
    f = memoize(lambda x: x, key=lambda x, y: x[1] == y[1])

# Generated at 2022-06-12 05:43:38.040727
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x+1)([1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]


# Generated at 2022-06-12 05:43:45.750188
# Unit test for function cond
def test_cond():
    # Example of using
    def f(i):
        return cond([
            (lambda x: x % 2 == 0, lambda x: x * 2),
            (lambda x: x % 2 != 0, lambda x: x ** 2)
        ])(i)

    assert f(9) == 9**2
    assert f(2) == 2 * 2

    # Test return some value
    def g(x):
        return cond([
            (lambda x: x % 2 == 0, lambda x: x * 2),
            (lambda x: x % 2 != 0, lambda x: x ** 2)
        ])(x)

    assert g(10) == 20
    assert g(9) == 9**2



# Generated at 2022-06-12 05:43:49.802983
# Unit test for function memoize
def test_memoize():
    def add(x, y):
        return x + y

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3


# Generated at 2022-06-12 05:43:54.243938
# Unit test for function cond
def test_cond():
    assert (cond([
        (lambda x: True, lambda x: True),
        (lambda x: False, lambda x: False)
    ])(True)) == True

    assert (cond([
        (lambda x: False, lambda x: True),
        (lambda x: True, lambda x: False)
    ])(True)) == False

    assert (cond([
        (lambda x: True, lambda x: True),
        (lambda x: True, lambda x: False)
    ])(True)) == True



# Generated at 2022-06-12 05:44:02.760644
# Unit test for function curried_filter
def test_curried_filter():
    x = [1, 2, 3, 4, 5, 9]
    assert curried_filter(lambda e: e > 3, x) == [4, 5, 9]
    assert curried_filter(lambda e: e % 2 == 0, x) == [2, 4]
    assert curried_filter(lambda e: e > 8, x) == [9]
    assert curried_filter(lambda e: e > 10, x) == []
    assert curried_filter(lambda e: e > -10, x) == [1, 2, 3, 4, 5, 9]


# Generated at 2022-06-12 05:44:07.582904
# Unit test for function find
def test_find():
    assert find(range(10), lambda a: a == 5) == 5
    assert find(range(10), eq(50)) == None
    assert find(range(10), lambda a: a % 2 == 0) == 0
    assert find(range(10), lambda a: a % 2 == 1) == 1
    assert find(range(10), lambda a: a > 7) == 8



# Generated at 2022-06-12 05:44:12.208906
# Unit test for function curried_filter
def test_curried_filter():
    def is_even(x):
        return x % 2 == 0

    assert curried_filter(is_even)([1, 2, 3, 4]) == [2, 4]
    assert curried_filter(is_even, [1, 2, 3, 4]) == [2, 4]

# Generated at 2022-06-12 05:45:51.889835
# Unit test for function memoize
def test_memoize():
    def factorial(n):
        if n < 2:
            return 1
        return n * factorial(n - 1)

    fact10 = memoize(factorial)
    result = fact10(10)
    assert result == 3628800
    assert fact10(10) == result
    assert fact10(10) == result


test_memoize()

# Generated at 2022-06-12 05:46:00.967812
# Unit test for function memoize
def test_memoize():
    error_message = "memoize({0})({1}) != {2}"

    def sum(a, b):
        return a + b

    @memoize
    def sum_memoize(a):
        return sum(a, 1)

    assert sum_memoize(2) == 3, error_message.format(
        "sum",
        2,
        3
    )
    assert sum_memoize(2) == 3, error_message.format(
        "sum",
        2,
        3
    )

if __name__ == '__main__':
    test_memoize()

# Generated at 2022-06-12 05:46:06.246892
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 2)([1, 2, 3]) == [3, 4, 5]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
