

# Generated at 2022-06-12 05:36:14.930952
# Unit test for function find
def test_find():
    assert find(
        [1, 2, 3, 4, 5],
        eq(3)
    ) == 3
    assert find(
        [1, 2, 3, 4, 5],
        eq(6)
    ) is None



# Generated at 2022-06-12 05:36:22.467321
# Unit test for function cond
def test_cond():
    cond_test_thunk_1 = lambda n: n % 5 == 0
    cond_test_thunk_2 = lambda n: n % 2 == 0
    cond_test_thunk_3 = lambda n: n % 3 == 0

    cond_test_result_1 = lambda n: "Buzz"
    cond_test_result_2 = lambda n: "Fizz"
    cond_test_result_3 = lambda n: "FizzBuzz"

    cond_test = cond([(cond_test_thunk_3, cond_test_result_3),
                      (cond_test_thunk_1, cond_test_result_1),
                      (cond_test_thunk_2, cond_test_result_2)])

    assert cond_test(15) == "FizzBuzz"

# Generated at 2022-06-12 05:36:26.026305
# Unit test for function memoize
def test_memoize():
    factorial = memoize(lambda x: 0 if x == 0 else x * factorial(x - 1))

    assert factorial(5) == 120
    assert factorial(7) == 5040



# Generated at 2022-06-12 05:36:32.708375
# Unit test for function curry
def test_curry():
    array = [1, 2, 3]

    def add(a, b, c):
        return a + b + c

    curried_add = curry(add)
    assert curried_add(1, 2, 3) == add(1, 2, 3)
    assert curried_add(1, 2)(3) == add(1, 2, 3)
    assert curried_add(1)(2)(3) == add(1, 2, 3)
    assert curried_add(1)(2, 3) == add(1, 2, 3)

    def eq_array(array1):
        return eq(array, array1)

    assert eq_array(array)(array)

    curried_map(identity, array) == [1, 2, 3]
    curried_map(lambda x: x + 1, array)

# Generated at 2022-06-12 05:36:38.467779
# Unit test for function find
def test_find():
    collection = [1, 2, 3, 4, 5, 6, 7]
    key = lambda x: x % 2 == 0
    assert find(collection, key) == 2
    assert find([], key) == None


# Assertion for function identity

# Generated at 2022-06-12 05:36:40.889701
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False



# Generated at 2022-06-12 05:36:43.778575
# Unit test for function curried_filter
def test_curried_filter():
    numbers = [1, 2, 3, 4]
    added_numbers = curried_filter(lambda item: item > 5)(numbers)
    assert added_numbers == []

# Generated at 2022-06-12 05:36:51.878502
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y, z: x * y * z)(3)(6)(9) == 162
    assert curry(lambda x, y, z: x * y * z, 3)(3, 6, 9) == 162
    assert curry(lambda x, y, z: x * y * z, 3)(3, 6)(9) == 162
    assert curry(lambda x, y, z: x * y * z, 3)(3, 6, 9) == 162
    assert curry(lambda x, y, z: x * y * z, 3)(3, 6, 9) == 162



# Generated at 2022-06-12 05:37:02.455687
# Unit test for function curry
def test_curry():
    assert curry(lambda x: x)(1) == 1
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z, 3)(1)(2)(3) == 6
    assert curry(lambda x, y=1, z=2: x + y + z, 3)(1)(2)(3) == 6
    assert curry(lambda x, y=1, z=2: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y=1, z=2: x + y + z)(1)(z=3)(2) == 6

# Generated at 2022-06-12 05:37:07.400173
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6



# Generated at 2022-06-12 05:37:21.366602
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(eq(3), eq(3))
    assert not eq(eq(3), eq(4))
    assert eq('abc', 'abc')
    assert not eq('abc', 'abcd')

# Generated at 2022-06-12 05:37:24.725129
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x * x, [1, 2, 3]) == [1, 4, 9]


# Generated at 2022-06-12 05:37:31.184156
# Unit test for function curried_map
def test_curried_map():
    """
    Test curried_map.
    """
    assert curried_map(identity, [1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-12 05:37:34.329143
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x * 2, [1, 2, 3]) == [2, 4, 6]



# Generated at 2022-06-12 05:37:36.812345
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, range(10)) == [0, 2, 4, 6, 8]



# Generated at 2022-06-12 05:37:42.418153
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4] ) == [3, 4]
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4, 5] ) == [3, 4, 5]
    assert curried_filter(lambda x: x > 2, [2, 3, 4, 5] ) == [3, 4, 5]

# Generated at 2022-06-12 05:37:45.101559
# Unit test for function curried_map
def test_curried_map():
    # map(lambda x: x * 2, [1, 2, 3])
    double = curried_map(lambda x: x * 2)
    assert double([1, 2, 3]) == [2, 4, 6]


# Generated at 2022-06-12 05:37:48.667470
# Unit test for function find
def test_find():
    assert find([], identity) is None
    assert find([1, 2], lambda x: x < 0) is None
    assert find([1, 2], lambda x: x > 1) == 2



# Generated at 2022-06-12 05:37:52.600640
# Unit test for function curried_filter
def test_curried_filter():
    # curried_filter is curried function, so we can partially apply it
    filter_fn = curried_filter(lambda x: x % 2)

    assert filter_fn([1, 2, 3, 4]) == [1, 3]



# Generated at 2022-06-12 05:37:59.227362
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x, [1, 2, 3]) == [1, 2, 3]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x % 2, [1, 2, 3]) == [1, 0, 1]
    assert curried_map(lambda x, y: x + y, [1, 2, 3])(
        [1, 2, 3]) == [2, 4, 6]



# Generated at 2022-06-12 05:38:13.205185
# Unit test for function cond
def test_cond():
    assert cond([(lambda n: n == 0, lambda _: 'water freezes at 0°C'),
                 (lambda n: n == 100, lambda _: 'water boils at 100°C'),
                 (lambda n: True, lambda n: 'nothing special happens at {0}°C'),
                ])(0) == 'water freezes at 0°C'



# Generated at 2022-06-12 05:38:17.159320
# Unit test for function curried_filter
def test_curried_filter():
    def is_even(value):
        return value % 2 == 0

    assert curried_filter(is_even, [1, 2, 3, 4, 5, 6])([]) == [2, 4, 6]


# Generated at 2022-06-12 05:38:20.499042
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 10, [0, 1, 10, 11, 12, 13, 14])([10]) == [11, 12, 13, 14]


# Generated at 2022-06-12 05:38:25.197028
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]

    curried_map_inc = curried_map(lambda x: x + 1)
    assert curried_map_inc([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-12 05:38:29.565990
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4]) == [3, 4]
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4]) == [3, 4]



# Generated at 2022-06-12 05:38:36.032044
# Unit test for function cond
def test_cond():
    f1 = cond([
        (lambda x: x % 2 == 0, lambda x: x // 2),
        (lambda x: x % 3 == 0, lambda x: x // 3),
        (lambda x: True, lambda x: x - 1),
    ])
    assert f1(5) == 4
    assert f1(6) == 3
    assert f1(7) == 6


# Generated at 2022-06-12 05:38:42.837700
# Unit test for function cond
def test_cond():
    def f():
        return 1

    def g():
        return 2

    def h():
        return 3

    def k():
        return 4

    assert 1 == cond([
        (lambda x: x > 1, f),
        (lambda x: x > 2, g),
        (lambda x: x > 3, h),
        (lambda x: x > 4, k)
    ])(1)

    assert 2 == cond([
        (lambda x: x > 1, f),
        (lambda x: x > 2, g),
        (lambda x: x > 3, h),
        (lambda x: x > 4, k)
    ])(2)


# Generated at 2022-06-12 05:38:46.925822
# Unit test for function find
def test_find():
    collection = [1, 2, 3, 4, 5]
    result = find(collection, lambda x: x == 2)
    assert result == 2
    result = find(collection, lambda x: x == 11)
    assert result is None

# Generated at 2022-06-12 05:38:53.043947
# Unit test for function curried_filter
def test_curried_filter():
    def map_filterer(x):
        return x % 2 == 0

    assert isinstance(curried_filter(map_filterer), curry)

    assert curried_filter(map_filterer)(range(0, 10)) \
        == list(filter(map_filterer, range(0, 10)))

    assert curried_filter(map_filterer)(range(0, 10)) \
        == list(filter(map_filterer, range(0, 10)))

    assert curried_filter(map_filterer, range(0, 10)) \
        == list(filter(map_filterer, range(0, 10)))


# Generated at 2022-06-12 05:38:58.775955
# Unit test for function memoize
def test_memoize():
    def get_time(i):
        print('get_time is called')
        return time.time()

    time_now_memoize = memoize(get_time)
    assert time_now_memoize(1) == time_now_memoize(1)
    assert time_now_memoize(2) == time_now_memoize(2)
    assert time_now_memoize(1) != time_now_memoize(2)



# Generated at 2022-06-12 05:39:24.798223
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def increase_by_1(value):
        return value + 1

    def double(value):
        return value + value

    assert cond([
        (is_even, double),
        (lambda x: True, increase_by_1),
    ])(3) == 4

    assert cond([
        (is_even, double),
        (lambda x: True, increase_by_1),
    ])(4) == 8

    assert cond([
        (is_even, double),
        (lambda x: True, increase_by_1),
    ])(7) == 8

    assert cond([
        (is_even, double),
        (lambda x: True, increase_by_1),
    ])(6) == 12



# Generated at 2022-06-12 05:39:32.548151
# Unit test for function memoize
def test_memoize():
    from time import time

    @memoize
    def time_to_sleep(x):
        import time
        time.sleep(x)
        return x

    start = time()
    time_to_sleep(1)
    time_to_sleep(1)
    finish = time()

    assert abs(start + 1 - finish) < 0.5
    print("Unit test for memoize has been passed successfully")

if __name__ == '__main__':
    test_memoize()

# Generated at 2022-06-12 05:39:37.918276
# Unit test for function curried_filter
def test_curried_filter():
    data = [1, 2, 3, 4, 5]
    assert(list(curried_filter(eq(2))(data)) == [2])
    assert(list(curried_filter(eq(2), data)) == [2])
    assert(list(curried_filter(eq(2), [1, 2, 3])) == [2])
    assert(list(curried_filter(lambda x: x % 2 == 0, data)) == [2, 4])
    assert(list(curried_filter(lambda x: x % 2 == 0)(data)) == [2, 4])



# Generated at 2022-06-12 05:39:42.761457
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(1)) == 1
    assert find([1, 2, 3], eq(2)) == 2
    assert find([1, 2, 3], eq(3)) == 3
    assert find([1, 2, 3], eq(4)) == None
    assert find([], eq(None)) == None


# Generated at 2022-06-12 05:39:45.484393
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x**2)([1, 2, 3]) == [1, 4, 9]



# Generated at 2022-06-12 05:39:49.717067
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1,2,3,4,5]
    filter_collection = curried_filter(lambda x: x>3)
    assert filter_collection(collection) == [4,5]


# Generated at 2022-06-12 05:39:52.758642
# Unit test for function curry
def test_curry():
    curried_add = curry(lambda a, b: a + b)
    assert curried_add(1)(2) == 3
    assert curried_add(1, 2) == 3


# Generated at 2022-06-12 05:39:56.386673
# Unit test for function eq
def test_eq():
    assert eq(1) == 1
    assert eq(1)(1) is True
    assert eq(1)(2) is False
    assert eq(1, 1) is True
    assert eq(1, 2) is False



# Generated at 2022-06-12 05:40:00.417790
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter([1, 2, 3, 4])(lambda x: x > 2) == [3, 4]
    assert curried_filter([1, 2, 3, 4])(lambda x: x < 3) == [1, 2]



# Generated at 2022-06-12 05:40:06.771792
# Unit test for function find
def test_find():
    assert find([], eq(2)) is None
    assert find([], lambda item: item == 2) is None
    assert find([3, 2, 1], eq(2)) == 2
    assert find([3, 2, 1], lambda item: item == 2) == 2
    assert find([3, 2, 1], eq(4)) is None
    assert find([3, 2, 1], lambda item: item == 4) is None


# Generated at 2022-06-12 05:40:47.102462
# Unit test for function find
def test_find():
    collection = ["test", "anothertest", 1, 2, 3, 0]

    def is_number(x):
        return type(x) == int

    assert find(collection, is_number) == 1



# Generated at 2022-06-12 05:40:49.992551
# Unit test for function eq
def test_eq():
    assert(eq(1, 1))
    assert(not eq(1, 2))
    assert(eq(1, 1) == eq(1)(1))



# Generated at 2022-06-12 05:40:56.460464
# Unit test for function curried_filter
def test_curried_filter():
    l = ['a', 'b', 'c', 'd']
    assert curried_filter(lambda x: x == 'a', l) == ['a']
    assert curried_filter(lambda x: x == 'a')(l) == ['a']
    assert curried_filter(lambda x: x == 'a', [])(l) == ['a']



# Generated at 2022-06-12 05:41:03.744673
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 1) == 1
    assert find([1, 2, 3], lambda x: x == 3) == 3
    assert find([1, 2, 3], lambda x: x == 5) is None
    assert find([1, 2, 3], lambda x: x == 1) == 1
    assert find([1, 2, 3], lambda x: x == 5) is None
    assert find(range(100), lambda x: x == 5) == 5
    assert find(range(100), lambda x: x == 10) == 10
    assert find(xrange(100), lambda x: x == 5) == 5
    assert find(xrange(100), lambda x: x == 10) == 10


# Generated at 2022-06-12 05:41:07.100139
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq(1)(1) == True
    assert eq(1)(2) == False
    assert eq(1, eq(1)) == False


# Generated at 2022-06-12 05:41:13.896318
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x > 2) == 3, "Should be 3"
    assert find([1, 2, 3, 4], lambda x: x > 4) is None, "Should be none"
    assert find([1, 2, 3, 4], lambda x: x > 6) is None, "Should be none"


# Generated at 2022-06-12 05:41:17.653962
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 5)([1, 2, 3, 4, 5, 6, 7]) == [6, 7]
    assert curried_filter(lambda x: x < 5, [1, 2, 3, 4, 5, 6, 7]) == [1, 2, 3, 4]



# Generated at 2022-06-12 05:41:26.514380
# Unit test for function cond
def test_cond():
    def is_zero(value):
        return value == 0

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    def add_one(value):
        return value + 1

    def minus_one(value):
        return value - 1

    def square(value):
        return value * value

    result = cond(
        [
            (is_positive, add_one),
            (is_negative, minus_one),
            (is_zero, square),
        ]
    )

    assert result(4) == 5
    assert result(-4) == -3
    assert result(0) == 0


if __name__ == "__main__":
    assert increase(1) == 2
    assert curry(increase)(1) == 2

# Generated at 2022-06-12 05:41:32.097337
# Unit test for function find
def test_find():
    collection = [
        1,
        2,
        3,
    ]
    expected_result = 2
    key = lambda element: element == expected_result
    truthy_result = find(collection, key)

    assert truthy_result == expected_result
    assert find(collection, lambda x: x == 0) is None



# Generated at 2022-06-12 05:41:34.839117
# Unit test for function find
def test_find():
    assert find(['a', 'b', 'c'], lambda x: x == 'b') == 'b'
    assert find(['a', 'b', 'c'], lambda x: x == 'x') is None



# Generated at 2022-06-12 05:42:50.201977
# Unit test for function memoize
def test_memoize():
    @memoize
    def factorial(x):
        return 1 if x <= 1 else x * factorial(x - 1)
    assert factorial(6) == 720

# Generated at 2022-06-12 05:42:54.762226
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(1)) == 1
    assert find([1, 2, 3], eq(4)) is None
    assert find([{1: 2}], eq({1: 2})) == {1: 2}
    assert find([{1: 2}], eq({1: 3})) is None



# Generated at 2022-06-12 05:43:01.488903
# Unit test for function memoize
def test_memoize():
    fib_cache = []

    def fib(n):
        if n < 2:
            return n
        return find(
            fib_cache,
            lambda item: item[0] == n
        )[1] if find(fib_cache, lambda item: item[0] == n) else fib(n - 2) + fib(n - 1)

    fib = memoize(fib)

    print(fib(5))



# Generated at 2022-06-12 05:43:09.318632
# Unit test for function cond
def test_cond():
    add_1 = lambda x: x + 1
    add_2 = lambda x: x + 2
    multiply_2 = lambda x: x * 2
    print('should be eq 5', cond([(lambda x: x == 1, multiply_2), (lambda x: x == 5, add_1)])(5))
    print('should be eq 3', cond([(lambda x: x == 2, multiply_2), (lambda x: x == 2, add_1)])(2))
    print('should be eq 6', cond([(lambda x: x == 3, multiply_2), (lambda x: x == 6, add_1)])(6))
    print('should be eq 6', cond([(lambda x: x == 4, multiply_2), (lambda x: x == 6, add_2)])(6))



# Generated at 2022-06-12 05:43:14.748316
# Unit test for function memoize
def test_memoize():
    @memoize
    def add1(x):
        return x + 1

    assert add1(2) == 3
    assert add1(2) == 3
    assert add1(2) == 3
    assert add1(2) == 3
    assert add1(2) == 3

    assert add1(3) == 4
    assert add1(3) == 4
    assert add1(3) == 4
    assert add1(3) == 4
    assert add1(3) == 4

    assert add1(3) == 4

    assert add1('x') == 'x1'



# Generated at 2022-06-12 05:43:19.697611
# Unit test for function eq
def test_eq():
    assert eq(2, 2)
    assert eq(-2, -2)
    assert eq(0, 0)
    assert eq('0', '0')
    assert eq(None, None)
    assert not eq(2, 3)
    assert not eq('0', 0)



# Generated at 2022-06-12 05:43:26.765535
# Unit test for function curry
def test_curry():
    func1 = lambda x: x + 1
    func2 = lambda x, y: x * y
    func3 = lambda x, y, z: x + y + z
    func4 = lambda w, x, y, z: w * x + y + z
    func5 = lambda v, w, x, y, z: v * w + x + y + z

    assert curry(func1)(1) == 2
    assert curry(func2)(1, 2) == 2
    assert curry(func2)(2)(1) == 2
    assert curry(func3)(1, 2, 3) == 6
    assert curry(func3)(1, 2)(3) == 6
    assert curry(func3)(1)(2)(3) == 6
    assert curry(func4)(1, 2, 3, 4) == 13

# Generated at 2022-06-12 05:43:36.278675
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b, c, d: a + b + c + d)(1, 2, 3, 4) == 10
    assert curry(lambda a, b, c, d: a + b + c + d)(1)(2)(3)(4) == 10
    assert curry(lambda a, b, c, d: a + b + c + d)(1)(2, 3, 4) == 10
    assert curry(lambda a, b, c, d: a + b + c + d)(1, 2)(3)(4) == 10
    assert curry(lambda a, b, c, d: a + b + c + d)(1, 2)(3, 4) == 10
    assert curry(lambda a, b, c, d: a + b + c + d)(1, 2, 3)(4) == 10

# Generated at 2022-06-12 05:43:38.184181
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-12 05:43:41.537355
# Unit test for function memoize
def test_memoize():
    def xx(x):
        print(x)
    x = memoize(xx, key=lambda x1, x2: x1 >= x2)
    assert x(5) == x(5)


# Generated at 2022-06-12 05:45:07.909662
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_triple(value):
        return value % 3 == 0

    def is_odd(value):
        return not is_even(value)

    def is_divisible_by_12(value):
        return value % 12 == 0

    foo = curried_map(increase)
    bar = curried_filter(is_even)
    qux = curried_filter(is_odd)
    foobarqux = compose(qux, bar, foo)

    value_evaluator_list = [
        (is_triple, foobarqux),
        (is_divisible_by_12, qux),
        (identity, foo)
    ]

    conditional_evaluator = cond(value_evaluator_list)



# Generated at 2022-06-12 05:45:10.888678
# Unit test for function memoize
def test_memoize():
    def double_number(x): return x * 2

# Generated at 2022-06-12 05:45:14.972210
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(lambda x: x*x)([1, 2, 3]) == [1, 4, 9]



# Generated at 2022-06-12 05:45:20.919166
# Unit test for function cond
def test_cond():
    my_list = [
        (lambda x: x < 0, lambda x: "smaller than 0"),
        (lambda x: x == 0, lambda x: "equal to 0"),
        (lambda x: x > 0, lambda x: "greater than 0")
    ]
    my_cond = cond(my_list)

    print("2 is " + my_cond(2))
    print("0 is " + my_cond(0))
    print("15 is " + my_cond(15))
    print("-3 is " + my_cond(-3))

# Generated at 2022-06-12 05:45:24.975190
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 1, [1, 2, 3]) == [2, 3]
    assert curried_filter(lambda x: x > 1)([1, 2, 3]) == [2, 3]



# Generated at 2022-06-12 05:45:33.048824
# Unit test for function eq
def test_eq():
    # Arrange
    assert_eq: Callable[[Any, Any], None] = \
        lambda actual, expected: \
            assert_equal(actual, expected)

    # Act&Assert
    for args in (
        (1, 1),
        (1, 1),
        (True, True),
        (False, False),
        (None, None),
        ([1, 2], [1, 2]),
        ([], []),
        ({'a': 1}, {'a': 1}),
        ({}, {}),
        (('a',), ('a',))
    ):
        assert_eq(eq(*args), True)

# Generated at 2022-06-12 05:45:38.690209
# Unit test for function curried_filter
def test_curried_filter():
    curried_filter_func = curried_filter(
        lambda x: x % 2 == 1
    )
    assert curried_filter_func(
        [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    ) == [1, 3, 5, 7, 9]


# Generated at 2022-06-12 05:45:40.897598
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4])([]) == [2, 4]

# Generated at 2022-06-12 05:45:44.209291
# Unit test for function find
def test_find():
    find_function = find([1, 2, 3, 4], lambda x: x % 2 == 0)
    if find_function != 2:
        raise AssertionError('Error in function find')



# Generated at 2022-06-12 05:45:50.252761
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x > 0, lambda x: x * x),
        (lambda x: x < 0, lambda x: -x),
        (lambda x: True, lambda x: 0)
    ])(1) == 1
    assert cond([
        (lambda x: x > 0, lambda x: x * x),
        (lambda x: x < 0, lambda x: -x),
        (lambda x: True, lambda x: 0)
    ])(-1) == 1
    assert cond([
        (lambda x: x > 0, lambda x: x * x),
        (lambda x: x < 0, lambda x: -x),
        (lambda x: True, lambda x: 0)
    ])(0) == 0

