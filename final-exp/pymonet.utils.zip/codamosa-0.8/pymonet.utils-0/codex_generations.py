

# Generated at 2022-06-12 05:36:14.384627
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1]) == [2]
    assert curried_map(increase, [1]) == [2]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]

test_curried_map()


# Generated at 2022-06-12 05:36:19.753120
# Unit test for function memoize
def test_memoize():
    fn_to_memoize_called_count = 0

    def fn_to_memoize():
        nonlocal fn_to_memoize_called_count
        fn_to_memoize_called_count += 1

    memoized_fn = memoize(fn_to_memoize)
    memoized_fn()
    memoized_fn()
    assert fn_to_memoize_called_count == 1

# Generated at 2022-06-12 05:36:29.291695
# Unit test for function find
def test_find():
    items = [
        {'id': 1, 'name': 'test1'},
        {'id': 2, 'name': 'test2'},
        {'id': 3, 'name': 'test3'},
        {'id': 4, 'name': 'test4'},
        {'id': 5, 'name': 'test5'},
    ]

    key1 = find(items, lambda item: item['id'] == 2)
    assert key1['id'] == 2
    assert key1['name'] == 'test2'

    key2 = find(items, lambda item: item['id'] == 3)
    assert key2['id'] == 3
    assert key2['name'] == 'test3'


# Generated at 2022-06-12 05:36:37.906770
# Unit test for function cond
def test_cond():
    def is_even(value: int, devider: int = 2) -> bool:
        return value % devider == 0

    def even_calculator(value: int, addend: int = 100) -> int:
        return value + addend

    def odd_calculator(value: int, addend: int = 200) -> int:
        return value + addend

    def default_calculator(value: int, addend: int = 300) -> int:
        return value + addend

    condition_list = [
        (is_even, even_calculator),
        (lambda value: not is_even(value), odd_calculator),
    ]
    default_calculator = cond([(lambda value: True, default_calculator)])

# Generated at 2022-06-12 05:36:43.600818
# Unit test for function curried_filter
def test_curried_filter():
    def even(value):
        return value % 2 == 0

    collection = list(range(10))
    expected_collection = list(range(0, 10, 2))

    filtered_collection = curried_filter(even, collection)
    assert(expected_collection == filtered_collection)

    # curried_filter with one argument
    filter_function = curried_filter(even)
    filtered_collection2 = filter_function(collection)
    assert(expected_collection == filtered_collection2)



# Generated at 2022-06-12 05:36:47.537348
# Unit test for function find
def test_find():
    assert find(
        range(0, 5),
        lambda item: item == 3
    ) == 3
    assert find(
        range(0, 5),
        lambda item: item == 10
    ) is None

# Generated at 2022-06-12 05:36:57.027269
# Unit test for function curry
def test_curry():
    def f(x, y, z):
        return x + y + z

    f1 = curry(f)
    f2 = curry(f)(1)
    f3 = curry(f)(1)(2)
    assert f1(1, 2, 3) == 6
    assert f2(2, 3) == 6
    assert f3(3) == 6

    f4 = curry(f, 3)
    assert f4(1, 2, 3) == 6

    assert f4(1)(2)(3) == 6
    assert f4(1, 2)(3) == 6


# Generated at 2022-06-12 05:37:04.807388
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x < 5, [1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4]
    assert curried_filter(lambda x: x < 5)([1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4]
    assert curried_filter(lambda x: x < 5)(range(1, 10)) == [1, 2, 3, 4]
    assert curried_filter(lambda x: x > 5)(range(1, 10)) == [6, 7, 8, 9]
    assert curried_filter(lambda x: x % 2 == 0)(range(1, 10)) == [2, 4, 6, 8]



# Generated at 2022-06-12 05:37:07.306986
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x * x, [1, 2, 3]) == [1, 4, 9]


# Generated at 2022-06-12 05:37:18.222148
# Unit test for function memoize
def test_memoize():
    """
    Test memoize
    """

    def inner_func(arg):
        """
        Inner method for testing memoize
        """
        return arg

    inner_func_memoized = memoize(inner_func)
    assert inner_func_memoized("") == ""
    assert inner_func_memoized("") == ""

    def inner_func_sideeffect(arg):
        """
        Inner method for testing memoize
        """
        inner_func_sideeffect.call_count += 1
        return arg

    inner_func_sideeffect.call_count = 0
    inner_func_sideeffect_memoized = memoize(inner_func_sideeffect)
    inner_func_sideeffect_memoized("")
    inner_func_sideeffect_memoized("")
    assert inner_func_side

# Generated at 2022-06-12 05:37:25.968164
# Unit test for function curried_filter
def test_curried_filter():
    result = curried_filter(lambda x: x % 2 == 0)(range(10))
    assert result == [0, 2, 4, 6, 8]



# Generated at 2022-06-12 05:37:37.715366
# Unit test for function memoize
def test_memoize():
    result_list = [identity(10), identity(10), identity(10)]
    memoized_fn = memoize(identity)
    result_list[0] = memoized_fn(10)
    result_list[1] = memoized_fn(10)
    result_list[2] = memoized_fn(10)
    assert result_list == [10, 10, 10]

    result_list = [identity(i) for i in [10, 11, 12, 13, 14]]
    memoized_fn = memoize(identity)
    result_list[0] = memoized_fn(10)
    result_list[1] = memoized_fn(11)
    result_list[2] = memoized_fn(12)
    result_list[3] = memoized_fn(13)
   

# Generated at 2022-06-12 05:37:39.847860
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-12 05:37:46.432827
# Unit test for function cond
def test_cond():
    equation = cond([
        (lambda x: x % 5 == 0 and x % 3 == 0, lambda: 'FizzBuzz'),
        (lambda x: x % 3 == 0, lambda: 'Fizz'),
        (lambda x: x % 5 == 0, lambda: 'Buzz'),
        (lambda x: True, lambda x: x),
    ])

    assert equation(3) == 'Fizz', 'Conditional equation in test_cond failed'
    assert equation(5) == 'Buzz', 'Conditional equation in test_cond failed'
    assert equation(15) == 'FizzBuzz', 'Conditional equation in test_cond failed'



# Generated at 2022-06-12 05:37:54.998147
# Unit test for function memoize
def test_memoize():
    def foo(n):
        return n ** 2

    foo = memoize(foo)

    assert foo(1) == 1
    # The first call to foo will save the result
    # Future calls to foo with the same argument

    assert foo(1) == 1
    # will use the cached result and will not call the function

    assert foo(2) == 4
    # The call to foo(2) will save the result for later use

    assert foo(2) == 4
    # The result will be taken from the cache
    # and the function will not be called again until foo(3)

    assert foo(3) == 9



# Generated at 2022-06-12 05:37:58.338485
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(identity, [1, 2, 3]) == [1, 2, 3]
    assert curried_filter(lambda x: x > 1, [1, 2, 3]) == [2, 3]



# Generated at 2022-06-12 05:38:01.440036
# Unit test for function curried_map
def test_curried_map():
    a = curried_map(increase, [1, 2, 3, 4, 5])
    assert a == [2, 3, 4, 5, 6]



# Generated at 2022-06-12 05:38:03.388264
# Unit test for function memoize
def test_memoize():
    assert to_string(memoize(curried_map(increase))([1, 2, 3])) == '[2, 3, 4]'
    assert to_string(memoize(curried_filter(lambda x: x > 2))([1, 2, 3])) == '[3]'

# Generated at 2022-06-12 05:38:06.720220
# Unit test for function memoize
def test_memoize():
    assert memoize(increase)(4) == 5
    assert memoize(increase)(4) == 5
    assert memoize(increase)(4) == 5


# Generated at 2022-06-12 05:38:11.436745
# Unit test for function memoize
def test_memoize():
    def fn(arg):
        return arg * 2

    memoized_fn = memoize(fn)
    assert memoized_fn(10) == fn(10)
    assert memoized_fn(10) == fn(10)
    assert memoized_fn(10) == 20



# Generated at 2022-06-12 05:38:26.302519
# Unit test for function memoize
def test_memoize():
    fake_factorial = lambda x: 1 if x == 0 else x * fake_factorial(x - 1)
    factorial = memoize(fake_factorial)
    assert factorial(5) == 120
    assert factorial(5) == 120
    assert factorial(5) == 120
    assert factorial(1) == 1
    assert factorial(2) == 2
    assert factorial(3) == 6
    assert factorial(4) == 24
    assert factorial(5) == 120
    assert factorial(6) == 720
    assert factorial(7) == 5040
    assert factorial(8) == 40320


if __name__ == '__main__':
    test_memoize()

# Generated at 2022-06-12 05:38:31.891268
# Unit test for function curried_filter
def test_curried_filter():
    # Test for curried_filter with argument filterer
    def is_even_number(number: int) -> bool:
        return number % 2 == 0

    # Test for curried_filter with argument collection
    def numbers():
        return range(10)

    test_list = curried_filter(is_even_number)(numbers())

    assert test_list == list(filter(is_even_number, range(10)))


# Generated at 2022-06-12 05:38:33.996786
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-12 05:38:37.930939
# Unit test for function curried_filter
def test_curried_filter():
    a = [1, 2, 3, 4]
    b = curried_filter(eq(3))(a)
    assert b == [3], 'curried_filter should filter'



# Generated at 2022-06-12 05:38:39.258274
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False


# Generated at 2022-06-12 05:38:49.456138
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([4, 2, 3]) == [5, 3, 4]
    assert curried_map(lambda x: x + 1, [4, 2, 3]) == [5, 3, 4]
    increase1 = curried_map(increase)
    increase2 = increase1(increase)
    assert increase2([1, 2, 3]) == [2, 3, 4]

# Generated at 2022-06-12 05:38:55.546950
# Unit test for function curried_map
def test_curried_map():
    """
    Tests curried_map
    :return:
    :rtype:
    """
    lst = [1, 2, 3, 4]
    square = lambda x: x * x
    fmap = curried_map(square)
    assert fmap(lst) == list(map(square, lst))
    return True



# Generated at 2022-06-12 05:39:00.812198
# Unit test for function curried_filter
def test_curried_filter():
    test = [1, 2, 3, 4, 5]
    assert curried_filter(eq(3))(test) == [3]
    assert curried_filter(eq(3), test) == [3]
    assert curried_filter(eq(6))(test) == []
    assert curried_filter(eq(6), test) == []



# Generated at 2022-06-12 05:39:08.898567
# Unit test for function memoize
def test_memoize():
    @memoize
    def plus(a, b):
        return a + b

    _ = plus(1, 1)
    assert(plus(1, 1) == 2)
    assert(plus(1, 1) == 2)
    assert(plus(2, 1) == 3)
    assert(plus(2, 1) == 3)
    assert(plus(2, 1) == 3)
    assert(plus(3, 1) == 4)

if __name__ == "__main__":
    test_memoize()
    pass

# Generated at 2022-06-12 05:39:13.894275
# Unit test for function curried_map
def test_curried_map():
    curried_map_add_10 = curried_map(lambda x: x + 10)
    assert curried_map_add_10([1, 2, 3]) == [11, 12, 13]

    assert curried_map(lambda x: x + 10, [1, 2, 3]) == [11, 12, 13]



# Generated at 2022-06-12 05:39:27.606184
# Unit test for function memoize
def test_memoize():
    def times2(x):
        return x * 2

    def test_memoized():
        memoized = memoize(times2)
        assert memoized(2) == 4
        assert memoized(2) == 4
        assert memoized(2) == 4

# Generated at 2022-06-12 05:39:32.166240
# Unit test for function curried_filter
def test_curried_filter():
    filter_odd_numbers = curried_filter(lambda number: number % 2 == 1)
    assert filter_odd_numbers(range(20)) == [1, 3, 5, 7, 9, 11, 13, 15, 17, 19]



# Generated at 2022-06-12 05:39:35.259999
# Unit test for function curried_map
def test_curried_map():
    my_list = [1, 2, 3, 4, 5]
    my_map = curried_map(lambda x: x * 2)
    assert my_map(my_list) == [2, 4, 6, 8, 10]


# Generated at 2022-06-12 05:39:47.249717
# Unit test for function curried_filter
def test_curried_filter():
    assert [] == curried_filter(lambda x: x % 2 == 0, []), "Test #1"
    assert [] == curried_filter(lambda x: x % 2 == 0, [1, 3, 5, 7, 9]), "Test #2"
    assert [1, 3, 5, 7, 9] == curried_filter(lambda x: x % 2 == 1, [1, 3, 5, 7, 9]), "Test #3"
    assert [0, 2, 4, 6, 8] == curried_filter(lambda x: x % 2 == 0, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]), "Test #4"

# Generated at 2022-06-12 05:39:51.897905
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq('1', 1)
    assert eq(1, 1)()
    assert not eq('1', 1)()
    assert eq(1)(1)
    assert not eq('1')(1)



# Generated at 2022-06-12 05:39:55.513109
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4], lambda x: x == 5) is None

test_find()

# Generated at 2022-06-12 05:39:58.304343
# Unit test for function curry
def test_curry():
    """
    Test for function curry.
    """
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6



# Generated at 2022-06-12 05:40:01.537069
# Unit test for function curried_filter
def test_curried_filter():
    assert [x for x in range(11) if x % 2 == 0] == curried_filter(lambda x: x % 2 == 0, range(11))



# Generated at 2022-06-12 05:40:04.332278
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(2)) == 2
    assert find([1, 2, 3], eq(4)) is None
    return True



# Generated at 2022-06-12 05:40:10.513792
# Unit test for function find
def test_find():
    """
    Function to prove function find.
    """
    test_list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert find(test_list, lambda number: number > 5) == 6
    assert find(test_list, lambda number: number < 5) == 0
    assert find(test_list, lambda number: number > 9) is None



# Generated at 2022-06-12 05:40:34.926964
# Unit test for function curried_filter
def test_curried_filter():
    """
    Test function curried_filter

    :returns: True if curried_filter works
    :rtype: bool
    """
    assert([1, 2, 3] == curried_filter(lambda x: x > 0, [1, 2, 3]))
    assert([2, 4] == curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4]))
    assert([1, 2, 3] == curried_filter(lambda x: x < 5, [1, 2, 3]))

    def positive(x): return lambda x: x > 0

    assert([1, 2, 3] == curried_filter(positive, [1, 2, 3]))

    return True


# Generated at 2022-06-12 05:40:44.994290
# Unit test for function curried_map
def test_curried_map():
    """
    Test for curried_ma.
    """
    # curried_map_is_callable:
    try:
        assert callable(curried_map)
    except AssertionError:
        print("curried_map is not callable")

    # curried_map_is_curried:
    try:
        assert callable(curried_map(identity))
    except AssertionError:
        print("curried_map is not curried")

    # curried_map_has_two_argument:
    try:
        assert len(inspect.signature(curried_map).parameters) == 2
    except AssertionError:
        print("curried_map has not two argument")

    # curried_map_return_empty_list_when_collection_is_empty_list:

# Generated at 2022-06-12 05:40:48.545682
# Unit test for function find
def test_find():
    """ Unit test for find function."""
    assert find([], lambda x: True) is None
    assert find([1, 2, 3], lambda x: x == 1) == 1
    assert find([1, 2, 3], lambda x: x == 5) is None

# Generated at 2022-06-12 05:40:50.496836
# Unit test for function curried_filter
def test_curried_filter():
    result = curried_filter(lambda a: a % 2 == 1)
    assert result([1, 2, 3, 4, 5]) == [1, 3, 5]



# Generated at 2022-06-12 05:40:54.519062
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x % 2 == 1, increase),
        (lambda x: x % 2 == 0, identity)
    ])(1) == 2



# Generated at 2022-06-12 05:40:59.021991
# Unit test for function find
def test_find():
    some_list = [1, 2, 3, 4, 5]
    assert find(some_list, lambda item: item > 3) == 4
    assert find(some_list, lambda item: item < 3) == 1
    assert find(some_list, lambda item: item == 6) is None


# Generated at 2022-06-12 05:41:04.669305
# Unit test for function cond
def test_cond():
    is_even = cond([
        (lambda x: x % 2 == 0, lambda x: print(x, 'is even')),
        (lambda x: True, lambda x: print(x, 'is odd')),
    ])

    is_even(2)
    is_even(3)



# Generated at 2022-06-12 05:41:15.919822
# Unit test for function memoize
def test_memoize():
    calls = []
    def f(x, y):
        calls.append((x, y))
        return x + y

    x = memoize(f)

    assert x(1, 2) == 3
    assert x(2, 3) == 5
    assert calls == [(1, 2), (2, 3)]
    assert x(1, 2) == 3
    assert calls == [(1, 2), (2, 3)]

    x = memoize(f, key=compose(eq, increase))

    assert x(1, 2) == 4
    assert x(2, 3) == 6
    assert calls == [(1, 2), (2, 3)]
    assert x(1, 2) == 4
    assert calls == [(1, 2), (2, 3)]



# Generated at 2022-06-12 05:41:24.370003
# Unit test for function memoize
def test_memoize():
    # First call is true
    assert memoize(lambda x: x ** 2)(10) == 100
    # Second call is false because result from first call is taken from cache
    assert memoize(lambda x: x ** 2)(10) == 100
    # Curry function is false because there is no cached result for this arguments
    assert memoize(lambda x: x ** 2)(11) == 121
    # Curry function is false because there is no cached result for this function
    assert memoize(lambda x: x ** 3)(10) == 1000

# Generated at 2022-06-12 05:41:29.311790
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(curried_map(increase), [[1, 2], [3, 4]]) == [[2, 3], [4, 5]]


# Generated at 2022-06-12 05:41:38.701519
# Unit test for function find
def test_find():
    find_test_map = [1, 2, 3, 4]
    assert find(find_test_map, lambda a: a == 3) == 3
    assert find(find_test_map, lambda a: a == 6) is None
    assert find(find_test_map, lambda a: a % 2 == 0) == 2



# Generated at 2022-06-12 05:41:45.764791
# Unit test for function find
def test_find():
    dict_collection = [
        {'a': 1},
        {'a': 2},
        {'a': 3},
    ]
    expect_value = {'a': 2}
    assert find(dict_collection, lambda item: item['a'] == 2) == expect_value
    assert find(dict_collection, lambda item: item['a'] == 4) == None

    numbers_collection = [1, 2, 3]
    assert find(numbers_collection, lambda num: num == 2) == 2
    assert find(numbers_collection, lambda num: num == 5) == None


# Generated at 2022-06-12 05:41:50.025608
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(2)) == 2
    assert find([1, 2, 3], eq(4)) is None
    assert find([1, 2, 3], eq(2)) == 2
    assert find([1, 2, 3], eq(4)) is None



# Generated at 2022-06-12 05:41:53.505236
# Unit test for function curry
def test_curry():
    assert curry(identity)(1) == 1
    assert curry(identity, 2)(1, 2) == (1, 2)
    assert curry(identity, 2)(1)(2) == (1, 2)



# Generated at 2022-06-12 05:42:00.892518
# Unit test for function curried_filter
def test_curried_filter():
    a = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    result = curried_filter(eq(0))(a)
    assert result == []
    result = curried_filter(eq(1))(a)
    assert result == [1]
    result = curried_filter(eq(2))(a)
    assert result == [2]
    result = curried_filter(eq(3))(a)
    assert result == [3]
    result = curried_filter(eq(4))(a)
    assert result == [4]
    result = curried_filter(eq(5))(a)
    assert result == [5]
    result = curried_filter(eq(6))(a)
    assert result == [6]

# Generated at 2022-06-12 05:42:03.063515
# Unit test for function find
def test_find():
    assert find([], eq(0)) is None
    assert find(range(5), eq(2)) == 2
    assert find(range(5), eq(5)) is None



# Generated at 2022-06-12 05:42:04.812635
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2)([1, 2, 3]) == [3]



# Generated at 2022-06-12 05:42:08.625526
# Unit test for function curried_filter
def test_curried_filter():
    test_data = [1, 2, 3, 4, 5, 6]
    test_data_result = [1, 3, 5]
    curried_filter_fn = curried_filter(lambda x: x % 2 == 1)
    assert curried_filter_fn(test_data) == test_data_result



# Generated at 2022-06-12 05:42:16.889142
# Unit test for function curried_map
def test_curried_map():
    @curry
    def sort(key, coll):
        return sorted(coll, key=key)

    @curry
    def map(x, coll):
        return list(map(x, coll))

    def square(x):
        return x ** 2

    assert sort(lambda x: x['name'])([{'name': 'David', 'age': 20}, {'name': 'Alicia', 'age': 21}]) == \
        [{'name': 'Alicia', 'age': 21}, {'name': 'David', 'age': 20}]

# Generated at 2022-06-12 05:42:26.465317
# Unit test for function cond
def test_cond():
    assert cond([
        (eq(0), identity),
        (eq(1), increase),
        (eq(2), identity),
    ])(0) == 0
    assert cond([
        (eq(0), identity),
        (eq(1), increase),
        (eq(2), identity),
    ])(1) == 2
    assert cond([
        (eq(0), identity),
        (eq(1), increase),
        (eq(2), identity),
    ])(2) == 2
    assert cond([
        (eq(0), identity),
        (eq(1), increase),
        (eq(2), identity),
    ])(11) is None

# Generated at 2022-06-12 05:42:39.845234
# Unit test for function curried_map
def test_curried_map():
    curried_map_plus_one = curried_map(increase)

    assert curried_map_plus_one([3, 2, 1]) == [4, 3, 2]



# Generated at 2022-06-12 05:42:50.630401
# Unit test for function eq
def test_eq():
    assert(eq(5,5) == True)
    assert(eq(5,3) == False)
    assert(eq("a","a") == True)
    assert(eq("a","b") == False)
    assert(eq([1,2,3],[1,2,3]) == True)
    assert(eq([1,2,3],[1,2,4]) == False)
    curry_eq = curry(eq)
    assert(curry_eq(5)(5) == True)
    assert(curry_eq(5)(3) == False)
    assert(curry_eq("a")("a") == True)
    assert(curry_eq("a")("b") == False)
    assert(curry_eq([1,2,3])([1,2,3]) == True)

# Generated at 2022-06-12 05:42:53.626392
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 3, 4, 5, 6]
    assert curried_filter(lambda x: x % 2 == 0, collection) == [2, 4, 6]


# Generated at 2022-06-12 05:42:59.396894
# Unit test for function memoize
def test_memoize():
    def sum(x: int, y: int) -> int:
        return x + y

    memoized_fn = memoize(sum)
    first_call = memoized_fn(2, 3)
    second_call = memoized_fn(2, 3)
    assert first_call == second_call
    assert first_call == 5



# Generated at 2022-06-12 05:43:07.949195
# Unit test for function memoize
def test_memoize():
    def f1(value):
        return 2 + value

    def f2(value):
        return 3 + value

    def condition(value1, value2):
        return value1 == value2

    def condition2(value1, value2):
        return value1 == value2 + 1

    memoize_f1 = memoize(f1)
    memoize_f2 = memoize(f2, condition2)
    assert memoize_f1(2) == 4
    assert memoize_f1(2) == 4
    assert memoize_f2(2) == 5
    assert memoize_f2(3) == 6
    assert memoize_f2(2) == 5



# Generated at 2022-06-12 05:43:09.597080
# Unit test for function find
def test_find():
    """
    Unit test for function find.

    :returns: result of test
    :rtype: Boolean
    """
    return find([3, 6, 7, 8, 2], lambda x: x == 6) == 6



# Generated at 2022-06-12 05:43:14.353950
# Unit test for function cond
def test_cond():
    def true(value):
        return value > 0

    def false(value):
        return value == 0

    def true_function(value):
        return 'true'

    def false_function(value):
        return 'false'

    function_depending_on_condition = cond(
        [(true, true_function), (false, false_function)]
    )
    assert function_depending_on_condition(1) == 'true'
    assert function_depending_on_condition(0) == 'false'



# Generated at 2022-06-12 05:43:21.446065
# Unit test for function cond
def test_cond():
    print(cond([(eq(1), lambda x: x + 2), (eq(2), lambda x: x)])(2))
    print(cond([(eq(1), lambda x: x + 2), (eq(2), lambda x: x)])(1))
    print(cond([(lambda x: x % 3 == 0, lambda x: x), (lambda x: x % 3 == 1, lambda x: x + 2)])(1))



# Generated at 2022-06-12 05:43:23.708091
# Unit test for function eq
def test_eq():
    assert eq(1) == curried_filter(eq(1))
    assert eq(1)(1)
    assert not eq(1)(2)



# Generated at 2022-06-12 05:43:28.442423
# Unit test for function curried_map
def test_curried_map():
    curried_add = curry(lambda x, y: x + y)
    curried_increase = curried_add(1)
    assert curried_map(curried_increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-12 05:44:05.951716
# Unit test for function find
def test_find():
    assert find(['a', 'b', 'c'], lambda x: x == 'b') == 'b'
    assert find(['a', 'b', 'c'], lambda x: x == 'd') is None



# Generated at 2022-06-12 05:44:10.396294
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert eq(1.0, 1.0)
    assert eq('1', '1')
    assert eq('str', 'str')
    assert eq([1, 2], [1, 2])
    assert eq([1, 2], (1, 2))


test_eq()



# Generated at 2022-06-12 05:44:15.195933
# Unit test for function memoize
def test_memoize():
    def multiply(a, b):
        return a * b
    memoized_multiply = memoize(multiply, key=eq)
    assert memoized_multiply(2, 3) == 6
    assert memoized_multiply(2, 3) == 6
    assert memoized_multiply(2, 5) == 10



# Generated at 2022-06-12 05:44:18.456694
# Unit test for function find
def test_find():
    assert find(collection=[1, 2, 3], key=eq(2)) == 2
    assert find(collection=[1, 2, 3], key=eq(4)) is None



# Generated at 2022-06-12 05:44:29.272290
# Unit test for function memoize
def test_memoize():
    import random
    from functools import partial

    def slow_identity(*args):
        slow = random.randint(1, 3)
        import time
        time.sleep(slow)
        print("Slow::: ", slow)
        return args

    fast_identity = memoize(slow_identity)

    assert slow_identity("a", "b") == fast_identity("a", "b")
    assert slow_identity("a", "b") == fast_identity("a", "b")

    slow_identity("a", "b")
    fast_identity("a")
    slow_identity("a", "b")
    fast_identity("a", "b")
    fast_identity("a")
    slow_identity("a", "b")
    fast_identity("a")



# Generated at 2022-06-12 05:44:33.330188
# Unit test for function memoize
def test_memoize():
    original_function = lambda x: x + 1
    memoized_function = memoize(original_function)
    args = [1, 2]
    result_values = [2, 3]
    for i in range(2):
        assert memoized_function(args[i]) == result_values[i]



# Generated at 2022-06-12 05:44:38.123578
# Unit test for function find
def test_find():
    @curry
    def gt(value, value1: int) -> bool:
        return value > value1

    assert find([9, 8, 7], gt(3)) == 9
    assert find([9, 8, 7], eq(3)) is None
test_find()


# Generated at 2022-06-12 05:44:42.185462
# Unit test for function cond
def test_cond():
    cond_test = cond([
        (lambda x: x < 2, lambda x: x + 1),
        (lambda x: True, lambda x: x - 1),
    ])
    assert cond_test(1) == 2
    assert cond_test(3) == 2


if __name__ == '__main__':
    test_cond()

# Generated at 2022-06-12 05:44:44.616669
# Unit test for function eq
def test_eq():
    """
    Unit test for function eq
    """

    assert eq(5)(5)
    assert not eq(5)(6)


# Generated at 2022-06-12 05:44:47.980596
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 4) == 4
    assert find([1, 2, 3, 4], lambda x: x == -1) == None



# Generated at 2022-06-12 05:45:26.573755
# Unit test for function cond
def test_cond():
    is_even = cond([(lambda x: x % 2 == 0, lambda x: x), (lambda x: True, lambda x: x * 3)])
    assert is_even(3) == 9
    assert is_even(4) == 4

# Generated at 2022-06-12 05:45:31.280811
# Unit test for function memoize
def test_memoize():
    @memoize
    def add(a, b):
        return a + b

    assert (add(1, 2) == 3)
    assert (add(1, 2) == 3)
    assert (add(1, 2) == 3)
    assert (add(2, 2) == 4)
    assert (add(1, 2) == 3)



# Generated at 2022-06-12 05:45:34.646327
# Unit test for function curried_map
def test_curried_map():
    collection = [1,2,3,4]
    mapper = lambda x: x * 2

    assert curried_map(mapper)(collection) == [2, 4, 6, 8]

# Generated at 2022-06-12 05:45:40.378810
# Unit test for function curried_map
def test_curried_map():
    def double(x):
        return x * 2

    @curry
    def result(collection, mapper):
        return curried_map(mapper, collection)

    res = result(range(10), double)
    actual = [0, 2, 4, 6, 8, 10, 12, 14, 16, 18]
    assert actual == res



# Generated at 2022-06-12 05:45:46.508173
# Unit test for function find
def test_find():
    test_data = [
        [
            range(10),
            (lambda x: x == 2),
            2
        ],
        [
            [],
            (lambda x: x == 2),
            None
        ],
        [
            range(10),
            (lambda x: x == 10),
            None
        ]
    ]

    for (collection, key, expected) in test_data:
        assert find(collection, key) == expected



# Generated at 2022-06-12 05:45:49.647250
# Unit test for function find
def test_find():
    not_found = find([], identity)
    found = find([1, 2, 3], eq(1))
    assert not_found is None
    assert found == 1



# Generated at 2022-06-12 05:45:53.567765
# Unit test for function cond
def test_cond():
    @cond([
        (eq(True), lambda x: x + 2),
        (eq(False), lambda x: x + 3)
    ])
    def res(x):
        return x

    assert res(1) == 3
    assert res(2) == 4
    assert res(False) == 3
    assert res(True) == 4



# Generated at 2022-06-12 05:45:58.939954
# Unit test for function curried_map
def test_curried_map():
    map_function = curried_map(increase)
    assert map_function([1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]

    map_function_with_args = map_function([1, 2, 3, 4, 5])
    assert map_function_with_args == [2, 3, 4, 5, 6]



# Generated at 2022-06-12 05:46:03.713352
# Unit test for function find
def test_find():
    assert find([], lambda x: False) is None
    assert find([1, 2, 3], lambda x: x == 1) == 1
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 3) == 3
    assert find([1, 2, 3], lambda x: x == 4) is None

