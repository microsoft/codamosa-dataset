

# Generated at 2022-06-12 05:36:19.186384
# Unit test for function cond
def test_cond():
    condition_list: List[Tuple[Callable[[int, int], bool], Callable]] = [
        (lambda x, y: x > y, lambda x, y: x),
        (lambda x, y: x == y, lambda x, y: x),
        (lambda x, y: x < y, lambda x, y: y)
    ]
    test_cond_function = cond(condition_list)
    assert test_cond_function(1, 2) == 2
    assert test_cond_function(1, 1) == 1
    assert test_cond_function(2, 1) == 2



# Generated at 2022-06-12 05:36:21.425985
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-12 05:36:24.994584
# Unit test for function curried_map
def test_curried_map():
    fn_increase_by_one = curried_map(lambda x: x + 1)
    assert fn_increase_by_one([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-12 05:36:35.348470
# Unit test for function cond
def test_cond():
    from operator import add, mul
    from functools import partial

    def even(x: int) -> bool:
        return x % 2 == 0

    def square(x: int) -> int:
        return x * x

    def cube(x: int) -> int:
        return x ** 3

    operation = cond([(even, square), (identity, cube)])
    assert (operation(2) == square(2))
    assert (operation(3) == cube(3))

    add_or_mul = cond([(even, add), (identity, mul)])
    assert (add_or_mul(3, 4) == mul(3, 4))
    assert (add_or_mul(2, 2) == add(2, 2))

    operation_partial_no_args = partial(operation)

# Generated at 2022-06-12 05:36:39.473421
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [
                         0, 1, 2, 3, 4, 5, 6, 7, 8]) == [0, 2, 4, 6, 8]



# Generated at 2022-06-12 05:36:43.217186
# Unit test for function curried_filter
def test_curried_filter():
    users = [{'age': 10, 'name': 'a'}, {'age': 20, 'name': 'b'}, {'age': 10, 'name': 'c'}]
    filtered_users = curried_filter(lambda user: user['age'] == 20)(users)
    assert len(filtered_users) == 1
    assert filtered_users[0] == {'age': 20, 'name': 'b'}



# Generated at 2022-06-12 05:36:52.384982
# Unit test for function cond
def test_cond():
    """
    Test for function cond.
    """
    def is_even(x):
        return x % 2 == 0

    def is_odd(x):
        return not is_even(x)

    def double(x):
        return x * 2

    def triple(x):
        return x * 3

    assert cond([
        (is_even, double),
        (is_odd, triple),
    ])(6) == 12
    assert cond([
        (is_even, double),
        (is_odd, triple),
    ])(5) == 15
    assert cond([
        (is_even, double),
        (is_odd, triple),
    ])(7) == 21



# Generated at 2022-06-12 05:36:55.727839
# Unit test for function curry
def test_curry():
    curried_map_len = curry(lambda a, b: map(a, b))
    assert curried_map_len([1, 2, 3], len)("123") == [1, 2, 3]

# Generated at 2022-06-12 05:36:58.026743
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(str)([1, 2, 3]) == ['1', '2', '3']



# Generated at 2022-06-12 05:37:05.561569
# Unit test for function memoize
def test_memoize():
    import time
    import random

    import pytest

    # test if function is really cached
    def simple_callable(value):
        return value

    memoized = memoize(simple_callable, key=identity)
    random_values = [random.random() for _ in range(100)]
    start_time = time.time()
    [memoized(value) for value in random_values]
    first_execution_time = time.time() - start_time
    start_time = time.time()
    [memoized(value) for value in random_values]
    second_execution_time = time.time() - start_time

    assert first_execution_time > second_execution_time

    # test if memoize really works

# Generated at 2022-06-12 05:37:15.805887
# Unit test for function cond
def test_cond():
    def is_list(list_):
        return type(list_) == list

    def is_int(int_):
        return type(int_) == int

    @cond([
        (is_list, identity),
        (is_int, increase),
    ])
    def f(arg):
        return arg

    assert f([1, 2, 3]) == [1, 2, 3], f([1, 2, 3])
    assert f(1) == 2, f(1)



# Generated at 2022-06-12 05:37:27.385708
# Unit test for function cond
def test_cond():
    def divide(x, y):
        return x / y

    def add(x, y):
        return x + y

    def multiply(x, y):
        return x * y

    def function_to_test(x, y):
        return cond([
            (lambda x, y: y == 0, lambda x, y: float('inf')),
            (lambda x, y: y < 0, lambda x, y: float('-inf')),
            (lambda x, y: y > 1, lambda x, y: add(x, y)),
            (lambda x, y: y == 1, lambda x, y: multiply(x, y)),
            (lambda x, y: y == 0, lambda x, y: divide(x, y)),
        ])(x, y)

    assert function_to_test(1, 2) == 3

# Generated at 2022-06-12 05:37:34.580105
# Unit test for function memoize
def test_memoize():
    import random

    def slow_fn(argument):
        x = 0
        for index in range(1, random.randint(100, 100000)):
            x += index
        return x

    slow_fn = memoize(slow_fn)

    assert slow_fn(1) == slow_fn(1)
    assert slow_fn(2) == slow_fn(2)
    assert slow_fn(1) != slow_fn(2)



# Generated at 2022-06-12 05:37:44.667665
# Unit test for function cond
def test_cond():
    def greater_than_5(x): return x > 5
    def between_1_and_5(x): return 1 < x < 5
    def lower_than_1(x): return x < 1

    def is_number_equal_to_10(x): return x == 10
    def is_number_equal_to_5(x): return x == 5
    def is_number_equal_to_0(x): return x == 0

    choose_number_to_add = cond([
        (greater_than_5, lambda x: x + 1),
        (between_1_and_5, lambda x: x + x),
        (lower_than_1, lambda x: x)
    ])
    assert choose_number_to_add(11) == 12
    assert choose_number_to_add(2) == 4

# Generated at 2022-06-12 05:37:47.175393
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)


# Generated at 2022-06-12 05:37:52.456972
# Unit test for function cond
def test_cond():
    @cond([
        (eq(1), identity),
        (eq(2), increase),
        (eq(3), increase),
    ])
    def test(number):
        return number

    assert test(1) == 1
    assert test(2) == 3
    assert test(3) == 4
    assert test(4) is None



# Generated at 2022-06-12 05:37:54.181888
# Unit test for function eq
def test_eq():
    assert eq(2, 2)
    assert not eq(2, 3)



# Generated at 2022-06-12 05:37:58.107241
# Unit test for function curried_filter
def test_curried_filter():
    """
    Test that curried_filter return list with filtered values.
    """

# Generated at 2022-06-12 05:38:04.281043
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda item: item > 2, [1, 2, 3, 4]) == [3, 4]
    assert curried_filter(lambda item: item < 5)([1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4]
    assert curried_filter(eq(2))([1, 2, 3, 4]) == [2]



# Generated at 2022-06-12 05:38:06.769018
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x == 2)([1, 2, 3]) == [2]



# Generated at 2022-06-12 05:38:12.308260
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-12 05:38:14.093180
# Unit test for function curried_map
def test_curried_map():
    def plus_one(x):
        return x + 1

    assert curried_map(plus_one, [1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-12 05:38:24.696912
# Unit test for function cond
def test_cond():
    """
    In functional programming, cond is a special form of conditional expression.
    """

    def is_even(value) -> bool:
        """
        Check if value is even.

        :param value: argument to check
        :type value: Int
        :returns: true if value is even, else false
        :rtype: Boolean
        """
        return value % 2 == 0

    def increment_value(value: int) -> int:
        """
        Return increased by 1 argument.

        :param value:
        :type value: Int
        :returns:
        :rtype: Int
        """
        return value + 1


# Generated at 2022-06-12 05:38:26.761710
# Unit test for function eq
def test_eq():
    assert eq(3, 3) is True
    assert eq("test", "test") is True



# Generated at 2022-06-12 05:38:31.032719
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2])(None) == [2, 3]
    assert curried_map(increase, [1, 2, 3])(None) == [2, 3, 4]
    assert curried_map(increase, [1])(None) == [2]



# Generated at 2022-06-12 05:38:38.538321
# Unit test for function curry
def test_curry():
    @curry
    def test_add(value1, value2, value3):
        return value1 + value2 + value3

    assert test_add(1,2,3) == 6

    test_add1 = test_add(1)
    test_add2 = test_add1(2)
    test_add3 = test_add2(3)
    assert test_add3 == 6

    assert test_add(1)(2)(3) == 6



# Generated at 2022-06-12 05:38:44.892259
# Unit test for function curried_filter
def test_curried_filter():
    int_list = [1, 2, 3, 4, 5]
    filtered_list = curried_filter(lambda x: x % 2 == 0, int_list)
    curried_filter_list = curried_filter(lambda x: x % 2 == 0)(int_list)
    assert(filtered_list == [2, 4])
    assert(curried_filter_list == [2, 4])



# Generated at 2022-06-12 05:38:51.080175
# Unit test for function curry
def test_curry():
    def f(x, y, z):
        return x + y + z

    assert f(1, 2, 3) == 6
    assert curry(f)(1)(2)(3) == 6

    def f(x):
        return x * x

    assert f(x=2) == 4

    f1 = curry(f)
    assert f1(2) == 4

    f2 = f1(x=2)
    assert f2 == 4
# test_curry()



# Generated at 2022-06-12 05:38:58.989645
# Unit test for function cond
def test_cond():
    add = lambda x, y: x + y
    sub = lambda x, y: x - y

    condition1 = lambda x, y: x > y
    condition2 = lambda x, y: x < y
    condition3 = lambda x, y: x == y

    evaluator = cond([
        (condition1, add),
        (condition2, sub),
        (condition3, identity),
    ])

    assert evaluator(2, 3) == -1
    assert evaluator(3, 2) == 5
    assert evaluator(2, 2) == 2
    # Assert Error
    # evaluator(2, 1, 3)

# Generated at 2022-06-12 05:39:04.396957
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2, [1, 2, 3, 4, 5]) == [1, 3, 5]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5]) == [2, 4]


# Generated at 2022-06-12 05:39:09.972017
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 7)([1, 2, 5, 7, 8, 9]) == [8, 9]
    assert curried_filter(lambda x: x > 7, [1, 2, 5, 7, 8, 9]) == [8, 9]



# Generated at 2022-06-12 05:39:16.733029
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 3) == 3
    assert find([1, 2, 3], lambda x: x == 4) is None
    assert find([1, 2, 3], lambda x: x > 2) == 3
    assert find([1, 2, 3], lambda x: x > 3) is None
    assert find([], lambda x: x == 1) is None



# Generated at 2022-06-12 05:39:23.841838
# Unit test for function memoize
def test_memoize():
    @memoize
    def fibonacci(n):
        if n < 2:
            return 1
        return fibonacci(n - 1) + fibonacci(n - 2)

    assert fibonacci(1000) == 43466557686937456435688527675040625802564660517371780402481729089536555417949051890403879840079255169295922593080322634775209689623239873322471161642996440906533187938298969649928516003704476137795166849228875


test_memoize()

# Generated at 2022-06-12 05:39:26.962940
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x % 2 == 0) == 2
    assert find([1, 2, 3, 4], lambda x: x > 4) is None



# Generated at 2022-06-12 05:39:30.132206
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda x: x == 6) is None



# Generated at 2022-06-12 05:39:38.301368
# Unit test for function cond
def test_cond():
    """
    This funciton test function cond.
    """
    test_list = [
        (3, "3"),
        (1, "1"),
        (2, "2")
    ]

    def first_condition(x):
        return x == test_list[0][0]

    first_function = lambda x: test_list[0][1]

    def second_condition(x):
        return x == test_list[1][0]

    second_function = lambda x: test_list[1][1]

    def third_condition(x):
        return x == test_list[2][0]

    third_function = lambda x: test_list[2][1]


# Generated at 2022-06-12 05:39:43.036162
# Unit test for function cond
def test_cond():
    eq2 = curry(eq, 2)
    assert cond(
        [
            (eq2, identity),
            (eq2, identity),
        ]
    )(1) is None
    assert cond(
        [
            (eq2, identity),
            (eq2, identity),
        ]
    )(2) == 2



# Generated at 2022-06-12 05:39:51.306164
# Unit test for function cond
def test_cond():
    # this test failed, in line with the specification should be return 5, not 4
    assert cond(
        [(lambda x: x == 4, lambda x: x + 1),
         (lambda x: x < 5, lambda x: 'x < 5'),
         (lambda x: x > 6, lambda x: 'x > 6')]
    )(4) == 5

    assert cond(
        [
            (lambda x: x == 4, lambda x: x + 1),
            (lambda x: x < 5, lambda x: 'x < 5'),
            (lambda x: x > 6, lambda x: 'x > 6')
        ]
    )(3) == 'x < 5'



# Generated at 2022-06-12 05:39:55.977570
# Unit test for function curried_map
def test_curried_map():
    f = curried_map(lambda x: x + 1)
    assert f([1, 2, 3]) == [2, 3, 4]

    f = curried_map(lambda x: x + 1, [1, 2, 3])
    assert f() == [2, 3, 4]



# Generated at 2022-06-12 05:39:58.490254
# Unit test for function eq
def test_eq():
    assert eq(None, None) is True
    assert eq(1, 2) is False
    assert eq(1, 1) is True



# Generated at 2022-06-12 05:40:03.583359
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4]) == [2, 4]


# Generated at 2022-06-12 05:40:09.266553
# Unit test for function eq
def test_eq():
    # For eq function used currying

    # If eq function get two true arguments
    assert eq('a')('a')
    assert eq(1)(1)

    # If eq function get two false arguments
    assert eq('a')('b') is False
    assert eq(1)(2) is False

    # If eq function get argument with different types
    assert eq(1)('1') is False



# Generated at 2022-06-12 05:40:12.180729
# Unit test for function eq
def test_eq():
    assert True  == eq(0, 0)
    assert False == eq(1, 0)
    assert True  == eq(1, 1)



# Generated at 2022-06-12 05:40:21.809444
# Unit test for function eq
def test_eq():
    print('unit test for function eq')
    assert True == eq(True, True), 'eq for True and True should return True'
    assert False == eq(True, False), 'eq for True and False should return False'
    assert False == eq(False, True), 'eq for False and True should return False'
    assert True == eq(False, False), 'eq for False and False should return True'
    assert True == eq(1, 1), 'eq for 1 and 1 should return True'
    assert False == eq(1, 2), 'eq for 1 and 2 should return False'
    assert False == eq(2, 1), 'eq for 2 and 1 should return False'
    assert True == eq(2, 2), 'eq for 2 and 2 should return True'
    print('... Success!')



# Generated at 2022-06-12 05:40:26.773182
# Unit test for function curried_filter
def test_curried_filter():
    def greater_than10(value):
        return value > 10

    assert curried_filter(greater_than10, [1, 2, 3, 4, 5, 6, 7, 8]) == []
    assert curried_filter(greater_than10, [1, 2, 3, 4, 5, 6, 7, 8, 100, 1321]) == [100, 1321]
    assert curried_filter(greater_than10, []) == []



# Generated at 2022-06-12 05:40:38.599572
# Unit test for function cond
def test_cond():
    def is_string(value: Any) -> bool:
        return isinstance(value, str)

    def is_number(value: Any) -> bool:
        return isinstance(value, int)

    def is_list(value: Any) -> bool:
        return isinstance(value, list)

    def increase(value: int) -> int:
        return value + 1

    def to_upper(value: str) -> str:
        return value.upper()

    def length(value: list) -> int:
        return len(value)

    assert cond([
        (is_string, to_upper),
        (is_number, increase),
        (is_list, length)
    ])("test_string") == "TEST_STRING"

# Generated at 2022-06-12 05:40:42.599175
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4]) == [2, 4]
    assert curried_filter(lambda x: x % 2, [1, 2, 3, 4]) == [1, 3]


# Generated at 2022-06-12 05:40:47.762604
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    increase_curried_map = curried_map(increase)
    assert increase_curried_map([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase_curried_map)([1, 2, 3]) == [[2, 3, 4], [2, 3, 4], [2, 3, 4]]



# Generated at 2022-06-12 05:40:54.792185
# Unit test for function cond
def test_cond():
    # Setup
    a = [1, 2, 3]
    b = [3, 4, 5]
    c = [{1, 2}, {3, 4}]
    d = [{2, 3}, {4, 5}]
    e = [4, 5]
    f = [5, 6]
    g = [7, 8]

    # Expected result
    expected_result = [
        {1, 2},
        {2, 3},
        {4, 5},
        {5, 6},
        None
    ]

    # Test

# Generated at 2022-06-12 05:40:57.791249
# Unit test for function curried_filter
def test_curried_filter():
    print(curried_filter(lambda x: x > 2)(range(10)))

if __name__ == '__main__':
    test_curried_filter()

# Generated at 2022-06-12 05:41:05.913498
# Unit test for function memoize
def test_memoize():
    def add(a):
        """Example function for test."""
        return a + 1

    add_memoized = memoize(add)
    assert add(3) != add_memoized(3)  # Should return different result
    assert add_memoized(3) == add_memoized(3)  # Should return same result



# Generated at 2022-06-12 05:41:10.136540
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(1), [1, 2, 3, 1]) == [1, 1]
    assert curried_filter(eq(1), [2, 3]) == []



# Generated at 2022-06-12 05:41:11.526724
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq('a', 'a') == True



# Generated at 2022-06-12 05:41:14.193292
# Unit test for function curried_map
def test_curried_map():
    assert(curried_map(increase)([1, 2, 3]) == [2, 3, 4])



# Generated at 2022-06-12 05:41:17.801789
# Unit test for function eq
def test_eq():
    assert eq("a", "a") is True
    assert eq("a", "b") is False
    assert eq("a", "a", "a") is False
    assert eq("a")("a") is True
    assert eq("a")("b") is False
    assert eq("a")("a", "a") is False



# Generated at 2022-06-12 05:41:26.553740
# Unit test for function cond
def test_cond():
    def is_zero(x):
        return x == 0

    def is_positive(x):
        return x > 0

    def is_negative(x):
        return x < 0

    def get_value(x):
        return x

    def negative_value(x):
        return -x

    assert cond([
        (is_zero, get_value),
        (is_positive, get_value),
        (is_negative, negative_value),
    ])(0) == 0
    assert cond([
        (is_zero, get_value),
        (is_positive, get_value),
        (is_negative, negative_value),
    ])(1) == 1

# Generated at 2022-06-12 05:41:33.770467
# Unit test for function curry
def test_curry():
    def sum_of_three(x, y, z):
        return x + y + z

    curried_sum_of_three = curry(sum_of_three)
    assert curried_sum_of_three(1)(2)(3) == 6
    assert curried_sum_of_three(1, 2)(3) == 6
    assert curried_sum_of_three(1)(2, 3) == 6
    assert curried_sum_of_three(1, 2, 3) == 6



# Generated at 2022-06-12 05:41:35.837526
# Unit test for function memoize
def test_memoize():
    import time
    slow_fn = lambda x: time.sleep(1)
    faster_fn = memoize(slow_fn)
    assert faster_fn(1) == None

# Generated at 2022-06-12 05:41:42.640666
# Unit test for function curried_map
def test_curried_map():
    assert [2, 4, 6] == curried_map(increase, [1, 2, 3])
    assert [2, 4, 6] == curried_map(increase)([1, 2, 3])
    assert [2, 4, 6] == curried_map(increase, [1, 2, 3])
    assert [2, 4, 6] == curried_map(increase)([1, 2, 3])



# Generated at 2022-06-12 05:41:44.560980
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x+1, [1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-12 05:41:52.104269
# Unit test for function curried_map
def test_curried_map():
    collection = [1, 2, 3, 4, 5]
    mapper = lambda item: item + 1
    assert curried_map(mapper)(collection) == [2, 3, 4, 5, 6]
    assert curried_map(mapper)([2, 3, 4]) == [3,4,5]
    assert curried_map(mapper)([]) == []



# Generated at 2022-06-12 05:41:56.222579
# Unit test for function curried_map
def test_curried_map():
    collection = [1, 2, 3]
    curried_incr = curried_map(increase)
    result = curried_incr(collection)
    assert result == [2, 3, 4]


# Generated at 2022-06-12 05:41:58.895265
# Unit test for function curried_filter
def test_curried_filter():
    collection, filterer = [1, 2, 3, 4, 5], lambda x: x % 2 == 0
    assert curried_filter(filterer)(collection) == [2, 4]



# Generated at 2022-06-12 05:42:04.914549
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 0, [1, 2, 3]) == [1, 2, 3]
    assert curried_filter(lambda x: x > 0)([1, 2, 3]) == [1, 2, 3]
    assert curried_filter(lambda x: x < 0, [1, 2, 3]) == []
    assert curried_filter(lambda x: x < 0)([1, 2, 3]) == []

test_curried_filter()


# Generated at 2022-06-12 05:42:06.549777
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-12 05:42:14.939595
# Unit test for function memoize
def test_memoize():
    a = 0

    def test_fn(argument):
        nonlocal a
        a = a + 1
        return argument ** 2

    memoized_fn = memoize(test_fn)

    assert memoized_fn(2) == 4
    assert memoized_fn(2) == 4
    assert a == 1

    a = 0
    memoized_fn = memoize(test_fn, curry(lambda a, b: a > b))

    assert memoized_fn(2) == 4
    assert a == 1
    assert memoized_fn(3) == 9
    assert a == 2
    assert memoized_fn(2) == 9
    assert a == 2

    a = 0
    memoized_fn = memoize(test_fn, curry(lambda a, b: a < b))

    assert memoized_fn(2)

# Generated at 2022-06-12 05:42:16.607707
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [1, 2]) == curried_map(identity)([1, 2]) == [1, 2]



# Generated at 2022-06-12 05:42:19.730832
# Unit test for function memoize
def test_memoize():
    """
    Test function memoize
    """
    function = lambda argument: argument
    memoized_function = memoize(function, lambda a, b: a == b)

    for i in range(0, 100):
        assert(memoized_function(1) == 1)



# Generated at 2022-06-12 05:42:24.423843
# Unit test for function curried_map
def test_curried_map():
    print('Testing curried map for default parameters')
    collection = [1, 2, 3]
    assert curried_map(increase)(collection) == [2, 3, 4]
    print('Testing curried map for set parameters')
    collection = [1, 2, 3]
    assert curried_map(lambda x: x*2, collection) == [2, 4, 6]



# Generated at 2022-06-12 05:42:26.821407
# Unit test for function eq
def test_eq():
    assert eq(1)(1) is True
    assert eq(1)(0) is False



# Generated at 2022-06-12 05:42:34.880319
# Unit test for function curried_map
def test_curried_map():
    assert [0, 2, 4] == curried_map(lambda x: x * 2)([0, 1, 2])
    assert [0, 2, 4] == curried_map(lambda x: x * 2, [0, 1, 2])

# Generated at 2022-06-12 05:42:38.145134
# Unit test for function find
def test_find():
    assert find([], eq(0)) is None
    assert find(range(0, 10), eq(1)) is 1
    assert find(range(0, 10), eq(10)) is None
    assert find(range(0, 10), eq(20)) is None

# Generated at 2022-06-12 05:42:39.892386
# Unit test for function eq
def test_eq():
    assert eq(1)(1)



# Generated at 2022-06-12 05:42:50.629719
# Unit test for function cond
def test_cond():
    # This kind of passing multiple arguments causes a problem in the Python 3 version.
    def add(*args):
        return args[0] + args[1]

    def subtract(*args):
        return args[0] - args[1]

    def multiply(*args):
        return args[0] * args[1]

    def divide(*args):
        return args[0] / args[1]

    def greater_than(*args):
        return args[0] > args[1]

    def lesser_than(*args):
        return args[0] < args[1]

    def equals(*args):
        return args[0] == args[1]


# Generated at 2022-06-12 05:42:52.934611
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-12 05:42:56.450916
# Unit test for function cond
def test_cond():
    def fn(*args):
        return args

    def predicate(*args):
        return len(args) == 1

    cond_fn = cond([
        (predicate, fn),
        (predicate, fn)
    ])
    assert cond_fn(1) == (1, )
    assert cond_fn(1, 2) == (1, 2)

# Generated at 2022-06-12 05:43:03.060446
# Unit test for function curry
def test_curry():
    def add_numbers(a, b):
        return a + b

    assert curry(add_numbers, 2)(1, 2) == add_numbers(1, 2)
    assert curry(add_numbers, 2)(1)(2) == add_numbers(1, 2)
    assert curry(add_numbers, 1)(1) == add_numbers(1)



# Generated at 2022-06-12 05:43:05.703754
# Unit test for function curried_filter
def test_curried_filter():
    filter_by_two = curried_filter(lambda x: x % 2 == 0)
    assert(filter_by_two(range(1, 10)) == [2, 4, 6, 8])


# Generated at 2022-06-12 05:43:11.376347
# Unit test for function curried_map
def test_curried_map():
    result = curried_map(lambda n: n * n)([1, 2, 3])
    assert result == [1, 4, 9]

    incrementer = curried_map(lambda n: n + 1)
    result = incrementer([1, 2, 3])
    assert result == [2, 3, 4]

    result = incrementer([4, 5, 6])
    assert result == [5, 6, 7]


# Generated at 2022-06-12 05:43:16.805142
# Unit test for function memoize
def test_memoize():
    counter = {'value': 0}
    def fn(arg: int, counter: dict) -> int:
        counter['value'] += arg + 1
        return arg

    memoized_fn = memoize(lambda arg: fn(arg, counter), key=lambda arg1, arg2: arg1 == arg2)

    assert memoized_fn(1) == 1, "first call"
    assert counter['value'] == 2, "first call"

    assert memoized_fn(1) == 1, "second call to the same argument"
    assert counter['value'] == 2, "second call to the same argument"

    assert memoized_fn(2) == 2, "third call to another argument"
    assert counter['value'] == 5, "third call to another argument"


# Generated at 2022-06-12 05:43:24.780953
# Unit test for function cond
def test_cond():
    assert cond([
        (eq('FOO'), identity),
        (eq('BAR'), identity),
    ])('FOO') == 'FOO'
    assert cond([
        (eq('FOO'), identity),
        (eq('BAR'), identity),
    ])('BAR') == 'BAR'



# Generated at 2022-06-12 05:43:32.946997
# Unit test for function cond
def test_cond():
    test_list = [
        ('test', lambda x: x == 'test'),
        ('test1', lambda y: y == 'test1'),
        ('test2', lambda z: z == 'test2'),
    ]

    test_fn = cond(test_list)

    assert test_fn('test') == 'test'
    assert test_fn('test1') == 'test1'
    assert test_fn('test2') == 'test2'
    assert test_fn('test3') is None
    print('test_cond success!')

# Generated at 2022-06-12 05:43:41.741323
# Unit test for function curry
def test_curry():
    """Curry function test."""
    def abc(a, b, c):
        return a + b + c

    assert curry(abc)(1)(2)(3) == 6
    assert curry(abc)(1)(2, 3) == 6
    assert curry(abc)(1, 2)(3) == 6
    assert curry(abc)(1, 2, 3) == 6
    assert curry(abc)(1, b=2)(3) == 6
    assert curry(abc)(1)(b=2, c=3) == 6
    assert curry(abc)(1, b=2, c=3) == 6



# Generated at 2022-06-12 05:43:43.219490
# Unit test for function find
def test_find():
    test_list = [1, 2, 3, 4, 5]
    assert find(test_list, lambda x: x > 3) == 4



# Generated at 2022-06-12 05:43:51.538698
# Unit test for function curried_filter
def test_curried_filter():
    # Test curried_filter with curried_map
    assert curried_map(increase, curried_filter(eq(1), [0, 1, 2, 3])) == [2, 3]
    # Test curried_filter with curried_map and identity
    assert curried_map(identity, curried_filter(eq(1), [0, 1, 2, 3])) == [1]
    # Test curried_filter with curried_map and custom function
    assert curried_map(lambda x: x * 10, curried_filter(eq(1), [0, 1, 2, 3])) == [10]



# Generated at 2022-06-12 05:43:55.638986
# Unit test for function curried_filter
def test_curried_filter():
    pred = lambda x: x % 2 == 0

    curried_fp = curried_filter(pred)

    assert isinstance(curried_fp, Callable)
    assert curried_filter(pred, [1, 2, 3, 4, 5, 6])([]) == [2, 4, 6]



# Generated at 2022-06-12 05:44:04.753532
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False
    assert eq(1, 1, 1) is True
    assert eq(1, 1, 2) is False
    assert eq(1, 1, 1, 1) is True
    assert eq(1, 1, 1, 2) is False
    assert eq(1)(1) is True
    assert eq(1)(2) is False
    assert eq(1)(1, 1) is True
    assert eq(1)(1, 2) is False
    assert eq(1)(1, 1, 1) is True
    assert eq(1)(1, 1, 2) is False



# Generated at 2022-06-12 05:44:06.888189
# Unit test for function curry
def test_curry():
    def test1(a, b, c):
        return a + b + c

    assert curry(test1, 2)(1, 2) == 5



# Generated at 2022-06-12 05:44:12.111384
# Unit test for function curried_filter
def test_curried_filter():
    # Create a test value to use
    my_name = "Yogesh"

    assert curried_filter(eq(my_name), ['a', 'b', 'c']) == []
    assert curried_filter(eq(my_name), ['a', 'b', 'c', my_name]) == [my_name]


# Generated at 2022-06-12 05:44:13.788761
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2]) == [2, 3]



# Generated at 2022-06-12 05:44:27.176177
# Unit test for function memoize
def test_memoize():
    counter = 0

    @memoize
    def test(arg):
        nonlocal counter
        counter += 1
        return counter

    assert test(1) == 1
    assert test(1) == 1
    assert test(2) == 2

# Generated at 2022-06-12 05:44:35.837544
# Unit test for function memoize
def test_memoize():
    import operator
    from datetime import datetime
    from time import sleep

    @memoize
    def test_fn(x):
        sleep(1)
        return x + 1

    def test_fn2(x):
        return x + 1

    start_time = datetime.now()
    print(test_fn(1))
    end_time = datetime.now()
    print(test_fn(1))
    end_time1 = datetime.now()
    assert end_time - start_time > end_time1 - end_time
    start_time = datetime.now()
    print(test_fn2(1))
    end_time = datetime.now()
    print(test_fn2(1))
    end_time1 = datetime.now()
    assert end_time - start_time

# Generated at 2022-06-12 05:44:39.381342
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6])([]) == [2, 4, 6]


# Generated at 2022-06-12 05:44:43.553834
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda number: number == 1) == 1
    assert find([1, 2, 3], lambda number: number == 2) == 2
    assert find([1, 2, 3], lambda number: number == 3) == 3
    assert find([1, 2, 3], lambda number: number == 4) is None



# Generated at 2022-06-12 05:44:47.001314
# Unit test for function curried_map
def test_curried_map():
    # assert curried_map((lambda x: x + 1), [1, 2, 3]) == [2, 3, 4]
    assert curried_map((lambda x: x + 1), [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-12 05:44:53.977141
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    curried_eq = curry(eq)
    assert curried_eq(1, 1)
    assert not curried_eq(1, 2)
    assert curried_eq(1)(1)
    assert not curried_eq(1)(2)
    assert curried_eq(1, 1)()
    assert not curried_eq(1, 2)()



# Generated at 2022-06-12 05:44:56.695918
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3)(4) == 6



# Generated at 2022-06-12 05:45:00.783167
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, '1') == False
    assert eq(1, 2) == False


# Generated at 2022-06-12 05:45:07.199430
# Unit test for function memoize
def test_memoize():
    cache = []
    test_function = lambda x: x
    memoized_test_function = memoize(test_function, lambda a, b: a == b)

    # first argument should be cached
    assert memoized_test_function(1) == 1
    assert cache == [(1, 1)]

    # first argument should be returned from cache
    assert memoized_test_function(1) == 1
    assert cache == [(1, 1)]

    # second argument should be cached
    assert memoized_test_function(2) == 2
    assert cache == [(1, 1), (2, 2)]

test_memoize()

# Generated at 2022-06-12 05:45:14.412243
# Unit test for function curried_filter
def test_curried_filter():
    # Setup
    test_set: List[Tuple[List[int], int, List[int]]] = [
        ([1, 2, 3, 4, 5, 6], 3, [3, 4, 5, 6]),
        ([1, 2, 3, 4, 5, 6], 0, [0, 1, 2, 3, 4, 5, 6]),
        ([1, 2, 3, 4, 5, 6], 15, []),
        ([1, 1, 1, 1, 1, 1], 1, [1, 1, 1, 1, 1, 1]),
    ]
    for test_item, gt_value, expected_result in test_set:
        # Exercise
        actual_result = curried_filter(lambda x: x >= gt_value, test_item)

        # Verify
        assert actual_result == expected_

# Generated at 2022-06-12 05:45:39.238094
# Unit test for function curried_filter
def test_curried_filter():
    list = [1, 2, 3, 4]
    function = curried_filter(lambda x: x % 2 == 0)
    assert function(list) == [2, 4]


# Generated at 2022-06-12 05:45:45.089637
# Unit test for function cond
def test_cond():
    def condition(value):
        return value == "test"

    def execute():
        return "passed"

    def condition_fail(value):
        return value == "fail"

    def execute_fail():
        return "failed"

    function = cond([
        (condition, execute),
        (condition_fail, execute_fail)
    ])

    assert function() == "passed"


# Generated at 2022-06-12 05:45:46.701760
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter((lambda x: x % 2 == 0))([1, 2, 3, 4, 5]) == [2, 4]



# Generated at 2022-06-12 05:45:51.972495
# Unit test for function find
def test_find():
    assert find([
            {
                'id': 1,
                'name': 'alice'
            },
            {
                'id': 2,
                'name': 'bob'
            },
        ], lambda user: user['id'] == 1) == {'id': 1, 'name': 'alice'}
    assert find(None, None) is None



# Generated at 2022-06-12 05:45:57.719186
# Unit test for function curried_filter
def test_curried_filter():
    curried_filter_greater_than_5 = curried_filter(lambda x: x > 5)
    assert curried_filter_greater_than_5([1, 2, 3, 4, 5, 6]) == [6]
    assert curried_filter_greater_than_5([1, 2, 3, 4, 5]) == []



# Generated at 2022-06-12 05:46:06.595853
# Unit test for function cond
def test_cond():
    is_even = lambda x: x % 2 == 0
    is_odd = lambda x: x % 2 != 0
    is_not_number = lambda x: not isinstance(x, int)

    increment = lambda x: x + 1
    decrement = lambda x: x - 1
    return_first_argument = lambda x: x

    decrement_if_even = cond([
        (is_even, decrement),
        (is_not_number, return_first_argument),
    ])

    increment_if_even = cond([
        (is_even, increment),
        (is_not_number, return_first_argument),
    ])

    increment_if_odd = cond([
        (is_odd, increment),
        (is_not_number, return_first_argument),
    ])

    decrement_if_