

# Generated at 2022-06-12 05:36:17.303726
# Unit test for function cond
def test_cond():

    def is_even(i):
        return i % 2 == 0

    def is_odd(i):
        return not is_even(i)

    cond_function = cond([
        (is_even, increase),
        (is_odd, identity),
    ])

    assert cond_function(1) == 1
    assert cond_function(2) == 3
    assert cond_function(3) == 3
    assert cond_function(4) == 5



# Generated at 2022-06-12 05:36:24.157761
# Unit test for function curried_map
def test_curried_map():
    assert [0, 2, 4] == curried_map(increase)([-1, 1, 3])
    assert [0, 2, 4] == curried_map(increase)([-1, 1, 3])
    assert [0, -2, -4] == curried_map(lambda x: -x)([0, 2, 4])


# Generated at 2022-06-12 05:36:34.744457
# Unit test for function eq
def test_eq():
    # Test variables
    test_value = 5
    test_value1 = 5
    test_value2 = 6
    test_value3 = 5.0
    test_value4 = "5"
    test_value5 = True
    test_value6 = None
    # Test functions
    assert (
        eq(test_value, test_value1) == True and
        eq(test_value, test_value2) == False and
        eq(test_value, test_value3) == True and
        eq(test_value, test_value4) == False and
        eq(test_value, test_value5) == False and
        eq(test_value, test_value6) == False
    )



# Generated at 2022-06-12 05:36:37.540089
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-12 05:36:40.888403
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x <= 2) == 2



# Generated at 2022-06-12 05:36:42.977407
# Unit test for function eq
def test_eq():
    assert(eq(1, 1) == True)
    assert(eq(1, 2) == False)

# Generated at 2022-06-12 05:36:48.804740
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4]) == [2, 4]
    assert curried_filter(eq(2), [1, 2, 3, 4]) == [2]

# Generated at 2022-06-12 05:36:52.975393
# Unit test for function curry
def test_curry():
    fn = lambda a, b: a + b
    curried_fn = curry(fn)
    curried_fn1 = curried_fn(2)

    assert curried_fn1(3) == 5

# Generated at 2022-06-12 05:36:56.346247
# Unit test for function curried_map
def test_curried_map():
    array = [1, 2, 3]
    new_array = curried_map(lambda x: x + 2)(array)
    print("new_array: " + str(new_array))


# Generated at 2022-06-12 05:37:01.371971
# Unit test for function memoize
def test_memoize():
    numbers = []

    def get_number():
        numbers.append(1)
        return len(numbers)

    assert get_number() == 1
    assert get_number() == 2
    assert get_number() == 3

    assert get_number() == 1
    assert get_number() == 2
    assert get_number() == 3



# Generated at 2022-06-12 05:37:08.402491
# Unit test for function eq
def test_eq():
    assert eq(2, 2) is True
    assert eq(2, 2) is True
    assert eq(2, 2 + 1) is False
    assert eq(2, 2 + 1) is False



# Generated at 2022-06-12 05:37:15.627263
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)(range(0, 10)) == list(range(1, 11))
    assert curried_map(increase, range(0, 10)) == list(range(1, 11))
    assert curried_map(lambda i: i*2, [1,2]) == [2,4]
    assert curried_map(lambda i: i*2)([1,2]) == [2,4]


# Generated at 2022-06-12 05:37:18.660422
# Unit test for function curry
def test_curry():
    eq2 = curry(eq)
    eq1 = eq2(1)

    assert eq1(1) is True
    assert eq1(2) is False



# Generated at 2022-06-12 05:37:21.219290
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-12 05:37:26.585533
# Unit test for function find
def test_find():
    """
    Function test_find test function find.
    """
    assert find([1, 2, 3], eq(2)) == 2
    assert find([1, 2, 3], eq(3)) == 3
    assert find([1, 2, 3], eq(4)) is None



# Generated at 2022-06-12 05:37:28.523291
# Unit test for function eq
def test_eq():
    assert eq(1, 2) == False
    assert eq(1, 1) == True



# Generated at 2022-06-12 05:37:34.133199
# Unit test for function curried_map
def test_curried_map():
    assert(curried_map([1, 2, 3])(increase) == [2, 3, 4])
    assert(curried_map(increase)([1, 2, 3]) == [2, 3, 4])
    assert(curried_map(increase, [1, 2, 3]) == [2, 3, 4])



# Generated at 2022-06-12 05:37:39.268213
# Unit test for function eq
def test_eq():
    _eq = curry(eq)
    assert _eq(1)(1)
    assert _eq('abc', 'abc')
    assert not _eq(1)(2)
    assert not _eq('abc', 'abcd')
    assert not _eq(1)(True)
    assert not _eq(2, 3, 4)



# Generated at 2022-06-12 05:37:41.177917
# Unit test for function find
def test_find():
    lista = [1, 2, 3, 4, 5]
    assert find(lista, lambda x: x == 3) == 3, 'test_find failed'



# Generated at 2022-06-12 05:37:45.859325
# Unit test for function curry
def test_curry():
    """
    Tests that curry creates curried function.
    """
    def test_fn(arg1, arg2):
        return arg1 + arg2

    curried_fn = curry(test_fn)
    assert curried_fn(1)(2) == 3



# Generated at 2022-06-12 05:37:51.849408
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(increase)([1,2,3]) == [2,3,4]


# Generated at 2022-06-12 05:37:55.681575
# Unit test for function curry
def test_curry():
    assert increase(2) == 3
    assert increase(5) == 6
    assert increase(44) == 45
    assert curry(increase)(2) == 3
    assert curry(increase)(5) == 6
    assert curry(increase)(44) == 45



# Generated at 2022-06-12 05:38:02.753156
# Unit test for function cond
def test_cond():
    """
    :returns: Tests for function cond
    :rtype: None
    """
    assert cond([
        (lambda: True, lambda: 'True'),
        (lambda: False, lambda: 'False'),
    ])() == 'True', 'True condition should be executed'

    assert cond([
        (lambda: False, lambda: 'False'),
        (lambda: True, lambda: 'True'),
    ])() == 'True', 'True condition should be executed'

    assert cond([
        (lambda: True, lambda: 'True'),
        (lambda: True, lambda: 'True2'),
    ])() == 'True', 'True condition should be executed'


# Generated at 2022-06-12 05:38:06.182578
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x % 2 == 0) == 2
    assert find([1, 3, 5], lambda x: x % 2 == 0) is None



# Generated at 2022-06-12 05:38:11.241270
# Unit test for function curry
def test_curry():
    concat = lambda x, y: x + y
    concat2 = curry(concat, 2)
    concat3 = curry(concat, 3)
    assert concat2('a')('b') == 'ab'
    assert concat3('a')('b')('c') == 'abc'



# Generated at 2022-06-12 05:38:21.353811
# Unit test for function cond
def test_cond():
    print('It should return correct function: ', end='')
    assert cond([
        (lambda *args: True, increase),
        (lambda *args: False, lambda *args: 1),
        (lambda *args: False, lambda *args: 2),
    ])(4) == increase(4)
    print('\033[92m' + 'Ok' + '\033[0m')
    print('It should return first applicable function: ', end='')
    assert cond([
        (lambda *args: True, lambda *args: 'first'),
        (lambda *args: False, lambda *args: 'second'),
        (lambda *args: True, lambda *args: 'third'),
    ])(4) == 'first'
    print('\033[92m' + 'Ok' + '\033[0m')

# Generated at 2022-06-12 05:38:26.164203
# Unit test for function find
def test_find():
    collection = [1, 2, 3, 4]

    assert(find(collection, lambda item: item % 2 == 0)(0) == 2)
    assert(find(collection, lambda item: item % 2 == 1)(0) == 1)
    assert(find(collection, lambda item: item > 4)(0) == None)



# Generated at 2022-06-12 05:38:28.648083
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1, '1')


# Generated at 2022-06-12 05:38:31.032549
# Unit test for function curry
def test_curry():
    def add_two_numbers(a, b):
        return a + b

    assert curry(add_two_numbers)(1, 2) == 3



# Generated at 2022-06-12 05:38:34.096097
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, list(range(1, 10))) == [2, 4, 6, 8]


# Generated at 2022-06-12 05:38:47.179305
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x * 2)([1, 2, 3]) == [2, 4, 6]
    assert curried_map(lambda x: x * 2, [1, 2, 3]) == [2, 4, 6]



# Generated at 2022-06-12 05:38:51.778579
# Unit test for function curried_filter
def test_curried_filter():
    data = [0, 1, 2, 3, 4, 5]
    assert([1, 2, 3] == curried_filter(lambda x: x > 0, data))
    assert([1, 2, 3] == curried_filter(lambda x: x > 0)(data))
    is_positive = curried_filter(lambda x: x > 0)
    assert([1, 2, 3] == is_positive(data))



# Generated at 2022-06-12 05:38:54.186100
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 10)([1, 2, 11, 12, 13]) == [11, 12, 13]



# Generated at 2022-06-12 05:38:56.030239
# Unit test for function curried_map
def test_curried_map():
    assert curried_map([1,2,3])(increase) == [2, 3, 4]


# Generated at 2022-06-12 05:39:01.388973
# Unit test for function cond
def test_cond():
    factorial = cond([
        (lambda arg: arg == 0, lambda arg: 1),
        (lambda arg: True, lambda arg: arg * factorial(arg - 1)),
    ])

    assert factorial(0) == 1
    assert factorial(1) == 1
    assert factorial(2) == 2
    assert factorial(3) == 6



# Generated at 2022-06-12 05:39:10.406419
# Unit test for function curry
def test_curry():
    """
    Function for check curry function.

    :returns:
    :rtype:
    """
    def fn(x, y):
        return x + y

    curried = curry(fn)
    assert curried(3, 4) == 7
    assert curried(3)(4) == 7

    def fn1(x, y, z):
        return x + y + z

    curried = curry(fn1)
    assert curried(1, 2, 3) == 6
    assert curried(1)(2)(3) == 6
    assert curried(1)(2, 3) == 6
    assert curried(1, 2)(3) == 6



# Generated at 2022-06-12 05:39:15.122878
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2]) == [2, 3]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3, 4]) == [2, 3, 4, 5]

# Generated at 2022-06-12 05:39:19.831029
# Unit test for function curried_map
def test_curried_map():
    result = curried_map(identity)([1, 2, 3])
    assert result == [1, 2, 3]

    result = curried_map(identity, [1, 2, 3])
    assert result == [1, 2, 3]



# Generated at 2022-06-12 05:39:27.503751
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 1, [1, 2, 3]) == [2, 3]
    assert curried_filter(lambda x: x > 1)([1, 2, 3]) == [2, 3]
    assert curried_filter(lambda x: x > 1)([1, 2, 3]) == [2, 3]
    assert curried_filter(lambda x: x > 1, [1, 2, 3]) == [2, 3]



# Generated at 2022-06-12 05:39:37.113911
# Unit test for function cond
def test_cond():
    """
    Test passed conditions and if none of them passed it should raise exception
    :returns: None
    :rtype: None
    """
    def test_positive(number):
        return number > 0

    def test_negative(number):
        return number < 0

    test_equal = lambda number: number == 0

    should_be_positive = cond([
        (test_positive, lambda _: 'True'),
        (test_negative, lambda _: 'False'),
    ])

    should_be_negative = cond([
        (test_negative, lambda _: 'True'),
        (test_positive, lambda _: 'False'),
    ])

    should_be_zero = cond([
        (test_equal, lambda _: 'True'),
        (test_positive, lambda _: 'False'),
    ])

    assert should_be

# Generated at 2022-06-12 05:39:52.838451
# Unit test for function cond
def test_cond():
    def calcul(equation: str):
        pattern = re.compile(r'(\d+)(\+|\-|\*|\/)(\d+)')

        @cond([
            (lambda equation: pattern.match(equation), lambda equation: eval(equation)),
            (lambda equation: True, lambda equation: equation)
        ])
        def result(equation):
            return equation

        return (result(equation))


    print(calcul('3+3'))
    print(calcul('10-5'))
    print(calcul('3*3'))
    print(calcul('9/3'))
    print(calcul('3q3'))



# Generated at 2022-06-12 05:39:56.663558
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda value: value > 2, [1, 2, 3, 4, 5]) == [3, 4, 5]
    assert curried_filter(lambda value: value < 3)([1, 2, 3, 4, 5]) == [1, 2]


# Generated at 2022-06-12 05:40:02.471998
# Unit test for function cond
def test_cond():
    f = cond([
        (lambda x: x > 5, lambda x: x + 1),
        (lambda x: x == 5, lambda x: x * 2),
        (lambda x: x < 5, lambda x: x - 1)
    ])
    assert f(10) == 11
    assert f(5) == 10
    assert f(1) == 0



# Generated at 2022-06-12 05:40:08.026156
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 3 != 0, [1, 2, 3, 4]) == [1, 2, 4]
    func = curried_filter(lambda x: x % 3 == 0)
    assert func([1, 2, 3, 4]) == [3]
    func = curried_filter()
    assert func(lambda x: x % 2 == 0, [1, 2, 3, 4]) == [2, 4]



# Generated at 2022-06-12 05:40:10.929988
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4]) == [2, 4]


# Generated at 2022-06-12 05:40:14.653922
# Unit test for function find
def test_find():
    collection = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    find_even = find(collection, lambda item: item % 2 == 0)

    assert find_even == 0



# Generated at 2022-06-12 05:40:16.671964
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False


# Generated at 2022-06-12 05:40:19.274393
# Unit test for function memoize
def test_memoize():
    assert memoize(increase)(4) == 5
    assert memoize(increase)(4) == 5


if __name__ == "__main__":
    test_memoize()

# Generated at 2022-06-12 05:40:23.911148
# Unit test for function curried_filter
def test_curried_filter():
    data = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    even = curried_filter(lambda value: value % 2 == 0)
    assert even(data) == [0, 2, 4, 6, 8]
    assert even(data) == list(filter(lambda value: value % 2 == 0, data))



# Generated at 2022-06-12 05:40:25.826407
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1, 'a')
    assert not eq(1, None)



# Generated at 2022-06-12 05:40:38.101606
# Unit test for function curried_map
def test_curried_map():
    assert curried_map([1, 2, 3, 4], identity) == [1, 2, 3, 4]
    assert curried_map([1, 2, 3, 4], increase)() == [2, 3, 4, 5]



# Generated at 2022-06-12 05:40:46.217437
# Unit test for function cond
def test_cond():
    def greet(name):
        return 'Hello ' + name

    def intro(name):
        return 'My name is ' + name

    def hello(value):
        return 'hello'

    condition_list = [
        (lambda value: value == 'hello', hello),
        (lambda name: name == 'John', greet),
        (lambda name: name == 'John', intro),
        (lambda *args: True, lambda *args: 'error'),
    ]

    hello_function = cond(condition_list)

    assert(hello_function('hello') == 'hello')
    assert(hello_function('John') == 'Hello John')
    assert(hello_function('Stack') == 'error')



# Generated at 2022-06-12 05:40:49.813075
# Unit test for function curry
def test_curry():
    def average(a, b, c):
        return (a + b + c) / 3.0

    average_c = curry(average, 3)
    assert average_c(1)(2)(3) == 2.0



# Generated at 2022-06-12 05:41:00.914486
# Unit test for function memoize
def test_memoize():
    counter = 0

    @memoize
    def inc(value):
        nonlocal counter
        counter += 1
        return value + 1

    assert inc(2) == 3
    assert inc(2) == 3
    assert inc([1, 2, 3]) == [1, 2, 3, 4]
    assert inc([1, 2, 3]) == [1, 2, 3, 4]
    assert counter == 2

    inc2 = memoize(lambda value: value + 1)
    assert inc2(2) == 3
    assert inc2(2) == 3
    assert inc2([1, 2, 3]) == [1, 2, 3, 4]
    assert inc2([1, 2, 3]) == [1, 2, 3, 4]
    assert counter == 2


# Generated at 2022-06-12 05:41:08.167657
# Unit test for function memoize
def test_memoize():
    def average(values):
        return sum(values) / len(values)

    assert average([1, 2, 3, 4, 5]) == 3
    assert average([1, 2, 3, 4, 5, 6]) == average([1, 2, 3, 4, 5])

    average = memoize(average, eq)

    assert average([1, 2, 3, 4, 5]) == 3
    assert average([1, 2, 3, 4, 5, 6]) == average([1, 2, 3, 4, 5])


if __name__ == '__main__':
    test_memoize()

# Generated at 2022-06-12 05:41:18.196796
# Unit test for function cond
def test_cond():
    assert cond(
        [
            (eq(0), lambda value: 'zero'),
            (eq(1), lambda value: 'one'),
            (lambda _: True, lambda value: 'more than one')
        ]
    )(1) == 'one'
    assert cond(
        [
            (eq(0), lambda value: 'zero'),
            (eq(1), lambda value: 'one'),
            (lambda _: True, lambda value: 'more than one')
        ]
    )(2) == 'more than one'
    assert cond(
        [
            (eq(0), lambda value: 'zero'),
            (eq(1), lambda value: 'one'),
            (lambda _: True, lambda value: 'more than one')
        ]
    )(0) == 'zero'



# Generated at 2022-06-12 05:41:20.922347
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(2, 3) is False



# Generated at 2022-06-12 05:41:23.360999
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], eq(4)) == 4
    assert find([1, 2, 3, 4], eq(5)) is None

# Generated at 2022-06-12 05:41:34.498257
# Unit test for function curry
def test_curry():
    """
    Test function curry
    """
    def test_function(a, b, c, d):
        return (a + b) * (c + d)

    assert curry(test_function, 4)(1, 2, 3, 4) == 21, "Test curry failed"
    assert curry(test_function, 4)(1, 2, 3)(4) == 21, "Test curry failed"
    assert curry(test_function, 4)(1, 2)(3, 4) == 21, "Test curry failed"
    assert curry(test_function, 4)(1, 2)(3)(4) == 21, "Test curry failed"
    assert curry(test_function, 4)(1)(2, 3, 4) == 21, "Test curry failed"

# Generated at 2022-06-12 05:41:42.882513
# Unit test for function curry
def test_curry():
    """
    Function test_curry is simple unit test for function curry

    :returns: nothing
    :rtype: None
    """
    power3 = curry(lambda x, y, z: x ** y ** z)
    assert power3(2, 3, 4) == power3(2, 3)(4)
    assert power3(2, 3, 4) == power3(2)(3)(4)
    assert power3(2, 3)(4) == power3(2)(3, 4)
    assert power3(2)(3)(4) == power3(2)(3, 4)



# Generated at 2022-06-12 05:42:03.307631
# Unit test for function memoize
def test_memoize():
    test_sqr = memoize(lambda x: x * x)
    assert test_sqr(3) == 9
    assert test_sqr(3) == 9
    assert test_sqr(5) == 25
    assert test_sqr(5) == 25



# Generated at 2022-06-12 05:42:11.874638
# Unit test for function find
def test_find():
    assert find(
        [1, 2, 3, 4],
        lambda arg: arg > 2
    ) is not None
    assert find(
        [1, 2, 3, 4],
        lambda arg: arg > 5
    ) is None
    assert find(
        ['a', 'b', 'c', 'd', 'e'],
        lambda arg: arg == 'a'
    ) is not None
    assert find(
        ['a', 'b', 'c', 'd', 'e'],
        lambda arg: arg == 'f'
    ) is None
    assert find(
        [True, False, False, True],
        lambda arg: arg
    ) is not None
    assert find(
        [False, False, False, False],
        lambda arg: arg
    ) is None



# Generated at 2022-06-12 05:42:19.841605
# Unit test for function memoize
def test_memoize():
    counter = 0
    def proof_function(value):
        nonlocal counter
        counter += 1
        return value
    # without cache
    counter = 0
    assert(proof_function(1) == 1)
    assert(counter == 1)
    assert(proof_function(1) == 1)
    assert(counter == 2)
    # with cache
    counter = 0
    memoized_proof_function = memoize(proof_function)
    assert(memoized_proof_function(1) == 1)
    assert(counter == 1)
    assert(memoized_proof_function(1) == 1)
    assert(counter == 1)
    assert(memoized_proof_function(2) == 2)
    assert(counter == 2)


# Generated at 2022-06-12 05:42:30.008359
# Unit test for function cond
def test_cond():
    def is_even(x):
        return x % 2 == 0

    def is_odd(x):
        return not is_even(x)

    def divide_2(x):
        return x // 2

    def multiply_3(x):
        return x * 3

    def add_1(x):
        return x + 1

    is_even_divide_2_add_1_cond = cond([
        (is_even, compose(divide_2, add_1)),
        (is_odd, compose(multiply_3, add_1)),
    ])

    assert is_even_divide_2_add_1_cond(2) == 3
    assert is_even_divide_2_add_1_cond(3) == 10

    is_even_divide_2_add_1_cond

# Generated at 2022-06-12 05:42:36.543252
# Unit test for function memoize
def test_memoize():
    """
    Test for function memoize
    """
    @memoize
    def add(a):
        return a + 1

    def add1(a):
        return a + 1

    @memoize
    def add2(a):
        return a + 2

    assert add(2) == add(2)
    assert add1(2) != add1(2)
    assert add(2) != add(3)
    assert add2(2) == add2(2)


# Generated at 2022-06-12 05:42:47.894223
# Unit test for function cond
def test_cond():
    """
    cond is function witch get list of two-item tuples,
    first is condition_function, second is execute_function.
    Returns this execute_function witch first condition_function return truly value.

    :returns: test result
    :rtype: Boolean
    """
    def condition_is_a(a):
        return eq(a, 'a')

    def condition_is_b(b):
        return eq(b, 'b')

    def condition_is_c(c):
        return eq(c, 'c')

    def execute_is_x():
        return 'x'

    def execute_is_y():
        return 'y'

    def execute_is_z():
        return 'z'


# Generated at 2022-06-12 05:42:51.724377
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq(1, 1)(1) == True
    assert eq(2, 3)(2) == False
    assert eq(2, 3)(3) == False


# Generated at 2022-06-12 05:42:56.290090
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x * 2, [1, 2, 3]) == [2, 4, 6]
    assert curried_map(lambda x: x * 2)([1, 2, 3]) == [2, 4, 6]
    list_map = curried_map(lambda x: x * 2)
    assert list_map([1, 2, 3]) == [2, 4, 6]

# Generated at 2022-06-12 05:42:59.190907
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(2)) == 2
    assert find([4, 5, 6], eq(1)) is None

# Generated at 2022-06-12 05:43:07.544024
# Unit test for function curried_map
def test_curried_map():
    """
    Test curried_map for different args counts
    """
    assert curried_map()(range(10), lambda i: i + 1) == list(range(1, 11))
    assert curried_map(lambda i: i + 1)(range(10)) == list(range(1, 11))
    assert curried_map(lambda i: i + 1, range(10)) == list(range(1, 11))

    """
    Test curried_map for increasing
    """
    curried_map_increase = curried_map(increase)

    assert curried_map_increase(range(10)) == list(range(1, 11))



# Generated at 2022-06-12 05:43:33.691215
# Unit test for function cond
def test_cond():
    assert cond([(lambda x: x > 10, identity), (lambda x: x <= 10, increase)])(11) == 11
    assert cond([(lambda x: x > 10, identity), (lambda x: x <= 10, increase)])(10) == 11
    assert cond([(lambda x: x > 10, increase), (lambda x: x <= 10, identity)])(11) == 12
    assert cond([(lambda x: x > 10, increase), (lambda x: x <= 10, identity)])(9) == 9


# Unit tests for function find

# Generated at 2022-06-12 05:43:37.945832
# Unit test for function curried_map
def test_curried_map():
    arr = [1, 2, 3]

    assert(curried_map(lambda x: x + 1, arr) == map(lambda x: x + 1, arr))
    assert(curried_map(lambda x: x + 1)(arr) == map(lambda x: x + 1, arr))



# Generated at 2022-06-12 05:43:40.438335
# Unit test for function curried_map
def test_curried_map():
    test = ['1', '2', '3']
    assert curried_map(int, test) == [1, 2, 2]



# Generated at 2022-06-12 05:43:47.091675
# Unit test for function cond
def test_cond():
    def is_even(number):
        return (number % 2) == 0

    def increment(number):
        return number + 1

    def double(number):
        return number * 2

    even = cond(
        [(is_even, identity),
         (lambda x: True, increment)]
    )
    assert even(2) == 2, "even(2) == 2"
    assert even(3) == 4, "even(3) == 4"
    assert even(5) == 6, "even(5) == 6"
    assert even(7) == 8, "even(7) == 8"

    odd = cond(
        [(is_even, double),
         (lambda x: True, identity)]
    )
    assert odd(2) == 4, "odd(2) == 4"
    assert odd(3) == 3

# Generated at 2022-06-12 05:43:50.501913
# Unit test for function cond
def test_cond():
    assert cond([(eq(1), identity), (eq(2), increase)], )(1) == 1
    assert cond([(eq(1), identity), (eq(2), increase)], )(2) == 3



# Generated at 2022-06-12 05:43:52.172665
# Unit test for function memoize
def test_memoize():
    factorial = memoize(lambda n: 1 if n == 0 else n * factorial(n - 1))
    assert factorial(20) == 2432902008176640000

# Generated at 2022-06-12 05:44:00.189968
# Unit test for function curried_filter
def test_curried_filter():
    assert pipe(
        [1, 2, 3],
        curried_filter(lambda x: x > 1),
        lambda x: x == [2, 3]
    ) == True

    assert pipe(
        [1, 2, 3, 4],
        curried_filter(lambda x: x > 4),
        lambda x: x == []
    ) == True

    assert pipe(
        [1, 2, 3],
        curried_filter(lambda x: x > 2),
        curried_map(lambda x: x * 2),
        lambda x: x == [6]
    ) == True


# Generated at 2022-06-12 05:44:03.441841
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4, 5]) == [3, 4, 5]



# Generated at 2022-06-12 05:44:05.142954
# Unit test for function curried_map
def test_curried_map():
    assert ([1, 4] == curried_map(increase, [0, 3]))


# Generated at 2022-06-12 05:44:15.235055
# Unit test for function memoize
def test_memoize():
    # Given
    add_args1 = 1
    add_args2 = 2
    multiple_args1 = 1
    multiple_args2 = 2
    add_result = add_args1 + add_args2
    multiply_result = multiple_args1 * multiple_args2
    # When
    memoized_add = memoize(lambda args: args[0] + args[1])
    memoized_multiply = memoize(lambda args: args[0] * args[1])
    # Then
    assert memoized_add((add_args1, add_args2)) == add_result
    assert memoized_add((add_args1, add_args2)) == add_result
    assert memoized_multiply((multiple_args1, multiple_args2)) == multiply_result

# Generated at 2022-06-12 05:44:56.350391
# Unit test for function curry
def test_curry():
    print(curry(lambda x, y: x + y)(1)(2))



# Generated at 2022-06-12 05:45:07.054204
# Unit test for function find
def test_find():
    """
    Test for function find
    """
    assert find([], lambda item: item == 1) == None
    assert find([0, 2, 3, 4, 5], lambda item: item == 1) == None
    assert find([0, 2, 3, 4, 5], lambda item: item == 2) == 2
    assert find([0, 2, 3, 4, 5], lambda item: item == 3) == 3
    assert find([0, 2, 3, 4, 5], lambda item: item == 4) == 4
    assert find([0, 2, 3, 4, 5], lambda item: item == 5) == 5
    assert find(['a', 'b', 'c'], lambda item: item == 'a') == 'a'

# Generated at 2022-06-12 05:45:11.501454
# Unit test for function find
def test_find():
    test_list = [
        1,
        2,
        3,
        'abc',
        {1: 1, 2: 2},
    ]

    result = find(test_list, lambda x: x == 'abc')
    assert result == 'abc'

    result = find(test_list, lambda x: x == 'def')
    assert result is None



# Generated at 2022-06-12 05:45:15.175743
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 5)([1, 2, 3, 4, 5, 6, 7, 8, 9]) == [6, 7, 8, 9]



# Generated at 2022-06-12 05:45:20.477812
# Unit test for function cond
def test_cond():
    is_even = lambda x: x % 2 == 0
    is_odd = lambda x: x % 2 == 1
    power_of_two = lambda x: x ** 2
    power_of_three = lambda x: x ** 3

    function = cond([
        (is_even, power_of_two),
        (is_odd, power_of_three),
    ])

    assert function(4) == 16
    assert function(9) == 729

# Generated at 2022-06-12 05:45:23.805474
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(2)) == 2
    assert find([1, 2, 3], eq(4)) is None



# Generated at 2022-06-12 05:45:31.571072
# Unit test for function memoize
def test_memoize():
    def time_execution_once(fn):
        start = time.time()
        result = fn()
        elapsed = time.time() - start
        return (result, elapsed)

    def benchmark(fn):
        result, elapsed = time_execution_once(fn)
        print(f'function ({result}) was calculated in {elapsed}ms')


    @memoize
    def fib(n):
        if n < 2:
            return n
        return fib(n - 2) + fib(n - 1)

    benchmark(lambda: fib(2))
    benchmark(lambda: fib(10))
    benchmark(lambda: fib(35))

# Generated at 2022-06-12 05:45:40.941810
# Unit test for function cond
def test_cond():
    """
    Test for cond
    """
    assert cond([
        (lambda x: x == 1, identity),
        (lambda x: x < 0, increase),
        (lambda x: True, decrease),
    ])(1) == 1

    assert cond([
        (lambda x: x == 1, identity),
        (lambda x: x < 0, increase),
        (lambda x: True, decrease),
    ])(-10) == -9

    assert cond([
        (lambda x: x == 1, identity),
        (lambda x: x < 0, increase),
        (lambda x: True, decrease),
    ])(10) == 9



# Generated at 2022-06-12 05:45:44.857210
# Unit test for function find
def test_find():
    assert find([], lambda x: True) is None
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 10) is None



# Generated at 2022-06-12 05:45:49.120899
# Unit test for function curried_filter
def test_curried_filter():
    collection1 = [1, 2, 3, 4, 5]
    collection2 = ['a', 'b', 'c']

    @curry
    def is_even(value):
        return value % 2 == 0

    assert curried_filter(is_even, collection1) == [2, 4]
    assert curried_filter(is_even)(collection1) == [2, 4]

    assert curried_filter(lambda item: item != 'b', collection2) == ['a', 'c']

