

# Generated at 2022-06-12 05:36:18.434760
# Unit test for function cond
def test_cond():
    def fn(arg: int) -> int:
        return arg

    def fn1(arg: int) -> int:
        return arg + 1

    def fn2(arg: int) -> int:
        return arg + 2

    def fn3(arg: int) -> int:
        return arg + 3

    cond_fn = cond([
        (lambda x: x % 2 == 0, fn),
        (lambda x: x % 3 == 0, fn1),
        (lambda x: True, fn3)
    ])
    assert cond_fn(3) == 4
    assert cond_fn(4) == 4



# Generated at 2022-06-12 05:36:24.268323
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(['a', 'b', 'c'], ['a', 'b', 'c'])
    assert not eq(['a', 'b', 'c'], ['a', 'b', 'd'])



# Generated at 2022-06-12 05:36:32.466325
# Unit test for function eq
def test_eq():
    # Test passing the value and return true
    assert eq(1, 1), 'Values 1 and 1 should be equal'
    # Test passing the value and return false
    assert not eq(1, 2), 'Values 1 and 2 should not be equal'
    # Test passing the equal functions and values
    assert eq(eq, eq)(1, 1), 'Function should return true because equal'
    # Test passing the equal functions and values
    assert not eq(eq, increase)(increase, eq)(1, 2), 'Function should return false because not equal'



# Generated at 2022-06-12 05:36:40.176066
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(2), [1, 2, 3]) == [2]
    assert curried_filter(eq(2), [1, 2, 3, 2]) == [2, 2]
    assert curried_filter(eq(2), [1, 3, 1, 3]) == []
    assert curried_filter(eq(2), []) == []

# Generated at 2022-06-12 05:36:45.279911
# Unit test for function cond
def test_cond():
    equals = cond([
        (lambda a, b: a == b, identity),
        (lambda a, b: a > b, increase),
        (lambda a, b: a < b, lambda a: a - 1)
    ])

    assert equals(0, 0) == 0
    assert equals(1, 0) == 1
    assert equals(0, 1) == -1



# Generated at 2022-06-12 05:36:47.187594
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False


# Generated at 2022-06-12 05:36:51.258179
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda item: item == 1) == 1
    assert find([1, 2, 3], lambda item: item == 2) == 2
    assert find([1, 2, 3], lambda item: item == 3) == 3
    assert find([1, 2, 3], lambda item: item == 4) is None



# Generated at 2022-06-12 05:36:55.774258
# Unit test for function curried_filter
def test_curried_filter():
    curried_filter_with_function_is_even = curried_filter(lambda n: n % 2 == 0)
    assert curried_filter_with_function_is_even([1, 2, 3, 4]) == [2, 4]



# Generated at 2022-06-12 05:36:58.127280
# Unit test for function curry
def test_curry():
    assert curried_map([1, 2, 3])(identity) == [1, 2, 3]



# Generated at 2022-06-12 05:36:59.119442
# Unit test for function eq
def test_eq():
    pass



# Generated at 2022-06-12 05:37:09.947890
# Unit test for function curry
def test_curry():
    f = curry(lambda x, y, z, w: (x, y, z, w))
    assert f(1) == curry(lambda y, z, w: (1, y, z, w), 3)
    assert f(1)(2) == curry(lambda z, w: (1, 2, z, w), 2)
    assert f(1)(2)(3) == curry(lambda w: (1, 2, 3, w), 1)
    assert f(1)(2)(3)(4) == (1, 2, 3, 4)



# Generated at 2022-06-12 05:37:13.171447
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 1, [1, 2, 3, 4, 5, 6, 7, 8, 9]) == [1, 3, 5, 7, 9]


# Generated at 2022-06-12 05:37:15.806727
# Unit test for function curry
def test_curry():
    # 1) Testing function with one argument
    assert curry(identity)(1) == 1

    # 2) Testing function with multiple arguments
    assert curry(eq)(1)(1) == True
    assert curry(eq)(1)(2) == False



# Generated at 2022-06-12 05:37:20.934144
# Unit test for function cond
def test_cond():
    f = lambda x: x
    g = lambda x: x + 1
    h = lambda x: x + 2
    assert cond([(lambda x: x if x > 2 else False, f),
                 (lambda x: x if x < 2 else False, g),
                 (lambda x: x if x == 2 else False, h)]) == 2

# Generated at 2022-06-12 05:37:25.016170
# Unit test for function eq
def test_eq():
    assert True is eq(2)(2)
    assert True is eq(2, 2)
    assert False is eq(2)(2.1)
    assert False is eq(2, 2.1)



# Generated at 2022-06-12 05:37:32.595764
# Unit test for function curry
def test_curry():
    assert (lambda x: x + 1)(1) == 2
    assert curry(lambda x: x + 1)(1) == 2

    assert (lambda x, y: x + y)(1, 1) == 2
    assert curry(lambda x, y: x + y)(1)(1) == 2

    assert (lambda x, y, z: x + y + z)(1, 1, 1) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(1)(1) == 3



# Generated at 2022-06-12 05:37:37.159920
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]

# Generated at 2022-06-12 05:37:40.480001
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(2), [1, 2, 3]) == [2]
    assert curried_filter(eq(4), [1, 2, 3]) == []



# Generated at 2022-06-12 05:37:43.560864
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-12 05:37:51.586618
# Unit test for function cond
def test_cond():
    age = cond([
        (lambda x: x < 2, lambda x: 'baby'),
        (lambda x: x < 18, lambda x: 'child'),
        (lambda x: x < 60, lambda x: 'adult'),
        (lambda x: True, lambda x: 'senior'),
    ])

    assert age(15) == 'child'
    assert age(18) == 'adult'
    assert age(0) == 'baby'
    assert age(65) == 'senior'



# Generated at 2022-06-12 05:38:09.416596
# Unit test for function cond
def test_cond():
    def add(x: int):
        return lambda y: x + y

    def subtract(x: int):
        return lambda y: y - x

    def multiply(x: int):
        return lambda y: x * y

    def divide(x: int):
        return lambda y: y / x

    def even(x: int):
        return x % 2 == 0

    def odd(x: int):
        return not even(x)

    fns = cond([
        (even, add(1)),
        (odd, multiply(2)),
    ])

    assert fns(1) == 2
    assert fns(2) == 3


# Generated at 2022-06-12 05:38:11.437104
# Unit test for function eq
def test_eq():
    eq_function = eq(1)
    assert eq_function(1)



# Generated at 2022-06-12 05:38:14.202969
# Unit test for function memoize
def test_memoize():
    @memoize
    def fib(n):
        return 1 if n < 2 else fib(n - 1) + fib(n - 2)

    for i in range(100):
        assert fib(i) == 1 if i < 2 else fib(i - 1) + fib(i - 2)

# Generated at 2022-06-12 05:38:15.547608
# Unit test for function cond
def test_cond():
    assert cond([(identity, identity)])(True)



# Generated at 2022-06-12 05:38:22.478613
# Unit test for function curried_map
def test_curried_map():
    assert(curried_map(identity)([1,2,3]) == [1,2,3])
    assert(curried_map(identity)([]) == [])
    assert(curried_map(lambda x: x+1)([1]) == [2])
    assert(curried_map(lambda x: x+2)([3,4]) == [5,6])

    print("Test for function curried_map: OK!")


# Generated at 2022-06-12 05:38:25.198895
# Unit test for function curried_map
def test_curried_map():
    expected_result = [2, 3, 4, 5, 6]
    assert curried_map(increase)([1, 2, 3, 4, 5]) == expected_result



# Generated at 2022-06-12 05:38:30.988052
# Unit test for function curried_filter
def test_curried_filter():
    def is_odd(a):
        return not a % 2

    curried_filter(is_odd, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    is_odd_all = curried_filter(is_odd)
    is_odd_all([0, 1, 2, 3, 4, 5, 6, 7, 8, 9])


# Generated at 2022-06-12 05:38:38.538593
# Unit test for function curry
def test_curry():
    add = curry(lambda x, y: x + y)
    assert add(1)(2) == 3

    @curry
    def sum_item(item_list, start=0):
        return reduce(
            lambda sum, current_value: sum + current_value,
            item_list,
            start
        )

    assert sum_item([1, 2, 3])(1) == sum_item([1, 2, 3], 1)



# Generated at 2022-06-12 05:38:40.357020
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3, 4]) == [2, 3, 4, 5]


# Generated at 2022-06-12 05:38:45.195358
# Unit test for function eq
def test_eq():
    def test_positive():
        assert eq(2, 2) is True
        assert eq(2, 1) is False

    def test_negative():
        pass

    test_negative()
    test_positive()



# Generated at 2022-06-12 05:39:24.142170
# Unit test for function curry
def test_curry():
    # Test with 0 args
    def return_1():
        return 1
    curried_return_1 = curry(return_1)
    assert curried_return_1() == 1
    # Test with 1 arg
    def return_arg(arg):
        return arg
    curried_return_arg = curry(return_arg)
    assert curried_return_arg(1) == 1
    # Test with 2 args
    def plus(a, b):
        return a + b
    curried_plus = curry(plus)
    assert curried_plus(1)(2) == 3
    assert curried_plus(1, 2) == 3
    assert curried_plus(1)(2) == curry(plus)(1)(2)
    assert curry(plus)(1)(2) == curry(plus)(1, 2)


# Unit

# Generated at 2022-06-12 05:39:29.410235
# Unit test for function cond
def test_cond():
    cond_fn = cond([
        (lambda val: val == 0, lambda val: 1),
        (lambda val: val == 1, lambda val: 2),
        (lambda val: val == 2, lambda val: 3)
    ])
    assert cond_fn(1) == 2
    assert cond_fn(0) == 1
    assert cond_fn(3) is None


# Generated at 2022-06-12 05:39:33.981990
# Unit test for function memoize
def test_memoize():
    def func(n):
        return n

    func_memoized = memoize(func)

    assert func_memoized(1) == 1
    assert func_memoized(2) == 2
    assert func_memoized(1) == 1
    return


# Generated at 2022-06-12 05:39:36.324422
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(5))([9, 2, 3, 5, 1, 4, 5, 5]) == [5, 5, 5]

# Generated at 2022-06-12 05:39:42.711253
# Unit test for function curried_map
def test_curried_map():
    """
    Unit test for function curried_map

    :return:
    """
    example_list = [1, 2, 3, 4, 5]
    assert curried_map(increase)(example_list) == [2, 3, 4, 5, 6], 'curried_map increase [1, 2, 3, 4, 5] != [2, 3, 4, 5, 6]'


# Generated at 2022-06-12 05:39:48.999298
# Unit test for function cond
def test_cond():
    def get_result(arg):
        return arg

    list_of_condition_function = [
        (lambda arg: arg > 1, get_result),
        (lambda arg: arg == 1, get_result),
        (lambda arg: arg < 1, get_result),
    ]
    function = cond(list_of_condition_function)
    assert function(1) == 1
    assert function(30) == 30
    assert function(-10) == -10



# Generated at 2022-06-12 05:39:55.158639
# Unit test for function cond
def test_cond():
    def inc(x: int) -> int:
        return x + 1

    def dec(x: int) -> int:
        return x - 1

    test = cond([
        (lambda x: x % 2 == 0, inc),
        (lambda x: x % 2 == 1, dec),
    ])
    assert test(10) == 11
    assert test(9) == 8



# Generated at 2022-06-12 05:39:57.133898
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)


# Generated at 2022-06-12 05:39:59.729792
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 4) is None
    assert find([1, 2, 3], lambda x: x == 2) == 2



# Generated at 2022-06-12 05:40:08.635828
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq([1, 2], [1, 2]) == True
    assert eq([1, 2], [2, 3]) == False
    assert eq((1, 2), (1, 2)) == True
    assert eq((1, 2), (2, 3)) == False
    assert eq({"a": 1}, {"a": 1}) == True
    assert eq({"a": 1}, {"a": 2}) == False
    assert eq({"a": 1, "b": 2}, {"a": 1, "b": 2}) == True
    assert eq({"a": 1, "b": 2}, {"a": 1, "b": 1}) == False



# Generated at 2022-06-12 05:40:27.623385
# Unit test for function eq
def test_eq():
    assert True == eq(1, 1)
    assert True == eq('abc', 'abc')
    assert True == eq([1, 2, 3], [1, 2, 3])
    assert False == eq(1, 2)
    assert False == eq(True, False)
    assert False == eq([1, 2, 3], [1, 2])

# Generated at 2022-06-12 05:40:36.807810
# Unit test for function cond
def test_cond():
    assert cond([
        (
            lambda x: x % 2 == 1,
            lambda x: 'Odd'
        ),
        (
            lambda x: x % 2 == 0,
            lambda x: 'Even'
        )
    ])(2) == 'Even'

    assert cond([
        (
            lambda x: x % 2 == 1,
            lambda x: 'Odd'
        ),
        (
            lambda x: x % 2 == 0,
            lambda x: 'Even'
        )
    ])(3) == 'Odd'

# Generated at 2022-06-12 05:40:42.870178
# Unit test for function curry
def test_curry():
    def add_two_ints(a, b):
        return a + b

    assert curry(add_two_ints)(1, 1) == 2

    add_two = curry(add_two_ints)
    add_three = add_two(1)

    assert add_three(2) == 3

    assert curry(increase)(1) == 2

    assert curry(add_two)(1)(3) == 4



# Generated at 2022-06-12 05:40:46.072918
# Unit test for function cond
def test_cond():
    fn = cond([
        (lambda x: True, lambda x: x),
        (lambda x: False, lambda x: x)
    ])

    assert fn(1) == 1


# Generated at 2022-06-12 05:40:49.673752
# Unit test for function find
def test_find():
    collection = [1, 2, 3, 4, 5]
    assert find(collection,
                lambda x: x > 2) == 3
    assert find(collection,
                lambda x: x > 5) == None


# Generated at 2022-06-12 05:40:59.678324
# Unit test for function cond
def test_cond():
    """
    Test case for function cond.

    Test is passed if all assertions are true.
    """
    is_event_number = cond([
        (lambda x: x % 2 == 0, lambda x: True),
        (lambda x: x % 2 != 0, lambda x: False),
    ])
    is_positive = cond([
        (lambda x: x > 0, lambda x: True),
        (lambda x: x < 0, lambda x: False),
    ])

    assert is_event_number(4) is True
    assert is_event_number(5) is False
    assert is_positive(8) is True
    assert is_positive(-5) is False

# Generated at 2022-06-12 05:41:04.720517
# Unit test for function eq
def test_eq():
    result = eq(0, 0)
    assert result == True

    result = eq(1, 1)
    assert result == True

    result = eq(1, 0)
    assert result == False

    result = eq(0, 1)
    assert result == False



# Generated at 2022-06-12 05:41:09.405348
# Unit test for function curried_filter
def test_curried_filter():
    # given

    # when
    result = curried_filter(
        lambda x: x % 2 == 0,
        [1, 2, 3, 4, 5, 6]
    )

    # then
    assert result == [2, 4, 6]


# Generated at 2022-06-12 05:41:14.456332
# Unit test for function cond
def test_cond():
    """
    Function to test cond function
    """
    result = cond([
        (lambda a, b, c: a > b, lambda a, b, c: 'a > b'),
        (lambda a, b, c: b > a, lambda a, b, c: 'b > a'),
        (lambda a, b, c: a == b, lambda a, b, c: 'a == b'),
        (lambda a, b, c: True, lambda a, b, c: 'a is not greater than b and b is not greater than a'),
    ])(4, 2, 0)

    if result != 'a > b':
        raise Exception('test_cond does not return correct value')


# Generated at 2022-06-12 05:41:19.994079
# Unit test for function curried_map
def test_curried_map():
    map_increase = curried_map(increase)
    test_list = [1, 2, 3]
    assert map_increase(test_list) == [2, 3, 4]



# Generated at 2022-06-12 05:41:53.324051
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b, c: a + b + c)(1, 2, 3) == 6
    assert curry(lambda a, b, c: a + b + c)(1, 2)(3) == 6
    assert curry(lambda a, b, c: a + b + c)(1)(2)(3) == 6



# Generated at 2022-06-12 05:41:57.201864
# Unit test for function find
def test_find():
    assert find([], lambda x: True) == None
    assert find([{'a': 1}], lambda x: x['a'] == 1) == {'a': 1}
    assert find([{'a': 1}], lambda x: x['a'] == 2) == None



# Generated at 2022-06-12 05:42:05.950549
# Unit test for function memoize
def test_memoize():
    cache = []

    def sample_function(arg: str) -> str:
        return arg[::-1]

    def test_function(arg: str) -> str:
        cache.append(arg)
        return arg[::-1]

    memoized_function = memoize(test_function)

    received_value = memoized_function("test")
    received_value2 = memoized_function("test")

    assert sample_function("test") == received_value == received_value2
    assert len(cache) == 1

    received_value = memoized_function("test2")
    received_value2 = memoized_function("test2")

    assert sample_function("test2") == received_value == received_value2
    assert len(cache) == 2



# Generated at 2022-06-12 05:42:08.314036
# Unit test for function curried_filter
def test_curried_filter():
    odd_filter = curried_filter(lambda x: x % 2)
    assert [1, 3, 5] == odd_filter([0, 1, 2, 3, 4, 5])


# Generated at 2022-06-12 05:42:12.702579
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, range(100)) == list(range(100))
    assert curried_map(increase, range(100)) == list(range(1, 101))
    assert curried_map(identity)(range(100)) == list(range(100))
    assert curried_map(increase)(range(100)) == list(range(1, 101))



# Generated at 2022-06-12 05:42:20.894376
# Unit test for function cond
def test_cond():
    print(
        cond([
            (lambda a: a > 20, lambda a: "above"),
            (lambda a: a >= 2, lambda a: "equal"),
            (lambda a: a < 2, lambda a: "below"),
        ])(21)
    )

    print(
        cond([
            (lambda a: a > 20, lambda a: "above"),
            (lambda a: a >= 2, lambda a: "equal"),
            (lambda a: a < 2, lambda a: "below"),
        ])(2)
    )

    print(
        cond([
            (lambda a: a > 20, lambda a: "above"),
            (lambda a: a >= 2, lambda a: "equal"),
            (lambda a: a < 2, lambda a: "below"),
        ])(1)
    )


# Generated at 2022-06-12 05:42:28.182965
# Unit test for function curry
def test_curry():
    """
    Unit test for function curry

    :returns: None
    :rtype: NoneType
    """
    def test_add(x: int, y: int, z: int):
        """
        Test for function curry

        :returns: Result of adding x, y and z
        :rtype: Int
        """
        return x + y + z

    assert curry(test_add, 3)(1)(2)(3) == 6
    assert curry(lambda x, y: x + y)(1)(2) == 3



# Generated at 2022-06-12 05:42:30.098989
# Unit test for function eq
def test_eq():
    print("Test for function eq")
    assert eq("1", "1")



# Generated at 2022-06-12 05:42:40.568718
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x > 5, lambda x: x * 2),
        (lambda x: x == 5, lambda x: x ** 2),
        (lambda x: True, lambda x: x + 1),
    ])(1) == 2
    assert cond([
        (lambda x: x > 5, lambda x: x * 2),
        (lambda x: x == 5, lambda x: x ** 2),
        (lambda x: True, lambda x: x + 1),
    ])(5) == 25
    assert cond([
        (lambda x: x > 5, lambda x: x * 2),
        (lambda x: x == 5, lambda x: x ** 2),
        (lambda x: True, lambda x: x + 1),
    ])(6) == 12



# Generated at 2022-06-12 05:42:43.473702
# Unit test for function memoize
def test_memoize():
    """Unit test for function memoize"""
    assert memoize(lambda x: x * 2)(3) == 6
    assert memoize(lambda x: x * 2)(3) == 6



# Generated at 2022-06-12 05:43:48.691635
# Unit test for function curry
def test_curry():
    assert add(1, 1) == 2
    assert add(1)(1) == 2

    assert multiply(2, 3) == 6
    assert multiply(2)(3) == 6

    assert sub(3, 1) == 2
    assert sub(3)(1) == 2

    assert divide(6, 2) == 3
    assert divide(6)(2) == 3



# Generated at 2022-06-12 05:43:53.167076
# Unit test for function cond
def test_cond():
    # arrange
    condition_list = [
        (lambda number: number > 5, lambda number: number + 3),
        (lambda number: number < 5, lambda number: number * 4),
        (lambda number: number == 5, lambda number: 'five')
    ]
    # act
    result = cond(condition_list)(5)
    # assert
    assert result == 'five'



# Generated at 2022-06-12 05:44:04.692229
# Unit test for function memoize
def test_memoize():
    @memoize
    def fib(n: int) -> int:
        if n == 0:
            return 0
        if n == 1:
            return 1
        return fib(n - 1) + fib(n - 2)

    def test_fib(n: int) -> int:
        if n == 0:
            return 0
        if n == 1:
            return 1
        return test_fib(n - 1) + test_fib(n - 2)

    time1 = time.time()
    for i in range(999):
        fib(i)
    time2 = time.time()

    time3 = time.time()
    for i in range(999):
        test_fib(i)
    time4 = time.time()

# Generated at 2022-06-12 05:44:11.708806
# Unit test for function curried_map
def test_curried_map():
    # map for factorial
    factorial = curried_map(lambda x: reduce(lambda a, b: a*b, range(1, x + 1), 1))

    assert factorial([1, 2, 3, 4, 5, 6, 7]) == [1, 2, 6, 24, 120, 720, 5040]

    # map for increasing
    increase_list = curried_map(increase)

    assert increase_list([1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]


# Generated at 2022-06-12 05:44:13.880786
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 2, [1, 2, 3]) == [3, 4, 5]



# Generated at 2022-06-12 05:44:19.281347
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x >= 2, [1, 2, 3]) == [2, 3]
    assert curried_filter(lambda x: x % 2, [1, 2, 3]) == [1, 3]
    assert curried_filter(lambda x: x % 2, [1,2,3,4,5]) == [1,3,5]


# Generated at 2022-06-12 05:44:30.001798
# Unit test for function cond
def test_cond():
    from random import randint
    from functools import partial

    odds = [randint(0, 100) for _ in range(randint(10, 20))]
    evens = [randint(0, 100) for _ in range(randint(10, 20))]

    result = cond([
        (lambda x: x % 2 == 0, lambda x: 'even'),
        (lambda x: x % 2 == 1, lambda x: 'odd'),
    ])(1)

    assert result == 'odd'

    result = cond([
        (lambda x: x % 2 == 0, lambda x: 'even'),
        (lambda x: x % 2 == 1, lambda x: 'odd'),
    ])(2)

    assert result == 'even'


# Generated at 2022-06-12 05:44:35.598457
# Unit test for function curry
def test_curry():
    """
    Unit test for function curry.
    """
    # All arguments already set
    assert curry(lambda x, y, z: x+y+z, 3)(1, 2, 3) == 6
    # One argument missing
    assert curry(lambda x, y, z: x+y+z, 3)(1, 2)(3)() == 6
    # Double curry
    curry_test = curry(lambda y, z: y+z, 2)(1)
    assert curry_test(2) == 3



# Generated at 2022-06-12 05:44:40.838734
# Unit test for function curried_filter
def test_curried_filter():
    """
    This function test curried_filter function
    """
    collection = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    actual_value = curried_filter(eq(3), collection)

    expected_value = [3]

    assert actual_value == expected_value



# Generated at 2022-06-12 05:44:44.401273
# Unit test for function find
def test_find():
    search_in = [1, 2, 3, 4]
    assert find(search_in, lambda x: x % 2 == 0) == 2
    assert find(search_in, lambda x: x > 4) is None


test_find()