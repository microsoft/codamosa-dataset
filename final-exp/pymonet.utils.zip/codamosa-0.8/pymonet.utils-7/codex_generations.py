

# Generated at 2022-06-12 05:36:10.933369
# Unit test for function memoize
def test_memoize():
    import random

    @memoize
    def f(x):
        return random.randint(0, 10)

    assert f(5) == f(5)

# Generated at 2022-06-12 05:36:15.921060
# Unit test for function cond
def test_cond():
    assert cond([(eq(1), identity), (eq(2), increase)], 1) == identity(1)
    assert cond([(eq(1), identity), (eq(2), increase)], 2) == increase(2)
    assert cond([(eq(1), identity)])(1) == identity(1)



# Generated at 2022-06-12 05:36:20.128250
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x == 3) == 3
    assert find([[1, 2, 3], [1, 2]], lambda x: len(x) == 2) == [1, 2]
    assert find([], identity) is None
    assert find([], lambda x: x > 10) is None


# Generated at 2022-06-12 05:36:27.622650
# Unit test for function cond
def test_cond():
    f = cond([
        (lambda x: x > 0, lambda x: 'big'),
        (lambda x: x == 0, lambda x: 'small'),
        (lambda x: True, lambda x: 'negative'),
    ])
    assert f(1) == 'big'
    assert f(0) == 'small'
    assert f(-1) == 'negative'
    assert f(2) == 'big'
    assert f(-5) == 'negative'
    assert f(10) == 'big'


# Generated at 2022-06-12 05:36:30.705636
# Unit test for function eq
def test_eq():
    assert eq(4, 4) == True
    assert eq(6, 10) == False



# Generated at 2022-06-12 05:36:32.863973
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(2), [1, 2, 3]) == [2]


# Generated at 2022-06-12 05:36:45.421515
# Unit test for function memoize
def test_memoize():
    # Define functions to test
    def sum_of_range(end):
        total = 0
        for n in range(end):
            total += n
        return total

    def factorial(end):
        total = 1
        for n in range(1, end + 1):
            total *= n
        return total

    # Define memoize function
    memoized_sum_of_range = memoize(sum_of_range)
    memoized_factorial = memoize(factorial)

    # Execute functions and tests result
    assert memoized_sum_of_range(10) == sum_of_range(10)
    assert memoized_sum_of_range(10) == sum_of_range(10)
    assert memoized_sum_of_range(113) == sum_of_range(113)
   

# Generated at 2022-06-12 05:36:49.214957
# Unit test for function cond
def test_cond():
    func = cond([
        (lambda x: x % 2 == 0, lambda x: x + 1),
        (lambda x: True, lambda x: x + 2),
    ])
    assert func(1) == 3
    assert func(2) == 3



# Generated at 2022-06-12 05:36:51.009599
# Unit test for function memoize
def test_memoize():
    # TODO: cause how to write test for memoize
    pass


# Generated at 2022-06-12 05:36:55.919915
# Unit test for function curried_map
def test_curried_map():
    my_list = [1, 2, 3, 4]
    assert curried_map(lambda x: x + 1, my_list) == [2, 3, 4, 5]
    assert curried_map(increase, my_list) == [2, 3, 4, 5]


# Generated at 2022-06-12 05:37:05.415474
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(
        lambda x: x * x,
        [1, 2, 3, 4]
    ) == [1, 4, 9, 16]

    assert curried_map(
        lambda x: x * x,
    )([1, 2, 3, 4]) == [1, 4, 9, 16]

    assert curried_map(
        lambda x: x * x,
    )(range(5)) == [0, 1, 4, 9, 16]

    assert curried_map(
        lambda x: x * x,
    )([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [0, 1, 4, 9, 16, 25, 36, 49, 64, 81, 100]



# Generated at 2022-06-12 05:37:07.443918
# Unit test for function memoize
def test_memoize():
  assert memoize(increase)(1) == 2
  assert memoize(increase)(1) == 2


# Generated at 2022-06-12 05:37:14.246342
# Unit test for function find
def test_find():
    assert find([], lambda _: False) is None
    assert find([], lambda _: True) is None
    assert find([1, 2, 3, 4, 5], eq(1)) == 1
    assert find([1, 2, 3, 4, 5], eq(2)) == 2
    assert find([1, 2, 3, 4, 5], eq(0)) is None



# Generated at 2022-06-12 05:37:17.875402
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-12 05:37:20.065309
# Unit test for function eq
def test_eq():
    assert eq(1, 2) == False
    assert eq(1, 1) == True
    assert eq(1)(1) == True



# Generated at 2022-06-12 05:37:26.587038
# Unit test for function memoize
def test_memoize():
    not_memoized = lambda x: x + 1
    memoized = memoize(not_memoized)

    assert memoized(1) == not_memoized(1)
    assert memoized(1) == not_memoized(1)
    assert memoized(1) == not_memoized(1)
    assert memoized(1) == not_memoized(1)


# Generated at 2022-06-12 05:37:31.457804
# Unit test for function curried_filter
def test_curried_filter():
    """
    Test cond function.
    """
    example_list = [1, 2, 3, 4, 5]
    execute_list = curried_filter(lambda x: x < 3, example_list)
    assert execute_list == [1, 2]


if __name__ == "__main__":
    test_curried_filter()

# Generated at 2022-06-12 05:37:34.579198
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-12 05:37:37.855261
# Unit test for function curried_map
def test_curried_map():
    def double_map(collection:List[int]):
        return curried_map(increase, collection)

    assert double_map([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-12 05:37:42.621600
# Unit test for function cond
def test_cond():
    result = cond(
        [
            (lambda x: x == "A", lambda x: "hi"),
            (lambda x: x == "B", lambda x: "ho"),
            (lambda x: x == "C", lambda x: "hu")
        ]
    )("A")
    assert (result == "hi")



# Generated at 2022-06-12 05:37:52.601183
# Unit test for function memoize
def test_memoize():
    import time

    @memoize
    def heavy_computation(value):
        time.sleep(1)
        return value ** 2

    print('start')
    start = time.time()
    heavy_computation(5)
    heavy_computation(5)
    end = time.time()
    print('end')

    assert end - start < 2

# Generated at 2022-06-12 05:38:01.313748
# Unit test for function cond
def test_cond():
    def multiply_by_2(value):
        return value * 2

    def multiply_by_3(value):
        return value * 3

    multiply = cond([
        (lambda value: value % 2 == 0, multiply_by_2),
        (lambda value: True, multiply_by_3)
    ])
    assert multiply(2) == 4
    assert multiply(3) == 9

    # Check behavior on None result
    def multiply_by_3(value):
        return value * 3

    multiply = cond([
        (lambda value: value % 2 == 0, multiply_by_2),
        (lambda value: value % 3 == 0, multiply_by_3)
    ])
    assert multiply(5) is None

    # Check behavior on None result

# Generated at 2022-06-12 05:38:04.656350
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x % 2 == 0) == 2

    assert find([1, 3, 5], lambda x: x % 2 == 0) is None



# Generated at 2022-06-12 05:38:07.005749
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True, 'eq function not working properly'



# Generated at 2022-06-12 05:38:11.290124
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert curried_map(increase)([1, 2, 3, 4]) == [2, 3, 4, 5]



# Generated at 2022-06-12 05:38:13.169568
# Unit test for function cond
def test_cond():
    assert cond([
        (eq(3), lambda x: True),
        (eq(4), lambda x: False),
        ])

# Generated at 2022-06-12 05:38:17.159310
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-12 05:38:21.530463
# Unit test for function curried_filter
def test_curried_filter():
    assert [1, 3, 5] == curried_filter(lambda x: x % 2 == 1, [1, 2, 3, 4, 5])

    assert [1, 3] == curried_filter(lambda x: x % 2 == 1)([1, 2, 3])


# Generated at 2022-06-12 05:38:22.610808
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    

# Generated at 2022-06-12 05:38:24.970131
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-12 05:38:49.639527
# Unit test for function cond
def test_cond():
    def is_even(number: int):
        return number % 2 == 0

    def is_negative(number: int):
        return number < 0

    def add_three(number: int):
        return number + 3

    def subtract_eight(number: int):
        return number - 8

    def multiply_by_five(number: int):
        return number * 5

    condition_list = [
        (is_negative, subtract_eight),
        (is_even, add_three),
    ]

    transform_number = cond(condition_list)

    assert transform_number(1) == 5
    assert transform_number(-10) == -18
    assert transform_number(-1) == 5

# Generated at 2022-06-12 05:38:57.298460
# Unit test for function find
def test_find():
    assert find(None, None) is None

    assert find([1, 2, 3], lambda num: num == 1) == 1
    assert find([1, 2, 3], lambda num: num == 4) is None

    assert find([(1, 1), (2, 2)], lambda item: eq(1, item[0])) == (1, 1)
    assert find([(1, 1), (2, 2)], lambda item: eq(1, item[1])) is None



# Generated at 2022-06-12 05:39:03.468817
# Unit test for function curry
def test_curry():
    def add(x, y):
        return x + y

    def add3(x, y, z):
        return x + y + z

    assert curry(add)(1, 2) == 3
    assert curry(add3)(1, 2, 3) == 6
    assert curry(add3)(1)(2, 3) == 6



# Generated at 2022-06-12 05:39:11.766268
# Unit test for function eq
def test_eq():
    assert eq(1, 1), 'The eq function should return True, but returned False'
    assert eq('a', 'a'), 'The eq function should return True, but returned False'
    assert eq(False, False), 'The eq function should return True, but returned False'
    assert eq(None, None), 'The eq function should return True, but returned False'
    assert not eq('a', 'b'), 'The eq function should return False, but returned True'
    assert not eq(1, 2), 'The eq function should return False, but returned True'
    assert not eq(True, False), 'The eq function should return False, but returned True'
    assert not eq(False, True), 'The eq function should return False, but returned True'
    print("test_eq() passed.")



# Generated at 2022-06-12 05:39:22.876691
# Unit test for function curried_map
def test_curried_map():
    """
    Check if curried_map works like original map
    """
    assert map(lambda x: x + 1, [1, 2, 3]) == curried_map(lambda x: x + 1, [1, 2, 3])
    assert map(lambda x: x + 1, [1, 2, 3]) == curried_map(lambda x: x + 1)([1, 2, 3])
    assert map(lambda x: x + 1, [1, 2, 3]) == curried_map(
        lambda x: x + 1,
        curried_map(lambda x: x + 1, [1, 2, 3])
    )

# Generated at 2022-06-12 05:39:28.174894
# Unit test for function memoize
def test_memoize():
    def factorial(value):
        assert isinstance(value, int)
        return value if value <= 1 else factorial(value - 1) * value

    memoized_factorial = memoize(factorial)
    assert memoized_factorial(5) == 120
    assert memoized_factorial(5) == 120


# Generated at 2022-06-12 05:39:37.036888
# Unit test for function curried_filter
def test_curried_filter():
    test_list = [1, 2, 3, 4]
    assert curried_filter(_eq(2), test_list) == [2]
    assert curried_filter(_gt(2), test_list) == [3, 4]
    assert curried_filter(_gte(2), test_list) == [2, 3, 4]
    assert curried_filter(_lt(3), test_list) == [1, 2]
    assert curried_filter(_lte(3), test_list) == [1, 2, 3]
    assert curried_filter(_in([3, 4]), test_list) == [3, 4]
    assert curried_filter(_nin([3, 4]), test_list) == [1, 2]

# Generated at 2022-06-12 05:39:48.416523
# Unit test for function cond
def test_cond():
    # for assert
    # +1
    def plus_1(value):
        return value + 1

    # +2
    def plus_2(value):
        return value + 2

    # +3
    def plus_3(value):
        return value + 3

    # +4
    def plus_4(value):
        return value + 4

    # create function and call cond to it
    plus = cond([
        (lambda x: x < 5, plus_1),
        (lambda x: x < 10, plus_2),
        (lambda x: x < 15, plus_3),
        (lambda x: True, plus_4)
    ])
    assert plus(2) == 3
    assert plus(7) == 9
    assert plus(12) == 15
    assert plus(17) == 21



# Generated at 2022-06-12 05:39:51.803287
# Unit test for function memoize
def test_memoize():
    @memoize
    def memoized_fn(argument: int) -> int:
        print('\nInvoke old function')
        return argument * argument

    assert memoized_fn(1) == 1
    assert memoized_fn(2) == 4
    assert memoized_fn(1) == 1



# Generated at 2022-06-12 05:39:54.656874
# Unit test for function find
def test_find():
    assert find([1,2,3], eq(2)) == 2
    assert find([1,2,3], eq(5)) is None



# Generated at 2022-06-12 05:40:21.395534
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3, 4]) == [2, 3, 4, 5]
    assert curried_map(lambda x: x + 1)([1, 2, 3, 4]) == [2, 3, 4, 5]
    assert curried_map(lambda x: x + 1, (1, 2, 3, 4)) == (2, 3, 4, 5)
    assert curried_map(lambda x: x + 1)((1, 2, 3, 4)) == (2, 3, 4, 5)
    assert curried_map(lambda x: x + 1, {1, 2, 3, 4}) == {2, 3, 4, 5}

# Generated at 2022-06-12 05:40:23.123074
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-12 05:40:29.371511
# Unit test for function cond
def test_cond():
    def first_bigger(x, y):
        return x > y

    def second_bigger(x, y):
        return y > x

    def same(x, y):
        return x == y

    result = cond([
        (first_bigger, lambda x, y: '%d is bigger than %s' % (x, y)),
        (second_bigger, lambda x, y: '%d is less than %s' % (x, y)),
        (same, lambda x, y: '%d is equal to %s' % (x, y))])

    assert result(5, 7) == '5 is less than 7'
    assert result(7, 5) == '7 is bigger than 5'
    assert result(5, 5) == '5 is equal to 5'

# Generated at 2022-06-12 05:40:37.870410
# Unit test for function curried_filter
def test_curried_filter():
    def is_even(value):
        return value % 2 == 0

    filtered = curried_filter(is_even)([1, 2, 3, 4, 5, 6, 7, 8, 9])
    filtered_equal = curried_filter(is_even, [1, 2, 3, 4, 5, 6, 7, 8, 9])

    assert filtered == filtered_equal == [2, 4, 6, 8]
    assert curried_filter(lambda _: True)([1, 2, 3, 4]) == [1, 2, 3, 4]



# Generated at 2022-06-12 05:40:42.898110
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        print("Calculating {} + {}".format(a, b))
        return a + b

    fast_add = memoize(add)
    fast_add(1, 2) # Calculating 1 + 2
    fast_add(1, 2)
    fast_add(2, 3) # Calculating 2 + 3
    fast_add(2, 3)
    fast_add(1, 2) # key is eq, so result is taken from cache



# Generated at 2022-06-12 05:40:48.087139
# Unit test for function memoize
def test_memoize():
    """
    Test memoize function
    """
    @memoize
    def word_count(text):
        return sum(1 for _ in text.split(' '))

    text = 'Is curry function curry function curry function curry function curry function curry function'
    assert word_count(text) == 7
    assert len(word_count.__closure__[0].cell_contents) == 1
    assert word_count.__closure__[0].cell_contents[0][0] == text
    assert word_count.__closure__[0].cell_contents[0][1] == 7



# Generated at 2022-06-12 05:40:50.269735
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)(range(10)) == [0, 2, 4, 6, 8]



# Generated at 2022-06-12 05:40:54.818462
# Unit test for function curried_filter
def test_curried_filter():
    """
    Testing curried_filter function
    """
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5]) == [2, 4]



# Generated at 2022-06-12 05:40:57.001481
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y, z: x * y * z)(1)(2)(3) == 6



# Generated at 2022-06-12 05:41:03.250380
# Unit test for function cond
def test_cond():
    assert cond([
        (eq(True), lambda: 'one'),
        (eq(True), lambda: 'two'),
        (eq(False), lambda: 'three'),
    ])(False) == 'three'

    assert cond([
        (eq(False), lambda: 'one'),
        (eq(True), lambda: 'two'),
        (eq(False), lambda: 'three'),
    ])(False) == 'two'

    assert cond([
        (eq(False), lambda: 'one'),
        (eq(False), lambda: 'two'),
        (eq(True), lambda: 'three'),
    ])(True) == 'three'



# Generated at 2022-06-12 05:41:57.388256
# Unit test for function memoize
def test_memoize():
    """
    Unit test for memoize().
    """
    assert memoize(increase)(1) == 2

# Generated at 2022-06-12 05:42:02.140341
# Unit test for function memoize
def test_memoize():
    # Should be [0,1,1,2,3,5]
    fn = lambda x: (0 if(x == 0) else 1 if(x == 1) else fn(x - 1) + fn(x - 2))
    fibonacci = memoize(fn)
    for i in [0, 1, 2, 3, 4, 5]:
        assert (fibonacci(i) == i)



# Generated at 2022-06-12 05:42:05.670582
# Unit test for function curried_filter
def test_curried_filter():
    list_ = [1, 2, 3, 4, 5, 6]
    filter_ = lambda x: x > 5
    expected_result = [6]
    actual_result = curried_filter(filter_, list_)
    assert expected_result == actual_result


# Generated at 2022-06-12 05:42:10.336170
# Unit test for function curry
def test_curry():
    def sum3(x, y, z):
        return x + y + z

    assert curry(sum3)(1)(2)(3) == 6
    assert curry(sum3, 3)(1, 2, 3) == 6
    add_one_after_multiply2 = curry(lambda x, y: x * y + 1, 2)
    assert add_one_after_multiply2(2, 5) == 11
    asser

# Generated at 2022-06-12 05:42:18.628070
# Unit test for function cond
def test_cond():
    not_nested_cond_function = cond([
        (lambda x: x > 2, lambda x: x + 10),
        (lambda x: x > 0, lambda x: x + 1)
    ])
    assert not_nested_cond_function(3) == 13
    assert not_nested_cond_function(1) == 2
    assert not_nested_cond_function(-1) is None

    nested_cond_function = cond([
        (lambda x: x > 2, lambda x: not_nested_cond_function(x)),
        (lambda x: x > 0, lambda x: not_nested_cond_function(x))
    ])
    assert nested_cond_function(3) == 13
    assert nested_cond_function(1) == 2
    assert nested_cond_function(-1) is None

# Generated at 2022-06-12 05:42:27.543930
# Unit test for function find
def test_find():
    listOfOneValue = [10, 20, 10]
    listOfKeys = [5, 10, 20]
    for listOfKeysIndex in range(0, len(listOfKeys)):
        assert eq(
            find(
                listOfOneValue,
                lambda value: eq(value, listOfKeys[listOfKeysIndex])
            ),
            listOfKeys[listOfKeysIndex]
        )
    assert find(listOfOneValue, lambda value: eq(value, 30)) == None
    assert find(listOfOneValue, lambda value: eq(value, None)) == None
    assert find(listOfOneValue, None) == None
    assert find(None, lambda value: eq(value, None)) == None



# Generated at 2022-06-12 05:42:30.652805
# Unit test for function memoize
def test_memoize():
    @memoize
    def f(argument):
        return int(argument * 2)

    assert f('10') == 20
    assert f('10') == 20
    assert len(f.__closure__) == 2

# Generated at 2022-06-12 05:42:33.455453
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq('a', 'b')
    assert eq('a', 'a')



# Generated at 2022-06-12 05:42:35.373385
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 10)([1, 2, 3, 15, 20, 10]) == [15, 20]



# Generated at 2022-06-12 05:42:37.942782
# Unit test for function curried_filter
def test_curried_filter():
    list = [1, 2, 3, 4, 5]
    assert curried_filter(lambda x: x < 3)(list) == [1, 2]


# Generated at 2022-06-12 05:43:47.686450
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-12 05:43:53.089167
# Unit test for function curried_filter
def test_curried_filter():
    assert [1, 2, 3] == list(curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4]))
    assert [2, 4] == list(curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5]))
    assert [1, 3, 5] == list(curried_filter(lambda x: x % 2 != 0, [1, 2, 3, 4, 5]))



# Generated at 2022-06-12 05:44:00.058008
# Unit test for function eq
def test_eq():
    # assert eq(1, 1) == True
    assert eq(1)(1) == True
    assert eq(1, 2) == False
    assert eq(1)(2) == False
    # assert eq([1, 2], [1, 2]) == True
    assert eq([1, 2])([1, 2]) == True
    assert eq([1, 2], [1]) == False
    assert eq([1, 2])([1]) == False



# Generated at 2022-06-12 05:44:03.090559
# Unit test for function curried_filter
def test_curried_filter():
    assert(curried_filter(lambda x: x % 2)(list(range(10))) == [1, 3, 5, 7, 9])



# Generated at 2022-06-12 05:44:04.873957
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 0)



# Generated at 2022-06-12 05:44:06.701782
# Unit test for function curried_map
def test_curried_map():
    map_ = curried_map(lambda x: x + 1)
    print(map_([1, 2, 3]))



# Generated at 2022-06-12 05:44:11.757872
# Unit test for function memoize
def test_memoize():
    def fn(*argument):
        return argument[0]
    memoized_fn = memoize(fn)
    assert memoized_fn(2) == 2
    assert memoized_fn(2) == 2
    assert memoized_fn(2) == 2
    assert memoized_fn(1) == 1
    assert memoized_fn(2) == 2

# Generated at 2022-06-12 05:44:15.346735
# Unit test for function curried_map
def test_curried_map():
    assert [1, 2, 3] == curried_map(lambda x: x + 1, [0, 1, 2])
    assert [2, 3, 4] == curried_map(lambda x: x + 1)([1, 2, 3])

# Generated at 2022-06-12 05:44:20.255495
# Unit test for function find
def test_find():
    """
    Test function find
    """
    test_dict = [{'name': 'Sasha'}, {'name': 'Alex'}]
    result = find(test_dict, lambda item: item.get('name') == 'Sasha')
    assert result == {'name': 'Sasha'}



# Generated at 2022-06-12 05:44:25.407275
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: True)([1, 2, 3]) == [1, 2, 3]
    assert curried_filter(lambda x: False)([1, 2, 3]) == []
    assert curried_filter(lambda x: x > 2)([1, 2, 3]) == [3]

