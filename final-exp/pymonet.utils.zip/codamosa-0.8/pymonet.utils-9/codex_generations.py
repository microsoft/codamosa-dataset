

# Generated at 2022-06-12 05:36:14.330607
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1, None)
    assert not eq(None, 1)
    assert eq(None, None)
    assert eq("", "")
    assert eq("1", "1")
    assert not eq("1", "2")



# Generated at 2022-06-12 05:36:18.585539
# Unit test for function curried_filter
def test_curried_filter():
    def is_even(x):
        return x % 2 == 0
    assert curried_filter(is_even)([1, 2, 3, 4, 5]) == [2, 4]
    assert [1, 2] == curried_filter(eq(1))([1, 2])


# Generated at 2022-06-12 05:36:28.171261
# Unit test for function curry
def test_curry():
    """
    Test application of curry decorator on functions
    """
    assert callable(curry(identity))
    assert callable(curry(identity, 1))
    assert identity(5) == curry(identity)(5)
    assert identity(5) == curry(identity, 1)(5)

    @curry
    def increment_by(x, y):
        return x + y

    def increment_by_1(x):
        return x + 1

    assert callable(increment_by)
    assert increment_by_1(10) == increment_by(1)(10)


# Unit tests for identity function

# Generated at 2022-06-12 05:36:31.546789
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-12 05:36:33.762996
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-12 05:36:37.957281
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(2)(2) == 4
    assert curry(lambda x, y, z: x + y + z)(2)(2)(2) == 6



# Generated at 2022-06-12 05:36:45.175032
# Unit test for function cond
def test_cond():
    def cond_equal_1(number: int) -> bool:
        return number == 1

    def cond_equal_2(number: int) -> bool:
        return number == 2

    def cond_equal_3(number: int) -> bool:
        return number == 3

    def cond_equal_4(number: int) -> bool:
        return number == 4

    def cond_equal_5(number: int) -> bool:
        return number == 5

    assert 1 == pipe(1, cond([
        (cond_equal_1, identity),
        (cond_equal_2, increase),
        (cond_equal_3, increase),
        (cond_equal_4, increase),
    ]))


# Generated at 2022-06-12 05:36:51.090698
# Unit test for function curried_filter
def test_curried_filter():
    # arrange
    collection = ["", "1", "2"]
    filterer = lambda x: x != ""

    # act
    # [x != ""] is equal to (lambda x: x != "")
    # curried_filter is curried function can be also maped with curried_filter(filterer)(collection)
    result = curried_filter([x != ""])(collection)

    # assert
    assert result == ["1", "2"]



# Generated at 2022-06-12 05:36:53.969466
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-12 05:37:01.399894
# Unit test for function memoize
def test_memoize():
    # Create a factorial function.
    def factorial(n):
        print("Calculating {}".format(n))
        if n == 0:
            return 1
        else:
            return n * factorial(n-1)

    memoized_factorial = memoize(factorial)

    print(memoized_factorial(8))
    print(memoized_factorial(8))
    print(memoized_factorial(10))
    print(memoized_factorial(10))



# Generated at 2022-06-12 05:37:10.712439
# Unit test for function cond
def test_cond():
    test = cond([
        (lambda x: x == 0, lambda _: 'zero'),
        (lambda x: x == 1, lambda _: 'one'),
        (lambda x: x == 2, lambda _: 'two'),
        (lambda x: x == 3, lambda _: 'three'),
        (lambda x: True, lambda _: 'other'),
    ])
    assert test(0) == 'zero'
    assert test(1) == 'one'
    assert test(2) == 'two'
    assert test(3) == 'three'
    assert test(4) == 'other'



# Generated at 2022-06-12 05:37:15.987135
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x > 5, lambda x: x + 1),
        (lambda x: x <= 5, lambda x: x + 2)
    ])(6) == 7

    assert cond([
        (lambda x: x > 5, lambda x: x + 1),
        (lambda x: x <= 5, lambda x: x + 2)
    ])(4) == 6



# Generated at 2022-06-12 05:37:18.404573
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x % 2 == 0) == 2



# Generated at 2022-06-12 05:37:20.983853
# Unit test for function eq
def test_eq():
    assert eq(1)(1)
    assert not eq(1)(2)
    assert not eq(1)(None)
    assert not eq(None)(1)



# Generated at 2022-06-12 05:37:25.096972
# Unit test for function curried_map
def test_curried_map():
    listForMap = [1, 2, 3, 4, 5]
    assert curried_map(increase)(listForMap) == listForMap.__mul__(increase)


# Generated at 2022-06-12 05:37:36.178689
# Unit test for function eq
def test_eq():
    assert eq(1, 2) == False, 'Function eq should return False'
    assert eq(1, 1) == True, 'Function eq should return True'
    assert eq(eq(1, 2), False) == True, 'Function eq should return True'
    assert eq(eq(eq(eq(eq(eq(eq(1, 1), 1), 1), 1), 1), 1), 1) == True,\
        'Function eq should return True'
    assert eq(eq(eq(eq(eq(eq(eq(1, 2), 1), 1), 1), 1), 1), 1) == False,\
        'Function eq should return False'

    print('Tests for function eq are passed!')


# Generated at 2022-06-12 05:37:40.237489
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x > 2) == 3
    assert find([1, 2, 3], lambda x: x < 0) is None



# Generated at 2022-06-12 05:37:44.287292
# Unit test for function cond
def test_cond():
    increment_if_less_than_5 = cond([
        [lambda x: x >= 5, lambda: 'second value'],
        [lambda x: True, lambda x: x + 1]
    ])
    assert increment_if_less_than_5(2) == 3
    assert increment_if_less_than_5(7) == 'second value'

# Generated at 2022-06-12 05:37:49.851540
# Unit test for function memoize
def test_memoize():
    def not_memoized(x):
        if x % 2 == 0:
            return 'even'
        else:
            return 'odd'

    assert(not_memoized(1) == 'odd')
    assert(not_memoized(2) == 'even')

    memoized = memoize(not_memoized)
    assert(memoized(1) == 'odd')
    assert(memoized(1) == 'odd')
    assert(memoized(2) == 'even')
    assert(memoized(2) == 'even')
    assert(memoized(3) == 'odd')
    assert(memoized(3) == 'odd')
    assert(memoized(4) == 'even')
    assert(memoized(4) == 'even')



# Generated at 2022-06-12 05:37:53.995944
# Unit test for function memoize
def test_memoize():
    def fn(number):
        return number + 10
    fn = memoize(fn)
    assert fn.__code__.co_argcount == 1
    assert fn(1) == 11
    assert fn(1) == 11
    assert fn(2) == 12
    assert fn(2) == 12



# Generated at 2022-06-12 05:38:11.194304
# Unit test for function memoize
def test_memoize():
    def product(n):
        return n * n

    memoized_product = memoize(product)
    # check product values
    assert memoized_product(6) == 36
    assert memoized_product(6) == 36
    assert memoized_product(6) == 36
    assert memoized_product(6) == 36
    # check if memoize doesn't produces additional calls
    memoized_product_call_counter = 0
    def memoized_product_old(x):
        nonlocal memoized_product_call_counter
        memoized_product_call_counter += 1
        return product(x)
    assert memoize(memoized_product_old, eq)(6) == 36
    assert memoize(memoized_product_old, eq)(6) == 36

# Generated at 2022-06-12 05:38:15.958859
# Unit test for function curry
def test_curry():
    def sum(*args):
        res = 0
        for arg in args:
            res += arg
        return res

    curried_sum = curry(sum, 2)
    assert curried_sum(1)(2) == 3
    assert curried_sum(1, 2) == 3
    assert curried_sum(2, 3) == 5

    curried_sum = curry(sum, 2)
    assert curried_sum(1)(2) == 3
    assert curried_sum(1, 2) == 3
    assert curried_sum(2, 3) == 5


# Generated at 2022-06-12 05:38:21.531478
# Unit test for function curried_filter
def test_curried_filter():
    list_a = [1, 2, 3]
    list_b = [4, 5, 6]
    list_c = [7, 8, 9]
    input_list = [list_a, list_b, list_c]
    assert curried_filter(lambda x: x[0] == 1, input_list) == [list_a]



# Generated at 2022-06-12 05:38:29.955742
# Unit test for function curry
def test_curry():
    a = curry(lambda a, b, c: a + b + c)
    assert a(1, 2, 3) == 6
    assert a(1, 2)(3) == 6
    assert a(1)(2, 3) == 6
    assert a(1)(2)(3) == 6
    b = curry(lambda a, b, c, d, e: a + b + c + d + e)
    assert b(1, 2, 3, 4, 5) == 15
    assert b(1)(2, 3)(4)(5) == 15
    assert b(1)(2)(3, 4)(5) == 15



# Generated at 2022-06-12 05:38:38.072545
# Unit test for function find
def test_find():
    """
    Function to test find function.
    """
    assert find([], lambda item: False) is None, 'Should return None'
    assert find([1], eq(1)) == 1, 'Should return 1'
    assert find([1], eq(2)) is None, 'Should return None'
    assert find([1, 2, 3], eq(2)) == 2, 'Should return 2'
    assert find([1, 2, 3], eq(4)) is None, 'Should return None'
    print('test find done')



# Generated at 2022-06-12 05:38:44.506168
# Unit test for function curried_filter
def test_curried_filter():
    test_list = [0, 1, 2, 3, 4, 5, 6]

    assert curried_filter(eq(1), test_list) == [1]
    assert curried_filter(eq(2), test_list) == [2]

    assert curried_filter(eq(1), test_list)(1) == [1]
    assert curried_filter(eq(2), test_list)(2) == [2]



# Generated at 2022-06-12 05:38:48.029674
# Unit test for function curried_filter
def test_curried_filter():
    numbers = [1, 2, 3, 4, 5]
    assert curried_filter(eq(2), numbers) == [2]
    assert curried_filter(eq(9), numbers) == []


# Generated at 2022-06-12 05:38:58.170341
# Unit test for function eq
def test_eq():
    assert eq(3, 3)
    assert not eq(4, 3)
    assert not eq('a', 'b')
    assert eq('a', 'a')
    assert not eq('a', 4)
    assert not eq('a', True)
    assert not eq(None, False)

    assert eq(3)(3)
    assert not eq(4)(3)
    assert not eq('a')('b')
    assert eq('a')('a')
    assert not eq('a')(4)
    assert not eq('a')(True)
    assert not eq(None)(False)

    assert eq(3)(3)(3)
    assert not eq(4)(3)(3)
    assert not eq('a')('b')('a')
    assert eq('a')('a')('a')
   

# Generated at 2022-06-12 05:39:05.438628
# Unit test for function eq
def test_eq():
    assert True == eq(1, 1)
    assert False == eq(10, 1)
    assert False == eq(3, 24)
    assert True == eq(3, 3)
    assert True == eq([1, 2], [1, 2])
    assert False == eq([1, 2], [2, 1])
    assert False == eq([1, 3], [1, 2])



# Generated at 2022-06-12 05:39:09.583361
# Unit test for function curried_filter
def test_curried_filter():
    # condition
    def filter_by(condition, value):
        return value < condition

    # array
    data = [1, 2, 3, 4, 5]
    # filter
    data_filtered = curried_filter(filter_by(3))(data)

    assert data_filtered == [1, 2]



# Generated at 2022-06-12 05:39:26.198911
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(2, 2) == True
    assert eq(1, 2) == False
    assert eq(2, 1) == False



# Generated at 2022-06-12 05:39:33.391124
# Unit test for function curried_filter
def test_curried_filter():
    """
    Function curried_filter
    :return:
    """
    assert curried_filter(lambda x: x > 1, [1, 2, 3]) == [2, 3]
    assert curried_filter(lambda x: x < 3, range(10)) == [0, 1, 2]
    assert curried_filter(lambda x: x > 0, range(-10, 10)) == [1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-12 05:39:40.830923
# Unit test for function memoize
def test_memoize():
    def slow_add(x, y):
        import time
        time.sleep(.5)
        return x + y
    memoized_slow_add = memoize(slow_add)
    time_before = time.time()
    assert memoized_slow_add(1, 2) == 3
    assert memoized_slow_add(1, 2) == 3
    time_after = time.time()
    direct_call_time = time_after - time_before
    assert direct_call_time < .5

# Generated at 2022-06-12 05:39:44.768847
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter([1, 2, 3, 4])(eq(2)) == [2]
    assert curried_filter(eq(2))([1, 2, 3, 4]) == [2]
    # Unit test for function curried_map
    assert curried_map(eq(2))([1, 2, 3, 4]) == [False, True, False, False]
    assert curried_map([1, 2, 3, 4])(eq(2)) == [False, True, False, False]
    assert isinstance(curried_map(eq(2)), curry)



# Generated at 2022-06-12 05:39:51.371329
# Unit test for function memoize
def test_memoize():
    old_add_5 = lambda value: value + 5
    add_5 = memoize(old_add_5)

    assert old_add_5(2) == add_5(2)
    assert old_add_5(2) == add_5(2)
    assert old_add_5(3) == add_5(3)
    assert old_add_5(3) == add_5(3)
    assert old_add_5(2) == add_5(2)
    assert old_add_5(3) == add_5(3)



# Generated at 2022-06-12 05:39:54.656707
# Unit test for function memoize
def test_memoize():
    @memoize
    def sum(value):
        return value + 1

    assert sum(1) == 2
    assert sum(1) == 2



# Generated at 2022-06-12 05:39:56.662607
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x.isupper(), 'AaBbCc') == ['A', 'B', 'C']


# Generated at 2022-06-12 05:40:03.875078
# Unit test for function eq
def test_eq():
    assert eq(2, 4) is False
    assert eq(2, 2) is True
    assert eq('e', 'f') is False
    assert eq('e', 'e') is True
    assert eq('e', 'E') is False
    assert eq(eq, eq) is True
    assert eq([1, 2, 3], [1, 2, 3]) is True
    assert eq([1, 2, 3], [1, 2, 3, 4]) is False



# Generated at 2022-06-12 05:40:05.220233
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 2) == 2



# Generated at 2022-06-12 05:40:13.590397
# Unit test for function curried_filter
def test_curried_filter():
    local_list = [1, 2, 3, 4]
    assert curried_filter(lambda x: x < 3)(local_list) == [1, 2]

    assert curried_filter(lambda x: x < 3)([1, 2, 3, 4]) == [1, 2]

    assert curried_filter(lambda x: x < 3)([1, 2, 3, 4]) == [1, 2]

    assert curried_filter(lambda x: x < 3)([1, 2, 3, 4]) == [1, 2]



# Generated at 2022-06-12 05:40:29.749560
# Unit test for function memoize
def test_memoize():
    """
    Test function `memoize`.
    """

    def f(x):
        return x + 1

    def g(x):
        return x + 1

    def h(x):
        return x + 1

    memoized_f = memoize(f)
    assert memoized_f(1) == 2
    assert memoized_f(1) == 2

    memoized_g = memoize(g)
    assert memoized_g(1) == 2
    assert memoized_g(1) == 2

    memoized_h = memoize(h, key=int)
    assert memoized_h(1) == 2
    assert memoized_h(1.) == 2
    assert memoized_h(1) == 2
    assert memoized_h(1.) == 2



# Generated at 2022-06-12 05:40:34.247769
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x ** 2, [1, 2, 3]) == [1, 4, 9]
    assert curried_map(lambda x: x ** 2, range(100)) == list(map(lambda x: x ** 2, range(100)))



# Generated at 2022-06-12 05:40:39.571982
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([0, 1, 2]) == [1, 2, 3]
    assert curried_map(lambda x: x + 1)([0, 1, 2]) == [1, 2, 3]
    assert curried_map(lambda x: x + 1, [0, 1, 2]) == [1, 2, 3]



# Generated at 2022-06-12 05:40:45.886830
# Unit test for function eq
def test_eq():
    assert eq(2, 2)
    assert not eq(2, 1)
    assert not eq(1, 2)
    assert not eq(2, 3)

    eq1 = eq(1)
    assert eq1(1)
    assert not eq1(2)
    assert not eq1(3)
    assert not eq1(0)

    eq2 = eq(2)
    assert not eq2(1)
    assert eq2(2)
    assert not eq2(3)
    assert not eq2(0)



# Generated at 2022-06-12 05:40:47.623818
# Unit test for function eq
def test_eq():
    assert eq(1)(1) == True
    assert eq(1)(1, 2) == False

# Generated at 2022-06-12 05:40:54.748092
# Unit test for function cond
def test_cond():
    def condition_1(param: int) -> bool:
        return param == 1

    def condition_2(param: int) -> bool:
        return param == 2

    def condition_3(param: int) -> bool:
        return param == 3

    execute_1 = lambda _: 'First'
    execute_2 = lambda _: 'Second'
    execute_3 = lambda _: 'Third'

    execute_other = lambda _: 'Some thing else'

    def result_1(param):
        return cond([
            (condition_1, execute_1),
            (condition_2, execute_2),
            (condition_3, execute_3),
        ])(param)

    test_1 = result_1(1)
    assert test_1 == execute_1(1)

    test_2 = result_1(2)

# Generated at 2022-06-12 05:40:56.952888
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False



# Generated at 2022-06-12 05:40:59.363678
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None


# Generated at 2022-06-12 05:41:02.539470
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False



# Generated at 2022-06-12 05:41:04.510760
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-12 05:41:32.196766
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 3, 4, 5]
    filterer = lambda item: item % 2 == 0
    assert curried_filter(filterer)(collection) == \
        curried_filter(filterer, collection)



# Generated at 2022-06-12 05:41:37.070041
# Unit test for function memoize
def test_memoize():
    print('test memoize')
    print('cached:', memoize(identity)(2))
    print('cached:', memoize(identity)(2))
    print('cached:', memoize(identity)(3))
    print('cached:', memoize(identity)(3))
    print('cached:', memoize(identity)(2))



# Generated at 2022-06-12 05:41:40.149305
# Unit test for function eq
def test_eq():
    assert eq('key', 'key') == True
    assert eq('value', 'key') == False
    assert eq(1, 1) == True
    assert eq(1, 2) == False



# Generated at 2022-06-12 05:41:44.826900
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)
    assert eq(1, 2)(1)
    assert not eq(1, 2)(2)
    assert eq(1)(2)(1)
    assert not eq(1)(2)(2)



# Generated at 2022-06-12 05:41:55.073759
# Unit test for function find
def test_find():
    collection = [
        {'id': 1, 'title': 'Севастополь'},
        {'id': 2, 'title': 'Владивосток'},
        {'id': 3, 'title': 'Астрахань'},
        {'id': 4, 'title': 'Пермь'},
    ]
    assert find(collection, lambda item: item['id'] == 2) == {'id': 2, 'title': 'Владивосток'}
    assert find(collection, lambda item: item['id'] == 5) is None
    assert find([], lambda item: item['id'] == 5) is None


# Generated at 2022-06-12 05:42:00.290933
# Unit test for function eq
def test_eq():
    """
    Test for function eq

    :param none:
    :type none: none
    :returns: AssertionError: if tests are failed
    :rtype: AssertionError
    """
    assert eq(1, 1), 'Equal values should be equal'
    assert not eq(1, '1'), 'Not equal value should be not equal'
    assert eq('test', 'test'), 'Equal values should be equal'
    assert not eq('test', 'test1'), 'Not equal value should be not equal'
    assert eq('test', 'test', eq), 'Equal values should be equal'
    assert not eq('test', 'test1', eq), 'Not equal value should be not equal'



# Generated at 2022-06-12 05:42:08.352328
# Unit test for function curry
def test_curry():
    # condition_function, execute_function
    condition_list = [
        (lambda x: x < 18, lambda x: 'child'),
        (lambda x: x >= 18 and x <= 65, lambda x: 'adult'),
        (lambda x: x > 65, lambda x: 'old')
    ]

    curried_cond = curry(cond(condition_list))
    assert curried_cond(1) == 'child'
    assert curried_cond(36) == 'adult'
    assert curried_cond(99) == 'old'

    is_child = curried_cond(1) == 'child'
    is_adult = curried_cond(100) == 'adult'
    assert is_child is True
    assert is_adult is False



# Generated at 2022-06-12 05:42:12.418094
# Unit test for function memoize
def test_memoize():
    """
    Test function memoize.

    :returns: None
    :rtype: None
    """
    def foo(x):
        print('foo was called')
        return x
    memoized = memoize(foo)

    foo(0)
    foo(0)
    foo(1)
    foo(0)
    foo(1)


# Generated at 2022-06-12 05:42:14.185013
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5]) == [2, 4]



# Generated at 2022-06-12 05:42:16.191394
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(increase)([1, 2, 3]) == [2, 3, 4]
test_curried_filter()

# Generated at 2022-06-12 05:42:56.648180
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x == 1, [1, 2, 3]) == [1]
    assert curried_filter(lambda x: x == 1)([1, 2, 3]) == [1]
    assert curried_filter(lambda x: x == 1, [1, 2, 3, 4, 5])([1, 2, 3]) == [1]



# Generated at 2022-06-12 05:43:01.611248
# Unit test for function find
def test_find():
    x = find([1, 2, 3], lambda x: x == 2)
    assert x == 2, 'Wrong result of find function'
    assert find([1, 2, 3], lambda x: x == 5) is None, 'Wrong result of find function'



# Generated at 2022-06-12 05:43:05.626301
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == \
        [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == \
        [2, 3, 4]


# Generated at 2022-06-12 05:43:14.262953
# Unit test for function cond
def test_cond():

    def first_condition_function(number):
        return number == 1

    def second_condition_function(number):
        return number == 2

    def first_execute_function(number):
        return number + 10

    def second_execute_function(number):
        return number + 20

    def third_execute_function(number):
        return number + 30

    # define function, witch will be returned by function cond
    condition_list = [
        (first_condition_function, first_execute_function),
        (second_condition_function, second_execute_function)
    ]
    cond_function = cond(condition_list)

    assert cond_function(1) == 11, 'first condition function'
    assert cond_function(2) == 22, 'second condition function'

# Generated at 2022-06-12 05:43:16.565640
# Unit test for function find
def test_find():
    assert find([1, 2, 3], identity) == 1
    assert find([1, 2, 3], eq(2)) == 2



# Generated at 2022-06-12 05:43:21.447539
# Unit test for function cond
def test_cond():
    def is_positive(value: int) -> bool:
        return value > 0

    def identity(value: int) -> int:
        return value

    assert cond([
        (is_positive, identity)
    ])(1) == 1

test_cond()

# Generated at 2022-06-12 05:43:22.765406
# Unit test for function memoize
def test_memoize():
    assert memoize(add)(2, 3) == 5



# Generated at 2022-06-12 05:43:26.578307
# Unit test for function eq
def test_eq():
    assert eq(1)(1) == True
    assert eq(1)(2) == False
    assert eq(1, 2) == False
    assert eq(1, 1) == True


# Generated at 2022-06-12 05:43:34.049899
# Unit test for function memoize
def test_memoize():
    def fib(n):
        if n < 2:
            return n
        return fib(n - 1) + fib(n - 2)

    fib_memo = memoize(fib)

    assert fib_memo(10) == 55
    assert fib_memo(20) == 6765
    assert fib_memo(10) == 55
    assert fib_memo(20) == 6765
    assert fib_memo(30) == 832040
    assert fib_memo(30) == 832040


# Generated at 2022-06-12 05:43:43.212095
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    times = curried_map(lambda x: x * x)
    assert times([1, 2, 3]) == [1, 4, 9]
    assert times([10, 20]) == [100, 400]
    curried_map_lambda = curried_map(lambda x: x * x)
    assert curried_map_lambda([1, 2, 3]) == [1, 4, 9]
    assert curried_map_lambda([10, 20]) == [100, 400]



# Generated at 2022-06-12 05:44:29.850044
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b
    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(2, 2) == 4
    assert memoized_add(2, 2) == 4
    assert memoized_add(2, 2) == 4


# Unit tests for function compose

# Generated at 2022-06-12 05:44:34.672856
# Unit test for function curry
def test_curry():
    """
    Test function curry.
    """
    assert curry(increase)(1) == 2
    increase_one = curry(increase, 1)
    increase_two = curry(increase, 2)
    increase_three = curry(increase, 3)
    assert increase_one(2) == 3
    assert increase_two(2) == 4
    assert increase_three(2) == 5



# Generated at 2022-06-12 05:44:43.043608
# Unit test for function cond
def test_cond():
    assert cond([
        (eq(1), increase),
        (eq(2), increase),
        (eq(3), increase),
    ])(1) == 2
    assert cond([
        (eq(1), increase),
        (eq(2), increase),
        (eq(3), increase),
    ])(2) == 3
    assert cond([
        (eq(1), increase),
        (eq(2), increase),
        (eq(3), increase),
    ])(3) == 4
    assert cond([
        (eq(1), increase),
        (eq(2), increase),
        (eq(3), increase),
    ])(4) is None



# Generated at 2022-06-12 05:44:48.476804
# Unit test for function cond
def test_cond():
    # Example from Ramda js docs
    _cond = cond([
        (eq(0), lambda: 'water freezes at 0°C'),
        (eq(100), lambda: 'water boils at 100°C'),
        (lambda: True, lambda temperature: 'nothing special happens at {}°C'.format(temperature)),
    ])

    assert _cond(0) == 'water freezes at 0°C'
    assert _cond(100) == 'water boils at 100°C'
    assert _cond(50) == 'nothing special happens at 50°C'


if __name__ == '__main__':
    test_cond()
    print('All tests passed')

# Generated at 2022-06-12 05:44:52.825984
# Unit test for function eq
def test_eq():
    assert True == eq(1)(1)
    assert False == eq(1)(2)
    assert True == eq("a")("a")
    assert False == eq("a")("b")
    assert True == eq([1])([1])
    assert False == eq([1])([2])



# Generated at 2022-06-12 05:44:57.613463
# Unit test for function curry
def test_curry():
    def curried_fn(a, b, c):
        return a + b + c

    assert curry(curried_fn) == curried_fn
    assert curry(curried_fn)(1, 2, 3) == 6
    assert curry(curried_fn)(1)(2, 3) == 6
    assert curry(curried_fn)(1)(2)(3) == 6
    assert curry(curried_fn)(1, 2)(3) == 6



# Generated at 2022-06-12 05:45:04.439756
# Unit test for function memoize
def test_memoize():
    def add_times_two(x):
        print('add_times_two called')
        return x + x

    add_times_two = memoize(add_times_two)
    value = add_times_two(1)
    value = add_times_two(2)
    value = add_times_two(1)
    value = add_times_two(1)
    value = add_times_two(1)
    assert value == 2

# Generated at 2022-06-12 05:45:12.290874
# Unit test for function memoize
def test_memoize():
    def fib(num):
        if num < 2:
            return num
        return fib(num - 1) + fib(num - 2)

    fib = memoize(fib)
    assert fib(5) == 5
    assert fib(7) == 13
    assert fib(5) == 5
    assert len(fib.__code__.co_consts[0]) == 2
    assert fib.__code__.co_consts[0][0] == (5, 5)
    assert fib.__code__.co_consts[0][1] == (7, 13)



# Generated at 2022-06-12 05:45:20.330774
# Unit test for function memoize
def test_memoize():
    mock_http_get = lambda url: "result"
    memoized_http_get = memoize(mock_http_get)

    # first call
    first_call_result = memoized_http_get("http://a.b.c/1")
    assert first_call_result == "result"

    # second call
    second_call_result = memoized_http_get("http://a.b.c/1")
    assert second_call_result == "result"

if __name__ == "__main__":
    test_memoize()

# Generated at 2022-06-12 05:45:28.540527
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], eq(1)) == 1
    assert find([1, 2, 3, 4], eq(2)) == 2
    assert find([1, 2, 3, 4], eq(3)) == 3
    assert find([1, 2, 3, 4], eq(4)) == 4
    assert find([1, 2, 3, 4], eq(5)) is None
    assert find([1, 2, 3, 4], eq(6)) is None

