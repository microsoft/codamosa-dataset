

# Generated at 2022-06-12 05:36:14.602859
# Unit test for function curried_map
def test_curried_map():
    curried_add_one = curried_map(increase)
    print('Passed: curried_map function test')

    assert curried_add_one([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-12 05:36:17.350680
# Unit test for function curried_map
def test_curried_map():
    """
    Test curried map
    """
    assert curried_map(increase)([1, 2, 3] == [2, 3, 4])



# Generated at 2022-06-12 05:36:28.978105
# Unit test for function memoize
def test_memoize():
    def get_random_number(length):
        if length == 0:
            return

        return random.choice([get_random_number(length - 1), 'X'])

    def count_X(num):
        if num == 'X':
            return 1
        else:
            return sum([i for i in num if count_X(i) == 1])

    memoized_count_X = memoize(count_X)

    assert memoized_count_X(get_random_number(10)) == count_X(get_random_number(10))
    assert memoized_count_X(get_random_number(10)) == count_X(get_random_number(10))
    assert memoized_count_X(get_random_number(10)) == count_X(get_random_number(10))
    assert memo

# Generated at 2022-06-12 05:36:37.894697
# Unit test for function curried_filter

# Generated at 2022-06-12 05:36:44.097986
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 0)
    assert not eq(0, 1)
    assert eq(1.0, 1.0)
    assert eq('1', '1')
    assert eq((1, 2), (1, 2))



# Generated at 2022-06-12 05:36:48.562479
# Unit test for function curried_filter
def test_curried_filter():
    numbers = (1, 2, 3, 4)
    greater_than_2 = curried_filter(lambda x: x > 2)
    result = greater_than_2(numbers) == (3, 4)
    assert result, 'curried filter failed'



# Generated at 2022-06-12 05:37:00.931068
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None
    assert find([{'name': 'test', 'id': 1}, {'name': 'test1', 'id': 2}],
                lambda x: x['id'] == 1) \
           == {'name': 'test', 'id': 1}
    assert find([{'name': 'test', 'id': 1}, {'name': 'test1', 'id': 2}],
                lambda x: x['id'] == 89) is None
    assert find([[1, 2, 3], [2, 3, 4], [3, 4, 5]],
                lambda x: x[0] == 2) == [2, 3, 4]

# Generated at 2022-06-12 05:37:03.580348
# Unit test for function memoize
def test_memoize():
    def add(x, y):
        return x + y

    add_memoized = memoize(add)



# Generated at 2022-06-12 05:37:06.535337
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], eq(3)) == 3
    assert find([1, 2, 3, 4, 5], eq(7)) is None



# Generated at 2022-06-12 05:37:17.579224
# Unit test for function find
def test_find():
    print("### Test for find starts\n")

    def test_for_find_with_collection(
        message,
        collection,
        finded_key,
        expected_finded_element,
    ):
        print(message)
        result = find(collection, finded_key)
        print("Expected:")
        print(expected_finded_element)
        print("Result:")
        print(result)
        assert result == expected_finded_element

    test_for_find_with_collection(
        "Find first element in list when first element is finded element",
        [1, 2, 3],
        eq(1),
        1
    )

# Generated at 2022-06-12 05:37:27.000322
# Unit test for function memoize
def test_memoize():
    def function_to_memoize(value: int) -> int:
        print(f'Function call with {value}')
        return value

    memoized_function = memoize(function_to_memoize)

    assert memoized_function(1) == 1
    assert memoized_function(1) == 1
    assert memoized_function(5) == 5
    assert memoized_function(5) == 5



# Generated at 2022-06-12 05:37:30.538071
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1, 2, 1)
    assert eq(1, 1, 1, 1)
    assert not eq()
    assert not eq(1)



# Generated at 2022-06-12 05:37:38.716731
# Unit test for function curried_map
def test_curried_map():
    assert (curried_map(increase, [1, 2, 3]) == [2, 3, 4])
    assert (curried_map(increase)([1, 2, 3]) == [2, 3, 4])
    assert (curried_map(increase, []) == [])
    assert (curried_map(increase)([]) == [])
    assert (curried_map(None, []) == [])
    assert (curried_map(None)([]) == [])



# Generated at 2022-06-12 05:37:45.518477
# Unit test for function cond
def test_cond():
    def iseven(x):
        return x % 2 == 0

    def ispositive(x):
        return x > 0

    def isnegative(x):
        return x < 0

    div_by_2_5 = cond([
        (iseven, lambda m: m // 2),
        (ispositive, lambda m: m % 5),
        (isnegative, lambda m: m // 2 + 1)
    ])
    print(div_by_2_5(2))
    print(div_by_2_5(3))
    print(div_by_2_5(-3))



# Generated at 2022-06-12 05:37:49.137231
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 3, [1, 2, 3]) == [4, 5, 6]


# Generated at 2022-06-12 05:37:58.301516
# Unit test for function cond
def test_cond():
    assert cond([
        (eq(1), identity),
        (eq(2), identity),
        (eq(3), identity)
    ])(1) == 1
    assert cond([
        (eq(1), identity),
        (eq(2), identity),
        (eq(3), identity)
    ])(2) == 2
    assert cond([
        (eq(1), identity),
        (eq(2), identity),
        (eq(3), identity)
    ])(3) == 3
    assert cond([
        (eq(1), identity),
        (eq(2), identity),
        (eq(3), identity)
    ])(4) is None
test_cond()

# Generated at 2022-06-12 05:38:08.362685
# Unit test for function cond
def test_cond():
    """
    >>> is_even = lambda x: x % 2 == 0
    >>> is_odd = lambda x: not is_even(x)
    >>> value = 2
    >>> is_even_or_odd = cond([
    ...  (is_odd, lambda x: print(f"Argument is odd and is {x}")),
    ...  (is_even, lambda x: print(f"Argument is even and is {x}"))
    ... ])
    >>> assert is_even_or_odd(value) is None
    Argument is even and is 2
    """


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 05:38:13.661741
# Unit test for function find
def test_find():
    assert find([], lambda item: False) is None
    assert find([12], lambda item: True) == 12
    assert find([12, 13], lambda item: item == 12) == 12
    assert find([12, 13], lambda item: item == 13) == 13
    assert find([12, 13], lambda item: item == 17) is None
    assert find([], lambda item: True) is None



# Generated at 2022-06-12 05:38:24.561339
# Unit test for function memoize
def test_memoize():
    def get_number():
        return random.randint(1, 10)

    get_number()
    get_number()
    get_number()
    get_number()

    assert get_number() != get_number()

    random.seed(1)
    get_number()
    get_number()
    get_number()
    get_number()

    assert get_number() != get_number()

    random.seed(1)
    get_number()
    get_number()
    get_number()
    get_number()

    assert get_number() == get_number()

    random.seed(1)
    get_number()
    get_number()
    get_number()
    get_number()

    assert get_number() == get_number()


# Generated at 2022-06-12 05:38:29.996523
# Unit test for function find
def test_find():
    a = [
        {'x': 2, 'y': 3},
        {'x': 4, 'y': 7},
        {'x': 6, 'y': 8},
    ]

    def find_by_value(obj):
        return obj['x'] % 2 == 0

    assert find(a, find_by_value) is a[0]



# Generated at 2022-06-12 05:38:38.197528
# Unit test for function memoize
def test_memoize():
    def factorial(number):
        def factorial_aux(number, result):
            if number == 0:
                return result
            return factorial_aux(number - 1, result * number)
        return factorial_aux(number, 1)

    assert factorial(5) == 120
    factorial = memoize(factorial)
    assert factorial(5) == 120

# Generated at 2022-06-12 05:38:41.114218
# Unit test for function curried_map
def test_curried_map():
    """Test if curried_map return expected value when is called with value and function."""
    assert curried_map(lambda x: x * x, [1, 2, 3]) == [1, 4, 9]



# Generated at 2022-06-12 05:38:51.842018
# Unit test for function memoize
def test_memoize():
    #def fibonacci(n: int) -> int:
    #    return 1 if n <= 2 else fibonacci(n - 1) + fibonacci(n - 2)

    fibonacci = \
        memoize(
            lambda n: 1 if n <= 2 else fibonacci(n - 1) + fibonacci(n - 2)
        )
    for n in range(1, 7):
        assert fibonacci(n - 1) + fibonacci(n - 2) == fibonacci(n)

    fibonacci = \
        memoize(
            lambda n: 1 if n <= 2 else fibonacci(n - 1) + fibonacci(n - 2),
            key=lambda x, y: x == y
        )

# Generated at 2022-06-12 05:38:56.519942
# Unit test for function curried_map
def test_curried_map():
    """
    test for curried_map function
    :return:
    """
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-12 05:38:58.426835
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 0)



# Generated at 2022-06-12 05:39:00.991394
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3, 4]) == [2, 3, 4, 5]



# Generated at 2022-06-12 05:39:09.618602
# Unit test for function find
def test_find():
    collection: List[int] = [1, 2, 3, 4, 5, 6]

    for i in range(len(collection) + 2):
        element = find(collection, lambda item: item == i)
        if element is None:
            if i in collection:
                print("test_find failed: {0} not found".format(i))
        elif element != i:
            print("test_find failed: {0} != {1}".format(element, i))
        else:
            print("test_find success: {0} == {1}".format(element, i))



# Generated at 2022-06-12 05:39:11.444561
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-12 05:39:16.630159
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(2)) == 2
    assert find(['1', True], lambda x: x == '1') == '1'
    assert find(['1', True], lambda x: x == '2') is None



# Generated at 2022-06-12 05:39:21.292806
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1])([2, 3]) == [2, 3, 4]


# Generated at 2022-06-12 05:39:27.828028
# Unit test for function memoize
def test_memoize():
    @memoize
    def expensive_fn(argument):
        print("Invoked expensive function with argument " + str(argument))
        return argument

    assert expensive_fn(1) == 1
    assert expensive_fn(2) == 2
    assert expensive_fn(1) == 1



# Generated at 2022-06-12 05:39:33.980631
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2]) == [2, 3]
    assert curried_map(lambda item: [item, item])([1, 2]) == [[1, 1], [2, 2]]
    assert curried_map(increase, [1, 2]) == [2, 3]
    assert curried_map(increase) == curried_map



# Generated at 2022-06-12 05:39:42.458414
# Unit test for function cond
def test_cond():
    def a_gt_10(x): return x > 10

    def a_lt_10(x): return x < 10

    def add_10(x): return x + 10

    def sub_10(x): return x - 10

    def add_5(x): return x + 5

    fun = cond([(a_gt_10, add_5),
                (a_lt_10, add_10),
                (a_lt_10, sub_10)
               ])
    assert fun(15) == 20
    assert fun(5) == 10


# Generated at 2022-06-12 05:39:48.807677
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x * 2, [1, 2, 3]) == [2, 4, 6]
    assert curried_map(lambda x: x * 4, range(1, 3)) == [4, 8]
    assert curried_map(lambda x: x * 2, [1, 2, 3]) == [2, 4, 6]
    assert curried_map(lambda x: x * 4)(range(1, 3)) == [4, 8]



# Generated at 2022-06-12 05:39:57.593875
# Unit test for function cond
def test_cond():
    def fn1(value):
        return reduce(lambda acc, num: acc * num, range(1, value + 1), 1)

    def fn2(value):
        return reduce(lambda acc, num: acc + num, range(1, value + 1), 1)

    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 != 0

    def is_not_one(value):
        return value != 1

    is_even_ = cond([
        (is_even, fn2),
        (is_not_one, fn1),
        (is_odd, fn1),
    ])

    assert is_even_(2) == 3
    assert is_even_(3) == 6
    assert is_even_(4) == 10

# Generated at 2022-06-12 05:40:02.048257
# Unit test for function memoize
def test_memoize():
    def add(x, y):
        return x + y


    add_memoized = memoize(add)
    assert add_memoized(1, 2) == 3
    assert add_memoized(2, 3) == 5


test_memoize()

# Generated at 2022-06-12 05:40:08.026462
# Unit test for function find
def test_find():
    # Check if element not exist case
    assert find([1, 2], lambda item: item == 3) is None

    # Check empty collection
    collection = []
    assert find(collection, lambda item: item == 1) is None

    # Check regular case
    collection = [1, 2, 3]
    assert find(collection, lambda item: item == 3) == 3

    # Check not found element
    collection = [1, 2, 3]
    assert find(collection, lambda item: item == '3') is None



# Generated at 2022-06-12 05:40:19.061709
# Unit test for function cond
def test_cond():
    # this function will return sum of arguments
    def sum(*args):
        return sum(args)

    # this function will print arguments
    def print_args(*args):
        print(args)

    # this function will return all arguments in list
    def list_args(*args):
        return list(args)

    # this functions will return arguments multiplied by 10
    def multiply_by_10(*args):
        return args[0] * 10

    # this functions will return arguments multiplied by 2
    def multiply_by_2(*args):
        return args[0] * 2

    # the testing function

# Generated at 2022-06-12 05:40:27.316364
# Unit test for function cond
def test_cond():
    def result():
        return "result"

    def no_result():
        return None

    def args(*args):
        return None

    # this is a list of tests with not null values
    check_list = [
        [args, args, None, None],
        # this is a list of tests with null values
        [args, args, args, None]
    ]

    for tests in check_list:
        # these are the conditions
        conditions = [(lambda *args: True, result), (lambda *args: False, no_result)]

        # this is the function we will test
        test_cond = cond(conditions)

        # we test that all our results are the same
        # and we test that a None result is the same
        # we give the test function a None argument
        # to test that this works in all cases
       

# Generated at 2022-06-12 05:40:30.767445
# Unit test for function curried_map
def test_curried_map():
    filter_fn = curried_map(increase)
    assert filter_fn([0, 1, 2]) == [1, 2, 3]



# Generated at 2022-06-12 05:40:43.276617
# Unit test for function find
def test_find():
    collections = [
        {"id": 1, "title": "Basic arithmetic"},
        {"id": 2, "title": "Basic algebra"},
        {"id": 3, "title": "Basic geometry"},
    ]

    assert find(collections, lambda item: eq(item["id"], 1)) == {
        "id": 1, "title": "Basic arithmetic"}
    assert find(collections, lambda item: eq(item["id"], 2)) == {
        "id": 2, "title": "Basic algebra"}
    assert find(collections, lambda item: eq(item["id"], 3)) == {
        "id": 3, "title": "Basic geometry"}
    assert find(collections, lambda item: eq(item["id"], 4)) == None



# Generated at 2022-06-12 05:40:45.647540
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 4)([5, 6, 7]) == [5, 6, 7], \
        "curried_filter should return elements in list, bigger than 4"



# Generated at 2022-06-12 05:40:51.025665
# Unit test for function curry
def test_curry():
    @curry
    def curried_sum(x, y, z):
        return x + y + z

    assert curried_sum(1, 2, 3) == 6
    assert curried_sum(1, 2)(3) == 6
    assert curried_sum(1)(2)(3) == 6
    assert curried_sum(1)(2, 3) == 6


test_curry()



# Generated at 2022-06-12 05:40:56.953141
# Unit test for function curried_map
def test_curried_map():
    # Create new function with passed state
    curried_map_increase = curried_map(increase)

    # Invoke function on specific arguments
    increased_values = curried_map_increase([1, 2, 3])

    assert increased_values == [2, 3, 4], "incorrect increased_values"



# Generated at 2022-06-12 05:40:59.362712
# Unit test for function eq
def test_eq():
    eqTest = eq(1, 1)
    eqTestFalse = eq(1, 2)
    assert eqTest
    assert not eqTestFalse


# Generated at 2022-06-12 05:41:04.288126
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-12 05:41:06.251781
# Unit test for function curried_filter
def test_curried_filter():
    assert(curried_filter(eq(1))([1, 2, 3, 4, 1]) == [1, 1])



# Generated at 2022-06-12 05:41:10.236759
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-12 05:41:16.463868
# Unit test for function memoize
def test_memoize():
    """
    Test for equality of results memoized and not memoized functions with one and many arguments.
    """
    def inc(value: int) -> int:
        return value + 1

    def sum(value: int, value1: int) -> int:
        return value + value1

    incMemoized = memoize(inc)
    assert inc(3) == incMemoized(3)
    assert incMemoized(3) == incMemoized(3)
    sumMemoized = memoize(sum)
    assert sum(2, 3) == sumMemoized(2, 3)
    assert sumMemoized(2, 3) == sumMemoized(2, 3)



# Generated at 2022-06-12 05:41:21.456127
# Unit test for function eq
def test_eq():
    assert not eq(1, 2)
    assert eq(1, 1)
    assert not eq(1, '1')
    assert not eq(1, list((1, )))



# Generated at 2022-06-12 05:41:35.661214
# Unit test for function cond
def test_cond():
    """
    1. Tests for correct work with simple case.
    2. Tests for correct work with case when there is no results.
    """
    condition_list = [
        (lambda x: x > 10, lambda x: '> 10'),
        (lambda x: x == 10, lambda x: '== 10'),
        (lambda x: x < 10, lambda x: '< 10'),
    ]
    result = cond(condition_list)
    assert result(100) == '> 10'
    assert result(10) == '== 10'
    assert result(5) == '< 10'
    assert result(0) == '< 10'


# Generated at 2022-06-12 05:41:42.182042
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)

    eq1 = eq(1)
    assert eq1(1)
    assert not eq1(2)
    assert not eq1(3)

    eq3 = eq1(3)
    assert not eq3(3)
    assert not eq3(2)
    assert not eq3(1)



# Generated at 2022-06-12 05:41:44.444805
# Unit test for function find
def test_find():
    assert(find([1, 2, 3], eq(2)) == 2)
    assert(find([1, 2, 3], eq(4)) is None)



# Generated at 2022-06-12 05:41:47.532584
# Unit test for function eq
def test_eq():
    eq1 = eq(1)
    eq2 = eq(2)
    assert eq1(1) == True
    assert eq1(2) == False
    assert eq2(2) == True
    assert eq2(1) == False


# Generated at 2022-06-12 05:41:57.848410
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z, a: x + y + z + a)(1)(2)(3)(4) == 10
    assert curry(lambda w, x, y, z, a: w + x + y + z + a)(1)(2)(3)(4)(5) == 15
    assert curry(lambda v, w, x, y, z, a: v + w + x + y + z + a)(1)(2)(3)(4)(5)(6) == 21
    assert curry(lambda u, v, w, x, y, z, a: u + v + w + x + y + z + a)(1)(2)(3)(4)(5)(6)(7) == 28


# Generated at 2022-06-12 05:42:02.015028
# Unit test for function find
def test_find():
    collection = [1, 2, 3]

    # Test return None if element not found
    assert find(collection, lambda x: x > 3) is None

    # Test return correct element if founded
    assert find(collection, lambda x: x == 3) == 3
    assert find(collection, lambda x: x == 2) == 2



# Generated at 2022-06-12 05:42:07.741329
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: True)([1, 2, 3]) == [1, 2, 3]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3]) == [2]
    assert curried_filter(lambda x: x > 10)([10, 11, 12, 5]) == [11, 12]
    assert curried_filter(lambda x: x != 10)([10, 11, 12, 5]) == [11, 12, 5]


# Generated at 2022-06-12 05:42:13.062514
# Unit test for function cond
def test_cond():
    @curry
    def add(nr1, nr2):
        return nr1 + nr2

    @curry
    def subtract(nr1, nr2):
        return nr1 - nr2

    cond_add = cond([(eq(1), add), (eq(2), subtract)])
    assert cond_add(1)(3, 4) == 7
    assert cond_add(1)(3, 1) == 4
    assert cond_add(2)(3, 1) == 2



# Generated at 2022-06-12 05:42:15.691566
# Unit test for function curry
def test_curry():
    def func(a, b, c, d):
        return a + b + c + d

    func_curry = curry(func)
    assert func_curry(1)(2)(3)(4) == 10



# Generated at 2022-06-12 05:42:17.574245
# Unit test for function eq
def test_eq():
    assert eq(2, 2)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(2)(1)


# Generated at 2022-06-12 05:42:37.772353
# Unit test for function curried_map
def test_curried_map():
    curried_increase = curried_map(increase)
    assert curried_increase([0, 1, 2]) == [1, 2, 3], "Function curried_map failed"


# Generated at 2022-06-12 05:42:40.481663
# Unit test for function eq
def test_eq():
    assert eq(2)(2)
    assert eq(2)(1) != 2



# Generated at 2022-06-12 05:42:44.863874
# Unit test for function curried_filter
def test_curried_filter():
    """
    Test for curried_filter function.
    """
    assert curried_filter(eq("Two"), [1, "Two", 3])("Two") == ["Two"]
    assert curried_filter(eq("One"), ["One", "Two", "Three"])("One") == ["One"]


# Generated at 2022-06-12 05:42:49.963153
# Unit test for function eq
def test_eq():
    # eq_function = lambda arg1, arg2: arg1 == arg2
    eq_function = eq
    assert eq_function(1, 1) == True
    assert eq_function(1, 2) == False
    eq_function = eq('a')
    assert eq_function('a') == True
    assert eq_function('b') == False


# Generated at 2022-06-12 05:42:57.002881
# Unit test for function memoize
def test_memoize():
    """
    >>> add_one = lambda n: n + 1
    >>> double = lambda n: n * 2
    >>> add_one_plus_double = lambda n: add_one(double(n))
    >>> memo_add_one_plus_double = memoize(add_one_plus_double)
    >>> assert memo_add_one_plus_double(10) == add_one_plus_double(10)
    >>> assert memo_add_one_plus_double(10) == add_one_plus_double(10)
    """
    pass

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 05:43:04.201191
# Unit test for function cond
def test_cond():
    condition_list = [
        (lambda x: x == 1, lambda x: print('1')),
        (lambda x: x == 2, lambda x: print('2')),
        (lambda x: x == 3, lambda x: print('3')),
        (lambda x: x == 4, lambda x: print('4')),
    ]
    func = cond(condition_list)
    func(11)
    func(3)
    func(4)



# Generated at 2022-06-12 05:43:10.610937
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)  # is callable
    assert curry(lambda x, y: x + y, args_count=1)(1)  # is callable
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z, args_count=2)(1, 2) == 3



# Generated at 2022-06-12 05:43:13.381592
# Unit test for function find
def test_find():
    assert find([], lambda x: x % 2 == 0) is None
    assert find([1, 3, 5], lambda x: x % 2 == 0) is None
    assert find([1, 2, 3], lambda x: x % 2 == 0) == 2



# Generated at 2022-06-12 05:43:23.492703
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x == 1, [1, 2, 1, 3]) == [1, 1]
    assert curry(curried_filter)(lambda x: x == 1, [1, 2, 1, 3]) == [1, 1]
    assert curry(curried_filter, 2)(lambda x: x == 1, [1, 2, 1, 3]) == [1, 1]
    assert curry(curried_filter, 2)(lambda x: x == 1)([1, 2, 1, 3]) == [1, 1]
    assert curry(curried_filter, 2)(lambda x: x == 1)([1, 2, 1, 3]) == [1, 1]


# Generated at 2022-06-12 05:43:28.545665
# Unit test for function memoize
def test_memoize():
    @memoize
    def factorial(num):
        if num == 0:
            return 1

        return num * factorial(num - 1)
    assert factorial(5) == 120
    assert factorial(5) == 120
    assert factorial(5) == 120



# Generated at 2022-06-12 05:43:49.571912
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(1), [1, 2]) == [1]
    assert curried_filter(eq(1), [2, 3]) == []



# Generated at 2022-06-12 05:43:50.913841
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)

# Generated at 2022-06-12 05:43:53.093413
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: (x + y, z))(1, 'z')(2) == (3, 'z')



# Generated at 2022-06-12 05:43:59.677523
# Unit test for function curry
def test_curry():
    @curry
    def add(x, y):
        return x + y

    assert add(4, 5) == 9
    assert add(4)(5) == 9

    assert add(4, 5, 6) == 15
    assert add(4)(5, 6) == 15
    assert add(4, 5)(6) == 15
    assert add(4)(5)(6) == 15


# Unit tests for functions identity, increase

# Generated at 2022-06-12 05:44:05.145263
# Unit test for function eq
def test_eq():
    assert True == eq(1, 1)
    assert True == eq([], [])
    assert True == eq(None, None)
    assert True == eq(1)(1)
    assert True == eq([]) ([])
    assert True == eq(None) (None)
    assert False == eq(1, 2)
    assert False == eq(1) (2)



# Generated at 2022-06-12 05:44:06.995303
# Unit test for function find
def test_find():
    test_array = [1, 2, 3]
    result = find(test_array, eq(2))
    assert result == 2



# Generated at 2022-06-12 05:44:17.770164
# Unit test for function curried_filter
def test_curried_filter():
    def __test_curried_filter(expected_result, filterer, collection):
        filtered = curried_filter(filterer)(collection)
        assert expected_result == filtered

    __test_curried_filter([4, 5, 6], lambda x: x > 3, [1, 2, 3, 4, 5, 6])
    __test_curried_filter([], lambda x: x < 0, [1, 2, 3, 4, 5, 6])
    __test_curried_filter([], lambda x: True, [])
    __test_curried_filter([], identity, [])
    __test_curried_filter([1, 2, 3, 4, 5, 6], lambda x: True, [1, 2, 3, 4, 5, 6])



# Generated at 2022-06-12 05:44:19.465786
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False


# Generated at 2022-06-12 05:44:25.673532
# Unit test for function cond
def test_cond():
    second = lambda data: data[1]
    is_even = lambda value: value % 2 == 0
    # is_true = lambda value: value

    is_number_even = cond([
        (is_even, second),
        (None, first),
    ])

    assert is_number_even((1, 2)) == 2
    assert is_number_even((1, 1)) == 1



# Generated at 2022-06-12 05:44:31.999859
# Unit test for function curried_map
def test_curried_map():
    array = [1, 2, 3, 4, 5]
    curried_array_inc = curried_map(increase)
    array_inc = curried_array_inc(array)
    expected_array_inc = [2, 3, 4, 5, 6]
    diff_array_inc = [item for item in array_inc if item != expected_array_inc[array_inc.index(item)]]
    assert not diff_array_inc


# Generated at 2022-06-12 05:45:33.160963
# Unit test for function memoize
def test_memoize():
    all_args: List[int] = []

    def f(arg):
        all_args.append(arg)
        return arg

    mem_f = memoize(f, eq)
    assert mem_f(1) == 1
    assert mem_f(1) == 1
    assert len(all_args) == 1
    assert mem_f(2) == 2
    assert len(all_args) == 2
    assert mem_f(2) == 2
    assert len(all_args) == 2

    all_args = []
    mem_f = memoize(f, lambda x, y: x == y)
    assert mem_f(1) == 1
    assert mem_f(1) == 1
    assert len(all_args) == 1
    assert mem_f(2) == 2

# Generated at 2022-06-12 05:45:36.259004
# Unit test for function curried_map
def test_curried_map():
    curried_map_1 = curried_map(increase)
    result = curried_map_1([1, 2, 3])
    assert result == [2, 3, 4]



# Generated at 2022-06-12 05:45:40.143850
# Unit test for function find
def test_find():

    assert find([1, 2, 3], eq(2)) == 2, "Should return 2"
    assert find([1, 2, 3], eq(7)) is None, "Should return None"



# Generated at 2022-06-12 05:45:46.850868
# Unit test for function curried_map
def test_curried_map():
    """
    Unit test for function curried_map.
    """
    assert curried_map(lambda x: x, [1, 2, 3, 4]) == [1, 2, 3, 4]
    assert curried_map(lambda x: x ** 3, [1, 2, 3, 4, 5]) == [1, 8, 27, 64, 125]
    assert curried_map(lambda x: x + 100, [0, 1, 2, 3, 4, 5]) == [100, 101, 102, 103, 104, 105]



# Generated at 2022-06-12 05:45:51.826509
# Unit test for function cond
def test_cond():
    condition_list = [
        (lambda a: a < 3, lambda a: a ** 2),
        (lambda a: 3 <= a <= 5, lambda a: a ** 3),
        (lambda a: a > 5, lambda a: a ** 4)]
    assert cond(condition_list)(2) == 4
    assert cond(condition_list)(3) == 27
    assert cond(condition_list)(6) == 1296
    assert cond(condition_list)(7) == 2401
    condition_list = [
        (lambda a: 0 < a < 3, lambda a: a ** 2),
        (lambda a: 3 <= a <= 5, lambda a: a ** 3),
        (lambda a: a > 5, lambda a: a ** 4),
        (lambda a: a < 0, lambda a: a ** -1)]

# Generated at 2022-06-12 05:45:57.217500
# Unit test for function find
def test_find():
    assert find(['A', 'B', 'C'], identity) == 'A'
    assert find(['A', 'B', 'C'], eq('B')) == 'B'
    assert find(['A', 'B', 'C'], eq('D')) is None


# Generated at 2022-06-12 05:46:04.178979
# Unit test for function memoize
def test_memoize():
    def long_running_process(a):
        sleep(1)
        return a

    # Testing if memoize is creating new function
    assert memoize(long_running_process) != long_running_process
    # Testing if memoize if calculating new value
    first_value = memoize(long_running_process)('a')
    second_value = memoize(long_running_process)('a')
    assert first_value == second_value
    # Testing if memoize caching results
    third_value = memoize(long_running_process)('a')
    assert third_value == first_value



# Generated at 2022-06-12 05:46:07.978726
# Unit test for function memoize
def test_memoize():
    def function_to_memoize(value: int) -> int:
        return value

    memoized_function = memoize(function_to_memoize)
    assert memoized_function(1) == memoized_function(1)