

# Generated at 2022-06-12 05:36:15.605178
# Unit test for function find
def test_find():
    """
    Test if find function return correct result,
    or return None if list does not contain match element.
    """
    list_to_search = list(range(10))
    assert find(
        list_to_search,
        lambda x: x == 1
    ) == 1, 'incorrect search result'
    assert find(
        list_to_search,
        lambda x: x == 100
    ) is None, 'incorrect search result'



# Generated at 2022-06-12 05:36:17.843574
# Unit test for function memoize
def test_memoize():
    assert memoize(lambda x: 1+x)(2) == 3
    assert memoize(lambda x: x-1)(2) == 1

# Generated at 2022-06-12 05:36:28.171225
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2)(4) == 7
    assert curry(lambda x, y, z: x + y + z)(1)(3)(3) == 7
    assert curry(lambda x, y, z: x + y + z)(1)(3)(4) == 8
    assert curry(lambda x, y, z: x + y + z)(2)(2)(2) == 6
    assert curry(lambda x, y, z: x + y + z)(2)(2)(3) == 7



# Generated at 2022-06-12 05:36:36.107625
# Unit test for function curried_filter
def test_curried_filter():
    assert [1, 3, 5] == curried_filter(eq(1), [1, 2, 3, 4, 5, 6])(), "should filter correctly"
    assert [1, 1, 2] == curried_filter(lambda x: x <= 2, [1, 1, 2, 3, 5, 8, 13])(), "should filter correctly"
    assert [] == curried_filter(lambda x: x % 2 == 0, [1, 1, 3, 5, 13, 21])(), "should filter correctly"



# Generated at 2022-06-12 05:36:38.370219
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-12 05:36:45.194823
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x * x, [1, 2, 3]) == [1, 4, 9]
    assert curried_map(lambda x: x * x)([1, 2, 3]) == [1, 4, 9]
    assert curried_map(lambda x: x * x, {1: 1, 2: 2, 3: 3}) == [1, 4, 9]
    assert curried_map(lambda x: x * x)({1: 1, 2: 2, 3: 3}) == [1, 4, 9]
    assert curried_map(lambda x: x * x, range(1, 4)) == [1, 4, 9]
    assert curried_map(lambda x: x * x)(range(1, 4)) == [1, 4, 9]



# Generated at 2022-06-12 05:36:48.707772
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda n: n == 2) == 2
    assert find([1, 2, 3], lambda n: n == 4) is None

if __name__ == '__main__':
    test_find()

# Generated at 2022-06-12 05:36:57.726210
# Unit test for function memoize
def test_memoize():
    l = []

    def f(x):
        l.append(x)
        return x

    assert f(1) == 1
    assert f(2) == 2
    assert f(1) == 1
    assert l == [1, 2, 1]

    ff = memoize(f)
    assert ff(1) == 1
    assert ff(2) == 2
    assert ff(1) == 1
    assert l == [1, 2, 1]


if __name__ == '__main__':
    print(test_memoize())

# Generated at 2022-06-12 05:37:01.399566
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 3) == 3
    assert find([1, 2, 3], lambda x: x == 4) is None
    assert find([1, 2, 3], lambda x: x == 2) == 2



# Generated at 2022-06-12 05:37:08.101221
# Unit test for function curried_filter
def test_curried_filter():
    is_positive = lambda num: num > 0
    arr = [1, 2, 3, 4, 5, -1, -2, -3, -4, -5]
    result = curried_filter(is_positive, arr)
    expected = [1, 2, 3, 4, 5]
    assert expected == result
    assert expected == curried_filter(is_positive)(arr)
    assert expected == curried_filter(is_positive)()(arr)



# Generated at 2022-06-12 05:37:14.387766
# Unit test for function memoize
def test_memoize():
    def sum(a):
        return a + 1

    sum = memoize(sum)
    first_sum = sum(1)
    second_sum = sum(1)

    return first_sum == second_sum


print(test_memoize())



# Generated at 2022-06-12 05:37:18.915806
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda item: item > 2)([1, 2, 3]) == [3]
    assert curried_filter(lambda item: item > 2)([5, 6, 100]) == [5, 6, 100]
    assert curried_filter(lambda item: item < 5)([5, 6, 100]) == []


# Generated at 2022-06-12 05:37:23.159711
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(42), [1, 42, 42, 4]) == [42, 42]
    assert curried_filter(eq(42))([1, 42, 42, 4]) == [42, 42]


# Generated at 2022-06-12 05:37:26.156412
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-12 05:37:31.511753
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, []), 'empty list'

# Generated at 2022-06-12 05:37:36.125052
# Unit test for function curried_map
def test_curried_map():
    curried_map_fn = curried_map(increase)
    assert curried_map_fn([1, 2, 3]) == [2, 3, 4]
    assert curried_map_fn([]) == []



# Generated at 2022-06-12 05:37:40.191716
# Unit test for function curried_map
def test_curried_map():
    result = curried_map(increase, [1, 2, 3])
    assert result == [2, 3, 4]
    result = curried_map(lambda x: x+1)([1, 2, 3])
    assert result == [2, 3, 4]



# Generated at 2022-06-12 05:37:45.416718
# Unit test for function curry
def test_curry():
    """
    Test currying function.

    :return:
    """
    def is_even(x):
        return x % 2 == 0

    assert is_even(2) is True
    curry3 = curry(is_even, 3)
    assert curry3(1, 2, 3) is False
    assert curry3(1, 2)(3) is False
    is_even2 = curry(is_even)
    assert is_even2(2) is True

# Generated at 2022-06-12 05:37:55.681663
# Unit test for function cond
def test_cond():
    def add_one(number):
        return number + 1

    def add_two(number):
        return number + 2

    def multiply_on_three(number):
        return number * 3

    def is_one_or_two(number):
        return number == 1 or number == 2

    def is_three(number):
        return number == 3

    cond_result = cond([
        (is_one_or_two, add_one),
        (is_three, multiply_on_three),
        (lambda: True, add_two)
    ])
    assert(cond_result(2) == 3)
    assert(cond_result(3) == 9)
    assert(cond_result(4) == 6)



# Generated at 2022-06-12 05:37:57.577802
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x * 2)([1, 2]) == [2, 4]



# Generated at 2022-06-12 05:38:03.228325
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 5, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [6, 7, 8, 9, 10]



# Generated at 2022-06-12 05:38:13.875110
# Unit test for function find
def test_find():
    assert find(list(range(10)), lambda x: x > 5) == 6, 'find(list(range(10)), lambda x: x > 5) = 6'
    assert find(list(range(10)), lambda x: x < 0) is None, 'find(list(range(10)), lambda x: x < 0) = None'
    assert find(list(range(10)), None) is None, 'find(list(range(10)), None) = None'
    assert find([None], None) is None, 'find([None], None) = None'
    assert find([None], lambda _: True) is None, 'find([None], lambda _: True) = None'
    assert find([object()], lambda _: True) is not None, 'find([object()], lambda _: True) != None'


# Generated at 2022-06-12 05:38:24.653034
# Unit test for function cond
def test_cond():
    less_then_5 = lambda x: x < 5
    more_then_5 = lambda x: x > 5
    is_5 = lambda x: x == 5
    is_10 = lambda x: x == 10

    func = cond([
        (less_then_5, lambda x: 'less than 5'),
        (more_then_5, lambda x: 'more than 5'),
        (is_5, lambda x: 'is 5'),
    ])

    assert func(1) == 'less than 5'
    assert func(6) == 'more than 5'
    assert func(5) == 'is 5'
    assert func(10) is None


# Generated at 2022-06-12 05:38:31.464301
# Unit test for function cond
def test_cond():
    assert cond([
        (eq(1), identity),
        (eq(2), increase),
        (eq(3), identity)
    ])(1) == 1

    assert cond([
        (eq(1), identity),
        (eq(2), increase),
        (eq(3), identity)
    ])(2) == 3

    assert cond([
        (eq(1), identity),
        (eq(2), increase),
        (eq(3), identity)
    ])(4) is None

# Generated at 2022-06-12 05:38:37.145545
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x == 1, [1, 2, 3]) == [1]
    assert curried_filter(lambda x: x > 2, [1, 2, 3]) == [3]
    assert curried_filter(lambda x: x < 1, [1, 2, 3]) == []



# Generated at 2022-06-12 05:38:43.011318
# Unit test for function memoize
def test_memoize():
    def test_fn(argument: int) -> int:
        print('calling test_fn with argument:', argument)
        return argument

    memoized_test_fn = memoize(test_fn)
    assert memoized_test_fn(1) == 1
    assert memoized_test_fn(2) == 2
    assert memoized_test_fn(1) == 1


if __name__ == '__main__':
    test_memoize()

# Generated at 2022-06-12 05:38:52.266993
# Unit test for function curried_filter
def test_curried_filter():
    print("Test curried_filter function")

    # language=rst
    """
    .. code-block:: python

        def test_curried_filter():
            print("Test curried_filter function")
            print("Assert: curried_filter(some_function, list) ==")
            assert curried_filter(some_function, list) ==
            print("Assert: curried_filter(another_function, list) ==")
            assert curried_filter(another_function, list) ==
            print("Assert: curried_filter(some_function)(list) ==")
            assert curried_filter(some_function)(list) ==
            print("Assert: curried_filter(another_function)(list) ==")
            assert curried_filter(another_function)(list) ==
    """


# Generated at 2022-06-12 05:38:59.473960
# Unit test for function cond
def test_cond():
    def fn_a(x):
        return x / 2

    def fn_b(x):
        return x + 1

    def fn_c(x):
        return x + 2

    condition_fn_a = cond([
        (eq(2), fn_a),
        (eq(5), fn_b),
        (True, fn_c),
    ])

    assert condition_fn_a(1) == 2
    assert condition_fn_a(2) == 1.0
    assert condition_fn_a(3) == 2
    assert condition_fn_a(5) == 6
    assert condition_fn_a(10) == 12


# Generated at 2022-06-12 05:39:07.505797
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 3, 4, 5]
    is_even = lambda item: item % 2 == 0
    curried_filter_even = curried_filter(is_even)
    curried_filter_odd = curried_filter(lambda item: not is_even(item))
    assert curried_filter_even(collection) == filter(is_even, collection)
    assert curried_filter_odd(collection) == filter(lambda item: not is_even(item), collection)



# Generated at 2022-06-12 05:39:10.717233
# Unit test for function find
def test_find():
    assert find([], eq(3)) is None
    assert find([1, 3, 5], eq(3)) == 3
    assert find([1, 2, 3], eq(4)) is None



# Generated at 2022-06-12 05:39:18.720063
# Unit test for function curried_filter
def test_curried_filter():
    values = [1, 2, 3]

    expected_result = [1, 3]
    result = curried_filter(lambda x: x % 2 != 0, values)
    assert result == expected_result

    result = curried_filter(lambda x: x % 2 != 0)(values)
    assert result == expected_result

    even = lambda x: x % 2 == 0
    result = curried_filter(even)(values)
    assert result == [2]

    f = curried_filter(even)
    result = f(values)
    assert result == [2]



# Generated at 2022-06-12 05:39:21.894853
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 1)([1, 2, 3]) == [2, 3]
    assert curried_filter(lambda x: x > 1, [1, 2, 3]) == [2, 3]


# Generated at 2022-06-12 05:39:26.605688
# Unit test for function find
def test_find():
    assert find([], lambda x: True) is None
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None


# Generated at 2022-06-12 05:39:34.112358
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda value: value > 2)([1, 2, 3, 4]) == [3, 4]
    assert curried_filter(lambda value: value > 2)([1, 2, 4]) == [4]
    greater_than_3 = curried_filter(lambda value: value > 3)
    assert greater_than_3([1, 2, 3, 4]) == [4]
    assert greater_than_3([1, 2, 3, 5]) == [5]


# Generated at 2022-06-12 05:39:38.577928
# Unit test for function cond
def test_cond():
    fn = cond([
        (eq(True), lambda x: x),
        (eq(False), lambda x: x + 1)
    ])
    assert fn(0) == 0
    assert fn(1) == 1



# Generated at 2022-06-12 05:39:48.960670
# Unit test for function cond
def test_cond():
    def add(value):
        return value + 1

    def double_add(value):
        return value + 2

    def double(value):
        return value * 2

    def triple(value):
        return value * 3

    assert cond([
        (lambda value: value > 5, add),
        (lambda value: value > 10, double_add),
        (lambda value: value > 5, double),
        (lambda value: value > 10, triple),
    ])(1) == 2

    assert cond([
        (lambda value: value > 5, add),
        (lambda value: value > 10, double_add),
        (lambda value: value > 5, double),
        (lambda value: value > 10, triple),
    ])(6) == 7


# Generated at 2022-06-12 05:39:51.744847
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1,2,3]) == [2,3,4]
    assert curried_map(increase, [1,2,3]) == [2,3,4]


# Generated at 2022-06-12 05:39:55.977201
# Unit test for function memoize
def test_memoize():
    import pytest
    # Test function
    def multiply(value):
        return value * 2

    multiply = memoize(multiply)
    assert multiply(2) == 4
    assert multiply(2) == 4


# Test for function memoize, with new key

# Generated at 2022-06-12 05:40:06.962765
# Unit test for function curry
def test_curry():
    assert increase(1) == 2
    assert increase(2) == 3
    assert increase(3) == 4
    assert increase(4) == 5
    assert increase(5) == 6
    assert increase(6) == 7
    increase = curry(increase)
    assert increase(1) == 2
    assert increase(2) == 3
    assert increase(3) == 4
    assert increase(4) == 5
    assert increase(5) == 6
    assert increase(6) == 7

    assert identity(10) == 10
    identity = curry(identity)
    assert identity(10) == 10

    assert eq(10, 10)
    assert not eq(10, 11)
    eq = curry(eq)
    assert eq(10)(10)
    assert not eq(10)(11)
    assert not eq(11)(10)

# Generated at 2022-06-12 05:40:11.033828
# Unit test for function curry
def test_curry():
    def add(x, y, z):
        return x + y + z

    result = curry(add)(1)(2)(3)
    assert(result == 6)



# Generated at 2022-06-12 05:40:25.127054
# Unit test for function cond
def test_cond():
    is_even = lambda x: x % 2 == 0
    is_not_even = lambda x: x % 2 != 0
    is_positive = lambda x: x > 0
    is_negative = lambda x: x < 0

    do_nothing = lambda x: x
    do_nothing_curry = curry(do_nothing)
    do_nothing_and_print = lambda x: print(x)
    do_nothing_and_print_curry = curry(do_nothing_and_print)

    to_even = lambda x: x + 1
    to_odd = lambda x: x - 1

    plus_one = lambda x: x + 1


# Generated at 2022-06-12 05:40:36.635476
# Unit test for function cond
def test_cond():
    assert cond([
        # test for equal
        (eq(2), pipe([2, 3], curried_map(increase))),
        (eq(4), pipe([4, 5], curried_map(increase))),
        (eq(7), pipe([7, 8], curried_map(increase))),
        (eq(9), pipe([9, 10], curried_map(increase))),
        (eq(11), pipe([11, 12], curried_map(increase))),
    ])(2) == [3, 4]

# Generated at 2022-06-12 05:40:38.551763
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert eq(1, 2) is False


# Generated at 2022-06-12 05:40:40.335910
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert eq('a', 'a')
    assert eq(False, False)



# Generated at 2022-06-12 05:40:44.149483
# Unit test for function cond
def test_cond():
    fn = cond([
        (eq(2), const(True)),
        (eq(3), const(True)),
        (eq(4), const(True)),
    ])
    assert fn(2)
    assert fn(4)
    assert not fn(1)



# Generated at 2022-06-12 05:40:46.784421
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(2), [1, 2, 3, 4, 5]) == [2]



# Generated at 2022-06-12 05:40:51.065203
# Unit test for function curried_map
def test_curried_map():
    def add_five(num):
        return num + 5

    inc = curried_map(add_five)
    assert inc([1, 2, 3]) == [6, 7, 8]
    assert inc([10, 20]) == [15, 25]
    assert inc([0]) == [5]



# Generated at 2022-06-12 05:40:58.519227
# Unit test for function memoize
def test_memoize():
    @memoize
    def fib(n):
        if n < 2:
            return n
        return fib(n - 2) + fib(n - 1)

    print(fib(5))
    print(fib(6))
    print(fib(5))
    print(fib(6))
    print(fib(7))
    print(fib(8))


if __name__ == '__main__':
    test_memoize()

# Generated at 2022-06-12 05:41:07.999506
# Unit test for function memoize
def test_memoize():
    # Given
    counter1 = 0
    counter2 = 0
    counter1_fn = lambda value: counter1 + 1
    counter2_fn = lambda value: counter2 + 1
    memoized_counter1_fn = memoize(counter1_fn)
    memoized_counter2_fn = memoize(counter2_fn)
    argument1 = 1
    argument2 = 2
    argument3 = 2

    # When
    memoized_counter1_fn(argument1)
    memoized_counter1_fn(argument1)
    memoized_counter2_fn(argument2)
    memoized_counter2_fn(argument3)

    # Then
    assert counter1 == 1
    assert counter2 == 2



# Generated at 2022-06-12 05:41:12.438118
# Unit test for function cond
def test_cond():
    print(
        cond([
            (lambda x: x > 0, lambda x: x + 1),
            (lambda x: x < 0, lambda x: x + 2)
        ])(-20)
    )


# Generated at 2022-06-12 05:41:24.447883
# Unit test for function find
def test_find():
    assert None == find([], identity)
    assert 1 == find([1], identity)
    assert None == find([1, 2], identity)
    assert None == find([1, 2], eq(3))
    assert 2 == find([1, 2], eq(2))



# Generated at 2022-06-12 05:41:34.362847
# Unit test for function memoize
def test_memoize():
    # pylint: disable=unused-variable
    # pylint: disable=undefined-variable
    global count
    count = 0

    @memoize
    def count_and_sum(x: int) -> int:
        global count
        count += 1
        return sum(range(x))

    count_and_sum(3)
    count_and_sum(3)
    assert count == 1
    count_and_sum(5)
    assert count == 2
    count_and_sum(5)
    assert count == 2
    count_and_sum(3)
    assert count == 2


if __name__ == '__main__':
    test_memoize()

# Generated at 2022-06-12 05:41:38.660960
# Unit test for function curry
def test_curry():
    # Increase function will be curried
    curried_increase = curry(increase)

    assert curried_increase(2) == 3
    assert curried_increase()(3) == 4
    assert curried_increase()()()()(10) == 14



# Generated at 2022-06-12 05:41:42.558439
# Unit test for function memoize
def test_memoize():
    @memoize
    def factorial(n):
        if n <= 1:
            return 1
        return n * factorial(n - 1)

    assert factorial(10) == 3628800
    assert factorial(11) == 39916800



# Generated at 2022-06-12 05:41:47.111854
# Unit test for function memoize
def test_memoize():
    # Initialize function
    @memoize
    def factorial(number):
        if number == 1:
            return 1
        return number * factorial(number - 1)
    # Start test
    assert factorial(10) == 3628800
    assert factorial(5) == 120
    assert factorial(5) == 120
    assert factorial(5) == 120
    assert factorial(5) == 120
    assert factorial(5) == 120



# Generated at 2022-06-12 05:41:55.826957
# Unit test for function cond
def test_cond():
    def is_even(value): return value % 2 == 0
    def is_odd(value): return value % 2 != 0
    def double(value): return value * 2
    def triple(value): return value * 3

    result = cond([
        (is_even, double),
        (is_odd, triple)
    ])(1)
    assert result == 3, "Result should be equal to triple of value"

    result = cond([
        (is_even, double),
        (is_odd, triple)
    ])(2)
    assert result == 4, "Result should be equal to double of value"



# Generated at 2022-06-12 05:41:57.198770
# Unit test for function curry
def test_curry():
    assert curry(lambda a: a)(1) == 1



# Generated at 2022-06-12 05:41:59.464215
# Unit test for function find
def test_find():
    assert None == find([1,2,3], lambda x: x == 4)
    assert 2 == find([1,2,3], lambda x: x == 2)



# Generated at 2022-06-12 05:42:06.433608
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x > 6, lambda x: x + 1),
        (lambda x: x < 6, lambda x: x - 1),
    ])(2) == 1
    assert cond([
        (lambda x: x < 4, lambda x: x + 1),
        (lambda x: x < 0, lambda x: x - 1),
    ])(2) == 3
    assert cond([
        (lambda x: x > 6, lambda x: x + 1),
        (lambda x: x > 3, lambda x: x - 1),
    ])(7) == 8



# Generated at 2022-06-12 05:42:13.301371
# Unit test for function curry
def test_curry():
    """
    Testing function curry
    """
    def my_func(a, b, c, d):
        return a + b + c + d

    curried_func = curry(my_func)
    curried_func1 = curried_func(1)
    curried_func2 = curried_func1(2)
    curried_func3 = curried_func2(3)

    assert curried_func(1)(2)(3)(4) == 10
    assert curried_func1(2)(3)(4) == 10
    assert curried_func2(3)(4) == 10
    assert curried_func3(4) == 10



# Generated at 2022-06-12 05:42:28.534337
# Unit test for function curried_map
def test_curried_map():
    for collection in [[], [1, 2, 3, 4], [1.0, 2.0, 3.0, 4.0]]:
        res1 = curried_map(identity)(collection)
        res2 = curried_map(identity, collection)
        assert res1 == res2
        assert res1 == collection



# Generated at 2022-06-12 05:42:31.625001
# Unit test for function eq
def test_eq():
    """
    Test function eq.

    :returns:
    :rtype:
    """
    assert eq(1)(1) == True
    assert eq(1)(-1) == False



# Generated at 2022-06-12 05:42:38.024679
# Unit test for function cond
def test_cond():
    print("Test function cond")
    print("Test: cond([(lambda x: x > 3, lambda x: x + 2)])")
    cond_result = cond([(lambda x: x > 3, lambda x: x + 2)])
    result_list = [
        cond_result(4),
        cond_result(1),
    ]
    result_list_true = [6, None]
    assert result_list == result_list_true, "Wrong result of func cond"



# Generated at 2022-06-12 05:42:41.952115
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 2) == 2
    assert find([], lambda x: False) is None
    assert find([], lambda x: True) is None



# Generated at 2022-06-12 05:42:52.515607
# Unit test for function cond
def test_cond():
    """
    Test function cond.
    """
    is_even = lambda x: x % 2 == 0
    power_two = lambda x: x ** 2
    power_three = lambda x: x ** 3
    power_four = lambda x: x ** 4
    power_five = lambda x: x ** 5
    power_six = lambda x: x ** 6

    assert cond([
        (is_even, power_two),
        (is_even, power_three),
        (is_even, power_four),
        (is_even, power_five),
        (is_even, power_six),
    ])(2) == 4

# Generated at 2022-06-12 05:42:55.736648
# Unit test for function cond
def test_cond():
    @cond([
        (eq(0), increase),
        (eq(1), identity)
    ])
    def test_cond(x):
        return x

    assert test_cond(0) == 1
    assert test_cond(1) == 1
    assert test_cond(2) is None

# Generated at 2022-06-12 05:42:58.980048
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq(1, 1, 1) == False


# Generated at 2022-06-12 05:43:07.703366
# Unit test for function find
def test_find():
    collection = [
        {'id': 1, 'name': 'a'},
        {'id': 2, 'name': 'b'},
        {'id': 3, 'name': 'c'},
    ]

    assert find(collection, lambda item: item['id'] == 1) == {'id': 1, 'name': 'a'}
    assert find(collection, lambda item: item['id'] == 2) == {'id': 2, 'name': 'b'}
    assert find(collection, lambda item: item['id'] == 3) == {'id': 3, 'name': 'c'}
    assert find(collection, lambda item: item['id'] == 4) is None



# Generated at 2022-06-12 05:43:11.641224
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq('str', 'str')

    assert eq(1)(1)
    assert not eq(1)(2)
    assert eq('str')('str')


# Generated at 2022-06-12 05:43:15.732774
# Unit test for function cond
def test_cond():
    @cond([

        (lambda a, b: a == 0, lambda: 'a == 0'),
        (lambda a, b: b == 0, lambda: 'b == 0'),
        (lambda a, b: True,   lambda: 'a == ' + str(a) + ', b == ' + str(b))
    ])
    def cond_func(a, b):
        pass

    print(cond_func(0, 1))
    print(cond_func(1, 0))
    print(cond_func(1, 1))



# Generated at 2022-06-12 05:43:38.347074
# Unit test for function curry
def test_curry():
    """
    Test for curry function.

    :returns: Unit test for curry function
    :rtype: Bool
    """
    assert identity(1) == 1
    assert identity(1)("1") == 1
    assert increase(5)("2") == 6
    assert increase(5)("2")(2) == 6



# Generated at 2022-06-12 05:43:46.416416
# Unit test for function eq
def test_eq():
    assert eq('a', 'a')
    assert not eq('a', 'b')
    assert not eq('a', 2)
    assert not eq({'a': 1}, {'a': 1})
    assert not eq({'a': 1}, {'a': 2})
    assert not eq({'a': 1}, {'b': 1})
    assert eq(None, None)
    assert not eq(None, False)
    assert not eq(None, 0)
    assert not eq(False, True)
    assert eq(False, False)
    assert not eq(False, 0)
    assert not eq(False, None)
    assert eq(1, True)
    assert eq(0, False)
    assert not eq(1, False)
    assert not eq(0, True)



# Generated at 2022-06-12 05:43:50.319255
# Unit test for function curried_filter
def test_curried_filter():

    numbers = [1, 2, 3, 4]
    divisibleBy2 = curried_filter(lambda x: x % 2 == 0)
    result = divisibleBy2(numbers)
    assert result == [2, 4]


# Generated at 2022-06-12 05:43:53.004886
# Unit test for function memoize
def test_memoize():
    def factorial(value):
        return reduce(lambda x, y: x * y, range(1, value + 1))

    cached_fac = memoize(factorial)

    assert cached_fac(5) == 120
    assert cached_fac(5) == 120
    assert cached_fac(5) == 120

# Generated at 2022-06-12 05:43:56.350121
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 1], eq(1)) == 1
    assert find([1, 2, 3, 1], eq(5)) is None


# Generated at 2022-06-12 05:44:06.410481
# Unit test for function cond
def test_cond():
    # define functions for test cond
    def condition_1(value: int) -> bool:
        return value > 10

    def condition_2(value: int) -> bool:
        return value < 10

    def execute_1():
        return 10

    def execute_2():
        return 100

    def execute_3():
        return 1000

    # test if condition are truly
    assert test_cond.cond([
        (condition_1, execute_1),
        (condition_2, execute_2)
    ])(10) == 100
    assert test_cond.cond([
        (condition_1, execute_1),
        (condition_2, execute_2),
        (condition_2, execute_3),
    ])(10) == 1000

# Generated at 2022-06-12 05:44:09.344819
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    print('All test for function curry was passed!')



# Generated at 2022-06-12 05:44:15.718471
# Unit test for function curry
def test_curry():
    print(curry(sum)()(1, 2, 3, 4, 5)(6)())
    print(curry(sum)(1)(2)(3)(4)(5)(6)())
    print(curry(sum)(1, 2, 3)(4, 5)(6)())
    print(curry(sum)(1, 2, 3, 4)(5, 6)())
    print(curry(sum)(1, 2, 3, 4, 5, 6)())



# Generated at 2022-06-12 05:44:21.080431
# Unit test for function cond
def test_cond():

    def _is_even(number: int) -> bool:
        return number % 2 == 0

    def _increase(number: int) -> int:
        return number + 1

    fn = cond([
        (_is_even, _increase),
        (identity, identity)
    ])

    assert fn(1) == 1
    assert fn(2) == 3

# Generated at 2022-06-12 05:44:28.576785
# Unit test for function curried_filter
def test_curried_filter():
    count = 0

    def true(x):
        nonlocal count
        count += 1
        return True

    def false(x):
        nonlocal count
        count += 1
        return False

    curriedFilterTrue = curried_filter(true)
    curriedFilterFalse = curried_filter(false)
    curriedFilterTrue([1, []])
    assert count == 2, "Should invoked 2 times a function"

    curriedFilterFalse([1, []])

    assert count == 4, "Should invoked 4 times a function"



# Generated at 2022-06-12 05:44:54.681095
# Unit test for function eq
def test_eq():
    def test_equality():
        assert eq(1, 1)

    def test_inequality():
        assert not eq(1, 4)

    def test_equality_partial_application_left():
        assert eq(1)(1)

    def test_equality_partial_application_both():
        assert eq(1)(1)

    test_equality()
    test_inequality()
    test_equality_partial_application_left()
    test_equality_partial_application_both()
    print('test_eq is passed')



# Generated at 2022-06-12 05:44:56.998530
# Unit test for function find
def test_find():
    assert find(['a', 'b'], lambda x: x == 'a') == 'a'
    assert find(['a', 'b'], lambda x: x == 'c') is None



# Generated at 2022-06-12 05:45:02.360256
# Unit test for function curried_map
def test_curried_map():

    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-12 05:45:04.206509
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2]) == [2, 3]



# Generated at 2022-06-12 05:45:09.376824
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 2) == 2
    assert find([1, 2, 3, 4], lambda x: x % 2 == 0) == 2
    assert find([1, 2, 3, 4], lambda x: x == 7) is None



# Generated at 2022-06-12 05:45:13.889439
# Unit test for function curried_map
def test_curried_map():
    mapped_generator = curried_map(increase)
    assert [2, 3, 4] == mapped_generator([1, 2, 3])

    mapped_generator = curried_map(increase, [1, 2, 3])
    assert [2, 3, 4] == mapped_generator()



# Generated at 2022-06-12 05:45:19.570150
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4]) == [2, 4]
    assert curried_filter(lambda x: x > 2)((1, 2, 3, 4)) == (3, 4)
    assert curried_filter(lambda x: x % 2 == 0, (1, 2, 3, 4)) == (2, 4)


# Generated at 2022-06-12 05:45:21.712007
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True


# Generated at 2022-06-12 05:45:25.304236
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-12 05:45:30.614704
# Unit test for function cond
def test_cond():
    @cond([
        (eq(1), identity),
        (eq(2), lambda v: v * v),
        (eq(3), lambda v: v * v * v),
    ])
    def result(value):
        return value

    assert result(1) == 1
    assert result(2) == 4
    assert result(3) == 27



# Generated at 2022-06-12 05:46:03.097067
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-12 05:46:04.521551
# Unit test for function eq
def test_eq():
    assert eq(3, 3) is True
    assert eq(3, 4) is False

