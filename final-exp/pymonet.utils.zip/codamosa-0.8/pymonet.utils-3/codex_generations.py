

# Generated at 2022-06-12 05:36:15.492300
# Unit test for function cond
def test_cond():
    cond_test = cond(
        [(lambda x: x < 0, lambda x: x * -1),
         (lambda x: x >= 10, increase),
         (lambda x: True, identity)])
    assert cond_test(12) == 13
    assert cond_test(-12) == 12
    assert cond_test(3) == 3


test_cond()

# Generated at 2022-06-12 05:36:22.701293
# Unit test for function cond
def test_cond():

    def first_case(n: int) -> bool:
        return n % 2 == 0

    def first_case_action(n: int) -> int:
        return n * 2

    def second_case(n: int) -> bool:
        return n == 3

    def second_case_action(n: int) -> int:
        return n * 3

    def last_case(n: int) -> bool:
        return True

    def last_case_action(n: int) -> int:
        return n * 4

    cases = [
        (first_case, first_case_action),
        (second_case, second_case_action),
        (last_case, last_case_action)
    ]

    result_function = cond(cases)

    assert result_function(1) == 4
    assert result_function

# Generated at 2022-06-12 05:36:24.683672
# Unit test for function eq
def test_eq():
    assert eq(0, 0)
    assert not eq(0, 1)



# Generated at 2022-06-12 05:36:35.348408
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda value: value == 0, lambda value: 'zero'),
        (lambda value: value == 1, lambda value: 'one'),
        (lambda value: value > 1, lambda value: 'more than one'),
    ])(0) == 'zero'

    assert cond([
        (lambda value: value == 0, lambda value: 'zero'),
        (lambda value: value == 1, lambda value: 'one'),
        (lambda value: value > 1, lambda value: 'more than one'),
    ])(1) == 'one'

    assert cond([
        (lambda value: value == 0, lambda value: 'zero'),
        (lambda value: value == 1, lambda value: 'one'),
        (lambda value: value > 1, lambda value: 'more than one'),
    ])(2) == 'more than one'


#

# Generated at 2022-06-12 05:36:38.320390
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-12 05:36:42.598424
# Unit test for function cond
def test_cond():
    assert cond(
        [(eq(0), curry(increase, 1)), (eq(1), curry(increase, 1))]
    )(0) == 1
    assert cond(
        [(eq(0), curry(increase, 1)), (eq(1), curry(increase, 1))]
    )(1) == 2


# Generated at 2022-06-12 05:36:53.046883
# Unit test for function cond
def test_cond():
    def true_predicate(*args):
        return True

    def false_predicate(*args):
        return False

    def empty_list():
        return []

    def empty_tuple():
        return ()

    def empty_dict():
        return {}

    def empty_string():
        return ''

    def false_value():
        return 0

    def non_empty_list():
        return [1]

    def non_empty_tuple():
        return (1,)

    def non_empty_dict():
        return {'k1': 'v1'}

    def non_empty_string():
        return 'non empty string'

    def true_value():
        return 1


# Generated at 2022-06-12 05:37:01.822445
# Unit test for function cond
def test_cond():
    # Arrange
    find_args = []
    find_function = lambda collection, key: [find_args.append(argument) for argument in [collection, key]]

    # Act
    cond_function = cond([
        (lambda x: True, lambda x: x),
        (lambda x: False, lambda x: x),
    ])
    cond_function(find_function, [])

    # Assert
    assert find_args[0] == [
        (lambda x: True, lambda x: x),
        (lambda x: False, lambda x: x)
    ]


if __name__ == '__main__':
    test_cond()

# Generated at 2022-06-12 05:37:07.902429
# Unit test for function memoize
def test_memoize():
    assert memoize(lambda x: x ** 2)(3) == 9
    assert memoize(lambda x: x + 1)(3) == 4
    assert memoize(lambda x: x + 1)(7) == 8
    assert memoize(lambda x: x ** 2)(3) == 9
    assert memoize(lambda x: x + 2)(3) == 5
    assert memoize(lambda x: x + 2)(3) == 5



# Generated at 2022-06-12 05:37:15.849859
# Unit test for function curried_map
def test_curried_map():
    curried_map_function = curried_map(identity)
    assert curried_map_function([10, -10]) == [10, -10]

    curried_map_function = curried_map(identity)
    assert curried_map_function([]) == []

    curried_map_function = curried_map(increase)
    assert curried_map_function([10, -10]) == [11, -9]



# Generated at 2022-06-12 05:37:24.406077
# Unit test for function eq
def test_eq():
    assert eq(3, 3)
    assert not eq(3, 2)
    assert eq(3, curry(lambda x, y, z: x + y + z)(1, 1, 1))
    assert eq(curry(lambda x, y, z: x + y + z)(1, 1, 1), 3)


# Generated at 2022-06-12 05:37:25.999862
# Unit test for function eq
def test_eq():
    eq()(2)(2)
    eq()(2)(3)



# Generated at 2022-06-12 05:37:30.441532
# Unit test for function curry
def test_curry():
    def curried_add(x):
        return lambda y: x + y

    curried_add(1)(2) == 3

    @curry
    def add(x, y):
        return x + y

    assert add(1)
    assert add(1)(2) == 3



# Generated at 2022-06-12 05:37:34.088949
# Unit test for function curried_map
def test_curried_map():
    result = curried_map(lambda x: x + 1, [1, 2, "string"])
    assert result == [2, 3, "string"]


# Generated at 2022-06-12 05:37:44.298317
# Unit test for function cond
def test_cond():
    def condition_function_1(value):
        return value % 2 == 0

    def condition_function_2(value):
        return value % 3 == 0

    def condition_function_3(value):
        return value % 5 == 0

    def execute_function_1(value):
        return "Sorry, I cant help you"

    def execute_function_2(value):
        return value ** 2

    def execute_function_3(value):
        return value ** 3

    execute_function = cond((
        (condition_function_1, execute_function_1),
        (condition_function_2, execute_function_2),
        (condition_function_3, execute_function_3)
    ))

    assert execute_function(2) == "Sorry, I cant help you"
    assert execute_function(3) == 9
   

# Generated at 2022-06-12 05:37:55.437846
# Unit test for function curried_filter
def test_curried_filter():
    test_list = [1, 2, 3, 4]
    first_test_cond = lambda x: x % 2 == 0
    second_test_cond = lambda x: x == 2
    third_test_cond = lambda x: x == 0
    first_test_executor = curried_filter(first_test_cond, test_list)
    first_test_result = first_test_executor()
    second_test_result = curried_filter(second_test_cond, None)(test_list)
    third_test_result = curried_filter(third_test_cond, test_list)()
    assert first_test_result == [2, 4]
    assert second_test_result == [2]
    assert third_test_result == []



# Generated at 2022-06-12 05:37:58.939976
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)(range(10)) == range(10)
    assert curried_map(increase)(range(10)) == range(1, 11)
    assert curried_map(increase, range(10)) == range(1, 11)


# Generated at 2022-06-12 05:38:01.165389
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq({1: []}, {2: []})



# Generated at 2022-06-12 05:38:12.658838
# Unit test for function cond
def test_cond():
    def is_equal(a, b):
        return a == b

    def is_less(a, b):
        return a < b

    def is_larger(a, b):
        return a > b

    def plus(a: int, b: int) -> int:
        return a + b

    def minus(a: int, b: int) -> int:
        return a - b

    def multiply(a: int, b: int) -> int:
        return a * b

    def divide(a: int, b: int) -> int:
        return a / b

    fn = cond([
        (is_equal, plus),
        (is_less, minus),
        (is_larger, multiply),
        (lambda *args: True, divide)
    ])

    assert fn(1, 2) == 0.

# Generated at 2022-06-12 05:38:18.958078
# Unit test for function eq
def test_eq():
    eq1 = eq(1)
    eq2 = eq(2)
    eq1_1 = eq(1, 1)
    eq1_2 = eq(1, 2)
    assert eq1_1
    assert not eq1_2
    assert eq1(1)
    assert not eq1(2)
    assert not eq2(1)



# Generated at 2022-06-12 05:38:29.016636
# Unit test for function curried_filter
def test_curried_filter():
    # Given
    collection = [1, 2, 3]
    filterer = lambda x: x % 2 == 0

    # When
    result = curried_filter(filterer)(collection)

    # Then
    assert result == [2]


# Generated at 2022-06-12 05:38:31.927207
# Unit test for function cond
def test_cond():
    assert cond(
        [
            (lambda n: n % 2 == 0, lambda n: n // 2),
            (lambda n: n % 2 == 1, lambda n: n * 3 + 1)
        ])(7) == 22



# Generated at 2022-06-12 05:38:33.622004
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 1, [1, 2, 3]) == [2, 3]

# Generated at 2022-06-12 05:38:41.529282
# Unit test for function memoize
def test_memoize():
    def factorial(number):
        def factorial_step(number, accumulator):
            if number == 1:
                return accumulator
            return factorial_step(number - 1, number * accumulator)

        return factorial_step(number, 1)

    assert factorial(0) == 1
    assert factorial(1) == 1
    assert factorial(5) == 120

    factorial_memoized = memoize(factorial)
    assert factorial_memoized(0) == 1
    assert factorial_memoized(1) == 1
    assert factorial_memoized(5) == 120



# Generated at 2022-06-12 05:38:48.612064
# Unit test for function find
def test_find():
    assert find([], lambda item: item) is None
    assert find([1, 2, 3, 4], eq(1)) == 1
    assert find([1, 2, 3, 4], eq(4)) == 4
    assert find([1, 2, 3, 4], eq(5)) is None
    assert find([1, 2, 3, 4, 1, 2], eq(1)) == 1



# Generated at 2022-06-12 05:38:55.917149
# Unit test for function cond
def test_cond():
    def f(value): return value < 10
    def g(value): return value + 2
    def h(value): return value * 2
    def j(value): return value ** 2

    assert cond([(f, g), (f, h), (f, j)])(4) == 6
    assert cond([(f, g), (f, h), (f, j)])(10) == 4
    assert cond([(f, g), (f, h), (f, j)])(10.1) == 100

test_cond()

# Generated at 2022-06-12 05:39:01.950980
# Unit test for function cond
def test_cond():
    test_cond_1 = cond([
        (lambda x: x < 0, lambda x: x),
        (lambda x: x == 0, lambda x: 0),
        (lambda x: x > 0, lambda x: x)
    ])
    assert test_cond_1(-1) == -1
    assert test_cond_1(0) == 0
    assert test_cond_1(1) == 1

# Generated at 2022-06-12 05:39:06.788556
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1, 2, 3)
    assert not eq(1, 2, 3, 4)
    assert not eq(1, 2, 3, 4, 5)



# Generated at 2022-06-12 05:39:13.044901
# Unit test for function memoize
def test_memoize():
    # True for functional style
    assert memoize(identity)(1) == 1
    assert memoize(identity)(2) == 2
    assert memoize(identity)(1) == 1
    assert memoize(identity)(1) == 1

    # False for functional style
    memoize(identity)(100)
    memoize(identity)(101)
    memoize(identity)(100)
    memoize(identity)(100)
    memoize(identity)(100)
    memoize(identity)(100)
    memoize(identity)(100)
    memoize(identity)(100)

    # True for functional style
    assert memoize(identity, key=lambda x, y: y == x * 5)(100) == 100

# Generated at 2022-06-12 05:39:23.444079
# Unit test for function cond
def test_cond():
    def is_list(value):
        return isinstance(value, list)

    def is_tuple(value):
        return isinstance(value, tuple)

    def is_string(value):
        return isinstance(value, str)

    def is_int(value):
        return isinstance(value, int)

    def to_list(value):
        return list(value)

    def to_tuple(value):
        return tuple(value)

    def to_string(value):
        return str(value)

    def to_int(value):
        return int(value)

    def is_none(value):
        return value is None

    def to_none():
        return None


# Generated at 2022-06-12 05:39:52.319478
# Unit test for function memoize
def test_memoize():
    def something(value):
        return value + 1

    memoized_something = memoize(something)
    assert memoized_something(-1) == something(-1)
    assert memoized_something(-1) == something(-1)
    assert memoized_something(-1) == something(-1)
    assert memoized_something(-1) == something(-1)


if __name__ == '__main__':
    # Unit test for function identity
    assert identity(1) == 1
    assert identity(1) == 1
    assert identity(1) == 1
    assert identity(1) == 1

    # Unit test for function increase
    assert increase(0) == 1
    assert increase(1) == 2
    assert increase(2) == 3
    assert increase(3) == 4

    # Unit test for function eq

# Generated at 2022-06-12 05:39:54.746083
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False



# Generated at 2022-06-12 05:39:57.042260
# Unit test for function curry
def test_curry():
    c = curry(lambda x, y, z: x + y + z)(1)(2)(3)
    assert c == 6



# Generated at 2022-06-12 05:40:01.444708
# Unit test for function curried_filter
def test_curried_filter():
    filter_array_by_seven = curried_filter(eq(7))
    result = filter_array_by_seven([1, 2, 3, 4, 7, 5, 6, 7, 7, 8, 9])
    assert result == [7, 7, 7]


# Generated at 2022-06-12 05:40:09.417289
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x == 1, lambda x: 'one'),
        (lambda x: x == 2, lambda x: 'two'),
        (lambda _: True, lambda x: 'other')
    ])(1) == 'one'

    assert cond([
        (lambda x: x == 1, lambda x: 'one'),
        (lambda x: x == 2, lambda x: 'two'),
        (lambda _: True, lambda x: 'other')
    ])(2) == 'two'

    assert cond([
        (lambda x: x == 1, lambda x: 'one'),
        (lambda x: x == 2, lambda x: 'two'),
        (lambda _: True, lambda x: 'other')
    ])(3) == 'other'



# Generated at 2022-06-12 05:40:19.875184
# Unit test for function cond
def test_cond():
    if cond([
        (lambda x: x < 0, lambda x: x - 1),
        (lambda x: x == 0, lambda x: x),
        (lambda x: x > 0, lambda x: x + 1)
    ])(1) != 2:
        raise ValueError()
    if cond([
        (lambda x: x < 0, lambda x: x - 1),
        (lambda x: x == 0, lambda x: x),
        (lambda x: x > 0, lambda x: x + 1)
    ])(0) != 0:
        raise ValueError()

# Generated at 2022-06-12 05:40:22.247408
# Unit test for function memoize
def test_memoize():
    @memoize
    def sum(a, b):
        return a + b

    assert sum(2, 3) == 5
    assert sum(2, 3) == 5

# Generated at 2022-06-12 05:40:26.552536
# Unit test for function memoize
def test_memoize():
    def sum_to(x):
        return x + sum_to(x - 1) if x > 1 else 1

    sum_to_3 = cond([
        (eq(3), lambda: 1),
        (lambda x: True, lambda x: x + sum_to(x - 1))
    ])

    assert sum_to(5) == 15
    assert sum_to_3(5) == 15



# Generated at 2022-06-12 05:40:31.524448
# Unit test for function curried_filter
def test_curried_filter():
    collection = [increase, increase, identity]
    filtered = curried_filter(lambda x: x(1) == 2, collection)
    if len(filtered) != 2 or not filtered[0] == increase or not filtered[1] == increase:
        raise Exception("curried_filter function is wrong")


# Generated at 2022-06-12 05:40:42.187037
# Unit test for function cond
def test_cond():
    increment = lambda value: value + 1
    decrement = lambda value: value - 1
    assert cond([
        (lambda value: value < 0, increment),
        (lambda value: value > 0, decrement),
        (lambda value: value == 0, lambda value: value),
    ])(1) == 0
    assert cond([
        (lambda value: value < 0, increment),
        (lambda value: value > 0, decrement),
        (lambda value: value == 0, lambda value: value),
    ])(-1) == 0
    assert cond([
        (lambda value: value < 0, increment),
        (lambda value: value > 0, decrement),
        (lambda value: value == 0, lambda value: value),
    ])(0) == 0



# Generated at 2022-06-12 05:41:00.528645
# Unit test for function find
def test_find():
    test_data = [1, 2, 3, 4, 5, 6]
    eq_to_5 = eq(5)
    eq_to_7 = eq(7)

    assert find(test_data, eq_to_5) == 5
    assert find(test_data, eq_to_7) is None



# Generated at 2022-06-12 05:41:03.126163
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(add, [1, 2, 3])(3) == [4, 5, 6]



# Generated at 2022-06-12 05:41:10.109036
# Unit test for function memoize
def test_memoize():
    from random import randint
    from time import time

    def timeit(fn, *args):
        time0 = time()
        fn(*args)
        time1 = time()
        return time1 - time0

    def fibonacci(n):
        if n < 2:
            return 1
        else:
            return fibonacci(n - 1) + fibonacci(n - 2)

    def test(n, title):
        slow_time = timeit(fibonacci, n)
        fast_time = timeit(memoize(fibonacci), n)
        print("%s - time without memoize: %.3f, time with memoize: %.3f" % (title, slow_time, fast_time))

    test(10, "Test 10")
    test(50, "Test 50")

# Generated at 2022-06-12 05:41:12.124770
# Unit test for function eq
def test_eq():
    assert True is eq(2, 2)
    assert True is eq(eq(2, 2), True)
    assert False is eq(2, 3)
    assert False is eq(eq(2, 3), False)



# Generated at 2022-06-12 05:41:16.369022
# Unit test for function curried_map
def test_curried_map():
    curried_map_typed = curried_map[Any, List[Any]]
    numbers_double = curried_map_typed(lambda x: x * 2)
    assert numbers_double([1, 2, 3]) == [2, 4, 6]


# Generated at 2022-06-12 05:41:23.681296
# Unit test for function memoize
def test_memoize():
    from random import randint

    test_numbers = [randint(0, 100) for _ in range(10)]

    def my_function(x: int) -> int:
        return x + 1

    my_memoized_function = memoize(my_function)

    for i in test_numbers:
        assert my_function(i) == my_memoized_function(i)

# Generated at 2022-06-12 05:41:32.912276
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, []) == []
    assert curried_map(identity, [0]) == [0]
    assert curried_map(identity, [0, 1, 2]) == [0, 1, 2]
    assert curried_map(increase, [0]) == [1]
    assert curried_map(increase, [0, 1, 2]) == [1, 2, 3]
    assert curried_map(lambda x: x + 1, [0, 1, 2]) == [1, 2, 3]



# Generated at 2022-06-12 05:41:34.644210
# Unit test for function find
def test_find():
    collection = range(1, 10)
    key = lambda x: x > 5

    assert find(collection, key) == 6



# Generated at 2022-06-12 05:41:45.054811
# Unit test for function cond
def test_cond():
    def is_0(value):
        return value == 0

    def is_1(value):
        return value == 1

    def is_2(value):
        return value == 2

    def sum_of_arguments(*args):
        return sum(args)

    def product_of_arguments(*args):
        return reduce(lambda x,y: x * y, args)

    def difference_of_arguments(*args):
        return reduce(lambda x,y: x - y, args)

    test_cond = cond([
        (is_0, sum_of_arguments),
        (is_1, product_of_arguments),
        (is_2, difference_of_arguments)
    ])

    assert test_cond(0, 2, 3, 4) == 9

# Generated at 2022-06-12 05:41:49.899959
# Unit test for function eq
def test_eq():
    values_to_test = [(1, 1, True), (1, 2, False), ('a', 'a', True), ('a', 'b', False)]
    for left, right, result in values_to_test:
        assert eq(left, right) == result, \
            'wrong result for test with arguments {} and {}'.format(left, right)



# Generated at 2022-06-12 05:42:26.504676
# Unit test for function memoize
def test_memoize():
    memoized_square = memoize(lambda x: x ** 2)
    assert memoized_square(5) == 25
    assert memoized_square(5) == 25
    assert memoized_square(5) == 25
    assert memoized_square(5) == 25
    assert memoized_square(5) == 25

    memoized_add_and_square = memoize(lambda x, y: (x + y) ** 2)
    assert memoized_add_and_square(5, 1) == 36
    assert memoized_add_and_square(5, 1) == 36
    assert memoized_add_and_square(5, 1) == 36
    assert memoized_add_and_square(5, 1) == 36
    assert memoized_add_and_square(5, 1) == 36

    memoized_square

# Generated at 2022-06-12 05:42:28.577126
# Unit test for function eq
def test_eq():
    assert eq(1, 1)

    eq_1 = eq(1)
    assert eq_1(1)



# Generated at 2022-06-12 05:42:31.624109
# Unit test for function memoize
def test_memoize():
    def add_one(num):
        return num + 1

    assert memoize(add_one)(1) == 2
    assert memoize(add_one)(1) == 2



# Generated at 2022-06-12 05:42:33.617607
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x == 3)([1, 2, 3, 4]) == [3]

# Generated at 2022-06-12 05:42:38.255375
# Unit test for function curried_map
def test_curried_map():
    """
    Test curried_map(mapper: Function(A) -> B, collection: List[A]) -> List[B].

    :returns: None
    :rtype: None
    """
    collection = [1, 2, 3]
    doubled = curried_map(lambda value: value * 2, collection)
    assert doubled == [2, 4, 6]



# Generated at 2022-06-12 05:42:47.041341
# Unit test for function cond
def test_cond():
    """
    >>> test_cond()
    'value is 1'
    'value is 0'
    """
    value_condition = lambda value: value == 1
    value_condition2 = lambda value: value == 0
    execute_function = lambda value: print('value is 1')
    execute_function2 = lambda value: print('value is 0')
    test_value = cond([
        (value_condition, execute_function),
        (value_condition2, execute_function2)
    ])
    test_value(1)
    test_value(0)



# Generated at 2022-06-12 05:42:49.919006
# Unit test for function find
def test_find():
    assert find([0, 1, 2, 3, 4], lambda x: x == 1) == 1
    assert find([0, 1, 2, 3, 4], lambda x: x == 5) is None

# Generated at 2022-06-12 05:42:53.588544
# Unit test for function curried_filter
def test_curried_filter():
    assert [] == curried_filter(lambda x: x > 5)([1, 2, 3])
    assert [5] == curried_filter(lambda x: x < 5)([5, 3, 6, 7])



# Generated at 2022-06-12 05:42:59.397321
# Unit test for function curried_filter
def test_curried_filter():
    is_even = lambda x: True if x % 2 == 0 else False
    is_odd = lambda x: True if x % 2 == 0 else False
    curried = curried_filter(is_even)
    result = curried([1, 2, 3, 4])
    expected = [2, 4]
    assert result == expected



# Generated at 2022-06-12 05:43:04.439112
# Unit test for function memoize
def test_memoize():
    import random

    function = identity

    @memoize
    def memoize_function(argument):
        return function(argument)

    for i in range(10):
        argument = random.randint(0, 99999)
        assert memoize_function(argument) == function(argument)
    print('test_memoize passed')

# Generated at 2022-06-12 05:44:24.866858
# Unit test for function curry
def test_curry():
    assert curry(increase)(1) == 2
    assert curry(increase)(1)(2)(3)(4) == 5
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(increase, 2)(1)(2) == 3
    assert curry(lambda x, y: x + y, 2)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z, 2)(1)(2) == 3
    assert curry(lambda x, y, z, p: x + y + z + p, 3)(1)(2) == 3



# Generated at 2022-06-12 05:44:33.757976
# Unit test for function cond
def test_cond():
    def test_func(value):
        return cond([(lambda x: x is None, lambda: 'None'),
                     (lambda x: isinstance(x, str), lambda x: x[0]),
                     (lambda x: x == 1, lambda: '1'),
                     (lambda x: x < 0, lambda: '<'),
                     (lambda x: x > 0, lambda: '>')])(value)

    test_func(None) == 'None'
    test_func('str') == 'str'
    test_func(1) == '1'
    test_func(0) == '>'
    test_func(-1) == '<'
    test_func(4) == '>'
    test_func(-4) == '<'



# Generated at 2022-06-12 05:44:39.604187
# Unit test for function memoize
def test_memoize():
    cache: List[Tuple[int, Any]] = []
    example_function = lambda x: x * x
    memoized_function = memoize(example_function)

    for i in range(5):
        memoized_function(i)
    for i in range(5):
        memoized_function(i)
    assert len(memoized_function.cache) == 5



# Generated at 2022-06-12 05:44:49.925442
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x > 0, lambda x: '{} is positive'.format(x)),
        (lambda x: x < 0, lambda x: '{} is negative'.format(x)),
        (lambda x: x == 0, lambda x: '{} is zero'.format(x)),
    ])(-1) == '-1 is negative'
    assert cond([
        (lambda x: x > 0, lambda x: '{} is positive'.format(x)),
        (lambda x: x < 0, lambda x: '{} is negative'.format(x)),
        (lambda x: x == 0, lambda x: '{} is zero'.format(x)),
    ])(0) == '0 is zero'

# Generated at 2022-06-12 05:44:58.305870
# Unit test for function memoize
def test_memoize():
    from random import randint
    from time import time

    @memoize
    def factorial(n):
        if n == 0 or n == 1:
            return 1
        return n * factorial(n - 1)

    start = time()
    for _ in range(100):
        rand = randint(1, 1000)
        print(f'factorial({rand}) = {factorial(rand)}')
    print(f'Time for not cached execution: {time() - start} seconds')

    start = time()
    for _ in range(100):
        rand = randint(1, 1000)
        print(f'factorial({rand}) = {factorial(rand)}')
    print(f'Time for cached execution: {time() - start} seconds')


if __name__ == '__main__':
    test_mem

# Generated at 2022-06-12 05:45:04.901146
# Unit test for function memoize
def test_memoize():
    def function1(argument):
        return argument * 2

    memoized_fn = memoize(function1)
    assert memoized_fn(1) == 2
    assert memoized_fn(1) == 2
    assert memoized_fn(2) == 4
    assert memoized_fn(2) == 4
    assert memoized_fn(1) == 2
    assert memoized_fn(3) == 6
    assert memoized_fn(1) == 2


# Generated at 2022-06-12 05:45:14.074179
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b, c: a + b + c)(1)(2)(3) == 6
    assert curry(lambda a, b, c: a + b + c)(1, 2, 3) == 6
    assert curry(lambda a, b, c: a + b + c)(1)(2, 3) == 6
    assert curry(lambda a, b, c: a + b + c)(1, 2)(3) == 6
    assert curry(lambda a, b, c: a + b + c)(_)(2)(3) == 6

    assert curry(lambda *args: list(args))(1)(2)(3) == [1, 2, 3]
    assert curry(lambda *args: list(args))(1, 2)(3) == [1, 2, 3]

# Generated at 2022-06-12 05:45:19.735107
# Unit test for function memoize
def test_memoize():
    f = memoize(lambda x: x * x)
    assert f(3) == 9
    assert f(3) == 9
    f = memoize(lambda x: x * x, key=lambda a, b: a == b)
    assert f(3) == 9
    assert f(3) == 9
    assert f(4) == 16
    assert f(4) == 16



# Generated at 2022-06-12 05:45:22.725013
# Unit test for function eq
def test_eq():
    assert eq(1, 2) == False
    assert eq(1, 1) == True


# Generated at 2022-06-12 05:45:27.346621
# Unit test for function cond
def test_cond():
    execute_function = cond([
        (lambda x: x > 0, identity),
        (lambda x: x < 0, decrease),
        (lambda x: True, increase)
    ])

    assert execute_function(10) == 10
    assert execute_function(-1) == -2
    assert execute_function(0) == 1
