

# Generated at 2022-06-24 00:44:20.495388
# Unit test for function curry
def test_curry():
    import unittest

    def test_function(x, y, z, k):
        return x + y + z + k + 42

    temp_function = curry(test_function)
    temp_function = temp_function(1)
    temp_function = temp_function(2)
    temp_function = temp_function(3)
    assert temp_function(4) == 1 + 2 + 3 + 4 + 42

    class TestMethods(unittest.TestCase):
        def test_function_curry(self):
            def test_function(x, y, z, k):
                return x + y + z + k + 42

            temp_function = curry(test_function)
            temp_function = temp_function(1)
            temp_function = temp_function(2)
            temp_function = temp_function(3)

# Generated at 2022-06-24 00:44:22.092391
# Unit test for function compose
def test_compose():
    assert (compose(1, increase, increase) == 3)
    assert (compose('hello', lambda x: x.upper(), lambda x: x + ' world') == 'HELLO WORLD')


# Generated at 2022-06-24 00:44:23.854418
# Unit test for function find
def test_find():
    assert find([], None) is None
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 5) is None


# Unit tests for function cond

# Generated at 2022-06-24 00:44:24.618524
# Unit test for function identity
def test_identity():
    assert identity(1) == 1


# Generated at 2022-06-24 00:44:29.842160
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6]) == [2, 4, 6]



# Generated at 2022-06-24 00:44:33.292379
# Unit test for function identity
def test_identity():
    test_value = "functional programming"
    assert identity(test_value) == test_value


# Generated at 2022-06-24 00:44:35.391371
# Unit test for function pipe
def test_pipe():
    assert pipe(1, lambda x: x + 1, lambda x: x * 2) == 4



# Generated at 2022-06-24 00:44:37.959617
# Unit test for function compose
def test_compose():
    assert(compose(10, increase, increase, increase) == 13)



# Generated at 2022-06-24 00:44:39.611219
# Unit test for function compose
def test_compose():
    val = compose(
        1,
        increase,
        increase
    )

    assert val == 3



# Generated at 2022-06-24 00:44:44.620262
# Unit test for function memoize
def test_memoize():
    cache = [
        (1, 2),
        (3, 4),
        (5, 6),
    ]
    cache_clear = []
    key = lambda cacheItem, argument: cacheItem[0] == argument
    fn = lambda argument: argument + 1

    class TestMemoize:
        def test_when_prev_results_are_equals_cacheItem_then_return_cacheItem(self):
            result = find(cache, lambda cacheItem: key(cacheItem, 1))
            assert result == (1, 2)

        def test_when_prev_results_are_not_equals_cacheItem_then_return_None(self):
            result = find(cache, lambda cacheItem: key(cacheItem, 2))
            assert result is None


# Generated at 2022-06-24 00:44:48.270810
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(
        lambda x: x % 2 == 0,
        [1, 2, 3, 4, 5, 6]
    ) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0)(
        [1, 2, 3, 4, 5, 6]
    ) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0)(range(1, 7)) == [2, 4, 6]



# Generated at 2022-06-24 00:44:50.600592
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y, z: x * y * z)(2)(3)(4) == 24



# Generated at 2022-06-24 00:44:55.538317
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4]) == [2, 4]


# Generated at 2022-06-24 00:45:01.892647
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    f_map_function = curried_map(lambda x: x ** 3)
    assert f_map_function([1, 2, 3]) == [1, 8, 27]
    assert f_map_function([1, 2, 3]) == [1, 8, 27]



# Generated at 2022-06-24 00:45:06.132806
# Unit test for function curried_filter
def test_curried_filter():
    even = lambda x: x % 2 == 0
    assert curried_filter(even)([1, 2, 3, 4]) == [2, 4]
    assert curried_filter(even)([2, 4]) == [2, 4]



# Generated at 2022-06-24 00:45:06.785339
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:45:08.506075
# Unit test for function find
def test_find():
    collection = [[1, 2], [3, 4]]
    assert find(collection, eq([1, 2])) == [1, 2]
    assert find(collection, eq([2, 3])) is None



# Generated at 2022-06-24 00:45:12.518916
# Unit test for function cond
def test_cond():
    from operator import lt, gt

    assert cond([
        (lambda a: lt(a, 1), lambda _: 0),
        (lambda a: lt(a, 2), lambda a: 1),
        (lambda a: gt(a, 3), lambda a: 3),
    ])(5) == 3
    assert cond([
        (lambda a: lt(a, 1), lambda _: 0),
        (lambda a: lt(a, 2), lambda a: 1),
        (lambda a: gt(a, 3), lambda a: 3),
    ])(1) == 1



# Generated at 2022-06-24 00:45:14.481470
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(True) is True
    assert identity(None) is None
    assert identity({}) == {}
    assert identity([]) == []
    assert identity(()) == ()

# Generated at 2022-06-24 00:45:18.098834
# Unit test for function curried_map
def test_curried_map():
    assert curried_map([increase])([1]) == [2]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map([increase, increase])([1, 2, 3]) == [2, 3, 4]
    assert curried_map([increase, identity])([1, 2, 3]) == [2, 2, 3]



# Generated at 2022-06-24 00:45:22.318596
# Unit test for function curry
def test_curry():
    add = lambda x, y: x + y
    assert 2 == curry(add)(2, 0)
    assert 3 == curry(add, 2)(1)
    assert 6 == curry(add, 2)(2, 2)
    assert 11 == curry(add, 2)(2, 2, 5)



# Generated at 2022-06-24 00:45:24.134955
# Unit test for function eq
def test_eq():
    eq(1, 1)



# Generated at 2022-06-24 00:45:28.309567
# Unit test for function identity
def test_identity():
    assert identity(0) == 0, 'Function identity not works correctly'
    assert identity('0') == '0', 'Function identity not works correctly'
    assert identity(1) == 1, 'Function identity not works correctly'
    assert identity([]) == [], 'Function identity not works correctly'
    assert identity((1, 2)) == (1, 2), 'Function identity not works correctly'



# Generated at 2022-06-24 00:45:29.549863
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-24 00:45:31.215088
# Unit test for function curried_filter
def test_curried_filter():
    list_ = [1, 2, 3]

    assert curried_filter(lambda value: value == 1, list_) == [1]



# Generated at 2022-06-24 00:45:36.468270
# Unit test for function identity
def test_identity():
    """
    Test identity function.

    :returns: None
    """
    print("Test identity function...")
    assert identity(1) == 1



# Generated at 2022-06-24 00:45:38.375679
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 1) == 1
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-24 00:45:44.768836
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(1) == 2
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6



# Generated at 2022-06-24 00:45:49.428366
# Unit test for function memoize
def test_memoize():
    @memoize
    def sum_to(n: int) -> int:
        if n == 1:
            return 1
        return n + sum_to(n - 1)

    assert sum_to(5) == 15
    assert sum_to(5) == 15


# Generated at 2022-06-24 00:45:59.018751
# Unit test for function cond
def test_cond():
    def f1(a):
        return a

    def f2(a):
        return a + 1

    def f3(a):
        return a + 2

    def f4(a):
        return a + 3

    def gt2(a):
        return a > 2

    def gt3(a):
        return a > 3

    def gt5(a):
        return a > 5

    test_cond_function_1 = cond([
        (gt5, f1),
        (gt3, f2),
        (gt2, f3),
        (lambda x: True, f4)
    ])

    assert test_cond_function_1(2) == 5
    assert test_cond_function_1(3) == 6
    assert test_cond_function_1(4) == 7

# Generated at 2022-06-24 00:46:01.194847
# Unit test for function pipe
def test_pipe():
    # Given
    result = pipe(
        'TEST',
        str.lower,
        str.capitalize,
        lambda s: s * 2,
    )
    # When

    # Then
    assert result == 'Testtest'

test_pipe()



# Generated at 2022-06-24 00:46:09.517969
# Unit test for function cond
def test_cond():
    # Simple test
    assert cond([(eq(1), lambda x: x+1), (eq(2), lambda x: x+2)]) == compose(cond([(eq(1), lambda x: x+1), (eq(2), lambda x: x+2)]))(2)
    # Curried test
    assert cond([(eq(1), lambda x: x+1), (eq(2), lambda x: x+2)])(2) == compose(cond([(eq(1), lambda x: x+1), (eq(2), lambda x: x+2)]))(2)

# Generated at 2022-06-24 00:46:14.717735
# Unit test for function compose
def test_compose():
    """
    composing(compose, [[identity, increase, increase],
                        [identity, increase, increase, increase]])
    """
    def identity(x):
        return x

    def increase(x):
        return x + 1

    def increase3(x):
        return x + 3

    def increase5(x):
        return x + 5

    assert compose(2, identity, increase) == 3
    assert compose(2, identity, increase, increase) == 4
    assert compose(2, identity, increase, increase, increase) == 5
    assert compose(2, increase3, increase3) == 8



# Generated at 2022-06-24 00:46:19.322377
# Unit test for function curry
def test_curry():
    assert eq(1, 1)
    assert eq(1)(1)
    assert eq(1, 1)
    assert eq(1)(1)
    assert eq(1)(1)



# Generated at 2022-06-24 00:46:21.563789
# Unit test for function compose
def test_compose():
    assert compose(0, lambda x: x + 1, lambda x: x + 2) == 0 + 1 + 2



# Generated at 2022-06-24 00:46:27.379074
# Unit test for function curried_map
def test_curried_map():
    print("Test curried_map", end="")
    assert curried_map(lambda value: value + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda value: value + 1, [1]) == [2]
    assert curried_map(lambda value: value + 1, []) == []
    print(" - OK")



# Generated at 2022-06-24 00:46:31.709252
# Unit test for function find
def test_find():
    try:
        not_found_element = find([1,2,3], lambda x: x == 4)
        assert not_found_element is None
    except Exception as ex:
        print('Error lambda function not working. Error message: ' + str(ex))
    try:
        found_element = find([1,2,3], lambda x: x == 2)
        assert found_element is not None
        assert found_element == 2
    except Exception as ex:
        print('Error lambda function not working. Error message: ' + str(ex))


# Generated at 2022-06-24 00:46:33.005953
# Unit test for function increase
def test_increase():
    assert increase(1) == 2

# Generated at 2022-06-24 00:46:36.941037
# Unit test for function curried_map
def test_curried_map():
    curried_map_increase = curried_map(increase)
    print(curried_map_increase([1, 2]))
    print(curried_map_increase([3, 4]))



# Generated at 2022-06-24 00:46:39.458148
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 2, [1, 2, 3]) == [3, 4, 5]



# Generated at 2022-06-24 00:46:41.947431
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(3) == 4
    assert increase(4) == 5



# Generated at 2022-06-24 00:46:43.526747
# Unit test for function find
def test_find():
    assert find([], lambda item: True) is None
    assert find([0], eq(0)) == 0


# Generated at 2022-06-24 00:46:47.299787
# Unit test for function pipe
def test_pipe():
    assert pipe(
        'First test string',
        lambda x: f'{x} second test string',
        lambda x: x.title(),
        lambda x: x[:5]
    ) == 'First'


# Generated at 2022-06-24 00:46:51.478257
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, range(10)) == range(10)
    assert curried_map(increase, range(10)) == range(1, 11)
    assert curried_map(increase)(range(10)) == range(1, 11)

    # add1 = curried_map(increase)
    # assert add1(range(10)) == range(1, 11)
    # assert add1(range(5)) == range(1, 6)
    #
    # identity_map = curried_map(identity)
    # assert identity_map(range(10)) == range(10)



# Generated at 2022-06-24 00:46:58.042591
# Unit test for function cond
def test_cond():
    eq_1 = cond([
        (eq(0), lambda: 'water freezes at 0°C'),
        (eq(100), lambda: 'water boils at 100°C'),
        (eq(37), lambda: 'nothing special happens at 37°C'),
    ])
    eq_2 = cond([
        (eq(1), lambda: 'ONE'),
        (eq(2), lambda: 'TWO'),
        (eq(3), lambda: 'THREE'),
    ])
    assert eq_1(5) == 'nothing special happens at 37°C'
    assert eq_2(2) == 'TWO'


# Generated at 2022-06-24 00:47:03.550431
# Unit test for function memoize
def test_memoize():
    x = memoize(lambda x: x * 2, key=(lambda x1, x2: x1 == x2))
    assert x(1) == 2
    assert x(2) == 4
    assert x(1) == 2
    assert x(3) == 6
    assert x(4) == 8
    assert x(1) == 2
    assert x(2) == 4
    assert x(1) == 2


# Generated at 2022-06-24 00:47:08.002444
# Unit test for function pipe
def test_pipe():
    assert pipe(
        1,
        increase,
        increase,
        increase
    ) == 4


# Generated at 2022-06-24 00:47:12.161004
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)(range(10)) == [0, 2, 4, 6, 8]

    filt = curried_filter(lambda x: x % 2 == 0)
    assert filt(range(10)) == [0, 2, 4, 6, 8]


# Generated at 2022-06-24 00:47:17.911736
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert curried_map(increase)([1, 2, 3, 4]) == [2, 3, 4, 5]
    assert curried_map(lambda item: item * 2)([1, 2, 3, 4]) == [2, 4, 6, 8]
    assert curried_map(increase, [1, 2, 3, 4]) == [2, 3, 4, 5]


# Generated at 2022-06-24 00:47:21.575512
# Unit test for function find
def test_find():
    collection = [{'id': 1}, {'id': 2}, {'id': 3}]

    assert find(collection, lambda item: item['id'] == 2) == {'id': 2}
    assert find(collection, lambda item: item['id'] == 4) is None



# Generated at 2022-06-24 00:47:28.363085
# Unit test for function eq
def test_eq():
    eq1 = curry(eq, 2)
    eq2 = curry(eq)
    eq3 = curry(eq, 1)
    assert eq2(1, 1) is True
    assert eq2(1, 2) is False
    assert eq1(1)(1) is True
    assert eq1(1)(2) is False
    assert eq3(1, 1) is True
    assert eq3(1, 2) is False



# Generated at 2022-06-24 00:47:32.357171
# Unit test for function curried_map
def test_curried_map():
    print(curried_map(lambda x: x + 1, [1, 2, 3]))



# Generated at 2022-06-24 00:47:36.196600
# Unit test for function memoize
def test_memoize():
    started = time()
    # Memoize function and add one to 10 thousand
    memoized = memoize(lambda value: value + 1)
    result = 0
    for i in range(1, 10001):
        result = memoized(i)
    finished = time()

    assert result == 10001
    assert finished - started < 1

# Generated at 2022-06-24 00:47:41.472813
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 5) is None


# Generated at 2022-06-24 00:47:47.045783
# Unit test for function find
def test_find():
    assert find([0, 1, 2, 3], eq(0)) == 0
    assert find([0, 1, 2, 3], eq(4)) is None


# Generated at 2022-06-24 00:47:53.289512
# Unit test for function pipe
def test_pipe():
    res = pipe('a', lambda v: v + 'b', lambda v: v + 'c', lambda v: v + 'd')
    assert res == 'abcd'


# Generated at 2022-06-24 00:47:59.946108
# Unit test for function curried_filter
def test_curried_filter():
    print("Test curried_filter")
    def is_even(num: int) -> bool:
        return num % 2 == 0

    print(curried_filter(is_even)([1, 2, 3, 4, 5, 6]))
    print(curried_filter(is_even)([1, 3, 5]))
    assert curried_filter(is_even)([1, 2, 3, 4, 5, 6]) == [2, 4, 6]
    assert curried_filter(is_even)([1, 3, 5]) == []



# Generated at 2022-06-24 00:48:02.514973
# Unit test for function find
def test_find():
    assert find(
        [1, 2, 3, 4, 5, 6, 7],
        eq(2)
    ) == 2
    assert find(
        [1, 2, 3, 4, 5, 6, 7],
        eq(8)
    ) is None



# Generated at 2022-06-24 00:48:09.561798
# Unit test for function curry
def test_curry():
    add_two = curry(lambda x, y: x + y)
    assert add_two(1, 2) == 3
    assert add_two(1)(2) == 3
    add_three = curry(lambda x, y, z: x + y + z)
    assert add_three(1, 2, 3) == 6
    assert add_three(1, 2)(3) == 6
    assert add_three(1)(2, 3) == 6
    assert add_three(1)(2)(3) == 6



# Generated at 2022-06-24 00:48:17.098292
# Unit test for function eq
def test_eq():
    assert eq(2, 3) is False
    assert eq(2, 2) is True
    assert eq('Hello', 'Hello') is True
    assert eq('Hello', 5) is False
    assert eq([1, 2, 3, 4], [1, 2, 3, 4]) is True
    assert eq([1, 2, 3, 4], [1, 2, 3, 5]) is False
    assert eq(
        {'a': 1, 'b': 2, 'c': 3},
        {'a': 1, 'b': 2, 'c': 3}
    ) is True
    assert eq(
        {'a': 1, 'b': 2, 'c': 3},
        {'a': 1, 'b': 2, 'c': 5}
    ) is False

# Generated at 2022-06-24 00:48:18.237956
# Unit test for function eq
def test_eq():
    assert (eq(1, 1))
    assert (not eq(1, 2))


# Generated at 2022-06-24 00:48:21.319376
# Unit test for function increase
def test_increase():
    """
    Increase function test

    :returns: None
    :rtype: None
    """
    from hypothesis import given
    from hypothesis.strategies import integers

    @given(argument=integers())
    def run_test(argument):
        assert increase(argument) == argument + 1

    run_test()


# Generated at 2022-06-24 00:48:23.679222
# Unit test for function curried_map
def test_curried_map():
    sample = [2, 3, 4]
    square = lambda x: x * x
    assert curried_map(square)(sample) == list(
        map(square, sample))



# Generated at 2022-06-24 00:48:27.071166
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False



# Generated at 2022-06-24 00:48:30.557339
# Unit test for function find
def test_find():
    # Arrange
    items = [1, 2, 3, 4, 5]

    # Act
    result1 = find(items, eq(2))
    result2 = find(items, eq(6))

    # Assert
    assert result1 == 2
    assert result2 is None

# Generated at 2022-06-24 00:48:34.910299
# Unit test for function memoize
def test_memoize():
    """ Unit test for function memoize """
    def add1(x):
        return x + 1

    memoized_add1 = memoize(add1)
    assert memoized_add1(1) == 2
    assert memoized_add1(1) == 2
    memoized_add1 = memoize(add1)
    assert memoized_add1(1) == 2
    assert memoized_add1(2) == 3



# Generated at 2022-06-24 00:48:40.757485
# Unit test for function cond
def test_cond():
    assert cond([
        (eq(1), identity),
        (eq(2), increase),
        (eq(3), identity)
    ])(1) == 1

    assert cond([
        (eq(1), identity),
        (eq(2), increase),
        (eq(3), identity)
    ])(2) == 3



# Generated at 2022-06-24 00:48:44.447327
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x > 4) == 5, \
        "Find must return last element witch is greater than 4"
    assert find([1, 2, 3, 4, 5], lambda x: x > 5) == None, \
        "Find must return None if element not found"



# Generated at 2022-06-24 00:48:51.869772
# Unit test for function find
def test_find():
    def test_find_for_empty_collection():
        assert find([], lambda item: item) is None

    def test_find_for_item_in_collection():
        assert find([1, 2, 3, 4], lambda item: item == 2) == 2

    def test_find_for_item_not_in_collection():
        assert find([1, 2, 3, 4], lambda item: item == 5) is None

    def test_find_for_curry_collection():
        assert find(curried_filter(lambda item: item % 2 == 0)([1, 2, 3, 4]))(lambda item: item == 2) == 2

    test_find_for_empty_collection()
    test_find_for_item_in_collection()
    test_find_for_item_not_in_collection()
    test

# Generated at 2022-06-24 00:48:59.543233
# Unit test for function cond
def test_cond():
    # We need to use this object to make the test work
    class ObjectClass:
        def __init__(self, value: int) -> None:
            self.value = value

    # Define functions witch will return truthy values
    def condition1(object_: ObjectClass) -> bool:
        return object_.value == 42

    def condition2(object_: ObjectClass) -> bool:
        return object_.value == 23

    def condition3(object_: ObjectClass) -> bool:
        return object_.value == 0

    # Define functions witch will be executed
    def execute1(object_: ObjectClass) -> int:
        return object_.value + 1

    def execute2(object_: ObjectClass) -> int:
        return object_.value + 2


# Generated at 2022-06-24 00:49:02.872688
# Unit test for function pipe
def test_pipe():
    assert pipe([1, 2, 3, 4, 5], curried_filter(lambda x: x % 2 == 0), curried_map(lambda x: x ** 2), sum) == 120


# Generated at 2022-06-24 00:49:06.773811
# Unit test for function identity
def test_identity():
    assert identity(10) == 10



# Generated at 2022-06-24 00:49:14.501340
# Unit test for function memoize
def test_memoize():
    def test_function(value):
        test_function.count += 1
        return value
    test_function.count = 0

    mem_test_function = memoize(test_function)

    first_calculated_value = mem_test_function(5)
    second_calculated_value = mem_test_function(5)
    third_calculated_value = mem_test_function(5)

    assert test_function.count == 1
    assert first_calculated_value == second_calculated_value == third_calculated_value



# Generated at 2022-06-24 00:49:16.283926
# Unit test for function eq
def test_eq():
    assert True is eq(1, 1)
    assert False is eq(1, 2)



# Generated at 2022-06-24 00:49:18.239894
# Unit test for function eq
def test_eq():
    assert eq(0, 1) is False
    assert eq(1, 1) is True
    assert eq(1, 1, 2) is False



# Generated at 2022-06-24 00:49:18.996076
# Unit test for function identity
def test_identity():
    assert identity(3) == 3



# Generated at 2022-06-24 00:49:21.737309
# Unit test for function pipe
def test_pipe():
    assert pipe(
        6,
        lambda value: value * 2,
        lambda value: value ** 2
    ) == 144
    assert pipe(
        [4, 1, 3, 5],
        lambda value: sorted(value),
        lambda value: value[1]
    ) == 3



# Generated at 2022-06-24 00:49:24.094040
# Unit test for function pipe
def test_pipe():
    def fn_1(x): return x * 2
    def fn_2(x): return x + 1

    assert pipe(3, fn_1, fn_2) == 7



# Generated at 2022-06-24 00:49:29.859977
# Unit test for function cond
def test_cond():
    assert cond([
        (eq(1), identity),
        (eq(2), identity),
        (eq(3), identity),
        (eq(4), identity)
    ])(2) == 2
    assert cond([
        (eq(1), identity),
        (eq(2), identity),
    ])(3) is None
    assert cond([
        (eq(1), identity),
        (eq(2), identity),
    ])(2) == 2
    assert cond([
        (eq(1), identity),
        (eq(2), identity),
        (eq(3), identity),
        (eq(4), identity)
    ])(5) is None



# Generated at 2022-06-24 00:49:33.681712
# Unit test for function compose
def test_compose():
    """
    Composing zero functions should return the argument.

    :returns:
    :rtype: None
    """
    assert compose(12, [])(None) == 12



# Generated at 2022-06-24 00:49:38.805117
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)(range(1, 10)) == list(range(2, 11))



# Generated at 2022-06-24 00:49:40.350742
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-24 00:49:43.979131
# Unit test for function curried_map
def test_curried_map():
    # Initialize the variables with fixed value
    x = [1, 2, 3, 4]
    y = [2, 3, 4, 5]

    # Test the curried map
    assert curried_map(increase)(x) == y


# Unit tests for function identity

# Generated at 2022-06-24 00:49:45.981861
# Unit test for function identity
def test_identity():
    assert identity(10) == 10
    assert identity([]) == []
    assert identity(identity) == identity

# Unit tests for function eq

# Generated at 2022-06-24 00:49:53.232528
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(1), [1, 2, 3, 4, 5])(0) == []
    assert curried_filter(eq(1), [1, 2, 3, 4, 5])(1) == [1]
    assert curried_filter(eq(2), [1, 2, 3, 4, 5])(0) == []
    assert curried_filter(eq(2), [1, 2, 3, 4, 5])(1) == [2]
    assert curried_filter(eq(3), [1, 2, 3, 4, 5])(3) == [3]
    assert curried_filter(eq(4), [1, 2, 3, 4, 5])(4) == [4]

# Generated at 2022-06-24 00:49:58.908899
# Unit test for function memoize
def test_memoize():
    """
    Check if memoize work correctly
    """
    some_fn = memoize(lambda x: x**2)
    some_fn(3)
    print(some_fn.__closure__[0].cell_contents)
    some_fn(3)
    print(some_fn.__closure__[0].cell_contents)



# Generated at 2022-06-24 00:50:01.315419
# Unit test for function curry
def test_curry():
    assert increase(1) == 2
    assert curry(increase)(1) == 2
    assert curry(increase)(1, 2) == 2



# Generated at 2022-06-24 00:50:04.131920
# Unit test for function compose
def test_compose():
    assert(identity(2) == compose(2, identity))
    assert(increase(2) == compose(2, increase))
    assert(increase(increase(2)) == compose(2, increase, increase))



# Generated at 2022-06-24 00:50:05.830510
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(2) == 3
    assert increase(3) == 4


# Generated at 2022-06-24 00:50:07.670430
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False



# Generated at 2022-06-24 00:50:13.280259
# Unit test for function memoize
def test_memoize():
    assert memoize(identity)(1) == memoize(identity)(1)
    assert memoize(identity)(1) != memoize(identity)(2)
    assert memoize(identity)(1) == memoize(identity)(1)
    assert memoize(identity)(2) == memoize(identity)(2)
    assert memoize(identity)(3) == memoize(identity)(3)
    assert memoize(identity)(1) == memoize(identity)(1)
    assert memoize(identity)(2) == memoize(identity)(2)
    assert memoize(identity)(1) == memoize(identity)(1)
    assert memoize(identity)(2) == memoize(identity)(2)
    assert memoize(identity)(3) == memoize(identity)(3)

# Generated at 2022-06-24 00:50:16.773459
# Unit test for function pipe
def test_pipe():
    assert pipe(3, increase, increase) == 5
    assert pipe(3, increase, lambda x: x * x) == 16
    assert pipe(3, lambda x: x * x, increase) == 10



# Generated at 2022-06-24 00:50:19.053307
# Unit test for function increase
def test_increase():
    assert increase(10) == 11


# Generated at 2022-06-24 00:50:20.598311
# Unit test for function eq
def test_eq():
    assert eq(5, 5)
    assert not eq(5, 6)



# Generated at 2022-06-24 00:50:22.981986
# Unit test for function find
def test_find():
    assert(find([1, 2, 3, 4], lambda x: x == 3) == 3)
    assert(find([1, 2, 3, 4], lambda x: x == 5) is None)

test_find()

# Generated at 2022-06-24 00:50:29.711269
# Unit test for function curried_map
def test_curried_map():
    fn = lambda item: item if item % 2 == 0 else -item
    collection = [-5, -4, -3, -2, -1, 0, 1, 2, 3, 4, 5]

    assert curried_map(fn, collection) == [-5, 4, -3, 2, -1, 0, 1, 2, 3, 4, 5]



# Generated at 2022-06-24 00:50:35.178776
# Unit test for function pipe
def test_pipe():
    map_increase = compose(curried_map, increase)
    pipe_test_function = pipe(identity, curried_filter, map_increase)
    assert pipe_test_function([1, 2, 3]) == [3, 4]



# Generated at 2022-06-24 00:50:47.092632
# Unit test for function cond
def test_cond():
    def is_even(number):
        return number % 2 == 0

    def is_gt_ten(number):
        return number > 10

    def is_negative(number):
        return number < 0

    def inc(number):
        return number + 1

    def dec(number):
        return number - 1

    def negate(number):
        return -number

    is_even_inc_dec_negate = cond([
        (is_even, inc),
        (is_gt_ten, dec),
        (is_negative, negate),
        (identity, identity)
    ])

    is_even_inc_dec_negate(5) == dec(5)
    is_even_inc_dec_negate(-5) == negate(-5)

# Generated at 2022-06-24 00:50:52.125342
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq(1)(1) == True
    assert eq(2)(1) == False



# Generated at 2022-06-24 00:50:53.689618
# Unit test for function identity
def test_identity():
    assert identity(42) == 42
    assert identity(13) == 13


# Generated at 2022-06-24 00:51:00.130806
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6



# Generated at 2022-06-24 00:51:03.479507
# Unit test for function increase
def test_increase():
    assert increase(1) == 2, "Not increased by 1 argument"



# Generated at 2022-06-24 00:51:04.972535
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:51:05.942175
# Unit test for function identity
def test_identity():
    assert identity(1)



# Generated at 2022-06-24 00:51:11.800854
# Unit test for function cond
def test_cond():
    def is_three(x):
        return x == 3

    def incr(x):
        return x + 1

    def square(x):
        return x * x

    assert cond([(is_three, incr), (is_three, square)])(3) == 4
    assert cond([(is_three, incr), (is_three, square)])(4) == 25



# Generated at 2022-06-24 00:51:16.344673
# Unit test for function compose
def test_compose():
    """
    Unit test for function compose
    :returns: None
    :rtype: None
    """
    assert compose(
        [1, 2, 3],
        curried_map(increase),
        curried_filter(lambda x: x != 0)
    ) == [2, 3, 4]



# Generated at 2022-06-24 00:51:19.985838
# Unit test for function identity
def test_identity():
    assert identity is not None
    assert identity(None) == None
    assert identity(10) == 10
    assert identity(True) == True
    assert identity(False) == False



# Generated at 2022-06-24 00:51:26.647394
# Unit test for function curried_filter
def test_curried_filter():
    print("test_curried_filter:")
    array = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    even_number = curried_filter(lambda x: x % 2 == 0)

    print("expect: [2, 4, 6, 8, 10]")
    print("got:    " + str(even_number(array)))



# Generated at 2022-06-24 00:51:33.191397
# Unit test for function identity
def test_identity():
    assert identity(2) == 2, 'identity return true argument'
    assert identity('a') == 'a', 'identity return true argument'
    assert identity([1, 2, 3]) == [1, 2, 3], 'identity return true argument'
    assert identity({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}, 'identity return true argument'



# Generated at 2022-06-24 00:51:36.244010
# Unit test for function curried_filter
def test_curried_filter():

    new_filter = curried_filter(lambda x: x > 1)
    assert new_filter([1, 2, 3, 4, 5]) == [2, 3, 4, 5]



# Generated at 2022-06-24 00:51:44.294136
# Unit test for function cond
def test_cond():
    def test_func(a, b):
        return cond([
            (lambda a, b: a < 0, lambda *args: 'a < 0'),
            (eq(b), lambda *args: 'b is equal to a'),
            (lambda a, b: b < 0, lambda *args: 'b < 0'),
            (lambda a, b: a > 0, lambda *args: 'a > 0')
        ])(a, b)

    assert test_func(1, 1) == 'b is equal to a'
    assert test_func(2, 2) == 'b is equal to a'
    assert test_func(0, 0) == 'b is equal to a'
    assert test_func(-7, -7) == 'a < 0'
    assert test_func(5, -7) == 'b < 0'
   

# Generated at 2022-06-24 00:51:49.124266
# Unit test for function find
def test_find():
    collection: List[int] = [1, 2, 3, 4, 5, 6]
    assert find(collection, eq(3)) is 3
    assert find(collection, eq(7)) is None



# Generated at 2022-06-24 00:51:53.775306
# Unit test for function eq
def test_eq():
    assert eq(2, 3) is False
    assert eq([], [1, 2]) is False
    assert eq([1, 2], [1, 2]) is True
    assert eq(None, None) is True



# Generated at 2022-06-24 00:51:55.146478
# Unit test for function identity
def test_identity():
    assert identity(0) == 0
    assert identity('test') == 'test'
    assert identity((1, 'test')) == (1, 'test')


# Generated at 2022-06-24 00:51:56.954299
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-24 00:52:03.673931
# Unit test for function pipe
def test_pipe():
    assert pipe(2, increase, increase, increase) == 5
    assert pipe(2, str, int) == 2
    assert pipe('2', int, increase) == 3
    assert pipe(['a', 'b', 'c'], curried_map(str.upper), curried_filter(lambda item: item == "B")) == ["B"]
    try:
        pipe(['a', 'b', 'c'], curried_map(str.upper), curried_filter(lambda item: item == "B"), int)
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-24 00:52:09.034508
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert curried_map(increase)([1, 2, 3, 4]) == [2, 3, 4, 5]
    assert curried_map(increase)([1, 2, 3, 4]) != [1, 2, 3, 4]
    assert curried_map(increase)([1, 2, 3, 4]) == curried_map(increase)([1, 2, 3, 4])
    assert curried_map(identity)([1, 2, 3, 4]) == curried_map(identity)([1, 2, 3, 4])

# Generated at 2022-06-24 00:52:09.645762
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:52:13.153477
# Unit test for function curry
def test_curry():
    """
    Unit test for curry
    """
    curry_fn = curry(lambda x, y, z: x * y + 2 * z - 2)
    assert curry_fn(2)(3)(4) == 2 * 3 + 2 * 4 - 2
    assert curry_fn(3)(3)(3) == 3 * 3 + 2 * 3 - 2



# Generated at 2022-06-24 00:52:17.588765
# Unit test for function eq
def test_eq():
    assert True == eq(1, 1)
    assert True == eq(eq, eq)
    assert False == eq(1, 2)
    assert False == eq('a', 'b')
    assert False == eq(True, False)



# Generated at 2022-06-24 00:52:25.821646
# Unit test for function find
def test_find():
    assert find([1, 2, 6, 4, 9], lambda x: x > 7) == 9, 'test 1'
    assert find([1, 2, 6, 4, 9], lambda x: x < 7) == 1, 'test 2'
    assert find([1, 2, 6, 4, 9], lambda x: x == 6) == 6, 'test 3'
    assert find([1, 2, 6, 4, 9], lambda x: x == 12) is None, 'test 4'
    print('test_find is OK!')



# Generated at 2022-06-24 00:52:28.291314
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(2)) == 2
    assert find([1, 2, 3], eq(4)) is None



# Generated at 2022-06-24 00:52:33.101762
# Unit test for function pipe
def test_pipe():
    functions = [
        lambda x: x + 1,
        lambda x: x * 2,
        lambda x: x * 3,
        lambda x: x * 4,
    ]
    assert pipe(3, *functions) == (1 + 3) * 2 * 3 * 4
    assert pipe(4, *functions) == (1 + 4) * 2 * 3 * 4
    assert pipe(5, *functions) == (1 + 5) * 2 * 3 * 4



# Generated at 2022-06-24 00:52:35.701830
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(2) == 3
    assert increase(3) == 4
    assert increase(4) == 5


# Generated at 2022-06-24 00:52:37.177442
# Unit test for function cond
def test_cond():
    assert cond(
        [(eq(0), increase), (eq(8), increase), (identity, identity)]
    )(8) == 9



# Generated at 2022-06-24 00:52:41.484013
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x > 3) == 4
    assert find([1, 2, 3, 4], lambda x: x > 5) is None



# Generated at 2022-06-24 00:52:47.003021
# Unit test for function pipe
def test_pipe():
    def add(x, y):
        return x + y

    def multiply(x, y):
        return x * y
    assert pipe(1, add, add) == 3
    assert pipe(1, add, multiply, add) == 4



# Generated at 2022-06-24 00:52:52.909596
# Unit test for function eq
def test_eq():
    assertTrue(eq(5, 5))
    assertFalse(eq(5, 34))
    assertTrue(eq('a', 'a'))
    assertFalse(eq('a', 'b'))
    assertTrue(eq('', ''))
    assertFalse(eq('', ' '))



# Generated at 2022-06-24 00:53:04.011313
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x ** 2, [1, 2, 3]) == [1, 4, 9]
    assert curried_map(lambda x: x ** 2, [2, 3, 4])([1, 2, 3]) == [1, 4, 9]
    assert curried_map(lambda x: x ** 2, [1, 2, 3])([2, 3, 4]) == [1, 4, 9]
    assert curried_map(lambda x: x ** 2)([1, 2, 3])([2, 3, 4]) == [1, 4, 9]
    assert curried_map(lambda x: x ** 2, [1, 2, 3])([2, 3, 4])([5, 6, 7, ]) == [1, 4, 9]

# Generated at 2022-06-24 00:53:08.386255
# Unit test for function curried_filter
def test_curried_filter():
    def gt5(x):
        return x > 5

    assert [6, 7, 8, 9] == curried_filter(gt5)([1, 2, 3, 4, 5, 6, 7, 8, 9])
    assert [6, 7, 8, 9] == curried_filter(gt5, [1, 2, 3, 4, 5, 6, 7, 8, 9])



# Generated at 2022-06-24 00:53:12.773147
# Unit test for function curry
def test_curry():
    """
    Return increased by 1 argument.

    :returns:
    :rtype: Int
    """
    assert curried_map(lambda x: x + 10, [1, 2, 3, 4])([1, 2, 3, 4]) == [11, 12, 13, 14]
    assert curried_map(lambda x: x + 10)([1, 2, 3, 4])([1, 2, 3, 4]) == [11, 12, 13, 14]
    assert increase(10) == 11
    assert curry(increase, 1)(10) == 11



# Generated at 2022-06-24 00:53:20.513790
# Unit test for function memoize
def test_memoize():
    from time import time
    from random import randint
    from copy import copy
    start = time()
    #result = [fib(randint(0, 44)) for _ in range(1000)]
    fib = memoize(lambda x: x if x < 2 else (fib(x - 1) + fib(x - 2)))

    result = [fib(x) for x in range(1, 1000)]
    print(time() - start)
    print(result)
    start = time()
    result1 = [fib(x) for x in range(1, 1000)]
    print(time() - start)
    print(result == result1)



# Generated at 2022-06-24 00:53:30.005550
# Unit test for function pipe
def test_pipe():
    func1 = lambda x: x + 1
    func2 = lambda x: x * 2
    func3 = lambda x: x - 1
    assert (3 == pipe(1, func1, func2, func3))
    assert (6 == pipe(1, func1, func2, func3, func2))


if __name__ == "__main__":
    test_pipe()
    assert (curried_filter(eq(1), [1, 2, 3])) == [1]
    assert (compose(2, lambda x: x + 1, lambda x: x * 2)) == 6
    assert (compose(1, lambda x: x + 1, lambda x: x * 2)) == 4

# Generated at 2022-06-24 00:53:31.277524
# Unit test for function identity
def test_identity():
    assert identity(5) == 5
    assert identity(identity(5)) == identity(5)


# Generated at 2022-06-24 00:53:33.067773
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(False) == False
    assert identity("string") == "string"
    assert identity(None) == None
    print('test_identity = OK')



# Generated at 2022-06-24 00:53:44.985212
# Unit test for function cond
def test_cond():
    def test_arg(value):
        def result(item):
            return item - value
        return result

    def test_eq(value):
        def result(item):
            return test_arg(value)(item) == 0
        return result

    test_list = [1, 2, 3, 5, 4, 9, 7, 8, 6]
    assert cond([
        (test_eq(1), increase),
        (test_eq(2), increase),
        (test_eq(3), increase),
        (test_eq(4), increase),
        (test_eq(5), increase),
        (test_eq(6), increase),
        (test_eq(7), increase),
        (test_eq(8), increase),
        (test_eq(9), increase),
    ])(2) == 3

# Generated at 2022-06-24 00:53:51.720964
# Unit test for function curried_map
def test_curried_map():
    """
    >>> curried_map(lambda a: a + 1, [1, 2, 3])
    [2, 3, 4]
    >>> curried_map(lambda a: a + 1)([1, 2, 3])
    [2, 3, 4]
    >>> curried_map(lambda a: a + 1, [] )
    []

    :return:
    :rtype:
    """
    pass


# Generated at 2022-06-24 00:53:53.709979
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x < 3, [1, 2, 3, 4])([]) == [1, 2]



# Generated at 2022-06-24 00:53:59.377721
# Unit test for function cond
def test_cond():
    test_func = cond(
        [
            (eq(True), lambda x: 10),
            (eq(10), lambda x: None),
            (eq('s'), lambda x: False),
            (eq(4), lambda x: True),
        ]
    )

    assert test_func(10) is None
    assert test_func('s') is False
    assert test_func(4)



# Generated at 2022-06-24 00:54:01.555943
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)



# Generated at 2022-06-24 00:54:07.039418
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1, 1, 1)
    assert not eq(1, 1, 3)
    assert not eq("a", "b")
    assert eq("a", "a")
    assert eq([1, 2], [1, 2], [1, 2])
    assert not eq([1, 2], [1, 2], [1, 3])



# Generated at 2022-06-24 00:54:08.293691
# Unit test for function pipe
def test_pipe():
    assert pipe(1, identity, increase, lambda x: x + 2, lambda x: x * 2) == 10


# Generated at 2022-06-24 00:54:12.760465
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda item: item == 3) == 3


# run unit tests