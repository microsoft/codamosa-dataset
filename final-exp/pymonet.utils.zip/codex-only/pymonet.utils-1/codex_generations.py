

# Generated at 2022-06-24 00:44:20.943662
# Unit test for function cond
def test_cond():
    # example1
    assert cond(
        [
            (lambda x: x > 0, lambda x: x + 1),
            (lambda x: x < 0, lambda x: x - 1),
            (lambda x: x == 0, lambda x: x)
        ]
    )(10) == 11

    # example2
    assert cond(
        [
            (lambda x: x > 0, lambda x: x + 1),
            (lambda x: x < 0, lambda x: x - 1),
            (lambda x: x == 0, lambda x: x)
        ]
    )(0) == 0



# Generated at 2022-06-24 00:44:27.778357
# Unit test for function cond
def test_cond():
    def fn1(value: int) -> int:
        return value + 1

    def fn2(value: int) -> int:
        return value

    def fn3(value: int) -> int:
        return value - 1

    assert cond([
        (eq(1), fn1),
        (eq(2), fn2),
    ])(2) == 2

    assert cond([
        (eq(1), fn1),
        (eq(2), fn2),
        (eq(3), fn3),
    ])(3) == 2



# Generated at 2022-06-24 00:44:29.836762
# Unit test for function identity
def test_identity():
    assert identity(10) == 10
    assert identity('result') == 'result'

# Generated at 2022-06-24 00:44:34.872354
# Unit test for function identity
def test_identity():
    assert identity(True) == True
    assert identity('Hello World') == 'Hello World'
    assert identity(1) == 1
    assert identity([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-24 00:44:37.608311
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:44:38.457122
# Unit test for function increase
def test_increase():
    assert increase(1) == 2

# Generated at 2022-06-24 00:44:39.757398
# Unit test for function identity
def test_identity():
    assert (
        identity(1)
        == 1
    )



# Generated at 2022-06-24 00:44:41.922345
# Unit test for function pipe
def test_pipe():
    assert pipe(1, curried_map(increase)) == [2]
    assert pipe(1, increase) == 2



# Generated at 2022-06-24 00:44:44.751602
# Unit test for function find
def test_find():
    assert find([], lambda x: x == 5) is None
    assert find([1, 2, 3], lambda x: x == 5) is None
    assert find([1, 2, 3], lambda x: x == 2) == 2
    print('test_find OK')



# Generated at 2022-06-24 00:44:51.953765
# Unit test for function memoize
def test_memoize():
    assert identity(1) == memoize(identity, eq)(1)
    assert identity(1) == memoize(identity, eq)(1)
    assert identity(1) == memoize(identity, eq)(1)


# Generated at 2022-06-24 00:44:53.457235
# Unit test for function curry
def test_curry():
    add = lambda a, b, c: a + b + c
    assert curry(add)(1)(2)(3) == 6



# Generated at 2022-06-24 00:44:55.698136
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 0, [1, -2, 3]) == [1, 3]



# Generated at 2022-06-24 00:45:04.630068
# Unit test for function cond
def test_cond():
    def gt(x: Any, y: Any) -> bool:
        return x > y

    def eq(x: Any, y: Any) -> bool:
        return x == y

    def gt1(x: Any) -> bool:
        return x > 1

    def eq2(x: Any) -> bool:
        return x == 2

    c = cond([
        (gt, lambda x: x),
        (eq, lambda x: x + 1),
        (gt1, lambda x: x * x),
        (eq2, lambda x: x),
    ])
    assert c(1) == 2
    assert c(2) == 4
    assert c(3) == 9
    assert c(4) == 16

# Generated at 2022-06-24 00:45:09.021398
# Unit test for function pipe
def test_pipe():
    assert pipe(1, lambda x: x + 1, lambda x: x * 2) == 4


# Generated at 2022-06-24 00:45:13.401903
# Unit test for function memoize
def test_memoize():
    @memoize
    def exp(x, y):
        return x ** y
    assert exp(2, 2) == 4, "exp(2, 2) != 4"
    assert exp(2, 2) == 4, "exp(2, 2) != 4"
    assert exp(2, 4) == 16, "exp(2, 4) != 16"
    assert exp(3, 2) == 9, "exp(3, 2) != 9"


# Generated at 2022-06-24 00:45:21.296907
# Unit test for function curried_filter
def test_curried_filter():
    test_set = [
        ({'a': 1, 'b': 2}, lambda item: item['a'] == 1, [{'a': 1, 'b': 2}]),
        ({'a': 1, 'b': 2}, lambda item: item['a'] == 2, []),
        ([1, 2], lambda item: item < 2, [1]),
        ([1, 2], lambda item: item > 2, []),
    ]
    for (element, filterer, expected_result) in test_set:
        assert memoize(filterer(curried_filter(filterer(element))) == expected_result, key=identity)



# Generated at 2022-06-24 00:45:24.611008
# Unit test for function memoize
def test_memoize():
    @memoize
    def add(n):
        return n + 10
    assert add(10) == 20
    assert add(10) == 20


# Generated at 2022-06-24 00:45:27.512552
# Unit test for function curried_filter
def test_curried_filter():
    nums = [1, 2, 3, 4, 5, 6]

    add_nums = curried_filter(lambda x: x > 2, nums)

    assert add_nums == [3, 4, 5, 6]



# Generated at 2022-06-24 00:45:29.586457
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 1, 1) == True
    assert eq(1, 1, 2) == False



# Generated at 2022-06-24 00:45:32.441633
# Unit test for function memoize
def test_memoize():
    def expensive_fn(x):
        if x == 1:
            return 1
        return x * expensive_fn(x - 1)  # recursive call

    expensive_fn = memoize(expensive_fn)
    result = expensive_fn(5)
    print(result)

# Generated at 2022-06-24 00:45:34.484994
# Unit test for function curry
def test_curry():
    print()
    print("test curry function")
    func1 = curry(lambda x, y, z: (x + y) * z)
    print(func1(2)(3)(4))



# Generated at 2022-06-24 00:45:36.681968
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 1) == 1
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-24 00:45:37.470780
# Unit test for function identity
def test_identity():
    assert identity(2) == 2



# Generated at 2022-06-24 00:45:39.027557
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:45:42.070982
# Unit test for function compose
def test_compose():
    def add1(x): return x + 1

    def mul2(x): return x * 2

    assert compose(1, add1, mul2) == 4


# Generated at 2022-06-24 00:45:47.293721
# Unit test for function curry
def test_curry():
    curried_map_1 = curried_map(increase)
    assert curried_map_1([1, 2, 3]) == [2, 3, 4]
    assert curried_map_1([2, 3, 4]) == [3, 4, 5]
    assert curried_map_1([3, 4, 5]) == [4, 5, 6]



# Generated at 2022-06-24 00:45:49.420542
# Unit test for function identity
def test_identity():
    assert identity(0) == 0
    assert identity('') == ''



# Generated at 2022-06-24 00:45:50.356401
# Unit test for function increase
def test_increase():
    assert 1 == increase(0)


# Generated at 2022-06-24 00:45:53.968237
# Unit test for function identity
def test_identity():
    assert identity(0) == 0
    assert identity(False) is False
    assert identity(1e5) == 1e5
    assert identity([1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-24 00:45:57.026846
# Unit test for function curried_filter
def test_curried_filter():
    arr = list(range(10))  # [1, 2, 3, 4, 5, 6, 7, 8, 9]
    filterer = curried_filter(lambda x: x % 2 == 1)
    assert filterer(arr) == [1, 3, 5, 7, 9]



# Generated at 2022-06-24 00:45:59.952324
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity([1, 2, 3]) == [1, 2, 3]
    assert identity('test') == 'test'



# Generated at 2022-06-24 00:46:02.096958
# Unit test for function curry
def test_curry():
    x_plus_y = lambda x, y: x + y
    add_one = curry(x_plus_y)
    add_two = add_one(2)
    assert add_two(3) == 5
    assert add_two(5) == 7



# Generated at 2022-06-24 00:46:03.043273
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-24 00:46:08.628118
# Unit test for function memoize
def test_memoize():
    assert memoize(increase)(0) == 1
    assert memoize(increase)(0) == 1
    assert memoize(increase)(1) == 2
    assert memoize(increase, eq)(1) == 2
    assert memoize(increase, eq)(1) == 2
    assert memoize(increase, eq)(0) == 1



# Generated at 2022-06-24 00:46:11.625812
# Unit test for function compose
def test_compose():
    print('test_compose')
    assert(compose(1, lambda x: x + 1, lambda x: x + 2) == 4)
    print('test_compose passed')



# Generated at 2022-06-24 00:46:14.083247
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x < 3)([1, 2, 3, 4]) == [1, 2]



# Generated at 2022-06-24 00:46:18.606392
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: True) == 1
    assert find([1, 2, 3], lambda x: False) is None
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None

# Generated at 2022-06-24 00:46:23.181526
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert curried_map(increase)([1, 2, 3, 4]) == [2, 3, 4, 5]



# Generated at 2022-06-24 00:46:25.939801
# Unit test for function memoize
def test_memoize():
    value = []
    def memoized_push(value):
        value.append(1)
        return len(value)
    push = memoize(memoized_push)
    assert push(1) == 1
    assert push(1) == 1
    assert push(2) == 2


# Generated at 2022-06-24 00:46:26.731953
# Unit test for function pipe
def test_pipe():
    assert pipe(1, identity, increase) == 2


# Generated at 2022-06-24 00:46:27.974506
# Unit test for function pipe
def test_pipe():
    assert pipe(1, compose(
        lambda x: x + 1,
        lambda x: x * 2,
        lambda x: x - 3,
    )) == -3



# Generated at 2022-06-24 00:46:30.422984
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-24 00:46:34.718052
# Unit test for function increase
def test_increase():
    assert increase(1) == 2, "test_increase failed, expected 2, got %s" % increase(1)
    assert increase(3) == 4, "test_increase failed, expected 4, got %s" % increase(3)



# Generated at 2022-06-24 00:46:37.346544
# Unit test for function curry
def test_curry():
    assert(eq(curry(lambda x, y, z: x + y + z)(1, 2)(3), 6))



# Generated at 2022-06-24 00:46:43.482747
# Unit test for function compose
def test_compose():
    """
    Unit test for function compose

    :param fn: function to invoke
    :type fn: Function(A) -> B
    :returns: None
    :rtype: None
    """
    def multiply(value):
        return value * 2

    def subtract(value):
        return value - 5

    composed_function = compose(10, multiply, subtract)

    assert composed_function == 10
    return None


# Generated at 2022-06-24 00:46:53.643307
# Unit test for function memoize
def test_memoize():
    @memoize
    def fact(n):
        if n <= 0:
            return 1
        return n * fact(n - 1)
    fact_of_5 = fact(5)
    assert fact_of_5 == 120
    # without memoize the next call will took so long time
    fact_of_10 = fact(10)
    assert fact_of_10 == 3628800
    fact_of_5_second_call = fact(5)
    assert fact_of_5_second_call == fact_of_5
    assert fact_of_5_second_call == 120


memoize = curry(memoize)

# Generated at 2022-06-24 00:46:56.081689
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 1) == 1
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 3) == 3
    assert find([1, 2, 3], lambda x: x > 5) is None



# Generated at 2022-06-24 00:46:57.193418
# Unit test for function identity
def test_identity():
    assert identity(4) == 4



# Generated at 2022-06-24 00:47:03.316691
# Unit test for function eq
def test_eq():
    """
    Unit test for function eq.
    Test pass if all values are equal.
    """
    arguments = [
        (1, 1),
        ('1', '1'),
        (None, None),
        ([], []),
    ]

    assert all([
            eq(arg1, arg2)
            for arg1, arg2
            in arguments
        ]), "All arguments should be equal"



# Generated at 2022-06-24 00:47:13.502385
# Unit test for function memoize
def test_memoize():
    """
    Test for memoize function.
    """
    from time import time
    from statistics import mean

    def f(x):
        return time()

    m = memoize(f)
    t1 = m(1)
    t2 = m(1)

    def a(x):
        return f(x)

    a1 = a(1)
    a2 = a(1)

    print("Difference between time for creating a(1) and time for creating m(1) is {0}".format(t1 - a1))
    print("Difference between time for creating m(1) and time for creating m(1) is {0}".format(t2 - t1))

# Generated at 2022-06-24 00:47:14.645631
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6



# Generated at 2022-06-24 00:47:20.121140
# Unit test for function curried_map
def test_curried_map():
    """
    Unit test: Test map function
    """
    # Test map with function
    map_test_function = curried_map(lambda x: x + 1)
    assert map_test_function(range(0, 3)) == [1, 2, 3]

    # Test map with lambda function
    map_test_lambda = curried_map(
        lambda x: x + 1,
        range(0, 3)
    )
    assert map_test_lambda == [1, 2, 3]



# Generated at 2022-06-24 00:47:24.709999
# Unit test for function pipe
def test_pipe():
    assert pipe(
        0,
        increase,
        increase
    ) == 2



# Generated at 2022-06-24 00:47:26.210223
# Unit test for function compose
def test_compose():
    assert identity(1) == compose(1, identity)



# Generated at 2022-06-24 00:47:28.027561
# Unit test for function memoize
def test_memoize():
    assert memoize(lambda x: x + 1)(14) == 15
    assert memoize(lambda x: x + 1)(14) == 15

# Generated at 2022-06-24 00:47:33.170798
# Unit test for function find
def test_find():
    collection = [1, 2, 3, 4, 5]
    key = lambda item: item == 2

    assert find(collection, key) == 2
    assert find(collection, lambda item: item == 6) is None



# Generated at 2022-06-24 00:47:34.936090
# Unit test for function pipe
def test_pipe():
    assert pipe(1, identity) == 1
    assert pipe(2, increase) == 3



# Generated at 2022-06-24 00:47:41.188944
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(10), [1, 2, 10, 4, 5]) == [10]
    is_even = lambda x: x % 2 == 0
    assert curried_filter(is_even, [1, 2, 3, 4, 5]) == [2, 4]
    is_ten = eq(10)
    assert curried_filter(is_ten, [1, 2, 3, 10, 4, 5]) == [10]
    assert curried_filter(lambda x: x > 1, [1, 2, 3]) == [2, 3]
    assert curried_filter(lambda x: x > 3, [1, 2, 3]) == []



# Generated at 2022-06-24 00:47:50.975289
# Unit test for function cond
def test_cond():
    assert pipe(
        'apple',
        cond([
            (eq('apple'), increase),
            (eq('banana'), increase)
        ])
    ) == 1
    assert pipe(
        'banana',
        cond([
            (eq('apple'), increase),
            (eq('banana'), increase)
        ])
    ) == 1
    assert pipe(
        'banana',
        cond([
            (eq('banana'), increase),
            (eq('apple'), increase)
        ])
    ) == 1
    assert pipe(
        'banana',
        curried_filter(eq('banana')),
        curried_map(increase),
        identity
    ) == 1

# Generated at 2022-06-24 00:47:52.225583
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(2) == 2


# Generated at 2022-06-24 00:47:55.474811
# Unit test for function eq
def test_eq():
    eq(1, 1)
    eq(1, 2)
    eq(1, 1, 1)
    eq(1, 1, 2)



# Generated at 2022-06-24 00:47:57.289175
# Unit test for function curry
def test_curry():
    @curry
    def add(a, b, c):
        return a + b + c

    assert add(1)(2)(3) == 6
    assert add(1)(2, 3) == 6
    assert add(1, 2)(3) == 6
    assert add(1, 2, 3) == 6


# Generated at 2022-06-24 00:47:58.093166
# Unit test for function increase
def test_increase():
    assert increase(1) == 2


# Generated at 2022-06-24 00:48:02.945608
# Unit test for function curry
def test_curry():
    @curry
    def test_add_curry(a, b, c):
        return a + b + c

    assert test_add_curry(1) == curry(lambda b: curry(lambda c: 1 + b + c), 2)
    assert test_add_curry(1)(2) == curry(lambda c: 1 + 2 + c, 1)
    assert test_add_curry(1)(2)(3) == 1 + 2 + 3


# Unit tests for function identity

# Generated at 2022-06-24 00:48:03.936138
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(22) == 23



# Generated at 2022-06-24 00:48:07.814922
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(
        lambda i: i > 2,
        [0, 1, 2, 3, 4, 5]
    ) == [False, False, False, True, True, True]



# Generated at 2022-06-24 00:48:12.970685
# Unit test for function find
def test_find():
    assert find([0, 1, 2, 3], lambda number: number > 2) == 3
    assert find([0, 1, 2, 3], lambda number: number < 1) == 0
    assert find([0, 1, 2, 3], lambda number: number > 3) is None
    assert find([0, 1, 2, 3], lambda number: number < -1) is None
    assert find([], lambda number: number < -1) is None



# Generated at 2022-06-24 00:48:20.139453
# Unit test for function cond
def test_cond():
    no_args_function = lambda: 1
    args_function = lambda x, y: x + y
    assert cond([
        (lambda: True, no_args_function),
        (eq(1, 2), no_args_function)
    ])() == cond([
        (lambda: True, no_args_function),
        (eq(1, 2), no_args_function)
    ])()

    assert cond([
        (lambda x, y: True, args_function),
        (eq(1, 2), no_args_function)
    ])(1, 5) == cond([
        (lambda x, y: True, args_function),
        (eq(1, 2), no_args_function)
    ])(1, 5)



# Generated at 2022-06-24 00:48:30.280747
# Unit test for function find
def test_find():
    assert find([1, 2], lambda x: x == 1) == 1
    assert find([1, 2], lambda x: x == 2) == 2
    assert find([1, 2], lambda x: x == 0) is None

    collection = [{'id': 1, 'name': 'Foo'},
                  {'id': 2, 'name': 'Bar'},
                  {'id': 3, 'name': 'Baz'}]

    assert find(collection, lambda x: x['id'] == 2) == {'id': 2, 'name': 'Bar'}
    assert find(collection, lambda x: x['id'] == 0) is None
    assert find(collection, lambda x: x['id'] == 3) == {'id': 3, 'name': 'Baz'}



# Generated at 2022-06-24 00:48:33.101137
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(2)) == 2



# Generated at 2022-06-24 00:48:38.458822
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 3, [1, 2, 3, 4, 5]) == [4, 5]
    assert curried_filter(eq(1), [1, 2, 3, 4, 5]) == [1]



# Generated at 2022-06-24 00:48:41.628837
# Unit test for function pipe
def test_pipe():
    A = [1, 2, 3, 4, 5]
    assert pipe(
        A,
        (lambda x: curried_filter(lambda y: y % 2 == 0, x)),
        (lambda x: curried_map(increase, x)),
        (lambda x: curried_filter(lambda y: y % 2 == 0, x)),
    ) == [5, 7]



# Generated at 2022-06-24 00:48:46.077875
# Unit test for function cond
def test_cond():
    def test(x):
        return x + 1

    assert(cond([(lambda x: x > 3, test)]) == cond([(lambda x: x > 3, test)]))


# Generated at 2022-06-24 00:48:56.760672
# Unit test for function cond
def test_cond():
    def greater_than(number):
        return lambda number1: number > number1

    def less_than(number):
        return lambda number1: number < number1

    def greater_than_zero(number):
        return greater_than(0)(number)

    def less_than_zero(number):
        return less_than(0)(number)

    def increase(number):
        return number + 1

    def decrease(number):
        return number - 1

    conditional_function = cond(
        (greater_than_zero, increase),
        (less_than_zero, decrease),
        (eq(0), identity),
    )

    assert conditional_function(5) == 6
    assert conditional_function(-5) == -4
    assert conditional_function(0) == 0



# Generated at 2022-06-24 00:48:59.362778
# Unit test for function find
def test_find():
    collection = [1, 3, 5, 7, 9]
    key = lambda x: x == 7
    assert find(collection, key) == 7



# Generated at 2022-06-24 00:49:00.448044
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-24 00:49:07.198017
# Unit test for function pipe
def test_pipe():
    """
    Testing pipe function.

    >>> test_pipe()
    True
    """
    assert pipe(1, lambda x: x + 1, lambda x: x * 2) == 4
    assert pipe(1, (lambda x: x + 1), lambda x: x * 2) == 4



# Generated at 2022-06-24 00:49:11.369400
# Unit test for function curried_map
def test_curried_map():
    assert curried_map({})([1, 2, 3])(increase) == [2, 3, 4]


# Generated at 2022-06-24 00:49:13.993288
# Unit test for function increase
def test_increase():
    assert 0 == increase(0)
    assert 1 == increase(1)
    assert 2 == increase(2)
    assert 100 == increase(100)
    assert -1 == increase(-1)
    assert -233 == increase(-233)


# Generated at 2022-06-24 00:49:17.539872
# Unit test for function compose
def test_compose():
    lst = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    result = compose(lst, curried_map(increase), curried_filter(eq(3)))
    assert result == [4, 5, 6, 7, 8, 9, 10, 11]



# Generated at 2022-06-24 00:49:19.679374
# Unit test for function memoize
def test_memoize():
    assert memoize(identity)(1) == 1
    assert memoize(identity)('a') == 'a'
    assert memoize(lambda x: 'c')('a') == 'c'



# Generated at 2022-06-24 00:49:24.169433
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity([1, 2]) == [1, 2]
    assert identity({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert identity(identity) == identity


# Generated at 2022-06-24 00:49:24.982084
# Unit test for function identity
def test_identity():
    assert identity(1) == 1


# Generated at 2022-06-24 00:49:28.044371
# Unit test for function pipe
def test_pipe():
    """Test composition"""
    assert pipe(1, lambda x: x + 1, lambda x: 2 * x, lambda x: x ** 2) == 16
    assert pipe(1, lambda x: x + 1, lambda x: 2 * x, lambda x: x ** 2,
                lambda x: x - 1) == 15



# Generated at 2022-06-24 00:49:33.395273
# Unit test for function curry
def test_curry():
    @curry
    def multiply(x, y):
        return x * y

    double = multiply(2)
    assert double(5) == 10

    twelve = multiply(3)(4)
    assert twelve == 12

    nine = multiply(3, 3)
    assert nine == 9



# Generated at 2022-06-24 00:49:39.764074
# Unit test for function curry
def test_curry():
    """
    Test currying function.
    :return:
    """
    def add(x, y):
        return x + y

    addCurry = curry(add)
    assert addCurry(1, 2) == 3
    assert addCurry(1)(2) == 3
    assert curry(add, 3)(1, 2, 3) == 6
    assert curry(add, 3)(1)(2)(3, 1) == 7



# Generated at 2022-06-24 00:49:40.964774
# Unit test for function identity
def test_identity():
    assert identity(0) == 0



# Generated at 2022-06-24 00:49:48.274254
# Unit test for function cond
def test_cond():
    add_three = lambda x: x + 3
    add_five = lambda x: x + 5
    is_divided_by_three = lambda x: x % 3 == 0
    is_divided_by_five = lambda x: x % 5 == 0
    is_divided_by_fifteen = lambda x: x % 15 == 0

    f = cond([
        (is_divided_by_fifteen, lambda x: print('FizzBuzz')),
        (is_divided_by_five, lambda x: print('Buzz')),
        (is_divided_by_three, lambda x: print('Fizz')),
        (identity, identity),
    ])

    assert f(15) == None
    assert f(5) == None
    assert f(3) == None
    assert f(10) == 10



# Generated at 2022-06-24 00:49:50.179020
# Unit test for function compose
def test_compose():
    assert compose(1, lambda x: x+1, lambda x: x*5) == 5



# Generated at 2022-06-24 00:49:53.093347
# Unit test for function curried_filter
def test_curried_filter():
    mapper = curried_filter(lambda x: x > 1)

    assert mapper([1, 2, 3]) == [2, 3]


# Generated at 2022-06-24 00:49:55.685512
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(5) == 6
    assert increase(0) == 1


# Generated at 2022-06-24 00:50:00.183274
# Unit test for function increase
def test_increase():
    # Check increasing of zero
    assert increase(0) == 1

    # Check increasing of one
    assert increase(1) == 2


# Generated at 2022-06-24 00:50:01.453137
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False


# Generated at 2022-06-24 00:50:04.142881
# Unit test for function curried_map
def test_curried_map():
    """
    Unit test for function curried_map

    :returns: test status
    :rtype: Boolean
    """
    assert curried_map(increase)([1, 1, 1]) == [2, 2, 2]
    return True



# Generated at 2022-06-24 00:50:13.681747
# Unit test for function find
def test_find():
    # test int
    assert find([1, 2, 3], lambda x: x == 1) is 1
    assert find([1, 2, 3], lambda x: x == 5) is None
    # test string
    assert find(['asd', 'das', 'dsa'], lambda x: x == 'das') is 'das'
    assert find(['asd', 'das', 'dsa'], lambda x: x == 'ds') is None
    # test none
    assert find([None, 1, 2], lambda x: x is None) is None
    assert find([None, 1, 2], lambda x: x is not None) is 1

# Generated at 2022-06-24 00:50:23.321543
# Unit test for function cond
def test_cond():
    """
    Unit test for function cond
    """
    # Test for passing
    assert cond([
        (eq(1), identity),
        (eq(2), increase)
    ]) == identity

    assert cond([
        (eq(1), increase),
        (eq(2), identity)
    ]) == increase

    # Test for passing with pipe
    assert pipe(
        1,
        lambda v: cond([
            (eq(1), identity),
            (eq(2), increase)
        ])(v),
    ) == 1

    assert pipe(
        1,
        lambda v: cond([
            (eq(1), increase),
            (eq(2), identity)
        ])(v)
    ) == 2

    # Test for failing

# Generated at 2022-06-24 00:50:24.322624
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-24 00:50:34.596610
# Unit test for function cond
def test_cond():
    true_condition = lambda x: x > 1
    false_condition = lambda x: x == 1
    condition_list = [
        (true_condition, increase),
        (false_condition, identity),
    ]
    test_cond = cond(condition_list)
    assert test_cond(0) == 0
    assert test_cond(1) == 1
    assert test_cond(2) == 3
    true_condition = lambda x: x
    false_condition = lambda x: not x
    condition_list = [
        (true_condition, increase),
        (false_condition, identity),
    ]
    test_cond = cond(condition_list)
    assert test_cond(False) == False
    assert test_cond(True) == 2
    assert test_cond(True) == 3



# Generated at 2022-06-24 00:50:39.083450
# Unit test for function eq
def test_eq():
    assert eq(True, True)
    assert not eq(True, False)

    is_e = eq(True)
    assert is_e(True)
    assert not is_e(False)


# Generated at 2022-06-24 00:50:41.596646
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(0) == 1
    assert increase(-1) == 0



# Generated at 2022-06-24 00:50:42.639015
# Unit test for function eq
def test_eq():
    assert eq(2, 2)



# Generated at 2022-06-24 00:50:45.275433
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq(1, 2, 3) == False


# Generated at 2022-06-24 00:50:46.083501
# Unit test for function increase
def test_increase():
    assert increase(0) == 1



# Generated at 2022-06-24 00:50:48.557084
# Unit test for function compose
def test_compose():
    compose_test = compose(
        2,
        lambda value: value + 1,
        lambda value: value * 3
    )
    assert compose_test == 9



# Generated at 2022-06-24 00:50:51.544871
# Unit test for function pipe
def test_pipe():
    assert pipe(
        1,
        increase,
        increase,
        increase
    ) == 4



# Generated at 2022-06-24 00:50:55.687194
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda a: a % 2 == 0) == 2
    assert find([1, 2, 3, 4, 5], lambda a: a == 0) is None
    assert find([], lambda a: a == 0) is None



# Generated at 2022-06-24 00:51:00.310267
# Unit test for function curried_filter
def test_curried_filter():
    filter_even = curried_filter(lambda x: x % 2 == 0)
    result = filter_even(list(range(10)))
    expected_result = [0, 2, 4, 6, 8]
    assert result == expected_result, "Result was: %s and expected was: %s" % (result, expected_result)



# Generated at 2022-06-24 00:51:03.514384
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase) == curried_map(increase, None)
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-24 00:51:05.756427
# Unit test for function compose
def test_compose():
    assert compose(1, identity, increase) == 2
    assert compose(1, increase, identity) == 2


# Generated at 2022-06-24 00:51:07.341406
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(5) == 6

test_increase()

# Generated at 2022-06-24 00:51:10.369282
# Unit test for function pipe
def test_pipe():
    assert pipe(
        1,
        lambda x: x + 1,
        lambda x: x + 1,
        lambda x: x + 1) == 4


# Generated at 2022-06-24 00:51:20.114452
# Unit test for function cond
def test_cond():
    eq_0 = eq(0)
    is_even = lambda value: value % 2 == 0
    is_odd = lambda value: not is_even(value)

    def raise_even(value):
        if is_even(value):
            raise Exception("Expected odd but got even")
        return value + 1

    def raise_odd(value):
        if is_odd(value):
            raise Exception("Expected even but got odd")
        return value + 1

    raise_even_or_raise_odd = cond([
        (eq_0, identity),
        (is_even, raise_even),
        (is_odd, raise_odd)
    ])

    assert raise_even_or_raise_odd(1) == 2
    assert raise_even_or_raise_odd(2) == 3
    assert raise_even

# Generated at 2022-06-24 00:51:21.711225
# Unit test for function curried_filter
def test_curried_filter():
    assert [1, 2] == curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4])



# Generated at 2022-06-24 00:51:22.670955
# Unit test for function pipe
def test_pipe():
    assert pipe(1, increase, increase, increase) == 4



# Generated at 2022-06-24 00:51:25.667276
# Unit test for function curried_filter
def test_curried_filter():
    def test_helper(a, b):
        return a == b
    assert curried_filter(eq(2))([2, 3, 4]) == [2]
    assert curried_filter(test_helper(2))([2, 3, 4]) == [2]
    assert curried_filter(test_helper)(2)([2, 3, 4]) == [2]


# Generated at 2022-06-24 00:51:29.510713
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(True) == True
    assert identity([]) == []
    assert identity(None) == None
    assert identity({}) == {}



# Generated at 2022-06-24 00:51:36.015851
# Unit test for function memoize
def test_memoize():
    import time

    @memoize
    def time_fib(n):
        if n < 2:
            return n
        else:
            return time_fib(n - 1) + time_fib(n - 2)

    start = time.time()

    time_fib(20)

    print(time.time() - start)


if __name__ == '__main__':
    test_memoize()

# Generated at 2022-06-24 00:51:38.091985
# Unit test for function curried_filter
def test_curried_filter():
    filtered = curried_filter(eq(3))
    assert [3] == filtered([1, 2, 3, 4, 3])



# Generated at 2022-06-24 00:51:45.474038
# Unit test for function eq
def test_eq():
    """
    Function for testing eq function

    :returns: None
    :rtype: None
    """
    assert eq(0, 0)
    assert eq(1, eq(1, 1))
    assert not eq(0, 1)
    assert not eq(1, 0)
    assert not eq(0, eq(1, 1))
    assert not eq(1, eq(0, 1))
    assert not eq(1, eq(1, 0))
    assert not eq(0, eq(0, 1))
    assert eq(1, 1)
    assert eq(['1', '0'], ['1', '0'])
    assert eq(['1', '0'], eq(['1', '0'], ['1', '0']))
    assert not eq([1, 0], ['1', '0'])
   

# Generated at 2022-06-24 00:51:53.030226
# Unit test for function curried_filter
def test_curried_filter():
    assert [1, 2] == curried_filter(lambda x: x % 2, [0, 1, 2, 3])
    assert [2, 3] == curried_filter(lambda x: x > 1, [0, 1, 2, 3])
    assert [1, 2, 3] == curried_filter(lambda x: x, [0, 1, 2, 3])
    assert curried_filter(lambda x: x % 2, [0, 1, 2, 3])([0, 1, 2, 3]) == [1, 2]



# Generated at 2022-06-24 00:52:02.685537
# Unit test for function curried_map
def test_curried_map():
    testing_array = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

    def mapper(number):
        return number + 1

    def double_mapper(number):
        return 2 * number

    def triple_mapper(number):
        return 3 * number

    assert curried_map(mapper, testing_array) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert curried_map(double_mapper)([1, 2, 3]) == [2, 4, 6]
    assert curried_map(triple_mapper, testing_array) == [0, 3, 6, 9, 12, 15, 18, 21, 24, 27]



# Generated at 2022-06-24 00:52:04.388629
# Unit test for function curried_map
def test_curried_map():
    data = [1, 2, 3]
    filtered_data = curried_map(lambda x: x + 1, data)
    assert filtered_data == [2, 3, 4]



# Generated at 2022-06-24 00:52:13.987315
# Unit test for function curry
def test_curry():
    assert curried_map(increase)([]) == []
    assert curried_map(increase)([0, 1, 2, 3]) == [1, 2, 3, 4]
    assert curried_filter(eq(0))([]) == []
    assert curried_filter(eq(0))([0, 1, 2, 3]) == [0]
    assert curried_filter(eq(10))([0, 1, 2, 3]) == []
    assert find([0, 1, 2, 3], lambda x: x == 2) == 2
    assert find([0, 1, 2, 3], lambda x: x == 10) is None
    assert compose(2, identity, increase, increase) == 4
    assert pipe(2, identity, increase, increase) == 4

# Generated at 2022-06-24 00:52:16.657704
# Unit test for function identity
def test_identity():
    assert identity("test") == "test"
    assert identity("test") != "test1"



# Generated at 2022-06-24 00:52:21.460386
# Unit test for function memoize
def test_memoize():
    assert memoize(increase)(1) == 2
    assert memoize(increase)(1) == 2
    assert memoize(increase, key=eq)('string') is None
    assert memoize(increase, key=eq)('string') is None



# Generated at 2022-06-24 00:52:26.664774
# Unit test for function curry
def test_curry():
    def curried_add(x, y):
        return x + y

    assert curry(curried_add, 2)(5, 3) == 8
    assert curry(curried_add)(5, 3) == 8
    assert curry(curried_add, 2)(5)(3) == 8
    assert curry(lambda x, y: x * y)(2)(10) == 20



# Generated at 2022-06-24 00:52:29.509534
# Unit test for function memoize
def test_memoize():
    import time

    @memoize
    def long_task(argument):
        time.sleep(1)
        return argument

    long_task("a")
    long_task("a")
    long_task("b")
    long_task("b")



# Generated at 2022-06-24 00:52:32.115769
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(2), [1, 2, 3]) == [2]
    assert curried_filter(lambda x: x % 2, [1, 2, 3]) == [1, 3]



# Generated at 2022-06-24 00:52:39.180128
# Unit test for function memoize
def test_memoize():
    def factorial(value):
        if value == 0:
            return 1
        return value * factorial(value - 1)

    assert(memoize(factorial)(4) == 24)
    assert(memoize(factorial)(4) == 24)
    assert(memoize(factorial)(4) == 24)
    assert(memoize(factorial)(4) == 24)
    assert(memoize(factorial)(4) == 24)



# Generated at 2022-06-24 00:52:41.675247
# Unit test for function eq
def test_eq():
    assert eq(1)(1)
    assert not eq(1)(2)
    assert not eq(1)()



# Generated at 2022-06-24 00:52:49.875757
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 3, 4, 5]
    assert curried_filter(lambda x: x > 2)(collection) == [3, 4, 5]
    assert curried_filter(lambda x: x == 2)(collection) == [2]
    assert curried_filter(lambda x: x < 0)(collection) == []
    assert curried_filter(lambda x: x < 2)(collection) == [1]
    assert curried_filter(lambda x: x > 1, collection) == [2, 3, 4, 5]

test_curried_filter()


# Generated at 2022-06-24 00:52:52.353561
# Unit test for function find
def test_find():
    assert find([1,2,3], lambda value: value == 2) == 2
    assert find([], lambda value: True) is None



# Generated at 2022-06-24 00:53:01.085520
# Unit test for function pipe
def test_pipe():
    assert pipe(5, increase) == 6
    assert pipe(5, curried_map(increase)) == [6]
    assert pipe(5, curried_map(increase), curried_map(increase)) == [7]
    assert pipe(5, curried_map(increase), curried_map(increase), curried_map(increase)) == [8]

    # Unit test for function compose
    def test_compose():
        assert compose(5, increase) == 6
        assert compose(5, curried_map(increase)) == [6]
        assert compose(5, curried_map(increase), curried_map(increase)) == [7]
        assert compose(5, curried_map(increase), curried_map(increase), curried_map(increase)) == [8]

# Generated at 2022-06-24 00:53:08.153385
# Unit test for function find
def test_find():
    collection = [1, 2, 3, 4]
    assert find(collection, lambda value: value % 2 == 0) == 2
    assert find(collection, eq(3)) == 3
    assert find(collection, curry(eq, 3)) == 3
    assert find(collection, eq(10)) is None
    assert find(collection, compose(eq(10), increase)) is None
    assert find(collection, compose(eq(11), increase)) == 4



# Generated at 2022-06-24 00:53:10.694150
# Unit test for function curried_filter
def test_curried_filter():
    list_for_filter = [1, 2, 3, 4]
    filtered_list = curried_filter(increase, list_for_filter)

    assert [2, 3, 4, 5] == filtered_list



# Generated at 2022-06-24 00:53:20.915195
# Unit test for function find
def test_find():
    """
    Test for function find.
    """
    print('Testing for find function')
    collection = [
        {'value': 1, 'id': 1},
        {'value': 2, 'id': 2},
        {'value': 3, 'id': 3},
        {'value': 4, 'id': 4},
        {'value': 5, 'id': 5},
    ]

    check_find('False search', find(collection, lambda item: item['id'] == 0), None)
    check_find('True search', find(collection, lambda item: item['value'] == 4), {'value': 4, 'id': 4})
    check_find('True search', find(collection, lambda item: item['value'] == 5), {'value': 5, 'id': 5})

    print("Find function passed test")



# Generated at 2022-06-24 00:53:24.544741
# Unit test for function compose
def test_compose():
    def add1(value):
        return value + 1

    def add2(value):
        return value + 2

    assert compose(1, add1, add2) == 4


# Generated at 2022-06-24 00:53:28.948407
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-24 00:53:32.509624
# Unit test for function cond
def test_cond():
    add_one = cond([
        (eq(0), lambda _: 1),
        (eq(1), lambda _: 2),
        (eq(2), lambda _: 3),
        (eq(3), lambda _: 4)
    ])
    assert add_one(0) == 1
    assert add_one(1) == 2
    assert add_one(2) == 3
    assert add_one(3) == 4

# Generated at 2022-06-24 00:53:35.033810
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-24 00:53:37.845618
# Unit test for function pipe
def test_pipe():
    assert pipe(
        10,
        lambda x: x + x,
        lambda x: x / 2,
        lambda x: x + 2,
    ) == 12


# Generated at 2022-06-24 00:53:41.360277
# Unit test for function eq
def test_eq():
    assert eq(1, 2) == False
    assert eq(2, 2) == True
    assert eq(None, None) == True
    assert eq(0, '') == False



# Generated at 2022-06-24 00:53:43.915456
# Unit test for function pipe
def test_pipe():
    assert pipe(1, increase) == 2
    assert pipe(1, identity) == 1
    assert pipe(1, lambda current_value: current_value + 1, lambda current_value: current_value + 1) == 3



# Generated at 2022-06-24 00:53:45.511505
# Unit test for function pipe
def test_pipe():
    result = pipe(0, increase, increase)
    assert result == 2



# Generated at 2022-06-24 00:53:49.992024
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x > 2) is 3
    assert find([1, 2, 3, 4], lambda x: x > 5) is None



# Generated at 2022-06-24 00:53:52.463056
# Unit test for function curry
def test_curry():
    first_fn = lambda x, y: x + y
    curried_first_fn = curry(first_fn)
    second_fn = curried_first_fn(10)
    assert (second_fn(10) == 20)

    third_fn = curried_first_fn(20)
    assert (third_fn(30) == 50)



# Generated at 2022-06-24 00:53:53.821351
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda n: n*2, [1, 2, 3] ) == [2, 4, 6]


# Generated at 2022-06-24 00:54:01.496373
# Unit test for function curried_filter
def test_curried_filter():
    collection = ['foo', 'bar', 'baz']
    assert curried_filter(lambda x: x == 'bar', collection) == ['bar']
    assert curried_filter(lambda x: x == 'foo')(collection) == ['foo']
    assert curried_filter(lambda x: x == 'boo')(collection) == []
    assert curried_filter(lambda x: True)(collection) == collection
    assert curried_filter(lambda x: False)(collection) == []



# Generated at 2022-06-24 00:54:04.389791
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x > 3) == 4
    assert find([1, 2, 3, 4], lambda x: x > 5) is None



# Generated at 2022-06-24 00:54:05.358815
# Unit test for function identity
def test_identity():
    assert identity(1) == 1


# Generated at 2022-06-24 00:54:06.265744
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:54:08.198423
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False



# Generated at 2022-06-24 00:54:10.155448
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity('test') == 'test'
    assert identity(True) is True



# Generated at 2022-06-24 00:54:13.133840
# Unit test for function compose
def test_compose():
    assert eq(compose(10, increase, increase, increase), 13)

