

# Generated at 2022-06-24 00:44:14.471550
# Unit test for function curried_map
def test_curried_map():
    fn_map = curried_map(lambda x: x+1)
    assert fn_map([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-24 00:44:20.599024
# Unit test for function identity
def test_identity():
    assert identity(None) is None
    assert identity(1) == 1
    assert identity(1.1) == 1.1
    assert identity('test') == 'test'
    assert identity([]) == []
    assert identity([1]) == [1]
    assert identity((1, 2)) == (1, 2)
    assert identity({'test': 2}) == {'test': 2}



# Generated at 2022-06-24 00:44:23.141345
# Unit test for function identity
def test_identity():
    assert identity(42) == 42


# Generated at 2022-06-24 00:44:27.626587
# Unit test for function find
def test_find():
    collection = [1, 2, 3, 4, 5]
    assert find(collection, lambda x: x == 3) == 3



# Generated at 2022-06-24 00:44:33.027914
# Unit test for function curry
def test_curry():
    abs_curry = curry(lambda x, y: abs(x) + abs(y))
    assert abs_curry(2, 3) == 5
    assert abs_curry(1)(-100) == 101


# Generated at 2022-06-24 00:44:34.715830
# Unit test for function pipe
def test_pipe():
    assert pipe(None, identity) is None
    assert pipe(False, identity) is False
    assert pipe(1, increase) == 2
    assert pipe(1, increase, increase) == 3



# Generated at 2022-06-24 00:44:39.967369
# Unit test for function compose
def test_compose():
    fn_list = [lambda x: x + 1, lambda x: x + 1, lambda x: x + 1]
    expected_result = 3
    actual_result = compose(0, *fn_list)

    assert actual_result == expected_result


# Generated at 2022-06-24 00:44:42.970020
# Unit test for function curry
def test_curry():
    curried_add = curry(lambda a, b: a + b, 2)
    assert curried_add(1, 2) == 3
    assert curried_add(1)(2) == 3



# Generated at 2022-06-24 00:44:44.087003
# Unit test for function increase
def test_increase():
    assert increase(5) == 6

    assert increase(15) == 16



# Generated at 2022-06-24 00:44:51.231353
# Unit test for function find
def test_find():
    assert find([0, 1, 2], eq(1)) == 1
    assert find([0, 1, 2], eq(3)) is None



# Generated at 2022-06-24 00:45:03.814677
# Unit test for function curried_filter
def test_curried_filter():
    def is_even(n):
        return n % 2 == 0

    assert curried_filter(is_even, range(10)) == [0, 2, 4, 6, 8]
    assert curried_filter(is_even)(range(10)) == [0, 2, 4, 6, 8]
    assert curried_filter(is_even, range(5)) == [0, 2, 4]
    assert curried_filter(is_even)(range(5)) == [0, 2, 4]
    assert curried_filter(is_even, range(3)) == [0, 2]
    assert curried_filter(is_even)(range(3)) == [0, 2]
    assert curried_filter(is_even, range(1)) == []

# Generated at 2022-06-24 00:45:08.413518
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, (1, 2, 3)) == [1, 2, 3]
    assert curried_map(increase)((1, 2, 3)) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, (1, 2, 3)) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, (1, 2, 3)) == [2, 3, 4]



# Generated at 2022-06-24 00:45:10.676092
# Unit test for function curried_filter
def test_curried_filter():
    example_list = [1,2,3,4,5,6]
    print(curried_filter(eq(1))(example_list)) # [1], check 1st argument
    print(curried_filter(increase)(eq(1))(example_list)) # [2], check 2nd argument


# Generated at 2022-06-24 00:45:16.285871
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], eq(3)) == 3
    assert find([1, 2, 3, 4], eq(5)) is None



# Generated at 2022-06-24 00:45:19.994509
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3, 4]) == [2, 3, 4, 5]
    add5 = curried_map(lambda x: x + 5)
    assert add5([1, 2, 3, 4]) == [6, 7, 8, 9]


# Generated at 2022-06-24 00:45:25.086676
# Unit test for function pipe
def test_pipe():
    assert pipe(2, increase, increase, increase) == 5
    assert pipe(2, increase, increase, increase, lambda n: n/2) == 2.5
    assert pipe([2], lambda l: [l[0]], increase, increase, increase, lambda n: n/2) == [2.5]


# Generated at 2022-06-24 00:45:27.893464
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-24 00:45:31.998110
# Unit test for function eq
def test_eq():
    """
    Test function eq.

    :param:
    :type:
    :returns:
    :rtype:
    """
    assert eq(2, 2) is True
    assert eq(2, 3) is False
    assert eq(2, '2') is False
    assert eq('2', '2') is True
    assert eq('2', 2) is False
    assert eq(True, True) is True



# Generated at 2022-06-24 00:45:35.687398
# Unit test for function cond
def test_cond():
    def is_even(n):
        return n % 2 == 0

    def is_odd(n):
        return n % 2 == 1

    def is_positive(n):
        return n > 0

    apply_fn = cond([
        (is_even, identity),
        (is_odd, increase),
        (is_positive, lambda n: n),
    ])

    assert apply_fn(1) == 2
    assert apply_fn(2) == 2
    assert apply_fn(0) == 0
    assert apply_fn(-1) == 0



# Generated at 2022-06-24 00:45:37.768149
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)



# Generated at 2022-06-24 00:45:43.528874
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(identity)([]) == []
    assert curried_map(identity, [3, 2, 1]) == [3, 2, 1]
    assert curried_map(identity, []) == []



# Generated at 2022-06-24 00:45:46.665529
# Unit test for function pipe
def test_pipe():
    def add1(x: int) -> int:
        return x + 1

    def mul2(x: int) -> int:
        return x * 2

    assert pipe(1, add1, mul2) == 4

# Generated at 2022-06-24 00:45:51.642344
# Unit test for function curried_filter
def test_curried_filter():
    """Test for curried_filter function"""
    coll = [1, 2, 3, 4, 5]
    predicate = eq(2)
    assert curried_filter(predicate, coll) == [2]
    assert curried_filter(predicate)(coll) == [2]



# Generated at 2022-06-24 00:45:56.160216
# Unit test for function cond
def test_cond():
    result = cond([
        (lambda a: a < 10, lambda a: 'less 10'),
        (lambda a: a < 100, lambda a: 'less 100'),
        (lambda a: a < 1000, lambda a: 'less 1000'),
        (lambda a: a < 10000, lambda a: 'less 10000'),
        (lambda _: True, lambda a: 'other'),
    ])(11)
    assert result == 'less 100'



# Generated at 2022-06-24 00:46:00.992449
# Unit test for function find
def test_find():
    assert find([], lambda x: x == 2) is None
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None
    assert find([1, 2, 3, 4], lambda x: x < 3) == 1



# Generated at 2022-06-24 00:46:01.808579
# Unit test for function compose
def test_compose():
    rv = compose(1, increase, identity)
    assert rv == 2



# Generated at 2022-06-24 00:46:03.780101
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 0)([1, -1, 2, -1]) == [1, 2]



# Generated at 2022-06-24 00:46:07.557332
# Unit test for function curry
def test_curry():
    @curry
    def add(x, y):
        return x + y

    assert add(1, 2) == 3
    assert add(1)(2) == 3
    assert add(1, 2) == 3



# Generated at 2022-06-24 00:46:14.662468
# Unit test for function cond
def test_cond():
    def is_zero(x):
        return x == 0

    def is_one(x):
        return x == 1

    def is_two(x):
        return x == 2

    def is_three(x):
        return x == 3

    def always_true(x):
        return True

    def always_false(x):
        return False

    def is_none(x):
        return x is None

    def do_return_None():
        return None

    def do_return_zero():
        return 0

    def do_return_one():
        return 1

    def do_return_two():
        return 2

    def do_return_three():
        return 3

    # This test is skipped because of pytest bug
    # https://github.com/pytest-dev/pytest/issues/1445


# Generated at 2022-06-24 00:46:18.342946
# Unit test for function eq
def test_eq():
    assert eq(True, True) == True
    assert eq(True, False) == False
    assert eq(True, None) == False
    assert eq(1, 1) == True
    assert eq(1, 2) == False



# Generated at 2022-06-24 00:46:24.191857
# Unit test for function cond
def test_cond():
    # BEGIN (write your solution here)
    cond_list = [
        ((lambda x: x == 1), (lambda x: x+50)),
        ((lambda x: x == 2), (lambda x: x+60)),
        ((lambda x: x == 3), (lambda x: x+70)),
    ]
    result = cond(cond_list)
    # END



# Generated at 2022-06-24 00:46:28.968842
# Unit test for function cond
def test_cond():
    def is_greater_than_4(value):
        return value > 4

    def add_1(value):
        return value + 1

    def return_initial_value(value):
        return value

    assert cond([
        (is_greater_than_4, add_1),
        (lambda x: True, return_initial_value),
    ])(5) == 6

    assert cond([
        (is_greater_than_4, add_1),
        (lambda x: True, return_initial_value),
    ])(0) == 0



# Generated at 2022-06-24 00:46:30.504659
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3, 4]) == [2, 3, 4, 5]



# Generated at 2022-06-24 00:46:37.143418
# Unit test for function memoize
def test_memoize():
    counter = 0

    def fn(argument):
        nonlocal counter
        counter += 1
        return argument

    memoized_fn = memoize(fn)

    assert memoized_fn(1) == 1
    assert memoized_fn(1) == 1
    assert counter == 1
    assert memoized_fn(2) == 2
    assert memoized_fn(2) == 2
    assert counter == 2


# Generated at 2022-06-24 00:46:40.819737
# Unit test for function find
def test_find():
    """
    This function test is find function return expected result.
    """
    collection = [1, 2, 3]
    key = lambda x: x == 1
    assert find(collection, key) == 1



# Generated at 2022-06-24 00:46:43.482771
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq(1)(1) == True
    assert eq(1)(2) == False


# Generated at 2022-06-24 00:46:45.928946
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(0, 1)


# Generated at 2022-06-24 00:46:52.537035
# Unit test for function memoize
def test_memoize():
    x = 2

    def test_memo(argument):
        nonlocal x
        x += 1
        return x

    memo_test_memo = memoize(test_memo)
    assert memo_test_memo(1) == 3
    assert memo_test_memo(2) == 4
    assert memo_test_memo(1) == 3
    assert memo_test_memo(1) == 3
    assert memo_test_memo(2) == 4
    assert memo_test_memo(2) == 4



# Generated at 2022-06-24 00:46:59.926702
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 1) == 1
    assert find([1, 2, 3, 4], lambda x: x == 2) == 2
    assert find([1, 2, 3, 4], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4], lambda x: x == 4) == 4
    assert find([1, 2, 3, 4], lambda x: x == 6) is None



# Generated at 2022-06-24 00:47:01.977609
# Unit test for function compose
def test_compose():
    assert compose(4, lambda x: x + 1, lambda x: x * 2) == 10



# Generated at 2022-06-24 00:47:04.631108
# Unit test for function curry
def test_curry():
    curried_add = curry(lambda x, y: x + y)
    assert curried_add(1)(2) == curried_add(1, 2) == 3
    assert curried_add(1, 2, 3) == 3



# Generated at 2022-06-24 00:47:05.911031
# Unit test for function pipe
def test_pipe():
    assert pipe(2, increase, increase) == 4



# Generated at 2022-06-24 00:47:06.710992
# Unit test for function identity
def test_identity():
    assert identity(10) == 10



# Generated at 2022-06-24 00:47:08.519931
# Unit test for function compose
def test_compose():
    assert compose(
        1,
        lambda val: val + 1,
        lambda val: val + 2
    ) == 4



# Generated at 2022-06-24 00:47:10.856818
# Unit test for function compose
def test_compose():
    assert(compose(
        1,
        increase,
        increase,
        increase
    ) == 4)



# Generated at 2022-06-24 00:47:12.019105
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True, "Function eq don't work"


# Generated at 2022-06-24 00:47:15.521500
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-24 00:47:23.233625
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x == 3, lambda x: x + 5)
    ])(3) == 8
    # Test for more then one condition

# Generated at 2022-06-24 00:47:27.415713
# Unit test for function memoize
def test_memoize():
    assert memoize(increase, eq)(1) == 2
    assert memoize(increase, eq)(1) == 2
    assert memoize(identity, eq)('a') == 'a'
    assert memoize(identity, eq)('a') == 'a'

# Generated at 2022-06-24 00:47:35.881857
# Unit test for function memoize
def test_memoize():
    def factorial(n: int) -> int:
        if n == 1:
            return 1
        return n * factorial(n - 1)

    # Test for function with no cache
    print(factorial(5))
    # => 120

    # Test for function with cache
    factorial_with_cache = memoize(factorial)
    print(factorial_with_cache(5))
    # => 120
    # after first time we'll get our result from cache



# Generated at 2022-06-24 00:47:42.084180
# Unit test for function curried_filter
def test_curried_filter():
    no_empty_strings = curried_filter(lambda x: len(x) > 0)
    filtered = no_empty_strings(['a', 'b', '', 'c', ''])
    assert(filtered == ['a', 'b', 'c'])



# Generated at 2022-06-24 00:47:44.617315
# Unit test for function pipe
def test_pipe():
    result = pipe(
        1,
        lambda v: v + 1,
        lambda v: v * 2,
        lambda v: v * 3
    )

    assert result == 12, "Pipe function not working"



# Generated at 2022-06-24 00:47:45.351788
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:47:47.641831
# Unit test for function curried_filter
def test_curried_filter():
    is_odd = curried_filter(lambda x: x % 2 == 1)
    assert is_odd([1, 2, 3, 4, 5]) == [1, 3, 5]



# Generated at 2022-06-24 00:48:00.129699
# Unit test for function cond
def test_cond():
    add = lambda x, y: x + y
    assert cond([
        (lambda x: len(x) == 0, lambda x: 'empty'),
        (lambda x: len(x) > 1, add)
    ])([]) == 'empty'
    assert cond([
        (lambda x: len(x) == 0, lambda x: 'empty'),
        (lambda x: len(x) > 1, add)
    ])((1, 2)) == 3
    assert cond([
        (lambda x: len(x) == 0, lambda x: 'empty'),
        (lambda x: len(x) > 1, add)
    ])([1]) == 'empty'

# Generated at 2022-06-24 00:48:02.448592
# Unit test for function memoize
def test_memoize():
    def fn(value):
        return value ** 2

    memoized_fn = memoize(fn, key=eq)

    assert fn(2) == 4
    assert fn(2) == 4
    assert memoized_fn(2) == 4
    assert memoized_fn(2) == 4
    assert memoized_fn(2) == 4
    assert fn(2) == 4

# Generated at 2022-06-24 00:48:08.153494
# Unit test for function memoize
def test_memoize():
    """
    Test for function memoize
    :returns: 
    :rtype: 
    """
    is_even_memoize = memoize(lambda x: x % 2 == 0)
    assert is_even_memoize(100) == True
    # assert is_even_memoize(100) == False
    assert is_even_memoize(100) == True



# Generated at 2022-06-24 00:48:16.698053
# Unit test for function memoize
def test_memoize():
    import unittest
    from unittest import mock

    class Test(unittest.TestCase):
        def test_memoize(self):
            class Price:
                def __init__(self, id, value):
                    self.id = id
                    self.value = value

                def __eq__(self, other):
                    if not isinstance(other, Price):
                        return NotImplemented
                    return self.id == other.id

            class PriceRepository:
                def __init__(self, prices):
                    self.prices = prices

                def _get_one(self, priceId):
                    """
                    Repository api.
                    """
                    return find(self.prices, lambda price: price.id == priceId)

                # Function to memoize

# Generated at 2022-06-24 00:48:23.275121
# Unit test for function find
def test_find():
    """
    Test if find return None when element not in list.

    """
    assert find([], identity) is None
    assert find([1, 2, 3], identity) is 3
    assert find([1, 2, 3], lambda x: x > 2) is 3
    assert find([1, 2, 3], curry(lambda x, y: x > y)(2)) is 3



# Generated at 2022-06-24 00:48:30.321152
# Unit test for function cond
def test_cond():
    print(cond([
        (eq(True), lambda *_: 'True is true'),
        (eq(False), lambda *_: 'False is not true')
    ])(False))
    print(cond([
        (eq(True), lambda *_: 'True is true'),
        (eq(False), lambda *_: 'False is not true')
    ])(True))


if __name__ == "__main__":
    test_cond()

# Generated at 2022-06-24 00:48:32.104257
# Unit test for function memoize
def test_memoize():
    assert memoize(lambda x: x * 2)(2) == 4
    assert memoize(lambda x: x * 2)(2) == 4


# Generated at 2022-06-24 00:48:35.176271
# Unit test for function compose
def test_compose():
    assert compose(2, increase, decrease, identity) == 3
    assert compose(2, increase, identity) == 3
    assert compose(3, identity) == 3



# Generated at 2022-06-24 00:48:38.649850
# Unit test for function compose
def test_compose():
    composed = compose(1, inc, float)
    assert composed == 2.0
    assert isinstance(composed, float)



# Generated at 2022-06-24 00:48:40.675549
# Unit test for function eq
def test_eq():
    assert eq('a', 'a'), 'Function eq should return True'
    assert not eq(1, 2), 'Function eq should return False'



# Generated at 2022-06-24 00:48:42.493480
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x ** 2)([1, 2, 3]) == [1, 4, 9]


# Generated at 2022-06-24 00:48:45.953042
# Unit test for function curried_map
def test_curried_map():
    def sq(x):
        return x * x

    f = curried_map(sq)
    assert [1, 4, 9] == f([1, 2, 3])



# Generated at 2022-06-24 00:48:48.762401
# Unit test for function find
def test_find():
    assert(find([1, 2, 3], lambda x: x == 2) == 2)
    assert(find([1, 2, 3], lambda x: x == 4) is None)


# Generated at 2022-06-24 00:48:54.306369
# Unit test for function curried_filter
def test_curried_filter():
    is_even = lambda item: item % 2 == 0
    assert curried_filter(is_even)([1, 2, 3, 4]) == [2, 4]
    assert curried_filter(is_even, [1, 2, 3, 4]) == [2, 4]


# Unit tests for function compose

# Generated at 2022-06-24 00:48:56.396131
# Unit test for function identity
def test_identity():
    assert identity(1) == 1


# Generated at 2022-06-24 00:49:01.771896
# Unit test for function eq
def test_eq():
    eq_1_1 = eq(1, 1)
    eq_1_2 = eq(1, 2)

    assert (eq_1_1 == True)
    assert (eq_1_2 == False)



# Generated at 2022-06-24 00:49:08.179484
# Unit test for function pipe
def test_pipe():
    assert pipe(5, identity, increase, increase) == 7, 'First test failed'
    assert pipe(5, increase, increase) == 7, 'Second test failed'
    assert pipe('hello', identity) == 'hello', 'Third test failed'



# Generated at 2022-06-24 00:49:17.359726
# Unit test for function curried_filter
def test_curried_filter():
    filter_is_even_number = curried_filter(lambda n: n % 2 == 0)
    filter_is_divide_by_3 = curried_filter(lambda n: n % 3 == 0)

    assert filter_is_even_number([1, 2, 3, 4, 5]) == [2, 4]
    assert filter_is_divide_by_3([1, 2, 3, 4, 5, 6, 7, 8, 9]) == [3, 6, 9]

    assert filter_is_even_number(filter_is_divide_by_3([1, 2, 3, 4, 5, 6, 7, 8, 9])) == [6]



# Generated at 2022-06-24 00:49:22.491431
# Unit test for function compose
def test_compose():
    assert compose(3, increase) == 4
    assert compose(3, increase, increase) == 5
    assert compose("3", increase, increase) == "23"



# Generated at 2022-06-24 00:49:27.485008
# Unit test for function memoize
def test_memoize():
    def add(x):
        return x + 1

    add_memoized = memoize(add)
    assert add_memoized(1) == 2
    assert add_memoized(1) == 2
    assert add_memoized(1) == 2



# Generated at 2022-06-24 00:49:34.989551
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return not is_even(value)

    assert cond(
        [(is_even, 'even'), (is_odd, 'odd')]
    )(2) == 'even'
    assert cond(
        [(is_even, 'even'), (is_odd, 'odd')]
    )(3) == 'odd'



# Generated at 2022-06-24 00:49:40.365862
# Unit test for function curry
def test_curry():
    # Test function with more than one argument
    def test_sum(a, b, c):
        return a + b + c

    # Test function with one argument
    def test_identity(a):
        return a

    assert curry(test_sum)(1)(2)(3) == 6
    assert curry(test_identity)(1) == 1



# Generated at 2022-06-24 00:49:47.046000
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b: a + b)(1)(2) == 3
    assert curry(lambda a, b: a - b)(1)(2) == -1
    assert curry(lambda a, b: a * b)(3)(2) == 6
    assert curry(lambda a, b, c: a * b + c)(3)(2)(1) == 7
    assert curry(lambda a, b, c: a * b + c)(3, 2)(1) == 7
    assert curry(lambda a, b, c: a * b + c)(3, 2, 1) == 7



# Generated at 2022-06-24 00:49:48.300652
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(2, 1)



# Generated at 2022-06-24 00:49:51.991797
# Unit test for function identity
def test_identity():
    """ Testing function identity(value: T) -> T """
    assert identity(1) == 1
    assert identity("a") == "a"
    assert identity([1,2,3]) == [1,2,3]

# Generated at 2022-06-24 00:49:57.827168
# Unit test for function find
def test_find():
    assert(None == find([], identity))
    assert(4 == find([4], eq(4)))
    assert(4 == find([1, 2, 3, 4], eq(4)))
    assert(4 == find([1, 2, 3, 4, 5], eq(4)))
    assert(None == find([1, 2, 3], eq(4)))



# Generated at 2022-06-24 00:49:59.546288
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2
    assert increase(2) == 3
    assert increase(4) == 5


# Generated at 2022-06-24 00:50:01.537600
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity([1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-24 00:50:08.187907
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3, 4]) == [2, 3, 4, 5], "curried_map function is incorrect"
    assert curried_map(lambda x: x + 1)([1, 2, 3, 4]) == [2, 3, 4, 5], "curried_map function is incorrect"
    assert curried_map(lambda x: x + 1, [1, 2, 3, 4]) == [2, 3, 4, 5], "curried_map function is incorrect"
    assert curried_map(lambda x: x + 1, [1, 2, 3, 4]) == [2, 3, 4, 5], "curried_map function is incorrect"

# Generated at 2022-06-24 00:50:20.030870
# Unit test for function cond
def test_cond():
    # Test function return true with one argument
    assert compose(3, lambda x: x >= 3)

    # Test function return true with one argument
    assert compose(3, lambda x: x >= 2, lambda x: x < 5)

    # Test function return true with two arguments
    assert compose(2, 3, lambda x, y: x < y)

    # Test function return true with two arguments
    assert compose(True, lambda x: not x, lambda x: x)

    # Test function return true from first condition
    assert cond([
        (lambda x: x > 2, lambda _: 'x is greater than 2'),
        (lambda x: x > 5, lambda _: 'x is greater than 5')
    ])(3) == 'x is greater than 2'

    # Test function return true from second condition

# Generated at 2022-06-24 00:50:26.481089
# Unit test for function cond
def test_cond():
    is_zero = lambda value: value == 0
    is_even = lambda value: value % 2 == 0
    is_odd = lambda value: value % 2 != 0
    inc_by_one = lambda value: increase(value)
    inc_by_two = lambda value: increase(increase(value))
    inc_by_three = lambda value: increase(increase(increase(value)))
    current_cond = cond([
        (is_zero, inc_by_one),
        (is_even, inc_by_two),
        (is_odd, inc_by_three)
    ])
    assert current_cond(0) == 1
    assert current_cond(2) == 4
    assert current_cond(3) == 6


# Generated at 2022-06-24 00:50:30.052104
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3

    add = curry(lambda x, y: x + y)
    add1 = add(1)

    assert add1(2) == 3
    assert add1(5) == 6



# Generated at 2022-06-24 00:50:35.703257
# Unit test for function cond
def test_cond():
    """
    Unit test for function cond
    """

    def is_even(number): return number % 2 == 0

    def is_positive(number): return number > 0

    def is_negative(number): return number < 0

    def execute_first(number): return 1

    def execute_second(number): return 2

    def execute_third(number): return 3

    condition_list = [
        (is_even, execute_first),
        (is_positive, execute_second),
        (is_negative, execute_third)
    ]

    assert cond(condition_list)(2) == 1
    assert cond(condition_list)(1) == 2
    assert cond(condition_list)(-1) == 3



# Generated at 2022-06-24 00:50:37.504147
# Unit test for function pipe
def test_pipe():
    assert pipe(1, increase, increase, increase) == 4


# Generated at 2022-06-24 00:50:43.086743
# Unit test for function eq
def test_eq():
    assert eq(1, 2) == False
    assert eq(2, 2) == True
    eq1 = eq(1)
    assert eq1(2) == False
    assert eq1(1) == True
    assert eq1(1)(1)(1)(1)(1)(1)(1)(1)(1)(1)(1)(1)(1)(1)(1) == True

# Generated at 2022-06-24 00:50:46.094364
# Unit test for function curried_filter
def test_curried_filter():
    filter_fn = curried_filter(lambda x: x > 1)
    result = filter_fn([1, 2, 3])
    assert result == [2, 3]

# Generated at 2022-06-24 00:50:48.434076
# Unit test for function pipe
def test_pipe():
    # given
    number = 0
    # when
    result = pipe(
        number,
        increase,
        increase
    )
    # then
    assert result == 2


# Generated at 2022-06-24 00:50:53.548245
# Unit test for function find
def test_find():
    assert None == find([], lambda x: x == 3)
    assert 3 == find([1, 2, 3, 2, 1], lambda x: x == 3)
    assert "Test" == find(["Test", "another", "not this"], lambda x: x == "Test")


# Generated at 2022-06-24 00:51:01.805399
# Unit test for function cond
def test_cond():
    assert cond([
        (eq(0), lambda v: 0),
        (eq(1), lambda v: 1),
        (eq(2), lambda v: 2),
    ])(0) == 0
    assert cond([
        (eq(0), lambda v: 0),
        (eq(1), lambda v: 1),
        (eq(2), lambda v: 2),
    ])(1) == 1
    assert cond([
        (eq(0), lambda v: 0),
        (eq(1), lambda v: 1),
        (eq(2), lambda v: 2),
    ])(2) == 2



# Generated at 2022-06-24 00:51:03.626488
# Unit test for function curry
def test_curry():
    assert compose('hello', compose('world', identity), identity) == 'worldhello'



# Generated at 2022-06-24 00:51:05.071278
# Unit test for function increase
def test_increase():
    assert increase(0) == 1



# Generated at 2022-06-24 00:51:15.744121
# Unit test for function pipe
def test_pipe():
    assert pipe(1, increase, increase) == 3
    assert pipe(1, lambda x: x ** 2, identity) == 1
    assert pipe(curried_filter(eq("test"), curried_map(lambda x: x + '!'))(["test", "test", "test1", "test2"]),
                lambda x: curried_map(identity, x),
                lambda x: reduce(lambda y, z: y + z, x, ''),
                lambda x: x + "!") == "test!test!test!!"

# Generated at 2022-06-24 00:51:18.773215
# Unit test for function curried_map
def test_curried_map():
    """
    Tests for curried map function

    :rtype: Boolean
    """
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4], 'Curried map should sum by one all element in collection'

# Generated at 2022-06-24 00:51:20.697178
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(int, [4, 3, 2, 1])(lambda x: x % 2 == 0) == [4, 2]


# Generated at 2022-06-24 00:51:22.496852
# Unit test for function eq
def test_eq():
    assert eq(2, 2)
    assert not eq(2, 3)
    assert eq(2)(2)
    assert not eq(2)(3)


# Generated at 2022-06-24 00:51:26.588646
# Unit test for function eq
def test_eq():
    assert eq(0, 0)
    assert not eq(0, 1)
    assert not eq(1, 0)
    assert eq(1, 1)
    assert eq(1, 1) is True
    assert eq(1, 1, 1) is False
    assert eq(1)(1)
    assert eq(1, 1)(1) is False



# Generated at 2022-06-24 00:51:29.341793
# Unit test for function compose
def test_compose():
    f = compose(1, lambda x: x * 2, lambda x: x + 1)
    assert f == 4

# Generated at 2022-06-24 00:51:35.828571
# Unit test for function curry
def test_curry():
    assert callable(curry(identity))
    assert callable(curry(identity, 2))
    assert callable(curry(identity)(2))
    assert callable(curry(identity, 2)(3))
    assert curry(identity)(1) == 1
    assert curry(identity, 2)(2, 3) == 3
    assert curry(identity, 2)(1)(1) == 1



# Generated at 2022-06-24 00:51:40.894837
# Unit test for function cond
def test_cond():
    def test(a, b, c):
        return cond([
            (eq(1), lambda x: x + 1),
            (eq(2), lambda x: x + 2),
            (eq(3), lambda x: x + 3),
        ])(a)

    assert test(1, 2, 3) == 2
    assert test(2, 2, 3) == 4
    assert test(3, 2, 3) == 6


# Generated at 2022-06-24 00:51:43.608214
# Unit test for function find
def test_find():
    l = []

    assert find([], lambda x: x > 2) is None
    assert find([1, 2, 3, 4, 5], lambda x: x > 2) == 3
    assert find([1, 2, 3, 4, 5], lambda x: x > 3) == 4



# Generated at 2022-06-24 00:51:45.034298
# Unit test for function compose
def test_compose():
    assert compose(2, increase, increase, increase) == 5



# Generated at 2022-06-24 00:51:49.808534
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(3))([1, 2, 3, 4]) == [3]
    assert curried_filter(eq(3))([2, 4]) == []



# Generated at 2022-06-24 00:52:01.527322
# Unit test for function curry
def test_curry():
    """
    Check curry work.
    """
    # standard curry
    @curry
    def curried(a, b, c):
        return (a, b, c)

    # check, that applying 1 argument return function with 2 arguments
    assert callable(curried(1))
    # check apply 2 arguments return function with 1 argument
    assert callable(curried(1)(2))
    # check apply 3 arguments return not function
    assert not callable(curried(1)(2)(3))
    # check apply all arguments and get result
    assert (curried(1)(2)(3) == (1, 2, 3))

    # curry with unknown number of arguments
    @curry
    def curried_2(a, b, c=None, d=None):
        if (c is None):
            return a + b


# Generated at 2022-06-24 00:52:03.839350
# Unit test for function compose
def test_compose():
    initial_value = 0
    assert compose(initial_value, increase) == 1
    assert compose(initial_value, identity) == 0
    assert compose(initial_value, increase, identity) == 1
    assert compose(initial_value, identity, increase) == 0



# Generated at 2022-06-24 00:52:06.187439
# Unit test for function identity
def test_identity():
    assert identity(123) == 123
    assert identity(True) is True
    assert identity('blabla') == 'blabla'
    assert identity([[], [], []]) == [[], [], []]



# Generated at 2022-06-24 00:52:08.912709
# Unit test for function increase
def test_increase():
    assert increase(1) == 2

# Generated at 2022-06-24 00:52:11.509119
# Unit test for function identity
def test_identity():
    assert identity(10) == 10
    assert identity(None) is None
    assert identity('hello') == 'hello'
    assert identity([1, 2, 3]) == [1, 2, 3]
    assert identity(['a', 'b', 'c']) == ['a', 'b', 'c']


# Generated at 2022-06-24 00:52:12.646515
# Unit test for function pipe
def test_pipe():
    assert pipe(1, identity, increase, increase) == 3



# Generated at 2022-06-24 00:52:23.617237
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 3, 4, 5, 6, 7]
    assert curried_filter(lambda x: x > 3, collection) == [4, 5, 6, 7]
    assert curried_filter(lambda x: x > 7, collection) == []
    assert curried_filter(lambda x: x % 2 == 0, collection) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0)(collection) == [2, 4, 6]
    assert curried_filter(lambda x: x > 3)(collection) == [4, 5, 6, 7]
    assert curried_filter(lambda x: x > 7)(collection) == []



# Generated at 2022-06-24 00:52:33.815869
# Unit test for function curry
def test_curry():
    # simple example of curry
    def add(a, b, c):
        return a + b + c

    print('---curry---')
    curried_add = curry(add)
    print(curried_add(1)(2)(3))

    curried_add = curry(add, 2)
    print(curried_add(1)(2))
    print(curried_add(1, 2))

    def add_with_kw(a, b, c=0, d=0):
        return a + b + c + d

    curried_add_with_kw = curry(add_with_kw)
    print(curried_add_with_kw(1)(2)(3)(4))
    print(curried_add_with_kw(1)(2)(3))

# Generated at 2022-06-24 00:52:39.916219
# Unit test for function curried_map
def test_curried_map():
    print('Test curried_map:')
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3])([1, 2, 3]) == [2, 3, 4]
    print('*******************')


# Generated at 2022-06-24 00:52:49.527866
# Unit test for function memoize
def test_memoize():
    def count_b():
        nonlocal counter
        counter += 1
        return counter

    counter = 0
    memoized_count_b = memoize(count_b)
    assert counter == 0
    assert memoized_count_b(1) == 1
    assert counter == 1
    assert memoized_count_b(1) == 1
    assert counter == 1
    assert memoized_count_b(2) == 2
    assert counter == 2
    assert memoized_count_b(1) == 1
    assert counter == 2


# Generated at 2022-06-24 00:52:50.754361
# Unit test for function eq
def test_eq():
    assert True is eq(2, 2)
    assert False is eq(3, 2)



# Generated at 2022-06-24 00:52:55.043807
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(2), [1, 2, 3]) == [2]


# Generated at 2022-06-24 00:53:02.285261
# Unit test for function pipe
def test_pipe():
    result = pipe(
        [1, 2, 3, 4],
        lambda list: list[-1],
        increase
    )
    assert result == 5

    result = pipe(
        [1, 2, 3, 4],
        lambda list: list[-1],
        increase,
        lambda value: value + 1
    )
    assert result == 6



# Generated at 2022-06-24 00:53:04.451157
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(2), [1, 3, 2, 1, 2]) == [2, 2]
    assert curried_filter(eq(4), [1, 2, 3, 2, 1, 2]) == []



# Generated at 2022-06-24 00:53:08.819738
# Unit test for function memoize
def test_memoize():
    @memoize
    def get_square(x):
        return x * x

    assert get_square(1) == 1
    assert get_square(1) == 1
    assert get_square(3) == 9
    assert get_square(3) == 9
    assert get_square(1) == 1
    assert get_square(2) == 4
    assert get_square(2) == 4


# Generated at 2022-06-24 00:53:11.143603
# Unit test for function curried_filter
def test_curried_filter():
    def if_less_than_3(value):
        return value < 3

    assert curried_filter(if_less_than_3)([1, 2, 3, 4, 5]) == [1, 2]



# Generated at 2022-06-24 00:53:20.451210
# Unit test for function memoize
def test_memoize():
    """
    :returns: Unit test result
    :rtype: Bool
    """
    def some_func(value):
        print(value)
        return increase(value)

    def inc_func(value):
        return increase(value)

    def eq_func(x, y):
        return x == y

    result = memoize(some_func, eq_func)

    assert result(1) == 2
    assert result(2) == 3
    assert result(1) == 2
    assert result(1) == 2

    result1 = memoize(inc_func)

    assert result1(5) == 6
    assert result1(5) == 6
    assert result1(5) == 6



# Generated at 2022-06-24 00:53:22.968852
# Unit test for function pipe
def test_pipe():
    assert pipe(5, sqrt, lambda x: x * 2) == 5



# Generated at 2022-06-24 00:53:24.675958
# Unit test for function identity
def test_identity():
    assert identity(8) == 8
    assert identity(identity) == identity


# Generated at 2022-06-24 00:53:29.077502
# Unit test for function find
def test_find():
    """
    Should return 2
    """
    assert find([1, 2, 3], lambda x: x == 2) == 2


"""
Should return None
"""
assert find([1, 2, 3], lambda x: x == 5) is None



# Generated at 2022-06-24 00:53:29.834986
# Unit test for function identity
def test_identity():
    assert identity(5) == 5



# Generated at 2022-06-24 00:53:31.112429
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)

test_eq()



# Generated at 2022-06-24 00:53:37.847276
# Unit test for function pipe
def test_pipe():
    is_even = lambda number: number % 2 == 0
    is_odd = lambda number: number % 2
    is_10 = lambda number: number == 10

    assert pipe(10, is_even, is_odd, is_10) is False
    assert pipe(0, is_even, is_odd, is_10) is True


# Generated at 2022-06-24 00:53:46.138040
# Unit test for function compose
def test_compose():
    identity = lambda x: x
    twice = lambda x: x*2
    hello = lambda x: "Hello {}".format(x)
    assert compose(
        "Hello World!",
        hello,
        twice) == compose(
            "Hello World!",
            lambda x: hello(twice(x))
        )
    assert compose(
        "Hello World!",
        hello,
        twice,
        identity
    ) == compose(
        "Hello World!",
        hello,
        twice
    )
    assert compose(
        "World!",
        hello,
        twice,
        identity) == "Hello World!"
    assert compose(
        2,
        lambda x: x+1,
        lambda x: x / 2) == 2
    assert compose(10, twice) == 20
    assert compose(1000, twice, twice) == 4000

# Generated at 2022-06-24 00:53:47.206706
# Unit test for function pipe
def test_pipe():
    assert(pipe(1, lambda x: x + 1, lambda x: x + 1) == 3)


# Generated at 2022-06-24 00:53:53.592059
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b, c: a + b + c)(1)(2)(3) == 6
    assert curry(lambda a, b, c: a + b + c)(1, 2)(3) == 6
    assert curry(lambda a, b, c: a + b + c)(1, 2, 3) == 6


# Generated at 2022-06-24 00:53:58.450733
# Unit test for function cond
def test_cond():
    test_a = cond([
        (lambda x, y: x > 1, lambda x, y: y + '1'),
        (lambda x, y: x == 1, lambda x, y: y + '2'),
        (lambda x, y: True, lambda x, y: y),
    ])
    return test_a(1, '1')



# Generated at 2022-06-24 00:54:04.022215
# Unit test for function find
def test_find():
    list_to_search = [
        ('a', 'b'),
        ('c', 'd'),
    ]
    key = lambda item: item[0] == 'a'

    assert 'b' == find(list_to_search, key)[1]
    assert find(list_to_search, lambda item: item[0] == 'a1') is None



# Generated at 2022-06-24 00:54:10.218033
# Unit test for function memoize
def test_memoize():
    interface = [
            [identity,                   [1, 1]],
            [increase,                   [1, 2]],
            [compose(identity, increase), [1, 2]],
            [compose(
                increase,
                compose(identity, increase)),
                [1, 3]
            ],
            [pipe(
                increase,
                compose(identity, increase)),
                [1, 3]
            ],
            [cond(
                [
                    [eq(1), lambda: "One"],
                    [eq(2), lambda: "Two"],
                    [eq(3), lambda: "Three"]
                ]
            ), [3, "Three"]]
        ]
    for (function, expected_result) in interface:
        assert function(*expected_result[0]) == expected_result[1]
    memoized

# Generated at 2022-06-24 00:54:12.789896
# Unit test for function memoize
def test_memoize():
    def get_value():
        return 1

    result = memoize(get_value)

    assert result() == 1
    assert result() == 1
    assert result() == 1
    assert result() == 1
    assert result() == 1

