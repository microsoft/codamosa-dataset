

# Generated at 2022-06-24 00:44:19.011122
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x < 5)([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert curried_filter(lambda x: x < 5)([1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4]
    assert curried_filter(lambda x: x > 5)([1, 2, 3, 4, 5, 6]) == [6]


# Generated at 2022-06-24 00:44:20.633787
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3



# Generated at 2022-06-24 00:44:22.446108
# Unit test for function compose
def test_compose():
    assert compose(3, (lambda x: x + 3), (lambda x: x * 3), str) == '18'



# Generated at 2022-06-24 00:44:24.060649
# Unit test for function find
def test_find():
    assert find(range(10), curry(eq, 2)) == 2
    assert find(range(10), curry(eq, 20)) is None



# Generated at 2022-06-24 00:44:27.415732
# Unit test for function cond
def test_cond():
    cond_result = cond([(lambda value: value == 1, lambda value: 'one'),
                        (lambda value: value == 2, lambda value: 'two')])

    assert cond_result(1) == 'one'
    assert cond_result(2) == 'two'
    assert cond_result(3) is None



# Generated at 2022-06-24 00:44:33.685844
# Unit test for function curry
def test_curry():
    curried_add = curry(lambda x, y, z: x + y + z)
    assert curried_add(1)(2)(3) == 6
    assert curried_add(1, 2)(3) == 6
    assert curried_add(1)(2, 3) == 6



# Generated at 2022-06-24 00:44:37.796556
# Unit test for function cond
def test_cond():
    condition_list = [
        (lambda x: x > 0, print),
        (lambda x: x == 0, lambda: print('zero')),
        (lambda x: True, lambda: print('less zero'))
    ]
    test_function = cond(condition_list)
    test_function(5)
    test_function(0)
    test_function(-5)



# Generated at 2022-06-24 00:44:39.464728
# Unit test for function memoize
def test_memoize():
    assert memoize(identity)(1) == memoize(identity)(1)



# Generated at 2022-06-24 00:44:41.532957
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(4) == 5



# Generated at 2022-06-24 00:44:46.214832
# Unit test for function identity
def test_identity():
    assert identity(True)
    assert identity(False)
    assert identity(None)
    assert identity('')
    assert identity([])
    assert identity(())
    assert identity({})
    assert identity(1) == 1
    assert identity(-1) == -1
    assert identity(1.1) == 1.1
    assert identity(-1.1) == -1.1
    assert identity((1, 1.1, 'hi', True)) == (1, 1.1, 'hi', True)



# Generated at 2022-06-24 00:44:50.695589
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity("1") == "1"



# Generated at 2022-06-24 00:44:54.142935
# Unit test for function compose
def test_compose():
    from unittest import TestCase, main

    class TestFunction(TestCase):
        def test_compose(self):
            f = compose(1, lambda x: x + 1, lambda x: x + 1)
            self.assertEqual(3, f)
    main()



# Generated at 2022-06-24 00:44:58.124387
# Unit test for function compose
def test_compose():
    assert compose(
        1,
        lambda x: x * 2,
        lambda x: x + 1,
        lambda x: x + x
    ) == 6



# Generated at 2022-06-24 00:44:59.497684
# Unit test for function pipe
def test_pipe():
    assert pipe(1, identity, increase, increase) == 3



# Generated at 2022-06-24 00:45:05.162198
# Unit test for function compose
def test_compose():
    """
    Test compose functionality
    """
    test_collection = [1, 2, 3, 4]
    assert compose(test_collection,
                   increase,
                   increase) == [3, 4, 5, 6], "Error in compose"
    assert compose(test_collection,
                   [lambda x: increase(x), lambda x: increase(x)]) == [3, 4, 5, 6], "Error in compose"
    assert compose(test_collection,
                   [increase, increase]) == [3, 4, 5, 6], "Error in compose"



# Generated at 2022-06-24 00:45:08.942889
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:45:09.689914
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:45:19.129767
# Unit test for function memoize
def test_memoize():
    test_list = [1, 2, 3, 4, 5]

    # Example

    @memoize
    def fn(x):
        print(f'First: {x}')
        return x

    result = fn(3)
    assert result == 3
    result = fn(3)
    assert result == 3

    def square_x(x):
        return x ** 2

    assert list(map(square_x, test_list)) == list(map(memoize(square_x), test_list))

    # First - Function
    # Second - Result
    # Third - Number of function invoking

    # A
    @memoize
    def a(x):
        return x

    assert a(1) == 1
    assert a(1) == 1
    assert a(1) == 1

# Generated at 2022-06-24 00:45:20.259445
# Unit test for function identity
def test_identity():
    assert 'd' == identity('d'), 'identity returns first argument'



# Generated at 2022-06-24 00:45:21.552582
# Unit test for function increase
def test_increase():
    assert increase(2) == 3



# Generated at 2022-06-24 00:45:25.734937
# Unit test for function eq
def test_eq():
    assert True == eq(1, 1)
    assert False == eq(1, 2)
    curried_eq = eq(1)
    assert True == curried_eq(1)
    assert False == curried_eq(2)



# Generated at 2022-06-24 00:45:32.890657
# Unit test for function cond
def test_cond():
    test_equal = compose(
        compose(
            cond([
                (lambda x: x > 3, compose(increase, increase, increase)),
                (lambda x: x > 1, increase),
                (lambda x: True, identity),
            ]),
            increase
        ),
        increase
    )

    assert test_equal(1) == 3, \
        "Should return 3 equal to increased 3 times"

    assert test_equal(2) == 3, \
        "Should return 3 equal to increased 3 times"

    assert test_equal(3) == 4, \
        "Should return 4 equal to increased 4 times"

    assert test_equal(4) == 7, \
        "Should return 7 equal to increased 7 times"

    print("test_cond finished")



# Generated at 2022-06-24 00:45:34.802661
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda e: e == 2) == 2
    assert find([1, 2, 3], lambda e: e == 5) is None



# Generated at 2022-06-24 00:45:39.076184
# Unit test for function curried_filter
def test_curried_filter():
    """
    Test curried_filter function.
    """
    assert curried_filter(eq(1), [1, 2, 3]) == [1]
    assert curried_filter(eq(1), [2, 3]) == []
    assert curried_filter(lambda x: x == 1, [1, 2, 3]) == [1]
    assert curried_filter(lambda x: x == 1, [2, 3]) == []



# Generated at 2022-06-24 00:45:50.171502
# Unit test for function cond
def test_cond():
    def greatest_common_divisor(a, b):
        if b == 0:
            return a
        return greatest_common_divisor(b, a % b)

    def fibonacci(number):
        def function_1(number):
            return number == 1 or number == 2

        def function_2(number):
            return number

        def function_3(number):
            return fibonacci(number - 1) + fibonacci(number - 2)

        return cond([
            (function_1, function_2),
            (lambda *_: True, function_3)
        ])(number)

    assert fibonacci(3) == 2
    assert fibonacci(4) == 3
    assert fibonacci(5) == 5
    assert fibonacci(6) == 8

# Generated at 2022-06-24 00:45:51.916433
# Unit test for function increase
def test_increase():
    assert increase(4) == 5, 'increase(4) should be 5'



# Generated at 2022-06-24 00:45:56.313794
# Unit test for function pipe
def test_pipe():
    """
    Check if function pipe() work properly.

    :return: None
    :rtype: None
    """
    assert pipe(2, increase, increase) == 4
    assert pipe(2, increase, increase, lambda x: x > 3)



# Generated at 2022-06-24 00:45:58.632598
# Unit test for function increase
def test_increase():
    assert increase(3) == 4
    assert increase(0) == 1
    assert increase(-3) == -2



# Generated at 2022-06-24 00:46:03.739475
# Unit test for function find
def test_find():
    # Test for find when collection is empty
    assert find([], identity) is None
    # Test for find when no element matches
    assert find([1, 2, 3], lambda x: x == 0) is None
    # Test for find which return the first element of the list which matches the keys
    assert find([1, 2, 3], lambda x: x == 2) == 2


# Generated at 2022-06-24 00:46:07.552596
# Unit test for function find
def test_find():
    assert find([], identity) is None
    assert find([1, 2, 3, 4], lambda x: x == 4) == 4
    assert find([1, 2, 3, 4], lambda x: x == 0) is None



# Generated at 2022-06-24 00:46:15.085362
# Unit test for function cond
def test_cond():
    assert cond([
        (eq(1), compose(str, increase)),
        (eq(2), identity)
    ])(1) == '2'
    assert cond([
        (eq(1), identity),
        (eq(2), compose(str, increase))
    ])(2) == '3'
    assert cond([
        (eq(0), identity),
        (eq(1), identity)
    ])(1) == 1
    assert cond([
        (eq(0), increase),
        (eq(1), identity)
    ])(1) == 1



# Generated at 2022-06-24 00:46:15.852823
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-24 00:46:20.846854
# Unit test for function cond
def test_cond():
    FIRST = 1
    SECOND = 2
    condition_list = [(eq(FIRST), identity), (eq(SECOND), increase)]
    assert cond(condition_list)(SECOND) == increase(SECOND)
    assert cond(condition_list)(FIRST) == identity(FIRST)



# Generated at 2022-06-24 00:46:27.141080
# Unit test for function compose
def test_compose():
    assert compose(1, lambda x: x + 1) == 2
    assert compose(1, lambda x: x + 1, lambda x: x + 1) == 3
    assert compose(1, lambda x: x + 1, lambda x: x + 1, lambda x: x + 1) == 4
    assert compose(1, lambda x: x + 1, lambda x: x + 1, lambda x: x + 1, lambda x: x + 1) == 5



# Generated at 2022-06-24 00:46:28.199725
# Unit test for function curry
def test_curry():
    assert (curry(lambda x, y: x + y, 2)(1)(2) == 3)



# Generated at 2022-06-24 00:46:32.131809
# Unit test for function pipe
def test_pipe():
    assert pipe(
        [{'name': 'mike'}, {'name': 'peter'}],
        curried_filter(lambda x: x['name'] == 'mike'),
        curried_map(lambda x: x['name'])
    ) == ['mike']



# Generated at 2022-06-24 00:46:39.719391
# Unit test for function find
def test_find():
    assert (find([1, 2, 3, 4, 5], lambda x: x == 3) == 3)
    assert (find([1, 2, 3, 4, 5], lambda x: x == 7) is None)
    assert (find([{"id": 1}, {"id": 2}], lambda x: x["id"] == 2) == {"id": 2})
    assert (find([{"id": 1}, {"id": 2}], lambda x: x["id"] == 3) is None)


# Generated at 2022-06-24 00:46:43.905785
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity("test") == "test"
    assert identity([1, 2, 3]) == [1, 2, 3]
    assert identity({}).__class__ == dict
    assert identity(set()) == set()
    assert identity((1,)) == (1,)



# Generated at 2022-06-24 00:46:54.389774
# Unit test for function memoize
def test_memoize():
    def adder(a, b):
        return a + b

    def subtract(a, b):
        return a - b

    memoized_adder = memoize(adder)
    memoized_subtract = memoize(subtract)

    assert memoized_adder(1, 2) == 3
    assert memoized_adder(1, 2) == 3
    memoized_adder.cache.append((3, 3))
    assert memoized_adder(1, 2) == 3

    memoized_subtract.cache.append(((1, 2), 3))
    assert memoized_subtract(1, 2) == 3
    assert memoized_subtract(1, 2) == 3



# Generated at 2022-06-24 00:47:03.283712
# Unit test for function cond
def test_cond():
    def is_even(x): return x % 2 == 0

    def is_negative(x): return x < 0

    def is_string(x): return isinstance(x, str)

    def even_or_negative(x): return x * 2

    def string_or_none(x): return "string"

    assert cond([
        (is_even, even_or_negative),
        (is_negative, even_or_negative),
        (is_string, string_or_none)
    ])(1) == -2
    assert cond([
        (is_even, even_or_negative),
        (is_negative, even_or_negative),
        (is_string, string_or_none)
    ])(-4) == -8

# Generated at 2022-06-24 00:47:13.502727
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 4) == 4, 'value should be 4'
    assert find([1, 2, 3, 4], lambda x: x == 3) == 3, 'value should be 3'
    assert find([1, 2, 3, 4], lambda x: x == 2) == 2, 'value should be 2'
    assert find([1, 2, 3, 4], lambda x: x == 1) == 1, 'value should be 1'
    assert find(['one', 'two', 'three', 'four'], lambda x: x == 'four') == 'four', 'value should be \'four\''
    assert find(['one', 'two', 'three', 'four'], lambda x: x == 'three') == 'three', 'value should be \'three\''

# Generated at 2022-06-24 00:47:17.605600
# Unit test for function compose
def test_compose():
    def add(value, number):
        return value + number

    compose_function = compose(5, lambda a: add(a, 2), lambda a: add(a, 3))

    assert compose_function == 10

    compose_function = compose(5, lambda a: add(a, 2))

    assert compose_function == 7



# Generated at 2022-06-24 00:47:19.081874
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(2)(2) == 4



# Generated at 2022-06-24 00:47:23.476427
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1, 1.0)

    assert eq("1", "1")
    assert not eq("1", "2")
    assert not eq("1", 1)

    assert eq(1, 1.0)
    assert eq("1", 1)
    assert eq(True, 1)

    assert eq(identity, identity)
    assert not eq(identity, identity)



# Generated at 2022-06-24 00:47:24.752988
# Unit test for function pipe
def test_pipe():
    assert pipe(1, increase, increase, increase) == 4



# Generated at 2022-06-24 00:47:26.558817
# Unit test for function identity
def test_identity():
    assert identity(5) == 5
    assert identity("Hello world!") == "Hello world!"



# Generated at 2022-06-24 00:47:30.398833
# Unit test for function compose
def test_compose():
    """
    Testing function compose.
    """
    test = compose(2, increase, lambda x: x ** 2)
    assert test == 5
    test = compose(2, lambda x: x ** 2, increase)
    assert test == 9
    test = compose(3, increase, lambda x, y: x ** y, lambda x: x / 2)
    assert test == 4.0



# Generated at 2022-06-24 00:47:32.806635
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(0) == 1
    assert increase(-1) == 0


# Generated at 2022-06-24 00:47:35.790894
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 3)([1, 2, 3, 4, 5]) == [4, 5]
    assert curried_filter(lambda x: x > 3)([1, 2]) == []



# Generated at 2022-06-24 00:47:40.671526
# Unit test for function curry
def test_curry():
    def g(a, b):
        return a + b

    assert g(1, 2) == 3

    g_c = curry(g)

    assert g_c(1)(2) == 3
    assert g_c(1, 2) == 3

    g_c1 = curry(g, 1)

    assert g_c1(2) == 3
    assert g_c1(1, 2) == 3
    assert g_c1(2, 1) == 3



# Generated at 2022-06-24 00:47:46.320711
# Unit test for function find
def test_find():
    assert find(['a', 'b'], lambda x: x == 'a') == 'a'
    assert find(['a', 'b'], lambda x: x == 'c') is None



# Generated at 2022-06-24 00:47:49.540160
# Unit test for function pipe
def test_pipe():
    """
    Test for function pipe
    """
    assert pipe(1, increase, identity) == 2, 'Should be 2'
    assert curry(pipe)(increase, identity)(1) == 2, 'Should be 2'
    assert curry(pipe)(identity, increase)(1) == 2, 'Should be 2'



# Generated at 2022-06-24 00:47:52.111878
# Unit test for function find
def test_find():
    assert find([], identity) == None
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 0) == None
    assert find([[1, 2], [3, 4]], lambda x: x == [1, 2]) == [1, 2]



# Generated at 2022-06-24 00:47:55.475135
# Unit test for function find
def test_find():
    collection = [1, 2, 3, 4, 5]
    result = find(collection, lambda list_item: list_item == 2)
    print(result)


# Generated at 2022-06-24 00:48:00.504938
# Unit test for function cond
def test_cond():
    def is_number(number):
        return lambda a: a == number

    def condition_1(a):
        return a + 1

    def condition_2(a):
        return a * 2

    function = cond([(is_number(6), condition_1), (is_number(4), condition_2)])
    assert function(4) == condition_2(4)
    assert function(6) == condition_1(6)

# Generated at 2022-06-24 00:48:05.100137
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-24 00:48:12.156820
# Unit test for function memoize
def test_memoize():
    nonmemoized_fib = lambda n: n if n < 2 else nonmemoized_fib(n - 1) + nonmemoized_fib(n - 2)
    memoized_fib = memoize(nonmemoized_fib)
    assert nonmemoized_fib(10) == 55
    assert memoized_fib(10) == 55
    assert memoized_fib(10) == memoized_fib(10)



# Generated at 2022-06-24 00:48:13.702045
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b, c: a + b + c)(2)(3)(4) == 9



# Generated at 2022-06-24 00:48:17.794801
# Unit test for function find
def test_find():
    assert find(
        [
            {'id': 1, 'name': 'name_1'},
            {'id': 2, 'name': 'name_3'},
            {'id': 3, 'name': 'name_3'}
        ],
        lambda item: item['id'] == 2
    ) == {'id': 2, 'name': 'name_3'}



# Generated at 2022-06-24 00:48:19.095868
# Unit test for function identity
def test_identity():
    assert identity(5) == 5
    assert identity('a') == 'a'



# Generated at 2022-06-24 00:48:25.985118
# Unit test for function cond
def test_cond():
    def get_int(obj):
        return obj['int']

    def get_float(obj):
        return obj['float']

    def get_default(obj):
        return obj['default']

    get_field = cond([
        [eq(1), get_int],
        [eq(2), get_float],
        [eq(3), get_default],
    ])

    assert get_field({
        'int': 1,
        'float': 0.5,
        'default': True,
    }) == 1

    assert get_field({
        'int': 2,
        'float': 0.5,
        'default': True,
    }) == 0.5

    assert get_field({
        'int': 3,
        'float': 0.5,
        'default': True,
    }) is True



# Generated at 2022-06-24 00:48:28.365623
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(None) is None
    assert identity(True) is True
    assert identity([]) == []
    assert identity(()) == ()


# Generated at 2022-06-24 00:48:32.087769
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda item: item == 1) == 1
    assert find([1, 2, 3], lambda item: item == 2) == 2
    assert find([1, 2, 3], lambda item: item == 3) == 3
    assert find([1, 2, 3], lambda item: item == 4) is None



# Generated at 2022-06-24 00:48:38.425766
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-24 00:48:43.044549
# Unit test for function curried_map
def test_curried_map():
    curried_map_ = curry(curried_map)
    assert curried_map_(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map_(identity, [1, 2, 3]) == [1, 2, 3]
    assert curried_map_(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-24 00:48:44.606475
# Unit test for function find
def test_find():
    assert find(range(10), eq(2)) == 2
    assert find(range(10), eq(11)) is None

# Generated at 2022-06-24 00:48:49.727899
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x < 5)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4]
    assert curried_filter(lambda x: x < 5)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 2, 3, 4]



# Generated at 2022-06-24 00:48:50.703526
# Unit test for function pipe
def test_pipe():
    assert pipe(0, increase, increase, increase) == 3
    assert pipe(0, increase, str) == '1'



# Generated at 2022-06-24 00:48:51.647028
# Unit test for function identity
def test_identity():
    assert identity('123') == '123', 'Test function identity'



# Generated at 2022-06-24 00:48:54.837188
# Unit test for function find
def test_find():
    assert (find(
        [5, 3, 1, 4, 5, -9, 7],
        lambda x: x > 0
    )) == 5

    assert (find(
        [],
        lambda x: x > 0
    )) is None



# Generated at 2022-06-24 00:48:55.897326
# Unit test for function compose
def test_compose():
    assert compose(2, str, increase, increase) == "4"



# Generated at 2022-06-24 00:49:03.047273
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [0, 1, 2, 3, 4]) == [1, 2, 3, 4, 5]
    assert curried_map(increase)([0, 1, 2, 3, 4]) == [1, 2, 3, 4, 5]
    assert curried_map(increase, [0, 1, 2])([3, 4]) == [4, 5]



# Generated at 2022-06-24 00:49:05.215545
# Unit test for function curried_filter
def test_curried_filter():
    curried_filter(lambda x: x > 0, [1, 2, 3, -1]) == [1, 2, 3]

if __name__ == '__main__':
    test_curried_filter()

# Generated at 2022-06-24 00:49:09.384349
# Unit test for function cond
def test_cond():
    is_even = lambda value: value % 2 == 0
    is_odd = lambda value: value % 2 == 1

    result = cond([
        (is_even, identity),
        (is_odd, increase)
    ])

    assert result(1) == 2
    assert result(2) == 2



# Generated at 2022-06-24 00:49:13.090574
# Unit test for function find
def test_find():
    assert find([0, 1, 2, 3], lambda x: x == 2) == 2
    assert find([0, 1, 2, 3], lambda x: x == 4) is None
    assert find([0, 1, 2, 3], lambda x: x % 2 == 0) == 0
    assert find([], lambda x: x == 4) is None



# Generated at 2022-06-24 00:49:15.445305
# Unit test for function eq
def test_eq():
    assert(eq(2, 2) == True)
    assert(eq(2, 3) == False)
    assert(eq(2)(2) == True)



# Generated at 2022-06-24 00:49:17.987005
# Unit test for function curry
def test_curry():
    def add(a, b):
        return a + b

    assert curry(add)(2, 3) == 5
    assert curry(add)(2)(3) == 5
    assert curry(add, 3)(2, 3, 4) == 9



# Generated at 2022-06-24 00:49:19.576510
# Unit test for function compose
def test_compose():
    assert compose(1, identity, increase, increase) == 3
    assert compose(1, increase, identity) == 2



# Generated at 2022-06-24 00:49:22.196754
# Unit test for function compose
def test_compose():
    """
    Unit test function
    """

    assert callable(compose)

    assert compose(1, identity) == 1
    assert compose(1, increase) == 2
    assert compose(1, increase, increase) == 3
    assert compose(1, increase, lambda value: value * 2) == 4


# Generated at 2022-06-24 00:49:23.213653
# Unit test for function pipe
def test_pipe():
    f = pipe(
        4,
        increase
    )
    assert f() == 5


# Generated at 2022-06-24 00:49:25.940871
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 5]

    assert curried_filter(lambda a: a % 2 == 0, collection) == [2]
    assert curried_filter(lambda a: a % 2 == 0)(collection) == [2]



# Generated at 2022-06-24 00:49:28.086296
# Unit test for function pipe
def test_pipe():
    def add(x, y):
        return x + y

    def multi(x, y):
        return x * y

    assert pipe(1, add, multi)(2, 3) == 7


# Generated at 2022-06-24 00:49:31.507635
# Unit test for function memoize
def test_memoize():
    assert pipe(memoize(increase, eq), increase, increase, increase)() == 5
    assert pipe(memoize(increase, eq), increase, increase)() == 3



# Generated at 2022-06-24 00:49:35.509816
# Unit test for function compose
def test_compose():
    def fn1(value):
        return value * 2
    def fn2(value):
        return value + 1
    def fn3(value):
        return value
    assert compose(5, fn1, fn2, fn3) == 11



# Generated at 2022-06-24 00:49:45.257557
# Unit test for function memoize
def test_memoize():
    """
    Unit test for function memoize.

    :returns: None
    :rtype: None
    """
    def curried_add(item1):
        def add(item2):
            return item1 + item2
        return add

    memoized_add = memoize(curried_add)
    print(memoized_add(1)(2))
    print(list(map(memoized_add(1), [1, 2, 3, 4])))  # [2, 3, 4, 5]

    # I don't get why is this test so important.
    # This function has nothing to do with returning curried function
    memoize2 = memoize(lambda x: x)
    print(memoize2(''))
    print(memoize2(1))

# Generated at 2022-06-24 00:49:50.116065
# Unit test for function cond
def test_cond():
    result = cond(
        [(lambda x: x > 10, lambda x: x - 1),
         (lambda x: x < 5, lambda x: x + 1)]
    )(101)
    assert result == 100

    result = cond(
        [(lambda x: x > 10, lambda x: x - 1),
         (lambda x: x < 5, lambda x: x + 1)]
    )(4)
    assert result == 5



# Generated at 2022-06-24 00:49:55.396063
# Unit test for function curried_map
def test_curried_map():
    collection = [1, 2, 3]
    add_one = curried_map(lambda x: x + 1)
    add_two = curried_map(lambda x: x + 2)

    assert add_one(collection) == [2, 3, 4]
    assert add_two(collection) == [3, 4, 5]



# Generated at 2022-06-24 00:49:58.027091
# Unit test for function pipe
def test_pipe():
    result = pipe(1, increase, str)
    assert result == "2", "pipe returns not correct result"



# Generated at 2022-06-24 00:50:00.484706
# Unit test for function curried_map
def test_curried_map():
    test_curried_map = curried_map(increase)
    assert test_curried_map([0, 1]) == [1, 2]



# Generated at 2022-06-24 00:50:02.068821
# Unit test for function find
def test_find():
    assert find([], lambda item: item == 5) is None

# Generated at 2022-06-24 00:50:03.898916
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x == 4)([1, 2, 4, 8, 16, 32]) == [4]



# Generated at 2022-06-24 00:50:07.650585
# Unit test for function curried_map
def test_curried_map():
    # Preparing test data
    collection = [1, 2, 3, 4]
    # Preparing expected data
    expected_result = [2, 4, 6, 8]
    # Preparing test function
    test_mapper = lambda x: x * 2
    # Testing function curried_map
    assert(curried_map(test_mapper, collection) == expected_result)


# Generated at 2022-06-24 00:50:09.233617
# Unit test for function memoize
def test_memoize():
    add_one = memoize(lambda x: x + 1)
    assert add_one(1) == 2
    assert add_one(1) == 2


# Generated at 2022-06-24 00:50:19.854517
# Unit test for function memoize
def test_memoize():
    counter: int = 0

    @memoize
    def test(value):
        nonlocal counter
        counter += 1
        return counter

    assert test(1) == 1
    assert test(1) == 1
    assert test(1) == 1
    assert test(2) == 2
    assert test(2) == 2
    assert test(2) == 2
    assert test(1) == 1
    assert test(1) == 1
    assert test(1) == 1
    assert test(3) == 3
    assert test(3) == 3
    assert test(3) == 3
    assert test(2) == 2
    assert test(2) == 2
    assert test(2) == 2



# Generated at 2022-06-24 00:50:24.031019
# Unit test for function increase
def test_increase():
    assert increase(3) == 4



# Generated at 2022-06-24 00:50:34.377892
# Unit test for function cond
def test_cond():
    def is_number(number):
        return isinstance(number, (int, float))

    def is_string(string):
        return isinstance(string, str)

    def true(_):
        return True

    def double_number(number):
        return number * 2

    def concat_string(first: str, second: str):
        return f'{first}{second}'

    def sum_numbers(first: int, second: int):
        return first + second

    f = cond([
        (is_number, double_number),
        (is_string, concat_string),
    ])

    assert f(5) == 10
    assert f('foo') == 'foofoo'

    f = cond([
        (is_number, double_number),
        (true, sum_numbers),
    ])



# Generated at 2022-06-24 00:50:37.206220
# Unit test for function increase
def test_increase():
    value = increase(1)
    assert value == 2

# Generated at 2022-06-24 00:50:38.529341
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-24 00:50:44.126145
# Unit test for function eq
def test_eq():
    assert True == eq(1, 1)
    assert True == eq(1, eq(1))
    assert False == eq(1, 2)
    assert False == eq(1, eq(2))

# Generated at 2022-06-24 00:50:50.757441
# Unit test for function cond
def test_cond():
    equals = lambda x, y: x is y
    cond_function = cond([
        (lambda x: equals(x, 1), lambda: 4),
        (lambda x: equals(x, 2), lambda: 5),
        (lambda x: equals(x, 3), lambda: 6),
    ])
    assert cond_function(1) == 4
    assert cond_function(2) == 5
    assert cond_function(3) == 6


# Unit tests for function memoize

# Generated at 2022-06-24 00:50:53.229277
# Unit test for function compose
def test_compose():
    assert compose(1, increase, increase) == 3
    assert compose(1, identity, increase, increase, increase) == 4



# Generated at 2022-06-24 00:50:58.823380
# Unit test for function find
def test_find():

    assert find([1, 2, 3], eq(2)) == 2
    assert find([1, 2, 3], eq(5)) is None
    assert find([], eq(5)) is None

    assert find([2, 3, 4], lambda x: x > 2) == 3
    assert find(["test", "test1", "test2"], lambda x: x.startswith("test")) == "test"



# Generated at 2022-06-24 00:51:01.492486
# Unit test for function identity
def test_identity():
    assert identity(5) == 5


# Generated at 2022-06-24 00:51:05.790266
# Unit test for function cond
def test_cond():
    assert cond([(lambda x: x % 2 == 0, lambda x: x + 2)])(1) is None
    assert cond([(lambda x: x % 2 == 0, lambda x: x + 2)])(2) == 4
    assert cond([
        (lambda x: x % 2 == 0, lambda x: x + 2),
        (lambda x: x % 2 == 1, lambda x: x + 3)
    ])(1) == 4
    assert cond([
        (lambda x: x % 2 == 0, lambda x: x + 2),
        (lambda x: x % 2 == 1, lambda x: x + 3)
    ])(2) == 4



# Generated at 2022-06-24 00:51:08.388828
# Unit test for function curried_filter
def test_curried_filter():
    print(curried_filter(lambda x: x[0] == 'a')([['a', 1], ['b', 2], ['a', 3], ['d', 4]]))



# Generated at 2022-06-24 00:51:13.500600
# Unit test for function curry
def test_curry():
    # increment(1) == 2
    increment = curry(lambda a, b: a + b)
    assert 2 == increment(1)

    # increment(1)(2) == 3
    increment = curry(lambda a, b: a + b)
    assert 3 == increment(1)(2)



# Generated at 2022-06-24 00:51:15.006591
# Unit test for function eq
def test_eq():
    assert eq(5, 5) is True



# Generated at 2022-06-24 00:51:20.277734
# Unit test for function memoize
def test_memoize():
    def factorial(n):
        return n * factorial(n-1) if n != 0 else 1
    def test(n):
        return n * n

    memoized_factorial = memoize(factorial)
    memoized_test = memoize(test)

    print(memoized_factorial(10))

    for i in range (10):
        assert memoized_test(i) == i * i

    # AssertionError: assert 25 == None

# Generated at 2022-06-24 00:51:23.757406
# Unit test for function cond
def test_cond():
    """
    Check for correct work of function cond.
    """
    condition_list = [
        (lambda number: number == 0, lambda number: number),
        (lambda number: number < 10, lambda number: number + 1)
    ]

    cond_function = cond(condition_list)

    assert cond_function(0) == 0
    assert cond_function(5) == 6
    assert cond_function(10) is None

# Generated at 2022-06-24 00:51:24.861947
# Unit test for function identity
def test_identity():
    assert identity('String') == 'String'


# Generated at 2022-06-24 00:51:29.845569
# Unit test for function curried_filter
def test_curried_filter():
    numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    less_than_five = curried_filter(lambda item: item < 5)
    assert less_than_five(numbers) == [1, 2, 3, 4]


# Generated at 2022-06-24 00:51:33.050692
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(3) == 3
    assert identity(5) == 5
    return 'test_identity ok'


# Generated at 2022-06-24 00:51:37.272173
# Unit test for function curry
def test_curry():
    myfunc = curry(lambda a, b, c: a + b + c)
    assert myfunc(1, 2, 3) == 6
    assert myfunc(1, 2)(3) == 6
    assert myfunc(1)(2, 3) == 6
    assert myfunc(1)(2)(3) == 6



# Generated at 2022-06-24 00:51:39.662183
# Unit test for function compose
def test_compose():
    assert 1 == compose(1, identity, increase, increase)
    assert 3 == compose(1, increase, increase)
    assert 1 == compose(1, identity)



# Generated at 2022-06-24 00:51:40.968274
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True


# Generated at 2022-06-24 00:51:51.334820
# Unit test for function cond
def test_cond():
    def greater_than(x, y):
        return x > y

    def equal_to(x, y):
        return x == y

    @curry
    def sum(x, y):
        return x + y

    @curry
    def minus(x, y):
        return x - y

    @curry
    def mult(x, y):
        return x * y

    @curry
    def divide(x, y):
        return x / y

    operation = cond([
        (greater_than(3), sum),
        (equal_to(3), minus),
        (equal_to(2), mult),
        (equal_to(1), divide),
    ])

    return operation(3, 5) == 3 + 5



# Generated at 2022-06-24 00:51:52.500839
# Unit test for function identity
def test_identity():
    assert identity(5) == 5



# Generated at 2022-06-24 00:51:58.601888
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x > 0, lambda x: x + 5 ),
        (lambda x: x < 0, lambda x: x - 10),
    ])(10) == 15
    assert cond([
        (lambda x: x > 0, lambda x: x + 5 ),
        (lambda x: x < 0, lambda x: x - 10),
    ])(-10) == -20


# Generated at 2022-06-24 00:52:01.526908
# Unit test for function compose
def test_compose():
    str_add_exclamation = compose('Hello', lambda string: string * 3, lambda string: string + '!')
    assert(str_add_exclamation == 'HelloHelloHello!')



# Generated at 2022-06-24 00:52:04.470508
# Unit test for function curried_filter
def test_curried_filter():
    curried_filtered = curried_filter(
        lambda item: item > 10,
        [1, 2, 3, 5, 10, 11, 20, 21]
    )
    assert curried_filtered == [11, 20, 21]



# Generated at 2022-06-24 00:52:09.647321
# Unit test for function increase
def test_increase():
    assert(increase(1)) == 2, "increase function doesn't work"
    print("increase function - OK")


# Generated at 2022-06-24 00:52:11.080628
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:52:17.440995
# Unit test for function compose
def test_compose():
    def add(value, value1):
        return value + value1

    def multiply(value, value1):
        return value * value1

    def double(value):
        return value * 2

    def square(value):
        return value ** 2

    assert(compose(1, add, multiply, double, square)(10, 10) == (1 * (10 + 10) * (10 * 2) * (10 ** 2)))



# Generated at 2022-06-24 00:52:22.508399
# Unit test for function curry
def test_curry():
    @curry
    def add(x, y):
        return x + y

    assert add(1)(2) == 3

    @curry
    def add(x, y, z):
        return x + y + z

    assert add(1, 2)(3) == 6



# Generated at 2022-06-24 00:52:31.255477
# Unit test for function curry
def test_curry():
    print('Test curry')

    def sum(a, b, c, d):
        return a + b + c + d

    a = 1
    b = 2
    c = 3
    d = 4

    curry_sum = curry(sum)
    curry_a_sum = curry_sum(a)
    curry_b_a_sum = curry_a_sum(b)
    curry_c_b_a_sum = curry_b_a_sum(c)
    assert curry_c_b_a_sum(d) == a + b + c + d
    assert curry_sum(a)(b)(c)(d) == a + b + c + d
    assert curry_sum(a, b)(c)(d) == a + b + c + d
    assert curry_sum(a)(b, c)(d) == a

# Generated at 2022-06-24 00:52:34.028579
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6



# Generated at 2022-06-24 00:52:37.635485
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False
    assert eq(1)(1) is True
    assert eq(1)(2) is False


# Generated at 2022-06-24 00:52:42.138780
# Unit test for function curry
def test_curry():
    """
    Unit test for function curry.
    """
    def add(x, y, z=0):
        return x + y + z

    a = curry(add)
    b = a(1)
    c = b(2)
    assert c() == 3



# Generated at 2022-06-24 00:52:43.791400
# Unit test for function identity
def test_identity():
    assert identity(2) == 2


# Generated at 2022-06-24 00:52:52.017305
# Unit test for function memoize
def test_memoize():
    import random
    import time

    def factorial(n):
        if n < 0:
            raise RuntimeError('Factorial for negative numbers does not exist')
        if n < 2:
            return 1
        return reduce(lambda a, b: a * b, range(2, n + 1))

    memoized_factorial = memoize(factorial)

    # measure time
    number = random.randint(0, 1000)
    start = time.time()
    memoized_factorial(number)
    end = time.time()
    first_call_duration = end - start

    # measure time
    start = time.time()
    memoized_factorial(number)
    end = time.time()
    second_call_duration = end - start

    assert first_call_duration > second_call_duration

# Generated at 2022-06-24 00:52:52.897291
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:52:59.288262
# Unit test for function curried_map
def test_curried_map():
    square = lambda x: x * x
    double = lambda x: 2 * x
    assert curried_map(square, []), []
    assert curried_map(square, [1, 2, 3, 4, 5]), [1, 4, 9, 16, 25]
    assert curried_map(double, [1, 2, 3, 4, 5]), [2, 4, 6, 8, 10]
    assert curried_map(square)([1, 2, 3, 4, 5]), [1, 4, 9, 16, 25]

    # Unit test for function curried_map

# Generated at 2022-06-24 00:53:03.873107
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([]) == []



# Generated at 2022-06-24 00:53:07.326717
# Unit test for function pipe
def test_pipe():
    assert pipe(0, [identity, increase]) == 1
    assert pipe(1, [increase, increase]) == 3
    assert pipe([1, 2, 3], [lambda c: [increase(item) for item in c], lambda c: [item for item in c if item == 2]]) == [2]

# Generated at 2022-06-24 00:53:11.756726
# Unit test for function curried_filter
def test_curried_filter():
    is_even = lambda number: number % 2 == 0
    curried_filter_func = curried_filter(is_even)
    assert curried_filter_func([1, 4, 6, 7, 5, 1, 6, 9]) == [4, 6, 6]
    assert curried_filter_func([1, 1]) == []



# Generated at 2022-06-24 00:53:13.491332
# Unit test for function curried_map
def test_curried_map():
    assert [1, 2, 3] == curried_map(increase)([0, 1, 2])

# Generated at 2022-06-24 00:53:17.973414
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x ** 2)([1, 2, 3]) == [1, 4, 9]
    assert curried_map(lambda x: x ** 2, [1, 2, 3]) == [1, 4, 9]


# Generated at 2022-06-24 00:53:25.323699
# Unit test for function find
def test_find():
    assert find(
        [],
        lambda item: item == 1
    ) is None

    assert find(
        [1],
        lambda item: item == 1
    ) == 1

    assert find(
        [1, 2, 3],
        lambda item: item == 1
    ) == 1

    assert find(
        [1, 2, 3],
        lambda item: item == 4
    ) is None



# Generated at 2022-06-24 00:53:26.852129
# Unit test for function increase
def test_increase():
    assert increase(1) == 2


# Generated at 2022-06-24 00:53:28.424724
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 2) == 2
    assert find([1, 2, 3, 4], lambda x: x == 3) == 3



# Generated at 2022-06-24 00:53:30.864818
# Unit test for function curried_map
def test_curried_map():
    # result = curried_map(identity, [1, 2, 3])
    result = curried_map(identity)([1, 2, 3])
    assert result == [1, 2, 3]



# Generated at 2022-06-24 00:53:38.424844
# Unit test for function memoize
def test_memoize():
    def test_function(a, b, c=1):
        print('function')
        return a + b + c

    memoized_function = memoize(test_function)
    assert memoized_function(1, 2) == 4
    assert memoized_function(1, 3) == 5
    assert memoized_function(1, 2) == 4
    print("memoize - ok")


# Generated at 2022-06-24 00:53:43.513448
# Unit test for function cond
def test_cond():
    assert cond(
        [(eq(0), lambda x: "zero"),
         (eq(1), lambda x: "one"),
         (lambda x: True, lambda x: "many")]
    )(0) == "zero"
    assert cond(
        [(eq(0), lambda x: "zero"),
         (eq(1), lambda x: "one"),
         (lambda x: True, lambda x: "many")]
    )(1) == "one"
    assert cond(
        [(eq(0), lambda x: "zero"),
         (eq(1), lambda x: "one"),
         (lambda x: True, lambda x: "many")]
    )(10) == "many"

# Generated at 2022-06-24 00:53:46.138043
# Unit test for function find
def test_find():
    list_ = [{'a': 1}, {'b': 2}, {'c': 3}]
    assert find(list_, lambda item: item['b'] == 2) == {'b': 2}
    assert find(list_, lambda item: item['a'] == 5) is None



# Generated at 2022-06-24 00:53:54.225421
# Unit test for function curry
def test_curry():
    def add(a, b, c):  return a + b + c
    curried_add = curry(add)
    assert curried_add(1, 2, 3) == 6  # curried_add(1, 2, 3) == 6
    assert curried_add(1, 2)(3) == 6  # curried_add(1, 2)(3) == 6
    assert curried_add(1)(2, 3) == 6  # curried_add(1)(2, 3) == 6
    assert curried_add(1)(2)(3) == 6  # curried_add(1)(2)(3) == 6



# Generated at 2022-06-24 00:54:00.834191
# Unit test for function eq
def test_eq():
    assert eq(5, 5) is True
    assert eq(5, "5") is False
    assert eq(5, "5") is False
    assert eq(True, True) is True
    assert eq(True, False) is False
    assert eq([1, 2], [1, 2]) is False
    assert eq((1, 2), (1, 2)) is True


test_eq()



# Generated at 2022-06-24 00:54:03.043307
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4]) == [2, 4]


# Generated at 2022-06-24 00:54:04.023136
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-24 00:54:07.738384
# Unit test for function curried_filter
def test_curried_filter():
    assert isinstance(curried_filter(eq(1)), Callable)
    assert isinstance(curried_filter(eq(1), [1, 2]), list)
    assert curried_filter(eq(1), [1, 2]) == [1]



# Generated at 2022-06-24 00:54:10.396042
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1)(1) is True
    assert eq(0, 1) is False
    assert eq(0)(1) is False



# Generated at 2022-06-24 00:54:13.139551
# Unit test for function curry
def test_curry():
    assert curry(lambda x: x)(1) == 1
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6

