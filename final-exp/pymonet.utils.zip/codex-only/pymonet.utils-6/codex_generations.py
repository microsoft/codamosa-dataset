

# Generated at 2022-06-24 00:44:19.953205
# Unit test for function memoize
def test_memoize():
    maxValue = 8
    results = []

    def fibonacci(i):
        if i < 2:
            return i
        return fibonacci(i - 1) + fibonacci(i - 2)

    fibonacci_memoize = memoize(fibonacci)

    for i in range(maxValue):
        results.append(fibonacci_memoize(i))

    assert fibonacci_memoize.__closure__ is not None
    assert results == [
        0, 1, 1, 2, 3, 5, 8, 13, 21
    ]

# Generated at 2022-06-24 00:44:21.455557
# Unit test for function compose
def test_compose():
    assert compose(5, lambda x: x * x, lambda x: x + 1) == 26



# Generated at 2022-06-24 00:44:23.455916
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5]
                         ) == [2, 4]


# Generated at 2022-06-24 00:44:24.192923
# Unit test for function increase
def test_increase():
    assert increase(5) == 6



# Generated at 2022-06-24 00:44:26.996188
# Unit test for function curried_map
def test_curried_map():
    """
    Test function curried_map
    :return: curried_map([1,2], mapper=increase)
    :rtype: List[int]
    """
    return curried_map([1,2], mapper=increase)


# Generated at 2022-06-24 00:44:29.090575
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(compose(identity, increase))([1, 2, 3]) == [2, 3, 4]

    assert curried_filter(lambda x: x > 2)([1, 2, 3]) == [3]



# Generated at 2022-06-24 00:44:32.570117
# Unit test for function compose
def test_compose():
    assert compose(5, increase, increase) == 7
    assert compose(5, increase, identity) == 6



# Generated at 2022-06-24 00:44:33.155276
# Unit test for function pipe
def test_pipe():
    assert pipe(3, increase, increase, increase) == 6

# Generated at 2022-06-24 00:44:37.488876
# Unit test for function curried_map
def test_curried_map():
    curried_map_test_list = [1, 2, 3]
    curried_result = curried_map(increase, curried_map_test_list)
    curried_result2 = curried_map(increase)(curried_map_test_list)
    assert curried_result == [2, 3, 4]
    assert curried_result2 == [2, 3, 4]



# Generated at 2022-06-24 00:44:45.323306
# Unit test for function cond
def test_cond():
    def is_zero(value):
        return value == 0

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    def execute_positive(value):
        return f'Value {value} is positive'

    def execute_zero(value):
        return f'Value {value} is zero'

    def execute_negative(value):
        return f'Value {value} is negative'

    expected_positive = 'Value 1 is positive'
    expected_zero = 'Value 0 is zero'
    expected_negative = 'Value -1 is negative'

    actual_positive = cond([
        (is_positive, execute_positive),
        (is_zero, execute_zero),
        (is_negative, execute_negative)
    ])(1)


# Generated at 2022-06-24 00:44:53.307822
# Unit test for function memoize
def test_memoize():
    def doubler(x):
        return x * 2

    doubler_memoized = memoize(doubler)
    list(map(doubler_memoized, list(range(3))))

    def tripler(x):
        return x * 3

    new_memoized = memoize(tripler)
    list(map(new_memoized, list(range(3))))



# Generated at 2022-06-24 00:45:00.877858
# Unit test for function cond
def test_cond():
    """
    Test function cond
    """
    is_true = lambda value: value is True
    is_false = lambda value: value is False
    return_true = lambda: True
    return_false = lambda: False

    condition = [
        (is_true, return_true),
        (is_false, return_false)
    ]
    assert cond(condition)(True)
    assert not cond(condition)(False)
    assert not cond(condition)("123")



# Generated at 2022-06-24 00:45:05.743230
# Unit test for function curried_filter
def test_curried_filter():
    """
    Test for function curried_filter.
    """
    assert curried_filter(lambda x: x >= 2)([1, 2, 3, 4]) == [2, 3, 4]



# Generated at 2022-06-24 00:45:11.272263
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda value: value == 0, lambda value: "Zero"),
        (lambda value: value % 2 == 0, lambda value: "Even"),
        (lambda value: value % 2 == 1, lambda value: "Odd"),
    ])(6) == "Even"

    assert cond([
        (lambda value: value == 0, lambda value: "Zero"),
        (lambda value: value % 2 == 0, lambda value: "Even"),
        (lambda value: value % 2 == 1, lambda value: "Odd"),
    ])(3) == "Odd"


# Generated at 2022-06-24 00:45:13.499482
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x >= 10)([1, 2, 10, 12]) == [10, 12]
    assert curried_filter(lambda x: x >= 10)([]) == []


# Generated at 2022-06-24 00:45:17.686948
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(0) == 1
    assert increase(2) == 3
    assert increase(-1) == 0


# Generated at 2022-06-24 00:45:25.204854
# Unit test for function curried_filter
def test_curried_filter():
    # Define anonymous function for filter items in list by 5
    is_five = lambda x: x == 5
    # Create new curried function filtering list by 5
    curried_filter_by_five = curried_filter(is_five)
    # Create new list filtered by 5
    filtered_list = curried_filter_by_five([1, 5, 7, 10, 15, 5, 3, 5])
    # Check if result of filtering is correct
    assert (filtered_list == [5, 5, 5])


# Generated at 2022-06-24 00:45:32.639583
# Unit test for function cond
def test_cond():
    """
    Function for testing function cond
    """
    # test for function 'identity'
    assert cond([
        (lambda val: val, identity)
    ])(1) == 1

    # test for function 'increase'
    assert cond([
        (lambda val: val, increase)
    ])(1) == 2

    # test for function 'eq'
    assert cond([
        (lambda val: val, lambda val: eq(val, 1))
    ])(1)

    # test for function 'compose'
    assert cond([
        (
            lambda val: val,
            compose(increase, identity)
        )
    ])(1) == 2

    assert cond([
        (
            lambda val: val,
            compose(identity, increase)
        )
    ])(1) == 2

    # test

# Generated at 2022-06-24 00:45:34.079216
# Unit test for function curried_filter
def test_curried_filter():
    assert [] == curried_filter(lambda x: x > 0)([-1, -2])
    assert [-1, -2] == curried_filter(lambda x: x < 0)([-1, -2])


# Generated at 2022-06-24 00:45:40.841879
# Unit test for function find
def test_find():
    example_collection = [
        {'id': 1, 'name': 'aaa'},
        {'id': 2, 'name': 'bbb'},
        {'id': 3, 'name': 'ccc'},
    ]
    assert find(example_collection, lambda item: item['id'] == 1) == {'id': 1, 'name': 'aaa'}
    assert find(example_collection, lambda item: item['id'] == 2) == {'id': 2, 'name': 'bbb'}
    assert find(example_collection, lambda item: item['id'] == 3) == {'id': 3, 'name': 'ccc'}
    assert find(example_collection, lambda item: item['id'] == 4) is None


# Generated at 2022-06-24 00:45:43.678908
# Unit test for function pipe
def test_pipe():
    # Example:
        # pipe(10, increase, increase) == 12
    # Test:
    assert pipe(10, increase, increase) == 12


# Generated at 2022-06-24 00:45:50.265729
# Unit test for function curried_filter
def test_curried_filter():
    print(curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6]))
    print(curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6]))
    print(curried_filter(lambda x: x % 2 == 0, [1, 2]))
    print(curried_filter(lambda x: x % 2 == 0)([1, 2]))



# Generated at 2022-06-24 00:45:51.890605
# Unit test for function curried_map
def test_curried_map():
    assert (curry(curried_map)(increase)(range(10)) == range(1, 11))



# Generated at 2022-06-24 00:45:52.820173
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-24 00:45:59.229145
# Unit test for function cond
def test_cond():
    """
    Test for function cond.
    """
    def cond_fn(param):
        return cond([
            (lambda x: x > 0, lambda x: x + 1),
            (lambda x: x == 0, lambda x: x),
            (lambda x: x < 0, lambda x: x - 1)
        ])(param)

    assert cond_fn(0) == 0
    assert cond_fn(1) == 2
    assert cond_fn(-1) == -2



# Generated at 2022-06-24 00:46:03.977000
# Unit test for function curry
def test_curry():
    def add(a, b): return a + b

    add_curried = curry(add)
    assert add_curried(1)(2) == 3

    # Assert that curried function is immutable
    assert add_curried(1)(2) == 3
    assert add_curried(1)(2) == 3



# Generated at 2022-06-24 00:46:06.162685
# Unit test for function identity
def test_identity():
    test_value = 1
    assert identity(test_value) == test_value



# Generated at 2022-06-24 00:46:08.014414
# Unit test for function eq
def test_eq():
    assert False == eq(1, 2)
    assert True == eq(2, 2)



# Generated at 2022-06-24 00:46:10.608972
# Unit test for function cond
def test_cond():
    def test_condition(x):
        return x == 6

    def execute_function(x):
        return x % 2 == 0

    new_func = cond([
        (test_condition, execute_function),
    ])

    assert new_func(6) == True



# Generated at 2022-06-24 00:46:16.040901
# Unit test for function cond
def test_cond():
    def test_func(x, y):
        return cond([
            (lambda x, y: x > y, lambda x, y: (x, y, 'x > y')),
            (lambda x, y: x < y, lambda x, y: (x, y, 'x < y')),
            (lambda x, y: x == y, lambda x, y: (x, y, 'x == y'))
        ])(x, y)

    assert test_func(1, 2) == (1, 2, 'x < y')
    assert test_func(2, 1) == (2, 1, 'x > y')
    assert test_func(1, 1) == (1, 1, 'x == y')


# Generated at 2022-06-24 00:46:19.974758
# Unit test for function curry
def test_curry():
    def f(x, y):
        return x + y

    assert curry(f)(1)(1) == 2



# Generated at 2022-06-24 00:46:23.604673
# Unit test for function compose
def test_compose():
    def add1(value):
        return value + 1

    def mul2(value):
        return value * 2

    assert compose(1, mul2, add1) == 4



# Generated at 2022-06-24 00:46:29.185162
# Unit test for function cond
def test_cond():
    def even(value: int) -> int:
        return value % 2 == 0

    def odd(value: int) -> int:
        return value % 2 == 1

    def sqr(value: int) -> int:
        return value ** 2

    def cube(value: int) -> int:
        return value ** 3

    def false(_) -> bool:
        return False

    def identity(value: str) -> str:
        return value

    assert(
        cond([
            (even, sqr),
            (odd, cube),
            (false, identity),
        ])(0) == 0)
    assert(
        cond([
            (even, sqr),
            (odd, cube),
            (false, identity),
        ])(1) == 1)

# Generated at 2022-06-24 00:46:29.984027
# Unit test for function increase
def test_increase():
    assert increase(2) == 3


# Generated at 2022-06-24 00:46:33.603594
# Unit test for function compose
def test_compose():
    assert compose(1, increase) == 2
    assert compose(
        1,
        lambda x: x + 4,
        increase
    ) == 6



# Generated at 2022-06-24 00:46:44.449274
# Unit test for function pipe

# Generated at 2022-06-24 00:46:46.710748
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-24 00:46:47.579245
# Unit test for function identity
def test_identity():
    assert identity(2) == 2



# Generated at 2022-06-24 00:46:55.372923
# Unit test for function find
def test_find():
    list1 = [1, 2, 3, 4, 5, 6]
    list2 = ['1', '2', '3', '4', '5', '6']
    list3 = ['1', '2', '3', '4', '5', '6']
    eq_function = eq
    assert find(list1, eq_function(2)) == 2
    assert find(list2, eq_function('1')) == '1'
    assert find(list3, eq_function('20')) is None



# Generated at 2022-06-24 00:46:59.668647
# Unit test for function find
def test_find():
    assert find([1, 2], eq(2)) == 2, "first"
    assert find([1, 2], eq(5)) is None, "second"
    assert find([1, 2, 3, 4], eq(3)) == 3, "third"
    assert find([1, 2, 3, 4], eq(5)) is None, "fourth"



# Generated at 2022-06-24 00:47:02.664441
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda value: value == 2) == 2
    assert find([1, 2, 3, 4, 5], lambda value: value == 6) == None



# Generated at 2022-06-24 00:47:10.011945
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda item: item > 1, [1, 2, 3]) == [2, 3]
    assert curried_filter(lambda item: item > 1, []) == []
    assert curried_filter(lambda item: item is not None, []) == []
    assert curried_filter(lambda item: item is not None, [None, 1]) == [1]



# Generated at 2022-06-24 00:47:19.309148
# Unit test for function memoize
def test_memoize():
    def multiply_by(multiplier):
        "A function that multiplies the input by 10"
        return multiplier*10

    memoized_multiply_by = memoize(multiply_by)

    assert memoized_multiply_by(5) == 50
    assert memoized_multiply_by(5) == 50
    assert memoized_multiply_by(6) == 60
    assert memoized_multiply_by(6) == 60

    from functools import partial
    memoized_multiply_by = memoize(multiply_by, key=partial(eq, 5))
    assert memoized_multiply_by(5) == 50
    assert memoized_multiply_by(5) == 50
    assert memoized_multiply_by(6) == 60

# Generated at 2022-06-24 00:47:27.732217
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x == 0, lambda x: 'water freezes at 0°C'),
        (lambda x: x == 100, lambda x: 'water boils at 10°C'),
        (lambda x: True, lambda x: 'nothing special happens at {0}°C'.format(x))
    ])(0) == 'water freezes at 0°C'
    assert cond([
        (lambda x: x == 0, lambda x: 'water freezes at 0°C'),
        (lambda x: x == 100, lambda x: 'water boils at 10°C'),
        (lambda x: True, lambda x: 'nothing special happens at {0}°C'.format(x))
    ])(100) == 'water boils at 10°C'

# Generated at 2022-06-24 00:47:35.245612
# Unit test for function curry
def test_curry():
    assert(curry(lambda x, y: x + y)(1)(2) == 3)
    assert(curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6)
    assert(curry(lambda x, y, z, q: x + y + z + q)(1)(2, 3, 4) == 10)



# Generated at 2022-06-24 00:47:40.935792
# Unit test for function cond
def test_cond():
    assert cond([(lambda x: x % 2 == 0, lambda x: x // 2),
                 (lambda x: (x + 1) % 2 == 0, lambda x: x * 3 + 1)
                 ])(3) == 10
    assert cond([
        (lambda x: x < 0, lambda x: "less than 0"),
        (lambda x: x == 0, lambda x: "equal 0"),
        (lambda x: x > 0, lambda x: "greater than 0"),
    ])(-1) == "less than 0"


if __name__ == '__main__':
    test_cond()

# Generated at 2022-06-24 00:47:48.276675
# Unit test for function eq
def test_eq():
    # eq is curried function
    # but we can use it in different ways
    assert eq(1, 2) == False, 'eq() should return False if arguments don\'t equal'
    assert eq(1, 1) == True, 'eq() should return True if arguments equal'

    assert eq(1)(1) == True, 'eq() should return True if arguments equal'
    assert eq(1)(2) == False, 'eq() should return False if arguments don\'t equal'

    # when we use it in functional style,
    # we should remember that this function curried
    assert not eq(1)(eq(2))(), 'eq() should return False if arguments don\'t equal'
    assert eq(eq(1))(1)(), 'eq() should return True if arguments equal'



# Generated at 2022-06-24 00:47:52.007673
# Unit test for function pipe
def test_pipe():
    assert pipe(1, lambda x: x + 1, lambda x: x * 3) == 6

# Generated at 2022-06-24 00:47:53.646507
# Unit test for function identity
def test_identity():
    assert identity(1) == 1

# Generated at 2022-06-24 00:47:56.153574
# Unit test for function find
def test_find():
    assert find(range(10), lambda x: x > 4) == 5
    assert find(range(10), lambda x: x > 15) is None



# Generated at 2022-06-24 00:47:59.293321
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-24 00:48:03.254050
# Unit test for function curry
def test_curry():
    """
    Test functions:

      - curry
      - identity
      - increase

    :returns: None
    :rtype: None

    """
    # passed first argument to increase and it return increased version of it
    assert increase(5) == 6

    # increased applied only to last argument and return increased version of it
    assert curry(increase)(1, 2) == 3
    # passed 3 arguments but function increase is only for 2 arguments
    # last argument call increase and return increased version of it
    assert curry(increase, 3)(1, 2) == 3

    # identity returns first argument
    assert identity(5) == 5
    # curry applied only to last argument and return first argument
    assert curry(identity)(1, 2) == 2
    # curry applied for all arguments but function identity is only for one argument
    # last argument call identity and

# Generated at 2022-06-24 00:48:05.170557
# Unit test for function pipe
def test_pipe():

    def add(x, y): return x + y

    assert pipe(1, lambda x: add(x, 1), lambda x: add(x, 10)) == 12, 'Test for function pipe'

# Generated at 2022-06-24 00:48:08.235587
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([3]) == [4]
    assert curried_map(increase)([3, 4]) == [4, 5]
    assert curried_map(increase)([3, 4, 5]) == [4, 5, 6]
    assert curried_map(identity)([3]) == [3]
    assert curried_map(identity)([3, 4]) == [3, 4]
    assert curried_map(identity)([3, 4, 5]) == [3, 4, 5]



# Generated at 2022-06-24 00:48:09.438536
# Unit test for function identity
def test_identity():
    result = identity(5)
    assert result == 5



# Generated at 2022-06-24 00:48:12.234703
# Unit test for function compose
def test_compose():
    assert compose(3, increase, increase, increase) == 6
    assert compose(3, increase, increase) == 5
    assert compose(3, increase) == 4
    assert compose(3, identity) == 3


# Generated at 2022-06-24 00:48:14.415752
# Unit test for function increase
def test_increase():
    assert increase(10) == 11
    assert increase(10) == 11
    assert increase(10) == 11
    assert increase(10) == 11



# Generated at 2022-06-24 00:48:21.376736
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x > 4, lambda x: x),
        (lambda x: x > 3, lambda x: x),
        (lambda x: x > 2, lambda x: x),
        (lambda x: x > 1, lambda x: x),
        (lambda x: x > 0, lambda x: x),
    ])(5) == 5
    assert cond([
        (lambda x: x > 4, lambda x: x),
        (lambda x: x > 3, lambda x: x),
        (lambda x: x > 2, lambda x: x),
        (lambda x: x > 1, lambda x: x),
        (lambda x: x > 0, lambda x: x),
    ])(3) == 3

# Generated at 2022-06-24 00:48:27.188770
# Unit test for function memoize
def test_memoize():
    def fib(n):
        if n < 2:
            return n
        return fib(n - 1) + fib(n - 2)

    fib = memoize(fib)
    fib(400)

    print(fib(400))
    # expected output: 43466557686937456435688527675040625802564660517371780402481729089536555417949051890403879840079255169295922593080322634775209689623239873322471161642996440906533187938298969649928516003704476137795166849228875



# Generated at 2022-06-24 00:48:31.792229
# Unit test for function memoize
def test_memoize():
    counter_calls = 0

    @memoize
    def memoized_fn(value):
        nonlocal counter_calls
        counter_calls += 1
        return value * 2

    memoized_fn(1)
    memoized_fn(1)
    memoized_fn(2)
    memoized_fn(2)
    memoized_fn(3)

    assert counter_calls == 3



# Generated at 2022-06-24 00:48:37.505123
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(1))([1, 2]) == [1]
    assert curried_filter(eq(2))([1, 2]) == [2]
    assert curried_filter(eq(1))([1, 2, 2]) == [1]
    assert curried_filter(eq(1))([1, 1, 2]) == [1, 1]



# Generated at 2022-06-24 00:48:43.445443
# Unit test for function find
def test_find():
    # search by identity
    assert find([1, 2, 3, 4], lambda x: x == 2) == 2

    # search by eq function
    assert find([1, 2, 3, 4], eq(3)) == 3

    # search not existing value
    assert find([1, 2, 3, 4], eq(5)) is None

    # search by identity in empty collection
    assert find([], lambda x: x == 2) is None

    # search by identity in None collection
    assert find(None, lambda x: x == 2) is None

# Generated at 2022-06-24 00:48:50.120959
# Unit test for function cond
def test_cond():
    def is_even(x):
        return not x % 2

    def add_x(x):
        return x + 1

    def multiple_x(x):
        return x * 2

    def square_x(x):
        return x ** 2

    result_function = cond(
        [(is_even, add_x), (is_even, square_x), (identity, multiple_x)])

    assert result_function(2) == 5
    assert result_function(3) == 12
    assert result_function(4) == 9



# Generated at 2022-06-24 00:48:59.819623
# Unit test for function cond
def test_cond():
    def condition1(arg):
        return arg == 1

    def condition2(arg):
        return arg == 2

    def condition3(arg):
        return arg == 3

    def execute_function_for_condition1(arg):
        return 1

    def execute_function_for_condition2(arg):
        return 2

    def execute_function_for_condition3(arg):
        return 3

    # if arg == 1 return 1
    # if arg == 2 return 2
    # if arg == 3 return 3
    # if arg != 1,2,3 return 0
    condition_list = [
        (condition1, execute_function_for_condition1),
        (condition2, execute_function_for_condition2),
        (condition3, execute_function_for_condition3)
    ]

    # if arg == 1 return 1

# Generated at 2022-06-24 00:49:01.567386
# Unit test for function identity
def test_identity():
    assert identity('test') == 'test'
    assert identity(42) == 42
    assert identity(False) is False



# Generated at 2022-06-24 00:49:12.973824
# Unit test for function eq
def test_eq():
    assert eq((1, 2, 3), (1, 2, 3))
    assert not eq((1, 2, 3), (1, 2, 3, 4))
    assert not eq((1, 2, 3), ())
    assert not eq((), ())

    assert eq(1, 1)
    assert not eq(1, 2)

    assert eq("", "")
    assert not eq("", "s")
    assert not eq("s", "")
    assert eq("s", "s")

    assert eq("str", "str")
    assert not eq("str", "String")

    assert eq({}, {})
    assert eq({1}, {1})
    assert not eq({1}, {1, 2})
    assert not eq({1}, {})

    # With currying
    assert eq(2)(2)

# Generated at 2022-06-24 00:49:17.396389
# Unit test for function compose
def test_compose():
    is_even = lambda x: x % 2 == 0
    mul_two = lambda x: x * 2
    add_one = lambda x: x + 1
    test_value = 2
    expected_result = mul_two(add_one(test_value))
    actual_result = compose(test_value, add_one, mul_two)
    assert actual_result == expected_result



# Generated at 2022-06-24 00:49:21.885309
# Unit test for function pipe
def test_pipe():
    assert pipe(
        2,
        increase,
        increase,
        increase
    ) == 5



# Generated at 2022-06-24 00:49:25.255723
# Unit test for function curry
def test_curry():
    assert identity(1) == 1
    identity1 = curry(identity)
    assert identity1(1) == 1
    identity2 = curry(identity, 1)
    assert identity2(1) == 1

    assert increase(1) == 2
    increase3 = curry(increase)
    assert increase3(1) == 2
    increase4 = curry(increase, 1)
    assert increase4(1) == 2

    assert eq(1, 1)
    assert eq(1)(1)



# Generated at 2022-06-24 00:49:26.902254
# Unit test for function pipe
def test_pipe():
    value = '   abC   '
    len_result = len(value)

    pipe_value = pipe(value, str.upper, str.strip, len)

    assert pipe_value == len_result



# Generated at 2022-06-24 00:49:32.593925
# Unit test for function memoize
def test_memoize():

    def fn(x):
        return x + 1

    memoized_fn = memoize(fn)
    assert memoized_fn(1) == 2
    assert memoized_fn(1) == 2
    cache = memoized_fn.__globals__['cache']  # could not find better solution
    assert len(cache) == 1



# Generated at 2022-06-24 00:49:36.503471
# Unit test for function memoize
def test_memoize():
    def test_fn(argument: str) -> str:
        return argument * 3

    memoized_test_fn = memoize(test_fn)
    assert memoized_test_fn('1') == '111'



# Generated at 2022-06-24 00:49:43.380287
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x**2, [1, 2, 3]) == [1, 4, 9]
    assert curried_map(lambda x: ''.join(['a', x]), ['a1', 'a2', 'a3']) == ['aa1', 'aa2', 'aa3']



# Generated at 2022-06-24 00:49:45.836651
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 3, 4, 5]
    filterer = lambda x: x > 2
    print(curried_filter(filterer)(collection))



# Generated at 2022-06-24 00:49:47.835902
# Unit test for function eq
def test_eq():
    assert True is eq(1, 1)
    assert True is eq(3)(3)
    assert False is eq(3)(4)



# Generated at 2022-06-24 00:49:58.635874
# Unit test for function cond
def test_cond():
    assert cond([
        (eq(3), lambda x: x * 2),
        (eq(4), lambda x: x * 3),
        (eq(5), lambda x: x * 4),
    ])(3)(3) == 6
    assert cond([
        (eq(3), lambda x: x * 2),
        (eq(4), lambda x: x * 3),
        (eq(5), lambda x: x * 4),
    ])(4)(4) == 12
    assert cond([
        (eq(3), lambda x: x * 2),
        (eq(4), lambda x: x * 3),
        (eq(5), lambda x: x * 4),
    ])(5)(5) == 20



# Generated at 2022-06-24 00:50:04.943169
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0, []) == []
    assert curried_filter(lambda x: x % 2 == 0) == curried_filter(lambda x: x % 2 == 0)
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4]) == [2, 4]

if __name__ == "__main__":
    test_curried_filter()

# Generated at 2022-06-24 00:50:14.964881
# Unit test for function curried_filter
def test_curried_filter():
    """
    Test for curried_filter function
    """
    list_of_zeros = [0, 0, 0, 0, 0]
    list_of_ones = [1, 1, 1, 1, 1]

    filter_zeros = curried_filter(eq(0))
    filter_ones = curried_filter(eq(1))

    assert filter_zeros(list_of_zeros) == list_of_zeros
    assert filter_zeros(list_of_ones) == []

    assert filter_ones(list_of_ones) == list_of_ones
    assert filter_ones(list_of_zeros) == []


# Generated at 2022-06-24 00:50:19.989254
# Unit test for function curry
def test_curry():
    @curry
    def multiply(number, multiplier):
        return number * multiplier
    assert multiply(2, 6) == 12
    assert multiply(2)(6) == 12
    assert multiply(multiplier=10)(number=3) == 30
    assert multiply(10)(multiplier=3, number=6) == 60



# Generated at 2022-06-24 00:50:26.796796
# Unit test for function curried_filter
def test_curried_filter():
    assert_true = compose(
        eq(True),
        identity
    )

    assert_true(
        compose(
            curried_filter(lambda x: x == 5),
            lambda x: list(range(x))
        )(10)
    )
    assert_true(
        compose(
            curried_filter(lambda x: x % 2 == 0),
            lambda x: list(range(x))
        )(10)
    )



# Generated at 2022-06-24 00:50:29.723479
# Unit test for function memoize
def test_memoize():
    # Arrange
    def fn(argument):
        return argument * 2

    # Act
    fn1 = memoize(fn)

    # Assert
    print(fn1(1))
    print(fn1(2))



# Generated at 2022-06-24 00:50:36.010090
# Unit test for function curried_filter
def test_curried_filter():
    """
    Test for curried_filter
    """
    assert curried_filter(eq(2))([1, 2, 3, 4, 5]) == [2]
    assert curried_filter(lambda x: x == 2, [1, 2, 3, 4, 5]) == [2]


if __name__ == '__main__':
    test_curried_filter()

# Generated at 2022-06-24 00:50:44.565592
# Unit test for function memoize
def test_memoize():
    def simple_function(a):
        return a + 1

    memoized_simple_function = memoize(simple_function)

    memoized_simple_function_result = memoized_simple_function(1)
    memoized_simple_function_result_two = memoized_simple_function(1)
    assert memoized_simple_function_result == memoized_simple_function_result_two
    memoized_simple_function_result_three = memoized_simple_function(2)
    assert memoized_simple_function_result != memoized_simple_function_result_three



# Generated at 2022-06-24 00:50:53.436204
# Unit test for function cond
def test_cond():
    is_zero = lambda x: x == 0
    return_42 = lambda x: 42
    return_x = lambda x: x

    cond_is_zero = cond([(is_zero, return_42)])
    assert cond_is_zero(0) == 42
    assert cond_is_zero(1) is None

    cond_is_zero_or_return_x = cond([
        (is_zero, return_42),
        (identity, return_x),
    ])
    assert cond_is_zero_or_return_x(0) == 42
    assert cond_is_zero_or_return_x(1) == 1

# Generated at 2022-06-24 00:50:56.223454
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x % 2 == 0) == 2
    assert find([], lambda x: True) is None


# Generated at 2022-06-24 00:51:04.424805
# Unit test for function curry
def test_curry():
    @curry
    def f(a, b, c):
        return a + b + c
    assert f(1)(2)(3) == 6, 'test_curry: case 1'
    assert f(1, 2)(3) == 6, 'test_curry: case 2'
    assert f(1)(2, 3) == 6, 'test_curry: case 3'

    def _sum(a, b):
        return a + b
    assert curry(_sum)(1, 2) == 3, 'test_curry: case 4'
    assert curry(_sum, 2)(1, 2) == 3, 'test_curry: case 5'
    assert curry(_sum, 2)(1)(2) == 3, 'test_curry: case 6'

# Generated at 2022-06-24 00:51:15.283676
# Unit test for function cond
def test_cond():
    def is_string(arg):
        return type(arg) == str

    def to_uppercase(arg):
        return arg.upper()

    def to_lowercase(arg):
        return arg.lower()

    def to_join(arg):
        return ''.join(arg)

    def to_divide(arg):
        return arg[0] / arg[1]

    def to_increase(arg):
        return arg + 1

    def to_decrease(arg):
        return arg - 1


# Generated at 2022-06-24 00:51:18.046448
# Unit test for function find
def test_find():
    print("test_find")
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 10) == None



# Generated at 2022-06-24 00:51:20.814850
# Unit test for function eq
def test_eq():
    eq_function = eq(1)
    result = eq_function(1)
    assert result is True, "Equality function should return True"
    result = eq_function(2)
    assert result is False, "Equality function should return False"



# Generated at 2022-06-24 00:51:27.136833
# Unit test for function cond
def test_cond():
    def is_even(n):
        return n % 2 == 0

    def is_odd(n):
        return n % 2 == 1

    def add_one(n):
        return n + 1

    def sub_one(n):
        return n - 1

    test_function = cond([(is_even, add_one), (is_odd, sub_one)])
    assert test_function(2) == 3
    assert test_function(3) == 2

# Generated at 2022-06-24 00:51:30.705532
# Unit test for function pipe
def test_pipe():
    pipe_test = pipe(
        1,
        lambda value: value + 1,
        lambda value: value * 2,
        lambda value: value - 1,
    )

    assert pipe_test == 3



# Generated at 2022-06-24 00:51:35.582644
# Unit test for function compose
def test_compose():
    assert compose(1, identity) == 1
    assert compose(1, increase) == 2
    assert compose(1, increase, identity, increase) == 3
    assert compose(1, increase, identity, identity) == 2
    assert compose(1, identity, identity, identity) == 1



# Generated at 2022-06-24 00:51:40.767562
# Unit test for function curry
def test_curry():
    @curry
    def add(a, b):
        return a + b

    f = add(3)
    assert f(4) == 7



# Generated at 2022-06-24 00:51:47.870889
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], eq(5)) is None
    assert find([1, 2, 3, 4], eq(1)) == 1
    assert find([1, 2, 3, 4], eq(2)) == 2
    assert find([1, 2, 3, 4], eq(3)) == 3
    assert find([1, 2, 3, 4], eq(4)) == 4

    assert find(['hello', 'world'], eq('mary')) is None
    assert find(['hello', 'world'], eq('hello')) == 'hello'
    assert find(['hello', 'world'], eq('world')) == 'world'



# Generated at 2022-06-24 00:51:50.219418
# Unit test for function curried_filter
def test_curried_filter():
    data = [1, 2, 3]
    assert curried_filter(curried_map(increase))(data) == [2, 3, 4]



# Generated at 2022-06-24 00:51:55.870853
# Unit test for function cond
def test_cond():
    is_even = lambda x: x % 2 == 0
    # TODO: make better tests
    result = cond(
        [(is_even, identity),]
    )
    assert result(1) is None
    assert result(2) == 2
    assert result(3) is None
    assert result(4) == 4

# Generated at 2022-06-24 00:52:01.244299
# Unit test for function curried_map
def test_curried_map():
    print("\n" + "-" * 100 + "\n" + "   Testing curried_map" + "\n" + "-" * 100)

    increase = curried_map(increase)

    result = increase([1, 2, 3])

    print("\n" + "increase([1, 2, 3])")
    print(result)

    assert result == [2, 3, 4]



# Generated at 2022-06-24 00:52:07.341666
# Unit test for function curried_filter
def test_curried_filter():
    list_to_test = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert curried_filter(lambda item: item > 5, list_to_test) == [6, 7, 8, 9, 10]
    assert curried_filter(lambda item: item > 5)(list_to_test) == [6, 7, 8, 9, 10]
    assert curried_filter(lambda item: item > 5)([1, 2, 3, 4, 5, 6, 7]) == [6, 7]
    assert curried_filter(lambda item: item % 2 == 0, list_to_test) == [2, 4, 6, 8, 10]
    # Unit test for function curried_map

# Generated at 2022-06-24 00:52:09.310835
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False
    assert eq(1, 1, 2) is False


# Generated at 2022-06-24 00:52:17.638955
# Unit test for function cond
def test_cond():
    def condition1(value):
        return value > 0

    def condition2(value):
        return value > 10

    def function(value):
        return value + 10

    def function2(value):
        return value + 20

    def function3(value):
        return value + 30

    test_list = [
        (1, condition1, function, 11),
        (11, condition2, function2, 21),
        (12, condition1, function2, 22),
        (2, condition2, function3, 30)
    ]
    for test_arg, test_condition, test_function, expected in test_list:
        assert cond([(test_condition, test_function)]) == expected



# Generated at 2022-06-24 00:52:22.790796
# Unit test for function find
def test_find():
    array = [1, 3, 5, 7]
    found_item = find(array, lambda x: x == 3)
    assert found_item == 3
    not_found_item = find(array, lambda x: x == 4)
    assert not_found_item is None



# Generated at 2022-06-24 00:52:27.547400
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6



# Generated at 2022-06-24 00:52:29.315204
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity('text') == 'text'


# Generated at 2022-06-24 00:52:31.056973
# Unit test for function find
def test_find():
    assert find([1,2,3], eq(2)) == 2
    assert find([1, 2, 3], eq(4)) is None



# Generated at 2022-06-24 00:52:35.167756
# Unit test for function compose
def test_compose():
    """
    Test function compose
    """
    assert compose(3, increase, increase) == 5
    assert compose(3, identity) == 3
    assert compose(3, increase) == 4
    assert compose(None, increase, identity) == 1



# Generated at 2022-06-24 00:52:46.126280
# Unit test for function curried_filter
def test_curried_filter():
    def greater_than_20(item):
        return item > 20


# Generated at 2022-06-24 00:52:56.911150
# Unit test for function compose
def test_compose():
    # Create test values
    value = 5
    value_1 = 6

    # Create test functions
    test_addition = compose(
        value,
        lambda x: x + value,
        lambda x: x * value
    )
    test_divider = compose(
        value,
        lambda x: x / value,
        lambda x: x / value
    )
    test_equal = compose(
        value,
        lambda x: x == value,
        lambda x: x == value
    )
    test_equal_1 = compose(
        value,
        lambda x: x == value_1,
        lambda x: x == value
    )

    # Test
    assert test_addition == 30
    assert test_divider == 1
    assert test_equal
    assert not test_equal_1

# Unit test

# Generated at 2022-06-24 00:52:59.391421
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([]) == []


# Generated at 2022-06-24 00:53:00.892140
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False


# Generated at 2022-06-24 00:53:11.144465
# Unit test for function cond
def test_cond():
    def func1(arg):
        print('func1({})'.format(arg))
        return arg + 1

    def func2(arg):
        print('func2({})'.format(arg))
        return arg * 2

    def func3(arg):
        print('func3({})'.format(arg))
        return arg ** 3

    def func4(arg):
        print('func4({})'.format(arg))
        return arg // 4

    def func5(arg):
        print('func5({})'.format(arg))
        return arg // 5

    def func6(arg):
        print('func6({})'.format(arg))
        return arg // 6

    def func7(arg):
        print('func7({})'.format(arg))
        return arg // 7

    def func8(arg):
        raise

# Generated at 2022-06-24 00:53:14.030885
# Unit test for function pipe
def test_pipe():
    assert pipe([], identity) == []
    assert pipe([1, 2, 3, 4, 5], curried_map(increase), curried_filter(eq(3))) == [3]



# Generated at 2022-06-24 00:53:17.750377
# Unit test for function curry
def test_curry():
    def function(a, b):
        return a * b

    assert function(2, 3) == 6
    curried_function = curry(function)
    assert curried_function(2)(3) == 6



# Generated at 2022-06-24 00:53:19.948741
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:53:30.346886
# Unit test for function cond
def test_cond():
    def to_upper(value):
        return value.upper()

    def to_lower(value):
        return value.lower()

    assert eq(
        'data',
        compose(
            'Data',
            cond([
                (eq('Data'), to_upper),
                (eq('data'), to_lower)]
            )
        )
    )
    assert eq(
        'DATA',
        compose(
            'Data',
            cond([
                (eq('data'), to_lower),
                (eq('Data'), to_upper)]
            )
        )
    )
    assert eq(
        'Data',
        compose(
            'Data',
            cond([
                (eq('data'), to_lower)]
            )
        )
    )



# Generated at 2022-06-24 00:53:33.859472
# Unit test for function curry
def test_curry():

    def add(x, y, z, a):
        return x + y + z + a

    curried_add = curry(add)

    assert curried_add(1)(2)(3)(4) == 10
    assert curried_add(1)(2)(3, 4) == 10
    assert curried_add(1, 2)(3, 4) == 10
    assert curried_add(1, 2, 3, 4) == 10



# Generated at 2022-06-24 00:53:43.783219
# Unit test for function curry
def test_curry():
    # simple
    assert curry(increase)(1) == 2
    assert curry(increase, 1)(1) == 2
    # string
    assert curry(increase, 1)('1') == 2
    # curried
    increase_two = curry(increase, 2)
    increase_three = curry(increase, 3)
    assert increase_two(1) == 3
    assert increase_two(1)(1) == 3
    assert increase_two(1)(1)(1) == 3
    assert increase_two(1, 1, 1) == 3
    assert increase_three(1)(1)(1, 1, 1) == 7



# Generated at 2022-06-24 00:53:45.669902
# Unit test for function compose
def test_compose():
    assert compose(20, lambda x: x + 1, lambda x: x - 10) == 11
    assert compose(10, lambda x: x + 1) == 11
    assert compose(1) == 1



# Generated at 2022-06-24 00:53:48.379429
# Unit test for function eq
def test_eq():
    assert eq(5, 5) == True
    assert eq(5, 15) == False



# Generated at 2022-06-24 00:53:50.146123
# Unit test for function eq
def test_eq():
    eq2 = curry(eq)
    assert eq2(36)(36)
    assert not eq2(3)(36)



# Generated at 2022-06-24 00:53:54.736405
# Unit test for function curried_map
def test_curried_map():
    curried_map_2 = curried_map(lambda x: x * 2)
    assert curried_map_2([2, 3]) == [4, 6]

    assert curried_map(lambda x: x * 2, [2, 3]) == [4, 6]

    assert curried_map(lambda x: x * 2, [1, 2, 3, 4, 5]) == [2,4,6,8,10]



# Generated at 2022-06-24 00:53:58.343460
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(2) == 3
    assert increase(3) == 4
    assert increase(4) == 5
    assert increase(5) == 6
    assert increase(6) == 7


# Generated at 2022-06-24 00:54:03.182837
# Unit test for function compose
def test_compose():
    return compose(
        [1, 2, 3],
        curried_map(increase),
        curried_map(str),
        curried_filter(compose(lambda x: x % 2 == 0, increase)),
        curried_map(lambda x: x + '2')
    )



# Generated at 2022-06-24 00:54:11.958936
# Unit test for function eq
def test_eq():
    assert eq(1, 1), "one equal one"
    assert not eq(1, 2), "one not equal two"
    assert not eq(1, "1"), "one not equal '1'"
    assert not eq('one', 1), "'one' not equal 1"
    assert eq(1, 1.0), "one equal 1.0"
    assert not eq(1, 1.1), "one not equal 1.1"
    assert not eq(1, None), "one not equal None"
    assert eq('one', 'one'), "'one' equal 'one'"
    assert not eq('one', 'two'), "'one' not equal 'two'"
    assert not eq(1, True), "one not equal True"
    assert eq(1, 1j), "one equal 1j"



# Generated at 2022-06-24 00:54:13.949098
# Unit test for function identity
def test_identity():
    assert identity(0) == 0
    assert identity(1) == 1
    assert identity(None) is None

