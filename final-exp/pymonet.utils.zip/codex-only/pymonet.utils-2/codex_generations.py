

# Generated at 2022-06-24 00:44:18.685101
# Unit test for function curry
def test_curry():
    def square(a):
        return a ** 2

    assert square(2) == 4
    assert square(3) == 9

    assert curry(square)(2) == 4
    assert curry(square)(3) == 9

    square_curried = curry(square)
    square2 = square_curried(2)
    square3 = square_curried(3)

    assert square2 == 4
    assert square3 == 9



# Generated at 2022-06-24 00:44:20.814404
# Unit test for function curried_map
def test_curried_map():
    assert [1, 2, 2, 4] == curried_map(lambda x:x+1, [1, 2, 3, 4])



# Generated at 2022-06-24 00:44:24.517909
# Unit test for function pipe
def test_pipe():
    assert pipe(
        1,
        lambda x: x + 1,
        lambda y: y * y
    ) == 4

    assert pipe(
        1,
        lambda x: x + 1,
        lambda y: y * y
    ) == compose(
        1,
        lambda x: x * x,
        lambda x: x + 1
    )



# Generated at 2022-06-24 00:44:27.028936
# Unit test for function compose
def test_compose():
    assert compose(5, increase, increase) == 7
    assert compose(identity(5), increase) == compose(5, increase) == 6
    assert compose(5, identity, identity) == compose(5, identity) == 5



# Generated at 2022-06-24 00:44:28.240843
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(2)(2) == 4



# Generated at 2022-06-24 00:44:33.646313
# Unit test for function find
def test_find():
    numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

    assert find(numbers, lambda x: x % 2 == 0) == 2
    assert find(numbers, lambda x: x % 2 == 1) == 1


# Generated at 2022-06-24 00:44:35.076454
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-24 00:44:43.194847
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    def addMemoized(a, b):
        return memoize(add)(a, b)

    class ValueContainer:
        pass

    a = ValueContainer()
    b = ValueContainer()

    test_value1 = addMemoized(a, 5)
    test_value2 = addMemoized(b, 5)

    assert test_value1 == test_value2 == 10

    test_value3 = addMemoized(a, 15)
    test_value4 = addMemoized(b, 15)

    assert test_value3 == test_value4 == 20

# Generated at 2022-06-24 00:44:48.749209
# Unit test for function cond
def test_cond():
    def even_number(number): return number % 2 == 0

    def odd_number(number): return number % 2 != 0

    def even_number_plus_one(number): return even_number(number) + 1

    def odd_number_plus_one(number): return odd_number(number) + 1

    condition_list = [
        (even_number, even_number_plus_one),
        (odd_number, odd_number_plus_one)
    ]

    test_list = [4, 5, 6, 7]

    assert cond(condition_list)(4) == 5
    assert cond(condition_list)(5) == 6
    assert cond(condition_list)(6) == 7



# Generated at 2022-06-24 00:44:50.229433
# Unit test for function identity
def test_identity():
    assert identity(3) == 3



# Generated at 2022-06-24 00:44:57.050587
# Unit test for function cond
def test_cond():
    """
    Function for testing function cond.
    Return True if all test passing, else return False.

    :returns: Testing result
    :rtype: Boolean
    """
    # Unit test for cond when all condition functions return False
    test_result = cond([
        (lambda number: True, increase),
        (lambda number: True, increase),
        (lambda number: True, increase)
    ])(1) == 1
    if test_result is False:
        return test_result

    # Unit test for cond when first condition functions return True
    test_result = test_result and cond([
        (lambda number: number == 1, increase),
        (lambda number: True, increase),
        (lambda number: True, increase)
    ])(1) == 2
    if test_result is False:
        return test_result

    # Unit

# Generated at 2022-06-24 00:45:00.120835
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], eq(2)) == 2
    assert find([1, 2, 3, 4], eq(0)) is None



# Generated at 2022-06-24 00:45:10.334675
# Unit test for function memoize
def test_memoize():
    @memoize
    def sum(a, b):
        return a + b

    assert sum(2, 3) == 5, 'Test 1'
    assert sum(2, 3) == 5, 'Test 2'

    @memoize
    def sum_tuple(a):
        return a[0] + a[1]

    assert sum_tuple((2, 3)) == 5, 'Test 3'
    assert sum_tuple((2, 3)) == 5, 'Test 4'

    @memoize
    def sum_string(a):
        return int(a[0]) + int(a[1])

    assert sum_string('23') == 5, 'Test 5'
    assert sum_string('23') == 5, 'Test 6'



# Generated at 2022-06-24 00:45:17.671318
# Unit test for function curry
def test_curry():
    """
    >>> add = lambda a, b, c: a + b + c
    >>> curried_add = curry(add)
    >>> curried_add(1)(2)(3)
    6
    """
    pass



# Generated at 2022-06-24 00:45:21.306166
# Unit test for function curry
def test_curry():
    def add(a, b):
        return a + b

    assert curry(add)(1)(2) == 3
    assert curry(add, 2)(1, 2) == 3
    assert curry(add, 2)(1)(2) == 3


test_curry()



# Generated at 2022-06-24 00:45:28.837934
# Unit test for function compose
def test_compose():
    function_1 = lambda x: x + 1
    function_2 = lambda x: x * 2
    function_3 = lambda x: x ** 2
    function_4 = lambda x: x * 3
    function_5 = lambda x: x ** 3

    assert compose(1, function_1) == 2
    assert compose(1, function_2, function_1) == 4
    assert compose(1, function_3, function_4, function_1) == 54
    assert compose(1, function_5, function_3, function_4, function_2, function_1) == 576



# Generated at 2022-06-24 00:45:31.143395
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 2) == 2
    assert find([1, 2, 3, 4], lambda x: x == 5) is None



# Generated at 2022-06-24 00:45:32.658245
# Unit test for function increase
def test_increase():
    assert increase(5) == 6
    assert increase(increase(5)) == 7



# Generated at 2022-06-24 00:45:34.367192
# Unit test for function increase
def test_increase():
    """Unit test for function increase."""
    assert increase(2) == 3
    increase = curry(increase)
    increased_increase = increase(1)
    assert increased_increase(2) == 3
    increased_increase = increase(2)
    assert increased_increase() == 3


# Generated at 2022-06-24 00:45:35.913707
# Unit test for function compose
def test_compose():
    assert compose(1,
                   identity,
                   increase,
                   increase,
                   increase) == 4



# Generated at 2022-06-24 00:45:37.278988
# Unit test for function pipe
def test_pipe():
    assert pipe(2, increase, increase) == 4
    assert pipe(1, None) == 1


# Generated at 2022-06-24 00:45:40.822219
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity("hello") == "hello"
    assert identity(("hello", 1)) == ("hello", 1)



# Generated at 2022-06-24 00:45:44.046838
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(2))([1, 2, 3]) == [2]
    assert curried_filter(eq(4))([1, 2, 3]) == []



# Generated at 2022-06-24 00:45:45.070257
# Unit test for function increase
def test_increase():
    assert increase(2) == 3



# Generated at 2022-06-24 00:45:49.616737
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(2, 3) == 5
    increment = curry(lambda x: x + 1)
    assert increment(3) == 4
    assert increment(3, 4) == 4
    assert increment(3) == 4
    assert increment(y=3) == 4



# Generated at 2022-06-24 00:45:56.145125
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6
    assert curry(lambda x, y, z=3: x + y + z)(1, 2) == 6
    assert curry(lambda x, y, z=3: x + y + z)(1)(2) == 6



# Generated at 2022-06-24 00:46:00.929226
# Unit test for function pipe
def test_pipe():
    def sum(a, b):
        return a + b

    def product(a, b):
        return a * b

    assert pipe(
        2,
        lambda it: sum(it, 3),
        lambda it: product(it, 4),
        lambda it: sum(it, 5),
    ) == 45



# Generated at 2022-06-24 00:46:03.496274
# Unit test for function find
def test_find():
    assert find([], lambda x: True) is None
    assert find([1], eq(0)) is None
    assert find([0], eq(0)) == 0



# Generated at 2022-06-24 00:46:12.725244
# Unit test for function cond
def test_cond():
    def even(x: int) -> bool:
        """
        Check is number even.

        :param x: number to check
        :type x: Integer
        :returns: is number even
        :rtype: Boolean
        """
        return x % 2 == 0

    true_cond = (even, identity)
    false_cond = (lambda x: x % 2 != 1, increase)

    assert cond([])(0) == None
    assert cond([true_cond])(0) == 0
    assert cond([false_cond])(0) == 1
    assert cond([false_cond, true_cond, false_cond])(0) == 0



# Generated at 2022-06-24 00:46:18.989930
# Unit test for function compose
def test_compose():
    assert compose(1, lambda a: a + 1, lambda a: a * 2) == 4
    assert compose(2, lambda a: a + 1, lambda a: a * 2) == 6
    assert compose(
        [1, 2, 3],
        curried_map(lambda v: v + 1),
        curried_map(lambda v: v * 2)
    ) == [4, 6, 8]



# Generated at 2022-06-24 00:46:25.194357
# Unit test for function curry
def test_curry():
    def func_for_currying(a: int, b: int) -> int:
        return a + b

    my_curry = curry(func_for_currying)
    my_curry_with_args = curry(func_for_currying, 2)
    assert my_curry_with_args(1)(2) == my_curry(1, 2) == 3


# Generated at 2022-06-24 00:46:30.159044
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x == 1, identity)
    ])(1) == identity(1)
    assert cond([
        (lambda x: x == 1, identity)
    ])(2) == None



# Generated at 2022-06-24 00:46:33.748593
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 2) == 2
    assert find([1, 2, 3, 4], lambda x: x == 5) is None

# Generated at 2022-06-24 00:46:39.101385
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert eq(1, 1.0)
    assert not eq(1, '1')
    assert not eq(1, 2)
    assert eq(1)(1)
    assert eq(1)(1.0)
    assert not eq(1)('1')
    assert not eq(1)(2)



# Generated at 2022-06-24 00:46:41.989688
# Unit test for function compose
def test_compose():
    def add(x):
        return x + 1

    def multiply(x):
        return x * 2

    assert compose(1, add, multiply) == 4



# Generated at 2022-06-24 00:46:44.571282
# Unit test for function curried_map
def test_curried_map():
    print('test curried map')
    double = lambda x: x*2
    arr = [1, 2, 3]
    print('double list', curried_map(double, arr))



# Generated at 2022-06-24 00:46:48.380942
# Unit test for function increase
def test_increase():
    """
    Unit test for function increase.
    """
    assert increase(0) == 1
    assert increase(1) == 2
    assert increase(100) == 101



# Generated at 2022-06-24 00:46:53.404841
# Unit test for function pipe
def test_pipe():
    def plus_1(value):
        return value + 1

    def plus_2(value):
        return value + 2

    assert pipe(1, plus_1, plus_2) == 4



# Generated at 2022-06-24 00:46:54.191109
# Unit test for function increase
def test_increase():
    assert increase(1) == 2

# Generated at 2022-06-24 00:46:58.521625
# Unit test for function curried_map
def test_curried_map():
    """

    """
    data_for_test_curried_map = [
        [None, None],
        [[1, 2, 3], [2, 3, 4]],
        [[], []]
    ]
    for input_data, result_data in data_for_test_curried_map:
        assert curried_map(increase, input_data) == result_data



# Generated at 2022-06-24 00:47:04.260414
# Unit test for function curried_filter
def test_curried_filter():
    test_list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert curried_filter(lambda x: x % 2 == 0, test_list) == [0, 2, 4, 6, 8]

    curried_test_list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert curried_filter(lambda x: x % 2 == 0)(curried_test_list) == [0, 2, 4, 6, 8]


# Generated at 2022-06-24 00:47:08.521913
# Unit test for function find
def test_find():
    # Arrange
    collection = range(10)

    # Act
    result = find(
        collection,
        lambda item: item % 2 == 0
    )

    # Assert
    assert result is not None, "Result should not be None"
    assert result % 2 == 0, f"Result is not even, but {result}"
    print("test find passed")



# Generated at 2022-06-24 00:47:09.787177
# Unit test for function identity
def test_identity():
    assert identity(1) == 1


# Generated at 2022-06-24 00:47:19.480744
# Unit test for function compose
def test_compose():
    """
    Test for function compose.

    :returns: result of all tests
    :rtype: bool
    """

    # Test for two functions with one arguments
    def test_compose_for_compose_two_functions_with_one_argument():
        """
        Test for two functions with one arguments.

        :returns: result of test
        :rtype: Bool
        """
        assert compose(2, increase, increase) == 4
        assert compose(2, increase, identity) == 3

    # Test for three functions with one arguments
    def test_compose_for_compose_three_functions_with_one_argument():
        """
        Test for three functions with one arguments.

        :returns: result of test
        :rtype: Bool
        """

# Generated at 2022-06-24 00:47:23.993464
# Unit test for function cond
def test_cond():
    assert cond(
        [
            (lambda value: value % 3 == 0, lambda value: "Fizz"),
            (lambda value: value % 5 == 0, lambda value: "Buzz"),
        ]
    )(15) == "FizzBuzz"

    assert cond(
        [
            (lambda value: value % 3 == 0, lambda value: "Fizz"),
            (lambda value: value % 5 == 0, lambda value: "Buzz"),
        ]
    )(10) == "Buzz"



# Generated at 2022-06-24 00:47:31.465991
# Unit test for function find
def test_find():
    assert find(
        [
            {'a': 1, 'b': '2'},
            {'a': 3, 'b': '4'},
            {'a': 5, 'b': '6'},
            {'a': 7, 'b': '8'},
            {'a': 9, 'b': '0'},
        ],
        lambda item: item['a'] == 3
    ) == {'a': 3, 'b': '4'}


# Generated at 2022-06-24 00:47:38.263853
# Unit test for function curry
def test_curry():
    def func(a, b, c):
        return a+b+c

    assert curry(func) == curry(func)

    func = curry(func)
    assert curry(func) == curry(func)

    assert curry(func)(1)(2)(3) == 6
    assert curry(func)(1, 2)(3) == 6
    assert curry(func)(1)(2, 3) == 6
    assert curry(func)(1, 2, 3) == 6
    assert curry(func)(1, 2, 3, 4) == 6
    assert curry(func)(1, 2)(3, 4) == 6
    assert curry(func)(1)(2, 3, 4) == 6



# Generated at 2022-06-24 00:47:41.339890
# Unit test for function increase
def test_increase():
    # Check if calling increase without arguments and with integer argument equals to identity function
    assert increase(1) == 2
    assert increase(0) == 1
    assert increase(-1) == 0
    assert increase(10) == 11
    assert increase(10.0) == 11.0
    assert increase(0.0) == 1.0
    assert increase(-1.0) == 0.0



# Generated at 2022-06-24 00:47:48.647141
# Unit test for function eq
def test_eq():
    # True because second and third argument are equal
    eq_test = compose(eq(1), eq(1))
    assert(eq_test(2) == True)

    # False because second and third argument are not equal
    eq_test = compose(eq(1), eq(2))
    assert(eq_test(2) == False)


# Generated at 2022-06-24 00:48:00.253410
# Unit test for function cond
def test_cond():
    # Define conditions (first argument of unit test is always argument of test function)
    def is_int(argument):
        return type(argument) == int

    def is_string(argument):
        return type(argument) == str

    def is_list(argument):
        return type(argument) == list

    # Define test function
    def test_function(arg):
        return arg

    # Define test data
    test_data = [
        (1, '1'),
        ('1', '1'),
        ([1, '2', 3], '1,2,3')
    ]
    # Define test actions

# Generated at 2022-06-24 00:48:01.278647
# Unit test for function compose
def test_compose():
    assert compose(2, increase, identity) == 3



# Generated at 2022-06-24 00:48:07.455968
# Unit test for function curry
def test_curry():
    @curry
    def test_curry_function(x, y):
        return x + y

    @curry
    def test_curry_function1(x, y, z):
        return x + y + z

    assert test_curry_function(2)(2) == 4
    assert test_curry_function1(1)(1)(1) == 3



# Generated at 2022-06-24 00:48:09.623793
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(5) == 6
    assert increase(-1) == 0



# Generated at 2022-06-24 00:48:11.716470
# Unit test for function compose
def test_compose():
    assert compose(
        1,
        increase,
        increase,
        increase,
        increase
    ) == 5



# Generated at 2022-06-24 00:48:13.896815
# Unit test for function pipe
def test_pipe():
    assert pipe("first arg", identity, lambda x: x + " second arg", lambda x: x + " third arg") == \
        "first arg second arg third arg"



# Generated at 2022-06-24 00:48:15.311327
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-24 00:48:20.970041
# Unit test for function memoize
def test_memoize():
    def square(x):
        return x * x

    def increment(x):
        return x + 1

    memoized_square = memoize(square)
    memoized_increment = memoize(increment)

    assert memoized_square(4) == 16
    assert memoized_square(4) == 16
    assert memoized_square(4) == 16
    assert memoized_square(4) == 16

    assert memoized_increment(4) == 5
    assert memoized_increment(4) == 5
    assert memoized_increment(4) == 5
    assert memoized_increment(4) == 5



# Generated at 2022-06-24 00:48:30.708841
# Unit test for function cond
def test_cond():
    def function1(value: int) -> int:
        return value + 1

    def function2(value: int) -> int:
        return value + 2

    assert cond([
        (lambda value: value % 2 == 0, function1),
        (lambda value: value % 2 == 1, function2)
    ])(3) == 5

    assert cond([
        (lambda value: value % 2 == 0, function1),
        (lambda value: value % 2 == 1, function2)
    ])(2) == 3

    assert cond([
        (lambda value: value % 2 == 0, function1),
        (lambda value: value % 2 == 1, function2)
    ])(-3) == 0



# Generated at 2022-06-24 00:48:31.557975
# Unit test for function identity
def test_identity():
    assert identity(10) == 10



# Generated at 2022-06-24 00:48:37.601762
# Unit test for function compose
def test_compose():
    assert compose(
        10,
        increase
    ) == 11

    assert compose(
        True,
        lambda x: not x,
        lambda x: x
    ) is False

    assert compose(
        10,
        increase,
        increase,
        increase
    ) == 13

    assert compose(
        10,
        increase,
        increase,
        increase,
        increase,
        increase
    ) == 15



# Generated at 2022-06-24 00:48:42.834045
# Unit test for function curried_map
def test_curried_map():
    def add_5(item):
        return item + 5

    assert curried_map(add_5, [1, 2, 3]) == [6, 7, 8]
    assert curried_map(add_5)([1, 2, 3]) == [6, 7, 8]
    assert curried_map(add_5)([8]) == [13]
    assert curried_map(add_5)([]) == []

    assert curried_map(lambda x: x + 3, [1, 2, 3]) == [4, 5, 6]
    assert curried_map(lambda x: x + 3)([1, 2, 3]) == [4, 5, 6]



# Generated at 2022-06-24 00:48:46.878999
# Unit test for function find
def test_find():
    assert find(
        [1, { 'a': 1 }],
        lambda item: item == 1
    ) == 1

    assert find(
        [1, { 'a': 1 }],
        lambda item: item == 3
    ) is None


# Generated at 2022-06-24 00:48:53.576574
# Unit test for function curry
def test_curry():
    @curry
    def add(x, y):
        return x + y

    assert add(2, 3) == 5
    add2 = add(2)
    add3 = add(3)

    assert add2(3) == 5
    assert add3(2) == 5



# Generated at 2022-06-24 00:48:58.623545
# Unit test for function cond
def test_cond():
    a = 1
    b = 2
    func = cond([
        (lambda x: x > 1, lambda x: x + 2),
        (lambda x: x == 1, lambda x: x + 1)
    ])
    assert func(a) == a + 1
    assert func(b) == b + 2



# Generated at 2022-06-24 00:49:02.779303
# Unit test for function pipe
def test_pipe():
    amount = pipe(
        10,
        (increase),
        (increase),
        (increase),
        (increase),
        (increase),
    )
    assert amount == 15

# Generated at 2022-06-24 00:49:08.546935
# Unit test for function compose
def test_compose():
    assert compose(0, increase, increase) == 2
    assert compose(0, increase, identity) == 1
    assert compose(0, identity, identity) == 0
    assert compose(0, identity, increase) == 1

# Generated at 2022-06-24 00:49:09.593454
# Unit test for function compose
def test_compose():
    assert compose(2, increase) == 3



# Generated at 2022-06-24 00:49:20.366582
# Unit test for function memoize
def test_memoize():
    def memoized_function(x):
        return x * x

    memoized_function = memoize(memoized_function)
    memoized_function_with_key = memoize(memoized_function, key=lambda x, y: x == y)

    assert memoized_function(2) == 4
    assert memoized_function_with_key(2) == 4
    assert memoized_function(3) == 9
    assert memoized_function_with_key(3) == 9
    assert memoized_function_with_key(2) == 4
    assert memoized_function(4) == 16
    assert memoized_function_with_key(4) == 16
    assert memoized_function(5) == 25
    assert memoized_function_with_key(5) == 25

# Generated at 2022-06-24 00:49:26.317767
# Unit test for function curried_filter
def test_curried_filter():
    # given
    collection = [1, 2,  3, 4, 5]

    # when
    result = curried_filter(eq(2), collection)

    # then
    assert result == [2], "Wrong result should be [2] but was {}".format(result)



# Generated at 2022-06-24 00:49:29.307056
# Unit test for function curry
def test_curry():
    def sum(x, y, z):
        return x + y + z

    assert curry(sum)(1)(2)(3) == 6
    assert curry(sum, 2)(1, 2)(3) == 6
    assert curry(sum, 2)(2)(2) == 6
    assert curry(sum)(1, 2, 3) == 6



# Generated at 2022-06-24 00:49:32.115127
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x * 2)([1, 2, 3]) == [2, 4, 6]



# Generated at 2022-06-24 00:49:37.414306
# Unit test for function find
def test_find():
    assert find([], lambda x: x > 2) == None
    assert find([1, 2, 3], lambda x: x > 2) == 3
    assert find(["a", "b", "c"], lambda x: x == "b") == "b"
    assert find([1, 2, 3], lambda x: x == "b") == None



# Generated at 2022-06-24 00:49:43.208230
# Unit test for function memoize
def test_memoize():
    def to_be_memoized(i):
        return i * i

    memoized = memoize(to_be_memoized)
    assert memoized(10) == 100
    assert memoized(10) == 100
    assert memoized(10) == 100
    assert memoized(10) == 100
    assert memoized(10) == 100



# Generated at 2022-06-24 00:49:50.216168
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x * x, [1, 2, 3, 4, 5]) == [1, 4, 9, 16, 25]
    assert curried_map(lambda x: x * x)([1, 2, 3, 4, 5]) == [1, 4, 9, 16, 25]
    assert curried_map(lambda x: x * x, [1])([2, 3])([4, 5]) == [1, 4, 9, 16, 25]



# Generated at 2022-06-24 00:49:53.142156
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq(1, 2, False) == False


# Generated at 2022-06-24 00:49:59.243384
# Unit test for function compose
def test_compose():
    assert compose(1, lambda x: x + 1, lambda x: x * 10) == 21
    assert compose(10, lambda x: x + 1, lambda x: x * 10) == 101
    assert compose(10, lambda x: x - 1, lambda x: x ** 2) == 9801
    assert compose(20, lambda x: x - 1, lambda x: x ** 2) == 99801



# Generated at 2022-06-24 00:50:02.956045
# Unit test for function find
def test_find():
    assert find(
        [1, 2, 3],
        lambda x: x == 2
    ) == 2

    assert find(
        [1, 2, 3],
        lambda x: x == 0
    ) is None


if __name__ == '__main__':
    test_find()

# Generated at 2022-06-24 00:50:05.627057
# Unit test for function pipe
def test_pipe():
    # test
    assert pipe(
        0,
        lambda val: val + 1,
        lambda val: val * 2
    ) == 2



# Generated at 2022-06-24 00:50:08.467786
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(0) == 0
    assert identity(12.54) == 12.54
    assert identity("") == ""
    assert identity("as") == "as"



# Generated at 2022-06-24 00:50:11.156507
# Unit test for function curried_map
def test_curried_map():
    result = curried_map(increase, [1, 2])
    assert result == [2, 3]


# Generated at 2022-06-24 00:50:15.381013
# Unit test for function curried_map
def test_curried_map():
    mapping_function = lambda x: x**2
    curried_mapper = curried_map(mapping_function)
    assert curried_mapper([1, 2, 3]) == [1, 4, 9]


# Generated at 2022-06-24 00:50:17.316559
# Unit test for function pipe
def test_pipe():
    assert pipe(1, increase, increase) == 3


# Generated at 2022-06-24 00:50:18.528627
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-24 00:50:24.951127
# Unit test for function memoize
def test_memoize():
    import time

    new_time = time.time

    def time_elapsed(fn: Callable) -> Callable:
        def timer(*args, **kwargs):
            start_time = new_time()
            result = fn(*args, **kwargs)
            elapsed_time = new_time() - start_time
            return elapsed_time, result
        return timer

    def factorial(number: int) -> int:
        if number == 0:
            return 1
        return number * factorial(number - 1)

    assert time_elapsed(factorial)(30)[0] > 0
    assert time_elapsed(memoize(factorial))(30)[0] < 0.01
    assert time_elapsed(memoize(factorial))(30)[0] < 0.01

# Generated at 2022-06-24 00:50:29.749168
# Unit test for function curry
def test_curry():
    assert curry(lambda *args: reduce(lambda a, b: a + b, args))(1)(2)(3)(4)() == 10



# Generated at 2022-06-24 00:50:34.607426
# Unit test for function cond
def test_cond():
    """
    Checks of execution of function cond.
    """
    assert cond([
        (eq(1), increase),
        (eq(2), identity),
    ])(1) == 2



# Generated at 2022-06-24 00:50:36.670768
# Unit test for function eq
def test_eq():
    """
    Unit test for function eq.
    """
    assert eq(1, 2) is False, "Must be False"
    assert eq(1, 1) is True, "Must be True"



# Generated at 2022-06-24 00:50:40.387732
# Unit test for function pipe
def test_pipe():
    result = pipe(0, increase, increase, increase, increase)
    assert result == 4, \
        'Expected pipe(0, increase, increase, increase, increase) equals 4'



# Generated at 2022-06-24 00:50:46.993237
# Unit test for function eq
def test_eq():
    assert True == eq(1, 1)
    assert False == eq(1, 2)
    assert True == eq(1, 1, key=identity)
    assert False == eq(1, 2, key=identity)
    assert True == eq(1)(1)
    assert False == eq(1)(2)
    assert True == eq(1, key=identity)(1)
    assert False == eq(1, key=identity)(2)



# Generated at 2022-06-24 00:50:51.400745
# Unit test for function find
def test_find():
    assert find([0, 1, 2, 3], eq(2)) == 2



# Generated at 2022-06-24 00:50:54.737369
# Unit test for function identity
def test_identity():

    assert identity(1) == 1
    assert identity("1") == "1"
    assert identity(None) is None
    assert identity(True) is True

    print("Test test_identity was successful")



# Generated at 2022-06-24 00:51:00.970676
# Unit test for function cond
def test_cond():
    def is_even(x):
        return x % 2 == 0

    def even_number(x):
        return x / 2

    def odd_number(x):
        return x + 1

    even_handler = cond([
        (is_even, even_number),
        (lambda x: True, odd_number),
    ])

    assert even_handler(1) == 2
    assert even_handler(2) == 1
    assert even_handler(3) == 4


# Generated at 2022-06-24 00:51:07.850570
# Unit test for function eq
def test_eq():
    collection = [1, 2, 3]

    assert 1 == find(collection, eq(1))
    assert 1 == find(collection, eq(1))
    assert 3 == find(collection, eq(3))
    assert None == find(collection, eq(4))

    assert 1 == find(collection, curried_filter(eq(1)))
    assert 1 == find(collection, curried_filter(eq(1)))
    assert 3 == find(collection, curried_filter(eq(3)))
    assert None == find(collection, curried_filter(eq(4)))



# Generated at 2022-06-24 00:51:09.533138
# Unit test for function compose
def test_compose():
    assert 3 == compose(1, increase, increase)



# Generated at 2022-06-24 00:51:12.741634
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4], lambda x: x == 5) is None

# Generated at 2022-06-24 00:51:15.821336
# Unit test for function compose
def test_compose():
    def add1(x):
        return x + 1

    def mul2(x):
        return x * 2

    assert compose(1, add1, add1, mul2) == 4



# Generated at 2022-06-24 00:51:18.585724
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1)(1) is True
    assert eq(1)(2) is False
    assert eq(1, 2) is False



# Generated at 2022-06-24 00:51:20.825650
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(2, 3) == 5
    add1 = curry(lambda x, y: x + y, 2)
    assert add1(10, 15) == 25



# Generated at 2022-06-24 00:51:25.006738
# Unit test for function curried_map
def test_curried_map():
    curried_increase = curry(increase)
    curried_eq = curry(eq)
    curried_map_curried_increase = curried_map(curried_increase)
    curried_filter_curried_eq = curried_filter(curried_eq)
    assert curried_map_curried_increase([1, 2, 3]) == [2, 3, 4]
    assert curried_filter_curried_eq([1, 2, 3], 2) == [2]



# Generated at 2022-06-24 00:51:26.031102
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:51:33.681748
# Unit test for function cond
def test_cond():
    def is_even(x):
        return x % 2 == 0

    def is_positive(x):
        return x > 0

    f = cond([
        (is_even, lambda x: x * 2),
        (is_positive, lambda x: x * 3),
        (identity, lambda x: -x),
    ])

    assert f(2) == 4
    assert f(3) == 9
    assert f(-2) == 4



# Generated at 2022-06-24 00:51:34.459592
# Unit test for function increase
def test_increase():
    assert increase(1) == 2


# Generated at 2022-06-24 00:51:36.202732
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity('Hello') == 'Hello'


# Generated at 2022-06-24 00:51:44.992098
# Unit test for function find
def test_find():
    test_data = dict(
        key=[-1, 1, 2],
        value=['not_found', 'found', 'found1']
    )
    key_function = lambda x: x >= 0
    result = find(test_data['key'], key=key_function)
    assert result == 1

    result = find(test_data['key'], key=eq(0))
    assert result is None

    result = find(test_data['value'], key=eq('not_found'))
    assert result == 'not_found'



# Generated at 2022-06-24 00:51:49.425413
# Unit test for function increase
def test_increase():
    assert increase(2) == 3
    assert increase(0) == 1
    assert increase(1) == 2
    assert increase(-1) == 0


# Generated at 2022-06-24 00:51:52.400811
# Unit test for function compose
def test_compose():
    assert compose(2, increase, increase) == 4
    assert compose(2, increase) == 3
    assert compose(2) == 2



# Generated at 2022-06-24 00:51:56.954843
# Unit test for function eq
def test_eq():
    print("Unit test for function eq:", end="")

    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(None, None)
    assert eq("", "")
    assert not eq("a", "")

    print("OK")


# Generated at 2022-06-24 00:52:05.839471
# Unit test for function find
def test_find():
    collection = [
        {"id": 1, "status": "pending"},
        {"id": 2, "status": "running"},
        {"id": 3, "status": "done"},
    ]
    find_by_id = find(collection)

    assert find_by_id(lambda item: item['id'] == 2) == collection[1]
    assert find_by_id(lambda item: item['status'] == 'done') == collection[2]
    assert find_by_id(lambda item: item['status'] == 'failed') is None



# Generated at 2022-06-24 00:52:13.459799
# Unit test for function find
def test_find():
    print('test_find()')
    list1 = [1, 2, 3, 4, 5]
    list2 = [[1, 2], [1, 3], [1, 4], [2, 3]]
    find_result1 = find(list1, eq(5))
    find_result2 = find(list1, eq(6))
    find_result3 = find(list2, eq([1, 2]))
    find_result4 = find(list2, eq([3, 4]))
    assert find_result1 == 5
    assert find_result2 is None
    assert find_result3 is not None
    assert find_result4 is None



# Generated at 2022-06-24 00:52:14.815398
# Unit test for function identity
def test_identity():
    assert identity(5) == 5



# Generated at 2022-06-24 00:52:18.860746
# Unit test for function curry
def test_curry():
    def add(x, y):
        return x + y

    add_one = curry(add, 2)(1)
    assert add_one(2) == 3
    assert curry(add_one)(4) == 5



# Generated at 2022-06-24 00:52:21.207122
# Unit test for function eq
def test_eq():
    assert eq(4, 4)(4)



# Generated at 2022-06-24 00:52:27.863484
# Unit test for function curry
def test_curry():
    def sum_3(a, b, c):
        return a + b + c
    curried_sum_3 = curry(sum_3)
    assert(curried_sum_3(1)(2, 3) == 6)
    assert(curried_sum_3(1, 2, 3) == 6)
    assert(curried_sum_3(1)(2)(3) == 6)
    assert(curried_sum_3(1, 2)(3) == 6)



# Generated at 2022-06-24 00:52:32.114698
# Unit test for function pipe
def test_pipe():
    """
    Test for function pipe.

    :returns: test result
    :rtype: Boolean
    """
    assert pipe(
        1,
        increase,
        increase,
        increase
    ) == 4, 'Identity function should return 4'

    assert pipe('Hello', len) == 5, 'Pipe function should return 5'
    return True



# Generated at 2022-06-24 00:52:34.744086
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3



# Generated at 2022-06-24 00:52:40.896372
# Unit test for function cond
def test_cond():
    def is_even(n):
        return n % 2 == 0

    def is_odd(n):
        return n % 2 == 1

    def cond_example(n):
        return cond([
            (is_even, lambda n: even(n)),
            (is_odd, lambda n: 'odd'),
        ])(n)

    def even(n):
        return 'even'

    def odd(n):
        return 'odd'

    assert cond_example(1) == 'odd'
    assert cond_example(2) == 'even'

# Generated at 2022-06-24 00:52:46.672390
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 1) == 1
    assert find([1, 2, 3, 4], lambda x: x == 6) is None



# Generated at 2022-06-24 00:52:51.151179
# Unit test for function curry
def test_curry():
    two_args_function = lambda x, y: x + y
    curried = curry(two_args_function)
    assert curried(1)(1) == 2
    assert curried(1, 2) == 3



# Generated at 2022-06-24 00:52:55.824046
# Unit test for function compose
def test_compose():
    assert compose(1, increase, increase, increase) == 4
    assert compose("lala", lambda arg: arg + "lala", lambda arg: arg + "lala") == "lalalalalala"



# Generated at 2022-06-24 00:53:05.854716
# Unit test for function cond
def test_cond():
    assert eq(1, cond(
        [(eq(3), increase), (eq(1), identity)]
    )(1))
    assert eq(2, cond(
        [(eq(3), increase), (eq(1), identity)]
    )(2))
    assert eq(1, cond(
        [(eq(3), identity), (eq(1), increase)]
    )(1))
    assert eq(2, cond(
        [(eq(3), identity), (eq(1), increase)]
    )(2))
    assert eq(2, cond(
        [(eq(3), identity), (eq(1), increase), (eq(2), increase)]
    )(1))
    assert eq(3, cond(
        [(eq(3), identity), (eq(1), increase), (eq(2), increase)]
    )(2))

# Generated at 2022-06-24 00:53:12.271575
# Unit test for function find
def test_find():
    find_test_list = [{'name': 'nested_item1', 'id': 1}, {'name': 'nested_item2', 'id': 2}]

    assert find({'id': '1'}, find_test_list) == {'name': 'nested_item1', 'id': 1}
    assert find({'id': '3'}, find_test_list) == None

    assert find({'id': '1'}, find_test_list, key=lambda item: item['id'] == 1) == {'name': 'nested_item1', 'id': 1}
    assert find({'id': '3'}, find_test_list, key=lambda item: item['id'] == 1) == None

# Generated at 2022-06-24 00:53:15.368024
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:53:25.224456
# Unit test for function memoize
def test_memoize():
    def power(number):
        return number ** 2

    def test_power(number):
        return number ** 3

    def identity(value):
        return value

    def test_identity(value):
        return 'value'

    memoized_power = memoize(power)
    memoized_power(2)
    memoized_test_power = memoize(test_power)
    memoized_test_power(2)
    memoized_identity = memoize(identity)
    memoized_identity(1)
    memoized_test_identity = memoize(test_identity)
    memoized_test_identity(1)

    assert memoized_power(2) == memoized_power(2)
    assert memoized_test_power(2) == memoized_test_power(2)

# Generated at 2022-06-24 00:53:33.347775
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 1, [])([1, 2, 3, 0]) == [2, 3]

    assert curried_filter(lambda x: x > 1)([1, 2, 3, 0])([1, 2, 3, 0]) == [2, 3]

    assert curried_filter(lambda x: x > 1)([1, 2, 3, 0])([1, 2, 3, 0]) == [2, 3]

    assert curried_filter(lambda x: x > 1)([1, 2, 3, 0]) == [2, 3]



# Generated at 2022-06-24 00:53:40.352365
# Unit test for function curry
def test_curry():
    add2 = curry(lambda x, y: x + y)
    assert add2(5)(5) == 10

    sub2 = curry(lambda x, y: x - y)
    assert sub2(5)(5) == 0

    mul2 = curry(lambda x, y: x * y)
    assert mul2(5)(5) == 25

    div2 = curry(lambda x, y: x / y)
    assert div2(10)(5) == 2

    pow2 = curry(lambda x, y: x ** y)
    assert pow2(10)(5) == 100000



# Generated at 2022-06-24 00:53:46.259206
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4, 5]) == [3, 4, 5]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4, 5]) == [3, 4, 5]


# Generated at 2022-06-24 00:53:47.737741
# Unit test for function pipe
def test_pipe():
    a=1
    b=pipe(
        a,
        increase,
        increase,
        increase
    )
    assert b == 4


# Generated at 2022-06-24 00:53:54.126321
# Unit test for function memoize
def test_memoize():
    def get_random_value():
        return random.randint(0, 99999)

    wrapped_get_random_value = memoize(get_random_value)
    first_call = wrapped_get_random_value(1)
    second_call = wrapped_get_random_value(1)
    assert first_call == second_call



# Generated at 2022-06-24 00:54:01.092277
# Unit test for function memoize
def test_memoize():
    import time
    import random

    # the slow version
    def s(x):
        time.sleep(random.uniform(.1, 1))
        return x

    # the memoized version
    ms = memoize(s)

    assert ms(1) == 1

    # since 1 was passed to the memoized version of s, it should only take a moment
    # to make the call
    assert ms(1) == 1



# Generated at 2022-06-24 00:54:09.307899
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x == 0, lambda x: 0),
        (lambda x: x == 1, lambda x: 1),
        (lambda x: x == 2, lambda x: 2),
    ])(0) == 0

    assert cond([
        (lambda x: x == 0, lambda x: 0),
        (lambda x: x == 1, lambda x: 1),
        (lambda x: x == 2, lambda x: 2),
    ])(1) == 1

    assert cond([
        (lambda x: x == 0, lambda x: 0),
        (lambda x: x == 1, lambda x: 1),
        (lambda x: x == 2, lambda x: 2),
    ])(2) == 2



# Generated at 2022-06-24 00:54:11.150894
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(0) == 1
    assert increase(-1) == 0


# Generated at 2022-06-24 00:54:12.631593
# Unit test for function identity
def test_identity():
    assert identity(2) == 2
    assert identity('test') == 'test'



# Generated at 2022-06-24 00:54:19.003959
# Unit test for function cond
def test_cond():
    def first_fun(value):
        return value < 0

    def second_fun(value):
        return value > 0

    @cond([
        (first_fun, identity),
        (second_fun, increase)
    ])
    def test_fun():
        pass
    assert test_fun(-1) == -1
    assert test_fun(1) == 2