

# Generated at 2022-06-24 00:44:13.997580
# Unit test for function identity
def test_identity():
    assert identity(2) == 2
    assert identity("test") == "test"

# Generated at 2022-06-24 00:44:17.681404
# Unit test for function increase
def test_increase():
    assert increase(2) == 3


# Generated at 2022-06-24 00:44:18.598257
# Unit test for function increase
def test_increase():
    assert increase(3) == 4



# Generated at 2022-06-24 00:44:21.999412
# Unit test for function pipe
def test_pipe():
    assert pipe({}, lambda x: x, lambda x: x.update({'name': 'Ivan'})) == {'name': 'Ivan'}
    assert pipe(10, lambda x: x + 5, lambda x: x ** 2) == 225



# Generated at 2022-06-24 00:44:24.436707
# Unit test for function compose
def test_compose():
    composed_functions = compose(
        1,
        increase,
        increase,
        increase,
        increase
    )

    assert composed_functions == 5



# Generated at 2022-06-24 00:44:26.922010
# Unit test for function eq
def test_eq():
    """
    Test eq function
    """
    assert eq(1, 1)
    assert eq('A', 'A')
    assert not eq(1, 2)
    assert not eq('A', 'B')


# Generated at 2022-06-24 00:44:32.263356
# Unit test for function memoize
def test_memoize():
    def factorial(n):
        if n == 0:
            return 1
        return n * factorial(n - 1)

    mf = memoize(factorial, curry(eq))

    assert mf(0) == 1
    assert mf(6) == 720
    assert mf(0) == 1
    assert mf(6) == 720

    class Argument:
        def __init__(self, c):
            self.group = c

        def __eq__(self, other):
            return self.group == other.group

    mfa = memoize(factorial, curry(eq))

    assert mfa(Argument(0)) == 1
    assert mfa(Argument(6)) == 720
    assert mfa(Argument(0)) == 1
    assert mfa(Argument(6)) == 720


#

# Generated at 2022-06-24 00:44:32.882027
# Unit test for function increase
def test_increase():
    assert increase(1) == 2


# Generated at 2022-06-24 00:44:36.173520
# Unit test for function identity
def test_identity():
    assert identity(True) is True
    assert identity(None) is None
    assert identity(10) == 10
    assert identity(0) == 0
    assert identity(-10) == -10
    assert identity('Test') == 'Test'



# Generated at 2022-06-24 00:44:38.069497
# Unit test for function compose
def test_compose():
    assert compose(1, increase, increase) == 3


# Generated at 2022-06-24 00:44:39.391267
# Unit test for function pipe
def test_pipe():
    assert pipe(0, increase, increase) == 2



# Generated at 2022-06-24 00:44:45.550487
# Unit test for function cond
def test_cond():
    """
    Test function cond.

    :returns: True if test case passed otherwise False
    :rtype: Boolean
    """
    f = cond([
        (lambda x: x > 0, lambda x: x + 1),
        (lambda x: x < 0, lambda x: x - 2),
        (lambda x: x == 0, lambda x: x)
    ])
    return f(1) == 2 and \
           f(-1) == -3 and \
           f(0) == 0

# Generated at 2022-06-24 00:44:51.361431
# Unit test for function curried_filter
def test_curried_filter():
    def more_than_3(x):
        return x > 3
    assert curried_filter(more_than_3, [1, 4, 5]) == [4, 5]



# Generated at 2022-06-24 00:44:54.520935
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:44:58.124351
# Unit test for function pipe
def test_pipe():
    assert pipe(5, increase, increase) == 7
    assert pipe(5, lambda x: x + 1) == 6



# Generated at 2022-06-24 00:44:58.969932
# Unit test for function identity
def test_identity():
    result = identity(5)
    expected_result = 5

    assert result == expected_result



# Generated at 2022-06-24 00:45:01.236697
# Unit test for function find
def test_find():
    assert find([1, 2, 3], identity) is 1
    assert find([1, 2, 3], increase) is None
    assert find([], increase) is None



# Generated at 2022-06-24 00:45:05.785468
# Unit test for function memoize
def test_memoize():
    func_memoize = memoize(lambda x: x**2)
    assert func_memoize(2) == 4
    assert func_memoize(2) == 4



# Generated at 2022-06-24 00:45:06.673561
# Unit test for function increase
def test_increase():
    assert(increase(1) == 2)


# Generated at 2022-06-24 00:45:08.585951
# Unit test for function identity
def test_identity():
    assert identity(0) == 0
    assert identity(42) == 42
    assert identity(True) is True
    assert identity([1, 2, 3]) == [1, 2, 3]
    assert identity("test") == "test"



# Generated at 2022-06-24 00:45:11.954120
# Unit test for function pipe
def test_pipe():
    assert pipe(1, increase, identity) == 2
    assert pipe(3, increase, increase) == 5
    assert pipe(1, identity) == 1
    assert pipe(1, ) == 1



# Generated at 2022-06-24 00:45:12.819814
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:45:14.446451
# Unit test for function identity
def test_identity():
    assert identity(0) == 0
    assert identity(1) == 1
    assert identity(None) is None

# Generated at 2022-06-24 00:45:17.017731
# Unit test for function identity
def test_identity():
    assert identity(0) == 0
    assert identity(2) == 2
    assert identity('string') == 'string'
    assert identity(None) is None
    assert identity(True) is True
    assert identity((1,2)) == (1,2)

test_identity()

# Generated at 2022-06-24 00:45:20.875808
# Unit test for function compose
def test_compose():
    # Function to add two number
    def add(x, y):
        return x + y
    composed_function = compose(3, lambda x: add(x, 1), lambda x: add(x, 2))
    # Expected result: 6
    result = composed_function()
    assert result == 6


test_compose()



# Generated at 2022-06-24 00:45:23.968208
# Unit test for function compose
def test_compose():
    assert compose(1, increase, increase, increase) == 4
    assert compose('9', str, increase, increase) == '11'



# Generated at 2022-06-24 00:45:24.875223
# Unit test for function identity
def test_identity():
    assert identity(5) == 5



# Generated at 2022-06-24 00:45:28.346544
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x*2)([1, 2, 3, 4]) == [2, 4, 6, 8]
    assert curried_map(lambda x: x*2, [1, 2, 3, 4]) == [2, 4, 6, 8]


# Generated at 2022-06-24 00:45:31.035008
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 3, 4, 5]
    result = curried_filter(lambda x: x % 2 == 0, collection)
    assert result == [2, 4]



# Generated at 2022-06-24 00:45:38.238375
# Unit test for function compose
def test_compose():
    assert compose(1, lambda x: x + 1, lambda x: x * 2) == 4
    assert compose(1, lambda x: x * 2, lambda x: x + 1) == 3
    assert compose(1, lambda x: x * 2, lambda x: x + 1, lambda x: x * 3) == 9
    assert compose(1, lambda x: x * 2, lambda x: x + 1, lambda x: x * 3, lambda x: x + 1) == 10



# Generated at 2022-06-24 00:45:42.236053
# Unit test for function pipe
def test_pipe():
    assert pipe(1, increase, increase, increase) == 4
    assert pipe("Hello World", lambda x: x.rstrip("d"), str.upper) == "Hello Worl"


# Generated at 2022-06-24 00:45:43.274281
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:45:50.634234
# Unit test for function curry
def test_curry():
    def fn(a, b, c, d, e, f):
        return a, b, c, d, e, f

    fn = curry(fn)

    assert fn(1, 2, 3, 4, 5, 6) == (1, 2, 3, 4, 5, 6)
    assert fn(1, 2, 3)(4, 5, 6) == (1, 2, 3, 4, 5, 6)
    assert fn(1)(2)(3)(4)(5)(6) == (1, 2, 3, 4, 5, 6)



# Generated at 2022-06-24 00:45:55.720728
# Unit test for function find
def test_find():
    assert find(
        [{'a': 1}, {'b': 2}],
        lambda item: item['a'] == 1
    ) == {'a': 1}

    assert find(
        [{'a': 1}, {'b': 2}],
        lambda item: 'not_existed_key' in item
    ) is None


# Generated at 2022-06-24 00:46:05.308030
# Unit test for function cond
def test_cond():  # pragma: no cover
    def f():
        return """
            def cond(condition_list):
                def result(*args):
                    for (condition_function, execute_function) in condition_list:
                        if condition_function(*args):
                            return execute_function(*args)

                return result
        """

    def test_cond1(value):
        return cond([
            (lambda x: x > 0, lambda x: 'more than zero'),
            (lambda x: x == 0, lambda x: 'zero'),
            (lambda x: x < 0, lambda x: 'less than zero'),
        ]
        )(value)


# Generated at 2022-06-24 00:46:07.095882
# Unit test for function find
def test_find():
    true = eq(True)
    false = eq(False)

    assert find([1, 4, 6, 8, 9], true) == 1
    assert find([1, 4, 6, 8, 9], false) is None



# Generated at 2022-06-24 00:46:12.332877
# Unit test for function cond
def test_cond():
    md = curry(lambda a, b: a % b)
    is_even = md(2, eq(0))

# Generated at 2022-06-24 00:46:17.702543
# Unit test for function pipe
def test_pipe():
    """
    >>> test_pipe()
    [3, 5, 7]
    """
    print(
        pipe(
            [1, 2, 3],
            lambda l: [x + 1 for x in l],
            lambda l: [x + 1 for x in l],
            lambda l: [x + 1 for x in l],
        ),
    )



# Generated at 2022-06-24 00:46:18.764960
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-24 00:46:21.006327
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-24 00:46:27.669501
# Unit test for function compose
def test_compose():
    # GIVEN
    fn1 = lambda x: x + 1
    fn2 = lambda x: x * 2
    fn3 = lambda x: x + 5
    fn4 = lambda x: x * 3

    # WHEN
    result = compose(
        2,
        fn1,
        fn2,
        fn3,
        fn4
    )

    # THEN
    assert result == (((2 + 1) * 2 + 5) * 3)



# Generated at 2022-06-24 00:46:32.629792
# Unit test for function memoize
def test_memoize():
    from random import randint


    @memoize
    def exponential(base, exp):
        return base ** exp


    assert exponential(2, 8) == 256
    assert exponential(3, 5) == 243

    for _ in range(10):
        base = randint(1, 10)
        exp = randint(1, 10)
        assert exponential(base, exp) == base ** exp



# Generated at 2022-06-24 00:46:34.520896
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda item: item > 2, [1, 2, 3]) == [3]



# Generated at 2022-06-24 00:46:35.949182
# Unit test for function compose
def test_compose():
    assert compose(5, increase, increase) == 7



# Generated at 2022-06-24 00:46:42.295708
# Unit test for function curried_filter
def test_curried_filter():
    data = [0, 1, 2, 3, 4, 5]
    even_number = lambda x: x % 2 == 0

    assert curried_filter(even_number, data) == [0, 2, 4]
    assert curried_filter(even_number)(data) == [0, 2, 4]
    assert curried_filter(even_number, data) == [0, 2, 4]



# Generated at 2022-06-24 00:46:45.023694
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(1))([1, 2, 3]) == [1]
    assert curried_filter(eq(4))([1, 2, 3]) == []



# Generated at 2022-06-24 00:46:46.214341
# Unit test for function increase
def test_increase():
    assert increase(1) == 2

# Generated at 2022-06-24 00:46:55.109159
# Unit test for function curried_map
def test_curried_map():
    double = lambda x: 2 * x
    double_list = [1, 2, 3, 4]
    double_list1 = curried_map(double)(double_list)
    assert isinstance(double_list1, list)
    assert len(double_list1) == len(double_list)
    assert double_list1[0] == double_list[0]*2
    assert double_list1[1] == double_list[1]*2
    assert double_list1[2] == double_list[2]*2
    assert double_list1[3] == double_list[3]*2


# Generated at 2022-06-24 00:46:58.568764
# Unit test for function curry
def test_curry():
    @curry
    def add(a, b):
        return a + b

    assert add(1)(2) == 3

    add_one = add(1)
    assert add_one(2) == 3



# Generated at 2022-06-24 00:47:00.562083
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x == 2, [1, 2, 3, 4]) == [2]



# Generated at 2022-06-24 00:47:03.562045
# Unit test for function eq
def test_eq():
    assert eq(2, 2) is True
    assert eq(2)(2) is True
    assert eq(2, 3) is False
    assert eq(2)(3) is False



# Generated at 2022-06-24 00:47:08.877101
# Unit test for function find
def test_find():
    assert (find([1, 2, 3], lambda x: x == 2) == 2)
    assert (find([1, 2, 3], lambda x: x == 0) is None)



# Generated at 2022-06-24 00:47:15.344388
# Unit test for function curried_map
def test_curried_map():
    collection = [5,6,3]
    collection1 = list(map(lambda x: x * 2, collection))
    collection2 = curried_map(lambda x: x * 2, collection)
    assert collection1 == collection2
    collection2 = curried_map(lambda x: x * 2)(collection)
    assert collection1 == collection2
    collection2 = curried_map(lambda x: x * 2, collection)
    assert collection1 == collection2



# Generated at 2022-06-24 00:47:19.156897
# Unit test for function cond
def test_cond():
    t_true = True
    f_true = False
    true_fn = lambda: t_true
    false_fn = lambda: f_true
    cond_fn = cond([
        (eq(1), true_fn),
        (eq(1), false_fn),
    ])
    assert cond_fn(1) is t_true



# Generated at 2022-06-24 00:47:21.413434
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(1))([1, 2, 3]) == [1]
    assert curried_filter(eq(4))([1, 2, 3]) == []


# Generated at 2022-06-24 00:47:29.442901
# Unit test for function compose
def test_compose():
    assert compose(3, lambda x: x + 2, lambda y: y / 2) == 4
    assert compose('hello', lambda x: x + ' world', lambda y: y[:5]) == 'hello'
    assert compose([1, 2, 3], lambda x: x[:2], lambda y: y * 2) == [1, 2, 1, 2]
    assert compose({'hello': 'world'}, lambda x: x['hello'], lambda y: y.upper()) == 'WORLD'
    assert compose(3, identity, increase) == 4



# Generated at 2022-06-24 00:47:33.050644
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4])(None) == [2, 4]



# Generated at 2022-06-24 00:47:39.816645
# Unit test for function curry
def test_curry():
    assert curry(identity)(1) == 1
    assert curry(lambda x, y: x + y)(1, 1) == 2
    assert curry(lambda x, y: x + y)(1)(1) == 2
    assert curry(lambda x, y, z: x + y + z)(1, 1, 1) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(1)(1) == 3
    assert curry(lambda x, y, z: x + y + z)(1, 1)(1) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(1, 1) == 3



# Generated at 2022-06-24 00:47:40.659001
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-24 00:47:45.694629
# Unit test for function cond
def test_cond():
    def odd(x):
        return x % 2 == 1
    def even(x):
        return x % 2 == 0
    def pos(x):
        return x > 0

    test_f = cond(
        [(odd, identity), (even, increase), (pos, increase)]
    )  # identity 1 -> 1, increase 2 -> 3, increase 3 -> 4

    assert test_f(1) == 1
    assert test_f(2) == 3
    assert test_f(4) is None

# Generated at 2022-06-24 00:47:49.480769
# Unit test for function pipe
def test_pipe():
    assert pipe(2, lambda x: x + 1, lambda x: x * x) == 9
    assert pipe(2, lambda x: x + 1, lambda x: x + 1, lambda x: x * x) == 16
    assert pipe(2, lambda x: x + 1, lambda x: x + 1,
                lambda x: x + 1, lambda x: x * x) == 25



# Generated at 2022-06-24 00:47:51.686053
# Unit test for function cond
def test_cond():
    assert 1 == cond([
        (eq(1), increase),
        (eq(2), identity)
    ])(1)

    assert None is cond([
        (eq(1), increase),
        (eq(2), identity)
    ])(2)


# Generated at 2022-06-24 00:47:54.045820
# Unit test for function compose
def test_compose():
    assert eq(increase(2))(compose(
        1,
        increase
    ))



# Generated at 2022-06-24 00:48:00.612462
# Unit test for function memoize
def test_memoize():
    def add(x, y):
        return x + y

    memoized_add = memoize(add)

    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3

    memoized_add2 = memoize(add, lambda x, y: x == y)
    memoized_add2(1, 2)
    memoized_add2(2, 3)
    memoized_add2(3, 4)
    memoized_add2(4, 5)
    assert memoized_add2(1, 2) == 3



# Generated at 2022-06-24 00:48:04.815434
# Unit test for function curried_filter
def test_curried_filter():
    assert False == curried_filter(lambda x: x == 1)([1, 2, 3])



# Generated at 2022-06-24 00:48:15.055243
# Unit test for function memoize
def test_memoize():
    # Test for time of first and next calls 
    # since this time should be different
    # if memoize work truly
    import time
    from random import random
    # create function witch takes long time to complete
    @memoize
    def long_time_function(number):
        time.sleep(random())
        return number
    # run first function call
    first_time = time.time()
    long_time_function(5)
    # run second function call
    second_time = time.time()
    long_time_function(5)
    # assert time of next call
    # should be less than time of first call
    assert second_time - first_time < first_time - (second_time - first_time)

    # Test for memoize work correctly
    # since if memoize work correctly
    # result should be

# Generated at 2022-06-24 00:48:20.320194
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(2)(2) == 4
    assert curry(lambda x, y, z: x + y + z)(2)(2)(3) == 7
    assert curry(lambda x, y, z, t: x + y + z + t)(2)(2)(2)(2) == 8
    assert curry(lambda x, y, z, t, v, n: n * n + t * t + v * v + z * z + x * x + y * y)()(2, 5, 1, 2, 3) == 43



# Generated at 2022-06-24 00:48:26.498752
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(
        lambda x: x % 2 == 0,
        list(range(10))
    ) == [0, 2, 4, 6, 8]

    even_filter = curried_filter(lambda x: x % 2 == 0)
    assert even_filter
    assert even_filter(list(range(10))) == [0, 2, 4, 6, 8]



# Generated at 2022-06-24 00:48:30.361712
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x*x)([1, 2, 3]) == [1, 4, 9]
    assert curried_map(lambda x: x*x, [1, 2, 3]) == [1, 4, 9]

#Unit test for function curried_filter

# Generated at 2022-06-24 00:48:31.816872
# Unit test for function pipe
def test_pipe():
    assert pipe(
        3,
        increase,
        increase,
        increase
    ) == 6



# Generated at 2022-06-24 00:48:38.696358
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2, [1, 2, 3, 4, 5]) == [1, 3, 5]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5]) == [2, 4]
    assert curried_filter(lambda x: x <= 2, [1, 2, 3, 4, 5]) == [1, 2]
    assert curried_filter(lambda x: x < 2, [1, 2, 3, 4, 5]) == [1]


# Generated at 2022-06-24 00:48:47.280310
# Unit test for function eq
def test_eq():
    assert(eq(1, 1) == True)
    assert(eq(1, 2) == False)
    assert(eq(1, 1.0) == False)
    assert(eq(1, -1) == False)
    assert(eq('abc', 'abc') == True)
    assert(eq('abc', 'abd') == False)
    assert(eq('abc', 'aBc') == False)
    assert(eq(['a','b','c'],['a','b','c']) == True)
    assert(eq(['a','c','c'],['a','b','c']) == False)
    assert(eq(['a','b','c'],['a','b','c','d']) == False)
    assert(eq(['a','b','c'],['a','b']) == False)

# Generated at 2022-06-24 00:48:55.726972
# Unit test for function eq
def test_eq():
    assert eq(1)(1) == True, "eq(1)(1) should be True"
    assert eq(1)(2) == False, "eq(1)(2) should be False"
    assert eq(1)(3) == False, "eq(1)(3) should be False"
    assert eq(2)(2) == True, "eq(2)(2) should be True"
    assert eq(2)(3) == False, "eq(2)(3) should be False"
    assert eq(3)(3) == True, "eq(3)(3) should be True"


# Generated at 2022-06-24 00:49:02.031996
# Unit test for function curried_map
def test_curried_map():
    map_adder = curried_map(lambda a: a + 1)
    assert map_adder([4, 5]) == [5, 6]

    assert curried_map(lambda a: a + 1, [4, 5]) == curried_map(lambda a: a + 1)([4, 5])

# Generated at 2022-06-24 00:49:10.593388
# Unit test for function pipe
def test_pipe():
    assert pipe(
        2,
        lambda n: n + 1,
        lambda n: n * 2,
    ) == 6

    assert pipe(
        2,
        lambda n: n + 1,
        lambda n: n * 2,
        lambda n: n + 5,
    ) == 13

    assert pipe(
        None,
        lambda n: n + 1,
        lambda n: n * 2,
        lambda n: n + 5,
    ) == None



# Generated at 2022-06-24 00:49:13.260567
# Unit test for function memoize
def test_memoize():
    assert memoize(lambda x: x * x)(3) == 9
    assert memoize(lambda x: x * x)(2) == 4
    assert memoize(lambda x: x * x)(2) == 4



# Generated at 2022-06-24 00:49:16.561322
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:49:19.850532
# Unit test for function curried_map
def test_curried_map():
    doubled = lambda x: x * 2
    assert curried_map(doubled, [1, 2]) == [2, 4]
    assert curried_map(doubled, [3, 4, 5]) == [6, 8, 10]
    assert curried_map(doubled, []) == []



# Generated at 2022-06-24 00:49:21.385385
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2, \
        "Find is not working properly"



# Generated at 2022-06-24 00:49:26.029865
# Unit test for function compose
def test_compose():
    # args: value, *functions
    assert compose(1, [increase, increase]) == 3, "first case"



# Generated at 2022-06-24 00:49:26.659572
# Unit test for function eq
def test_eq():
    assert eq(1, 1)



# Generated at 2022-06-24 00:49:28.460812
# Unit test for function curried_map
def test_curried_map():
    map_increase = curried_map(increase)

    assert map_increase([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-24 00:49:34.367062
# Unit test for function curry
def test_curry():
    @curry
    def sum(a: int, b: int) -> int:
        return a + b

    assert sum(2, 3) == 5
    assert sum(3)(3) == 6

    assert compose(
        sum(1, 1),
        sum(1, 1),
    ) == 4



# Generated at 2022-06-24 00:49:35.509720
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:49:36.737019
# Unit test for function identity
def test_identity():
    assert identity(None) is None
    assert identity(1) == 1
    assert identity("text") == "text"



# Generated at 2022-06-24 00:49:41.580902
# Unit test for function memoize
def test_memoize():
    @memoize
    def add(a):
        return a + 1
    assert add(2) == 3, 'Add function is not working'
    assert add(2) == 3, 'Add function is not working'

# Generated at 2022-06-24 00:49:47.519631
# Unit test for function compose
def test_compose():
    # compose(2, lambda x: x, lambda x: x + 1, lambda x: x ** 2) == 9
    assert compose(2, lambda x: x ** 2, lambda x: x + 1, lambda x: x) == 9



# Generated at 2022-06-24 00:49:50.247959
# Unit test for function find
def test_find():
    assert (find([1, 2, 3], eq(2))) == 2, "Find function should return 2"
    assert (find([1, 2, 3], eq(5))) == None, "Find function should return None"



# Generated at 2022-06-24 00:49:53.151844
# Unit test for function increase
def test_increase():
    assert(increase(10) == 11)
    assert(increase(-1) == 0)
    assert(increase(99) == 100)


# Generated at 2022-06-24 00:50:00.092233
# Unit test for function curried_map
def test_curried_map():
    assert(curried_map(lambda x: x)([0, 1, 2]) == [0, 1, 2])
    assert(curried_map(identity)([0, 1, 2]) == [0, 1, 2])
    assert(curried_map(increase)([0, 1, 2]) == [1, 2, 3])
    assert(curried_map(lambda x: [x])([0, 1, 2]) == [[0], [1], [2]])
    assert(curried_map(lambda x: [x, x])([0, 1, 2]) == [[0, 0], [1, 1], [2, 2]])



# Generated at 2022-06-24 00:50:00.777009
# Unit test for function increase
def test_increase():
    assert increase(2) == 3



# Generated at 2022-06-24 00:50:07.718830
# Unit test for function memoize
def test_memoize():
    data1 = {
        'start': [1, 2, 3, 1, 3, 2, 1, 2, 3, 1, 3, 2, 1, 2, 3, 1, 3, 2, 1, 2, 3, 1, 3, 2, 1, 2, 3, 1, 3, 2, 1, 2, 3, 1,
                  3, 2],
        'end': [0, 1, 2, 0, 1, 2, 0, 1, 2, 0, 1, 2, 0, 1, 2, 0, 1, 2, 0, 1, 2, 0, 1, 2, 0, 1, 2, 0, 1, 2, 0, 1, 2, 0, 1, 2]
    }

# Generated at 2022-06-24 00:50:08.596852
# Unit test for function increase
def test_increase():
    assert increase(2) == 3


# Generated at 2022-06-24 00:50:17.763379
# Unit test for function curry
def test_curry():
    @curry
    def add_3(a, b, c):
        return a + b + c

    @curry
    def add_2(a, b):
        return a + b

    assert add_3(1, 2, 3) == 6
    assert add_3(1, 2)(3) == 6
    assert add_3(1)(2, 3) == 6
    assert add_3(1)(2)(3) == 6

    assert add_2(1, 2) == 3
    assert add_2(1)(2) == 3



# Generated at 2022-06-24 00:50:23.726503
# Unit test for function memoize
def test_memoize():
    def fn(argument):
        return argument

    assert fn(1) == 1
    assert fn(1) == 1

    memoized_fn = memoize(fn)
    assert memoized_fn(1) == 1
    assert memoized_fn(1) == 1

    memoized_fn = memoize(fn, key=lambda a, b: a == 'das' and b == 'das')
    assert memoized_fn('das') == 'das'
    assert memoized_fn('das') == 'das'



# Generated at 2022-06-24 00:50:24.796536
# Unit test for function pipe
def test_pipe():
    assert pipe(1, increase, increase, identity) == 3


# Generated at 2022-06-24 00:50:33.662670
# Unit test for function curry
def test_curry():
    import pytest

    assert curry(identity)(0) == 0
    assert curry(identity)(0)(0) == 0
    assert curry(identity, 1)(0) == 0
    assert curry(identity, 2)(0, 0) == 0

    assert curry(curry(identity, 2))(0) == 0
    assert curry(curry(identity, 2))(0)(0) == 0
    assert curry(curry(identity, 2))(0, 0) == 0
    assert curry(curry(identity, 2))(0, 0) == 0



# Generated at 2022-06-24 00:50:41.314774
# Unit test for function curry
def test_curry():
    # Example: 1
    assert curry(lambda x, y: x + y)(1)(2) == 3
    # Example: 2
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6, \
        'Curried function not work properly with three arguments'
    # Example: 3
    assert curry(lambda x, y, z, a: x + y + z + a)(1)(2)(3)(4) == 10, \
        'Curried function not work properly with four arguments'
    # Example: 4
    assert curry(lambda x, y, z, a, b: x + y + z + a + b)(1)(2)(3)(4)(5) == 15, \
        'Curried function not work properly with five arguments'
    # Example: 5

# Generated at 2022-06-24 00:50:45.113087
# Unit test for function memoize
def test_memoize():
    def heavy_function():
        return list(range(10 ** 7))

    memoized_fn = memoize(heavy_function)

    first_result = memoized_fn()
    second_result = memoized_fn()

    assert first_result == second_result

# Generated at 2022-06-24 00:50:47.714522
# Unit test for function curried_map
def test_curried_map():
    mapped_sequence = curried_map(lambda x: x + 1)([1, 2, 3])
    assert mapped_sequence == [2, 3, 4]


# Generated at 2022-06-24 00:50:51.954878
# Unit test for function pipe
def test_pipe():
    assert pipe(
        [],
        curried_map(increase),
        curried_filter(lambda x: x % 2 == 1)
    ) == [1]

# Generated at 2022-06-24 00:51:02.367137
# Unit test for function compose
def test_compose():
    f = lambda x: x + 1
    g = lambda x: x * x
    h = lambda x: x / 2
    assert compose(1, h, g, f) == 2, "Function(-1+1)^2/2 = 2"
    assert compose(2, h, g, f) == 4, "Function(-2+1)^2/2 = 4"
    assert compose(3, f, g, h) == 4, "Function(3+1)^2/2 = 4"
    assert compose(4, g, f, h) == 6, "Function(4^2/2+1) = 6"
    assert compose(5, h, g, f) == 8, "Function(5-1)^2/2 = 8"

# Generated at 2022-06-24 00:51:03.560508
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b: a * b)(5)(5) == 25



# Generated at 2022-06-24 00:51:06.177183
# Unit test for function curry
def test_curry():
    assert curry(increase, 1)(2) == 3
    assert curry(increase, 1)(2, 3) == 3



# Generated at 2022-06-24 00:51:07.957798
# Unit test for function curried_map
def test_curried_map():
    map_test = curried_map(increase)([1, 2, 3])
    assert map_test == [2, 3, 4]



# Generated at 2022-06-24 00:51:14.372471
# Unit test for function compose
def test_compose():
    assert compose(2, lambda x: x + 2, lambda y: y * y) == 16
    assert compose("Python", lambda x: x[0].upper() + x[1:], lambda y: y * 3) == "PythonPythonPython"
    assert compose("2 2 3", lambda x: x.split(" "), lambda y: map(int, y)) == [2, 2, 3]

# Generated at 2022-06-24 00:51:16.345447
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(0) == 1
    assert increase(-1) == 0



# Generated at 2022-06-24 00:51:21.645135
# Unit test for function pipe
def test_pipe():
    result = pipe([1, 2, 3, 4, 5],
        lambda collection: curried_filter(eq(2), collection),
        lambda x: x[0],
        lambda x: x + 1
    )
    assert result == 3
    result = pipe([1, 2, 3, 4, 5],
        lambda collection: curried_filter(eq(5), collection),
        lambda x: x[0],
        lambda x: x + 1
    )
    assert result == 6



# Generated at 2022-06-24 00:51:24.433297
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)


# Generated at 2022-06-24 00:51:25.207634
# Unit test for function identity
def test_identity():
    assert identity(10) == 10



# Generated at 2022-06-24 00:51:28.223429
# Unit test for function pipe
def test_pipe():
    assert pipe(0, [increase, increase, increase]) == 3
    assert pipe(0, [increase]) == 1


# Generated at 2022-06-24 00:51:33.632346
# Unit test for function curry
def test_curry():
    curried = curry(lambda x, y, z: x * y * z)
    assert curried(1)(2, 3) == 6
    assert curried(1, 2, 3) == 6
    assert curried(1, 2)(3) == 6
    assert curried(1)(2)(3) == 6



# Generated at 2022-06-24 00:51:37.074105
# Unit test for function identity
def test_identity():
    """
    Test for correct work of function "identity"
    """
    assert identity(1) == 1
    assert identity('a') == 'a'
    assert identity((1, 2)) == (1, 2)



# Generated at 2022-06-24 00:51:40.407887
# Unit test for function curry
def test_curry():
    def test(x, y):
        return x + y
    z = curry(test)
    assert z(1, 2) == 3
    x = curry(test, args_count=1)
    assert x(1)(2) == 3



# Generated at 2022-06-24 00:51:44.258762
# Unit test for function memoize
def test_memoize():
    e = memoize(lambda x: x + 1)
    l = [1, 2, 3, 4, 5]
    print(l)
    map(e, l)
    map(e, l)
    print(l)
    l = [1, 2, 4, 5]
    print(l)
    map(e, l)
    map(e, l)
    print(l)



# Generated at 2022-06-24 00:51:52.034867
# Unit test for function memoize
def test_memoize():
    import time
    import random

    def time_func(x):
        time.sleep(random.random())
        return x ** 2
    sleep_and_square = memoize(time_func)

    start_time = time.time()
    for number in range(3):
        print(sleep_and_square(number))
    end_time = time.time()
    assert end_time - start_time < 6


if __name__ == "__main__":
    test_memoize()

# Generated at 2022-06-24 00:51:56.618175
# Unit test for function compose
def test_compose():
    assert compose(
        'Hello ',
        curry(lambda x: x.lower()),
        curry(lambda x: x.replace('H', 'Q')),
        curry(lambda x: x + 'World')
    ) == 'qello world'



# Generated at 2022-06-24 00:51:58.429531
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-24 00:52:00.752220
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(2) == 3
    assert increase(3) == 4

test_increase()



# Generated at 2022-06-24 00:52:04.370190
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1, '1')



# Generated at 2022-06-24 00:52:05.099785
# Unit test for function increase
def test_increase():
    assert increase(10) == 11



# Generated at 2022-06-24 00:52:10.614063
# Unit test for function eq
def test_eq():
    assert eq(5, 5) == True
    assert eq("hello", "hello") == True
    assert eq("hello", "world") == False
    assert eq([1, 2, 3], [1, 2, 3]) == False


# Generated at 2022-06-24 00:52:11.939127
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: 1 == x)([1, 2, 3]) == [1]



# Generated at 2022-06-24 00:52:12.802953
# Unit test for function increase
def test_increase():
    assert increase(1) == 2

# Generated at 2022-06-24 00:52:18.820863
# Unit test for function find
def test_find():
    assert find([1, 3, 5], curry(eq, 1)) == 1
    assert find([1, 3, 5], curry(eq, 2)) is None
    assert find([1, 3, 5], lambda value: value % 2 == 0) is None
    assert find([1, 3, 5, 6], lambda value: value % 2 == 0) == 6



# Generated at 2022-06-24 00:52:29.711059
# Unit test for function curried_filter
def test_curried_filter():
    assert [] == curried_filter(eq(increase(10)))
    assert [] == curried_filter(increase, lambda x: x == 10)
    assert [1, 2, 3] == curried_filter(lambda x: x < 4)([1, 2, 3, 4, 5, 6])
    assert [1, 2, 3, 4] == curried_filter(lambda x: x < 5)([1, 2, 3, 4, 5, 6])
    assert [1, 2, 3, 4, 5] == curried_filter(lambda x: x < 6)([1, 2, 3, 4, 5, 6])
    assert [1, 2, 3, 4, 5, 6] == curried_filter(lambda x: x < 7)([1, 2, 3, 4, 5, 6])
    assert [] == curried

# Generated at 2022-06-24 00:52:31.769460
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-24 00:52:38.135117
# Unit test for function increase
def test_increase():
    """ Test increase function"""
    assert increase(1) == 2
    assert increase(2) == 3
    assert increase(3) == 4
    assert increase(4) == 5
    assert increase(5) == 6
    assert increase(6) == 7
    assert increase(7) == 8
    assert increase(8) == 9
    assert increase(9) == 10


# Generated at 2022-06-24 00:52:43.254976
# Unit test for function find
def test_find():
    """
    Function for unit test function find.

    :returns: text description of function test
    :rtype: str
    """
    assert find([1, 2, 3, 4, 5], lambda item: item == 2) == 2
    assert find([1, 2, 3, 4, 5], lambda item: item > 2) is None
    return 'Test passed!'



# Generated at 2022-06-24 00:52:46.782183
# Unit test for function curried_map
def test_curried_map():
    curried_map_2 = curried_map(increase)
    assert curried_map_2([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-24 00:52:50.648255
# Unit test for function find
def test_find():
    assert find([1,2,3,4,5], identity) == 5
    assert find([1,2,3,4,5], increase) == None


# Generated at 2022-06-24 00:52:55.200480
# Unit test for function eq
def test_eq():
    assert eq('a', 'a')('a') is True
    assert eq(1, 'a')(1) is False



# Generated at 2022-06-24 00:53:01.570520
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 3]
    assert curried_filter(eq(2), collection) == [2]
    assert curried_filter(increase, collection) == [2, 3, 4]
    assert curried_filter(eq(4))(collection) == []



# Generated at 2022-06-24 00:53:07.046741
# Unit test for function cond
def test_cond():

    def test_case_1(x):
        return x
    def test_case_2(x):
        return x + 1
    def test_case_3(x):
        return x + 2

    def test_case_11(x):
        return x == 1
    def test_case_12(x):
        return 3 <= x <= 6
    def test_case_13(x):
        return x >= 7

    assert cond([
        (test_case_11, test_case_1),
        (test_case_12, test_case_2),
        (test_case_13, test_case_3),
    ])(1) == 1


# Generated at 2022-06-24 00:53:10.039946
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x * 2)([1, 2, 3]) == [2, 4, 6]



# Generated at 2022-06-24 00:53:18.367422
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4]) == [2, 4]
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4]) == [3, 4]

    odd_filter = curried_filter(lambda x: x % 2 != 0)
    assert odd_filter([1, 2, 3, 4]) == [1, 3]



# Generated at 2022-06-24 00:53:21.973934
# Unit test for function eq
def test_eq():
    assert eq(2,2) == True
    assert eq(2,3) == False
    assert eq(2)(2) == True
    assert eq(2)(3) == False



# Generated at 2022-06-24 00:53:23.948595
# Unit test for function pipe
def test_pipe():
    assert pipe(2, (_ + 1) , (_ * 4)) == 12



# Generated at 2022-06-24 00:53:29.355834
# Unit test for function curry
def test_curry():
    def sum(a, b):
        return a + b

    curriedSum = curry(sum)
    assert curriedSum(1, 2) == 3
    curriedSum1 = curriedSum(1)
    assert curriedSum1(2) == 3
    curriedSum2 = curriedSum(3)
    assert curriedSum2(2) == 5


# Generated at 2022-06-24 00:53:30.547033
# Unit test for function pipe
def test_pipe():
    assert pipe(
        1,
        lambda x: x + 1,
        lambda x: x * 2
    ) == 4



# Generated at 2022-06-24 00:53:34.516570
# Unit test for function pipe
def test_pipe():
    assert pipe(0, compose(increase, identity, identity)) == 2

# Generated at 2022-06-24 00:53:37.353574
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None

# Generated at 2022-06-24 00:53:40.375034
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2
    assert increase(-1) == 0



# Generated at 2022-06-24 00:53:47.837347
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x == 0, lambda: -1),
        (lambda x: x > 0, lambda x: x + 4),
    ])(0) == -1
    assert cond([
        (lambda x: x == 0, lambda: -1),
        (lambda x: x > 0, lambda x: x + 4),
    ])(-12) == -1
    assert cond([
        (lambda x: x == 0, lambda: -1),
        (lambda x: x > 0, lambda x: x + 4),
    ])(3) == 7



# Generated at 2022-06-24 00:53:58.506304
# Unit test for function find
def test_find():
    find([1, 2, 3], eq(1)) == 1
    find([1, 2, 3], eq(2)) == 2
    find([1, 2, 3], eq(3)) == 3
    find([1, 2, 3], eq(4)) is None
    find([], eq(4)) is None

    array_1 = [1, 2, 3]
    find_1 = find(array_1, eq(1))
    find_2 = find(array_1, eq(2))
    find_3 = find(array_1, eq(3))
    find_4 = find(array_1, eq(4))

    find_1(1) == 1
    find_2(2) == 2
    find_3(3) == 3
    find_4(4) is None


# Generated at 2022-06-24 00:54:02.202513
# Unit test for function find
def test_find():
    assert find([], lambda x: x) is None
    assert find([1, 2, 3], lambda x: x == 1) == 1
    assert find([1, 2, 3], lambda x: x == 3) == 3

# Generated at 2022-06-24 00:54:08.876853
# Unit test for function curry
def test_curry():
    curried_add = curry(lambda x, y: x + y)
    assert curried_add(2)(2) == 4
    assert curried_add(2, 2) == 4
    two_add_three = curried_add(2)
    assert two_add_three(2) == 4
    assert two_add_three(3) == 5
    assert two_add_three(4) == 6
    assert two_add_three(5) == 7
    assert two_add_three(6) == 8
    return True



# Generated at 2022-06-24 00:54:18.963352
# Unit test for function compose
def test_compose():
    assert True == compose(True, identity, identity)
    assert False == compose(False, identity, identity)
    assert "a" == compose("a", identity, identity)
    assert "" == compose("", identity, identity)
    assert (1, 2) == compose((1, 2), identity, identity)
    assert (1, 2, 3) == compose((1, 2, 3), identity, identity)
    assert (1, 2, 3, 4) == compose((1, 2, 3, 4), identity, identity)
    assert [1] == compose([1], identity, identity)
    assert [1, 2] == compose([1, 2], identity, identity)
    assert [1, 2, 3] == compose([1, 2, 3], identity, identity)