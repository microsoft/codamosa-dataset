

# Generated at 2022-06-24 00:44:13.061127
# Unit test for function identity
def test_identity():
    assert identity(1) == 1


# Generated at 2022-06-24 00:44:21.158236
# Unit test for function memoize
def test_memoize():
    @memoize
    def factorial(n):
        if n < 2:
            return 1
        return n * factorial(n - 1)

    assert factorial(3) == 6
    assert factorial(3) == 6
    assert factorial.__closure__[0].cell_contents == [(3, 6), (2, 2), (1, 1)]

    factorial_memoized = memoize(factorial)

    assert factorial_memoized(3) == 6
    assert factorial_memoized.__closure__[0].cell_contents == [(3, 6), (2, 2), (1, 1)]

# Generated at 2022-06-24 00:44:30.885927
# Unit test for function memoize
def test_memoize():
    import time
    import random

    def memoized_fib(n):
        return memoize(fib)(n)

    def fib(n):
        if n < 2:
            return n
        return fib(n - 2) + fib(n - 1)

    def non_memoized_fib(n):
        if n < 2:
            return n
        return non_memoized_fib(n - 2) + non_memoized_fib(n - 1)

    current_time = int(time.time())
    print(memoized_fib(10))
    print("memoized_fib: {}\n".format(int(time.time()) - current_time))

    current_time = int(time.time())
    print(non_memoized_fib(10))


# Generated at 2022-06-24 00:44:32.196552
# Unit test for function memoize
def test_memoize():
    def square(x: int) -> int:
        return x * x

    result = memoize(square)(3)
    assert result == 9



# Generated at 2022-06-24 00:44:33.662237
# Unit test for function compose
def test_compose():
    assert compose("test", lambda x: x + "1", lambda x: x + "2") == "test12"
    assert compose(2, increase, increase) == 4



# Generated at 2022-06-24 00:44:36.239236
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 3]
    filterer = lambda item: item > 2

    assert curried_filter(filterer)(collection) == [3]

# Generated at 2022-06-24 00:44:46.264841
# Unit test for function find
def test_find():
    test_collection: List[Tuple[str, int]] = [
        ('Ala', 22),
        ('Ola', 20),
        ('Iga', 21)
    ]
    # NOTE: [::-1] because of that search is from right to left
    assert find(test_collection, eq(('Ala', 22))) == ('Ala', 22)
    assert find(test_collection, eq(('Ola', 23))) is None

    assert find(test_collection[::-1], eq(('Ala', 22))) is None
    assert (
        find(test_collection[::-1], eq(('Ola', 20))) == ('Ola', 20)
    )



# Generated at 2022-06-24 00:44:54.840855
# Unit test for function curried_filter
def test_curried_filter():
    filter_odd = curried_filter(lambda x: x % 2 == 1)
    filter_even = curried_filter(lambda x: x % 2 == 0)

    assert [1, 3, 5] == filter_odd([1, 2, 3, 4, 5])
    assert [2, 4] == filter_even([1, 2, 3, 4, 5])
    assert [1, 3, 5] == filter(lambda x: x % 2 == 1, [1, 2, 3, 4, 5])
    assert [2, 4] == filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5])


# Generated at 2022-06-24 00:45:00.630895
# Unit test for function memoize
def test_memoize():
    def add_to_five(num):
        return num + 5
    memoized_add_to_five = memoize(add_to_five)
    assert memoized_add_to_five(1) == 6
    assert memoized_add_to_five(2) == 7
    assert memoized_add_to_five(1) == 6

# Generated at 2022-06-24 00:45:06.580666
# Unit test for function pipe
def test_pipe():
    result = pipe(
        'hello',
        lambda text: text.split(),
        curried_map(curry(lambda first, last: first + last)),
        curried_filter(lambda word: word.endswith('o'))
    )
    assert result == ['hello']



# Generated at 2022-06-24 00:45:12.924729
# Unit test for function curried_map
def test_curried_map():
    assert True == eq(
        [1, 2, 3, 4, 5],
        curried_map(increase, [0, 1, 2, 3, 4])
    )
    curried_map_plus_1 = curried_map(increase)
    assert True == eq(
        [1, 2, 3, 4, 5],
        curried_map_plus_1([0, 1, 2, 3, 4])
    )



# Generated at 2022-06-24 00:45:19.474361
# Unit test for function find
def test_find():
    """
    Tests for function find()
    """
    def test_find_found():
        assert find([1, 2, 3], eq(2)) == 2

    def test_find_not_found():
        assert find([1, 2, 3], eq(4)) is None

    test_find_found()
    test_find_not_found()



# Generated at 2022-06-24 00:45:24.480259
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [1, 2, 3, 4] * 3) == [[1, 2, 3, 4] * 3]
    assert curried_map(increase, [1, 2, 3, 4] * 3) == [2, 3, 4, 5] * 3



# Generated at 2022-06-24 00:45:29.203184
# Unit test for function cond
def test_cond():
    condition_list = [
        (lambda x: x > 10, max),
        (lambda x: x < 10, min),
        (lambda x: x == 10, identity)
    ]
    result = cond(condition_list)

    if result(12) != 12:
        raise ValueError()

    if result(7) != 7:
        raise ValueError()

    if result(10) != 10:
        raise ValueError()



# Generated at 2022-06-24 00:45:32.368865
# Unit test for function identity
def test_identity():
    assert identity(True)
    assert identity(False)
    assert identity(0)
    assert identity(3)
    assert identity("abc")
    assert identity("")
    assert identity(['a', 'b'])
    assert identity(['a', "b", 3, True])


# Generated at 2022-06-24 00:45:40.348362
# Unit test for function cond
def test_cond():
    # Arrange
    def bigger_than_five(value: int) -> bool:
        return value > 5

    def less_than_ten(value: int) -> bool:
        return value < 10

    def return_seven(value: int) -> int:
        return 7

    def return_thirteen(value: int) -> int:
        return 13

    def return_nineteen(value: int) -> int:
        return 19

    # Act & Assert
    assert cond([
        (bigger_than_five, return_seven),
        (less_than_ten, return_thirteen),
    ])(6) == 7

    assert cond([
        (bigger_than_five, return_seven),
        (less_than_ten, return_thirteen),
    ])(3) == 13


# Generated at 2022-06-24 00:45:43.577731
# Unit test for function memoize
def test_memoize():
    @memoize
    def factorial(number: int) -> int:
        if number <= 1:
            return 1
        return number * factorial(number - 1)
    assert factorial(5) == 120

# Generated at 2022-06-24 00:45:53.572270
# Unit test for function curried_filter
def test_curried_filter():
    import unittest

    class TestCurriedFilter(unittest.TestCase):
        def test_empty_collection(self):
            self.assertEqual([], curried_filter(lambda value: True, []))
        def test_one_element(self):
            self.assertEqual([1], curried_filter(lambda value: True, [1]))
            self.assertEqual([], curried_filter(lambda value: False, [1]))
        def test_many_elements(self):
            self.assertEqual([1, 2, 3], curried_filter(lambda value: True, [1, 2, 3]))
            self.assertEqual([1, 2, 3], curried_filter(lambda value: value > 0, [1, -2, 3]))

    unittest.main()



# Generated at 2022-06-24 00:45:56.259030
# Unit test for function curried_map
def test_curried_map():
    result = curried_map(lambda x, y: y + x)(3)([
        2,
        4,
        6,
        8
    ])
    assert result == [5, 7, 9, 11]


# Generated at 2022-06-24 00:45:58.891523
# Unit test for function eq
def test_eq():
    assert not eq("a", "b")
    assert eq("a", "a")
    assert not eq("a")
    assert not eq("a", "A")



# Generated at 2022-06-24 00:46:04.282257
# Unit test for function cond
def test_cond():
    def is_even(number):
        return number % 2 == 0

    def increase(number):
        return number + 1

    def decrease(number):
        return number - 1

    assert cond([(is_even, increase),
                 (lambda number: True, decrease)])(1) == 0
    assert cond([(is_even, increase),
                 (lambda number: True, decrease)])(2) == 3



# Generated at 2022-06-24 00:46:14.192987
# Unit test for function curry
def test_curry():
    """Unit test for function curry."""
    assert curry(lambda x, y: x + y, 2)(1, 2) == 3
    assert curry(lambda x, y: x + y, 2)(1)(2) == 3
    assert curry(lambda x, y: x + y, 2)(1, 2, 3) == 3
    assert curry(lambda x, y: x + y, 2)(1, )(2) == 3
    assert curry(lambda x, y: x + y, 2)(1)(2, 3) == 3
    assert curry(lambda x, y: x + y, 2)(1, 2)(3) == 3
    assert curry(lambda x, y: x + y, 2)(1)(2)(3) == 3



# Generated at 2022-06-24 00:46:22.214054
# Unit test for function curried_map
def test_curried_map():
    numbers = [1, 2, 3, 4, 5]

    assert curried_map(increase, numbers) == [2, 3, 4, 5, 6]
    assert curried_map(increase)(numbers) == [2, 3, 4, 5, 6]
    assert curried_map(lambda x: x + x)(numbers) == [2, 4, 6, 8, 10]
    assert curried_map(lambda x: x + x, numbers) == [2, 4, 6, 8, 10]



# Generated at 2022-06-24 00:46:23.282807
# Unit test for function increase
def test_increase():
    assert increase(1) == 2


# Generated at 2022-06-24 00:46:30.490240
# Unit test for function memoize
def test_memoize():
    test_data = [1, 2, 3, 4, 5, 6]

    def double(x):
        time.sleep(1)
        return 2 * x

    # create cached instance of double
    double_cached = memoize(double)

    def test_double():
        assert [double(value) for value in test_data] == [double_cached(value) for value in test_data]

    # Test with default eq key
    test_double()

    # Test with our key
    double_cached = memoize(double, key=lambda x, y: x % 2 == y % 2)
    test_double()

# Generated at 2022-06-24 00:46:31.976763
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:46:43.316938
# Unit test for function memoize
def test_memoize():
    """
    For test memoize function.
    """
    import sys
    import time

    def get_time():
        return str(time.strftime("%H:%M:%S", time.gmtime()))

    def expensive_function(arg):
        print("Called expensive function with arg: %s at: %s" % (arg, get_time()))
        time.sleep(2)
        return "Result"

    memoized_function = memoize(expensive_function, key=eq)

    start_time = get_time()
    print("Called memoried function with arg: %s at: %s" % (1, start_time))
    assert memoized_function(1) == "Result"

# Generated at 2022-06-24 00:46:44.221712
# Unit test for function identity
def test_identity():
    assert identity(3) == 3

# Generated at 2022-06-24 00:46:46.467446
# Unit test for function compose
def test_compose():
    f = compose(2, increase, increase)
    assert(f == 4)


# Generated at 2022-06-24 00:46:47.332653
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:46:52.204797
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1, 2)
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-24 00:46:56.005328
# Unit test for function compose
def test_compose():
    assert compose(0, increase, increase) == 2
    assert compose(0, increase, increase, increase) == 3



# Generated at 2022-06-24 00:46:58.085962
# Unit test for function identity
def test_identity():
    assert identity(5) == 5
    assert identity(True) is True
    assert identity('Hello, world') == 'Hello, world'



# Generated at 2022-06-24 00:46:59.767178
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:47:07.311498
# Unit test for function cond
def test_cond():
    # Example of usage function cond
    is_even = lambda x: x % 2 == 0
    is_less_than_ten = lambda x: x < 10
    add_five = lambda x: x + 5
    square = lambda x: x ** 2
    noop = lambda x: x

    # Here we define condition list of two-item tuple.
    # The first element of tuple is a function to be called,
    # and if it returns a truthy value, the second argument in the tuple will be executed
    # and the result of cond() will be the result of executing the second argument.
    condition_list = [
        (is_even, add_five),
        (is_less_than_ten, square),
        (lambda x: True, noop)
    ]

    # Function cond return function depending on condition list.
    # This function

# Generated at 2022-06-24 00:47:10.272897
# Unit test for function pipe
def test_pipe():
    assert pipe(0, lambda x: x + 1, lambda x: x * 3) == 3
    assert pipe('a', lambda x: x + 'b', lambda x: x * 3) == 'ababab'

# Generated at 2022-06-24 00:47:17.031873
# Unit test for function find
def test_find():
    data = [{
        "name": "Apple",
        "price": 100
    }, {
        "name": "Apple",
        "price": 200
    }, {
        "name": "Apple",
        "price": 300
    }]
    assert find(data, lambda item: item["price"] > 100 and item["name"] == "Apple") == {
        "name": "Apple",
        "price": 200
    }
    assert find(data, lambda item: item["price"] > 500 or item["name"] == "Banana") is None



# Generated at 2022-06-24 00:47:19.486551
# Unit test for function curry
def test_curry():
    raise NotImplementedError



# Generated at 2022-06-24 00:47:21.575768
# Unit test for function curried_map
def test_curried_map():
    test_values = [1, 2, 3, 4]
    result = curried_map(increase)(test_values)
    assert result == [2, 3, 4, 5]



# Generated at 2022-06-24 00:47:27.452557
# Unit test for function curry
def test_curry():
    assert(curry(lambda x: x + 1)(1) == 2)
    assert(curry(lambda x, y: x * y)(1, 2) == 2)
    add = curry(lambda x, y: x + y)
    inc = add(1)
    assert(inc(3) == 4)



# Generated at 2022-06-24 00:47:35.427956
# Unit test for function cond
def test_cond():
    conditions = [
        (lambda x: x < 0, lambda x: -1),
        (lambda x: x == 0, lambda _: 0),
        (lambda x: x > 0, lambda x: 1),
    ]
    condition_function = cond(conditions)
    assert condition_function(0) == 0
    assert condition_function(-10) == -1
    assert condition_function(10) == 1

# Generated at 2022-06-24 00:47:36.838747
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b, c: a + b + c)(100)(200)(300) == 600



# Generated at 2022-06-24 00:47:39.083103
# Unit test for function pipe
def test_pipe():
    assert pipe(2, identity, increase) == 3
    assert pipe(2)(identity)(increase) == 3
    assert pipe(2, increase, increase, increase) == 5


# Generated at 2022-06-24 00:47:41.236827
# Unit test for function find
def test_find():
    assert find(["a", "b", "c"], lambda x: x == "b") == "b"

    assert find(["a", "b", "c"], lambda x: x == "b") == "b"

    assert find(["a", "b", "c"], lambda x: x == "x") is None



# Generated at 2022-06-24 00:47:46.224518
# Unit test for function find
def test_find():
    """Tests for function find"""
    print(
        'Cases for find:',
        find([1, 2, 3, 4], lambda x: x == 2),
        find([{'a': 1}, {'a': 2}, {'a': 3}], lambda x: x['a'] == 3),
        find([{'a': 1}, {'a': 2}, {'a': 3}], lambda x: x['a'] == 5),
        sep='\n'
    )


test_find()

# Generated at 2022-06-24 00:47:47.563163
# Unit test for function curried_map
def test_curried_map():
    result = curried_map(lambda x: x + x)([1, 2, 3])
    assert result == [2, 4, 6]


# Generated at 2022-06-24 00:47:56.718044
# Unit test for function curry
def test_curry():
    print('test_curry')

    assert curry(increase, 2)(1, 2) == 3
    assert curry(increase, 2)(1)(2) == 3
    assert curry(increase, 2)(1, 3) == 4
    assert curry(increase, 2)(2, 3) == 4
    assert curry(increase)(1) == 2
    assert curry(increase)(2) == 3
    assert curry(increase)(5) == 6


# Unit tests for function find

# Generated at 2022-06-24 00:48:02.863032
# Unit test for function memoize
def test_memoize():
    count = [0]

    @memoize
    def expensive_fn(argument):
        count[0] += 1

        return argument ** 2

    assert expensive_fn(2) == 4
    assert count[0] == 1

    assert expensive_fn(2) == 4
    assert count[0] == 1

    assert expensive_fn(3) == 9
    assert count[0] == 2

    assert expensive_fn(2) == 4
    assert count[0] == 2

    assert expensive_fn(3) == 9
    assert count[0] == 2


if __name__ == '__main__':
    test_memoize()

# Generated at 2022-06-24 00:48:04.440855
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False


# # Unit test for function increase

# Generated at 2022-06-24 00:48:07.772654
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5]) == [2, 4]



# Generated at 2022-06-24 00:48:09.282308
# Unit test for function pipe
def test_pipe():
    assert pipe(1, identity, increase) == 2
    assert pipe(1, increase, identity) == 1



# Generated at 2022-06-24 00:48:14.682216
# Unit test for function memoize
def test_memoize():
    def multiply(argument):
        return argument * argument
    multiply_memoize = memoize(multiply)
    assert 4 == multiply_memoize(2), "Assert multiply on 2"
    assert 4 == multiply_memoize(2), "Assert memoize of multiply on 2"
    assert 9 == multiply_memoize(3), "Assert multiply on 3"
    assert 9 == multiply_memoize(3), "Assert memoize of multiply on 3"



# Generated at 2022-06-24 00:48:21.581005
# Unit test for function memoize
def test_memoize():
    """
    Test for function memoize.

    :returns: -
    :rtype: -
    """
    import time

    fibonacci_numbers = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]

    def fibonacci(n):
        return fibonacci_numbers[n]

    def non_memoized_fibonacci(n):
        time.sleep(0.001)
        return fibonacci(n)

    memoized_fibonacci = memoize(non_memoized_fibonacci)

    def time_fibonacci(fibonacci_function, n):
        import datetime

        start = datetime.datetime.now()
        fibonacci_function(n)
        finish = datetime.dat

# Generated at 2022-06-24 00:48:23.082697
# Unit test for function compose
def test_compose():
    value = 5
    functions = [
        lambda x: x + 2,
        lambda x: x ** 2,
    ]
    result = compose(value, *functions)

    assert result == 49



# Generated at 2022-06-24 00:48:24.735503
# Unit test for function compose
def test_compose():
    assert compose(5, increase, increase, increase) == 8



# Generated at 2022-06-24 00:48:28.945273
# Unit test for function pipe
def test_pipe():
    assert pipe(1, (lambda x: x + 1), (lambda x: x * x)) == 4
    assert pipe('one', lambda x: x[0], lambda x: x.upper()) == 'O'



# Generated at 2022-06-24 00:48:34.927510
# Unit test for function eq
def test_eq():
    def eq_test_suite():
        print('Test eq:')

        print(eq(1, 2), False)
        print(eq(1, 1), True)
        print(eq('a', 'a'), True)
        print(eq('a', 'b'), False)

    return eq_test_suite



# Generated at 2022-06-24 00:48:41.971276
# Unit test for function curry
def test_curry():
    def f(a, b, c):
        return a, b, c

    # here we can pass two arguments, because f is partially applied
    assert f(1, 2, 3) == (1, 2, 3)
    assert f(1, 2)(3) == (1, 2, 3)
    assert f(1)(2, 3) == (1, 2, 3)
    assert f(1)(2)(3) == (1, 2, 3)



# Generated at 2022-06-24 00:48:51.097930
# Unit test for function cond
def test_cond():
    def eq1(x, y):
        return x == y

    def greater_than_zero(x):
        return x > 0

    def less_than_zero(x):
        return x < 0

    def is_zero(x):
        return x == 0

    def add_x(x, y=0):
        return x + y

    def sub_x(x, y=0):
        return x - y

    condition_list = [
        (greater_than_zero, curry(add_x, 2)),
        (less_than_zero, curry(sub_x, 2)),
        (is_zero, curry(eq1, 0)),
    ]
    f = cond(condition_list)

    assert f(4) == 6
    assert f(-4) == -6
    assert f(0) == True

# Generated at 2022-06-24 00:48:59.710310
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity('1') == '1'
    assert identity([1, 2, 3]) == [1, 2, 3]
    assert identity(True)
    assert identity(False) is False
    assert identity(None) is None
    assert identity((1, 2, 3)) == (1, 2, 3)
    assert identity({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}

    # prove that identity return the same object and not copy
    test_dict = {'a': 1, 'b': 2}
    assert identity(test_dict) is test_dict



# Generated at 2022-06-24 00:49:01.683873
# Unit test for function find
def test_find():
    assert find(range(10), lambda x: not x % 2)(3) == 2
    assert find(range(10), lambda x: not x % 2)(4) == None


# Generated at 2022-06-24 00:49:04.688134
# Unit test for function increase
def test_increase():
    assert increase(10) == 11


# Generated at 2022-06-24 00:49:11.407683
# Unit test for function identity
def test_identity():
    assert identity(None) is None
    assert identity(False) is False
    assert identity(True) is True
    assert identity(0) == 0
    assert identity(1) == 1
    assert identity('string') == 'string'
    assert identity([1, 2, 3]) == [1, 2, 3]
    assert identity({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert identity({}) == {}



# Generated at 2022-06-24 00:49:13.444222
# Unit test for function curried_filter
def test_curried_filter():
    def even(_num):
        return _num % 2 == 0

    assert curried_filter(even, [1,2,3,4]) == [2,4]



# Generated at 2022-06-24 00:49:17.586668
# Unit test for function curry
def test_curry():
    @curry
    def add(a, b, c, d):
        return a + b + c + d

    assert add(1, 2, 3, 4) == 10
    assert add(1, 2, 3)(4) == 10
    assert add(1)(2, 3, 4) == 10
    assert add(1)(2)(3)(4) == 10



# Generated at 2022-06-24 00:49:21.927987
# Unit test for function eq
def test_eq():
    assert eq(True, True)
    assert not eq(True, False)
    assert not eq(False, True)
    assert eq(False, False)
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(2, 1)
    assert eq(2, 2)
    assert eq('a', 'a')
    assert not eq('b', 'a')
    assert not eq('a', 'b')
    assert eq('b', 'b')



# Generated at 2022-06-24 00:49:24.537226
# Unit test for function compose
def test_compose():
    assert compose(True, identity, identity) == True
    assert compose(True, identity, identity, identity) == True
    assert compose(True, increase, identity) == 2
    assert compose(True, increase, identity, increase) == 3
    assert compose(False, increase, identity) == 1
    assert compose(False, increase, identity, increase) == 2



# Generated at 2022-06-24 00:49:25.793961
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(2) == 3


# Generated at 2022-06-24 00:49:27.099025
# Unit test for function pipe
def test_pipe():
    assert pipe(
        42,
        lambda x: x + 2,
        lambda x: x * 2
    ) == 88



# Generated at 2022-06-24 00:49:33.134143
# Unit test for function memoize
def test_memoize():
    import time

    @memoize
    def time_consuming_func(n):
        time.sleep(n)
        return n

    start = time.time()
    assert time_consuming_func(5) == 5
    time_consuming_func(5)
    time_consuming_func(5)
    time_consuming_func(5)
    time_consuming_func(5)
    time_consuming_func(5)
    time_consuming_func(5)
    time_consuming_func(5)
    time_consuming_func(5)
    time_consuming_func(5)
    time_consuming_func(5)
    time_consuming_func(5)
    time_consuming_func(5)
    time1 = time.time() - start
    assert time1 < 5.5

# Generated at 2022-06-24 00:49:41.128941
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 == 1

    def triple_number(number):
        return number * 3

    def square_number(number):
        return number ** 2

    assert cond([
        (is_even, triple_number),
        (is_odd, square_number),
    ])(4) == 12

    assert cond([
        (is_even, triple_number),
        (is_odd, square_number),
    ])(5) == 25


# Generated at 2022-06-24 00:49:45.396042
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:49:47.352104
# Unit test for function pipe
def test_pipe():
    result = pipe(1, lambda x: x + 1, lambda x: x * 2)
    assert result == 4



# Generated at 2022-06-24 00:49:51.654911
# Unit test for function compose
def test_compose():
    value_10 = 10
    is_eq_10 = lambda value: value == value_10
    is_less_then_20 = lambda value: value < 20

    print(compose(value_10, increase, increase))
    print(compose(value_10, eq(value_10), identity))
    print(compose(value_10, is_eq_10, is_less_then_20, increase, eq(11)))



# Generated at 2022-06-24 00:49:55.155155
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(2), [2, 3, 4]) == [2]
    assert curried_filter(eq(10), [1, 2, 3, 4, 5, 6]) == []



# Generated at 2022-06-24 00:49:56.286436
# Unit test for function curry
def test_curry():
    pass

# Unit test function identity

# Generated at 2022-06-24 00:50:01.187803
# Unit test for function cond
def test_cond():
    cond_function = cond([
        (lambda x: x == 0, lambda _: 0),
        (lambda x: x == 1, lambda _: 1),
        (lambda x: True, lambda x: x + 1)
    ])

    assert cond_function(0) == 0
    assert cond_function(1) == 1
    assert cond_function(2) == 3



# Generated at 2022-06-24 00:50:06.222038
# Unit test for function curry
def test_curry():
    print("Testing curry...")

    def f(x, y, z):
        return x + y + z

    assert f(1, 2, 3) == 6

    f_curried = curry(f, 3)

    assert f_curried(1)(2)(3) == 6
    assert f_curried(1)(2)(4) == 7
    assert f_curried(1)(3)(4) == 8
    assert f_curried(2)(3)(4) == 9

    print("Passed!")



# Generated at 2022-06-24 00:50:14.875613
# Unit test for function eq
def test_eq():
    a = 2
    b = 1
    c = "a"
    assert eq(a, b) == False
    assert eq(a, a)
    assert eq(a, c) == False
    assert curry(eq)(a)(b) == False
    assert curry(eq)(a)(a)
    assert curry(eq)(a)(c) == False
    assert curry(eq)(a)(b)(c)() == False
    assert curry(eq)(a)(b)(a)()
    assert curry(eq)(a)(b)(c)(a)() == False



# Generated at 2022-06-24 00:50:17.176241
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity([1, 2]) == [1, 2]



# Generated at 2022-06-24 00:50:18.745877
# Unit test for function compose
def test_compose():
    assert compose(2, increase, increase, increase) == 5



# Generated at 2022-06-24 00:50:20.354848
# Unit test for function find
def test_find():
    assert find([0, 1, 2, 3, 4], lambda x: x == 0) == 0



# Generated at 2022-06-24 00:50:25.144579
# Unit test for function curried_filter
def test_curried_filter():
    is_even = lambda x: x % 2 == 0
    is_odd = lambda x: x % 2 != 0

    curried_filtered_list = curried_filter(is_even)([1, 3, 4, 6])
    assert curried_filtered_list == [4, 6]

    curried_filtered_list = curried_filter(is_odd)([1, 3, 4, 6])
    assert curried_filtered_list == [1, 3]



# Generated at 2022-06-24 00:50:25.978386
# Unit test for function increase
def test_increase():
    value = increase(1)
    assert value == 2



# Generated at 2022-06-24 00:50:28.596981
# Unit test for function compose
def test_compose():
    """
    Unit test for function compose.
    """
    assert compose(1, identity, increase) == 2
    assert compose(2, increase, increase) == 4



# Generated at 2022-06-24 00:50:32.887558
# Unit test for function curry
def test_curry():
    def add(a, b):
        return a + b

    assert curry(add, 2)(3, 4) == 7
    assert curry(add, 2)(3)(4) == 7
    assert curry(add, 2)(3) == curry(lambda a: curry(lambda b: a + b, 1)(3), 1)
    assert curry(lambda x: lambda y: x * y, 1)(6)(7) == 42



# Generated at 2022-06-24 00:50:34.127116
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-24 00:50:37.620371
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(-1) == 0
    assert increase(1) == 2



# Generated at 2022-06-24 00:50:41.595380
# Unit test for function compose
def test_compose():
    assert compose(1, identity) == 1
    assert compose(1, lambda x: x + 1, identity) == 2
    assert compose(1, lambda x: x + 1, lambda x: x * 2) == 4



# Generated at 2022-06-24 00:50:44.981398
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda x: x == 7) is None



# Generated at 2022-06-24 00:50:48.791407
# Unit test for function identity
def test_identity():
    assert identity(2) == 2
    assert identity(None) is None
    assert identity(True) is True
    assert identity(False) is False
    assert identity(1) == 1
    assert identity('abc') == 'abc'
    assert curry(identity)(2) == 2
    assert curry(identity)('abc') == 'abc'



# Generated at 2022-06-24 00:50:52.602953
# Unit test for function compose
def test_compose():
    """
    Test compose function.
    Check if it perform right-to-left function composition.
    """
    assert compose(1, lambda x: x + 1, lambda x: x + 2) == 4

# Generated at 2022-06-24 00:50:58.400884
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)(range(6)) == [0, 2, 4]



# Generated at 2022-06-24 00:50:59.182246
# Unit test for function identity
def test_identity():
    assert identity(None) is None
    assert identity(1) == 1



# Generated at 2022-06-24 00:51:06.756567
# Unit test for function cond
def test_cond():
    """
    Unit test for function cond.
    """
    condition_list = [
        (lambda value: value == 1, lambda value: value * 2),
        (lambda value: value == 2, lambda value: value * 3),
        (lambda value: value == 3, lambda value: value * 4)
    ]
    assert cond(condition_list)(1) == 2
    assert cond(condition_list)(2) == 6
    assert cond(condition_list)(3) == 12



# Generated at 2022-06-24 00:51:10.418752
# Unit test for function eq
def test_eq():
    assert eq(2, 2) == True
    assert eq("a", "b") == False
    assert eq("a", "a") == True
    assert eq(["a", "b"], ["a", "b"]) == True



# Generated at 2022-06-24 00:51:14.670751
# Unit test for function find
def test_find():
    assert find([], lambda x: True) is None
    assert find([1], lambda x: x == 2) is None
    assert find([1], lambda x: x == 1) == 1
    assert find([1], lambda x: True) == 1


# Generated at 2022-06-24 00:51:16.326938
# Unit test for function curried_map
def test_curried_map():
    collection = [1, 2, 3]

    assert curried_map(lambda x: x + 1, collection) == [2, 3, 4]
    assert curried_map(increase, collection) == [2, 3, 4]
    assert curried_map(increase)(collection) == [2, 3, 4]


# Generated at 2022-06-24 00:51:20.509589
# Unit test for function pipe
def test_pipe():
    def is_odd(value):
        return value % 2 == 1

    def multiply_by(value, by):
        return value * by

    assert pipe(
        True,
        is_odd,
        multiply_by,
        increase
    ) == True


# Generated at 2022-06-24 00:51:22.586800
# Unit test for function compose
def test_compose():
    assert compose(1, increase, increase, increase) == 4
    assert compose(2, lambda x: x * x, lambda x: x + 1, lambda x: x + 1) == 16



# Generated at 2022-06-24 00:51:23.237015
# Unit test for function increase
def test_increase():
    assert increase(1) == 2

# Generated at 2022-06-24 00:51:28.264178
# Unit test for function cond
def test_cond():
    # Test for cond function
    def f1(arg):
        return arg == 1

    def f2(arg):
        return arg == 2

    def f3(arg):
        return arg == 3

    def f4(arg):
        return arg == 4

    def g(arg):
        return arg * 2

    def h(arg):
        return arg + 1

    def k(arg):
        return arg**2

    # Test for cond function
    assert cond(
        [(f1, g),
         (f2, h),
         (f3, k)]
        )(4) == 16, "Error in cond"

# Generated at 2022-06-24 00:51:37.267397
# Unit test for function pipe
def test_pipe():
    testObjects = [
        ([1, 2, 3], lambda x: x + 1),
        ([1, 2, 3], [lambda x: x + 1, lambda x: x + 2]),
        ([1, 2, 3], [lambda x: x + 1, lambda x: x + 2, lambda x: x + 3]),
        ([1, 2, 3], [lambda x: x + 1, lambda x: x + 2, lambda x: x + 3, lambda x: x + 4])
    ]

    for testObject in testObjects:
        assert(pipe(*testObject) == testObject[0] + len(testObject[1]))



# Generated at 2022-06-24 00:51:40.557715
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    filterer = lambda x: x % 2 == 0
    assert curried_filter(filterer)(collection) == [2, 4, 6, 8, 10]



# Generated at 2022-06-24 00:51:41.340198
# Unit test for function increase
def test_increase():
    assert increase(1) == 2


# Generated at 2022-06-24 00:51:47.326390
# Unit test for function compose
def test_compose():
    assert compose(
        [1, 2, 3],
        lambda x: [increase(i) for i in x],
        lambda x: [i * 2 for i in x]
    ) == [4, 6, 8]

    assert compose(
        [[1, 2, 3], [4, 5, 6]],
        lambda x: [list(map(increase, i)) for i in x],
        lambda x: [list(map(lambda x: x * 2, i)) for i in x]
    ) == [[4, 6, 8], [10, 12, 14]]

    assert compose(
        [1, 2, 3],
        curried_map(increase),
        curried_map(lambda x: x * 2)
    ) == [4, 6, 8]



# Generated at 2022-06-24 00:51:49.331829
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-24 00:51:52.652823
# Unit test for function compose
def test_compose():
    assert pipe(5, lambda x: x + 1, lambda x: x ** 2) == 36
    assert pipe(5, lambda x: x + 1) == 6



# Generated at 2022-06-24 00:51:58.760308
# Unit test for function find
def test_find():
    """
    Function for unit test for function find.

    :returns: None
    :rtype: None
    """
    assert find([1,2,3,4], lambda x: x % 2 == 0) == 2
    assert find([1,2,3,4], lambda x: x % 5 == 0) is None
    assert find([], lambda x: x % 2 == 0) is None


# Generated at 2022-06-24 00:52:04.714067
# Unit test for function curried_map
def test_curried_map():
    result = curried_map(
        lambda x: x + 1,
        [1, 2, 3, 4]
    )
    assert result == [2, 3, 4, 5]
    result = curried_map(
        lambda x: x + 1,
        {}
    )
    assert result == []
    result = curried_map(
        lambda x: x + 1,
        'Python'
    )
    assert result == ['P', 'y', 't', 'h', 'o', 'n']


# Generated at 2022-06-24 00:52:09.354034
# Unit test for function increase
def test_increase():
    """
    >>>test_increase()
    True
    """
    return increase(1) == 2


# Generated at 2022-06-24 00:52:10.220859
# Unit test for function increase
def test_increase():
    increased = increase(1)
    assert increased == 2



# Generated at 2022-06-24 00:52:12.567799
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4], lambda x: x == 5) is None

# Generated at 2022-06-24 00:52:14.074145
# Unit test for function compose
def test_compose():
    assert identity(1) == compose(1, identity)



# Generated at 2022-06-24 00:52:24.856662
# Unit test for function memoize
def test_memoize():
    """
    Function for testing of memoize work.
    Creates cache item, if cache was empty or cache key is different from current argument.
    Returns cache item, if cache was not empty and cache key is equal to current argument.
    :returns:
    :rtype:
    """

    @memoize
    def sum_2(num):
        return num + 2

    assert sum_2(3) == 5
    assert sum_2(3) == 5
    assert sum_2(6) == 8
    assert sum_2(3) == 5
    assert sum_2(6) == 8
    assert sum_2(3) == 5



# Generated at 2022-06-24 00:52:27.764283
# Unit test for function pipe
def test_pipe():
    assert pipe(1, increase, increase) == 3

# Generated at 2022-06-24 00:52:29.898449
# Unit test for function memoize
def test_memoize():
    assert memoize(identity)(0) == identity(0) == memoize(identity)(0) == memoize(identity)(0) == 0

# Generated at 2022-06-24 00:52:31.371521
# Unit test for function curried_filter
def test_curried_filter():
    odd = lambda x: x % 2 == 1
    assert curried_filter(odd)([1, 2, 3, 4]) == [1, 3]



# Generated at 2022-06-24 00:52:32.459899
# Unit test for function identity
def test_identity():
    assert identity(10) == 10



# Generated at 2022-06-24 00:52:36.824314
# Unit test for function cond
def test_cond():
    fn = cond([
        (lambda x: x % 3 == 0, lambda x: "Fizz"),
        (lambda x: x % 5 == 0, lambda x: "Buzz"),
        (lambda x: True, lambda x: x),
    ])

    test_list = [
        (1, 1),
        (2, 2),
        (3, "Fizz"),
        (4, 4),
        (5, "Buzz"),
        (15, "FizzBuzz"),
    ]

    for argument, expected in test_list:
        assert fn(argument) == expected


test_cond()

# Generated at 2022-06-24 00:52:42.664121
# Unit test for function find
def test_find():
    assert None == find([], lambda item: True)
    assert 1 == find([1, 2, 3], lambda item: item == 1)
    assert 4 == find([1, 2, 3, 4], lambda item: item == 4)
    assert None == find([1, 2, 3], lambda item: item == 6)



# Generated at 2022-06-24 00:52:51.207038
# Unit test for function memoize
def test_memoize():
    def slow_fn(num):
        """
        Slow function that count from 0 to argument value.
        """
        time.sleep(2)
        return reduce(
            lambda a, b: a + b,
            range(0, num)
        )

    start1 = time.time()
    slow_fn(10000)
    print(time.time() - start1)

    start2 = time.time()
    slow_fn(10000)
    print(time.time() - start2)

    memoized_slow_fn = memoize(slow_fn)

    start3 = time.time()
    memoized_slow_fn(10000)
    print(time.time() - start3)

    start4 = time.time()
    memoized_slow_fn(10000)
    print(time.time() - start4)

# Generated at 2022-06-24 00:52:53.984930
# Unit test for function identity
def test_identity():
    """
    assert equality of results of calling each function
    """
    value = 'some string'
    assert id(value) == id(identity(value))



# Generated at 2022-06-24 00:52:55.567553
# Unit test for function memoize
def test_memoize():
    assert memoize(lambda x: x+1)(1) == 2, "memoize"



# Generated at 2022-06-24 00:53:01.391843
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b: a + b)(2)(3) == 5, \
        "curry(lambda a, b: a + b)(2)(3) should return 5"


# Generated at 2022-06-24 00:53:06.314690
# Unit test for function find
def test_find():
    assert find([0, 1, 2], lambda item: item == 1) == 1
    assert find([0, 1, 2], lambda item: item == 3) is None
    assert find([], lambda item: item == 3) is None



# Generated at 2022-06-24 00:53:10.801417
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda item: item == 2) == 2
    assert find([1, 2, 3, 4], lambda item: item == 5) is None



# Generated at 2022-06-24 00:53:15.612276
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(2, 3) is False



# Generated at 2022-06-24 00:53:19.359902
# Unit test for function identity
def test_identity():
    assert identity(5) == 5
    assert identity(False) is False
    assert identity(None) is None
    assert identity('hello') == 'hello'



# Generated at 2022-06-24 00:53:24.499839
# Unit test for function curry
def test_curry():
    assert 1 == curry(lambda x: x)(1)
    assert 1 == curry(lambda x, y: x)(1)
    assert 1 == curry(lambda x, y: x, 2)(1, 2)
    assert 3 == curry(lambda x, y, z: x + y + z, 3)(1, 2, 3)



# Generated at 2022-06-24 00:53:30.124315
# Unit test for function curried_map
def test_curried_map():
    curried_increase = curried_map(increase, [0, 1, 2, 3, 4])
    assert curried_increase == [1, 2, 3, 4, 5]

    curried_increase = curried_map(increase)
    assert curried_increase([0, 1, 2, 3, 4]) == [1, 2, 3, 4, 5]



# Generated at 2022-06-24 00:53:36.176347
# Unit test for function compose
def test_compose():
    """
    run unit test for function compose
    :returns: True if test passed
    :rtype: Boolean
    """
    assert compose(1, identity, increase) == 2
    assert compose([1], curried_map(identity), curried_map(increase)) == [2]
    assert compose(1, identity, increase) == 2
    assert compose([1, 2, 3, 4], curried_map(identity), curried_map(increase)) == [2, 3, 4, 5]
    assert compose([1], curried_filter(lambda x: True), curried_filter(lambda x: True)) == [1]
    assert compose([1, 2, 3, 4], curried_filter(lambda x: True), curried_filter(lambda x: False)) == []



# Generated at 2022-06-24 00:53:45.363511
# Unit test for function curried_filter
def test_curried_filter():
    """
    test curried_filter
    :return:
    :rtype: Void
    """
    curried_even = curried_filter(lambda x: x % 2 == 0)
    assert curried_even([1, 2, 3, 4]) == [2, 4]
    assert curried_even([]) == []
    assert curried_even([1, 3]) == []

    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0)([]) == []
    assert curried_filter(lambda x: x % 2 == 0)([1, 3]) == []


# Generated at 2022-06-24 00:53:47.883344
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-24 00:53:49.254612
# Unit test for function pipe
def test_pipe():
    assert pipe(1, increase, increase) == 3
    assert pipe(1, lambda x: x + 1, lambda x: x + 1) == 3



# Generated at 2022-06-24 00:53:53.710467
# Unit test for function cond
def test_cond():
    def even(number):
        return number % 2 == 0

    def evenIncrease(number):
        return number + 1

    def oddIncrease(number):
        return number + 2

    increase_result = cond([
        (even, evenIncrease),
        (identity, oddIncrease),
    ])

    assert increase_result(1) == 3
    assert increase_result(2) == 4



# Generated at 2022-06-24 00:53:57.021298
# Unit test for function curried_map
def test_curried_map():
    double = lambda x: x * 2
    numbers = [1, 2, 3, 4, 5]
    assert curried_map(double, numbers) == [2, 4, 6, 8, 10]


# Generated at 2022-06-24 00:53:58.818197
# Unit test for function eq
def test_eq():
    assert eq(1)(0) == False
    assert eq(1)(1) == True



# Generated at 2022-06-24 00:54:01.746537
# Unit test for function eq
def test_eq():
    assert eq(3, 3)
    assert not eq(3, 4)
    assert not eq(5, 4)



# Generated at 2022-06-24 00:54:03.840095
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-24 00:54:07.131127
# Unit test for function curried_map
def test_curried_map():
    collection = [1, 2, 3, 4, 5]
    result = curried_map(increase, collection)
    assert result == [2, 3, 4, 5, 6], "result of curried_map(increase, collection) should be [2, 3, 4, 5, 6]"



# Generated at 2022-06-24 00:54:10.442924
# Unit test for function curry
def test_curry():
    def sum_of_3(a, b, c):
        return a + b + c

    assert curry(sum_of_3)(1, 2, 3) == 6
    assert curry(sum_of_3)(1, 2)(3) == 6
    assert curry(sum_of_3)(1)(2, 3) == 6
    assert curry(sum_of_3)(1)(2)(3) == 6
    assert curry(sum_of_3)(1, 2, 3, 4) == 6



# Generated at 2022-06-24 00:54:13.441928
# Unit test for function curry
def test_curry():
    curried_func = curry(lambda x, y, z: x + y + z)
    assert 3 == curried_func(1, 2)  # fn=3, arg=(1, 2)
    assert 6 == curried_func(1, 2)(3)  # fn=6, arg=(1, 2, 3)
    assert 6 == curried_func(1)(2, 3)  # fn=6, arg=(1, 2, 3)
    assert 6 == curried_func(1)(2)(3)  # fn=6, arg=(1, 2, 3)

