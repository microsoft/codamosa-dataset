

# Generated at 2022-06-24 00:44:15.949624
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda x: x == 6) == None
    assert find([], lambda x: True) == None



# Generated at 2022-06-24 00:44:21.845582
# Unit test for function curried_map
def test_curried_map():
    assert [2, 3] == curried_map(increase)([1, 2])
    assert [2, 3] == curried_map(increase, [1, 2])
    assert [2, 3] == curried_map(increase, [1, 2])
    assert [2, 3] == map(lambda x: increase(x), [1, 2])
    assert [2, 3] == (lambda x: curried_map(x + 1, [1, 2]))(1)


# Generated at 2022-06-24 00:44:25.283312
# Unit test for function find
def test_find():
    collection = [1, 3, 5, 7, 9]
    assert find(collection, eq(1)), 'Should return number 1'
    assert find(collection, eq(5)), 'Should return number 5'
    assert find(collection, eq(9)), 'Should return number 9'
    assert find(collection, eq(10)) is None, 'Should return None'



# Generated at 2022-06-24 00:44:26.350906
# Unit test for function pipe
def test_pipe():
    assert pipe(1, lambda x: x + 2, lambda x: x * 3) == 9

# Generated at 2022-06-24 00:44:27.137705
# Unit test for function identity
def test_identity():
    assert identity(123) == 123


# Generated at 2022-06-24 00:44:30.009520
# Unit test for function increase
def test_increase():
    assert 1 == increase(0)
    assert 2 == increase(1)
    assert 3 == increase(2)


# Generated at 2022-06-24 00:44:34.704612
# Unit test for function identity
def test_identity():
    assert identity('a') == 'a'
    assert identity(1) == 1
    assert identity(None) is None
    assert identity(identity) == identity



# Generated at 2022-06-24 00:44:44.652344
# Unit test for function curried_map
def test_curried_map():
    from collections import defaultdict

    assert curried_map(lambda x: x * 3, [1, 2, 3]) == [3, 6, 9]
    assert curried_map(lambda x: x * 3, []) == []
    assert curried_map(lambda x: x * 3, "") == []
    assert curried_map(lambda x: x * 3, defaultdict(lambda: 5)) == []
    assert curried_map(lambda x: x * 3, (1, 2, 3)) == [3, 6, 9]
    assert curried_map(lambda x: x * 3, {1, 2, 3}) == [3, 6, 9]
    assert curried_map(lambda x: x * 3, "abc") == ["aaa", "bbb", "ccc"]
    #assert curried_map(lambda x

# Generated at 2022-06-24 00:44:51.227544
# Unit test for function curry
def test_curry():
    assert callable(curry(increase))
    assert curry(increase)(1) == 2
    assert curry(increase, 2)(1, 1) == 2



# Generated at 2022-06-24 00:44:58.628483
# Unit test for function memoize
def test_memoize():
    def add_one(x):
        print('add_one')
        return x + 1

    memoized_add_one = memoize(add_one)

    assert memoized_add_one(1) == 2
    assert memoized_add_one(1) == 2



# Generated at 2022-06-24 00:45:02.456538
# Unit test for function curry
def test_curry():
    import pytest

    curried_sum = curry(lambda x, y, z, w: x + y + z + w)
    result = curried_sum(1)
    result = curried_sum(2)
    result = curried_sum(3)
    result = curried_sum(4)
    assert result == 10



# Generated at 2022-06-24 00:45:05.231143
# Unit test for function compose
def test_compose():
    square = lambda x: x * x
    cube = lambda x: x * x * x
    result = compose(4, cube, square)

    assert result == 4096

    greater = lambda a, b: a > b
    result = compose(4, greater, square)

    assert not result

# Generated at 2022-06-24 00:45:10.442822
# Unit test for function increase
def test_increase():
    assert increase(1) == 2, 'increase(1) == 2'
    assert increase(2) == 3, 'increase(2) == 3'
    print('test_increase passed')


# Generated at 2022-06-24 00:45:17.792093
# Unit test for function compose
def test_compose():
    assert compose(
        42,
        lambda value: value + 2,
        lambda value: value + 2,
        lambda value: value + 2,
        lambda value: value + 2,
        lambda value: value + 2,
    ) == 54



# Generated at 2022-06-24 00:45:21.882551
# Unit test for function curried_filter
def test_curried_filter():
    assert [1, 3, 5] == curried_filter(lambda x: x % 2 == 1)([1, 2, 3, 4, 5])
    assert [1, 3, 5] == curried_filter(lambda x: x % 2 == 1, [1, 2, 3, 4, 5])



# Generated at 2022-06-24 00:45:23.784755
# Unit test for function increase
def test_increase():
    assert increase(2) == 3



# Generated at 2022-06-24 00:45:26.428682
# Unit test for function compose
def test_compose():
    f = lambda x: x * 2
    g = lambda y: y + 5
    h = lambda z: z - 1
    assert compose(10, f, g, h) == 27


# Generated at 2022-06-24 00:45:28.195579
# Unit test for function identity
def test_identity():
    assert identity('a') == 'a'
    assert identity(1) == 1
    assert identity(identity) == identity


# Generated at 2022-06-24 00:45:28.985082
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-24 00:45:31.900506
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(0) == 0
    assert identity(True) is True
    assert identity(False) is False
    assert identity('a') == 'a'
    assert identity('Aa') == 'Aa'
    assert identity(lambda a: a)



# Generated at 2022-06-24 00:45:32.536363
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:45:38.163370
# Unit test for function curry
def test_curry():
    print('***** Test for function curry *****')

    def sum_of_two_values(x, y):
        return x + y

    add = curry(sum_of_two_values)
    assert add(1)(3) == 4
    assert add(1)(3)(1) == 4



# Generated at 2022-06-24 00:45:41.320539
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 0)
    assert eq(1, eq(1, 1))


# Generated at 2022-06-24 00:45:51.849920
# Unit test for function cond
def test_cond():
    if cond([
        (lambda x: True, lambda x: 5),
        (lambda x: True, lambda x: 10),
        (lambda x: True, lambda x: 15)
    ])(11) == 5 and \
       cond([
           (lambda x: False, lambda x: 5),
           (lambda x: True, lambda x: 10),
           (lambda x: True, lambda x: 15)
       ])(11) == 10 and \
       cond([
           (lambda x: False, lambda x: 5),
           (lambda x: False, lambda x: 10),
           (lambda x: True, lambda x: 15)
       ])(11) == 15:
        print("Unit tests for function cond exit with result: True")
    else:
        print("Unit tests for function cond exit with result: False")



# Generated at 2022-06-24 00:45:57.121437
# Unit test for function memoize
def test_memoize():
    # Verify that the results of two calls to fibonacci are the same.
    @memoize
    def fib(n):
        if n < 2:
            return n
        return fib(n - 2) + fib(n - 1)

    assert fib(10) == fib(10)

    # Add verification that the two calls are actually different.
    @memoize
    def increment(x):
        return x + 1

    assert increment(3) != increment(3)

# Function takes input value and returns square value

# Generated at 2022-06-24 00:45:58.287081
# Unit test for function increase
def test_increase():
    assert increase(3) == 4



# Generated at 2022-06-24 00:46:00.219584
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(3, 4) == False


# Generated at 2022-06-24 00:46:02.558121
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x == 1, [1, 2, 3, 4, 5])([1]) == [1]



# Generated at 2022-06-24 00:46:07.757814
# Unit test for function curried_filter
def test_curried_filter():
    # Given
    collection = [1, 2, 3, 4]
    filterer = lambda value: value % 2 == 0

    # When
    result = curried_filter(filterer)(collection)

    # Then
    assert len(result) == 2
    assert result[0] == 2
    assert result[1] == 4



# Generated at 2022-06-24 00:46:10.332547
# Unit test for function curried_map
def test_curried_map():
    map_curried = curried_map(lambda x: x * 2)
    assert map_curried([1, 2, 3]) == [2, 4, 6]



# Generated at 2022-06-24 00:46:15.572172
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x < 4, [1, 2, 3]) == [1, 2, 3]
    assert curried_filter(lambda x: x > 4, [1, 2, 3]) == [1, 2, 3]
    assert curried_filter(lambda x: x > 4, [1, 2, 3, 4, 5]) == [4, 5]
    assert curried_filter(lambda x: x > 4, [1, 2, 3, 5, 6]) == [5, 6]
    assert curried_filter(lambda x: x + 1, [1, 2, 3, 5, 6]) == [1, 2, 3, 5, 6]


# Generated at 2022-06-24 00:46:17.980522
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(3)) == 3
    assert find([1, 2, 3], eq(4)) is None



# Generated at 2022-06-24 00:46:29.067794
# Unit test for function memoize
def test_memoize():
    from time import time
    @memoize
    def add(x, y):
        return x + y

    start = time()
    print(add(10, 20))
    print(add(10, 20))
    print(add(10, 20))
    print(add(10, 20))
    print(add(10, 20))
    print(add(10, 20))
    print(add(10, 20))
    print(add(10, 20))
    print(add(10, 20))
    print(add(10, 20))
    print(add(10, 20))
    print(add(10, 20))
    print(add(10, 20))
    print(add(10, 20))
    print(add(10, 20))
    print(add(10, 20))

# Generated at 2022-06-24 00:46:31.197830
# Unit test for function compose
def test_compose():
    a = compose(1, lambda x: x + 1, lambda x: x * 2, lambda x: x ** 2)
    assert a == 16

    b = compose(3, identity)
    assert b == 3


# Generated at 2022-06-24 00:46:33.380368
# Unit test for function identity
def test_identity():
    assert identity(0) == 0
    assert identity("0") == "0"


# Generated at 2022-06-24 00:46:34.851058
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(2) == 3


# Generated at 2022-06-24 00:46:35.848423
# Unit test for function increase
def test_increase():
    assert increase(5) == 6



# Generated at 2022-06-24 00:46:41.856261
# Unit test for function find
def test_find():
    find_test_list = [1, 2, 3, 4, 5, 6]
    find_result = find(find_test_list, lambda x: x % 2 == 0)
    assert find_result == 2

    find_result_not_exists = find(find_test_list, lambda x: x > 10)
    assert find_result_not_exists is None



# Generated at 2022-06-24 00:46:46.049851
# Unit test for function curried_map
def test_curried_map():
    map_fn = curried_map(lambda x: x + 1)
    assert type(map_fn) == function
    assert map_fn([1, 2, 3]) == [2, 3, 4]
    assert map_fn([1, 2, 3, 4, 5, 6]) == [2, 3, 4, 5, 6, 7]



# Generated at 2022-06-24 00:46:47.900077
# Unit test for function memoize
def test_memoize():
    fn = memoize(lambda x: x + x)
    assert fn(1) == 2
    assert fn(2) == 4


# Generated at 2022-06-24 00:46:52.132537
# Unit test for function curried_filter
def test_curried_filter():
    filter_func = curried_filter(eq(1))
    assert filter_func([1, 2, 3]) == [1]



# Generated at 2022-06-24 00:47:00.287800
# Unit test for function memoize
def test_memoize():
    def expensive_func(v):
        print(f"expensive function was called with argument {v}")
        return v ** 2

    memoized_exp_func = memoize(expensive_func)

    assert memoized_exp_func(2) == 4
    assert memoized_exp_func(2) == 4
    assert memoized_exp_func(3) == 9
    assert memoized_exp_func(2) == 4
    assert memoized_exp_func(3) == 9


if __name__ == '__main__':
    test_memoize()

# Generated at 2022-06-24 00:47:06.661824
# Unit test for function memoize
def test_memoize():
    @memoize
    def fib(n):
        if n == 0:
            return 0
        if n == 1:
            return 1
        return fib(n - 1) + fib(n - 2)

    assert fib(0) == 0
    assert fib(1) == 1
    assert fib(2) == 1
    assert fib(3) == 2
    assert fib(4) == 3
    assert fib(5) == 5
    assert fib(6) == 8
    assert fib(7) == 13
    assert fib(8) == 21
    assert fib(9) == 34
    assert fib(10) == 55



# Generated at 2022-06-24 00:47:12.905896
# Unit test for function curried_map
def test_curried_map():
    """
    Test function curried_map

    :returns:
    :rtype:
    """
    list1 = [1, 2, 3, 4]
    assert curried_map(lambda x: x + x, list1) == [2, 4, 6, 8]
    assert curried_map(increase)(list1) == [2, 3, 4, 5]
    assert curried_map(increase, list1) == [2, 3, 4, 5]



# Generated at 2022-06-24 00:47:21.481009
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z=3: x + y + z)(1)(2)   == 6
    assert curry(lambda x, y, z=3: x + y + z)(1, 2)  == 6
    assert curry(lambda x, y, z=3: x + y + z)(1)     == 4
    assert curry(lambda x, y, z=3: x + y + z)(1, 2, 3) == 6
    assert curry(lambda x, y, z=3: x + y + z, 4)(1)  == 4

# Generated at 2022-06-24 00:47:27.634735
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(True) is True
    assert identity(False) is False
    assert identity([1, 2, 3]) == [1, 2, 3]
    assert identity((1, 2, 3)) == (1, 2, 3)
    assert identity({1: 1, 2: 2}) == {1: 1, 2: 2}
    assert id(identity([])) == id([])
    assert id(identity({})) == id({})
    assert id(identity(())) == id(())



# Generated at 2022-06-24 00:47:32.852318
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(5) == 6
    assert increase(0) == 1
    assert increase(-5) == -4
    assert increase(2.5) == 3.5



# Generated at 2022-06-24 00:47:35.536564
# Unit test for function identity
def test_identity():
    assert identity('foo') == 'foo'
    assert identity(1) == 1
    assert identity([1, 2]) == [1, 2]
    assert identity(None) is None


# Generated at 2022-06-24 00:47:36.783924
# Unit test for function increase
def test_increase():
    assert increase(10) == 11
    assert increase(0) == 1



# Generated at 2022-06-24 00:47:43.506782
# Unit test for function curry
def test_curry():
    curried_add = curry(lambda a, b, c: a + b + c)
    assert curried_add(1, 2, 3) == 6
    assert curried_add(1, 2)(3) == 6
    assert curried_add(1)(2, 3) == 6
    assert curried_add(1)(2)(3) == 6
    # test for currying functions which take a keyword argument
    curried_add2 = curry(lambda x, y=10, z=20: x + y + z)
    assert curried_add2(1, 2, 3) == 6
    assert curried_add2(1) == 31
    assert curried_add2(1, 2) == 23
    assert curried_add2(1, z=2) == 13



# Generated at 2022-06-24 00:47:47.600702
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(False) == False
    assert identity('string_value') == 'string_value'
    assert identity(None) is None


# Generated at 2022-06-24 00:47:51.605510
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(3) == 4


# Generated at 2022-06-24 00:47:56.592345
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6])(None) == [2, 4, 6]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6])(None) == [2, 4, 6]



# Generated at 2022-06-24 00:48:00.138120
# Unit test for function find
def test_find():
    assert find([], eq(0)) is None, 'Empty collection and any argument should return None'
    assert None == find([0, 1, 2], eq(3)), 'Any collection, not existing argument should return None'
    assert 0 == find([0, 1, 2], eq(0)), 'Find a element as a first'
    assert 1 == find([2, 1, 0], eq(1)), 'Find a element as a last'
    assert 1 == find([1, 2, 1], eq(1)), 'Find a element as a duplicate 1st'
    assert 1 == find([1, 2, 1], eq(2)), 'Find a element as a duplicate 2nd'



# Generated at 2022-06-24 00:48:05.595753
# Unit test for function cond
def test_cond():

    def condition_equal_zero(number):
        return number == 0

    def execute_return_zero(number):
        return 0

    def condition_equal_ten(number):
        return number == 10

    def execute_return_ten(number):
        return 10

    def condition_equal_one(number):
        return number == 1

    def execute_return_one(number):
        return 1

    condition_list = [
        (condition_equal_zero, execute_return_zero),
        (condition_equal_ten, execute_return_ten),
        (condition_equal_one, execute_return_one)
    ]

    cond_function = cond(condition_list)
    assert cond_function(0) == 0
    assert cond_function(10) == 10
    assert cond_function(1) == 1


# Unit

# Generated at 2022-06-24 00:48:11.814160
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 3, 4, 5, 6]

    less_than_four = curried_filter(lambda x: x < 4)
    assert less_than_four(collection) == [1, 2, 3]

    is_even = curried_filter(lambda x: x % 2 == 0)
    assert is_even(collection) == [2, 4, 6]



# Generated at 2022-06-24 00:48:15.528646
# Unit test for function curry
def test_curry():
    def funk(x, y, z=2):
        return x + y + z

    assert funk(1, 2) == 5
    assert funk(1, 2, 3) == 6
    c = curry(funk)
    assert c(1)(2) == 5
    assert c(1)(2)(3) == 6



# Generated at 2022-06-24 00:48:16.537216
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2


# Generated at 2022-06-24 00:48:19.054777
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(1), [1, 2, 3]) == [1]
    assert curry(curried_filter)(eq(1))([1, 2, 3]) == [1]
    assert curry(curried_filter)(eq(1))([1, 2, 3]) == [1]



# Generated at 2022-06-24 00:48:25.964967
# Unit test for function find
def test_find():
    print('Testing find function')
    assert find([], eq(0, 1)) is None
    assert find(['a'], eq(0, 1)) is None
    assert find(['a'], eq('a', 'b')) is None
    assert find([], eq('a', 'a')) is None
    assert find(['a'], eq('a', 'a')) == 'a'
    assert find(['a', 'b'], eq('a', 'a')) == 'a'
    assert find(['a', 'b'], eq('b', 'b')) == 'b'
    assert find(['a', 'b', 'c'], eq('b', 'b')) == 'b'
    assert find(['a', 'b', 'c'], eq('a', 'b')) is None

# Generated at 2022-06-24 00:48:28.039999
# Unit test for function curried_filter
def test_curried_filter():
    # Test if curried_filter returns true if param 'collection' contains item which satisfy param 'filterer'
    assert curried_filter(lambda x: x > 3, [1, 2, 3, 4, 5])([4, 5]) == [4, 5]

# Generated at 2022-06-24 00:48:31.864823
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x % 2 == 0) == 2
    assert find([1, 3, 5], lambda x: x % 2 == 0) is None
    assert find([], lambda x: x % 2 == 0) is None


if __name__ == "__main__":
    test_find()

# Generated at 2022-06-24 00:48:40.675474
# Unit test for function curry
def test_curry():
    with unittest.mock.patch(
        '__main__.curry',
        wraps=curry
    ) as mock_curry:
        def add(a, b):
            return a + b

        curried_add = curry(add)
        curried_add(2)(2)
        curried_add(2)(3)

        expected_calls = [
            unittest.mock.call(add, args_count=2),
            unittest.mock.call(mock_curry.return_value, args_count=2),
            unittest.mock.call(mock_curry.return_value, args_count=1)
        ]

        assert mock_curry.call_count == 3
        assert mock_curry.call_args_list == expected_calls

# Generated at 2022-06-24 00:48:42.783801
# Unit test for function increase
def test_increase():
    # Given
    value = 4
    # When
    actual_result = increase(value)
    # Then
    assert actual_result == value + 1



# Generated at 2022-06-24 00:48:47.832894
# Unit test for function compose
def test_compose():
    def add_five(num: int) -> int:
        return num + 5

    def times_three(num: int) -> int:
        return num * 3

    def curried_plus_5(num: int) -> int:
        return add_five(num)

    compose_example = compose(5, curried_plus_5, times_three)
    assert compose_example == 30



# Generated at 2022-06-24 00:48:52.102729
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity('a') == 'a'



# Generated at 2022-06-24 00:48:55.401855
# Unit test for function eq
def test_eq():
    assert(eq(1, 2) == eq(1)(2))
    assert(eq(2, 2) == eq(2)(2))
    assert(eq(1, 1) == eq(1)(1))
    assert(eq(2, 1) == eq(2)(1))



# Generated at 2022-06-24 00:48:58.022003
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 1) == 1
    assert find([1, 2, 3], lambda x: x == 4) is None
    assert find([], lambda x: x == 4) is None



# Generated at 2022-06-24 00:49:02.031713
# Unit test for function compose
def test_compose():
    assert compose(
        42,
        lambda x: x + 1,
        lambda x: x + 2,
    ) == 45



# Generated at 2022-06-24 00:49:07.041979
# Unit test for function compose
def test_compose():
    assert compose(1, increase) == 2
    assert compose(1, increase, increase, increase) == 4



# Generated at 2022-06-24 00:49:14.783602
# Unit test for function curry
def test_curry():
    def sum(a, b, c):
        return a + b + c

    sum2args = curry(sum, 2)
    assert sum2args(1, 2) == 3
    assert sum2args(1)(2) == 3

    sum3args = curry(sum, 3)
    assert sum3args(1, 2, 3) == 6
    assert sum3args(1)(2, 3) == 6
    assert sum3args(1, 2)(3) == 6
    assert sum3args(1)(2)(3) == 6



# Generated at 2022-06-24 00:49:17.135327
# Unit test for function identity
def test_identity():
    assert identity(0) == 0, 'identity should return first argument'
    assert identity('test') == 'test', 'identity should return first argument'


# Generated at 2022-06-24 00:49:22.005466
# Unit test for function compose
def test_compose():
    array_of_str = ['1', '2', '3']
    array_of_int = [1, 2, 3]
    map_to_int = compose(map, int)
    assert map_to_int(array_of_str) == array_of_int
    increase_all = compose(map, increase)
    assert increase_all(array_of_int) == [2, 3, 4]
    increase_all_reverse = compose(increase, map)
    assert increase_all_reverse(array_of_int) == [2, 3, 4]



# Generated at 2022-06-24 00:49:26.970395
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(2))([1, 2, 3]) == [2]
    assert curried_filter(eq(2))([1, 3]) == []
# end test
# UNit test for function curried_map

# Generated at 2022-06-24 00:49:33.681183
# Unit test for function curried_map
def test_curried_map():
    """
    Test case for function curried_map.
    """
    collection = [1, 2, 3]
    predefined_mapper = lambda x: x**2 + 1
    double_collection = curried_map(predefined_mapper)(collection)
    assert double_collection == [2, 5, 10],\
        "Function curried_map must correctly map collection"



# Generated at 2022-06-24 00:49:39.752307
# Unit test for function curried_map
def test_curried_map():
    print('test curried_map')
    assert curried_map(identity, []) == []
    assert curried_map(identity, [1, 2, 3, 4]) == [1, 2, 3, 4]
    assert curried_map(lambda x: x * x, [1, 2, 3, 4]) == [1, 4, 9, 16]
    assert curried_map(lambda x: x + 1, [1, 2, 3, 4]) == [2, 3, 4, 5]
    print('success')



# Generated at 2022-06-24 00:49:46.793553
# Unit test for function curry
def test_curry():
    def sum(a, b, c):
        return a + b + c

    sum = curry(sum)

    assert sum(1, 2, 3) == 6
    assert sum(1, 2)(3) == 6
    assert sum(1)(2, 3) == 6
    assert sum(1)(2)(3) == 6
    assert sum(1, 2, 3, 4) == 6
    assert sum(1, 2, 3)(4) == 6
    assert sum(1)(2)(3)(4) == 6
    assert sum(1)(2, 3, 4) == 6
    assert sum(1, 2)(3, 4) == 6


# Generated at 2022-06-24 00:49:49.732040
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(0) == 0
    assert identity([1]) == [1]
    assert identity(True) == True
    assert identity(False) == False
    assert identity(None) == None


# Generated at 2022-06-24 00:49:54.644773
# Unit test for function pipe
def test_pipe():
    # TODO: replace with assert functions
    # TODO: replace with assert functions
    assert pipe(3, lambda n: n + 1, lambda n: n * 3) == 12
    assert pipe(3, lambda n: n + 1, lambda n: n * 3, lambda n: n ** 2) == 144



# Generated at 2022-06-24 00:49:57.233313
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity("test") == "test"
    assert identity(dict()) == dict()



# Generated at 2022-06-24 00:49:59.705442
# Unit test for function compose
def test_compose():
    """
    Testing compose function

    :returns: None
    :rtype: None
    """
    assert compose(2, increase, increase) == 4



# Generated at 2022-06-24 00:50:07.529585
# Unit test for function curried_filter
def test_curried_filter():
    from functional_python import functional_list
    from functional_python import functional_string

    letters_list = list('abcdefghijklmnopqrstuvwxyz')

    # Using import from package functional_list
    assert functional_list.curried_filter(lambda x: x == 'a', letters_list) == ['a']
    assert functional_list.curried_filter(lambda x: x == 'b', letters_list) == ['b']

    # Using import from package functional_string
    assert functional_string.curried_filter(lambda x: x == 'a', letters_list) == ['a']
    assert functional_string.curried_filter(lambda x: x == 'b', letters_list) == ['b']

    # Using import from package functional_python

# Generated at 2022-06-24 00:50:14.161340
# Unit test for function curry
def test_curry():
    print('test_curry')

    @curry
    def add(x: int, y: int, z: int) -> int:
        return x + y + z

    assert add(1, 2, 3) == 6
    assert add(1, 2)(3) == 6
    assert add(1)(2, 3) == 6
    assert add(1)(2)(3) == 6



# Generated at 2022-06-24 00:50:16.490208
# Unit test for function eq
def test_eq():
    assert eq(1, 2) is False
    assert eq(1, 1) is True



# Generated at 2022-06-24 00:50:20.242383
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda value: value == 2) == 2
    assert find([1, 2, 3, 4], lambda value: value > 10) is None



# Generated at 2022-06-24 00:50:25.231591
# Unit test for function find
def test_find():
    collection = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    key = lambda value: value > 1
    assert(find(collection, key) == 2)



# Generated at 2022-06-24 00:50:35.331389
# Unit test for function cond
def test_cond():
    is_zero = lambda value: value == 0
    is_one = lambda value: value == 1
    is_two = lambda value: value == 2
    is_other = lambda value: True
    identity_function = lambda value: value

    function_to_test = cond([
        (is_zero, lambda: 'zero'),
        (is_one, lambda: 'one'),
        (is_two, lambda: 'two'),
        (is_other, lambda: 'other')
    ])

    assert function_to_test(1) == 'one'
    assert function_to_test(2) == 'two'
    assert function_to_test(3) == 'other'
    assert function_to_test(1) == 'one'



# Generated at 2022-06-24 00:50:42.336920
# Unit test for function curried_map
def test_curried_map():
    # Value to test
    value = range(10)
    # Initialization of function
    curried_increase = curried_map(increase)
    # Mapp all value by increase function
    curried_increase_all = curried_increase(value)

    # Verify
    assert curried_increase_all == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]



# Generated at 2022-06-24 00:50:43.436521
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:50:44.669783
# Unit test for function identity
def test_identity():
    assert identity(1) == 1


# Generated at 2022-06-24 00:50:47.293497
# Unit test for function compose
def test_compose():
    assert compose(4, identity, increase) == 5
    assert compose('a', lambda _: 'a', lambda _: 'b') == 'b'



# Generated at 2022-06-24 00:50:51.925829
# Unit test for function compose
def test_compose():
    assert compose(2, increase, increase) == 4
    assert compose('a', lambda x: x.upper(), lambda x: x * 2) == 'AA'



# Generated at 2022-06-24 00:50:57.359063
# Unit test for function curry
def test_curry():
    assert eq(curry(increase)(1), 2)
    double = lambda x, y: x * 2 + y
    assert eq(curry(double)(10), lambda y: 10 * 2 + y)
    assert eq(double(10, 20), curry(double)(10)(20))
    assert eq(double(10, 20), curry(double)(10, 20))



# Generated at 2022-06-24 00:50:59.976994
# Unit test for function pipe
def test_pipe():
    value = pipe(
        1,
        lambda arg: arg +1,
        lambda arg: arg * 2
    )
    assert value == 4



# Generated at 2022-06-24 00:51:05.081729
# Unit test for function identity
def test_identity():
    assert identity(1) == compose(1, identity)
    assert identity(1) == compose(1, pipe(identity))
    assert identity(1) == pipe(1, identity)
    assert identity(1) == pipe(1, identity)



# Generated at 2022-06-24 00:51:05.838846
# Unit test for function identity
def test_identity():
    assert identity(0) == 0



# Generated at 2022-06-24 00:51:07.718889
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(5)) is None
    assert find([1, 2, 3], eq(2)) == 2



# Generated at 2022-06-24 00:51:12.742431
# Unit test for function curried_filter
def test_curried_filter():
    collection, f = range(5), lambda x: x % 2 == 1
    assert curried_filter(f, collection) == [1, 3]
    assert curried_filter(f)(collection) == [1, 3]
    assert curried_filter(f, range(3)) == [1]



# Generated at 2022-06-24 00:51:21.576240
# Unit test for function cond
def test_cond():
    from functools import reduce

    functions_list = [
        (lambda x: x % 2, lambda x: x - 1),
        (lambda x: x < 0, lambda x: -x),
        (lambda x: x % 5 == 0, lambda x: x * 3)
    ]

    # with reduce
    def cond_reduce(list_of_functions):
        return reduce(
            lambda curried, tuple_of_functions:
            lambda argument:
            tuple_of_functions[0](argument) and tuple_of_functions[1](argument) or curried(argument),
            list_of_functions[::-1],
            lambda x: x
        )

    # with if-elif-else

# Generated at 2022-06-24 00:51:24.354219
# Unit test for function memoize
def test_memoize():
    import time

    def long_function(value: int):
        time.sleep(1)  # emulate long operation
        return value

    long_function_memoized = memoize(long_function)
    assert long_function(1) == long_function_memoized(1)
    print('test_memoize: function memoize is correct')

# Generated at 2022-06-24 00:51:25.762903
# Unit test for function eq
def test_eq():
    assert eq(2, 2) == True
    assert eq(2, 3) == False
    assert eq('asdf', 'asdf') == True
    assert eq('asdf', 'Asdf') == False



# Generated at 2022-06-24 00:51:30.898212
# Unit test for function find
def test_find():
    assert find(
        collection=[1, 2, 3, 4, 5, 6],
        key=lambda item: item > 3
    ) == 4
    assert find(
        collection=[1, 2, 3, 4, 5, 6],
        key=lambda item: item > 6
    ) is None


# Generated at 2022-06-24 00:51:35.682189
# Unit test for function curry
def test_curry():
    """
    Test for function curry
    """
    fn = lambda x, y: x + y
    increment = curry(fn)
    assert(increment(1)(2) == fn(1, 2))
    assert(increment(1, 2) == fn(1, 2))



# Generated at 2022-06-24 00:51:38.406918
# Unit test for function pipe
def test_pipe():
    def add(a, b):
        return a + b

    def multiply(x):
        return x * x

    assert pipe(5, multiply, add(5), multiply) == 100



# Generated at 2022-06-24 00:51:40.335996
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2
    assert increase(2) == 3



# Generated at 2022-06-24 00:51:41.741846
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-24 00:51:44.934706
# Unit test for function pipe
def test_pipe():
    class Person:
        def __init__(self, age):
            self.age = age

    assert pipe([Person(10), Person(20), Person(30)],
                curried_filter(lambda person: person.age > 15),
                curried_map(lambda person: person.age)) == [20, 30]



# Generated at 2022-06-24 00:51:54.517130
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b, c, d: (a, b, c, d))(1)(
        2)(3)(4) == ((1, 2, 3, 4))
    assert curry(lambda a, b, c, d: (a, b, c, d))(1, 2)(
        3)(4) == ((1, 2, 3, 4))
    assert curry(lambda a, b, c, d: (a, b, c, d))(1)(
        2, 3)(4) == ((1, 2, 3, 4))
    assert curry(lambda a, b, c, d: (a, b, c, d))(1)(
        2)(3, 4) == ((1, 2, 3, 4))

# Generated at 2022-06-24 00:51:57.140186
# Unit test for function identity
def test_identity():
    assert None == identity(None)
    assert [1] == identity([1])
    assert 1 == identity(1)
    assert -123 == identity(-123)



# Generated at 2022-06-24 00:51:58.943032
# Unit test for function increase
def test_increase():
    """ assert for increase """
    assert (increase(4) == 5)


# Generated at 2022-06-24 00:52:03.967595
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(1) == 1
    assert identity(1) != 2



# Generated at 2022-06-24 00:52:06.880257
# Unit test for function compose
def test_compose():
    assert compose(5, increase) == 6
    assert compose(5, increase, increase) == 7
    assert compose(3, curried_filter(eq(1)), curried_map(increase)) == []
    assert compose(range(3), curried_filter(eq(1)), curried_map(increase)) == [2]



# Generated at 2022-06-24 00:52:10.498552
# Unit test for function cond
def test_cond():
    def test_fn(value):
        return cond([
            (eq(1), identity),
            (eq(2), increase),
            (eq(3), increase),
        ])(value)

    assert test_fn(1) == 1
    assert test_fn(2) == 3
    assert test_fn(3) == 4
    assert test_fn(10) is None



# Generated at 2022-06-24 00:52:14.074405
# Unit test for function curried_filter
def test_curried_filter():
    def greater_than_three(x: int):
        return x > 3

    assert curried_filter(greater_than_three, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]) == [4, 5, 6, 7, 8, 9]



# Generated at 2022-06-24 00:52:18.363587
# Unit test for function compose
def test_compose():
    def add_ten(value):
        return value + 10

    def multiply_by_two(value):
        return value * 2

    result = compose(0, multiply_by_two, add_ten)
    assert(result == 20)



# Generated at 2022-06-24 00:52:21.948976
# Unit test for function curry
def test_curry():
    curried_power = curry(lambda x, y: pow(x, y), args_count=2)
    assert(curried_power(2)(3) == 8)



# Generated at 2022-06-24 00:52:29.593471
# Unit test for function cond
def test_cond():
    def is_pos(n):
        return n > 0

    def square(x):
        return x * x

    def cube(x):
        return x * x * x

    assert cond([(is_pos, square), (is_pos, cube)], 1) == 1
    assert cond([(is_pos, square), (is_pos, cube)], -1) == 1
    assert cond([(is_pos, square), (is_pos, cube)], 2) == 8
    assert cond([(is_pos, square), (is_pos, cube)], -2) == 8



# Generated at 2022-06-24 00:52:31.732981
# Unit test for function increase
def test_increase():
    assert 4 == increase(3)



# Generated at 2022-06-24 00:52:35.390806
# Unit test for function eq
def test_eq():
    assert eq(3, 3) == True
    assert eq(3, 1) == False
    assert eq(3)(3) == True
    assert eq(3)(1) == False


# Generated at 2022-06-24 00:52:41.239359
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(0))([0, 1, 2, 0, 3, 0, 4]) == [0, 0, 0]
    assert curried_filter(eq(0))([1, 2, 3, 4]) == []



# Generated at 2022-06-24 00:52:48.974168
# Unit test for function cond
def test_cond():
    def is_even(number: int) -> bool:
        return number % 2 == 0

    def is_odd(number: int) -> bool:
        return (not is_even(number))

    test_cond_function = cond([
        (is_even, identity),
        (is_odd, increase)
    ])

    assert (1 == test_cond_function(1))
    assert (2 == test_cond_function(2))



# Generated at 2022-06-24 00:52:53.690139
# Unit test for function memoize
def test_memoize():
    fib = lambda n: n if n < 2 else fib(n-1) + fib(n-2)
    fib = memoize(fib)
    assert fib(4) == 3
    assert fib(4) == 3


if __name__ == "__main__":
    test_memoize()

# Generated at 2022-06-24 00:52:57.108219
# Unit test for function memoize
def test_memoize():
    # pylint: disable=unused-variable
    add1 = lambda x: x + 1
    add1 = memoize(add1)
    print(add1(5))
    print(add1(5))


if __name__ == '__main__':
    test_memoize()

# Generated at 2022-06-24 00:53:03.878013
# Unit test for function cond
def test_cond():
    def cnd1(a):
        return a == 1
    def cnd2(a):
        return a == 2
    def exec1(a):
        return "exec1"
    def exec2(a):
        return "exec2"
    cond_test = cond([(cnd1, exec1), (cnd2, exec2)])
    assert cond_test(1) == "exec1"
    assert cond_test(2) == "exec2"



# Generated at 2022-06-24 00:53:07.643365
# Unit test for function curried_filter
def test_curried_filter():
    """
    Test curried_filter function.

    :returns: void
    :rtype: None
    """
    collection = (1, 2, 3, 4, 5)
    func = curried_filter(lambda x: x % 2 == 0)
    result = func(collection)
    assert result == (2, 4)



# Generated at 2022-06-24 00:53:11.796865
# Unit test for function memoize
def test_memoize():
    input_list: List[int] = list(range(11))
    fibonacci: Callable[[int], int] = memoize(lambda n: n if n < 2 else fibonacci(n - 2) + fibonacci(n - 1))
    assert fibonacci(10) == 55
    result = map(fibonacci, input_list)
    assert list(result) == [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55]

# Generated at 2022-06-24 00:53:14.369099
# Unit test for function pipe
def test_pipe():
    assert pipe(4, identity, increase, increase) == 6
    assert pipe(4, increase, increase, identity) == 6
    assert pipe(4, increase, identity, increase) == 6


# Generated at 2022-06-24 00:53:19.787183
# Unit test for function increase
def test_increase():
    print(increase(2))
    curried_increase = curry(increase)
    print(curried_increase(2))
    print(curry(increase)(2)(3)(4))
    print(curry(increase, 1)(2))
    print(curry(increase, 3)(2)(3)(4))



# Generated at 2022-06-24 00:53:24.187410
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 0) == False
    assert eq(1, 1)(1) == True
    assert eq(1)(1)(1) == True
    assert eq(1)(1)(0) == False



# Generated at 2022-06-24 00:53:28.599602
# Unit test for function curry
def test_curry():
    def power(base, exp):
        return base**exp

    curried_power = curry(power)
    two_in_power_two = curried_power(2)
    assert two_in_power_two(2) == 4, "expected 4"



# Generated at 2022-06-24 00:53:30.151674
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(True) == True
    assert identity("Hello, World!") == "Hello, World!"


# Generated at 2022-06-24 00:53:31.894932
# Unit test for function compose
def test_compose():
    func = lambda x: x + 1
    func2 = lambda x: x * 2
    assert compose(2, func2, func) == 5



# Generated at 2022-06-24 00:53:39.433182
# Unit test for function curried_map
def test_curried_map():
    """Test for curried_map function"""
    test_list = [1, 2, 3, 4]
    curried_map_lambda = lambda x: x + 1
    curried_map_func = curried_map(curried_map_lambda)
    assert curried_map_lambda(test_list[0]) == 2
    assert curried_map_func(test_list)[0] == 2
    assert curried_map(lambda x: x + 1)(test_list)[0] == 2



# Generated at 2022-06-24 00:53:44.172504
# Unit test for function find
def test_find():
    collection = [
        {
            'a': 1,
        },
        {
            'a': 2,
        }
    ]
    key = compose(
        eq,
        lambda x: x['a']
    )
    assert find(collection, key)({'a': 1}) == {'a': 1}
    assert find(collection, key)({'a': 2}) == {'a': 2}


# Generated at 2022-06-24 00:53:50.812603
# Unit test for function pipe
def test_pipe():
    """
    Unit test for function pipe
    """
    assert pipe(1, increase, increase, increase) == 4
    assert pipe(1.0, lambda x: int(x) * 2.0, lambda x: f'{x}') == '4.0'
    assert pipe('g', lambda x: x.upper(), lambda x: '{}!'.format(x)) == 'G!'



# Generated at 2022-06-24 00:53:59.241274
# Unit test for function curried_map
def test_curried_map():
    """
    Unit test for function curried_map.
    """
    print("test_curried_map")
    assert curried_map(lambda x: x + 2)([1, 2, 3]) == [3, 4, 5]
    assert curried_map(lambda x: x + 2)([1, 2, 3, 4]) == [3, 4, 5, 6]
    assert curried_map(lambda x: x + 2)([1, 2, 3, 4, 5]) == [3, 4, 5, 6, 7]
    print("test_curried_map is passed")


# Generated at 2022-06-24 00:54:03.331286
# Unit test for function pipe
def test_pipe():
    assert pipe(10, identity, increase, increase) == 12
    assert pipe(10, identity) == 10
    assert pipe(10, increase) == 11
    assert pipe(10, [increase, increase]) == 12



# Generated at 2022-06-24 00:54:04.291469
# Unit test for function identity
def test_identity():
    assert identity(0) == 0



# Generated at 2022-06-24 00:54:11.074649
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: [x, y, z])(1)(2)(3) == [1, 2, 3]
    assert curry(lambda x, y: x ** y)(5)(5) == 3125
    assert curry(print)(1)(2)(3)(4)(5) is None
    assert curry(print)(1)(2)(3)(4)(5)(6)(7)(8)(9)(10)(11)(12)(13)(14) is None



# Generated at 2022-06-24 00:54:17.812328
# Unit test for function memoize
def test_memoize():
    def square(value):
        return value * value

    def assert_square_result(value):
        assert square(value) == square_memoized(value)

    square_memoized = memoize(square)
    assert_square_result(2)
    assert_square_result(4)
    assert_square_result(4)
    assert_square_result(2)

