

# Generated at 2022-06-24 00:44:19.608257
# Unit test for function memoize
def test_memoize():
    def test_fn(x):
        test_fn.calls_count += 1
        return x * x * x

    test_fn.calls_count = 0

    memoized_fn = memoize(test_fn)

    assert memoized_fn(1) == 1
    assert memoized_fn(1) == 1
    assert memoized_fn(1) == 1
    assert memoized_fn(1) == 1
    assert memoized_fn(1) == 1
    assert memoized_fn(2) == 8
    assert memoized_fn(8) == 512
    assert memoized_fn(2) == 8
    assert memoized_fn(3) == 27
    assert memoized_fn(3) == 27
    assert memoized_fn(8) == 512
    assert memoized_fn(2) == 8


# Generated at 2022-06-24 00:44:22.718050
# Unit test for function curried_map
def test_curried_map():
    collection = [1, 2, 3]
    mapper = lambda x: x + 1

    assert curried_map(mapper)(collection) == [2, 3, 4]
    assert curried_map(mapper, collection) == [2, 3, 4]



# Generated at 2022-06-24 00:44:25.470059
# Unit test for function eq
def test_eq():
    assert eq(True) is True
    assert eq(True, True) is True
    assert eq(True, False) is False
    assert eq('test', 'test') is True
    assert eq('test')('test') is True
    assert eq('test', 'test1') is False



# Generated at 2022-06-24 00:44:29.229311
# Unit test for function identity
def test_identity():
    assert identity(1) == 1


# Generated at 2022-06-24 00:44:30.194874
# Unit test for function identity
def test_identity():
    assert identity(2) == 2


# Generated at 2022-06-24 00:44:35.406036
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, '1') is False
    assert eq(1, 1, 1) is True
    assert eq(1, 2, 1) is False
    assert eq(1)(1) is True
    assert eq(1)(1, 1) is True
    assert eq(1)(2, 1) is False
    assert eq(1, 1)(1) is True
    assert eq(1, 1)(2, 1) is False



# Generated at 2022-06-24 00:44:37.903393
# Unit test for function compose
def test_compose():
    assert compose(
        1,
        increase,
        increase
    ) == 3
    return 'Pass'



# Generated at 2022-06-24 00:44:41.641802
# Unit test for function compose
def test_compose():
    assert compose(
        1,
        lambda x: x + 5,
        lambda x: x * 2
    ) == (1 + 5) * 2

    assert compose(
        'a',
        lambda x: x + 'b',
        lambda x: x + 'c'
    ) == 'a' + 'b' + 'c'



# Generated at 2022-06-24 00:44:42.707132
# Unit test for function pipe
def test_pipe():
    assert pipe(5, increase, increase) == 7



# Generated at 2022-06-24 00:44:45.555711
# Unit test for function memoize
def test_memoize():
    def factorial(num):
        # Use memoization to avoid the recursive call
        return num if num == 1 else num * memoized_factorial(num - 1)

    memoized_factorial = memoize(factorial)

    assert (memoized_factorial(5) == 120)

# Generated at 2022-06-24 00:44:52.200926
# Unit test for function find
def test_find():
    collection = [1, 2, 3, 4, 5]
    assert find(collection, lambda value: value == 1) == 1
    assert find(collection, lambda value: value % 2 == 0) == 2
    assert find(collection, lambda value: value > 5) is None



# Generated at 2022-06-24 00:44:54.372213
# Unit test for function curried_map
def test_curried_map():
    assert [1, 2, 3] == curried_map(identity, [1, 2, 3])
    assert [1, 2, 3] == curried_map(increase)([0, 1, 2])



# Generated at 2022-06-24 00:45:00.877259
# Unit test for function curry
def test_curry():
    @curry
    def curried_adder(x, y, z):
        return x + y + z

    assert curried_adder(1)(2)(3) == 6
    assert curried_adder(1, 2)(3) == 6
    assert curried_adder(1)(2, 3) == 6
    assert curried_adder(1, 2, 3) == 6



# Generated at 2022-06-24 00:45:06.301666
# Unit test for function cond
def test_cond():
    assert (cond([
        (lambda value: value == 1, lambda _: "one"),
        (lambda value: value == 2, lambda _: "two"),
        (lambda value: value == 3, lambda _: "three")
    ])(2) == "two")



# Generated at 2022-06-24 00:45:07.310309
# Unit test for function pipe
def test_pipe():
    assert pipe(0, increase, increase) == 2



# Generated at 2022-06-24 00:45:09.631386
# Unit test for function find
def test_find():
    l = [1, 2, 3, 4, 5]
    a = 2
    assert find(l, lambda x: x == a) == a
    b = 10
    assert find(l, lambda x: x == b) is None



# Generated at 2022-06-24 00:45:11.717808
# Unit test for function compose
def test_compose():
    assert compose('a', lambda x: x + 'b', lambda x: x + 'c') == 'abc'
    assert compose(True, lambda x: not x, lambda x: not x) == False



# Generated at 2022-06-24 00:45:16.020402
# Unit test for function eq
def test_eq():
    """
    Test if eq function return true if equal two parameters.

    :returns:
    :rtype:
    """
    test_array = [True, False, True, True, True, True]
    cmp_array = [True, False, True, True, True, True]
    output_array = list(map(lambda cmp_value: eq(True)(cmp_value), cmp_array))

    assert test_array == output_array



# Generated at 2022-06-24 00:45:19.692991
# Unit test for function pipe
def test_pipe():
    data = [1, 2, 3, 4, 5, 6]
    even = lambda x: x % 2 == 0

    result = pipe(
        data,
        partial(curried_filter, even),
        partial(curried_map, increase),
    )

    assert result == [3, 5, 7]



# Generated at 2022-06-24 00:45:23.692367
# Unit test for function curry
def test_curry():
    curry_test = curry(lambda x, y: x + y)
    assert curry_test(1)(2) == curry_test(1, 2)
    assert curry_test(1, 2) == 3


# Generated at 2022-06-24 00:45:26.346622
# Unit test for function find
def test_find():
    assert find([10, 20, 30, 40], lambda x: x == 30) == 30
    assert find([10, 20, 30, 40], lambda x: x == 25) is None



# Generated at 2022-06-24 00:45:29.021264
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity('id') == 'id'
    assert identity([1, 2, 3]) == [1, 2, 3]
    assert identity({'id': 'id'}) == {'id': 'id'}


# Generated at 2022-06-24 00:45:36.963193
# Unit test for function find
def test_find():
    assert None is find([], lambda x: x == 2)
    assert 1 is find([1, 2, 3], lambda x: x == 1)
    assert 2 is find([1, 2, 3], lambda x: x == 2)
    assert 3 is find([1, 2, 3], lambda x: x == 3)
    assert None is find([1, 2, 3], lambda x: x > 3)
    assert None is find([1, 2, 3], lambda x: x < 1)


# Generated at 2022-06-24 00:45:46.616084
# Unit test for function memoize
def test_memoize():
    def isPrime(num):
        for i in range(2, num):
            if num % i == 0:
                return False
        return True

    assert isPrime(4) is False
    assert isPrime(13) is True

    isPrimeMemoized = memoize(isPrime)
    assert isPrimeMemoized(13) is True

    isPrimeMemoized(24)
    isPrimeMemoized(28)
    isPrimeMemoized(32)

    assert len(isPrimeMemoized.__closure__[0].cell_contents) is 3

if __name__ == '__main__':
    test_memoize()

# Generated at 2022-06-24 00:45:55.740081
# Unit test for function memoize
def test_memoize():
    """
    >>> memoized_increase = memoize(increase)
    >>> memoized_increase(2)
    3
    >>> memoized_increase(4)
    5
    >>> len(memoized_increase.__closure__[0].cell_contents)
    2
    >>> memoized_increase.__closure__[0].cell_contents[0][0] == 2
    True
    >>> memoized_increase.__closure__[0].cell_contents[0][1] == 3
    True
    >>> memoized_increase.__closure__[0].cell_contents[1][0] == 4
    True
    >>> memoized_increase.__closure__[0].cell_contents[1][1] == 5
    True
    """
    pass



# Generated at 2022-06-24 00:45:58.293816
# Unit test for function eq
def test_eq():
    print("test_eq")
    print(eq(1, 1))
    print(eq(1)(1))
    print(eq(1)(2))


# Generated at 2022-06-24 00:46:07.415976
# Unit test for function find
def test_find():
    assert find(
        [
            {"id": "1", "name": "Peter"},
            {"id": "2", "name": "John"},
            {"id": "3", "name": "Jack"}
        ],
        lambda item: item["id"] == "2"
    ) == {"id": "2", "name": "John"}

    assert find(
        [
            {"id": "1", "name": "Peter"},
            {"id": "2", "name": "John"},
            {"id": "3", "name": "Jack"}
        ],
        lambda item: item["id"] == "4"
    ) is None

    assert find(
        ["1", "2", "3"],
        lambda item: item == "2"
    ) == "2"


# Generated at 2022-06-24 00:46:10.678455
# Unit test for function curry
def test_curry():
    def sum_args(*args):
        return sum(args)

    curried_sum_args = curry(sum_args, 3)
    assert curried_sum_args(2, 3)(5) == 10
    assert curried_sum_args(2)(5, 5) == 12



# Generated at 2022-06-24 00:46:12.078324
# Unit test for function compose
def test_compose():
    assert compose(1, increase, increase, increase) == 4
    assert compose('a', increase) == None



# Generated at 2022-06-24 00:46:14.037914
# Unit test for function increase
def test_increase():
    start = 5
    end = 6
    assert increase(start) == end, 'test fail'



# Generated at 2022-06-24 00:46:19.484851
# Unit test for function compose
def test_compose():
    """
    Test for function compose

    :returns: True if all cases passed
    :rtype: Boolean
    """
    assert compose(1, increase, increase) == 3
    assert compose(1, increase, increase, increase) == 4
    assert compose(1, increase, identity) == 2
    assert compose(1, identity, increase) == 2
    return True



# Generated at 2022-06-24 00:46:25.247277
# Unit test for function pipe
def test_pipe():
    assert pipe(1, lambda x: x + 1, lambda x: x * 2) == 4
    assert pipe(1, lambda x: 2 * x, lambda x: '{}'.format(x)) == '2'
    assert pipe(1, lambda x: x + 1, lambda x: x * 2, lambda x: str(x)) == '4'



# Generated at 2022-06-24 00:46:30.394945
# Unit test for function find
def test_find():
    test_array = [1, 2, 3, 4, 5, 6]
    assert(find(test_array, lambda el: el > 1) == 2)
    assert(find(test_array, lambda el: el == 0) is None)



# Generated at 2022-06-24 00:46:33.004953
# Unit test for function compose
def test_compose():
    assert compose(4, lambda x: x * x, lambda x: x + 1) == 17



# Generated at 2022-06-24 00:46:34.901718
# Unit test for function pipe
def test_pipe():
    assert pipe(1, lambda x: x + 1, lambda x: x * 2) == 4



# Generated at 2022-06-24 00:46:37.493619
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(identity, [1, 2, 3])(1) == (1, 2, 3)



# Generated at 2022-06-24 00:46:42.975867
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 0, 3]) == [2, 1, 4]
    assert curried_map(increase)([1, 0, 3]) == [2, 1, 4]
    assert curried_map(increase, [1, 0, 3])([2, 3, 4]) == [3, 1, 5]


# Generated at 2022-06-24 00:46:45.859745
# Unit test for function compose
def test_compose():
    compose_test = compose(
        10,
        increase,
        increase,
        increase,
        increase,
        increase
    )

    assert compose_test == 15


if __name__ == '__main__':
    test_compose()

# Generated at 2022-06-24 00:46:51.412953
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(2, 3) == False
    assert eq(1, 3) == False
    assert eq(1)(2)(3)(4)(5)(6)(7)()(8)(9)(1) == True


# Generated at 2022-06-24 00:46:54.486010
# Unit test for function eq
def test_eq():
    print(eq(1, 1))
    print(eq(1, 2))
    print(eq(1)(1))
    print(eq(1)(2))
    print(eq(1)(1))
    print(eq(1, 2))


# Generated at 2022-06-24 00:46:55.047889
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-24 00:46:59.051887
# Unit test for function memoize
def test_memoize():
    """
    Unit test for function memoize
    """
    count: int = 0
    memoizable_function = memoize(lambda x: count)

    memoizable_function(3)
    memoizable_function(3)
    memoizable_function(3)
    memoizable_function(3)

    return count == 1



# Generated at 2022-06-24 00:47:00.380133
# Unit test for function increase
def test_increase():
    expected = 3
    actual = curry(increase)(2)
    assert expected == actual


# Generated at 2022-06-24 00:47:02.778787
# Unit test for function curried_map
def test_curried_map():
    expected = curried_map(increase, [1, 2, 3])
    assert expected == [2, 3, 4]


# Generated at 2022-06-24 00:47:04.774614
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 1) == 1
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-24 00:47:06.528134
# Unit test for function memoize
def test_memoize():
    func = memoize(lambda x: x * x)
    for i in range(10):
        assert func(i) == i ** 2


# Generated at 2022-06-24 00:47:11.139237
# Unit test for function find
def test_find():
    collection = [{'name': 'Anton'}, {'name': 'Andrew'}, {'name': 'Ivan'}]
    assert find(collection, lambda item: item['name'] == 'Anton') == {'name': 'Anton'}
    assert find(collection, lambda item: item['name'] == 'Dmitry') is None



# Generated at 2022-06-24 00:47:14.695372
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(2) == 2
    assert identity('string') == 'string'
    assert identity([1, 'string', 2]) == [1, 'string', 2]
    assert identity({'one': 1, 'two': 2, 'three': 3}) == {'one': 1, 'two': 2, 'three': 3}



# Generated at 2022-06-24 00:47:17.883068
# Unit test for function curry
def test_curry():
    assert eq(1)(1) is True
    assert eq(1)(2) is False
    add = lambda x, y: x + y
    assert (add(1)(2) == 3) is True



# Generated at 2022-06-24 00:47:19.929264
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(None) is None
    assert identity(True) is True
    assert identity(False) is False


# Generated at 2022-06-24 00:47:27.510444
# Unit test for function memoize
def test_memoize():
    from random import shuffle
    from math import sqrt

    def int_sqrt(val: int) -> int:
        return int(sqrt(val))

    memoized_fn = memoize(int_sqrt)

    test_values = list(range(10)) * 10
    shuffle(test_values)
    unshuffled_test_values = list(test_values)

    assert test_values == unshuffled_test_values

    for value in test_values:
        assert memoized_fn(value) == int_sqrt(value)

    assert test_values == unshuffled_test_values


if __name__ == '__main__':
    test_memoize()

# Generated at 2022-06-24 00:47:38.215738
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(curry(add))
    memoized_add(2, 3)
    memoized_add(2, 3)

    if memoized_add(2, 3) != memoized_add(2, 3):
        raise Exception('Error memoizing number')

    def add_name(name, last_name):
        return name + ' ' + last_name

    memoized_add_name = memoize(curry(add_name))
    memoized_add_name('Jan', 'Rutkowski')
    memoized_add_name('Jan', 'Kowalski')


# Generated at 2022-06-24 00:47:39.293409
# Unit test for function identity
def test_identity():
    assert identity('123') == '123'
    assert identity(123) == 123



# Generated at 2022-06-24 00:47:43.004309
# Unit test for function memoize
def test_memoize():
    def fibonacci(n):
        if n <= 0:
            return 0
        elif n == 1:
            return 1
        else:
            return fibonacci(n - 1) + fibonacci(n - 2)

    memoized_fibonacci = memoize(fibonacci)

    assert memoized_fibonacci(20) == 6765
    assert memoized_fibonacci(20) == 6765

# Generated at 2022-06-24 00:47:47.828510
# Unit test for function pipe
def test_pipe():
    def addTwo(value):
        return value + 2

    def mulTwo(value):
        return value * 2

    assert pipe(1, addTwo, mulTwo) == 6



# Generated at 2022-06-24 00:47:50.217166
# Unit test for function find
def test_find():
    """
    This function test result depends on collection and key.

    :returns:
    :rtype:
    """
    assert find([], lambda x: True) is None
    assert find([1, 2], lambda x: x > 3) is None
    assert find([1, 2], lambda x: x > 1) == 2



# Generated at 2022-06-24 00:47:51.065497
# Unit test for function pipe
def test_pipe():
    assert identity(10) == pipe(10, increase, increase)



# Generated at 2022-06-24 00:47:54.090669
# Unit test for function eq
def test_eq():
    """
    Checks all eq cases:
    True
    False
    """

    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-24 00:47:57.351077
# Unit test for function pipe
def test_pipe():
    assert pipe(
        "Mr. John Smith",
        lambda item: item.split('.')[1],
        lambda item: item.strip(),
        lambda item: item[:3] + '.'
    ) == 'Joh.'



# Generated at 2022-06-24 00:47:58.329126
# Unit test for function eq
def test_eq():
    expected = True
    actual = eq(1, 1)
    assert expected == actual



# Generated at 2022-06-24 00:47:59.323589
# Unit test for function pipe
def test_pipe():
    assert pipe(
        2,
        increase,
        increase,
    ) == 4

# Generated at 2022-06-24 00:48:04.741925
# Unit test for function curried_map
def test_curried_map():
    collection = [1, 2, 3, 4]
    assert curried_map(increase)(collection) == [2, 3, 4, 5]



# Generated at 2022-06-24 00:48:10.152626
# Unit test for function pipe
def test_pipe():
    def add_one(value):
        return value + 1

    def multiply_by_two(value):
        return value * 2

    assert pipe(1, add_one, multiply_by_two) == 4
    assert pipe(1, multiply_by_two, add_one) == 3



# Generated at 2022-06-24 00:48:12.545704
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2



# Generated at 2022-06-24 00:48:18.245610
# Unit test for function memoize
def test_memoize():
    def memoized_fn(argument):
        return argument + 2

    def key(x, y):
        return x == y

    memoized_fn_decorated = memoize(memoized_fn, key)

    assert memoized_fn_decorated(2) == 4
    assert memoized_fn_decorated(2) == 4
    assert memoized_fn_decorated(3) == 5
    assert memoized_fn_decorated(3) == 5


if __name__ == '__main__':
    test_memoize()

# Generated at 2022-06-24 00:48:19.252560
# Unit test for function compose
def test_compose():
    assert compose(1, __.__add__(1), __.__add__(2)) == 4



# Generated at 2022-06-24 00:48:23.883247
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)


# Generated at 2022-06-24 00:48:29.559942
# Unit test for function find
def test_find():
    # Test valid collection
    collection = ['foo', 'bar', 'baz']
    assert find(collection, lambda item: item * 2 == 'foofoo') == 'foo'

    # Test invalid collection
    assert find(collection, lambda item: item * 2 == 'spam') == None



# Generated at 2022-06-24 00:48:35.396076
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 1) is not None
    assert find([1, 2, 3], lambda x: x == 2) is not None
    assert find([1, 2, 3], lambda x: x == 3) is not None
    assert find([1, 2, 3], lambda x: x == 4) is None
    assert find([], lambda x: True) is None



# Generated at 2022-06-24 00:48:39.201926
# Unit test for function memoize
def test_memoize():
    @memoize
    def call(arg):
        return arg

    assert call("1") == "1"
    assert call("2") == "2"
    assert call("1") == "1"
    assert call("1") is "1"
    assert call("2") is "2"
    assert len(call.__closure__[0].cell_contents) == 2
    assert call("1") is "1"
    assert call("2") is "2"
    assert len(call.__closure__[0].cell_contents) == 2


if __name__ == "__main__":
    test_memoize()

# Generated at 2022-06-24 00:48:40.532463
# Unit test for function compose
def test_compose():
    assert compose(1, identity, identity, increase) == 3


# Generated at 2022-06-24 00:48:46.332815
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq(None, None) == True
    assert eq({}, {}) == False
    assert eq([], []) == False



# Generated at 2022-06-24 00:48:47.483251
# Unit test for function identity
def test_identity():
    assert identity(5) == 5



# Generated at 2022-06-24 00:48:51.704382
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(1) == 2



# Generated at 2022-06-24 00:48:59.187682
# Unit test for function curried_filter
def test_curried_filter():
    """
    Unit test for curried_filter
    """
    # First test
    collection = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0]
    print("Test 1")
    print("collection =", collection)
    print("curried_filter(lambda x: x > 5, collection) =",
          curried_filter(lambda x: x > 5, collection))

    # Second test
    collection = [2, 3, 4, 5, 6, 7, 8, 9, 0]
    print("Test 2")
    print("collection =", collection)
    print("curried_filter(lambda x: x % 2 == 0, collection) =",
          curried_filter(lambda x: x % 2 == 0, collection))



# Generated at 2022-06-24 00:49:01.227620
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:49:07.422622
# Unit test for function eq
def test_eq():
    assert True == eq(1)(1)
    assert True == eq(1)(1, 1)
    assert False == eq(1)(2, 1)
    assert False == eq(1)(2, 1, 1)



# Generated at 2022-06-24 00:49:11.602781
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4]) == [2, 4]


# Generated at 2022-06-24 00:49:15.475580
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x * 2, [1, 2, 3]) == [2, 4, 6]


# Generated at 2022-06-24 00:49:19.788127
# Unit test for function curry
def test_curry():
    sum_args_function = curry(lambda *args: sum(args))

    assert sum_args_function(4, 5) == 9
    assert sum_args_function(4)(5) == 9
    assert sum_args_function(4, 5, 6) == 15
    assert sum_args_function(4)(5, 5) == 14


test_curry()



# Generated at 2022-06-24 00:49:25.504958
# Unit test for function curried_map
def test_curried_map():
    mapped_collection = curried_map(increase, [1, 2, 3, 5, 8])
    assert mapped_collection == [2, 3, 4, 6, 9], \
        "curried_map must return collection with all elements increased by 1"



# Generated at 2022-06-24 00:49:27.173928
# Unit test for function identity
def test_identity():
    assert identity(10) == 10
    assert identity(10.05) == 10.05
    assert identity('10') == '10'


# Generated at 2022-06-24 00:49:32.650762
# Unit test for function curried_map
def test_curried_map():
    assert list(map(increase, [1, 2, 3])) == curried_map(increase)([1, 2, 3])
    assert list(map(increase, [1, 2, 3])) == curried_map(increase, [1, 2, 3])


# Generated at 2022-06-24 00:49:38.327319
# Unit test for function find
def test_find():
    collection = [
        {"name": "Dima", "age": 30},
        {"name": "Alex", "age": 35},
        {"name": "Nick", "age": 25}
    ]
    key = lambda x: x["age"] > 30
    assert find(collection, key) == {"name": "Alex", "age": 35}, "Wrong find method"



# Generated at 2022-06-24 00:49:40.562691
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2
    assert increase(-5) == -4



# Generated at 2022-06-24 00:49:41.545719
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:49:46.099673
# Unit test for function curried_map
def test_curried_map():
    curried_map(increase, [1,2,3]) == [2,3,4]


# Generated at 2022-06-24 00:49:50.957148
# Unit test for function curried_map
def test_curried_map():
    #Asserts
    assert(curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4])
    assert(curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4])
    assert(curried_map(lambda x: x + 1, [1, 2, 3])([4, 5, 6]) == [5, 6, 7])


# Generated at 2022-06-24 00:50:00.530504
# Unit test for function cond
def test_cond():
    assert cond(
        [(lambda a: a == 1, lambda a: "a == 1"),
         (lambda a: a == 2, lambda a: "a == 2")]
    )(1) == "a == 1"
    assert cond(
        [(lambda a: a == 1, lambda a: "a == 1"),
         (lambda a: a == 2, lambda a: "a == 2")]
    )(2) == "a == 2"
    assert cond(
        [(lambda a: a == 1, lambda a: "a == 1"),
         (lambda a: a == 2, lambda a: "a == 2")]
    )(3) is None



# Generated at 2022-06-24 00:50:04.104669
# Unit test for function find
def test_find():
    assert find([], lambda x: False) is None
    assert find((), lambda x: False) is None
    assert find([1, 2, 3], lambda x: x > 2) == 3
    assert find([1, 2, 3], lambda x: x > 1) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-24 00:50:05.506763
# Unit test for function pipe
def test_pipe():
    assert pipe(3, lambda x: x*2, lambda x: x-1) == 5


# Generated at 2022-06-24 00:50:07.770880
# Unit test for function curried_filter
def test_curried_filter():
    odds = curried_filter(lambda x: x % 2)
    assert odds([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 3, 5, 7, 9]



# Generated at 2022-06-24 00:50:09.590406
# Unit test for function cond
def test_cond():
    assert cond([
        (identity, increase),
    ])(False) == 1



# Generated at 2022-06-24 00:50:11.360461
# Unit test for function identity
def test_identity():
    assert identity('42') == '42'



# Generated at 2022-06-24 00:50:16.908988
# Unit test for function pipe
def test_pipe():
    def add(value):
        return value + 1

    def double(value):
        return value * 2

    test_value = 1
    result = pipe(
        test_value,
        add,
        double,
        double
    )

    assert result == 6, "Pipe don't work correctly"



# Generated at 2022-06-24 00:50:18.831051
# Unit test for function eq
def test_eq():
    assert eq(2, 2)
    assert not eq(2, 3)


# Generated at 2022-06-24 00:50:22.898829
# Unit test for function curried_map
def test_curried_map():
    double = lambda x: x * 2
    numbers = [1, 2, 3, 4, 5]

    curried_map_double = curried_map(double)
    curried_map_double_numbers = curried_map_double(numbers)

    assert curried_map_double_numbers == [2, 4, 6, 8, 10]


# Generated at 2022-06-24 00:50:24.499319
# Unit test for function memoize
def test_memoize():
    assert memoize(increase, key=eq)(3) == 4
    assert memoize(increase, key=eq)(3) == 4

# Generated at 2022-06-24 00:50:31.021915
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1])([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-24 00:50:35.103064
# Unit test for function identity
def test_identity():
    a = 1
    assert identity(a) == 1
    assert identity(1) == 1
    assert identity(None) is None
    assert identity({'a': 'b'}) == {'a': 'b'}



# Generated at 2022-06-24 00:50:47.091081
# Unit test for function curried_map
def test_curried_map():
    # check that curried_map return correct result
    assert eq(curried_map(identity)([1, 2, 3]), [1, 2, 3])
    assert eq(curried_map(identity)([1, 2, 3, 4]), [1, 2, 3, 4])
    assert eq(curried_map(increase)([1, 2, 3, 4]), [2, 3, 4, 5])
    # check that curried_map return correct result if invoked in one line
    assert eq(curried_map(identity, [1, 2, 3]), [1, 2, 3])
    assert eq(curried_map(identity, [1, 2, 3, 4]), [1, 2, 3, 4])

# Generated at 2022-06-24 00:50:54.491952
# Unit test for function pipe
def test_pipe():
    assert pipe(
        [{'name': 'Archer'}, {'name': 'Lana'}, {'name': 'Cheryl'}],

        curried_map(lambda x: {'name': x['name'] + ' Tunt'}),
        curried_filter(lambda x: x['name'] != 'Archer Tunt'),
    ) == [{'name': 'Lana Tunt'}, {'name': 'Cheryl Tunt'}]



# Generated at 2022-06-24 00:50:59.647809
# Unit test for function cond
def test_cond():
    def test_fun(param):
        return param
    fun_list = [
        (lambda x: x > 1, lambda x: 'first'),
        (lambda x: True, lambda x: 'second'),
    ]
    assert cond(fun_list)(2) == 'first'
    assert cond(fun_list)(1) == 'second'


# Generated at 2022-06-24 00:51:05.048617
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], eq(3)) is 3
    assert find(["a", "b", "c", "d", "e"], eq("e")) is "e"
    assert find([], eq(3)) is None



# Generated at 2022-06-24 00:51:09.085783
# Unit test for function compose
def test_compose():
    # Function to test
    def add(value1: int, value2: int) -> int:
        return value1 + value2

    # compose right-to-left three functions
    # test for eq function for identity
    assert compose(1, identity) == 1
    # test for increase function
    assert compose(1, increase) == 2
    # test for add function
    assert compose(1, increase, add(1)) == 3



# Generated at 2022-06-24 00:51:13.548477
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq('1', '1') is True
    assert eq(1, 2) is False
    assert eq(1)(1) is True
    assert eq(1)(2) is False
    assert eq(1, 2, 3) is False

# Generated at 2022-06-24 00:51:23.717080
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    def subtract(a, b):
        return a - b

    add_memoized_by_first_arg = memoize(add, lambda a, b: a == b)
    add_memoized_by_second_arg = memoize(add, lambda a, b: b == a)
    subtract_memoized_by_first_arg = memoize(subtract)
    subtract_memoized_by_second_arg = memoize(subtract)

    assert add_memoized_by_first_arg(1, 1) == 2
    assert add_memoized_by_first_arg(1, 1) == 2
    assert add_memoized_by_first_arg(2, 2) == 4
    assert add_memoized_

# Generated at 2022-06-24 00:51:29.897639
# Unit test for function cond
def test_cond():
    condition_list = [
        (lambda x: x % 2, lambda x: "odd"),
        (lambda x: x - 1, lambda x: "even")
    ]

    f = cond(condition_list)

    assert f(1) == "odd"
    assert f(0) == "even"
    assert f(2) == "even"

    f = cond()

    assert f("Herro") is None



# Generated at 2022-06-24 00:51:35.234798
# Unit test for function curried_filter
def test_curried_filter():
    test_list = list(range(12))
    assert (curried_filter(lambda x: x % 2)(test_list) == [1, 3, 5, 7, 9, 11])
    assert (curried_filter(lambda x: x % 2)(test_list) == [1, 3, 5, 7, 9, 11])



# Generated at 2022-06-24 00:51:40.428456
# Unit test for function find
def test_find():
    assert find([1, 2, 3])(eq(2)) == 2
    assert find([])(eq(1)) is None



# Generated at 2022-06-24 00:51:46.827310
# Unit test for function find
def test_find():
    """
    Unit test for function find.

    :returns: List of failed test objects
    :rtype: List[Test]
    """
    from expect import expect

# Generated at 2022-06-24 00:51:58.661381
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)
    assert eq(1, 1, 1)
    assert not eq(1, 1, 2)
    assert eq(1, 1, 1, 1)
    assert not eq(1, 1, 1, 2)
    assert eq(1, 1, 1, 1, 1)
    assert not eq(1, 1, 1, 1, 2)
    assert eq(1, 1, 1, 1, 1, 1)
    assert not eq(1, 1, 1, 1, 1, 2)
    assert not eq(1, 2, 1, 1, 1, 2)
    assert not eq(1, 1, 2, 1, 1, 2)



# Generated at 2022-06-24 00:52:03.786232
# Unit test for function curry
def test_curry():
    def fn3(first, second, third):
        return first + second + third

    assert fn3(1, 2, 3) == 6
    assert curry(fn3, 3)(1)(2)(3) == 6
    assert curry(fn3, 3)(1)(2, 3) == 6
    assert curry(fn3, 3)(1, 2)(3) == 6
    assert curry(fn3, 3)(1, 2, 3) == 6



# Generated at 2022-06-24 00:52:04.800535
# Unit test for function increase
def test_increase():
    assert(increase(1) == 2)


# Generated at 2022-06-24 00:52:09.518394
# Unit test for function cond
def test_cond():
    """
    Unit test for function cond
    """
    assert cond([
        (lambda x: x > 0, lambda x: x + 1),
        (lambda x: x == 0, lambda x: 0),
        (lambda x: x < 0, lambda x: x - 1)
    ])(-1) == -2
    assert cond([
        (lambda x: x > 0, lambda x: x + 1),
        (lambda x: x == 0, lambda x: 0),
        (lambda x: x < 0, lambda x: x - 1)
    ])(1) == 2

# Generated at 2022-06-24 00:52:13.268080
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False
    assert eq(1)(1) is True
    assert eq(1)(2) is False

    assert eq(1)(1)(1)(1)(1)(1)(1)(2)(1)(1)(1)(1) is False


# Generated at 2022-06-24 00:52:14.595394
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-24 00:52:17.932232
# Unit test for function curried_filter
def test_curried_filter():
    filtered_by_3 = curried_filter(eq(3))
    assert filtered_by_3([1, 2, 3]) == [3]



# Generated at 2022-06-24 00:52:28.785745
# Unit test for function pipe
def test_pipe():
    """
    Test pipe function.
    """

# Generated at 2022-06-24 00:52:35.130230
# Unit test for function compose
def test_compose():
    def sub(value: int) -> int:
        return value - 1
    def add(value: int) -> int:
        return value + 1
    print(compose(1, sub, add))
    print(compose(1, add, sub))


# Generated at 2022-06-24 00:52:46.098951
# Unit test for function cond
def test_cond():
    def equal(a, b):
        return a == b

    def append_a(value):
        return value + 'a'

    def append_b(value):
        return value + 'b'

    def append_c(value):
        return value + 'c'

    conditions = [
        cond([
            (
                lambda value: value == 'a',
                append_a
            ),
            (
                lambda value: value == 'b',
                append_b
            ),
            (
                lambda value: value == 'c',
                append_c
            ),
        ])
    ]
    result_list = []

    def ignore(value):
        result_list.append(value)

    map(
        lambda condition: ignore(condition('a')),
        conditions,
    )

# Generated at 2022-06-24 00:52:50.726496
# Unit test for function curried_filter
def test_curried_filter():
    num_list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    result = curried_filter(eq(2), num_list)
    assert result == [2]



# Generated at 2022-06-24 00:52:56.716848
# Unit test for function memoize
def test_memoize():
    #def fn(a, b, c):
    #    print('Execute')
    #    return a + b + c

    # TODO: Make code for cache
    #memoized_fn = memoize(fn)

    #print(memoized_fn(1, 2, 3))
    #print(memoized_fn(1, 2, 3))
    pass

# Generated at 2022-06-24 00:53:03.920365
# Unit test for function curried_filter
def test_curried_filter():
    list = [1, 2, 3, 4, 5]
    list_filtered = curried_filter(lambda x: x > 1, list)
    assert list_filtered == [2, 3, 4, 5]
    list_filtered_1 = curried_filter(lambda x: x > 0, list)
    assert list_filtered_1 == [1, 2, 3, 4, 5]


# Generated at 2022-06-24 00:53:04.797548
# Unit test for function identity
def test_identity():
    assert identity(1) == 1


# Generated at 2022-06-24 00:53:07.247527
# Unit test for function curried_map
def test_curried_map():
    list = [1, 2, 3, 4, 5]

    fnc = compose(list, curried_map(increase))
    assert fnc == [2, 3, 4, 5, 6]



# Generated at 2022-06-24 00:53:09.940313
# Unit test for function memoize
def test_memoize():
    def f(x):
        return x * x
    f = memoize(f)
    assert f(10) == 100
    assert f(10) == 100
    assert f(11) == 121
    assert f(11) == 121



# Generated at 2022-06-24 00:53:13.642821
# Unit test for function pipe
def test_pipe():
    assert pipe(1, lambda x: x + 1, lambda x: x + 2) == 4



# Generated at 2022-06-24 00:53:16.442574
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(True) is True
    assert identity(None) is None



# Generated at 2022-06-24 00:53:20.451100
# Unit test for function curry
def test_curry():
    """
    >>> import core
    >>> square_it = core.curry(lambda a, b: a ** b)
    >>> square_it(2)(4)
    16
    """


# Generated at 2022-06-24 00:53:24.098053
# Unit test for function compose
def test_compose():
    assert compose(1, lambda x: x + 1, lambda x: x * 2) == 4
    assert compose(1, lambda x: x + 1, lambda x: '*' * x) == '**'



# Generated at 2022-06-24 00:53:28.862976
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4, 5]) == [3, 4, 5]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5]) == [2, 4]



# Generated at 2022-06-24 00:53:31.278020
# Unit test for function curry
def test_curry():
    def add(x, y):
        return x + y

    assert curry(add, 2)(1)(2) == add(1, 2)
    assert curry(add)(1)(2) == add(1, 2)



# Generated at 2022-06-24 00:53:32.337710
# Unit test for function compose
def test_compose():
    """
    Unit test for function compose
    """
    assert compose('a', increase) == 'b'



# Generated at 2022-06-24 00:53:39.466646
# Unit test for function pipe
def test_pipe():
    result = pipe('Hello, world!',
                  lambda value: value.split(' '),
                  lambda value: value[1],
                  lambda value: value[::-1],
                  lambda value: value.capitalize(),
                  lambda value: value + ',',
                  )
    expected_result = 'Dlrow,'
    assert result == expected_result, \
        'expected result of %s got %s' % (expected_result, result)
    print('test pipe [passed]')



# Generated at 2022-06-24 00:53:41.244949
# Unit test for function pipe
def test_pipe():
    assert pipe(
        1,
        identity,
        increase,
        identity
    ) == 3



# Generated at 2022-06-24 00:53:47.177626
# Unit test for function cond
def test_cond():
    some_value = 1

    def only_return_true(argument):
        return argument % 2

    def an_other_only_return_true(argument):
        return int(argument)

    test_result = cond(
        [
            (only_return_true, identity),
            (an_other_only_return_true, increase)
        ]
    )
    assert test_result(some_value) == some_value + 1

# Generated at 2022-06-24 00:53:47.984801
# Unit test for function identity
def test_identity():
    assert "42" == identity(42)


# Generated at 2022-06-24 00:53:50.955743
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(list, [[1,2,3,4], [4,5,6,7], [7,8,9,10]]) == [[1,2,3,4], [4,5,6,7], [7,8,9,10]]


# Generated at 2022-06-24 00:53:57.137531
# Unit test for function cond
def test_cond():
    assert cond(
        [(eq(1), identity), (eq(2), increase)]
    )(1) == 1
    assert cond(
        [(eq(1), identity), (eq(2), increase)]
    )(2) == 3
    assert cond(
        [(eq('a'), identity), (eq('b'), increase)]
    )('c') is None



# Generated at 2022-06-24 00:53:58.132592
# Unit test for function increase
def test_increase():
    assert increase(3) == 4



# Generated at 2022-06-24 00:53:59.480593
# Unit test for function identity
def test_identity():
    assert identity("test") == 'test'


# Generated at 2022-06-24 00:54:02.976481
# Unit test for function identity
def test_identity():
    assert identity(1) == 1


# Generated at 2022-06-24 00:54:04.292129
# Unit test for function eq
def test_eq():
    assert curry(eq, 2)(1, 1) == True



# Generated at 2022-06-24 00:54:06.629018
# Unit test for function pipe
def test_pipe():
    assert pipe(1, lambda arg: arg + 1) == 2
    assert pipe(1, lambda arg: arg + 1, lambda arg: arg * 3) == 6



# Generated at 2022-06-24 00:54:11.595772
# Unit test for function curried_filter
def test_curried_filter():
    # create function for adding 1 to argument
    def add_one(argument):
        return argument + 1

    # create function for filter
    def filter_func(value):
        return value == 3

    # create list
    list_ = [1,2,3,4,5]

    # filter_func is curried function with function add_one
    # curried_filtered_list is list with values that are filterer
    # curried_filtered_list is the same with list_ but every element is increased by 1
    curried_filtered_list = curried_filter(filter_func)(list_)

    # non_curried_filtered_list is list with values that are filterer
    non_curried_filtered_list = curried_filter(filter_func, list_)

    # map adding one on list