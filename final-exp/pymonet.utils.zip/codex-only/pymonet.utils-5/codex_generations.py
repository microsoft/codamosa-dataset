

# Generated at 2022-06-24 00:44:17.458180
# Unit test for function cond
def test_cond():
    assert cond(
        [
            (eq(1), increase),
            (eq(2), identity)
        ])(1) == 2
    assert cond(
        [
            (eq(1), increase),
            (eq(2), identity)
        ])(2) == 2
    assert cond(
        [
            (eq(1), increase),
            (eq(2), identity)
        ])(3) is None



# Generated at 2022-06-24 00:44:18.726633
# Unit test for function identity
def test_identity():
    assert(identity(1) == 1)



# Generated at 2022-06-24 00:44:20.187494
# Unit test for function pipe
def test_pipe():
    assert pipe(1, increase, increase, increase) == 4



# Generated at 2022-06-24 00:44:29.063336
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b, c: a + b + c)(1, 2, 3) == 6
    assert curry(lambda a, b, c: a + b + c, 3)(1, 2, 3) == 6

    assert curry(lambda a, b, c: a + b + c)(1, 2)(3) == 6
    assert curry(lambda a, b, c: a + b + c)(1)(2)(3) == 6

    assert curry(lambda a, b, c: a + b + c)(1)(2, 3) == 6

    assert curry(lambda a, b, c: a + b + c, 1)(1) == 1
    assert curry(lambda a, b, c: a + b + c, 2)(1, 2) == 3



# Generated at 2022-06-24 00:44:32.519762
# Unit test for function identity
def test_identity():
    assert identity(5) == 5
    assert identity('text') == 'text'



# Generated at 2022-06-24 00:44:34.704704
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-24 00:44:39.352545
# Unit test for function eq
def test_eq():
    assert eq(1, 2) == False
    assert eq(True, False) == False
    assert eq('cat', 'dog') == False
    assert eq('cat', 'cat') == True



# Generated at 2022-06-24 00:44:41.533562
# Unit test for function compose
def test_compose():
    assert compose(3, identity, increase)(3) == 4



# Generated at 2022-06-24 00:44:45.257798
# Unit test for function curried_map
def test_curried_map():
    assert curried_map((lambda x: x+1))([1, 2, 3]) == [2, 3, 4]
    assert curried_map((lambda x: x+1), [1, 2, 3]) == [2, 3, 4]
    assert curried_map((lambda x: x+1), [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-24 00:44:51.889129
# Unit test for function curry
def test_curry():
    assert callable(curry(increase))
    assert curry(increase)(1) == 2
    assert callable(curry(increase)(1))
    assert curry(increase)(1)(1) == 2



# Generated at 2022-06-24 00:44:53.790175
# Unit test for function memoize
def test_memoize():
    def add(x: int):
        return x + 10

    memoize_add = memoize(add)
    memoize_add(10)
    memoize_add(10)

    assert memoize_add(10) == add(10)

# Generated at 2022-06-24 00:44:55.838014
# Unit test for function pipe
def test_pipe():
    assert pipe(
        5,
        lambda x: x + 2,
        lambda x: x * 3
    ) == 21



# Generated at 2022-06-24 00:45:02.080731
# Unit test for function memoize
def test_memoize():
    def foo(n: int) -> (str, int):
        return str(n), n * 1

    f1 = memoize(foo)
    first_result = f1(1)
    second_result = f1(1)
    assert id(first_result) == id(second_result)
# end Unit test


if __name__ == "__main__":
    test_memoize()

# Generated at 2022-06-24 00:45:03.780711
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x*2)([1, 2, 3]) == [2, 4, 6]



# Generated at 2022-06-24 00:45:05.550159
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity('1') == '1'
    assert identity([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-24 00:45:08.173459
# Unit test for function memoize
def test_memoize():
    @memoize
    def fib(n):
        if n == 0 or n == 1:
            return n
        else:
            return fib(n - 1) + fib(n - 2)

    assert fib(100) == 354224848179261915075

# Generated at 2022-06-24 00:45:10.323027
# Unit test for function memoize
def test_memoize():
    @memoize
    def fib(value):
        if value < 2:
            return 1
        return fib(value - 1) + fib(value - 2)
    assert fib(2) == 2



# Generated at 2022-06-24 00:45:18.051493
# Unit test for function pipe
def test_pipe():
    collection = [1, 2, 3]
    mapped_collection = pipe(
        collection,
        curried_map(increase),
        curried_map(increase),
    )
    if mapped_collection != [3, 4, 5]:
        raise Exception('Pipe function not work correctly')



# Generated at 2022-06-24 00:45:21.834704
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5]) == [2, 4]



# Generated at 2022-06-24 00:45:24.435350
# Unit test for function pipe
def test_pipe():
    assert pipe(
        1,
        identity,
        increase,
        lambda x: x * x
    ) == 4

# Generated at 2022-06-24 00:45:25.378378
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:45:32.891374
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 1, [1, 2, 3]) == [2, 3]
    assert curried_filter(lambda x: x > 1)([1, 2, 3]) == [2, 3]
    assert curried_filter(lambda x: x > 1, []) == []

# Generated at 2022-06-24 00:45:34.766740
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 3, 4]
    filt = curried_filter(eq(2))
    assert filt(collection) == [2]


# Generated at 2022-06-24 00:45:39.271581
# Unit test for function find
def test_find():
    test_collection = [
        {'test': '1', 'test2': '2'},
        {'test': '2', 'test2': '3'},
        {'test': '3', 'test2': '3'}
    ]
    test_key = lambda item: item["test"] == '2'
    assert find(test_collection, test_key) == {'test': '2', 'test2': '3'}


# Generated at 2022-06-24 00:45:41.709101
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(2) == 3
    assert increase(1) != 1


# Generated at 2022-06-24 00:45:42.805548
# Unit test for function eq
def test_eq():
    assert eq(1)(1)



# Generated at 2022-06-24 00:45:43.833563
# Unit test for function identity
def test_identity():
    assert identity(1) == 1


# Generated at 2022-06-24 00:45:48.883553
# Unit test for function cond
def test_cond():
    assert cond([(lambda x: x > 0, increase), (eq(0), identity)])(0) == 0
    assert cond([(lambda x: x > 0, increase), (eq(0), identity)])(1) == 2
    assert cond([(lambda x: x < 0, increase), (eq(0), identity)])(1) == 1



# Generated at 2022-06-24 00:45:49.299747
# Unit test for function memoize
def test_memoize():
    pass



# Generated at 2022-06-24 00:45:54.985547
# Unit test for function cond
def test_cond():
    # First function should return true, so must return 'Hello'
    assert cond([(eq(True), identity), (eq(False), lambda _: 'World')])(True) == 'Hello'
    # First function should return false, so must return 'World'
    assert cond([(eq(False), lambda _: 'Hello'), (eq(True), identity)])(True) == 'World'



# Generated at 2022-06-24 00:46:00.602400
# Unit test for function cond
def test_cond():
    def greater_than_5(value):
        return value > 5

    def less_than_5(value):
        return value < 5

    def between_5_10(value):
        return 5 < value < 10

    def equal_5(value):
        return value == 5

    def identity(value):
        return value

    def increase(value):
        return value + 1

    def decrease(value):
        return value - 1

    assert cond([
        (greater_than_5, increase),
        (less_than_5, decrease),
        (between_5_10, identity)
    ])(4) == 3
    assert cond([
        (greater_than_5, increase),
        (less_than_5, decrease),
        (equal_5, identity)
    ])(4) == 3

# Generated at 2022-06-24 00:46:04.505281
# Unit test for function pipe
def test_pipe():
    add_1 = lambda x: x + 1
    mul_2 = lambda x: x * 2
    sub_2 = lambda x: x - 2

    assert 6 == pipe(0, add_1, mul_2)
    assert 2 == pipe(0, add_1, mul_2, sub_2)


# Generated at 2022-06-24 00:46:07.039221
# Unit test for function eq
def test_eq():
    """
    Test function eq
    """
    assert(eq(1, 1))
    assert(not eq(1, 2))



# Generated at 2022-06-24 00:46:09.270137
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2
    assert increase(2) == 3



# Generated at 2022-06-24 00:46:20.081375
# Unit test for function cond
def test_cond():
    true_function_call_spy = False
    false_function_call_spy = False

# Generated at 2022-06-24 00:46:29.600397
# Unit test for function find
def test_find():
    assert find(list(range(10)), lambda x: x > 100) is None, 'Empty collection'
    assert find(['a', 'bb', 'c'], lambda x: x == 'bb'), 'Simple test'
    assert find([{'a': 1}, {'a': 2}], lambda x: x['a'] > 1) == {'a': 2}, 'List of dictionary'
    assert find([{'a': 1}, {'a': 2}], lambda x: x['a'] == 1) == {'a': 1}, 'List of dictionary'
    assert find([{'a': 1}, {'a': 2}], lambda x: x['a'] == 3) is None, 'List of dictionary'



# Generated at 2022-06-24 00:46:34.669194
# Unit test for function memoize
def test_memoize():
    a = memoize(identity)
    b = a(1)
    c = a(1)
    assert b == c

    a = memoize(identity, lambda x, y: x == y)
    b = a(1)
    c = a(1)
    assert b == c



# Generated at 2022-06-24 00:46:35.702088
# Unit test for function identity
def test_identity():
    assert identity(2) is 2



# Generated at 2022-06-24 00:46:46.050134
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6
    assert curry(lambda x, y, z, t: x + y + z + t)(1)(2)(3)(4) == 10
    assert curry(lambda x, y, z, t: x + y + z + t)(1, 2)(3, 4) == 10
    assert curry(lambda x, y, z, t: x + y + z + t)(1, 2, 3)(4) == 10

# Generated at 2022-06-24 00:46:47.324280
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-24 00:46:55.876540
# Unit test for function cond
def test_cond():
    add = lambda a, b: a + b
    multiply = lambda a, b: a * b

    is_even = lambda x: x % 2 == 0
    is_positive = lambda x: x > 0

    cond_function = cond(
        [(is_even, add),
         (is_positive, multiply),
         (identity, None)]
    )

    assert cond_function(1, 2) == 2
    assert cond_function(2, 2) == 4
    assert cond_function(1, -2) is None
    assert cond_function(-2, -2) == 4
    assert cond_function(-2, 2) == 0



# Generated at 2022-06-24 00:46:57.966952
# Unit test for function compose
def test_compose():
    assert compose(1, increase) == 2
    assert compose(1, lambda x: x * 2, increase) == 4



# Generated at 2022-06-24 00:47:02.572740
# Unit test for function curried_map
def test_curried_map():
    collection = [1, 2, 3, 4]
    assert curried_map(increase)(collection) == [2, 3, 4, 5]
    assert curried_map(increase, collection) == [2, 3, 4, 5]



# Generated at 2022-06-24 00:47:05.151118
# Unit test for function compose
def test_compose():
    assert compose(1, increase, identity) == 2
    assert compose([1, 2, 3], curried_map(identity), curried_map(increase), curried_filter(eq(2))) == [2]


# Generated at 2022-06-24 00:47:06.826506
# Unit test for function compose
def test_compose():
    fn = compose(1, lambda x: x + 1, lambda x: x + 2)
    assert fn == 4



# Generated at 2022-06-24 00:47:08.641719
# Unit test for function curried_filter
def test_curried_filter():
    element = curried_filter(lambda x: x % 2 == 0)
    assert element([1, 2, 3]) == [2]


# Generated at 2022-06-24 00:47:10.990739
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(5) == 6
    assert increase(555) == 556



# Generated at 2022-06-24 00:47:14.522292
# Unit test for function compose
def test_compose():
    result = compose(2, lambda x: x + 1, lambda x: x * 5)
    assert result == 15
    assert compose(2, lambda x: x + 1) == 3
    assert compose(2) == 2


# Generated at 2022-06-24 00:47:16.544638
# Unit test for function identity
def test_identity():
    assert identity('hello') == 'hello'
    assert identity(1) == 1
    assert identity(True) is True



# Generated at 2022-06-24 00:47:19.837323
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 3)([1, 2]) == [4, 5]



# Generated at 2022-06-24 00:47:23.907788
# Unit test for function curried_filter
def test_curried_filter():
    def less_than_5(number):
        return number < 5

    assert curried_filter(less_than_5, [1, 2, 3, 4, 5, 6, 7, 8, 9]) == [1, 2, 3, 4]
    assert curried_filter(lambda number: number < 5)([1, 2, 3, 4, 5, 6, 7, 8, 9]) == [1, 2, 3, 4]



# Generated at 2022-06-24 00:47:29.409913
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y, 2)(1)(2) == 3
    assert curry(lambda x, y: x + y, 2)(1) == curry(lambda y: 1 + y)
    assert curry(lambda x, y: x + y, 1)(1) == 2
    assert curry(lambda x, y: x * y, 2)(3)(8) == 24
    assert curry(lambda x, y, z: x * y + z, 3)(2)(3)(8) == 14



# Generated at 2022-06-24 00:47:34.947862
# Unit test for function memoize
def test_memoize():
    def memoized_add(a, b):
        @memoize
        def add(a, b):
            return a + b
        return add(a, b)

    assert memoized_add(2, 3) == 5
    assert memoized_add(2, 3) == 5
    assert memoized_add(3, 2) == 5



# Generated at 2022-06-24 00:47:45.951017
# Unit test for function curried_filter
def test_curried_filter():
    numbers = [1, 2, 3, 4]

    assert curried_filter(lambda x: x % 2 == 0, numbers) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 1, numbers) == [1, 3]

    assert curried_filter(lambda x: x == 2)(numbers) == [2]
    assert curried_filter(lambda x: x == 2 or x == 3)(numbers) == [2, 3]
    assert curried_filter(lambda x: x == 2 or x == 3 or x == 1)(numbers) == [
        1, 2, 3
    ]
    assert curried_filter(lambda x: x == 2 or x == 3 or x == 1 or x == 4)(numbers) == [
        1, 2, 3, 4
    ]
    assert curried

# Generated at 2022-06-24 00:47:47.914547
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert eq(1, 1)
    assert not eq(1, 0)
    assert not eq(0, 1)



# Generated at 2022-06-24 00:47:49.911393
# Unit test for function memoize
def test_memoize():
    def add(a):
        return a + 1

    memoized_add = memoize(add)
    assert memoized_add(1) == 2
    assert memoized_add(1) == 2

# Generated at 2022-06-24 00:47:53.960862
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(2, 3)
    assert eq(1)(1)
    assert not eq(1)(3)
    assert not eq(eq)(True)



# Generated at 2022-06-24 00:47:59.907830
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(2))([2]) == [2]
    assert curried_filter(eq(2))([1, 2]) == [2]
    assert curried_filter(eq(2))([2, 3]) == [2]
    assert curried_filter(eq(2))([1, 2, 3]) == [2]
    assert curried_filter(eq(2))([1, 3]) == []
    assert curried_filter(eq(2))([]) == []



# Generated at 2022-06-24 00:48:06.921450
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5]) == [2, 4]



# Generated at 2022-06-24 00:48:09.493149
# Unit test for function cond
def test_cond():
    """
    Function for test function cond

    :returns: True if test was passed, False otherwise
    :rtype: Boolean
    """
    condition_list = [
        (lambda value: value > 5, lambda value: value * 2),
        (lambda value: value < 2, lambda value: value - 4)
    ]
    test_cond_result = cond(condition_list)

    assert test_cond_result(5) == 10
    assert test_cond_result(2) == -4



# Generated at 2022-06-24 00:48:11.685127
# Unit test for function find
def test_find():
    collection = [1, 2, 3, 4]
    result = find(collection, lambda x: x == 3)
    assert result == 3



# Generated at 2022-06-24 00:48:12.449590
# Unit test for function identity
def test_identity():
    assert identity(1) == 1

# Generated at 2022-06-24 00:48:20.047747
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2
    assert increase(2) == 3
    assert increase(3) == 4
    assert increase(4) == 5
    assert increase(5) == 6
    assert increase(6) == 7
    assert increase(7) == 8
    assert increase(8) == 9
    assert increase(9) == 10
    assert increase(10) == 11
    assert increase(11) == 12
    assert increase(12) == 13
    assert increase(13) == 14
    assert increase(14) == 15
    assert increase(15) == 16
    assert increase(16) == 17
    assert increase(17) == 18
    assert increase(18) == 19
    assert increase(19) == 20
    assert increase(20) == 21
    assert increase(21) == 22
   

# Generated at 2022-06-24 00:48:26.508331
# Unit test for function compose
def test_compose():
    a = 13
    b = 2
    c = 5
    f = lambda x: x + a
    g = lambda x: x + b
    h = lambda x: x + c

    assert compose(a, f)(b) == a + b
    assert compose(a, f, g)(b) == a + b + b
    assert compose(a, f, g, h)(b) == a + b + b + c



# Generated at 2022-06-24 00:48:28.507853
# Unit test for function find
def test_find():
    collection = [1, 2, 3, 4, 5]
    assert find(collection, lambda item: item == 3) == 3
    assert find(collection, lambda item: item == 6) is None
    assert find(collection, lambda item: item == 1) == 1



# Generated at 2022-06-24 00:48:34.137445
# Unit test for function memoize
def test_memoize():
    @memoize
    def fibonacci(n):
        if n < 2:
            return 1
        return fibonacci(n - 1) + fibonacci(n - 2)

    assert fibonacci(10) == 89



# Generated at 2022-06-24 00:48:39.549455
# Unit test for function curried_map
def test_curried_map():
    for i in range(10):
        assert(reduce(lambda current, item: current + item, curried_map(lambda x: x + 10)([10, 20, 30])) == i * 3 * 10 + (1 + 100))


# Generated at 2022-06-24 00:48:46.206760
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x * x)([1, 2, 3]) == [1, 4, 9]
    assert curried_map(lambda x: x * x, [1, 2, 3]) == [1, 4, 9]



# Generated at 2022-06-24 00:48:51.075040
# Unit test for function curry
def test_curry():
    curried_add2 = curry(lambda x, y: x + y)
    assert curried_add2(1)(1) == 2



# Generated at 2022-06-24 00:48:57.102239
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert eq('a', 'a')
    assert not eq(1, 2)
    assert not eq(None, None)
    assert not eq('1', 1)
    assert not eq('a', 'A')


# Generated at 2022-06-24 00:48:59.259025
# Unit test for function pipe
def test_pipe():
    assert pipe(1, lambda x: x + 2, lambda x: x * 3) == 9



# Generated at 2022-06-24 00:49:03.318298
# Unit test for function memoize
def test_memoize():
    def add(x, y):
        """
        Add two numbers

        :param x: first number
        :type x: Integer
        :param y: second number
        :type y: Integer
        :returns: result of addition
        :rtype: Integer
        """
        return x + y

    curried_add = curry(add)
    assert curried_add(2)(3) == 5
    add_twice = memoize(curried_add)
    assert add_twice(2)(3) == 5
    assert add_twice(2)(2) == 4
    assert add_twice(2)(3) == 5



# Generated at 2022-06-24 00:49:05.302454
# Unit test for function find
def test_find():
    assert(compose(
        compose,
        find([1, 2, 3], eq(1)),
        eq(1)
    )())

# Generated at 2022-06-24 00:49:13.186992
# Unit test for function curried_map
def test_curried_map():
    assert [1, 4, 9, 16] == list(map(lambda x: x * x, [1, 2, 3, 4]))
    curried_map_function = curried_map(lambda x: x * x)
    assert [1, 4, 9, 16] == list(curried_map_function([1, 2, 3, 4]))
    curried_map_function = curried_map(lambda x: x * x, [1, 2, 3, 4])
    assert [1, 4, 9, 16] == list(curried_map_function())



# Generated at 2022-06-24 00:49:16.105030
# Unit test for function curry
def test_curry():
    def add(a, b):
        return a + b

    assert curry(add)()(3, 4) == add(3, 4)
    assert curry(add)(3, 4) == add(3, 4)



# Generated at 2022-06-24 00:49:16.911779
# Unit test for function identity
def test_identity():
    assert identity(10) == 10



# Generated at 2022-06-24 00:49:20.939827
# Unit test for function find
def test_find():
    """
    Unit test for function find

    :returns: Nothing
    :rtype: None
    """
    assert find([1, 2, 3, 4, 5], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda x: x > 4) == 5
    assert find([1, 2, 3, 4, 5], lambda x: x < 0) is None



# Generated at 2022-06-24 00:49:25.940620
# Unit test for function cond
def test_cond():
    condition_list = [
        (eq(0), lambda: 'boo'),
        (eq(1), lambda: 'foo'),
        (eq(2), lambda: 'doo')
    ]

    conditional_function = cond(condition_list)

    assert conditional_function(1) == 'foo'
    assert conditional_function(0) == 'boo'
    assert conditional_function(2) == 'doo'
    assert conditional_function(3) is None



# Generated at 2022-06-24 00:49:36.998336
# Unit test for function cond

# Generated at 2022-06-24 00:49:46.015532
# Unit test for function identity
def test_identity():
    assert identity(True) == True
    assert identity(0) == 0
    assert identity(1) == 1
    assert identity("1") == "1"
    assert identity("True") == "True"
    assert identity("False") == "False"
    assert identity([]) == []
    assert identity(['True', [1]]) == ['True', [1]]
    assert identity((1, ["True", [1]])) == (1, ["True", [1]])
    assert identity({}) == {}
    assert identity({1: "True", 2: [1]}) == {1: "True", 2: [1]}



# Generated at 2022-06-24 00:49:53.255050
# Unit test for function cond
def test_cond():
    is_even = lambda i: i % 2 == 0
    is_odd = lambda i: i % 2 != 0
    print('True value:', cond(
        [
            (is_even, lambda i: str(i) + ' - is even'),
            (is_odd, lambda i: str(i) + ' - is odd'),
        ]
    )(1))

    print('False value:', cond(
        [
            (is_even, lambda i: str(i) + ' - is even'),
            (is_odd, lambda i: str(i) + ' - is odd'),
        ]
    )(2))


# Generated at 2022-06-24 00:49:54.290816
# Unit test for function compose
def test_compose():
    assert compose(2, increase, increase) == 4
    assert compose(2, increase, increase, increase) == 5



# Generated at 2022-06-24 00:49:59.563417
# Unit test for function memoize
def test_memoize():
    """
    Test for function memoize.
    """
    @memoize
    def add(a: int, b: int) -> int:
        """
        Add two numbers.
        """
        return a + b

    assert add(3, 4) == 7
    assert add(3, 4) == 7
    assert add(3, 5) == 8



# Generated at 2022-06-24 00:50:06.168975
# Unit test for function cond
def test_cond():
    def is_positive(x):
        return x > 0

    def is_zero(x):
        return x == 0

    def map_to_positive(x):
        return x

    def map_to_negative(x):
        return -x

    compose_functions = cond([
        (is_positive, map_to_positive),
        (is_zero, map_to_positive),
        (lambda x: True, map_to_negative)
    ])

    assert compose_functions(2) == 2
    assert compose_functions(-2) == -2
    assert compose_functions(0) == 0



# Generated at 2022-06-24 00:50:09.052373
# Unit test for function curried_filter
def test_curried_filter():
    curried_filter_ = curried_filter(lambda x: x % 2 == 0)
    assert curried_filter_([1, 2, 3, 4]) == [2, 4]


# Generated at 2022-06-24 00:50:13.829628
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-24 00:50:18.615224
# Unit test for function find
def test_find():
    assert(find([], identity) is None)
    assert(find([1], identity) is 1)
    assert(find([1, 2, 3, 4], lambda x: x > 2) is 3)
    assert(find([1, 2, 3, 4], lambda x: x > 4) is None)



# Generated at 2022-06-24 00:50:20.915874
# Unit test for function cond
def test_cond():
    condition_list = [
        (eq(2), increase),
        (eq(3), identity)
    ]

    result = cond(condition_list)

    assert result(3) == 3
    assert result(2) == 3



# Generated at 2022-06-24 00:50:27.333597
# Unit test for function curry
def test_curry():
    @curry
    def curried_add(a, b):
        return a + b

    assert curried_add(2)(2) == 4
    assert curried_add(2, 2) == 4
    assert curried_add(2)(2)(2) == 4
    assert curried_add(2, 2, 2) == 4

    # Test that functional currying works
    @curry
    def curried_add_multiply(a, b, c):
        return a + b * c

    assert curried_add_multiply(1)(2)(3) == 7
    assert curried_add_multiply(1, 2)(3) == 7
    assert curried_add_multiply(1)(2, 3) == 7

# Generated at 2022-06-24 00:50:34.489355
# Unit test for function memoize
def test_memoize():
    def test_function(argument):
        return argument + 1

    memoized_function = memoize(test_function)
    assert memoized_function(1) == 2
    assert memoized_function(1) == 2
    memoized_function = memoize(test_function, lambda argument1, argument2: argument1 == argument2)
    assert memoized_function(1) == 2
    assert memoized_function(1) == 2



# Generated at 2022-06-24 00:50:35.111207
# Unit test for function identity
def test_identity():
    assert identity(1) == 1


# Generated at 2022-06-24 00:50:38.836120
# Unit test for function increase
def test_increase():
    assert(increase(2) == 3)
    assert(increase(-2) == -1)
    assert(increase(0) == 1)



# Generated at 2022-06-24 00:50:42.469129
# Unit test for function identity
def test_identity():
    assert(identity(1) == 1)



# Generated at 2022-06-24 00:50:45.708044
# Unit test for function compose
def test_compose():
    function_one = lambda x: x + 1
    function_two = lambda y: y * y

    composed_function = compose(2, function_one, function_two)

    assert(composed_function == 9)



# Generated at 2022-06-24 00:50:48.599430
# Unit test for function memoize
def test_memoize():
    @memoize
    def factorial(n):
        if n == 0:
            return 1
        return n * factorial(n - 1)

    assert factorial(100000) == factorial(100000)

    print('Test for function memoize has been done successfully.')



# Generated at 2022-06-24 00:50:56.997938
# Unit test for function eq
def test_eq():
    assert eq(1, 1) and eq('a', 'a') or \
        eq(False, False) and eq(1.1, 1.1) or \
        eq([1, 2, 3], [1, 2, 3]), 'Function eq should returned same values'
    assert not eq(1, 0) and not eq('a', 'b') or \
        not eq(False, True) and not eq(1.1, 1.0) or \
        not eq([1, 2, 3], [1, 2, 3]), 'Function eq should returned different values'



# Generated at 2022-06-24 00:50:57.615994
# Unit test for function identity
def test_identity():
    print(identity(10))


# Generated at 2022-06-24 00:51:00.166953
# Unit test for function eq
def test_eq():
    """
    Test eq method
    """
    assert eq(1, 1)
    assert not eq(2, 3)
    assert not eq(1, '1')



# Generated at 2022-06-24 00:51:01.230245
# Unit test for function eq
def test_eq():
    assert eq(2, 2) == True
    assert eq(a=2, value=2) == True
    assert eq(3, 2) == False



# Generated at 2022-06-24 00:51:02.961413
# Unit test for function curry
def test_curry():
    """Test function curry."""
    assert curry(increase)(3) == 4
    assert curry(increase, 1)(3) == 4



# Generated at 2022-06-24 00:51:12.092540
# Unit test for function curried_map
def test_curried_map():
    """
    :returns:
    :rtype:
    """
    assert curried_map(increase, [10]) == [11]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, []) == []
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    map_inc = curried_map(increase)
    assert map_inc([1, 2, 3]) == [2, 3, 4]
    assert map_inc([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-24 00:51:20.297805
# Unit test for function pipe
def test_pipe():
    from hypothesis import given, strategies as st

    @given(st.lists(st.integers()))
    def test_pipe_curried_map(x):
        assert pipe(
            x,
            [[1, 2, 3], curried_map(increase)]
        ) == [2, 3, 4]

    test_pipe_curried_map()

    @given(st.lists(st.integers()))
    def test_pipe_curried_filter(x):
        assert pipe(
            x,
            [[1, 2, 3], curried_filter(lambda x: x % 2 == 1)]
        ) == [1, 3]

    test_pipe_curried_filter()



# Generated at 2022-06-24 00:51:25.382914
# Unit test for function identity
def test_identity():
    assert identity(None) == None
    assert identity(True) == True
    assert identity(False) == False
    assert identity(1) == 1
    assert identity(0.5) == 0.5
    assert identity('word') == 'word'
    assert identity('1') == '1'
    assert identity('') == ''
    assert identity([]) == []
    assert identity([1, 2, 3]) == [1, 2, 3]
    assert identity({}) == {}
    assert identity({1: 1, 2: 2, 3: 3}) == {1: 1, 2: 2, 3: 3}
    assert identity(type) == type



# Generated at 2022-06-24 00:51:29.013141
# Unit test for function pipe
def test_pipe():
    def add(x):
        return x + 10

    def sub(x):
        return x - 10

    assert pipe(
        1,
        add,
        sub
    ) == 1



# Generated at 2022-06-24 00:51:33.920179
# Unit test for function curried_map
def test_curried_map():
    # Test for list of Integer and increase
    assert [2, 3, 4] == curried_map(increase)([1, 2, 3])
    # Test for list of integer and string
    assert ["1", "2", "3"] == curried_map(str)([1, 2, 3])



# Generated at 2022-06-24 00:51:39.848838
# Unit test for function compose
def test_compose():
    assert compose(1, increase, increase) == 3
    assert compose(1, increase, identity, increase) == 3
    assert compose("", lambda x: x.upper(), lambda x: x.lower()) == ""
    assert compose("abc", lambda x: x.upper(), lambda x: x.lower()) == "abc"
    assert compose("1", lambda x: x.upper(), lambda x: "") == ""
    assert compose("", identity, lambda x: "1") == "1"


# Generated at 2022-06-24 00:51:40.599503
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-24 00:51:41.540816
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:51:44.225070
# Unit test for function find
def test_find():
    assert find([], eq(2)) is None
    assert find([1], eq(2)) is None
    assert find([1, 2, 3], eq(2)) == 2
    assert find([1, 2, 3], eq(4)) is None



# Generated at 2022-06-24 00:51:48.404093
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity('hello') == 'hello'
    assert identity(True) is True


# Generated at 2022-06-24 00:51:54.202348
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 0)([-1, 0, 1, 2, 3]) == [1, 2, 3]
    assert curried_filter(lambda x: x < 0, [-1, 0, 1, 2, 3]) == [-1]

if __name__ == '__main__':
    test_curried_filter()

# Generated at 2022-06-24 00:51:55.280326
# Unit test for function increase
def test_increase():
    assert increase(3) == 4



# Generated at 2022-06-24 00:52:00.077249
# Unit test for function pipe
def test_pipe():
    """
    Test pipe function
    """
    pipe_result = pipe(1, identity, increase, increase, identity)
    assert pipe_result == 3, 'Wrong result'
    pipe_result = pipe(0, identity, increase, increase, identity)
    assert pipe_result == 2, 'Wrong result'



# Generated at 2022-06-24 00:52:01.607095
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-24 00:52:07.900234
# Unit test for function memoize
def test_memoize():
    def f(x):
        return x * x * x

    def g(x):
        return x * x

    def cond_f(x):
        return x % 2 == 0

    def cond_g(x):
        return x % 2 != 0

    def cond_h(x):
        return x == 5

    result = cond(
        [(cond_f, f), (cond_g, g), (cond_h, identity)]
    )

    @memoize
    def t(n):
        return result(n)

    for i in range(1, 10):
        if i % 2 == 0:
            assert t(i) == i * i * i
        elif i % 2 != 0:
            assert t(i) == i * i
        else:
            assert t(i) == 5
    assert len

# Generated at 2022-06-24 00:52:13.036738
# Unit test for function memoize
def test_memoize():
    def increase_number(number):
        time.sleep(1)
        return number + 1

    memoized_increase_number = memoize(increase_number)
    start = time.time()
    assert memoized_increase_number(1) == 2
    first_call_duration = time.time() - start
    assert first_call_duration >= 1
    start = time.time()
    assert memoized_increase_number(1) == 2
    second_call_duration = time.time() - start
    assert second_call_duration < 1


# Generated at 2022-06-24 00:52:14.227528
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:52:17.337543
# Unit test for function curry
def test_curry():
    def sum(x, y):
        return x + y
    assert curry(sum, 3)(1)(2)(3) == 6



# Generated at 2022-06-24 00:52:27.706687
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 3, [5, 6])([5, 6]) == [8, 9]
    assert curried_map(lambda x: x + 3)([5, 6]) == [8, 9]
    assert curried_map(lambda x: x + 3)([5, 6, 7]) == [8, 9, 10]
    assert isinstance(curried_map(lambda x: x + 3), curried_map)
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3])([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-24 00:52:32.474827
# Unit test for function memoize
def test_memoize():
    counter = 0

    @memoize
    def add(x):
        nonlocal counter
        counter += 1
        return x + 1

    assert counter == 0

    assert add(1) == 2
    assert counter == 1

    assert add(1) == 2
    assert counter == 1

    assert add(1) == 2
    assert counter == 1

    assert add(2) == 3
    assert counter == 2



# Generated at 2022-06-24 00:52:36.257808
# Unit test for function compose
def test_compose():
    assert compose(
        'chess',
        lambda x: x[::-1],
        str.lower,
        lambda x: x + '!',
    ) == '!sshec'


# Generated at 2022-06-24 00:52:38.404207
# Unit test for function eq
def test_eq():
    assert eq("test", "test") == True
    assert eq("test", "test1") == False



# Generated at 2022-06-24 00:52:46.293580
# Unit test for function curried_map
def test_curried_map():
    assert [2, 3, 4] == curried_map(lambda x: x + 1)([1, 2, 3])
    assert [2, 3, 4] == curried_map(lambda x: x + 1, [1, 2, 3])
    assert [2, 3, 4] == curried_map(increase, [1, 2, 3])
    assert [2, 3, 4] == curried_map(increase)([1, 2, 3])
    assert [3, 4, 5] == curried_map(increase, [2, 3, 4])
    assert [3, 4, 5] == curried_map(increase)([2, 3, 4])


# Generated at 2022-06-24 00:52:47.733075
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(0), [0, 0, 1, 2]) == [0, 0]



# Generated at 2022-06-24 00:52:54.331849
# Unit test for function curried_filter
def test_curried_filter():
    assert (curried_filter(eq(2), [1, 2, 3])) == [2]
    assert (curried_filter(eq(2))([1, 2, 3])) == [2]



# Generated at 2022-06-24 00:52:55.532389
# Unit test for function compose
def test_compose():
    assert compose(1, identity, increase) == 2



# Generated at 2022-06-24 00:52:58.597411
# Unit test for function curry
def test_curry():
    assert curry(lambda a: a, 1)(1) == 1
    assert curry(lambda a, b: b, 2)(1) == 1
    assert curry(lambda a, b: a + b, 2)(1) == 2



# Generated at 2022-06-24 00:52:59.484806
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:53:00.304510
# Unit test for function increase
def test_increase():
    assert increase(0) == 1



# Generated at 2022-06-24 00:53:10.007815
# Unit test for function memoize
def test_memoize():
    counter = 0

    def count(*_):
        nonlocal counter

        counter += 1
        return counter

    memoized_count = memoize(count, key=identity)

    assert memoized_count(1) == 1
    assert memoized_count(1) == 1
    assert memoized_count(2) == 2
    assert memoized_count(1) == 1
    assert memoized_count(2) == 2
    assert memoized_count(2) == 2
    assert memoized_count(2) == 2
    assert memoized_count(1) == 1
    assert memoized_count(3) == 3
    assert memoized_count(1) == 1


# Generated at 2022-06-24 00:53:10.875006
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:53:20.991411
# Unit test for function cond
def test_cond():
    condition = [
        (lambda val: val >= 0, print),
        (lambda val: val < 0, lambda x: print('Value is negative'))
    ]
    result = cond(condition)
    try:
        result(1)
    except NameError:
        pass  # Unit test not passed
    else:
        raise Exception('Wrong definition of cond')  # Unit test passed
    try:
        result(-1)
    except NameError:
        pass  # Unit test not passed, continue
    else:
        raise Exception('Wrong definition of cond')  # Unit test passed
    try:
        result(0)
    except NameError:
        pass  # Unit test not passed, continue
    else:
        raise Exception('Wrong definition of cond')  # Unit test passed



# Generated at 2022-06-24 00:53:24.229611
# Unit test for function curried_map
def test_curried_map():
    l = [1, 2, 3, 4, 5]
    assert curried_map(increase)(l) == [2, 3, 4, 5, 6]



# Generated at 2022-06-24 00:53:29.620978
# Unit test for function compose
def test_compose():
    composed = compose(3, increase, identity)
    assert composed == 4, 'compose positive test'
    composed = compose(3, increase, identity, increase)
    assert composed == 5, 'compose positive test'

    composed = compose(3, increase, identity, lambda x: x/0)
    assert composed == 5, 'compose negative test'



# Generated at 2022-06-24 00:53:40.497289
# Unit test for function curry
def test_curry():
    assert (lambda x, y: x + y)(1, 2) == 3
    assert curry(lambda x, y: x + y)(1, 2) == 3
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, m, n: x + y + m + n)(1)(2, 3)(4) == 10
    assert curry(lambda x, y, m, n: x + y + m + n)(1, 2)(3)(4) == 10
    assert curry(lambda x, y, m, n: x + y + m + n)(1, 2)(3, 4) == 10
    assert curry(lambda x, y, m, n: x + y + m + n)(1, 2, 3)(4) == 10

# Generated at 2022-06-24 00:53:46.963313
# Unit test for function cond
def test_cond():
    assert cond([(lambda x: x == 0, lambda x: 'zero'),
                 (lambda x: x % 2 == 0, lambda x: 'event'),
                 (lambda x: True, lambda x: 'odd')])(2) == 'event'
    assert cond([(lambda x: x == 0, lambda x: 'zero'),
                 (lambda x: x % 2 == 0, lambda x: 'event'),
                 (lambda x: True, lambda x: 'odd')])(1) == 'odd'
    assert cond([(lambda x: x == 0, lambda x: 'zero'),
                 (lambda x: x % 2 == 0, lambda x: 'event'),
                 (lambda x: True, lambda x: 'odd')])(0) == 'zero'



# Generated at 2022-06-24 00:53:48.473263
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(1), [1, 2, 3]) == [1]



# Generated at 2022-06-24 00:53:53.898292
# Unit test for function curried_filter
def test_curried_filter():
    numbers = [4, 5, 6, 7, 8, 9]
    assert curried_filter(lambda x: x > 5, numbers) == [6, 7, 8, 9]



# Generated at 2022-06-24 00:53:56.573304
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3, 4]) == [2, 3, 4, 5]



# Generated at 2022-06-24 00:53:59.521648
# Unit test for function compose
def test_compose():
    """
    Test compose function.
    """
    compose_test = compose(
        1,
        increase,
        increase,
        increase
    )
    assert compose_test == 4


# Generated at 2022-06-24 00:54:08.434251
# Unit test for function cond
def test_cond():
    def is_integer(value):
        return isinstance(value, int)

    def is_string(value):
        return isinstance(value, str)

    def is_str_1(value):
        return value == '1'

    is_numbers = cond([
        (is_integer, lambda x: True),
        (is_string, is_str_1)
    ])

    assert is_numbers(1)
    assert is_numbers('1')
    assert not is_numbers(2)
    assert not is_numbers('2')

# Generated at 2022-06-24 00:54:17.259867
# Unit test for function cond
def test_cond():
    def get_number(number: int) -> int:
        return number

    def get_string(string: str) -> str:
        return string

    def get_string_two() -> str:
        return "2"

    def test_function(test_value: int) -> Any:
        return cond([
            (lambda value: value == 1, get_string),
            (lambda value: value == 2, get_string_two),
            (lambda value: value == 3, get_number),
        ])(test_value)

    assert test_function(1) == "1"
    assert test_function(2) == "2"
    assert test_function(3) == 3

