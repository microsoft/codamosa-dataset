

# Generated at 2022-06-24 00:44:20.191370
# Unit test for function memoize
def test_memoize():
    # Arrange
    @memoize
    def factorial(number):
        if number == 0:
            return 1
        return number * factorial(number - 1)

    # Arrange
    @memoize
    def fibonacci(number):
        if number <= 2:
            return 1
        return fibonacci(number-1) + fibonacci(number-2)

    # Act & Assert
    assert factorial(4) == 24
    assert factorial(4) == 24
    assert fibonacci(8) == 21
    assert fibonacci(8) == 21


# Generated at 2022-06-24 00:44:22.039747
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(2), [1, 2, 3, 2]) == [2, 2]


# Generated at 2022-06-24 00:44:31.208456
# Unit test for function memoize
def test_memoize():
    def fn(x):
        return x + 1

    fn_memoized = memoize(fn)
    assert fn_memoized(1) == 2
    assert fn_memoized(1) == 2

    def fn(x):
        return x + x

    fn_memoized = memoize(fn)
    assert fn_memoized(1) == 2
    assert fn_memoized(0) == 0

    def fn(x):
        return x * x * x

    fn_memoized = memoize(fn)
    assert fn_memoized(1) == 1
    assert fn_memoized(2) == 8
    assert fn_memoized(3) == 27



# Generated at 2022-06-24 00:44:33.352026
# Unit test for function pipe
def test_pipe():
    assert pipe(1, lambda x: x + 1) == 1 + 1, \
        "Pipe should return the result of second function"
    assert pipe(1, lambda x: x + 1, lambda x: x * 2) == 2 * (1 + 1), \
        "Pipe should return the result of all functions"



# Generated at 2022-06-24 00:44:33.973271
# Unit test for function increase
def test_increase():
    """Test for function increase"""
    assert increase(3) == 4


# Generated at 2022-06-24 00:44:40.457024
# Unit test for function cond
def test_cond():
    def test_function():
        def f1():
            return 'f1'

        def f2():
            return 'f2'
        return cond([
            (lambda _: True, f1),
            (lambda _: True, f2),
        ])()

    assert test_function() == 'f1'



# Generated at 2022-06-24 00:44:42.114008
# Unit test for function compose
def test_compose():
    assert compose(1, lambda x: x + 1, lambda x: x * 2) == 4
    assert compose(1, lambda x: x + 1) == 2



# Generated at 2022-06-24 00:44:43.832518
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(2)) == 2
    assert find([1, 2, 3], eq(4)) is None



# Generated at 2022-06-24 00:44:55.623372
# Unit test for function cond
def test_cond():
    def test_fn(x: int) -> int:
        return x

    def test_fn1(x: int) -> str:
        return str(x)

    def test_fn2(x: int) -> float:
        return float(x)

    def test_fn3(x: int) -> list:
        return [x]

    def test_fn4(x: int) -> dict:
        return dict(x=x)

    def test_fn5(x: int) -> tuple:
        return tuple([x])

    def test_fn6(x: int) -> bool:
        return bool(x)

    # define curried functions
    grater_than_zero = lambda x: x > 0

    # call cond

# Generated at 2022-06-24 00:45:00.335350
# Unit test for function memoize
def test_memoize():
    assert memoize(increase)(1) == 2
    assert memoize(increase, key=lambda x, y: True)(2) == 3
    assert memoize(increase, key=lambda x, y: False)(3) == 5


# Generated at 2022-06-24 00:45:11.751821
# Unit test for function compose
def test_compose():
    assert eq(compose(
        5,
        lambda x: x * 5,
        lambda x: x + 2
    ), 27)
    assert not eq(compose(
        5,
        lambda x: x * 5,
        lambda x: x + 2
    ), 26)
    assert compose('.',
                   lambda x: x * 3,
                   lambda x: x + x + x) == '...'
    assert not eq(compose('.',
                          lambda x: x * 3,
                          lambda x: x + x + x), '..')
    assert compose(
        [1, 2, 3],
        lambda x: x + 1,
        lambda x: x + 2,
        lambda x: x + 3
    ) == [7, 8, 9]

# Generated at 2022-06-24 00:45:21.799433
# Unit test for function memoize
def test_memoize():
    """
    Test for function memoize.
    """
    import time
    def run_time(function):
        def fn(*args):
            start = time.clock()
            result = function(*args)
            print('Run time: ', (time.clock() - start))
            return result
        return fn

    @run_time
    def fib(n):
        if n == 0:
            return 0
        if n == 1:
            return 1
        return fib(n - 1) + fib(n - 2)

    # Test for run time
    print(fib(25))
    print()

    # Test for memoize
    @memoize
    def fib(n):
        if n == 0:
            return 0
        if n == 1:
            return 1

# Generated at 2022-06-24 00:45:23.688720
# Unit test for function eq
def test_eq():
    assert eq(1, 1)



# Generated at 2022-06-24 00:45:25.292578
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-24 00:45:30.668328
# Unit test for function curry
def test_curry():
    result = curry(lambda x, y, z: x + y + z)(1)(2)(3)
    assert result == 6

    result = curry(lambda x, y, z: x + y + z)(1, 2)(3)
    assert result == 6

    result = curry(lambda x, y, z: x + y + z)(1)(2, 3)
    assert result == 6

    result = curry(lambda x, y, z: x + y + z)(1, 2, 3)
    assert result == 6



# Generated at 2022-06-24 00:45:35.910984
# Unit test for function pipe
def test_pipe():
    assert pipe(3, identity, increase) == 3
    assert pipe(3, increase, increase) == 5
    assert pipe('Hello', identity, lambda x: x + ' world!') == 'Hello world!'



# Generated at 2022-06-24 00:45:38.156285
# Unit test for function compose
def test_compose():
    assert compose(
        3,
        increase,
        increase
    ) == 5
    assert compose(
        5,
        increase,
        increase,
        increase
    ) == 8


# Generated at 2022-06-24 00:45:46.415858
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z, 2)(1)(2) == 3


# Generated at 2022-06-24 00:45:49.746186
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]


# Generated at 2022-06-24 00:45:57.898299
# Unit test for function find
def test_find():
    # Given
    collection1 = [
        {"id": 1, "value": 1},
        {"id": 1},
        {"id": 2, "value": 1},
        {"id": 2},
        {"id": 3, "value": 2},
    ]

    def finder1(item):
        return item.get('id') == 2

    collection2 = [
        {"id": 1, "value": 1},
        {"id": 1},
        {"id": 2, "value": 1},
        {"id": 2},
        {"id": 3, "value": 2},
    ]

    def finder2(item):
        return item.get('id') == 2 and item.get('value') == 1

    # When
    result1 = find(collection1, finder1)

# Generated at 2022-06-24 00:46:01.914362
# Unit test for function curried_map
def test_curried_map():
    list1 = [1, 2, 3, 4, 5]
    assert curried_map(identity, list1) == [1, 2, 3, 4, 5]
    assert curried_map(increase, list1) == [2, 3, 4, 5, 6]


# Generated at 2022-06-24 00:46:04.753948
# Unit test for function increase
def test_increase():
    test_cases = [
        (1, 2),
        (2, 3),
    ]
    for test_case in test_cases:
        assert increase(test_case[0]) == test_case[1]



# Generated at 2022-06-24 00:46:08.067081
# Unit test for function curried_filter
def test_curried_filter():
    # Normal test
    def is_even(x):
        return x % 2 == 0

    assert [2, 4] == curried_filter(is_even, [1, 2, 3, 4])



# Generated at 2022-06-24 00:46:10.170871
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True, "EQ test failed"
    assert eq(1, 2) is False, "NEQ test failed"



# Generated at 2022-06-24 00:46:11.559296
# Unit test for function eq
def test_eq():
    assert eq(1, 2) is False
    assert eq(1, 1) is True



# Generated at 2022-06-24 00:46:18.606603
# Unit test for function find
def test_find():
    cases = [
        (
            [(1, "one"), (2, "two")],
            1,
            (1, "one")
        ),
        (
            [],
            None,
            None
        )
    ]

    for collection, key, expected_result in cases:
        assert find(collection, lambda item: item[0] == key) == expected_result, \
            f"find({collection}, lambda item: item[0] == {key}) != {expected_result}"



# Generated at 2022-06-24 00:46:26.990799
# Unit test for function curry
def test_curry():
    is_even = curry(lambda x, y: x % y == 0)
    assert is_even(2)(2) == True
    assert is_even(3)(2) == False

    map_curry = curry(lambda mapper, collection: map(mapper, collection))
    assert isinstance(map_curry, type(lambda: 0))
    assert next(map_curry(lambda x: x ** 2)(range(1, 9))) == 1
    assert next(map_curry(lambda x: x + 1)(range(3))) == 1



# Generated at 2022-06-24 00:46:29.156178
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4]) == [3, 4]



# Generated at 2022-06-24 00:46:29.959692
# Unit test for function find
def test_find():
    asse

# Generated at 2022-06-24 00:46:42.123420
# Unit test for function curried_filter
def test_curried_filter():
    print('start test curry filter')

    def get_first_even_number(numbers: List[int]) -> int:
        return curried_filter(lambda number: number % 2 == 0)(numbers)[0]

    get_first_even_number_from_5 = curry(get_first_even_number, 1)
    get_first_even_number_from_5_2_1_4_3_5_6_7_8_9_0 = curry(
        get_first_even_number,
        10
    )
    # Test 1. Get first even from [5, 2, 1, 4, 3, 5, 6, 7, 8, 9, 0]

# Generated at 2022-06-24 00:46:49.313955
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z, 4)(1, 2, 3) == 6
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y: x + y)(1, 2) == 3




# Generated at 2022-06-24 00:46:51.161858
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(False) is False
    assert identity([]) == []
    assert identity(None) is None



# Generated at 2022-06-24 00:46:52.660641
# Unit test for function eq
def test_eq():
    assert eq(2, 2)
    assert not(eq(1, 2))



# Generated at 2022-06-24 00:47:00.169590
# Unit test for function cond
def test_cond():
    """
    Test function cond.
    """
    function = cond([
        (lambda x: x % 2 == 0, lambda x: x * 2),
        (lambda x: x % 3 == 0, lambda x: x * 3),
        (lambda _: True, lambda x: x),
    ])

    assert function(2) == 4
    assert function(3) == 9
    assert function(4) == 8
    assert function(5) == 5
    assert function(6) == 12
    assert function(7) == 7

# Generated at 2022-06-24 00:47:02.898061
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 3, 4]

    assert curried_filter(eq(4))(collection) == [4]


test_curried_filter()



# Generated at 2022-06-24 00:47:07.598118
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(None) is None
    assert identity([]) == []



# Generated at 2022-06-24 00:47:11.391178
# Unit test for function compose
def test_compose():
    assert compose(0, increase, increase, increase, increase) == 4
    assert compose(0, lambda x: x + 1, lambda x: x + 1) == 2
    assert compose("", lambda x: x.strip(), lambda x: x.split(" ")) == []
    return True

# Generated at 2022-06-24 00:47:15.951618
# Unit test for function curried_map
def test_curried_map():
    """
    Tests for curried_map function

    :returns: None
    :rtype: None
    """
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]

    squared = curried_map(lambda x: x ** 2)
    assert squared([1, 2, 3]) == [1, 4, 9]
    assert squared([3, 4, 5]) == [9, 16, 25]

    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-24 00:47:26.978907
# Unit test for function curry
def test_curry():
    def test_fn(a, b, c, d):
        return a + b + c + d

    test_fn1 = curry(test_fn)
    test_fn2 = curry(test_fn, 2)

    assert test_fn1(1, 2, 3, 4) == test_fn(1, 2, 3, 4)
    assert test_fn1(1, 2)(3, 4) == test_fn(1, 2, 3, 4)
    assert test_fn1(1)(2)(3)(4) == test_fn(1, 2, 3, 4)

    assert test_fn2(1, 2)(3, 4) == test_fn(1, 2, 3, 4)
    assert test_fn2(1)(2)(3, 4) == test_fn(1, 2, 3, 4)




# Generated at 2022-06-24 00:47:31.124617
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

    filter_fn = curried_filter(lambda value: value % 2 == 0)
    assert filter_fn(collection) == [2, 4, 6, 8, 10]

    filter_fn = curried_filter(lambda value: value % 2 == 0, collection)
    assert filter_fn() == [2, 4, 6, 8, 10]


# Unit tests for function identity

# Generated at 2022-06-24 00:47:38.377510
# Unit test for function memoize
def test_memoize():
    """
    Unit test for function memoize

    :returns: Nothing.
    :rtype: None
    """
    def test_fn(i):
        time.sleep(1)
        return i + 1

    def test_equal_fn(a, b):
        return (a-1) == b

    start_time = float(time.time())
    test_memoize_fn = memoize(test_fn, test_equal_fn)
    assert test_memoize_fn(1) == 2
    # because result of the first call is saved in cache,
    # it takes 0s not 1s
    assert (time.time() - start_time) < 1



# Generated at 2022-06-24 00:47:41.188250
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x+1)([1,2,3]) == [2,3,4]
    assert curried_map(lambda x: x+1)([]) == []
    assert curried_map(lambda x: x+1)([1,2,3,4,5]) == [2,3,4,5,6]


# Generated at 2022-06-24 00:47:42.784698
# Unit test for function eq
def test_eq():
    assert eq(3, 3)
    assert not eq(2, 3)



# Generated at 2022-06-24 00:47:43.829685
# Unit test for function compose
def test_compose():
    assert compose(1, increase, increase, curry(eq)(2)) == True



# Generated at 2022-06-24 00:47:49.224708
# Unit test for function curried_map
def test_curried_map():
    curried_mapper = curried_map(increase)
    assert [1, 2, 3] == curried_map(identity, [0, 1, 2])
    assert [1, 2, 3] == curried_mapper([0, 1, 2])
    assert [1, 2, 3] == curried_mapper([1, 2])([0, 1, 2])



# Generated at 2022-06-24 00:47:53.559260
# Unit test for function identity
def test_identity():
    assert identity(3) == 3
    assert identity('3') == '3'
    assert identity(True) is True
    assert identity(False) is False



# Generated at 2022-06-24 00:48:02.122592
# Unit test for function cond
def test_cond():
    def odd(x: int) -> bool:
        return x % 2 == 1

    def even(x: int) -> bool:
        return x % 2 == 0

    def inc(x: int) -> int:
        return x + 1

    def dec(x: int) -> int:
        return x - 1

    test1 = cond(
        [(odd, inc),
         (even, dec),
         (identity, identity)])

    test2 = cond(
        [(even, dec),
         (odd, inc),
         (identity, identity)])

    assert test1(3) == 4
    assert test1(6) == 5
    assert test1(7) == 7

    assert test2(3) == 3
    assert test2(6) == 5
    assert test2(7) == 8



# Generated at 2022-06-24 00:48:02.726530
# Unit test for function identity
def test_identity():
    assert identity(True) is True



# Generated at 2022-06-24 00:48:04.882196
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)

    eq_1 = eq(1)
    assert eq_1(1)
    assert not eq_1(2)



# Generated at 2022-06-24 00:48:09.282679
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1, 'a')
    assert not eq(1, [1])
    assert not eq(1, {'a': 1})



# Generated at 2022-06-24 00:48:13.418408
# Unit test for function curried_filter
def test_curried_filter():
    def even_numbers(numbers):
        return curried_filter(lambda x: x % 2 == 0)(numbers)

    assert even_numbers([1, 2, 3, 4]) == [2, 4]
    assert even_numbers([2, 3, 4, 5, 6]) == [2, 4, 6]



# Generated at 2022-06-24 00:48:16.412107
# Unit test for function curry
def test_curry():
    def add_three_numbers(a, b, c):
        return a + b + c

    curried = curry(add_three_numbers)
    assert curried(1)(2)(3) == 6
    assert curried(4)(5)(6) == 15



# Generated at 2022-06-24 00:48:19.780677
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3, 4]) == [2, 3, 4, 5]
    assert curried_map(increase, [1, 2, 3, 4]) == [2, 3, 4, 5]


# Generated at 2022-06-24 00:48:28.077517
# Unit test for function curry
def test_curry():
    from random import randint

    def mult(x, y, z):
        return x * y * z

    times_three = curry(mult)(3)
    multiple_three = curry(mult, 3)
    assert times_three(2, 2) == multiple_three(2, 2)

    a = randint(1, 5)
    b = randint(1, 5)
    c = randint(1, 5)

    assert mult(a, b, c) == times_three(a, b)
    assert mult(a, b, c) == multiple_three(a, b)



# Generated at 2022-06-24 00:48:33.100283
# Unit test for function eq
def test_eq():
    # True case
    assert eq(1, 1)

    # False case
    assert not eq(1, 2)


# Generated at 2022-06-24 00:48:35.058535
# Unit test for function pipe
def test_pipe():
    actual_result = pipe(
        1,
        curry(lambda x, y: x * y)(2),
        increase,
        curry(lambda x, y: x + y)(3),
        curry(lambda x, y: x ** y)(2),
    )

    assert actual_result == 25, f'Actual result {actual_result}'



# Generated at 2022-06-24 00:48:36.606669
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x == 2, [1, 2, 3]) == [2]



# Generated at 2022-06-24 00:48:38.319243
# Unit test for function find
def test_find():
    print(find([1, 2, 3], lambda x: x % 2 == 0))



# Generated at 2022-06-24 00:48:40.227828
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 5, [1, 2, 3]) == [6, 7, 8]



# Generated at 2022-06-24 00:48:44.489084
# Unit test for function eq
def test_eq():
    assert 1 == eq(1)(1)
    assert eq(0)(0)
    assert not eq(0)(1)



# Generated at 2022-06-24 00:48:47.102015
# Unit test for function curried_map
def test_curried_map():
    assert [2, 3, 4] == curried_map(lambda x: x + 1)([1, 2, 3])


# Generated at 2022-06-24 00:48:51.063749
# Unit test for function compose
def test_compose():
    assert compose(1, increase, increase) == 3


# Generated at 2022-06-24 00:48:52.334490
# Unit test for function identity
def test_identity():
    assert identity('Hello') == 'Hello'



# Generated at 2022-06-24 00:49:00.537195
# Unit test for function cond
def test_cond():
    def is_even(value: int) -> bool:
        sqrt_value = sqrt(value)
        return (sqrt_value - floor(sqrt_value)) == 0.0

    get_result_message = cond([
        (is_even, lambda value: f'{value} is even'),
        (lambda value: True, lambda value: f'{value} is odd')
    ])

    assert get_result_message(1) == '1 is odd'
    assert get_result_message(2) == '2 is even'
    assert get_result_message(2 ** 2) == '4 is even'
    assert get_result_message(2 ** 3) == '8 is odd'



# Generated at 2022-06-24 00:49:09.898043
# Unit test for function cond
def test_cond():
    def even(f):
        return f % 2 == 0

    def odd(f):
        return not even(f)

    def double(f):
        return f * 2

    def square(f):
        return f * f

    def multiply_by_self(f):
        return f * f

    condition = cond([
        (even, double),
        (odd, square),
        (multiply_by_self, identity),
    ])

    assert condition(6) == 12
    assert condition(3) == 9
    assert condition(5) == 25



# Generated at 2022-06-24 00:49:12.939131
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(1) != 2
    assert identity("abc") == "abc"
    assert identity("abc") != "abcd"
    assert identity(None) is None
    assert identity(True) is True
    assert identity(False) is False



# Generated at 2022-06-24 00:49:19.578594
# Unit test for function find
def test_find():
    """
    Unit test for function find.
    """
    find_first_equal_six = find([3, 6, 8, 10], lambda x: x == 6)
    assert find_first_equal_six == 6

    find_something_not_found = find([1, 3, 5, 7, 9], lambda x: x == 6)
    assert find_something_not_found is None

    # In this case part of test is not passed, because filtration happens inside mapping
    find_something_not_found = find([1, 3, 5, 7, 9], lambda x: x == 1)
    assert find_something_not_found is None



# Generated at 2022-06-24 00:49:21.126422
# Unit test for function memoize
def test_memoize():
    """
    >>> @memoize
    ... def add(x, y):
    ...     return x + y
    >>> add(1, 2)
    3
    >>> add(1, 3)
    4
    >>> add(1, 2)
    3
    """



# Generated at 2022-06-24 00:49:25.805711
# Unit test for function cond
def test_cond():
    def is_even(x):
        return x % 2 == 0

    def is_odd(x):
        return x % 2 == 1

    def increment(x):
        return x + 1

    def decrement(x):
        return x - 1

    fn = cond([(is_even, increment), (is_odd, decrement)])

    assert fn(2) == 3
    assert fn(1) == 0



# Generated at 2022-06-24 00:49:28.464653
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(None) is None
    assert identity([]) == []
    assert identity(('a', 1)) == ('a', 1)
    assert identity({'a', 1}) == {'a', 1}



# Generated at 2022-06-24 00:49:38.803887
# Unit test for function pipe
def test_pipe():
    # Return result of function pipe
    pipe_result = pipe(
        42,
        increase,
        lambda v: v + 42
    )

    # Test if result is expected
    # test_1
    assert pipe_result == 42 + 1 + 42
    assert type(pipe_result) is int

    # Test if result is expected
    # test_2
    pipe_result = pipe(
        '42',
        int,
        lambda v: v + 42,
        lambda v: v / 2,
    )

    # Test if result is expected
    assert pipe_result == (42 + 42) / 2
    assert type(pipe_result) is int



# Generated at 2022-06-24 00:49:40.019909
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2



# Generated at 2022-06-24 00:49:41.729761
# Unit test for function pipe
def test_pipe():
    assert pipe('payload', lambda x: x + 1, lambda x: x * 3) == 12



# Generated at 2022-06-24 00:49:46.500347
# Unit test for function increase
def test_increase():
    """
    Test for function increase.
    """
    assert increase(1) == 2
    assert increase(10) == 11


# Generated at 2022-06-24 00:49:50.756136
# Unit test for function memoize
def test_memoize():
    def calc_function(argument):
        import time
        time.sleep(0.1)
        return argument + 1

    memoized_function = memoize(calc_function)
    assert(memoized_function(2) == 3)

    import time
    start = time.time()
    memoized_function(2)
    end = time.time()
    assert(end - start < 0.05)

# Generated at 2022-06-24 00:49:53.723417
# Unit test for function curried_map
def test_curried_map():
    assert curry(curried_map)(increase)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-24 00:49:57.973504
# Unit test for function curried_filter
def test_curried_filter():
    def filter_fn(x):
        return x % 2 == 0

    filter_fn_curried = curried_filter(filter_fn)
    assert [2, 4] == filter_fn_curried([1, 2, 3, 4, 5, 6])



# Generated at 2022-06-24 00:50:00.281398
# Unit test for function eq
def test_eq():
    assert eq(4, 4)
    assert not eq(4, 5)
    assert eq([1, 2], [1, 2])
    assert not eq([1, 2], [1, 3])

    eq2 = eq(2)
    assert eq2(2)
    assert not eq2(3)



# Generated at 2022-06-24 00:50:02.558345
# Unit test for function memoize
def test_memoize():
    def mem_func(num):
        return num + 1

    mem_func = memoize(mem_func)

    assert mem_func(2) == 3
    assert mem_func(2) == 3
    assert mem_func(3) == 4
    assert mem_func(3) == 4


# Generated at 2022-06-24 00:50:03.988804
# Unit test for function identity
def test_identity():
    assert compose(10, identity) == 10
    assert identity(10) == 10


# Generated at 2022-06-24 00:50:08.164926
# Unit test for function memoize
def test_memoize():
    def factorial(value):
        if value < 2:
            return 1
        return value * factorial(value - 1)

    assert 1 == factorial(0)
    assert 1 == factorial(1)
    assert 2 == factorial(2)
    factorial_memoized = memoize(factorial)
    assert 1 == factorial_memoized(0)
    assert 1 == factorial_memoized(1)
    assert 2 == factorial_memoized(2)

# Generated at 2022-06-24 00:50:12.737231
# Unit test for function compose
def test_compose():
    assert compose(
        0,
        lambda x: x + 1
    ) == 1

    assert compose(
        0,
        lambda x: x + 2,
        lambda y: y + 1
    ) == 3



# Generated at 2022-06-24 00:50:15.099725
# Unit test for function identity
def test_identity():
    assert identity(5) == 5
    assert identity('b') == 'b'
    assert identity([]) == []


# Generated at 2022-06-24 00:50:21.379952
# Unit test for function find
def test_find():
    list1 = [1, 2, 3]
    list2 = ['one', 'two', 'three', 'four']

    def find1(item):
        return item == 3

    def find2(item):
        return item == 'four'

    def find3(item):
        return item == 5

    assert find(list1, find1) == 3
    assert find(list2, find2) == 'four'
    assert find(list1, find3) is None


# Generated at 2022-06-24 00:50:25.133562
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], eq(4)) == 4
    assert find([1, 2, 3, 4], eq(5)) is None



# Generated at 2022-06-24 00:50:27.788857
# Unit test for function memoize
def test_memoize():
    def add5(x):
        print('sum', x)
        return x + 5

    memoized_add5 = memoize(add5)
    result1 = memoized_add5(2)
    result2 = memoized_add5(2)

    print('is equals:', result1 == result2)
    print('is equals:', add5(2) == result2)



# Generated at 2022-06-24 00:50:30.009915
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2
    assert increase(-1) == 0
    assert increase(-10) == -9



# Generated at 2022-06-24 00:50:31.628512
# Unit test for function memoize
def test_memoize():
    assert(memoize(identity)(10) == 10)
    assert(memoize(identity)(10) == 10)



# Generated at 2022-06-24 00:50:32.407484
# Unit test for function identity
def test_identity():
    assert identity(True)



# Generated at 2022-06-24 00:50:33.264074
# Unit test for function increase
def test_increase():
    assert increase(0) == 1



# Generated at 2022-06-24 00:50:37.581630
# Unit test for function find
def test_find():
    """
    Testing function find.
    """
    test_list = [1, 2, 3, 4, 5, 6, 7]
    eq_function = lambda x, y: x == y

    assert find(test_list, lambda x: x == 4) == 4
    assert find(test_list, eq_function(4)) == 4
    assert find(test_list, lambda x: x == 8) is None



# Generated at 2022-06-24 00:50:42.740063
# Unit test for function memoize
def test_memoize():
    """
    Test for function memoize
    """
    def add(a, b):
        return a + b
    curried = curry(add)
    curried_memoized = curry(memoize(curried))
    curried_memoized(2)(3)
    curried_memoized(2)(3)

# Generated at 2022-06-24 00:50:45.689518
# Unit test for function find
def test_find():
    assert (find([1, 2, 2, 3], eq(2)) == 2)
    assert (find([1, 2, 2, 3], eq(5)) is None)



# Generated at 2022-06-24 00:50:47.857143
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda el: el % 2 == 0, [1, 2, 3, 4]) == [2, 4]



# Generated at 2022-06-24 00:50:52.915970
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 2) == 2
    assert find([1, 2, 3, 4], lambda x: x == 5) == None



# Generated at 2022-06-24 00:50:53.950993
# Unit test for function identity
def test_identity():
    assert identity(5) == 5


# Generated at 2022-06-24 00:50:56.797829
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    print("Test passed", '\U0001F44D')



# Generated at 2022-06-24 00:51:04.613502
# Unit test for function memoize
def test_memoize():
    """
    Unit test for function memoize.
    """
    @memoize
    def incr(value):
        return value + 1


    assert incr(1) == 2

    assert incr(1) == 2

    assert incr(1) == 2

    assert incr(2) == 3

    assert incr(1) == 2

    assert incr(2) == 3

# Generated at 2022-06-24 00:51:09.533925
# Unit test for function memoize
def test_memoize():
    test_fn = lambda x: (x + 1) * x
    test_key = lambda arg_list: arg_list[0]
    memoized_test_fn = memoize(test_fn, key=test_key)

    assert memoized_test_fn(1) == 2
    assert memoized_test_fn(2) == 6



# Generated at 2022-06-24 00:51:11.191452
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-24 00:51:12.571439
# Unit test for function cond
def test_cond():
    assert cond([
        (eq(True), print)
    ])('hello') == None

# Generated at 2022-06-24 00:51:15.703497
# Unit test for function find
def test_find():
    assert find(list(range(1, 10)), lambda x: x % 2 == 0) == 2
    assert find(list(range(1, 10)), lambda x: x == 0) == None


# Generated at 2022-06-24 00:51:19.371271
# Unit test for function curried_map
def test_curried_map():
    collection = [1, 2, 3]
    mapper = lambda x: x * x
    curried_mapper = curried_map(mapper)
    result = map(mapper, collection)

    assert result == [1, 4, 9]
    assert curried_mapper(collection) == result



# Generated at 2022-06-24 00:51:25.846453
# Unit test for function curried_filter
def test_curried_filter():
    def is_even(number):
        return number % 2 == 0

    assert curried_filter(eq(1), [1, 2, 3]) == [1]
    assert curried_filter(is_even, [1, 2, 3, 4, 5, 6]) == [2, 4, 6]


# Generated at 2022-06-24 00:51:27.266532
# Unit test for function increase
def test_increase():
    assert increase(2) == 3



# Generated at 2022-06-24 00:51:28.418913
# Unit test for function identity
def test_identity():
    assert identity(5) == 5


# Generated at 2022-06-24 00:51:31.874285
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda n: n == 2) == 2
    assert find([1, 2, 3], lambda n: n == 5) is None

# Generated at 2022-06-24 00:51:39.155680
# Unit test for function eq
def test_eq():
    assert eq(2, 3) == False
    assert eq(None, None) == True
    assert eq(None, 1) == False
    assert eq(1, 1) == True
    assert eq(True, True) == True
    assert eq(False, False) == True
    assert eq(False, True) == False
    assert eq('1', 1) == False
    assert eq(0, 1) == False
    assert eq(1, 0) == False
    assert eq(0, 0) == True
    assert eq('1', '1') == True


# Generated at 2022-06-24 00:51:42.025254
# Unit test for function curried_filter
def test_curried_filter():
    filtered_collection = curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    assert filtered_collection == [2, 4, 6, 8, 10]


# Generated at 2022-06-24 00:51:44.692979
# Unit test for function compose
def test_compose():
    x = lambda x: x + 1
    y = lambda y: y * y
    z = lambda z: z + 2
    assert compose(z, y, x)(1) == 6
    assert compose(z, y, x)(2) == 9



# Generated at 2022-06-24 00:51:50.782187
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 10, [3, 5, 12, 15, 17])([]) == [12, 15, 17]
    assert curried_filter(lambda x: x > 10, [3, 5, 12, 15, 17]) == [3, 5, 12, 15, 17]


# Generated at 2022-06-24 00:51:52.348660
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-24 00:51:55.329093
# Unit test for function compose
def test_compose():
    """
    >>> compose(1, identity, increase, increase, increase)
    4
    """


# Unit Test for function pipe

# Generated at 2022-06-24 00:51:56.579157
# Unit test for function increase
def test_increase():
    assert increase(10) == 11
    assert increase(-10) == -9
    assert increase(10.0) == 11.0
    assert increase(-10.0) == -9.0

# Generated at 2022-06-24 00:52:00.832203
# Unit test for function compose
def test_compose():
    x = compose(
        "Lorem",
        lambda x: x.lower(),
        lambda x: x.split(" "),
        lambda x: x[::-1],
        lambda x: " ".join(x)
    )
    assert x == "meroL", "compose"



# Generated at 2022-06-24 00:52:01.689207
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-24 00:52:05.133321
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(True)
    assert identity('string') == 'string'
    assert identity([1, 2, 3]) == [1, 2, 3]
    assert identity({1: 1, 2: 2}) == {1: 1, 2: 2}
    print('- identity')



# Generated at 2022-06-24 00:52:09.097792
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert callable(identity)



# Generated at 2022-06-24 00:52:12.959231
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y: x + y, 1)(1) == 2
    assert curry(lambda x, y: x + y, 1)(1) == 2
    assert curry(lambda x, y: x + y, 1)(1) == 2
    assert curry(lambda x, y: x + y, 1, 1) == 2



# Generated at 2022-06-24 00:52:25.557283
# Unit test for function curry
def test_curry():
    @curry
    def add(x, y):
        return x + y
    assert add(1)(2) == 3
    assert add(1)(3) == 4
    #
    @curry
    def add2(x, y, z):
        return x + y + z
    assert add2(1)(2)(3) == 6
    assert add2(1)(2)(4) == 7
    #
    @curry
    def add2_custom(x, y=0, z=0):
        return x + y + z
    assert add2_custom(1)(2)() == 3
    assert add2_custom(1)()(2) == 3
    assert add2_custom(1, 2)() == 3
    assert add2_custom(1, z=2)() == 3
    assert add2

# Generated at 2022-06-24 00:52:28.692782
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x > 2) == 3
    assert find([1, 2, 3, 4], lambda x: x == 7) is None



# Generated at 2022-06-24 00:52:33.762727
# Unit test for function compose
def test_compose():
    assert compose(
        10,
        lambda a: a * 2,
        lambda a: a + 1
    ) == 22



# Generated at 2022-06-24 00:52:37.408268
# Unit test for function curry
def test_curry():
    res_from_curry = curry(lambda x, y, z: x + y + z)
    print(res_from_curry(1)(2)(3))
    # 6



# Generated at 2022-06-24 00:52:40.854353
# Unit test for function pipe
def test_pipe():
    fun_chain = pipe(
        10,
        increase,
        increase,
    )
    assert fun_chain == 12



# Generated at 2022-06-24 00:52:44.308724
# Unit test for function identity
def test_identity():
    assert identity(5) == 5
    assert identity('q') == 'q'


# Generated at 2022-06-24 00:52:47.638827
# Unit test for function curry
def test_curry():
    def add(a, b):
        return a + b

    def add3(a, b, c):
        return a + b + c
    assert curry(add)(2)(4) == 6
    assert curry(add)(2)(4)(56) == 62
    assert curry(add3)(2)(4) == 6
    assert curry(add3)(2)(4)(56) == 6



# Generated at 2022-06-24 00:52:52.564843
# Unit test for function pipe
def test_pipe():
    assert pipe(
        42,
        lambda x: x + 1,
        lambda x: x * 2,
        lambda x: x - 0.5,
    ) == 84.5



# Generated at 2022-06-24 00:52:58.287569
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1)(2)
    assert eq(1)(1)
    assert not curried_filter(eq(1), [1, 2, 3]) == [1, 2, 3]
    assert not curried_filter(eq(1), [1, 2, 3]) == [1]
    assert not curried_filter(eq(1), [1, 2, 3]) == [2, 3]



# Generated at 2022-06-24 00:53:04.852627
# Unit test for function find
def test_find():
    assert find(
        [{'name': 'Mario', 'surname': 'Kart'}, {'name': 'Peach', 'surname': 'Kart'}],
        lambda person: person['name'] == 'Mario'
    ) == {'name': 'Mario', 'surname': 'Kart'}

    assert find(
        [{'name': 'Mario', 'surname': 'Kart'}, {'name': 'Peach', 'surname': 'Kart'}],
        lambda person: person['name'] == 'Baby Mario'
    ) is None



# Generated at 2022-06-24 00:53:10.733735
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda list: list[0] % 2 == 0, lambda list: list[0] + 1),
        (lambda list: list[0] % 3 == 0, lambda list: list[0] + 2)
    ])([1]) == 2



# Generated at 2022-06-24 00:53:14.868694
# Unit test for function increase
def test_increase():
    assert increase(3) == 4



# Generated at 2022-06-24 00:53:15.760968
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:53:25.411242
# Unit test for function cond
def test_cond():
    assert(cond([
        (lambda x: x < 0, lambda x: print(x)),
        (lambda x: x > 0, lambda x: x),
        (lambda x: x == 0, lambda x: x + 1)
    ])(-10) is None)

    assert(cond([
        (lambda x: x < 0, lambda x: print(x)),
        (lambda x: x > 0, lambda x: x),
        (lambda x: x == 0, lambda x: x + 1)
    ])(0) == 1)

    assert(cond([
        (lambda x: x < 0, lambda x: print(x)),
        (lambda x: x > 0, lambda x: x),
        (lambda x: x == 0, lambda x: x + 1)
    ])(10) == 10)


# Generated at 2022-06-24 00:53:34.527829
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2, [1, 2, 3]) == [3]
    assert curried_filter(lambda x: x > 2)([1, 2, 3]) == [3]
    assert list(filter(lambda x: x > 2, [1, 2, 3])) == [3]
    assert list(map(lambda x: x * 3, filter(lambda x: x > 2, [1, 2, 3]))) == [9]
    assert pipe([1, 2, 3], curried_filter(lambda x: x > 2), curried_map(lambda x: x * 3)) == [9]
    assert compose([1, 2, 3], curried_map(lambda x: x * 3), curried_filter(lambda x: x > 2)) == [9]
# END Unit test for function curried

# Generated at 2022-06-24 00:53:35.154582
# Unit test for function increase
def test_increase():
    assert increase(1) == 2

# Generated at 2022-06-24 00:53:36.544670
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-24 00:53:39.969548
# Unit test for function pipe
def test_pipe():
    assert pipe('1', str, int, increase, str) == '2'



# Generated at 2022-06-24 00:53:42.344067
# Unit test for function increase
def test_increase():
    assert increase(2) == 3
    assert increase(1) == 2
    assert increase(0) == 1
    assert increase(-1) == 0



# Generated at 2022-06-24 00:53:46.138481
# Unit test for function memoize
def test_memoize():
    def add(a):
        return a + 1

    memoized_add = memoize(add)

    assert memoized_add(1) == 2
    assert memoized_add(2) == 3
    assert memoized_add(1) == 2
    assert memoized_add(10) == 11
    assert memoized_add(2) == 3
    assert memoized_add(1) == 2
    assert memoized_add(10) == 11

# Generated at 2022-06-24 00:53:51.190735
# Unit test for function cond
def test_cond():
    assert cond(
        [
            (lambda x: x < 0, lambda x: 'Less than 0'),
            (lambda x: x == 0, lambda x: 'Equal to 0'),
            (lambda x: x > 0, lambda x: 'Greater than 0')
        ]
    )(-1) == 'Less than 0'
    assert cond(
        [
            (lambda x: x < 0, lambda x: 'Less than 0'),
            (lambda x: x == 0, lambda x: 'Equal to 0'),
            (lambda x: x > 0, lambda x: 'Greater than 0')
        ]
    )(0) == 'Equal to 0'

# Generated at 2022-06-24 00:54:00.844531
# Unit test for function memoize
def test_memoize():
    print('Test memoize function...')
    real_fib = lambda x: 1 if x <= 2 else real_fib(x - 1) + real_fib(x - 2)
    expected_result = 832040
    fib = memoize(real_fib)

    print(
        'Measured time for real fibonacci ({0}): {1}'.format(
            expected_result,
            timeit.timeit(lambda: real_fib(30))
        )
    )
    print(
        'Measured time for memoized fibonacci ({0}): {1}'.format(
            expected_result,
            timeit.timeit(lambda: fib(30))
        )
    )


# Generated at 2022-06-24 00:54:03.306830
# Unit test for function compose
def test_compose():
    assert compose(100, increase) == 101



# Generated at 2022-06-24 00:54:05.762280
# Unit test for function find
def test_find():
    assert find([(1, 1), (2, 2), (3, 3)], lambda item: item[0] == 2) == (2, 2)
    asser

# Generated at 2022-06-24 00:54:07.104864
# Unit test for function compose
def test_compose():
    result = compose('hello', lambda x: x.capitalize(), lambda x: x + ' world')
    assert result == 'Hello world'



# Generated at 2022-06-24 00:54:11.225844
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 1) == 1
    assert find(["1", "2", "3"], lambda x: x == "1") == "1"
    assert find([1, 2, 3], lambda x: x == 10) is None
    assert find([], lambda x: False) is None



# Generated at 2022-06-24 00:54:14.917395
# Unit test for function pipe
def test_pipe():
    piped = pipe(
        'Hello, World!',
        lambda x: x.split(),
        lambda x: x.reverse(),
        lambda x: x.join())
    assert piped == 'World!,Hello'
