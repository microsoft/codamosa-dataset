

# Generated at 2022-06-24 00:44:15.951846
# Unit test for function compose
def test_compose():
    assert compose(20, increase) == 21
    assert pipe(20, increase) == 21
    assert compose(
        20, lambda v: increase(v) * 2, lambda v: v - 2, lambda v: increase(v)
    ) == 20



# Generated at 2022-06-24 00:44:18.203794
# Unit test for function eq
def test_eq():
    eq_test = eq(1)
    assert eq_test(1)
    assert not eq_test(0)



# Generated at 2022-06-24 00:44:22.280197
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda a: a*a)([1, 2, 3]) == [1, 4, 9]


# Generated at 2022-06-24 00:44:26.798776
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0)([2, 4, 6, 8]) == [2, 4, 6, 8]
    assert curried_filter(lambda x: x % 2 == 0)([2, None, 5, 8]) == [2, 8]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4]) == [2, 4]



# Generated at 2022-06-24 00:44:32.196761
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [1, 2, 3]) == [1, 2, 3]
    assert curried_map(lambda x: x * x, [1, 2, 3]) == [1, 4, 9]

    # Unit test for function curried_map
    assert curried_map(lambda x, y: x + y, [1, 2, 3])([1, 2, 3]) == [2, 4, 6]
    assert curried_map(lambda x, y: x + y, [1, 2, 3])([1, 2, 3])([1, 2, 3]) == [3, 6, 9]
    assert curried_map(identity, [1, 2, 3])([1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-24 00:44:41.069498
# Unit test for function find
def test_find():
    test_collection = [
        {'name': 'a', 'value': 1},
        {'name': 'b', 'value': 2},
        {'name': 'c', 'value': 3},
        {'name': 'd', 'value': 4},
        {'name': 'e', 'value': 5},
    ]

    assert find(test_collection, lambda item: item['value'] == 3) == {
        'name': 'c', 'value': 3
    }

    assert find(test_collection, lambda item: item['name'] == 'a') == {
        'name': 'a', 'value': 1
    }

    assert find(test_collection, lambda item: item['name'] == 'f') is None



# Generated at 2022-06-24 00:44:42.671742
# Unit test for function compose
def test_compose():
    assert compose(1, lambda x: x + 1, lambda x: x + 2, lambda x: x * 2) == 7



# Generated at 2022-06-24 00:44:44.685712
# Unit test for function eq
def test_eq():
    assert eq('a', 'a') == True
    assert eq('a', 'b') == False
    assert eq('a', 'c') == False


# Generated at 2022-06-24 00:44:51.654224
# Unit test for function pipe
def test_pipe():
    assert pipe(2, increase, increase, increase) == 5
    assert pipe(2, increase, increase) == 4
    assert pipe(2, increase) == 3
    assert pipe(2) == 2


# Generated at 2022-06-24 00:44:56.294987
# Unit test for function memoize
def test_memoize():
    def simple_fn(argument):
        return argument + 1

    memoized_simple_fn = memoize(simple_fn)

    assert memoized_simple_fn(5) == 6
    assert memoized_simple_fn(5) == 6

    def simple_fn2(argument):
        return argument + 1

    memoized_simple_fn2 = memoize(simple_fn2, eq)

    assert memoized_simple_fn2(5) == 6
    assert memoized_simple_fn2(5) == 6

    def multi_argument_fn(a1, a2, a3):
        return a1 + a2 + a3

    memoized_multi_argument_fn = memoize(multi_argument_fn, eq)

    assert memoized_multi_argument_fn(1, 1, 1) == 3
    assert memo

# Generated at 2022-06-24 00:45:01.354591
# Unit test for function memoize
def test_memoize():
    def expensive_function(x):
        print('Expensive function call with argument:', x)
        return x

    cached = memoize(expensive_function)
    cached(1)
    cached(1)
    cached(1)
    cached(2)
    cached(2)



# Generated at 2022-06-24 00:45:04.765496
# Unit test for function curried_filter
def test_curried_filter():
    print(curried_filter(lambda x: x % 2 == 0, range(10)))



# Generated at 2022-06-24 00:45:11.348854
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-24 00:45:14.560782
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 1, 1, 1]) == [2, 2, 2, 2]



# Generated at 2022-06-24 00:45:17.467929
# Unit test for function increase
def test_increase():
    assert increase(0) == 1



# Generated at 2022-06-24 00:45:19.166745
# Unit test for function compose
def test_compose():
    assert compose(5, lambda x: x * 2, lambda x: x + 1) == 11


# Generated at 2022-06-24 00:45:20.572950
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(1.0) == 2.0


# Generated at 2022-06-24 00:45:24.565925
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda item: item == 2) == 2
    assert find([1, 2, 3, 4], lambda item: item == 5) is None



# Generated at 2022-06-24 00:45:26.839898
# Unit test for function eq
def test_eq():
    assert eq(10, 10)
    assert not eq(10, 11)
    assert eq(10, 10)(10)
    assert not eq(10, 11)(10)



# Generated at 2022-06-24 00:45:30.835456
# Unit test for function curried_map
def test_curried_map():
    result = curried_map(increase, [1, 2, 3, 4, 5])
    assert result == [2, 3, 4, 5, 6]
    curried_map_increase = curried_map(increase)
    result1 = curried_map_increase([1, 2, 3, 4, 5])
    assert result1 == [2, 3, 4, 5, 6]



# Generated at 2022-06-24 00:45:32.221762
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(1), [1, 2, 3, 4]) == [1]

# Generated at 2022-06-24 00:45:37.809347
# Unit test for function pipe
def test_pipe():
    data = [1, 2, 3]
    result = pipe(
        data,
        curried_map(increase),
        curried_filter(lambda x: x > 2),
        lambda x: x[0]
    )
    assert result == 3



# Generated at 2022-06-24 00:45:41.445055
# Unit test for function find
def test_find():
    assert find(range(10), lambda x: x == 5) == 5
    assert find(range(10), lambda x: x == 10) is None


# Generated at 2022-06-24 00:45:46.715857
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(1.0) == 1.0
    assert identity('asd') == 'asd'
    assert identity({'asd': 'asd'}) == {'asd': 'asd'}
    assert identity([1, 2, 3]) == [1, 2, 3]
    assert identity(None) is None



# Generated at 2022-06-24 00:45:51.112577
# Unit test for function find
def test_find():
    collection = [1, 2, 3, 4, 5]
    assert find(collection, lambda x: x % 10 == 0) is None
    assert find(collection, lambda x: x % 2 == 0) == 2
    assert find(collection, lambda x: x % 5 == 0) == 5



# Generated at 2022-06-24 00:45:55.226495
# Unit test for function eq
def test_eq():
    assert eq(3, 3)
    assert not eq(3, 4)



# Generated at 2022-06-24 00:45:57.002158
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(True) is True
    assert identity(None) is None


# Generated at 2022-06-24 00:46:02.509686
# Unit test for function memoize
def test_memoize():
    func = memoize(lambda x: x**2)
    # f(2) ->  4
    assert func(2) == 4
    # f(2) ->  4
    assert func(2) == 4
    # f(3) -> 9
    assert func(3) == 9
    # f(2) ->  4
    assert func(2) == 4


# Generated at 2022-06-24 00:46:04.166057
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(2) == 3

# Generated at 2022-06-24 00:46:07.558666
# Unit test for function curry
def test_curry():
    add = lambda x, y: x + y
    assert add(1, 2) == 3
    add_one = curry(add)(1)
    assert add_one(2) == 3



# Generated at 2022-06-24 00:46:10.833038
# Unit test for function pipe
def test_pipe():
    """
    Test pipe function.

    :returns:
    :rtype: Any
    """
    assert pipe(2, increase, identity) == 3
    assert pipe(2, identity) == 2
    assert pipe(2) == 2
    assert pipe(2, lambda x: x) == 2



# Generated at 2022-06-24 00:46:11.633182
# Unit test for function identity
def test_identity():
    assert identity(5) == 5



# Generated at 2022-06-24 00:46:12.369664
# Unit test for function increase
def test_increase():
    assert increase(0) == 1



# Generated at 2022-06-24 00:46:19.535299
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 3]

    def filterer(x):
        return x > 2

    def filterer1(x):
        return x == 2

    assert curried_filter(filterer, collection) == [3]
    assert curried_filter(filterer1)(collection) == [2]
    assert curried_filter(filterer)(collection) == [3]



# Generated at 2022-06-24 00:46:29.987142
# Unit test for function cond
def test_cond():
    def gt10(x):
        return x > 10

    def lt15(x):
        return x < 15

    def eq20(x):
        return x == 20

    result = cond([
        (gt10, lambda value: 'gt10'),
        (lt15, lambda value: 'lt15'),
        (eq20, lambda value: 'eq20'),
    ])(12)
    assert result == 'gt10'

    result = cond([
        (gt10, lambda value: 'gt10'),
        (lt15, lambda value: 'lt15'),
        (eq20, lambda value: 'eq20'),
    ])(8)
    assert result is None


# Generated at 2022-06-24 00:46:34.794070
# Unit test for function compose
def test_compose():
    """
    Function for test compose
    """
    assert pipe(2, lambda x: x + 3, lambda x: x ** 2) == 49
    assert pipe('String', lambda x: x.upper(), lambda x: x[::-1]) == 'GNIRTS'



# Generated at 2022-06-24 00:46:38.210293
# Unit test for function compose
def test_compose():
    assert compose(10, lambda x: x*2, increase, lambda x: x+5) == 35
    assert compose(10, increase, lambda x: x*2) == 32


# Generated at 2022-06-24 00:46:39.973241
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False

    assert eq(1)(1) is True
    assert eq(1)(2) is False



# Generated at 2022-06-24 00:46:47.740398
# Unit test for function find
def test_find():
    my_list = [1, 2, 3]

    assert find(my_list, lambda x: x == 1) == 1
    assert find(my_list, lambda x: x == 2) == 2
    assert find(my_list, lambda x: x == 3) == 3
    assert find(my_list, lambda x: x == 4) is None


# Generated at 2022-06-24 00:46:58.438912
# Unit test for function cond
def test_cond():
    assert cond(
        [
            (eq(0), lambda: 'water freezes at 0°C'),
            (eq(100), lambda: 'water boils at 100°C'),
            (lambda x: True, lambda x: f'nothing special happens at {x}°C')
        ]
    )(0) == 'water freezes at 0°C'

    assert cond(
        [
            (eq(0), lambda: 'water freezes at 0°C'),
            (eq(100), lambda: 'water boils at 100°C'),
            (lambda x: True, lambda x: f'nothing special happens at {x}°C')
        ]
    )(50) == 'nothing special happens at 50°C'


# Generated at 2022-06-24 00:46:59.800538
# Unit test for function increase
def test_increase():
    assert increase(2) == 3


# Generated at 2022-06-24 00:47:04.344178
# Unit test for function memoize
def test_memoize():
    # @curry
    # def add(argument1, argument2):
    #     print('Adding arguments')
    #     return argument1 + argument2

    cached_add = memoize(add)
    assert cached_add(1, 2) == 3
    assert cached_add(1, 2) == 3


if __name__ == '__main__':
    test_memoize()

# Generated at 2022-06-24 00:47:14.085753
# Unit test for function curry
def test_curry():
    def fn1(x, y, z):
        return x + y + z

    curried1 = curry(fn1)
    assert curried1(1, 2, 3) == curried1(1)(2, 3) == curried1(1, 2)(3) == 6
    assert curried1(1, 2, 3) == 6
    assert curried1(1)(2, 3) == 6
    assert curried1(1, 2)(3) == 6

    def fn2(x, y, z, k):
        return x + y + z + k

    curried2 = curry(fn2)

# Generated at 2022-06-24 00:47:17.112304
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x % 2 == 0) == 2, 'Must return 2'
    assert find([1, 2, 3, 4], lambda x: x > 10) is None, 'Must return None'



# Generated at 2022-06-24 00:47:22.449263
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq('a', 'a') == True
    assert eq('a', 'b') == False
    assert eq(None, None) == True
    assert eq(None, 1) == False
    assert eq((1, 2), (1, 2)) == True
    assert eq((1, 2), (1, 2, 3)) == False


# Generated at 2022-06-24 00:47:29.542247
# Unit test for function cond
def test_cond():
    fn_cond = cond([
        (lambda arg: arg == 'A', lambda arg: arg + '1'),
        (lambda arg: arg == 'B', lambda arg: arg + '2'),
        (lambda arg: arg == 'C', lambda arg: arg + '3'),
    ])
    assert fn_cond('A') == 'A1', 'Should be "A1"'
    assert fn_cond('B') == 'B2', 'Should be "B2"'
    assert fn_cond('C') == 'C3', 'Should be "C3"'



# Generated at 2022-06-24 00:47:34.042999
# Unit test for function curried_filter
def test_curried_filter():
    actual = curried_filter(lambda x: x > 2, [1, 4, 2, 5, 2, 6, 2, 5])
    expected = [4, 5, 6, 5]
    assert actual == expected



# Generated at 2022-06-24 00:47:37.818188
# Unit test for function eq
def test_eq():
    eq_function = curry(lambda a, b: a == b)

    # check if eq working
    assert (eq_function(1, 1) == True)

    # check if eq not working
    assert (eq_function(1, 2) == False)

    # check if eq working without curred
    assert (eq(1, 1) == True)



# Generated at 2022-06-24 00:47:40.263583
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-24 00:47:41.519115
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
# End of unit test



# Generated at 2022-06-24 00:47:47.067131
# Unit test for function curried_filter
def test_curried_filter():
    assert eq(
        curried_filter(eq(2))([1, 2, 3]),
        [2]
    ), "curried_filter not passed"


# Generated at 2022-06-24 00:47:53.289447
# Unit test for function increase
def test_increase():
    """
    Check that increase function increase value by one.
    """
    assert increase(0) == 1
    assert increase(1) == 2



# Generated at 2022-06-24 00:47:56.932396
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x * 2, [1, 2, 3]) == [2, 4, 6]
    assert curried_map(lambda x: x * 2, [1, 2, 3, 4]) == [2, 4, 6, 8]


# Generated at 2022-06-24 00:47:58.940429
# Unit test for function curried_map
def test_curried_map():
    result = curried_map(increase)([1,2,3,4,5])
    expected = [2,3,4,5,6]
    assert result == expected


# Generated at 2022-06-24 00:48:05.060244
# Unit test for function memoize
def test_memoize():
    """
    Unit test for function memoize.
    """
    def sum(x, y):
        return x + y

    memoized_sum = memoize(sum)

    assert memoized_sum(1, 2) == memoized_sum(1, 2) == memoized_sum(1, 2) == 3
    assert memoized_sum(1, 2) == 3
    assert memoized_sum(1, 2) == 3
    assert memoized_sum(1, 2) == 3
    assert memoized_sum(1, 3) == memoized_sum(1, 3) == memoized_sum(1, 3) == 4
    assert memoized_sum(1, 3) == 4
    assert memoized_sum(1, 3) == 4
    assert memoized_sum(1, 3) == 4

# Generated at 2022-06-24 00:48:08.154097
# Unit test for function eq
def test_eq():
    assert (eq(1, 1)) == True
    assert (eq(2, 1)) == False



# Generated at 2022-06-24 00:48:10.678543
# Unit test for function pipe
def test_pipe():
    assert pipe(2, identity, increase) == 3
    assert pipe('foo', identity) == 'foo'
    assert pipe('foo', identity) != 'FOO'



# Generated at 2022-06-24 00:48:11.518132
# Unit test for function increase
def test_increase():
    assert increase(14) == 15


# Generated at 2022-06-24 00:48:15.529182
# Unit test for function memoize
def test_memoize():
    def fn(value):
        print(str(value))
        return value

    fn_memoized = memoize(fn)

    fn_memoized(1)
    fn_memoized(1)
    fn_memoized(2)
    fn_memoized(1)
    fn_memoized(1)
    fn_memoized(1)

# Generated at 2022-06-24 00:48:24.808727
# Unit test for function find
def test_find():
    condition_list = [
        (lambda *args: len(args) == 1, lambda x: x[0]),
        (lambda x, y: (x[0] is not None) and (y[0] is not None), lambda x, y: x[0] + y[0]),
        (lambda *args: len(args) == 2, lambda x, y: x),
        (lambda *args: len(args) == 2, lambda x, y: y),
        (lambda *args: len(args) == 2, lambda x, y: x + y),
        (lambda *args: len(args) > 2, lambda *args: args),
    ]
    f = lambda *args: find(condition_list, lambda condition: condition[0](*args))[1](*args)
    assert f(1) == 1
    assert f

# Generated at 2022-06-24 00:48:27.910420
# Unit test for function compose
def test_compose():
    assert compose(
        None,
        lambda _: 1,
        lambda _: 2
    ) == 2

# Generated at 2022-06-24 00:48:30.283175
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(False) == False
    assert identity('test') == 'test'
    assert identity(None) == None



# Generated at 2022-06-24 00:48:35.247804
# Unit test for function memoize
def test_memoize():
    def sum_string(s1, s2):
        return s1 + s2

    memoized_sum_string = memoize(sum_string)
    assert memoized_sum_string('a', 'b') == 'ab'
    assert memoized_sum_string('a', 'b') == 'ab'


if __name__ == "__main__":
    test_memoize()

# Generated at 2022-06-24 00:48:42.007337
# Unit test for function memoize
def test_memoize():
    def test_fn(n):
        return n * 2
    memoized_fn = memoize(test_fn)
    assert memoized_fn(1) == 2
    assert memoized_fn(1) == 2
    assert memoized_fn(2) == 4
    assert memoized_fn(1) == 2
    assert memoized_fn(2) == 4
    assert memoized_fn(3) == 6
    assert memoized_fn(1) == 2



# Generated at 2022-06-24 00:48:44.172645
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(2, 1)
    assert eq(1, 1, 1)
    assert not eq(1, 1, 2)



# Generated at 2022-06-24 00:48:45.806270
# Unit test for function eq
def test_eq():
    assert eq(1,1)


# Generated at 2022-06-24 00:48:53.011127
# Unit test for function memoize
def test_memoize():
    def sum(a, b, c):
        return a + b + c
    sum = curry(sum)
    sum = memoize(sum)
    assert sum(1, 2, 3) == 6
    assert sum(1, 2, 3) == 6
    assert sum(1, 2, 3) == 6



# Generated at 2022-06-24 00:49:04.087721
# Unit test for function curry
def test_curry():
    def test_fn(x=1, y=2, z=3):
        return x + y + z

    assert curry(test_fn)()()(1)()(2)()(3) == curry(test_fn)()(1)(2)()(3) == curry(test_fn)(1)()(2)()(3) == 6
    assert curry(test_fn)()()(1)()()(2)()(3) == 6
    assert curry(test_fn)()()(1)()()(2)()()(3) == 6
    assert curry(test_fn)(1)(2)(3) == 6
    assert curry(test_fn, 0)(1)(2)(3) == 6
    assert curry(test_fn, -1)(1)(2)(3) == 6

# Generated at 2022-06-24 00:49:07.604931
# Unit test for function curried_map
def test_curried_map():
    # Test composition of curried_map and filter

    # Set up
    map_filter = compose(curried_map(lambda x: x ** 2), curried_filter(lambda x: x % 2 == 0))
    collection = [1, 2, 3, 4, 5]
    expected = [4, 16]
    actual = map_filter(collection)

    # Assert
    assert actual == expected


# Generated at 2022-06-24 00:49:11.173101
# Unit test for function eq
def test_eq():
    assert eq(10, 10)
    assert eq(10)(10)



# Generated at 2022-06-24 00:49:16.068960
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq('string', 'string')
    assert not eq('string', 'different string')
    assert not eq('string', 1)
    assert not eq(1, 'string')
    assert not eq([], [])
    assert not eq([1], [])
    assert not eq([], [1])
    assert not eq([1], [2])
    assert not eq([1, 2], [1, 3])
    assert not eq([1, 2, 3], [1, 2])
    assert not eq([1, 2], [1, 2, 3])
    assert not eq([], ())
    assert not eq(1, '1')
    assert not eq('1', 1)



# Generated at 2022-06-24 00:49:18.573751
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(0))([1, 0, 1]) == [0]
    assert curried_filter(lambda x: x > 0)([1, 0, 1]) == [1, 1]



# Generated at 2022-06-24 00:49:20.198245
# Unit test for function increase
def test_increase():
    # Arrange
    value = 10
    # Act
    result = increase(value)
    # Assert
    assert result == 11



# Generated at 2022-06-24 00:49:21.371553
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(0, 1)



# Generated at 2022-06-24 00:49:23.266363
# Unit test for function find
def test_find():
    assert(find([1, 2, 3, 4], eq(2)) == 2)
    assert(find([1, 2, 3, 4], eq(5)) is None)
    assert(find([1, 2, 3, 4], identity) == 1)

# Generated at 2022-06-24 00:49:30.220525
# Unit test for function cond
def test_cond():
    def is_equal_three(value):
        return value == 3

    def is_equal_four(value):
        return value == 4

    def is_equal_five(value):
        return value == 5

    def sum_3(value, value1):
        return value + value1

    def sum_4(value, value1):
        return value + value1

    def sum_5(value, value1):
        return value + value1

    function = cond([
        (is_equal_three, sum_3),
        (is_equal_four, sum_4),
        (is_equal_five, sum_5),
    ])

    assert function(3, 4) == 7
    assert function(4, 5) == 9
    assert function(5, 1) == 6
    assert function(10, 1) is None

# Generated at 2022-06-24 00:49:35.320705
# Unit test for function curried_filter
def test_curried_filter():
    """
    Unit test for function curried_filter
    """
    assert curried_filter(
        lambda x: x % 2 == 0,
        [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    ) == [2, 4, 6, 8, 10]



# Generated at 2022-06-24 00:49:40.264238
# Unit test for function cond
def test_cond():
    condition_list = [
        (eq(2), increase),
        (eq(1), identity),
    ]
    result = cond(condition_list)(1)
    assert result == 1

    result = cond(condition_list)(2)
    assert result == 3

    result = cond(condition_list)(3)
    assert result is None

# Generated at 2022-06-24 00:49:46.247503
# Unit test for function find
def test_find():
    collection = [
        {'name': 'name1', 'age': 1},
        {'name': 'name2', 'age': 2}
    ]
    assert find(collection, lambda item: item['name'] == 'name1') == {'name': 'name1', 'age': 1}
    assert find(collection, lambda item: item['name'] == 'name3') is None
    assert find(collection, lambda item: item['name'] == 'name1', default='default') == {'name': 'name1', 'age': 1}



# Generated at 2022-06-24 00:49:51.368025
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(1.1) == 1.1
    assert identity('test') == 'test'
    assert identity(2) == 2
    assert identity(3.3) == 3.3
    assert identity('test1') == 'test1'
    assert identity(4) == 4
    assert identity(5.5) == 5.5
    assert identity(6.6) == 6.6
    assert identity('test2') == 'test2'


# Generated at 2022-06-24 00:49:54.130077
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 10, [1, 2, 3, 4]) == [11, 12, 13, 14]


# Generated at 2022-06-24 00:49:55.919882
# Unit test for function pipe
def test_pipe():
    assert pipe(1, lambda value: value + 2, lambda value: value / 2) == 1.5


# Generated at 2022-06-24 00:50:02.131022
# Unit test for function pipe
def test_pipe():
    assert pipe('fai', lambda x: x + 'l',
                lambda x: x + 'ure') == 'fail'
    assert pipe([1, 2, 3, 4, 5], lambda x: x[:3],
                lambda x: x + [6, 7], lambda x: x[3:]) == [4, 5, 6, 7]



# Generated at 2022-06-24 00:50:05.903903
# Unit test for function identity
def test_identity():
    test_cases = [
        ((), None),
        (1, 1),
        ("a", "a"),
        (1.3, 1.3),
        ([], []),
        ([1, 2], [1, 2]),
        (False, False),
    ]
    for args, result in test_cases:
        assert identity(args) == result



# Generated at 2022-06-24 00:50:07.754474
# Unit test for function eq
def test_eq():
    assert(eq(2, 2) == True)
    assert(eq(2, 3) == False)



# Generated at 2022-06-24 00:50:12.691389
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x % 2 == 1) == 1
    assert find([1, 2, 3], lambda x: x % 2 == 2) == 2
    assert find([1, 2, 3], lambda x: x % 2 == 3) is None

# Generated at 2022-06-24 00:50:13.931835
# Unit test for function identity
def test_identity():
    assert 10 == identity(10)



# Generated at 2022-06-24 00:50:16.999331
# Unit test for function curried_map
def test_curried_map():
    # Should return list with increased by 1 items
    assert curried_map(increase)([0, 1, 2]) == [1, 2, 3]



# Generated at 2022-06-24 00:50:20.598526
# Unit test for function memoize
def test_memoize():
    f = lambda x: x + 10
    g = memoize(f)
    assert f(1) == g(1)
    assert f(2) == g(2)
    assert f(2) + f(2) == g(2) + g(2)



# Generated at 2022-06-24 00:50:24.094777
# Unit test for function identity
def test_identity():
    assert identity(5) == 5


# Generated at 2022-06-24 00:50:30.046641
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x >= 2)([1, 2, 3, 4]) == [2, 3, 4]
    assert curried_filter(lambda x: x >= 2, [1, 2, 3, 4]) == [2, 3, 4]



# Generated at 2022-06-24 00:50:39.712814
# Unit test for function curried_map
def test_curried_map():
    """
    Tests for curried_map function

    :returns: this test always return True
    :rtype: Boolean
    """
    # simple cases
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(identity, [1, 2, 3]) == [1, 2, 3]

    # test currying
    add_two = curried_map(lambda x: increase(increase(x)))
    assert add_two([1, 2, 3]) == [3, 4, 5]

    add_two_from_three = curried_map(lambda x: increase(increase(x)), [3, 4, 5])
    assert add_two_from_three == [5, 6, 7]

    return True


# Generated at 2022-06-24 00:50:49.609716
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda n: n < 0, lambda x: 'negative'),
        (lambda n: n == 0, lambda x: 'zero'),
        (lambda n: n > 0, lambda x: 'positive'),
    ])(0) == 'zero'
    assert cond([
        (lambda n: n < 0, lambda x: 'negative'),
        (lambda n: n == 0, lambda x: 'zero'),
        (lambda n: n > 0, lambda x: 'positive'),
    ])(-10) == 'negative'
    assert cond([
        (lambda n: n < 0, lambda x: 'negative'),
        (lambda n: n == 0, lambda x: 'zero'),
        (lambda n: n > 0, lambda x: 'positive'),
    ])(10) == 'positive'

# Generated at 2022-06-24 00:50:52.966806
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2]) == [1, 2]
    assert curried_map(increase)([1, 2]) == [2, 3]



# Generated at 2022-06-24 00:50:56.946198
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([]) == []
    assert curried_map(increase)([]) is not curried_map(increase)([])

# Generated at 2022-06-24 00:50:59.176651
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x == 3)([1, 2, 3, 4, 5]) == [3]



# Generated at 2022-06-24 00:51:02.742619
# Unit test for function increase
def test_increase():
    assert increase(1) == 2


# Generated at 2022-06-24 00:51:06.355362
# Unit test for function pipe
def test_pipe():
    fn1 = lambda arg: arg + 1
    fn2 = lambda arg: arg * 2
    fn3 = lambda arg: arg - 1

    result = pipe(0, fn1, fn2, fn3)
    assert result == 1



# Generated at 2022-06-24 00:51:14.009746
# Unit test for function cond
def test_cond():
    def yes(value) -> bool:
        return True

    def no(value) -> bool:
        return False

    def f(value) -> str:
        return "f"

    def g(value) -> str:
        return "g"

    def h(value) -> str:
        return "h"

    condition_list = [
        (yes, f),
        (no, g),
        (no, h)
    ]

    cond_function = cond(condition_list)
    assert cond_function("any_argument") == "f"

# Generated at 2022-06-24 00:51:19.665735
# Unit test for function curried_filter
def test_curried_filter():
    numbers = [1, 2, 3, 4, 5]
    filtered_numbers = curried_filter(lambda x: x > 2)(numbers)
    assert filtered_numbers == [3, 4, 5]



# Generated at 2022-06-24 00:51:26.840640
# Unit test for function memoize
def test_memoize():
    def get_function():
        counter = 0
        @curry
        def fn(argument):
            nonlocal counter
            counter += argument
            return counter
        return fn, counter
    fn, counter = get_function()
    memoized_fn = memoize(fn)
    memoized_fn(1)
    memoized_fn(1)
    memoized_fn(1)
    memoized_fn(1)
    assert counter == 1

# Generated at 2022-06-24 00:51:29.992346
# Unit test for function curried_map
def test_curried_map():
    curried_map_inc = curried_map(increase)
    assert curried_map_inc([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-24 00:51:32.069664
# Unit test for function eq
def test_eq():
    assert eq(2, 2)
    assert not eq(3, 2)

# Generated at 2022-06-24 00:51:36.667784
# Unit test for function compose
def test_compose():
    collection = range(100)
    print(
        compose(
            identity,
            lambda x: [v * v for v in x],
            lambda x: [v * v * v for v in x]
        )(collection)
        ==
        [v * v * v * v for v in collection]
    )


# Generated at 2022-06-24 00:51:37.663465
# Unit test for function increase
def test_increase():
    assert increase(1) == 2


# Generated at 2022-06-24 00:51:43.952121
# Unit test for function cond
def test_cond():
    def is_even(item):
        return lambda value: value % item == 0

    def even_string(value):
        return str(value) + ' is even'

    def odd_string(value):
        return str(value) + ' is odd'

    assert cond([
        (is_even(2), even_string),
        (is_even(1), odd_string),
    ])(8) == even_string(8)
    assert cond([
        (is_even(2), even_string),
        (is_even(1), odd_string),
    ])(3) == odd_string(3)



# Generated at 2022-06-24 00:51:48.171517
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2
    assert increase(5) == 6



# Generated at 2022-06-24 00:51:59.627490
# Unit test for function find
def test_find():
    """
    Test function find.
    """
    test_list = [
        {'x': 1, 'y': 1},
        {'x': 2, 'y': 2},
        {'x': 3, 'y': 3},
        {'x': 4, 'y': 4},
        {'x': 5, 'y': 5},
        {'x': 6, 'y': 6},
        {'x': 7, 'y': 7},
        {'x': 8, 'y': 8},
    ]

    def key(argument: Any) -> bool:
        return argument['x'] == 5

    find_result = find(test_list, key)

    assert find_result == {'x': 5, 'y': 5}



# Generated at 2022-06-24 00:52:04.567701
# Unit test for function curry
def test_curry():
    curried_add = curry(lambda x, y, z: x + y + z)
    print(curried_add(2)(3)(4))



# Generated at 2022-06-24 00:52:12.029084
# Unit test for function curried_filter
def test_curried_filter():
    """
    Test function curried_filter
    """
    assert curried_filter(lambda x: x < 4, range(5)) == list(range(4))
    assert curried_filter(lambda x: x <= 3)(range(5)) == list(range(4))
    curried_filter_ = curried_filter(lambda x: x < 4)
    assert curried_filter_(range(5)) == list(range(4))



# Generated at 2022-06-24 00:52:12.880983
# Unit test for function identity
def test_identity():
    assert identity(5) == 5


# Generated at 2022-06-24 00:52:19.958492
# Unit test for function pipe
def test_pipe():
    test_list = [1, 2, 3, 4, 5]
    assert pipe(test_list, curried_filter(lambda item: item > 2), curried_map(lambda item: item + 2)) == [5, 6, 7]
    assert pipe(test_list, curried_map(lambda item: item + 5), curried_filter(lambda item: item < 8)) == [6, 7, 8]



# Generated at 2022-06-24 00:52:22.090972
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-24 00:52:25.103166
# Unit test for function identity
def test_identity():
    assert identity(identity([])) == []
    assert identity((1, (2, (3, None)))) == (1, (2, (3, None)))



# Generated at 2022-06-24 00:52:26.551485
# Unit test for function find
def test_find():
    assert find([0, 1, 2], lambda value: value == 1) == 1
    assert find([0, 1, 2], lambda value: value == 3) is None



# Generated at 2022-06-24 00:52:28.681219
# Unit test for function compose
def test_compose():
    assert compose(10, increase, increase, increase) == 13
    assert compose(10, increase, identity) == 11
    assert compose(10, identity, increase) == 11



# Generated at 2022-06-24 00:52:31.245543
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity([1]) == [1]
    assert identity((1,)) == (1,)
    assert identity({"a": 1}) == {"a": 1}



# Generated at 2022-06-24 00:52:32.790900
# Unit test for function curry
def test_curry():
    assert (curry(increase)(1)() == 2)
    assert (curry(increase)(1)(2) == 3)



# Generated at 2022-06-24 00:52:35.083934
# Unit test for function eq
def test_eq():
    assert eq(21, 21) == True
    assert eq(21, 22) == False
    assert eq(22)(21) == False
    assert eq(22)(22) == True
    assert eq(22, id)(22) == True



# Generated at 2022-06-24 00:52:37.002023
# Unit test for function compose
def test_compose():
    """
    >>> compose(1, increase, increase, increase)
    4
    >>> compose(1, lambda x: x + 5, lambda x: x * 5, lambda x: x ** 2)
    2156
    """
    pass



# Generated at 2022-06-24 00:52:43.951569
# Unit test for function curry
def test_curry():
    print('Unit test for curry:')
    sum_two = lambda a, b: a + b

    assert(curry(sum_two)(3, 5) == 8)
    assert(curry(sum_two)(3)(5) == 8)
    assert(curry(sum_two)()(3)(5) == 8)
    assert(curry(sum_two)()(3, 5) == 8)
    print('Test complete')


# Generated at 2022-06-24 00:52:44.944869
# Unit test for function pipe
def test_pipe():
    assert pipe(
        1,
        lambda value: value * 2,
        lambda value: value / 3,
    ) == 0.6666666666666666



# Generated at 2022-06-24 00:52:50.646490
# Unit test for function pipe
def test_pipe():
    def f(x): return x + 1
    def g(x): return x * 3
    def h(x): return x ** 2

    """
    f(g(h(x))) -> (x + 1) * 3 ** 2 -> x*9 + 3
    f(g(h(x))) == pipe(x, h, g, f)
    """
    assert compose(4, f, g, h) == pipe(4, h, g, f)


if __name__ == '__main__':
    test_pipe()

# Generated at 2022-06-24 00:52:57.030376
# Unit test for function memoize
def test_memoize():
    def memoizeWrap(function):
        call_count = 0
        return memoize(function, lambda argument1, argument2: argument1 == argument2 and call_count == 0)

    @memoizeWrap
    def function(value):
        return value

    assert function(1) == 1
    assert function(1) == 1
    assert function(2) == 2
    assert function(2) == 2



# Generated at 2022-06-24 00:52:58.904828
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(1), [1, 2, 3]) == [1]



# Generated at 2022-06-24 00:53:00.032159
# Unit test for function increase
def test_increase():
    result = increase(1)
    assert result == 2



# Generated at 2022-06-24 00:53:06.315013
# Unit test for function compose
def test_compose():
    sum3 = lambda x: x + 3
    mul3 = lambda x: x * 3
    equal_6 = lambda x: x == 6
    nothing = lambda x: x

    assert compose(5, sum3, mul3, equal_6) == False
    assert compose(5, nothing, nothing, nothing) == 5



# Generated at 2022-06-24 00:53:10.801142
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq(1)(1) == True
    assert eq(1)(2) == False



# Generated at 2022-06-24 00:53:17.824517
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1)(1)(1) is True
    assert eq(1, 2) is False
    assert eq(2)(1) is False
    assert eq(2)(2) is True
    assert eq(None, None) is True



# Generated at 2022-06-24 00:53:20.694484
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)


# Generated at 2022-06-24 00:53:30.346879
# Unit test for function cond
def test_cond():
    def true(value):
        return True

    def is_equals_5(value):
        return value == 5

    def is_equals_7(value):
        return value == 7

    def is_equals_2(value):
        return value == 2

    f1 = lambda x: x + 1
    f2 = lambda x: x + 2
    f3 = lambda x: x + 3

    assert cond([(is_equals_5, f1), (is_equals_7, f2)]) == f1
    assert cond([(is_equals_7, f2), (is_equals_2, f3), (true, f1)]) == f1



# Generated at 2022-06-24 00:53:32.635502
# Unit test for function pipe
def test_pipe():
    assert pipe(10, lambda x: x + 1, lambda x: x - 1) == 10



# Generated at 2022-06-24 00:53:35.434681
# Unit test for function identity
def test_identity():
    assert identity(True)
    assert identity(1) is 1
    assert identity('test') is 'test'



# Generated at 2022-06-24 00:53:38.388647
# Unit test for function memoize
def test_memoize():
    array = [[1, 1], [2, 1], [3, 2], [4, 3], [5, 5], [6, 8]]

    @memoize
    def fib(n):
        if n == 0:
            return 0
        elif n == 1:
            return 1
        else:
            return fib(n - 1) + fib(n - 2)

    for value in array:
        assert fib(value[0]) == value[1]



# Generated at 2022-06-24 00:53:43.471011
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 == 1, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [1, 3, 5, 7, 9]



# Generated at 2022-06-24 00:53:47.639635
# Unit test for function compose
def test_compose():
    assert compose(2, increase, increase) == 4
    assert compose(2, increase, identity) == 3
    assert compose(2, identity, increase) == 3
    assert compose(2, identity, identity) == 2
    assert compose(2, increase, lambda x: x + 1) == 4
    assert compose(2, lambda x: x + 1, increase) == 4
    assert compose(2, lambda x: x + 1, identity) == 3
    assert compose(2, identity, lambda x: x + 1) == 3



# Generated at 2022-06-24 00:53:54.012880
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-24 00:53:58.005180
# Unit test for function curried_filter
def test_curried_filter():

    a = [1, 2, 3, 4, 5]

    eq(curried_filter(lambda x: 1 > x)(a), [])
    eq(curried_filter(lambda x: x > 3)(a), [4, 5])



# Generated at 2022-06-24 00:54:05.752069
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y: x + y)(1, 2) == 3
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6
    assert curry(lambda x, y=2: x + y)(1) == 3
    assert curry(lambda x, y, z=3: x + y + z)(1, 2) == 6



# Generated at 2022-06-24 00:54:12.243807
# Unit test for function curry
def test_curry():
    # create curried function add_three
    add_three = curry(lambda x, y, z: x + y + z)
    assert add_three(1, 2, 3) == 6
    assert add_three(1)(2, 3) == 6
    assert add_three(1, 2)(3) == 6
    assert add_three(1)(2)(3) == 6

    add_three_one = add_three(1)
    assert add_three_one(2, 3) == 6
    assert add_three_one(2)(3) == 6

