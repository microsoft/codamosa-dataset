

# Generated at 2022-06-24 00:44:12.996071
# Unit test for function pipe
def test_pipe():
    assert pipe(1, increase) == 2

    to_string = lambda x: str(x)
    add_one = lambda x: x + 1
    result = pipe(1, add_one, to_string)
    assert result == '2'
    assert not (result != '2')



# Generated at 2022-06-24 00:44:21.139489
# Unit test for function curry
def test_curry():
    def adds_two_function(arg1, arg2):
        return arg1 + arg2

    curz_function = curry(adds_two_function)

    assert curz_function(2)(2) == 4
    assert curz_function(2)(3) == 5
    assert curz_function(2)(7) == 9
    assert curz_function(2)(-3) == -1
    assert curz_function(3)(2) == 5
    assert curz_function(3)(3) == 6
    assert curz_function(3)(7) == 10
    assert curz_function(3)(-3) == 0



# Generated at 2022-06-24 00:44:22.591555
# Unit test for function pipe
def test_pipe():
    assert pipe("1", lambda a: int(a) + 1, lambda a: a * 3) == 6



# Generated at 2022-06-24 00:44:25.408936
# Unit test for function find
def test_find():
    assert identity(12) == find([12, 16, 20], lambda x: x == 12)

    assert None == find([12, 16, 20], lambda x: x == 13)

    #   assert find([12, 16, 20], lambda x: x == 13) is None



# Generated at 2022-06-24 00:44:27.028556
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 0)(range(-10, 11)) == list(range(1, 11))



# Generated at 2022-06-24 00:44:35.389069
# Unit test for function find
def test_find():
    # Assert that a list of integers contains 2
    assert eq(find([1, 2, 3], eq(2)), 2)
    # Assert that a list of ints does not contain 4
    assert find([1, 2, 3], eq(4)) is None
    # Using None as a list to get a TypeError
    try:
        find(None, identity)
        assert False
    except TypeError:
        assert True



# Generated at 2022-06-24 00:44:37.645556
# Unit test for function increase
def test_increase():
    assert increase(3) == 4


# Generated at 2022-06-24 00:44:43.410391
# Unit test for function cond
def test_cond():
    def is_even(x):
        return x % 2 == 0

    def is_odd(x):
        return not is_even(x)

    def inc(x):
        return x + 1

    def dec(x):
        return x - 1

    inc_or_dec = cond([
        (is_even, inc),
        (is_odd, dec)
    ])

    # 2 => 3
    assert inc_or_dec(2) == 3

    # 3 => 2
    assert inc_or_dec(3) == 2



# Generated at 2022-06-24 00:44:45.588250
# Unit test for function find
def test_find():
    assert find(list(range(5)), lambda x: x == 3) == 3
    assert find(list(range(5)), lambda x: x == 5) is None

    # Unit test for function cond


# Generated at 2022-06-24 00:44:49.449180
# Unit test for function find
def test_find():
    collection = [0, 1, 2, 3]
    eq_0 = eq(0)
    eq_1 = eq(1)
    eq_2 = eq(2)
    eq_3 = eq(3)
    eq_4 = eq(4)

    assert find(collection, eq_0) == 0
    assert find(collection, eq_1) == 1
    assert find(collection, eq_2) == 2
    assert find(collection, eq_3) == 3
    assert find(collection, eq_4) is None



# Generated at 2022-06-24 00:44:53.344793
# Unit test for function curried_filter
def test_curried_filter():
    is_even = lambda x: x % 2 == 0
    assert curried_filter(is_even)([12, 13, 14, 15]) == [12, 14]


# Generated at 2022-06-24 00:44:59.640967
# Unit test for function cond
def test_cond():
    def is_even(x: int) -> bool:
        return x % 2 == 0

    def is_odd(x: int) -> bool:
        return x % 2 != 0

    def is_positive(x: int) -> bool:
        return x > 0

    def is_negative(x: int) -> bool:
        return x < 0

    def is_zero(x: int) -> bool:
        return x == 0

    def is_one(x: int) -> bool:
        return x == 1

    def is_two(x: int) -> bool:
        return x == 2

    def is_three(x: int) -> bool:
        return x == 3

    def is_four(x: int) -> bool:
        return x == 4


# Generated at 2022-06-24 00:45:01.505085
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 3)([1, 2, 3, 4, 5]) == [4, 5]



# Generated at 2022-06-24 00:45:02.895265
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-24 00:45:05.322778
# Unit test for function increase
def test_increase():
    # Normal
    assert increase(1) == 2
    assert increase(0) == 1
    assert increase(10) == 11
    assert increase(25) == 26
    assert increase(25.5) == 26.5



# Generated at 2022-06-24 00:45:09.688770
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False



# Generated at 2022-06-24 00:45:16.956119
# Unit test for function memoize
def test_memoize():
    test_list = [1, 2, 5, 3, 2, 1]

    @memoize
    def test_function(x):
        for idx, item in enumerate(test_list):
            if item == x:
                return idx

    assert test_function(3) == 3
    assert test_function(3) == 3
    assert test_function(1) == 0
    assert test_function(2) == 1
    assert test_function(2) == 1


# Unit testing
if __name__ == '__main__':
    test_memoize()

# Generated at 2022-06-24 00:45:26.881152
# Unit test for function cond
def test_cond():
    def f_even(x): return x % 2 == 0

    def f_int(x): return type(x) == int

    def f_string(x): return type(x) == str

    def f_none(x): return x is None

    def f_test_even(x): return "it's even"

    def f_test_int(x): return "it's int"

    def f_test_string(x): return "it's string"

    def f_test_none(x): return "it's none"

    def f_test_all(x): return "it's all"

    def f_cond_none_string(x): return cond([(f_int, f_test_int),
                                            (f_even, f_test_even)])
    def f_cond_none(x): return

# Generated at 2022-06-24 00:45:31.742776
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(2), [2, 3]) == [2]



# Generated at 2022-06-24 00:45:36.474667
# Unit test for function memoize
def test_memoize():
    """
    Test function memoize.
    :param fn: function to test
    :type fn: Function(A) -> B
    :returns:
    :rtype:
    """
    def count():
        count.counter += 1
        return count.counter

    count.counter = 0

    memoized_count = memoize(count)

    assert memoized_count() == 1
    assert count.counter == 1
    assert memoized_count() == 1
    assert count.counter == 1



# Generated at 2022-06-24 00:45:39.642372
# Unit test for function curried_map
def test_curried_map():
    assert list(curried_map(lambda x: x + 1, [1, 2, 3])) == [2, 3, 4]


# Generated at 2022-06-24 00:45:42.018790
# Unit test for function curry
def test_curry():
    @curry
    def foo(added, value):
        return added + value

    assert foo(1)(1) == 2



# Generated at 2022-06-24 00:45:51.659512
# Unit test for function cond
def test_cond():
    def is_zero(x): return x == 0

    def is_odd(x): return x % 2 == 1

    def is_even(x): return x % 2 == 0

    # tests
    assert 5 == cond([(is_zero, identity), (is_odd, increase), (is_even, increase)])(0)
    assert 1 == cond([(is_zero, identity), (is_odd, increase), (is_even, decrease)])(0)
    assert 6 == cond([(is_zero, identity), (is_odd, increase), (is_even, increase)])(5)
    assert 4 == cond([(is_zero, identity), (is_odd, increase), (is_even, increase)])(3)



# Generated at 2022-06-24 00:45:54.745799
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:46:00.070621
# Unit test for function cond
def test_cond():
    def f(x: int):
        return x ** 2

    def g(x: int):
        return x ** 3

    def h(x: int):
        return x ** 4

    def f_condition(x: int):
        return x % 2 == 0

    def g_condition(x: int):
        return x % 3 == 0

    def h_condition(x: int):
        return x % 4 == 0

    function = cond([
        (f_condition, f),
        (g_condition, g),
        (h_condition, h)
    ])

    assert function(4) == f(4)
    assert function(9) == g(9)
    assert function(16) == h(16)



# Generated at 2022-06-24 00:46:04.092710
# Unit test for function compose
def test_compose():
    def say_hello(person):
        return 'Hello, {}'.format(person)

    def shout(phrase):
        return phrase.upper() + '!'

    greet = compose(shout, say_hello)
    assert greet('Guido') == 'HELLO, GUIDO!'



# Generated at 2022-06-24 00:46:08.326323
# Unit test for function curry
def test_curry():
   # f = lambda a, b, c, d, e: a + b + c + d + e
    f = lambda a, b, c: a + b + c

    g = curry(f)
    print(g(1)(1)(1))



# Generated at 2022-06-24 00:46:11.225320
# Unit test for function memoize
def test_memoize():
    @curry
    def add(a, b):
        print('hello')
        return a + b


    add_memoized = memoize(add)
    # assert add_memoized(2, 3) == 5
    # assert add_memoized(3, 3) == 5
    # assert add_memoized(1, 4) == 5



# Generated at 2022-06-24 00:46:12.278445
# Unit test for function identity
def test_identity():
    result = identity(0)
    assert result == 0


# Generated at 2022-06-24 00:46:17.647639
# Unit test for function curried_map
def test_curried_map():
    # create curried_map by currying curried_map function
    curried_map1 = curried_map(lambda x: x + 1)

    assert curried_map1([1, 2, 3]) == [2, 3, 4]
    assert curried_map1([1, 2, 3, 4]) == [2, 3, 4, 5]



# Generated at 2022-06-24 00:46:19.210662
# Unit test for function identity
def test_identity():
    assert identity(1) == 1, "Identity test failed"



# Generated at 2022-06-24 00:46:23.536460
# Unit test for function eq
def test_eq():
    assert True == eq(1, 1)
    assert True == eq(True, True)
    assert True == eq("True", "True")
    assert False == eq(False, "True")



# Generated at 2022-06-24 00:46:28.175504
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity("1") == "1"
    assert identity([1]) == [1]



# Generated at 2022-06-24 00:46:34.856567
# Unit test for function eq
def test_eq():
    assert eq(0, 0) is True
    assert eq(1, 0) is False
    assert eq(1, 1) is True
    assert eq(5, 5) is True
    assert eq('a', 'a') is True
    assert eq(True, True) is True

    eq_1 = eq(1)
    assert eq_1(1) is True
    eq_2 = eq(2)
    assert eq_1(2) is False
    assert eq_2(2) is True


# Generated at 2022-06-24 00:46:43.060830
# Unit test for function memoize
def test_memoize():
    factorial: Callable = lambda n: 1 if n <= 1 else n * factorial(n - 1)
    factorial_memoized: Callable = memoize(factorial)
    factorial_memoized_2: Callable = memoize(factorial)

    assert factorial_memoized(3) == 6
    assert factorial_memoized(3) == 6

    assert factorial_memoized_2(4) == 24
    assert factorial_memoized_2(4) == 24
    assert factorial_memoized(5) == 120



# Generated at 2022-06-24 00:46:45.651624
# Unit test for function eq
def test_eq():
    assert eq(2, 1) == False
    assert eq(2, 2) == True
    assert eq(2)(1) == False
    assert eq(2)(2) == True



# Generated at 2022-06-24 00:46:48.508011
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b, c: a + b + c)(1)(2)(3) == 6
    assert curry(lambda a, b, c: a + b + c)(1, 2, 3) == 6



# Generated at 2022-06-24 00:46:58.125747
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x * 2, [1, 2, 3, 4, 5]) == [2, 4, 6, 8, 10]
    assert curried_map(lambda x: x * 2, [1, 2, 3, 4, 5]) == [2, 4, 6, 8, 10]
    assert curried_map(lambda x: x * 2)([1, 2, 3, 4, 5]) == [2, 4, 6, 8, 10]
    assert curried_map(lambda x: x * 2)([1, 2, 3, 4, 5]) == [2, 4, 6, 8, 10]



# Generated at 2022-06-24 00:47:00.533673
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3]) == [2]



# Generated at 2022-06-24 00:47:01.914050
# Unit test for function increase
def test_increase():
    assert increase(1) == 2

# Generated at 2022-06-24 00:47:05.182897
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda a: a + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda a, b: a + b)(1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda a: a + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda a, b: a + b, 1, [1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-24 00:47:14.721647
# Unit test for function cond
def test_cond():
    eq_1 = cond([
        (eq(1), identity)
    ])
    eq_2 = cond([
        (eq(2), increase),
        (eq(1), identity)
    ])

    eq_3 = cond([
        (eq(3), identity),
        (eq(2), increase),
        (eq(1), identity)
    ])

    eq_4 = cond([
        (eq(4), increase),
        (eq(3), identity),
        (eq(2), increase),
        (eq(1), identity)
    ])

    assert eq_1(1) == 1
    assert eq_2(1) == 1
    assert eq_3(1) == 1
    assert eq_4(1) == 1
    assert eq_1(2) is None
    assert eq_2(2) == 3

# Generated at 2022-06-24 00:47:16.559465
# Unit test for function find
def test_find():
    items = [1, 5, 10, 15, 20]
    assert find(items, lambda item: item == 10) == 10
    assert find(items, lambda item: item == 11) is None



# Generated at 2022-06-24 00:47:20.780609
# Unit test for function curried_map
def test_curried_map():
    curried_mapper = curried_map(lambda item: item.isalpha())
    assert curried_mapper(['a', 'b', 'c']) == [True, True, True]



# Generated at 2022-06-24 00:47:24.125413
# Unit test for function increase
def test_increase():
    assert increase(3) == 4



# Generated at 2022-06-24 00:47:25.973762
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-24 00:47:28.363711
# Unit test for function pipe
def test_pipe():
    assert pipe(5, increase, increase, increase) == 8
    assert pipe(5, increase, (lambda x: x)) == 6
    assert pipe(5, (lambda x: x), increase, increase, increase) == 8

# Generated at 2022-06-24 00:47:37.170669
# Unit test for function curried_filter
def test_curried_filter():
    filter_out_gt = curried_filter(lambda x: x > 2)
    filter_out_even = curried_filter(lambda x: x % 2 == 0)
    assert filter_out_even([1, 2, 3, 4, 5, 6, 7, 8]) == [2, 4, 6, 8]
    assert filter_out_gt([1, 2, 3, 4, 5, 6, 7, 8]) == [1, 2, 3, 4]
    assert filter_out_even([1, 2, 3, 4, 5, 6, 7, 8]) == [2, 4, 6, 8]



# Generated at 2022-06-24 00:47:42.517784
# Unit test for function compose
def test_compose():
    double = lambda value: value * 2
    double_and_increase = compose(2, double, increase)
    assert double_and_increase == 6  # 2 + 1 = 3, 3 * 2 = 6


# Generated at 2022-06-24 00:47:46.574513
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6

# Generated at 2022-06-24 00:47:47.678732
# Unit test for function pipe
def test_pipe():
    assert pipe(1, identity, increase) == 2


# Generated at 2022-06-24 00:47:54.586165
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map([1, 2, 3])(lambda x: x + 1) == [2, 3, 4]


# Generated at 2022-06-24 00:47:56.591337
# Unit test for function compose
def test_compose():
    assert compose(1, increase) == 2
    assert compose(1, lambda a: a + 1, lambda a: a + 1) == 3



# Generated at 2022-06-24 00:48:00.246668
# Unit test for function compose
def test_compose():
    test_function = lambda x: x
    test_function_add = lambda x: x + 1
    test_function_multiply = lambda x: x * 2

    assert compose(1, test_function, test_function_add, test_function_multiply) == 4



# Generated at 2022-06-24 00:48:01.938471
# Unit test for function find
def test_find():
    """
    >>> test_find()
    42
    """
    value = find([13, 42, 69], lambda x: x == 42)
    assert value == 42



# Generated at 2022-06-24 00:48:05.899602
# Unit test for function memoize
def test_memoize():
    some_function = lambda argument: argument + 1

    memoized_fn = memoize(some_function)

    assert memoized_fn(1) == 2
    assert memoized_fn(1) == 2



# Generated at 2022-06-24 00:48:09.041021
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda value: value + 1, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-24 00:48:12.510702
# Unit test for function pipe
def test_pipe():
    assert pipe('Hello world', lower, find_letter) == [1, 1, 2, 2, 2, 3, 3, 4, 4, 5, 5, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12]



# Generated at 2022-06-24 00:48:14.376581
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x * 2)([1, 2, 3]) == [2, 4, 6]



# Generated at 2022-06-24 00:48:19.603432
# Unit test for function find
def test_find():
    assert find(list(range(5)), lambda x: x == 3) == 3
    assert find(list(range(5)), lambda x: x % 2 == 0) == 0
    assert find(list(range(5)), lambda x: x == 10) is None



# Generated at 2022-06-24 00:48:22.030969
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], eq(3)) == 3
    assert find([1, 2, 3, 4], eq(0)) is None
    assert find([1, 2, 3, 4], eq(5)) is None
    assert find([], eq(5)) is None



# Generated at 2022-06-24 00:48:30.706891
# Unit test for function memoize
def test_memoize():
    def factorial(x: int) -> int:
        if x == 1:
            return 1
        return x * factorial(x - 1)

    factorial = memoize(factorial)
    # factorial(12) = 479001600
    assert factorial(12) == 479001600
    factorial_result = factorial(12)
    # factorial(12) = 479001600
    assert factorial(12) == factorial_result
    # factorial(13) = 6227020800
    assert factorial(13) == 6227020800



# Generated at 2022-06-24 00:48:37.352358
# Unit test for function find
def test_find():
    find_list = [0, 1, 'a', 'b', '', [], [1, 2], [1, 2, 3], None, True]
    assert find(find_list, lambda value: value is None) is None
    assert find(find_list, lambda value: value is '') == ''
    assert find(find_list, lambda value: value is []) == []
    assert find(find_list, lambda value: value) is True


# Generated at 2022-06-24 00:48:39.590766
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b: a + b)(1, 2) == 3
    assert curry(lambda a, b: a + b)(1)(2) == 3



# Generated at 2022-06-24 00:48:40.910761
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(0) == 1
    assert increase(increase(2)) == 4



# Generated at 2022-06-24 00:48:42.711425
# Unit test for function curry
def test_curry():
    def add(x, y):
        return x + y

    add_curry = curry(add)
    assert add_curry(3)(4) == 7


if __name__ == '__main__':
    test_curry()

# Generated at 2022-06-24 00:48:46.207733
# Unit test for function compose
def test_compose():
    """
    Function run all unittest

    :param:
    :type:
    :returns:
    :rtype:
    """
    assert compose(1, increase, increase) == 3



# Generated at 2022-06-24 00:48:55.725709
# Unit test for function cond
def test_cond():
    key = identity
    cond_func = cond([
        (lambda x: x < 0, lambda x: 'less then zero'),
        (lambda x: x == 0, lambda x: 'equal zero'),
        (lambda x: x > 0, lambda x: 'more then zero')
    ])
    assert cond_func(-10) == 'less then zero'
    assert cond_func(-0.1) == 'less then zero'
    assert cond_func(0) == 'equal zero'
    assert cond_func(0.1) == 'more then zero'
    assert cond_func(10) == 'more then zero'



# Generated at 2022-06-24 00:49:04.694599
# Unit test for function curried_filter
def test_curried_filter():
    collection = ['a', 'b', 'c', 'd', 'e']
    assert curried_filter(eq('a'))(collection) == ['a']
    assert curried_filter(eq('b'))(collection) == ['b']
    assert curried_filter(eq('c'))(collection) == ['c']
    assert curried_filter(eq('d'))(collection) == ['d']
    assert curried_filter(eq('e'))(collection) == ['e']
    filtered = curried_filter(eq('a'))
    assert filtered(collection) == ['a']



# Generated at 2022-06-24 00:49:11.134227
# Unit test for function find
def test_find():
    result = find(
        [(0, 'a'), (1, 'b'), (2, 'c')],
        lambda element: element[0] == 1
    )
    assert result == (1, 'b')
    result = find(
        [(0, 'a'), (1, 'b'), (2, 'c')],
        lambda element: element[0] == 3
    )
    assert result is None



# Generated at 2022-06-24 00:49:11.969116
# Unit test for function increase
def test_increase():
    assert increase(1) == 2

# Generated at 2022-06-24 00:49:16.601395
# Unit test for function curried_map
def test_curried_map():
    assert(curried_map(lambda value: value * 2)([1, 2, 3]) == [2, 4, 6])

# Generated at 2022-06-24 00:49:18.786709
# Unit test for function memoize
def test_memoize():
    def times2(num):
        return num*2

    decorated_times2 = memoize(times2)

    assert decorated_times2(2) == 4
    assert decorated_times2(2) == 4

# Generated at 2022-06-24 00:49:25.613018
# Unit test for function find
def test_find():
    # Test for find with filter function
    assert find(range(1, 100), lambda x: x % 2 == 0) == 2
    assert find(range(1, 100), lambda x: x % 2 == 1) == 1

    # Test for find with eq function
    assert find(range(1, 100), eq(99)) == 99
    assert find(range(1, 100), eq(100)) is None



# Generated at 2022-06-24 00:49:27.786052
# Unit test for function compose
def test_compose():
    assert compose(
        5, increase,
        lambda x: x ** 2, lambda x: x / 2,
    ) == (((5 + 1) ** 2) / 2)



# Generated at 2022-06-24 00:49:30.676386
# Unit test for function eq
def test_eq():
    assert curry(eq(1))(1) == True
    assert curry(eq(1))(2) == False



# Generated at 2022-06-24 00:49:36.558371
# Unit test for function cond
def test_cond():
    assert cond(
        [
            (lambda x, y: x + y == 50, curry(increase, 1)),
            (lambda x, y: x + y == 60, curry(increase, 2)),
            (lambda x, y: x + y == 70, curry(increase, 3))
        ],
    )(10, 40) == 1



# Generated at 2022-06-24 00:49:46.827900
# Unit test for function memoize
def test_memoize():
    def square(x):
        return x ** 2

    def cube(x):
        return x ** 3

    memoized_square = memoize(square)
    memoized_cube = memoize(cube)

    assert memoized_square(2) == 4
    assert memoized_square(2) == 4
    assert memoized_square(2) == 4
    assert memoized_square(2) == 4

    assert memoized_cube(2) == 8
    assert memoized_cube(2) == 8
    assert memoized_cube(2) == 8
    assert memoized_cube(2) == 8

    memoized_cube2 = memoize(cube, lambda x, y: x == y)
    assert memoized_cube2(2) == 8
    assert memoized_cube2(3) == 27



# Generated at 2022-06-24 00:49:48.735900
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity('1') == '1'



# Generated at 2022-06-24 00:49:50.653839
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b, c: a + b + c)(1)(2)(3) == 6



# Generated at 2022-06-24 00:49:52.399343
# Unit test for function increase
def test_increase():
    assert increase(5) == 6
    assert increase(-3) == -2

# Generated at 2022-06-24 00:49:55.443991
# Unit test for function curried_map
def test_curried_map():
    # Arrange

    # Act
    curried = curried_map(increase)
    result = curried([1, 2, 3])

    assert result == [2, 3, 4]

# Generated at 2022-06-24 00:50:04.287932
# Unit test for function memoize
def test_memoize():
    # Check if memoize works without cache
    memoized_identity = memoize(identity)
    assert memoized_identity(10) == identity(10)
    assert memoized_identity(20) == identity(20)
    assert memoized_identity(20) == identity(20)
    assert memoized_identity(10) == identity(10)


    # Check if memoize works with cache
    memoized_identity = memoize(identity)
    assert memoized_identity(10) == identity(10)
    assert memoized_identity(20) == identity(20)
    assert memoized_identity(20) == identity(20)
    assert memoized_identity(10) == identity(10)



# Generated at 2022-06-24 00:50:07.751532
# Unit test for function curried_map
def test_curried_map():
    assert eq(['a', 'b', 'c'], curried_map(identity, ['a', 'b', 'c']))
    assert eq([1, 2, 3], curried_map(identity, [1, 2, 3]))
    assert eq(['1', '2', '3'], curried_map(str, [1, 2, 3]))



# Generated at 2022-06-24 00:50:17.937720
# Unit test for function compose
def test_compose():
    assert compose(
        1,
        lambda x: x + 1,
        lambda x: x * 2,
        lambda x: x - 3,
    ) == 2
    assert compose(
        [1, 2, 3],
        curried_map(lambda x: x + 1),
        curried_map(lambda x: x * 2),
        curried_map(lambda x: x - 3),
    ) == [2, 4, 6]
    assert compose(
        [1, 2, 3],
        curried_map(lambda x: x + 1),
        curried_filter(lambda x: x != 4),
    ) == [2, 3]



# Generated at 2022-06-24 00:50:27.282525
# Unit test for function curried_filter
def test_curried_filter():
    """ Test curried_filter"""
    from random import randint
    from functools import reduce
    from functools import partial
    from operator import add
    # for reproducibility
    randints = [randint(0, 10) for _ in range(20)]
    count = reduce(add, curried_filter(lambda x: x % 2 == 0, randints))
    assert count == reduce(add, filter(lambda x: x % 2 == 0, randints))
    count = reduce(add, partial(curried_filter, lambda x: x % 2 == 0)(randints))
    assert count == reduce(add, filter(lambda x: x % 2 == 0, randints))



# Generated at 2022-06-24 00:50:35.646835
# Unit test for function find
def test_find():
    assert find([], identity) is None
    assert find([0, 1, 1, 2, 3, 5, 8], eq(0)) == 0
    assert find([0, 1, 1, 2, 3, 5, 8], eq(2)) == 2
    assert find([0, 1, 1, 2, 3, 5, 8], eq(3)) == 3
    assert find([0, 1, 1, 2, 3, 5, 8], eq(8)) == 8
    assert find([0, 1, 1, 2, 3, 5, 8], eq(9)) is None



# Generated at 2022-06-24 00:50:45.239356
# Unit test for function cond
def test_cond():
    user = {
        'name': 'Tom'
    }

    def get_name(user):
        return user.get('name')

    def get_default_name():
        return 'John'

    def is_name_set(name):
        return name is not None

    def is_name_not_empty(name):
        return not name == ''

    expected_result = 'Tom'

    assert cond([
        (is_name_set, get_name),
        (is_name_not_empty, get_name),
        (identity, get_default_name),
    ])(user) == expected_result


# Generated at 2022-06-24 00:50:48.731383
# Unit test for function find
def test_find():
    collection: List[Tuple[int, str]] = [(1, "one"), (2, "two"), (3, "three"), (4, "four")]
    print(find(collection, lambda item: item[0] == 3))
    print(find(collection, lambda item: item[0] == 5))



# Generated at 2022-06-24 00:50:54.162619
# Unit test for function find
def test_find():
    assert find([1, 3, 4], eq(3)) == 3, "Find function should return appropriate element"
    assert find([], eq(3)) is None, "Find function should return None if collection is empty"
    assert find([1, 4, 5], eq(7)) is None, "Find function should return None if appropriate element not exists"


# Generated at 2022-06-24 00:50:55.212579
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:50:58.723852
# Unit test for function find
def test_find():
    assert find([0, 1, 2, 3, 4, 5], lambda item: item == 5) == 5
    assert find([0, 1, 2, 3, 4, 5], lambda item: item == 6) is None



# Generated at 2022-06-24 00:51:06.757386
# Unit test for function find
def test_find():
    """
    Test for function find
    """
    collection = [1, 2, 3, 4, 5]
    def odd_numbers(item):
        return item % 2 == 0
    assert find(collection, odd_numbers) == 2
    assert find(collection, lambda item: item % 2) == 1
    assert find(collection, lambda item: item) == 1
    assert find(collection, lambda item: item > 5) is None


if __name__ == '__main__':
    test_find()

# Generated at 2022-06-24 00:51:09.814530
# Unit test for function curried_filter
def test_curried_filter():
    curried_filter_even = curried_filter(lambda x: x % 2 == 0)

    assert curried_filter_even([1, 2, 3, 4]) == [2, 4]


# Generated at 2022-06-24 00:51:15.149447
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0)([]) == []
    assert curried_filter(lambda _: False)([1, 2, 3, 4]) == []


# Generated at 2022-06-24 00:51:19.590807
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity([1, 2, 3]) == [1, 2, 3]
    assert identity("foobar") == "foobar"


# Generated at 2022-06-24 00:51:27.056056
# Unit test for function curried_map
def test_curried_map():
    arr = [1, 2, 3, 4, 5]
    assert curried_map(increase, arr) == [2, 3, 4, 5, 6]
    assert curried_map(increase)(arr) == [2, 3, 4, 5, 6]
    assert curried_map(increase)(arr)(arr)(arr)(arr)(arr)(arr)(arr)(arr)(arr)(arr)(arr) == [2, 3, 4, 5, 6]



# Generated at 2022-06-24 00:51:38.252426
# Unit test for function cond
def test_cond():
    assert cond(
        [
            (lambda x: x < 0, lambda x: -1),
            (lambda x: x == 0, lambda x: 0),
            (lambda x: x > 0, lambda x: 1),
        ]
    )(-1) == -1

    assert cond(
        [
            (lambda x: x < 0, lambda x: -1),
            (lambda x: x == 0, lambda x: 0),
            (lambda x: x > 0, lambda x: 1),
        ]
    )(0) == 0

    assert cond(
        [
            (lambda x: x < 0, lambda x: -1),
            (lambda x: x == 0, lambda x: 0),
            (lambda x: x > 0, lambda x: 1),
        ]
    )(1) == 1


# Unit

# Generated at 2022-06-24 00:51:40.832793
# Unit test for function eq
def test_eq():
    assert eq(1, 1), "eq(1, 1) should be true"
    assert eq(1, 2) is False, "eq(1, 2) should be false"



# Generated at 2022-06-24 00:51:42.749628
# Unit test for function identity
def test_identity():
    assert identity(2) == 2, 'Identity should return first argument'
    assert identity(None) is None, 'Identity should return first argument'



# Generated at 2022-06-24 00:51:45.499792
# Unit test for function curried_map
def test_curried_map():
    assert [2, 4, 6, 8] == curried_map(lambda x: x * 2, [1, 2, 3, 4])
    assert [2, 4, 6, 8] == \
        curried_map(lambda x: x * 2)([1, 2, 3, 4])



# Generated at 2022-06-24 00:51:49.458053
# Unit test for function curry
def test_curry():
    multiply = lambda x, y: x * y
    double = curry(multiply, 2)
    assert double(5) == 10
    assert double(10) == 20



# Generated at 2022-06-24 00:51:51.995371
# Unit test for function identity
def test_identity():
    assert identity('a') == 'a'
    assert identity(5) == 5


# Generated at 2022-06-24 00:51:55.769601
# Unit test for function find
def test_find():
    # Act
    result = find([1, 2, 3, 4], lambda x: x == 3)

    # Assert
    assert result == 3, "find(): not return 3"



# Generated at 2022-06-24 00:51:59.086968
# Unit test for function find
def test_find():
    a = [2, 3, 4, 7, 8, 1, 5, 6]
    assert(find(a, lambda x: x == 5) == 5)
    assert(find(a, lambda x: x == 0) == None)



# Generated at 2022-06-24 00:52:07.513476
# Unit test for function curried_map
def test_curried_map():
    r = [1, 3, 5, 7, 9]
    assert curried_map(increase)(r) == [2, 4, 6, 8, 10], \
        "Error in curried_map function"
    assert curried_map(increase, r) == [2, 4, 6, 8, 10], \
        "Error in curried_map function"
    assert curried_map(identity, r) == r, \
        "Error in curried_map function"
    assert curried_map(increase, [1])([2]) == [3], \
        "Error in curried_map function"



# Generated at 2022-06-24 00:52:12.209081
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1]) == [2]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1]) == [2]
    assert curried_map(increase, []) == []



# Generated at 2022-06-24 00:52:16.428555
# Unit test for function curry
def test_curry():
    def add(x, y):
        return x + y

    curry_add = curry(add)
    curry_add_1 = curry_add(1)

    assert curry_add_1(2) == 3



# Generated at 2022-06-24 00:52:22.090536
# Unit test for function curry
def test_curry():
    def add(x, y):
        return x + y

    curry_add = curry(add, args_count=2)
    assert curry_add(1, 2) == 3
    assert curry_add(10)(20) == 30
    assert curry_add(10, 10) == 20
    assert curry_add(10, 20) == 30



# Generated at 2022-06-24 00:52:25.098526
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda a: a > 1, [0, 1, 2, 3, 4, 5])(0) == [2, 3, 4, 5]

# Generated at 2022-06-24 00:52:29.564975
# Unit test for function curry
def test_curry():
    inc = curry(increase)
    assert inc(1) == 2
    assert inc(1, 1) == 2

    is_eq1 = curry(eq, 2)
    assert is_eq1(1, 1) == False
    assert is_eq1(1, 2) == True
    assert is_eq1(1) == False


# Unit tests for function identity

# Generated at 2022-06-24 00:52:35.792847
# Unit test for function memoize
def test_memoize():
    calls: int = 0

    @memoize
    def double(x: int):
        nonlocal calls
        calls += 1
        return x * 2

    assert double(2) == 4
    assert double(2) == 4
    assert calls == 1
    assert double(5) == 10
    assert calls == 2



# Generated at 2022-06-24 00:52:42.179509
# Unit test for function cond
def test_cond():
    """
    Test for function cond :)

    :returns:
    :rtype:
    """
    def is_even(x):
        return x % 2 == 0

    def is_odd(x):
        return x % 2 != 0

    def increase(x):
        return x + 1

    def decrease(x):
        return x - 1

    assert cond([
        (is_even, increase),
        (is_odd, decrease),
    ])(2) == 3
    assert cond([
        (is_even, increase),
        (is_odd, decrease),
    ])(3) == 2


if __name__ == "__main__":
    test_cond()

# Generated at 2022-06-24 00:52:47.656817
# Unit test for function curry
def test_curry():
    def sum_(a, b, c):
        return a + b + c

    sum_2 = curry(sum_)
    assert sum_2(1)(2)(3) == 6

    sum_3 = sum_2(1)
    assert sum_3(2)(3) == 6



# Generated at 2022-06-24 00:52:49.410188
# Unit test for function memoize
def test_memoize():
    def add(arg):
        return arg + 1

    m_add = memoize(add)
    assert m_add(1) == 2
    assert m_add(1) == 2



# Generated at 2022-06-24 00:52:50.754103
# Unit test for function pipe
def test_pipe():
    """
    >>> pipe(1, increase, identity)
    2
    """
    return True



# Generated at 2022-06-24 00:52:57.260091
# Unit test for function memoize
def test_memoize():
    def test_func(a):
        return a + 1
    test_memoized_func = memoize(test_func)
    assert test_memoized_func(2) == 3
    assert test_memoized_func(3) == 4
    assert test_memoized_func(3) == 4
    assert test_memoized_func(2) == 3


if __name__ == "__main__":
    test_memoize()

# Generated at 2022-06-24 00:52:59.180267
# Unit test for function find
def test_find():
    assert None is find([], identity)
    assert 0 is find([0, 1, 2, 3], identity)
    assert None is find([0, 1, 2, 3], lambda x: x > 3)
    assert 3 is find([0, 1, 2, 3], lambda x: x > 2)



# Generated at 2022-06-24 00:53:09.659049
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x < 5, lambda x: x * 2),
        (lambda x: x % 2 == 0, lambda x: x + 1),
        (lambda _: True, lambda x: x),
    ])(1) == 1
    assert cond([
        (lambda x: x < 5, lambda x: x * 2),
        (lambda x: x % 2 == 0, lambda x: x + 1),
        (lambda _: True, lambda x: x),
    ])(4) == 9
    assert cond([
        (lambda x: x < 5, lambda x: x * 2),
        (lambda x: x % 2 == 0, lambda x: x + 1),
        (lambda _: True, lambda x: x),
    ])(5) == 11



# Generated at 2022-06-24 00:53:15.771776
# Unit test for function pipe
def test_pipe():
    """
    Test for pipe function
    """
    assert pipe(10, [identity, increase, increase, increase])(10) == 13
    assert pipe(10, [increase, increase, increase])(10) == 13


# Generated at 2022-06-24 00:53:20.451197
# Unit test for function compose
def test_compose():
    add1 = lambda x: x + 1
    mul2 = lambda x: x * 2
    mul3 = lambda x: x * 3

    assert compose(2, add1, mul2, mul3) == (2 + 1) * 2 * 3



# Generated at 2022-06-24 00:53:23.017922
# Unit test for function pipe
def test_pipe():
    assert pipe(1, lambda i: i + 1, lambda i: i * 2) == 4



# Generated at 2022-06-24 00:53:33.378351
# Unit test for function cond
def test_cond():
    def is_zero(value):
        return value == 0

    def sum(value, value1):
        return value + value1

    plus_one = lambda value: value + 1

    assert cond([
        (is_zero, lambda _: 'is zero'),
        (lambda value: value < 0, lambda _: 'is negative'),
    ])(1) is None

    assert cond([
        (is_zero, lambda _: 'is zero'),
        (lambda value: value < 0, lambda _: 'is negative'),
    ])(-2) == 'is negative'

    assert cond([
        (is_zero, lambda _: 'is zero'),
        (lambda value: value < 0, lambda _: 'is negative'),
    ])(0) == 'is zero'


# Generated at 2022-06-24 00:53:36.279714
# Unit test for function cond
def test_cond():
    condition_list = [
        (lambda x: x > 5, identity),
        (lambda x: x > 0, lambda x: x + 1),
        (lambda x: x < 0, lambda x: x - 1),
    ]
    func = cond(condition_list)
    assert func(7) == 7
    assert func(3) == 4
    assert func(-1) == -2

# Generated at 2022-06-24 00:53:40.267004
# Unit test for function curried_filter
def test_curried_filter():
    assert [2, 4] == curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4])



# Generated at 2022-06-24 00:53:42.307450
# Unit test for function compose
def test_compose():
    assert compose(2, identity, increase) == 3
    assert compose(2, increase, identity) == 2


# unit test for function pipe

# Generated at 2022-06-24 00:53:44.238722
# Unit test for function curried_map
def test_curried_map():
    items = [1, 2, 3, 4, 5]
    assert curried_map(increase, items) == [2, 3, 4, 5, 6]



# Generated at 2022-06-24 00:53:48.359258
# Unit test for function eq
def test_eq():
    assert callable(eq)
    assert eq(1, 1, eq)
    assert not eq(1, 2, eq)


# Generated at 2022-06-24 00:53:58.819308
# Unit test for function memoize
def test_memoize():
    counter = 0
    def add_1(x: int) -> int:
        nonlocal counter
        counter += 1
        return x + 1

    memoized_add_1 = memoize(add_1)

    assert memoized_add_1(0) == 1
    assert memoized_add_1(0) == 1
    assert memoized_add_1(0) == 1
    assert counter == 1

    # Test with custom equal function
    memoized_add_1 = memoize(add_1, key=lambda a, b: (a % 2) == (b % 2))

    assert memoized_add_1(0) == 1
    assert memoized_add_1(2) == 3
    assert memoized_add_1(0) == 1
    assert memoized_add_1(2) == 3

# Generated at 2022-06-24 00:54:03.277457
# Unit test for function curry
def test_curry():
    def multi_add(a, b, c, d):
        return a + b + c + d

    assert curry(multi_add)(1)(2)(3)(4) == 10
    assert curry(multi_add, 4)(1, 2, 3, 4) == 10



# Generated at 2022-06-24 00:54:05.709469
# Unit test for function compose
def test_compose():
    """Unit test for function compose"""
    assert compose(1, increase, increase, increase) == 4
    assert compose(True, identity, identity) == True



# Generated at 2022-06-24 00:54:13.010760
# Unit test for function cond
def test_cond():
    is_odd = lambda number: number % 2 == 1
    is_even = lambda number: number % 2 == 0
    inc = lambda number: number + 1
    identity = lambda number: number

    increment_if_odd = cond([
        (is_odd, inc),
        (is_even, identity),
    ])

    assert increment_if_odd(1) == 2
    assert increment_if_odd(2) == 2

    increment_if_even = cond([
        (is_even, inc),
        (is_odd, identity),
    ])

    assert increment_if_even(2) == 3
    assert increment_if_even(1) == 1
