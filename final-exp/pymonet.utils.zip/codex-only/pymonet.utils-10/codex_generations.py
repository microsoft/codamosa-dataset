

# Generated at 2022-06-24 00:44:17.983488
# Unit test for function cond
def test_cond():
    execute = cond([
        (eq(0), lambda number: identity(number)),
        (eq(1), lambda number: increase(number)),
        (eq(2), lambda number: increase(number)),
        (eq(3), lambda number: increase(number)),
        (lambda *args: True, lambda number: increase(number)),
    ])
    for i in range(4):
        assert execute(i) == i + 1



# Generated at 2022-06-24 00:44:20.495536
# Unit test for function find
def test_find():
    assert None is find([1, 2, 3], lambda x: x > 4)
    assert 3 is find([1, 2, 3], lambda x: x == 3)



# Generated at 2022-06-24 00:44:24.258412
# Unit test for function curry
def test_curry():
    """
    testing curry
    """
    curried_addition = curry(lambda a, b, c: a + b + c)
    assert curried_addition(1)(2)(3) == 6
    assert curried_addition(1, 2)(3) == 6
    assert curried_addition(1, 2, 3) == 6



# Generated at 2022-06-24 00:44:27.838103
# Unit test for function curry
def test_curry():
    def test_func(a, b, c):
        return a + b + c
    curried = curry(test_func)
    assert curried(1)(2)(3) == 6
    assert curried(1)(2)(3)(4) == 6
    assert curried(1, 2, 3) == 6
    assert curried(1, 2)(3) == 6
    assert curried(1)(2, 3) == 6
    assert curried(1, 2, 3, 4) == 6



# Generated at 2022-06-24 00:44:32.003226
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2]) == [2, 3]
    assert curried_map(increase, []) == []



# Generated at 2022-06-24 00:44:32.652608
# Unit test for function identity
def test_identity():
    assert identity(1) == 1


# Generated at 2022-06-24 00:44:35.428192
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(1.0) == 1.0
    assert identity("s") == "s"
    assert identity("") == ""



# Generated at 2022-06-24 00:44:38.298476
# Unit test for function pipe
def test_pipe():
    assert pipe(2, increase, identity) == 3
    assert pipe(3, increase, increase, increase) == 6



# Generated at 2022-06-24 00:44:41.675277
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(1)) == 1
    assert find([1, 2, 3], eq(6)) is None
    assert find(list(range(100)), eq(60)) == 60
    assert find(list(range(10000)), eq(5000)) == 5000



# Generated at 2022-06-24 00:44:43.042507
# Unit test for function compose
def test_compose():
    assert compose(1, lambda value: value + 1, lambda value: value * 2) == 4



# Generated at 2022-06-24 00:44:44.441648
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(1), [1, 2, 3]) == [1]



# Generated at 2022-06-24 00:44:49.600726
# Unit test for function curry
def test_curry():
    def add(a, b):
        return a + b

    # Test for simple case
    assert add(1, 2) == 3
    f_3 = curry(add, 2)(1)
    assert f_3 == 3
    f_2 = curry(add)(1)(2)
    assert f_2 == 3
    f_1 = curry(add)(1)
    f_1_5 = f_1(5)
    assert f_1_5 == 6
    # Test for variable arguments count
    assert curry(add)(1)(2)(3)(4)(5) == 15



# Generated at 2022-06-24 00:45:03.815350
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert curried_filter(lambda x: x % 2 == 0, collection) == [2, 4, 6, 8, 10]
    assert curried_filter(lambda x: x % 2 != 0, collection) == [1, 3, 5, 7, 9]

    curried_filter_lambda = curried_filter(lambda x: x % 2 == 0)

    assert curried_filter_lambda([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [
        2, 4, 6, 8, 10]
    assert curried_filter_lambda([1, 3, 5, 7, 9]) == []
    assert curried_filter_lambda([]) == []



# Generated at 2022-06-24 00:45:04.829744
# Unit test for function compose
def test_compose():
    print(compose(1, increase, increase, increase, decrease))



# Generated at 2022-06-24 00:45:12.889170
# Unit test for function memoize
def test_memoize():
    def factorial_memoize(n):
        if n == 0:
            return 1
        else:
            return n * factorial(n - 1)

    def factorial(n):
        if n == 0:
            return 1
        else:
            return n * factorial(n - 1)

    factorial_memoize = memoize(factorial_memoize)
    factorial = memoize(factorial)
    assert factorial_memoize(5) == 120
    assert factorial(5) == 120



# Generated at 2022-06-24 00:45:14.451549
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(2, 3) == 5



# Generated at 2022-06-24 00:45:17.879112
# Unit test for function memoize
def test_memoize():
    def fn(a):
        return a + 1
    def key(a, b):
        return a == b
    Memoize = memoize(fn, key)

    assert Memoize(1) == fn(1)
    assert Memoize(1) == fn(1)
    assert Memoize(2) == fn(2)
    assert Memoize(1) == fn(1)



# Generated at 2022-06-24 00:45:27.123911
# Unit test for function cond
def test_cond():
    assert cond([
        (eq(2), increase)
    ])(2) == 3

    assert cond([
        (eq(1), identity),
        (eq(2), increase)
    ])(1) == 1

    assert cond([
        (eq(1), identity),
        (eq(2), increase)
    ])(2) == 3

    assert cond([
        (eq(1), increase),
        (eq(2), increase),
        (eq(3), increase)
    ])(3) == 4

    assert cond([
        (eq(1), increase),
        (eq(2), increase),
        (eq(3), increase)
    ])(4) is None



# Generated at 2022-06-24 00:45:27.755717
# Unit test for function identity
def test_identity():
    assert identity(True) is True
    assert identity(False) is False



# Generated at 2022-06-24 00:45:30.033288
# Unit test for function curried_filter
def test_curried_filter():
    gt_one = curried_filter(lambda x: x > 1)
    assert gt_one([1, 2, 3]) == [2, 3]


# Generated at 2022-06-24 00:45:32.008379
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 1) == 1
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-24 00:45:36.961266
# Unit test for function compose
def test_compose():
    assert compose(1, identity, increase) == 2
    assert compose(1, increase, increase) == 3
    assert compose(1, identity) == 1



# Generated at 2022-06-24 00:45:39.106775
# Unit test for function pipe
def test_pipe():
    assert pipe(1, identity, increase) == 2


# Generated at 2022-06-24 00:45:42.552461
# Unit test for function curried_map
def test_curried_map():
    collection = [1, 2, 3, 4, 5]
    result = [2, 3, 4, 5, 6]
    assert curried_map(increase, collection) == result



# Generated at 2022-06-24 00:45:47.005609
# Unit test for function memoize
def test_memoize():
    f = memoize(lambda x: x + 1)
    assert f(3) == 4
    assert f(3) == 4
    assert find(f.cache, lambda cacheItem: cacheItem[0] == 3) == (3, 4)
    f(4)
    assert len(f.cache) == 2



# Generated at 2022-06-24 00:45:51.659863
# Unit test for function pipe
def test_pipe():
    f = pipe(4, identity, increase, lambda x: x * 2)
    assert f == 12

    g = pipe(3, lambda x: x + 1, lambda x: x * 2)
    assert g == 8

    h = pipe(2, lambda x: x + 1)
    assert h(4) == 5



# Generated at 2022-06-24 00:45:58.197731
# Unit test for function compose
def test_compose():
    # arrange
    value1 = 1
    value2 = 'test value'
    functions = [
        identity,
        increase,
        lambda arg: arg + 'append',
        lambda arg: arg * 2
    ]
    expected_result = 4

    # act
    compose_result_1 = compose(value1, *functions)
    compose_result_2 = compose(value2, *functions)

    # assert
    assert expected_result == compose_result_1
    assert expected_result == len(compose_result_2)



# Generated at 2022-06-24 00:45:59.543066
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 2)([1, 2, 3]) == [3, 4, 5]



# Generated at 2022-06-24 00:46:01.962314
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq(1)(2) == False



# Generated at 2022-06-24 00:46:04.505488
# Unit test for function identity
def test_identity():
    assert identity(10) == 10
    assert identity(None) is None
    assert identity('hello') == 'hello'
    assert identity([1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-24 00:46:08.274673
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x % 2 == 1) == 1
    assert find([1, 2, 3, 4, 5], lambda x: x % 2 == 3) is None



# Generated at 2022-06-24 00:46:09.694976
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)


# Generated at 2022-06-24 00:46:12.724765
# Unit test for function pipe
def test_pipe():
    assert pipe(3, lambda x: x * 2, lambda x: x + 3) == 9
    assert pipe(1, lambda x: x + 1, lambda x: x * 2) == 4



# Generated at 2022-06-24 00:46:19.054583
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 3)([0, 1, 2, 3, 4, 5]) == [4, 5]
    assert curried_filter(lambda x: x > 5, [0, 1, 2, 3, 4, 5]) == []
    assert curried_filter(lambda x: x > 0, [0, 1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]



# Generated at 2022-06-24 00:46:28.056076
# Unit test for function curry
def test_curry():
    def divide(x, y):
        return x / y

    def test_curry(divide):
        """
        Test function curry
        """
        assert callable(curry(divide))
        assert curry(divide)(10)(2) == 5.0
        assert curry(curried_map)(lambda x: 2 * x)([1, 2]) == [2, 4]
        assert curry(curried_filter)(lambda x: x % 2 == 0)([2, 3, 4]) == [2, 4]

    if __name__ == "__main__":
        test_curry(divide)


# test curried_map

# Generated at 2022-06-24 00:46:29.976540
# Unit test for function curried_filter
def test_curried_filter():
    filter_numbers = curried_filter(lambda number: number % 2 == 0)
    assert filter_numbers([1, 2, 3]) == [2]


# Generated at 2022-06-24 00:46:33.061953
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity('asd') == 'asd'
    assert identity(False) is False


# Generated at 2022-06-24 00:46:34.526314
# Unit test for function eq
def test_eq():
    assert eq(True, identity(True))



# Generated at 2022-06-24 00:46:39.101459
# Unit test for function curry
def test_curry():
    def add(a, b, c):
        return a + b + c
    assert curry(add)(1)(2)(3) == 6
    assert curry(add, 2)(1, 2)(3) == 6
    assert curry(add, 3)(1, 2, 3) == 6



# Generated at 2022-06-24 00:46:41.631492
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4]) == [3, 4]


# Generated at 2022-06-24 00:46:45.059779
# Unit test for function memoize
def test_memoize():
    @memoize
    def expensive_function(x):
        print('expensive_function()')
        return x

    assert expensive_function(1) == 1
    assert expensive_function(1) == 1
    assert expensive_function(2) == 2


# Generated at 2022-06-24 00:46:50.588540
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)(range(10)) == list(filter(lambda x: x % 2 == 0, range(10)))
    assert curried_filter(lambda x: x % 2 == 0, range(10)) == list(filter(lambda x: x % 2 == 0, range(10)))



# Generated at 2022-06-24 00:46:58.786624
# Unit test for function cond
def test_cond():
    is_even = lambda value: value % 2 == 0

    # Return always true
    is_answer_42 = lambda value: value == 42

    # Return increase by one
    increment = lambda value: value + 1

    # Return divide by two
    divide_by_two = lambda value: value / 2

    cond_function = cond([(is_even, divide_by_two), (is_answer_42, identity)])

    assert 3 == cond_function(3)
    assert 2 == cond_function(4)
    assert 42 == cond_function(42)



# Generated at 2022-06-24 00:47:02.739286
# Unit test for function memoize
def test_memoize():
    @memoize
    def function(x):
        if x == 0:
            return 0
        return x * function(x - 1)

    assert function(2) == 2
    assert function(3) == 6
    assert function(0) == 0
    assert function(2) == 2



# Generated at 2022-06-24 00:47:03.561801
# Unit test for function increase
def test_increase():
    assert increase(5) == 6



# Generated at 2022-06-24 00:47:09.139760
# Unit test for function cond
def test_cond():
    cond_fn = cond([
        (eq(1), increase),
        (eq(2), identity)
    ])

    assert cond_fn(1) == 2
    assert cond_fn(2) == 2


# Generated at 2022-06-24 00:47:16.288764
# Unit test for function curried_filter
def test_curried_filter():
    even = lambda number: number % 2 == 0
    assert curried_filter(even)([]) == []
    assert curried_filter(even)([1, 2, 3, 4]) == [2, 4]

    assert curried_filter(lambda number: number % 3 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9]) == [3, 6, 9]


# Generated at 2022-06-24 00:47:19.068171
# Unit test for function increase
def test_increase():
    assert increase(0) == 1


# Generated at 2022-06-24 00:47:20.234412
# Unit test for function compose
def test_compose():
    assert compose(5, increase, increase, increase) == 8



# Generated at 2022-06-24 00:47:29.741261
# Unit test for function cond
def test_cond():
    """
    Test function cond

    :returns:
    :rtype:
    """
    condition = [
        (lambda a: a > 10, increase),
        (lambda a: a < 10, identity)
    ]
    increment_if_greater = cond(condition)
    assert increment_if_greater(11) == 12

    condition = [
        (lambda a: a > 10, identity),
        (lambda a: a < 10, increase)
    ]
    increment_if_less = cond(condition)
    assert increment_if_less(11) == 11


# Generated at 2022-06-24 00:47:38.226492
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0, ()) == []
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 2, 4]) == [2, 2, 4]
    assert curried_filter(lambda x: x % 2 == 0, [2, 2, 2, 2]) == [2, 2, 2, 2]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]


# Generated at 2022-06-24 00:47:38.859897
# Unit test for function identity
def test_identity():
    assert identity(42) == 42



# Generated at 2022-06-24 00:47:42.654455
# Unit test for function curried_map
def test_curried_map():
    map_one_by_one = curried_map(lambda x:x)
    map_one_by_one([1,2,3,4,5])
    map_odd_by_one = curried_map(lambda x:x, lambda x:x % 2 == 1)
    map_odd_by_one([1,2,3,4,5])
    print('Unit test for function curried_map: Ok')


# Generated at 2022-06-24 00:47:51.407886
# Unit test for function curry

# Generated at 2022-06-24 00:47:56.374100
# Unit test for function compose
def test_compose():
    assert compose(
        0,
        lambda value: value + 1,
        lambda value: value * 2,
        lambda value: value / 2,
    ) == 1

    assert compose(
        0,
        lambda value: value + 1,
    ) == 1

    assert compose(
        0,
    ) == 0



# Generated at 2022-06-24 00:48:02.917626
# Unit test for function cond
def test_cond():
    """
    """
    even = lambda x: x % 2 == 0
    multiply = lambda x: x * 2
    add = lambda x: x + 1
    subtract = lambda x: x - 1

    test_cond_function = cond(
        [(even, multiply), (even, add), (lambda x: True, subtract)]
    )

    assert test_cond_function(1) == 0, 'test_cond_function(1) != 0'
    assert test_cond_function(2) == 4, 'test_cond_function(2) != 4'
    assert test_cond_function(3) == 2, 'test_cond_function(3) != 2'



# Generated at 2022-06-24 00:48:04.505586
# Unit test for function compose
def test_compose():
    assert compose(1, increase, increase) == 3
    assert compose(1, increase) == 2
    assert compose(1) == 1


# Generated at 2022-06-24 00:48:10.195374
# Unit test for function cond
def test_cond():
    cond_test = cond([
        (lambda x: x % 2 == 0,
         lambda x: x * 2),
        (lambda x: True,
         lambda x: x + 1),
    ])

    assert [cond_test(item) for item in range(5)] == [1, 4, 3, 6, 5]



# Generated at 2022-06-24 00:48:11.041185
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:48:13.538755
# Unit test for function memoize
def test_memoize():
    def memoizeTest( value):
        return value + 1

    memoizeTest = memoize(memoizeTest)

    assert memoizeTest(2) == 3
    assert memoizeTest(2) == 3

# Generated at 2022-06-24 00:48:18.442089
# Unit test for function curried_map
def test_curried_map():
    assert [1, 2, 3] == curried_map(lambda x: x + 1)([0, 1, 2])



# Generated at 2022-06-24 00:48:21.265111
# Unit test for function curried_map
def test_curried_map():
    map_inc = curried_map(lambda a: a+1)
    map_inc_multiplied_by_4 = map_inc(map_inc(map_inc(map_inc([0]))))
    assert map_inc_multiplied_by_4 == [4]



# Generated at 2022-06-24 00:48:25.353163
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x == 2)([1, 2, 3]) == [False, True, False]



# Generated at 2022-06-24 00:48:30.114554
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, []) == []
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x ** 2, [1, 2, 3]) == [1, 4, 9]



# Generated at 2022-06-24 00:48:34.106702
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda value: value > 2) == 3
    assert find([1, 2, 3, 4], lambda value: value > 9) is None



# Generated at 2022-06-24 00:48:39.866551
# Unit test for function curried_map
def test_curried_map():
    map_list_of_strings = curried_map(lambda x: x[::-1])
    assert map_list_of_strings(['abc', 'def', 'ghj']) == ['cba', 'fed', 'jhg']



# Generated at 2022-06-24 00:48:46.579829
# Unit test for function curried_map
def test_curried_map():
    list1 = [1, 2, 3]
    list2 = [2, 3, 4]
    assert curried_map(lambda arg: arg + 1, list1) == list2

if __name__ == "__main__":
    test_curried_map()

# Generated at 2022-06-24 00:48:51.269195
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(2, 1)
    assert not eq(None, 1)

# Unit tests for curry function

# Generated at 2022-06-24 00:48:54.837121
# Unit test for function curried_filter
def test_curried_filter():
    """Test curried function filter, pass to this function list of odd numbers,
    filter odd numbers and return list of odd numbers"""
    assert curried_filter(
        lambda value: value % 2 == 0, [1, 2, 3, 4, 5, 6]
    ) == [2, 4, 6]



# Generated at 2022-06-24 00:48:55.613763
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:48:57.363319
# Unit test for function curried_filter
def test_curried_filter():
    return curried_filter(eq(2))([2, 3]) == [2]


# Generated at 2022-06-24 00:49:01.228819
# Unit test for function identity
def test_identity():
    assert identity(None) is None
    assert identity(1) == 1
    assert identity(1.0) == 1.0
    assert identity('test') == 'test'
    assert identity(True) is True
    assert identity(False) is False
    assert identity(()) == ()
    assert identity([]) == []
    assert identity({}) == {}



# Generated at 2022-06-24 00:49:10.700604
# Unit test for function memoize
def test_memoize():
    import time

    @memoize
    def fib(x):
        if x == 0 or x == 1:
            return 1
        else:
            return fib(x - 1) + fib(x - 2)

    start = time.time()
    fib_30 = fib(30)
    end = time.time()
    print(fib_30)
    print(end - start)

    start = time.time()
    fib_30 = fib(30)
    end = time.time()
    print(fib_30)
    print(end - start)

# Generated at 2022-06-24 00:49:12.907531
# Unit test for function compose
def test_compose():
    '''
    >>> compose(
    ...     3,
    ...     lambda x: x ** 3,
    ...     lambda x: x + 1,
    ... )
    64
    '''


# Generated at 2022-06-24 00:49:18.427624
# Unit test for function find
def test_find():
    collection, key, expected_result = [1, 2, 3, 4, 5], lambda x: x % 2 == 0, 2
    assert find(collection, key) == expected_result
    assert find(collection, key) == expected_result


# Generated at 2022-06-24 00:49:21.976578
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda a: a == 2) == 2
    assert find([1, 2, 3], lambda a: a < 2) == 1
    assert find([1, 2, 3], lambda a: a > 2) == 3
    assert find([1, 2, 3], lambda a: a > 3) is None



# Generated at 2022-06-24 00:49:22.801924
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:49:27.786678
# Unit test for function find
def test_find():
    assert find(
        [
            {'name': 'Max', 'age': 18},
            {'name': 'Alex', 'age': 11}
        ],
        lambda person: person['name'] == 'Alex'
    ) == {'name': 'Alex', 'age': 11}
    assert find(
        [
            {'name': 'Max', 'age': 18},
            {'name': 'Alex', 'age': 11}
        ],
        lambda person: person['name'] == 'Alexey'
    ) is None

# Generated at 2022-06-24 00:49:30.044043
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-24 00:49:35.224232
# Unit test for function find
def test_find():
    assert find([], lambda item: item == 1) is None
    assert find([1], lambda item: item == 1) == 1
    assert find([1], lambda item: item == 2) is None
    assert find([2, 1], lambda item: item == 1) == 1
    assert find([4, 2, 1], lambda item: item == 1) == 1
    assert find([4, 2, 1], lambda item: item == 0) is None
    assert find([6, 2, 1], lambda item: item == 6) == 6
    assert find([6, 2, 1], lambda item: item == 2) == 2



# Generated at 2022-06-24 00:49:38.111594
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2
    assert increase(2) == 3
    assert increase(3) == 4


# Generated at 2022-06-24 00:49:40.756941
# Unit test for function find
def test_find():
    assert find([], lambda x: True) is None
    assert find([1, 2, 3, 4], lambda x: x % 2 == 0) == 2



# Generated at 2022-06-24 00:49:43.488179
# Unit test for function eq
def test_eq():
    print(eq(2, 2))
    print(eq(2, 3))
    partial = eq(2)
    print(partial(2))
    print(partial(3))



# Generated at 2022-06-24 00:49:45.993409
# Unit test for function pipe
def test_pipe():
    action = pipe(
        'Hello world',
        str.split,
        curried_map(str.title),
        ' '.join
    )

    assert action == 'Hello World'

# Generated at 2022-06-24 00:49:47.246973
# Unit test for function curry
def test_curry():
    assert curry(increase)(1) == 2



# Generated at 2022-06-24 00:49:53.886524
# Unit test for function cond
def test_cond():
    a, b, c = [1, 2, 3]
    condition = cond([
        (lambda x, y: x == y, lambda x, y: '{} == {}'.format(x, y)),
        (lambda x, y: x < y, lambda x, y: '{} < {}'.format(x, y)),
        (lambda x, y: x > y, lambda x, y: '{} > {}'.format(x, y)),
        (lambda x, y: x <= y, lambda x, y: '{} <= {}'.format(x, y)),
        (lambda x, y: x >= y, lambda x, y: '{} >= {}'.format(x, y)),
        (lambda x, y: x != y, lambda x, y: '{} != {}'.format(x, y)),
    ])

   

# Generated at 2022-06-24 00:49:59.989464
# Unit test for function memoize
def test_memoize():
    def non_memoized_function(num):
        num = int(num)
        print(f"Compute {num}")
        return num ** 2

    memoized_function = memoize(non_memoized_function)

    assert memoized_function(2) == 4
    assert memoized_function(2) == 4
    assert memoized_function(3) == 9
    assert memoized_function(3) == 9



# Generated at 2022-06-24 00:50:01.591187
# Unit test for function identity
def test_identity():
    # given
    value = 1

    # when
    result = identity(value)

    # then
    assert 1 == result



# Generated at 2022-06-24 00:50:03.378634
# Unit test for function eq
def test_eq():
    assert eq(5, 5)
    assert not eq(5, 4)
    assert not eq(5, "5")
    assert not eq(5, [5])



# Generated at 2022-06-24 00:50:06.257659
# Unit test for function curried_map
def test_curried_map():
    list = [1, 2, 3, 4, 5]
    curried_map_fn = curried_map(increase)
    new_list = curried_map_fn(list)
    assert [2, 3, 4, 5, 6] == new_list



# Generated at 2022-06-24 00:50:10.845908
# Unit test for function curry
def test_curry():
    curried_func = curry(lambda x, y, z: x + y + z)
    assert curried_func(1)(2)(3) == 6
    assert curried_func(1, 2)(3) == 6
    assert curried_func(1, 2, 3) == 6



# Generated at 2022-06-24 00:50:13.978113
# Unit test for function pipe
def test_pipe():
    assert pipe(0, increase, increase) == 2
    assert pipe(0, find, curried_filter, curried_map) == None



# Generated at 2022-06-24 00:50:17.398684
# Unit test for function pipe
def test_pipe():
    assert pipe([1, 2, 3, 4], curried_filter(lambda x: x % 2 == 0), curried_map(lambda x: x + 1)) == [3, 5]



# Generated at 2022-06-24 00:50:21.262783
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 0)
    assert eq('a', 'a')
    assert not eq('a', 'b')
    assert eq(None, None)
    assert not eq(None, 42)
    assert not eq(42, None)



# Generated at 2022-06-24 00:50:25.108242
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2, \
        "find([1, 2, 3], lambda x: x == 2) isn't 2"
    assert find([1, 2, 3], lambda x: x == 4) is None, \
        "find([1, 2, 3], lambda x: x == 4) isn't None"
    print("test_find - success")



# Generated at 2022-06-24 00:50:28.956378
# Unit test for function increase
def test_increase():
    assert increase(5) == 6



# Generated at 2022-06-24 00:50:34.835775
# Unit test for function memoize
def test_memoize():
    def f(x):
        return x * 2

    memory_f = memoize(f)
    assert memory_f(1) == 2
    assert memory_f(1) == 2
    assert memory_f(2) == 4
    assert memory_f(2) == 4


# Generated at 2022-06-24 00:50:35.875357
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2


# Generated at 2022-06-24 00:50:39.034672
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], eq(2)) == 2
    assert find([1, 2, 3, 4], eq(5)) is None



# Generated at 2022-06-24 00:50:46.120255
# Unit test for function curried_filter
def test_curried_filter():
    mapper = lambda x: x + x
    collection = [1, 2, 3, 4]
    filterer = lambda x: x % 2 == 0

    result = curried_filter(mapper)
    assert result(filterer)(collection) == [4, 8]

    result = curried_filter(filterer)(collection)
    assert result == [2, 4]



# Generated at 2022-06-24 00:50:48.729544
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 2) == 2
    assert find(['hello', 'world'], lambda x: x == 'hello') == 'hello'


# Composed function without currying

# Generated at 2022-06-24 00:50:52.506116
# Unit test for function find
def test_find():
    assert(find([1, 2, 3, 4], lambda x: x == 3) == 3)
    assert(find([1, 2, 3, 4], lambda x: x == 5) is None)



# Generated at 2022-06-24 00:50:58.850071
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity([1, 2, 3]) == [1, 2, 3]
    assert identity('1') == '1'


# Generated at 2022-06-24 00:51:06.602345
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z, 3)(1, 2, 3) == 6
    assert curry(lambda x, y, z: x + y + z, 3)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z, 3)(1, 2)(3) == 6



# Generated at 2022-06-24 00:51:16.775223
# Unit test for function cond
def test_cond():
    assert cond(
        [(lambda value: value > 1, lambda value: value + 1),
         (lambda value: value < -1, lambda value: value - 2),
         (lambda value: value == 0, identity)],
    )(-1) == -3

    assert cond(
        [(lambda value: value > 1, lambda value: value + 1),
         (lambda value: value < -1, lambda value: value - 2),
         (lambda value: value == 0, identity)],
    )(0) == 0

    assert cond(
        [(lambda value: value > 1, lambda value: value + 1),
         (lambda value: value < -1, lambda value: value - 2),
         (lambda value: value == 0, identity)],
    )(1) == 2



# Generated at 2022-06-24 00:51:24.118875
# Unit test for function cond
def test_cond():
    def double(value):
        return value * 2

    def triple(value):
        return value * 3

    def quadro(value):
        return value * 4

    cond_double_triple = cond([
        (lambda value: value % 2 == 0, double),
        (lambda value: value % 3 == 0, triple)
    ])
    cond_double_quadro = cond([
        (lambda value: value % 2 == 0, double),
        (lambda value: value % 4 == 0, quadro)
    ])

    assert cond_double_triple(4) == 8
    assert cond_double_triple(6) == 18
    assert cond_double_triple(5) == 15

    assert cond_double_quadro(4) == 8
    assert cond_double_quadro(5) == 10
    assert cond_

# Generated at 2022-06-24 00:51:25.723195
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert eq('x', 'x')
    assert not eq(1, 2)


# Generated at 2022-06-24 00:51:32.615993
# Unit test for function find
def test_find():
    list_ = [1, 2, 3, 4, 5]
    list_eq3 = [{'a' : 1, 'b': 3}, {'a': 6, 'b': 3}]
    assert find(list_, eq(3)) == 3
    assert find(list_eq3,  lambda x: x['b'] == 3) == {'a': 1, 'b': 3}


# Generated at 2022-06-24 00:51:37.616866
# Unit test for function memoize
def test_memoize():
    import time

    def very_slow_function_to_memorize(argument):
        time.sleep(1)
        return argument

    memoized_very_slow_function_to_memorize = memoize(very_slow_function_to_memorize)
    assert memoized_very_slow_function_to_memorize(1) == 1


# Generated at 2022-06-24 00:51:44.725189
# Unit test for function compose
def test_compose():
    """
    Assert that all functions pass
    """
    assert identity(5) == compose(5, identity)
    assert increase(5) == compose(5, increase)
    assert increase(5) == compose(increase(5), identity)
    assert compose(increase(5), increase) == compose(increase(5), identity, increase)
    assert compose(increase(5), increase, identity) == compose(increase(5), identity, increase, identity)
    assert compose(increase(increase(5)), increase) == compose(increase(increase(5)), identity, increase)
    assert compose(increase(increase(5)), increase, identity) == compose(increase(increase(5)), identity, increase, identity)



# Generated at 2022-06-24 00:51:50.178254
# Unit test for function curried_filter
def test_curried_filter():
    """
    :returns:
    :rtype:
    """
    assert curried_filter(identity, [0, 1, 2, 3, 4, 5])(lambda item: item % 2 == 0) == [0, 2, 4]



# Generated at 2022-06-24 00:51:54.145918
# Unit test for function increase
def test_increase():
    assert increase(5) == 6
    assert increase(increase(3)) == 5
    assert increase(increase(increase(2))) == 4


# Generated at 2022-06-24 00:52:02.762825
# Unit test for function cond
def test_cond():
    """
    True if cond works.
    """
    collatz = lambda x: x / 2 if (x % 2 == 0) else (3 * x + 1)
    collatz_algorithm = lambda x: 1 if x == 1 else collatz_algorithm(collatz(x))
    memoized_collatz_algorithm = memoize(collatz_algorithm)

    assert memoized_collatz_algorithm(15) == 17
    assert memoized_collatz_algorithm(5) == 6
    assert memoized_collatz_algorithm(110) == 26
    assert memoized_collatz_algorithm(356) == 44
    assert memoized_collatz_algorithm(356) == 44



# Generated at 2022-06-24 00:52:09.938873
# Unit test for function cond
def test_cond():
    x = 1
    double = lambda y: y * 2
    add_one = lambda y: y + 1
    condition_list = [
        (lambda y: y % 2 != 0, double),
        (lambda y: y % 2 == 0, add_one),
    ]
    f = cond(condition_list)
    assert f(x) == double(x)
    x = 2
    assert f(x) == add_one(x)

# Generated at 2022-06-24 00:52:14.886021
# Unit test for function cond
def test_cond():
    def positive_function(num: int) -> int:
        return num

    def negative_function(num: int) -> int:
        return -num

    zero_function = lambda num: 0

    cond_function = cond([
        (lambda num: num > 0, positive_function),
        (lambda num: num < 0, negative_function),
        (lambda num: num == 0, zero_function)
    ])

    assert cond_function(1) == 1
    assert cond_function(-1) == -1
    assert cond_function(0) == 0



# Generated at 2022-06-24 00:52:17.782873
# Unit test for function identity
def test_identity():
    assert identity(2) == 2
    assert identity(1) == 1
    assert identity('hello world') == 'hello world'



# Generated at 2022-06-24 00:52:26.034448
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6



# Generated at 2022-06-24 00:52:29.207518
# Unit test for function find
def test_find():
    assert find([], lambda _: True) is None
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-24 00:52:34.203730
# Unit test for function pipe
def test_pipe():
    plus_one = lambda x: x + 1
    minus_one = lambda x: x - 1

    assert pipe(1, minus_one, plus_one) == 1



# Generated at 2022-06-24 00:52:35.084906
# Unit test for function compose
def test_compose():
    assert compose(4, increase, identity) == 5

# Generated at 2022-06-24 00:52:35.691545
# Unit test for function increase
def test_increase():
    assert increase(5) == 6



# Generated at 2022-06-24 00:52:43.065667
# Unit test for function pipe
def test_pipe():
    # Should return '5'
    assert pipe(1, increase, increase, increase, lambda x: str(x)) == '5'

    # Should return '5'
    assert pipe(1, curried_map(increase), curried_map(increase), str) == '5'

    # Should return '3'
    assert pipe(
        list(range(10)),
        curried_map(increase),
        curried_filter(lambda x: x % 2 == 1),
        str,
        len
    ) == '3'

    # Should return '3'
    assert pipe(
        list(range(10)),
        curried_map(pipe(increase, increase)),
        curried_filter(lambda x: x % 2 == 1),
        str,
        len
    ) == '3'

    # Should return

# Generated at 2022-06-24 00:52:46.314238
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-24 00:52:56.686280
# Unit test for function cond
def test_cond():
    # Function to test
    cond_to_test = cond([
        (lambda x: x == 42, lambda x: "answer"),
        (lambda x: x % 2 == 0, lambda x: "even"),
        (lambda x: x % 2 == 1, lambda x: "odd"),
    ])
    # Test 1
    assert cond_to_test(41) == "odd", "should return 'odd'"
    # Test 2
    assert cond_to_test(42) == "answer", "should return 'answer'"
    # Test 3
    assert cond_to_test(43) == "odd", "should return 'odd'"
    # Test 4
    assert cond_to_test(44) == "even", "should return 'even'"
    print("test of cond passed")



# Generated at 2022-06-24 00:53:05.757434
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x - 1, [1, 2, 3]) == [0, 1, 2]
    assert curried_map(lambda x: x / 2, [0, 0, 2]) == [0, 0, 1]
    assert curried_map(lambda x: x * 2, [0, 0, 1]) == [0, 0, 2]
    assert curried_map(lambda x: x * x, [0, 0, 1]) == [0, 0, 1]
    assert curried_map(lambda x: x + 5, [0, 0, 1]) == [5, 5, 6]



# Generated at 2022-06-24 00:53:11.011568
# Unit test for function eq
def test_eq():
    assert eq(2, 2)
    assert not eq(2, 3)
    curried_eq = eq(2)
    assert curried_eq(2)
    assert not curried_eq(3)



# Generated at 2022-06-24 00:53:18.759145
# Unit test for function find
def test_find():
    values = [
        {'name': 'John', 'age': 30},
        {'name': 'John', 'age': 30},
        {'name': 'Luke', 'age': 30},
        {'name': 'Luke'},
        {'name': 'Luke'},
    ]
    assert find(values, lambda value: 'age' in value) == {'name': 'John', 'age': 30}



# Generated at 2022-06-24 00:53:19.934974
# Unit test for function find
def test_find():
    print(
        find(
            [1, 2, 3, 4, 5],
            lambda x: x == 1
        )
    )



# Generated at 2022-06-24 00:53:27.558051
# Unit test for function memoize
def test_memoize():
    def multiply(a, b):
        return a * b

    def add(a, b):
        return a + b

    multiply_memoize = memoize(multiply)
    add_memoize = memoize(add)

    assert multiply_memoize(2, 2) == 4
    assert add_memoize(4, 4) == 8
    assert multiply_memoize(2, 2) == 4
    assert add_memoize(4, 4) == 8



# Generated at 2022-06-24 00:53:31.008892
# Unit test for function curried_map
def test_curried_map():
    def sum(x, y):
        return x + y

    mapped_function = curry(sum, 2)
    assert mapped_function(1) == curry(sum(1), 1)
    assert mapped_function(1)(2) == sum(1, 2)



# Generated at 2022-06-24 00:53:39.356630
# Unit test for function cond
def test_cond():
    is_even = lambda n: n % 2 == 0
    is_positive = lambda n: n > 0

    call_even = lambda n: 'even'
    call_positive = lambda n: 'positive'

    call_something = cond([
        (is_even, call_even),
        (is_positive, call_positive)
    ])

    assert call_something(4) == 'even'
    assert call_something(1) == 'positive'
    assert call_something(0) is None


# Generated at 2022-06-24 00:53:41.778856
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq('test', 'test')
    assert not eq('test', 'test1')



# Generated at 2022-06-24 00:53:42.855424
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(10) == 11



# Generated at 2022-06-24 00:53:45.137925
# Unit test for function identity
def test_identity():
    assert identity(1) == 1  # type: ignore
    assert identity(None) is None  # type: ignore
    assert identity(False) is False  # type: ignore



# Generated at 2022-06-24 00:53:48.794167
# Unit test for function pipe
def test_pipe():
    assert pipe(2, lambda x: x * 2, lambda x: x ** 2) == 8



# Generated at 2022-06-24 00:53:52.160784
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-24 00:54:00.988269
# Unit test for function cond
def test_cond():
    """
    Run unit test for function cond.
    """
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return not is_even(value)

    def is_bigger_then(number):
        return lambda value: value > number

    function = cond([
        (is_even, is_bigger_then(5)),
        (is_odd, is_bigger_then(6)),
    ])

    assert function(1)
    assert not function(2)
    assert not function(3)
    assert not function(4)
    assert function(5)
    assert not function(6)
    assert function(7)



# Generated at 2022-06-24 00:54:04.958335
# Unit test for function pipe
def test_pipe():
    functions = [lambda a: a + 1,
                 lambda a: a + 2,
                 lambda a: a + 3,
                 lambda a: a + 4
                 ]
    assert pipe(0, *functions) == 10
    assert pipe(10, *functions) == 20


# Unit test compose function

# Generated at 2022-06-24 00:54:07.921483
# Unit test for function pipe
def test_pipe():
    assert 1 == pipe(0, increase, increase)
    assert 2 == pipe(0, increase, increase, increase)
    assert 3 == pipe(0, increase, increase, increase, increase)



# Generated at 2022-06-24 00:54:14.453298
# Unit test for function cond
def test_cond():
    def check_first(a, b):
        return a == b[0]

    def check_second(a, b):
        return a == b[1]

    def first(a, b):
        return a

    def second(a, b):
        return b[1]

    assert cond([
        (check_first, first),
        (check_second, second),
    ])(3, (3, 'abc')) == 3

    assert cond([
        (check_second, second),
        (check_first, first),
    ])(3, ('abc', 3)) == 3

    assert cond([
        (check_second, second),
    ])(3, ('abc', 4)) is None