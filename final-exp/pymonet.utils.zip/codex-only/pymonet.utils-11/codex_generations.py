

# Generated at 2022-06-24 00:44:11.657408
# Unit test for function pipe
def test_pipe():
    assert pipe(1, increase, increase) == 3


# Generated at 2022-06-24 00:44:14.689253
# Unit test for function curry
def test_curry():
    def f():
        return print('Hello World!')

    curried_f = curry(f)
    curried_f()
    return curried_f



# Generated at 2022-06-24 00:44:17.845377
# Unit test for function curried_map
def test_curried_map():
    curried_map_test = curried_map(lambda x: x + 100)
    assert curried_map_test([1, 2, 3, 4]) == [101, 102, 103, 104]



# Generated at 2022-06-24 00:44:24.998316
# Unit test for function curry
def test_curry():
    def add(*args):
        return args[0] + args[1]

    def mul(*args):
        return args[0] * args[1]

    assert add(10, 20) == 30
    assert add(10)(20) == 30
    assert add(10)(20)(30) == 30
    assert add(10, 20, 30) == 30

    add_curried = curry(add)
    mul_curried = curry(mul)

    assert add_curried(20)(10) == 30
    assert add_curried(10, 20, 30) == 30
    assert mul_curried(2)(3) == 6
    assert mul_curried(2, 3, 4) == 6



# Generated at 2022-06-24 00:44:31.061242
# Unit test for function curry
def test_curry():
    # Without curry
    def add(x, y):
        return x + y

    assert add(2, 3) == 5
    assert add(7, 4) == 11

    # With curry
    add = curry(add)

    assert add(2)(3) == 5
    assert add(7)(4) == 11


test_curry()

# Generated at 2022-06-24 00:44:36.415451
# Unit test for function curried_map
def test_curried_map():
    test_list = [x for x in range(1, 11)]
    expected_result = [x * 2 for x in range(1, 11)]
    curried_map_mul = curried_map(lambda x: x * 2)
    result = curried_map_mul(test_list)
    assert result == expected_result



# Generated at 2022-06-24 00:44:46.828518
# Unit test for function cond
def test_cond():
    assert cond([
        (eq(0), increase),
        (eq(1), increase),
        (eq(2), increase),
        (eq(3), increase),
        (eq(4), increase),
        (eq(5), increase),
        (eq(6), increase),
        (eq(7), increase),
        (eq(8), increase),
        (identity, identity),
    ])(0) == 1


# Generated at 2022-06-24 00:44:55.528731
# Unit test for function curried_map
def test_curried_map():
    def inc(value):
        return value + 1
    collection = [1, 2, 3, 4, 5]
    curried = curried_map(inc)
    assert curried(collection) == [2, 3, 4, 5, 6]
    collection = [1, 2, 3, 4, 5]
    curried = curried_map(inc, collection)
    assert curried == [2, 3, 4, 5, 6]
    collection = [1, 2, 3, 4, 5]
    curried = curried_map(inc)(collection)
    assert curried == [2, 3, 4, 5, 6]
    collection = [1, 2, 3, 4, 5]
    curried = curried_map(inc, collection)()
    assert curried == [2, 3, 4, 5, 6]


# Generated at 2022-06-24 00:45:01.275442
# Unit test for function memoize
def test_memoize():
    @memoize
    def add1(value):
        return value + 1

    assert add1(1) == 2
    assert add1(1) == 2
    assert add1(1) == 2
    assert add1(2) == 3
    assert add1(3) == 4
    assert add1(3) == 4

# Generated at 2022-06-24 00:45:04.086327
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-24 00:45:06.816472
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-24 00:45:08.073621
# Unit test for function eq
def test_eq():
    assert eq(2, 2)
    assert eq(2, 1) is False


# Generated at 2022-06-24 00:45:12.424626
# Unit test for function find
def test_find():
    assert find([], lambda x: True) is None
    assert find([], lambda x: False) is None
    assert find([1, 2, 3], lambda x: x == 1) == 1
    assert find([1, 2, 3], lambda x: x == 3) == 3
    assert find([1, 2, 3], lambda x: x == 4) is None

# Generated at 2022-06-24 00:45:16.482716
# Unit test for function cond
def test_cond():
    hello = lambda: print("Hello")
    bye = lambda: print("Bye")
    rule1 = lambda first_name: first_name == "John"
    rule2 = lambda first_name: first_name == "Alice"
    rule_list = [(rule1, hello), (rule2, bye)]
    cond_function = cond(rule_list)
    cond_function("John")
    cond_function("Alice")
    cond_function("NoName")



# Generated at 2022-06-24 00:45:17.801638
# Unit test for function pipe
def test_pipe():
    assert pipe(1, identity, identity, increase) == 2
    assert pipe(1, identity, identity, increase, increase) == 3



# Generated at 2022-06-24 00:45:25.680487
# Unit test for function pipe
def test_pipe():
    assert pipe([1, 2, 3], curried_map(increase), curried_filter(lambda x: x % 2 == 0), curried_map(str)) == ['3', '5']
    assert pipe([1, 2, 3], curried_map(increase), curried_filter(lambda x: x % 2 == 0)) == [3, 5]
    assert pipe([1, 2, 3], curried_map(increase), []) == [2, 3, 4]
    assert pipe([], curried_map(increase)) == []


# Generated at 2022-06-24 00:45:26.549442
# Unit test for function pipe
def test_pipe():
    assert pipe(1, identity, increase, identify) == 2

# Generated at 2022-06-24 00:45:30.597469
# Unit test for function cond
def test_cond():
    test_fn = cond([
        (lambda x: x > 0, lambda x: x+1),
        (lambda x: x < 0, lambda x: x-1),
        (lambda x: x == 0, lambda x: x),
    ])
    assert test_fn(1) == 2
    assert test_fn(-1) == -2
    assert test_fn(0) == 0

# Generated at 2022-06-24 00:45:37.698965
# Unit test for function curried_filter
def test_curried_filter():
    assert (curried_filter(lambda a: a > 3)([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]) == [4, 5, 6, 7, 8, 9])
    assert (curried_filter(lambda a: a > 3, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]) == [4, 5, 6, 7, 8, 9])



# Generated at 2022-06-24 00:45:42.600084
# Unit test for function compose
def test_compose():
    result = compose(1, increase, increase)
    assert result == 3

    result = compose(1, increase, lambda value: value * 2)
    assert result == 4

    result = compose(1, lambda value: value * 2, increase)
    assert result == 3



# Generated at 2022-06-24 00:45:45.754301
# Unit test for function increase
def test_increase():
    assert(increase(0) == 1)
    assert(increase(1) == 2)
    assert(increase(5) == 6)


test_increase()



# Generated at 2022-06-24 00:45:50.587369
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]

# Generated at 2022-06-24 00:45:51.642597
# Unit test for function identity
def test_identity():
    assert identity(4) == 4


# Generated at 2022-06-24 00:45:56.291230
# Unit test for function curried_filter
def test_curried_filter():
    assert [1, 3, 5, 7] == curried_filter(lambda x: x % 2 != 0, range(1, 10))
    assert [2, 4, 6, 8] == curried_filter(lambda x: x % 2 == 0, range(1, 10))



# Generated at 2022-06-24 00:45:59.888170
# Unit test for function eq
def test_eq():
    assert True == eq(identity, identity)
    assert True == eq(identity, identity, eq)
    assert False == eq(identity, increase)
    assert False == eq(identity, increase, eq)



# Generated at 2022-06-24 00:46:02.260121
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x * 2, [1, 2, 3]) == [2, 4, 6]


# Generated at 2022-06-24 00:46:03.819381
# Unit test for function pipe
def test_pipe():
    assert pipe(0, identity) == 0
    assert pipe(0, increase) == 1



# Generated at 2022-06-24 00:46:06.367734
# Unit test for function pipe
def test_pipe():
    """
    Test for function pipe.
    """
    composed = pipe(2, increase, increase, identity)
    assert composed == 4



# Generated at 2022-06-24 00:46:08.022347
# Unit test for function pipe
def test_pipe():
    assert pipe(1,
                (lambda x: x + 1),
                (lambda x: x * 2)
                ) == 4



# Generated at 2022-06-24 00:46:09.340785
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-24 00:46:14.869713
# Unit test for function curry
def test_curry():
    inc = curry(lambda x, y: x + y)
    assert inc(1)(2) == 3

    curl = curry(lambda x, y, z: x + y + z)
    assert curl(1)(2)(3) == 6
    assert curl(1, 2)(3) == 6
    assert curl(1)(2, 3) == 6
    assert curl(1, 2, 3) == 6



# Generated at 2022-06-24 00:46:18.552938
# Unit test for function find
def test_find():
    assert find([], lambda x: True) is None
    assert find([1, 2, 3, 4], lambda x: x % 2 == 0) == 2
    assert find([1, 2, 3, 4], lambda x: x == 5) is None

# Generated at 2022-06-24 00:46:23.977814
# Unit test for function pipe
def test_pipe():
    assert pipe(
        1,
        increase,
        increase
    ) == 3

    assert pipe(
        "Hello, World!",
        lambda x: x.split(" "),
        lambda x: x[::-1],
        lambda x: " ".join(x)
    ) == "World! Hello,"



# Generated at 2022-06-24 00:46:27.092540
# Unit test for function pipe
def test_pipe():
    assert pipe(1, identity, increase) == 2
    assert pipe(1, increase, increase, increase) == 4
    assert pipe(1, compose(increase, identity)) == 2

# Generated at 2022-06-24 00:46:29.430665
# Unit test for function compose
def test_compose():
    # Given
    test_collection = [1, 2]
    test_key = lambda x: x == 2

    # When
    result = compose(
        test_collection,
        curried_filter(test_key),
        curried_map(increase)
    )

    # Then
    assert result == [3]

# Generated at 2022-06-24 00:46:41.498323
# Unit test for function find
def test_find():
    assert find([], lambda x: True) is None

    assert find([1, 2, 3, 4, 5], lambda x: x == 1) == 1
    assert find([1, 2, 3, 4, 5], lambda x: x == 2) == 2
    assert find([1, 2, 3, 4, 5], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda x: x == 4) == 4
    assert find([1, 2, 3, 4, 5], lambda x: x == 5) == 5

    assert find([1, 2, 3, 4, 5], lambda x: x == 6) is None
    assert find([1, 2, 3, 4, 5], lambda x: x == 0) is None

# Generated at 2022-06-24 00:46:43.440675
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity('one') == 'one'
    assert identity('two') != 'one'



# Generated at 2022-06-24 00:46:48.184018
# Unit test for function identity
def test_identity():
    assert identity(0) == 0
    assert identity('') == ''
    assert identity([]) is not None
    assert identity(()) is not None
    assert identity([1, 2, 3]) == [1, 2, 3]
    assert identity({'x': 1, 'y': 2}) == {'x': 1, 'y': 2}



# Generated at 2022-06-24 00:46:53.806224
# Unit test for function compose
def test_compose():
    composed = compose(1, inc, inc, inc)
    assert composed == (1 + 1 + 1), "Composition of functions doesn't work"
    assert composed == pipe(1, inc, inc, inc), "Composition of functions doesn't work"



# Generated at 2022-06-24 00:46:58.438860
# Unit test for function curry
def test_curry():
    """Test for currying functions.
    """
    assert eq(curry(lambda a, b: a + b)(2)(2), 4)
    assert eq(curry(lambda a, b, c: a + b + c)(2)(2)(2), 6)
    assert eq(curry(lambda a, b, c, d: a + b + c + d)(2)(2)(2)(2), 8)


# Unit tests for compose and pipe

# Generated at 2022-06-24 00:47:01.525151
# Unit test for function compose
def test_compose():
    """
    Compose function tests
    """
    assert compose(1, increase) == 2
    assert compose('ABC', lambda x: x.lower()) == 'abc'



# Generated at 2022-06-24 00:47:03.677991
# Unit test for function increase
def test_increase():
    assert increase(5) == 6, "Increase doesn't work with 5"
    assert increase(15) == 16, "Increase doesn't work with 15"



# Generated at 2022-06-24 00:47:11.617200
# Unit test for function compose
def test_compose():
    assert identity(5) == compose(5, identity)
    assert 3 == compose(6, lambda x: x / 2)
    assert 9 == compose(6, lambda x: x / 2, lambda x: x * 3)
    assert 'hello, world!' == compose(
        12,
        lambda x: x + 1,
        lambda x: x * 2,
        lambda x: x / 3,
        lambda x: x % 4,
        lambda x: str(x),
        lambda x: 'hello, {}!'.format(x)
    )



# Generated at 2022-06-24 00:47:15.838580
# Unit test for function cond
def test_cond():
    """
    Test cond function.
    """
    cond_functions = cond(
        [(eq(1), lambda x: f'1'), (eq(2), lambda x: f'2')]
    )
    for i in [1, 2]:
        assert cond_functions(i) == str(i)

# Generated at 2022-06-24 00:47:19.710245
# Unit test for function curried_map
def test_curried_map():
    result_list = curried_map(lambda x: x*2)([1,2,3,4,5])
    assert result_list == [2,4,6,8,10]


# Generated at 2022-06-24 00:47:23.233405
# Unit test for function cond
def test_cond():
    assert type(cond([(eq(1), identity)])) is types.FunctionType
    assert cond([(eq(1), increase), (eq(2), identity)])(1) == 2
    assert cond([(eq(2), increase), (eq(2), identity)])(2) == 3
    assert cond([(eq(2), increase)])() is None



# Generated at 2022-06-24 00:47:30.968865
# Unit test for function curried_map
def test_curried_map():
    """
    Test cases.
    """
    tests = [
        [
            'case: map identity',
            curried_map(identity)([1, 2, 3]),
            [1, 2, 3]
        ],
        [
            'case: map identity (with curried)',
            curried_map(identity, [1, 2, 3]),
            [1, 2, 3]
        ],
        [
            'case: map increase',
            curried_map(increase, [1, 2, 3]),
            [2, 3, 4]
        ]
    ]

    for test in tests:
        assert test[1] == test[2], f'{test[0]}: {test[1]} should equal {test[2]}'



# Generated at 2022-06-24 00:47:33.853992
# Unit test for function pipe
def test_pipe():
    def add1(x):
        return x + 1
    def add2(x):
        return x + 2
    assert pipe(1, add1, add2) == 4


# Generated at 2022-06-24 00:47:38.348151
# Unit test for function curry
def test_curry():
    print('Test curry')
    x = lambda a, b, c, d: a * b * c * d
    curried = curry(x, 4)
    assert curried is not x
    assert curried(1, 2, 3, 4) == x(1, 2, 3, 4)
    assert curried(1, 2, 3, None) is not None
    assert curried(1, 2, None, None) is not None
    assert curried(1, None, None, None) is not None
    assert curried(None, None, None, None) is not None
    print('Test curry OK')



# Generated at 2022-06-24 00:47:41.555667
# Unit test for function curry
def test_curry():
    def add_three(a, b, c):
        return a + b + c

    add_one = curry(add_three)(1)
    add_two = curry(add_three)(1)

    assert add_one(2, 3) == 6
    assert add_two(2, 3) == 6



# Generated at 2022-06-24 00:47:43.531342
# Unit test for function pipe
def test_pipe():
    assert pipe(
        [1, 2],
        curried_map(increase),
        curried_filter(compose(
            identity,
            eq(1)
        ))
    ) == [2]


# Generated at 2022-06-24 00:47:43.956150
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:47:47.605874
# Unit test for function cond
def test_cond():
    abstract_test_cond(
        fn=cond([(lambda expression: expression > 0, identity),
                 (lambda expression: expression < 0, decrease),
                 (lambda expression: expression == 0, increase)]),
        test_condition_list=[
            (5, 5),
            (-5, -6),
            (0, 1)
        ]
    )



# Generated at 2022-06-24 00:47:54.946475
# Unit test for function curried_filter
def test_curried_filter():
    """
    Test for function curried_filter.
    """
    assert curried_filter(eq(2), [1, 2, 3, 4, 5]) == [2]
    assert curried_filter(eq(2))([1, 2, 3, 4, 5]) == [2]



# Generated at 2022-06-24 00:48:00.651599
# Unit test for function curry
def test_curry():
    # Define function to curry
    def add(a: int, b: int) -> int:
        return a + b

    # Usage of curry function
    add_two_numbers = curry(add)
    assert add_two_numbers(4)(5) == 9
    assert add_two_numbers(2, 3) == 5
    assert add_two_numbers(1)(2)(3)(4) == 10
    assert add_two_numbers(1)(5, 5) == 11



# Generated at 2022-06-24 00:48:05.146863
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(2) == 3
    assert increase(3) == 4


# Generated at 2022-06-24 00:48:07.577858
# Unit test for function identity
def test_identity():
    assert identity(True) == True



# Generated at 2022-06-24 00:48:09.476145
# Unit test for function identity
def test_identity():
    assert identity('test') == 'test'
    assert identity(['test']) == ['test']


# Unit tests for function increase

# Generated at 2022-06-24 00:48:10.678268
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-24 00:48:11.836245
# Unit test for function eq
def test_eq():
    assert eq(1, 1)


# Unit tests for function pipe

# Generated at 2022-06-24 00:48:18.994343
# Unit test for function curried_map
def test_curried_map():
    """
    Test for function curried_map
    """
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x * 2)(range(5)) == [0, 2, 4, 6, 8]
    assert curried_map(lambda x: x ** 2)(range(5)) == [0, 1, 4, 9, 16]
    assert curried_map(lambda x: x * x)(range(5)) == [0, 1, 4, 9, 16]
# Test for function curried_filter

# Generated at 2022-06-24 00:48:22.346585
# Unit test for function eq
def test_eq():
    # Equal ints
    assert(eq(1, 1))

    # Not equal ints
    assert(not eq(1, 2))

    # Equal strings
    assert(eq('a', 'a'))

    # Not equal strings
    assert(not eq('a', 'b'))

    # Equal lists
    assert(eq([1], [1]))

    # Not equal lists
    assert(not eq([1], [2]))


# Generated at 2022-06-24 00:48:29.386081
# Unit test for function cond
def test_cond():
    """
    cond should return execute_function witch first condition_function return truly value.
    """
    def is_lt5(n):
        return n < 5

    def double(n):
        return n * 2

    def half(n):
        return n / 2

    c = cond([(is_lt5, double), (identity, half)])
    assert c(3) == 6
    assert c(7) == 3.5



# Generated at 2022-06-24 00:48:34.525510
# Unit test for function memoize
def test_memoize():
    calls_count = 0

    def fn(value):
        nonlocal calls_count
        calls_count += 1

    memoized_fn = memoize(fn)

    memoized_fn(5)
    memoized_fn(5)

    assert calls_count == 1



# Generated at 2022-06-24 00:48:38.563499
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(2))([1, 2, 3, 2, 1]) == [2, 2]



# Generated at 2022-06-24 00:48:40.569049
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x * 2)([1, 2, 3, 4]) == [2, 4, 6, 8]



# Generated at 2022-06-24 00:48:46.001669
# Unit test for function identity
def test_identity():
    assert identity("1") == "1"
    assert identity("test") == "test"
    assert identity(1) == 1
    assert identity([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-24 00:48:52.216474
# Unit test for function cond
def test_cond():
    def func1(arg):
        return arg + 1

    def func2(arg):
        return arg + 2

    def func3(arg):
        return arg + 3

    def func4(arg):
        return arg + 4

    def func5(arg):
        return arg + 5

    def func6(arg):
        return arg + 6

    def func7(arg):
        return arg + 7

    func8 = cond([
        (lambda arg: arg < 3, func1),
        (lambda arg: arg < 4, func2),
        (lambda arg: arg < 5, func3),
        (lambda arg: arg < 6, func4),
        (lambda arg: arg < 7, func5),
        (lambda arg: arg < 8, func6),
        (lambda arg: arg < 9, func7),
    ])



# Generated at 2022-06-24 00:48:54.477348
# Unit test for function pipe
def test_pipe():
    assert pipe([1, 2, 3], curried_map(increase), curried_filter(lambda item: item % 2 == 0)) == [2, 4]


# Generated at 2022-06-24 00:49:01.310049
# Unit test for function memoize
def test_memoize():
    def factorial(n):
        def recur(n, acc):
            if n == 0:
                return acc
            return recur(n - 1, n * acc)
        return recur(n, 1)

    factorial_memoized = memoize(factorial)
    assert factorial_memoized(5) == factorial(5)



# Generated at 2022-06-24 00:49:06.922046
# Unit test for function curried_filter
def test_curried_filter():
    curried_filter2 = curried_filter(lambda x: x % 2 == 0)
    assert curried_filter2([1, 2, 3]) == [2]


# Generated at 2022-06-24 00:49:12.621602
# Unit test for function compose
def test_compose():
    def add(value, value1):
        return value + value1

    def sub(value):
        return value - 5

    assert compose(5, add, sub)(5) == 5
    assert compose(5, lambda x: x + 5, lambda x: x - 5)(5) == 5



# Generated at 2022-06-24 00:49:13.701576
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-24 00:49:19.360527
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map()([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-24 00:49:20.339184
# Unit test for function memoize
def test_memoize():
    assert memoize(identity)("asd") == memoize(identity)("asd")



# Generated at 2022-06-24 00:49:26.030141
# Unit test for function curry
def test_curry():
    multiply = curry(lambda x, y: x * y)
    assert multiply(1, 2) == 2
    assert multiply(1)(2) == 2
    assert multiply(2)(3) == 6
    assert multiply(2, 3) == 6


# Generated at 2022-06-24 00:49:29.548206
# Unit test for function curried_map
def test_curried_map():
    """
    This function is used as unit test.
    :return: true if curried_map is normal
    :rtype: bool
    """
    testList = [1, 2, 3]
    dryList = curried_map(increase, testList)
    assert testList != dryList, 'Curried map must make new list'

    for index in range(len(dryList)):
        assert dryList[index] == testList[index] + 1, \
            'Curried map must increase every element in list'

    return True


# Generated at 2022-06-24 00:49:33.333080
# Unit test for function pipe
def test_pipe():
    """Unit test for function pipe"""
    print("Function pipe:")
    print(pipe(1, identity, increase, increase))
    print(pipe(1, increase, increase, identity))


# Generated at 2022-06-24 00:49:34.989612
# Unit test for function compose
def test_compose():
    assert compose(2, increase, increase) == 4



# Generated at 2022-06-24 00:49:36.322457
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x ** 2)([1, 2, 3]) == [1, 4, 9]


# Generated at 2022-06-24 00:49:39.017277
# Unit test for function cond
def test_cond():
    assert cond([(lambda *args: True, lambda *args: True)])(1)



# Generated at 2022-06-24 00:49:46.247135
# Unit test for function memoize
def test_memoize():
    test_list = [1, 2, 3, 4, 5]
    def test_fn(argument):
        index = test_list.index(argument)
        return test_list[index]**2

    memoized_fn = memoize(test_fn)
    assert memoized_fn(1) == 1
    assert memoized_fn(2) == 4
    assert memoized_fn(3) == 9
    assert memoized_fn(2) == 4
    assert memoized_fn(1) == 1
    assert memoized_fn(2) == 4
    assert memoized_fn(3) == 9


# Generated at 2022-06-24 00:49:48.863750
# Unit test for function pipe
def test_pipe():
    initial_value = 5
    increment_by_one = lambda x: x + 1

    result = pipe(initial_value, increment_by_one)
    assert initial_value + 1 == result



# Generated at 2022-06-24 00:49:50.776110
# Unit test for function memoize
def test_memoize():
    def f(x):
        return x


# Generated at 2022-06-24 00:49:52.931625
# Unit test for function curry
def test_curry():
    assert (curry(lambda x, y: x + y))(2)(2) == 4



# Generated at 2022-06-24 00:50:03.241302
# Unit test for function memoize
def test_memoize():
    from timeit import timeit
    from time import sleep
    from random import randrange

    # Создание функции для проверки мемоизации
    def random(a):
        sleep(2)
        return randrange(100)

    # Мемоизация
    random_cached = memoize(random)

    # Вызов мемоизированной функции первый раз
    random_cached(1)
    # Второй раз, долже

# Generated at 2022-06-24 00:50:05.551851
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_filter(lambda x: x < 2)([1, 2, 3]) == [1]

# Generated at 2022-06-24 00:50:06.457564
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-24 00:50:14.458155
# Unit test for function curried_filter
def test_curried_filter():
    """Test curried_filter function"""
    assert curried_filter(lambda x: x < 3)([1, 2, 3, 4, 5, 6, 1, 3, 8]) == [1, 2, 1]
    curried_filter_less_4 = curried_filter(lambda x: x < 4)
    assert curried_filter_less_4([1, 2, 3, 4, 5, 6, 1, 3, 8]) == [1, 2, 3, 1, 3]



# Generated at 2022-06-24 00:50:18.915146
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: -x, [1, 2, 3]) == [-1, -2, -3]


# Generated at 2022-06-24 00:50:24.875609
# Unit test for function curried_map
def test_curried_map():
    list_ = [1, 2, 3, 4]
    result1 = curried_map(increase)(list_)
    result2 = curried_map(increase, list_)
    result3 = curried_map(increase, list_[:])
    result4 = curried_map(increase, list_[1:])
    assert result1 == [2, 3, 4, 5]
    assert result2 == [2, 3, 4, 5]
    assert result3 == [2, 3, 4, 5]
    assert result4 == [3, 4, 5]



# Generated at 2022-06-24 00:50:35.009113
# Unit test for function curry
def test_curry():
    def fn(*args):
        return sum(args)

    assert fn(1, 2, 3) == curry(fn, 3)(1, 2, 3)
    assert curry(fn, 3)(1, 2, 3) == curry(fn, 3)(1, 2)(3)
    assert curry(fn, 3)(1, 2)(3) == curry(fn, 3)(1)(2, 3)
    assert curry(fn, 3)(1)(2, 3) == curry(fn, 3)(1)(2)(3)
    assert curry(fn, 3)(1)(2)(3) == curry(fn, 3)()(1)(2)(3)
    assert curry(fn, 3)()(1)(2)(3) == curry(fn, 3)()()(1)(2)(3)


# Generated at 2022-06-24 00:50:38.531878
# Unit test for function curry
def test_curry():
    add2 = curry(lambda a, b: a + b)
    assert add2(1)(1) == 2
    assert add2(4)(5) == 9
    assert add2(1, 1) == 2
    assert add2(4, 5) == 9



# Generated at 2022-06-24 00:50:43.034632
# Unit test for function identity
def test_identity():
    assert identity(0) == 0
    assert identity('qwerty') == 'qwerty'
    assert identity(True) is True


# Generated at 2022-06-24 00:50:45.591536
# Unit test for function compose
def test_compose():
    fn = compose(increase, identity, increase)
    assert fn(1) == 3


test_compose()



# Generated at 2022-06-24 00:50:51.389200
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]
    assert curried_map(lambda x: x * 2, [1, 2, 3, 4, 5]) == [2, 4, 6, 8, 10]
    assert curried_map(lambda x: x + 1, []) == []


# Generated at 2022-06-24 00:50:53.019297
# Unit test for function pipe
def test_pipe():
    assert pipe(2, increase, increase) == 4



# Generated at 2022-06-24 00:50:54.475881
# Unit test for function identity
def test_identity():
    value = 'test_value'
    assert identity(value) == value



# Generated at 2022-06-24 00:50:59.287599
# Unit test for function find
def test_find():
    assert find([0, 1, 2, 3], lambda number: number == 1) == 1
    assert find([0, 1, 2, 3], lambda number: number == 4) is None



# Generated at 2022-06-24 00:51:04.089029
# Unit test for function pipe
def test_pipe():
    test_value = 5
    composition = pipe(
        test_value,
        increase,
        increase
    )
    assert composition == test_value + 2



# Generated at 2022-06-24 00:51:05.220537
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-24 00:51:07.112272
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(2) == 2
    assert identity(1) != 2


# Generated at 2022-06-24 00:51:11.667595
# Unit test for function pipe
def test_pipe():
    def add(value1, value2):
        return value1 + value2

    def increase(value):
        return value + 1

    add_increase = pipe(2, add, increase)
    assert add_increase(5) == 8, "Pipe failed"



# Generated at 2022-06-24 00:51:15.234570
# Unit test for function curried_map
def test_curried_map():
    """
    :returns: result of curried_map function
    :rtype: boolean
    """
    return curried_map(identity, [1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-24 00:51:16.424237
# Unit test for function pipe
def test_pipe():
    assert pipe(2, increase, increase, increase, increase) == 6

# Generated at 2022-06-24 00:51:17.928240
# Unit test for function pipe
def test_pipe():
    assert pipe(2, increase) == 3



# Generated at 2022-06-24 00:51:19.331795
# Unit test for function eq
def test_eq():
    assert True == eq(2)(2)
    assert False == eq(2)(3)



# Generated at 2022-06-24 00:51:28.799624
# Unit test for function pipe
def test_pipe():
    # The simplest test case
    assert pipe(1, increase) == 2

    # Return increase and decrease of argument
    assert pipe(1, increase, increase, increase, increase) == 5

    # Return increas of argument
    assert pipe(
        [1, 2, 3, 4, 5],
        curried_map(increase),
        curried_filter(lambda x: x % 2 == 0)
    ) == [2, 4, 6]

    # Return True if argument is two
    fn = cond([
        (lambda x: x == 0, lambda: False),
        (lambda x: x == 1, lambda: True),
        (lambda x: x == 2, lambda: True),
        (lambda x: x == 3, lambda: False)
    ])

# Generated at 2022-06-24 00:51:33.051506
# Unit test for function eq

# Generated at 2022-06-24 00:51:38.747841
# Unit test for function curried_filter
def test_curried_filter():
    """
    Test curried_filter function.
    """
    assert curried_filter(eq(2))([1, 2, 3]) == [2]
    assert curried_filter(eq(3))([1, 2, 3]) == [3]
    assert curried_filter(eq(4))([1, 2, 3]) == []
    assert curried_filter(eq(1))([1, 2, 3]) == [1]


# Generated at 2022-06-24 00:51:40.261846
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([0, 1, 2]) == [1, 2, 3]



# Generated at 2022-06-24 00:51:43.632886
# Unit test for function find
def test_find():
    assert find([-6, -4, -1, 0, 2, 3, 4], lambda x: x > 0) == 2
    assert find(["python", "java", "js"], lambda x: x == "ruby") is None
    assert find([], lambda x: x == "ruby") is None



# Generated at 2022-06-24 00:51:45.443445
# Unit test for function identity
def test_identity():
    assert identity(42) == 42
    assert identity('identity') == 'identity'



# Generated at 2022-06-24 00:51:54.751287
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda: 1)() == 1
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6



# Generated at 2022-06-24 00:51:58.156885
# Unit test for function compose
def test_compose():
    assert compose(
        'value',
        lambda x: x + '_1',
        lambda x: x + '_2',
        lambda y: y + '_3',
    ) == 'value_1_2_3'



# Generated at 2022-06-24 00:52:01.486586
# Unit test for function eq
def test_eq():
    assert eq() is True
    assert eq(1)(1) is True
    assert eq(1)(2) is False
    assert eq(1, 1) is True
    assert eq(1, 2) is False



# Generated at 2022-06-24 00:52:03.263952
# Unit test for function compose
def test_compose():
    assert(
        compose(
            3,
            increase,
            increase
        ) == 5
    )



# Generated at 2022-06-24 00:52:04.317797
# Unit test for function curried_map
def test_curried_map():
    print (curried_map(lambda x: x + 2)([1, 2, 3]))


# Generated at 2022-06-24 00:52:08.519392
# Unit test for function pipe
def test_pipe():
    assert pipe(1, increase, identity) == 2

# Generated at 2022-06-24 00:52:11.136983
# Unit test for function compose
def test_compose():
    f = lambda x: x * x
    g = lambda x: x + x
    h = lambda x: x - x

    assert compose(1, f)(10) == 100
    assert compose(1, f, g)(10) == 200
    assert compose(1, f, g, h)(10) == 100



# Generated at 2022-06-24 00:52:15.398193
# Unit test for function curried_filter
def test_curried_filter():
    f = curried_filter(lambda x: x < 4)

    assert [1, 2, 3] == f([1, 2, 3, 4])
    assert [1, 2, 3] == f([1, 2, 3])
    assert [] == f([4, 5, 6])


# Generated at 2022-06-24 00:52:18.078649
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity([]) == []
    assert identity('') == ''
    assert identity({}) == {}



# Generated at 2022-06-24 00:52:28.019103
# Unit test for function compose
def test_compose():
    compose_inc_and_id = compose(identity, increase)
    assert 1 == compose_inc_and_id(0)
    compose_id_and_inc = compose(increase, identity)
    assert 2 == compose_id_and_inc(2)
    compose_inc_inc_and_id = compose(identity, increase, increase)
    assert 2 == compose_inc_inc_and_id(0)
    compose_inc_inc_and_inc = compose(increase, increase, increase)
    assert 3 == compose_inc_inc_and_inc(0)
    assert 3 == compose(1, lambda a: a + 3, lambda b: b - 1)



# Generated at 2022-06-24 00:52:32.011212
# Unit test for function compose
def test_compose():
    def multiply(a, b):
        return a * b

    div_by_2 = lambda a: a / 2
    sum_by_3 = lambda a: a + 3

    composable = compose(1, sum_by_3, div_by_2, multiply(2, 3))
    assert composable == 9


# Generated at 2022-06-24 00:52:34.342089
# Unit test for function increase
def test_increase():
    assert 1 == increase(0)
    assert 2 == increase(1)



# Generated at 2022-06-24 00:52:39.424918
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(identity)([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert curried_filter(eq(1))([1, 2, 3, 4, 5]) == [1]
    assert curried_filter(eq(1), [1, 2, 3, 4, 5]) == [1]
    assert curried_filter(eq(1))([1, 2, 3, 4, 5]) == [1]
    assert curried_filter(increase)([1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]
    assert curried_filter(eq(0))([1, 2, 3, 4, 5]) == []
    assert curried_filter(eq(6))([1, 2, 3, 4, 5]) == []


# Generated at 2022-06-24 00:52:42.971916
# Unit test for function curry
def test_curry():
    @curry
    def add(x, y):
        return x + y

    assert callable(add)
    assert isinstance(add(1), curry)
    assert add(1)(2) == 3
    assert add(1, 2) == 3



# Generated at 2022-06-24 00:52:46.456078
# Unit test for function curried_filter
def test_curried_filter():
    """
    Unit test for function curried_filter
    """
    xs = [0, 1, 2, 3, 4, 5]
    assert curried_filter(eq(1))(xs) == [1]
    assert curried_filter(lambda x: x >= 2)(xs) == [2, 3, 4, 5]



# Generated at 2022-06-24 00:52:49.968379
# Unit test for function memoize
def test_memoize():
    add = lambda x: lambda y: x + y
    assert memoize(add(2))(3) == add(2)(3)


# Generated at 2022-06-24 00:52:53.648558
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(2), [1, 2, 3]) == [2]


# Generated at 2022-06-24 00:52:55.813256
# Unit test for function eq
def test_eq():
    assert eq(1, 2) == False
    assert eq(1, 2) == False
    assert eq(1, 1) == True
    assert eq(0, 0) == True


# Generated at 2022-06-24 00:53:05.644866
# Unit test for function cond
def test_cond():
    def test_function(argument):
        if argument > 10:
            return "more than 10"
        else:
            return "less than or 10"

    condition = cond([
        (lambda x: x > 10, lambda x: "more than 10"),
        (lambda x: x > 0, lambda x: "more than 0"),
        (lambda x: x > -10, lambda x: "less than or 10"),
    ])

    assert condition(11) == test_function(11) == "more than 10"
    assert condition(10) == test_function(10) == "less than or 10"
    assert condition(-11) == test_function(-11) == None



# Generated at 2022-06-24 00:53:12.239255
# Unit test for function cond
def test_cond():
    is_true = lambda x: x == 1
    is_false = lambda x: x == 0

    assert cond([
        (is_true, lambda x: x + 1),
        (is_false, lambda x: x + 0),
    ])(0) == 0

    assert cond([
        (is_true, lambda x: x + 0),
        (is_false, lambda x: x + 1),
    ])(0) == 1



# Generated at 2022-06-24 00:53:14.709069
# Unit test for function curry
def test_curry():
    def inc(a, b):
        return a + b
    inc = curry(inc)
    assert inc(1)(2) == 3
    assert inc(2)(2) == 4



# Generated at 2022-06-24 00:53:18.647585
# Unit test for function compose
def test_compose():
    times_2 = lambda x: 2 * x
    plus_4 = lambda x: x + 4
    three = 3
    assert compose(three, times_2, plus_4) == 10



# Generated at 2022-06-24 00:53:24.118363
# Unit test for function cond
def test_cond():
    """
    Test function cond
    """
    def test_function(value):
        return cond([
            (lambda x: x % 2 == 0, lambda x: x),
            (lambda x: x % 2 != 0, lambda x: x + 1),
        ])(value)

    assert test_function(1) == 2
    assert test_function(2) == 2



# Generated at 2022-06-24 00:53:33.971843
# Unit test for function curry
def test_curry():
    assert compose(2, compose(identity, identity), identity)() == 2
    assert compose(2, compose(identity, lambda x: x + 1), identity)() == 3
    assert compose(2, compose(identity, curry(lambda x, y: x + y)), increase)() == 4
    assert pipe(2, pipe(identity, identity), identity)() == 2
    assert pipe(2, pipe(identity, lambda x: x + 1), identity)() == 3
    assert pipe(2, pipe(identity, curry(lambda x, y: x + y)), increase)() == 4
    assert cond([(eq(0), increase), (eq(1), identity), (eq(2),  identity), (eq(3), increase)])() == 1

# Generated at 2022-06-24 00:53:35.222052
# Unit test for function curried_filter
def test_curried_filter():
    curried_filter(lambda x: x > 2, [1, 2, 3, 4])

# Generated at 2022-06-24 00:53:40.041005
# Unit test for function curried_map
def test_curried_map():
    square = lambda x: x * x
    assert curried_map(square, [1, 2, 3]) == [1, 4, 9]
    assert curried_map(square)([1, 2, 3]) == [1, 4, 9]
    square_array = curried_map(square)
    assert square_array([1, 2, 3]) == [1, 4, 9]



# Generated at 2022-06-24 00:53:42.121314
# Unit test for function compose
def test_compose():
    assert compose(1, increase, identity)(1) == 2
    assert compose(2, str)(1) == "1"



# Generated at 2022-06-24 00:53:49.126109
# Unit test for function pipe
def test_pipe():
    flag = False
    executed = []

    def f1(): executed.append("f1")

    def f2(): executed.append("f2")

    def f3(): executed.append("f3")

    def flag_setter_1(): flag = True

    def flag_setter_2(): flag = False

    def flag_getter():
        return flag

    def flag_getter_1():
        return flag_getter() == True

    def flag_getter_2():
        return flag_getter() == False

    def check_list(list_to_check):
        for i in range(0, len(list_to_check)):
            if list_to_check[i] != executed[i]:
                return False

        return True


# Generated at 2022-06-24 00:53:51.185135
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([], lambda x: x == 3) is None



# Generated at 2022-06-24 00:53:59.906442
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq(1)(1) == True
    assert eq(1)(2) == False
    assert eq(1)(1)(1) == True
    assert eq(1)(1)(2) == False
    assert eq(1)(2)(1) == False
    assert eq(1)(2)(2) == False
    assert eq(1, 1, 1) == True
    assert eq(1, 1, 2) == False
    assert eq(1, 2, 1) == False
    assert eq(1, 2, 2) == False


# Generated at 2022-06-24 00:54:03.246565
# Unit test for function identity
def test_identity():
    assert identity(True) is True
    assert identity(None) is None

# Generated at 2022-06-24 00:54:06.014315
# Unit test for function compose
def test_compose():
    assert eq(3, compose(1, increase, increase))
    assert eq('123',
              compose(1, id, str, lambda x: x + '2', lambda x: x + '3'))



# Generated at 2022-06-24 00:54:07.040680
# Unit test for function identity
def test_identity():
    assert identity(10) == 10



# Generated at 2022-06-24 00:54:12.068456
# Unit test for function cond
def test_cond():
    cubed = lambda x: x ** 3
    squared = lambda x: x ** 2

    true = lambda _: True
    is_even = lambda val: val % 2 == 0

    f = cond([
        (is_even, cubed),
        (true, squared)
    ])
    assert f(3) == 9
    assert f(4) == 64
    assert f(5) == 25
    assert f(6) == 216

