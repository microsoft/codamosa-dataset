

# Generated at 2022-06-26 00:18:27.040487
# Unit test for function curried_filter
def test_curried_filter():
    # Test case for function curried_filter
    # Return collection of even numbers
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5]) == [2, 4]

    # Add test case
    ...



# Generated at 2022-06-26 00:18:27.856300
# Unit test for function eq
def test_eq():
    assert eq(1, 1)



# Generated at 2022-06-26 00:18:30.158062
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(IncrementFilter(increase=3), [0, 1, 2, 3, 4, 5]) == [0, 1, 2, 4, 5]



# Generated at 2022-06-26 00:18:32.101193
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda item: item > 2, [1, 2, 3]) == [3], "curried_filter failed"



# Generated at 2022-06-26 00:18:37.601638
# Unit test for function eq
def test_eq():
    assert eq(0, 0) is True
    assert eq(1, 1) is True
    assert eq(0, 5) is False
    assert eq(1, 2) is False

    assert eq(0)(0) is True
    assert eq(1)(1) is True
    assert eq(0)(5) is False
    assert eq(1)(2) is False
    assert eq(1, 3)(2) is False



# Generated at 2022-06-26 00:18:39.807420
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x ** 2 == 4, [0, 1, 2, 3, 4]) == [2]



# Generated at 2022-06-26 00:18:42.648686
# Unit test for function memoize
def test_memoize():
    value = memoize(identity, eq)
    assert value(1) == identity(1)
    value(1)
    value(2)
    value(3)
    print(value(1))

# Generated at 2022-06-26 00:18:55.281452
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, y=2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(y=2, z=3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, y=2, z=3) == 6

# Generated at 2022-06-26 00:19:04.519362
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(curried_map(increase))([[1, 2, 3]]) == [[2, 3, 4]]



# Generated at 2022-06-26 00:19:07.802131
# Unit test for function memoize
def test_memoize():
    def fn(argument: int) -> int:
        print("exec")
        return argument + 1

    mfn = memoize(fn)
    mfn(1)
    assert([(1, 2), ] == mfn.cache)


test_memoize()

# Generated at 2022-06-26 00:19:19.842605
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x < 10, lambda x: x * 10),
        (lambda x: x > 10, lambda x: x / 10)
    ])(3) == 30
    assert cond([
        (lambda x: x < 10, lambda x: x * 10),
        (lambda x: x > 10, lambda x: x / 10)
    ])(12) == 1.2


# Unit tests for function compose

# Generated at 2022-06-26 00:19:26.075934
# Unit test for function memoize
def test_memoize():
    def non_memoized_function(argument):
        non_memoized_function.times += 1
        return argument

    non_memoized_function.times = 0

    memoized_function = memoize(non_memoized_function)

    assert memoized_function(10) == 10
    assert memoized_function(10) == 10
    assert memoized_function(10) == 10

    assert non_memoized_function.times == 1


test_memoize()


# Generated at 2022-06-26 00:19:29.933255
# Unit test for function eq
def test_eq():
    assert callable(eq)
    assert eq(1, 1)
    assert not eq("1", 1)
    assert eq("a", "a")
    assert not eq("a", "b")
    assert not eq(1, 2)
    assert not eq(1, "2")



# Generated at 2022-06-26 00:19:41.066736
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x % 2 == 1) == 1
    assert find([1, 2, 3, 4, 5], lambda x: x % 2 == 2) == 2
    assert find([1, 2, 3, 4, 5], lambda x: x % 2 == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda x: x % 2 == 4) == 4
    assert find([1, 2, 3, 4, 5], lambda x: x % 2 == 5) == 5
    assert find([1, 2, 3, 4, 5], lambda x: x % 2 == 6) is None



# Generated at 2022-06-26 00:19:48.659698
# Unit test for function cond
def test_cond():
    condition_list = [(lambda x: x < 0, identity), (lambda x: x > 0, increase)]
    f = cond(condition_list)
    assert f(-1) == -1
    assert f(0) == 0
    assert f(1) == 2
    condition_list = [(lambda x: len(x) == 3, identity), (lambda x: len(x) == 2, increase)]
    g = cond(condition_list)
    assert g('abc') == 'abc'
    assert g('ab') == 3
    assert g('abcd') == 'abcd'



# Generated at 2022-06-26 00:19:58.617838
# Unit test for function curried_map
def test_curried_map():
    var_0 = curried_map(identity, [1, 2, 3])
    assert(curried_map(identity, [1, 2, 3]) == [1, 2, 3])
    var_1 = curried_map(increase, [1, 2, 3])
    assert(var_1 == [2, 3, 4])
    var_3 = compose(var_1, curried_map(increase))
    assert(var_3 == [3, 4, 5])
    var_4 = cond(
        [
            (eq(increase), increase),
            (eq(identity), identity)
        ]
    )
    assert(var_4(increase) == increase)

# Generated at 2022-06-26 00:20:08.341387
# Unit test for function memoize
def test_memoize():
    test_0: str = memoize(lambda i: i + 1)(1)
    print(test_0)

    def test_1(a, b):
        if a == b:
            return True
        else:
            return False

    test_0_1: bool = test_1(1, 1)
    test_0_2: bool = test_1(1, 2)
    print(test_0_1)
    print(test_0_2)

    def test_2(x):
        print(x)

    def fn(x: int) -> int:
        return 2 * x

    var_0: int = fn(1)
    var_1: int = fn(1)
    print(var_0)
    print(var_1)
    return



# Generated at 2022-06-26 00:20:09.840609
# Unit test for function curried_map
def test_curried_map():
    def map_func(item):
        return item + 2

    assert curried_map(map_func)([1, 2, 3, 4]) == [3, 4, 5, 6]



# Generated at 2022-06-26 00:20:14.092812
# Unit test for function memoize
def test_memoize():

    @memoize
    def work_hard(number):
        if number == 1:
            return 1
        return number * work_hard(number - 1)

    assert work_hard(5) == 120
    assert work_hard(1) == 1
    assert work_hard(5) == 120
    assert work_hard(1) == 1


# Generated at 2022-06-26 00:20:16.603615
# Unit test for function curry
def test_curry():
    @curry
    def add(a, b):
        return a + b

    assert add(1)(2) == 3
    assert add(1, 2) == 3



# Generated at 2022-06-26 00:20:23.577324
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: 2 == x) == 2
    assert find([1, 2, 3], lambda x: 4 == x) is None



# Generated at 2022-06-26 00:20:28.552468
# Unit test for function curry
def test_curry():
    """
    :returns: True if all tests passed
    :rtype: Boolean
    """
    return all([
        curry(increase, 2)(1) == 2,
        curry(increase, 2)(2) == 3,
        curry(increase, 2)(1)(1) == 2,
        curry(identity)(1) == 1
    ])



# Generated at 2022-06-26 00:20:31.654754
# Unit test for function curried_filter
def test_curried_filter():
    function = curried_filter(lambda x: x % 2 == 0)
    collection = [1, 2, 3, 4, 5]
    assert function(collection) == [2, 4]


# Generated at 2022-06-26 00:20:36.478076
# Unit test for function curried_filter
def test_curried_filter():
    assert eq(curried_filter(eq(1), [1, 2, 3]), [1])
    assert eq(curried_filter(eq(2), [1, 2, 3]), [2])
    assert eq(curried_filter(eq(3), [1, 2, 3]), [3])
    assert eq(curried_filter(eq(4), [1, 2, 3]), [])



# Generated at 2022-06-26 00:20:43.724017
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b, c: a + b + c)(1)(2)(3) == 6
    assert curry(lambda a, b, c: a + b + c)(1, 2)(3) == 6
    assert curry(lambda a, b, c: a + b + c)(1, 2, 3) == 6



# Generated at 2022-06-26 00:20:50.501139
# Unit test for function eq
def test_eq():
    assert eq(1, 1), "eq(1, 1)"
    assert not eq(1, 2), "not eq(1, 2)"
    assert not eq(1, 2, 3, 4), "not eq(1, 2, 3, 4)"
    assert eq(2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 2), "eq(2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 2)"



# Generated at 2022-06-26 00:20:57.546124
# Unit test for function curried_map
def test_curried_map():
    test_list = [1, 2, 3]
    test_function = lambda item: item * 2
    curried = curried_map(test_function)
    assert curried(test_list) == [test_function(i) for i in test_list]



# Generated at 2022-06-26 00:21:01.051350
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3])(None) == [2, 3, 4]
    assert curried_map(identity, [1, 2, 3])(None) == [1, 2, 3]



# Generated at 2022-06-26 00:21:10.349247
# Unit test for function cond
def test_cond():
    def fn_0(x: int) -> bool:
        return x == 5

    def fn_1(x: int) -> bool:
        return x == 4

    def fn_2(x: int) -> bool:
        return x == 3

    def fn_3(x: int) -> int:
        return x + 1

    def fn_4(x: int) -> int:
        return x + 2

    def fn_5(x: int) -> int:
        return x + 3

    assert cond([
        (fn_0, fn_3),
        (fn_1, fn_4),
        (fn_2, fn_5),
    ])(5) == 6

# Generated at 2022-06-26 00:21:17.447103
# Unit test for function find
def test_find():
# Test 1
# INPUT
    find([1, 2, 3, 4], lambda x: x == 3)
# OUTPUT
    3
# Test 2
# INPUT
    find([1, 2, 3, 4], lambda x: x > 3)
# OUTPUT
    4
# Test 3
# INPUT
    find(['1','2','3','4'], lambda x: x == '3')
# OUTPUT
    '3'
# Test 4
# INPUT
    find([1, 2, 3, 4], lambda x: x > 4)
# OUTPUT
    None



# Generated at 2022-06-26 00:21:23.022132
# Unit test for function eq
def test_eq():
    assert eq(5,5) == True
    assert eq(5,'5') == False


# Generated at 2022-06-26 00:21:28.693767
# Unit test for function cond
def test_cond():
    is_even = lambda number: number % 2 == 0
    is_odd = lambda number: number % 2 != 0
    add = lambda number: number + 1
    subtract = lambda number: number - 1
    test_function = cond([
        (is_even, add),
        (is_odd, subtract)
    ])

    assert test_function(1) == 0
    assert test_function(2) == 3



# Generated at 2022-06-26 00:21:31.145668
# Unit test for function eq
def test_eq():
    assert eq(1,1)
    assert not eq(2,1)
    assert not eq(1,2)
    assert not eq(2,2)


# Generated at 2022-06-26 00:21:37.106360
# Unit test for function curry
def test_curry():
    @curry
    def abc(a, b, c):
        return (a, b, c)

    assert abc(1, 2, 3) == (1, 2, 3)
    assert abc(1, 2)(3) == (1, 2, 3)
    assert abc(1)(2, 3) == (1, 2, 3)
    assert abc(1)(2)(3) == (1, 2, 3)



# Generated at 2022-06-26 00:21:45.588926
# Unit test for function eq
def test_eq():
    assert eq(1, 2) is False, 'Failed to eq(1, 2)'
    assert eq(2, 2) is True, 'Failed to eq(2, 2)'
    assert eq(1, 1, 1) is True, 'Failed to eq(1, 1, 1)'
    assert eq(1, 1, 2) is False, 'Failed to eq(1, 1, 2)'
    assert eq(1, 2, 1) is False, 'Failed to eq(1, 2, 1)'
    assert eq(2, 1, 1) is False, 'Failed to eq(1, 1, 2)'
    print('test_eq - OK')



# Generated at 2022-06-26 00:21:54.654110
# Unit test for function cond
def test_cond():
    assert cond([(lambda x: x > 0, lambda x: "POSITIVE"),
                (lambda x: x == 0, lambda x: "ZERO"),
                (lambda x: x < 0, lambda x: "NEGATIVE")])(-5) == "NEGATIVE"
    assert cond([(lambda x: x > 0, lambda x: "POSITIVE"),
                (lambda x: x == 0, lambda x: "ZERO"),
                (lambda x: x < 0, lambda x: "NEGATIVE")])(0) == "ZERO"
    assert cond([(lambda x: x > 0, lambda x: "POSITIVE"),
                (lambda x: x == 0, lambda x: "ZERO"),
                (lambda x: x < 0, lambda x: "NEGATIVE")])(5) == "POSITIVE"




# Generated at 2022-06-26 00:22:01.297601
# Unit test for function curried_filter
def test_curried_filter():
    odd_numbers = curried_filter(lambda x: x % 2 == 1)
    odd_numbers_from_five_to_ten = odd_numbers([5, 6, 7, 8, 9, 10])

    assert odd_numbers((5, 6, 7, 8, 9, 10)) == [5, 7, 9]
    assert odd_numbers_from_five_to_ten == [5, 7, 9]
    assert curried_filter(lambda x: x % 2 == 1, (5, 6, 7, 8, 9, 10)) == [5, 7, 9]



# Generated at 2022-06-26 00:22:02.920283
# Unit test for function eq
def test_eq():
    assert not eq(1, 2)
    assert eq(1, 1)


# Generated at 2022-06-26 00:22:07.008864
# Unit test for function curry
def test_curry():
    """
    Function that test curry function.

    :param :
    :type :
    :returns: True in case of no errors
    :rtype: Boolean
    """
    # Arrange
    inc = curry(increase)

    # Act
    actual_result = inc(1)

    # Assert
    assert actual_result == 2



# Generated at 2022-06-26 00:22:12.612764
# Unit test for function cond
def test_cond():
    def fn(data):
        def odd(x):
            return x % 2 == 1
        def even(x):
            return x % 2 == 0

        def call_fn_1(x):
            return x

        def call_fn_2(x):
            return x + 1

        condition_list = [
            (odd, call_fn_1),  # Return data
            (even, call_fn_2)
        ]

        return cond(condition_list)(data)

    assert fn(1) == 1



# Generated at 2022-06-26 00:22:20.926062
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(len, ["one", "two", "three", "four", "five"]) == [3, 3, 5, 4, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]



# Generated at 2022-06-26 00:22:29.637739
# Unit test for function cond
def test_cond():
    eq_1 = cond([
        (lambda var_0: var_0 == 1, identity),
        (lambda var_0: var_0 == 2, increase),
        (lambda var_0: True, lambda var_0: f"this var is {var_0}")
    ])
    eq_2 = cond([(lambda var_0: True, lambda var_0: f"this var is {var_0}")])

    test_cases = [
        (1, 1),
        (2, 3),
        (3, "this var is 3"),
        (4, "this var is 4"),
        (5, "this var is 5")
    ]

    for (var_0, expected) in test_cases:
        assert eq_1(var_0) == expected
        assert eq_2(var_0) == expected

# Generated at 2022-06-26 00:22:41.133153
# Unit test for function curry
def test_curry():
    """
    Test for curry function.
    We can call curry with some function
    and number of expected arguments. For example curry(inc, 2)
    """
    def add(arg1, arg2, arg3): return arg1 + arg2 + arg3

    add1 = curry(add)
    assert add1(1, 2, 3) == 6
    assert add1(1, 2)(3) == 6
    assert add1(1)(2, 3) == 6
    assert add1(1)(2)(3) == 6
    assert add1(1, 2, 3) == add1(1, 2)(3)
    assert add1(1, 2, 3) == add1(1)(2, 3)
    assert add1(1, 2, 3) == add1(1)(2)(3)

# Generated at 2022-06-26 00:22:45.972347
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4, ]


# Generated at 2022-06-26 00:22:47.631037
# Unit test for function curried_filter
def test_curried_filter():
    curried_filter(lambda x: x % 2 == 0)


# Generated at 2022-06-26 00:22:49.400084
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-26 00:22:51.603667
# Unit test for function eq
def test_eq():
    assert True is eq(1, 1)
    assert True is eq(True, True)
    assert False is eq(True, False)



# Generated at 2022-06-26 00:23:02.676566
# Unit test for function cond
def test_cond():
    def expression(x):
        return x % 2 == 0

    def expression1(x):
        return x % 2 == 1

    def expression2(x):
        return x == 2

    fn = cond(
        [(expression, lambda _: "Even"),
         (expression1, lambda _: "Odd"),
         (expression2, lambda _: "Special")]
    )
    assert "Even" == fn(2)
    assert "Odd" == fn(1)
    assert "Special" == fn(2)



# Generated at 2022-06-26 00:23:08.750649
# Unit test for function find
def test_find():
    def test_case_0():
        assert find([1, 2, 3], lambda x: x == 1) == 1
        assert find([1, 2, 3], lambda x: x == 4) is None

    def test_case_1():
        assert find([1, 2, 3], lambda x: x % 2 == 0) == 2

    def test_case_2():
        assert find([1, 2, 3], lambda x: x % 2 != 0) == 1

    def test_case_3():
        assert find([1, 2, 3], lambda x: x % 2 == 1) == 1

    def test_case_4():
        assert find([1, 2, 3], lambda x: x % 2 == 0) == 2


# Generated at 2022-06-26 00:23:14.176703
# Unit test for function curried_map
def test_curried_map():
    test_list = [1, 2, 3]
    test_function = lambda value: value + 1
    assert curried_map(test_function)(test_list) == [2, 3, 4]
    assert curried_map(test_function, test_list) == [2, 3, 4]
    assert curried_map(test_function, test_list) == curried_map(test_function)(test_list)



# Generated at 2022-06-26 00:23:29.918322
# Unit test for function cond
def test_cond():
    def fn0(value):
        return value == 0

    def fn1(value):
        return value % 2 == 0
    condition_functions = [
        cond(
            [
                (fn0, lambda value: 'zero'),
                (fn1, lambda value: 'even'),
            ]
        ),
        lambda value: 'odd',
    ]
    assert condition_functions[0](0) == 'zero', 'only 0 equals zero'
    assert condition_functions[0](1) == 'odd', '1 is an odd number'
    assert condition_functions[0](2) == 'even', '2 is an even number'
    assert condition_functions[1](3) == 'odd', '3 is an odd number'



# Generated at 2022-06-26 00:23:31.429024
# Unit test for function eq
def test_eq():
    assert eq('a', 'a') == True
    assert eq('a', 'b') == False



# Generated at 2022-06-26 00:23:32.819021
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-26 00:23:37.409581
# Unit test for function cond
def test_cond():
    fn_0 = lambda argument: argument % 2 == 0
    fn_1 = lambda argument: argument + 2
    fn_2 = lambda argument: argument + 5

    fn_3 = cond([
        (
            fn_0, fn_1,
        ),
        (
            identity, fn_2,
        ),
    ])
    assert fn_3(2) == 4
    assert fn_3(3) == 8



# Generated at 2022-06-26 00:23:43.630480
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find(
        [{'field1': 'field1_value_1'}, {'field1': 'field1_value_2'}],
        lambda x: x['field1'] == 'field1_value_2'
    ) == {'field1': 'field1_value_2'}
    assert find(["a", "b"], lambda x: x == "a") == "a"



# Generated at 2022-06-26 00:23:48.193244
# Unit test for function memoize
def test_memoize():
    counter = 0

    @memoize
    def fn(argument=1):
        nonlocal counter
        counter += 1
        return counter * argument

    assert fn(1) == 1
    assert fn(1) == 1
    assert fn(2) == 4
    assert fn(1, 2) == 1
    assert fn(1) == 1
    assert fn({0: 0}) == 5



# Generated at 2022-06-26 00:23:57.675285
# Unit test for function cond
def test_cond():
    expected_0 = 20
    actual_0 = cond([
        (lambda x: x < 30, lambda x: x + 10),
        (lambda x: x < 20, lambda x: x + 100),
        (lambda x: True, lambda x: x)
    ])(10)
    assert expected_0 == actual_0

    expected_1 = 12
    actual_1 = cond([
        (lambda x: x < 30, lambda x: x + 10),
        (lambda x: x < 20, lambda x: x + 100),
        (lambda x: True, lambda x: x)
    ])(42)
    assert expected_1 == actual_1

    expected_2 = "b"

# Generated at 2022-06-26 00:23:59.573092
# Unit test for function find
def test_find():
    assert find(
        [1, 2, 3, 4, 5],
        lambda x: x == 4
    ) == 4



# Generated at 2022-06-26 00:24:00.975932
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(inc)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-26 00:24:02.346756
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert eq('a', 'a')
    assert not eq(1, 'a')


# Generated at 2022-06-26 00:24:24.677273
# Unit test for function cond
def test_cond():
    composed_fn = cond([
        (lambda a: a == 1, lambda a: "One"),
        (lambda a: a == 2, lambda a: "Two"),
        (lambda a: a == 3, lambda a: "Three"),
        (lambda a: True, lambda a: "Unknown")
    ])
    assert composed_fn(1) == "One"
    assert composed_fn(2) == "Two"
    assert composed_fn(3) == "Three"
    assert composed_fn(4) == "Unknown"
    print("Test cond passed")



# Generated at 2022-06-26 00:24:30.462485
# Unit test for function curry
def test_curry():
    def assert_curry(fn, expected_output, *input):
        actual_output = curry(fn)(*input)
        assert actual_output == expected_output, \
            f'{fn} gives {actual_output} when given {input}, but expected {expected_output}'


    assert_curry(lambda x: x * 2, 10, 5)
    assert_curry(lambda x, y: x * y, 10, 5, 2)
    assert_curry(lambda x, y, z: x * y * z, 10, 5, 2, 1)



# Generated at 2022-06-26 00:24:33.115696
# Unit test for function curried_filter
def test_curried_filter():
    assert eq(
        curried_filter(lambda x: x < 5)([1, 2, 3, 4, 5, 6, 7]),
        [1, 2, 3, 4]
    ), 'Test curried_filter'



# Generated at 2022-06-26 00:24:39.686227
# Unit test for function cond
def test_cond():
    assert (cond([(eq(1), identity), (eq(2), increase), (eq(3), lambda x: x * 2)])(1) == 1)
    assert (cond([(eq(1), identity), (eq(2), increase), (eq(3), lambda x: x * 2)])(2) == 3)
    assert (cond([(eq(1), identity), (eq(2), increase), (eq(3), lambda x: x * 2)])(3) == 6)
    assert (cond([(eq(1), identity), (eq(2), increase), (eq(3), lambda x: x * 2)])(4) is None)


# Generated at 2022-06-26 00:24:45.723466
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b, c: a + b + c)(1)(2)(3) == 6
    assert curry(lambda a, b, c: a + b + c)(1, 2)(3) == 6
    assert curry(lambda a, b, c: a + b + c)(1, 2, 3) == 6
    assert curry(lambda a, b, c: a + b + c, 1)(1) == 1
    assert curry(lambda a, b, c: a + b + c, 2)(1, 2) == 3
    assert curry(lambda a, b, c: a + b + c, 2)(1)(2) == 3



# Generated at 2022-06-26 00:24:49.415547
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x < 3)([1, 2, 3, 4]) == [1, 2]
    assert curried_filter(lambda x: x % 2)([1, 2, 3, 4]) == [1, 3]
    assert curried_filter(lambda x: x > 5)([1, 2, 3, 4]) == []



# Generated at 2022-06-26 00:24:50.964566
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 1, [1, 2, 3]) == [2, 3]


# Generated at 2022-06-26 00:24:56.198237
# Unit test for function find
def test_find():
    def eq(value1, value2):
        return value1 == value2
    assert find([1, 2, 3], eq(1)) == 1, "find([1, 2, 3], eq(1)) != 1"
    assert find([1, 2, 3], eq(4)) is None, "find([1, 2, 3], eq(4)) is not None"
    assert find([], eq(4)) is None, "find([], eq(4)) is not None"



# Generated at 2022-06-26 00:24:59.959734
# Unit test for function memoize
def test_memoize():
    var_0 = memoize(fn)()
    var_1 = var_0[0]
    var_2 = var_0[1]
    var_3 = var_1[1]
    var_4 = var_2[1]

    assert var_3[0] == var_4[0] and var_3[1] == var_4[1]


# Generated at 2022-06-26 00:25:02.537604
# Unit test for function find
def test_find():
    assert(find([0, 1, 2, 3, 4, 5], lambda item: item % 2 == 0)) == 0
    assert(find([1, 3, 5, 7, 9], lambda item: item % 2 == 0)) is None

# Generated at 2022-06-26 00:25:42.147198
# Unit test for function cond
def test_cond():
    """
    Test function cond

    :returns: True if test is passed
    :rtype: Boolean
    """
    condition_list = [
        (lambda x: x % 2 == 0, lambda x: x + 1),
        (lambda x: x % 2 == 1, lambda x: x - 1),
    ]

    assert(cond(condition_list)(1) == 0)
    assert(cond(condition_list)(2) == 3)

    return True


# Generated at 2022-06-26 00:25:51.983986
# Unit test for function cond
def test_cond():
    is_string = lambda argument: isinstance(argument, str)
    is_int = lambda argument: isinstance(argument, int)
    is_number = lambda argument: isinstance(argument, (int, float))

    sum = lambda a, b: a + b
    div = lambda a, b: a / b

    functions_list = [
        (is_string, lambda argument: '{}{}'.format('string', argument)),
        (is_number, sum),
        (is_int, div),
    ]

    cond_function = cond(functions_list)
    assert cond_function(1, 2) == 0.5
    assert cond_function('1', '2') == 'string12'



# Generated at 2022-06-26 00:25:54.855361
# Unit test for function curry
def test_curry():
    def add(x, y):
        return x + y

    assert curry(add)(1)(2) == 3
    assert curry(add, 2)(1)(2) == 3
    assert curry(add, 2)(1, 2) == 3



# Generated at 2022-06-26 00:25:58.795061
# Unit test for function eq
def test_eq():
    assert eq(10, 10) == True
    assert eq(10, 11) == False
    assert eq((10, 10), (10, 10)) == True
    assert eq((10, 10), (10, 11)) == False
    assert eq("10", "10") == True
    assert eq("10", "11") == False
    assert eq({10}, {10}) == True
    assert eq({10}, {11}) == False


# Generated at 2022-06-26 00:26:01.940370
# Unit test for function memoize
def test_memoize():
    def test_fn(argument):
        return argument + ' ' + 'called'

    test_memoized_fn = memoize(test_fn)

    assert test_memoized_fn('first') == 'first called'
    assert test_memoized_fn('first') == 'first called'



# Generated at 2022-06-26 00:26:05.335961
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]


# unit test for function curried_filter

# Generated at 2022-06-26 00:26:07.519791
# Unit test for function find
def test_find():
    test_set = [0, 1, 2, 'a', 'b', 'c']
    assert find(test_set, eq(1)) == 1
    assert find(test_set, eq(4)) is None



# Generated at 2022-06-26 00:26:13.527070
# Unit test for function curried_filter
def test_curried_filter():
    test_array = [1, 2, 3, 4, 5, 6, 7, 8]

    # test for filter even
    assert curried_filter(lambda x: x % 2 == 0, test_array) == [2, 4, 6, 8]
    assert curried_filter(lambda x: x < 3, test_array) == [1, 2]
    assert curried_filter(lambda x: x > 0, test_array) == [1, 2, 3, 4, 5, 6, 7, 8]



# Generated at 2022-06-26 00:26:16.200695
# Unit test for function memoize
def test_memoize():
    fn = memoize(lambda x: x + 1)

    assert fn(1) == 2
    assert fn(1) == 2
    assert fn(2) == 3
    assert fn(1) == 2
    assert fn(2) == 3



# Generated at 2022-06-26 00:26:18.352145
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda item: item == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda item: item == 6) is None



# Generated at 2022-06-26 00:27:50.826733
# Unit test for function curry
def test_curry():
    @curry
    def func_0(argument_0, argument_1, argument_2):
        return (argument_0, argument_1, argument_2)

    result = func_0(1)(2)(3)
    assert result == (1, 2, 3), "Curry not working: curry(func_0)(1)(2)(3) = " + str(result)

    result = func_0(1)(2, 3)
    assert result == (1, 2, 3), "Curry not working: curry(func_0)(1)(2, 3) = " + str(result)

    result = func_0(1, 2)(3)
    assert result == (1, 2, 3), "Curry not working: curry(func_0)(1, 2)(3) = " + str(result)

    result = func_0

# Generated at 2022-06-26 00:27:52.582380
# Unit test for function memoize
def test_memoize():
    # assertion for variable var_0
    assert var_0 == "test"
    # assertion for variable var_1
    assert var_1 == "test"

# Generated at 2022-06-26 00:27:59.226262
# Unit test for function curry
def test_curry():
    @curry
    def fn_1(a, b, c):
        return [a, b, c]

    result = fn_1(1)(2)(3)
    assert result == [1, 2, 3]

    @curry
    def fn_2(a, b, c, d):
        return [a, b, c, d]

    res_fn_2 = fn_2(1)(2)(3)
    assert res_fn_2(4) == [1, 2, 3, 4]



# Generated at 2022-06-26 00:28:06.943797
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b, c: a + b + c)(1, 2, 3) == 6
    assert curry(lambda a, b, c: a + b + c)(1)(2)(3) == 6
    assert curry(lambda a, b, c: a + b + c)(1)(2, 3) == 6
    assert curry(lambda a, b, c: a + b + c)(1, 2)(3) == 6



# Generated at 2022-06-26 00:28:16.254503
# Unit test for function cond
def test_cond():
    # Assert if cond_function return truly cond_function don`t call execute_function
    assert cond([
        (lambda x: x < 0, lambda x: x),
        (lambda x: 0 <= x < 3, lambda x: x)
    ])(2) == 2
    # Assert if cond_function return false cond_function don`t call execute_function
    assert cond([
        (lambda x: x < 0, lambda x: x),
        (lambda x: 3 <= x, lambda x: x)
    ])(2) is None
    assert cond([
        (lambda x: 0 < x < 3, lambda x: x),
        (lambda x: x < 0 or x > 3, lambda x: x)
    ])(2) == 2

# Generated at 2022-06-26 00:28:18.389781
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq(1, 2, 3) == False
    assert eq(1, 2, 3, 3) == False

