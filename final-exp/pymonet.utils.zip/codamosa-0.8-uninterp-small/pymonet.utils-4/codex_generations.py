

# Generated at 2022-06-26 00:18:28.463312
# Unit test for function eq
def test_eq():
    """
    Test for function eq

    :param:
    :type:
    :returns:
    :rtype:
    """
    assert eq(2, 3) == False
    assert eq(3, 3) == True


# Generated at 2022-06-26 00:18:32.183717
# Unit test for function cond
def test_cond():
    def f_0(value):
        return True

    def f_1(value):
        return False

    assert cond([(f_0, identity), (f_1, increase)])(0) == 0
    assert cond([(f_1, identity), (f_0, increase)])(0) == 1



# Generated at 2022-06-26 00:18:40.439346
# Unit test for function find
def test_find():
    collection = [1, 2, 3, 4]

    fn = find(collection, lambda element: element == 3)
    assert fn == 3, 'Find for Ints test 0 FAILED'

    collection = ['1', '2', '3', '4']

    fn = find(collection, lambda element: element == '3')
    assert fn == '3', 'Find for Strings test 1 FAILED'

    collection = [1, 2, [3, 4], 5]

    fn = find(collection, lambda element: element[0] == 3)
    assert fn == [3, 4], 'Find for List test 2 FAILED'
    print('Find test FINISHED')



# Generated at 2022-06-26 00:18:51.992436
# Unit test for function memoize
def test_memoize():
    f = lambda x: x * 2
    g = memoize(f)
    var_0 = f(3)
    var_1 = g(3)
    var_2 = f(3)
    var_3 = g(3)
    var_4 = f(4)
    var_5 = g(4)
    var_6 = f(4)
    var_7 = g(4)

    assert var_0 == 6
    assert var_1 == 6
    assert var_2 == 6
    assert var_3 == 6
    assert var_4 == 8
    assert var_5 == 8
    assert var_6 == 8
    assert var_7 == 8


# Generated at 2022-06-26 00:19:01.655841
# Unit test for function memoize
def test_memoize():
    """
    Test function memoize with different function
    """
    test_list = []
    test_fn = lambda x: x+1
    test_condition = lambda x, y: x == y
    test_var = memoize(test_fn, test_condition)
    test_list.append(test_var(1))
    test_list.append(test_var(1))
    assert test_list == [2, 2]


# Generated at 2022-06-26 00:19:03.769597
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5, 6], lambda item: item % 2 == 0) == 2
    assert find([1, 3, 5], lambda item: item % 2 == 0) is None



# Generated at 2022-06-26 00:19:09.084447
# Unit test for function curry
def test_curry():
    add_two_numbers = curry(lambda a, b: a + b)
    add_three_numbers = curry(lambda a, b, c: a + b + c)

    assert add_two_numbers(5, 6) == 11
    assert add_three_numbers(1, 2, 3) == 6
    assert add_two_numbers(1)(1) == 2
    assert add_three_numbers(4)(3)(2) == 9



# Generated at 2022-06-26 00:19:11.003294
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-26 00:19:14.535925
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(2, 3) is False
    assert eq('test', 'test') is True
    assert eq({'a': 1}, {'a': 1}) is True



# Generated at 2022-06-26 00:19:23.362012
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True, 'eq(1, 1) == True'
    assert eq(1, '1') == False, 'eq(1, "1") == False'
    assert eq(1, eq(1, 1)) == True, 'eq(1, eq(1, 1)) == True'
    assert eq(1, eq(1, eq(1, '1'))) == False, 'eq(1, eq(1, eq(1, "1"))) == False'


# Generated at 2022-06-26 00:19:32.367163
# Unit test for function eq
def test_eq():
    assert True == eq(1, 1)
    assert False == eq(1, 2)
    assert True == eq('qwerty', 'qwerty')
    assert False == eq('qwerty', 'asdfg')
    assert True == eq({1, 2, 3}, {1, 2, 3})
    assert True == eq({'qwerty', 'asdfg'}, {'asdfg', 'qwerty'})
    assert False == eq({'qwerty', 'asdfg'}, {'asdfg', 'qwerty', 'zxcvb'})



# Generated at 2022-06-26 00:19:34.654409
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x * 2, [1, 2, 3])([1, 2, 3]) == [1, 4, 9]



# Generated at 2022-06-26 00:19:40.644171
# Unit test for function curried_filter
def test_curried_filter():
    assert [4, 6] == curried_filter(lambda l: l % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10])



# Generated at 2022-06-26 00:19:43.671710
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x % 2 == 0) == 2
    assert find([1, 3, 5], lambda x: x % 2 == 0) is None



# Generated at 2022-06-26 00:19:53.568637
# Unit test for function curried_filter
def test_curried_filter():
    print("Unit test for function curried_filter")

    test_array = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

    test_0 = curried_filter(lambda x: x % 2 == 0)(test_array)
    assert test_0 == [2, 4, 6, 8, 10]

    test_1 = curried_filter(lambda x: x % 2 == 0)(test_array) == [2, 4, 6, 8, 10]
    test_2 = curried_filter(lambda x: x % 3 == 0)(test_array) == [3, 6, 9]
    test_3 = curried_filter(lambda x: x % 4 == 0)(test_array) == [4, 8]

# Generated at 2022-06-26 00:19:56.955605
# Unit test for function cond
def test_cond():
    var_1 = cond([(lambda value: value >= 5, increase), (lambda value: value < 5, identity)])
    assert var_1(5) == 6
    assert var_1(4) == 4



# Generated at 2022-06-26 00:19:59.672852
# Unit test for function find
def test_find():
    collection = [1, 2, 3, 4, 5]
    assert find(collection, lambda x: x == 3) == 3
    assert find(collection, lambda x: x == 0) is None



# Generated at 2022-06-26 00:20:09.225343
# Unit test for function cond
def test_cond():
    def eq1(arg1, arg2):
        return arg1 == arg1
    def eq2(arg1, arg2):
        return arg2 == arg2

    assert cond([(eq(1, 1), identity), (eq(1, 2), identity)])(1) == 1
    assert cond([(eq(1, 2), identity), (eq(1, 1), identity)])(1) == 1
    assert cond([(eq1(1, 1), identity), (eq2(1, 2), identity)])(1) == 1
    assert cond([(eq1(1, 2), identity), (eq2(1, 1), identity)])(1) == 1
    assert cond([(eq1(1, 1), identity), (eq2(1, 2), increase)])(1) == 1

# Generated at 2022-06-26 00:20:11.731582
# Unit test for function curried_map
def test_curried_map():
    # Setup
    items = [1, 2, 3, 4, 5]
    mapper = lambda item: item + 2

    expected = [3, 4, 5, 6, 7]
    assert curried_map(mapper, items) == expected

    assert compose(items, curried_map(mapper)) == expected

    assert pipe(items, curried_map(mapper)) == expected



# Generated at 2022-06-26 00:20:14.904220
# Unit test for function eq
def test_eq():
    assert eq(True, True) == True
    assert eq(1, 2) == False
    assert eq(2, 2) == True
    assert eq('1', '2') == False
    assert eq('adad', 'adad') == True



# Generated at 2022-06-26 00:20:28.727204
# Unit test for function memoize
def test_memoize():
    from functools import partial
    from datetime import datetime, timedelta

    def wait_1_sec(argument):
        time_to_sleep = datetime.now() + timedelta(seconds=1)
        while time_to_sleep > datetime.now():
            pass
        return argument
    cache_function = memoize(wait_1_sec)

    started_at = datetime.now()
    result = cache_function('hello')
    time_delta = datetime.now() - started_at
    assert result == 'hello'
    assert time_delta.seconds == 1

    started_at = datetime.now()
    result = cache_function('hello')
    time_delta = datetime.now() - started_at
    assert result == 'hello'
    assert time_delta.microseconds < 1000

# Generated at 2022-06-26 00:20:31.741515
# Unit test for function find
def test_find():
    assert find([], lambda item: False) is None
    assert find([1, 2], lambda item: False) is None
    assert find([1, 2], lambda item: True) == 1



# Generated at 2022-06-26 00:20:34.532677
# Unit test for function eq
def test_eq():
    assert(eq(1, 1) == True)
    assert(eq(1, 2) == False)
    assert(eq(1, 2, 3, 4) == False)


# Generated at 2022-06-26 00:20:46.111935
# Unit test for function memoize
def test_memoize():
    assert memoize(lambda x: x + 1)(1) == 2
    assert memoize(lambda x: x + 1)(1) == 2
    assert memoize(lambda x: x + 1)(1) == 2
    assert memoize(lambda x: x + 1)(2) == 3
    assert memoize(lambda x: x + 1, lambda a, b: a + b)(2) == 3
    assert memoize(lambda x: x + 1, lambda a, b: a + b)(2) == 3
    assert memoize(lambda x: x + 1, lambda a, b: a == b)(2) == 3
    assert memoize(lambda x: x + 1, lambda a, b: a == b)(2) == 3



# Generated at 2022-06-26 00:20:51.312590
# Unit test for function find
def test_find():
    arg_0 = [1,2, 3, 5]
    arg_1 = lambda element: element > 4
    assert find(arg_0, arg_1) == 5
    arg_0 = [1,2, 3, 5]
    arg_1 = lambda element: element == 4
    assert find(arg_0, arg_1) is None
    print('Test find is ok')



# Generated at 2022-06-26 00:20:58.958340
# Unit test for function cond
def test_cond():
    is_even = lambda x: x % 2 == 0
    is_odd = lambda x: not is_even(x)
    is_positive = lambda x: x > 0
    is_zero = lambda x: x == 0
    is_negative = lambda x: not is_positive(x)
    add_one = lambda x: x + 1
    minus_one = lambda x: x - 1
    return_zero = lambda: 0

    f = cond([
        (is_even, add_one),
        (is_odd, minus_one),
        (is_zero, return_zero),
        (is_positive, identity),
        (is_negative, return_zero),
    ])
    assert f(10) == 11
    assert f(9) == 8
    assert f(0) == 0

# Generated at 2022-06-26 00:21:01.902485
# Unit test for function eq
def test_eq():
    assert eq(2)(2) is True
    assert eq('abc')('abc') is True
    assert eq(0)('abc') is False
    assert eq(1)(0) is False
    assert eq(None)(None) is True


# Generated at 2022-06-26 00:21:04.641340
# Unit test for function memoize
def test_memoize():
    assert memoize(lambda x: x + 1)(1) == 2
    assert memoize(lambda x: x + 1)(2) == 3
    assert memoize(lambda x: x + 1)(1) == 2


# Generated at 2022-06-26 00:21:09.374847
# Unit test for function find
def test_find():
    list_0 = [1, 2, 3]
    var_0 = find(list_0, lambda x: x == 1)
    var_1 = 1
    var_2 = find(list_0, lambda x: x == 2)
    var_3 = 2
    var_4 = find(list_0, lambda x: x == 4)
    var_5 = None



# Generated at 2022-06-26 00:21:14.046618
# Unit test for function curried_map
def test_curried_map():
    print('\n#1 Test curried_map:')
    my_items_list = [1, 2, 3, 4, 5]
    mapped_list = curried_map(increase, my_items_list)
    assert mapped_list == [2, 3, 4, 5, 6]
    print('Test case 1 complete.')



# Generated at 2022-06-26 00:21:21.422804
# Unit test for function find
def test_find():
    assert find([0, 1, 2, 3, 4, 5], lambda x: x == 4) == 4
    assert find([0, 1, 2, 3, 4, 5], lambda x: x == 12) is None



# Generated at 2022-06-26 00:21:22.904010
# Unit test for function cond
def test_cond():
    f = cond(
        [(eq(2), increase),
         (eq(1), identity)])



# Generated at 2022-06-26 00:21:30.604305
# Unit test for function cond
def test_cond():
    def fn_0(arg_0):
        return arg_0 > 0

    def fn_1(arg_0):
        return increase(arg_0)

    def fn_2(arg_0):
        return decrease(arg_0)

    def fn_3(arg_0):
        return identity(arg_0)

    fn_4 = cond([(fn_0, fn_1), (fn_0, fn_2), (fn_0, fn_3)])
    fn_4()

    fn_4(1.0)

    fn_4(dec(0))



# Generated at 2022-06-26 00:21:37.200500
# Unit test for function memoize
def test_memoize():
    def fn1(value):
        def inner(value1):
            return value1 + value
        return inner
    fn2 = memoize(fn1)
    assert fn2(2)(2) == (fn2(2)(2))
    assert fn2(2)(2) == 4

    def fn3(value):
        def inner(value1):
            return value1 + value
        return inner
    fn4 = memoize(fn3)
    assert not (fn4(2)(2) == (fn4(3)(3)))



# Generated at 2022-06-26 00:21:41.931236
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [1, 2]) == [1, 2], 'first item passed identity function'
    assert curried_map(increase, [1, 2]) == [2, 3], 'second item pass increase function'
    assert curried_map(increase)([1, 2]) == [2, 3], 'pass function from curried_map without all args'



# Generated at 2022-06-26 00:21:47.844100
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(5) == 6
    assert curry(lambda x, y: x + y, 3)(1, 5, 10) == 16
    assert curry(lambda x, y, z, t: x + y + z + t, 4)(1, 5, 10, 15) == 31
    assert curry(lambda x, y, z, t: x + y + z + t)(1)(5)(10)(15) == 31


# Generated at 2022-06-26 00:21:50.712719
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert eq("Hello", "Hello")
    assert eq("Hello", "hello")
    assert eq([1, 2, 3], [1, 2, 3])
    assert not eq("Hello", "World")


# Generated at 2022-06-26 00:21:54.775210
# Unit test for function curry
def test_curry():
    f = curry(lambda x, y: x + y)

    assert f(3)(4) == 7
    assert f(3, 4) == 7
    assert f(x=3)(y=4) == 7
    assert f(x=3, y=4) == 7



# Generated at 2022-06-26 00:21:58.838244
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda a: a > 2)([1, 2, 3, 4, 5, 6]) == [3, 4, 5, 6]
    assert curried_filter(lambda a: a > 1, [1, 2, 3, 4, 5, 6]) == [2, 3, 4, 5, 6]



# Generated at 2022-06-26 00:22:04.101374
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x+y)(3, 4) == 7
    assert curry(lambda x, y: x*y)(1, 2, 3) == 6
    assert curry(lambda x, y, z=1: x*y*z)(3, 4, 5) == 60
    assert curry(lambda x, y: x**y)(2, 3) == 8
    assert curry(lambda x, y: x**y, 3)(2) == 8



# Generated at 2022-06-26 00:22:15.609040
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], eq(1)) == 1
    assert find([1, 2, 3, 4], eq(5)) == None


# Generated at 2022-06-26 00:22:21.241481
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(lambda x: x * x)([1, 2, 3]) == [1, 4, 9]
    assert curried_map(lambda x: x * x, [1, 2, 3]) == [1, 4, 9]
    assert curried_map(lambda x: x * x)([1]) == [1]
    assert curried_map(lambda x: x * x)([]) == []



# Generated at 2022-06-26 00:22:25.134408
# Unit test for function curry
def test_curry():
    def add(x, y, z):
        return x + y + z

    assert curry(add)(1, 2, 3) == 6
    assert curry(add)(1)(2)(3) == 6
    assert curry(add, 3)(1, 2, 3) == 6



# Generated at 2022-06-26 00:22:29.955412
# Unit test for function cond
def test_cond():
    """
    >>> cond(
    ...     [
    ...         (eq(1), lambda x: x + 1),
    ...         (eq(2), lambda x: x - 1)
    ...     ]
    ... )(2)
    1
    >>> cond(
    ...     [
    ...         (eq(1), lambda x: x + 1),
    ...         (eq(2), lambda x: x - 1)
    ...     ]
    ... )(1)
    2
    """



# Generated at 2022-06-26 00:22:35.077971
# Unit test for function curried_map
def test_curried_map():
    expected = [2, 3, 4]
    actual = curried_map(increase, [1, 2, 3])
    assert actual == expected



# Generated at 2022-06-26 00:22:38.316211
# Unit test for function curried_map
def test_curried_map():
    # pipe
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]

    # compose
    assert compose([1, 2, 3], curried_map(increase)) == [2, 3, 4]



# Generated at 2022-06-26 00:22:44.633856
# Unit test for function memoize
def test_memoize():
    var_1 = 0
    def fn():
        nonlocal var_1
        var_1 += 1
        return var_1
    assert (1 == fn())
    assert (2 == fn())
    memoized_fn = memoize(fn)
    assert (3 == memoized_fn(123))
    assert (3 == memoized_fn(123))
    assert (4 == memoized_fn(321))
    assert (4 == memoized_fn(321))
    assert (4 == memoized_fn(123))


# Generated at 2022-06-26 00:22:55.066374
# Unit test for function curried_map
def test_curried_map():
    assert [1, 2, 3] == [1, 2, 3, 4, 5] | curried_map(lambda x: x)
    assert [2, 3, 4] == [1, 2, 3, 4, 5] | curried_map(lambda x: x + 1)
    assert [0, 1, 2] == [1, 2, 3, 4, 5] | curried_map(lambda x: x - 1)
    assert [1] == [1] | curried_map(lambda x: x)
    assert [] == [] | curried_map(lambda x: x)
    assert [2, 4, 6] == [1, 2, 3] | curried_map(lambda x: x * 2)


# Generated at 2022-06-26 00:22:57.073579
# Unit test for function find
def test_find():
    collection1 = [1, 2, 3, 4]
    key1 = lambda x: x > 2
    assert find(collection1, key1) == 3
    assert find([], key1) is None



# Generated at 2022-06-26 00:23:00.344687
# Unit test for function curried_map
def test_curried_map():
    var_0 = curried_map(identity, [1])
    assert var_0 == [1]

    var_1 = curried_map(identity)([1])
    assert var_1 == [1]


# Generated at 2022-06-26 00:23:18.080549
# Unit test for function eq
def test_eq():
    assert not eq(10)(20), \
        'eq_test_1'
    assert eq(10)(10), \
        'eq_test_2'
    assert not eq(10)('10'), \
        'eq_test_3'
    assert eq('10')('10'), \
        'eq_test_4'
    assert not eq('10')(10), \
        'eq_test_5'
    assert not eq(10)(20, 1), \
        'eq_test_6'
    assert eq(10, 10)(), \
        'eq_test_7'
    assert not eq(10, 20)(), \
        'eq_test_8'
    assert not eq(10, '10')(), \
        'eq_test_9'

# Generated at 2022-06-26 00:23:25.796707
# Unit test for function memoize
def test_memoize():
    # create function with some logic
    def heavy_logic(argument: bool) -> bool:
        if argument:
            return True
        return False

    # create memoize version of this function
    memoized_heavy_logic = memoize(heavy_logic)

    # call memoized_heavy_logic twice with true and false arguments
    # look at console log, and you will see that heavy_logic function called only for first time
    print("memoize_test 1:")
    memoized_heavy_logic(True)
    memoized_heavy_logic(False)

    # now call memoized_heavy_logic with same arguments
    # again look at console log, and you will see that memoized_heavy_logic decide that it already have cache
    # for this argument, and have no need to run heavy_logic function

# Generated at 2022-06-26 00:23:27.294203
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False


# Generated at 2022-06-26 00:23:32.931955
# Unit test for function cond
def test_cond():
    cond_func = cond([
        (lambda x: x > 10, lambda x: '> 10'),
        (lambda x: x > 0, lambda x: '> 0'),
        (lambda x: x == 0, lambda x: '0'),
        (lambda x: x < 0, lambda x: '< 0'),
    ])

    assert cond_func(5) == '> 0'
    assert cond_func(15) == '> 10'
    assert cond_func(0) == '0'
    assert cond_func(-2) == '< 0'



# Generated at 2022-06-26 00:23:39.224283
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2)([1, 2, 3, 4]) == [1, 3]
    assert curried_filter(lambda x: x.startswith('a'))(['a', 'b', 'ab', 'ac', 'd']) == ['a', 'ab', 'ac']
    assert curried_filter(lambda x: x[0] == x[-1])(['a', 'ab', 'cc', 'ca', 'caa']) == ['ab', 'cc', 'ca', 'caa']


# Generated at 2022-06-26 00:23:42.239329
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda item: item == 2) == 2
    assert find([1, 2, 3, 4], lambda item: item == 'test') is None
    assert find([1, 2, 3, 4], lambda item: False) is None



# Generated at 2022-06-26 00:23:48.664960
# Unit test for function cond
def test_cond():
    # Create condition functors
    def even(x):
        return x % 2 == 0

    def lt5(x):
        return x < 5

    # Create execute functors
    def halve(x):
        return x / 2

    def inc(x):
        return x + 1

    # Create functional composition
    functional_case = cond([(even, halve), (lt5, inc)])

    # Test
    assert functional_case(4) == 2
    assert functional_case(3) == 4
    assert functional_case(9) == 4.5



# Generated at 2022-06-26 00:23:58.057024
# Unit test for function cond
def test_cond():
    assert cond([(lambda x: x < 0, lambda x: "less than 0"),
                (lambda x: x > 0, lambda x: "greater than 0"),
                (lambda x: x == 0, lambda x: "equal to 0")])(-1) == "less than 0"
    assert cond([(lambda x: x < 0, lambda x: "less than 0"),
                (lambda x: x > 0, lambda x: "greater than 0"),
                (lambda x: x == 0, lambda x: "equal to 0")])(0) == "equal to 0"

# Generated at 2022-06-26 00:24:05.231400
# Unit test for function cond
def test_cond():
    @memoize
    def fibonacci(n):
        if n < 3:
            return 1
        return fibonacci(n - 1) + fibonacci(n - 2)

    def cond_test(*args):
        fibonacci_condition = cond(
            [(eq(0), identity),
             (eq(1), identity),
             (eq(2), identity),
             (eq(3), identity),
             (eq(4), identity),
             (eq(5), identity)]
        )
        return fibonacci_condition(*args)

    assert fibonacci(0) == 1
    assert fibonacci(1) == 1
    assert fibonacci(2) == 1
    assert fibonacci(3) == 2
    assert fibonacci(4) == 3
    assert fibonacci(5) == 5



# Generated at 2022-06-26 00:24:09.450105
# Unit test for function find
def test_find():
    var_0 = find([1,2,3,4], lambda x: x == 2)
    assert var_0 == 2
    var_1 = find([1,2,3,4], lambda x: x == 5)
    assert var_1 is None


# Generated at 2022-06-26 00:24:30.670533
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2, [1, 2, 3]) == [3]
    assert curried_filter(lambda x: x > 3, [1, 2, 3]) == []
    assert curried_filter(eq(2), [1, 2, 3]) == [2]
    assert curried_filter(eq(4), [1, 2, 3]) == []



# Generated at 2022-06-26 00:24:35.797967
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, list(range(1, 10))) == list(range(1, 10))
    assert curried_map(increase, list(range(1, 10))) == list(range(2, 11))
    assert curried_map(compose(str, lambda x: x + 1), list(range(1, 10))) == [
        '2', '3', '4', '5', '6', '7', '8', '9', '10'
    ]



# Generated at 2022-06-26 00:24:43.913724
# Unit test for function curry
def test_curry():
    # Test 1: fn(a) -> a + 1
    fn = lambda a: a + 1
    assert curry(fn)(1) == 2

    # Test 2: fn(a, b) -> a + b
    fn = lambda a, b: a + b
    assert curry(fn)(1)(2) == 3

    # Test 3: fn(a, b, c) -> a + b + c
    fn = lambda a, b, c: a + b + c
    assert curry(fn)(1)(2)(3) == 6

    # Test 4: fn(a, b, c, d) -> a + b + c + d
    fn = lambda a, b, c, d: a + b + c + d
    assert curry(fn)(1)(2)(3)(4) == 10

    # Test 5: fn(a, b)

# Generated at 2022-06-26 00:24:45.207472
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [2, 3, 4]) == [3, 4, 5]



# Generated at 2022-06-26 00:24:53.041004
# Unit test for function eq
def test_eq():
    assert eq(3, 3) is True
    assert eq(5, 5) is True
    assert eq(7, 7) is True
    assert eq(9, 9) is True

    assert eq(2, 2)

    assert not eq(2, 3)
    assert not eq(4, 5)
    assert not eq(6, 7)
    assert not eq(8, 9)

    # Curried
    assert eq(1)(1)
    assert eq(2)(2) is True
    assert eq(3)(3) is True
    assert eq(4)(4) is True

    assert not eq(1)(2)
    assert not eq(2)(3) is True
    assert not eq(3)(4) is True
    assert not eq(4)(5) is True



# Generated at 2022-06-26 00:24:56.631457
# Unit test for function curried_filter
def test_curried_filter():
    var_0 = curried_filter([2, 3, 4, 5], lambda arg_0: arg_0 % 2 == 0)
    assert var_0 == [2, 4]
    var_1 = curried_filter([2, 3, 4, 5], lambda arg_0: arg_0 % 2 == 1)
    assert var_1 == [3, 5]


# Generated at 2022-06-26 00:25:03.642404
# Unit test for function curried_filter
def test_curried_filter():
    test_cases = [
        {
            "test": curried_filter(lambda x: x % 2 == 0, [1, 2, 3]),
            "expected": [2],
            "name": "simple_case_0"
        },
        {
            "test": curried_filter(lambda x: x == 1, [1, 2, 3]),
            "expected": [1],
            "name": "simple_case_1"
        }
    ]
    [print("Test case %s: %s" % ((i + 1), test_case["name"])) for i, test_case in enumerate(test_cases)]
    for test_case in test_cases:
        assert test_case["test"] == test_case["expected"]



# Generated at 2022-06-26 00:25:15.215241
# Unit test for function cond
def test_cond():
    test_list = [(1, 2), (3, 4)]
    assert cond([
        [eq(1), lambda x: x + 1],
        [eq(2), lambda x: x + 2],
    ])(1) == 2, 'First test'

    assert cond([
        [eq(2), lambda x: x + 2],
        [eq(1), lambda x: x + 1],
    ])(1) == 2, 'Second test'

    assert cond([
        [eq(1), lambda x: x + 1],
        [eq(2), lambda x: x + 2],
    ])(1) == cond([
        [eq(2), lambda x: x + 2],
        [eq(1), lambda x: x + 1],
    ])(1), 'Third test'


# Generated at 2022-06-26 00:25:18.148169
# Unit test for function curried_filter
def test_curried_filter():
    assert [1, 2, 3] == curried_filter(
        lambda item: item > 0,
        [-1, 1, -2, 2, -3, 3]
    )



# Generated at 2022-06-26 00:25:23.296998
# Unit test for function cond
def test_cond():
    neg = lambda x: x < 0
    eq = lambda x: x == 0
    pos = lambda x: x > 0
    cond_function = cond([(neg, lambda x: "-"), (eq, lambda x: "0"), (pos, lambda x: "+")])
    assert cond_function(-1) == "-"
    assert cond_function(0) == "0"
    assert cond_function(1) == "+"
    assert cond_function(2) == "+"



# Generated at 2022-06-26 00:26:02.540699
# Unit test for function eq
def test_eq():
    assert eq(1)(1) == True



# Generated at 2022-06-26 00:26:05.408261
# Unit test for function curried_map
def test_curried_map():
    assert curried_map([1, 2, 3], lambda x: x + 1) == [2, 3, 4]
    assert curried_map([1, 2, 3], lambda x: x * 2) == [2, 4, 6]



# Generated at 2022-06-26 00:26:09.744315
# Unit test for function find
def test_find():
    # Try find identity function
    assert find([identity, increase], lambda fn: fn(10) == 10) == identity
    # Try find increase function
    assert find([identity, increase], lambda fn: fn(10) == 11) == increase
    # Try find not existing function
    assert find([identity, increase], lambda fn: fn(10) == 12) == None



# Generated at 2022-06-26 00:26:14.720630
# Unit test for function eq
def test_eq():
    assert eq(1, 2) is False, "no values are equal"
    assert eq(1, 1) is True, "all values are equal"
    assert type(eq(1, 1)) == bool, "eq return a boolean value"
    assert eq(1, 2)(3) is False, "no values are equal"
    assert eq(1, 1)(2) is True, "all values are equal"
    assert type(eq(1, 1)(2)) == bool, "eq return a boolean value"



# Generated at 2022-06-26 00:26:17.749228
# Unit test for function find
def test_find():
    lst = [1, 2, 3, 4, 5, 6]
    assert find(lst, lambda x: x < 3) == 1
    assert find(lst, lambda x: x < 9) == 1
    assert find(lst, lambda x: x > 9) is None



# Generated at 2022-06-26 00:26:26.593645
# Unit test for function curried_map
def test_curried_map():
    # curried_map should return list where function was applied to all items of input list
    curried_map_0 = curried_map(lambda x: x)
    assert curried_map_0([]) == []
    # curried_map should return list where function was applied to all items of input list
    curried_map_1 = curried_map(lambda x: x)
    assert curried_map_1([]) == []
    # curried_map should return list where function was applied to all items of input list
    curried_map_2 = curried_map(lambda x: x)
    assert curried_map_2([]) == []
    # curried_map should return list where function was applied to all items of input list
    curried_map_3 = curried_map(lambda x: x)
    assert curried

# Generated at 2022-06-26 00:26:29.850028
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6



# Generated at 2022-06-26 00:26:34.292762
# Unit test for function find
def test_find():
    assert find(['k', 'a', 'v'], lambda value: value == 'a') == 'a'
    assert find(['k', 'a', 'v'], lambda value: value == 'b') is None

    find_array = ['k', 'a', 'v']
    find_key = lambda value: value == 'a'

    assert find(find_array, find_key) == 'a'
    assert find(find_array, lambda value: value == 'b') is None



# Generated at 2022-06-26 00:26:37.474178
# Unit test for function cond
def test_cond():
    def fn_1(x):
        return x == 0

    def fn_2(x):
        return x * 2 + 2

    def fn_3(x):
        return x * 3 + 3
    func = cond([(fn_1, fn_2), (fn_1, fn_3)])
    assert func(0) == fn_2(0)



# Generated at 2022-06-26 00:26:41.374601
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x)(1) == 1
    assert curried_map(lambda x: x)([1]) == [1]
    assert curried_map(lambda x: x)([1, 2]) == [1, 2]
    assert curried_map(lambda x: x)([1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-26 00:27:37.036215
# Unit test for function memoize
def test_memoize():
    assert memoize(identity)('a') == 'a'
    assert memoize(identity)('a') == 'a'
    assert memoize(identity)('a') == 'a'



# Generated at 2022-06-26 00:27:44.051841
# Unit test for function find
def test_find():
    # Test case for find
    collection = [1, 2, 3, 4, 5]
    key = eq(2)
    assert find(collection, key) == 2

    collection = ['a', 'b', 'c', 'd', 'e']
    key = eq('e')
    assert find(collection, key) == 'e'

    collection = [{'a': 1}, {'a': 2}, {'a': 3}, {'a': 4}, {'a': 5}]
    key = lambda item: item['a'] == 3
    assert find(collection, key) == {'a': 3}

    collection = [1, 2, 3, 4, 5]
    key = lambda value: value > 5
    assert find(collection, key) is None


# Generated at 2022-06-26 00:27:49.950015
# Unit test for function memoize
def test_memoize():
    # Create two distinct First-Class Functions
    # that check for a value in the list.
    # The results are the same.
    def find_first(value, list):
        for item in list:
            if value == item:
                return True
        return False

    def find_last(value, list):
        for i in range(len(list), 0, -1):
            if value == list[i]:
                return True
        return False

    assert find_first(1, [1, 2, 3]) == find_last(1, [1, 2, 3])

    # Create a memoized version of each.
    memoized_find_first = memoize(find_first)
    memoized_find_last = memoize(find_last)

    # Call the memoized function repeatedly.
    # Verify that the return value is

# Generated at 2022-06-26 00:27:54.087205
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4]) == [3, 4]
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4]) == [3, 4]
    assert curried_filter(lambda x: x > 1)([1, 2, 3, 4]) == [2, 3, 4]



# Generated at 2022-06-26 00:27:58.788411
# Unit test for function find
def test_find():
    # Test cases for function find
    assert find([1, 2, 3], lambda x: x == 3) == 3, 'test_find_case_0'
    assert find([1, 2, 3], lambda x: x == 0) is None, 'test_find_case_1'



# Generated at 2022-06-26 00:28:07.709310
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_not_even(value):
        return not is_even(value)

    def div_two(value):
        return value / 2

    def plus_one(value: int) -> int:
        return value + 1

    result_0 = cond([(is_even, div_two)])
    result_1 = cond([(is_even, div_two), (is_not_even, plus_one)])

    assert result_0(2) == 1
    assert result_1(1) == 2


# Generated at 2022-06-26 00:28:10.992177
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-26 00:28:16.559391
# Unit test for function curried_filter
def test_curried_filter():
    var_0 = curried_filter(lambda x: x < 3, [0, 1, 2, 3, 4, 5])
    var_1 = curried_filter(lambda x: x < 3)([0, 1, 2, 3, 4, 5])
    var_2 = curried_filter(lambda x: x < 3)([[0, 1, 2], [1, 2], [2], [0, 2]])

    print(var_0)
    print(var_1)
    print(var_2)



# Generated at 2022-06-26 00:28:21.661142
# Unit test for function cond
def test_cond():
    cond_is_even = cond(
        [
            (lambda x: x % 2 == 0, lambda x: x / 2),
            (lambda x: x % 2 != 0, lambda x: x * 3 + 1)
        ]
    )
    assert cond_is_even(1) == 4
    assert cond_is_even(2) == 1
    assert cond_is_even(3) == 10
    assert cond_is_even(4) == 2

