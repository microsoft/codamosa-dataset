

# Generated at 2022-06-26 00:18:34.140150
# Unit test for function curry
def test_curry():
    var_0 = curry(fn)
    var_1 = curry(fn, 1)



# Generated at 2022-06-26 00:18:41.297452
# Unit test for function curried_filter
def test_curried_filter():
    assert [1, 2, 3] == pipe(
        [1, 2, 3, 4, 5],
        curried_filter(lambda x: x > 3)
    )
    assert [1, 2, 3] == pipe(
        [1, 2, 3, 4, 5],
        curried_filter(lambda x: x > 0)
    )
    assert [1, 2, 3] == pipe(
        [1, 2, 3, 4, 5],
        curried_filter(lambda x: x % 2 == 1)
    )



# Generated at 2022-06-26 00:18:42.888388
# Unit test for function eq
def test_eq():
    assert eq(3, 3) == True
    assert eq(1, 2) == False


# Generated at 2022-06-26 00:18:44.824768
# Unit test for function find
def test_find():
    assert find([1, 2], eq(1)) == 1
    assert find([1, 2], eq(3)) is None


# Generated at 2022-06-26 00:18:52.218606
# Unit test for function memoize
def test_memoize():
    def fn():
        print("hi")
        return fn

    memoized_fn = memoize(fn)
    assert fn() is fn()
    assert memoized_fn() is memoized_fn()
    assert fn() is not memoized_fn()


# Generated at 2022-06-26 00:18:55.824878
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False



# Generated at 2022-06-26 00:19:07.347907
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda value: value == 0, lambda value: 'Zero'),
        (lambda value: value % 2 == 0, lambda value: 'Even'),
        (lambda value: value % 2 != 0, lambda value: 'Odd'),
    ])(2) == 'Even'

    assert cond([
        (lambda value: value < 0, lambda value: 'Less then zero'),
        (lambda value: value < 10, lambda value: 'Less then ten'),
        (lambda value: value < 100, lambda value: 'Less then hundred'),
    ])(5) == 'Less then ten'


# Generated at 2022-06-26 00:19:10.048230
# Unit test for function find
def test_find():
    assert find(
        list(range(10)),
        lambda x: x == 5
    ) == 5

    assert find(
        list(range(10)),
        lambda x: x == 15
    ) is None



# Generated at 2022-06-26 00:19:18.697323
# Unit test for function eq
def test_eq():
    assert eq(3)(3) == True
    assert eq(3)(4) == False
    assert eq(3, 3) == True
    assert eq(3, 4) == False
    assert eq(3)(4) == False
    assert eq(3, 4) == False
    assert eq(3, 4) == False
    assert eq(3, 4) == False
    assert eq(3, 4) == False
    assert eq(3, 4) == False



# Generated at 2022-06-26 00:19:24.895946
# Unit test for function curried_filter
def test_curried_filter():
    # 1. Test for curried_filter
    assert curried_filter(lambda item: item <= 5)([1, 2, 3, 4, 5, 6]) == [1, 2, 3, 4, 5]
    # 2. Test for return None
    assert curried_filter(lambda item: item <= 5)([7, 8, 9]) is None
    # 3. Test for return None
    assert curried_filter(lambda item: item <= 5)("") is None



# Generated at 2022-06-26 00:19:30.934241
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 4) == 4
    assert find([1, 2, 3, 4], lambda x: x % 2 == 0) == 2



# Generated at 2022-06-26 00:19:34.924673
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([]) == []


# Generated at 2022-06-26 00:19:43.057049
# Unit test for function curried_map
def test_curried_map():
    # 1. Define a list of integers
    var_0 = [1, 2, 3]

    # 2. Execute the curried_map function with the list of integers and curried increase function
    var_1 = curried_map(increase)(var_0)

    # 3. The expected result is the list [2,3,4]
    assert var_1 == [2, 3, 4]



# Generated at 2022-06-26 00:19:47.183256
# Unit test for function find
def test_find():
    assert find([2, 3, 5], lambda i: i % 2 == 1) == 3
    assert find([2, 3, 5], lambda i: i % 2 == 0) == 2
    assert find([2, 3, 5], lambda i: i % 3 == 0) is None


# Generated at 2022-06-26 00:19:51.258822
# Unit test for function curried_filter
def test_curried_filter():
    lst = [1, 2, 3, 4, 5, 6]
    assert curried_filter(lambda x: x % 2 == 0, lst) == [2, 4, 6]
    assert curried_filter(lambda x: x > 3, lst) == [4, 5, 6]


# Generated at 2022-06-26 00:19:53.527401
# Unit test for function eq
def test_eq():
    assert True == eq(True, True)
    assert True != eq(True, 1)
    assert True != eq(True, False)



# Generated at 2022-06-26 00:20:03.495456
# Unit test for function eq
def test_eq():
    assert eq(True, True) == True, "eq is not work correct with boolean"
    assert eq(False, True) == False, "eq is not work correct with boolean"
    assert eq(2, 2) == True, "eq is not work correct with int"
    assert eq(2, 3) == False, "eq is not work correct with int"
    assert eq(2.0, 2.0) == True, "eq is not work correct with float"
    assert eq(2.0, 3.0) == False, "eq is not work correct with float"
    assert eq("abc", "abc") == True, "eq is not work correct with string"
    assert eq("abc", "cba") == False, "eq is not work correct with string"


# Generated at 2022-06-26 00:20:11.827773
# Unit test for function curry
def test_curry():
    """
    Unit test for function curry
    """
    assert curried_map(lambda x: x, [1, 2, 3]) == [1, 2, 3]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_filter(lambda x: x % 2, [1, 2, 3]) == [1, 3]

    assert compose(
        1,
        lambda x: x + 1,
        lambda x: x * 2,
    ) == 4
    assert compose(
        1,
        lambda x: x + 1,
        lambda x: x * 2,
    ) == pipe(
        1,
        lambda x: x + 1,
        lambda x: x * 2,
    )


# Generated at 2022-06-26 00:20:15.042034
# Unit test for function eq
def test_eq():
    assert (eq(1,1)) is True
    assert (eq(1,2)) is False
    assert (eq(1,1,1)) is True
    assert (eq(1,1,2)) is False

test_eq()

# Generated at 2022-06-26 00:20:19.966790
# Unit test for function find
def test_find():
    assert find(['1', '2', '3'], eq('1')) == '1'

    assert find(['1', '2', '3'], eq('2')) == '2'

    assert find(['1', '2', '3'], eq('3')) == '3'

    assert find(['1', '2', '3'], eq('4')) is None



# Generated at 2022-06-26 00:20:30.832687
# Unit test for function curried_filter
def test_curried_filter():
    print(curried_filter(lambda a: a > 10, range(5)))
    print(curried_filter(lambda a: a > 10)(range(5)))
    print(curried_filter(lambda a: a > 10, range(15)))
    print(curried_filter(lambda a: a > 10)(range(15)))



# Generated at 2022-06-26 00:20:33.960858
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x : x % 2 == 0)([1, 2, 3]) == [2]
    assert curried_filter(lambda x : x % 2 == 0, [1, 2, 3]) == [2]


# Generated at 2022-06-26 00:20:45.904993
# Unit test for function memoize
def test_memoize():
    fn_0 = lambda x: x
    var_0 = memoize(fn_0)
    assert callable(var_0)
    assert var_0(0) == 0
    assert var_0(0) == 0

    fn_1 = lambda x: 2 * x
    var_1 = memoize(fn_1)
    assert var_1(0) == 0
    assert var_1(1) == 2
    assert var_1(1) == 2

    fn_2 = lambda x, y: x + y
    var_2 = memoize(fn_2, lambda a, b: a == b)
    assert var_2(0, 0) == 0
    assert var_2(1, 0) == 1
    assert var_2(0, 0) == 0

# Generated at 2022-06-26 00:20:52.880416
# Unit test for function curried_filter
def test_curried_filter():
    # Test with filter
    def filter_eq_5(x):
        return x == 5

    assert curried_filter(filter_eq_5, [1, 2, 3, 4, 5]) == [5]

    # Test with filter and map
    def filter_eq_5_and_map_to_power_2(x):
        return x ** 2

    assert curried_filter(filter_eq_5, curried_map(filter_eq_5_and_map_to_power_2, [1, 2, 3, 4, 5])) == [25]



# Generated at 2022-06-26 00:20:55.058005
# Unit test for function cond
def test_cond():
    assert cond(
        [(eq(2), lambda _: 'A'),
         (eq(3), lambda _: 'B')]
    )(3) == 'B'



# Generated at 2022-06-26 00:20:59.345545
# Unit test for function cond
def test_cond():
    var_0 = cond([(lambda x : x > 0, lambda x : x + 1), (lambda x : True, lambda x : x * 2)])(0)
    var_1 = cond([(lambda x : x > 0, lambda x : x + 1), (lambda x : True, lambda x : x * 2)])(-1)
    var_2 = cond([(lambda x : x > 0, lambda x : x + 1), (lambda x : True, lambda x : x * 2)])(1)


# Generated at 2022-06-26 00:21:01.240808
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 1, [1, 2, 3]) == [2, 3]



# Generated at 2022-06-26 00:21:04.298607
# Unit test for function eq
def test_eq():
    # test if function returns True for equal arguments
    assert(eq(0, 0)) == True

    # test if function returns True for equal arguments with different order
    assert(eq(0, 0) == eq(0, 0, 0)) == True



# Generated at 2022-06-26 00:21:09.036657
# Unit test for function find
def test_find():

    assert find([], eq(1)) == None

    assert find([1], eq(1)) == 1

    assert find([2, 3], eq(3)) == 3

    assert find([2, 3], eq(1)) == None

    assert find([2, 3], lambda x: x % 2 == 0) == 2

    assert find([1, 3], lambda x: x % 2 == 0) == None



# Generated at 2022-06-26 00:21:15.177821
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq({1: 2}, {1: 2})
    assert not eq({2: 3}, {3: 2})
    assert not eq({1, 2}, {2, 1})
    assert eq([1, 2, 3], [1, 2, 3])
    assert not eq([2, 3, 4], [3, 4, 2])
    assert eq('abc', 'abc')



# Generated at 2022-06-26 00:21:26.232493
# Unit test for function curried_map
def test_curried_map():
    assert [2, 4, 6] == curried_map(increase, [1, 2, 3])
    assert [2, 4, 6] == curried_map(increase)([1, 2, 3])
    assert [2, 4, 6] == curry(curried_map)(increase)([1, 2, 3])


# Generated at 2022-06-26 00:21:28.419120
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1])([2, 3]) == [2, 3, 2]



# Generated at 2022-06-26 00:21:36.035535
# Unit test for function memoize
def test_memoize():
    sum_cache = []

    def sum(a, b, c):
        sum_cache.append((a, b, c))
        return a + b + c

    memoized_sum = memoize(sum)

    assert memoized_sum(1, 2, 3) == 6
    assert memoized_sum(1, 2, 3) == 6
    assert memoized_sum(1, 2, 3) == 6

    assert len(sum_cache) == 1

    assert memoized_sum(2, 3, 4) == 9
    assert memoized_sum(1, 4, 1) == 6

    assert len(sum_cache) == 3



# Generated at 2022-06-26 00:21:43.920233
# Unit test for function find
def test_find():

    find_test_cases = [
        (
            [1, 2, 3],
            lambda item: item % 2 == 0,
            2
        ),
        (
            [{"a": 1}, {"a": 2}],
            lambda item: item["a"] == 1,
            {"a": 1}
        ),
        (
            [("a", 1)],
            lambda item: item[1] == 1,
            ("a", 1)
        )
    ]

    for test_case in find_test_cases:
        print("test case:\n", test_case)

        assert find(*test_case[:2]) == test_case[2]



# Generated at 2022-06-26 00:21:53.709730
# Unit test for function curried_filter
def test_curried_filter():
    def always_true(arg):
        return True

    fn1 = curried_filter(always_true)

    assert fn1(range(1, 100)) == fn1(range(1, 100))
    assert fn1(range(1, 100)) is not fn1(range(1, 100))

    fn2 = curried_filter(eq)

    assert fn2(2)(range(1, 5)) == [2, 2, 2, 2]
    assert fn2(2)(range(1, 5)) is not fn2(2)(range(1, 5))

    fn3 = curried_filter(lambda x, y: x == y)

    assert fn3(2, range(1, 5)) == [2, 2, 2, 2]

# Generated at 2022-06-26 00:21:57.481668
# Unit test for function curried_map
def test_curried_map():
    assert curried_map([1, 2, 3], increase) == [2, 3, 4]
    assert curried_map({1: 1, 2: 2, 3: 3}, increase) == [2, 3, 4]
    assert curried_map('string', increase) == [115, 116, 114, 105, 110, 103]


# Generated at 2022-06-26 00:22:02.963753
# Unit test for function cond
def test_cond():
    def add_2(a):
        return a + 2

    def add_3(a):
        return a + 3

    cond_fn = cond(
        [(eq(0), add_2),
         (eq(1), add_3)],
    )
    assert cond_fn(0) == 2
    assert cond_fn(1) == 4
    with pytest.raises(UnboundLocalError):
        cond_fn(2) == 5


# Generated at 2022-06-26 00:22:06.106285
# Unit test for function cond
def test_cond():
    condition = cond([
        (eq(2), increase),
        (eq(1), identity),
        (eq(4), identity),
    ])

    assert condition(2) == 3
    assert condition(1) == 1
    assert condition(4) == 4



# Generated at 2022-06-26 00:22:10.375764
# Unit test for function curry
def test_curry():
    assert fn, "Сформувати функцію, що приймає список слів та повертає кількість слів, що починаються на 'С'."
    words = ['Соломія', 'Соняшник', 'Сінник', 'Квітка', 'Сонечко', 'Соня']
    res_0 = fn(words)

# Generated at 2022-06-26 00:22:16.121899
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 is 1, [1, 2, 3]) == [1, 3]
    assert curried_filter(lambda x: x > 2, [1, 2, 3]) == [3]
    assert curried_filter(lambda x: x == 3, [1, 2, 3]) == [3]
    assert curried_filter(lambda x: x % 2 is 0, [1, 2, 3, 4, 5]) == [2, 4]



# Generated at 2022-06-26 00:22:39.657675
# Unit test for function curried_filter
def test_curried_filter():
    """
        >>> fn_filter = curried_filter(eq(2))
        >>> fn_filter([1, 2, 3])
        [2]
        >>> fn_filter([3, 4, 5])
        []
        >>> fn_filter([2, 3, 4])
        [2]
        >>> fn_filter((1, 2, 3))
        [2]
        >>> fn_filter((3, 4, 5))
        []
        >>> fn_filter((2, 3, 4))
        [2]
        >>> fn_filter({1: 1, 2: 2, 3: 3})
        [2]
        >>> fn_filter({3: 3, 4: 4, 5: 5})
        []
        >>> fn_filter({2: 2, 3: 3, 4: 4})
        [2]
    """

# Unit

# Generated at 2022-06-26 00:22:46.076728
# Unit test for function find
def test_find():
    assert find(
        [1, 2, 3, 4, 5, 6],
        lambda x: x == 3
    ) == 3
    assert find(
        [1, 2, 3, 4, 5, 6],
        lambda x: x == 7
    ) is None



# Generated at 2022-06-26 00:22:56.197361
# Unit test for function eq
def test_eq():
    var_0 = eq()
    assert var_0 is None, \
        "TEST_0: expected %s, got %s" % (None, var_0)

    var_0 = eq(1)
    assert var_0 is not None, \
        "TEST_1: expected %s, got %s" % (not None, var_0)

    var_0 = eq(1, 1)
    assert var_0 is True, \
        "TEST_2: expected %s, got %s" % (True, var_0)

    var_0 = eq(1, 2)
    assert var_0 is False, \
        "TEST_3: expected %s, got %s" % (False, var_0)



# Generated at 2022-06-26 00:22:56.879111
# Unit test for function memoize
def test_memoize():
    assert True



# Generated at 2022-06-26 00:23:05.103659
# Unit test for function find
def test_find():
    assert find(collection=[], key=eq(value=1)) is None
    assert find(collection=[1], key=eq(value=1)) == 1
    assert find(collection=[1, 2], key=eq(value=1)) == 1
    assert find(collection=[2, 1], key=eq(value=1)) == 1
    assert find(collection=[1, 2, 1], key=eq(value=1)) == 1
    assert find(collection=[1, 2, 1], key=eq(value=2)) == 2
    assert find(collection=[1, 2, 1], key=eq(value=3)) is None



# Generated at 2022-06-26 00:23:07.425974
# Unit test for function find
def test_find():
    collection: List[int] = [1, 2, 3, 4, 5]
    result: int = find(
        collection=collection,
        key=lambda item: item * 2 == 4
    )
    assert result == 2



# Generated at 2022-06-26 00:23:13.845564
# Unit test for function memoize
def test_memoize():
    rng = np.random.RandomState(1234)
    input_list = rng.uniform(low=0.0, high=1.0, size=(50, 2))

    @memoize
    def _sum(input_list: List[float]):
        return np.sum(input_list)

    output_list = [_sum(input_list[i]) for i in range(50)]
    assert np.allclose(output_list, np.sum(input_list, axis=1))



# Generated at 2022-06-26 00:23:15.273447
# Unit test for function eq
def test_eq():
    assert False == eq(1, 2)
    assert True == eq(1, 1)



# Generated at 2022-06-26 00:23:23.112276
# Unit test for function curried_filter
def test_curried_filter():
    var_0 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    var_1 = [1, 2, 3]
    var_2 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    var_3 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    var_4 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    var_5 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    var_6 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

# Generated at 2022-06-26 00:23:24.494660
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False



# Generated at 2022-06-26 00:23:42.199010
# Unit test for function curried_filter
def test_curried_filter():
    """
    Python3 -m pytest -v --assert=plain scalar.py
    """
    assert [2, 4] == curried_filter(lambda item: item % 2 == 0)([1, 2, 3, 4])
    assert [2, 4] == curried_filter(lambda item: item % 2 == 0, [1, 2, 3, 4])
    assert [2, 4] == filter(lambda item: item % 2 == 0, [1, 2, 3, 4])



# Generated at 2022-06-26 00:23:49.746022
# Unit test for function curried_map
def test_curried_map():
    def test_case_0():
        var_0 = identity
        var_1 = curried_map(var_0)
        var_2 = (1, 2, 3)
        var_3 = var_1(var_2)
        assert var_3 == (1, 2, 3)

    def test_case_1():
        var_0 = increase
        var_1 = curried_map(var_0)
        var_2 = [1, 2, 3]
        var_3 = var_1(var_2)
        assert var_3 == [2, 3, 4]

    test_case_0()
    test_case_1()


# Generated at 2022-06-26 00:23:52.679594
# Unit test for function curried_map
def test_curried_map():
    var_0: List[Any] = []
    var_1 = curried_map(lambda var_2: var_2 + 1)(var_0)


# Generated at 2022-06-26 00:23:54.171892
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-26 00:24:02.264724
# Unit test for function memoize
def test_memoize():
    from functools import wraps
    from time import time

    def time_calc(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            before = time()
            result = func(*args, **kwargs)
            after = time()
            print("{} took {} seconds".format(func.__name__, after-before))
            return result
        return wrapper

    @memoize
    @time_calc
    def heavy_function(item):
        return reduce(
            lambda current_value, x: current_value * x,
            range(1, item+1),
            1
        )

    heavy_function(5)
    heavy_function(5)
    heavy_function(5)
    heavy_function(5)

# Generated at 2022-06-26 00:24:05.874776
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda value: value > 10, lambda value: value),
        (lambda value: True, lambda value: -value),
    ])(-10) == 10
    assert cond([
        (lambda value: value > 10, lambda value: value),
        (lambda value: True, lambda value: -value),
    ])(20) == 20


# Generated at 2022-06-26 00:24:15.435460
# Unit test for function cond
def test_cond():
    cond_function_0 = lambda var_0: var_0 == 1
    cond_function_1 = lambda var_0: var_0 == 2

    execute_function_0 = lambda var_0: var_0 + 1
    execute_function_1 = lambda var_0: var_0 + 2

    result_function = cond([
        (cond_function_0, execute_function_0),
        (cond_function_1, execute_function_1),
    ])

    def test_case_0():
        assert result_function(1) == 2
    test_case_0()

    def test_case_1():
        assert result_function(2) == 3
    test_case_1()

    def test_case_2():
        assert result_function(3) == 3
    test_case_2()



# Generated at 2022-06-26 00:24:18.087427
# Unit test for function curry
def test_curry():
    assert identity == curry(identity)
    assert identity(1) == curry(identity)(1)

    assert eq == curry(eq)
    assert eq(1, 1) == curry(eq)(1, 1)



# Generated at 2022-06-26 00:24:23.681185
# Unit test for function cond
def test_cond():
    test_case_0 = lambda value: value == 0
    test_case_1 = lambda value: value == 1
    test_case_2 = lambda value: value == 2

    fn_result = cond([
        (test_case_0, lambda: 0),
        (test_case_1, lambda: 1),
        (test_case_2, lambda: 2),
    ])

    assert fn_result(0) == 0
    assert fn_result(1) == 1
    assert fn_result(2) == 2

    assert fn_result(3) is None

# Generated at 2022-06-26 00:24:28.298275
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b: a + b)(1)(2) == 3
    assert curry(lambda a, b, c: a + b + c)(1)(2)(3) == 6

    def add(a: int, b: int, c=1) -> int:
        return a + b + c

    assert curry(add)(1)(2) == 4
    assert curry(add)(1)(2)(3) == 6



# Generated at 2022-06-26 00:24:50.413142
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False



# Generated at 2022-06-26 00:24:56.198135
# Unit test for function curried_filter
def test_curried_filter():
    is_even = lambda x: x % 2 == 0
    filtered_list = map(increase, filter(is_even, [1, 2, 3, 4]))
    assert filtered_list == [3, 5]

    filter_evens = curried_filter(is_even)
    filter_increase = curried_map(increase)
    f = compose(filter_evens, filter_increase)
    filtered_list = f([1, 2, 3, 4])
    assert filtered_list == [3, 5]



# Generated at 2022-06-26 00:24:57.857272
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(2)) == 2
    assert find([1, 3, 5], eq(4)) is None



# Generated at 2022-06-26 00:25:03.121871
# Unit test for function eq
def test_eq():
    assert eq(1, 1), "eq(1, 1) should return True"
    assert not eq(1, 2), "eq(1, 2) should return False"
    assert eq(None, None), "eq(None, None) should return True"
    assert not eq(1, None), "eq(1, None) should return False"
    assert not eq(None, 1), "eq(None, 1) should return False"
    assert not eq(eq, eq), "eq(eq, eq) should return False"


# Generated at 2022-06-26 00:25:09.482439
# Unit test for function eq
def test_eq():
    var_0 = 1
    var_1 = 1
    var_2 = eq(var_0, var_1)
    print(var_2)
    var_3 = 1
    var_4 = 2
    var_5 = eq(var_3, var_4)
    print(var_5)
    var_6 = curry(lambda x, y: x == y)(1)(1)
    print(var_6)
    var_7 = curry(lambda x, y: x == y)(1)(2)
    print(var_7)



# Generated at 2022-06-26 00:25:19.835102
# Unit test for function curried_filter
def test_curried_filter():
    first_condition, second_condition = (
        lambda x: x > 0,
        lambda x: x < 10
    )
    collection = range(-10, 10)
    filter_with_first_condition = curried_filter(first_condition)
    filter_with_second_condition = curried_filter(second_condition)

    assert filter_with_first_condition(collection) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert filter_with_second_condition(collection) == [-10, -9, -8, -7, -6, -5, -4, -3, -2, -1]



# Generated at 2022-06-26 00:25:22.676775
# Unit test for function curried_map
def test_curried_map():
    test_list = [0, 1, 2]
    assert curried_map(identity)(test_list) == test_list
    assert curried_map(increase)(test_list) == [1, 2, 3]


# Generated at 2022-06-26 00:25:28.843132
# Unit test for function curried_map
def test_curried_map():
    var_0 = ['a', 'bc', 'def']
    var_1 = curried_map(lambda x: len(x))(var_0)
    var_2 = curried_map(lambda x: x)(var_0)



# Generated at 2022-06-26 00:25:31.718668
# Unit test for function curried_map
def test_curried_map():
    """
    Checks if curried_map works right.
    """
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-26 00:25:32.513960
# Unit test for function eq
def test_eq():
    eq(1, 1)



# Generated at 2022-06-26 00:26:27.267326
# Unit test for function curried_filter
def test_curried_filter():
    var_2 = filter(eq(True), [True, False, True])
    var_3 = curried_filter(curry(eq(True)))([True, False, True])
    assert var_2 == var_3


# Generated at 2022-06-26 00:26:30.562732
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(10))([1, 10, 100, 10, 1000]) == [10, 10]
    assert curried_filter(eq(10))([])([1, 10, 100, 10, 1000]) == [10, 10]
    assert curried_filter(eq(20))([1, 10, 100, 10, 1000]) == []



# Generated at 2022-06-26 00:26:36.831359
# Unit test for function cond
def test_cond():
    test_key = compose(
        eq(None),
        lambda x: cond(
            (
                compose(eq(0), increase),
                lambda x: x + 6
            ),
            (
                compose(eq(1), increase),
                lambda x: x + 5
            ),
            (
                compose(eq(1), lambda x: x % 2),
                lambda x: x + 4
            ),
            (
                identity,
                lambda x: x + 3
            )
        )(x)
    )
    assert test_key(0)
    assert test_key(1)
    assert test_key(3)
    assert test_key(100)
    assert not test_key(2)



# Generated at 2022-06-26 00:26:39.137676
# Unit test for function find
def test_find():
    collection = [1, 2, 3, 4, 5]

    for item in collection:
        assert item == find(collection, lambda i: i == item)

    assert find(collection, lambda i: i == 10) is None



# Generated at 2022-06-26 00:26:39.953555
# Unit test for function curried_filter
def test_curried_filter():
    pass


# Generated at 2022-06-26 00:26:42.504796
# Unit test for function eq
def test_eq():
    var_0 = 10
    var_1 = 10
    assert eq(var_0, var_1) == True

    var_0 = 10
    var_1 = 20
    assert eq(var_0, var_1) == False



# Generated at 2022-06-26 00:26:45.293272
# Unit test for function curried_map
def test_curried_map():
    array_list = [1, 2, 3, 4]
    result_list = curried_map(
        increase,
        array_list
    )
    assert [2, 3, 4, 5] == result_list


# Generated at 2022-06-26 00:26:47.909827
# Unit test for function curried_map
def test_curried_map():
    var_0 = [1, 2, 3, 4, 5]
    var_1 = curried_map(increase, var_0)
    var_2 = [2, 3, 4, 5, 6]
    assert var_1 == var_2



# Generated at 2022-06-26 00:26:52.132540
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y: x + y, 2)(1, 2) == 3
    assert curry(lambda x, y, z: x + y + z, 3)(1, 2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6



# Generated at 2022-06-26 00:26:55.339741
# Unit test for function eq
def test_eq():
    assert eq(1, 2) == False, "Test 1 failed."
    assert eq(1, 1) == True, "Test 2 failed."
    assert eq(1)(1) == True, "Test 3 failed."


# Generated at 2022-06-26 00:27:52.168965
# Unit test for function curried_filter
def test_curried_filter():
    curried_filter_0 = curried_filter(lambda x: x % 2 == 0)
    curried_filter_1 = curried_filter_0([1, 2, 3, 4, 5])
    assert curried_filter_1 == [2, 4]



# Generated at 2022-06-26 00:27:53.745797
# Unit test for function find
def test_find():
    find([1, 2, 3], eq(2)) == 2
    find([1, 2, 3], eq(4)) is None



# Generated at 2022-06-26 00:28:03.627112
# Unit test for function memoize
def test_memoize():
    @memoize
    def sum_parameters(parameter):
        return parameter * 2
    assert sum_parameters(1) == 2
    assert sum_parameters(1) == 2
    assert sum_parameters(2) == 4
    assert sum_parameters(2) == 4
    assert sum_parameters(1) == 2

    @memoize
    def sum_parameters_with_eq(parameter):
        return parameter * 2
    assert sum_parameters_with_eq(2) == 4
    assert sum_parameters_with_eq(1) == 2
    assert sum_parameters_with_eq(2) == 4
    assert sum_parameters_with_eq(1) == 2


# Generated at 2022-06-26 00:28:09.754672
# Unit test for function memoize
def test_memoize():
    curried_fn = memoize(increase)
    test_value = curried_fn(5)
    assert test_value == 6
    test_value = curried_fn(5)
    assert test_value == 6
    test_value = curried_fn(7)
    assert test_value == 8
    test_value = curried_fn(7)
    assert test_value == 8
    test_value = curried_fn(5)
    assert test_value == 6



# Generated at 2022-06-26 00:28:12.578960
# Unit test for function memoize
def test_memoize():
    var_0 = None
    var_1 = identity(var_0)
    var_2 = identity(var_1)
    var_3 = identity(var_1)
    var_4 = identity(var_3)



# Generated at 2022-06-26 00:28:16.561435
# Unit test for function curry
def test_curry():
    assert callable(curry(identity))
    assert callable(curry(identity)(1))
    assert identity(1) == curry(identity)(1)
    assert increase(1) == curry(increase)(1)
    assert increase(1) != curry(increase)(2)
    assert increase(1) == curry(increase, 1)(1)



# Generated at 2022-06-26 00:28:17.853614
# Unit test for function memoize
def test_memoize():
    """
    It should be able to return a function that can return a cached value.
    """



# Generated at 2022-06-26 00:28:23.381769
# Unit test for function memoize
def test_memoize():
    var_0 = True
    var_1 = False
    var_2 = True

    var_3 = lambda var_0: var_0
    var_4 = lambda var_0: var_1

    var_5 = memoize(var_3)
    var_6 = memoize(var_3)
    var_7 = memoize(var_3)
    var_8 = memoize(var_4)
    var_9 = memoize(var_4)
    var_10 = memoize(var_4)
