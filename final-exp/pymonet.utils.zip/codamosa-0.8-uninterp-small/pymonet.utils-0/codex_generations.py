

# Generated at 2022-06-26 00:18:32.817170
# Unit test for function cond
def test_cond():
    # Test case
    var_1 = cond([(eq(0), identity), (eq(1), increase)])
    var_2 = var_1(1)

    # Asserts
    assert var_2 == 2



# Generated at 2022-06-26 00:18:34.646328
# Unit test for function eq
def test_eq():
    var_1 = eq(1, 1)
    var_2 = eq(1, 2)


# Generated at 2022-06-26 00:18:36.690019
# Unit test for function find
def test_find():
    assert find([], lambda x: x) is None
    assert find([1, 2, 3], lambda x: x) == 1



# Generated at 2022-06-26 00:18:46.010203
# Unit test for function curried_filter
def test_curried_filter():
    list_0 = list(np.linspace(0, 10, 11))
    lambda_0 = lambda var_0: eq(5, var_0)
    print(curried_filter(lambda_0, list_0))

    def lambda_1(var_0):
        return eq(5, var_0)

    print(curried_filter(lambda_1, list_0))

    def lambda_2(var_1):
        def lambda_3(var_0): return eq(var_0, var_1)
        return lambda_3

    print(curried_filter(lambda_2(5), list_0))
    print(5 == 5)

    def lambda_4(var_1):
        def lambda_5(var_0):
            return var_0 == var_1
        return lambda_5

   

# Generated at 2022-06-26 00:18:51.857534
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda i: i == 2) == 2
    assert find([1, 2, 3], lambda i: i > 3) is None



# Generated at 2022-06-26 00:18:57.356475
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda item: item % 2 == 0) == 2
    assert find([1, 2, 3, 4], lambda item: item % 5 == 0) is None


# Generated at 2022-06-26 00:19:02.886036
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 10)([1, 2, 3, 4, 15, 16, 17, 18]) == [15, 16, 17, 18]
    assert curried_filter(lambda x: x > 10, [1, 2, 3, 4, 15, 16, 17, 18]) == [15, 16, 17, 18]
    assert curried_filter(lambda x: x > 10)([1, 2, 3, 4, 15, 16, 17, 18]) == [15, 16, 17, 18]


# Generated at 2022-06-26 00:19:08.011276
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([2, 3, 4, 5]) == [3, 4, 5, 6]
    assert curried_map(increase, [2, 3, 4, 5]) == [3, 4, 5, 6]
    assert curried_map(curried_map(increase), [[1, 2], [3, 4, 5]]) == [[2, 3], [4, 5, 6]]


# Generated at 2022-06-26 00:19:09.276323
# Unit test for function eq
def test_eq():
    assert eq(1, 0) == False


# Generated at 2022-06-26 00:19:22.158668
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter([1, 2, 3, 4, 5])(eq(2)) == [2]
    assert curried_filter([1, 2, 3, 4, 5])(eq(3)) == [3]
    assert curried_filter([1, 2, 3, 4, 5])(eq(4)) == [4]
    assert curried_filter([1, 2, 3, 4, 5])(eq(5)) == [5]
    assert curried_filter([1, 2, 3, 4, 5])(eq(6)) == []
    assert curried_filter([1, 2, 3, 4, 5])(eq(1)) == [1]
    assert curried_filter([1, 2, 3, 4, 5])(eq(7)) == []

# Generated at 2022-06-26 00:19:33.304579
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x == 1, [1, 2, 3]) == [1]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3]) == [2]



# Generated at 2022-06-26 00:19:46.583448
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x > 0, lambda x: '> 0'),
        (lambda x: x == 0, lambda x: '= 0'),
        (lambda x: x < 0, lambda x: '< 0'),
    ])(5) == '> 0'

    assert cond([
        (lambda x: x > 0, lambda x: '> 0'),
        (lambda x: x == 0, lambda x: '= 0'),
        (lambda x: x < 0, lambda x: '< 0'),
    ])(0) == '= 0'


# Generated at 2022-06-26 00:19:49.664989
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False

# Generated at 2022-06-26 00:19:53.568717
# Unit test for function eq
def test_eq():
    assert eq(3)(3) == True
    assert eq(4)(4) == True
    assert eq(5)(5) == True
    assert eq(3)(4) == False
    assert eq(4)(5) == False
    assert eq(5)(3) == False



# Generated at 2022-06-26 00:20:02.499231
# Unit test for function curried_filter
def test_curried_filter():
    """
    test_curried_filter tests curried_filter function
    """
    assert curried_filter(lambda x: x > 1, [1, 2, 3]) == [2, 3]
    assert curried_filter(lambda x: x > 0, [1, 2]) == [1, 2]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4]) == [2, 4]
    assert curried_filter(lambda x: isinstance(x, int), [1, 'a', {}]) == [1]
    assert curried_filter(lambda x: isinstance(x, int), []) == []


# Generated at 2022-06-26 00:20:09.975608
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, range(10)) == [0, 2, 4, 6, 8]
    assert curried_filter(lambda x: x % 2 == 0, {}) == []
    assert curried_filter(lambda x: x % 2 == 0, []) == []
    with pytest.raises(TypeError):
        curried_filter(lambda x: x % 2 == 0, 1)
    with pytest.raises(TypeError):
        curried_filter(lambda x: x % 2 == 0, 'string')
    with pytest.raises(TypeError):
        curried_filter(lambda x: x % 2 == 0, None)


# Generated at 2022-06-26 00:20:14.533142
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(identity, [1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert curried_filter(eq(3), [1, 2, 3, 4, 5]) == [3]
    assert curried_filter(lambda x: x == 3, [1, 2, 3, 4, 5]) == [3]



# Generated at 2022-06-26 00:20:23.742202
# Unit test for function curried_filter
def test_curried_filter():
    # Positive test case
    var_0 = curried_filter(lambda x: x > 0, [1, 2, 3])
    var_1 = curried_filter(lambda x: x == 0, [1, 2, 3])
    var_2 = curried_filter(lambda x: x < 0, [1, 2, 3])
    var_3 = curried_filter(eq(5), [1, 2, 3, 5, 5])
    var_4 = curried_filter(eq(0), [1, 2, 3])

    # Negative test case
    var_5 = curried_filter(lambda x: x < 0, [1, 2, 3])
    var_6 = curried_filter(lambda x: x > 0, [1, 2, 3])

# Generated at 2022-06-26 00:20:33.797212
# Unit test for function cond
def test_cond():
    is_even = lambda x: x % 2 == 0
    is_odd = lambda x: x % 2 != 0
    is_zero = lambda x: x == 0
    assert cond([
        (is_even, lambda x: "It's even!"),
        (is_odd, lambda x: "It's odd!"),
        (is_zero, lambda x: "It's zero!")
    ])(3) == "It's odd!"
    assert cond([
        (is_even, lambda x: "It's even!"),
        (is_odd, lambda x: "It's odd!"),
        (is_zero, lambda x: "It's zero!")
    ])(2) == "It's even!"

# Generated at 2022-06-26 00:20:46.069009
# Unit test for function memoize
def test_memoize():
    def fn(arg: int) -> int:
        return arg

    def fn_1(arg: int) -> int:
        return arg

    # Case 0. Basic invoke
    var_0 = memoize(fn, key=eq)
    assert var_0(1) == 1

    # Case 1. Two arguments with different hash
    var_0 = memoize(fn, key=eq)
    assert var_0(1) == 1
    assert var_0(2) == 2
    var_0 = memoize(fn, key=eq)
    assert var_0(1) == 1
    assert var_0(2) == 2

    # Case 2. Two arguments with different hash
    var_0 = memoize(fn, key=eq)
    assert var_0(1) == 1

# Generated at 2022-06-26 00:21:06.769587
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x * 2, [1, 2, 3]) == [2, 4, 6]
    # var_0 = fn()
    assert curried_map(lambda x: x + 4, [1, 4, 3]) == [5, 8, 7]
    # var_0 = fn()
    assert curried_map(lambda x: x - 1, [1, 4, 3]) == [0, 3, 2]
    # var_0 = fn()
    assert curried_map(lambda x: x + 4, None) == []
    # var_0 = fn()
    assert curried_map(lambda x: x + 4, []) == []
    # var_0 = fn()
    assert curried_map(lambda x: x * 2, []) == []
    # var_0 = fn

# Generated at 2022-06-26 00:21:16.478277
# Unit test for function find
def test_find():
    array = [1, 2, 3, 4, 5, 6, 7]
    # Test for finding first even number
    assert find(array, lambda i: i % 2 == 0) == 2, "Not found first even number"
    # Test for finding last even number
    assert find(array, lambda i: i % 2 == 0) == 6, "Not found last even number"
    # Test for finding first even number
    assert find(array, lambda i: i % 2 == 1) == 1, "Not found first odd number"
    # Test for finding last even number
    assert find(array, lambda i: i % 2 == 1) == 7, "Not found last odd number"
    # Test for finding first number divisible by three
    assert find(array, lambda i: i % 3 == 0) == 3, "Not found first number divisible by three"

# Generated at 2022-06-26 00:21:17.498878
# Unit test for function eq
def test_eq():
    assert eq(9)(9)



# Generated at 2022-06-26 00:21:20.359554
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x == 1, lambda x: 1),
        (lambda x: x == 2, lambda x: 2),
        (lambda x: x == 3, lambda x: 3),
    ])(3) == 3


# Generated at 2022-06-26 00:21:21.192415
# Unit test for function eq
def test_eq():
    assert eq(1, 2) == False
    assert eq(1, 1) == True


# Generated at 2022-06-26 00:21:22.664248
# Unit test for function eq
def test_eq():
    a = 1
    b = 1
    assert(eq(a, b) == True)


# Generated at 2022-06-26 00:21:25.596165
# Unit test for function eq
def test_eq():
    # case True
    assert eq(True, True)
    # case True
    assert eq(1, 1)
    # case False
    assert not eq(True, False)


# Generated at 2022-06-26 00:21:28.510767
# Unit test for function curried_map
def test_curried_map():
    m = curried_map(lambda x: x + 1)

    assert m([1, 2, 3]) == [2, 3, 4]
    assert m([]) == []



# Generated at 2022-06-26 00:21:33.855378
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y: x + y)(1)(2)(3)(4) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z, w: x + y + z + w)(1)(2)(3)(4) == 10



# Generated at 2022-06-26 00:21:37.248564
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [0, 2, 4, 6, 8, 10]



# Generated at 2022-06-26 00:21:49.514292
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-26 00:21:54.852451
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(fn, []) == []
    assert curried_map(fn, [1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]
    assert curried_map(fn, []) == []
    assert curried_map(fn, [1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]

test_curried_map()



# Generated at 2022-06-26 00:21:58.246422
# Unit test for function memoize
def test_memoize():
    def test_fn(argument):
        return argument + 1

    memoized_fn = memoize(test_fn)
    assert memoized_fn(0) == 1
    assert memoized_fn(1) == 2
    assert memoized_fn(0) == 1



# Generated at 2022-06-26 00:22:01.045834
# Unit test for function cond
def test_cond():
    result = cond([
        (lambda x: x == 'foo', lambda x: x + 'baz')
    ])('foo')
    assert result == 'foobaz', 'cond don\'t work correctly'



# Generated at 2022-06-26 00:22:09.354261
# Unit test for function cond
def test_cond():
    def fn_0(var_0: int) -> int:
        return var_0
    def fn_1(var_0: int) -> int:
        return var_0 + 1
    def fn_2(var_0: int) -> int:
        return var_0 + 2
    def fn_3(var_0: int) -> int:
        return var_0 + 3
    def fn_4(var_0: int) -> int:
        return var_0 + 4
    def fn_5(var_0: int) -> int:
        return var_0 + 5
    def fn_6(var_0: int) -> int:
        return var_0 + 6
    def fn_7(var_0: int) -> int:
        return var_0 + 7

# Generated at 2022-06-26 00:22:10.774315
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda item: item == 2) is 2



# Generated at 2022-06-26 00:22:15.804210
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([]) == []



# Generated at 2022-06-26 00:22:20.769592
# Unit test for function curry
def test_curry():
    """
    Test curry function with some useful examples.
    """
    def fn_0(a, b, c):
        return a + b + c

    fn_0 = curry(fn_0)
    assert fn_0(1)(2)(3) == 6
    assert fn_0(1, 2)(3) == 6
    assert fn_0(1)(2, 3) == 6
    assert fn_0(1, 2, 3) == 6



# Generated at 2022-06-26 00:22:29.526472
# Unit test for function eq
def test_eq():
    # функция 'eq' должна принимать 2 параметра и возвращать True если они равны и False в обратном случае
    # функция должна быть curried
    fail_message_0 = "Function 'eq' should work!"
    fail_message_1 = "Function 'eq' should be curried!"

    failed = False
    for x in range(100):
        # test for equality
        if not eq(x, x):
            failed = True
            break

   

# Generated at 2022-06-26 00:22:33.584940
# Unit test for function eq
def test_eq():
    assert eq(2, 4) == False
    assert eq(2, 2) == True


# Generated at 2022-06-26 00:22:44.434488
# Unit test for function eq
def test_eq():
    assert eq(1, 1)


# Generated at 2022-06-26 00:22:47.534661
# Unit test for function curry
def test_curry():
    def foo(x, y, z):
        return x + y + z
    assert foo(1, 2, 3) == curry(foo)(1)(2)(3)



# Generated at 2022-06-26 00:22:49.295136
# Unit test for function eq
def test_eq():
    # Unit test for function eq
    assert eq(1, 1)
    assert not eq(1, 2)


# Generated at 2022-06-26 00:22:51.258748
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-26 00:22:58.984996
# Unit test for function cond
def test_cond():
    # Test case 1
    test_case_1 = cond([
        (compose(eq(20)), compose(identity)),
        (compose(eq(10)), compose(identity)),
    ])
    assert callable(test_case_1), "Function cond is not callable"
    assert test_case_1(10) == 10, "Test case 1 is failed"

    # Test case 2
    test_case_2 = cond([
        (compose(eq(10)), compose(identity)),
        (compose(eq(20)), compose(identity)),
    ])
    assert callable(test_case_2), "Function cond is not callable"
    assert test_case_2(10) == 10, "Test case 2 is failed"

    # Test case 3

# Generated at 2022-06-26 00:23:04.167426
# Unit test for function curried_filter
def test_curried_filter():
    int_0 = 100
    var_0 = curried_filter(eq(100), [100, 101, 102])
    assert var_0 == [int_0]

    int_0 = 42
    var_1 = curried_filter(eq, [int_0])
    assert var_1 == [int_0]



# Generated at 2022-06-26 00:23:10.156260
# Unit test for function memoize
def test_memoize():
    def factorial(n: int) -> int:
        """
        Calculate factorial of `n`.

        :param n:
        :type n: Int
        :returns:
        :rtype: Int
        """
        if n in [0, 1]:
            return n
        else:
            return n * factorial(n-1)

    factorial = memoize(factorial)

    assert factorial(1) == 1
    assert factorial(2) == 2
    assert factorial(3) == 6
    assert factorial(4) == 24

# Unit test function identity

# Generated at 2022-06-26 00:23:12.680694
# Unit test for function cond
def test_cond():
    int_0 = -1541
    var_0 = cond([(lambda x: x > 10, lambda x: x + 10), (lambda x: x < 10, lambda x: x + 1)])(int_0)



# Generated at 2022-06-26 00:23:16.339973
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x % 2, [1, 2, 3]) == [1, 0, 1]
    assert curried_map(lambda x: x**2, [1, 2, 3]) == [1, 4, 9]


# Generated at 2022-06-26 00:23:21.861315
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1)(1) == True
    assert eq(1)(2) == False
    assert eq(1, 2) == False
    assert eq([1, 2, 3], [1, 2, 3]) == True
    assert eq([1, 2, 3])([1, 2, 3]) == True
    assert eq([1, 2, 3])([1, 2, 4]) == False
    assert eq([1, 2, 3], [1, 2, 4]) == False


# Generated at 2022-06-26 00:23:41.457813
# Unit test for function cond
def test_cond():
    test_case_1()
    test_case_2()



# Generated at 2022-06-26 00:23:44.190113
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [1, 2]) == [1, 2]
    assert curried_map(increase, [1, 2]) == [2, 3]



# Generated at 2022-06-26 00:23:45.763424
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x * x == 9) == 3



# Generated at 2022-06-26 00:23:54.984907
# Unit test for function cond
def test_cond():
    is_even = lambda value: value % 2 == 0
    is_odd = lambda value: value % 2 == 1
    is_negative = lambda value: value < 0
    is_positive = lambda value: value >= 0

    even_action = lambda value: 'even'
    odd_action = lambda value: 'odd'
    negative_action = lambda value: 'negative'
    positive_action = lambda value: 'positive'

    assert cond([
        (is_even, even_action),
        (is_odd, odd_action)
    ])(2) == 'even'
    assert cond([
        (is_even, even_action),
        (is_odd, odd_action)
    ])(3) == 'odd'


# Generated at 2022-06-26 00:23:58.680765
# Unit test for function find
def test_find():
    array = [1, 2, 3, 4, 6, 7]
    result = find(array, lambda x: x == 8)
    assert result is None, 'should be None'

    result = find(array, lambda x: x == 3)
    assert result == 3, 'should be 3'



# Generated at 2022-06-26 00:24:02.084302
# Unit test for function find
def test_find():
    assert(find([1, 2, 3], lambda n: n % 2 == 0) == 2)
    assert(find([1, 2, 3], lambda n: n % 3 == 0) == 3)
    assert(find([1, 2, 3], lambda n: n % 4 == 0) == None)



# Generated at 2022-06-26 00:24:03.632857
# Unit test for function memoize
def test_memoize():
    def square(x):
        return x * x

    assert mem(square)(3) == 9

test_memoize()

# Generated at 2022-06-26 00:24:04.910964
# Unit test for function eq
def test_eq():
    print(eq(1, 1))
    print(eq(1, 2))


# Generated at 2022-06-26 00:24:07.477643
# Unit test for function memoize
def test_memoize():
    output = memoize(lambda x: x * 2)(4)
    assert output == 8
    output = memoize(lambda x: x * 2)(4)
    assert output == 8


# Generated at 2022-06-26 00:24:10.513017
# Unit test for function eq
def test_eq():
    var_0 = eq(0, 0)
    var_1 = eq(0, 1)
    var_2 = eq(1, 0)
    var_3 = eq(1, 1)


# Generated at 2022-06-26 00:25:07.723092
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map([1, 2, 3])(increase) == [2, 3, 4]


# Generated at 2022-06-26 00:25:19.504933
# Unit test for function curried_map
def test_curried_map():
    int_0 = 1
    int_1 = 2
    int_2 = 3
    array_0 = [int_0, int_1, int_2]
    function_0 = curry(lambda x: x + 1)
    function_1 = curry(lambda x: x + 2)
    array_1 = curried_map(function_0, array_0)
    array_2 = curried_map(function_1, array_0)
    int_3 = array_1[0]
    int_4 = array_1[1]
    int_5 = array_1[2]
    int_6 = array_2[0]
    int_7 = array_2[1]
    int_8 = array_2[2]
    print(str(int_3))
    print(str(int_4))

# Generated at 2022-06-26 00:25:22.984690
# Unit test for function curried_filter
def test_curried_filter():
    even = lambda num: num % 2 == 0

    list_0 = [3, 5, 7, 9, 11, 13, 15]
    list_1 = curried_filter(even, list_0)

    assert list_1 == [3, 5, 7, 9, 11, 13, 15]



# Generated at 2022-06-26 00:25:34.974746
# Unit test for function curry
def test_curry():
    test_function = lambda a, b, c, d: a + b + c + d
    test_function_1 = curry(test_function, 1)
    test_function_2 = curry(test_function_1, 1)
    test_function_3 = curry(test_function_2, 1)
    assert test_function(1, 1, 1, 1) == test_function_3(1)

    test_function = lambda a, b, c, d: a + b + c + d
    test_function_1 = curry(test_function, 2)
    test_function_2 = curry(test_function_1, 1)
    assert test_function(1, 1, 1, 1) == test_function_2(1, 1)

    test_function = lambda a, b, c, d: a + b + c

# Generated at 2022-06-26 00:25:38.265274
# Unit test for function curried_filter
def test_curried_filter():
    list_0 = [1, 2, 3, 4, 5, 6]
    lambda_0 = lambda var_1: (var_1 % 2) == 0
    list_1 = curried_filter(lambda_0, list_0)
    print("list_1:", list_1)



# Generated at 2022-06-26 00:25:43.553555
# Unit test for function find
def test_find():
    # Test for find function
    search_in_list = [2, 3, 5, 7, 11]
    # Test for find function with key function
    assert find(search_in_list, lambda item: item == 5) == 5
    assert find(search_in_list, lambda item: item == 6) is None
    # Test for find function with key object
    assert find(search_in_list, "== 5") is None
    assert find(search_in_list, 5) is None



# Generated at 2022-06-26 00:25:50.850960
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], eq(2)) == 2
    assert find([1, 2, 3, 4], eq(5)) is None
    assert find(['Python', 'Java', 'C++'], lambda string: 'J' in string) == 'Java'
    assert find(['Python', 'Java', 'C++'], lambda string: 'JS' in string) is None


# Generated at 2022-06-26 00:25:51.608963
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True

# Generated at 2022-06-26 00:25:54.457516
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None
    assert find([], lambda x: x == 2) is None


# Generated at 2022-06-26 00:25:57.529492
# Unit test for function curried_filter
def test_curried_filter():
    # Test 1
    assert curried_filter(lambda x: x > 1)([1, 2, 3]) == [2, 3]

    # Test 2
    assert curried_filter(lambda x: x > 1)([1, 1]) == []



# Generated at 2022-06-26 00:27:15.383315
# Unit test for function curried_map
def test_curried_map():
    """
    Test function curried_map
    """
    assert curried_map(lambda x: x + 2)([1, 4, 3]) == [3, 6, 5]
    assert curried_map(lambda x: x + 2)([]) == []
    assert curried_map(lambda x: x + 2)([1]) == [3]


# Generated at 2022-06-26 00:27:25.053051
# Unit test for function memoize
def test_memoize():
    increase_memoized = memoize(increase)
    assert increase_memoized(5) == increase(5)
    assert increase_memoized(5) == 6
    assert increase_memoized(6) == increase(6)

    only_first_memoized = memoize(increase, lambda value, value1: value is value1)
    assert only_first_memoized(5) == increase(5)
    assert only_first_memoized(5) == 6
    assert only_first_memoized(6) == 7



# Generated at 2022-06-26 00:27:26.675212
# Unit test for function eq
def test_eq():
    assert eq(2)(2)
    assert not eq(2)(3)



# Generated at 2022-06-26 00:27:30.010594
# Unit test for function memoize
def test_memoize():
    assert memoize(increase)(0) == 1
    assert memoize(increase)(0) == 1


test_memoize()

# Generated at 2022-06-26 00:27:35.060886
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert eq('asd', 'asd')
    assert not eq(1, 2)
    assert not eq('asd', 'ghjk')
    assert eq(1, 1.0)
    assert not eq(1, 2.0)



# Generated at 2022-06-26 00:27:42.658850
# Unit test for function curried_filter
def test_curried_filter():
    collection = [3, 3, 3, 1, 2, 4, 5, 6, 4, 8, 9, 0]
    is_odd = lambda x: x % 2 == 1
    is_greater_than_three = lambda x: x > 3
    is_equal_three = lambda x: x == 3
    is_less_than_zero = lambda x: x < 0
    is_even = lambda y: y % 2 == 0
    curried_filter_odd = curried_filter(is_odd)
    curried_filter_greater_than_three = curried_filter(is_greater_than_three)
    curried_filter_equal_three = curried_filter(is_equal_three)
    curried_filter_less_than_zero = curried_filter(is_less_than_zero)
   

# Generated at 2022-06-26 00:27:44.084456
# Unit test for function find
def test_find():
    assert (find(
        [1, 2, 3],
        lambda item: item == 2
    ) == 2)



# Generated at 2022-06-26 00:27:47.027316
# Unit test for function find
def test_find():
    print("TEST Find:")
    collection = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    item = find(collection, lambda item: item == 5)
    print("Item: ", item)
    # TEST find function
    assert item is not None, "Find item in collection"



# Generated at 2022-06-26 00:27:48.802557
# Unit test for function eq
def test_eq():
    assert eq(2, 2) is True
    assert eq(2, 4) is False
    assert eq(3)(3) is True
    assert eq(3)(4) is False


# Generated at 2022-06-26 00:27:54.801396
# Unit test for function find
def test_find():
    """
            finds should return the first element of the list which matches the predicate, or None if no elements match.

            >>> from ramda import curry, maps, filter
            >>> filter(lambda x: x % 2 == 0)([1, 2, 3, 4])
            [2, 4]

            >>> find(lambda x: x % 2 == 0, [1, 2, 3, 4])
            2
    """

    # TODO: implement function
    pass


if __name__ == '__main__':
    test_case_0()

    from doctest import testmod
    testmod()