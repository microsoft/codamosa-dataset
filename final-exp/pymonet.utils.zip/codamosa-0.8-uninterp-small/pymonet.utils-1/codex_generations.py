

# Generated at 2022-06-26 00:18:29.059164
# Unit test for function curried_filter
def test_curried_filter():
    func = curried_filter(eq(0))
    assert func([0, 1, 2, 3]) == [0]
    assert func([]) == []



# Generated at 2022-06-26 00:18:35.187238
# Unit test for function cond
def test_cond():
    assert cond(
        [(eq(0), increase),
         (eq(1), increase),
         (eq(2), identity)]
    )(0) == 1
    assert cond(
        [(eq(0), increase),
         (eq(1), increase),
         (eq(2), identity)]
    )(1) == 2
    assert cond(
        [(eq(0), increase),
         (eq(1), increase),
         (eq(2), identity)]
    )(2) == 2



# Generated at 2022-06-26 00:18:43.576243
# Unit test for function cond
def test_cond():
    # Create condition list
    condition_list: List[Tuple[Callable[[int], bool], Callable]] = [
        (lambda x: x == 0, lambda: 'zero'),
        (lambda x: x > 0, lambda x: 'more'),
        (lambda x: x < 0, lambda x: 'less'),
        (lambda x: True, lambda x: 'other'),
    ]

    # Create new function conditionally invoke
    conditionally = cond(condition_list)

    # Test new function
    assert conditionally(0) == 'zero'
    assert conditionally(2) == 'more'
    assert conditionally(-2) == 'less'
    assert conditionally(1.23) == 'other'


# Generated at 2022-06-26 00:18:46.207173
# Unit test for function eq
def test_eq():
    assert eq(3, 3)
    assert eq("hello", "hello")
    assert eq("a", "A") is False
    assert eq("a", "B") is False


# Generated at 2022-06-26 00:18:53.666947
# Unit test for function find
def test_find():
    try:
        assert find([1, 2, 3, 4], lambda x: x ** 2 == 16) == 4
        assert find([1, 2, 3, 4, 5], lambda x: x == 123) is None
    except AssertionError:
        print("test failed")


# Generated at 2022-06-26 00:18:59.637779
# Unit test for function eq
def test_eq():
    assert (eq(1, 1) == True)
    assert (eq('abc', 'abc') == True)
    assert (eq([1, 2, 3], [1, 2, 3]) == True)
    assert (eq(1, 2) == False)
    assert (eq('abc', 'def') == False)
    assert (eq([1, 2, 3], [3, 2, 1]) == False)


# Generated at 2022-06-26 00:19:04.843234
# Unit test for function curry
def test_curry():
    assert(identity(1)(2)(3)(4)(5) == 1)
    assert(increase(1)(2)(3)(4)(5) == 2)
    assert(curry(lambda a, b, c, d: a + b + c + d, 4)(1)(2)(3)(4) == 10)
    assert(curry(lambda a, b, c, d: a + b + c + d)(1)(2)(3)(4) == 10)


# Generated at 2022-06-26 00:19:11.033866
# Unit test for function find
def test_find():
    var_0 = find([1, 2, 3, 4, 5], lambda x: x % 2 == 0)
    print(var_0)
    print(var_0)
    print(find([1, 2, 3, 4, 5], lambda x: x % 2 == 0))
    print(find([1, 2, 3, 4, 5], lambda x: x % 3 == 0))
    print(find([1, 2, 3, 4, 5], lambda x: x % 4 == 0))
    print(find([1, 2, 3, 4, 5], lambda x: x % 5 == 0))


# Generated at 2022-06-26 00:19:20.096760
# Unit test for function curried_map
def test_curried_map():
    """
    Testing that curried_map will return the same value
    as the map function with a lambda function that doubles a number.

    :returns: True if curried_map works, otherwise False
    :rtype: Boolean
    """

    a = curried_map(lambda x: x * 2)
    b = list(map(lambda x: x * 2, range(10)))

    for i in range(10):
        if a(i) != b[i]:
            return False
    return True



# Generated at 2022-06-26 00:19:29.535392
# Unit test for function curry
def test_curry():
    def test_curry(assert_equal, assert_not_equal, assert_raises):
        assert_equal(
            curry(lambda x, y, z: x + y + z)(1)(2)(3),
            6
        )
        assert_equal(
            curry(lambda x, y, z: x + y + z)(1)(2)(3),
            6
        )
        assert_equal(
            curry(lambda x, y, z: x + y + z)(1)(2)(3),
            6
        )
        assert_equal(
            curry(lambda x, y, z: x + y + z)(1)(2)(3),
            6
        )
        assert_equal(
            curry(lambda x, y, z: x + y + z)(1)(2)(3),
            6
        )

   

# Generated at 2022-06-26 00:19:45.336040
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], eq(3)) == 3
    assert find([1, 2, 3, 4], eq(5)) is None
    assert find(['a', 'b'], eq('b')) == 'b'
    assert find(['a', 'b'], eq('c')) is None
    assert find([[1, 2], [2, 3], [4, 5]], eq([2, 3])) == [2, 3]
    assert find([[1, 2], [2, 3], [4, 5]], eq([5, 6])) is None



# Generated at 2022-06-26 00:19:47.277862
# Unit test for function curried_map
def test_curried_map():
    result = curried_map(increase)([1, 2, 3])
    assert result == [2, 3, 4]



# Generated at 2022-06-26 00:19:52.242356
# Unit test for function memoize
def test_memoize():
    res = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]

    @memoize
    def fib(n):
        if n < 2:
            return n
        return fib(n - 2) + fib(n - 1)

    for i in range(10):
        assert fib(i) == res[i]



# Generated at 2022-06-26 00:20:02.678414
# Unit test for function curried_map
def test_curried_map():
    assert curry(lambda x, y, z: [x, y, z]) == curry(lambda x, y, z: [x, y, z], 3)
    assert curry(lambda x, y: y(x)) == curry(lambda x, y: y(x), 2)
    assert curry(lambda x, y, z, a: y(x + z, a)) == curry(lambda x, y, z, a: y(x + z, a), 4)
    assert curry(lambda x, y, z, a: y(z + x, z, a)) == curry(lambda x, y, z, a: y(z + x, z, a), 4)
    assert curry(lambda x: x)(1) == 1
    assert curry(lambda x, y: y)(3)(11) == 3

# Generated at 2022-06-26 00:20:07.002733
# Unit test for function memoize
def test_memoize():
    def test_function(argument):
        return argument + 1

    test_function_memoized = memoize(test_function)
    assert test_function_memoized(1) == test_function(1)

    assert test_function_memoized(
        1) == test_function_memoized(1) == test_function(1)



# Generated at 2022-06-26 00:20:09.677144
# Unit test for function curried_filter
def test_curried_filter():
    assert [1, 2] == curried_filter(lambda value: value < 3, [1, 2, 3])
    assert [1, 2] == curried_filter(lambda value: value < 3)([1, 2, 3])



# Generated at 2022-06-26 00:20:12.394051
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [1, 2, 3]) == [1, 2, 3]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-26 00:20:15.773362
# Unit test for function curried_map
def test_curried_map():
    result = curried_map(increase, [1, 2, 3])
    assert [2, 3, 4] == result

    result = curried_map(increase, [])
    assert [] == result


# Generated at 2022-06-26 00:20:22.610858
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: True)([0, 1, 2, 3, 4, 5]) == [0, 1, 2, 3, 4, 5]

    assert curried_filter(lambda x: False)([0, 1, 2, 3, 4, 5]) == []
    assert curried_filter(lambda x: x % 2 == 0)([0, 1, 2, 3, 4, 5]) == [0, 2, 4]
    assert curried_filter(lambda x: "a" == x)(["a", "b", "c", "d", "e", "f"]) == ["a"]



# Generated at 2022-06-26 00:20:25.212688
# Unit test for function memoize
def test_memoize():
    # Var declaration
    var_0 = memoize(lambda x: x * 2)

    # Assertions
    assert var_0(10) == 20
    assert var_0(10) == 20



# Generated at 2022-06-26 00:20:44.403081
# Unit test for function curried_filter
def test_curried_filter():
    # t0-t1
    assert True == curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6])(), "t0: curried_filter([1, 2, 3, 4, 5, 6], lambda x: x % 2 == 0) should equal [2, 4, 6]"
    assert False == curried_filter(lambda x: x > 0, [1, 2, 3, 4, 5, 6])(), "t0: curried_filter([1, 2, 3, 4, 5, 6], lambda x: x > 0) should equal [1, 2, 3, 4, 5, 6]"
    
    # t2-t3

# Generated at 2022-06-26 00:20:48.416623
# Unit test for function memoize
def test_memoize():
    def slow_increase(number):
        from time import sleep
        sleep(1)
        return number + 1

    cached_fn = memoize(slow_increase)
    assert cached_fn(10) == 11
    assert cached_fn(10) == 11

    print('test_memoize passed')



# Generated at 2022-06-26 00:20:52.705693
# Unit test for function memoize
def test_memoize():
    """ Check if function was invoked once """
    var_0 = 0

    def fn():
        nonlocal var_0
        var_0 += 1
        return 0

    memoized_fn = memoize(fn)
    memoized_fn(0)
    memoized_fn(0)

    return var_0 == 1


# Generated at 2022-06-26 00:21:01.619843
# Unit test for function find
def test_find():
    assert find(['a', 'b', 'c', 'd'], lambda x: x == 'c') == 'c'
    assert find([{'num': 'a'}, {'num': 'b'}], lambda x: x['num'] == 'b') == {'num': 'b'}
    assert find([1, 2, 3, 4], lambda x: isinstance(x, int)) == 1



# Generated at 2022-06-26 00:21:06.323040
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 1, [1, 2, 3]) == [2, 3]
    assert curried_filter(lambda x: x > 1, []) == []
    assert curried_filter(lambda x: x > 1, [1, 1, 1]) == []
    assert curried_filter(lambda x: x > 3, [1, 2, 3]) == []


# Generated at 2022-06-26 00:21:12.819186
# Unit test for function curry
def test_curry():
    def simple_curry():
        def a(a, b, c):
            return a + b + c
        return curry(a)(1)(2)(3)

    assert simple_curry() == 6

    def simple_curry_with_wrong_arguments():
        def a(a, b, c):
            return a + b + c
        return curry(a)(1)

    assert simple_curry_with_wrong_arguments() == curry(a)(1)



# Generated at 2022-06-26 00:21:21.621386
# Unit test for function find
def test_find():
    # when collection is empty, empty
    assert find([], lambda item: item == 'test') is None
    # when collection is not empty and no element match
    assert type(find([1, 2, 3], lambda item: item == 'test')) is None
    # when collection is not empty and element match
    assert find([1, 2, 3, 'test'], lambda item: item == 'test') == 'test'
    assert find(['test', 1, 2, 3], lambda item: item == 'test') == 'test'
    assert find([1, 'test', 2, 3], lambda item: item == 'test') == 'test'
    assert find([1, 2, 'test', 3], lambda item: item == 'test') == 'test'
    assert find([1, 2, 3, 'test'], lambda item: item == 'test')

# Generated at 2022-06-26 00:21:30.152619
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5])([2, 4]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0, [])([1, 2, 3, 4, 5]) == []
    assert curried_filter(lambda x: x % 2 == 0, [2, 4])([1, 2, 3, 4, 5]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5])([]) == []
    assert curried_filter(lambda x: x % 2 == 0, [])([]) == []


# Generated at 2022-06-26 00:21:32.372738
# Unit test for function find
def test_find():
    assert find([1, 2], lambda item: item == 2) == 2
    assert find([1, 2], lambda item: item == 3) is None



# Generated at 2022-06-26 00:21:34.184916
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda value: value > 2)([1, 2, 3]) == [3]


# Generated at 2022-06-26 00:21:44.236571
# Unit test for function curried_map
def test_curried_map():
    evens = curried_map(lambda x: x % 2 == 0)
    assert evens([1, 2, 3, 4]) == [False, True, False, True]
    assert evens([2, 4, 6]) == [True, True, True]
    

# Generated at 2022-06-26 00:21:54.005164
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda c: c % 2 == 0, [1, 2, 3, 4, 5, 6])([2, 4, 6])
    assert curried_filter(lambda c: c % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8])([2, 4, 6, 8])
    assert curried_filter(lambda c: c % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8])([2, 4, 6, 8])
    assert curried_filter(lambda c: c % 2 != 0, [1, 2, 3, 4, 5, 6, 7, 8])([1, 3, 5, 7])

# Generated at 2022-06-26 00:21:56.175369
# Unit test for function curry
def test_curry():
    add = curry(lambda x, y: x + y)
    output_0 = add(2)(4)

    assert output_0 == 6


# Generated at 2022-06-26 00:21:58.585655
# Unit test for function eq
def test_eq():
    eq(curried_map(increase)([1,2,3]), [2,3,4])
    eq(curried_map(increase)([]), [])


# Generated at 2022-06-26 00:22:00.147722
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)


# Generated at 2022-06-26 00:22:08.417854
# Unit test for function cond
def test_cond():
    def condition_0(value):
        return value == 0

    def execute_0(value):
        return "value_is_0"

    def condition_1(value):
        return value == 1

    def execute_1(value):
        return "value_is_1"

    def condition_2(value):
        return value == 2

    def execute_2(value):
        return "value_is_2"

    def execute_2_2(value):
        return "value_is_2_2"

    assert (
        cond([
            (condition_0, execute_0),
            (condition_1, execute_1),
            (condition_2, execute_2),
        ])(0) == "value_is_0"
    )


# Generated at 2022-06-26 00:22:11.623320
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], eq(3)) == 3
    assert find([1, 2, 3, 4], lambda x: x == 5) == None
    assert find([1, 2, 3, 4], lambda x: x == 4) == 4



# Generated at 2022-06-26 00:22:19.956708
# Unit test for function cond
def test_cond():
    assert (
        cond([
            (lambda x: x < 5, lambda x: f'{x} less than 5'),
            (lambda x: x > 5, lambda x: f'{x} bigger than 5'),
            (lambda x: x == 5, lambda x: f'{x} equal 5')
        ])(6) == '6 bigger than 5'
    )
    assert (
        cond([
            (lambda x: x < 5, lambda x: f'{x} less than 5'),
            (lambda x: x > 5, lambda x: f'{x} bigger than 5'),
            (lambda x: x == 5, lambda x: f'{x} equal 5')
        ])(4) == '4 less than 5'
    )

# Generated at 2022-06-26 00:22:22.992671
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda item: item == 2) == 2
    assert find([1, 2, 3], lambda item: item == 4) is None



# Generated at 2022-06-26 00:22:28.404147
# Unit test for function curry
def test_curry():
    assert eq(fn(1, 2), curry(fn)(1)(2))
    assert eq(fn(1, 2, 3), curry(fn)(1)(2)(3))
    assert eq(fn(1, 2, 3), curry(fn, 3)(1, 2, 3))
    assert eq(fn(1, 2, 3), curry(fn, 3)(1)(2, 3))
    assert eq(fn(1, 2, 3), curry(fn, 3)(1)(2)(3))



# Generated at 2022-06-26 00:22:41.356542
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda number: number == 4, [1, 2, 4, 8]) == [4]
    assert curried_filter(lambda number: number == 4, [1, 2, 4, 8, 4, 4]) == [4, 4, 4]
    assert curried_filter(lambda num1: num1 == 4, [1, 2, 4, 8]) == [4]


# Generated at 2022-06-26 00:22:48.111433
# Unit test for function memoize
def test_memoize():
    square = lambda x: x**2
    square = memoize(square)

    assert square(4) == 16
    assert square(4) == 16
    assert square(5) == 25
    assert square(4) == 16
    assert square(5) == 25

# Generated at 2022-06-26 00:22:50.961912
# Unit test for function curry
def test_curry():
    var_0 = curry(lambda argument_0, argument_1, argument_2: argument_0 + argument_1 + argument_2)(1, 2, 3)



# Generated at 2022-06-26 00:22:58.449228
# Unit test for function memoize
def test_memoize():
    counter = [0]
    def increment(a):
        counter[0] += 1
        return a + 1
    memoized_increment = memoize(increment)

    # First call
    assert memoized_increment(1) == 2
    assert counter == [1]

    # Second call
    assert memoized_increment(1) == 2
    assert counter == [1]

    # With new argument
    assert memoized_increment(2) == 3
    assert counter == [2]

    @memoize
    def test_fn(a):
        return a + 1

    assert test_fn(1) == 2
    assert test_fn(1) == 2
    assert test_fn(2) == 3



# Generated at 2022-06-26 00:23:07.209302
# Unit test for function memoize
def test_memoize():
    var_0 = memoize(identity)
    print(var_0(42))
    print(var_0(1))
    print(var_0(42))
    var_1 = memoize(identity, lambda x, y: x == y)
    print(var_1(42))
    print(var_1(1))
    print(var_1(42))
    print(var_1(1))
    var_2 = memoize(identity, eq)
    print(var_2(42))
    print(var_2(1))
    print(var_2(42))
    print(var_2(1))
    print(var_2(42))
    print(var_2(1))
    print(var_2(42))

# Generated at 2022-06-26 00:23:15.452601
# Unit test for function memoize
def test_memoize():
    def function_counter():
        function_counter.counter += 1
        return function_counter.counter

    function_counter.counter = 0

    simple_memoized_function = memoize(function_counter)

    assert 1 == simple_memoized_function()
    assert 1 == simple_memoized_function()

    memoized_function_with_custom_key = memoize(function_counter, lambda x, y: x == y)
    assert 2 == memoized_function_with_custom_key(None)
    assert 2 == memoized_function_with_custom_key(True)
    assert 2 == memoized_function_with_custom_key(False)
    assert 3 == memoized_function_with_custom_key(None)



# Generated at 2022-06-26 00:23:21.532932
# Unit test for function cond
def test_cond():
    # Test case 0
    assert cond([(lambda value: value % 3 == 0, lambda value: 'fizz')])(3) == 'fizz'

    # Test case 1
    assert cond([(lambda value: value % 3 == 0, lambda value: 'fizz'), (
        lambda value: value % 5 == 0, lambda value: 'buzz')])(3) == 'fizz'

    # Test case 2
    assert cond([(lambda value: value % 3 == 0, lambda value: 'fizz'), (
        lambda value: value % 5 == 0, lambda value: 15)])(3) == 'fizz'



# Generated at 2022-06-26 00:23:24.381975
# Unit test for function curry
def test_curry():
    """
    For testing function curry
    """
    assert curry(identity)(1) == 1
    assert curry(identity)('a') == 'a'

    assert curry(increase)(1) == 2
    assert curry(increase)(3) == 4



# Generated at 2022-06-26 00:23:28.609816
# Unit test for function curried_filter
def test_curried_filter():
    var_0 = curried_filter(lambda var_1: var_1 < 5, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    var_1 = curried_filter(lambda var_1: var_1 > 5, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    return var_0



# Generated at 2022-06-26 00:23:31.275372
# Unit test for function memoize
def test_memoize():
    memoized_func = memoize(lambda x: x * x)
    assert memoized_func(4) == 16
    assert memoized_func(5) == 25
    assert memoized_func(5) == 25



# Generated at 2022-06-26 00:23:40.943691
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert eq(None, None)
    assert not eq(1, 2)
    assert not eq(1, None)



# Generated at 2022-06-26 00:23:44.673538
# Unit test for function curried_filter
def test_curried_filter():
    # Test case curried_filter-1
    assert curried_filter(eq(2))([2, 3, 4, 2]) == [2, 2]
    # Test case curried_filter-2
    assert curried_filter(eq(2))([2, 3, 4, 5]) == [2]



# Generated at 2022-06-26 00:23:46.367762
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-26 00:23:48.756299
# Unit test for function find
def test_find():
    collection = [1, 2, 3, 4]
    assert find(collection, lambda item: item > 3) == 4
    assert find(collection, lambda item: item == 5) is None



# Generated at 2022-06-26 00:23:55.367544
# Unit test for function memoize
def test_memoize():
    cache = []
    arg = 1
    result = 3

    def memoized_function(argument):
        nonlocal arg, result
        assert arg == argument
        cache.append((arg, result))
        return result

    memoized_function = memoize(memoized_function)

    # Check if argument is passed
    assert memoized_function(arg) == result
    assert cache == [(arg, result)]

    # Check if argument is not passed
    memoized_function(arg + 1)
    assert cache == [(arg, result)]



# Generated at 2022-06-26 00:24:01.534491
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(2), [1, 2, 3]) == [2]
    assert curried_filter(eq(4), [1, 2, 3]) == []

    assert curried_filter(eq(2), [1, 2, 3]) == [2]
    assert curried_filter(eq(2), [1, 2, 3]) == [2]

    assert curried_filter(eq(2))([1, 2, 3]) == [2]
    assert curried_filter(eq(4))([1, 2, 3]) == []



# Generated at 2022-06-26 00:24:09.810268
# Unit test for function memoize
def test_memoize():
    import random

    @memoize
    def random_50_100():
        return random.randint(50, 100)

    assert random_50_100 == random_50_100, 'Function should be equals'
    assert random_50_100() != random_50_100(), 'Function should return different result'
    assert random_50_100() == random_50_100(), 'Function should return same result'

    @memoize
    def random_range(start: int, end: int):
        return random.randint(start, end)

    assert random_range(10, 20) == random_range(10, 20), 'Function should return same result'
    assert random_range(10, 20) != random_range(10, 20), 'Function should return different result'


# Generated at 2022-06-26 00:24:11.281617
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-26 00:24:16.447558
# Unit test for function memoize
def test_memoize():
    fibonacci: Callable[[int], int] = memoize(lambda x: 1 if x < 2 else fibonacci(x - 1) + fibonacci(x - 2))
    assert fibonacci(45) == 1134903170
    assert fibonacci(100) == 354224848179261915075
    assert fibonacci(100) == 354224848179261915075
    assert fibonacci(40) == 102334155



# Generated at 2022-06-26 00:24:20.035743
# Unit test for function find
def test_find():
    """
    Define function find test case

    :returns:
    :rtype:
    """
    # Assert to compare whant equal to what
    var_0 = find(
        [1, 2, 3, 4, 5],
        lambda arg: arg > 4
    )
    assert var_0 == 5



# Generated at 2022-06-26 00:24:39.264416
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x*x)([1, 2, 3]) == [1, 4, 9]
    assert curried_map(lambda x: x*2)([1, 2, 3]) == [2, 4, 6]

# Unit tests for function curried_filter

# Generated at 2022-06-26 00:24:42.414202
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x % 2 == 0) == 2
    assert find([1, 2, 3, 4, 5], lambda x: x > 6) is None
    assert find([1, 2, 3, 4, 5], lambda x: x == 1) == 1



# Generated at 2022-06-26 00:24:46.634152
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 3)([1, 2, 3, 4, 5]) == [4, 5]
    assert curried_filter(lambda x: x > 6)([1, 2, 3]) == []
    assert curried_filter(lambda x: True)([1, 2, 3]) == [1, 2, 3]
    assert curried_filter(lambda x: False)([1, 2, 3]) == []



# Generated at 2022-06-26 00:24:53.112639
# Unit test for function cond
def test_cond():
    @curry
    def is_equal(x, y):
        return x == y

    test_fn = cond([
        (is_equal(0), lambda x: "zero"),
        (is_equal(1), lambda x: "one"),
        (lambda x, z: True, lambda x, z: "many")
    ])

    print("Running cond test...")
    assert test_fn(1) == "one"
    assert test_fn(0) == "zero"
    assert test_fn(2) == "many"
    print("unit test for cond passed")



# Generated at 2022-06-26 00:24:58.731237
# Unit test for function memoize
def test_memoize():
    counter = {
        'call': 0
    }
    def function(arg):
        """
        Function for unit test memoize.

        :param arg: argument for function
        :type arg: Any
        :returns: arg and increase call counter
        :rtype: Any
        """
        counter['call'] += 1
        return arg

    memoized_function = memoize(function, key=eq)

    assert memoized_function(1) == 1
    assert memoized_function(2) == 2
    assert memoized_function(1) == 1
    assert counter['call'] == 2



# Generated at 2022-06-26 00:25:00.685185
# Unit test for function eq
def test_eq():
    var_0 = eq(0, 1)
    var_1 = eq(1, 1)
    var_2 = not eq(1, 0)


# Generated at 2022-06-26 00:25:01.733492
# Unit test for function eq
def test_eq():
    # eq(1, 1) -> True
    assert eq(1, 1)



# Generated at 2022-06-26 00:25:03.206068
# Unit test for function curried_map
def test_curried_map():
    var_0 = curried_map(fn_0)
    var_0(list_0)



# Generated at 2022-06-26 00:25:08.356347
# Unit test for function memoize
def test_memoize():
    def memory_using_sum(a, b):
        return a + b
    memoized_sum = memoize(memory_using_sum)
    assert memoized_sum(1, 2) == 3
    assert memoized_sum(1, 2) == 3
    assert memoized_sum(1, 2) == 3
    assert memoized_sum(2, 3) == 5
    assert memoized_sum(2, 3) == 5



# Generated at 2022-06-26 00:25:09.736132
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x == 1, [1, 2, 3]) == [1]


# Generated at 2022-06-26 00:25:28.312895
# Unit test for function eq
def test_eq():
    assert(eq(1, 1))
    assert(not eq(0, 1))


# Generated at 2022-06-26 00:25:31.678962
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None
    assert find([1, 2, 3]) == 1



# Generated at 2022-06-26 00:25:39.069727
# Unit test for function memoize
def test_memoize():
    from time import time
    from random import randint
    cache = []
    start = time()
    for i in range(10000):
        x = randint(0, 10)
        res = find(cache, lambda cacheItem: cacheItem[0] == x)
        if res is None:
            cache.append((x, i))
    end = time()
    print('Time for find in cache:', end - start)

    cache = []
    start = time()
    memoized_find = memoize(lambda x: find(cache, lambda cacheItem: cacheItem[0] == x))
    for i in range(10000):
        x = randint(0, 10)
        res = memoized_find(x)
        if res is None:
            cache.append((x, i))
    end = time()

# Generated at 2022-06-26 00:25:48.339614
# Unit test for function cond
def test_cond():
    condition_list = [
        (lambda x: x < 0, lambda x: x * (-1)),
        (lambda x: x > 0, lambda x: x * x)
    ]
    f = cond(condition_list)

    assert f(-1) == 1
    assert f(0) is None
    assert f(1) == 1

    condition_list = [
        (lambda x: x < 0, lambda x: x + 1),
        (lambda x: x == 0, lambda x: x * x)
    ]
    f = cond(condition_list)

    assert f(-1) == 0
    assert f(0) == 0
    assert f(1) is None



# Generated at 2022-06-26 00:25:52.619499
# Unit test for function find
def test_find():
    try:
        assert compose(
            curried_filter(eq(1)),
            curried_map(increase)
        )([1, 3, 5]) == [2, 4, 6]

    except AssertionError:
        print('Test find failed!')
        return

    print('Test find passed!')
    print('')



# Generated at 2022-06-26 00:25:55.106604
# Unit test for function curried_filter
def test_curried_filter():
    assert list(curried_filter(eq(2), [1, 2, 3])) == [2]
    assert list(curried_filter(eq(4), [1, 2, 3])) == []



# Generated at 2022-06-26 00:25:57.130926
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(2)) == 2
    assert find([1, 2, 3], eq(5)) is None



# Generated at 2022-06-26 00:26:00.060788
# Unit test for function eq
def test_eq():
    assert True == eq(1, 1)
    assert True == eq('some', 'some')
    assert False == eq(1, 'some')
    assert False == eq('some', 'some1')


# Generated at 2022-06-26 00:26:08.028806
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], eq(3)) == 3

    assert find([1, 2, 3, 4, 5], eq(6)) is None

    assert find([{'name': 'Bob'}, {'name': 'Alice'}, {'name': 'Alice'}], eq({'name': 'Alice'})) == {'name': 'Alice'}

    assert find([{'name': 'Bob'}, {'name': 'Alice'}, {'name': 'Alice'}], eq({'name': 'John'})) is None


# Generated at 2022-06-26 00:26:16.235274
# Unit test for function curry
def test_curry():
    assert curry(
        lambda x, y: x + y,
    )(1)(2) == 3
    assert curry(
        lambda x, y: x + y
    )(3)(4) == 7
    assert curry(
        lambda x, y: x + y
    )(1)(2)(3) == None
    assert curry(
        lambda x, y, z: x + y + z
    )(1)(2)(3) == 6
    assert curry(
        lambda x, y, z: x + y + z
    )(1)(2, 3) == 6
    assert curry(
        lambda x, y, z: x + y + z
    )(1, 2)(3) == 6
    assert curry(
        lambda x, y, z: x + y + z
    )(1, 2, 3)

# Generated at 2022-06-26 00:26:56.619514
# Unit test for function eq
def test_eq():
    assert eq()(1)(1) is True
    assert eq()(1)(2) is False
    assert eq()(1, 1) is True
    assert eq()(1, 2) is False


# Generated at 2022-06-26 00:27:01.847725
# Unit test for function memoize
def test_memoize():
    result_list, result_dict = [], {}

    def function(number):
        result_list.append(number)
        result_dict[number] = number * 2

        return number * 2

    memoized_function = memoize(function)

    assert (
        memoized_function(1) == 2 and
        memoized_function(2) == 4 and
        memoized_function(1) == 2 and
        memoized_function(4) == 8 and
        memoized_function(1) == 2 and
        result_list == [1, 2, 4] and
        result_dict == {1: 2, 2: 4, 4: 8}
    )


# Generated at 2022-06-26 00:27:08.963012
# Unit test for function memoize
def test_memoize():
    import pytest
    import random
    rand_list = [random.randint(0, 100) for _ in range(100)]

    def make_identity(argument):
        return argument

    def make_idempotent(argument):
        return argument

    memoized_identity_1 = memoize(make_identity)
    memoized_idempotent_1 = memoize(make_idempotent)

    memoized_identity_2 = memoize(make_identity, key=lambda x, y: y > x)
    memoized_idempotent_2 = memoize(make_idempotent, key=lambda x, y: y > x)

    memoized_identity_3 = memoize(make_identity, key=lambda x, y: y < x)
    memoized_idempotent_3 = memo

# Generated at 2022-06-26 00:27:10.659215
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)



# Generated at 2022-06-26 00:27:13.298957
# Unit test for function find
def test_find():
    arrayList = [1, 2, 3, 4, 5, 6]
    assert find(arrayList, lambda x: x == 3) == 3
    assert find(arrayList, lambda x: x == 8) is None
    assert find(arrayList, lambda x: x % 2 == 0) == 2



# Generated at 2022-06-26 00:27:20.618287
# Unit test for function curried_map
def test_curried_map():
    """
    curried_map(lambda x: x * x * x, [1, 2, 3, 4, 5]) == [1, 8, 27, 64, 125]
    """
    print(curried_map(lambda x: x * x * x, [1, 2, 3, 4, 5]) == [1, 8, 27, 64, 125])



# Generated at 2022-06-26 00:27:24.509717
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False
    assert eq(1)(1) is True
    assert eq(1)(2) is False
    assert eq(1, 1) is True
    assert eq(1, 2) is False
    assert eq(2, 2) is True
    assert eq(2, 1) is False


# Generated at 2022-06-26 00:27:26.935901
# Unit test for function curried_map
def test_curried_map():
    curried_map_ = curried_map(lambda x: x + 1)
    assert curried_map_([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-26 00:27:28.929314
# Unit test for function eq
def test_eq():
    return eq(0, 0)



# Generated at 2022-06-26 00:27:32.693725
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq(1, 2, 3) == False



# Generated at 2022-06-26 00:28:11.147209
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2]) == [1, 2]
    assert curried_map(increase)([1, 2]) == [2, 3]
    assert curried_map(increase, [1, 2]) == [2, 3]



# Generated at 2022-06-26 00:28:14.330819
# Unit test for function curry
def test_curry():
    assert curry(lambda: 1)() == 1
    assert curry(lambda x: x + 1)(0) == 1
    assert curry(lambda x, y: x + y)(1)(1) == 2
    assert curry(lambda x, y, z: x + y + z)(1)(1)(1) == 3



# Generated at 2022-06-26 00:28:17.478015
# Unit test for function curry
def test_curry():
    @curry
    def multiply(a, b, c):
        return a * b * c

    assert multiply(1, 2, 3) == 6
    assert multiply(1, 2)(3) == 6
    assert multiply(1)(2)(3) == 6



# Generated at 2022-06-26 00:28:19.053370
# Unit test for function curried_map
def test_curried_map():
    assert(curried_map(increase, [1, 2, 3]) == [2, 3, 4])



# Generated at 2022-06-26 00:28:20.852909
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 0)



# Generated at 2022-06-26 00:28:24.742271
# Unit test for function memoize
def test_memoize():
    # Arrange
    memoized_increase = memoize(increase)

    # Act
    var_1 = (memoized_increase(5) == 6)
    var_2 = (memoized_increase(5) == 6)

    # Assert
    assert var_1
    assert var_2

    # Act
    var_3 = (memoized_increase(6) == 7)

    # Assert
    assert var_3

