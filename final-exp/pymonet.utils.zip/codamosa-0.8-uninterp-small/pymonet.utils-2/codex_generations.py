

# Generated at 2022-06-26 00:18:40.938741
# Unit test for function memoize
def test_memoize():
    fn = memoize(increase)
    assert fn.__name__ == 'memoized_fn'

    assert fn(1) == 2
    assert fn(1) == 2
    assert fn(2) == 3
    assert fn(2) == 3

    fn2 = memoize(increase, lambda a, b: a == b)
    assert fn2.__name__ == 'memoized_fn'
    assert fn2(1) == 2
    assert fn2(1) == 2
    assert fn2(1) == 2
    assert fn2(2) == 3
    assert fn2(2) == 3
    assert fn2(3) == 4


if __name__ == "__main__":
    test_memoize()
    print('All tests passed')

# Generated at 2022-06-26 00:18:47.444293
# Unit test for function curried_filter
def test_curried_filter():
    assert isinstance(curried_filter, Curryable)
    assert isinstance(curried_filter(identity), Curryable)
    assert isinstance(curried_filter(identity)([])[0], TypeError)
    assert curried_filter(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_filter(identity, [1, None, 3]) == [1, 3]

    assert curried_filter(identity)([1, None, 3]) == curried_filter(identity, [1, None, 3])



# Generated at 2022-06-26 00:18:55.380294
# Unit test for function memoize
def test_memoize():
    # create function which return it's argument + 1
    add2 = lambda x: x + 2

    # apply memoization to fn
    memoized_add2 = memoize(add2)

    # first call always call fn and return argument + 1
    assert memoized_add2(1) == 3
    # second and next calls return cache value
    assert memoized_add2(1) == 3

    # same function with different argument return different result
    assert memoized_add2(2) == 4
    assert memoized_add2(2) == 4
    # and may be cached
    assert memoized_add2(2) == 4

    # same function with same argument return same result
    assert memoized_add2(1) == 3
    assert memoized_add2(1) == 3
    # and may be cached
    assert memoized

# Generated at 2022-06-26 00:19:02.296473
# Unit test for function memoize
def test_memoize():
    def fn(a):
        return a

    import random
    random.seed(42)
    examples = [random.randint(0, 100) for _ in range(100)]

    memoized_fn = memoize(fn)

    results = [fn(a) == memoized_fn(a) for a in examples]
    assert all(results)



# Generated at 2022-06-26 00:19:09.162991
# Unit test for function cond
def test_cond():
    """
    cond_test
    """
    @memoize
    def fib(n):
        return n if n < 2 else fib(n - 1) + fib(n - 2)

    condition_list = [(lambda x: x <= 0, identity),
                      (lambda x: x == 1, increase),
                      (lambda x: True, fib)]
    result = cond(condition_list)

    assert result(0) == 0
    assert result(1) == 2
    assert result(2) == 1
    assert result(3) == 2
    assert result(4) == 3
    assert result(5) == 5

# Generated at 2022-06-26 00:19:22.067594
# Unit test for function memoize
def test_memoize():

    def plus(x):
        return x + 1

    plus1 = memoize(plus)
    plus2 = memoize(plus1)

    # Our "plus" function should return 3 if we call it with argument 2.
    assert plus1(2) == 3
    # Our "plus" function should return 4 if we call it with argument 3.
    assert plus1(3) == 4
    # Our "plus" function should return 5 if we call it with argument 4.
    assert plus1(4) == 5
    # Our "plus" function should return 6 if we call it with argument 5.
    assert plus1(5) == 6
    # Our "plus" function should return 5 if we call it with argument 4.
    assert plus1(4) == 5
    # Our "plus" function should return 4 if we call it with argument 3.
   

# Generated at 2022-06-26 00:19:27.060206
# Unit test for function cond
def test_cond():
    """
    Test for cond function
    """

    condition_function_0 = cond(
        [(lambda x: x == 0, lambda _: 1), (lambda x: x == 1, lambda _: 0)]
    )

    assert condition_function_0(0) == 1, 'Test 0 Failed'
    assert condition_function_0(1) == 0, 'Test 1 Failed'



# Generated at 2022-06-26 00:19:28.544608
# Unit test for function eq
def test_eq():
    assert eq(1, 2) == False
    assert eq(1, 1) == True


# Generated at 2022-06-26 00:19:35.067177
# Unit test for function curry
def test_curry():
    @curry
    def fn(x, y):
        return x + y

    assert fn(1)(2) == 3
    assert fn(1, 2) == 3
    assert fn(1)(1)(1)(1)(1)(1) == 6
    assert fn(1)(1)(1)(1)(1)(2) == 7

    assert fn(1)(1)(1)(1) == 4
    assert fn(1)(1)(1)(2) == 5
    assert fn(1)(1)(2) == 4
    assert fn(1)(2) == 3

    assert fn(1, 1) == 2
    assert fn(1, 2) == 3
    assert fn(1, 3) == 4
    assert fn(1, 4) == 5
    assert fn(1, 5) == 6
    assert fn(1, 6) == 7

# Generated at 2022-06-26 00:19:40.691701
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert eq([], [])
    assert not eq('', '')
    assert not eq('', [])



# Generated at 2022-06-26 00:19:57.624257
# Unit test for function memoize
def test_memoize():
    functions = [
        identity,
        lambda x: x+1,
        lambda x: x+2,
        lambda x: x*10,
        lambda x: x*100,
        lambda x: x**2,
        lambda x: x**3,
        lambda x,y: x+y,
        lambda x,y,z: x+y+z,
    ]
    for fn in functions:
        not_memoed_fn = fn
        memoed_fn = memoize(not_memoed_fn)
        for i in range(50):
            assert (memoed_fn(i) == not_memoed_fn(i))
        for i in range(50):
            assert (memoed_fn(i) == memoed_fn(i))



# Generated at 2022-06-26 00:20:07.463912
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq(1, 2, 3) == False
    assert eq(1, 1, 1, 1) == True
    assert eq(1)(1) == True
    assert eq(1)(2) == False
    assert eq(1)(2, 3) == False
    assert eq(1)(1, 1, 1) == True
    assert eq(1, 2)(3, 4) == False
    assert eq(1, 1)(1, 1)(1) == True
    assert eq(1)(2)(3, 4) == False
    assert eq(1)(2)(3)(4, 5) == False
    assert eq(1)(1)(1)(1, 1) == True
    return "test_eq finished sucessfully"



# Generated at 2022-06-26 00:20:12.019826
# Unit test for function memoize
def test_memoize():
    from time import time
    from random import random

    start_time_0 = time()
    for i in range(100000):
        res_0 = memoized_fn(random())
    end_time_0 = time()
    time_0 = end_time_0 - start_time_0
    print("memoized time: " + str(time_0))

    start_time_1 = time()
    for i in range(100000):
        res_1 = fn(random())
    end_time_1 = time()
    time_1 = end_time_1 - start_time_1
    print("non-memoized time: " + str(time_1))

    assert time_1 > time_0
    assert res_0 == res_1


# Generated at 2022-06-26 00:20:16.362716
# Unit test for function memoize
def test_memoize():
    var_0 = curry(memoize)(increase)
    var_1 = var_0(1)
    var_2 = var_0(1)
    var_3 = var_0(2)

    assert var_1 == 2
    assert var_2 == 2
    assert var_3 == 3



# Generated at 2022-06-26 00:20:18.534995
# Unit test for function curry
def test_curry():
    fn = curry(lambda x, y: x + y)
    assert fn(5)(5) == 10, "Not equal 10"



# Generated at 2022-06-26 00:20:27.767939
# Unit test for function memoize
def test_memoize():
    cache = []

    def get_cache():
        return cache

    def fn():
        cache.append(0)
        return 1

    fn_memoized = memoize(fn)

    assert get_cache() == []
    assert fn_memoized(0) == 1
    assert get_cache() == [(0, 1)]
    assert fn_memoized(1) == 1
    assert get_cache() == [(0, 1), (1, 1)]
    assert fn_memoized(0) == 1
    assert get_cache() == [(0, 1), (1, 1)]
    assert fn_memoized(1) == 1
    assert get_cache() == [(0, 1), (1, 1)]
    assert fn_memoized(2) == 1

# Generated at 2022-06-26 00:20:34.803376
# Unit test for function curried_filter
def test_curried_filter():
    not_none = curried_filter(lambda item: item is not None)
    is_number = curried_filter(lambda item: type(item) is int)
    is_five = curried_filter(lambda item: item == 5)

    assert not_none([None, None, 5, 'a', None]) == [5, 'a']
    assert is_number([1, 2, None, 'a', 4]) == [1, 2, 4]
    assert is_five([1, 5, 'a', 5, None]) == [5, 5]


# Generated at 2022-06-26 00:20:47.250447
# Unit test for function memoize
def test_memoize():
    # Create double_num with lambda as argument
    double_num = lambda x: x * 2

    # Memoize double_num function
    memoized_double_num = memoize(double_num)
    # Assert function has been changed
    assert memoized_double_num(2) == 4
    # Assert function has been changed
    assert memoized_double_num(3) == 6
    # Assert same input will be return from cash
    assert memoized_double_num(2) == 4

    # Memoize double_num function
    memoized_double_num = memoize(double_num, key=eq)
    # Assert function has been changed
    assert memoized_double_num(2) == 4
    # Assert function has been changed
    assert memoized_double_num(3) == 6
    #

# Generated at 2022-06-26 00:20:52.350351
# Unit test for function eq
def test_eq():
    assert curry(eq, 2)(1, 2)
    assert curry(eq, 2)(1, 2)
    assert not curry(eq, 2)(1, 's')
    assert curry(eq, 2)('s', 's')
    assert eq(1, 1)
    assert eq('s', 's')
    assert not eq(1, 's')
    assert not eq(1, 2)



# Generated at 2022-06-26 00:20:54.252915
# Unit test for function curried_map
def test_curried_map(): # Test success
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-26 00:21:11.541047
# Unit test for function memoize
def test_memoize():
    c: int = 0

    @memoize
    def fn(a):
        """
        Return increased c variable and a variable.

        :param a:
        :type a: Int
        :returns:
        :rtype: Int
        """
        nonlocal c
        c += 1
        return a + c
    assert fn(1) == 2
    assert fn(1) == 2
    assert c == 1
    assert fn(2) == 3
    assert fn(2) == 3
    assert c == 2
    assert fn(1) == 2
    assert fn(1) == 2
    assert c == 2
    assert fn(3) == 4
    assert fn(3) == 4
    assert c == 3



# Generated at 2022-06-26 00:21:14.916666
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4]) == [2, 4]



# Generated at 2022-06-26 00:21:23.459005
# Unit test for function cond
def test_cond():
    def func_true(value):
        if value % 2 == 0:
            return True
        return False

    def func_false(value):
        if value % 2 == 0:
            return False
        return True

    func_true_wrong_arguments_type = (1, 2)
    func_false_wrong_arguments_type = (1, 2)
    func_true_correct_arguments_type = 6
    func_false_correct_arguments_type = 5

    assert cond([(func_true_correct_arguments_type, func_true)]) == cond([(func_true_wrong_arguments_type, func_true)]), 'wrong func true'

# Generated at 2022-06-26 00:21:28.810935
# Unit test for function cond
def test_cond():
    # unit test for cond
    def is_even(number):
        return number % 2 == 0

    def is_odd(number):
        return not is_even(number)

    def square(number):
        return number * number

    def cube(number):
        return number * number * number

    assert 3 == cond([(is_even, square), (is_odd, cube)])(3)



# Generated at 2022-06-26 00:21:33.432881
# Unit test for function cond
def test_cond():
    condition_list = [
        (identity, lambda x: x + 1),
        (lambda x: x == 0, lambda x: x)
    ]
    assert cond(condition_list)(0) == 0

    assert cond(condition_list)(-1) == 0

    assert cond(condition_list)(1) == 2

    assert cond(condition_list)(5) == 6



# Generated at 2022-06-26 00:21:41.408298
# Unit test for function memoize
def test_memoize():
    global fn
    fn = lambda value: value + 1
    fn_memoized = memoize(fn)
    assert fn_memoized(2) == 3
    assert fn_memoized(2) == 3
    assert fn_memoized(3) == 4

    fn = lambda value: value + 1
    fn_memoized = memoize(fn, key=lambda value, key: value == key)
    assert fn_memoized(2) == 3
    assert fn_memoized(2) == 3
    assert fn_memoized(3) == 4
# End unit test for function memoize



# Generated at 2022-06-26 00:21:44.992882
# Unit test for function memoize
def test_memoize():
    def fn(arg):
        return arg

    test_fn = memoize(fn)
    assert test_fn("1") == "1"
    assert test_fn("2") == "2"
    assert test_fn("1") == "1"



# Generated at 2022-06-26 00:21:46.851779
# Unit test for function cond
def test_cond():
    c = cond([(eq(True), lambda a: True)])
    assert c(True)



# Generated at 2022-06-26 00:21:50.682731
# Unit test for function memoize
def test_memoize():
    def factorial(n):
        return 1 if n == 0 else reduce(lambda a, b: a*b, range(1, n+1))

    factorial_memoized = memoize(factorial)

    assert factorial_memoized(5) == 120
    assert factorial_memoized(5) == 120



# Generated at 2022-06-26 00:21:55.092583
# Unit test for function memoize
def test_memoize():
    mock_fn = lambda number: number**2

    memoized_fn = memoize(mock_fn)
    assert memoized_fn(2) == 4
    assert memoized_fn(3) == 9
    assert memoized_fn(2) == 4
    assert memoized_fn(3) == 9



# Generated at 2022-06-26 00:22:05.382585
# Unit test for function find
def test_find():
    collection = [1, 2, 3]

    def key(value): return value == 2

    assert find(collection, key) == 2
    assert find(collection, lambda value: value == 10) is None
    assert find([], key) is None



# Generated at 2022-06-26 00:22:07.919348
# Unit test for function memoize
def test_memoize():
    def factorial(n):
        return factorial(n - 1) * n if n > 1 else 1

    factorial_memo = memoize(factorial)
    assert factorial(4) == 24
    assert factorial(4) == 24
    assert factorial(4) == 24
    assert factorial(4) == 24
    print('Test for function memoize successfully finished')



# Generated at 2022-06-26 00:22:12.061600
# Unit test for function curried_filter
def test_curried_filter():
    c_1 = [1, 2, 3, 4]
    c_2 = [2, 3]
    c_3 = [1, 4]
    eq(curried_filter(lambda x: x % 2 == 0)(c_1), c_2)
    eq(curried_filter(lambda x: x % 2 != 0)(c_1), c_3)



# Generated at 2022-06-26 00:22:13.949616
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4]) == [2, 4]



# Generated at 2022-06-26 00:22:17.481950
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda n: n == 2) == 2
    assert find([1, 2, 3], lambda n: n == 5) is None
    assert find([1, 2, 3], eq(5)) is None
    assert find([1, 2, 3], eq(2)) == 2



# Generated at 2022-06-26 00:22:23.330473
# Unit test for function find
def test_find():
    # Condition when find nothing
    find_result = find([1, 2], (lambda x: x == 3))
    assert find_result is None
    # Condition when find one value
    find_result = find([1, 2], (lambda x: x == 1))
    assert find_result == 1
    # Condition when find several values
    find_result = find([1, 2], (lambda x: x == 1 or x == 2))
    assert find_result == 1



# Generated at 2022-06-26 00:22:29.679519
# Unit test for function cond
def test_cond():
    # Test 1
    condition_list = [
        (eq(1), increase),
        (eq(2), increase),
    ]
    result = cond(condition_list)(1)

    assert result == 2

    # Test 2
    condition_list = [
        (eq(2), identity),
        (eq(1), increase),
    ]
    result = cond(condition_list)(1)

    assert result == 1

    # Test 3
    condition_list = [
        (eq(2), identity),
        (eq(2), increase),
    ]
    result = cond(condition_list)(2)

    assert result == 3



# Generated at 2022-06-26 00:22:35.265457
# Unit test for function eq
def test_eq():
    assert curry(eq, 2)(1, 2) == True
    assert curry(eq, 2)(1, 3) == False
    assert curry(eq, 2)(1, 1) == False



# Generated at 2022-06-26 00:22:39.264835
# Unit test for function curried_filter
def test_curried_filter():
    assert [0, 2] == curried_filter(lambda x: x % 2 == 0, [0, 1, 2, 3])
    assert [] == curried_filter(lambda x: x % 2 == 0, [1, 3])
    assert [] == curried_filter(lambda x: x % 2 == 0, [])



# Generated at 2022-06-26 00:22:53.554312
# Unit test for function memoize
def test_memoize():
    var_0 = memoize(identity, eq)

    assert var_0("a") == "a", "Memoize check error 1"
    var_1 = var_0("a")

    assert var_1 == "a", "Memoize check error 2"
    var_2 = memoize(identity, eq)
    var_3 = var_2("a")

    assert var_3 == "a", "Memoize check error 3"
    var_4 = memoize(identity, eq)
    var_5 = var_4("a")

    assert var_5 == "a", "Memoize check error 4"

    memoized = memoize(identity, eq)
    memoized1 = memoized(1)

    assert memoized1 == 1, "Memoize check error 5"

# Generated at 2022-06-26 00:23:07.992625
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b, c: a + b + c)(1)(2)(3) == 6



# Generated at 2022-06-26 00:23:16.859550
# Unit test for function cond
def test_cond():
    is_greater_than_5 = lambda x: x > 5
    is_greater_than_10 = lambda x: x > 10
    is_greater_than_15 = lambda x: x > 15

    print('Test case 0:')
    print(cond(
        [
            (is_greater_than_5, lambda x: 'Greater than 5!'),
            (is_greater_than_10, lambda x: 'Greater than 10!'),
            (is_greater_than_15, lambda x: 'Greater than 15!')
        ]
    )(6))

    print()

    print('Test case 1:')

# Generated at 2022-06-26 00:23:21.494884
# Unit test for function memoize
def test_memoize():
    global var_0
    var_0 = 0
    def fn():
        global var_0
        print(var_0)
        if var_0 == 0:
            var_0 += 1
            return 1
        else:
            return 0
    result = memoize(fn)
    assert result(0) == 1
    assert result(0) == 1
    assert result(1) == 0
    assert result(0) == 1



# Generated at 2022-06-26 00:23:22.894878
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(5), range(5)) == [5]



# Generated at 2022-06-26 00:23:24.267890
# Unit test for function eq
def test_eq():
    assert(eq(1, 1) == True)
    assert(eq(2, 3) == False)


# Generated at 2022-06-26 00:23:29.046418
# Unit test for function memoize
def test_memoize():
    f = memoize(lambda x: x ** 2)

    assert f(2) == 4, "f(2) = 4"
    assert f(2) == 4, "f(2) = 4, second call"
    assert f(3) == 9, "f(3) = 9"
    assert f(3) == 9, "f(3) = 9, second call"
    assert f(2) == 4, "f(2) = 4, third call"



# Generated at 2022-06-26 00:23:31.428523
# Unit test for function memoize
def test_memoize():
    var_0 = identity(0)
    var_1 = memoize(identity)
    var_2 = var_1(0)

    assert var_0 == var_2



# Generated at 2022-06-26 00:23:39.316475
# Unit test for function cond
def test_cond():
    def is_empty(collection: List[int]) -> bool:
        return collection.__len__() == 0

    def always_true(collection: List[int]) -> bool:
        return True

    def get_first(collection: List[int]):
        return collection[0]

    def always_return_error(collection: List[int]):
        raise ValueError('Collection is empty')

    cond_function = cond([
        (is_empty, always_return_error),
        (always_true, get_first),
    ])

    assert cond_function([5, 10, 15]) == 5
    with pytest.raises(ValueError):
        cond_function([])



# Generated at 2022-06-26 00:23:42.766535
# Unit test for function find
def test_find():
    assert (find([1, 2, 3, 4, 5], lambda x: x % 2 == 0)) == 2
    assert (find([1, 2, 3, 4, 5], lambda x: x % 2 == 1)) == 1
    assert (find([1, 2], lambda x: x == 3)) is None



# Generated at 2022-06-26 00:23:46.895892
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([[1], [2], [3]], lambda x: x[0] == 2) == [2]
    assert find([], lambda x: x == 1) is None
    assert find([2, 3, 4], lambda x: x == 1) is None

# Generated at 2022-06-26 00:24:18.664348
# Unit test for function memoize
def test_memoize():
    global count
    count = 0

    def fn():
        global count
        count += 1
        return 'done'

    mn = memoize(fn)

    assert 'done' == mn()
    assert 1 == count
    assert 'done' == mn()
    assert 1 == count



# Generated at 2022-06-26 00:24:26.573692
# Unit test for function memoize
def test_memoize():
    assert memoize(identity)(1) == 1
    assert memoize(identity)(1) == 1
    assert memoize(identity)[1]() == 1
    assert memoize(identity)[1]() == 1
    assert memoize(identity)[1, 2]() == 1
    assert memoize(identity)[1, 2]() == 1
    assert memoize(identity, key=lambda x, y: x == y)(1, 2) == 1
    assert memoize(identity, key=lambda x, y: x == y)(1, 2) == 1
    assert memoize(identity, key=lambda x, y: x == y)(2, 2) == 2
    assert memoize(identity, key=lambda x, y: x == y)(1, 1) == 1

# Generated at 2022-06-26 00:24:28.262449
# Unit test for function curried_map
def test_curried_map():
    assert(curried_map(increase)([1, 2, 3])) == [2, 3, 4]



# Generated at 2022-06-26 00:24:32.367081
# Unit test for function curried_filter
def test_curried_filter():
    assert [2, 3] == curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4])
    assert [2, 3] == curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4])
    assert [2, 3] == curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4])



# Generated at 2022-06-26 00:24:38.365087
# Unit test for function cond
def test_cond():
    def fn_1(x):
        return x + 1

    def fn_2(x):
        return x + 2

    def fn_3(x):
        return x + 3

    result_fn = cond(
        [
            (lambda x: x > 1, fn_1),
            (lambda x: x > 2, fn_2),
            (lambda x: x > 3, fn_3),
        ]
    )

    assert result_fn(2) == 3
    assert result_fn(3) == 5
    assert result_fn(4) == 7



# Generated at 2022-06-26 00:24:45.977990
# Unit test for function eq
def test_eq():
    assert eq(True, True)
    assert not eq(True, False)
    assert not eq(False, True)
    assert eq(False, False)

    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(2, 1)
    assert eq(2, 2)

    assert not eq(1, True)
    assert not eq(True, 1)
    assert not eq(1, False)
    assert not eq(False, 1)
    assert not eq('a', False)
    assert not eq(False, 'a')
    assert not eq(1, 'a')
    assert not eq('a', 1)

    assert not eq('1', True)
    assert not eq(True, '1')
    assert not eq('1', False)
    assert not eq(False, '1')

# Generated at 2022-06-26 00:24:54.094253
# Unit test for function memoize
def test_memoize():
    from random import randint
    from time import time

    def fn_0(x):
        time()
        time()
        time()
        return x

    fn_1 = memoize(fn_0)

    def fn_2(x):
        time()
        time()
        time()
        return x

    fn_3 = memoize(fn_2)

    rnd_0 = randint(0, 1000)
    rnd_1 = randint(0, 1000)
    rnd_2 = randint(0, 1000)

    start = time()
    assert (fn_1(rnd_0) == rnd_0)
    assert (fn_1(rnd_0) == rnd_0)
    assert (fn_3(rnd_1) == rnd_1)

# Generated at 2022-06-26 00:24:57.419775
# Unit test for function find
def test_find():
    list_0: List[int] = [1, 2, 3, 4, 5]
    assert find(list_0, lambda item: item == 3) == 3
    list_1: List[int] = [1, 2, 3, 4, 5]
    assert find(list_1, lambda item: item == 6) is None



# Generated at 2022-06-26 00:24:59.714389
# Unit test for function memoize
def test_memoize():
    def used_function(a):
        return a + 1

    used_function = memoize(used_function)
    assert used_function(0) == 1
    assert used_function(0) == 1



# Generated at 2022-06-26 00:25:08.117273
# Unit test for function cond
def test_cond():
    """
    Function for return function depended on first function argument
    cond get list of two-item tuples,
    first is condition_function, second is execute_function.
    Returns this execute_function witch first condition_function return truly value.
    """
    test_case_0()
    var_0 = cond([(lambda x: x == 1, lambda x: 2), (lambda x: x == 2, lambda x: 3), (lambda x: x == 3, lambda x: 4)])
    var_1 = var_0(1)
    # 2
    var_0 = cond([(lambda x: x == 1, lambda x: 2), (lambda x: x == 2, lambda x: 3), (lambda x: x == 3, lambda x: 4)])
    var_1 = var_0(2)
    # 3
    var_0

# Generated at 2022-06-26 00:25:48.508495
# Unit test for function memoize
def test_memoize():
    cache = []

    def fn():
        return 123

    m_fn = memoize(fn)

    assert cache == [], "Function memoize must not invoke function fn after initialization"
    assert m_fn() == 123, "Function memoize must return result of calling fn"
    assert cache == [(()), 123], "Function memoize must save result of calling fn if it is called first time"
    assert m_fn() == 123, "Function memoize must return result of calling fn saved into cache"
    assert cache == [(()), 123], "Function memoize must return result of calling fn without calling fn"
    assert m_fn(1) == 123, "Function memoize must return result of calling fn"
    assert cache == [(()), 123, (1,), 123], "Function memoize must return result of calling fn"

# Generated at 2022-06-26 00:25:53.103388
# Unit test for function find
def test_find():
    coll = [4,3,2,1]
    eq = lambda x: x == 2
    eq1 = lambda x: x == 5
    eq2 = lambda x: x == 3
    eq3 = lambda x: x == 1
    eq4 = lambda x: x == 0
    assert find(coll, eq) == 2
    assert find(coll, eq1) is None
    assert find(coll, eq2) == 3
    assert find(coll, eq3) == 1
    assert find(coll, eq4) is None



# Generated at 2022-06-26 00:25:55.910904
# Unit test for function curry
def test_curry():
    add = curry(lambda x, y: x + y)
    add_five = add(5)
    assert add_five(1) == 6
    assert add_five(2) == 7
    assert add_five(3) == 8



# Generated at 2022-06-26 00:25:57.746397
# Unit test for function curried_map
def test_curried_map():
    test_case_1()
    test_case_2()


# Generated at 2022-06-26 00:26:00.142645
# Unit test for function curried_filter
def test_curried_filter():
    # Test 0
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3])([1, 2, 3]) == [2]



# Generated at 2022-06-26 00:26:04.274139
# Unit test for function curried_map
def test_curried_map():
    add1 = lambda x: x + 1
    assert curried_map(add1, [])([1]) == [2]
    assert curried_map(add1, [1])([1, 2, 3]) == [2, 3, 4]
    assert curried_map(add1, [1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-26 00:26:07.171526
# Unit test for function cond
def test_cond():
    f = cond([
        (lambda x: x % 2 == 0, lambda x: x + 2),
        (lambda x: x % 2 != 0, lambda x: x + 1)
    ])
    assert f(3) == 4
    assert f(4) == 6



# Generated at 2022-06-26 00:26:14.320607
# Unit test for function curried_map
def test_curried_map():
    assert cond([
        (lambda x, y: x == y, identity),
        (lambda x, y: True, increase)
    ])(0, 0) == 0
    assert cond([
        (lambda x, y: x == y, identity),
        (lambda x, y: True, increase)
    ])(0, 1) == 1
    assert cond([
        (lambda x, y: x == y, identity),
        (lambda x, y: True, increase)
    ])(1, 0) == 1
    assert cond([
        (lambda x, y: x == y, identity),
        (lambda x, y: True, increase)
    ])(1, 1) == 1



# Generated at 2022-06-26 00:26:20.624577
# Unit test for function cond
def test_cond():
    is_even = lambda x: x % 2 == 0
    is_positive = lambda x: x > 0
    add_5 = lambda x: x + 5
    multiply_5 = lambda x: x * 5
    div_5 = lambda x: int(x/5)

    assert cond([(is_even, add_5), (is_positive, multiply_5)])(-5) == -5
    assert cond([(is_even, add_5), (is_positive, multiply_5)])(10) == 15
    assert cond([(is_even, div_5), (is_positive, multiply_5)])(10) == 2



# Generated at 2022-06-26 00:26:28.997421
# Unit test for function cond
def test_cond():
    def condition_0(value):
        return value > 10

    def condition_1(value):
        return value == 10

    def condition_2(value):
        return value < 10

    var_0 = cond([
        (condition_0, increase),
        (condition_1, identity),
        (condition_2, identity),
    ])(0)
    assert var_0 == 0

    var_1 = cond([
        (condition_0, identity),
        (condition_1, increase),
        (condition_2, identity),
    ])(10)
    assert var_1 == 11

    var_2 = cond([
        (condition_0, identity),
        (condition_1, identity),
        (condition_2, increase),
    ])(11)
    assert var_2 == 12



# Generated at 2022-06-26 00:27:49.243275
# Unit test for function eq
def test_eq():
    assert eq(eq(1, 1), True)



# Generated at 2022-06-26 00:27:56.191790
# Unit test for function memoize
def test_memoize():
    # Arrange
    var_0 = memoize(identity)(0)
    var_1 = memoize(identity)(0)
    var_2 = memoize(identity)(1)
    var_3 = memoize(identity)(0)
    var_4 = memoize(identity)(1)

    # Assert
    if not var_0 == var_1 == var_3 == 0:
        raise AssertionError("fn_0() !== fn_1() !== fn_3()")

    if not var_2 == var_4 == 1:
        raise AssertionError("fn_2() !== fn_4()")



# Generated at 2022-06-26 00:28:01.409670
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x % 2 == 0, lambda x: x / 2),
        (lambda x: x % 2 != 0, lambda x: x * 2)
    ])(1) == 2
    assert cond([
        (lambda x: x % 2 == 0, lambda x: x / 2),
        (lambda x: x % 2 != 0, lambda x: x * 2)
    ])(2) == 1



# Generated at 2022-06-26 00:28:06.660063
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x % 2 == 0, lambda x: x // 2),
        (lambda x: True, lambda x: x * 3 + 1),
    ])(3) == 10



# Generated at 2022-06-26 00:28:12.434169
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [])([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-26 00:28:16.737376
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1, 1, 3)
    assert not eq(1, 2, 3)
    assert eq(1, 1, 2)
    assert not eq(1, 2, 2)
    assert not eq(1, 2, 2, 3)
    assert not eq(1, 2, 3, 3)


# Generated at 2022-06-26 00:28:22.634954
# Unit test for function cond
def test_cond():
    condition_list = [
        (lambda value: value > 10, lambda value: 'greater then 10'),
        (lambda value: value < 0, lambda value: 'less than 0'),
        (lambda value: value == 0, lambda value: 'equal 0')
    ]

    f_cond = cond(condition_list)

    assert f_cond(11) == 'greater then 10'
    assert f_cond(-1) == 'less than 0'
    assert f_cond(0) == 'equal 0'
    assert f_cond(1) is None



# Generated at 2022-06-26 00:28:28.157365
# Unit test for function curried_filter
def test_curried_filter():
    """
    Test for function curried_filter.

    :returns: True if tests passed, else False
    :rtype: Boolean
    """
    test_data = [
        [
            [1, 2, 3, 4],
            lambda item: item % 2 == 0,
            [2, 4],
        ],
        [
            [],
            lambda item: True,
            [],
        ],
        [
            ['123', 'qwerty', 'qwerty'],
            lambda item: len(item) == 6,
            ['qwerty'],
        ],
    ]
    for (collection, filterer, expected) in test_data:
        assert curried_filter(filterer)(collection) == expected
    return True

