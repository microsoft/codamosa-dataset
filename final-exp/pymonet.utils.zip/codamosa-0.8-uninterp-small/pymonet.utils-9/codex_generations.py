

# Generated at 2022-06-26 00:18:32.437682
# Unit test for function cond
def test_cond():
    eq_ = cond([
        (lambda x: x > 0, increase),
        (lambda x: x < 0, lambda x: x),
        (lambda x: True, lambda x: x+1)
    ])
    assert eq_(-1) == -1
    assert eq_(0) == 1
    assert eq_(1) == 2


# Generated at 2022-06-26 00:18:34.742497
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 0, [-1, 1, 2, -3]) == [1, 2]


# Generated at 2022-06-26 00:18:37.817022
# Unit test for function curried_filter
def test_curried_filter():
    list_0 = [1, 2, 3, 4, 5]
    var_0 = curried_filter(lambda var_0: var_0 < 3, list_0)
    assert var_0 == [1, 2]


# Generated at 2022-06-26 00:18:40.444539
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-26 00:18:45.300877
# Unit test for function cond
def test_cond():
    assert cond(
        [
            (eq(1), lambda x: '1'),
            (eq(2), lambda x: '2')
        ]
    )(1) == '1'

    assert cond(
        [
            (eq(1), lambda x: '1'),
            (eq(2), lambda x: '2')
        ]
    )(2) == '2'



# Generated at 2022-06-26 00:18:46.617487
# Unit test for function find
def test_find():
    find_0 = lambda x: x == 3
    find_1 = find([1, 2, 3, 4], find_0)
    assert find_1 == 3


# Generated at 2022-06-26 00:19:01.656209
# Unit test for function curried_filter
def test_curried_filter():
    list_a = [0, 1, 2, 3, 4, 5]
    list_b = [0, 2, 4]
    list_c = [5, 4, 3, 2, 1, 0]

    """ Test filter with list of even numbers """
    assert(curried_filter(lambda n: n % 2 == 0, list_a) == list_b)

    """ Test filter with list of even numbers """
    assert(curried_filter(lambda n: n % 2 == 0)(list_a) == list_b)

    """ Test filter with list of even numbers with reversed argument order """
    assert(curried_filter(list_a)(lambda n: n % 2 == 0) == list_b)

    """ Test filter with list of even numbers """

# Generated at 2022-06-26 00:19:06.902121
# Unit test for function cond
def test_cond():
    assert cond([
                (lambda x: x < 3, lambda x: x)
            ])(0) == 0
    assert cond([
                (lambda x: x < 3, lambda x: x),
                (lambda x: x > 3, lambda x: x)
            ])(2) == 2
    assert cond([
                (lambda x: x < 3, lambda x: x),
                (lambda x: x > 3, lambda x: x)
            ])(4) == 4
    assert cond([
                (lambda x: x < 3, lambda x: x),
                (lambda x: x > 3, lambda x: x),
                (lambda x: x == 3, lambda x: x)
            ])(3) == 3

# Generated at 2022-06-26 00:19:07.574884
# Unit test for function eq
def test_eq():
    assert eq(3, 3)
    assert not eq(3, 4)



# Generated at 2022-06-26 00:19:09.084444
# Unit test for function cond
def test_cond():
    assert cond([(lambda x: x == 2, lambda x: x)], 2) == 2


# Generated at 2022-06-26 00:19:14.154577
# Unit test for function curry
def test_curry():
    idFunction = curry(identity)
    curried_id = idFunction()
    assert curried_id(2) == 2



# Generated at 2022-06-26 00:19:21.576888
# Unit test for function memoize
def test_memoize():
    """
    >>> @memoize
    ... def factorial(n):
    ...     return 1 if n < 2 else n * factorial(n-1)
    >>> factorial(10)
    3628800
    >>> factorial(10)
    3628800
    """


if __name__ == "__main__":
    doctest.testmod()

# Generated at 2022-06-26 00:19:23.192504
# Unit test for function eq
def test_eq():
    assert eq(True, True)
    assert not(eq(True, False))


# Generated at 2022-06-26 00:19:28.432084
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], eq(3)) == 3, '3 should be found in the list'
    assert find([1, 2, 3, 4], eq(10)) is None, '10 should not be found in the list'

    assert find([{'a': 10}, {'b': 20}],
                lambda item: item.get('a') == 10) == {'a': 10}, 'item with key should be found'



# Generated at 2022-06-26 00:19:32.622887
# Unit test for function eq
def test_eq():
    print('eq test case')

    assert True is (eq(1, 1))
    assert True is (eq(True, True))
    assert True is (eq(0.0, 0.0))
    assert True is (eq('', ''))



# Generated at 2022-06-26 00:19:34.654735
# Unit test for function curried_map
def test_curried_map():
    assert [2, 3, 4] == curried_map(lambda x: x + 1, [1, 2, 3])



# Generated at 2022-06-26 00:19:47.688550
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq(1, True) == True
    assert eq(1, False) == False
    assert eq(True, True) == True
    assert eq(True, False) == False
    assert eq(False, False) == True
    assert eq(False, True) == False
    assert eq(['a', 'b', 'c'], ['a', 'b', 'c']) == True
    assert eq(['a', 'b'], ['a', 'b', 'c']) == False
    assert eq(['a', 'b', 'c'], ['a', 'b', 'd']) == False
    assert eq(['a', 'b', 'c'], ['a', 'b']) == False

# Generated at 2022-06-26 00:19:53.083248
# Unit test for function curried_filter
def test_curried_filter():
    test_var_0 = [1, 2, 3, 5, 6]
    test_var_1 = curried_filter(lambda x: x == 2, test_var_0)
    test_var_2 = curried_filter(lambda x: x > 3, test_var_0)
    assert test_var_1 == [2]
    assert test_var_2 == [5, 6]



# Generated at 2022-06-26 00:20:03.409639
# Unit test for function memoize
def test_memoize():
    # setup
    fibonacci_numbers = [0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765, 10946]

    def fibonacci(n):
        if n < 2:
            return n
        return fibonacci(n - 1) + fibonacci(n - 2)

    fibonacci_recursive = memoize(fibonacci)

    # execute
    fibonacci_memoized = fibonacci_recursive(20)

    # assert
    assert fibonacci_memoized == fibonacci_numbers[20]
    assert fibonacci(20) == fibonacci_numbers[20]

# Generated at 2022-06-26 00:20:05.360665
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, range(6)) == [0, 2, 4]


# Generated at 2022-06-26 00:20:13.002761
# Unit test for function memoize
def test_memoize():
    assert memoize(lambda x: x * 2)(3) == 6
    assert memoize(lambda x: x * 2)(3) == 6



# Generated at 2022-06-26 00:20:17.393902
# Unit test for function memoize
def test_memoize():
    assert (memoize(lambda x: x + 1)(1) == 2)
    assert (memoize(lambda x: x + 1)(1) == 2)
    assert (memoize(lambda x: x + 1)(2) == 3)
    assert (memoize(lambda x: x + 1)(2) == 3)



# Generated at 2022-06-26 00:20:19.035715
# Unit test for function memoize
def test_memoize():
    assert memoize(identity(1)) == 1
    assert memoize(identity, key=increase)(3) == 3

# Generated at 2022-06-26 00:20:21.605324
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, range(10)) == [0, 2, 4, 6, 8], \
        'It should return even numbers from 0 to 10'



# Generated at 2022-06-26 00:20:25.212240
# Unit test for function find
def test_find():
    # test with no elements
    assert find([], lambda x: True) is None
    # test with one element
    assert find([1], lambda x: x == 1) == 1
    # test with few elements
    assert find([2, 3, 4], lambda x: x == 3) == 3



# Generated at 2022-06-26 00:20:27.186924
# Unit test for function eq
def test_eq():
    eq_test = eq(1, 1)
    assert eq_test == True


# Generated at 2022-06-26 00:20:30.790160
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert (curried_eq(1)(2) == False)
    assert (curried_eq(1)(1) == True)



# Generated at 2022-06-26 00:20:34.601376
# Unit test for function cond
def test_cond():
    def fn1(a: int):
        return a

    # Return value from fn1 if argument positive
    cond_fn = cond([
        (lambda arg: arg >= 0, fn1)
    ])

    assert None is cond_fn(-5)
    assert 10 is cond_fn(10)



# Generated at 2022-06-26 00:20:42.189048
# Unit test for function memoize
def test_memoize():
    var_0 = lambda var_1: var_1
    var_0 = memoize(var_0)  # var_0 is function(var_1 : int) -> int
    var_0(var_1=0)  # todo probably this expression must be more complex
    var_0(var_0=0)  # todo probably this expression must be more complex


# Generated at 2022-06-26 00:20:51.411793
# Unit test for function cond
def test_cond():
    var_2 = cond([
        (lambda value: value == 1,
         lambda value: "Zero"),
        (lambda value: value == 5,
         lambda value: "Five"),
        (lambda value: True,
         lambda value: "Other")
    ])

    assert var_2(1) == "Zero"
    assert var_2(2) == "Other"
    assert var_2(5) == "Five"

    var_3 = cond([
        (lambda value: value == "Zero",
         lambda value: "Zero"),
        (lambda value: value == "Five",
         lambda value: "Five"),
        (lambda value: True,
         lambda value: "Other")
    ])("Zero")

    assert var_3 == "Zero"



# Generated at 2022-06-26 00:21:00.047766
# Unit test for function cond
def test_cond():

    def is_zero(number: int) -> bool:
        return number == 0

    def is_odd(number: int) -> bool:
        return number % 2 == 1

    def is_even(number: int) -> bool:
        return number % 2 == 0

    def is_negative(number: int) -> bool:
        return number < 0

    def test_case_0():
        get_message = cond(
            [
                (is_zero, identity),
                (is_odd, lambda number: 'Odd number'),
                (is_even, lambda number: 'Even number'),
                (is_negative, lambda number: 'Negative number')
            ]
        )
        assert 'Odd number' == get_message(3)


# Generated at 2022-06-26 00:21:03.748537
# Unit test for function curried_filter
def test_curried_filter():
    """
    Test curried_filter function.
    """
    assert curried_filter(eq(0))([1, 2, 3, 0, 5]) == [0]
    assert curried_filter(eq(0), [1, 2, 3, 0, 5]) == [0]


# Generated at 2022-06-26 00:21:11.906354
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda _: True, lambda x: x + 1),
        (lambda _: False, lambda x: x - 1),
    ])(0) == 1
    assert cond([
        (lambda _: False, lambda x: x + 1),
        (lambda _: True, lambda x: x - 1),
    ])(0) == -1
    assert cond([
        (lambda _: True, lambda x: x + 1),
        (lambda _: False, lambda x: x + 1),
        (lambda _: True, lambda x: x - 1),
        (lambda _: True, lambda x: x + 2),
    ])(0) == -1



# Generated at 2022-06-26 00:21:20.725038
# Unit test for function cond
def test_cond():
    """Test cond function."""

    func_1 = cond([
                    (lambda arg: arg == 'a', lambda arg: 'alpha'),
                    (lambda arg: arg == 'b', lambda arg: 'bravo'),
                    (lambda arg: arg == 'c', lambda arg: 'charlie'),
                    (lambda arg: arg == 'd', lambda arg: 'delta'),
                    (lambda arg: arg == 'e', lambda arg: 'echo'),
                    (lambda arg: arg == 'f', lambda arg: 'foxtrot'),
                ])

    assert func_1('a') == 'alpha'
    assert func_1('b') == 'bravo'
    assert func_1('c') == 'charlie'
    assert func_1('d') == 'delta'
    assert func_1('e') == 'echo'
   

# Generated at 2022-06-26 00:21:23.953181
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert curried_map(lambda x: x * 2)([1, 2, 3, 4]) == [2, 4, 6, 8]



# Generated at 2022-06-26 00:21:32.775840
# Unit test for function memoize
def test_memoize():
    def addOne(x):
        return x + 1

    addOne_memoized = memoize(addOne)
    assert (addOne_memoized(0) == 1)
    assert (addOne_memoized(1) == 2)
    assert (addOne_memoized(0) == 1)
    assert (addOne_memoized(0) == 1)
    assert (addOne_memoized(1) == 2)
    assert (addOne_memoized(1) == 2)
    assert (addOne_memoized(1) == 2)
    assert (addOne_memoized(1) == 2)
    assert (addOne_memoized(1) == 2)


# Generated at 2022-06-26 00:21:38.868514
# Unit test for function cond
def test_cond():
    condition_list = [
        (lambda x: x > 0, lambda x: 'more 0'),
        (lambda x: x == 0, lambda x: 'more 0'),
        (lambda x: x < 0, lambda x: 'less 0')
    ]
    test_0 = cond(condition_list)(0)
    assert test_0 == 'more 0'
    test_1 = cond(condition_list)(-1)
    assert test_1 == 'less 0'



# Generated at 2022-06-26 00:21:44.043477
# Unit test for function memoize
def test_memoize():
    global var_0

    def fn(argument):
        if argument < 5:
            return fn(argument + 1)
        return argument

    result = memoize(fn)
    assert result(0) == 5
    assert result(0) == 5
    assert result(1) == 5
    assert result(2) == 5
    assert result(3) == 5
    assert result(4) == 5
    assert result(5) == 5



# Generated at 2022-06-26 00:21:46.420685
# Unit test for function eq
def test_eq():
    assert True is eq(1, 1)
    assert False is eq(1, 2)


# Generated at 2022-06-26 00:21:53.079966
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda i: i + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(identity, [5, 6, 7]) == [5, 6, 7]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda i: i * i, [1, 2, 3]) == [1, 4, 9]
    assert curried_map(lambda i: i * i, []) == []



# Generated at 2022-06-26 00:22:03.812770
# Unit test for function curried_filter
def test_curried_filter():
    print('\nTest for curried_filter start\n')
    def double(item):
        return item * 2

    def is_even(item):
        return item % 2 == 0

    # test data
    collection_1 = [1, 2, 3, 4, 5]

    # test
    map_collection = curried_map(double, collection_1)
    filter_collection = curried_filter(is_even, collection_1)
    print('Curried filter result: ')
    print(filter_collection)
    print('\n')

    return 0



# Generated at 2022-06-26 00:22:10.551540
# Unit test for function memoize
def test_memoize():
    from random import randint
    from time import time

    def generate_random_int():
        """
        Return random int number from 1 to 100.

        :returns: random int number from 1 to 100
        :rtype: Int
        """
        return randint(1, 100)

    memoized_generate_random_int = memoize(generate_random_int)

    start_time = time()
    memoized_generate_random_int()
    end_time = time() - start_time

    start_time = time()
    memoized_generate_random_int()
    end_time = time() - start_time



# Generated at 2022-06-26 00:22:17.203836
# Unit test for function cond
def test_cond():
    condition_list = [
        (lambda x: x < 1, lambda x: x + 10),
        (lambda x: 1 <= x < 5, lambda x: x + 5),
        (lambda x: 5 <= x, lambda x: x + 1),
    ]

    test_cases = [
        -1,
        0,
        1,
        2,
        5,
        10,
        10.5,
    ]

    for test_case in test_cases:
        assert cond(condition_list)(test_case) == test_case + 10


# Unit tests for function pipe

# Generated at 2022-06-26 00:22:18.998868
# Unit test for function memoize
def test_memoize():
    test_function = memoize(increase)
    assert test_function(2) == 3
    assert test_function(2) == 3


# Generated at 2022-06-26 00:22:26.678647
# Unit test for function memoize
def test_memoize():
    memoized_fn = memoize(lambda x: x + 2)
    assert memoized_fn(1) == 3
    assert memoized_fn(1) == 3
    assert memoized_fn(1) == 3
    assert memoized_fn(2) == 4
    assert memoized_fn(3) == 5
    assert memoized_fn(1) == 3
    assert memoized_fn(2) == 4
    assert memoized_fn(3) == 5
    assert memoized_fn(4) == 6
    assert memoized_fn(5) == 7
    assert memoized_fn(4) == 6



# Generated at 2022-06-26 00:22:29.737034
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x * 2)([1, 2, 3, 4]) == [2, 4, 6, 8]



# Generated at 2022-06-26 00:22:36.672705
# Unit test for function memoize
def test_memoize():
    def fib(n):
        if n == 0 or n == 1:
            return n
        return fib(n - 1) + fib(n - 2)

    mfib = memoize(fib, key=lambda x, y: x == y)
    assert mfib(5) == mfib(5)
    

# Generated at 2022-06-26 00:22:39.314692
# Unit test for function eq
def test_eq():
    fn_0 = eq(1, 1)
    fn_1 = eq(1, '1')

    # Assertion
    assert fn_0 == True
    assert fn_1 == False



# Generated at 2022-06-26 00:22:49.853234
# Unit test for function curried_map
def test_curried_map():
    # Test curried_map with empty list
    var_0 = curried_map(increase, [])
    assert var_0 == []

    # Test curried_map with increase and list of elements
    var_1 = curried_map(increase, [1, 2, 3])
    assert var_1 == [2, 3, 4]

    # Test curried_map with lambda function and list of elements
    var_2 = curried_map(lambda x: x*2, [1, 2, 3])
    assert var_2 == [2, 4, 6]


# Generated at 2022-06-26 00:22:52.894789
# Unit test for function curry
def test_curry():
    var_0 = curry(lambda x, y: x + y, 2)(2)(2)
    assert var_0 == 4



# Generated at 2022-06-26 00:23:06.400625
# Unit test for function memoize
def test_memoize():
    # Test for case when cache is empty.
    var_0 = memoize(identity)(1)
    assert var_0 == 1
    var_0 = memoize(identity)(1)
    assert var_0 == 1
    var_0 = memoize(identity)(1)
    assert var_0 == 1

    # Test for case when cache is not empty.
    var_1 = memoize(increase)(1)
    assert var_1 == 2
    var_1 = memoize(increase)(1)
    assert var_1 == 2
    var_1 = memoize(increase)(1)
    assert var_1 == 2
    var_2 = memoize(increase)(2)
    assert var_2 == 3
    var_3 = memoize(increase)(3)
    assert var_3 == 4


# Generated at 2022-06-26 00:23:14.259693
# Unit test for function memoize
def test_memoize():
    calls_count = 0

    def test_fn(a):
        nonlocal calls_count
        calls_count += 1
        return a
    memoized_test_fn = memoize(test_fn)

    assert memoized_test_fn(1) == 1
    assert memoized_test_fn(1) == 1
    assert memoized_test_fn(2) == 2
    assert memoized_test_fn(3) == 3
    assert memoized_test_fn(1) == 1
    assert memoized_test_fn(2) == 2
    assert memoized_test_fn(3) == 3
    assert memoized_test_fn(4) == 4
    assert calls_count == 4



# Generated at 2022-06-26 00:23:18.518690
# Unit test for function memoize
def test_memoize():
    """
    Test cases for function memoize
    """

    count = 0

    @memoize
    def fn(x):
        nonlocal count
        count += 1
        return x + 1

    assert fn(1) == 2
    assert fn(1) == 2
    assert count == 1
    assert fn(2) == 3
    assert fn(2) == 3
    assert count == 2



# Generated at 2022-06-26 00:23:26.195152
# Unit test for function cond
def test_cond():
    def eq_2(x):
        return x == 2

    def eq_4(x):
        return x == 4

    def eq_6(x):
        return x == 6

    func_1 = cond([
        (eq_2, lambda: 'second'),
        (eq_4, lambda: 'fourth'),
        (eq_6, lambda: 'sixth')
    ])

    assert func_1(2) == 'second'
    assert func_1(4) == 'fourth'
    assert func_1(6) == 'sixth'
    assert func_1(8) == None
    assert func_1(0) == None
    assert func_1(-2) == None
    assert func_1(-4) == None
    assert func_1(-6) == None



# Generated at 2022-06-26 00:23:33.750531
# Unit test for function memoize
def test_memoize():
    result_list: List[int] = []
    counter_0: int = 0
    counter_1: int = 0

    def memoized_fn(argument):
        nonlocal counter_0
        counter_0 += 1
        return argument

    memoized_fn = memoize(memoized_fn)
    for i in [1, 2, 1, 2, 1, 2, 1, 2]:
        result_list.append(memoized_fn(i))

    def fn(argument):
        nonlocal counter_1
        counter_1 += 1
        return argument

    for i in [1, 2, 1, 2, 1, 2, 1, 2]:
        result_list.append(fn(i))

    assert counter_0 != counter_1


# Unit tests for function cond

# Generated at 2022-06-26 00:23:42.692316
# Unit test for function memoize
def test_memoize():
    var_0 = memoize(identity)
    var_1 = memoize(identity)

    def var_2(arg):
        return arg + 1

    var_3 = memoize(var_2)
    var_4 = memoize(var_2)

    var_5 = var_0(10)
    var_6 = var_0(10)
    var_7 = var_0(20)
    var_8 = var_0(20)
    var_9 = var_1(10)
    var_10 = var_1(10)
    var_11 = var_1(20)
    var_12 = var_1(20)

    var_13 = var_3(10)
    var_14 = var_3(10)
    var_15 = var_3(20)
    var

# Generated at 2022-06-26 00:23:48.009940
# Unit test for function memoize
def test_memoize():
    def fn():
        yield 1  # yield from iter(range(10))
        yield 2
        yield 3

    gen = fn()
    memoized_gen = memoize(gen)
    memoized_gen_increase = compose(memoized_gen, curried_map(increase), list)
    assert memoized_gen_increase() == [2, 3, 4]
    assert memoized_gen_increase() == [2, 3, 4]



# Generated at 2022-06-26 00:23:54.673937
# Unit test for function memoize
def test_memoize():
    double = lambda x: 2 * x
    double_not_memoized = [double(i) for i in range(10)]
    double_memoized = [double(i) for i in range(10)]

    assert double_not_memoized != double_memoized, \
        'not memoized function should not return equal result'

    double_memoized = memoize(double)

    assert double_not_memoized != double_memoized, \
        'memoized function should not return equal result'



# Generated at 2022-06-26 00:24:02.991951
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x % 2 == 0, lambda x: x + 1),
        (lambda x: x % 3 == 0, lambda x: x + 2),
    ])(1) == 2
    assert cond([
        (lambda x: x % 2 == 0, lambda x: x + 1),
        (lambda x: x % 3 == 0, lambda x: x + 2),
    ])(2) == 3
    assert cond([
        (lambda x: x % 2 == 0, lambda x: x + 1),
        (lambda x: x % 3 == 0, lambda x: x + 2),
    ])(3) == 5

# Generated at 2022-06-26 00:24:08.214146
# Unit test for function cond
def test_cond():
    # Create list with two functions:
    # check if three equal to three
    # return three
    # and check if two equal to three
    # return two
    condition_list = [(eq(3), identity), (eq(2), identity)]

    # Call cond function and apply it to three
    cond_function = cond(condition_list)
    cond_function(3) == 3
    cond_function(2) == 2



# Generated at 2022-06-26 00:24:24.177499
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x % 2 == 0, lambda x: x + 1),
        (lambda x: x % 2 != 0, lambda x: x - 1),
    ])(3) == 2
    assert cond([
        (lambda x: x % 2 == 0, lambda x: x - 1),
        (lambda x: x % 2 != 0, lambda x: x + 1),
    ])(3) == 4
    assert cond([
        (lambda x: x > 3, lambda x: x + 1),
        (lambda x: x < 3, lambda x: x - 1),
    ])(1) == 0
    assert cond([
        (lambda x: x > 3, lambda x: x + 1),
        (lambda x: x < 3, lambda x: x - 1),
    ])(5) == 6

# Generated at 2022-06-26 00:24:31.825564
# Unit test for function curried_filter
def test_curried_filter():
    collection = [
        {'id': 0, 'name': 'name_0'},
        {'id': 1, 'name': 'name_1'},
        {'id': 2, 'name': 'name_2'},
        {'id': 3, 'name': 'name_3'},
        {'id': 4, 'name': 'name_4'},
    ]

    assert curried_filter(lambda item: item['id'] == 3, collection) == [
        item for item in collection if item['id'] == 3
    ]

    collection_filtered = curried_filter(lambda item: item['id'] == 3)
    assert collection_filtered(collection) == [
        item for item in collection if item['id'] == 3
    ]



# Generated at 2022-06-26 00:24:33.618661
# Unit test for function eq
def test_eq():
    # Unit test for eq(value, value1)
    assert eq(1, 1)
    assert eq(1, 2) == False


# Generated at 2022-06-26 00:24:36.197997
# Unit test for function curry
def test_curry():
    assert increase(5) == 6
    inc = curry(increase)
    assert inc(5) == 6
    inc_1 = inc(1)
    assert inc_1(5) == inc(1)(5) == 6



# Generated at 2022-06-26 00:24:38.912170
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([]) == []
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-26 00:24:41.529757
# Unit test for function curried_map
def test_curried_map():
    assert (curried_map(increase, [1, 2, 3]) == [2, 3, 4])
    assert (curried_map(increase)([1, 2, 3]) == [2, 3, 4])



# Generated at 2022-06-26 00:24:43.833325
# Unit test for function curried_map
def test_curried_map():
    assert list(map(lambda x: x + 1, [0, 1, 2, 3])) == list(curried_map(lambda x: x + 1)([0, 1, 2, 3]))



# Generated at 2022-06-26 00:24:48.022275
# Unit test for function curried_map
def test_curried_map():
    assert [1, 2, 3] == curried_map(identity)([0, 1, 2])
    assert [1, 2, 3] == curried_map(increase)([0, 1, 2])
    assert [1, 2, 3] == curried_map(increase, [0, 1, 2])
    assert [1, 2, 3] == curried_map(increase, [0, 1, 2])


# Generated at 2022-06-26 00:24:52.966666
# Unit test for function curry
def test_curry():
    assert curry(lambda x: x * 2, args_count=1)(2) == 4
    assert curry(lambda x, y: x * y, args_count=2)(2, 2) == 4
    assert curry(lambda x, y, z: x * y * z, args_count=3)(1, 2, 4) == 8
    assert curry(lambda x, y: x * y, args_count=2)(1)(2) == 2



# Generated at 2022-06-26 00:24:54.033885
# Unit test for function eq
def test_eq():
    assert 1 == 1, "test_eq() error"


# Generated at 2022-06-26 00:25:06.529651
# Unit test for function curried_filter
def test_curried_filter():
    filter_ = curried_filter(bool)
    filter_list = filter_([False, True, False, True, False])
    assert filter_list == [True, True], 'Test for function curried_filter was failed'



# Generated at 2022-06-26 00:25:09.879200
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], eq(3)) == 3
    assert find([3, 6, 9, 12, 15], eq(4)) is None
    assert find(["a", "b", "c", "d", "e"], eq("c")) == "c"



# Generated at 2022-06-26 00:25:15.877890
# Unit test for function find
def test_find():
    assert None == find([], lambda _: True)
    assert None == find([1, 2, 3], lambda x: x == 0)
    assert 1 == find([1, 2, 3], lambda x: x == 1)



# Generated at 2022-06-26 00:25:19.094605
# Unit test for function memoize
def test_memoize():
    assert 100 == memoize(increase)(100)
    assert 101 == memoize(increase)(101)
    assert 102 == memoize(increase)(102)
    assert 101 == memoize(increase)(101)



# Generated at 2022-06-26 00:25:23.249665
# Unit test for function cond
def test_cond():
    def fn_0(arg):
        return True

    def fn_1(arg):
        return False

    def fn_2(arg):
        return arg

    fn_3 = cond([
        (fn_0, fn_2),
        (fn_1, fn_2),
    ])

    assert fn_3(True) and not fn_3(False)



# Generated at 2022-06-26 00:25:29.907868
# Unit test for function curry
def test_curry():
    del int_0
    int_0 = False
    del int_1
    int_1 = increase(int_0)
    assert not int_0, "Test case 0: failed"
    assert int_1, "Test case 1: failed"


# Generated at 2022-06-26 00:25:36.187637
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(
        lambda item: item % 2 == 0,
        [1, 2, 3, 4, 5]
    ) == [2, 4]
    test = curried_filter(lambda item: item % 2 == 0)
    assert test([1, 2, 3, 4, 5]) == [2, 4]
    assert curried_filter(
        lambda item, num: item * 2 > num,
        [1, 2, 3, 4, 5]
    )([10, 11, 12, 13, 14, 15]) == [2, 3, 4]



# Generated at 2022-06-26 00:25:38.913399
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(2, 1) is False
    assert eq(1, 2) is False


# Generated at 2022-06-26 00:25:49.563420
# Unit test for function memoize
def test_memoize():
    def f1(n):
        return n

    def f2(n):
        g2 = lambda x: x
        g2.cache = {}
        return g2(n)

    def f3(n):
        return 3

    def f4(n):
        return 4

    def f5(n):
        return 5

    def f6(n):
        return 6

    def cond_1(x):
        return x == 5

    def cond_2(x):
        return x == 6

    def cond_3(x):
        return True

    f1_memoized = memoize(f1)

    assert f1_memoized(1) == f1(1)
    assert f1_memoized(2) == f1(2)

# Generated at 2022-06-26 00:25:52.549969
# Unit test for function memoize
def test_memoize():
    counter = 0
    @memoize
    def count(value):
        nonlocal counter
        counter += 1
        return value

    values = [12, 12, 12, 13, 13]
    calculated = list(map(count, values))
    assert counter == 2
    assert calculated == values

# Generated at 2022-06-26 00:26:17.413429
# Unit test for function curried_map
def test_curried_map():
    test_data = [
        [identity, [], []],
        [[increase], [], []],
        [increase, [], []],
        [identity, [1, 2, 3], [1, 2, 3]],
        [increase, [1, 2, 3], [2, 3, 4]],
        [lambda x: x / 2, [2, 4, 6], [1, 2, 3]],
    ]

    for test_item in test_data:
        assert curried_map(test_item[0], test_item[1]) == test_item[2]



# Generated at 2022-06-26 00:26:18.865190
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False
    assert eq(2, 1) is False


# Generated at 2022-06-26 00:26:24.302575
# Unit test for function find
def test_find():
    # Check that find find a value in a list
    expected = 5
    actual = find([1, 2, 3, 4, 5, 6, 7], lambda item: item == 5)
    assert expected == actual

    # Check that find not find a value in a list and return None
    expected = None
    actual = find([1, 2, 3, 4, 5, 6, 7], lambda item: item == 10)
    assert expected == actual



# Generated at 2022-06-26 00:26:31.642897
# Unit test for function memoize
def test_memoize():
    counter = 0

    @memoize
    def add(x, y):
        nonlocal counter
        counter += 1
        return x + y

    int_1_int_2 = add(1, 2)
    int_3_int_4 = add(3, 4)
    int_1_int_2_again = add(1, 2)

    assert counter == 2, "counter is {}".format(counter)
    assert int_1_int_2 == 3, "int_1_int_2 is {}".format(int_1_int_2)
    assert int_3_int_4 == 7, "int_3_int_4 is {}".format(int_3_int_4)

# Generated at 2022-06-26 00:26:37.184504
# Unit test for function memoize
def test_memoize():
    count_calls = 0

    def get_count_calls():
        nonlocal count_calls
        count_calls += 1
        return count_calls

    memoized_get_count_calls = memoize(get_count_calls)

    assert memoized_get_count_calls(1) == 1
    assert memoized_get_count_calls(1) == 1
    assert memoized_get_count_calls(2) == 2
    assert memoized_get_count_calls(2) == 2
    assert memoized_get_count_calls(1) == 1



# Generated at 2022-06-26 00:26:42.313025
# Unit test for function cond
def test_cond():
    is_even = lambda x: x % 2 == 0
    is_odd = lambda x: x % 2 != 0
    double = lambda x: x + x
    square = lambda x: x * x

    even_square = cond([(is_even, square)])
    even_double = cond([(is_even, double)])

    assert even_square(8) == 64
    assert even_square(9) == None
    assert even_double(13) == None
    assert even_double(12) == 24


# Generated at 2022-06-26 00:26:43.394159
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(2)) == 2



# Generated at 2022-06-26 00:26:45.729401
# Unit test for function memoize
def test_memoize():
    int_0 = False
    int_1 = increase(int_0)

    int_3 = True
    int_4 = increase(int_3)



# Generated at 2022-06-26 00:26:49.969728
# Unit test for function cond
def test_cond():
    def test_sum(arg1: int, arg2: int) -> int:
        return arg1 + arg2

    def test_multiply(arg1: int, arg2: int) -> int:
        return arg1 * arg2

    conditional_function = cond([
        (eq(True), test_sum),
        (eq(False), test_multiply),
    ])

    assert conditional_function(False, 4, 2) == 8
    assert conditional_function(True, 4, 2) == 6

# Generated at 2022-06-26 00:26:57.272427
# Unit test for function cond
def test_cond():
    test_value = 0
    increment_fn = lambda x: x + 1
    decrement_fn = lambda x: x - 1

    is_even_fn = lambda x: x % 2 == 0
    is_odd_fn = lambda x: x % 2 != 0

    even_number_function = cond(
        [(is_even_fn, increment_fn), (is_odd_fn, decrement_fn)])

    odd_number_function = cond(
        [(is_odd_fn, increment_fn), (is_even_fn, decrement_fn)])

    assert even_number_function(test_value) == test_value + 1
    assert odd_number_function(test_value) == test_value - 1



# Generated at 2022-06-26 00:27:46.889695
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert eq("", "")


# Generated at 2022-06-26 00:27:49.457330
# Unit test for function memoize
def test_memoize():
    curried_add = lambda x: lambda y: x + y

    add_three = memoize(curried_add(3))
    add_five = memoize(curried_add(5))

    assert add_three(2) == 5
    assert add_three(3) == 6
    assert add_five(3) == 8


# Generated at 2022-06-26 00:27:53.436836
# Unit test for function curried_map
def test_curried_map():
    values = [1, 2, 3, 4, 5]
    assert curried_map(increase, values) == [2, 3, 4, 5, 6]

    curried_map_increase = curried_map(increase)
    assert curried_map_increase(values) == [2, 3, 4, 5, 6]


# Generated at 2022-06-26 00:27:59.866437
# Unit test for function curry
def test_curry():
    func_1_arg = lambda a: a
    func_1_arg_curry = curry(func_1_arg)
    assert (func_1_arg(1) == func_1_arg_curry(1))

    func_2_arg = lambda a, b: a + b
    func_2_arg_curry = curry(func_2_arg)
    assert (func_2_arg(1, 2) == func_2_arg_curry(1)(2))


# Generated at 2022-06-26 00:28:06.912621
# Unit test for function find
def test_find():
    poi_lst = [
        (1, 2, 3),
        (1, 2),
        (1, 2, 3, 4, 5)
    ]
    assert find(poi_lst, lambda item: len(item) == 5) == (1, 2, 3, 4, 5)
    assert find(poi_lst, lambda item: len(item) == 4) == None



# Generated at 2022-06-26 00:28:15.188094
# Unit test for function cond
def test_cond():
    def function_0():
        pass

    def function_1():
        pass

    def function_2():
        pass

    def condition_0(value):
        return value == 0

    def condition_1(value):
        return value == 1

    def condition_2(value):
        return True

    result = cond([
        (condition_0, function_0),
        (condition_1, function_1),
        (condition_2, function_2)
    ])

    try:
        result(0)
        result(1)
        result(2)
    except:
        assert False

    try:
        result(-1)
    except:
        assert False



# Generated at 2022-06-26 00:28:18.653551
# Unit test for function curried_map
def test_curried_map():
    # Base cases
    assert curried_map(increase, [0, 1]
                       ) == [1, 2]
    assert curried_map(increase, []) == []
    assert curried_map(increase, [1, 2, 3, 4]
                       ) == [2, 3, 4, 5]



# Generated at 2022-06-26 00:28:22.636691
# Unit test for function curried_filter
def test_curried_filter():
    names = [
        'a',
        'b',
        'c',
        'd',
        'e',
    ]

    def eq_a(name):
        return name == 'a'

    names_with_a = curried_filter(eq_a, names)

    assert names_with_a == ['a']

# Generated at 2022-06-26 00:28:25.245092
# Unit test for function find
def test_find():
    """Test for function find"""
    assert find([1, 2, 3, 4, 5], lambda item: item == 1) == 1
    assert find([1, 2, 3, 4, 5], lambda item: item == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda item: item == 5) == 5

