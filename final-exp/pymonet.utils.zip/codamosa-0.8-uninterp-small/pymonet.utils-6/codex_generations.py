

# Generated at 2022-06-26 00:18:28.663752
# Unit test for function eq
def test_eq():
    assert True == eq(1, 1)
    assert False == eq(1, 2)


# Generated at 2022-06-26 00:18:30.998864
# Unit test for function find
def test_find():
    collection = [1,2,3,4]
    assert find(collection, fn(2)) == 2
    assert find(collection, fn(5)) == None


# Generated at 2022-06-26 00:18:35.050964
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x > 2) == 3
    assert find([100, 1, 2, 3, 4, 5], lambda x: x is 100) == 100
    assert find([1, 2, 3, 4, 5], lambda x: x is 6) is None



# Generated at 2022-06-26 00:18:44.489747
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b: (a, b))
    assert curry(lambda a, b, c: (a, b, c))
    assert curry(lambda a, b, c, d: (a, b, c, d))
    assert curry(lambda a, b, c, d, e: (a, b, c, d, e))
    assert curry(lambda a, b, c, d, e, f: (a, b, c, d, e, f))
    assert curry(lambda a, b, c, d, e, f, g: (a, b, c, d, e, f, g))
    assert curry(lambda a, b, c, d, e, f, g, h: (a, b, c, d, e, f, g, h))

# Generated at 2022-06-26 00:18:53.464630
# Unit test for function curry
def test_curry():
    @curry
    def f(a, b, c):
        return a + b + c
    assert f(1, 2, 3) == 6
    assert f(1)(2, 3) == 6
    assert f(1, 2)(3) == 6
    assert f(1)(2)(3) == 6
    assert f(1)(2, 3) == 6



# Generated at 2022-06-26 00:19:05.127564
# Unit test for function memoize
def test_memoize():
    """
    Function to check if memoize works well

    Return result of memoize(fn).
    memoize must cache all arguments and results,
    so when memoized_fn will be called with argument which was called before,
    result must be taken from cache. Otherwise it will be called fn.
    First call will call fn, second will take result from cache.

    :returns: memoized_fn
    :rtype: Function
    """
    cache: List[Any] = [
        (1, 'one'),
        (2, 'two'),
        (3, 'three')
    ]

    def fn(argument):
        for (argument1, result) in cache:
            if argument == argument1:
                return result



# Generated at 2022-06-26 00:19:10.458219
# Unit test for function cond
def test_cond():
    is_a = lambda x: x == 'a'
    add_to_a = lambda x: 'a' + x
    is_b = lambda x: x == 'b'
    double_b = lambda x: 'b' + x + 'b'

    fn = cond([(is_a, add_to_a),
               (is_b, double_b)])

    assert fn('a') == 'aa'
    assert fn('b') == 'bbbb'
    assert fn('c') is None



# Generated at 2022-06-26 00:19:15.649778
# Unit test for function curried_map
def test_curried_map():
    assert [2, 3, 4] == curried_map(increase)([1, 2, 3])
    assert [2, 4, 6] == curried_map(lambda x: 2 * x)([1, 2, 3])
    assert [False, True, False] == curried_map(eq(2))([1, 2, 3])


# Generated at 2022-06-26 00:19:21.090486
# Unit test for function curry
def test_curry():
    assert (lambda a, b, c: a + b + c)(10, 20, 30) == curry(lambda a, b, c: a + b + c)(10)(20)(30)



# Generated at 2022-06-26 00:19:22.390330
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 'a')


# Generated at 2022-06-26 00:19:41.440562
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 4, [1, 2, 3, 4, 5]) == [5]
    assert curried_filter(lambda x: x < 4, [1, 2, 3, 4, 5]) == [1, 2, 3]
    assert curried_filter(lambda x: x > 2 and x < 5, [1, 2, 3, 4, 5]) == [3, 4]
    assert curried_filter(lambda x: x < 1 or x > 5, [1, 2, 3, 4, 5]) == []
    print("test_curried_filter")



# Generated at 2022-06-26 00:19:46.277814
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert curried_map(increase)([1, 2, 3, 4]) == [2, 3, 4, 5]
    assert [] == curried_map(identity)([])


# Generated at 2022-06-26 00:19:52.244835
# Unit test for function memoize
def test_memoize():
    def add_one(n):
        return n + 1
    # create memoized version of add_one
    add_one_memoized = memoize(add_one)

    assert add_one_memoized(1) == add_one_memoized(add_one_memoized(1))
    assert add_one_memoized(2) == add_one_memoized(add_one_memoized(2))



# Generated at 2022-06-26 00:19:56.383473
# Unit test for function eq
def test_eq():
    print('test_eq')
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq(1, 1, 2) == False
    assert eq(1, 1, 1) == True
    assert eq(1, 1, 1, 1) == True



# Generated at 2022-06-26 00:20:05.304862
# Unit test for function find
def test_find():
    def find_key(letter):
        return letter
    var_1 = find(["A", "B", "C", "D", "E", "F", "G"], find_key)
    var_2 = var_1
    assert var_2 == "A"
    var_3 = find(["A", "B", "C", "D", "E", "F", "G"], find_key)
    var_4 = var_3
    assert var_4 == "A"
    var_5 = find(["A", "B", "C", "D", "E", "F", "G"], find_key)
    var_6 = var_5
    assert var_6 == "A"


# Generated at 2022-06-26 00:20:09.676661
# Unit test for function find
def test_find():
    def test(actual_result, expected_result):
        if actual_result != expected_result:
            print("Test failed: {} {}".format(actual_result, expected_result))
        else:
            print("Test completed")

    test(find([1, 2, 3], lambda x: x == 2), 2)
    test(find([1, 2, 3], lambda x: x == 0), None)



# Generated at 2022-06-26 00:20:16.208018
# Unit test for function memoize
def test_memoize():
    # helper function
    def add(a, b):
        return a + b

    # create memoize function
    memo_add = memoize(add)

    # test if returns 1
    assert memo_add(1, 1) == 2
    # test if returns 2
    assert memo_add(1, 1) == 2
    # test if returns 3,3,3
    assert memo_add(1, 2) == 3
    assert memo_add(1, 2) == 3
    assert memo_add(1, 2) == 3
    print("successful test_memoize")



# Generated at 2022-06-26 00:20:25.124818
# Unit test for function memoize
def test_memoize():
    @memoize
    def fn(argument):
        return argument + 5

    assert fn(2) == 7
    assert fn(2) == 7
    assert fn(3) == 8

    @memoize
    def fn2(argument):
        return argument + 5

    assert fn2(2) == 7
    assert fn2(2) == 7
    assert fn2(3) == 8
    assert fn2(5) == 10

    @memoize
    def fn3(argument):
        return argument + 5

    assert fn3(2) == 7
    assert fn3(2) == 7
    assert fn3(3) == 8
    assert fn3(5) == 10
    assert fn(2) == 7
    assert fn(2) == 7
    assert fn(3) == 8


# Generated at 2022-06-26 00:20:28.727150
# Unit test for function find
def test_find():
    # Arrange
    collection = [1, 2, 3, 4, 5]
    key = lambda x: x % 2 == 0

    # Act
    result = find(collection, key)

    # Assert
    assert result == 2



# Generated at 2022-06-26 00:20:41.231217
# Unit test for function cond
def test_cond():
    # prepare test data
    is_odd = lambda x: x % 2 == 1
    is_even = lambda x: x % 2 == 0
    get_number_type = lambda x: "odd" if is_odd(x) else "even"

    # test function cond
    assert cond([(is_even, get_number_type)])(4) == "even"
    assert cond([(is_even, get_number_type)])(5) == None

    # test function curry
    curry_get_number_type = curry(get_number_type)
    assert curry_get_number_type(3) == "odd"

    # test function compose
    compose_get_even = compose(get_number_type, is_even)
    assert compose_get_even(4) == "even"

# Generated at 2022-06-26 00:20:59.542187
# Unit test for function find
def test_find():
    assert (find([1, 2, 3], lambda value: value == 2) == 2)
    assert (find([1, 2, 3], lambda value: value == 4) is None)



# Generated at 2022-06-26 00:21:04.631139
# Unit test for function memoize
def test_memoize():
    test_array = list(range(1, 5))

    @memoize
    def test_curried_map(value):
        return curried_map(increase, value)

    result = test_curried_map(test_array)
    assert result == [2, 3, 4, 5]

    assert test_curried_map.__closure__[1].cell_contents[0][1] == result



# Generated at 2022-06-26 00:21:09.374877
# Unit test for function memoize
def test_memoize():
    is_called_0 = False

    def fn_0(x):
        nonlocal is_called_0
        is_called_0 = True
        return x * x

    memoized_fn_0 = memoize(fn_0)

    assert memoized_fn_0(2) == 4
    assert memoized_fn_0(2) == 4
    assert is_called_0 is True



# Generated at 2022-06-26 00:21:12.319935
# Unit test for function memoize
def test_memoize():
    def complex_fn():
        return []

    memoized_fn = memoize(complex_fn)
    assert memoized_fn().__eq__([])


# Generated at 2022-06-26 00:21:21.162582
# Unit test for function cond
def test_cond():
    def fn_1(value):
        return value == 1

    def fn_2(value):
        return value == 2

    def fn_3(value):
        return value == 3

    def fn_4(value):
        return value == 4

    condition_list = [
        (fn_1, lambda _: 'one'),
        (fn_2, lambda _: 'two'),
        (fn_3, lambda _: 'three'),
        (fn_4, lambda _: 'four')
    ]

    fn_1_result = cond(condition_list)(1)
    assert fn_1_result == 'one'
    fn_2_result = cond(condition_list)(2)
    assert fn_2_result == 'two'
    fn_3_result = cond(condition_list)(3)
    assert fn_3

# Generated at 2022-06-26 00:21:23.302797
# Unit test for function memoize
def test_memoize():
    """
    :return:
    """
    @memoize
    def fn(n):
        return n

    assert fn(1) == fn(1)

    return True

# Generated at 2022-06-26 00:21:33.027090
# Unit test for function memoize
def test_memoize():
    test_eq_with_dict = eq(0, 1)
    test_eq_with_list = eq(0, 2)
    test_eq_with_number = eq(1, 0)

    test_memoize_fn = memoize(lambda x: x)

    test_memoize_fn(1)
    test_memoize_fn(1)
    test_memoize_fn(1)

    test_memoize_fn(2)
    test_memoize_fn(2)
    test_memoize_fn(2)
    test_memoize_fn(2)

    test_memoize_fn_eq = memoize(lambda x: x, test_eq_with_dict)
    test_memoize_fn_eq([0, 1])
    test_memo

# Generated at 2022-06-26 00:21:35.891531
# Unit test for function find
def test_find():
    assert find([0, 1, 2, 3, 4], lambda x: x % 2 == 0) == 0
    assert find([0, 1, 2, 3, 4], lambda x: x == 5) is None



# Generated at 2022-06-26 00:21:41.930585
# Unit test for function cond
def test_cond():
    def fn_1(x):
        return x > 0

    def fn_2(x):
        return x < 0

    def fn_3(x):
        return x == 0

    fn_4 = cond([(fn_1, increase),
                 (fn_2, decrease),
                 (fn_3, identity)])

    assert fn_4(1) == 2
    assert fn_4(-1) == -2
    assert fn_4(0) == 0



# Generated at 2022-06-26 00:21:44.768971
# Unit test for function cond
def test_cond():
    is_even = lambda x: x % 2 == 0
    five = lambda x: 5
    add_five = lambda x: x + 5

    fn = cond(
        [(is_even, five), (eq(1), add_five)]
    )

    assert fn(2) == 5, 'Should apply first function'
    assert fn(1) == 6, 'Should apply second function'
    assert fn(0) == 5, 'Should apply first function'
    assert fn(3) == 8, 'Should apply second function'



# Generated at 2022-06-26 00:21:57.646759
# Unit test for function cond
def test_cond():
    condition_list = [(lambda x: x < 0, lambda x: x * -1),
                      (lambda x: x == 0, lambda x: 0),
                      (lambda x: True, lambda x: x)]

    f = cond(condition_list)
    assert f(10) == 10
    assert f(-10) == 10
    assert f(0) == 0



# Generated at 2022-06-26 00:22:00.318398
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x > 2) == 3
    assert find([1, 2, 3, 4], lambda x: x == '2') is None



# Generated at 2022-06-26 00:22:03.601920
# Unit test for function curried_map
def test_curried_map():
    assert(curried_map(lambda x: x % 2 == 0)([1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89]) == [False, False, True, False, False, True, False, False, True, False, False])



# Generated at 2022-06-26 00:22:06.686003
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda item: item % 2 == 0, [1, 2, 3])(1, 2, 3) == [2]
    assert curried_filter(lambda item: item % 2 == 0)([1, 2, 3]) == [2]


# Generated at 2022-06-26 00:22:11.662134
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 5, [1, 2, 3, 4, 5, 6, 7]) == [6, 7]
    assert curried_filter(lambda x: x > 5)([1, 2, 3, 4, 5, 6, 7]) == [6, 7]
    assert curried_filter(lambda x: x > 5)([1, 2, 3, 4, 5, 6, 7, 8]) == [6, 7, 8]



# Generated at 2022-06-26 00:22:19.982833
# Unit test for function memoize
def test_memoize():
    gen_0 = fn(var_0=memoize(fn(var_0=identity, var_1=args_0, var_2=args_1)), var_1=args_0, var_2=args_1)
    var_0 = gen_0(var_0=identity, var_1=1, var_2=2)
    var_1 = gen_0(var_0=identity, var_1=1, var_2=2)
    var_2 = gen_0(var_0=identity, var_1=1, var_2=2)
    var_3 = gen_0(var_0=identity, var_1=3, var_2=2)

# Generated at 2022-06-26 00:22:27.974044
# Unit test for function cond
def test_cond():
    def a():
        return True

    def b():
        return 'hi'

    def c():
        return 'hello'
    assert cond([(a, b), (a, c)])() == 'hi'
    assert cond([(a, b), (a, c)])() == 'hi'
    assert cond([(a, b), (a, c)])() == 'hi'
    assert cond([(a, c), (a, b)])() == 'hello'
    assert cond([(a, c), (a, b)])() == 'hello'
    assert cond([(a, c), (a, b)])() == 'hello'


# Generated at 2022-06-26 00:22:37.875917
# Unit test for function memoize
def test_memoize():
    x: int = 0
    def id(v):
        nonlocal x
        x += 1
        return v
    m_id: Callable = memoize(id)
    assert eq(m_id(1), 1)
    assert eq(x, 1)
    assert eq(m_id(1), 1)
    assert eq(x, 1)
    assert eq(m_id(2), 2)
    assert eq(m_id(3), 3)
    assert eq(x, 3)
    assert eq(m_id(2), 2)
    assert eq(x, 3)



# Generated at 2022-06-26 00:22:41.538836
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq("test", "test")
    assert not eq("test", "test2")

    assert eq("test")("test")
    assert not eq("test")("test2")
    assert eq(1)(1)
    assert not eq(1)(2)



# Generated at 2022-06-26 00:22:55.322135
# Unit test for function curry
def test_curry():
    """
    Test case for function curry
    """

    @curry
    def fn(a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z):
        return a + b + c + d + e + f + g + h + i + j + k + l + m + n + o + p + q + r + s + t + u + v + w + x + y + z

    assert fn(
        1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26) == \
           sum(range(1, 27))

# Generated at 2022-06-26 00:23:20.829291
# Unit test for function find
def test_find():
    assert (find([1, 2, 3], eq(3)) == 3)
    assert (find([1, 2, 3], eq(4)) is None)


# Generated at 2022-06-26 00:23:22.774121
# Unit test for function cond
def test_cond():
    condition_list = [(lambda x: x > 10, lambda x: x)]
    assert cond(condition_list)(10) is None
    assert cond(condition_list)(11) == 11

# Generated at 2022-06-26 00:23:30.461420
# Unit test for function cond
def test_cond():
    predicate_less_than_ten = lambda x: x < 10

    predicate_less_than_ten_and_even = lambda x: x % 2 == 0 and x < 10

    def execute_return_42(x):
        return 42

    def execute_return_None(x):
        return None

    def execute_return_x(x):
        return x

    assert cond(
        [(predicate_less_than_ten, execute_return_42),
         (predicate_less_than_ten_and_even, execute_return_42),
         (identity, execute_return_42)]
    )(9) == 42

    assert cond(
        [(predicate_less_than_ten, execute_return_42),
         (predicate_less_than_ten_and_even, execute_return_None)]
    )

# Generated at 2022-06-26 00:23:34.395950
# Unit test for function curried_map
def test_curried_map():
    assert eq(
        curried_map(increase, [0, 1, 2, 3]),
        [1, 2, 3, 4]
    )

    assert eq(
        curried_map(increase, [0, 1, 2, 3]),
        curried_map(increase)([0, 1, 2, 3])
    )



# Generated at 2022-06-26 00:23:40.711838
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [1, 2, 3]) == [1, 2, 3]
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(incr)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(incr, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(incr)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-26 00:23:45.444868
# Unit test for function cond
def test_cond():
    condition_list = [
        (lambda x: x < 2, lambda x: x * 10),
        (lambda x: x % 2 == 0, lambda x: x * 100),
        (lambda x: True, lambda x: x * 1000),
    ]
    fn = cond(condition_list)
    assert fn(1), 10
    assert fn(2), 100
    assert fn(3), 3000



# Generated at 2022-06-26 00:23:53.385013
# Unit test for function eq
def test_eq():
    assert eq(1)(1) == True, 'eq is not working'
    assert eq(1)(2) == False, 'eq is not working'
    assert eq('abcd')('abcd') == True, 'eq is not working'
    assert eq('abcd')('efgh') == False, 'eq is not working'
    assert eq(['a', 'b', 'c'])(['a', 'b', 'c']) == True, 'eq is not working'
    assert eq(['a', 'b', 'c'])(['d', 'e', 'f']) == False, 'eq is not working'
    print('Passed eq test')


# Generated at 2022-06-26 00:23:59.432303
# Unit test for function memoize
def test_memoize():
    # Test Case 0
    var_0 = memoize(lambda x: x + x)(2)
    assert var_0 == 4, f'Expected 4, but got {var_0}'
    var_1 = memoize(lambda x: x + x)(3)
    var_2 = memoize(lambda x: x + x)(2)
    assert var_1 == 6, f'Expected 6, but got {var_1}'
    assert var_2 == 4, f'Expected 4, but got {var_2}'


# Generated at 2022-06-26 00:24:04.846302
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(2)) == 2
    assert find([{'id': 1, 'color': 'red'}, {'id': 2, 'color': 'blue'}], eq({'id': 1, 'color': 'red'})) == {'id': 1, 'color': 'red'}
    assert find([1, 2, 3], eq(4)) is None
    assert find([{'id': 1, 'color': 'red'}, {'id': 2, 'color': 'blue'}], eq({'id': 3, 'color': 'red'})) is None



# Generated at 2022-06-26 00:24:14.325904
# Unit test for function memoize
def test_memoize():
    assert eq(
        isinstance(memoize(lambda x: x + 1), FunctionType),
        True
    ) is True

    var_1 = memoize(lambda x: x + 1)

    assert eq(
        var_1(1),
        2
    ) is True

    assert eq(
        memoize(lambda x: x + 1)(1),
        2
    ) is True

    assert eq(
        var_1(1),
        2
    ) is True

    var_2 = memoize(lambda x: x * 2)

    assert eq(
        var_2(1),
        2
    ) is True


# Generated at 2022-06-26 00:24:52.790526
# Unit test for function memoize
def test_memoize():
    assert [1, 2, 3, 4] == curried_map(memoize(lambda x: x + 1), [0, 1, 2, 3])



# Generated at 2022-06-26 00:24:58.693370
# Unit test for function curried_map
def test_curried_map():
    assert [] == curried_map(identity)([])
    assert [0] == curried_map(identity)([0])
    assert [0, 1] == curried_map(identity)([0, 1])
    assert [0, 1, 2] == curried_map(identity)([0, 1, 2])
    assert [1] == curried_map(increase)([0])
    assert [1, 2] == curried_map(increase)([0, 1])
    assert [1, 2, 3] == curried_map(increase)([0, 1, 2])



# Generated at 2022-06-26 00:25:00.940655
# Unit test for function memoize
def test_memoize():
    identity_memoized = memoize(identity)

    assert identity(1) == identity_memoized(1)
    assert identity_memoized(1) == identity_memoized(1)



# Generated at 2022-06-26 00:25:09.412525
# Unit test for function memoize
def test_memoize():
    data: List[Tuple[Any, Callable[..., Any], Callable[..., Any], List[List[Any]], List[Any]]]