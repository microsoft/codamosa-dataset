

# Generated at 2022-06-26 00:18:31.162291
# Unit test for function memoize
def test_memoize():
    var_1 = pipe(0,
                 lambda _: _ + 1,
                 lambda _: _ + 1,
                 lambda _: _ + 1)

    assert(var_1 == 3)

    var_2 = fn()

    assert(var_2 == 2)



# Generated at 2022-06-26 00:18:40.108724
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 3, 4, 5, 6, 10]
    assert compose(
        collection,
        lambda x: curried_filter(lambda y: y == 2, x),
        lambda x: curried_filter(lambda y: y == 3, x)
    ) == []
    assert compose(
        collection,
        lambda x: curried_filter(lambda y: y == 2, x),
        lambda x: curried_filter(lambda y: y == 2, x)
    ) == [2]
    assert compose(
        collection,
        curried_map(lambda y: y * y),
        lambda x: curried_filter(lambda y: y == 9, x)
    ) == [9]



# Generated at 2022-06-26 00:18:41.902951
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x == 1, [1, 2, 3]) == [1]



# Generated at 2022-06-26 00:18:47.239014
# Unit test for function find
def test_find():

    assert find([1, 2, 3, 4, 5, 6, 7, 8, 9], lambda a: a % 2 == 0) == 2
    assert find([1, 3, 5, 7, 9], lambda a: a % 2 == 0) is None
    assert find([], lambda a: a % 2 == 0) is None
    assert find({1: 2, 3: 4, 5: 6, 7: 8, 9: 10}, lambda a: a % 2 == 0) is None



# Generated at 2022-06-26 00:18:52.807833
# Unit test for function curry
def test_curry():
    @curry
    def add(x, y):
        return x + y

    assert add(1, 2) == 3
    assert add(1)(2) == 3
    assert add(1, 2, 3) == 3



# Generated at 2022-06-26 00:18:56.907494
# Unit test for function find
def test_find():
    assert find(collection=[1, 2, 3], key=eq(2)) == 2
    assert find(collection=[1, 2, 3], key=eq(4)) is None



# Generated at 2022-06-26 00:18:58.928161
# Unit test for function eq
def test_eq():
    """
    Unit test for function eq

    :returns:
    """
    assert eq('a', 'a')
    assert not eq('a', 'b')



# Generated at 2022-06-26 00:19:04.395375
# Unit test for function eq
def test_eq():
    assert eq(1, 2) == False
    assert eq(2, 2) == True
    assert eq(2)(2) == True
    assert eq(1)(1) == True


# Generated at 2022-06-26 00:19:09.569137
# Unit test for function find
def test_find():
    assert find([1, 10, 100, 1000], lambda x: x < 10) == 1
    assert find([1, 10, 100, 1000], lambda x: x < 100) == 1
    assert find([1, 10, 100, 1000], lambda x: x == 100) == 100
    assert find([1, 10, 100, 1000], lambda x: x > 100) == 1000
    assert find([1, 10, 100, 1000], lambda x: x > 1000) is None



# Generated at 2022-06-26 00:19:14.620741
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5, 6], lambda x: x % 2 == 0) == 2
    assert find([1, 2, 3, 4, 5, 6], lambda x: x > 6) is None
    assert find([1, 2, 3, 4, 5, 6], lambda x: x == 7) is None



# Generated at 2022-06-26 00:19:23.236380
# Unit test for function eq
def test_eq():
    assert eq()(1, 1), "TEST FAILED"


# Generated at 2022-06-26 00:19:25.694923
# Unit test for function curried_map
def test_curried_map():
    var_0 = curried_map(lambda x: x**2, [1, 2, 3])
    assert var_0 == [1, 4, 9]



# Generated at 2022-06-26 00:19:30.967239
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda num: True)([1, 2, 3]) == [1, 2, 3]
    assert curried_filter(lambda num: False)([1, 2, 3]) == []
    assert curried_filter(eq(1))([1, 2, 3]) == [1]
    assert curried_filter(lambda num: num % 2 == 0)([1, 2, 3]) == [2]



# Generated at 2022-06-26 00:19:32.831041
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq(1, "1") == False


# Generated at 2022-06-26 00:19:46.028916
# Unit test for function memoize
def test_memoize():

    @memoize
    def g(x):
        return x

    assert g(0) == 0

    @memoize
    def fib(x):
        if x == 0 or x == 1:
            return 1
        return fib(x - 1) + fib(x - 2)

    start_time = time.time()
    assert fib(25) == 121393
    end_time = time.time()
    time1 = end_time - start_time

    start_time = time.time()
    assert fib(25) == 121393
    end_time = time.time()
    time2 = end_time - start_time

    assert time2 < time1
    assert fib(0) == 1
    assert fib(1) == 1
    assert fib(2) == 2
    assert fib(3) == 3

# Generated at 2022-06-26 00:19:49.094700
# Unit test for function find
def test_find():
    even = lambda x: x % 2 == 0

    assert find([1, 2, 3, 4], even) == 2
    assert find([], even) is None
    assert find([1, 3, 5, 7], even) is None



# Generated at 2022-06-26 00:19:58.993635
# Unit test for function cond
def test_cond():
    lst = [1, 2, 3, 4, 5, 6, 7]
    gt2 = lambda x: x > 2
    lte5 = lambda x: x <= 5
    add10 = lambda x: x + 10
    def sub6(x): return x - 6
    def mul2(x): return x * 2

    def check_type(arg):
        return type(compose_cond([lambda l: type(l) == list, lambda f: lst], arg))


# Generated at 2022-06-26 00:20:03.378230
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(1), [1, 2, 3]) == [1]
    assert curried_filter(eq(4), [1, 2, 3]) == []
    assert curried_filter(eq(1), []) == []



# Generated at 2022-06-26 00:20:11.385703
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x > 5, lambda x: x + 1),
        (lambda x: x < 2, lambda x: x - 1),
        (lambda x: True, lambda x: x * x),
    ])(0) == 1
    assert cond([
        (lambda x: x > 5, lambda x: x + 1),
        (lambda x: x < 2, lambda x: x - 1),
        (lambda x: True, lambda x: x * x),
    ])(9) == 10
    assert cond([
        (lambda x: x > 5, lambda x: x + 1),
        (lambda x: x < 2, lambda x: x - 1),
        (lambda x: True, lambda x: x * x),
    ])(3) == 9



# Generated at 2022-06-26 00:20:14.056112
# Unit test for function eq
def test_eq():
    assert (eq(1, 1))
    assert (eq(1, 1) == True)
    assert not(eq(1, 2))
    assert (eq(1, 2) == False)


# Generated at 2022-06-26 00:20:35.453228
# Unit test for function cond
def test_cond():
    def is_odd(value):
        return value % 2

    def is_even(value):
        return not is_odd(value)

    def is_positive(value):
        return value > 0

    def is_negative(value):
        return value < 0

    even_fn = lambda value: value ** 2
    odd_fn = lambda value: value ** 3
    positive_fn = lambda value: value ** 4
    negative_fn = lambda value: value ** 5

    condition_list = [
        (is_even, even_fn),
        (is_odd, odd_fn),
        (is_positive, positive_fn),
        (is_negative, negative_fn)
    ]

    fn = cond(condition_list)

    assert fn(0) == 0
    assert fn(1) == 1

# Generated at 2022-06-26 00:20:41.609048
# Unit test for function curried_filter
def test_curried_filter():
    assert(curried_filter(lambda x: x > 2, [1, 2, 3, 4, 5]) == list(filter(lambda x: x > 2, [1, 2, 3, 4, 5])))


# Generated at 2022-06-26 00:20:51.169189
# Unit test for function curried_filter
def test_curried_filter():
    # Input data
    input_list = [
        (1, 2, 3, 4, 5),
        (1, 2, 3, 4),
        (1, 2, 3),
        (1, 2),
        (1,),
        (),
    ]
    input_function = (
        lambda value: value % 2 == 0,
        lambda value: value % 2 != 0,
    )

    # Expected results
    output_list = (
        [2, 4],
        [2, 4],
        [2],
        [2],
        [],
        [],
    )

    # Run test
    for index in range(len(input_list)):
        out = curried_filter(input_function[index % len(input_function)])(input_list[index])

# Generated at 2022-06-26 00:20:55.426433
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x % 2 == 0) == 2
    assert find([], lambda x: {})[1] == 1
    assert find([1, 2, 3, 4], lambda x: x > 3) == 4
    assert find([0, 0, 0, 0], lambda x: x == 1) is None



# Generated at 2022-06-26 00:20:56.513804
# Unit test for function memoize
def test_memoize():
    def fn(x):
        return x * x
    fn1 = memoize(fn)
    assert fn1(5) == fn(5)



# Generated at 2022-06-26 00:21:03.536111
# Unit test for function cond
def test_cond():
    assert cond([(eq(2), identity), (eq(3), increase)])(2) == 2
    assert cond([(eq(2), identity), (eq(3), increase)])(3) == 4
    assert cond([(eq(2), identity), (eq(3), increase)])(1) is None
    assert cond([(eq(2), identity), (eq(3), increase)])() is None
    assert cond([(eq(2), identity)])(2) == 2
    assert cond([(eq(2), identity)])(3) is None



# Generated at 2022-06-26 00:21:06.083709
# Unit test for function memoize
def test_memoize():

    def count(value):
        return value + 1

    test_fn = memoize(count)

    assert test_fn(1) == 2
    assert test_fn(1) == 2



# Generated at 2022-06-26 00:21:15.770264
# Unit test for function find
def test_find():
    class TestCases(object):

        def test_case_0(self):
            assert find([1, 2, 3, 4], lambda x: x % 2 == 0) == 2

        def test_case_1(self):
            assert find(["a", "b", "c", "d"], lambda x: x == "a") == "a"

        def test_case_2(self):
            assert find([1, 2, 3, 4], lambda x: x == 5) is None

        def test_case_3(self):
            assert find(["a", "b", "c", "d"], lambda x: x == "f") is None

        def test_case_4(self):
            assert find([], lambda x: x % 2 == 0) is None

    test_cases = TestCases()
    test_cases.test

# Generated at 2022-06-26 00:21:19.756531
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(2)) == 2
    assert find([1, 2, 3], eq(5)) is None
    assert find([[1], [[2]]], eq([2])) == [[2]]
    assert find([1, 2, 3, 4], lambda x: x > 3) == 4


# Generated at 2022-06-26 00:21:21.705516
# Unit test for function curried_map
def test_curried_map():
    add = lambda x, y: x + y
    curried_add = curry(add)
    assert [1, 2, 3, 4] == curried_map(identity, [1, 2, 3, 4])
    assert [2, 3, 4, 5] == curried_map(curried_add(1), [1, 2, 3, 4])



# Generated at 2022-06-26 00:21:36.358561
# Unit test for function memoize
def test_memoize():
    square_root = memoize(lambda x: x ** .5, lambda a, b: abs(a - b) < 0.000000001)
    assert square_root(4) == 2
    assert square_root(4) == 2
    assert square_root(4) == 2
    assert square_root(4) == 2



# Generated at 2022-06-26 00:21:40.365275
# Unit test for function curried_filter
def test_curried_filter():
    filter_fn = lambda item: item % 2 == 0
    collection = list(range(10))
    filter_fn_1 = curried_filter(filter_fn)
    result = filter_fn_1(collection)
    assert result == [0, 2, 4, 6, 8]



# Generated at 2022-06-26 00:21:43.433649
# Unit test for function curry
def test_curry():
    assert curry(identity)(1) == 1
    assert curry(identity, 1)(1) == 1
    assert curry(increase)(1) == 2
    assert curry(increase, 1)(1) == 2



# Generated at 2022-06-26 00:21:53.205908
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(2))([1, 2, 3, 2, 1]) == [2, 2]  # test 1
    assert curried_filter(eq(2), [1, 2, 3, 2, 1]) == [2, 2]  # test 2
    assert curried_filter(eq(2))([]) == []  # test 3
    assert curried_filter(eq(2), []) == []  # test 4
    assert curried_filter(eq(2))([1, 1, 1, 1]) == []  # test 5
    assert curried_filter(eq(2), [1, 1, 1, 1]) == []  # test 6
    assert curried_filter(id)([1, 2, 3, 2, 1]) == [1, 2, 3, 2, 1]  # test 7

# Generated at 2022-06-26 00:21:58.587496
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 2) == 2
    assert find([1, 2, 3, 4], lambda x: x == 9) is None
    assert find([1, 3, 5, 7, 9], lambda x: x % 2 == 0) is None
    assert find([1, 3, 5, 7, 9], lambda x: x % 2 != 0) == 1
    assert find([], lambda x: True) is None



# Generated at 2022-06-26 00:22:01.046060
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(2), [1, 2, 3]) == [2]
    assert curried_filter(eq(4), [1, 2, 3]) == []



# Generated at 2022-06-26 00:22:05.342719
# Unit test for function find
def test_find():
    assert find(
        [1, 2, 3, 4, 5],
        lambda x: x == 2
    ) == 2
    assert find(
        [1, 2, 3, 4, 5],
        lambda x: x == 6
    ) is None
    assert find(
        [],
        lambda x: x == 6
    ) is None



# Generated at 2022-06-26 00:22:06.702549
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(
        lambda x: x % 2 == 0,
        [1, 2, 3, 4, 5]
    ) == [2, 4]



# Generated at 2022-06-26 00:22:11.355765
# Unit test for function cond
def test_cond():
    compose_fn = compose(identity, identity)
    pipe_fn = pipe(identity, identity)

    cond_fn = cond([
        (lambda x: x == 0, compose_fn),
        (lambda x: x == 1, pipe_fn),
    ])

    assert cond_fn(0) == compose_fn
    assert cond_fn(1) == pipe_fn
    assert cond_fn(None) is None



# Generated at 2022-06-26 00:22:13.465634
# Unit test for function curry
def test_curry():
    assert curry(sum, 4)(1, 2, 3, 4) == 10
    assert curry(sum, 4)(1)(2)(3)(4) == 10



# Generated at 2022-06-26 00:22:36.554119
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x % 2 == 0) == 2
    assert find([1, 3, 5], lambda x: x % 2 == 0) is None
    assert find([], lambda x: x % 2 == 0) is None



# Generated at 2022-06-26 00:22:41.265868
# Unit test for function curried_filter
def test_curried_filter():
        assert curried_filter(lambda x: True, [1, 2, 3])([1, 2, 3]) == [1, 2, 3]
        assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3])([1, 2, 3]) == [2]
        assert curried_filter(lambda x: x > 4, [1, 2, 3])([1, 2, 3]) == []



# Generated at 2022-06-26 00:22:53.043996
# Unit test for function curry

# Generated at 2022-06-26 00:22:58.247715
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], eq(3)) == 3
    assert find([1, 2, 3, 4], eq(5)) is None



# Generated at 2022-06-26 00:23:05.271243
# Unit test for function cond
def test_cond():
    # Arrange
    condition_list = [
        (eq(1), lambda x: x + 1),
        (eq(2), lambda x: x + 2)
    ]

    # Act
    func = cond(condition_list)

    # Assert
    assert func(1) == 2
    assert func(2) == 4
    assert func(3) is None
    assert func(None) is None

    try:
        cond('q')
        assert False
    except TypeError as e:
        assert type(e) == TypeError



# Generated at 2022-06-26 00:23:08.173098
# Unit test for function curried_map
def test_curried_map():
    doubled = curried_map(lambda x: x * 2)
    doubled_list = doubled([1, 2, 3, 4])
    assert doubled_list == [2, 4, 6, 8]
    doubled_list = doubled([1, 2])
    assert doubled_list == [2, 4]


# Generated at 2022-06-26 00:23:11.739330
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x % 2 == 1) == 1
    assert find(['a', 'b', 'c'], lambda x: x == 'b') == 'b'



# Generated at 2022-06-26 00:23:19.501951
# Unit test for function curried_filter
def test_curried_filter():
    assert [1, 2, 3] == curried_filter(lambda x: x > 0, [1, 2, 3, -1])
    assert [1, 2, 3] == curried_filter(lambda x: x > 0)([1, 2, 3, -1])
    assert [1, 2, 3] == curried_filter(lambda x: x > 0, [1, 2, 3, -1])
    assert [1, 2, 3] == curried_filter(lambda x: x > 0)([1, 2, 3, -1])
    assert [1, 2, 3] == curried_filter(lambda x: x > 0)([1, 2, 3, -1])


# Generated at 2022-06-26 00:23:20.345998
# Unit test for function eq
def test_eq():
    assert eq(1, 1)



# Generated at 2022-06-26 00:23:28.062477
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(0), [0, 1, 2, 3]) == [0]
    assert curried_filter(eq(1), [0, 1, 2, 3]) == [1]
    assert curried_filter(eq(2), [0, 1, 2, 3]) == [2]
    assert curried_filter(eq(3), [0, 1, 2, 3]) == [3]
    assert curried_filter(eq(4), [0, 1, 2, 3]) == []
    assert curried_filter(identity, [0, 1, 2, 3]) == [0, 1, 2, 3]
    assert curried_filter(eq(3), []) == []
    assert curried_filter(eq(0), [0, 0, 0, 0]) == [0, 0, 0, 0]

# Generated at 2022-06-26 00:23:50.402782
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-26 00:23:58.096006
# Unit test for function curried_filter
def test_curried_filter():
    TEST_DATA = [
        (lambda x: x < 2, list(range(5)), list([0, 1])),
        (lambda x: x > 2, list(range(5)), list([3, 4])),
    ]

    for filterer, collection, expect_result in TEST_DATA:
        test_result = curried_filter(filterer, collection)
        assert expect_result == test_result, \
            '{0}({1}, {2}) != {3}'.format(
                curried_filter.__name__,
                filterer,
                collection,
                expect_result
            )



# Generated at 2022-06-26 00:24:00.616967
# Unit test for function eq
def test_eq():
    test_var_0 = False
    test_var_1 = True
    assert test_var_0 == eq(False)(False)
    assert test_var_1 == eq(False)(True)



# Generated at 2022-06-26 00:24:04.861193
# Unit test for function cond
def test_cond():
    cond_function = cond([
        (lambda x: x % 3 == 0, lambda x: 'fizz'),
        (lambda x: x % 5 == 0, lambda x: 'buzz'),
        (lambda x: True, lambda x: x),
    ])

    assert cond_function(3) == 'fizz'
    assert cond_function(5) == 'buzz'
    assert cond_function(2) == 2
    assert cond_function(15) == 'fizzbuzz'



# Generated at 2022-06-26 00:24:09.315558
# Unit test for function memoize
def test_memoize():
    def square(x):
        return x * x


# Generated at 2022-06-26 00:24:17.608804
# Unit test for function cond
def test_cond():
    # Define functions for cond
    fn_0 = lambda value: type(value) == int
    fn_1 = lambda value: value + 1
    fn_2 = lambda value: value + 'test'
    fn_3 = lambda value: value * 2
    # cond function
    fn_4 = cond(
        [(fn_0, fn_1), (fn_0, fn_2), (fn_0, fn_3)]
    )
    # tests
    assert fn_4(0) == 1
    assert fn_4('test') == 'testtest'
    assert fn_4(1) == 2
    assert fn_4('test') == 'testtest'
    assert fn_4(1) == 2
    assert fn_4(2) == 4
    assert fn_4(3) == 6

# Generated at 2022-06-26 00:24:20.612137
# Unit test for function curried_map
def test_curried_map():
    test_data = [1, 2, 3, 4]
    expected_result = [2, 3, 4, 5]
    actual_result = curried_map(increase, test_data)
    assert actual_result == expected_result


# Test for function curried_filter

# Generated at 2022-06-26 00:24:26.065631
# Unit test for function curried_filter
def test_curried_filter():
    # test of call curried_filter with partial calling
    # set of values to filter
    numbers = [3, 2, 1, 2, 3]
    # part of condition to filter
    filter_condition = eq(2)
    # get filter function
    filter_function = curried_filter(filter_condition)
    # get filtered values
    filtered_numbers = filter_function(numbers)
    # set of expected values
    expected_values = [2, 2]
    # verify results
    assert filtered_numbers == expected_values



# Generated at 2022-06-26 00:24:28.085703
# Unit test for function find
def test_find():
    """

    :return:
    """
    assert find([1, 2], eq(1)) == 1
    assert find([], eq(1)) is None



# Generated at 2022-06-26 00:24:35.798494
# Unit test for function memoize
def test_memoize():
    # Should return false
    assert(
        find([], lambda item: item) is None
    )

    # Should return true
    assert(
        find([1, 2], lambda item: item == 1) == 1
    )

    # Should return 5
    fn = lambda x: 5
    assert(
        find([1, 2], fn) == 5
    )

    # Should return 5
    fn = lambda x: 5
    assert(
        find([1, 2], fn) == 5
    )

    # Should return 5
    def fn(x):
        return 5

    assert(
        find([1, 2], fn) == 5
    )

    # Should return 7
    fn = lambda x: x + 1
    assert(
        find([1, 2], fn) == 7
    )

    # Should return 5
   

# Generated at 2022-06-26 00:24:59.500747
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x == 1, lambda x: '1!'),
        (lambda x: x == 2, lambda x: '2!'),
        (lambda x: x > 2, lambda x: '>2!')
    ])(2) == '2!'



# Generated at 2022-06-26 00:25:03.557752
# Unit test for function cond
def test_cond():
    a_b_c = cond([
        (eq(0), increase),
        (eq(1), increase),
        (eq(2), increase)
    ])

    assert a_b_c(0) == 1
    assert a_b_c(1) == 2
    assert a_b_c(2) == 3
    assert a_b_c(3) is None


# Generated at 2022-06-26 00:25:05.520714
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter([1, 2, 3, 4, 5])(eq(3)) == [3]


# Generated at 2022-06-26 00:25:07.564087
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4]) == [2, 4]



# Generated at 2022-06-26 00:25:10.159373
# Unit test for function find
def test_find():
    assert find(list(range(5)), lambda x: x == 3) == 3
    assert find(list(range(5)), lambda x: x == 7) is None
    assert find([], lambda x: x == 3) is None



# Generated at 2022-06-26 00:25:16.335332
# Unit test for function eq
def test_eq():
    assert not eq(3, 2)
    assert not eq(3, None)
    assert not eq(None, 2)

    assert eq(3, 3)
    assert eq('a', 'a')
    assert eq(None, None)



# Generated at 2022-06-26 00:25:19.016440
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x % 2 == 0) == 2
    assert find([1, 2, 3, 4], lambda x: x > 3) is None



# Generated at 2022-06-26 00:25:26.389430
# Unit test for function find
def test_find():
    """
    Test case for find

    :returns:
    :rtype:
    """
    assert find([1, 2, 3, 4, 5], eq(2)) == 2
    assert find([1, 2, 3, 4, 5], eq(10)) is None

    assert find([{'key': 'value'}, {'key': 'value1'}], lambda x: x['key'] == 'value') == {'key': 'value'}
    assert find([{'key': 'value'}, {'key': 'value1'}], lambda x: x['key'] == 'value2') is None

    assert find([['key', 'value'], ['key', 'value1']], lambda x: x[0] == 'key' and x[1] == 'value') == ['key', 'value']

# Generated at 2022-06-26 00:25:30.049043
# Unit test for function memoize
def test_memoize():
    assert (
        pipe(
            0,
            memoize(increase),
            memoize(increase)
        )
    ) == 2



# Generated at 2022-06-26 00:25:34.612927
# Unit test for function memoize
def test_memoize():
    # get string for any int
    int_to_string = memoize(lambda x: chr(ord('a') + x))

    # first call
    assert int_to_string(15) == 'p'

    # second call with same argument
    assert int_to_string(15) == 'p'

    # second call with different argument
    assert int_to_string(2) == 'c'

# Generated at 2022-06-26 00:26:29.757741
# Unit test for function find
def test_find():
    # create list of fake messages
    fake_messages = [
        {
            'id': 1,
            'name': 'UFO',
        },
        {
            'id': 2,
            'name': 'Titanic',
        },
        {
            'id': 3,
            'name': 'Prometheus',
        },
        {
            'id': 4,
            'name': 'Fracture',
        },
        {
            'id': 5,
            'name': 'Fracture',
        },
    ]
    # function for find string in message
    test_find_string = lambda message: message['name'] == 'Fracture'
    # find string in list
    message = find(fake_messages, test_find_string)
    # check results

# Generated at 2022-06-26 00:26:31.844045
# Unit test for function curried_filter
def test_curried_filter():
    collection = [0, 1, 2, 3]
    is_even = lambda val: val % 2 == 0
    filtered = curried_filter(is_even, collection)
    assert filtered == [0, 2]



# Generated at 2022-06-26 00:26:38.069843
# Unit test for function cond
def test_cond():
    def condition_0(x):
        return x < 0

    def condition_1(x):
        return x > 0

    def condition_2(x):
        return x == 0

    def execute_0(x):
        return 'less zero'

    def execute_1(x):
        return 'more zero'

    def execute_2(x):
        return 'zero'

    execute_function = cond([
        (condition_0, execute_0),
        (condition_1, execute_1),
        (condition_2, execute_2),
    ])

    assert execute_function(-1) == 'less zero'
    assert execute_function(1) == 'more zero'
    assert execute_function(0) == 'zero'


# Generated at 2022-06-26 00:26:41.240333
# Unit test for function memoize
def test_memoize():
    def add_1(value: int) -> int:
        return value + 1

    memoized_add_1 = memoize(add_1)

    assert memoized_add_1(1) == 2
    assert memoized_add_1(1) == 2


# Generated at 2022-06-26 00:26:44.991125
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(2), [1, 2, 3]) == [2]
    assert curried_filter(eq(1), [1, 2, 3]) == [1]
    assert curried_filter(eq(4), [1, 2, 3]) == []
    assert curried_filter(eq({}), [{}, {}]) == [{}, {}]


# Generated at 2022-06-26 00:26:46.690833
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1, True)


# Generated at 2022-06-26 00:26:48.722355
# Unit test for function curried_filter
def test_curried_filter():
    collection = [8, 3, 5, 9, 1]
    result = curried_filter(lambda x: x > 4)(collection)
    expected = [8, 5, 9]
    assert result == expected, result



# Generated at 2022-06-26 00:26:52.047869
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(1)) == 1
    assert find([1, 2, 3], eq(4)) == None
    assert find([0, 1, 2], increase) == 1
    assert find([1, 2, 3], lambda arg: arg > 10) == None
    assert find([3, 4, 5], lambda arg: arg > 2) == 3



# Generated at 2022-06-26 00:26:53.301503
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2]) == [2, 3]


# Generated at 2022-06-26 00:26:55.406694
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-26 00:28:25.593531
# Unit test for function cond
def test_cond():
    condition_list = [
        (lambda x: x == 1, lambda x: "one"),
        (lambda x: x == 2, lambda x: "two"),
        (lambda x: x == 3, lambda x: "three")
    ]

    assert "one" == cond(condition_list)(1)
    assert "two" == cond(condition_list)(2)
    assert "three" == cond(condition_list)(3)
    assert cond(condition_list)(4) is None

    condition_list_1 = [
        (lambda x: x == 1, lambda x: "one"),
        (lambda x: x == 2, lambda x: "two"),
        (lambda x: x == 3, lambda x: "three")
    ]

    assert "one" == cond(condition_list)(1)