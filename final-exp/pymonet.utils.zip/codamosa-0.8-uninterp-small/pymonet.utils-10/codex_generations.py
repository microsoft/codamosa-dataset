

# Generated at 2022-06-26 00:18:31.712675
# Unit test for function curried_map
def test_curried_map():
    # Case 0:
    assert curried_map(identity, [1, 2, 3, 4]) == [1, 2, 3, 4]

    # Case 1:
    assert curried_map(increase, [1, 2, 3, 4]) == [2, 3, 4, 5]



# Generated at 2022-06-26 00:18:36.161059
# Unit test for function cond
def test_cond():
    assert cond(
        [
            (lambda x: x == 0, lambda: 'zero'),
            (lambda x: x % 2 == 0, lambda: 'even'),
            (lambda x: x % 2 != 0, lambda: 'odd'),
        ]
    )(0) == 'zero'

# Test for function cond list of arguments



# Generated at 2022-06-26 00:18:45.504735
# Unit test for function memoize

# Generated at 2022-06-26 00:18:52.562920
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(1), [0, 1, 1]) == [1, 1]
    assert curried_filter(eq(1), [0, 2, 3]) == []
    assert curried_filter(eq(1), []) == []



# Generated at 2022-06-26 00:18:58.912475
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], eq(2)) == 2
    assert find([1, 2, 3, 4], eq(1)) == 1
    assert find([1, 2, 3, 4], eq(4)) == 4
    assert find([1, 2, 3, 4], eq(0)) is None



# Generated at 2022-06-26 00:19:03.350417
# Unit test for function find
def test_find():
    simple_collection = [1, 2, 3, 4, 5]

    assert find(simple_collection, lambda x: x == 3) == 3
    assert find(simple_collection, lambda x: x == 10) is None



# Generated at 2022-06-26 00:19:07.758199
# Unit test for function curried_filter
def test_curried_filter():
    assert [1, 3, 5] == curried_filter(lambda x: x % 2 == 1)([1, 2, 3, 4, 5])
    assert [] == curried_filter(lambda x: x % 2 == 1)([2, 4, 6, 8])
    assert [] == curried_filter(lambda x: x % 2 == 1)([])



# Generated at 2022-06-26 00:19:09.824751
# Unit test for function curried_filter
def test_curried_filter():
    assert (
        curried_filter(lambda item: item % 2 == 0)([1, 2, 3, 4, 5]) == [2, 4]
    )



# Generated at 2022-06-26 00:19:12.751909
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(10), [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]), [10]



# Generated at 2022-06-26 00:19:18.756517
# Unit test for function eq
def test_eq():
    var_0 = eq(1, 1)
    var_1 = eq(1, 2)
    var_2 = eq(2, 1)
    assert var_0 == var_2
    assert var_0 is not var_2
    assert var_1 is not var_2



# Generated at 2022-06-26 00:19:30.632252
# Unit test for function curry
def test_curry():
    def fn_0(arg1, arg2, arg3):
        return arg1 + arg2 + arg3

    assert fn_0(1, 2, 3) == 6
    assert fn_0(1, 2)(3) == 6
    assert fn_0(1)(2, 3) == 6

    fn_0_curried = curry(fn_0)
    assert fn_0_curried(1)(2)(3) == 6
    assert fn_0_curried(1, 2)(3) == 6
    assert fn_0_curried(1)(2, 3) == 6



# Generated at 2022-06-26 00:19:34.082721
# Unit test for function curried_filter
def test_curried_filter():
    """
    Unit test for function curried_filter

    :returns: None
    :rtype: None
    """
    assert curried_filter(lambda x: x % 2 == 0, [1,2,3,4]) == [2, 4]


# Generated at 2022-06-26 00:19:40.360518
# Unit test for function cond
def test_cond():
    var_0 = cond(
        [(eq(1), fn_0), (eq(2), fn_1), (eq(3), curry(fn_1))]
    )
    result_0 = var_0(3)



# Generated at 2022-06-26 00:19:42.052820
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(2, 3)


# Generated at 2022-06-26 00:19:47.855218
# Unit test for function cond
def test_cond():
    fn = cond([
        (gt(__, 1), lambda x: 'x bigger than 1'),
        (eq(__, 1), lambda x: 'x is equal to 1'),
        (lt(__, 1), lambda x: 'x less than 1'),
    ])
    assert fn(3) == 'x bigger than 1'
    assert fn(1) == 'x is equal to 1'
    assert fn(-1) == 'x less than 1'



# Generated at 2022-06-26 00:19:52.478872
# Unit test for function memoize
def test_memoize():
    var_1 = memoize(increase)
    var_2 = memoize(increase)
    var_3 = var_1(4)
    var_4 = var_2(4)
    var_5 = var_3 == var_4
    var_6 = var_5 == True
    return var_6


# Generated at 2022-06-26 00:19:54.472438
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(2, 2) == True
    assert eq(1, 2) == False


# Generated at 2022-06-26 00:20:04.793841
# Unit test for function cond
def test_cond():
    # usual case
    equal(
        cond(
            [(eq(1), identity), (eq(2), identity)]
        )(1),
        1
    )

    # first case
    equal(
        cond(
            [(eq(1), identity), (eq(2), identity)]
        )(2),
        2
    )

    # not exists case
    equal(
        cond(
            [(eq(1), identity), (eq(2), identity)]
        )(3),
        None
    )

    # list is empty
    equal(
        cond(
            []
        )(1),
        None
    )

    # tuple of list
    equal(
        cond(
            [(eq(1), identity)],
            [(eq(2), identity)]
        )(2),
        2
    )




# Generated at 2022-06-26 00:20:08.604999
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1,2,3]) == [1,2,3]
    assert curried_map(increase)([1,2,3]) == [2,3,4]
    assert curried_map(lambda x: x+1)([1,2,3]) == [2,3,4]



# Generated at 2022-06-26 00:20:10.122056
# Unit test for function find
def test_find():
    var_1 = [1, 2, 3, 4, 5]
    var_2 = find(var_1, lambda x: x == 2)
    assert var_2 == 2



# Generated at 2022-06-26 00:20:28.071701
# Unit test for function memoize
def test_memoize():
    global curried_increase
    curried_increase = lambda x: x + 1
    curried_increase = memoize(curried_increase)
    assert curried_increase(0) == curried_increase(0)
    assert curried_increase(1) == curried_increase(1)
    assert curried_increase(2) == curried_increase(2)
    assert curried_increase(0) != curried_increase(1)
    assert curried_increase(1) != curried_increase(2)
    assert curried_increase(2) != curried_increase(0)
    print(curried_increase(10))



# Generated at 2022-06-26 00:20:31.182701
# Unit test for function eq
def test_eq():
    assert eq(10, 10), '10 == 10'
    assert not eq(10, 11), '10 != 11'
    assert not eq(10, '10'), '10 != \'10\''



# Generated at 2022-06-26 00:20:43.368099
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(2), [1, 2, 3]) == [2]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4]) == [2, 4]
    assert curried_filter(lambda x: x > 5, [6, 7]) == [6, 7]
    assert curried_filter(lambda x: x == 3, [1, 2, 3]) == [3]
    assert curried_filter(lambda x: 3 > x, [1, 2]) == []
    assert curried_filter(lambda x: x < 3, [1, 2, 3]) == [1, 2]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4]) == [2, 4]

# Generated at 2022-06-26 00:20:53.009550
# Unit test for function curried_filter
def test_curried_filter():
    assert eq(curried_filter(eq(3), [3, 4, 5]), [3])
    assert eq(curried_filter(eq(3), {3: "a", 4: "b", 5: "c"}), [3])
    assert eq(curried_filter(eq(2), {3: "a", 4: "b", 5: "c"}), [])
    assert eq(curried_filter(eq(5))([3, 4, 5]), [5])
    assert eq(curried_filter(eq(5))({3: "a", 4: "b", 5: "c"}), [5])
    assert eq(curried_filter(eq(2))({3: "a", 4: "b", 5: "c"}), [])

# Generated at 2022-06-26 00:20:56.098868
# Unit test for function memoize
def test_memoize():
    def test_fn():
        test_fn.counter += 1
        return test_fn.counter

    test_fn.counter = -1

    memoized_fn = memoize(test_fn)

    assert memoized_fn(0) == 0
    assert memoized_fn(0) == 0
    assert memoized_fn(1) == 1
    assert memoized_fn(1) == 1
    assert memoized_fn(0) == 0



# Generated at 2022-06-26 00:20:58.782221
# Unit test for function curry
def test_curry():
    assert eq(curry(lambda x, y, z: x + y + z)(1, 2, 3), 6)



# Generated at 2022-06-26 00:21:01.823223
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda i: i * 2)([1, 2, 3]) == [2, 4, 6]
    assert curried_map(lambda i: i * 2, [1, 2, 3]) == [2, 4, 6]



# Generated at 2022-06-26 00:21:06.530370
# Unit test for function find
def test_find():
    assert find([0, 1, 2, 3, 4, 5], lambda x: x % 2 == 0) == 0
    assert find([0, 1, 2, 3, 4, 5], lambda x: x == 4) == 4
    assert find([], lambda x: x % 2 == 0) is None
    assert find([0, 1, 2, 3, 4, 5], lambda x: x == 42) is None



# Generated at 2022-06-26 00:21:16.227583
# Unit test for function cond
def test_cond():
    assert cond([
        (eq(0), lambda _: "water freezes at 0°C"),
        (eq(100), lambda _: "water boils at 100°C"),
        (lambda temp: True, lambda temp: "nothing special happens at {0}°C".format(temp))
    ])(0) == "water freezes at 0°C"
    assert cond([
        (eq(0), lambda _: "water freezes at 0°C"),
        (eq(100), lambda _: "water boils at 100°C"),
        (lambda temp: True, lambda temp: "nothing special happens at {0}°C".format(temp))
    ])(50) == "nothing special happens at 50°C"

# Generated at 2022-06-26 00:21:24.967845
# Unit test for function cond
def test_cond():
    is_even = lambda num: num % 2 == 0
    is_odd = lambda num: num % 2 == 1

    # Cond
    cond_1 = cond([
        (is_even, lambda x: 'EVEN'),
        (is_odd, lambda x: 'ODD')
    ])

    cond_1_result = cond_1(7)
    assert cond_1_result == 'ODD', '7 is not EVEN number'

    cond_2_result = cond_1(5)
    assert cond_2_result == 'ODD', '5 is not EVEN number'

    cond_3_result = cond_1(10)
    assert cond_3_result == 'EVEN', '10 is not ODD number'

    cond_4_result = cond_1(12)

# Generated at 2022-06-26 00:21:58.544919
# Unit test for function curry
def test_curry():
    # test_case_0
    var_0 = eq(
        curry(lambda x, y: x + y)(1)(3),
        4,
    )

    # test_case_1
    var_1 = eq(
        curry(lambda x, y, z: x + y + z)(1, 3)(2),
        6,
    )

    # test_case_2
    var_2 = eq(
        curry(lambda x, y, z, v: x + y + z + v)(1)(2, 3)(4),
        10,
    )

    return var_0 and var_1 and var_2



# Generated at 2022-06-26 00:22:06.972633
# Unit test for function cond
def test_cond():
    # First part of condition true
    assert cond([
        (lambda x: 0 < x, lambda x: x + 1),
        (lambda x: x < 0, lambda x: x - 2)
    ])(1) == 2

    # Second part of condition true
    assert cond([
        (lambda x: 0 < x, lambda x: x + 1),
        (lambda x: x < 0, lambda x: x - 2)
    ])(-1) == -3

    # None of parts is true
    assert cond([
        (lambda x: 0 < x, lambda x: x + 1),
        (lambda x: x < 0, lambda x: x - 2)
    ])(0) is None

    # If no parts raise exception

# Generated at 2022-06-26 00:22:08.600830
# Unit test for function curry
def test_curry():
    assert curry(increase(1), 1)() == 2
    assert curry(increase, 1)(1) == 2



# Generated at 2022-06-26 00:22:17.178191
# Unit test for function find
def test_find():
    # Prepare
    collection = [1, 2, 3]
    item_to_be_found = 2
    index_of_item_to_be_found = 1
    last_item = 3
    number_of_condition_results = 3
    number_of_condition_true_results = 1

    # Execute
    test_find_item = find(collection, lambda item: item == item_to_be_found)
    test_find_2_eq_2 = find(collection, lambda item: 2 == 2)

    # Assertion
    assert test_find_item == collection[index_of_item_to_be_found]
    assert test_find_2_eq_2 == last_item
    assert len(collection) == number_of_condition_results
    assert len([item for item in collection if 2 == 2])

# Generated at 2022-06-26 00:22:26.255175
# Unit test for function curried_filter
def test_curried_filter():
    test_var_0 = [1, 2, 3, 4, 5, 6, 7]
    test_var_1 = curried_filter(lambda x: x % 2 == 0, test_var_0)
    assert test_var_1 == [2, 4, 6]

    test_var_2 = curried_filter(lambda x: x > 4, test_var_0)
    assert test_var_2 == [5, 6, 7]

    test_var_0 = ["hello", "world"]
    test_var_3 = curried_filter(lambda x: x == "hello", test_var_0)
    assert test_var_3 == ["hello"]

    test_var_4 = curried_filter(lambda x: x == "hello", test_var_0)
    assert test_var_3 == test_

# Generated at 2022-06-26 00:22:34.223611
# Unit test for function memoize
def test_memoize():
    var_0 = None
    def fn():
        return var_0
    fn = memoize(fn)
    var_0 = 1
    var_1 = fn()
    var_0 = 2
    var_2 = fn()
    return [var_1, var_2]


# Generated at 2022-06-26 00:22:42.894654
# Unit test for function curry
def test_curry():
    assert curry(multiply, 3)(2)(2)(2) == 8, 'Error 1'
    assert curry(lambda x, y, z: x * y * z, 3)(2)(2)(2) == 8, 'Error 2'
    assert curry(lambda x, y, z, a, b: x * y * z * a * b, 5)(2)(2)(2)(2)(2) == 32, 'Error 3'
    assert curry(lambda x, y, z, a, b: x * y * z * a * b, 5)(2, 2, 2, 2, 2) == 32, 'Error 4'
    assert curry(lambda x, y: x * y, 3)(2, 2, 2) == 8, 'Error 5'


# Generated at 2022-06-26 00:22:46.350755
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(increase)([0, 1, 2]) == [1, 2, 3]



# Generated at 2022-06-26 00:22:51.594894
# Unit test for function eq
def test_eq():
    assert eq(1, 2) is False, "Variable var_1 should be False"
    assert eq(1, 1) is True, "Variable var_2 should be True"
    assert eq(1, 1, 1) is True, "Variable var_3 should be True"
    assert eq(1, 1, 2) is False, "Variable var_4 should be False"



# Generated at 2022-06-26 00:23:02.352242
# Unit test for function curried_filter
def test_curried_filter():
    # Arrange
    test_data = range(1000)
    expected = [item for item in range(1000) if item % 3 == 0]

    # Act
    result = curried_filter(lambda x: x % 3 == 0, test_data)

    # Assert
    assert len(result) == len(expected)
    for i in range(len(expected)):
        assert result[i] == expected[i]


if __name__ == '__main__':
    test_curried_filter()

# Generated at 2022-06-26 00:23:35.483036
# Unit test for function cond
def test_cond():
    import pytest
    from collections import namedtuple
    Con = namedtuple('Con', ['cond', 'fn'])

    def test_fns(num):
        return num + num

    test_conditions = [
        Con(lambda x: x == 2, lambda x: test_fns(x)),
    ]

    assert cond(test_conditions)(2) == test_fns(2)
    assert cond(test_conditions)(3) is None
    assert cond(test_conditions)(3) is None

# Generated at 2022-06-26 00:23:39.350645
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 7) is None
    assert find([1, 2, 3], lambda x: x % 2 == 0) == 2



# Generated at 2022-06-26 00:23:40.790455
# Unit test for function find
def test_find():
    """
    List of test cases for function find.
    """
    test_case_0()

# Generated at 2022-06-26 00:23:49.571723
# Unit test for function find
def test_find():
    assert find([{'id': 1, 'age': 15}, {'id': 2, 'age': 20}, {'id': 3, 'age': 20}], lambda item: item['age'] == 20) == \
        {'id': 2, 'age': 20}
    assert find([{'id': 1, 'age': 15}, {'id': 2, 'age': 20}, {'id': 3, 'age': 15}], lambda item: item['age'] == 20) == \
        {'id': 2, 'age': 20}
    assert find([{'id': 1, 'age': 15}, {'id': 2, 'age': 20}, {'id': 3, 'age': 15}], lambda item: item['age'] == 25) == \
        None


# Generated at 2022-06-26 00:23:53.461623
# Unit test for function curry
def test_curry():
    assert curry(lambda x: x, 1)() == curry(lambda x: x, 1)(None) == curry(lambda x: x, 1)(None, None) == curry(
        lambda x: x, 1)(None, None, None) is None



# Generated at 2022-06-26 00:23:56.838243
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 3 == 0, range(10)) == [0, 3, 6, 9]
    assert curried_filter(lambda x: x % 3 == 0, range(10)) != [0, 3, 6]


# Generated at 2022-06-26 00:24:04.470883
# Unit test for function memoize
def test_memoize():
    var_0 = memoize(lambda n: n * n)(2)
    var_1 = 4
    # Expected: 4
    var_2 = memoize(lambda n: n ** 2)(2)
    var_3 = 4
    # Expected: 4
    var_4 = memoize(lambda n: n ** 2, lambda a, b: a + b == b + a)(2)
    var_5 = 4
    # Expected: 4
    var_6 = memoize(lambda n: n * n, lambda a, b: a > b)(4)
    var_7 = 16
    # Expected: 16
    var_8 = memoize(lambda n: n * n, lambda a, b: a > b)(6)
    var_9 = 36
    # Expected: 36



# Generated at 2022-06-26 00:24:06.183759
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-26 00:24:10.784996
# Unit test for function curried_map
def test_curried_map():
    eq_(
        curried_map(lambda x: x * 2)([1, 2]), 
        [2, 4]
    ) 
    eq_(
        curried_map(lambda x: x * 2, [1, 2]), 
        [2, 4]
    )

# Generated at 2022-06-26 00:24:14.325966
# Unit test for function find
def test_find():
    collection = [1, 2, 3, 4, 5]

    key_0 = lambda n: n % 2 == 0
    key_1 = lambda n: n % 2 == 1

    assert(find(collection, key_0) == 2)
    assert(find(collection, key_1) == 1)



# Generated at 2022-06-26 00:24:47.768761
# Unit test for function curry
def test_curry():
    var_0 = curry(lambda a0, a1, a2, a3, a4, a5, a6, a7: a0)
    var_1 = curry(lambda a0, a1, a2, a3, a4, a5, a6: a0)



# Generated at 2022-06-26 00:24:49.404453
# Unit test for function curry
def test_curry():
    assert(curry(lambda x, y: x + y)(1)(2) == 3)


test_curry()



# Generated at 2022-06-26 00:24:52.596001
# Unit test for function curry
def test_curry():
    def sum(x, y):
        return x + y
    sum_curry = curry(sum)
    assert sum_curry(1)(2) == 3
    assert sum_curry(1)(2)(3) == 3


# Generated at 2022-06-26 00:24:53.916728
# Unit test for function eq
def test_eq():
    assert eq(10, 10) == True
    assert eq(10, 11) == False



# Generated at 2022-06-26 00:24:57.253782
# Unit test for function cond
def test_cond():
    not_10_increase = cond([
        (lambda x: x == 10, identity),
        (lambda x: True, increase)])

    eq(not_10_increase(9), 10)
    eq(not_10_increase(10), 10)
    eq(not_10_increase(11), 12)



# Generated at 2022-06-26 00:24:59.228786
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], eq(4)) == 4
    assert find([1, 2, 3, 4, 5], eq(10)) is None


# Generated at 2022-06-26 00:25:01.153569
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: True, lambda x: x + 1),
        (lambda x: False, lambda x: x - 1)
    ])



# Generated at 2022-06-26 00:25:03.483666
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x > 2) == 3
    assert find([1, 2, 3, 4], lambda x: x < 0) is None



# Generated at 2022-06-26 00:25:06.297812
# Unit test for function curried_filter
def test_curried_filter():
    test_fn = curried_filter(lambda x: x % 2 == 0)
    assert test_fn([1, 2, 3, 4, 5]) == [2, 4]


# Generated at 2022-06-26 00:25:11.353839
# Unit test for function find
def test_find():
    collection = [1, 2, 3, 4, 5]
    assert find(collection, lambda x: x % 2 == 0) == 2
    assert find(collection, lambda x: x % 2 != 0) == 1
    assert find(collection, lambda x: x > 100) is None
    assert find(collection, lambda x: True) == 1
    assert find(collection, lambda x: False) is None



# Generated at 2022-06-26 00:26:46.661299
# Unit test for function cond
def test_cond():
    # Test case 0
    def test_case_0():
        def fn_22(*_):
            return True
        def fn_23(*_):
            return False
        var_0 = cond([
            (fn_22, identity),
            (fn_23, identity),
        ])
        var_1 = var_0()
        assert var_1 is True
        return var_1
    test_case_0()

    # Test case 1
    def test_case_1():
        def fn_25(*_):
            return False
        def fn_26(*_):
            return False
        var_2 = cond([
            (fn_25, identity),
            (fn_26, identity),
        ])
        var_3 = var_2()
        assert var_3 is None
        return var_3
    test_

# Generated at 2022-06-26 00:26:50.087423
# Unit test for function memoize
def test_memoize():
    a = [0, 0, 0, 0, 0]
    func = lambda x: a.pop() or (time.sleep(0.1) or x)
    assert(memoize(func)('x') == 'x')
    start = time.time()
    assert(memoize(func)('x') == 'x')
    assert((time.time() - start) < 0.1)



# Generated at 2022-06-26 00:26:53.338441
# Unit test for function cond
def test_cond():
    def is_odd(value):
        return value % 2 == 1
    def is_even(value):
        return value % 2 == 0

    is_true = cond(
        [(is_odd, identity),
         (is_even, increase)],
    )

    assert is_true(1) == 1
    assert is_true(2) == 3



# Generated at 2022-06-26 00:26:59.538006
# Unit test for function curried_filter
def test_curried_filter():
    array_0 = [5, 4, 3, 2, 1]
    assert curried_filter(lambda x: x % 2 == 0)(array_0) == [4, 2], 'curried filter test 0'
    assert curried_filter(lambda x: x > 2)(array_0) == [5, 4, 3], 'curried filter test 1'
    assert curried_filter(lambda x: x % 3 == 0)(array_0) == [3], 'curried filter test 2'
    assert curried_filter(lambda x: x % 9 == 0)(array_0) == [], 'curried filter test 3'



# Generated at 2022-06-26 00:27:06.952092
# Unit test for function cond
def test_cond():
    def divide(number, divider):
        return number / divider

    result_1 = cond(
        [(
            lambda number: number % 2 == 0,
            lambda number: number * 2
        ), (
            lambda number: number <= 10,
            lambda number: number + 10
        ), (
            lambda number: True,
            lambda number: number * 2
        )]
    )(10)
    result_2 = cond(
        [(
            lambda number: number % 2 == 0,
            lambda number: number * 2
        ), (
            lambda number: number <= 10,
            lambda number: number + 10
        ), (
            lambda number: True,
            lambda number: number * 2
        )]
    )(11)

# Generated at 2022-06-26 00:27:12.743833
# Unit test for function cond
def test_cond():
    var_0 = cond([
        (lambda value: True, lambda value: 1),
        (lambda value: False, lambda value: 2),
        (lambda value: False, lambda value: 3),
    ])("")
    assert var_0 == 1
    var_1 = cond([
        (lambda value: False, lambda value: 1),
        (lambda value: True, lambda value: 2),
        (lambda value: False, lambda value: 3),
    ])("")
    assert var_1 == 2
    var_2 = cond([
        (lambda value: False, lambda value: 1),
        (lambda value: False, lambda value: 2),
        (lambda value: True, lambda value: 3),
    ])("")
    assert var_2 == 3


# Generated at 2022-06-26 00:27:20.038151
# Unit test for function curry
def test_curry():
    @curry
    def sum(a, b, c):
        return a + b + c

    assert sum(1)(2, 3) == 6
    assert sum(1)(2)(3) == 6
    assert sum(1, 2)(3) == 6
    assert sum(1)(b=2)(3) == 6
    assert sum(a=1)(2)(3) == 6



# Generated at 2022-06-26 00:27:23.655818
# Unit test for function cond
def test_cond():
    is_even = lambda x: x % 2 == 0
    is_odd = lambda x: x % 2 != 0
    var_0 = cond([
        (is_even, lambda x: x * 2),
        (is_odd, lambda x: x * 3),
    ])(1)


# Generated at 2022-06-26 00:27:26.580965
# Unit test for function memoize
def test_memoize():
    def fibonacci_sequence(n):
        a, b = 0, 1
        for _ in range(n):
            a, b = b, a + b
        return a

    fibonacci_memoized = memoize(fibonacci_sequence)



# Generated at 2022-06-26 00:27:34.582431
# Unit test for function find
def test_find():
    collection = [1, 3, 5, 8, 9]
    assert find(collection, lambda el: el == 3) == 3
    assert find(collection, lambda el: el == 10) is None
    assert find(collection, lambda el: el == 5) == 5
    assert find(collection, lambda el: el == 10) is None
    assert find(collection, lambda el: el == 20) is None
