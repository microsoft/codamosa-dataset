

# Generated at 2022-06-26 00:18:29.720030
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-26 00:18:34.332487
# Unit test for function memoize
def test_memoize():
    def fibonacci(x):
        if x < 2:
            return x
        else:
            return memoized_fibonacci(x-1) + memoized_fibonacci(x-2)

    memoized_fibonacci = memoize(fibonacci)
    assert memoized_fibonacci(17) == 1597



# Generated at 2022-06-26 00:18:38.139507
# Unit test for function curry
def test_curry():
    def fn(*args):
        return sum(args)

    f = curry(fn, 2)

    if f(1)(2) != 3:
        raise AssertionError('error in curry')

    if f(1, 2) != 3:
        raise AssertionError('error in curry')



# Generated at 2022-06-26 00:18:44.005266
# Unit test for function find
def test_find():
    """
    Test find function
    """
    numbers = [1, 2, 3, 4, 5, 6]

    def is_odd(number):
        return bool(number % 2)

    def is_even(number):
        return not is_odd(number)

    assert find(numbers, is_odd) == 1
    assert find(numbers, is_even) == 2
    assert find([], is_odd) is None

    print('test ok')




# Generated at 2022-06-26 00:18:57.077444
# Unit test for function eq
def test_eq():
    assert True is eq(0, 0)
    assert False is eq([], [])
    assert True is eq(curried_map(identity, [1]), [1])
    assert True is eq(
        curried_map(identity, [1, 2, 3]),
        [1, 2, 3]
    )
    assert True is eq(
        curried_filter(lambda x: x > 1, [0, 1, 2, 3]),
        [2, 3]
    )
    assert True is eq(
        curried_filter(lambda x: x > 1, [0, 1, 2, 3]),
        curried_filter(lambda x: x > 1, [0, 1, 2, 3])
    )

# Generated at 2022-06-26 00:19:01.810596
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3,]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3,]) == [2, 3, 4]



# Generated at 2022-06-26 00:19:06.344152
# Unit test for function memoize
def test_memoize():
    counter = [0]

    @memoize
    def fn():
        counter[0] += 1
        return 'local counter: {}'.format(counter[0])

    test_memoize.assert_equals = assert_equals
    test_memoize.assert_equals(fn.__name__, 'fn')
    test_memoize.assert_equals(fn(), 'local counter: 1')
    test_memoize.assert_equals(fn(), 'local counter: 1')
    test_memoize.assert_equals(fn(), 'local counter: 1')
    test_memoize.assert_equals(counter, [1])



# Generated at 2022-06-26 00:19:08.889795
# Unit test for function curry
def test_curry():
    temp = curry(lambda x, y: x + y)
    assert temp(2)(3) == 5
    assert temp(3)(3) == 6
    assert temp(5)(5) == 10



# Generated at 2022-06-26 00:19:21.662695
# Unit test for function find
def test_find():
    assert find(['a', 'b', 'c'], identity) == 'a'
    assert find(['a', 'b', 'c'], lambda x: x == 'b') == 'b'
    assert find(['a', 'b', 'c'], lambda x: x == 'd') is None
    assert find(['a', 'b', 'c'], lambda x: x in ['c', 'd']) == 'c'
    assert find(['a', 'b', 'c'], lambda x: x in ['d', 'e']) is None
    assert find([1, 2, 3], lambda x: x > 2) == 3
    assert find([1, 2, 3], lambda x: x > 3) is None
    assert find(range(5), lambda x: x > 1) == 2

# Generated at 2022-06-26 00:19:26.240558
# Unit test for function curry
def test_curry():
    func = curry(lambda x, y, z, u: x + y + z + u)

    assert func(1, 2, 3, 4) == 10
    assert func(1, 2)(3)(4) == 10
    assert func(1)(2)(3)(4) == 10
    assert func(1)(2, 3, 4) == 10



# Generated at 2022-06-26 00:19:34.768759
# Unit test for function curried_filter
def test_curried_filter():
    value_1 = [1, 2, 3]
    value_2 = [2, 4, 6]
    assert curried_filter(lambda value: value % 2 != 0, value_1) == [1, 3]
    assert curried_filter(lambda value: value % 2 == 0, value_2) == [2, 4, 6]



# Generated at 2022-06-26 00:19:45.179765
# Unit test for function cond
def test_cond():
    assert cond([
        (eq(1), identity),
        (eq(2), increase)
    ])(1) == 1

    assert cond([
        (eq(1), identity),
        (eq(2), increase)
    ])(2) == 3

    assert cond([
        (eq(2), increase),
        (eq(1), identity)
    ])(1) == 1

    assert cond([
        (eq(2), increase),
        (eq(1), identity)
    ])(2) == 3


# Generated at 2022-06-26 00:19:47.388589
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]


# Generated at 2022-06-26 00:19:57.407842
# Unit test for function memoize
def test_memoize():
    func = memoize(lambda x: x + 1)
    assert func.__closure__

    func(2)
    assert func.__closure__[0].cell_contents == [(2, 3)]

    func(2)
    assert func.__closure__[0].cell_contents == [(2, 3)]

    func(2)
    assert func.__closure__[0].cell_contents == [(2, 3)]

    func(3)
    assert func.__closure__[0].cell_contents == [(2, 3), (3, 4)]

    func(3)
    assert func.__closure__[0].cell_contents == [(2, 3), (3, 4)]

    func(3)
    assert func.__closure__[0].cell_contents == [(2, 3), (3, 4)]


# Generated at 2022-06-26 00:20:02.050946
# Unit test for function memoize
def test_memoize():
    var_0 = memoize(increase)()
    print(var_0)
    print(var_0)
    print(var_0)
    var_1 = memoize(identity)()
    print(var_1)
    print(var_1)
    print(var_1)


# Generated at 2022-06-26 00:20:04.076427
# Unit test for function curry
def test_curry():
    var_0 = curry(add)(1, 2)
    var_1 = curry(add)(1)()(2)


# Generated at 2022-06-26 00:20:05.636565
# Unit test for function eq
def test_eq():
    assert eq("test", "test") is True
    assert eq("test", "TEST") is False



# Generated at 2022-06-26 00:20:14.052565
# Unit test for function curried_filter
def test_curried_filter():
    assert(curried_filter(lambda x: x % 2 == 0, list(range(20)))) == \
    [0, 2, 4, 6, 8, 10, 12, 14, 16, 18]

    assert(curried_filter(lambda x: x > 5, list(range(20)))) == \
    [6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]

    assert(curried_filter(lambda x: x % 2 == 0, []) == [])
    assert(curried_filter(lambda x: x % 2 == 0, [1]) == [])
    assert(curried_filter(lambda x: x % 2 == 0, ['1', '2', '3']) == [])

# Generated at 2022-06-26 00:20:20.225652
# Unit test for function find
def test_find():
    # Unit test for function find
    collection = [
        {'id': '3', 'name': 'Vasya'},
        {'id': '4', 'name': 'Petya'},
        {'id': '5', 'name': 'Petya'},
        {'id': '6', 'name': 'Kolya'},
    ]

    call = lambda item: item['name'] == 'Petya'
    print('find', find(collection, call))



# Generated at 2022-06-26 00:20:21.782905
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, False) == False



# Generated at 2022-06-26 00:20:43.862864
# Unit test for function memoize
def test_memoize():
    cache = [
        ('a', 'b'),
        ('c', 'd'),
    ]

    fn = memoize(lambda x: 1 + x)

    assert fn(1) == 2
    assert fn(2) == 3
    assert fn(3) == 4
    assert fn(1) == 2

    cache.append((1, 2))
    cache.append((2, 3))
    cache.append((3, 4))
    assert cache == [
        (1, 2),
        (2, 3),
        (3, 4),
    ]



# Generated at 2022-06-26 00:20:53.518469
# Unit test for function curried_filter

# Generated at 2022-06-26 00:20:57.861680
# Unit test for function find
def test_find():
    print('Function find')

    collection = [1, 2, 3, 4]
    key = lambda x: x > 2
    assert find(collection, key) == 3

    collection = [
        {'a': 1, 'b': 2},
        {'a': 2, 'b': 3},
        {'a': 3, 'b': 4}
    ]
    key = lambda x: x['a'] == 2
    assert find(collection, key) == {'a': 2, 'b': 3}

    collection = [
        {'a': 1, 'b': 2},
    ]
    key = lambda x: x['a'] == 3
    assert find(collection, key) is None



# Generated at 2022-06-26 00:21:00.912013
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x == 1)([1, 2, 3]) == [1]
    assert curried_filter(eq(1))([1, 2, 3]) == [1]



# Generated at 2022-06-26 00:21:09.825745
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [0, 1, 2]) == [1, 2, 3]
    assert curried_map(lambda x: x > 0, [0, 1, 2]) == [False, True, True]
    assert curried_map(lambda x: x + 2, [0]) == [2]
    assert curried_map(lambda x: x + 3, []) == []
    assert curried_map(lambda x: x, (0, 1, 2)) == [0, 1, 2]
    assert curried_map(lambda x: x > 0, (0, 1, 2)) == [False, True, True]
    assert curried_map(lambda x: x + 2, (0,)) == [2]
    assert curried_map(lambda x: x + 3, ()) == []

# Generated at 2022-06-26 00:21:12.766132
# Unit test for function memoize
def test_memoize():
    fn = memoize(lambda x: x)
    eq_(fn(3), 3)
    eq_(fn('a'), 'a')
    eq_(fn(fn), fn)



# Generated at 2022-06-26 00:21:15.176036
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True, 'Eq function fails the test'
    assert eq(1, 2) == False, 'Eq function fails the test'



# Generated at 2022-06-26 00:21:17.832902
# Unit test for function curried_map
def test_curried_map():
    var_4 = curried_map(identity)([1, 2, 3, 4, 5])
    assert var_4 == [1, 2, 3, 4, 5]


# Generated at 2022-06-26 00:21:20.684400
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None
    assert find([1, 2, 3], lambda x: x == 3) == 3



# Generated at 2022-06-26 00:21:21.863770
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-26 00:21:37.494991
# Unit test for function eq
def test_eq():
    # (1)
    assert eq(1, 1)
    # (2)
    assert not eq(1, 2)
    # (3)
    assert eq(1, 1)
    # (4)
    assert not eq(1, 2)
    # (5)
    assert eq(1, 1)
    # (6)
    assert not eq(1, 2)
    # (7)
    assert eq(1, 1)
    # (8)
    assert not eq(1, 2)
    # (9)
    assert eq(1, 1)
    # (10)
    assert not eq(1, 2)
    # (11)
    assert eq(1, 1)
    # (12)
    assert not eq(1, 2)
    # (13)

# Generated at 2022-06-26 00:21:40.015906
# Unit test for function eq
def test_eq():
    assert eq(2, 3) is False
    assert eq(2, 2) is True
    assert eq(2, 2, 4) is True


# Generated at 2022-06-26 00:21:43.097185
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-26 00:21:45.671178
# Unit test for function cond
def test_cond():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-26 00:21:47.572267
# Unit test for function find
def test_find():
    assert find(
        [1, 2, 3, 4],
        lambda item: item == 2
    ) == 2



# Generated at 2022-06-26 00:21:50.120827
# Unit test for function eq
def test_eq():
    assert eq(1, 2) == False
    assert eq(2, 1) == False
    assert eq(2, 2) == True
    assert eq(1)(1) == True


# Generated at 2022-06-26 00:21:52.194973
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-26 00:21:54.418288
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(1), [1, 2])([1, 2], eq(1)) == [1]
    return 'test successful'



# Generated at 2022-06-26 00:21:56.894633
# Unit test for function eq
def test_eq():
    var_0 = eq(2)(2)
    if var_0:
        print(var_0)
    else:
        print(False)


if __name__ == "__main__":
    test_eq()

# Generated at 2022-06-26 00:22:05.654719
# Unit test for function cond
def test_cond():
    var_0 = cond([(lambda x: x == 0, lambda x: x - 1), (lambda x: x > 0, lambda x: x + 1)])
    cond([(lambda x: x == 0, lambda x: x - 1), (lambda x: x > 0, lambda x: x + 1)])(0)
    var_0(0)
    var_0(1)
    cond([(lambda x: x % 2 == 0, lambda x: x - 1), (lambda x: x % 2 != 0, lambda x: x + 1)])(0)
    var_0(0)
    cond([(lambda x: x % 2 == 0, lambda x: x - 1), (lambda x: x % 2 != 0, lambda x: x + 1)])(1)
    var_0(1)

# Generated at 2022-06-26 00:22:19.073501
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(eq(1, 2), False)


# Generated at 2022-06-26 00:22:20.926982
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([0, 1, 2]) == [1, 2, 3]


# Generated at 2022-06-26 00:22:25.466845
# Unit test for function curried_filter
def test_curried_filter():
    print('Test curried_filter')
    array = [1, 2, 3, 4, 5, 6, 7, 8]
    assert curried_filter(
        lambda item: item % 2 == 0,
        array
    ) == [2, 4, 6, 8]
    print('Test curried_filter: OK')



# Generated at 2022-06-26 00:22:29.554542
# Unit test for function memoize
def test_memoize():
    counter = 0

    def increment():
        nonlocal counter
        counter += 1

    def fn():
        increment()
        return counter

    fn_memoized = memoize(fn)

    assert fn() == fn_memoized() == 1

    assert fn() == fn_memoized() == 2

    assert fn() == fn_memoized() == 3
    del counter



# Generated at 2022-06-26 00:22:38.439531
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3]) == [2]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0, [1, 3, 4]) == [4]
    assert curried_filter(lambda x: x % 2 == 0, []) == []
    assert curried_filter(lambda x: x % 2 == 0)([]) == []


# Generated at 2022-06-26 00:22:45.246936
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-26 00:22:46.872078
# Unit test for function eq
def test_eq():
    condition = eq(1,1)
    assert condition == True


# Generated at 2022-06-26 00:22:56.863324
# Unit test for function memoize
def test_memoize():
    counter = 0

    dispatch_fn = cond([
        (lambda value: eq(value, 0), lambda: 'zero'),
        (lambda value: eq(value, 1), lambda: 'one'),
        (lambda value: eq(value, 2), lambda: 'two'),
    ])

    dispatch_fn_memoized = memoize(dispatch_fn)

    assert(dispatch_fn is not dispatch_fn_memoized)

    assert('zero' == dispatch_fn_memoized(0))
    assert('one' == dispatch_fn_memoized(1))
    assert('two' == dispatch_fn_memoized(2))

    assert('zero' == dispatch_fn_memoized(0))
    assert('one' == dispatch_fn_memoized(1))

# Generated at 2022-06-26 00:22:59.173096
# Unit test for function memoize
def test_memoize():
    # Testing function returns normally
    value = 5.0
    if not memoize(lambda n: n * n)(value) == value ** 2:
        raise Exception('Unit test failed')

# Generated at 2022-06-26 00:23:01.613188
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x < 2)([1, 2, 3]) == [1]


# Generated at 2022-06-26 00:23:21.470174
# Unit test for function memoize
def test_memoize():
    var_0 = fn()
    var_1 = 123.0
    var_2 = fn()
    var_3 = 45.0
    var_4 = fn()
    var_5 = (var_0, var_1)
    var_6 = identity(var_4)
    var_7 = (var_2, var_3)
    var_8 = identity(var_7)
    var_9 = fn()
    var_10 = (var_6, var_8)
    var_11 = eq(var_5, var_9)
    var_12 = (var_2, var_3)
    var_13 = (var_11, var_12)
    var_14 = fn()
    var_15 = (var_0, var_1)

# Generated at 2022-06-26 00:23:25.581119
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2])([3, 4]) == [2, 3, 4, 5]



# Generated at 2022-06-26 00:23:28.245808
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([-1, -2, -3]) == [0, -1, -2]


# Generated at 2022-06-26 00:23:29.588705
# Unit test for function curry
def test_curry():
    assert isinstance(curry(lambda x, y, z: x + y + z), FunctionType)


# Generated at 2022-06-26 00:23:34.447167
# Unit test for function cond
def test_cond():

    condition_0 = lambda x: x % 2 == 0
    condition_1 = lambda x: x % 3 == 0

    execute_0 = identity
    execute_1 = increase

    assert cond([
        (condition_0, execute_0),
        (condition_1, execute_1)
    ])(0) == 0

    assert cond([
        (condition_0, execute_0),
        (condition_1, execute_1)
    ])(1) == 2



# Generated at 2022-06-26 00:23:37.224383
# Unit test for function eq
def test_eq():
    assert eq(2, 2) == True
    assert eq(2, '2') == False
    assert eq(['a'], ['a']) == False
    assert eq(['a'], (['a'],)) == False


# Generated at 2022-06-26 00:23:43.392461
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 2, [1, 2, 3]) == [3, 4, 5]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + x, {1, 2, 3}) == [2, 4, 6]
    assert curried_map(lambda x: x + 2, {1, 2, 3}) == [3, 4, 5]


# Generated at 2022-06-26 00:23:48.009666
# Unit test for function cond
def test_cond():
    def test_case_0():
        inc = cond([(lambda x: x < 2, lambda x: x + 1),
                    (lambda x: x % 2 == 0, lambda x: x * 2)])
        assert(inc(1) == 2)
        assert(inc(2) == 4)
        assert(inc(3) == 4)
        assert(inc(5) == 6)

    test_case_0()

# Generated at 2022-06-26 00:23:54.055058
# Unit test for function curried_map
def test_curried_map():
    array = [1, 2, 3]
    curried_map_func = curried_map(lambda x: x + 1)
    result = curried_map_func(array)
    assert result == array.__map_func__(lambda x: x + 1)

    curried_map_func = curried_map(lambda x: x + 1, array)
    assert result == curried_map_func(lambda x: x + 1, array)



# Generated at 2022-06-26 00:23:55.784316
# Unit test for function eq
def test_eq():
    eq_2 = eq(3)
    assert eq_2(3)



# Generated at 2022-06-26 00:24:10.824584
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-26 00:24:12.539209
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(add1)([1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]



# Generated at 2022-06-26 00:24:20.754447
# Unit test for function cond
def test_cond():
    from utils.func_utils import cond, eq
    from utils.tests.test_utils import test

    equality_fn = lambda value, value1: value == value1
    length_fn = len
    is_empty = lambda collection: equality_fn(length_fn(collection), 0)
    is_one_item = lambda collection: equality_fn(length_fn(collection), 1)
    is_more_than_one_item = lambda collection: equality_fn(length_fn(collection), 2)

    test_fn1 = lambda collection: 'empty'
    test_fn2 = lambda collection: 'one item'
    test_fn3 = lambda collection: 'one more than one item'


# Generated at 2022-06-26 00:24:26.497682
# Unit test for function curry
def test_curry():
    curried_f = curry(lambda x1, x2, x3: x1 + x2 + x3)
    print('curried_f(1)(2)(3) = ', curried_f(1)(2)(3))
    print('curried_f(1)(2, 3) = ', curried_f(1)(2, 3))
    print('curried_f(1, 2)(3) = ', curried_f(1, 2)(3))
    print('curried_f(1, 2, 3) = ', curried_f(1, 2, 3))



# Generated at 2022-06-26 00:24:29.977147
# Unit test for function memoize
def test_memoize():
    var_0 = memoize(identity, eq)
    var_1 = var_0(1)
    var_2 = var_0(1)
    var_3 = var_0(2)
    var_4 = [var_1, var_2, var_3]
    print(var_4)



# Generated at 2022-06-26 00:24:34.779135
# Unit test for function curried_filter
def test_curried_filter():
    var_0 = curried_filter(eq(0), [0, 1, 0, 2, 0])
    assert var_0 == [0, 0, 0]
    var_1 = curried_filter(lt(1), [0, 1, 0, 2, 0])
    assert var_1 == [0, 0, 0]
    var_2 = curried_filter(gt(2), [0, 1, 0, 2, 0])
    assert var_2 == []


# Generated at 2022-06-26 00:24:38.637748
# Unit test for function find
def test_find():
    assert find(collection=[1, 2, 3], key=identity) == 1, 'Result should be 1'
    assert find(collection=[1, 2, 3], key=increase) == None, 'Result should be None'
    assert find(collection=[1, 2, 3], key=eq(1)) == 1, 'Result should be 1'



# Generated at 2022-06-26 00:24:41.271715
# Unit test for function find
def test_find():
    collection = list(range(10))
    assert find(collection, lambda x: x < 5) == 0
    assert find(collection, lambda x: x > 5) == 6
    assert find(collection, lambda x: x == 5) == 5



# Generated at 2022-06-26 00:24:45.241051
# Unit test for function curried_filter
def test_curried_filter():
    res = curried_filter(eq(1), [1, 2, 3, 4])
    assert len(res) == 1
    assert res[0] == 1
    res = curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4])
    assert len(res) == 2
    assert res[0] == 2
    assert res[1] == 4



# Generated at 2022-06-26 00:24:48.056297
# Unit test for function find
def test_find():
    assert(find([1, 2, 3], lambda x: x == 2) == 2)
    assert(find([1, 2, 3], lambda x: x < 0) is None)
    assert(find([], lambda x: x == 2) is None)



# Generated at 2022-06-26 00:25:16.930664
# Unit test for function curried_map
def test_curried_map():
    assert curried_map([i for i in range(1, 10)]) == \
        [i for i in range(2, 11)]



# Generated at 2022-06-26 00:25:19.600331
# Unit test for function find
def test_find():
    assert find([0, 1, 2, 3], lambda x: x == 2) == 2
    assert find([0, 1, 2, 3], lambda x: x == 7) is None



# Generated at 2022-06-26 00:25:21.562800
# Unit test for function curried_map
def test_curried_map():
    assert(curried_map(increase, [1, 2, 3]) == [2, 3, 4])



# Generated at 2022-06-26 00:25:30.902455
# Unit test for function cond
def test_cond():
    cond_1 = cond([
        (eq('a'), identity),
        (eq('b'), increase),
    ])
    cond_2 = cond([
        (eq('c'), increase),
        (eq('b'), identity),
    ])
    assert(cond_1('a') == 'a')
    assert(cond_1('b') == 'c')
    assert(cond_2('b') == 'b')
    assert(cond_2('c') == 'd')



# Generated at 2022-06-26 00:25:35.547729
# Unit test for function find
def test_find():
    def is_positive(x):
        return x > 0

    assert find([], lambda x: x < 0) is None
    assert find([-1, 0, 1], lambda x: x < 0) == -1
    assert find([-1, 0, 1], lambda x: x > 0) == 1
    assert find([-1, 0, 1], is_positive) == 1


# Generated at 2022-06-26 00:25:40.265193
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(curried_map(increase), [1, 2, 3, 4]) == [2, 3, 4, 5]
    assert curried_map(identity)([1, 2, 3, 4]) == [1, 2, 3, 4]



# Generated at 2022-06-26 00:25:49.563018
# Unit test for function memoize
def test_memoize():

    def func(n):
        if n == 0:
            return 1
        return n + func(n - 1)

    assert memoize(func, eq)(0) == 1
    assert memoize(func, eq)(2) == 3
    assert memoize(func, eq)(0) == 1
    assert memoize(func, eq)(4) == 5
    assert memoize(func, eq)(0) == 1
    assert memoize(func, eq)(1) == 2
    assert memoize(func, eq)(0) == 1
    assert memoize(func, eq)(3) == 4
    assert memoize(func, eq)(0) == 1



# Generated at 2022-06-26 00:25:52.290170
# Unit test for function find
def test_find():
    test_list = [10, 20, 30, 40]
    assert find(test_list, lambda x: x == 20) == 20
    assert find(test_list, lambda x: x == 50) is None
    print('Done')



# Generated at 2022-06-26 00:25:55.860650
# Unit test for function memoize
def test_memoize():
    f_times2 = lambda x: 2 * x
    f_times2_memoized = memoize(f_times2)
    assert f_times2_memoized(2) == 4
    assert f_times2_memoized(2) == 4


# Unit tests for function compose

# Generated at 2022-06-26 00:25:58.803382
# Unit test for function eq
def test_eq():
    assert eq(identity(1), 1) == True
    assert eq(identity(1), 2) == False


# Generated at 2022-06-26 00:27:12.889356
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)


# Generated at 2022-06-26 00:27:14.340291
# Unit test for function curried_map
def test_curried_map():
    assert(curried_map(identity, [1, 2, 3])) == [1, 2, 3]


# Generated at 2022-06-26 00:27:25.784053
# Unit test for function cond
def test_cond():
    assert cond([

    ])() == None
    assert cond([
        (lambda x: x < 1, lambda x: x),
        (lambda x: x > -1, lambda y: "Hello"),
    ])(0.5) == 0.5
    assert cond([
        (lambda x: x < 1, lambda x: x),
        (lambda x: x > -1, lambda y: "Hello"),
    ])(10.5) == "Hello"
    assert cond([
        (lambda x: x < 1, lambda x: x),
        (lambda x: x > -1, lambda y: "Hello"),
    ])() == None
    assert cond([
        (lambda x: x < 1, lambda x: x),
    ])() == None

# Generated at 2022-06-26 00:27:35.483815
# Unit test for function curried_map
def test_curried_map():
    # Unit test for function curried_map
    # Test for just two arguments
    result_0 = curried_map(increase, [1, 2, 3])
    assert result_0 == [2, 3, 4]
    # Test for first argument
    result_0 = curried_map(increase, [])
    result_1 = curried_map(increase)
    result_2 = result_1([1, 2, 3])
    assert result_0 == []
    assert result_2 == [2, 3, 4]



# Generated at 2022-06-26 00:27:42.991446
# Unit test for function curried_map
def test_curried_map():
    var_0 = [1, 2, 3, 4, 5]
    var_1 = lambda x: x < 3
    var_2 = curried_map(lambda x: x * x, var_0)    # [1, 4, 9, 16, 25]
    var_3 = curried_filter(lambda x: x < 3, var_0) # [1, 2]
    var_4 = curried_filter(lambda x: x < 3, var_2) # [1]
    var_5 = curried_map(var_1, var_0)              # [False, False, True, True, True]

    assert var_2 == [1, 4, 9, 16, 25]
    assert var_3 == [1, 2]
    assert var_4 == [1]

# Generated at 2022-06-26 00:27:49.092422
# Unit test for function memoize
def test_memoize():
    class Storage:
        def __init__(self):
            self.counter = 0

        def inc(self):
            self.counter += 1
            return self.counter

    storage = Storage()
    memoized_fn = memoize(storage.inc, key=eq)

    result = [memoized_fn(x) for x in range(10)]
    assert result == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],\
        'Memoization not works properly'

    result = [memoized_fn(x) for x in range(10)]
    assert result == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],\
        'Memoization not works properly'


# Generated at 2022-06-26 00:27:53.407499
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(4)) is None, 'not found'

    # found
    assert find([
        {'a': 1, 'b': 2},
        {'c': 1, 'd': 2},
        {'e': 1, 'f': 2},
    ], eq({'e': 1, 'f': 2})) == {'e': 1, 'f': 2}



# Generated at 2022-06-26 00:28:00.177963
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(1))([1, 2, 3, 4]) == [1]
    assert curried_filter(eq(2))([1, 2, 3, 4]) == [2]
    assert curried_filter(eq(3))([1, 2, 3, 4]) == [3]
    assert curried_filter(eq(4))([1, 2, 3, 4]) == [4]
    assert curried_filter(eq(5))([1, 2, 3, 4]) == []


# Generated at 2022-06-26 00:28:03.764135
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4], lambda x: x == 4) == 4
    assert find([1, 2, 3, 4], lambda x: x == 5) is None


# Generated at 2022-06-26 00:28:10.414024
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x ** 2, [1, 4, 9, 16, 25, 36])(None) == [1, 16, 81, 256, 625, 1296]

