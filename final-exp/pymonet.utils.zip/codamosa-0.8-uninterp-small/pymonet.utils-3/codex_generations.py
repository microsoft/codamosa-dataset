

# Generated at 2022-06-26 00:18:30.617892
# Unit test for function eq
def test_eq():
    assert (eq(1, 1))
    assert not (eq(1, 2))


# Generated at 2022-06-26 00:18:36.112691
# Unit test for function cond
def test_cond():
    cond_fn = cond([
        (lambda value: True if value < 0 else False, lambda value: 0),
        (lambda value: True if value == 0 else False, lambda value: 1),
        (lambda value: True if value > 0 else False, lambda value: 2),
    ])

    assert cond_fn(10) == 2
    assert cond_fn(0) == 1
    assert cond_fn(-1) == 0



# Generated at 2022-06-26 00:18:40.486874
# Unit test for function cond
def test_cond():
    # test for cond
    assert cond([
        (lambda num: num > 10, lambda _: 'greater than 10'),
        (lambda num: num > 5, lambda _: 'greater than 5'),
        (lambda num: num > 0, lambda _: 'greater than 0')
    ])(9) == 'greater than 5'



# Generated at 2022-06-26 00:18:42.592345
# Unit test for function curried_filter
def test_curried_filter():
    curried_filter(increase, [1, 2, 3, 4]) == [2, 3, 4, 5]


# Generated at 2022-06-26 00:18:55.145864
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 1) == 1
    assert find([1, 2, 3, 4], lambda x: x == 2) == 2
    assert find([1, 2, 3, 4], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4], lambda x: x == 4) == 4
    assert find([1, 2, 3, 4], lambda x: x == 0) is None
    assert find([1, 2, 3, 4], lambda x: x > 1) == 2
    assert find([1, 2, 3, 4], lambda x: x > 2) == 3
    assert find([1, 2, 3, 4], lambda x: x > 3) == 4
    assert find([1, 2, 3, 4], lambda x: x > 4) is None
   

# Generated at 2022-06-26 00:19:06.796487
# Unit test for function cond
def test_cond():
    equals_one = fn(lambda item, x=1: eq(item, x))
    greater_than_one = fn(lambda item: item > 1)
    return_one = fn(lambda x: 1)
    return_two = fn(lambda x: 2)
    return_three = fn(lambda x: 3)

    def execute(fn, value): return fn(value)


# Generated at 2022-06-26 00:19:12.970832
# Unit test for function curried_filter
def test_curried_filter():

    assert curried_filter(lambda a: a % 3 == 0, list(range(6))) == [0, 3]
    assert curried_filter(lambda a: a % 3 == 0, {2: 3, 3: 5, 4: 7, 5: 8}) == [3, 6]
    assert curried_filter(lambda a: a > 2, {2: 3, 3: 5, 4: 7, 5: 8}) == [3, 5]
    assert curried_filter(lambda a: a % 3 == 0, [2, 3, 4, 5]) == [3]
    assert curried_filter(lambda a: a < 2, [2, 3, 4, 5]) == []
    


# Generated at 2022-06-26 00:19:22.293943
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 10)([1, 2, 3, 4, 5]) == [11, 12, 13, 14, 15]
    assert curried_filter(lambda x: x > 10)([11, 12, 13, 14, 15]) == [11, 12, 13, 14, 15]
    assert curried_filter(lambda x: x > 10)([1, 2, 3, 4, 5, 11, 12, 13, 14, 15]) == [11, 12, 13, 14, 15]



# Generated at 2022-06-26 00:19:26.934178
# Unit test for function curry
def test_curry():
    curried_add = curry(lambda a, b, c: a + b + c)

    assert curried_add(1)(2)(3) == 6
    assert curried_add(1)(2, 3) == 6
    assert curried_add(1, 2)(3) == 6
    assert curried_add(1, 2, 3) == 6



# Generated at 2022-06-26 00:19:33.193543
# Unit test for function find
def test_find():
    """Test for function find"""
    print("test for function find")
    assert find([1, 2, 3, 4, 5], lambda x: x % 2 == 0) == 2
    assert find([1, 3, 5], lambda x: x % 2 == 0) is None
    assert find([1, -1, 2, -2], lambda x: x < 0) == -1
    assert find([1, -1, 2, -2], lambda x: x > 0) == 1
    assert find([1, -1, 2], lambda x: x > 2) is None
    print("test for function find: success")



# Generated at 2022-06-26 00:19:41.748053
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x < 3)([1, 2, 3, 4]) == [1, 2]



# Generated at 2022-06-26 00:19:46.575841
# Unit test for function memoize
def test_memoize():
    def fib(n: int) -> int:
        if n <= 2:
            return 1
        return fib(n - 1) + fib(n - 2)

    fibo_memoized = memoize(fib)
    assert fibo_memoized(5) == 5
    assert fibo_memoized(10) == 55



# Generated at 2022-06-26 00:19:49.330582
# Unit test for function find
def test_find():
    assert find([1, 2, 4, 5, 6], lambda x: x == 2) == 2
    assert find([1, 2, 4, 5, 6], lambda x: x == 3) is None



# Generated at 2022-06-26 00:19:59.218272
# Unit test for function memoize
def test_memoize():
    class Class:
        value = 1

    def fn2(arg):
        return arg

    # Test callable object
    fn_object = Class()
    assert memoize(fn_object)() == 1

    # Test callable function
    assert memoize(fn2)("argument") == "argument"

    # Test if recursive function doesn't work
    def memoized_recursion(argument):
        return memoized_recursion(argument)

    assert memoize(memoized_recursion)() is None

    def fn3(arg):
        return arg

    # Test if argument different by value
    # but equal by object(class) would be used
    # cached value
    memoized_fn = memoize(fn3)
    memoized_fn("argument")
    arg_0 = Class()

# Generated at 2022-06-26 00:20:03.241862
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x * x)([1, 2, 3]) == [1, 4, 9]



# Generated at 2022-06-26 00:20:10.047127
# Unit test for function find
def test_find():
    expected_find_b = "b"
    expected_find_c = "c"
    expected_find_None = None

    assert eq(find(["a", "b", "c"], lambda value: value == "b"), expected_find_b)
    assert eq(find(["a", "b", "c"], lambda value: value == "c"), expected_find_c)
    assert eq(find(["a", "b", "c"], lambda value: value == "d"), expected_find_None)
    assert eq(find(["a", "b", "c"], lambda value: value == "A"), expected_find_None)



# Generated at 2022-06-26 00:20:19.289724
# Unit test for function curried_map
def test_curried_map():
    test_collection = [1, 2, 3]
    assert curried_map(lambda x: x + 1, test_collection) == [2, 3, 4]
    assert curried_map(lambda x: x * 2, test_collection) == [2, 4, 6]
    assert curried_map(lambda x: x ** 2, test_collection) == [1, 4, 9]
    assert curried_map(lambda x: x % 4, test_collection) == [1, 2, 3]
    assert curried_map(lambda x: False, test_collection) == [False, False, False]
    assert curried_map(lambda x: True, test_collection) == [True, True, True]
    assert curried_map(lambda x: None, test_collection) == [None, None, None]

    test_

# Generated at 2022-06-26 00:20:22.522550
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq("1", "1")
    assert not eq("1", "2")
    assert eq("a", "a")
    assert not eq("a", "b")


# Generated at 2022-06-26 00:20:24.416936
# Unit test for function memoize
def test_memoize():
    assert isinstance(memoize(identity), Callable)
    # assert memoize(identity)(0) == identity(0)



# Generated at 2022-06-26 00:20:25.355521
# Unit test for function memoize
def test_memoize():
    var_0 = fn()


# Generated at 2022-06-26 00:20:50.881527
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [])([]) == curried_map(identity, []) == [], \
        "curried_map(identity, []) failed"
    assert curried_map(identity, [1, 2, 3])([1, 2, 3]) == curried_map(identity, [1, 2, 3]) == [1, 2, 3], \
        "curried_map(identity, [1, 2, 3]) failed"
    assert curried_map(identity, [1, 2, 3])([1, 2, 3]) == curried_map(identity, [1, 2, 3]) == [1, 2, 3], \
        "curried_map(identity, [1, 2, 3]) failed"

# Generated at 2022-06-26 00:20:53.264148
# Unit test for function eq
def test_eq():
    var_0 = eq(3, 4)
    var_1 = eq(3, 3)
    assert var_0 == False
    assert var_1 == True


# Generated at 2022-06-26 00:20:56.616870
# Unit test for function memoize
def test_memoize():
    assert memoize(lambda x: x + 1)(1) == 2
    assert memoize(lambda x: x + 2)(2) == 4
    assert memoize(lambda x: x + 3)(3) == 6
    assert memoize(lambda x: x + 4)(1) == 2



# Generated at 2022-06-26 00:20:58.257061
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x < 5, list(range(10))) == [0, 1, 2, 3, 4]



# Generated at 2022-06-26 00:21:00.869421
# Unit test for function curried_filter
def test_curried_filter():
    assert list(filter(lambda x: x < 0, range(-2, 2))) == list(curried_filter(lambda x: x < 0, range(-2, 2)))



# Generated at 2022-06-26 00:21:02.936522
# Unit test for function curried_filter
def test_curried_filter():
    items = [1, 2, 3]
    assert curried_filter(lambda x: x < 3)(items) == [1, 2]



# Generated at 2022-06-26 00:21:08.240130
# Unit test for function curry
def test_curry():
    assert curry(add, 3)(1)(1)(1) == 3
    assert curry(add, 2)(1)(1) == 2
    assert curry(add, 1)(1) == 1
    assert curry(add, 2)(1, 2) == 3
    assert curry(add, 3)(1, 2, 3) == 6
    assert curry(add, 2)(1, 2, 3) == 3
    assert curry(add, 2)(1, 2, 3, 4) == 3



# Generated at 2022-06-26 00:21:15.515768
# Unit test for function cond
def test_cond():
    assert cond(
        [
            (eq(1), lambda value: value),
            (eq(2), lambda value: increase(value))
        ]
    )(1) == 1
    assert cond(
        [
            (eq(1), lambda value: value),
            (eq(2), lambda value: increase(value))
        ]
    )(2) == 3
    assert cond(
        [
            (eq(1), lambda value: value),
            (eq(2), lambda value: increase(value))
        ]
    )(3) is None



# Generated at 2022-06-26 00:21:24.285155
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x < 10, lambda x: x + 10),
        (lambda x: x > 10, lambda x: x - 10),
    ])(3) == 13
    assert cond([
        (lambda x: x < 10, lambda x: x + 10),
        (lambda x: x > 10, lambda x: x - 10),
    ])(15) == 5
    assert cond([
        (lambda x: x == 10, lambda x: x + 5),
        (lambda x: x > 10, lambda x: x - 10),
    ])(15) == 5
    assert cond([
        (lambda x: x > 10, lambda x: x - 10),
        (lambda x: x == 10, lambda x: x + 5),
    ])(15) == 5

# Generated at 2022-06-26 00:21:27.166950
# Unit test for function curried_filter
def test_curried_filter():
    positive_is_even = curried_filter(eq(0), increase, percent=2)  # is_even = fn(positive_is_even)
    assert positive_is_even(4) == 1



# Generated at 2022-06-26 00:21:48.693702
# Unit test for function eq
def test_eq():
    var_0 = eq(1, 2)
    var_1 = eq(2, 2)



# Generated at 2022-06-26 00:21:50.907347
# Unit test for function curry
def test_curry():
    def fn(arg1, arg2):
        return arg1 + arg2
    var_0 = curry(fn)(1)(2)
    # assert var_0 == 3



# Generated at 2022-06-26 00:21:53.329884
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq(1)(1) == True



# Generated at 2022-06-26 00:21:57.442661
# Unit test for function cond
def test_cond():
    is_even = lambda x: x % 2 == 0
    add_one = lambda x: x + 1
    mult_on_2 = lambda x: x * 2

    result = cond(
        [(is_even, add_one),
         (lambda _: True, mult_on_2)])

    assert result(1) == 2
    assert result(2) == 3



# Generated at 2022-06-26 00:22:05.260191
# Unit test for function memoize
def test_memoize():
    test_cache = 'cache'

    # Test function
    def test_fn(value):
        test_cache[value] = value + 1
        return value + 1

    # Test cases
    def test_case_0():
        memoized_fn = memoize(test_fn)
        assert memoized_fn(1) == 2
        assert test_cache == {1: 2}
        assert memoized_fn(1) == 2
        assert test_cache == {1: 2}
        assert memoized_fn(2) == 3
        assert test_cache == {1: 2, 2: 3}
        memoized_fn(1) == 2

    test_case_0()



# Generated at 2022-06-26 00:22:08.158907
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3, 4]) == [2, 3, 4, 5]
    assert curried_map(increase)([1, 2, 3, 4]) == [2, 3, 4, 5]



# Generated at 2022-06-26 00:22:11.344327
# Unit test for function curried_map
def test_curried_map():
	assert curried_map(identity, [1,2,3,4]) == [1,2,3,4]
	assert curried_map(increase, [1,2,3,4]) == [2,3,4,5]


# Generated at 2022-06-26 00:22:15.648914
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x * 2 == 4) is None
    assert find([{'a': 1}, {'a': 2}, {'a': 3}], lambda x: x['a'] == 1) == {'a': 1}



# Generated at 2022-06-26 00:22:17.129704
# Unit test for function eq
def test_eq():
    assert(eq(1, 1) == True)
    assert(eq(0, 1) == False)


# Generated at 2022-06-26 00:22:23.280253
# Unit test for function cond
def test_cond():
    collection = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

    collection_conditional_increase = cond(
        [(lambda x: x % 2 == 0, increase),
         (lambda _: True, identity)]
    )

    assert collection_conditional_increase(2) == 3
    assert collection_conditional_increase(5) == 5
    assert all(map(lambda x: x % 2 == 0, map(collection_conditional_increase, collection)))


# Generated at 2022-06-26 00:22:48.110753
# Unit test for function curried_map
def test_curried_map():
    assert(curried_map(increase)([0, 1, 2]) == [1, 2, 3])
    assert(curried_map(increase, [0, 1, 2]) == [1, 2, 3])



# Generated at 2022-06-26 00:22:53.424868
# Unit test for function memoize
def test_memoize():
    var_1 = memoize(identity)
    var_2 = var_1(1)
    var_3 = var_1(1)
    var_4 = var_1(2)
    var_5 = [var_2, var_3, var_4]


# Generated at 2022-06-26 00:22:59.482337
# Unit test for function find
def test_find():
    assert find([], lambda element: True) is None
    assert find([1, 2, 3], lambda element: True) == 1
    assert find([1, 2, 3], lambda element: element == 2) == 2
    assert find([1, 2, 3], lambda element: element == 4) is None



# Generated at 2022-06-26 00:23:02.235309
# Unit test for function eq
def test_eq():
    assert eq(8, 8) == True
    assert eq(8, 5) == False
    assert eq(8)(8) == True



# Generated at 2022-06-26 00:23:05.897686
# Unit test for function curry
def test_curry():
    assert callable(curry)
    assert curry(lambda x: x, 0)() == ()
    assert curry(lambda x: x, 1)(1) == 1
    assert curry(lambda x, y: (x, y), 2)(1, 2) == (1, 2)



# Generated at 2022-06-26 00:23:07.172490
# Unit test for function eq
def test_eq():
    assert eq(1, 2) == False
    assert eq(1, 1) == True



# Generated at 2022-06-26 00:23:09.296883
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda item: item == 2) == 2
    assert find([1, 2, 3], lambda item: item == 4) is None



# Generated at 2022-06-26 00:23:11.566171
# Unit test for function curried_map
def test_curried_map():
    collection = [1, 2, 3]
    result = curried_map(increase, collection)

    assert [2, 3, 4] == result



# Generated at 2022-06-26 00:23:14.979220
# Unit test for function find
def test_find():
    def test_case_0():
        var_0 = find(list(x for x in range(0, 100)), lambda x: x == 5)
        assert var_0 == 5

    test_case_0()



# Generated at 2022-06-26 00:23:18.975636
# Unit test for function curried_filter
def test_curried_filter():
    # Test case curried_filter_0
    var_0 = curried_filter(increase, [1, 2, 3, 4, 5])

    # Assert function curried_filter
    assert var_0 == [2, 3, 4, 5, 6], \
        'Value of var_0 is not equals to [2, 3, 4, 5, 6]'



# Generated at 2022-06-26 00:24:11.877348
# Unit test for function find
def test_find():
    assert(find([1, 2, 3, 4, 5], eq(2)) == 2)
    assert(find([1, 2, 3, 4, 5], eq(7)) is None)



# Generated at 2022-06-26 00:24:18.262408
# Unit test for function eq
def test_eq():
    eq_0 = eq(identity('qwerty'), 'qwerty')
    eq_1 = eq(identity('qwerty'), 'qwe')
    eq_2 = eq(identity('qwerty'), 5)
    eq_3 = eq('qwerty', 'qwerty')

    # test cases for function eq
    assert eq_0, "Test case for function eq failed"
    assert not eq_1, "Test case for function eq failed"
    assert not eq_2, "Test case for function eq failed"
    assert eq_3, "Test case for function eq failed"



# Generated at 2022-06-26 00:24:22.142457
# Unit test for function find
def test_find():
    assert identity(identity) == identity, "Identity function should return identity function"
    assert identity(identity(identity)) == identity, "Identity(identity) should return identity function"

    assert increase(1) == 2, "Increase function should increase argument by 1"
    assert increase(0) == 1, "Increase.2"
    assert increase(1) == 2, "Increase.3"

# Generated at 2022-06-26 00:24:24.350661
# Unit test for function find
def test_find():
    assert find(['a', 'b'], lambda x: x == "b") == "b"
    assert find(['a', 'b'], lambda x: x == "c") is None



# Generated at 2022-06-26 00:24:28.988464
# Unit test for function curried_filter
def test_curried_filter():
    # Case 0
    expected_result = []
    values = curried_filter(eq, [])
    assert values == expected_result

    # Case 1
    expected_result = [1]
    values = curried_filter(eq(1), [1, 2])
    assert values == expected_result

    # Case 2
    values = curried_filter(eq(1), [])
    assert values == expected_result



# Generated at 2022-06-26 00:24:35.543391
# Unit test for function cond
def test_cond():
    result = cond([
        (eq(1), identity),
        (eq(2), identity),
        (eq(3), identity),
    ])(1)

    assert result == 1, 'Should return input value'

    result = cond([
        (eq(1), identity),
        (eq(2), identity),
        (eq(3), identity),
    ])(2)

    assert result == 2, 'Should return input value'

    result = cond([
        (eq(1), identity),
        (eq(2), identity),
        (eq(3), identity),
    ])(3)

    assert result == 3, 'Should return input value'



# Generated at 2022-06-26 00:24:42.415953
# Unit test for function cond
def test_cond():
    """
    Test cond function.
    """
    assert cond([
        (lambda var: var == 20,
            lambda var: 2 * var),
        (lambda var: var == 0,
            lambda var: 0),
    ])(20) == 40
    assert cond([
        (lambda var: var == 20,
            lambda var: 2 * var),
        (lambda var: var == 0,
            lambda var: 0),
    ])(0) == 0
    assert cond([
        (lambda var: var == 20,
            lambda var: 2 * var),
        (lambda var: var == 0,
            lambda var: 0),
    ])(1) is None



# Generated at 2022-06-26 00:24:47.064186
# Unit test for function curried_map
def test_curried_map():
    functions = [
        (curried_map(lambda x: x*x, [1, 2, 3]), [1, 4, 9]),
        (curried_map(lambda x: x*x, []), []),
        (curried_map(lambda x: x*x, [1, 2, 3, 4]), [1, 4, 9, 16])
    ]

    for function in functions:
        assert function[0] == function[1]



# Generated at 2022-06-26 00:24:49.778238
# Unit test for function curried_filter
def test_curried_filter():
    list_0 = [1, 2, 3, 4, 5, 6]
    filter_0 = curried_filter(
        lambda item: item % 2 == 0
    )
    filter_1 = filter_0(list_0)
    print(filter_1)



# Generated at 2022-06-26 00:24:51.066555
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-26 00:26:24.984777
# Unit test for function memoize
def test_memoize():
    # Check result of memoized function
    var_0 = memoize(identity)(10) == identity(10)
    # Check result is cached
    var_1 = memoize(identity)(10) == 10
    # Check that cache is not overwritten
    var_2 = memoize(increase)(10) == 11
    var_3 = memoize(identity)(10) == 10

    return var_0 and var_1 and var_2 and var_3



# Generated at 2022-06-26 00:26:28.675243
# Unit test for function curried_filter
def test_curried_filter():
    # Given
    collection = [0, 1, 2, 3, 4, 5]
    filterer = lambda value: value > 2
    expected_value = [3, 4, 5]

    # When
    actual_value = curried_filter(filterer, collection)

    # Then
    assert actual_value == expected_value



# Generated at 2022-06-26 00:26:32.021864
# Unit test for function memoize
def test_memoize():
    def fn(n):
        return f"result: {n}"

    def eq(a, b):
        return a == b

    memoized_fn = memoize(fn, key=eq)

    assert memoized_fn(1) == "result: 1"
    assert memoized_fn(1) == "result: 1"
    assert memoized_fn(2) == "result: 2"



# Generated at 2022-06-26 00:26:34.607018
# Unit test for function curry
def test_curry():
    add = curry(lambda x, y: x + y)
    add_one = add(1)

    assert add(1, 2) == 3
    assert add_one(2) == 3
    assert add_one(10) == 11



# Generated at 2022-06-26 00:26:41.732188
# Unit test for function curried_map
def test_curried_map():
    # True
    var_1 = curried_map(identity, [1, 2, 3, 4]) == [1, 2, 3, 4]
    var_2 = curried_map(identity, [5, 6, 7, 8]) == [5, 6, 7, 8]
    var_3 = curried_map(increase, [1, 2, 3, 4]) == [2, 3, 4, 5]
    var_4 = curried_map(increase, [5, 6, 7, 8]) == [6, 7, 8, 9]
    var_5 = curried_map(lambda x: x*x, [1, 2, 3, 4]) == [1, 4, 9, 16]
    var_6 = curried_map(lambda x: x*x, [5, 6, 7, 8])

# Generated at 2022-06-26 00:26:43.281112
# Unit test for function memoize
def test_memoize():
    var_0 = memoize(test_case_0)
    var_1 = var_0()
    assert var_1 == var_0()



# Generated at 2022-06-26 00:26:50.553369
# Unit test for function curry
def test_curry():
    # Setup
    var_0 = curry(lambda x, y: x if x > y else y)
    var_1 = var_0(1)
    assert var_1(2) == 1
    assert var_1(3) == 1
    assert var_1(4) == 1
    assert var_1(5) == 1
    var_2 = var_0(2)
    assert var_2(1) == 2
    assert var_2(3) == 2
    assert var_2(4) == 2
    assert var_2(5) == 2
    var_3 = var_0(3)
    assert var_3(1) == 3
    assert var_3(2) == 3
    assert var_3(4) == 3
    assert var_3(5) == 3
    var_4 = var

# Generated at 2022-06-26 00:26:52.370014
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: True)([1, 2, 3]) == [1, 2, 3]
    assert curried_filter(lambda x: False)([1, 2, 3]) == []



# Generated at 2022-06-26 00:26:54.450462
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(2)) == 2, "Find in list"



# Generated at 2022-06-26 00:26:55.852506
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], eq(2)) == 2

