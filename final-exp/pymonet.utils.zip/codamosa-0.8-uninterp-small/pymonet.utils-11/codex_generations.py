

# Generated at 2022-06-26 00:18:37.731812
# Unit test for function cond

# Generated at 2022-06-26 00:18:45.011442
# Unit test for function curried_map
def test_curried_map():
    """
    Test curried_map function.

    :returns: True if test passed, False if test failed
    :rtype: Boolean
    """
    # Test curried_map count items
    assert len(curried_map(increase)(list(range(10)))) == len(list(range(10)))

    # Test curried_map list items
    assert curried_map(increase)(list(range(10))) == list(range(1, 11))

    # Test curried_map
    assert curried_map(increase, list(range(10))) == list(range(1, 11))



# Generated at 2022-06-26 00:18:54.764108
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([0, 1, 2, 3]) == [1, 2, 3, 4]
    assert curried_map(identity)([0, 1, 2]) == [0, 1, 2]
    assert curried_map(identity)([-5, -4, -3]) == [-5, -4, -3]
    assert curried_map(increase)([]) == []
    assert curried_map(identity)([]) == []



# Generated at 2022-06-26 00:18:59.264514
# Unit test for function find
def test_find():
    assert find([], lambda x: x) is None
    assert find([0, False, {}, ()], identity) == 0
    assert find([0, False, {}, ()], lambda x: False) == False
    assert find([0, False, {}, ()], lambda x: True) is None


# Generated at 2022-06-26 00:19:05.026461
# Unit test for function memoize
def test_memoize():
    int_0 = -5
    int_1 = increase(int_0)
    memoized_increase = memoize(increase)
    assert memoized_increase(int_0) == int_1

    def power(value, power):
        return value ** power

    memoized_power = memoize(power)
    assert memoized_power(2, 3) == 8
    assert memoized_power(2, 3) == 8
    assert memoized_power(2, 7) == 128



# Generated at 2022-06-26 00:19:12.056678
# Unit test for function memoize
def test_memoize():
    fn_id = identity
    fn_mem_id = memoize(fn_id)
    assert fn_mem_id(0) == 0
    assert fn_mem_id(0) == 0
    assert fn_mem_id(1) == 1
    assert fn_mem_id(1) == 1

    fn_id_curry = curry(identity)
    fn_mem_id_curry = curry(memoize)(fn_id_curry)

    assert fn_mem_id_curry(0) == 0
    assert fn_mem_id_curry(0) == 0
    assert fn_mem_id_curry(1) == 1
    assert fn_mem_id_curry(1) == 1



# Generated at 2022-06-26 00:19:21.875198
# Unit test for function memoize
def test_memoize():
    @memoize
    def memoized_function(x, y):
        return x + y

    assert memoized_function(1, 2) == 3
    assert memoized_function(1, 2) == 3
    assert memoized_function(2, 2) == 4
    assert memoized_function(2, 2) == 4
    assert memoized_function(3, 2) == 5
    assert memoized_function(3, 2) == 5
    assert memoized_function(3, 2) == 5
    assert memoized_function(1, 2) == 3


# Generated at 2022-06-26 00:19:23.449907
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, -1) is False


# Generated at 2022-06-26 00:19:29.880526
# Unit test for function curry
def test_curry():
    add = curry(lambda a, b, c, d: a + b + c + d)
    assert add(1)(2)(3)(4) == 10
    assert add(1, 2)(3)(4) == 10
    assert add(1)(2, 3)(4) == 10
    assert add(1)(2)(3, 4) == 10
    assert add(1, 2, 3)(4) == 10
    assert add(1)(2, 3, 4) == 10
    assert add(1, 2, 3, 4) == 10


# Generated at 2022-06-26 00:19:33.072817
# Unit test for function curried_map
def test_curried_map():
    list_0 = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    list_1 = curried_map(increase, list_0)

    assert list_1 == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]



# Generated at 2022-06-26 00:19:40.419961
# Unit test for function eq
def test_eq():
    assert eq(3) == 3
    assert eq(3, 3)
    assert eq(1, 2) is False



# Generated at 2022-06-26 00:19:42.486696
# Unit test for function eq
def test_eq():
    assert eq(0, 0) == True
    assert eq(0, 1) == False
    assert eq(1, 0) == False



# Generated at 2022-06-26 00:19:47.983669
# Unit test for function find
def test_find():
    assert None == find([], lambda x: True)
    assert 1 == find([1, 2, 3], lambda x: x == 1)
    assert 2 == find([1, 2, 3], lambda x: x == 2)
    assert None == find([1, 2, 3], lambda x: x == '1')
    assert 5 == find([1, 2, 5, 3], lambda x: x % 2 == 0)



# Generated at 2022-06-26 00:19:50.465228
# Unit test for function curried_filter
def test_curried_filter():
    var_0 = curried_filter(increase)([1, 2, 3])
    assert var_0 == [2, 3, 4]


# Generated at 2022-06-26 00:19:58.781999
# Unit test for function curry
def test_curry():
    curried_function = curry(lambda a, b, c, d: a + b + c + d)
    result_0 = curried_function(1)
    result_1 = curried_function(1)(2, 3)(4)
    result_2 = curried_function(1)(2, 3, 4)
    result_3 = curried_function(1, 2)(3, 4)
    result_4 = curried_function(1, 2, 3, 4)

    assert result_0(2, 3, 4) == 10
    assert result_1 == 10
    assert result_2 == 10
    assert result_3 == 10
    assert result_4 == 10



# Generated at 2022-06-26 00:20:01.253957
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(2, 3)



# Generated at 2022-06-26 00:20:03.672494
# Unit test for function memoize
def test_memoize():
    assert memoize(lambda x: x * 2, lambda x, y: x == y)(2) == 4
    assert memoize(lambda x: x + 1)(3) == 4



# Generated at 2022-06-26 00:20:05.926265
# Unit test for function find
def test_find():
    assert test_find_0() == [0, 1]
    assert test_find_1() == [1, 3, 5]
    assert test_find_2() == None



# Generated at 2022-06-26 00:20:10.270015
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda n: n + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda n: n + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda n: n + 1)([1, 2, 3])(lambda n: n + 1) == [2, 3, 4]



# Generated at 2022-06-26 00:20:13.243751
# Unit test for function memoize
def test_memoize():
    def add_one_and_double(value):
        return value + 1

    memoized_add_one_and_double = memoize(add_one_and_double)
    memoized_add_one_and_double(3)

# Generated at 2022-06-26 00:20:18.452348
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-26 00:20:22.358587
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(equals_to_2, [1, 2, 3]) == [2]
    assert curried_filter(lambda x: x > 3, [1, 2, 3, 4, 5]) == [4, 5]
    assert curried_filter(lambda x: x < 0, [1, 2, 3]) == []



# Generated at 2022-06-26 00:20:27.087662
# Unit test for function curried_filter
def test_curried_filter():
    var_0 = curried_filter(identity, [1, 2, 3])
    var_1 = list(var_0)
    assert var_1 == [1, 2, 3]
    var_0 = curried_filter(identity, [])
    var_1 = list(var_0)
    assert var_1 == []


# Generated at 2022-06-26 00:20:33.162593
# Unit test for function cond
def test_cond():
    cond_fn = cond(
        [
            (lambda x: x < 10, lambda x: x),
            (lambda x: x % 2 == 0, lambda x: 'even'),
            (lambda _: True, lambda x: 'odd')
        ]
    )
    assert cond_fn(0) == 0
    assert cond_fn(1) == 'odd'
    assert cond_fn(2) == 'even'
    assert cond_fn(3) == 'odd'



# Generated at 2022-06-26 00:20:34.848257
# Unit test for function memoize
def test_memoize():
    # set up
    memoized_fib = memoize(fib)
    # Assertions



# Generated at 2022-06-26 00:20:41.290216
# Unit test for function find
def test_find():
    print('Test for find')
    assert find([1, 2, 3, 4], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4], lambda x: x == 5) is None
    print('Test for find - OK')



# Generated at 2022-06-26 00:20:45.610978
# Unit test for function memoize
def test_memoize():
    def my_fn(a):
        return a + 2

    mem_my_fn = memoize(my_fn)
    assert mem_my_fn(1) == 3
    assert mem_my_fn(2) == 4
    assert mem_my_fn(1) == 3
    assert mem_my_fn(2) == 4



# Generated at 2022-06-26 00:20:51.873682
# Unit test for function cond
def test_cond():
    print("Test case 0: ")
    print("f1(0):")
    print(f1(0))
    print("f1(1):")
    print(f1(1))
    print("f1(2):")
    print(f1(2))
    print("f1(3):")
    print(f1(3))
    print("f1(4):")
    print(f1(4))
    print("f1(5):")
    print(f1(5))


# Generated at 2022-06-26 00:20:57.530703
# Unit test for function cond
def test_cond():
    condition_list = [
        (lambda *arg: reduce(lambda a, b: a + b, arg), lambda *arg: reduce(lambda a, b: a * b, arg)),
        (lambda *arg: reduce(lambda a, b: a - b, arg) > 0, lambda *arg: reduce(lambda a, b: a / b, arg)),
    ]

    assert cond(condition_list)(1, 2, 3) == 2
    assert cond(condition_list)(2, 2, 3) == 1.5



# Generated at 2022-06-26 00:21:04.171877
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq(2, 1) == False
    assert eq('1', '2') == False
    assert eq('1', '1') == True
    assert eq('1', 1) == False
    assert eq({'a': 1}, {'a': 1}) == False
    assert eq((1, 'b'), (2, 'b')) == False
    assert eq((1, 'b'), (1, 'b')) == True



# Generated at 2022-06-26 00:21:13.868937
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)(range(10)) == [0, 2, 4, 6, 8]
    assert curried_filter(lambda x: x % 2 == 0, range(10)) == [0, 2, 4, 6, 8]



# Generated at 2022-06-26 00:21:22.585124
# Unit test for function cond
def test_cond():
    # Case 0
    assert cond([
        (lambda x: x == 0, lambda x: x + 1),
        (lambda x: x == 1, lambda x: x - 1),
        (lambda x: x > 0, lambda x: x),
    ])(0) == 1

    # Case 1
    assert cond([
        (lambda x: x == 0, lambda x: x + 1),
        (lambda x: x == 1, lambda x: x - 1),
        (lambda x: x > 0, lambda x: x),
    ])(1) == 0

    # Case 2

# Generated at 2022-06-26 00:21:24.353226
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y, args_count=2)(1, 2) == 3



# Generated at 2022-06-26 00:21:27.259116
# Unit test for function curry
def test_curry():
    add_four_number = curry(lambda x, y, z, n: x * y * z * n)
    assert(add_four_number(1)(2)(3)(4) == 24)


# Generated at 2022-06-26 00:21:30.611356
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq(1)(1) == True
    assert eq(1)(2) == False
    assert eq(1, 1, 1) == False


# Generated at 2022-06-26 00:21:37.936816
# Unit test for function eq
def test_eq():
    assert eq(1)(1) is True
    assert eq(2)(2) is True
    assert eq(0)(0) is True
    assert eq('text')('text') is True
    assert eq(True)(True) is True
    assert eq((1, 2, 3))((1, 2, 3)) is True
    assert eq([1, 2, 3])([1, 2, 3]) is True
    assert eq({1, 2, 3})({1, 2, 3}) is True
    assert eq({'a': 1, 'b': 2})({'a': 1, 'b': 2}) is True



# Generated at 2022-06-26 00:21:45.967097
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 2)([1, 2, 3]) == [3, 4, 5]
    assert curried_map(lambda x: x + 3)([1, 2, 3]) == [4, 5, 6]
    assert curried_map(lambda x: x + 4)([1, 2, 3]) == [5, 6, 7]
    assert curried_map(lambda x: x + 5)([1, 2, 3]) == [6, 7, 8]



# Generated at 2022-06-26 00:21:51.072550
# Unit test for function cond
def test_cond():
    condition_list = [
        (lambda x: x > 3, lambda x: x + 1),
        (lambda x: x == 3, lambda x: x + 1),
        (lambda x: x < 3, lambda x: x),
    ]
    test_cond_fn = cond(condition_list)
    assert test_cond_fn(3) == 4
    assert test_cond_fn(2) == 2
    assert test_cond_fn(4) == 5


# Generated at 2022-06-26 00:21:54.497913
# Unit test for function memoize
def test_memoize():
    @memoize
    def fib(n):
        if n <= 1:
            return n

        return fib(n - 2) + fib(n - 1)

    assert fib(10) == 55
    assert fib(10) == 55



# Generated at 2022-06-26 00:21:59.190362
# Unit test for function curried_map
def test_curried_map():
    assert curried_map((lambda x: x + 1))([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([-1, -2, -3]) == [0, -1, -2]
    assert curried_map(identity)(["1", "2", "3"]) == ["1", "2", "3"]



# Generated at 2022-06-26 00:22:07.802642
# Unit test for function find
def test_find():
    list_0 = [1, 2, 3, 4]
    fn_0 = lambda x: x == 2
    arg_0 = find(list_0, fn_0)
    assert arg_0 == 2
    fn_1 = lambda x: x == 7
    arg_1 = find(list_0, fn_1)
    assert arg_1 == None


# Test for function eq

# Generated at 2022-06-26 00:22:10.514859
# Unit test for function curried_map
def test_curried_map():
    """Test curried_map function."""
    assert curried_map(lambda x: x * 2, [1, 2, 3, 4]) == [2, 4, 6, 8]


# Test function curried_map with currying

# Generated at 2022-06-26 00:22:13.068761
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [1, 2]) == [1, 2]
    assert curried_map(increase, [1, 2]) == [2, 3]



# Generated at 2022-06-26 00:22:16.486424
# Unit test for function curried_map
def test_curried_map():
    curried_map_0 = curried_map(lambda var_0 : var_0 * 2)
    curried_map_1 = curried_map_0([1, 2, 3])
    assert curried_map_1 == [2, 4, 6]


# Generated at 2022-06-26 00:22:21.121420
# Unit test for function memoize
def test_memoize():
    counter = 0

    @memoize
    def fn(value):
        nonlocal counter
        counter += 1
        return counter

    assert fn(1) == 1
    assert fn(1) == 1
    assert fn(1) == 1
    assert fn(2) == 2
    assert fn(2) == 2
    assert fn(2) == 2
    assert fn(1) == 1
    assert counter == 2



# Generated at 2022-06-26 00:22:25.014793
# Unit test for function eq
def test_eq():
    assert(eq(1, 1))
    assert(not eq(1, 2))
    assert(eq(1+1, 2))
    assert(eq(1+1, 3-1))
    assert(not eq(1+1, 2+1))



# Generated at 2022-06-26 00:22:27.346609
# Unit test for function find
def test_find():
    assert find(['test'], eq('test')), 'should be true'
    assert not find(['test'], eq('another test')), 'should be false'


# Generated at 2022-06-26 00:22:29.540845
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)


# Generated at 2022-06-26 00:22:35.449235
# Unit test for function eq
def test_eq():
    assert eq(1, 2) == False
    assert eq(1, 1) == True
    assert eq(1)(1) == True
    assert eq(1)(2) == False
    assert eq(1, 2, 3) == False


# Generated at 2022-06-26 00:22:44.495250
# Unit test for function memoize
def test_memoize():
    # Set up
    # variable for test
    some_call_count = 0

    def some_function(value):
        nonlocal some_call_count
        some_call_count += 1
        return value

    # Test body
    # create memoized function
    some_memoized_function = memoize(some_function)
    # test of none-cached argument
    assert some_memoized_function('test') == 'test'
    # test of calling with the same argument should not invoke the function again
    assert some_call_count == 1
    assert some_memoized_function('test') == 'test'
    assert some_call_count == 1
    assert some_memoized_function('test1') == 'test1'
    assert some_call_count == 2



# Generated at 2022-06-26 00:22:58.415370
# Unit test for function curry
def test_curry():
    inc = curry(increase)
    assert inc(1) == 2
    assert inc(10) == 11
    assert inc(100) == 101



# Generated at 2022-06-26 00:23:06.800648
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y, 2)(1, 2) == 3
    assert curry(lambda x, y: x + y, 2)(1)(2) == 3
    assert curry(lambda x, y: x + y, 2)(1) == curry(lambda x: 1 + x, 1)
    assert curry(lambda x, y: x + y, 2)(1)(1) == 2
    assert curry(lambda x, y, z: x + y + z, 3)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z, 3)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z, 3)(1, 2, 3) == 6



# Generated at 2022-06-26 00:23:09.782668
# Unit test for function cond
def test_cond():
    a = [4, 5, 6]
    b = cond([(len, increase), (eq(1), increase), (eq(0), identity)])
    assert b(a) == 5
    assert b(1) == 2
    assert b(0) == 0


# Generated at 2022-06-26 00:23:16.957891
# Unit test for function cond
def test_cond():
    """
    test_cond()

    Test the function cond
    """
    # Create a function to check if x is positive
    is_positive = lambda x: x > 0

    # Create a function to return True
    return_true = lambda x: True

    # Create a function to return False
    return_false = lambda x: False

    # Create a cond function for the is_positive function
    cond_check_positive = cond(
        [(is_positive, return_true),
         (return_true, return_false)])

    assert cond_check_positive(7) == True
    assert cond_check_positive(-1) == False



# Generated at 2022-06-26 00:23:21.568129
# Unit test for function curried_map
def test_curried_map():
    var_1 = curried_map(lambda x: x * 2, range(10))
    var_2 = curried_map(lambda x, y: x + y, range(10))
    var_3 = curried_map(lambda x: x * 3, [1, 2, 3, 4, 5])
    var_4 = curried_map(lambda x: x, [1, 2, 3, 4])


# Generated at 2022-06-26 00:23:22.631540
# Unit test for function eq
def test_eq():
    eq_result = eq(1, 1)
    assert eq_result



# Generated at 2022-06-26 00:23:30.354033
# Unit test for function cond
def test_cond():
    test_cond_0 = cond([(eq(1), identity), (eq(2), increase)])
    assert test_cond_0(1) == 1
    assert test_cond_0(2) == 3
    test_cond_1 = cond([(eq(2), identity), (eq(1), increase)])
    assert test_cond_1(1) == 2
    assert test_cond_1(2) == 2
    test_cond_2 = cond([(eq(5), identity)])
    assert test_cond_2(5) == 5
    test_cond_3 = cond([(eq(5), identity)])
    assert test_cond_3(6) is None
    test_cond_4 = cond([(eq(1), identity)])
    assert test_cond_4(1, 2) == 1
    test

# Generated at 2022-06-26 00:23:32.781737
# Unit test for function memoize
def test_memoize():
    @memoize
    def fn(x, y):
        return x + y

    assert fn(1, 2) == 3
    assert fn(1, 2) == 3


# Generated at 2022-06-26 00:23:35.406874
# Unit test for function cond
def test_cond():
    assert(cond([
        (lambda x: x < 0, lambda x: False),
        (lambda x: x == 0, lambda x: True),
        (lambda x: x > 0, lambda x: False)
    ])(0))


# Generated at 2022-06-26 00:23:39.316918
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    increase_list = curried_map(increase)
    assert increase_list([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-26 00:23:59.802382
# Unit test for function curry
def test_curry():
    """Test case for function curry"""
    @curry
    def fn(a, b, c, d=0) -> bool:
        return a + b + c + d == 10

    var_0 = fn(1, 2, 3)
    var_1 = var_0(4)
    # fn(1, 2, 3, 4) == True
    assert var_1 == True

    var_0 = fn(1, 2, 3)
    var_1 = var_0(4, 5)
    # fn(1, 2, 3, 4, 5) == True
    assert var_1 == True

    var_0 = fn(1, 2, 3, 4)
    var_1 = var_0(5)
    # fn(1, 2, 3, 4, 5) == True
    assert var_1 == True



# Generated at 2022-06-26 00:24:01.230767
# Unit test for function eq
def test_eq():
    assert_true(eq(1, 1))
    assert_equal(eq(1, 2), False)



# Generated at 2022-06-26 00:24:05.003346
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]
    assert curried_map(lambda x: x * x, [1, 2, 3, 4, 5]) == [1, 4, 9, 16, 25]
    assert curried_map(lambda x: x * 2, range(5)) == [0, 2, 4, 6, 8]


# Generated at 2022-06-26 00:24:08.758868
# Unit test for function eq
def test_eq():
    # Test one argument
    assert(eq(1)(1))
    assert(not eq(1)(2))

    # Test multiple arguments
    assert(eq(1, 1))
    assert(eq(1, '1'))


# Generated at 2022-06-26 00:24:10.396316
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False



# Generated at 2022-06-26 00:24:12.428210
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], eq(3)) == 3
    assert find([1, 2, 3, 4], eq(5)) is None



# Generated at 2022-06-26 00:24:13.729794
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda item: item == 2) == 2



# Generated at 2022-06-26 00:24:21.769353
# Unit test for function curry
def test_curry():
    assert eq(1)(1) is True
    assert eq(0)(1) is False
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None
    assert memoize(lambda x: x, lambda x, y: x == y)(1) == 1
    assert memoize(lambda x: x, lambda x, y: x == y)(2) == 2
    assert memoize(lambda x: x, lambda x, y: x == y)(2) == 2
    assert compose(0, increase, increase) == 2
    assert pipe(0, increase, increase) == 2
    assert cond([(lambda x: x == 0, lambda x: "zero function")])(0) == "zero function"


# Generated at 2022-06-26 00:24:29.507984
# Unit test for function curry
def test_curry():
    # Execute function without currying
    def sum_with_two_args(first: int, second: int) -> int:
        return first + second

    # Execute function with currying
    sum_curried = curry(sum_with_two_args)

    def test_curry_without_args():
        # Without arguments should return new function
        assert callable(sum_curried)

    def test_curry_with_args_1(first: int):
        # With first argument should return new function
        assert callable(sum_curried(first))

    def test_curry_with_both_args(first: int, second: int):
        # With both arguments should return result from executed function
        assert sum_curried(first)(second) == sum_with_two_args(first, second)

    test_c

# Generated at 2022-06-26 00:24:37.487830
# Unit test for function cond
def test_cond():
    f_1 = lambda x: x < 0
    f_2 = lambda x: x ** 2
    f_3 = lambda x: x ** 3
    f_4 = lambda x: x ** 4

    array_1 = [
        (f_1, f_2),
        (f_1, f_3),
        (f_1, f_4),
    ]

    array_2 = [
        (f_1, f_2),
        (f_1, f_3),
        (f_1, f_4),
    ]

    f_5 = lambda x: x > 0
    f_6 = lambda x: x ** 0.5
    f_7 = lambda x: x ** 0.7
    f_8 = lambda x: x ** 0.9


# Generated at 2022-06-26 00:25:08.089920
# Unit test for function memoize
def test_memoize():
    var_0 = 0

    def fn():
        """
        Function to test memoize
        """
        nonlocal var_0
        var_0 += 1
        return var_0

    m_fn = memoize(fn)

    assert eq(1, m_fn(1))
    assert eq(2, m_fn(2))
    assert eq(1, m_fn(1))
    assert eq(2, m_fn(2))
    assert eq(3, m_fn(3))



# Generated at 2022-06-26 00:25:12.368025
# Unit test for function curried_filter
def test_curried_filter():
    """
    Check if function curried_filter returns filtered list.
    """
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4]) == [3, 4]
    assert curried_filter(lambda x: x % 2 == 1, [1, 2, 3, 4]) == [1, 3]



# Generated at 2022-06-26 00:25:19.323625
# Unit test for function eq
def test_eq():
    # positive tests
    assert eq(1, 1) == True
    assert eq(1, True) == False
    assert eq([1, 2], [1, 2]) == True

    # negative tests
    assert eq(1, 0) == False
    assert eq([1, 2], [1, 3]) == False
    assert eq(True, []) == False



# Generated at 2022-06-26 00:25:21.006122
# Unit test for function eq
def test_eq():
    assert eq(3, 3) is True
    assert eq(3, 2) is False


# Generated at 2022-06-26 00:25:27.256427
# Unit test for function memoize
def test_memoize():
    def create_test_function():
        cache = []
        @memoize
        def test_function(argument):
            cache.append(argument)
            return argument
        return cache, test_function

    cache_0, function_0 = create_test_function()
    assert cache_0 == []

    result_0 = function_0(0)
    assert cache_0 == [0]
    assert result_0 == 0

    result_1 = function_0(0)
    assert cache_0 == [0]
    assert result_1 == 0

    result_2 = function_0(1)
    assert cache_0 == [0, 1]
    assert result_2 == 1

    result_3 = function_0(1)
    assert cache_0 == [0, 1]
    assert result_3 == 1


#

# Generated at 2022-06-26 00:25:32.406014
# Unit test for function curry
def test_curry():
    # Test case
    # fn = A -> B -> C -> D -> E
    # args = x, y, z
    # fn(*args) = E
    # c_fn = c_A -> c_B -> c_C -> c_D -> c_E
    # c_fn(*args) = c_E
    fn = lambda x: lambda y: lambda z: x * y + z

    c_fn = curry(fn)
    assert fn(4, 2, 3) == c_fn(4)(2)(3)
    assert fn(5, 2, 8) == c_fn(5, 2, 8)
    assert fn(1, 3, 4) == c_fn(1, 3)(4)
    assert fn(5, 2, 4) == c_fn(5)(2, 4)

# Generated at 2022-06-26 00:25:38.210756
# Unit test for function curried_filter
def test_curried_filter():
    var_0 = find(
        curried_filter(
            fn_0=lambda var_0: False
        )(var_0=[]),
        fn_1=lambda var_0: var_0 == False
    )
    var_1 = find(
        curried_filter(
            fn_0=lambda var_0: True
        )(var_0=[]),
        fn_1=lambda var_0: var_0 == True
    )
    #
    if var_0 == var_1 == False:
        return True
    return False


# Generated at 2022-06-26 00:25:41.835801
# Unit test for function eq
def test_eq():
    assert eq(10, 10) is True
    assert eq(10, 10.0) is True
    assert eq(10, 10.1) is False
    assert eq(10, 11) is False
    assert eq("test", "test") is True
    assert eq("test", "test1") is False


# Generated at 2022-06-26 00:25:43.998491
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda i: i == 3) == 3
    assert find([1, 2, 3, 4], lambda i: i == 5) is None


# Generated at 2022-06-26 00:25:49.189721
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda a: a == 1) == 1
    assert find([1, 2, 3, 4], lambda a: a == 5) is None

# Generated at 2022-06-26 00:26:42.731278
# Unit test for function eq
def test_eq():
    assert(eq(10, 10) == True)
    assert(eq(10, "10") == False)
    assert(eq("10", "10") == True)
    assert(eq(1, 2) == False)


# Generated at 2022-06-26 00:26:44.992118
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x == 1, [0, 1, 2, 3, 4])([1, 2]) == [1, 2]



# Generated at 2022-06-26 00:26:46.691689
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4]) == [2, 4]


# Generated at 2022-06-26 00:26:50.959183
# Unit test for function memoize
def test_memoize():
    from time import time

    # Memoize variable
    cached_time = memoize(time)

    # some code here
    tmp = 1

    # Get and compare two time values
    time_1 = cached_time()
    time_2 = cached_time()

    # Test if condition is True
    try:
        assert time_1 == time_2
        print('[test_memoize] Test is OK')
    except:
        print('[test_memoize] Test is FAIL')



# Generated at 2022-06-26 00:26:58.571925
# Unit test for function cond
def test_cond():
    # Test case 0
    var_0 = cond([(lambda x: x == 'a', identity),
                  (lambda x: x == 'b', lambda x: x + 'b'),
                  (lambda x: True, lambda x: x + 'c')])('a')
    assert var_0 == 'a', "Test case 0"

    # Test case 1
    var_1 = cond([(lambda x: x == 'a', identity),
                  (lambda x: x == 'b', lambda x: x + 'b'),
                  (lambda x: True, lambda x: x + 'c')])('b')
    assert var_1 == 'bb', "Test case 1"

    # Test case 2

# Generated at 2022-06-26 00:27:04.527330
# Unit test for function memoize
def test_memoize():
    name_0 = 'fn'
    args_0 = []
    rslt_0 = {'0': 'call fn'}
    assert_def_0 = {
        'name_0': name_0,
        'args_0': args_0,
        'rslt_0': rslt_0,
    }
    assert_0 = {}
    def fn():
        fn.call_count = getattr(fn, 'call_count', 0) + 1
        return f'call {name_0}'

    mem_fn = memoize(fn)
    assert_0['0'] = mem_fn()
    assert_0['1'] = mem_fn()
    assert assert_0 == assert_def_0['rslt_0']



# Generated at 2022-06-26 00:27:08.830911
# Unit test for function curry
def test_curry():
    @curry
    def add(x, y, z):
        return x + y + z

    assert add(1)(2)(3) == 6
    assert add(1, 2)(3) == 6
    assert add(1, 2, 3) == 6
    assert add(1, 2)(4) == 7
    assert add(1)(2)(4) == 7
    assert add(1)(2, 4) == 7



# Generated at 2022-06-26 00:27:15.098092
# Unit test for function cond
def test_cond():
    """
    Test function cond.

    :returns: None
    :rtype: NoneType
    """

    assert cond([(lambda x: x < 0, lambda x: -x),
                 (lambda x: x > 0, lambda x: x + 1),
                 (lambda x: x == 0, lambda x: x)])(-1) == 1
    assert cond([(lambda x: x < 0, lambda x: -x),
                 (lambda x: x > 0, lambda x: x + 1),
                 (lambda x: x == 0, lambda x: x)])(1) == 2
    assert cond([(lambda x: x < 0, lambda x: -x),
                 (lambda x: x > 0, lambda x: x + 1),
                 (lambda x: x == 0, lambda x: x)])(0) == 0




# Generated at 2022-06-26 00:27:21.882916
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 5) is None
    assert find(None, lambda x: x == 5) is None



# Generated at 2022-06-26 00:27:30.123554
# Unit test for function cond
def test_cond():
    condition_list = [
        (lambda x: x == 0, lambda x: x * 2),
        (lambda x: x == 1, lambda x: x * 3),
        (lambda x: x > 3, identity),
        (lambda x: True, increase)
    ]
    test_0 = cond(condition_list)
    assert test_0(10) == 11

    test_1 = cond(condition_list)
    assert test_1(3) == 3

    test_2 = cond(condition_list)
    assert test_2(0) == 0

    test_3 = cond(condition_list)
    assert test_3(1) == 3

    test_4 = cond(condition_list)
    assert test_4(2) == 3

