

# Generated at 2022-06-26 00:18:26.426684
# Unit test for function find
def test_find():
    # Test 1
    test_list = [2, 3, 4]
    test_function = eq(2)
    assert find(test_list, test_function) == 2

    # Test 2
    test_list = [2, 3, 4]
    test_function = eq(5)
    assert find(test_list, test_function) is None



# Generated at 2022-06-26 00:18:30.781088
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(1), [1, 2, 3, 4, 5]) == [1]
    assert curried_filter(eq(2), [1, 2, 3, 4, 5]) == [2]
    assert curried_filter(eq(3), [1, 2, 3, 4, 5]) == [3]


test_curried_filter()



# Generated at 2022-06-26 00:18:33.232657
# Unit test for function find
def test_find():
    test_list = [1, 2, 3, 4, 5, 6]

    result = find(test_list, lambda item: item == 4)

    assert result == 4


# Generated at 2022-06-26 00:18:38.277697
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5])(None) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0, [2, 4])(None) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0, [1, 3, 5])(None) == []


# Generated at 2022-06-26 00:18:42.286362
# Unit test for function find
def test_find():
    assert find([True], eq(True)) == True
    assert find([False], eq(True)) == None
    assert find([True, False], eq(True)) == True
    assert find([False, True], eq(True)) == True
    assert find([False, True, False], eq(True)) == True



# Generated at 2022-06-26 00:18:47.291355
# Unit test for function curried_filter
def test_curried_filter():
    var_0 = curried_filter(identity, [])
    assert var_0 == []

    var_1 = curried_filter(lambda x: x > 1, [0, 1, 2, 3])
    assert var_1 == [2, 3]

    var_2 = curried_filter(lambda x: x % 2 == 0, [0, 1, 2, 3])
    assert var_2 == [0, 2]



# Generated at 2022-06-26 00:18:55.387513
# Unit test for function curry
def test_curry():
    assert increase(1) == 2

    # curried_0 is a function with 1 argument
    curried_0 = curry(increase)
    # curried_1 is a function with 1 argument
    curried_1 = curried_0(1)
    # curried_2 is a function with 0 arguments
    curried_2 = curried_1()
    # it will return 2
    assert curried_2 == 2

    assert eq(1, 1) is True
    assert eq(1, 2) is False

    curried_eq = curry(eq)
    assert curried_eq(1)(1) is True
    assert curried_eq(1)(2) is False

    # curried_filter is a function with 2 arguments
    curried_filter = curry(curried_filter)
    # curried_filter_0 is

# Generated at 2022-06-26 00:19:02.744350
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 3, 4, 5, 6, 7]
    assert curried_filter(lambda x: x % 2 == 0, collection) == [2, 4, 6]
    assert curried_filter(lambda x: x >= 4, collection)(collection) == [4, 5, 6, 7]
    assert curried_filter(lambda x: x >= 0)(collection)(collection) == collection



# Generated at 2022-06-26 00:19:05.907747
# Unit test for function curried_filter
def test_curried_filter():
    var_0 = curried_filter(lambda x: x > 2)

    assert var_0([1, 2, 3, 4, 5]) == [3, 4, 5]
    assert var_0([]) == []



# Generated at 2022-06-26 00:19:10.527205
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [0, 1, 2, 3]) == [0, 1, 2, 3]
    assert curried_map(lambda x: x + 1, [0, 1, 2, 3]) == [1, 2, 3, 4]
    assert curried_map(lambda x: x + 1, [0, 1, 2, 3, 4]) == [1, 2, 3, 4, 5]



# Generated at 2022-06-26 00:19:18.796421
# Unit test for function curried_map
def test_curried_map():
    curried_map()
    curried_map(lambda x: x)
    curried_map(lambda x: x)([1, 2, 3])


# Generated at 2022-06-26 00:19:21.286487
# Unit test for function find
def test_find():
    assert find([1, 2], eq(2)) == 2
    assert find([1, 2], eq(3)) == None


# Generated at 2022-06-26 00:19:24.810914
# Unit test for function curried_map
def test_curried_map():
    func = curried_map(lambda x: x * 2)
    assert func([1, 2, 3]) == [2, 4, 6]
    assert func([1, 2, 3, 4, 5]) == [2, 4, 6, 8, 10]



# Generated at 2022-06-26 00:19:27.186897
# Unit test for function cond
def test_cond():
    var_0 = eq()
    var_1 = cond([(var_0, identity)])
    assert var_1(var_0()) == True


# Generated at 2022-06-26 00:19:32.950251
# Unit test for function find
def test_find():
    assert None == find([1, 2, 3, 4], lambda x: x == 5)
    assert 2 == find([1, 2, 3, 4], lambda x: x == 2)
    assert 1 == find([1, 2, 3, 4], lambda x: x == 1)
    assert 0 == find([1, 2, 3, 4], lambda x: x == 0)
    assert 3 == find([1, 2, 3, 4], lambda x: x == 3)
    assert 4 == find([1, 2, 3, 4], lambda x: x == 4)



# Generated at 2022-06-26 00:19:40.456776
# Unit test for function memoize
def test_memoize():
    @memoize
    def fn(argument):
        return "result" if (argument == 2) else None

    assert fn(1) == None
    assert fn(2) == "result"
    assert fn(2) == "result"

    assert fn.__code__.co_varnames != ("argument", "key", "fn")



# Generated at 2022-06-26 00:19:44.568439
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda value: value == 2) == 2
    assert find([1], lambda value: value == 2) is None
    assert find([], lambda value: True) is None
    assert find(None, lambda value: False) is None



# Generated at 2022-06-26 00:19:47.615328
# Unit test for function curried_filter
def test_curried_filter():
    list_0 = [1, 2, 3]

    assert curried_filter(eq(1), list_0) == [1]
    assert curried_filter(eq(0), list_0) == []


# Generated at 2022-06-26 00:19:51.355044
# Unit test for function cond
def test_cond():
    is_even = lambda x: x % 2 == 0
    double = lambda x: x * 2

    fn = cond([
        (is_even, double),
    ])
    assert fn(2) == 4
    assert fn(3) is None



# Generated at 2022-06-26 00:19:55.624613
# Unit test for function eq
def test_eq():
    assert eq(0, 0) is True
    assert eq(0, 1) is False
    assert eq(0, "0") is False
    assert eq([1, 2, 3], [1, 2, 3]) is True
    assert eq([1, 2, 3], [1, 3, 2]) is False



# Generated at 2022-06-26 00:20:20.267580
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda var_0, var_1: var_0 is var_1, lambda var_0, var_1: var_0),
        (lambda var_0, var_1: var_0 is var_1, lambda var_0, var_1: 'str'),
    ])(1, 1) == 1
    assert cond([
        (lambda var_0, var_1: var_0 is var_1, lambda var_0, var_1: 'str'),
        (lambda var_0, var_1: var_0 is var_1, lambda var_0, var_1: 'str'),
    ])(1, 2) == 'str'

# Generated at 2022-06-26 00:20:27.815396
# Unit test for function memoize
def test_memoize():
    fn = memoize(lambda n: n * n * n)
    fn.cache = []
    fn.__annotations__ = {'return': int}
    assert fn.__annotations__ == {'return': int}
    assert fn(2) == 8
    assert fn.cache == [(2, 8)]
    assert fn(2) == 8
    assert fn.cache == [(2, 8)]
    assert fn(3) == 27
    assert fn.cache == [(2, 8), (3, 27)]
    assert fn(2) == 8
    assert fn.cache == [(2, 8), (3, 27)]



# Generated at 2022-06-26 00:20:29.570238
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-26 00:20:42.063393
# Unit test for function find
def test_find():

    # Test 0
    var_0 = find([], eq(10))
    assert var_0 == None

    # Test 1
    var_1 = find([10, 20, 30, 40, 50], eq(10))
    assert var_1 == 10

    # Test 2
    var_2 = find([10, 20, 30, 40, 50], eq(20))
    assert var_2 == 20

    # Test 3
    var_3 = find([10, 20, 30, 40, 50], eq(30))
    assert var_3 == 30

    # Test 4
    var_4 = find([10, 20, 30, 40, 50], eq(40))
    assert var_4 == 40

    # Test 5
    var_5 = find([10, 20, 30, 40, 50], eq(50))

# Generated at 2022-06-26 00:20:51.649036
# Unit test for function curried_filter
def test_curried_filter():
    # Test case 1
    var_0 = curried_filter(lambda var_0: var_0 > 2)([1, 2, 3])
    assert var_0 == [3]

    # Test case 2
    var_0 = curried_filter(lambda var_0: var_0 % 2 == 0)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    assert var_0 == [2, 4, 6, 8, 10]

    # Test case 3
    var_0 = curried_filter(lambda var_0: var_0 != -1)([-1, -1, -1, -1, -1])
    assert var_0 == []

    # Test case 4

# Generated at 2022-06-26 00:21:00.250452
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert eq(True, True)
    assert eq('a', 'a')
    assert not eq(1, 2)
    assert not eq(1, True)
    assert not eq('a', 'b')


# Generated at 2022-06-26 00:21:01.116629
# Unit test for function eq
def test_eq():
    assert eq(1, 1)



# Generated at 2022-06-26 00:21:03.161251
# Unit test for function eq
def test_eq():
    assert eq(False, True) == False
    assert eq(1, 2) == False
    assert eq("a", "a") == True



# Generated at 2022-06-26 00:21:05.371822
# Unit test for function find
def test_find():
    assert find([1, 2, 3], curry(eq)(1)) == 1
    assert find([1, 2, 3], curry(eq)(4)) is None


# Generated at 2022-06-26 00:21:09.793356
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x and x.isalpha(),
                          ['1', '2', '3', '4', '']) == ['1', '2', '3', '4']
    assert curried_filter(lambda x: len(x) < 3,
                          ['test', '12', '34', '123', '']) == ['12', '']



# Generated at 2022-06-26 00:21:18.882981
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-26 00:21:22.397179
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x > 2) == 3
    assert find([1, 2, 3, 4], lambda x: x > 4) is None
    assert find([1, 2, 3, 4, 2, 5], lambda x: x == 2) == 2



# Generated at 2022-06-26 00:21:31.948921
# Unit test for function curry
def test_curry():
    data = [
        [
            10,
            17,
            lambda a, b: a + b,
        ],
        [
            [
                'a',
                'b',
            ],
            'ab',
            lambda a, b: a + b,
        ],
        [
            [
                1,
                2,
                3,
                4,
            ],
            [
                1,
                2,
                3,
                4,
            ],
            lambda *args: args,
        ],
        [
            [
                1,
                2,
            ],
            True,
            lambda a, b: a == b,
        ],
    ]
    for test_case in data:
        test_args, expected_result, test_function = test_case

# Generated at 2022-06-26 00:21:41.799747
# Unit test for function curried_filter
def test_curried_filter():
    from random import choice
    from string import ascii_lowercase
    from data import test_data as data

    for _ in range(10000):
        collection_length = 20
        collection = [
            ''.join(choice(ascii_lowercase) for _ in range(10)) for _ in range(collection_length)
        ]
        filterer = choice([
            lambda el: el.endswith('a'),
            lambda el: el.startswith('z'),
            lambda el: el.endswith('z') and el.startswith('a'),
            lambda el: el.endswith('a') or el.startswith('z')
        ])
        assert curried_filter(filterer, collection) == data.curried_filter(filterer, collection)


# Generated at 2022-06-26 00:21:46.495943
# Unit test for function cond
def test_cond():
    var_0 = cond([(lambda arg_0: arg_0 == 0, lambda arg_1: arg_1),
                  (lambda arg_2: arg_2 == 1, lambda arg_3: arg_3 + 1)])
    print(var_0(0))
    print('###########')
    print(var_0(1))


# Generated at 2022-06-26 00:21:48.891112
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-26 00:21:50.475512
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 0) == False



# Generated at 2022-06-26 00:21:56.509564
# Unit test for function cond
def test_cond():
    inc_or_dec = cond([
        [eq(0), lambda x: 0],
        [lambda x: x > 0, increase],
        [lambda x: x < 0, decrease],
        [lambda x: True, identity]
    ])

    assert inc_or_dec(0) == 0
    assert inc_or_dec(1) == 2
    assert inc_or_dec(-1) == -2
    assert inc_or_dec(1.5) == 1.5



# Generated at 2022-06-26 00:21:58.953533
# Unit test for function eq
def test_eq():
    assert eq(0, 0)
    assert not eq(0, 1)
    assert not eq(1, 0)
    assert eq(1, 1)


# Generated at 2022-06-26 00:22:07.374150
# Unit test for function curry
def test_curry():
    assert curry(increase, 1)(2) == 3
    assert curry(identity, 1)(2) == 2
    eq = curry(eq)
    assert eq(1, 2) == False
    assert eq(2, 2) == True
    assert eq(2)(2) == True
    assert eq(2)(3) == False
    assert eq(3, 2) == False
    assert curry(lambda x, y: x == y, 2)(2, 2) == True
    assert curry(lambda x, y: x == y, 2)(2, 3) == False
    assert curry(lambda x, y: x == y, 2)(2)(2) == True
    assert curry(lambda x, y: x == y, 2)(2)(3) == False

# Generated at 2022-06-26 00:22:24.070059
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4])([]) == [3, 4]


# Generated at 2022-06-26 00:22:29.718292
# Unit test for function curried_filter
def test_curried_filter():
    # Test case 0
    var_0 = curried_filter(lambda value: value % 2 == 0, [1, 2, 3, 4, 5])

    assert var_0 == [2, 4], "Expected [2, 4], got " + str(var_0)

    # Test case 1
    var_1 = curried_filter(lambda value: value % 2 == 0)([1, 2, 3, 4, 5])

    assert var_1 == [2, 4], "Expected [2, 4], got " + str(var_1)


# Generated at 2022-06-26 00:22:34.546543
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3]) == [2]


# Generated at 2022-06-26 00:22:36.512217
# Unit test for function memoize
def test_memoize():
    global fn
    fn = memoize(lambda x: x * 2)
    assert fn(1) == 2
    assert fn(1) == 2



# Generated at 2022-06-26 00:22:38.717642
# Unit test for function curried_filter
def test_curried_filter():
    assert [1, 2, 3, 4] == curried_filter(lambda x: eq(increase(0), x), [1, 2, 3, 4])



# Generated at 2022-06-26 00:22:44.316795
# Unit test for function curry
def test_curry():
    var_0 = fn(0)
    var_1 = fn(1, 2)
    var_2 = fn(3, 4, 5)



# Generated at 2022-06-26 00:22:49.401854
# Unit test for function memoize
def test_memoize():
    results_list = []
    memoized_function = memoize(lambda argument: results_list.append(argument), key=lambda arg1, arg2: arg1 == arg2)

    memoized_function(3)
    memoized_function(3)
    memoized_function(3)

    assert (results_list == [3])



# Generated at 2022-06-26 00:22:58.094427
# Unit test for function curried_filter
def test_curried_filter():
    test_0 = True
    test_1 = [1, 2, 3, 4]

    def key(item):
        return item % 2 == 0

    def mapper(item):
        return item ** 2

    def filterer(item):
        return item % 2 == 0

    expected = [4, 16]

    assert test_0 is True
    assert curried_filter(filterer, test_1) == expected
    assert curried_filter(filterer, [1, 2, 3, 4]) == expected
    assert curried_filter(lambda x: x > 3, [1, 2, 3, 4]) == [4]
    assert curried_filter(key)(test_1) == expected
    assert curried_filter(key, test_1) == expected


# Generated at 2022-06-26 00:23:03.881188
# Unit test for function find
def test_find():
    assert find([0, 1, 2, 3], lambda x: x % 2 == 0) == 0
    assert find(["a", "b", "c"], lambda x: x != 'a') == 'b'
    assert find([1, 1, 1, 1], lambda x: x % 2 == 1) == 1
    assert find([1, 1, 1, 1], lambda x: x % 2 == 0) is None



# Generated at 2022-06-26 00:23:06.697543
# Unit test for function curried_map
def test_curried_map():
    list_0 = [1,2,3,4]
    var_0 = curried_map(increase, list_0)
    result = [2,3,4,5]
    assert var_0 == result


# Generated at 2022-06-26 00:23:33.977347
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, []) == []
    assert curried_map(identity, [1]) == [1]
    assert curried_map(identity, [1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-26 00:23:42.922710
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq('a', 'a') is True
    assert eq(False, True) is False
    assert eq('', '') is True
    assert eq('b', 'a') is False
    assert eq([1], [1]) is False
    assert eq({1: 1, 2: 2}, {1: 1, 2: 2}) is False
    assert eq(None, 'a') is False
    assert eq(True, 'a') is False
    assert eq(False, 'a') is False
    assert eq(False, None) is False
    assert eq(False, False) is True
    assert eq(None, None) is True
    assert eq(True, True) is True
    assert eq(True, 'True') is False
    assert eq({}, {}) is False

# Generated at 2022-06-26 00:23:45.283571
# Unit test for function cond
def test_cond():
    assert cond([(eq(1), identity)])(1) == 1
    assert cond([(eq(1), identity), (eq(2), identity)])(2) == 2

# Generated at 2022-06-26 00:23:46.894933
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False



# Generated at 2022-06-26 00:23:51.481608
# Unit test for function curried_map
def test_curried_map():
    assert map(lambda a: a + 3, [1, 2, 3]) == curried_map(lambda a: a + 3, [1, 2, 3])
    assert map(lambda a: a * 2, [1, 2, 3]) == curried_map(lambda a: a * 2, [1, 2, 3])



# Generated at 2022-06-26 00:23:54.298238
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-26 00:23:59.383210
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(0, 1)
    assert eq({}, {})
    assert not eq({}, {4: 5})
    assert eq([], [])
    assert not eq([], [4, 5])
    assert eq(None, None)
    assert not eq(None, {})
    assert not eq(None, [])
    assert eq('', '')
    assert not eq('', '4')



# Generated at 2022-06-26 00:24:02.581239
# Unit test for function curried_filter
def test_curried_filter():
    some_list = [1, 2, 3, 4]
    assert curried_filter(eq(2), some_list) == [2]
    assert curried_filter(eq(1), some_list) == [1]
    assert curried_filter(eq(10), some_list) == []



# Generated at 2022-06-26 00:24:03.837465
# Unit test for function curry
def test_curry():
    assert curry(fnA)(1)(2)(3) == [1, 2, 3]



# Generated at 2022-06-26 00:24:08.264058
# Unit test for function find
def test_find():
    assert find([], eq(1)) == None
    print(find([1, 2, 3, 4, 5, 6], eq(1))) # == 1
    print(find([{'a': 1}, {'a': 2}], lambda item: item.__eq__({'a': 1}))) # == {'a': 1}



# Generated at 2022-06-26 00:25:44.659812
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x % 2 == 0) == 2
    assert find([1, 2, 3], lambda x: x > 1) is None



# Generated at 2022-06-26 00:25:51.156187
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda x: x < 3) == 1
    assert find([1, 2, 3, 4, 5], lambda x: x > 6) is None



# Generated at 2022-06-26 00:25:52.998568
# Unit test for function curried_map
def test_curried_map():
    assert curried_map([1, 2, 3], lambda x: x * 2) == [2, 4, 6]



# Generated at 2022-06-26 00:25:55.031496
# Unit test for function find
def test_find():
    collection = [1, 2, 3]
    found_element = find(collection, lambda x: x == 2)
    assert 2 == found_element



# Generated at 2022-06-26 00:25:58.535860
# Unit test for function find
def test_find():
    assert find(['a', 'b', 'c', 'd', 'e', 'f', 'g'], lambda x: x == 'c') == 'c'
    assert find([1, 2, 3, 4, 5, 6], lambda x: x > 3) == 4
    assert find([1, 2, 3, 4], lambda x: x > 4) is None



# Generated at 2022-06-26 00:26:01.437073
# Unit test for function curry
def test_curry():
    assert curry(increase)(1) == increase(1)
    assert curry(increase, 1)(1) == increase(1)
    assert curry(increase)()()(1) == increase(1)
    return print('Test 1: curry - ok')


# Generated at 2022-06-26 00:26:04.088661
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x % 2 == 0) == 2
    assert find([1, 3, 5], lambda x: x % 2 == 0) is None



# Generated at 2022-06-26 00:26:06.967577
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert type(eq(1, 2)) is bool

    assert eq(1)(1)
    assert not eq(1)(2)
    assert type(eq(1)(1)) is bool



# Generated at 2022-06-26 00:26:10.576646
# Unit test for function memoize
def test_memoize():
    fn_0 = memoize(identity, eq)
    assert fn_0(1) == 1
    assert fn_0('a') == 'a'
    assert fn_0('a') == 'a'
    assert fn_0(1) == 1



# Generated at 2022-06-26 00:26:14.063201
# Unit test for function memoize
def test_memoize():
    var_0 = memoize(identity, eq)
    var_1 = memoize(identity, eq)
    var_2 = memoize(identity, eq)
    assert (var_0(1) == var_1(1) == var_2(1) == 1)
    print('test_memoize is passed')

