

# Generated at 2022-06-26 00:18:33.613001
# Unit test for function cond
def test_cond():
    condition_list = [
        (lambda val: val < 10, lambda val: val + 1),
        (lambda val: val > 10, lambda val: val - 1),
    ]

    test_0 = cond(condition_list)
    result_0 = test_0(9)
    assert result_0 == 10, 'function cond must return argument increased by 1'

    test_1 = cond(condition_list)
    result_1 = test_1(11)
    assert result_1 == 10, 'function cond must return argument decreased by 1'



# Generated at 2022-06-26 00:18:35.724954
# Unit test for function find
def test_find():
    array = [1, 2, 3, 4, 5]
    assert find(array, lambda x: x == 3) == 3, 'find failed'


# Generated at 2022-06-26 00:18:45.140443
# Unit test for function curry
def test_curry():
    var_0 = curry(lambda x, y: x + y)
    var_1 = var_0(1)
    var_2 = var_1(2)
    var_3 = var_0(1)(2)
    print('test_case_0')
    assert var_2 == 3
    assert var_3 == 3
    print('test_case_1')
    var_0 = curry(lambda x, y, z: x + y + z)
    var_1 = var_0(1)
    var_2 = var_1(2)
    var_3 = var_2(3)
    var_4 = var_0(1)(2)(3)
    assert var_3 == 6
    assert var_4 == 6
    print('test_case_2')

# Generated at 2022-06-26 00:18:46.790637
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 0)([]) == []
    assert curried_filter(lambda x: x > 0)([0, 1, -1]) == [1]



# Generated at 2022-06-26 00:18:55.583486
# Unit test for function cond
def test_cond():
    fn1 = lambda x: x % 2 == 0
    fn2 = lambda x: x + 2

    fn3 = cond([
        (fn1, lambda x: x//2),
        (lambda x: True, lambda x: x+1)
    ])

    assert fn3(4) == 2
    assert fn3(5) == 6
    assert fn3(1) == 2
    assert fn3(0) == 0


# Generated at 2022-06-26 00:19:02.071181
# Unit test for function curried_map
def test_curried_map():
    var_0 = [1, 2, 3]
    var_1 = curried_map(lambda var : var + 1, var_0)
    if var_1 == [2, 3, 4]:
        print("Test curried_map passed")
    else:
        print("Test curried_map failed")


# Generated at 2022-06-26 00:19:07.346129
# Unit test for function memoize
def test_memoize():
    def add():
        args = [item for item in range(1, 100)]
        return curried_map(lambda x: x + 1, args)

    def add_memoize():
        return curried_map(memoize(lambda x: x + 1), range(1, 100))

    assert (add() == add_memoize())

if __name__ == "__main__":
    test_memoize()

# Generated at 2022-06-26 00:19:08.782844
# Unit test for function curried_filter
def test_curried_filter():
    var_0 = curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4])
    assert var_0 == [2, 4]


# Generated at 2022-06-26 00:19:21.663760
# Unit test for function eq
def test_eq():
    # test positive
    assert True is eq(1, 1)
    assert True is eq('test', 'test')
    assert True is eq(True, True)
    assert True is eq(False, False)
    assert True is eq((1, 2, 3), (1, 2, 3))
    # test negative
    assert False is eq(1, 2)
    assert False is eq('test', 't')
    assert False is eq(True, False)
    assert False is eq((1, 2, 3), (1, 2, 4))
    assert False is eq((1, 2, 3), (1, 2))



# Generated at 2022-06-26 00:19:24.488639
# Unit test for function memoize
def test_memoize():
    test_f = memoize(lambda x: x)
    print(test_f(1))
    print(test_f(1))


if __name__ == "__main__":
    test_memoize()

# Generated at 2022-06-26 00:19:36.372995
# Unit test for function memoize
def test_memoize():
    def add3_to_number(number: int):
        return number + 3

    def multiply2_to_number(number: int):
        return number * 2

    memoized_add3_to_number = memoize(add3_to_number)
    memoized_multiply2_to_number = memoize(multiply2_to_number)

    assert memoized_add3_to_number(2) == 5
    assert memoized_add3_to_number(2) == 5
    assert memoized_multiply2_to_number(2) == 4
    assert memoized_multiply2_to_number(2) == 4
    assert memoized_multiply2_to_number(3) == 6



# Generated at 2022-06-26 00:19:42.524907
# Unit test for function memoize
def test_memoize():
    counter = 0
    def test_fn(i):
        nonlocal counter
        counter += 1
        return counter

    test_memoized_fn = memoize(test_fn)
    assert(test_memoized_fn(2) == 1)
    assert(test_memoized_fn(2) == 1)



# Generated at 2022-06-26 00:19:49.897922
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda item: item * 2, [1, 2, 3, 4]) == [2, 4, 6, 8]
    assert curried_map(lambda item: item * 2)
    assert curried_map(lambda item: item * 2)([1, 2, 3, 4]) == [2, 4, 6, 8]

    curried_map_plus_3 = curried_map(increase)(increase)(increase)
    assert curried_map_plus_3([1, 2, 3, 0]) == [4, 5, 6, 3]



# Generated at 2022-06-26 00:19:59.809762
# Unit test for function curried_map
def test_curried_map():
    eq(
        [2, 4, 6],
        curried_map(increase)([1, 2, 3])
    )
    eq(
        [2, 4, 6],
        curried_map(increase, [1, 2, 3])
    )
    eq(
        [2, 4, 6],
        curried_map(increase)(([1, 2, 3]))
    )
    eq(
        [2, 4, 6],
        curried_map(increase, ((1, 2, 3)))
    )
    eq(
        [2, 4, 6],
        curried_map(increase(1))([1, 2, 3])
    )

# Generated at 2022-06-26 00:20:05.761104
# Unit test for function cond
def test_cond():
    def fn0(x):
        return x > 0

    def fn1(x):
        return x < 0

    def fn2(x):
        return x == 0

    cond_function = cond([(fn0, increase), (fn1, identity), (fn2, identity)])
    assert cond_function(100) == 101
    assert cond_function(-100) == -100
    assert cond_function(0) == 0



# Generated at 2022-06-26 00:20:14.172623
# Unit test for function memoize
def test_memoize():
    # Test case 0
    #
    # Prepare the context
    def fn():
        global var_0
        var_0 = var_0 + 1
        return var_0

    global var_0
    var_0 = 0

    # Run the test
    var_1 = memoize(fn)()

    # Check the result
    assert var_0 == 1
    assert var_1 == 1

    # Test case 1
    #
    # Prepare the context
    global var_0
    var_0 = 0
    var_2 = 0

    # Run the test
    var_3 = memoize(fn)()

    # Check the result
    assert var_0 == 1
    assert var_2 == 0
    assert var_3 == 1

    # Test case 2
    #
    # Prepare the context
    global var_0

# Generated at 2022-06-26 00:20:16.681584
# Unit test for function memoize
def test_memoize():
    assert memoize(identity)(0) == 0
    assert memoize(identity)(1) == 1
    assert memoize(identity)(0) == 0



# Generated at 2022-06-26 00:20:19.883398
# Unit test for function curried_map
def test_curried_map():
    assert \
        curried_map(lambda x: x ** 2)([1, 2, 3]) == [1, 4, 9]
    print('Test passed!')


if __name__ == '__main__':
    test_curried_map()

# Generated at 2022-06-26 00:20:26.405986
# Unit test for function curry
def test_curry():
    """
    Unit tests for function curry.
    """
    assert 1 == curry(lambda a, b: a + b)(10, 20, 30)
    assert 4 == curry(lambda a, b: a + b, 2)(2, 2, 2)
    assert 1 == curry(lambda a, b, c: a + b + c)(10, 20, 30)
    assert 4 == curry(lambda a, b, c: a + b + c, 2)(2, 2, 2)
    assert 0 == curry(lambda: 0)()
# End for Unit test for function curry


# Generated at 2022-06-26 00:20:33.805725
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True, 'eq(1, 1) != True'
    assert eq(1, 1) != False, 'eq(1, 1) == False'
    assert eq(1, 1) is not False, 'eq(1, 1) == False'

    assert eq(1, 2) is False, 'eq(1, 2) != False'
    assert eq(1, 2) != True, 'eq(1, 2) == True'
    assert eq(1, 2) is not True, 'eq(1, 2) == True'


# Generated at 2022-06-26 00:20:46.903041
# Unit test for function curried_map
def test_curried_map():
    # Test set up
    var_1 = curried_map(identity)
    # Testing
    var_2 = var_1([1, 2, 3, 4, 5])
    assert var_2 == [1, 2, 3, 4, 5]
    # Teardown


# Generated at 2022-06-26 00:20:50.502136
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([0, 1, 2, 3]) == [1, 2, 3, 4]
    assert curried_map(lambda x: x ** 2)([1, 2, 3]) == [1, 4, 9]



# Generated at 2022-06-26 00:20:53.929949
# Unit test for function eq
def test_eq():
    # Testing eq
    assert eq()  # == assert eq(, )
    assert eq(1)  # == assert eq(, 1)
    assert eq(1)(1)
    assert not eq(1)(2)
    assert not eq(2)(1)



# Generated at 2022-06-26 00:20:58.077236
# Unit test for function cond
def test_cond():
    """
    Test for cond function.
    """
    add_one = lambda x: x + 1
    add_two = lambda x: x + 2
    add_four = lambda x: x + 4
    add_five = lambda x: x + 5

    cases = [
        ((lambda x: x == 0), add_one),
        ((lambda x: x == 1), add_two),
        ((lambda x: x == 2), add_four),
    ]

    result = cond(cases)

    assert result(0) == 1
    assert result(1) == 2
    assert result(2) == 4
    assert result(3) == 5


test_cond()

# Generated at 2022-06-26 00:21:05.536637
# Unit test for function cond
def test_cond():
    def fn_0(argument):
        return argument == 0

    def fn_1(argument):
        return argument

    def fn_2(argument):
        return argument + 1

    def fn_3(argument):
        return argument + 2

    test_list = [
        (1, fn_1),
        (2, fn_2),
        (3, fn_3)
    ]

    result_function = cond(test_list)

    assert result_function(0) == 1
    assert result_function(1) == 2
    assert result_function(2) == 3
    assert result_function(3) == 4



# Generated at 2022-06-26 00:21:07.053614
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False


# Generated at 2022-06-26 00:21:09.163110
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda item: item + 1, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-26 00:21:12.114909
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(2)) == 2
    assert find([1, 2, 3, 4], eq(5)) is None



# Generated at 2022-06-26 00:21:15.892644
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(1))([1, 2, 3]) == [1]
    assert curried_filter(eq(2))([1, 2, 3]) == [2]
    assert curried_filter(eq(3))([1, 2, 3]) == [3]


# Generated at 2022-06-26 00:21:20.839982
# Unit test for function cond
def test_cond():
    fn = cond([
        (lambda x: x < 3, lambda x: 1),
        (lambda x: x < 5, lambda x: 2),
        (lambda x: x < 7, lambda x: 3),
        (lambda x: True, lambda x: 4)
    ])

    assert fn(2) == 1
    assert fn(4) == 2
    assert fn(6) == 3
    assert fn(8) == 4



# Generated at 2022-06-26 00:21:33.573579
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(1), range(5)) == [1]
    assert curried_filter(lambda n: n > 1, range(5)) == [2, 3, 4]
    assert curried_filter(lambda n: n < 5, range(5)) == [0, 1, 2, 3, 4]



# Generated at 2022-06-26 00:21:37.712673
# Unit test for function curried_map
def test_curried_map():
    x = curried_map(identity, [1, 2, 3, 4])
    y = curried_map(lambda item: item ** 2, [1, 2, 3, 4])
    assert x == [1, 2, 3, 4]
    assert y == [1, 4, 9, 16]



# Generated at 2022-06-26 00:21:40.242840
# Unit test for function memoize
def test_memoize():
    def inner(x):
        return x

    fn = memoize(inner)
    some_result = fn(5)
    assert some_result == 5


# Generated at 2022-06-26 00:21:43.362356
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x % 2 == 0) == 2
    assert find([1, 2, 3, 4, 5], lambda x: x % 3 == 0) == 3



# Generated at 2022-06-26 00:21:45.588640
# Unit test for function eq
def test_eq():
    assert eq(1)(1) is True
    assert eq(1)(2) is False



# Generated at 2022-06-26 00:21:54.717617
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3

    # Test curried curried_map
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]

    # Test curried curried_filter
    assert curried_filter(lambda x: x > 2)([1, 2, 3]) == [3]

    # Test curried find
    assert find([1, 2, 3], lambda x: x == 2) == 2

    # Test cond
    add_x = lambda x, y: x + y
    def add_2(x):
        return add_x(x, 2)

    def add_3(x):
        return add_x(x, 3)


# Generated at 2022-06-26 00:21:59.118750
# Unit test for function cond
def test_cond():
    def fn1(x):
        return x == 1

    def fn2(x):
        return x == 2

    def fn3(x):
        return x == 3

    def fn4(x):
        return x * x

    assert cond([(fn1, fn4), (fn2, fn4), (fn3, fn4)], 5) is 25



# Generated at 2022-06-26 00:22:07.196246
# Unit test for function eq
def test_eq():
    """
    Test function eq

    :return:
    """
    # Test case # 0
    var_0 = eq(False, True)
    assert var_0 is False

    # Test case # 1
    var_1 = eq(True, False)
    assert var_1 is False

    # Test case # 2
    var_2 = eq(0, 0)
    assert var_2 is True

    # Test case # 3
    var_3 = eq(1, 0)
    assert var_3 is False

    # Test case # 4
    var_4 = eq('a', 'b')
    assert var_4 is False

    # Test case # 5
    var_5 = eq('b', 'b')
    assert var_5 is True



# Generated at 2022-06-26 00:22:10.178674
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(2)(2) == 4
    assert curry(lambda x, y: x + y, 1)(1) == 1
    assert curry(lambda x, y: x + y, 1)(1)(1) == 1



# Generated at 2022-06-26 00:22:15.526698
# Unit test for function curried_filter
def test_curried_filter():
    assert [1, 2] == curried_filter(lambda x: x < 3, [1, 2, 3, 4, 5])
    assert [3, 4, 5] == curried_filter(lambda x: x > 2, [1, 2, 3, 4, 5])
    assert [] == curried_filter(lambda x: x > 2, [1, 2])
    assert [] == curried_filter(lambda x: x < 1, [1, 2])


# Generated at 2022-06-26 00:22:32.850279
# Unit test for function curried_filter
def test_curried_filter():
    assert(curried_filter(lambda x: True, [1, 2, 3]) == filter(lambda x: True, [1, 2, 3]))
    assert(curried_filter(lambda x: True, ()) == filter(lambda x: True, ()))
    assert(curried_filter(lambda x: True, (1, 2, 3)) == filter(lambda x: True, (1, 2, 3)))
    assert(curried_filter(lambda x: True, (1, 2, 3, 4, 5)) == filter(lambda x: True, (1, 2, 3, 4, 5)))
    assert(curried_filter(lambda x: False, (1, 2, 3, 4, 5)) == filter(lambda x: False, (1, 2, 3, 4, 5)))

# Generated at 2022-06-26 00:22:38.820049
# Unit test for function cond
def test_cond():
    assert cond([
        (eq(1), increase),
        (eq(2), lambda x: x + 3),
    ])(1) == 2
    assert cond([
        (eq(1), increase),
        (eq(2), lambda x: x + 3),
    ])(2) == 5
    assert cond([
        (eq(1), increase),
        (eq(2), lambda x: x + 3),
    ])(3) is None


# Generated at 2022-06-26 00:22:41.516280
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert eq(2, 2)
    assert eq(1, 2) is False

# test for curried map

# Generated at 2022-06-26 00:22:47.065586
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 4) == 4
    assert find([1, 2, 3, 4], lambda x: x > 4) is None



# Generated at 2022-06-26 00:22:48.929678
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-26 00:22:54.994560
# Unit test for function curry
def test_curry():
    function_curry_test = curry(lambda x, y, z: x + y + z)
    assert function_curry_test(1, 2, 3) == 6
    assert function_curry_test(1)(2, 3) == 6
    assert function_curry_test(1)(2)(3) == 6
    assert function_curry_test(1, 2)(3) == 6



# Generated at 2022-06-26 00:22:57.230346
# Unit test for function eq
def test_eq():
    assert not eq(1, 'a')



# Generated at 2022-06-26 00:22:58.129058
# Unit test for function eq
def test_eq():
    eq(5,5)



# Generated at 2022-06-26 00:23:03.096855
# Unit test for function find
def test_find():
    assert find([], lambda value: value) is None
    assert find([1, 2, 3], eq(1)) == 1
    assert find(['ab', 'cd', 'ef'], lambda x: len(x) == 4) == 'cd'
    assert find(['ab', 'cd', 'ef'], lambda x: len(x) == 5) is None



# Generated at 2022-06-26 00:23:05.605548
# Unit test for function curry
def test_curry():
    assert curry(increase)(1) == 2
    assert curry(increase, 2)(1, 1) == 3
    assert curry(increase, 2)(1) == 2



# Generated at 2022-06-26 00:23:15.599991
# Unit test for function curried_map
def test_curried_map():
    map_1 = curried_map(lambda x: x ** 2)
    assert map_1([1, 2, 3]) == [1, 4, 9]


# Generated at 2022-06-26 00:23:20.794161
# Unit test for function curry
def test_curry():
    assert curried_map(identity)(range(10)) == list(range(10))
    assert curried_map(increase)(range(10)) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert curried_filter(eq(1))(range(10)) == [1]
    assert curried_filter(eq(3))(range(10)) == [3]
    assert curried_filter(eq(0))(range(10)) == []

# Generated at 2022-06-26 00:23:22.194016
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x >= 4) == 4



# Generated at 2022-06-26 00:23:23.580307
# Unit test for function curried_map
def test_curried_map():
    assert [2, 3, 4] == curried_map(increase, [1, 2, 3])


# Generated at 2022-06-26 00:23:31.427910
# Unit test for function curried_filter

# Generated at 2022-06-26 00:23:36.155789
# Unit test for function cond
def test_cond():
    var_0 = cond([
        (eq(1), increase),
    ])
    eq(var_0(1), 2)

    var_1 = cond([
        (eq(1), increase),
        (eq(2), identity),
    ])
    eq(var_1(2), 2)

    var_2 = cond([
        (eq(1), identity),
        (eq(2), identity),
    ])
    eq(var_2(3), None)



# Generated at 2022-06-26 00:23:39.430695
# Unit test for function curried_map
def test_curried_map():
    doubled_list = curried_map(lambda x: x*2)([1, 2, 3, 4])
    assert doubled_list == [2, 4, 6, 8]



# Generated at 2022-06-26 00:23:43.214937
# Unit test for function curried_filter
def test_curried_filter():
    """
    Test that curried_filter return result like normal filter
    """
    assert curried_filter(lambda x: x % 2 == 0, list(range(10))) == [0, 2, 4, 6, 8]
    assert curried_filter(lambda x: x % 2 == 0, list(range(0))) == []



# Generated at 2022-06-26 00:23:48.158470
# Unit test for function curry
def test_curry():
    def add(num1, num2):
        return num1 + num2

    curried_add = curry(add)
    assert curried_add(1) == curry(add, 1)
    assert curried_add(1)(2) == curry(add, 1)(2)
    assert curried_add(1)(2) == curry(add, 1, 2)
    assert curried_add(1)(2) == 3


# Generated at 2022-06-26 00:23:57.674037
# Unit test for function memoize
def test_memoize():

    assert type(memoize(identity)) is type(identity)

    assert memoize(identity)(1) == 1

    assert memoize(identity)(2) == memoize(identity)(2)

    assert memoize(identity, key=eq)(2) == memoize(identity, key=eq)(2) == 2

    assert memoize(identity, key=eq)(3) == memoize(identity, key=eq)(3) == 3

    assert memoize(identity, key=eq)(2) != memoize(identity, key=eq)(3)

    assert memoize(identity, key=eq)(2) != 3

    assert memoize(identity, key=eq)(3) != 2

    assert memoize(identity)(2) == memoize(identity)(2)


# Generated at 2022-06-26 00:24:30.497255
# Unit test for function cond
def test_cond():
    is_even_cond = lambda number: number % 2 == 0
    is_odd_cond = lambda number: not is_even_cond(number)
    even_result_func = lambda number: "even"
    odd_result_func = lambda number: "odd"
    cond_func = cond([
        (is_even_cond, even_result_func),
        (is_odd_cond, odd_result_func)
    ])
    assert cond_func(2) == "even"
    assert cond_func(3) == "odd"
    assert cond_func(4) == "even"



# Generated at 2022-06-26 00:24:32.869532
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4], lambda x: x == 5) is None



# Generated at 2022-06-26 00:24:35.253568
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(2))([1, 2, 3]) == [2]
    assert curried_filter(True)([1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-26 00:24:41.271054
# Unit test for function memoize
def test_memoize():
    # Arrange
    fn = curry(lambda x: x)
    expected_0 = fn(0)
    expected_1 = fn(1)
    expected_2 = fn(2)

    # Act
    memoized_fn = memoize(fn)
    actual_0 = memoized_fn(0)
    actual_1 = memoized_fn(1)
    actual_2 = memoized_fn(2)

    # Assert
    assert expected_0 == actual_0
    assert expected_1 == actual_1
    assert expected_2 == actual_2

# Generated at 2022-06-26 00:24:42.623330
# Unit test for function curried_map
def test_curried_map():
    assert curried_map()() == [2, 3, 4], 'curried_map test'


# Generated at 2022-06-26 00:24:44.766377
# Unit test for function curry
def test_curry():
    def fn_0(a, b, c):
        return a + b + c

    var_0 = curry(fn_0)(1)(2)(3)
    assert var_0 == 6



# Generated at 2022-06-26 00:24:52.865196
# Unit test for function memoize
def test_memoize():
    counter = 0

    # function with one argument: increase number if argument was not equal to the one in cache
    @memoize
    def counter_increase_if_not_equal(argument):
        nonlocal counter
        if counter != argument:
            counter = argument
        return counter

    assert counter_increase_if_not_equal(0) == 0
    assert counter_increase_if_not_equal(0) == 0
    assert counter_increase_if_not_equal(1) == 1
    assert counter_increase_if_not_equal(1) == 1
    assert counter_increase_if_not_equal(0) == 0
    assert counter_increase_if_not_equal(0) == 0
    assert counter_increase_if_not_equal(10) == 10

    counter = 0



# Generated at 2022-06-26 00:25:00.251176
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(2), [2, 3, 4])([1, 2, 3])([2, 3, 4]) == [[2], [2, 3], [2, 3, 4]]


if __name__ == '__main__':
    # Unit Tests

    test_curried_filter()

    # Functionality Tests

    # Filter even numbers below 20
    print(
        curried_filter(lambda x: x % 2 == 0, range(20))
    )

    # Find even number 12
    print(
        curried_filter(lambda x: x == 12, [12, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    )

    # Map numbers by 2
    print(
        curried_map(lambda x: x * 2, range(5))
    )



# Generated at 2022-06-26 00:25:01.625531
# Unit test for function eq
def test_eq():
    assert eq(2)(2) is True
    assert eq(2, 2) is True



# Generated at 2022-06-26 00:25:09.807352
# Unit test for function cond
def test_cond():
    """
    Case 1:
        cond(A) -> B
        cond(B) -> C
        cond(C) -> D

    """
    def fn_0(x):
        return x > 10

    def fn_1(x):
        return x > 20

    def fn_2(x):
        return x > 30

    def fn_3(x):
        return x > 40

    fn = cond([
        (fn_0, fn_1),
        (fn_1, fn_2),
        (fn_2, fn_3),
    ])

    assert fn(5) == fn_1(5)
    assert fn(15) == fn_2(15)
    assert fn(25) == fn_3(25)



# Generated at 2022-06-26 00:25:31.273607
# Unit test for function curry
def test_curry():
    a = curry(lambda a, b, c: a + b + c)
    assert a(1, 2, 3) == 6
    assert a(1)(2)(3) == 6
    assert a(1)(2, 3) == 6
    assert a(1, 2)(3) == 6
    assert a(1, b=2, c=3) == 6
    assert a(1, c=3, b=2) == 6
    assert a(c=3, b=2, a=1) == 6
    assert a(c=3, a=1, b=2) == 6



# Generated at 2022-06-26 00:25:34.093940
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x * 2)([1, 2, 3]) == [2, 4, 6]



# Generated at 2022-06-26 00:25:37.567280
# Unit test for function memoize
def test_memoize():

    # get fibonacci numbers from 1 to 10
    fib = memoize(lambda n: n if n < 2 else fib(n - 1) + fib(n - 2))

    for i in range(1, 11):
        print(fib(i))


test_memoize()

# test compose

# Generated at 2022-06-26 00:25:39.996893
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, range(5)) == [1, 2, 3, 4, 5]



# Generated at 2022-06-26 00:25:41.364440
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)


# Generated at 2022-06-26 00:25:42.465080
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-26 00:25:51.190066
# Unit test for function memoize
def test_memoize():
    initial_fn = lambda x: x

    test_memoize.called_times = 0

    def fn(x):
        test_memoize.called_times += 1
        return initial_fn(x)

    memoized = memoize(fn)

    assert memoized(1) == 1
    assert memoized(1) == 1
    assert memoized(1) == 1
    assert memoized(2) == 2
    assert memoized(1) == 1
    assert memoized(3) == 3

    assert test_memoize.called_times == 3



# Generated at 2022-06-26 00:25:55.910763
# Unit test for function cond
def test_cond():
    assert cond([(lambda a, b: a > b, lambda a, b: a + b),
                 (lambda a, b: a <= b, lambda a, b: a * b)])(1, 3) == 4

    assert cond([(lambda a, b: a > b, lambda a, b: a + b),
                 (lambda a, b: a <= b, lambda a, b: a * b)])(3, 1) == 4



# Generated at 2022-06-26 00:26:00.278519
# Unit test for function memoize
def test_memoize():
    counter = [0]

    def incr():
        counter[0] += 1
        return counter[0]

    incr = memoize(incr)

    test_case_0()

    assert incr() == 1
    assert incr() == 1
    assert counter[0] == 1


# Generated at 2022-06-26 00:26:04.417259
# Unit test for function cond
def test_cond():
    def is_even(n):
        return n % 2 == 0

    def increment(x):
        return x + 1

    def double(x):
        return 2 * x

    fn = cond(
        (is_even, increment),
        (identity, double)
    )
    assert fn(2) == 3
    assert fn(3) == 6



# Generated at 2022-06-26 00:26:44.477344
# Unit test for function memoize
def test_memoize():
    var_0 = memoize(increase)
    var_1 = var_0(1)
    var_2 = var_0(1)
    var_3 = var_0(2)



# Generated at 2022-06-26 00:26:46.969568
# Unit test for function find
def test_find():
    var_1 = [1, 2, 3]
    var_2 = find(var_1, lambda x: x == 2)
    var_3 = find(var_1, lambda x: x == 4)

# Generated at 2022-06-26 00:26:48.302300
# Unit test for function eq
def test_eq():
    assert eq(1, 1), 'Test failed'
    assert eq(1, 2) == False, 'Test failed'



# Generated at 2022-06-26 00:26:51.627727
# Unit test for function memoize
def test_memoize():
    global fn
    fn = lambda argument: argument * argument
    new_fn = memoize(fn)
    assert new_fn is not fn
    assert new_fn(2) == 2*2
    assert fn(2) == 2*2
    assert new_fn is not fn
    assert new_fn(2) == 2*2
    assert fn(2) == 2*2



# Generated at 2022-06-26 00:26:52.737504
# Unit test for function curried_filter
def test_curried_filter():
    assert 5 == curried_filter(eq(1), [0, 1, 2, 3])(0)



# Generated at 2022-06-26 00:27:00.372688
# Unit test for function cond
def test_cond():
    is_name = lambda name, x: x.get('name') == name
    get_name = lambda x: x.get('name')

    is_surname = lambda surname, x: x.get('surname') == surname
    get_surname = lambda x: x.get('surname')

    is_name_and_surname = lambda name, surname, x: x.get('name') == name and x.get('surname') == surname
    get_fullname = lambda x: x.get('name') + ' ' + x.get('surname')

    get_function = cond([
        (is_name_and_surname, get_fullname),
        (is_name, get_name),
        (is_surname, get_surname)
    ])


# Generated at 2022-06-26 00:27:07.780234
# Unit test for function cond
def test_cond():
    """
    Test case for function cond.

    :param:
    :type:
    :returns:
    :rtype:
    """
    def fn_0(a: int) -> int:
        return a + 1

    def fn_1(a: int) -> int:
        return a - 1

    def cond_function_1(a: int):
        return a > 5

    def cond_function_2(a: int):
        return a < 5

    def cond_function_3(a: int):
        return a < 0

    def cond_function_4(a: int):
        return a == 0

    def cond_function_5(a: int):
        return a == 10

    list_0 = [(cond_function_1, fn_0), (cond_function_2, fn_1)]


# Generated at 2022-06-26 00:27:10.551724
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 0, [-1, 2, 3, 1, -2, -3, 0]) == [2, 3, 1]
    assert curried_filter(lambda x: x > 0)([-1, 2, 3, 1, -2, -3, 0]) == [2, 3, 1]



# Generated at 2022-06-26 00:27:21.302889
# Unit test for function memoize
def test_memoize():
    function_calls_count = 0

    def count_function_calls(value):
        nonlocal function_calls_count
        function_calls_count += 1
        return value

    memoized_function = memoize(count_function_calls)

    assert memoized_function('some value') == 'some value'
    assert memoized_function('some value') == 'some value'
    assert memoized_function('some value') == 'some value'
    assert function_calls_count == 1, 'Function called more than one time'

    assert memoized_function(1) == 1
    assert memoized_function(1) == 1
    assert memoized_function(1) == 1
    assert function_calls_count == 2, 'Function called more than two times'



# Generated at 2022-06-26 00:27:24.961108
# Unit test for function curry
def test_curry():
    """
    Curry function test.
    """
    def add_two_numbers(a: int, b: int) -> int:
        """
        return sum of args
        """
        return a + b

    fn = curry(add_two_numbers)
    assert fn(1)(2) == 3
    assert fn(1, 2) == 3



# Generated at 2022-06-26 00:27:59.867157
# Unit test for function cond
def test_cond():
    assert cond([(eq(0), identity), (eq(0), identity)])(0) == 0



# Generated at 2022-06-26 00:28:06.459377
# Unit test for function memoize
def test_memoize():
    # Without cache
    fn = lambda x: x + 1
    var_0 = fn(1)
    # With cache
    fn = memoize(fn)
    var_1 = fn(1)
    assert var_0 == var_1
    var_2 = fn(1)
    assert var_1 == var_2
    assert var_2 is var_1



# Generated at 2022-06-26 00:28:10.801988
# Unit test for function memoize
def test_memoize():
    times = 1
    double = lambda n: n * 2
    double_memoized = memoize(double)
    assert double_memoized(2) == 4
    assert double_memoized(2) == 4



# Generated at 2022-06-26 00:28:13.432379
# Unit test for function memoize
def test_memoize():
    def fn(value):
        print(value)
        return value

    var_0 = memoize(fn)(0)
    var_1 = memoize(fn)(1)
    var_0 = memoize(fn)(0)


# Generated at 2022-06-26 00:28:21.755925
# Unit test for function cond
def test_cond():
    cond_unit_test = cond(
        [
            (eq(1), increase),
            (eq(2), identity),
            (eq(3), increase),
            (eq(42), lambda _: 'test'),
        ]
    )

    test_result = cond_unit_test(1)
    assert test_result == 2, (test_result, 'must be eq 2')

    test_result = cond_unit_test(2)
    assert test_result == 2, (test_result, 'must be eq 2')

    test_result = cond_unit_test(3)
    assert test_result == 4, (test_result, 'must be eq 4')

    test_result = cond_unit_test(42)
    assert test_result == 'test', (test_result, 'must be eq "test"')


