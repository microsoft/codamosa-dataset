

# Generated at 2022-06-26 00:18:30.697485
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4], lambda x: x == 5) is None


# Generated at 2022-06-26 00:18:40.346481
# Unit test for function eq
def test_eq():
    assert eq(True) == True
    assert eq(False) == False
    assert eq([1]) == [1]
    assert eq([1, 2]) == [1, 2]
    assert eq((1, 2)) == (1, 2)
    assert eq(None) == None
    assert eq(identity) == identity
    assert eq(eq) == eq
    assert eq(identity, identity) == True
    assert eq(eq, eq) == True
    assert eq(eq, identity) == False
    assert eq(eq, 'eq') == False
    assert eq(eq, False) == False
    assert eq(False, []) == False
    assert eq(True, []) == False
    assert eq(True, []) == False
    assert eq(True, ()) == False
    assert eq(None, ()) == False

# Generated at 2022-06-26 00:18:42.804802
# Unit test for function curried_filter
def test_curried_filter():
    var_0 = curried_filter(is_even, [1, 2, 3, 4])
    assert var_0 == [2, 4]


# Generated at 2022-06-26 00:18:55.356998
# Unit test for function cond
def test_cond():
    def fn(x):
        return True

    expected_result = True

    assert callable(cond([(fn, fn)])), 'cond returns function'
    assert cond([(fn, fn)])(1) == expected_result, 'cond returns result of true condition'
    assert cond([
        (lambda x: x % 2 == 0, lambda x: x),
        (lambda x: x % 3 == 0, lambda x: x),
        (lambda x: x % 5 == 0, lambda x: x)
    ])(10) == 10, 'cond returns result of first truly condition'

# Generated at 2022-06-26 00:19:07.003886
# Unit test for function memoize
def test_memoize():
    counter = 0

    def inc_counter(argument):
        global counter
        counter += 1
        return counter

    memoized_fn = memoize(inc_counter)

    assert memoized_fn(1) == 1
    assert memoized_fn(2) == 2
    assert memoized_fn(3) == 3
    assert memoized_fn(1) == 1
    assert memoized_fn(2) == 2
    assert memoized_fn(3) == 3
    assert memoized_fn(4) == 4
    assert memoized_fn(1) == 1
    assert memoized_fn(4) == 4

    counter = 0

    def inc_counter_by_one(argument):
        global counter
        counter += 1
        return argument + counter

    memoized_fn = memoize(inc_counter_by_one)

# Generated at 2022-06-26 00:19:08.001283
# Unit test for function curried_map
def test_curried_map():
    assert(curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4])



# Generated at 2022-06-26 00:19:13.985623
# Unit test for function find
def test_find():
    assert find(collection = [1, 2, 3], key = lambda item: item == 1) == 1
    assert find(collection = [1, 2, 3], key = lambda item: item == 0) is None
    assert find(collection = [1, 2, 3], key = lambda item: item == 2) == 2
    assert find(collection = [1, 2, 3], key = lambda item: item == 3) == 3


# Generated at 2022-06-26 00:19:20.989376
# Unit test for function cond
def test_cond():
    # test cond
    f = cond([
        (eq(0), identity),
        (eq(1), increase),
        (eq(2), lambda x: x * x),
    ])
    assert f(0) == 0
    assert f(1) == 2
    assert f(2) == 4
    assert f(3) is None


# Generated at 2022-06-26 00:19:30.278054
# Unit test for function cond
def test_cond():
    list_0, list_1, list_2, list_3 = [1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [1, 2, 3, 4]
    num_0, num_1, num_2, num_3, num_4, num_5 = 6, 0, 10, 9, 5, 10
    fn_0, fn_1, fn_2 = '', '', ''
    num_6, num_7, num_8, num_9, num_10, num_11, num_12, num_13, num_14, num_15, num_16, num_17, num_18, num_19, num_20, num_21, num_22, num_23, num_24, num_25, num_26, num_27,

# Generated at 2022-06-26 00:19:42.741043
# Unit test for function cond

# Generated at 2022-06-26 00:19:49.756076
# Unit test for function eq
def test_eq():
    assert True == eq(5, 5)
    assert False == eq(5, 7)


# Generated at 2022-06-26 00:19:59.611501
# Unit test for function curry
def test_curry():
    curry_result = curry(lambda x, y: x + y, 2)(1, 2)
    curry_result2 = curry(lambda x, y: x + y, 2)(1)(2)
    curry_result3 = curry(lambda x, y, z: x + y + z, 3)(1, 2, 3)
    curry_result4 = curry(lambda x, y, z: x + y + z, 3)(1, 2)(3)
    curry_result5 = curry(lambda x, y, z: x + y + z, 3)(1)(2)(3)
    curry_result6 = curry(lambda x, y, z: x + y + z, 3)(1)(2, 3)

# Generated at 2022-06-26 00:20:04.248238
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2]) == [1, 2]
    assert curried_map(increase)([1, 2]) == [2, 3]
    assert curried_map(lambda x: x * 2)([1, 2]) == [2, 4]



# Generated at 2022-06-26 00:20:12.527495
# Unit test for function memoize
def test_memoize():
    class TestKey:
        def __init__(self, value, value1):
            self.value = value
            self.value1 = value1

    @memoize
    def test_fn(value):
        test_fn.counter += 1
        return value

    test_fn.counter = 0
    test_key_1 = TestKey(1, 2)
    test_key_2 = TestKey(1, 2)
    test_key_3 = TestKey(3, 3)
    assert test_fn(test_key_1) == test_key_1
    assert test_fn(test_key_2) == test_key_1
    assert test_fn(test_key_3) == test_key_3
    assert test_fn.counter == 2
    assert test_fn(test_key_2) == test

# Generated at 2022-06-26 00:20:16.755448
# Unit test for function eq
def test_eq():
    var_0 = eq(3,3)
    print(var_0)
    var_1 = eq(0,0)
    print(var_1)
    var_2 = eq(1,1)
    print(var_2)
    var_3 = eq(7,7)
    print(var_3)


# Generated at 2022-06-26 00:20:19.966032
# Unit test for function find
def test_find():
    # 1, 2, 3, 4, 5
    assert find([1, 2, 3, 4, 5], lambda x: x == 2) == 2
    assert find([1, 2, 3, 4, 5], lambda x: x == 7) is None



# Generated at 2022-06-26 00:20:23.201337
# Unit test for function curry
def test_curry():
    increase = curry(lambda x, y: x + y)
    assert increase(2, 3) == 5
    assert increase(2)(3) == 5
    assert increase(2, y=3) == 5
    assert increase(y=3)(2) == 5



# Generated at 2022-06-26 00:20:28.104323
# Unit test for function find
def test_find():
    assert find('abracadabra', eq('a')) == 'a'
    assert find('abracadabra', eq('c')) == 'c'
    assert find('abracadabra', eq('d')) == 'd'
    assert find('abracadabra', eq('z')) is None
    print('test_find executed successful')



# Generated at 2022-06-26 00:20:31.922297
# Unit test for function cond
def test_cond():
    assert cond([
        (is_even, double),
        (is_odd, increase)
    ])(1) == 2

    assert cond([
        (is_even, double),
        (is_odd, increase)
    ])(2) == 4



# Generated at 2022-06-26 00:20:34.004371
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1, '1')



# Generated at 2022-06-26 00:20:46.661612
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 5, range(10)) == range(6, 10)



# Generated at 2022-06-26 00:20:51.360370
# Unit test for function cond
def test_cond():
    isEven = lambda x: x % 2 == 0
    isPositive = lambda x: x > 0
    cond_call = cond([
        (isPositive, (lambda x: x ** 2)),
        (isEven, (lambda x: 1)),
        (lambda x: True, (lambda x: 0)),
    ])
    assert cond_call(5) == 25



# Generated at 2022-06-26 00:20:54.293256
# Unit test for function eq
def test_eq():
    assert eq(None, None) == True
    assert eq(1, 1) == True
    assert eq(0, 1) == False
    assert eq(0, 0.0) == True
    assert eq([], []) == True


# Generated at 2022-06-26 00:21:00.319593
# Unit test for function eq
def test_eq():
    assert True is eq(1, 1)
    assert False is eq(1, 2)
    assert True is eq(1)(1)
    assert False is eq(2, 1)
    assert False is eq(1, 2)(1)
    assert True is eq(2)(2)



# Generated at 2022-06-26 00:21:09.245736
# Unit test for function curried_map
def test_curried_map():
    assert list(curried_map(lambda x: x + 1, [1, 2, 3])
               ) == [2, 3, 4], "Should return [2, 3, 4]"
    assert list(curried_map(lambda x: x * 2, [1, 2, 3])
               ) == [2, 4, 6], "Should return [2, 4, 6]"
    assert list(curried_map(lambda x: x + 1, (1, 2, 3))
               ) == [2, 3, 4], "Should return (2, 3, 4)"
    assert list(curried_map(lambda x: x * 2, (1, 2, 3))
               ) == [2, 4, 6], "Should return (2, 4, 6)"

# Generated at 2022-06-26 00:21:17.149588
# Unit test for function curried_filter
def test_curried_filter():
    """
    Return unit test status.

    :returns: True if test success, otherwise raise AssertionError
    :rtype: Boolean
    """
    first_condition = curry(curried_filter(lambda x: x % 2 == 0))
    second_condition = curry(curried_filter(lambda x: x % 3 == 0))

    assert first_condition([1, 2, 3, 4]) == [2, 4]
    assert first_condition([2, 3, 4, 5]) == [2, 4]
    assert second_condition([1, 2, 3, 4, 5, 6]) == [3, 6]



# Generated at 2022-06-26 00:21:19.044918
# Unit test for function curry
def test_curry():
    curried_add = curry(lambda a, b: a + b)
    assert curried_add(1)(2) == 3



# Generated at 2022-06-26 00:21:28.246717
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: True, lambda x: x),
        (lambda x: False, None)
    ])('1') == '1'
    assert cond([
        (lambda x: False, None),
        (lambda x: True, lambda x: x)
    ])('1') == '1'
    assert cond([
        (lambda x: False, None),
        (lambda x: False, None),
        (lambda x: True, lambda x: x)
    ])('1') == '1'
    assert cond([
        (lambda x: False, None),
        (lambda x: False, None)
    ])('1') is None

# Generated at 2022-06-26 00:21:36.359115
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x**2)(range(5)) == [0, 1, 4, 9, 16]
    assert curried_map(lambda x: x**2, range(5)) == [0, 1, 4, 9, 16]
    assert curried_map(lambda x: x**2, range(0, 5)) == [0, 1, 4, 9, 16]
    assert curried_map(lambda x: x**2, range(1, 2)) == [1]
    assert curried_map(lambda x: x**2, range(1, 1)) == []
    assert curried_map(lambda x: x**2, []) == []



# Generated at 2022-06-26 00:21:41.887119
# Unit test for function memoize
def test_memoize():
    @memoize
    def add(x, y):
        return x + y

    assert add(1, 2) == 3
    assert add(1, 2) == 3

    @memoize
    def sum_of_squares(x, y):
        return x + y

    assert sum_of_squares(1, 2) == 5
    assert sum_of_squares(1, 2) == 5



# Generated at 2022-06-26 00:22:05.653635
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 0, [1, 2, 3, -1, -2, -3]) == [1, 2, 3]
    assert curried_filter(lambda x: x > 0)([1, 2, 3, -1, -2, -3]) == [1, 2, 3]



# Generated at 2022-06-26 00:22:07.081986
# Unit test for function curry
def test_curry():
    fn = curry(lambda x, y: x + y)
    assert fn(1)(2) == 3


# Generated at 2022-06-26 00:22:11.742833
# Unit test for function find
def test_find():
    test_list = []
    assert find(test_list, eq(0, 0)) is None

    test_list = [1, 2, 3]

    assert find(test_list, eq(0, 0)) is None
    assert find(test_list, eq(2, 3)) is None

    assert find(test_list, eq(1, 1)) == 1
    assert find(test_list, eq(3, 3)) == 3



# Generated at 2022-06-26 00:22:16.979544
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x == 1, [1, 2, 3, 1]) == [1, 1]

    assert curried_filter(identity, [1, 2, 3]) == [1, 2, 3]

    assert curried_filter(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_filter(lambda x: x, [1, 2, 3]) == [1, 2, 3]
    return True



# Generated at 2022-06-26 00:22:21.008191
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(3), [1, 2, 3]) == [3]
    assert curried_filter(eq(5), [1, 2, 3]) == []
    assert curried_filter(eq(5), range(5)) == [5]
    assert curried_filter(eq(5), range(6)) == [5]



# Generated at 2022-06-26 00:22:29.694884
# Unit test for function curry
def test_curry():
    # Example from official documentation
    test_1 = curry(lambda a, b: print(a, b))
    test_1(1)(2)
    test_1(1, 2)

    # Additional test
    test_2 = curry(lambda a, b, c, d, e: print(a, b, c, d, e))
    test_2(1)(2)(3)(4)(5)
    test_2(1, 2, 3, 4, 5)
    with pytest.raises(TypeError):
        test_2(1, 2, 3, 4)
    with pytest.raises(TypeError):
        test_2(1, 2, 3)
    with pytest.raises(TypeError):
        test_2(1, 2)

# Generated at 2022-06-26 00:22:41.166704
# Unit test for function find
def test_find():
    print("Test find")

    # Test 1.1
    print("Test 1.1")
    print(find([1, 2, 3, 4], lambda x: x % 2 == 0))
    print(find([1, 2, 3, 4], lambda x: x > 3))
    print(find([1, 2, 3, 4], lambda x: x < 0))

    # Test 1.2
    print("Test 1.2")
    print(find([{'name': 'Ivan', 'age': 21}, {'name': 'Vasya', 'age': 20}],
               lambda x: x['name'] == 'Vasya'))

# Generated at 2022-06-26 00:22:54.922553
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5])(lambda x: x % 2 == 0) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5])(lambda x: x % 2 != 0) == [1, 3, 5]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5])(lambda x: x % 2 == 0) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5])(lambda x: x % 2 != 0) == [1, 3, 5]

# Generated at 2022-06-26 00:23:04.863564
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x == 3) == 3, "first"
    assert find([1, 2, 3, 4, 5], lambda x: x != 3) == 1, "second"
    assert find([1, 2, 3, 4, 5], lambda x: x > 3) == 4, "third"
    assert find([1, 2, 3, 4, 5], lambda x: x < 3) == 1, "fourth"
    assert find([1, 2, 3, 4, 5], lambda x: x == 0) == None, "fifth"
    assert find([1, 2, 3, 4, 5], lambda x: x > 5) == None, "sixth"

# Generated at 2022-06-26 00:23:05.643977
# Unit test for function curried_filter
def test_curried_filter():
    pass


# Generated at 2022-06-26 00:23:35.749695
# Unit test for function curried_map
def test_curried_map():
    test_list = [1, 2, 3]

    map_result = curried_map(increase, test_list)
    expected_result = [2, 3, 4]

    assert map_result == expected_result



# Generated at 2022-06-26 00:23:37.336517
# Unit test for function eq
def test_eq():
    assert eq(2, 2)
    assert eq(0, '0')


test_eq()



# Generated at 2022-06-26 00:23:40.791305
# Unit test for function curried_filter
def test_curried_filter():
    filterer = lambda x: x > 3
    collection = range(10)
    result = [4, 5, 6, 7, 8, 9]
    assert curried_filter(filterer, collection) == result



# Generated at 2022-06-26 00:23:45.167121
# Unit test for function find
def test_find():
    conditional_fn = lambda x: x % 2 != 0

    def iterate_over_collection(collection):
        for item in collection:
            yield item

    collection = [x for x in range(200)]
    result = find(collection, conditional_fn)
    assert result == iterate_over_collection(filter(conditional_fn, collection)).__next__()



# Generated at 2022-06-26 00:23:47.714605
# Unit test for function find
def test_find():
    collection = [1, 2, 3, 4, 5]
    assert find(collection, lambda value: value == 2) == 2
    assert find(collection, lambda value: value == 6) is None



# Generated at 2022-06-26 00:23:57.200999
# Unit test for function curry
def test_curry():
    # test for simple function
    @curry
    def add(x, y):
        return x + y

    assert add(2, 3) == add(2)(3)
    assert add(2)(3) == 5
    assert add(3, 4) == add(3)(4)

    # test for many arguments function
    @curry
    def add_many(x, y, z, *args):
        return x + y + z + sum(args)

    assert add_many(1, 2, 3) == 6
    assert add_many(1)(2)(3) == 6
    assert add_many(1, 2)(3) == 6
    assert add_many(1)(2, 3) == 6

# Generated at 2022-06-26 00:24:00.640196
# Unit test for function find
def test_find():
    assert None is find([], eq(2))
    assert 2 is find([1, 2, 3, 4], eq(2))
    assert 2 is find([1, 2, 3, 2, 4], eq(2))
    assert 5 is find([1, 2, 3, 2, 4], eq(5))



# Generated at 2022-06-26 00:24:08.666670
# Unit test for function curried_filter
def test_curried_filter():
    @curry
    def curried_filter(filterer, collection):
        return [item for item in collection if filterer(item)]

    def curried_map(mapper, collection):
        return [mapper(item) for item in collection]

    def identity(value):
        return value

    def eq(value, value1):
        return value == value1

    def compose(value, *functions):
        return reduce(
            lambda current_value, function: function(current_value),
            functions[::-1],
            value
        )

    def pipe(value, *functions):
        return reduce(
            lambda current_value, function: function(current_value),
            functions,
            value
        )


# Generated at 2022-06-26 00:24:11.244961
# Unit test for function curried_map
def test_curried_map():
    def fn(x): return x + 1
    data = [2, 3, 4]
    tmp = curried_map(fn, data)
    assert tmp == [3, 4, 5]



# Generated at 2022-06-26 00:24:14.500960
# Unit test for function memoize
def test_memoize():
    assert memoize(increase)(1) == 2
    increase_key = memoize(increase, key=identity)
    assert increase_key(1) == 2
    assert increase_key(1) == 2
    assert increase_key(1) == 2



# Generated at 2022-06-26 00:24:55.608721
# Unit test for function eq
def test_eq():
    assert eq(True, True) == True
    assert eq(0, 0) == True
    assert eq(False, False) == True
    assert eq(True, False) == False
    assert eq(None, False) == False
    assert eq(0.0, 0) == False
    assert eq(type, type) == True
    assert eq(type, int) == False



# Generated at 2022-06-26 00:25:01.368598
# Unit test for function find
def test_find():
    assert None == find([1, 2, 3, 4, 5], lambda x: x == 6)
    assert 1 == find([1, 2, 3, 4, 5], lambda x: x == 1)
    assert 2 == find([1, 2, 3, 4, 5], lambda x: x == 2)
    assert 3 == find([1, 2, 3, 4, 5], lambda x: x == 3)
    assert 4 == find([1, 2, 3, 4, 5], lambda x: x == 4)
    assert 5 == find([1, 2, 3, 4, 5], lambda x: x == 5)



# Generated at 2022-06-26 00:25:03.719384
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda element: element == 5) == 5
    assert find([1, 2, 3, 4, 5], lambda element: element == 42) is None



# Generated at 2022-06-26 00:25:08.544015
# Unit test for function memoize
def test_memoize():
    callable_0 = None
    callable_1 = memoize(callable_0)
    dict_0 = {}
    list_0 = [callable_1, callable_1]
    var_0 = compose(dict_0, *list_0)
    callable_2 = memoize(callable_0)
    assert callable_1 is callable_2



# Generated at 2022-06-26 00:25:17.287440
# Unit test for function curried_filter
def test_curried_filter():
    # Create curried_filter for filter odd numbers
    is_odd = curried_filter(bool)
    # Create curried_filter for filter even numbers
    is_even = curried_filter(bool)

    # Filtering list
    assert is_odd([1, 2, 3, 4])(lambda number: number % 2 == 1) == [1, 3]
    assert is_even([1, 2, 3, 4])(lambda number: number % 2 == 0) == [2, 4]



# Generated at 2022-06-26 00:25:23.149620
# Unit test for function curry
def test_curry():
    """
    Unit test for function curry.

    :return:
    """
    def sum_0(value):
        return reduce(lambda a, b: a + b, value, 0)

    assert sum_0([1, 2, 3]) == 6

    sum_1 = curry(sum_0)
    sum_2 = sum_1([1, 2])
    assert sum_2(3) == 6

    sum_3 = sum_1([1])
    assert sum_3(2)(3) == 6



# Generated at 2022-06-26 00:25:28.963355
# Unit test for function curried_filter
def test_curried_filter():
    filterer = curried_filter(lambda x: x % 2 == 0)
    filter_result = filterer([1, 2, 3, 4, 5])
    assert filter_result == [2, 4]



# Generated at 2022-06-26 00:25:37.644224
# Unit test for function cond
def test_cond():
    def func_0(arg_0):
        return True if arg_0 == 1 else False

    def func_1(arg_0):
        return True if arg_0 == 2 else False

    def func_2(arg_0):
        return True if arg_0 == 3 else False

    def func_3(arg_0):
        return True if arg_0 == 4 else False

    list_0 = [
        (func_0, func_1),
        (func_2, func_3),
        (func_3, func_0)
    ]
    func_4 = cond(list_0)

    assert func_4(1) is True
    assert func_4(2) is True
    assert func_4(3) is True
    assert func_4(4) is True



# Generated at 2022-06-26 00:25:44.940147
# Unit test for function memoize

# Generated at 2022-06-26 00:25:56.353458
# Unit test for function curried_filter
def test_curried_filter():
    def test_1():
        from math import sqrt

        assert curried_filter(lambda x: x % 2 == 0, range(10)) == list(range(0, 10, 2))
        assert curried_filter(lambda x: x % 2 == 1, range(10)) == list(range(1, 10, 2))

        assert curried_filter(lambda x: x < 5, range(10)) == list(range(5))

        assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]

# Generated at 2022-06-26 00:27:19.673404
# Unit test for function eq
def test_eq():
    assert eq(4, 4)
    assert not eq(4, 5)


# Generated at 2022-06-26 00:27:29.209847
# Unit test for function curry
def test_curry():
    def odd(x: int) -> bool:
        return x % 2 == 1

    def pow_(x: int, y: int) -> int:
        return x ** y

    def sum_(x: int, y: int) -> int:
        return x + y

    # test 1
    cur_odd = curry(odd)
    assert cur_odd(1)
    assert cur_odd(3)
    assert not cur_odd(2)

    # test 2
    cur_pow = curry(pow_)
    assert cur_pow(2)(2) == 4
    assert cur_pow(2, 3) == 8

    # test 3
    cur_sum = curry(sum_, 2)
    assert cur_sum(1) == 3
    assert cur_sum(2) == 4

# Generated at 2022-06-26 00:27:37.170584
# Unit test for function find
def test_find():
    # @func find

    assert find([(1, 2, 3), (1, 2, 4), (1, 5, 6)],
                lambda x: x[1] == 2) == (1, 2, 3)

    assert find([(1, 2, 3), (1, 2, 4), (1, 5, 6)],
                lambda x: x[0] == 2) is None

    assert find([(1, 2, 3), (1, 2, 4), (1, 5, 6)],
                lambda x: x[1] > 3) == (1, 5, 6)



# Generated at 2022-06-26 00:27:39.846709
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, []) == []
    assert curried_map(identity, [1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-26 00:27:52.687676
# Unit test for function cond
def test_cond():
    condition_list = [(lambda x: x == 1, lambda x: x + 1), (lambda x: x == 2, lambda x: x + 2)]
    result_fn = cond(condition_list)
    assert result_fn(1) == 2, "cond([(lambda x: x == 1, lambda x: x + 1), (lambda x: x == 2, lambda x: x + 2)])(1) = 2"
    assert result_fn(2) == 4, "cond([(lambda x: x == 1, lambda x: x + 1), (lambda x: x == 2, lambda x: x + 2)])(2) = 4"

# Generated at 2022-06-26 00:27:56.683107
# Unit test for function eq
def test_eq():
    # Positive
    assert eq(1, 1)
    assert eq(1, 1)
    assert eq(1) (1)
    # Negative
    assert not eq(1) (2)
    assert not eq(1) (2)
    assert not eq(1, 2)



# Generated at 2022-06-26 00:28:00.101085
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5]) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0)(range(6, 10)) == [6, 8]


# Generated at 2022-06-26 00:28:07.497357
# Unit test for function eq
def test_eq():
    assert eq(2,3) is False # not equal
    assert eq(2,2) is True  # equal
    assert eq(2,'2') is False # not equal by type
    assert eq([1,2],[1,2]) is True # equal
    assert eq([1,2],[1,2,3]) is False # not equal by size of list
    assert eq(1,1, 1) is None # too much arguments


# Generated at 2022-06-26 00:28:09.609263
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-26 00:28:11.142234
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 0) == False
