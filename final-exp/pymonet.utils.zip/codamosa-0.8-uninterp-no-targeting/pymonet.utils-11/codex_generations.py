

# Generated at 2022-06-21 19:47:27.802182
# Unit test for function curry
def test_curry():
    print("Test curry")
    a = curry(lambda a: lambda b: lambda c: a + b + c)
    assert a(1)(2)(3) == 6
    assert a(1, 2)(3) == 6
    assert a(1, 2, 3)() == 6
    assert a(1)(2, 3)() == 6
    assert a(1)(2)(3, 4) == 6



# Generated at 2022-06-21 19:47:28.883192
# Unit test for function identity
def test_identity():
    assert identity(1) == 1


# Generated at 2022-06-21 19:47:31.443106
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2
    assert increase(5) == 6
    assert increase(120) == 121


# Generated at 2022-06-21 19:47:34.670476
# Unit test for function pipe
def test_pipe():
    assert pipe(1, increase) == 2
    assert pipe(1, increase, increase) == 3
    assert pipe(1, increase, increase, increase) == 4
    assert pipe(1, increase, increase, identity) == 3
    assert pipe(1, increase, identity, identity) == 2
    assert pipe(1, 1, identity) == 1



# Generated at 2022-06-21 19:47:38.949068
# Unit test for function pipe
def test_pipe():
    assert pipe(
        9,
        lambda x: x - 3,
        lambda x: x - 3,
        lambda x: x + 4,
        lambda x: x ** 2,
    ) == 49

# Generated at 2022-06-21 19:47:40.617405
# Unit test for function compose
def test_compose():
    compose(0, lambda x: x + 1, lambda x: x * 2) == 2



# Generated at 2022-06-21 19:47:41.301569
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:47:42.363294
# Unit test for function increase
def test_increase():
    assert increase(1) == 2

# Generated at 2022-06-21 19:47:49.242363
# Unit test for function find
def test_find():
    test_list = [i for i in range(1, 10)]

    find_fn_1 = find(test_list)
    find_fn_2 = find(test_list, lambda x: x % 2 == 0)

    assert find_fn_1(lambda x: x % 2 == 0) == 2
    assert find_fn_2(lambda x: x % 2 == 0) == 2

    assert find_fn_1(lambda x: x > 10) == None


# Generated at 2022-06-21 19:47:59.082666
# Unit test for function curry
def test_curry():
    """
    Unit test for function curry.
    """
    assert curry(lambda x: x * 2)(5) == 10
    assert curry(lambda x, y: x * 2 + y)(5, 5) == 15

    def foo(a, b, c, d):
        return a * 2 + b * 3 + c * 4 + d * 5

    assert curry(foo)(1, 1, 1, 1) == 26
    assert curry(foo, 3)(1, 1, 1) == 26
    assert curry(foo, 3)(1, 1)(1) == 26
    assert curry(foo, 3)(1)(1)(1) == 26



# Generated at 2022-06-21 19:48:03.432354
# Unit test for function pipe
def test_pipe():
    assert pipe(4, identity, increase) == 5, 'pipe is not working'

# Generated at 2022-06-21 19:48:05.162664
# Unit test for function pipe
def test_pipe():
    assert pipe(1, lambda x: x + 1, lambda x: x ** 2) == 4

# Generated at 2022-06-21 19:48:06.341217
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(2) == 3


# Generated at 2022-06-21 19:48:07.432657
# Unit test for function pipe
def test_pipe():
    assert pipe(1, [lambda x: x + 1, lambda x: x * 2]) == 4



# Generated at 2022-06-21 19:48:09.499440
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_filter(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-21 19:48:12.046980
# Unit test for function curry
def test_curry():
    def add(value, value1):
        return value + value1

    add1 = curry(add)(1)
    assert add1(2) == 3



# Generated at 2022-06-21 19:48:16.958865
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x % 2 == 0) == 2
    assert find([1, 2, 3], lambda x: x % 2 == 1) == 1
    assert find([1, 2, 3], lambda x: x % 2 == 5) is None



# Generated at 2022-06-21 19:48:22.962565
# Unit test for function pipe
def test_pipe():
    assert pipe(
        'value',
        lambda x: x + '1',
        lambda x: x[::-1]
    ) == '1eulav'
    assert pipe(
        'value',
        lambda x: x + '1',
        lambda x: x + '2',
        lambda x: x[::-1]
    ) == '2ev1eulav'



# Generated at 2022-06-21 19:48:28.707018
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(True) is True
    assert identity(False) is False
    assert identity('string') == 'string'
    assert identity(None) is None
    assert identity([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-21 19:48:31.442392
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 0)
    assert not eq(0, 1)
    assert not eq((1,1), [1])


# Generated at 2022-06-21 19:48:43.751867
# Unit test for function curried_filter
def test_curried_filter():
    # Входной массив
    array = [1, 2, 3]
    # Метод который проверяет делится ли число на 2
    is_even = lambda x: x % 2 == 0
    # После каррирования возвращает массив с парамметром методом который проверяет делится ли число на 2
   

# Generated at 2022-06-21 19:48:46.024754
# Unit test for function compose
def test_compose():
    print("Test compose")
    assert compose("a", identity) == "a"
    assert compose("a", identity, lambda s: s + "b") == "ab"
    assert compose("a", lambda s: s + "b", lambda s: s + "c") == "abc"



# Generated at 2022-06-21 19:48:50.596325
# Unit test for function compose
def test_compose():
    assert compose(
        'Hello, world!',
        lambda x: list(x),
        lambda x: x[::-1],
        lambda x: ''.join(x)
    ) == '!dlrow ,olleH'



# Generated at 2022-06-21 19:48:57.267886
# Unit test for function memoize
def test_memoize():
    def counted_fn(i):
        counted_fn.call_count += 1
        return i + 1

    counted_fn.call_count = 0

    counted_fn = memoize(counted_fn)

    for _ in range(4):
        counted_fn(5)

    assert counted_fn.call_count == 1, \
        "Expected result is 1 but it was {count}" \
        .format(count=counted_fn.call_count)


if __name__ == '__main__':
    test_memoize()

# Generated at 2022-06-21 19:49:05.704809
# Unit test for function cond
def test_cond():
    assert cond([(eq(0), lambda x: 'water freezes at 0°C'),
                 (eq(100), lambda x: 'water boils at 100°C'),
                 (eq(0), lambda x: 'water freezes at 0°C')])(0) == 'water freezes at 0°C'
    assert cond([(eq(0), lambda x: 'water freezes at 0°C'),
                 (eq(100), lambda x: 'water boils at 100°C'),
                 (eq(0), lambda x: 'water freezes at 0°C')])(-1) is None

# Generated at 2022-06-21 19:49:08.928058
# Unit test for function memoize
def test_memoize():
    def sum(x, y):
        return x + y

    sum_memoized = memoize(sum)
    result = sum_memoized(1, 2)
    assert result == sum(1, 2)

    sum_memoized(1, 2)



# Generated at 2022-06-21 19:49:13.168070
# Unit test for function compose
def test_compose():
    assert compose(
        False,
        eq,
        increase,
        increase
    )

    assert not compose(
        1,
        eq,
        increase,
        increase
    )


# Generated at 2022-06-21 19:49:14.185755
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:49:15.208137
# Unit test for function identity
def test_identity():
    assert identity(2) == 2


# Generated at 2022-06-21 19:49:16.588161
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2



# Generated at 2022-06-21 19:49:25.274307
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    mapper = lambda x: x + 3

    assert curried_filter(mapper, collection) == curried_filter(mapper)(collection)
    assert curried_filter(mapper, collection) == [4, 5, 6, 7, 8, 9, 10, 11, 12]


# Generated at 2022-06-21 19:49:31.102089
# Unit test for function eq
def test_eq():
    assert(eq(1)(1) == True)
    assert(eq(1)(2) == False)
    assert(eq(1)(1.0) == True)
    assert(eq(1, 2) == False)
    assert(eq(1, 1) == True)



# Generated at 2022-06-21 19:49:33.262580
# Unit test for function curry
def test_curry():
    def sum(a, b):
        return a + b
    assert curry(sum)(1)(2) == 3


# Generated at 2022-06-21 19:49:35.310230
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:49:41.213321
# Unit test for function curry
def test_curry():
    """
    Test for curry function
    """
    def add(x, y, z):
        return x + y + z

    curried_add = curry(add)
    assert curried_add(1)(2)(3) == 6
    assert curried_add(1, 2)(3) == 6
    assert curried_add(1)(2, 3) == 6
    assert curried_add(1, 2, 3) == 6



# Generated at 2022-06-21 19:49:43.007100
# Unit test for function compose
def test_compose():
    assert compose(
        1,
        lambda x: x + 1,
        lambda x: x + 2
    ) == 4



# Generated at 2022-06-21 19:49:46.998635
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 5) is None


# Generated at 2022-06-21 19:49:50.043402
# Unit test for function pipe
def test_pipe():
    assert pipe(10, sqrt, increase) == 4
    assert pipe(10, increase, sqrt) == 5
    assert pipe(10) == 10


# Generated at 2022-06-21 19:49:53.731535
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda _: True)([1, 2, 3]) == [1, 2, 3]
    assert curried_filter(lambda _: True)([]) == []
    assert curried_filter(eq(1))([1, 2, 3]) == [1]


# Generated at 2022-06-21 19:49:57.828600
# Unit test for function curry
def test_curry():
    print(
        curry(lambda a: lambda b: a + b)(5)(5)
    )

    print(
        curry(lambda a, b: a + b)(5)(5)
    )

    print(
        curry(lambda a, b, c: a + b + c)(5)(5)(5)
    )

    print(
        curry(lambda a, b, c: a + b + c)(5)(5)(5, 5)
    )



# Generated at 2022-06-21 19:50:08.012184
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4], lambda x: x == 5) is None
    assert find([], lambda x: x == 5) is None



# Generated at 2022-06-21 19:50:10.486720
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(2) == 3
    assert increase(10) == 11



# Generated at 2022-06-21 19:50:15.661858
# Unit test for function pipe
def test_pipe():
    assert pipe(
        0,
        lambda value: value + 1,
        lambda value: value + 1,
        lambda value: value + 1,
    ) == 3

    assert pipe(
        0,
        lambda value: value + 1,
        lambda value: value + 1,
        lambda value: value + 1,
    ) == 3



# Generated at 2022-06-21 19:50:24.678549
# Unit test for function compose
def test_compose():
    # Setup
    value = 4

    def multiply_by_two(value: int) -> int:
        """
        Return multiplied by 2 argument.

        :param value:
        :type value: Int
        :returns:
        :rtype: Int
        """
        return value * 2

    def multiply_by_three(value: int) -> int:
        """
        Return multiplied by 3 argument.

        :param value:
        :type value: Int
        :returns:
        :rtype: Int
        """
        return value * 3

    # Exercise
    result = compose(value, multiply_by_two, multiply_by_three)

    # Verify
    assert result == 24



# Generated at 2022-06-21 19:50:26.705405
# Unit test for function pipe
def test_pipe():
    assert pipe(1, increase) == 2



# Generated at 2022-06-21 19:50:28.036515
# Unit test for function compose
def test_compose():
    assert compose(1, increase, increase) == 3


# Generated at 2022-06-21 19:50:32.928529
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False
    assert eq(1)(1) is True
    assert eq(1)(2) is False

    assert eq(curried_map(identity), curried_map(identity)) is False



# Generated at 2022-06-21 19:50:36.914679
# Unit test for function compose
def test_compose():
    assert compose(3, lambda x: x + 1, lambda x: x * 2) == 8
    assert compose(1, lambda x: x + 1, lambda x: x * 2, lambda x: x + 1, lambda x: x * 2) == 9



# Generated at 2022-06-21 19:50:40.530023
# Unit test for function curry
def test_curry():
    assert eq(1, 1)
    assert eq(1)(1)
    eq_one = eq(1)
    assert eq_one(1)
    assert eq_one(1)
    assert not eq_one(2)
    assert not eq_one(2)



# Generated at 2022-06-21 19:50:44.890625
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 3)([1, 4, 3, 4, 2, 5, 6]) == [4, 4, 5, 6]



# Generated at 2022-06-21 19:50:52.383980
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:50:59.291001
# Unit test for function memoize
def test_memoize():
    counted_function = lambda value: value + 1
    counted_function.count = 0
    def counted_function_memoize(*args):
        counted_function.count += 1
        return counted_function(*args)
    counted_function_memoized = memoize(counted_function_memoize)

    counted_function_memoized(0)
    counted_function_memoized(1)
    counted_function_memoized(2)
    counted_function_memoized(0)
    assert counted_function.count == 4

# Generated at 2022-06-21 19:51:02.391103
# Unit test for function memoize
def test_memoize():
    assert memoize(identity)('a') == 'a'
    fn = memoize(identity)
    assert fn('a') == 'a'
    assert fn('a') == 'a'
    assert fn('b') == 'b'
    assert fn('a') == 'a'
    assert fn('b') == 'b'



# Generated at 2022-06-21 19:51:07.112646
# Unit test for function pipe
def test_pipe():
    add = lambda a, b: a + b
    mult = lambda a, b: a * b
    twice = lambda a: a * 2
    gt = lambda a, b: a > b

    result = pipe(10, add, mult, twice)
    assert result == 220
    result = pipe(10, twice, mult, twice)
    assert result == 440
    result = pipe(10, twice, mult, twice, gt, twice)
    assert result == 880

# Generated at 2022-06-21 19:51:08.103937
# Unit test for function identity
def test_identity():
    assert identity(123) == 123
    assert identity("test") == "test"



# Generated at 2022-06-21 19:51:10.954224
# Unit test for function compose
def test_compose():
    # Should equal 5
    assert compose(
        5,
        lambda value: value + 2,
        lambda value: value * 2,
        lambda value: value + 1
    ) == 5



# Generated at 2022-06-21 19:51:14.970103
# Unit test for function curried_filter
def test_curried_filter():
    func = curried_filter(lambda x: x % 2 == 0)
    print(func([1, 2, 3, 4, 5]))
    func2 = curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5])
    print(func2)



# Generated at 2022-06-21 19:51:16.967187
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x > 2) == 3

# Generated at 2022-06-21 19:51:17.921563
# Unit test for function increase
def test_increase():
    assert increase(3) == 4


# Generated at 2022-06-21 19:51:22.076651
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], eq(3)) == 3
    assert find([1, 2, 3, 4, 5], eq(6)) is None
    assert find([], eq(1)) is None



# Generated at 2022-06-21 19:51:34.948168
# Unit test for function memoize
def test_memoize():
    def fn(argument):
        return argument * argument

    assert(memoize(fn)(3) == 9)
    assert(memoize(fn)(3) == 9)
    assert(memoize(fn)(4) == 16)
    assert(memoize(fn)(4) == 16)
    assert(memoize(fn)(3) == 9)



# Generated at 2022-06-21 19:51:36.692210
# Unit test for function identity
def test_identity():
    value = 'a'
    assert identity(value) == value


# Generated at 2022-06-21 19:51:43.305614
# Unit test for function increase
def test_increase():
    """
    Unit test for function increase
    """
    assert 1 == (increase(0))
    assert 2 == (increase(1))
    assert 3 == (increase(2))
    assert 4 == (increase(3))
    assert 5 == (increase(4))
    assert 6 == (increase(5))
    assert 6 == (increase(6))
    assert 7 == (increase(6))
    assert 15 == (increase(14))
    assert 16 == (increase(15))



# Generated at 2022-06-21 19:51:47.296999
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6])(None) == [2, 4, 6]



# Generated at 2022-06-21 19:51:53.288518
# Unit test for function memoize
def test_memoize():
    i: int = 0
    counter: int = 0
    original_function = lambda x: x * i
    def test(x):
        nonlocal counter
        counter += 1
        return x

    memoized_function = memoize(test)
    for _ in range(10):
        memoized_function(100)

    assert counter == 1, 'Memoize test failed, recursion counter should be 1.'

# Generated at 2022-06-21 19:51:56.248255
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda x: x == 7) is None



# Generated at 2022-06-21 19:52:01.157004
# Unit test for function cond
def test_cond():
    assert cond([
        (eq(1), increase),
        (eq(0), identity)
    ])(0) == identity(0)
    assert cond([
        (eq(1), increase),
        (eq(0), identity)
    ])(1) == increase(1)

# Generated at 2022-06-21 19:52:08.236462
# Unit test for function find
def test_find():
    find_int = find([1, 2, 3, 4], lambda x: x > 2)
    assert 3 == find_int

    find_int = find([1, 2, 3, 4], lambda x: x > 4)
    assert None is find_int

    find_string = find(['a', 'b', 'c', 'd'], lambda x: x == 'b')
    assert 'b' == find_string

    find_string = find(['a', 'b', 'c', 'd'], lambda x: x == 'e')
    assert None is find_string



# Generated at 2022-06-21 19:52:09.105609
# Unit test for function increase
def test_increase():
    assert increase(1) == 2


# Generated at 2022-06-21 19:52:11.892170
# Unit test for function compose
def test_compose():
    """
    For check working of function `compose` was created this test
    """
    assert 5 == compose(2, increase, lambda x: x ** 2)



# Generated at 2022-06-21 19:52:35.887500
# Unit test for function pipe
def test_pipe():
    assert pipe(
        1,
        lambda value: value + 1,
        lambda value: value * 2,
        lambda value: value + '!',
    ) == '4!'
    # Unit test for function cond



# Generated at 2022-06-21 19:52:38.089182
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6



# Generated at 2022-06-21 19:52:42.838734
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)

    assert memoized_add(1, 2) == 3
    assert memoized_add(3, 4) == 7
    assert memoized_add(1, 2) == 3
    assert memoized_add(3, 4) == 7



# Generated at 2022-06-21 19:52:47.157923
# Unit test for function memoize
def test_memoize():
    def logarithm_calculation(number):
        return number * number

    function_logarithm = memoize(logarithm_calculation)
    assert function_logarithm(2) == 4
    assert function_logarithm(2) == 4
    assert function_logarithm(2) == 4



# Generated at 2022-06-21 19:52:48.962699
# Unit test for function eq
def test_eq():
    fn = eq(1)
    assert fn(1)
    assert not fn(2)



# Generated at 2022-06-21 19:52:50.113175
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-21 19:52:52.655954
# Unit test for function find
def test_find():
    assert find(
        [1, 2, 3, 4],
        lambda x: x == 3
    ) == 3



# Generated at 2022-06-21 19:52:58.789612
# Unit test for function eq
def test_eq():
    __test_eq_positive([3, 3], True)
    __test_eq_positive([3, 4], False)
    __test_eq_positive(['3', '3'], True)
    __test_eq_positive(['3', '4'], False)
    __test_eq_positive([False, False], True)
    __test_eq_positive([True, False], False)



# Generated at 2022-06-21 19:53:02.022285
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [0]) == [0]
    assert curried_map(identity, [0, 1]) == [0, 1]
    assert curried_map(identity, []) == []



# Generated at 2022-06-21 19:53:05.326482
# Unit test for function increase
def test_increase():
    assert(increase(1) == 2)
    assert(increase(2) == 3)
    assert(increase(10) == 11)
    assert(increase(-10) == -9)



# Generated at 2022-06-21 19:53:40.065757
# Unit test for function find
def test_find():
    test_list = [1, 2, 3, 4, 5]
    assert find(test_list, lambda item: item > 2) == 3
    assert find(test_list, lambda item: item > 5) is None
    assert find([], lambda item: item > 2) is None


# Generated at 2022-06-21 19:53:42.334201
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(0), [0, 1, 2]) == [0]
    assert curried_filter(eq(1), [0, 1, 2]) == [1]



# Generated at 2022-06-21 19:53:53.597670
# Unit test for function cond
def test_cond():
    is_string = lambda arg: isinstance(arg, str)
    is_array = lambda arg: isinstance(arg, list)

    length = lambda arg: len(arg)

    first = lambda arg: arg[0]
    second = lambda arg: arg[1]

    def test_function(arg):
        return cond([
            (is_string, length),
            (is_array, compose(second, first))
        ])(arg)

    assert test_function("test") == 4
    assert test_function("") == 0
    assert test_function([1, 2, 3, 4]) == 2
    assert test_function([1, 2]) == 2
    assert test_function([1]) == 1
    assert test_function([]) is None



# Generated at 2022-06-21 19:53:58.215203
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2, (1, 2, 3)) == [3]
    assert curried_filter(lambda x: x > 2)((1, 2, 3)) == [3]
    assert curried_filter(lambda x: x > 2)((1, 2, 3, 4, 5)) == [3, 4, 5]



# Generated at 2022-06-21 19:53:59.359975
# Unit test for function pipe
def test_pipe():
    assert pipe(1, [identity, increase]) == 2


# Generated at 2022-06-21 19:54:10.160220
# Unit test for function curried_filter
def test_curried_filter():
    assert [4, 5] == curried_filter(lambda x: x > 3)([1, 2, 3, 4, 5, 6, 7, 8, 9])
    assert [4, 5] == curried_filter(lambda x: x > 3)([1, 2, 3, 4, 5, 6, 7, 8, 9])
    assert [2, 3, 4, 5, 6, 7, 8, 9] == curried_filter(lambda x: x < 1, [1, 2, 3, 4, 5, 6, 7, 8, 9])
    assert [2, 3, 4, 5, 6, 7, 8, 9] == curried_filter(lambda x: x < 1, [1, 2, 3, 4, 5, 6, 7, 8, 9])

# Generated at 2022-06-21 19:54:12.006571
# Unit test for function pipe
def test_pipe():
    assert pipe(2, increase, increase) == 4
    assert pipe(2, increase, lambda x: x * 3) == 9


# Generated at 2022-06-21 19:54:16.448204
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity('a') == 'a'
    assert identity([]) == []
    assert identity([1]) == [1]


# Generated at 2022-06-21 19:54:22.342265
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity('abc') == 'abc'
    assert identity([1, 2, 'abc']) == [1, 2, 'abc']
    assert identity({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert identity(True) is True
    assert identity(False) is False
    assert identity(None) is None



# Generated at 2022-06-21 19:54:24.890000
# Unit test for function pipe
def test_pipe():
    sum_values = pipe(
        lambda value: value + 1,
        lambda value: value + 2,
        lambda value: value + 3,
    )
    assert sum_values(1) == 7



# Generated at 2022-06-21 19:54:47.808038
# Unit test for function curry
def test_curry():
    def add(a, b):
        return a + b

    assert curry(add, 2)(1, 2) == 3
    assert curry(add, 2)(1)(2) == 3
    assert curry(add, 2)(1)
    assert curry(add)(2)(1, 2) == 3



# Generated at 2022-06-21 19:54:49.387429
# Unit test for function curried_filter
def test_curried_filter():
    filter_by_even = curried_filter(lambda x: x % 2 == 0)

    assert [1, 3, 5] == filter_by_even([1, 2, 3, 4, 5, 6])


# Generated at 2022-06-21 19:54:52.548393
# Unit test for function pipe
def test_pipe():
    assert pipe(
        'hello',
        lambda s: s.capitalize(),
        lambda s: ' '.join([s, 'world']),
        lambda s: '{0}!'.format(s)) == 'Hello world!'



# Generated at 2022-06-21 19:55:01.036392
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == curried_map(increase, [1, 2, 3])
    assert curry(curried_map)(increase)([1, 2, 3]) == [2, 3, 4]
    assert curry(curried_map)(increase, [1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-21 19:55:02.159109
# Unit test for function pipe
def test_pipe():
    assert pipe(
        4,
        increase,
        increase
    ) == 6, 'inc(4) == 5'



# Generated at 2022-06-21 19:55:04.568427
# Unit test for function curried_filter
def test_curried_filter():
    result = curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4, 5, 6])
    assert result == [2, 4, 6]


# Generated at 2022-06-21 19:55:06.976866
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 3) == 3
    assert find([1, 2, 3], lambda x: x == 4) is None
    assert find(['a', 'b', 'c'], lambda x: x == 'd') is None



# Generated at 2022-06-21 19:55:08.042633
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(2) == 3
    assert increase(3) == 4

# Generated at 2022-06-21 19:55:12.151667
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)(range(5)) == [1, 2, 3, 4, 5]
    assert curried_map(increase, [1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]



# Generated at 2022-06-21 19:55:13.073554
# Unit test for function eq
def test_eq():
    assert eq(1, 1)



# Generated at 2022-06-21 19:55:41.498482
# Unit test for function eq
def test_eq():
    assert not eq(1, 2)
    assert eq(1, 1)

    assert not eq(0.01, 0.01000000000000000000000000000001)
    assert eq(0.001, 0.0010001)

    assert not eq('a', 'b')
    assert eq('a', 'a')

    assert not eq(object(), object())
    assert eq(object(), object())

    assert not eq([1, 2, 3], [1, 2, 3, 4])
    assert eq([1, 2, 3], [1, 2, 3])

    assert not eq((1, 2, 3), (1, 2, 3, 4))
    assert eq((1, 2, 3), (1, 2, 3))

    assert not eq(None, 1)
    assert eq(None, None)

    assert not eq(False, 1)


# Generated at 2022-06-21 19:55:45.779362
# Unit test for function curry
def test_curry():
    def test_function(a, b, c):
        return a + b + c
    c1 = curry(test_function)
    c2 = curry(test_function)(1)
    c3 = curry(test_function, 1)(1)
    assert c1(1, 1, 1) == test_function(1, 1, 1)
    assert c2(1, 2) == test_function(1, 1, 2)
    assert c3(1, 2, 3) == test_function(1, 2, 3)



# Generated at 2022-06-21 19:55:51.074483
# Unit test for function compose
def test_compose():
    assert(compose(4, increase, increase, lambda x: x+1) == 7)
    assert(compose({}, lambda x: {'a': 5}, lambda x: {'b': 4}) == {'a': 5, 'b': 4})
    print ('Test compose passed.')


# Generated at 2022-06-21 19:55:59.910052
# Unit test for function memoize
def test_memoize():
    width = 10  # width of room, meters
    height = 7  # height of room, meters
    field_color = '#d3d3d3'  # color of room field
    obstacle_color = '#ffa500'  # color of obstacles

    def calc_cost(obstacles: List[List[int]]) -> float:
        """
        Calculate cost of paint for room

        :param obstacles: coordinates of obstacles
        :type obstacles: List[List[Int]]
        :returns: cost of paint
        :rtype: Float
        """
        return (width * height - len(obstacles)) * 0.01 + \
               sum([abs(obstacle[0] - width / 2) +
                    abs(obstacle[1] - height / 2) for obstacle in obstacles]) * 0.05

    cost

# Generated at 2022-06-21 19:56:01.894410
# Unit test for function identity
def test_identity():
    assert identity(42) == 42



# Generated at 2022-06-21 19:56:04.184850
# Unit test for function memoize
def test_memoize():
    assert memoize(increase)(1) == increase(1)
    assert memoize(increase)(1) == increase(1)



# Generated at 2022-06-21 19:56:13.403729
# Unit test for function memoize
def test_memoize():
    def sum(a, b):
        return a + b

    sum_memoized = memoize(sum)

    assert sum_memoized(5, 5) == 10
    assert sum_memoized(5, 5) == 10
    assert sum_memoized(5, 8) == 13
    assert sum_memoized(5, 8) == 13

    assert sum_memoized(5, 5) == 10
    assert sum_memoized(5, 5) == 10
    assert sum_memoized(5, 8) == 13
    assert sum_memoized(5, 8) == 13

    assert len(sum_memoized.__closure__[0].cell_contents) == 2



# Generated at 2022-06-21 19:56:14.734685
# Unit test for function pipe
def test_pipe():
    assert pipe(10, increase, identity) == 11



# Generated at 2022-06-21 19:56:16.281929
# Unit test for function increase
def test_increase():
    assert increase(5) == 6

# Unit test checking behavior of function identity

# Generated at 2022-06-21 19:56:18.442267
# Unit test for function compose
def test_compose():
    assert compose(0, increase, identity) == 1
    assert compose('hello', len, str) == '5'



# Generated at 2022-06-21 19:56:39.900667
# Unit test for function find
def test_find():
    assert find(
        collection=[
            {'name': 'John'},
            {'age': 23},
            {'name': 'Dave'},
            {'name': 'Dave'}
        ],
        key=lambda item: item.get('name') == 'Dave'
    ) == {'name': 'Dave'}



# Generated at 2022-06-21 19:56:45.631467
# Unit test for function cond
def test_cond():
    condition = lambda value: value == 3
    execute = lambda value: value
    execute2 = lambda value: value + 10

    condition2 = lambda value: value == 5
    execute3 = lambda value: value * 2

    result = cond([
        (condition, execute),
        (condition2, execute3),
    ])
    assert result(3) == 3
    assert result(5) == 10



# Generated at 2022-06-21 19:56:46.612593
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:56:47.469043
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:56:54.763223
# Unit test for function memoize
def test_memoize():
    current_value = 0

    @memoize
    def sum_value():
        nonlocal current_value
        current_value += 1
        return current_value

    assert sum_value() == 1
    assert sum_value() == 1
    assert sum_value() == 1
    assert sum_value() == 1
    assert sum_value() == 1
    assert sum_value() == 1
    assert sum_value() == 1
    assert sum_value() == 1
    assert sum_value() == 1
    assert sum_value() == 1



# Generated at 2022-06-21 19:56:55.704831
# Unit test for function compose
def test_compose():
    """
    >>> compose(increase, identity, increase)(1)
    3
    """



# Generated at 2022-06-21 19:57:00.473421
# Unit test for function cond
def test_cond():
    def odd_even(value: int):
        return 'odd' if curried_map(lambda x: x % 2, cond(
            (curried_filter(eq(0), [3]), lambda x: x + 1),
            (curried_filter(eq(1), [3]), lambda x: x),
        ))(value) else 'even'

    assert odd_even(3) == 'odd'
    assert odd_even(2) == 'even'



# Generated at 2022-06-21 19:57:02.793067
# Unit test for function find
def test_find():
    assert find([], identity) is None
    assert find([1, 2, 3], identity) == 1



# Generated at 2022-06-21 19:57:11.319532
# Unit test for function curried_map
def test_curried_map():
    arr = ["aa", "aaa", "aab", "aac", "bb", "bc", "bcd", "cc"]
    map_arr = [("aa", 1), ("aaa", 2), ("aab", 3), ("aac", 4), ("bb", 5), ("bc", 6), ("bcd", 7), ("cc", 8)]

    assert curried_map(identity, arr) == arr
    assert curried_map(lambda elem: elem + "!", arr) == ["aa!", "aaa!", "aab!", "aac!", "bb!", "bc!", "bcd!", "cc!"]
    assert curried_map(lambda elem: (elem, len(elem)), arr) == map_arr
    assert curried_map((lambda elem: (elem, len(elem))), arr) == map_arr


# Generated at 2022-06-21 19:57:12.431391
# Unit test for function increase
def test_increase():
    assert increase(1) == 2

