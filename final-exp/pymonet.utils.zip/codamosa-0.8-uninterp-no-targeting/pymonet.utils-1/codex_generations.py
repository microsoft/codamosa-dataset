

# Generated at 2022-06-21 19:47:22.302243
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(2, 1) == False


# Generated at 2022-06-21 19:47:25.487160
# Unit test for function curried_map
def test_curried_map():
    collection = [1, 2, 3, 4]
    result = curried_map(lambda x: x*2, collection)
    assert result == [2, 4, 6, 8]



# Generated at 2022-06-21 19:47:30.129448
# Unit test for function curry
def test_curry():
    def foo(a, b, c):
        return a + b + c

    foo_curried = curry(foo)
    foo1 = foo_curried(1)
    foo2 = foo1(2)
    foo3 = foo2(3)
    assert foo3 == 6



# Generated at 2022-06-21 19:47:32.051010
# Unit test for function find
def test_find():
    assert find(
        [1, 2, 3],
        lambda item: item == 3
    ) == 3



# Generated at 2022-06-21 19:47:33.453754
# Unit test for function increase
def test_increase():
    assert increase(4) == 5
    assert increase(0.4) == 1.4


# Generated at 2022-06-21 19:47:37.258544
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-21 19:47:46.862320
# Unit test for function memoize
def test_memoize():
    from unittest import TestCase, main

    class MemoizeTest(TestCase):
        def test_result_should_be_cached(self):
            iteration = 0

            @memoize
            def fn() -> int:
                nonlocal iteration
                iteration += 1
                return iteration

            self.assertEqual(fn(), 1)
            self.assertEqual(iteration, 1)
            self.assertEqual(fn(), 1)
            self.assertEqual(iteration, 1)

        def test_result_should_be_cached_for_different_key(self):
            iteration = 0

            @memoize(key=lambda key, args: eq(key[0], args[0]))
            def fn(arg) -> int:
                nonlocal iteration
                iteration += 1
                return iteration

            self

# Generated at 2022-06-21 19:47:55.530149
# Unit test for function find
def test_find():
    """
    Check that function works as expected. If not so raise exception.
    """
    try:
        find([1, 2, 3, 4], lambda x: x == 3) == 3
        find([1, 2, 3, 4], lambda x: x == 5) == None
    except AssertionError:
        raise AssertionError('Failed')


# Generated at 2022-06-21 19:47:56.790509
# Unit test for function increase
def test_increase():
    assert increase(2) == 3


# Generated at 2022-06-21 19:48:07.338222
# Unit test for function memoize
def test_memoize():
    def sum_to_n(n):
        if n <= 1:
            return n
        else:
            return n + sum_to_n(n - 1)

    def sum_to_n_memo(n):
        return memoize(
            sum_to_n,
            key=lambda arg, arg1: arg == arg1
        )(n)

    @memoize
    def sum_to_n_memo2(n):
        return sum_to_n(n)

    print(f"sum_to_n(10)= {sum_to_n(10)}")
    print(f"sum_to_n_memo(10)= {sum_to_n_memo(10)}")

# Generated at 2022-06-21 19:48:12.784693
# Unit test for function eq
def test_eq():
    """
    Test function "eq".
    """
    assert eq(1, 1) is True
    assert eq(1, 2) is False

    assert eq(1)(1) is True
    assert eq(1)(2) is False



# Generated at 2022-06-21 19:48:16.904003
# Unit test for function eq
def test_eq():
    eq1 = lambda x, y: x == y
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq1(1, 2)


# Generated at 2022-06-21 19:48:18.327304
# Unit test for function compose
def test_compose():
    assert compose(1, increase, increase) == 3
#


# Generated at 2022-06-21 19:48:21.214146
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)



# Generated at 2022-06-21 19:48:22.044645
# Unit test for function eq
def test_eq():
    assert eq(3)(3)


# Generated at 2022-06-21 19:48:25.636988
# Unit test for function curried_filter
def test_curried_filter():
    curried_filter_test = curried_filter(eq(1))
    assert curried_filter_test([1, 2, 3]) == [1]
    assert curried_filter_test([2, 2, 3]) == []
    assert curried_filter_test([1, 1, 1]) == [1, 1, 1]


# Generated at 2022-06-21 19:48:29.299135
# Unit test for function curry
def test_curry():
    def add(a, b):
        return a + b
    assert add(1, 2) == 3
    curried = curry(add)
    assert curried(1)(2) == 3



# Generated at 2022-06-21 19:48:36.034939
# Unit test for function compose
def test_compose():
    # Testing compose composition with three functions
    def f(a):
        return a + 1

    def g(a):
        return a * 2

    def h(a):
        return a ** 2

    assert pipe(1, f, g, h) == 16
    assert compose(1, h, g, f) == 16
    # Testing compose composition with one function
    def r(a):
        return a * 3

    assert pipe(2, r) == 6
    assert compose(3, r) == 9



# Generated at 2022-06-21 19:48:42.640291
# Unit test for function curried_map
def test_curried_map():
    assert [2, 3, 4] == curried_map(lambda x: x + 1)([1, 2, 3])
    assert [2, 3, 4] == curried_map(lambda x: x + 1, [1, 2, 3])
    assert [2, 3, 4] == curry(curried_map)(lambda x: x + 1)([1, 2, 3])
    assert [2, 3, 4] == curry(curried_map)(lambda x: x + 1, [1, 2, 3])



# Generated at 2022-06-21 19:48:48.560441
# Unit test for function curry
def test_curry():
    def multi_add(x: int, y: int, z: int) -> int:
        return x + y + z

    assert curry(multi_add)(1)(2)(3) == 6
    assert curry(multi_add)(1)(2)(3)(4) == 6
    assert curry(multi_add)(1, 2)(3) == 6
    assert curry(multi_add)(1)(2, 3) == 6
    assert curry(multi_add)(1, 2, 3) == 6
    assert curry(multi_add, 4)(1, 2, 3) == 6



# Generated at 2022-06-21 19:48:53.382815
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2
    assert increase(-1) == 0



# Generated at 2022-06-21 19:48:57.218682
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False



# Generated at 2022-06-21 19:48:59.805946
# Unit test for function compose
def test_compose():
    sometimes_increase = compose(increase, curried_map(eq(2)))
    assert sometimes_increase([1, 2, 3]) == [1, 3, 4]

# Generated at 2022-06-21 19:49:02.483503
# Unit test for function compose
def test_compose():
    assert compose(1, increase, increase) == 3
    assert compose(1, increase, identity) == 2
    assert compose(1, identity, increase) == 2



# Generated at 2022-06-21 19:49:05.450868
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [2, 3, 4])([1, 2, 10]) == [3, 4, 11], 'Should be [3, 4, 11]'


# Generated at 2022-06-21 19:49:07.095545
# Unit test for function pipe
def test_pipe():
    assert pipe(5, lambda x: x * 5, lambda y: y + 5) == 30



# Generated at 2022-06-21 19:49:12.607043
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x > 3) == None
    assert find([1, 2, 3], lambda x: True) == 1
    assert find([1, 2, 3], lambda x: False) == None


# Generated at 2022-06-21 19:49:15.144687
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 3, 4, 5]
    filterer = lambda value: value % 2 == 0
    result = curried_filter(filterer, collection)
    assert result == [2, 4], 'Not correct value of curried_filter function!'



# Generated at 2022-06-21 19:49:19.183090
# Unit test for function cond
def test_cond():
    result_cond = cond([
        (eq(1), identity),
        (eq(2), increase)
    ])

    assert result_cond(2) == 3
    assert result_cond(1) == 1



# Generated at 2022-06-21 19:49:20.156025
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-21 19:49:24.114883
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(1) != 1



# Generated at 2022-06-21 19:49:25.024358
# Unit test for function compose
def test_compose():
    assert identity(3) == compose(3, identity)

# Generated at 2022-06-21 19:49:32.781754
# Unit test for function curry
def test_curry():
    def sum_x_y(x, y):
        return x + y

    assert curry(sum_x_y)(1)(2) == 3
    assert curry(sum_x_y, 1)(1)() == 2
    assert curry(sum_x_y)(1, 2) == 3
    assert curry(sum_x_y, 3)(1, 2, 3) == 6
    assert curry(sum_x_y, 3)(4, 5, 6) == 15



# Generated at 2022-06-21 19:49:38.784957
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b, c: a + b + c)(1)(2)(3) == 6
    assert curry(lambda a, b, c: a + b + c)(1, 2)(3) == 6
    assert curry(lambda a, b, c: a + b + c)(1, 2, 3) == 6



# Generated at 2022-06-21 19:49:42.919349
# Unit test for function find
def test_find():
    def test_eq():
        assert find([], eq(1)) is None

        assert find([1], eq(1)) == 1
        assert find([1, 2], eq(2)) == 2
        assert find([1, 2, 3], eq(3)) == 3

        assert find([1, 2, 3], eq(4)) is None

    def test_with_polymorphic():
        assert find(["a", "a", "aa"], eq("a")) == "a"
        assert find(["a", "a", "aa"], eq("b")) is None
        assert find(["a", "a", "aa"], eq("aa")) == "aa"

    test_eq()
    test_with_polymorphic()

# Generated at 2022-06-21 19:49:44.757700
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-21 19:49:46.985547
# Unit test for function memoize
def test_memoize():
    count = 0
    def fn(x):
        nonlocal count
        count += 1
        return x
    fn = memoize(fn)
    fn(2)
    assert count == 1
    fn(3)
    assert count == 2
    fn(2)
    assert count == 2
    fn(3)
    assert count == 2

# Generated at 2022-06-21 19:49:53.492270
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x * 5)([1, 2, 3, 4]) == [5, 10, 15, 20]
    assert curried_map(lambda x: x * 2)([1, 2, 3, 4, 5]) == [2, 4, 6, 8, 10]
    assert curried_map(lambda x: x * 5, [1, 2, 3, 4, 5]) == [5, 10, 15, 20, 25]


# Generated at 2022-06-21 19:49:57.970996
# Unit test for function compose
def test_compose():
    assert compose(3, increase, increase) == 5
    assert compose(2, lambda x: x * 2, lambda x: x + 2) == 8



# Generated at 2022-06-21 19:50:00.605279
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(2) == 2
    assert identity(3) == 3



# Generated at 2022-06-21 19:50:17.419895
# Unit test for function memoize
def test_memoize():
    def assert_equal(first, second):
        return first == second

    @memoize
    def fn_a(num):
        return 2 * num

    assert_equal(fn_a(10), 20)
    assert_equal(fn_a(10), 20)
    assert_equal(fn_a(10), 20)
    assert_equal(fn_a(10), 20)
    assert_equal(fn_a(10), 20)

    @memoize
    def fn_b(first, last):
        return 2 * first * last

    assert_equal(fn_b(10, 15), 300)
    assert_equal(fn_b(10, 15), 300)
    assert_equal(fn_b(10, 15), 300)
    assert_equal(fn_b(10, 15), 300)

# Generated at 2022-06-21 19:50:18.335412
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-21 19:50:22.084804
# Unit test for function pipe
def test_pipe():
    assert pipe(1, lambda x: x + 1, lambda x: x ** 2) == 4
    assert pipe(1, lambda x: x + 1, lambda x: x ** 2, lambda x: x - 1) == 3



# Generated at 2022-06-21 19:50:24.726181
# Unit test for function increase
def test_increase():
    assert increase.args_count == 1
    assert increase(1) == 2
    assert increase(0) == 1
    assert increase(-1) == 0



# Generated at 2022-06-21 19:50:27.816250
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b: a)(3)(2) == 3
    assert curry(lambda a, b: a + b)(3)(2) == 5



# Generated at 2022-06-21 19:50:29.029706
# Unit test for function identity
def test_identity():
    assert identity(42) == 42



# Generated at 2022-06-21 19:50:30.836713
# Unit test for function identity
def test_identity():
    assert identity(2) == 2, 'Should return first argument'



# Generated at 2022-06-21 19:50:33.124297
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3, 4, 5]) == [2, 3, 4, 5, 6]


# Generated at 2022-06-21 19:50:38.331259
# Unit test for function memoize
def test_memoize():
    def some_function(argument):
        print('some function is called')

        return argument

    some_function_cache = memoize(some_function)

    some_function_cache(1)
    some_function_cache(1)
    some_function_cache('2')
    some_function_cache('2')
    some_function_cache(1)



# Generated at 2022-06-21 19:50:42.811715
# Unit test for function curry
def test_curry():
    f = curry(lambda x, y, z: x + y + z)
    assert f(1)(2)(3) == 6

    f = curry(lambda x, y, z: x + y + z)
    assert f(1,2)(3) == 6

    f = curry(lambda x, y, z: x + y + z)
    assert f(1)(2,3) == 6



# Generated at 2022-06-21 19:51:00.667521
# Unit test for function curried_filter
def test_curried_filter():
    """
    :returns:
    :rtype:
    """
    assert curried_filter(eq(1), [1, 2, 3, 4]) == [1]
    assert curried_filter(eq(2), [1, 2, 3, 4]) == [2]
    assert curried_filter(eq(3), [1, 2, 3, 4]) == [3]
    assert curried_filter(eq(4), [1, 2, 3, 4]) == [4]
    assert curried_filter(eq(0), [1, 2, 3, 4]) == []
    assert curried_filter(eq(5), [1, 2, 3, 4]) == []



# Generated at 2022-06-21 19:51:06.768527
# Unit test for function curried_map
def test_curried_map():
    assert curried_map([1, 2, 3])(increase) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-21 19:51:12.539818
# Unit test for function curry
def test_curry():
    """
    Test for function curry.
    """
    def get_sum(number, number1):
        return number + number1

    get_sum_curry = curry(get_sum)

    assert(get_sum_curry(1, 2) == 3)
    assert(get_sum_curry(1)(2) == 3)
    assert(get_sum_curry(3)(1) == 4)



# Generated at 2022-06-21 19:51:20.980926
# Unit test for function cond
def test_cond():
    tt = (True, True)
    tf = (True, False)
    ft = (False, True)
    ff = (False, False)

    assert cond([tt])() is True
    assert cond([tf])() is False
    assert cond([ft])() is True
    assert cond([ff])() is None

    gt4 = lambda n: n > 4
    eq4 = lambda n: n == 4
    lt4 = lambda n: n < 4

    assert cond([(gt4, inc), (eq4, inc), (lt4, dec)])
    assert cond([(gt4, inc), (eq4, inc), (lt4, dec)])(5) == 6
    assert cond([(gt4, inc), (eq4, inc), (lt4, dec)])(4) == 5

# Generated at 2022-06-21 19:51:24.169134
# Unit test for function identity
def test_identity():
    assert identity(10) == 10
    assert identity(-1) == -1
    assert identity(0) == 0
    assert identity(42) == 42
    assert identity(1.0) == 1.0


# Generated at 2022-06-21 19:51:27.674435
# Unit test for function curry
def test_curry():
    a = [1, 2, 3]
    b = [4, 5, 6]
    c = [7, 8, 9]

    assert curry(zip)(a, b, c) == list(zip(a, b, c))



# Generated at 2022-06-21 19:51:28.582222
# Unit test for function identity
def test_identity():
    assert identity(1) == 1


# Generated at 2022-06-21 19:51:32.938222
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b, c: a + b + c)(1)(2)(3) == 6
    assert curry(lambda a, b, c: a + b + c)(1)(2)(4) == 7
    assert curry(lambda a, b, c: a + b + c)(1)(2)(2) == 5
    assert curry(lambda a, b, c: a + b + c)(1)(2)()(2) == 5



# Generated at 2022-06-21 19:51:34.123449
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-21 19:51:35.114159
# Unit test for function identity
def test_identity():
    assert identity(42) == 42



# Generated at 2022-06-21 19:51:53.998278
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-21 19:51:55.854370
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2, range(6)) == [1, 3, 5]


# Generated at 2022-06-21 19:52:00.682426
# Unit test for function curried_map
def test_curried_map():
    # Arrange
    input = [1, 2, 3, 4, 5]
    expected = [2, 3, 4, 5, 6]

    # Act
    result = curried_map(increase)(input)

    # Assert
    assert result == expected



# Generated at 2022-06-21 19:52:03.029814
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(3) == 4
    assert increase(5) == 6


# Generated at 2022-06-21 19:52:05.574596
# Unit test for function compose
def test_compose():
    assert compose(
        'hello',
        lambda value: value + ' ',
        lambda value: value + 'world'
    ) == 'hello world'


# Generated at 2022-06-21 19:52:06.890186
# Unit test for function increase
def test_increase():
    assert increase(2) == 3
    assert increase(5) == 6


# Generated at 2022-06-21 19:52:10.100123
# Unit test for function compose
def test_compose():
    assert compose(
        'No PEP8',
        lambda string: string.upper(),
        lambda string: string.replace('PEP8', 'PEP-8')
    ) == 'NO PEP-8'


if __name__ == '__main__':
    test_compose()

# Generated at 2022-06-21 19:52:17.978409
# Unit test for function find
def test_find():
    """
    Run unit tests for find function.

    :param:
    :type:
    :returns:
    :rtype:
    """
    assert find([], lambda arg: True) is None
    assert find([1, 2, 3], lambda arg: arg == 4) is None
    assert find([1, 2, 3], lambda arg: arg == 2) == 2
    assert find([1, 2, 3], lambda arg: arg == 1) == 1
    assert find([1, 2, 3], lambda arg: arg == 3) == 3

# Generated at 2022-06-21 19:52:19.978734
# Unit test for function memoize
def test_memoize():
    @memoize
    def square(value):
        return value * value

    assert square(2) == 4
    assert square(2) == 4
    assert square(3) == 9


# Generated at 2022-06-21 19:52:28.618759
# Unit test for function memoize
def test_memoize():
    # create function to increment value without side effects
    def add(value):
        return value + 1

    # create cache for store results of function add
    cache = []

    # create memoized function using memoize function
    memoized_add = memoize(add, key=eq)

    # invoke memoized function with arg = 1, result = 2
    assert memoized_add(1) == 2
    # and second time with arg = 1, result = 2
    assert memoized_add(1) == 2
    # and third time with arg = 2, result = 3
    assert memoized_add(2) == 3
    # and fourth time with arg = 1, result = 2
    assert memoized_add(1) == 2



# Generated at 2022-06-21 19:53:26.635167
# Unit test for function identity
def test_identity():
    assert identity(2) == 2


# Generated at 2022-06-21 19:53:30.553835
# Unit test for function pipe
def test_pipe():
    assert pipe(1, increase, increase, increase) == 4
    assert pipe('test', lambda x: x[::-1], lambda x: x + x) == 'tsettse'



# Generated at 2022-06-21 19:53:36.418876
# Unit test for function memoize
def test_memoize():
    def test_fn(value):
        print("test_fn was called")
        return value

    memoized_fn = memoize(test_fn)

    def is_not_none(value):
        return value is not None

    assert is_not_none(find(memoized_fn(10), lambda cacheItem: cacheItem[0] == 10)) is not None

# Generated at 2022-06-21 19:53:47.359571
# Unit test for function curry
def test_curry():
    def foo(x, y, z):
        return x + y + z
    assert curry(foo) == curry(foo)
    assert curry(foo)(1, 2, 3) == curry(foo)(1)(2)(3)
    assert curry(foo)(1)(2)(3) == foo(1, 2, 3)
    assert curry(foo)(1, 2)(3) == foo(1, 2, 3)
    assert curry(foo)(1, y=2)(3) == foo(1, 2, 3)
    assert curry(foo)(1)(2, 3) == foo(1, 2, 3)
    assert curry(foo)(x=1)(2)(3) == foo(1, 2, 3)
    assert curry(foo)(x=1, y=2, z=3) == foo(1, 2, 3)


# Generated at 2022-06-21 19:53:51.932689
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)

    eq_curry = eq(1)
    assert eq_curry(1)
    assert not eq_curry(2)



# Generated at 2022-06-21 19:53:54.893785
# Unit test for function curry
def test_curry():
    # just checking that curring is working
    # TODO: replace with real test
    add2 = curry(lambda x, y: x + y)
    assert add2(1)(2) == 3



# Generated at 2022-06-21 19:53:56.200364
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    print("Test increase passed")



# Generated at 2022-06-21 19:53:58.378568
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)


# Generated at 2022-06-21 19:54:03.111864
# Unit test for function curried_filter
def test_curried_filter():
    is_even = lambda x: x % 2 == 0
    curried_evens = curried_filter(is_even)
    assert curried_evens(range(20)) == [0, 2, 4, 6, 8, 10, 12, 14, 16, 18]


# Generated at 2022-06-21 19:54:11.009434
# Unit test for function memoize
def test_memoize():
    @memoize
    def multiply(x):
        return x * 10
    assert multiply(2) == 20
    assert multiply(3) == 30
    assert multiply(2) == 20
    assert len(multiply.__closure__) == 1
    assert multiply.__closure__[0].cell_contents == [(2, 20), (3, 30)]

    @memoize
    def square(x):
        return x ** 2
    assert square(3) == 9
    assert square(3) == 9
    assert len(square.__closure__) == 1
    assert square.__closure__[0].cell_contents == [(3, 9)]



# Generated at 2022-06-21 19:55:17.091591
# Unit test for function memoize
def test_memoize():
    import functools

    @memoize
    def fib(n):
        return 1 if n <= 1 else fib(n - 1) + fib(n - 2)

    assert fib(10) == 55
    assert fib.__code__.co_flags == fib.__closure__[0].cell_contents.__code__.co_flags

    @memoize
    def fib(n):
        print('calculating fib ', n)
        return 1 if n <= 1 else fib(n - 1) + fib(n - 2)

    fib(10)
    fib(10)
    fib(11)
    assert fib.__code__.co_flags == fib.__closure__[0].cell_contents.__code__.co_flags


# Generated at 2022-06-21 19:55:20.522648
# Unit test for function find
def test_find():
    assert find([], eq(1)) is None
    assert find([1, 2, 3, 4, 5], eq(1)) == 1
    assert find([1, 2, 3, 4, 5], eq(6)) is None



# Generated at 2022-06-21 19:55:22.876157
# Unit test for function compose
def test_compose():
    # Check compose(identity, increase)(0) == 1
    assert compose(0, increase, identity) == 1


# Generated at 2022-06-21 19:55:26.333775
# Unit test for function pipe
def test_pipe():
    test_val = 1
    after_pipeline = pipe(
        1,
        lambda x: x + 1,
        lambda x: x * 2,
        lambda x: x - 1,
        lambda x: x + 5
    )

    assert after_pipeline == test_val * 2 + 5


co_curry = curry(curry)


# Generated at 2022-06-21 19:55:29.610336
# Unit test for function pipe
def test_pipe():
    assert pipe(
        1,
        lambda x: x + 1,
        lambda x: x + 10,
        lambda x: x - 2,
        lambda x: x * 3,
        lambda x: x ** 5
    ) == 82354


# Generated at 2022-06-21 19:55:33.097575
# Unit test for function compose
def test_compose():
    sum_and_increase = compose(2, sum, increase)
    assert sum_and_increase([1]) == 4
    assert sum_and_increase([1, 2, 3]) == 8



# Generated at 2022-06-21 19:55:35.737298
# Unit test for function pipe
def test_pipe():
    assert pipe(
        2,
        lambda x: x * 2,
        lambda y: y + 1
    ) == 5



# Generated at 2022-06-21 19:55:40.998332
# Unit test for function memoize
def test_memoize():
    """
    Function for testing memoize
    """
    def cube(value: int) -> int:
        return value ** 3

    cubic_memoize = memoize(cube, key=eq)
    print(cubic_memoize(2))
    print(cubic_memoize(2))
    print(cubic_memoize(3))



# Generated at 2022-06-21 19:55:44.654774
# Unit test for function cond
def test_cond():
    """
    Test case for function cond.
    """
    condition_list = [
        (lambda x: x >= 0, lambda x: x),
        (lambda x: x < 0, lambda x: -x),
    ]
    function = cond(condition_list)
    assert function(1) == 1
    assert function(-1) == 1
    assert function(0) == 0
    assert function(-0) == 0

# Generated at 2022-06-21 19:55:52.148357
# Unit test for function cond
def test_cond():
    """
    >>> cond_fn = cond([
    ...     (lambda d: d <= 10, lambda d: 10),
    ...     (lambda d: d >= 20, lambda d: 20),
    ... ])
    >>> assert cond_fn(5) == 10
    >>> assert cond_fn(15) == 10
    >>> assert cond_fn(25) == 20
    >>> assert cond_fn(30) == 20
    """
    pass

