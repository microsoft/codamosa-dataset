

# Generated at 2022-06-21 19:47:19.032920
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x * 2)([1, 2, 3]) == [2, 4, 6]



# Generated at 2022-06-21 19:47:24.873900
# Unit test for function memoize
def test_memoize():
    memoized_fibonacci = memoize(lambda n: n if n <= 1 else memoized_fibonacci(n - 1) + memoized_fibonacci(n - 2))

    assert memoized_fibonacci(1) == 1
    assert memoized_fibonacci(2) == 1
    assert memoized_fibonacci(6) == 8

# Generated at 2022-06-21 19:47:32.702069
# Unit test for function memoize
def test_memoize():
    def expensive_function(*args):
        print('Do something expensive...')
        return args[0]

    cached_function = memoize(expensive_function)

    assert cached_function('Hello') == 'Hello'
    assert cached_function('Hello') == 'Hello'  # Return result from cache
    assert cached_function('World') == 'World'

    cached_function = memoize(expensive_function, lambda old_arg, new_arg: old_arg == new_arg)
    assert cached_function('Hello') == 'Hello'
    assert cached_function('World') == 'World'



# Generated at 2022-06-21 19:47:38.949417
# Unit test for function compose
def test_compose():
    assert compose(2, lambda x: x * 2, lambda x: x + 2) == 6
    assert compose(
        'foo',
        lambda s: s * 2,
        lambda s: s + 'bar',
        lambda s: s[0:3]
    ) == 'foof'


# Generated at 2022-06-21 19:47:45.742498
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x < 0, increase),
        (lambda x: x == 0, lambda x: 0),
        (lambda x: x > 0, lambda x: x)
    ])(-100) == 1
    assert cond([
        (lambda x: x < 0, increase),
        (lambda x: x == 0, lambda x: 0),
        (lambda x: x > 0, lambda x: x)
    ])(0) == 0
    assert cond([
        (lambda x: x < 0, increase),
        (lambda x: x == 0, lambda x: 0),
        (lambda x: x > 0, lambda x: x)
    ])(100) == 100



# Generated at 2022-06-21 19:47:47.516851
# Unit test for function memoize
def test_memoize():
    assert memoize([1,2,3]) == [1,2,3]

# Generated at 2022-06-21 19:47:53.583771
# Unit test for function pipe
def test_pipe():
    assert pipe(
        1,
        increase,
        compose(
            identity,
            lambda i: i * 2,
            increase
        ),
        lambda i: i + 3
    ) == 11



# Generated at 2022-06-21 19:47:59.982888
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(2, 1)
    assert not eq(2, 1)
    assert eq('1', '1')
    assert not eq('1', '2')
    assert not eq(1.0, 1)



# Generated at 2022-06-21 19:48:01.439726
# Unit test for function identity
def test_identity():
    assert identity(10) == 10
    assert identity(None) is None



# Generated at 2022-06-21 19:48:02.581026
# Unit test for function increase
def test_increase():
    assert increase(10) == 11


# Generated at 2022-06-21 19:48:12.323587
# Unit test for function memoize
def test_memoize():
    count = 0
    def memoized_fn(argument):
        nonlocal count
        count += 1
        return argument

    assert count == 0

    memoized_fn = memoize(memoized_fn)
    assert count == 0
    assert memoized_fn(1) == 1
    assert count == 1

    assert memoized_fn(1) == 1
    assert count == 1

    assert memoized_fn(2) == 2
    assert count == 2

    assert memoized_fn(1) == 1
    assert count == 2

# Generated at 2022-06-21 19:48:15.547638
# Unit test for function eq
def test_eq():
    assert (curried_map(eq(2), [1, 2, 3]) == [False, True, False])


# Generated at 2022-06-21 19:48:19.100437
# Unit test for function memoize
def test_memoize():
    def fib(n: int) -> int:
        if n < 2:
            return n
        return fib(n - 2) + fib(n - 1)

    fib = memoize(fib)
    assert fib(5) == 5



# Generated at 2022-06-21 19:48:22.310425
# Unit test for function identity
def test_identity():
    assert identity(True) == True
    assert identity(None) == None
    assert identity(123) == 123
    assert identity(12.3) == 12.3


# Generated at 2022-06-21 19:48:25.807033
# Unit test for function compose
def test_compose():
    # Given
    compose_functions = [increase, decrease, identity]

    # When
    result = compose(0, *compose_functions)
    expected = 0

    # Then
    print(f"Made compose function with functions {compose_functions} and result {result}")
    assert result == expected



# Generated at 2022-06-21 19:48:31.133014
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y, 2)(2)(2) == 4
    assert curry(lambda x, y, z: x + y + z, 2)(2)(1) == 5
    assert curry(lambda x, y, z, t: x + y + z + t, 3)(1)(1, 1) == 4

# Generated at 2022-06-21 19:48:36.499672
# Unit test for function cond
def test_cond():
    symbols = {'one': 1, 'two': 2}
    getter = cond([
        (
            lambda key: key not in symbols,
            lambda key: 'undefined'
        ),
        (
            identity,
            lambda key: symbols[key]
        )
    ])

    assert getter('one') == 1
    assert getter('three') == 'undefined'



# Generated at 2022-06-21 19:48:37.344621
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:48:41.670979
# Unit test for function memoize
def test_memoize():
    not_memoize_test_fun = lambda x: x * x
    memoize_test_fun = memoize(not_memoize_test_fun)

    assert not_memoize_test_fun(3) == memoize_test_fun(3)


# Unit tests for function cond

# Generated at 2022-06-21 19:48:45.867309
# Unit test for function memoize
def test_memoize():
    def sum(a, b):
        return a + b

    curried_sum = curry(sum)

    assert curried_sum(2)(2) == 4
    assert curried_sum(3)(3) == 6
    assert curried_sum(2)(2) == 4
    assert curried_sum(2)(2) == 4



# Generated at 2022-06-21 19:48:55.011137
# Unit test for function cond
def test_cond():
    def test_function(value):
        test_function.value = value
        return value

    condition = cond([
        (eq(0), test_function)
    ])
    condition(0)
    # Assertion for function condition
    assert test_function.value == 0



# Generated at 2022-06-21 19:48:58.426103
# Unit test for function pipe
def test_pipe():
    assert [1, 2, 3, 4] == pipe(range(5), curried_filter(eq(0)), curried_map(increase))



# Generated at 2022-06-21 19:49:07.494658
# Unit test for function cond
def test_cond():
    # TODO: Rewrite to use unittest
    def to_string(x) -> str:
        return str(x)

    def to_array(x) -> List:
        return [x]

    def to_tuple(x) -> Tuple:
        return (x,)

    def is_instance_of(type_) -> Callable[[Any], bool]:
        return lambda x: isinstance(x, type_)

    to_collection = cond(
        [(is_instance_of(list), to_array),
         (is_instance_of(tuple), to_tuple),
         (is_instance_of(int), to_string),
         (lambda x: True, identity)]
    )

    assert to_collection([1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-21 19:49:10.071746
# Unit test for function pipe
def test_pipe():
    assert pipe(
        'some string',
        lambda x: x + '1',
        lambda x: x + '2',
        lambda x: x + '3'
    ) == 'some string123'


test_pipe()

# Generated at 2022-06-21 19:49:13.569803
# Unit test for function curry
def test_curry():
    def add(x, y):
        return x + y

    add_1 = curry(add)
    assert add_1(1)(1) == 2



# Generated at 2022-06-21 19:49:15.064386
# Unit test for function increase
def test_increase():
    assert increase(1) == 2, 'Increase function does not work'

# Generated at 2022-06-21 19:49:18.379549
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], eq(2)) == 2
    assert find([1, 2, 3, 4, 5], eq(6)) is None


# Unit tests for function cond

# Generated at 2022-06-21 19:49:20.887542
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(1)) == 1
    assert find([1, 2, 3], eq(4)) is None

# Generated at 2022-06-21 19:49:26.652740
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2)([1, 2, 3]) == [3]
    assert curried_filter(lambda x: x < 4)([1, 2, 3, 7, 8]) == [1, 2, 3]
    assert curried_filter(lambda x: x > 5)([1, 2, 3, 4, 5, 6, 7]) == [6, 7]


# Generated at 2022-06-21 19:49:34.741497
# Unit test for function cond
def test_cond():
    def f():
        return 'f'
    def g():
        return 'g'
    def h():
        return 'h'
    def i():
        return 'i'
    def k(x):
        return x == 1
    def l(x):
        return x == 2

    assert cond([(k, f), (l, g)])() == g()
    assert cond([(k, f), (l, g)]) == h
    assert cond([(k, f), (l, g)]) == i
    assert 'done'

# Generated at 2022-06-21 19:49:49.435766
# Unit test for function cond
def test_cond():
    condition_list1 = [
        (lambda x: x == 1, lambda x: x + 1),
        (lambda x: x == 2, lambda x: x - 1)
    ]
    condition_list2 = [
        (lambda y: y == 5, lambda y: y + 2),
        (lambda y: y == 6, lambda y: y - 5)
    ]

    assert cond(condition_list1)(1) == 2
    assert cond(condition_list1)(2) == 1

    assert cond(condition_list2)(5) == 7
    assert cond(condition_list2)(6) == 1

# Generated at 2022-06-21 19:49:50.734413
# Unit test for function pipe
def test_pipe():
    assert pipe(1, increase, increase, increase) == 4


# Generated at 2022-06-21 19:49:56.637689
# Unit test for function curry
def test_curry():
    # Test case 1:
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6, 'Curry error'

    # Test case 2:
    func = curry(lambda x, y, z: x + y + z)
    assert func(1, 2)(3) == 6, 'Curry error'

    # Test case 3:
    func = curry(lambda x, y, z: x + y + z)
    assert func(1)(2, 3) == 6, 'Curry error'


# Generated at 2022-06-21 19:49:58.885600
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-21 19:50:02.273175
# Unit test for function curry
def test_curry():
    def foo(*args):
        return args

    assert eq(curry(foo)(10)(20)(30), (10, 20, 30))

    print('Curry Test success')



# Generated at 2022-06-21 19:50:05.053757
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(2) == 2
    assert identity(1) == 1
    assert identity(2) == 2



# Generated at 2022-06-21 19:50:10.633628
# Unit test for function eq
def test_eq():
    assert(eq(1, 1) == True)
    assert(eq(1, 2) == False)
    assert(eq(1, 1) == curry(eq)(1, 1))
    assert(eq(1, 2) == curry(eq)(1, 2))


# Generated at 2022-06-21 19:50:13.496193
# Unit test for function pipe
def test_pipe():
    assert pipe(
        1,
        lambda i: i + 1,
        lambda i: i * 2,
    ) == 4


# Generated at 2022-06-21 19:50:17.779172
# Unit test for function compose
def test_compose():
    assert(compose(1, lambda x: x + 1, lambda x: x * 2) == 4)
    assert(compose(5, increase, lambda x: x * 2) == 12)



# Generated at 2022-06-21 19:50:19.593177
# Unit test for function curry
def test_curry():
    @curry
    def multiply(a, b):
        return a * b

    assert multiply(2)(2) == 4
    assert multiply(2) == curry(multiply(2), 1)



# Generated at 2022-06-21 19:50:37.370111
# Unit test for function find
def test_find():
    def assert_find(collection, key, expected):
        found = find(collection, key)
        if expected is None:
            assert found is None, "It is not None when it should be None."
        else:
            assert found == expected, "It is not %s when it should be." % expected

    assert_find([], lambda x: True, None)
    assert_find([1, 2, 3], lambda x: x == 1, 1)
    assert_find([1, 2, 3], lambda x: x == 5, None)



# Generated at 2022-06-21 19:50:42.208881
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x == 2, [1, 2, 3]) == [2]
    assert curried_filter(lambda x: x == 2)([1, 2, 3]) == [2]
    filter_by_2 = curried_filter(lambda x: x == 2)
    assert filter_by_2([1, 2, 3]) == [2]



# Generated at 2022-06-21 19:50:43.576647
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:50:48.153047
# Unit test for function eq
def test_eq():
    """
    Unit test for function eq
    """
    assert eq(2, 2) == True
    assert eq(1, 1.0) == True
    assert eq(0, False) == True
    assert eq(1, 0) == False
    assert eq(1, None) == False



# Generated at 2022-06-21 19:50:51.003160
# Unit test for function compose
def test_compose():
    assert 1 == compose(1, identity, identity, identity)
    assert 2 == compose(1, increase, increase)
    assert 3 == compose(1, increase, increase, increase)


# Generated at 2022-06-21 19:50:54.346121
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(100) == 101
    assert increase(1337) != 1336



# Generated at 2022-06-21 19:50:59.170966
# Unit test for function curry
def test_curry():
    assert callable(curry(lambda x, y: x + y))
    assert curry(lambda x, y: x + y)(1)(2) == 3
    test_function = curry(lambda x, y, z: x + y)
    assert test_function(1)(2)(3) == 3
    assert callable(curry(lambda x, y, z: x + y))



# Generated at 2022-06-21 19:51:08.378567
# Unit test for function memoize
def test_memoize():
    def add_one(x):
        print(f'add_one - {x}')
        return x + 1

    memoized_add_one = memoize(add_one)
    res1 = memoized_add_one(1)
    res2 = memoized_add_one(1)
    res3 = memoized_add_one(3)
    res4 = memoized_add_one(1)
    res5 = memoized_add_one(3)
    print('Result: ', res1, res2, res3, res4, res5)


# Generated at 2022-06-21 19:51:10.513009
# Unit test for function eq
def test_eq():
    assert eq(2)(2) == True
    assert eq(2, 2) == True
    assert eq(2)(2) == True



# Generated at 2022-06-21 19:51:12.157267
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(5) == 6

# Unit tests for function eq

# Generated at 2022-06-21 19:51:24.801165
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2
    assert increase(10) == 11
    print('test increase: Success')



# Generated at 2022-06-21 19:51:26.668860
# Unit test for function eq
def test_eq():
    assert eq(3, 3) == True
    assert eq(3, 4) == False



# Generated at 2022-06-21 19:51:29.797351
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], eq(3)) == 3
    assert find([1, 2, 3, 4, 5], eq(8)) == None
    assert find([], eq(8)) == None



# Generated at 2022-06-21 19:51:31.216142
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)


# Generated at 2022-06-21 19:51:32.514732
# Unit test for function eq
def test_eq():
    assert eq(5,5)
    assert not eq(5,3)


# Generated at 2022-06-21 19:51:39.625796
# Unit test for function find
def test_find():
    """
    Test for function find.
    :returns: None
    :rtype: NoneType
    """
    test_list: List[int] = [1, 2, 3, 4, 5, 6]

    def find_great_then_3(argument: int):
        return argument > 3

    if find(test_list, find_great_then_3) == 4:
        print('Test for function find passed!')
    else:
        print('Test for function find failed!')



# Generated at 2022-06-21 19:51:42.413581
# Unit test for function curry
def test_curry():
    def sum_3(a, b, c):
        return a + b + c

    assert curry(sum_3)(1)(2)(3) == sum_3(1, 2, 3)



# Generated at 2022-06-21 19:51:47.184643
# Unit test for function pipe
def test_pipe():
    pipe_func = pipe(1, lambda x: x + 1, lambda x: x * 2)
    assert pipe_func is not None
    assert pipe_func == 4


# Generated at 2022-06-21 19:51:52.302286
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6


# Generated at 2022-06-21 19:51:57.737751
# Unit test for function find
def test_find():
    # Test for found in collection
    collection = [1, 2, 3, 4, 5]
    assert find(collection, eq(3)) == 3
    assert find(collection, eq(1)) == 1

    # Test for not found in collection
    assert find(collection, eq(8)) is None
    assert find(collection, eq(0)) is None

    # Test for empty collection
    assert find([], eq(10)) is None



# Generated at 2022-06-21 19:52:23.582511
# Unit test for function pipe
def test_pipe():
    assert pipe(3, curry(lambda x: x + 1), curry(lambda x: x * 3)) == 12
    assert pipe("abc", curry(lambda x: x.upper()), curry(lambda x: len(x))) == 3
    assert pipe("abc", curry(lambda x: x.upper()), curry(lambda x: x * 3)) == "ABCABCABC"



# Generated at 2022-06-21 19:52:25.389871
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False



# Generated at 2022-06-21 19:52:27.250969
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(curried_filter(lambda x: x > 0), [0, 1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-21 19:52:28.465736
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2


# Generated at 2022-06-21 19:52:30.324720
# Unit test for function eq
def test_eq():
    assert(eq(1, 1))
    assert(not eq(1, 2))
    assert(eq('', ''))
    assert(not eq('1', 2))



# Generated at 2022-06-21 19:52:38.116995
# Unit test for function curried_filter
def test_curried_filter():
    """
    Test example from http://matt.might.net/articles/implementation-of-functional-language-features-in-javascript/
    """
    nums = [17, 28, 39, 46, 59, 72, 88, 100]
    # Applying curried_filter function and function to get first digit of number.
    first_eleven = curried_filter(lambda x: x < 12)(nums)

    assert [17, 28, 39] == first_eleven



# Generated at 2022-06-21 19:52:39.821523
# Unit test for function pipe
def test_pipe():
    assert pipe(1, increase) == 2
    assert pipe(1, identity) == 1



# Generated at 2022-06-21 19:52:45.166879
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(2)(2) == 4
    assert curry(lambda x, y, z: x + y + z)(1)(1)(1) == 3
    assert curry(lambda x, y, z, n: x + y + z + n)(1)(2)(3)(4) == 10



# Generated at 2022-06-21 19:52:46.001333
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:52:50.212342
# Unit test for function pipe
def test_pipe():
    test_value = 2
    test_functions = [multiply(2), add(2), subtract(2), divide(2)]
    result = pipe(test_value, *test_functions)

    assert result == 2


# Generated at 2022-06-21 19:53:14.908159
# Unit test for function identity
def test_identity():
    assert identity(42) == 42
    assert identity(None) is None


# Generated at 2022-06-21 19:53:20.372615
# Unit test for function curried_map
def test_curried_map():
    expected_result = [
        2,
        4,
        6,
        8,
    ]
    actual_result = pipe(
        [
            1,
            2,
            3,
            4,
        ],
        curried_map(lambda x: x * 2)
    )
    assert expected_result == actual_result



# Generated at 2022-06-21 19:53:24.308538
# Unit test for function find
def test_find():
    test_list = [
        {'id': 1, 'name': 'mike'},
        {'id': 2, 'name': 'moreno'}
    ]
    assert find(test_list, lambda item: item['id'] == 1) == {'id': 1, 'name': 'mike'}
    assert find(test_list, lambda item: item['name'] == 'moreno') == {'id': 2, 'name': 'moreno'}

# Generated at 2022-06-21 19:53:32.727010
# Unit test for function memoize
def test_memoize():
    memoized_func = memoize(increase)
    assert memoized_func(1) == 2
    assert memoized_func(1) == 2
    assert memoized_func(2) == 3
    assert memoized_func(2) == 3

    memoized_func = memoize(increase, lambda x, y: x == y)
    assert memoized_func(1) == 2
    assert memoized_func(1) == 2
    assert memoized_func(2) == 3
    assert memoized_func(2) == 3


# Generated at 2022-06-21 19:53:37.259404
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x * x, [1, 2, 3, 4]) == [1, 4, 9, 16]
    assert curried_map(lambda x: x * x)([1, 2, 3, 4]) == [1, 4, 9, 16]
    assert curried_map(lambda x: x * x)(range(4)) == [0, 1, 4, 9]
    assert curried_map(lambda x: x * x)(x for x in range(4)) == [0, 1, 4, 9]


# Generated at 2022-06-21 19:53:40.278034
# Unit test for function curry
def test_curry():
    assert increase(0) == 1

    curried_increase = curry(increase)
    assert curried_increase(0) == 1

    curried_increase1 = curry(increase)(0)
    assert curried_increase1 == 1



# Generated at 2022-06-21 19:53:41.631117
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1)(1) is True


# Generated at 2022-06-21 19:53:44.263675
# Unit test for function compose
def test_compose():
    def square(a):
        return a * a

    def double(a):
        return a * 2

    assert compose(2, square, double) == 8
    assert compose(2, double, square) == 16



# Generated at 2022-06-21 19:53:47.575985
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x % 2 == 0, lambda x: x // 2),
        (lambda x: x % 2 == 1, lambda x: x * 3 + 1)
    ])(3) == 10



# Generated at 2022-06-21 19:53:54.895471
# Unit test for function memoize
def test_memoize():
    @memoize
    def factorial(x):
        if x == 0:
            return 1
        return x * factorial(x-1)

    # assert factorial(0) == 1
    # assert factorial(1) == 1
    assert factorial(2) == 2
    # assert factorial(3) == 6
    assert factorial(4) == 24
    # assert factorial(5) == 120
    # assert factorial(6) == 720



# Generated at 2022-06-21 19:54:19.105680
# Unit test for function eq
def test_eq():
    eq = curry(lambda x, y: x == y)
    assert eq(3)(3)
    assert not eq(3)(4)



# Generated at 2022-06-21 19:54:20.912158
# Unit test for function identity
def test_identity():
    # Identity
    assert identity(1) == 1
    assert identity(2) == 2



# Generated at 2022-06-21 19:54:21.825985
# Unit test for function increase
def test_increase():
    assert(increase(1) == 2)



# Generated at 2022-06-21 19:54:28.970485
# Unit test for function curry
def test_curry():
    assert curry(lambda x: x * x * x)(1) == 1
    assert curry(lambda x, y, z: x * y * z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x * y * z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x * y * z)(1, 2, 3) == 6
    assert curry(lambda x, y, z: x * y * z)(1, 2, 3) == curry(lambda x, y, z: x * y * z)(1)(2, 3)
    assert curry(lambda x, y, z: x * y * z)(1, 2, 3) == curry(lambda x, y, z: x * y * z)(1)(2)(3)

# Generated at 2022-06-21 19:54:37.677353
# Unit test for function memoize
def test_memoize():
    @memoize
    def factorial(n):
        if n == 0:
            return 1
        else:
            return n * factorial(n - 1)

    assert factorial(4) == 24
    assert factorial(4) == 24
    assert factorial(4) == 24
    assert factorial(4) == 24

    @memoize
    def sum(n):
        return n * (n + 1) / 2

    assert sum(2) == 3
    assert sum(2) == 3
    assert sum(3) == 6
    assert sum(3) == 6
    assert sum(2) == 3
    assert sum(3) == 6



# Generated at 2022-06-21 19:54:39.507325
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-21 19:54:43.970845
# Unit test for function compose
def test_compose():
    increase_by_2 = compose(2, increase)
    assert increase_by_2(2) == 3

    identity_after_composing_increase = compose(1, increase, identity)
    assert identity_after_composing_increase == 2



# Generated at 2022-06-21 19:54:50.695304
# Unit test for function memoize
def test_memoize():
    import random

    random.seed(123)

    def random_callback():
        return random.random()

    result = curry(random_callback)

    result1 = result()
    result2 = result()
    assert eq(result1, result2)

    memo_random_callback = memoize(random_callback)
    result3 = memo_random_callback()
    result4 = memo_random_callback()
    result5 = memo_random_callback()
    assert not eq(result3, result4)
    assert eq(result4, result5)



# Generated at 2022-06-21 19:54:53.265664
# Unit test for function curry
def test_curry():
    """
    Test for function curl - Test if this function increase value by 1.
    :return: bool
    """
    return increase(1) == curry(increase)(1)



# Generated at 2022-06-21 19:55:00.305083
# Unit test for function memoize
def test_memoize():
    def fib(n):
        if n < 2:
            return n
        return fib(n-1) + fib(n-2)

    fib = memoize(fib)
    assert fib(0) == 0
    assert fib(1) == 1
    assert fib(7) == 13
    assert fib(25) == 75025
    assert fib(50) == 12586269025


if __name__ == "__main__":
    test_memoize()

# Generated at 2022-06-21 19:55:26.791116
# Unit test for function pipe
def test_pipe():
    # GIVEN
    value = 'lintCode'
    # WHEN
    result = pipe(value,
                  lambda x: x.replace('l', ''),
                  lambda x: x.replace('i', ''),
                  lambda x: ''.join(reversed(x)),
                  lambda x: x.upper())
    # THEN
    assert result == 'CODE'



# Generated at 2022-06-21 19:55:27.997357
# Unit test for function pipe
def test_pipe():
    assert pipe(
        1,
        increase,
        increase,
    ) == 3

# Generated at 2022-06-21 19:55:33.145596
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False
    assert eq(3, 3) is True
    assert eq(1, 2) is False
    assert eq(2, 3) is False
    assert eq(None, None) is True
    assert eq(1, None) is False
    assert eq(None, 3) is False


# Generated at 2022-06-21 19:55:42.260677
# Unit test for function cond
def test_cond():
    lg_fn = lambda value: value > 10
    lg_eq_fn = lambda value: value == 10
    eq_fn = lambda value: value == 7
    lt_fn = lambda value: value < 3

    condition_list = [
        (lg_fn, increase),
        (lg_eq_fn, identity),
        (eq_fn, increase),
        (lt_fn, increase),
    ]

    cond_fn = cond(condition_list)
    assert cond_fn(1) == 2
    assert cond_fn(7) == 8
    assert cond_fn(10) == 10
    assert cond_fn(11) == 12



# Generated at 2022-06-21 19:55:44.128751
# Unit test for function memoize
def test_memoize():
    assert memoize(lambda x: x + 1)(2) == 3
    assert memoize(lambda x: x + 1)(2) == 3



# Generated at 2022-06-21 19:55:49.934830
# Unit test for function eq
def test_eq():
    """
    For test function eq.
    """
    assert eq(2, 2) == True
    assert eq(2, 2.0) == True
    assert eq(2, '2') == False
    assert eq('2', '2') == True
    assert eq([2], [2]) == False



# Generated at 2022-06-21 19:55:56.604661
# Unit test for function find
def test_find():
    collection = [4, 3, 2, 1, 2]
    expected_search_result = 2

    # find all values
    find_all = find(collection, eq(2))
    assert find_all == expected_search_result

    # find first values
    find_first = find([expected_search_result, expected_search_result], eq(2))
    assert find_all == expected_search_result

    # find last value
    find_last = find(collection[::-1], eq(2))
    assert find_last == expected_search_result



# Generated at 2022-06-21 19:55:59.053706
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_filter(eq(2))([1, 2, 3]) == [2]



# Generated at 2022-06-21 19:56:03.978489
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2
    assert increase(4) == 5
    assert increase(14) == 15
    assert increase(23) == 24


# Generated at 2022-06-21 19:56:13.812184
# Unit test for function memoize
def test_memoize():
    def get_number(number):
        return number

    memoized_get_number = memoize(get_number)

    arguments: List[int] = [1, 2, 3, 4, 5, 1, 1, 3, 3, 5, 9]
    expectedResults: List[int] = [1, 2, 3, 4, 5, 1, 1, 3, 3, 5, 9]
    results: List[int] = list(map(memoized_get_number, arguments))
    assert expectedResults == results

    arguments: List[int] = [1, 2, 3, 4, 5, 1, 1, 3, 3, 5, 9]
    expectedResults: List[int] = [1, 2, 3, 4, 5, 1, 1, 3, 3, 5]

# Generated at 2022-06-21 19:56:45.049787
# Unit test for function memoize
def test_memoize():
    def f(x):
        print('calculating x ^ 2')
        return x ** 2
    def g(x):
        print('calculating x ^ 2')
        return x ** 2
    memoized_f = memoize(f)
    memoized_g = memoize(g)
    for i in range(10):
        print(i, ' ', memoized_f(i), ' ', memoized_g(i))
    for i in range(10):
        memoized_f(i)
        memoized_g(i)

# Testing function memoize
test_memoize()

# Generated at 2022-06-21 19:56:52.621893
# Unit test for function cond
def test_cond():
    def even(num):
        return num % 2 == 0

    def odd(num):
        return num % 2 == 1

    def positive(num):
        return num > 0

    def negative(num):
        return num < 0

    def is_zero(num):
        return num == 0

    def abs(num):
        return cond([
            (negative, lambda num: -num),
            (is_zero, identity),
            (positive, identity)
        ])(num)

    assert eq(abs(-10), 10)
    assert eq(abs(10), 10)
    assert eq(abs(0), 0)

# Generated at 2022-06-21 19:56:55.266724
# Unit test for function eq
def test_eq():
    """Test if function eq is working correctly"""
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1, 'a')



# Generated at 2022-06-21 19:57:02.199178
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b, c, d: a + b + c + d)(1, 2, 3, 4) == 10
    assert curry(lambda a, b, c, d: a + b + c + d)(1)(2)(3)(4) == 10
    assert curry(lambda a, b, c, d: a + b + c + d)(1)(2, 3, 4) == 10
    assert curry(lambda a, b, c, d: a + b + c + d)(1, 2, 3)(4) == 10
    assert curry(lambda a, b, c, d: a + b + c + d, 2)(1)(2) == 3
    assert curry(lambda a, b, c, d: a + b + c + d, 2)(1, 2) == 3

# Generated at 2022-06-21 19:57:08.082323
# Unit test for function curried_filter
def test_curried_filter():
    def greater(num):
        return lambda x: x > num

    collection = [1, 2, 3, 4, 5, 6]
    curried_greater = curried_filter(greater(3))
    result = curried_greater(collection)
    assert result == [4, 5, 6]
    result = curried_greater([1, 2, 3])
    assert result == []



# Generated at 2022-06-21 19:57:11.474344
# Unit test for function increase
def test_increase():
    assert increase(10) == 11, "Increase must return increased by 1 value!"


# Generated at 2022-06-21 19:57:12.530124
# Unit test for function identity
def test_identity():
    assert identity(1) == 1

