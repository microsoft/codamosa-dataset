

# Generated at 2022-06-21 19:47:32.342018
# Unit test for function cond
def test_cond():
    def test_result(result, expected):
        assert result == expected, 'Expected {0}, get {1}'.format(expected, result)

    def is_number(value):
        return isinstance(value, int)

    def is_lowercase_string(value):
        return isinstance(value, str) and value.islower()

    def is_uppercase_string(value):
        return isinstance(value, str) and value.isupper()

    def add_one(value):
        return value + 1

    def add_two(value):
        return value + 2

    def multiply_by_two(value):
        return value * 2


# Generated at 2022-06-21 19:47:44.015574
# Unit test for function memoize
def test_memoize():
    def make_adder(x: int) -> Callable:
        def make_adder_with_x(y: int) -> int:
            return x + y
        return make_adder_with_x

    add_2 = make_adder(2)
    add_2_memoized = memoize(add_2)
    assert add_2(3) == 5
    assert add_2_memoized(3) == 5
    assert add_2_memoized(3) == 5
    assert add_2_memoized(3) == 5
    assert add_2_memoized(3) == 5
    assert add_2_memoized(3) == 5
    assert add_2_memoized(3) == 5
    assert add_2_memoized(3) == 5
    assert add_2

# Generated at 2022-06-21 19:47:54.145173
# Unit test for function cond
def test_cond():
    def check_type(value, type_):
        return isinstance(value, type_)
    check_number = curry(check_type)(int)
    check_string = curry(check_type)(str)

    def is_even(value):
        return value % 2 == 0

    def sum(a, b):
        return a + b

    def multiply(a, b):
        return a * b

    def repeat_string(value, n):
        return value * n

    def repeat_number(value, n):
        return [value] * n

    test_conditions = cond([
        (check_number, is_even),
        (check_string, len)
    ])

    assert test_conditions(1) is False
    assert test_conditions(2) is True
    assert test_conditions('hello')

# Generated at 2022-06-21 19:47:59.479807
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x == 2)([0, 1, 2, 3, 4, 5, 6]) == [2]
    assert curried_filter(lambda x: x == 2, [0, 1, 2, 3, 4, 5, 6]) == [2]



# Generated at 2022-06-21 19:48:02.441468
# Unit test for function eq
def test_eq():
    # test for true result
    assert eq(1, 1) is True
    # test for false result
    assert eq(1, 2) is False



# Generated at 2022-06-21 19:48:05.073048
# Unit test for function find
def test_find():
    assert find([0, False, None], eq(False)) == False
    assert find([0, False], eq(None)) == None



# Generated at 2022-06-21 19:48:05.945341
# Unit test for function increase
def test_increase():
    assert increase(2) == 3



# Generated at 2022-06-21 19:48:06.764393
# Unit test for function increase
def test_increase():
    assert increase(4) == 5



# Generated at 2022-06-21 19:48:08.574780
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x % 2 == 0) == 2
    assert find([1, 3, 5], lambda x: x == 2) is None



# Generated at 2022-06-21 19:48:12.306166
# Unit test for function pipe
def test_pipe():
    print("Test pipe:")
    print("Initial value:", 10)
    value = pipe(10,
                 lambda x: x + 2,
                 lambda x: x * 2,
                 lambda x: x - 1
                 )
    print("Result:", value)
    print("Finish test\n")


# Generated at 2022-06-21 19:48:21.522328
# Unit test for function curry
def test_curry():
    def add(a, b, c):
        return a + b + c

    function = curry(add)
    assert function(1, 2, 3) == 6
    assert function(1, 2)(3) == 6
    assert function(1)(2, 3) == 6
    assert function(1)(2)(3) == 6


# Generated at 2022-06-21 19:48:24.456538
# Unit test for function pipe
def test_pipe():
    assert pipe(
        1,
        increase,
        lambda x: x * 5
    ) == 10

    assert pipe(
        "test1",
        lambda x: x + "2"
    ) == "test12"



# Generated at 2022-06-21 19:48:31.132944
# Unit test for function compose
def test_compose():
    _identity = compose(1, identity)
    assert _identity == 1, "first argument must be equal returned value"

    _increase = compose(1, increase)
    assert _increase == 2, "first argument must be equal returned value"

    _increase_and_identity = compose(1, increase, identity)
    assert _increase_and_identity == 2, "first argument must be equal returned value"



# Generated at 2022-06-21 19:48:34.282690
# Unit test for function curry
def test_curry():
    assert increase(5) == 6
    assert increase(1)(2) == 3
    assert increase(1)(2)(3) == 4
    assert increase(1)(2)(3)(4) == 5



# Generated at 2022-06-21 19:48:38.224610
# Unit test for function compose
def test_compose():
    assert compose(
        0,
        lambda arg: arg + 1,
        lambda arg: arg + 1,
        lambda arg: arg + 1
    ) == 3
    assert compose(
        2,
        lambda arg: arg + 1,
        lambda arg: arg + 1,
        lambda arg: arg + 1
    ) == 5


# Generated at 2022-06-21 19:48:43.703522
# Unit test for function compose
def test_compose():
    """
    >>> compose(1, identity)
    1
    >>> compose(1, increase)
    2
    >>> compose(1, increase, increase)
    3
    >>> compose(1, identity, increase, increase)
    3
    >>> compose(1, increase, identity, increase)
    3
    >>> compose(1, increase, increase, identity)
    3
    """


# Generated at 2022-06-21 19:48:46.582009
# Unit test for function identity
def test_identity():
    assert identity(123) == 123
    assert identity("123") == "123"
    assert identity([1, 2, 3]) == [1, 2, 3]
    assert identity({"a": 1}) == {"a": 1}



# Generated at 2022-06-21 19:48:48.415862
# Unit test for function compose
def test_compose():
    assert compose(1, increase, increase) == 3



# Generated at 2022-06-21 19:48:55.578550
# Unit test for function memoize
def test_memoize():
    counter = [0]

    def add(x):
        counter[0] += 1
        return x + 1
    memoized_add = memoize(add)
    assert memoized_add(6) == 7
    assert memoized_add(6) == 7
    assert counter[0] == 1
    assert memoized_add(7) == 8
    assert counter[0] == 2
    assert memoized_add(7) == 8
    assert counter[0] == 2
    assert memoized_add(6) == 7
    assert counter[0] == 2

# Generated at 2022-06-21 19:48:58.186564
# Unit test for function identity
def test_identity():
    assert identity(3) == 3
    assert identity('some string') == 'some string'
    assert identity(identity) == identity


# Generated at 2022-06-21 19:49:21.280530
# Unit test for function cond
def test_cond():
    is_even = lambda x: x % 2 == 0
    is_odd = lambda x: not is_even(x)
    is_positive = lambda x: x > 0
    is_negative = lambda x: x < 0
    increase = lambda x: x + 1
    decrease = lambda x: x - 1
    zero = lambda: 0

    assert 2 == cond([
        (is_even, increase),
        (is_odd, decrease),
    ])(1)

    assert 0 == cond([
        (is_positive, increase),
        (is_negative, decrease),
        (lambda: True, zero),
    ])(0)

    assert 0 == cond([
        (is_positive, decrease),
        (is_negative, increase),
        (lambda: True, zero),
    ])(0)


# Generated at 2022-06-21 19:49:23.882521
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity('a') == 'a'



# Generated at 2022-06-21 19:49:30.764212
# Unit test for function memoize
def test_memoize():
    """Unit test for function memoize"""

    def fun_to_memoize(x):
        return x + 2

    memoized_fun = memoize(fun_to_memoize)
    assert memoized_fun(1) == 3
    assert memoized_fun(1) == 3
    assert memoized_fun(2) == 4
    assert memoized_fun(2) == 4
    assert memoized_fun(2) == 4



# Generated at 2022-06-21 19:49:31.806719
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:49:41.726411
# Unit test for function memoize
def test_memoize():
    def some_function():
        print("some function called")
        return "some result"

    memoized = memoize(some_function)
    result = memoized()
    result = memoized()
    result = memoized()
    result = memoized()
    result = memoized()
    result = memoized()
    result = memoized()
    result = memoized()
    result = memoized()
    result = memoized()
    result = memoized()
    result = memoized()
    result = memoized()
    result = memoized()
    result = memoized()
    result = memoized()
    result = memoized()
    assert result == "some result"



# Generated at 2022-06-21 19:49:47.784823
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False
    assert eq(1)(1) is True
    assert eq(1)(2) is False
    assert eq(1, 1, 1) is False
    assert eq(1, 1, 1, 1) is False



# Generated at 2022-06-21 19:49:48.603906
# Unit test for function identity
def test_identity():
    assert identity(1) == 1


# Generated at 2022-06-21 19:49:55.120366
# Unit test for function curry
def test_curry():
    """
    Function for test curry functionality.
    Always should be passed.
    """
    fn = lambda a, b, c, d: a + b + c + d
    curried_function = curry(fn)
    assert curried_function(1, 2, 3, 4) == 10
    assert curried_function(1, 2, 3)(4) == 10
    assert curried_function(1)(2, 3, 4) == 10
    assert curried_function(1)(2)(3)(4) == 10



# Generated at 2022-06-21 19:49:56.690660
# Unit test for function eq
def test_eq():
    assert eq(5)(5) == True


# Generated at 2022-06-21 19:49:59.991467
# Unit test for function memoize
def test_memoize():
    def f(value):
        return value ** 2
    f = memoize(f)
    assert f(2) == 4
    assert f(2) == 4



# Generated at 2022-06-21 19:50:13.931178
# Unit test for function curried_filter
def test_curried_filter():
    numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    result = curried_filter(lambda n: n % 2 == 0)(numbers)
    assert result == [2, 4, 6, 8, 10], 'Filter should return even numbers of list'



# Generated at 2022-06-21 19:50:22.012205
# Unit test for function curried_filter
def test_curried_filter():
    # empty list must return empty list
    assert [] == curried_filter(lambda x: x, [])
    assert [] == curried_filter(lambda x: x)([])
    # filter with function eq on list of int
    assert [1, 2, 3] == curried_filter(eq(1), [1, 2, 3])
    assert [1, 2, 3] == curried_filter(eq(1))([1, 2, 3])
    assert [1] == curried_filter(eq(1), [1])
    assert [1] == curried_filter(eq(1))([1])
    assert [] == curried_filter(eq(1), [2])
    assert [] == curried_filter(eq(1))([2])
    # filter with function eq on list of dicts
    list_of_dicts

# Generated at 2022-06-21 19:50:26.202723
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-21 19:50:29.310287
# Unit test for function compose
def test_compose():
    """
    Test compose function

    :return:
    :rtype:
    """
    assert compose(2, increase, increase) == 4
    assert compose(2, identity, increase) == 3



# Generated at 2022-06-21 19:50:31.514358
# Unit test for function identity
def test_identity():
    assert identity(42) == 42
    assert identity.__name__ == 'identity'



# Generated at 2022-06-21 19:50:37.140804
# Unit test for function eq
def test_eq():
    assert eq(3, 3)
    assert not eq(3, 5)
    assert eq({'a': 2}, {'a': 2})
    assert not eq({'a': 2}, {'a': 2, 'b': 1})
    assert not eq({'a': 2}, {'a': 3})
    assert eq(None, None)
    assert not eq(None, 3)


# Generated at 2022-06-21 19:50:41.372320
# Unit test for function eq
def test_eq():
    eq_two_numbers = eq(2, 2)
    eq_two_strings = eq('test', 'test')
    eq_numbers_and_string = eq('test', 2)

    assert eq_two_numbers == True
    assert eq_two_strings == True
    assert eq_numbers_and_string == False



# Generated at 2022-06-21 19:50:45.781914
# Unit test for function curried_filter
def test_curried_filter():
    list_to_filter = [5, 6, 7, 8, 9, 10]
    assert list(curried_filter(lambda x: x > 8)(list_to_filter)) == [9, 10]
    assert list(curried_filter(lambda x: x > 5)(list_to_filter)) == [6, 7, 8, 9, 10]
    assert list(curried_filter(lambda x: x > 10)(list_to_filter)) == []



# Generated at 2022-06-21 19:50:50.240374
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) != [1, 2, 4]



# Generated at 2022-06-21 19:51:01.114202
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(0), [0, 1, 2, 3])([]) == []
    assert curried_filter(eq(0), [0])([]) == [0]
    assert curried_filter(eq(0), [1, 2, 3])([]) == []
    assert curried_filter(eq(0), [1, 0, 2, 0, 3, 0])([]) == [0, 0, 0]

    assert curried_filter(eq(0), [0, 1, 2, 3], []) == []
    assert curried_filter(eq(0), [0], []) == [0]
    assert curried_filter(eq(0), [1, 2, 3], []) == []

# Generated at 2022-06-21 19:51:10.644936
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:51:12.304977
# Unit test for function eq
def test_eq():
    assert eq(5, 5)
    assert not eq(4, 5)


# Generated at 2022-06-21 19:51:20.864412
# Unit test for function memoize
def test_memoize():
    def debug(value):
        return value

    def double(value):
        return value * 2

    def triple(value):
        return value * 3

    def four_times(value):
        return value * 4

    memoized_double = memoize(double)
    assert memoized_double(1) == 2
    assert memoized_double(2) == 4
    assert memoized_double(1) == 2
    assert memoized_double(3) == 6

    memoized_triple = memoize(triple)
    assert memoized_triple(1) == 3
    assert memoized_triple(2) == 6
    assert memoized_triple(1) == 3
    assert memoized_triple(3) == 9

    memoized_debug = memoize(debug)
    assert memoized_debug(1)

# Generated at 2022-06-21 19:51:22.580198
# Unit test for function pipe
def test_pipe():
    assert pipe(1, increase, identity) == 2
    return True



# Generated at 2022-06-21 19:51:23.567481
# Unit test for function identity
def test_identity():
    assert identity(10) == 10



# Generated at 2022-06-21 19:51:27.912209
# Unit test for function pipe
def test_pipe():
    result = pipe(
        1,
        increase,
        curried_map(lambda x: x * 2),
        curried_filter(lambda x: x > 10),
        curried_map(lambda x: x - 1)
    )
    assert result == [15]



# Generated at 2022-06-21 19:51:31.645629
# Unit test for function memoize
def test_memoize():
    def func(a):
        return a

    fn = memoize(func)
    fn(1)
    fn(1)
    fn(1)

    assert fn.__closure__[0].cell_contents[0][0] == 1
    assert len(fn.__closure__[0].cell_contents) == 1



# Generated at 2022-06-21 19:51:33.742552
# Unit test for function compose
def test_compose():
    assert compose(1, compose(inc, compose(inc, compose(inc, identity)))) == 4


# Generated at 2022-06-21 19:51:39.578340
# Unit test for function curried_filter
def test_curried_filter():
    # Arrange
    collection = [1, 2, 3, 4, 5, 6, 7]
    filterer = lambda x: x % 2 == 0

    # Act
    result1 = curried_filter(filterer, collection)
    result2 = curried_filter(filterer)(collection)

    # Assert
    assert result1 == result2 == [2, 4, 6]



# Generated at 2022-06-21 19:51:41.349372
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(0, -0) == True



# Generated at 2022-06-21 19:52:04.084763
# Unit test for function memoize
def test_memoize():
    def factorial(n):
        if n == 0 or n == 1:
            return 1
        return n * factorial(n - 1)

    factorial_memoized = memoize(factorial)

    assert factorial_memoized(10) == factorial(10)
    print('Unit test for function memoize is OK!')

# Generated at 2022-06-21 19:52:06.793840
# Unit test for function identity
def test_identity():
    assert identity("test_string") == "test_string"
    assert identity("another_string") == "another_string"



# Generated at 2022-06-21 19:52:08.144732
# Unit test for function pipe
def test_pipe():
    assert pipe(-12, identity, abs, increase) == 13



# Generated at 2022-06-21 19:52:10.332329
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], eq(2)) == 2
    assert find([1, 2, 3, 4], eq(5)) is None



# Generated at 2022-06-21 19:52:11.125161
# Unit test for function increase
def test_increase():
    assert increase(1) == 2


# Generated at 2022-06-21 19:52:11.891630
# Unit test for function identity
def test_identity():
    assert identity(5) == 5


# Generated at 2022-06-21 19:52:13.171314
# Unit test for function increase
def test_increase():
    result = increase(1)
    assert result == 2


# Generated at 2022-06-21 19:52:21.759228
# Unit test for function memoize
def test_memoize():
    def test():
        def foo():
            print('foo')
            return 1

        def bar(a):
            print('bar')
            return a + 1

        foo = memoize(foo)
        bar = memoize(bar, key=lambda a, b: a == b)
        foo()
        foo()
        foo()
        foo()
        print(bar(2))
        print(bar(2))
        print(bar(3))
        print(bar(2))
        print(bar(3))
    test()



# Generated at 2022-06-21 19:52:22.760893
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-21 19:52:23.769294
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:53:01.766752
# Unit test for function compose
def test_compose():
    assert compose(0, increase, increase) is 2
    assert compose('', lambda val: f'{val}2', lambda val: f'1{val}') is '12'



# Generated at 2022-06-21 19:53:02.639144
# Unit test for function increase
def test_increase():
    assert increase(1) == 2


# Generated at 2022-06-21 19:53:05.908352
# Unit test for function curried_filter
def test_curried_filter():
    @curried_filter
    def filterer(item: int) -> bool:
        return item > 3

    assert filterer([1,2,3,4,5]) == [4, 5]



# Generated at 2022-06-21 19:53:10.493052
# Unit test for function curried_map
def test_curried_map():
    def func(x):
        return 2 * x

    arr1 = [1, 2, 3, 4, 5]
    res = curried_map(func)(arr1)
    assert res == [2, 4, 6, 8, 10]

    arr1 = [1, 2, 3, 4, 5]
    res = curried_map(func, arr1)
    assert res == [2, 4, 6, 8, 10]



# Generated at 2022-06-21 19:53:13.186081
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-21 19:53:16.072479
# Unit test for function increase
def test_increase():
    """
    Test for function increase.

    :returns: None
    :rtype: None
    """
    assert increase(3) == 4



# Generated at 2022-06-21 19:53:23.476534
# Unit test for function cond
def test_cond():
    def add(a, b):
        return a + b

    def concat(a, b):
        return str(a) + str(b)

    def get_max(a, b):
        return max(a, b)

    fn = cond([
        (lambda v: isinstance(v, int), add),
        (lambda v: isinstance(v, str), concat),
        (lambda v: isinstance(v, float), get_max),
    ])
    print(fn(1, 2))
    print(fn('1', '2'))
    print(fn(1.0, 2.0))



# Generated at 2022-06-21 19:53:24.518487
# Unit test for function increase
def test_increase():
    assert 1 == increase(0)


# Generated at 2022-06-21 19:53:26.143607
# Unit test for function pipe
def test_pipe():
    assert pipe(1, increase, increase) == 3



# Generated at 2022-06-21 19:53:28.880532
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert eq(1)(1)
    assert eq(1)(1)



# Generated at 2022-06-21 19:54:43.596795
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity("str") == "str"
    assert identity({}) == {}



# Generated at 2022-06-21 19:54:47.082046
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x % 2 == 1) == 1
    assert find([2, 4, 6, 8], lambda x: x % 2 == 1) is None
    assert find([1, 2, 3, 4], lambda x: x > 4) is None



# Generated at 2022-06-21 19:54:48.521954
# Unit test for function curried_map
def test_curried_map():
    curried_sum = curried_map(lambda x: x + 1)
    assert(curried_sum([1, 2, 3]) == [2, 3, 4])


# Generated at 2022-06-21 19:54:59.789034
# Unit test for function memoize
def test_memoize():
    """
    Test case for function memoize
    """
    print('Unit test for function memoize')
    import random

    @memoize
    def random_or_cached(*args) -> int:
        """
        Returns random number from range 0 to 100 or cached value if any.

        :param args: arguments to pass to next function
        :type args: Any
        :returns: random number from range 0 to 100 or cached value if any
        :rtype: Int
        """
        return random.randint(0, 100)

    print(random_or_cached(1))
    print(random_or_cached('key'))
    print(random_or_cached('key'))
    print(random_or_cached('key'))
    print(random_or_cached(1))

# Generated at 2022-06-21 19:55:01.026569
# Unit test for function pipe
def test_pipe():
    assert pipe(2, increase) == increase(2)
    assert pipe(2, increase, increase) == increase(2) + 1



# Generated at 2022-06-21 19:55:09.198644
# Unit test for function compose
def test_compose():
    # GTL - get tail and list, list - get and second value to list
    # compose(2, inc, inc, inc)
    # inc(2) = 3
    # inc(3) = 4
    # inc(4) = 5 = compose(2, inc, inc, inc)
    # inc apply from right to left
    multiplier = lambda x: x * 2
    adder = lambda x: x + 1
    sub = lambda x: x - 1
    zero = lambda x: x

    assert compose(2, multiplier, adder) == 6
    assert compose(1, adder, zero) == 1
    assert compose(0, zero, zero) == 0
    assert compose(2, multiplier, adder, sub) == 5
    assert compose(3, multiplier, adder, sub, sub) == 2

# Generated at 2022-06-21 19:55:17.656770
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y: x + y)(1)(2)(3)(4)(5)(6)(7)(8)(9)(10) == 55
    assert curry(lambda x, y: x + y, 1)(1) == 2
    assert curry(lambda x, y: x + y, 3)(2)(1)(0) == 3
    assert curry(lambda x, y: x + y, 10)(1)(2)(3)(4)(5)(6)(7)(8)(9)(10) == 55
    assert curry(lambda x: x + 1, 1)(1) == 2



# Generated at 2022-06-21 19:55:19.444976
# Unit test for function curried_map
def test_curried_map():
    assert [2, 4, 6] == curried_map(lambda item: item + 1, [1, 2, 3])



# Generated at 2022-06-21 19:55:27.326625
# Unit test for function curried_map
def test_curried_map():
    get_value = lambda item: item['value']
    collection = [{'value': 1}, {'value': 2}, {'value': 3}]
    doubled_collection = [{'value': 2}, {'value': 4}, {'value': 6}]
    double_value = lambda item: {'value': 2 * item['value']}

    assert curried_map(double_value, collection) == doubled_collection
    double_values = curried_map(double_value)
    assert double_values(collection) == doubled_collection

    get_doubled_values = compose(curried_map(get_value), curried_map(double_value))
    assert get_doubled_values(collection) == [2, 4, 6]



# Generated at 2022-06-21 19:55:30.813847
# Unit test for function memoize
def test_memoize():
    def slow(x):
        for i in range(1000000):
            pass
        return x

    fast = memoize(slow)
    assert fast(1) == fast(1)
    assert fast(1) is not fast(2)

