

# Generated at 2022-06-21 19:47:27.804391
# Unit test for function cond
def test_cond():
    isEven = lambda x: x % 2 == 0
    getEven = lambda x: x + 2
    getOdd = lambda x: x + 1
    assert cond([(isEven, getEven), (lambda x: True, getOdd)])(1) == 2
    assert cond([(isEven, getEven), (lambda x: True, getOdd)])(2) == 4
    assert cond([(isEven, getEven), (lambda x: True, getOdd)])(3) == 4



# Generated at 2022-06-21 19:47:34.017914
# Unit test for function cond
def test_cond():
    """
    Function for unit testing function cond
    """
    even = lambda x: x % 2 == 0
    odd = lambda x: x % 2 != 0
    cond_even = cond([(even, increase), (odd, identity)])
    cond_odd = cond([(odd, increase), (even, identity)])
    assert cond_even(1) == 1
    assert cond_even(2) == 3
    assert cond_odd(1) == 2
    assert cond_odd(2) == 2

# Generated at 2022-06-21 19:47:40.770610
# Unit test for function find
def test_find():
    """
    Test method for find.
    Test cases:
    1. Test if find is working
    2. Test if find is working on empty collection
    3. Test if find is working on None collection 
    """
    assert find([1, 2, 3], EQ(3)) == 3
    assert find([], EQ(3)) is None
    assert find(None, EQ(3)) is None

# Generated at 2022-06-21 19:47:45.321238
# Unit test for function find
def test_find():
    assert find([], identity) is None
    assert find([1, 2, 3], identity) is 1
    assert find([None, 2, 3], identity) is 2
    assert find([1, 2, None], identity) is 1
    assert find([1, 2, 2], lambda v: v == 2) is 2
    assert find([1, None, 2], lambda v: v is None) is None



# Generated at 2022-06-21 19:47:47.670199
# Unit test for function compose
def test_compose():
    def test_func(x):
        return x * 2
    assert compose(1, test_func) == 2


# Generated at 2022-06-21 19:47:55.161230
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    add = memoize(add)
    assert add(1, 2) == 3
    assert add(2, 3) == 5
    assert add(2, 3) == 5
    assert add(3, 4) == 7
    assert add(1, 2) == 3



# Generated at 2022-06-21 19:48:06.341333
# Unit test for function cond
def test_cond():
    is_left = lambda value: value in (True, False)
    is_right = lambda value: value in range(0, 10)
    def is_bottom(value):
        return type(value) == str

    execute_left = lambda value, *args: f'L {value}'
    execute_right = lambda value, *args: f'R {value}'
    execute_bottom = lambda value, *args: f'B {value}'

    test_cond = cond([
        (is_left, execute_left),
        (is_right, execute_right),
        (is_bottom, execute_bottom)
    ])

    assert test_cond(1) == 'R 1'
    assert test_cond('s') == 'B s'
    assert test_cond(True) == 'L True'



# Generated at 2022-06-21 19:48:08.097293
# Unit test for function pipe
def test_pipe():
    assert pipe(
        1,
        lambda value: value + 1,
        lambda value: value * 2
    ) == 4



# Generated at 2022-06-21 19:48:08.866165
# Unit test for function identity
def test_identity():
    assert identity(2) == 2


# Generated at 2022-06-21 19:48:17.068072
# Unit test for function find
def test_find():
    # call function find on empty list
    assert find([], lambda x: True is None)
    # find first element
    assert find([1, 2, 3], lambda x: x == 1) == 1
    # find second element
    assert find([1, 2, 3], lambda x: x == 2) == 2
    # find third element
    assert find([1, 2, 3], lambda x: x == 3) == 3
    # find element in list of multiple identical elements
    assert find([0, 1, 0, 1, 0, 1], lambda x: x == 1) == 1



# Generated at 2022-06-21 19:48:35.444171
# Unit test for function curried_filter
def test_curried_filter():
    sieve = lambda sieve, number: \
        curried_filter(lambda prime_number: prime_number % number == 1, sieve) \
        if number > 1 else sieve

    assert curried_filter(eq(1), [1, 2, 3, 4]) == [1]
    assert curried_filter(eq(1), [1, 2, 3, 4])([1, 2, 3, 4]) == [1]
    assert curried_filter(eq(1))([1, 2, 3, 4])([1, 2, 3, 4]) == [1]
    assert curried_filter(eq(1))([1, 2, 3, 4])([1, 2, 3, 4]) == [1]

# Generated at 2022-06-21 19:48:39.769293
# Unit test for function find
def test_find():
    assert find(list(range(10)), lambda x: x % 2 == 0) == 0
    assert find(list(range(10)), lambda x: x % 2 == 1) == 1
    assert find(list(range(10)), lambda x: x % 2 == 2) is None



# Generated at 2022-06-21 19:48:40.812258
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:48:44.441897
# Unit test for function cond
def test_cond():
    condition = lambda x: x > 0
    function = lambda x: identity(x)
    assert cond([
        (condition, function),
        (lambda x: x == 0, identity),
        (condition, lambda x: x)
    ])(1) == 1



# Generated at 2022-06-21 19:48:47.187817
# Unit test for function identity
def test_identity():
    assert identity(5) == 5



# Generated at 2022-06-21 19:48:57.455183
# Unit test for function cond
def test_cond():
    def to_upper(value: str) -> str:
        return value.upper()

    def to_lower(value: str) -> str:
        return value.lower()

    def when_empty(value: str) -> bool:
        return not value

    def when_started_with_lower_letter(value: str) -> bool:
        return value[0].islower()

    assert cond([
        (when_started_with_lower_letter, to_upper),
        (when_empty, identity)
    ])('hello world') == 'HELLO WORLD'
    assert cond([
        (when_started_with_lower_letter, to_upper),
        (when_empty, identity)
    ])('') == ''

# Generated at 2022-06-21 19:49:00.865590
# Unit test for function pipe
def test_pipe():
    assert pipe(
        [0, 1, 2],
        curried_map(increase),
        curried_filter(lambda x: x % 2 == 0),
    ) == [2]

# Generated at 2022-06-21 19:49:04.804601
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(3, 1+2)
    assert not eq(3, 1+3)
    assert eq(eq, eq)
    assert not eq(identity, increase)



# Generated at 2022-06-21 19:49:08.547700
# Unit test for function compose
def test_compose():
    compose(
        3,
        compose(
            lambda value: value + 1,
            lambda value: value * 2
        ),
        lambda value: value * 3
    ) == 21



# Generated at 2022-06-21 19:49:15.997125
# Unit test for function cond
def test_cond():
    is_one = lambda x: x == 1
    return_one = lambda: 1
    return_two = lambda: 2
    return_five = lambda: 5

    assert cond([
        (is_one, return_one),
        (lambda x: True, return_five)
    ])(1) == 1
    assert cond([
        (is_one, return_five),
        (lambda x: True, return_two)
    ])(1) == 2



# Generated at 2022-06-21 19:49:30.009931
# Unit test for function pipe
def test_pipe():
    assert pipe(
        42,
        lambda x: x + 1,
        lambda x: x * 2
    ) == 86



# Generated at 2022-06-21 19:49:32.440099
# Unit test for function curry
def test_curry():
    assert curry(identity)(1) == 1


# Test for function eq

# Generated at 2022-06-21 19:49:37.157604
# Unit test for function eq
def test_eq():
    assert eq(1)(2) is False
    assert eq(1, 2) is False
    assert eq(1)(1) is True
    assert eq(1, 1) is True



# Generated at 2022-06-21 19:49:38.299933
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)(list(range(5))) == list(range(1, 6))



# Generated at 2022-06-21 19:49:44.831006
# Unit test for function cond
def test_cond():
    def is_even(x: int) -> bool:
        return x % 2 == 0

    def is_divisible_by_3(x: int) -> bool:
        return x % 3 == 0

    def is_divisible_by_5(x: int) -> bool:
        return x % 5 == 0

    is_multiple = cond([(is_even, "multiple of 2"), (is_divisible_by_3, "multiple of 3"), (is_divisible_by_5, "multiple of 5")])
    assert is_multiple(9) == "multiple of 3"
    assert is_multiple(5) == "multiple of 5"

# Generated at 2022-06-21 19:49:53.139036
# Unit test for function curry
def test_curry():

    def sum_three_args(x, y, z):
        return x + y + z

    sum_three_args_curry = curry(sum_three_args, 3)

    assert sum_three_args_curry(1)(2)(3) == sum_three_args(1, 2, 3)
    assert sum_three_args_curry(1, 2)(3) == sum_three_args(1, 2, 3)
    assert sum_three_args_curry(1, 2, 3) == sum_three_args(1, 2, 3)



# Generated at 2022-06-21 19:49:58.417831
# Unit test for function curried_filter
def test_curried_filter():
    """
    Testing curried_filter function
    curried_filter get function and list of numbers.
    Returns new list with elements from original list which more than 5.

    :return: Testing passed or error
    """
    curried_filter_function = curried_filter(lambda elem: elem > 5)
    test_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    result_list = [6, 7, 8, 9, 10]

    if curried_filter_function(test_list) == result_list:
        return True
    else:
        return False


# Generated at 2022-06-21 19:50:05.242040
# Unit test for function pipe
def test_pipe():
    assert pipe(
        10,
        lambda x: x + 2,
        lambda x: x * 2,
        lambda x: x - 4
    ) == 18
    assert pipe(
        10,
        lambda x: x + 2,
        lambda x: x * 2
    ) == 22
    assert pipe(
        1,
        lambda x: x + 2,
        lambda x: x * 2,
        lambda x: x - 4
    ) == 0



# Generated at 2022-06-21 19:50:13.231349
# Unit test for function eq
def test_eq():
    test_args = [
        (1, 1),
        (1, 2),
        (None, None),
        ("string", "string"),
        ("string", 1),
        (True, True),
        (False, True),
        ([], []),
        ([1, 2, 3], [1, 2, 3])
    ]

    for args in test_args:
        assert eq(*args)


# Unit tests for function curried_map

# Generated at 2022-06-21 19:50:21.188578
# Unit test for function memoize
def test_memoize():
    """
    Unit test for function memoize.

    :returns: True if all tests passed, otherwise False
    :rtype: Bool
    """
    def fib(number):
        if number <= 1:
            return number
        return fib(number - 1) + fib(number - 2)

    fib = memoize(fib)

    mem = fib(31)
    # print(mem)
    assert mem == 1346269, "memoized fibonacci should be equal 1346269"
    assert fib(31) == 1346269, "memoized fibonacci should be equal 1346269"

    return True


if __name__ == '__main__':
    print(test_memoize())

# Generated at 2022-06-21 19:50:34.969475
# Unit test for function compose
def test_compose():
    """
    Test function compose
    """
    assert compose(
        value=10,
        functions=[
            lambda value: value * 2,
            lambda value: value + 4,
            lambda value: value / 4
        ]
    ) == 13



# Generated at 2022-06-21 19:50:40.854054
# Unit test for function curried_map
def test_curried_map():
    test_list = [1, 2, 3]
    assert curried_map(increase, test_list) == [2, 3, 4]
    assert curried_map(increase)(test_list) == [2, 3, 4]
    assert curried_map(increase, []) == []
    assert curried_map(increase)([]) == []
    assert curried_map(increase)([0]) == [1]



# Generated at 2022-06-21 19:50:44.059547
# Unit test for function memoize
def test_memoize():
    @memoize
    def factorial(n):
        if (n == 0):
            return 1
        else:
            return factorial(n - 1) * n

    for i in range(5):
        factorial(i)

    assert len(factorial.__closure__[0].cell_contents) == 5



# Generated at 2022-06-21 19:50:46.509133
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq('1', '1')



# Generated at 2022-06-21 19:50:49.574768
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-21 19:50:50.954026
# Unit test for function eq
def test_eq():
    assert eq(1, 1)



# Generated at 2022-06-21 19:50:53.095253
# Unit test for function increase
def test_increase():
    assert increase(1) == 2


# Generated at 2022-06-21 19:50:56.410907
# Unit test for function compose
def test_compose():
    compose_result = compose(3, increase, increase, increase)
    assert compose_result == 6

    compose_result = compose(0, identity)
    assert compose_result == 0



# Generated at 2022-06-21 19:50:59.724057
# Unit test for function compose
def test_compose():
    functions = [
        lambda x: x + 1,
        lambda x: 2 * x,
        lambda x: x / 2
    ]
    assert compose(1, *functions) == 3
    assert pipe(1, *functions) == 3



# Generated at 2022-06-21 19:51:01.577596
# Unit test for function curry
def test_curry():
    assert curry(increase)(1) == 2
    assert curry(increase)(1)(2) == 3
    assert curry(increase)(1)(2)(3) == 4


# Generated at 2022-06-21 19:51:18.918299
# Unit test for function cond
def test_cond():
    def first(x):
        return x == 'foo'

    def second(x):
        return x == 'bar'


    def lambdafirst(x):
        return x == 'foo'

    def lambdasecond(x):
        return x == 'bar'


    def foo(x):
        return x + 'foo'


    def bar(x):
        return x + 'bar'

    def baz(x):
        return x + 'baz'

    func = cond([[first, foo], [second, bar]])
    assert func('foo') == 'foo' + 'foo'
    assert func('bar') == 'bar' + 'bar'
    assert func('lol') == 'lol' + 'baz'


# Generated at 2022-06-21 19:51:29.716499
# Unit test for function find
def test_find():
    collection = [
        {'id': 1, 'name': 'name1'},
        {'id': 2, 'name': 'name2'},
        {'id': 3, 'name': 'name3'},
        {'id': 4, 'name': 'name4'},
        {'id': 5, 'name': 'name5'},
        {'id': 6, 'name': 'name6'},
        {'id': 7, 'name': 'name7'},
        {'id': 8, 'name': 'name8'},
        {'id': 9, 'name': 'name9'},
        {'id': 10, 'name': 'name10'},
    ]
    assert find(collection, lambda x: x['id'] == 1) == {'id': 1, 'name': 'name1'}

# Generated at 2022-06-21 19:51:34.008341
# Unit test for function cond
def test_cond():
    f1 = lambda x: x >= 0
    f2 = lambda x: 'f2'
    f3 = lambda x: 'f3'
    f4 = lambda x: 'f4'

    result = cond([
        (f1, f2),
        (f1, f3),
        (f1, f4),
    ])(0)

    if result == 'f2':
        print('Test for function cond - OK')
    else:
        print('Test for function cond - Fail')



# Generated at 2022-06-21 19:51:37.736476
# Unit test for function memoize
def test_memoize():
    def my_function(arg: int) -> int:
        return arg * 2

    memoized_function = memoize(my_function)

    assert memoized_function(3) == 6
    assert memoized_function(3) == 6



# Generated at 2022-06-21 19:51:39.231300
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2

# Generated at 2022-06-21 19:51:41.753843
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda a: a % 2 == 1)([1, 2, 3, 4, 5]) == [1, 3, 5]



# Generated at 2022-06-21 19:51:42.445199
# Unit test for function increase
def test_increase():
    assert increase(10) == 11



# Generated at 2022-06-21 19:51:48.592420
# Unit test for function find
def test_find():
    assert find([{'a': 1}, {'a': 2}], lambda x: x['a'] == 1) == {'a': 1}
    assert find([{'a': 1}, {'a': 2}], lambda x: x['a'] == 3) is None



# Generated at 2022-06-21 19:51:51.930481
# Unit test for function find
def test_find():
    assert find(
        range(10),
        lambda x: x >= 5
    ) == 5

    assert find(
        range(10),
        lambda x: x == 10
    ) is None



# Generated at 2022-06-21 19:51:58.224255
# Unit test for function eq
def test_eq():
    """Function for test function eq."""
    assert(eq(1, 1) == True)
    assert(eq(1, 2) == False)
    assert(eq([1, 2], [1, 2]) == True)
    assert(eq([1, [1, 2]], [1, [2, 3]]) == False)
    assert(eq([1, [1, 2]], [1, [1, 2]]) == True)
    assert(eq([1, [1, 2]], [1, [1]]) == False)



# Generated at 2022-06-21 19:52:14.033062
# Unit test for function cond
def test_cond():
    """
    Test function cond.

    :returns: Nothing
    :rtype: Nothing
    """
    def is_1(number):
        return number == 1

    def is_2(number):
        return number == 2

    def is_3(number):
        return number == 3

    def return_1(number):
        return 1

    def return_2(number):
        return 2

    def return_3(number):
        return 3

    assert cond([(is_1, return_1), (is_2, return_2)])(1) == 1
    assert cond([(is_3, return_3), (is_2, return_2)])(1) == 2


# Generated at 2022-06-21 19:52:18.217807
# Unit test for function pipe
def test_pipe():
    assert pipe(1, identity, increase) == 2, 'pipe should be increased by 1'
    assert pipe(1, increase, identity) == 2, 'pipe should be increased by 1'


# Generated at 2022-06-21 19:52:20.284551
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity("value") == "value"



# Generated at 2022-06-21 19:52:21.732169
# Unit test for function eq
def test_eq():
    assert eq(1, 2) is False
    assert eq(1, 1) is True

# Generated at 2022-06-21 19:52:24.657498
# Unit test for function curry
def test_curry():
    curried_eq = curry(eq)
    assert curried_eq(3)(3)
    curried_eq1 = curried_eq(3)
    assert curried_eq1(3)



# Generated at 2022-06-21 19:52:25.638348
# Unit test for function identity
def test_identity():
    assert identity(7) == 7



# Generated at 2022-06-21 19:52:26.929254
# Unit test for function compose
def test_compose():
    assert compose(42, identity, increase) == 43



# Generated at 2022-06-21 19:52:28.654341
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity([]) == []
    assert identity('a') == 'a'


# Generated at 2022-06-21 19:52:39.300884
# Unit test for function increase
def test_increase():
    assert identity(1) == 1
    assert identity("asd") == "asd"
    assert eq(True, True)
    assert eq(False, False)
    assert not eq(True, False)
    assert not eq(False, True)
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_filter(eq(True), [True, False]) == [True]
    assert find([{'key': 'value'}], lambda x: x.get('key') == 'value') == {'key': 'value'}
    assert find([{'key': 'value1'}], lambda x: x.get('key') == 'value') is None
    assert memoize(identity)(1) == 1
    assert memoize(identity)(1) == 1


# Generated at 2022-06-21 19:52:41.719255
# Unit test for function pipe
def test_pipe():
    assert pipe(
        5,
        increase,
        increase,
        increase,
        increase,
        increase,
    ) == 10



# Generated at 2022-06-21 19:52:55.534873
# Unit test for function eq
def test_eq():
    assert eq(None, None) is True
    assert eq(None, False) is False
    assert eq(0, False) is False
    assert eq(1, True) is False
    assert eq(0, 0.0) is True



# Generated at 2022-06-21 19:52:58.833947
# Unit test for function increase
def test_increase():
    assert(increase(1) == 2)
    assert(increase(2) == 3)
    assert(increase(10) == 11)
    assert(increase(-1) == 0)


# Generated at 2022-06-21 19:53:08.309068
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda value: value > 0, lambda value: "great"),
        (lambda value: value == 0, lambda value: "equal"),
        (lambda value: value < 0, lambda value: "less")
    ])(3) == "great"
    assert cond([
        (lambda value: value > 0, lambda value: "great"),
        (lambda value: value == 0, lambda value: "equal"),
        (lambda value: value < 0, lambda value: "less")
    ])(0) == "equal"
    assert cond([
        (lambda value: value < 0, lambda value: "great"),
        (lambda value: value == 0, lambda value: "equal"),
        (lambda value: value > 0, lambda value: "less")
    ])(-1) == "great"



# Generated at 2022-06-21 19:53:18.851258
# Unit test for function cond
def test_cond():
    """
    Test cond function.
    Test parameters:
    - numbers = [1, 2, 3, 4],
    - condition_list = [
        (lambda x: x > 2, lambda x: x * 2),
        (lambda x: x % 2 == 0, lambda x: x - 1),
        (lambda x: True, lambda x: x + 2)
    ]

    :returns: cond function
    :rtype: Function
    """
    numbers = [1, 2, 3, 4]
    condition_list = [
        (lambda x: x > 2, lambda x: x * 2),
        (lambda x: x % 2 == 0, lambda x: x - 1),
        (lambda x: True, lambda x: x + 2)
    ]

    tested_function = cond(condition_list)

    assert tested_function

# Generated at 2022-06-21 19:53:22.709156
# Unit test for function memoize
def test_memoize():
    counter = 0
    def increment():
        nonlocal counter
        counter += 1
        return counter
    memoized_increment = memoize(increment)
    memoized_increment()
    memoized_increment()
    memoized_increment()
    assert counter == 3
    memoized_increment()
    assert counter == 3


# Generated at 2022-06-21 19:53:24.872942
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(1), [1, 2, 3, 4]) == [1]


# Generated at 2022-06-21 19:53:35.344896
# Unit test for function cond
def test_cond():
    eq_5_fn = eq(5)
    eq_6_fn = eq(6)
    eq_7_fn = eq(7)
    result_5_fn = identity
    result_6_fn = increase
    result_7_fn = increase

    print(cond([
        (eq_5_fn, result_5_fn),
        (eq_6_fn, result_6_fn),
        (eq_7_fn, result_7_fn),
    ])(5))  # 5
    print(cond([
        (eq_5_fn, result_5_fn),
        (eq_6_fn, result_6_fn),
        (eq_7_fn, result_7_fn),
    ])(6))  # 7

# Generated at 2022-06-21 19:53:42.923477
# Unit test for function cond
def test_cond():
    def is_even(number):
        return number % 2 == 0

    def is_not_divided_by_three(number):
        return number % 3 != 0

    def call_identity(argument):
        return identity(argument)

    def call_increase(argument):
        return increase(argument)

    def call_decrease(argument):
        return increase(-argument)

    new_function = cond([
        (is_even, call_identity),
        (is_not_divided_by_three, call_increase)
    ])

    assert new_function(2) == 2
    assert new_function(1) == 2
    assert new_function(3) == 4
    assert new_function(30) == 30

# Generated at 2022-06-21 19:53:45.775907
# Unit test for function find
def test_find():
    collection = [dict(key=1, name='a'), dict(key=2, name='b')]
    assert find(collection, lambda item: item['key'] == 2) == dict(key=2, name='b')
    assert find(collection, lambda item: item['key'] == 3) is None


# Generated at 2022-06-21 19:53:54.626912
# Unit test for function compose
def test_compose():
    assert compose(1, lambda x: x + 1, lambda x: x + 1) == 3
    assert compose(1, lambda x: x + 1, lambda x: x - 1) == 1
    assert compose(1, lambda x: x + 1, lambda x: x + 2) == 4
    assert compose(1, lambda x: x - 1, lambda x: x + 1) == 1
    assert compose(1, lambda x: x - 1, lambda x: x - 1) == -1
    assert compose(1, lambda x: x - 1, lambda x: x + 2) == 2



# Generated at 2022-06-21 19:54:10.966613
# Unit test for function curry
def test_curry():
    def sum(a, b, c):
        return a + b + c

    assert sum(1, 2, 3) == 6
    assert curry(sum)(1)(2)(3) == 6

    CURRIED_SUM = curry(sum)

    assert CURRIED_SUM(1)(2, 3) == 6
    assert CURRIED_SUM(1, 2)(3) == 6
    assert CURRIED_SUM(1, 2, 3) == 6



# Generated at 2022-06-21 19:54:13.130443
# Unit test for function curried_map
def test_curried_map():
    curried_map_of_increase = curried_map(increase)
    assert curried_map_of_increase([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-21 19:54:14.398222
# Unit test for function increase
def test_increase():
    assert increase(2) == 3


# Generated at 2022-06-21 19:54:15.907054
# Unit test for function pipe
def test_pipe():
    assert pipe(10, increase, increase) == 12

# Generated at 2022-06-21 19:54:19.098559
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y, z: (x, y, z))(10)(11)(12) == (10, 11, 12)


# Generated at 2022-06-21 19:54:21.595802
# Unit test for function curried_map
def test_curried_map():
    values = [1, 2, 3, 4, 5]
    actual = curried_map(increase)(values)
    assert actual == values



# Generated at 2022-06-21 19:54:23.678739
# Unit test for function find
def test_find():
    to_find = [1, 2, 3, 4]
    find_eq = find(to_find, eq(3))
    assert find_eq == 3



# Generated at 2022-06-21 19:54:26.408093
# Unit test for function memoize
def test_memoize():
    count = 0

    @memoize
    def unit(value):
        nonlocal count
        count += 1
        return value

    assert count == 0

    for i in range(5):
        assert unit(i) == i

    assert count == 5


test_memoize()

# Generated at 2022-06-21 19:54:31.067436
# Unit test for function eq
def test_eq():
    # assert eq(1, 2) == False
    # assert eq(2, 2) == True
    # assert eq(2, 3) == False
    assert curry(eq)(1)(eq)(2) == False
    assert curry(eq)(2)(eq)(2) == True
    assert curry(eq)(2)(eq)(3) == False



# Generated at 2022-06-21 19:54:41.961177
# Unit test for function cond
def test_cond():
    True_ = lambda _: True
    True_cond = cond(
        [(True_, identity)]
    )
    assert True_cond(False) == False

    False_ = lambda _: False
    True_1_cond = cond(
        [(False_, identity), (True_, identity)]
    )
    assert True_1_cond(False) == False
    assert True_1_cond(True) == True

    False_1_cond = cond(
        [(False_, identity), (False_, increase)]
    )
    assert False_1_cond(False) == False

    False_2_cond = cond(
        [(False_, identity), (False_, increase), (True_, identity)]
    )
    assert False_2_cond(False) == False
    assert False_2_cond(True) == True

# Generated at 2022-06-21 19:54:53.463429
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:55:00.520899
# Unit test for function curried_map
def test_curried_map():
    assert (curried_map(increase)([1, 2, 3, 4])) == [2, 3, 4, 5]
    curried_increase = curried_map(increase)
    assert (curried_increase([1, 2, 3, 4])) == [2, 3, 4, 5]
    assert (curried_increase([1, 2, 3, 4, 5])) == [2, 3, 4, 5, 6]



# Generated at 2022-06-21 19:55:03.997580
# Unit test for function curry
def test_curry():
    def foo(a, b, c):
        return a + b + c

    assert foo(1, 2, 3) == 6

    curried_foo = curry(foo)
    assert curried_foo(1)(2)(3) == 6

    assert curried_foo(1, 2)(3) == 6

# Generated at 2022-06-21 19:55:08.702015
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x % 2 == 0) == 2
    assert find([{'name': 'Bartosz', 'gender': 'male'},
                 {'name': 'Kasia', 'gender': 'female'}],
                lambda x: x['gender'] == 'male') == {'name': 'Bartosz', 'gender': 'male'}
    assert find([{'name': 'Bartosz', 'gender': 'male'},
                 {'name': 'Kasia', 'gender': 'female'}],
                lambda x: x['gender'] == 'not_existing') is None



# Generated at 2022-06-21 19:55:13.665253
# Unit test for function memoize
def test_memoize():
    def factorial(n):
        if n <= 1:
            return 1
        else:
            return n * factorial(n - 1)

    assert memoize(factorial)(5) == 120
    assert memoize(factorial)(5) == 120
    assert memoize(factorial)(10) == 3628800
    assert memoize(factorial)(10) == 3628800



# Generated at 2022-06-21 19:55:21.605329
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x ** 2, [1, 2, 3, 4]) == [1, 4, 9, 16]

    curried_map_mul_by_2 = curried_map(lambda x: x * 2)
    assert curried_map_mul_by_2([1, 2, 3, 4, 5]) == [2, 4, 6, 8, 10]
    assert curried_map_mul_by_2([1, 2, 3, 4, 5]) == [2, 4, 6, 8, 10]



# Generated at 2022-06-21 19:55:27.961859
# Unit test for function pipe
def test_pipe():
    from typing import List
    from operator import add, mul

    a = pipe(1, lambda x: x + 1, lambda y: y * y)
    print(a)
    assert a == 4, "Returned incorrect value, expected 4, got %s" % a

    b = pipe(1, lambda x: x + 1, lambda y: y * y, lambda z: z - 1)
    print(b)
    assert b == 3, "Returned incorrect value, expected 3, got %s" % b

    c = pipe([1, 2, 3], lambda x: [x[1], x[0], x[2]], lambda y: sum(y))
    print(c)
    assert c == 5, "Returned incorrect value, expected 5, got %s" % c


# Generated at 2022-06-21 19:55:28.836833
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-21 19:55:33.321361
# Unit test for function eq
def test_eq():
    # Default
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1, '1')
    # Through currying
    assert eq(1)(1)
    assert not eq(1)(2)
    assert not eq(1)('1')



# Generated at 2022-06-21 19:55:35.033306
# Unit test for function eq
def test_eq():
    assert eq(2, 2)
    assert not eq(2, 3)



# Generated at 2022-06-21 19:55:59.847370
# Unit test for function identity
def test_identity():
    print(identity(True))
    print(identity(False))
    print(identity(0))
    print(identity(1))
    print(identity(100))


# Generated at 2022-06-21 19:56:04.934088
# Unit test for function find
def test_find():
    assert identity(find(
        [1, 2, 3],
        lambda n: n == 2,
    )) == 2
    assert identity(find(
        [1, 2, 3],
        lambda n: n == 5,
    )) == None


# Generated at 2022-06-21 19:56:11.227496
# Unit test for function pipe
def test_pipe():
    assert pipe(1, lambda a: a + 1, lambda a: a + 1, lambda a: a + 1) == 4
    assert pipe(0, lambda a: a + 1, lambda a: a + 1, lambda a: a + 1) == 3
    assert pipe([1, 2, 3], tuple, set) == set((1, 2, 3))
    assert pipe(0, increase, increase, increase) == 3


# Generated at 2022-06-21 19:56:16.451380
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert curried_filter(lambda x: x % 2 == 0)(list(range(5))) == [0, 2, 4]
    assert curried_filter(lambda x: x % 2 == 0)([]) == []


# Generated at 2022-06-21 19:56:17.685686
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(2) == 3



# Generated at 2022-06-21 19:56:22.259582
# Unit test for function memoize
def test_memoize():
    from time import sleep

    counter = 0

    @memoize
    def test(arg):
        print("Computing")
        nonlocal counter
        counter += 1
        sleep(1)
        return arg

    assert test(5) == 5
    assert test(5) == 5
    assert counter == 1


if __name__ == '__main__':
    test_memoize()

# Generated at 2022-06-21 19:56:28.750026
# Unit test for function compose
def test_compose():
    # Input value
    value = 1
    # Functions to composition
    functions = [
        lambda x: x + 5,
        lambda x: x * 2,
        lambda x: x - 1,
    ]
    # Expected result
    result = 10
    # Perform compose functions
    compose_result = compose(value, *functions)
    # Check if result is equals expected value
    assert result == compose_result, "Compose result was not equal {}".format(result)



# Generated at 2022-06-21 19:56:31.200649
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, '1') == False
    assert eq(2)(2) == True



# Generated at 2022-06-21 19:56:34.365614
# Unit test for function curried_map
def test_curried_map():
    expected = [2, 3, 4]
    collection = [1, 2, 3]
    mapper = lambda value: value + 1
    result = curried_map(mapper)(collection)
    assert result == expected



# Generated at 2022-06-21 19:56:39.948654
# Unit test for function pipe
def test_pipe():
    def subtract(number):
        return number - 1

    def add(number):
        return number + 1

    assert pipe(2, subtract, add) == 3

    # Unit test for function cond
    assert cond([
        (lambda number: number == 2, identity),
        (lambda number: number == 1, increase),
    ])(1) == 2

    assert cond([
        (lambda number: number > 2, identity),
        (lambda number: number == 1, increase),
    ])(1) == 1


    # Unit test for function memoize
    from time import sleep
    from random import randint
    from datetime import datetime

    def expensive_function(number):
        sleep(randint(2, 3))
        return number + randint(1, 2)

    def time_gt(number1, number2):
        return