

# Generated at 2022-06-21 19:47:22.470111
# Unit test for function pipe
def test_pipe():
    value = pipe('1', lambda a: int(a), lambda a: a + 1)
    assert value == 2, 'pipe test'


# Generated at 2022-06-21 19:47:32.808658
# Unit test for function compose
def test_compose():
    assert compose(1, identity) == 1
    assert compose(0, identity, increase) == 1
    assert compose([1, 2, 3, 4], curried_filter(eq(3)), curried_map(increase)) == [4]
    assert compose(["a", "a", "b", "b", "b"], curried_filter(eq("b"))) == ["b", "b", "b"]
    assert compose(["a", "b", "c", "d"], curried_filter(eq("a")), curried_filter(eq("b"))) == []
    assert compose(["a", "b", "c", "d"], curried_map(increase), curried_map(increase)) == [3, 4, 5, 6]

# Generated at 2022-06-21 19:47:37.554451
# Unit test for function compose
def test_compose():
    assert compose(1, (lambda x: x + 1), (lambda x: x * 2)) == 4
    assert compose([1, 2, 3], lambda x: x[::-1]) == [3, 2, 1]


# Generated at 2022-06-21 19:47:40.626197
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity("1") == "1"



# Generated at 2022-06-21 19:47:43.285038
# Unit test for function curried_filter
def test_curried_filter():
    # Unit test for function curried_filter
    number = [1,2, 3, 4, 5, 6, 7, 8]
    number_mapped = curried_filter(lambda x: x % 2 == 0)(number)
    assert number_mapped == [2, 4, 6, 8]



# Generated at 2022-06-21 19:47:45.824694
# Unit test for function identity
def test_identity():
    print('test_identity')
    identity_test_val = 123
    identity_test_res = identity(identity_test_val)
    assert identity_test_res == identity_test_val
    print('test_identity: OK')



# Generated at 2022-06-21 19:47:49.787107
# Unit test for function compose
def test_compose():
    assert pipe('hello', lambda x: x + ' world', lambda x: x.capitalize()) == 'Hello world'
    assert pipe('hello', lambda x: x.capitalize(), lambda x: x + ' world') == 'Hello world'



# Generated at 2022-06-21 19:47:52.415368
# Unit test for function pipe
def test_pipe():
    assert pipe(1, lambda x: x + 1, lambda x: x + 2) == 4
    assert pipe(
        1,
        lambda x: x + 1,
        lambda x: x + 2,
        lambda x: x ** 2
    ) == 16



# Generated at 2022-06-21 19:47:53.775986
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-21 19:47:59.033423
# Unit test for function compose
def test_compose():
    assert (
        compose(increase, identity)(1) ==
        identity(increase(1))
    )
    assert (
        compose(identity, identity)(1) ==
        identity(identity(1))
    )



# Generated at 2022-06-21 19:48:05.242786
# Unit test for function compose
def test_compose():
    assert compose(4, increase, increase) == 6
    assert compose(4, increase, identity) == 5
    assert compose(10, lambda x: x * 2, lambda x: x + 4) == 28



# Generated at 2022-06-21 19:48:08.413196
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-21 19:48:11.647601
# Unit test for function pipe
def test_pipe():
    assert pipe(10, increase, identity) == 11
    assert pipe(0, lambda _: 1, identity, identity) == 1
    assert pipe('aa', lambda x: x + 'b', lambda x: x + 'c') == 'aabc'



# Generated at 2022-06-21 19:48:13.049255
# Unit test for function identity
def test_identity():
    assert identity("test_1") == "test_1"


# Generated at 2022-06-21 19:48:16.299476
# Unit test for function memoize
def test_memoize():
    f = memoize(identity)
    assert f("test") == "test"
    assert f("test") == "test"


# Generated at 2022-06-21 19:48:17.393549
# Unit test for function eq
def test_eq():
    assert eq(1, 1)



# Generated at 2022-06-21 19:48:20.732129
# Unit test for function pipe
def test_pipe():
    """
    Function for unit test of function pipe

    :returns: result of unit test
    :rtype: Int
    """
    assert pipe(1, increase, increase, increase) == 4

# Generated at 2022-06-21 19:48:26.736226
# Unit test for function cond
def test_cond():
    data = (
        ('number', lambda x: type(x) is int, lambda x: x * 2),
        ('string', lambda x: type(x) is str, lambda x: x * 3),
        ('object', lambda x: type(x) is object, lambda x: x * 4),
    )
    test_data = (
        (1, 2),
        ('ho', 'hohoho'),
        (object(), ''),
    )

    cond_fn = cond(data)

    for test_argument in test_data:
        assert cond_fn(test_argument[0]) == test_argument[1]



# Generated at 2022-06-21 19:48:29.884564
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 3) == 3
    assert find([1, 2, 3], lambda x: x > 3) == None



# Generated at 2022-06-21 19:48:32.139617
# Unit test for function compose
def test_compose():
    assert compose(
        2,
        lambda x: x + 1,
        lambda x: x * 2
    ) == 6



# Generated at 2022-06-21 19:48:41.020152
# Unit test for function curry
def test_curry():
    def add(a, b, c):
        return a + b + c

    assert add(1, 2, 3) == add(1, 2)(3)
    assert add(1, 2, 3) == add(1)(2, 3)
    assert add(1, 2, 3) == add(1)(2)(3)
    assert add(1, 2, 3) == curry(add)(1, 2, 3)
    assert add(1, 2, 3) == curry(add)(1, 2)(3)
    assert add(1, 2, 3) == curry(add)(1)(2, 3)
    assert add(1, 2, 3) == curry(add)(1)(2)(3)


# Generated at 2022-06-21 19:48:42.004455
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-21 19:48:42.953116
# Unit test for function compose
def test_compose():
    assert compose(1, square, increase) == 4
    assert compose(1, increase, square) == 4



# Generated at 2022-06-21 19:48:46.859740
# Unit test for function memoize
def test_memoize():
    memoized_increase = memoize(increase)
    assert memoized_increase(1) == 2
    assert memoized_increase(1) == 2
    assert memoized_increase(2) == 3
    assert memoized_increase(1) == 2
    assert memoized_increase(2) == 3



# Generated at 2022-06-21 19:48:57.237427
# Unit test for function curried_filter
def test_curried_filter():
    even_number1 = lambda x: x % 2 == 0
    number_greater_than_5 = lambda x: x > 5
    assert curried_filter(even_number1)([1, 2, 3, 4, 5, 6, 7, 8, 9]) == [2, 4, 6, 8]
    assert curried_filter(even_number1, [1, 2, 3, 4, 5, 6, 7, 8, 9]) == [2, 4, 6, 8]
    assert curried_filter(number_greater_than_5)([1, 2, 3, 4, 5, 6, 7, 8, 9]) == [6, 7, 8, 9]

# Generated at 2022-06-21 19:49:03.429363
# Unit test for function memoize
def test_memoize():
    def factorial(n):
        if(n <= 1):
            return 1
        else:
            return n * factorial(n - 1)

    def factorial_memoized(n):
        return memoize(factorial)(n)

    # Too big number will take a while
    assert factorial_memoized(100) == factorial_memoized(100)
    assert factorial_memoized(100) == factorial_memoized(100)


if __name__ == '__main__':
    test_memoize()

# Generated at 2022-06-21 19:49:04.420148
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:49:06.137534
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2)([1, 2, 3]) == [3]


# Generated at 2022-06-21 19:49:07.393277
# Unit test for function identity
def test_identity():
    assert identity(5) == 5
    assert identity("hello") != 5



# Generated at 2022-06-21 19:49:09.480573
# Unit test for function compose
def test_compose():
    assert compose(1, increase) == 2
    assert compose(1, identity, increase) == 2
    assert compose(1, identity, increase, identity, increase) == 3



# Generated at 2022-06-21 19:49:24.160126
# Unit test for function cond
def test_cond():
    """
    Test function cond

    :return:
    :rtype:
    """

    def is_even(arg):
        """
        Return true if argument is even, false otherwise.

        :param arg: Argument
        :type arg: Int
        :return: True if argument is even, false otherwise
        :rtype: Boolean
        """
        return arg % 2 == 0

    def double(arg):
        """
        Return argument multiplied by 2.

        :param arg: Argument
        :type arg: Int
        :return: argument multiplied by 2
        :rtype: Int
        """
        return arg * 2

    def triple(arg):
        """
        Return argument multiplied by 3.

        :param arg: Argument
        :type arg: Int
        :return: argument multiplied by 3
        :rtype: Int
        """


# Generated at 2022-06-21 19:49:27.507300
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_filter(increase, []) == []
    assert curried_filter(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-21 19:49:30.404987
# Unit test for function compose
def test_compose():
    result = compose(1, increase, increase)
    assert result == 3, "Error"


# Generated at 2022-06-21 19:49:37.058074
# Unit test for function cond
def test_cond():
    assert cond([(lambda x: x == True, lambda x: x),
                 (lambda x: x == False, lambda x: None)]) == True
    assert cond([(lambda x: x == True, lambda x: x),
                 (lambda x: x != "a", lambda x: None)]) == None


# Generated at 2022-06-21 19:49:40.413512
# Unit test for function curried_filter
def test_curried_filter():
    filter_even = curried_filter(lambda x: x % 2 == 0)

    filter_even_result = filter_even([1, 2, 3, 4, 5])
    assert filter_even_result == [2, 4]



# Generated at 2022-06-21 19:49:44.004797
# Unit test for function pipe
def test_pipe():
    def fn1(a: int) -> int:
        return a * 2

    def fn2(a: int) -> int:
        return a + 1

    def fn3(a: str) -> str:
        return a.capitalize()

    assert pipe(1, fn1, fn2, fn3, int) == 5



# Generated at 2022-06-21 19:49:47.204431
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2
    assert increase(2) == 3



# Generated at 2022-06-21 19:49:48.692936
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-21 19:49:50.798268
# Unit test for function identity
def test_identity():
    """
    >>> assert identity(1) == 1
    >>> assert identity('string') == 'string'
    """



# Generated at 2022-06-21 19:49:53.055448
# Unit test for function memoize
def test_memoize():
    def long_function(number):
        print('performing long calculation for', number)
        return -number

    long_function = memoize(long_function)
    print(long_function(10))
    print(long_function(100))
    print(long_function(10))
    print(long_function(100))



# Generated at 2022-06-21 19:49:57.870490
# Unit test for function cond
def test_cond():
    assert cond(
        (lambda _: True, lambda x: x+1)
    )(1) == 2



# Generated at 2022-06-21 19:50:02.868045
# Unit test for function find
def test_find():
    assert find([11, 13, 20, 33], eq(20)) == 20
    assert find([11, 13, 20, 33], eq(25)) is None
    assert find([11, 13, 20, 33], eq(30)) is None
    assert find([11, 13, 20, 33], eq(33)) == 33



# Generated at 2022-06-21 19:50:05.282067
# Unit test for function pipe
def test_pipe():
    assert pipe(
        1,
        increase,
        increase,
        increase,
        increase
    ) == 5



# Generated at 2022-06-21 19:50:10.436659
# Unit test for function compose
def test_compose():
    def inc(x: int) -> int:
        return x + 1

    def double(x: int) -> int:
        return x + x

    assert compose(2, inc, double) == (2 + 1) + (2 + 1)



# Generated at 2022-06-21 19:50:12.365369
# Unit test for function eq
def test_eq():
    assert eq(2, 3) is False
    assert eq(2, 2) is True



# Generated at 2022-06-21 19:50:15.492285
# Unit test for function compose
def test_compose():
    print(
        "Test compose",
        compose('hello', incr, identity),
        compose('hello', identity, incr),
    )



# Generated at 2022-06-21 19:50:20.119088
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(3))([1, 2, 3, 4, 5]) == ([3])
    assert curried_filter(eq(3), [1, 2, 3, 4, 5]) == ([3])
    assert curried_filter(eq(3), [])([1, 2, 3, 4, 5]) == ([3])



# Generated at 2022-06-21 19:50:20.960664
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(2) == 3

# Generated at 2022-06-21 19:50:32.213386
# Unit test for function cond
def test_cond():
    def is_string(value):
        return isinstance(value, str)

    def to_string(value):
        return str(value)

    def to_number(value):
        return int(value)

    def to_boolean(value):
        return bool(value)

    def to_list(value):
        return list(value)

    condition_list = [
        (is_string, identity),
        (lambda value: isinstance(value, int), to_string),
        (lambda value: isinstance(value, str), to_number),
        (lambda value: isinstance(value, bool), to_string),
        (lambda value: isinstance(value, (list, tuple)), to_list),
    ]

    result = cond(condition_list)('123')
    assert result == '123'

    result = cond

# Generated at 2022-06-21 19:50:42.017236
# Unit test for function pipe
def test_pipe():
    # Test variables
    test_data = [
        [1, 2, 3],
        [1, 2, 4]
    ]
    # Test numbers
    test_numbers = [1, 2, 3, 4]
    # Test pipes
    test_pipes = [
        pipe,
        compose
    ]


# Generated at 2022-06-21 19:50:48.251245
# Unit test for function increase
def test_increase():
    """
    Test for function increase.
    """
    assert increase(1) == 2



# Generated at 2022-06-21 19:50:52.000198
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda x: x == 10) is None



# Generated at 2022-06-21 19:51:00.479171
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda v: v == 'a', lambda v: v.upper()),
        (lambda v: v == 'b', lambda v: v.lower())
    ])('a') == 'A'
    assert cond([
        (lambda v: v == 'a', lambda v: v.upper()),
        (lambda v: v == 'b', lambda v: v.lower())
    ])('b') == 'b'
    assert cond([
        (lambda v: v == 'a', lambda v: v.upper()),
        (lambda v: v == 'b', lambda v: v.lower())
    ])('c') is None



# Generated at 2022-06-21 19:51:07.489239
# Unit test for function curry
def test_curry():
    identity_curried = curry(identity)
    assert identity(1) == identity_curried(1)
    assert identity('String') == identity_curried('String')

    increase_curried = curry(increase)
    assert increase(2) == increase_curried(2)
    assert increase_curried(3)(3) == 6



# Generated at 2022-06-21 19:51:09.991298
# Unit test for function pipe
def test_pipe():
    result = pipe(
        5,
        lambda v: v + 2,
        lambda v: v * 3
    )
    assert result == 21



# Generated at 2022-06-21 19:51:18.091694
# Unit test for function pipe
def test_pipe():
    math_fns = [
        math.pow,
        (lambda x: x - 1),
        (lambda x: x / 2),
        math.floor,
        (lambda x: x * 2),
        (lambda x: x + 1),
    ]

    assert pipe(
        2,
        *math_fns
    ) == math.pow(math.floor(((math.pow(2, 2) - 1) / 2) * 2 + 1), 2)

    # check if all functions were called
    assert pipe.__code__.co_argcount == 2



# Generated at 2022-06-21 19:51:29.023546
# Unit test for function cond
def test_cond():
    """
    Function to testing cond and curried_cond
    """
    def eq_value(value, expected):
        return eq(value, expected)

    def gt(value, expected):
        return value > expected

    def eq_value_and_gt(value, expected_value, expected_gt):
        return eq(value, expected_value) and value > expected_gt

    def f(value):
        return 2 * value

    def g(value):
        return 3 * value

    def h(value):
        return 4 * value

    assert cond([
        (eq_value, f),
        (gt, g),
        (lambda value: True, h)
    ])(1, 1, 1) == 2


# Generated at 2022-06-21 19:51:29.873891
# Unit test for function increase
def test_increase():
    assert increase(5) == 6



# Generated at 2022-06-21 19:51:34.733702
# Unit test for function find
def test_find():
    input_list = [0, 2, 4, 6, 8,  10, 12, 14, 16, 18]
    assert find(input_list, lambda x: x == 12) == 12
    assert find(input_list, lambda x: x == 20) is None


# Generated at 2022-06-21 19:51:38.494006
# Unit test for function eq
def test_eq():
    assert eq(4, 4)
    assert eq('hello', 'hello')
    assert eq([1, 2], [1, 2])
    assert not eq(4, 5)
    assert not eq([2, 3], [1, 2])



# Generated at 2022-06-21 19:51:47.737182
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False
    assert eq(1, '') is False
    assert eq(1, True) is False



# Generated at 2022-06-21 19:51:50.681216
# Unit test for function curried_map
def test_curried_map():
    collection = [1, 2, 3]
    map_result = curried_map(increase, collection)
    assert [2, 3, 4] == map_result



# Generated at 2022-06-21 19:51:58.249863
# Unit test for function curry
def test_curry():
    """
    If arguments count is greater function must return the function that takes the remaining arguments.
    If arguments count is equal function must return result of function.
    """
    # function that takes two arguments
    x = lambda a, b: a + b

    # currying of this function
    curried_x = curry(x)

    # actually curried_x is function that takes one argument and return the function that takes one argument
    assert curried_x(1) is not None
    assert callable(curried_x(1))

    # when both arguments is given, function x should return result
    assert curried_x(1)(1) == 2



# Generated at 2022-06-21 19:52:05.422282
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter([True, False])(eq(True)) == [True]
    assert curried_filter([1, 2, 3])(eq(1)) == [1]
    assert curried_filter([1, 2, 3])(eq(4)) == []
    assert curried_filter([1, 2, 3])(lambda x: x % 2 == 0) == [2]
    assert curried_filter([1, 2, 3])(lambda x: x > 2) == [3]

# Generated at 2022-06-21 19:52:07.065252
# Unit test for function increase
def test_increase():
    """
    Test for increase function
    """
    assert increase(1) == 2



# Generated at 2022-06-21 19:52:09.305865
# Unit test for function compose
def test_compose():
    function_compose = compose(increase, identity)
    assert function_compose(1) == 2
    assert function_compose(2) == 3


# Generated at 2022-06-21 19:52:11.102765
# Unit test for function increase
def test_increase():
    assert increase(42) == 43
    assert increase(0) == 1
    assert increase(-1) == 0


# Generated at 2022-06-21 19:52:11.822783
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-21 19:52:16.397463
# Unit test for function eq
def test_eq():
    assert eq(1, 2) == False
    assert eq(1, 1) == True
    assert eq(1, 1, 2) == False
    assert eq(1)(1) == True



# Generated at 2022-06-21 19:52:19.629419
# Unit test for function curried_filter
def test_curried_filter():
    curried_filter_ = curried_filter(lambda item: item % 2 == 0)
    assert curried_filter_([1, 2, 3, 4, 5]) == [2, 4]


# Generated at 2022-06-21 19:52:33.465396
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda item: item == 1, [1, 2, 3, 4]) == [1]
    assert curried_filter(lambda item: item == 1)([1, 2, 3, 4]) == [1]
    assert curried_filter(lambda item: item == 1)(([1, 2, 3, 4])) == [1]



# Generated at 2022-06-21 19:52:36.062202
# Unit test for function pipe
def test_pipe():
    assert pipe(1, identity, identity) == 1
    assert pipe(1, increase, increase) == 3
  

# Generated at 2022-06-21 19:52:38.193343
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-21 19:52:41.322290
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(1), [1, 2, 3]) == [1]
    assert curried_filter(lambda x: x > 2, [1, 2, 3]) == [3]


# Generated at 2022-06-21 19:52:46.112166
# Unit test for function find
def test_find():
    print("test_find")
    is_even = lambda x: x % 2 == 0

    assert find([], is_even) is None
    assert find([1], is_even) is None
    assert find([1, 2], is_even) == 2
    assert find([1, 3], is_even) is None



# Generated at 2022-06-21 19:52:47.717479
# Unit test for function identity
def test_identity():
    assert identity(1) == 1


# Generated at 2022-06-21 19:52:51.575092
# Unit test for function eq
def test_eq():
    assert(eq(1, 1) == True)
    assert(eq(1, 2) == False)
    assert(eq(1)(1) == True)
    assert(eq(1)(2) == False)



# Generated at 2022-06-21 19:52:53.222731
# Unit test for function identity
def test_identity():
    assert identity(10) == 10, "Function identity must return first argument!"


# Generated at 2022-06-21 19:52:58.505130
# Unit test for function eq
def test_eq():
    assert eq(identity)(1)(1) == True
    assert eq(identity)(1)(2) == False
    assert eq(identity)(1)(1)(1)(1)(1)(1)(1) == True
    assert eq(identity)(1)(1)(1)(1)(1)(1)(2) == False


# Generated at 2022-06-21 19:53:04.663463
# Unit test for function curry
def test_curry():
    @curry
    def add(x, y):
        return x + y

    assert add(1)(2) == 3
    assert add(1, 2) == 3

    @curry
    def add3(x, y, z):
        return x + y + z

    assert add3(1)(2)(3) == add3(1)(2, 3) == add3(1, 2)(3) == add3(1, 2, 3) == 6



# Generated at 2022-06-21 19:53:15.290147
# Unit test for function eq
def test_eq():
    assert True == eq(1, 1)


# Generated at 2022-06-21 19:53:17.998416
# Unit test for function eq
def test_eq():
    value = eq(1, 1)
    assert value

    value = eq(1, 0)
    assert value != True



# Generated at 2022-06-21 19:53:23.121656
# Unit test for function curried_filter
def test_curried_filter():
    list_of_numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    print(curried_filter(lambda x: x % 2 == 0, list_of_numbers))
    print(curried_filter(lambda x: x > 5)(list_of_numbers))
    named_lambda = curried_filter(lambda x: x % 2 == 0)
    print(named_lambda(list_of_numbers))



# Generated at 2022-06-21 19:53:32.444528
# Unit test for function cond
def test_cond():
    def empty(collection):
        return collection == []

    def head(collection):
        return collection[0]

    def tail(collection):
        return collection[1:]

    def first(collection):
        return collection[0]

    get_data = cond([
        (empty, lambda: []),
        (lambda _: True, lambda collection: [head(collection)] + tail(collection))
    ])

    data = get_data([1, 2, 3, 4])

    assert first(data) == 1, f'Actual: {first(data)}, Expected: {1}'
    # assert first(data) == 1



# Generated at 2022-06-21 19:53:41.849055
# Unit test for function memoize
def test_memoize():
    global_counter = 0

    @memoize
    def add_one(argument):
        global global_counter
        global_counter = global_counter + 1
        return argument + 1

    assert add_one(1) == 2
    assert add_one(1) == 2
    assert add_one(2) == 3
    assert add_one(2) == 3
    assert global_counter == 2

    global_counter = 0

    @memoize(eq)
    def add_one(argument):
        global global_counter
        global_counter = global_counter + 1
        return argument + 1

    assert add_one(1) == 2
    assert add_one(1) == 2
    assert add_one(2) == 3
    assert add_one(2) == 3
    assert global_counter == 2


#

# Generated at 2022-06-21 19:53:44.059716
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)

# Generated at 2022-06-21 19:53:46.254051
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 0) is False


# Unit test of function curried_map

# Generated at 2022-06-21 19:53:47.266405
# Unit test for function increase
def test_increase():
    assert increase(5) == 6


# Generated at 2022-06-21 19:53:51.503192
# Unit test for function compose
def test_compose():
    if compose(
        10,
        lambda value: value / 2,
        lambda value: value * 2
    ) == 20:
        print(
            "Function compose works correctly"
        )



# Generated at 2022-06-21 19:53:59.560962
# Unit test for function curry
def test_curry():
    """
    To test curry function
    """

    def add(a, b):
        return a + b

    assert add(2, 7) == 9

    assert curry(add)(2)(7) == 9
    assert curry(add, 2)(7) == 9
    assert curry(add, 2)(7) == 9
    assert curry(add, 2)(2) == 4
    assert curry(add, 2, 2) == 4
    assert curry(add, 3)(2) == 5

    @curry
    def add_1(a, b):
        return a + b

    assert add_1(2)(7) == 9
    assert add_1(2, 2) == 4
    assert add_1(3)(2) == 5



# Generated at 2022-06-21 19:54:23.456671
# Unit test for function curried_filter
def test_curried_filter():
    filter_odds = curried_filter(lambda x: x % 2)

    assert filter_odds(
        [1, 2, 3, 4, 5, 6]
    ) == [1, 3, 5]
    assert filter_odds(
        [1, 3, 5, 7, 9]
    ) == [1, 3, 5, 7, 9]
    assert filter_odds(
        [10, 20, 30, 40, 50, 60]
    ) == []


# Generated at 2022-06-21 19:54:26.741716
# Unit test for function cond
def test_cond():
    """Test function cond."""
    func = cond([
        (lambda val: val > 0, increase),
        (lambda val: val == 0, identity)
    ])

    assert func(1) == 2
    assert func(0) == 0
    assert func(-1) is None



# Generated at 2022-06-21 19:54:27.461281
# Unit test for function identity
def test_identity():
    assert identity(1) == 1


# Generated at 2022-06-21 19:54:36.774669
# Unit test for function find
def test_find():
    assert find([], lambda x: True) is None, 'example 1'
    assert find([1,2,3], lambda x: x % 2 == 0) == 2, 'example 2'
    assert find(['a', 'b', 'c'], lambda x: x == 'a') == 'a', 'example 3'
    assert find([], lambda x: False) is None, 'example 4'
    assert find([1,2,3], lambda x: False) is None, 'example 5'
    assert find(['a', 'b', 'c'], lambda x: x == 'd') is None, 'example 6'
    assert find([True, True, False], lambda x: True) == True, 'example 7'



# Generated at 2022-06-21 19:54:42.942309
# Unit test for function curried_filter
def test_curried_filter():
    values = [1, 2, 3, 4, 5, 6]
    assert curried_filter(lambda x: x % 2 == 0)(values) == \
        [2, 4, 6]
    assert curried_filter(lambda x: x % 3 == 0, values) == [3, 6]
    assert curried_filter(lambda x: x % 4 == 0, values) == [4]



# Generated at 2022-06-21 19:54:44.491972
# Unit test for function curried_map
def test_curried_map():
    assert (curried_map(value=0, collection=0) == 0)



# Generated at 2022-06-21 19:54:47.373788
# Unit test for function compose
def test_compose():
    assert(compose(1, lambda x: x + 1, lambda x: x * 2) == 4), \
        "compose function return wrong result"
    assert(compose(1) == 1), "compose function return wrong result"



# Generated at 2022-06-21 19:54:48.200496
# Unit test for function increase
def test_increase():
    assert increase(5) == 6



# Generated at 2022-06-21 19:54:51.086242
# Unit test for function curried_filter
def test_curried_filter():
    assert [0, 2, 4] == list(curried_filter(lambda x: x % 2 == 0, range(5)))



# Generated at 2022-06-21 19:54:53.343906
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1, '1')



# Generated at 2022-06-21 19:55:33.458454
# Unit test for function identity
def test_identity():
    assert identity(1) == 1


# Generated at 2022-06-21 19:55:36.446536
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(-1) == 0
    assert increase(10) == 11
    print('Function increase work!')



# Generated at 2022-06-21 19:55:41.736385
# Unit test for function memoize
def test_memoize():
    def add(x):
        time.sleep(1)
        return x + 1

    memoized_add = memoize(add)
    print('Result of memorized function', memoized_add(1))
    print('Result of memorized function', memoized_add(1))
    print('Result of memorized function', memoized_add(1))



# Generated at 2022-06-21 19:55:43.112262
# Unit test for function increase
def test_increase():
    """test increase function"""
    assert increase(0) == 1, "should be equal"


# Generated at 2022-06-21 19:55:45.228486
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 2)([1, 2, 3]) == [3, 4, 5]
    assert curried_map(lambda x: x + 2, [1, 2, 3]) == [3, 4, 5]



# Generated at 2022-06-21 19:55:46.054560
# Unit test for function increase
def test_increase():
    assert increase(1) == 2, 'should increase by 1'



# Generated at 2022-06-21 19:55:56.603943
# Unit test for function memoize

# Generated at 2022-06-21 19:55:58.732251
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert eq('test', 'test')
    assert not eq('fail', 'test')


test_eq()



# Generated at 2022-06-21 19:56:11.568292
# Unit test for function pipe

# Generated at 2022-06-21 19:56:19.175501
# Unit test for function cond
def test_cond():
    def lt_2(x): return x < 2

    def gt_5(x): return x > 5

    def lt_1(x): return x < 1

    def ge_2(x): return x >= 2

    def execute(x): return x * x

    def execute1(x): return x + x

    assert cond([(lt_2, execute), (gt_5, execute), (lt_1, execute)]) == execute

    assert cond([(lt_2, execute), (gt_5, execute), (ge_2, execute1)]) == execute1
