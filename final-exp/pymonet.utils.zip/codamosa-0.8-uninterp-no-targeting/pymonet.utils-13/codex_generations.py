

# Generated at 2022-06-21 19:47:25.122232
# Unit test for function curried_map
def test_curried_map():
    a = [1, 2, 3, 4, 5]
    f = map(lambda x: x + 1)
    assert curried_map(lambda x: x + 1, a) == list(f(a))


# Generated at 2022-06-21 19:47:31.815465
# Unit test for function find
def test_find():
    collection = [
        {
            "name": "Alice",
            "job": "CEO"
        },
        {
            "name": "Bob",
            "job": "Janitor"
        },
        {
            "name": "Charles",
            "job": "CEO"
        }
    ]

    assert find(collection, lambda item: item['job'] == 'Janitor') is collection[1]
    assert find(collection, lambda item: item['name'] == 'Charles') is collection[2]
    assert find(collection, lambda item: item['name'] == 'caesar') is None



# Generated at 2022-06-21 19:47:33.878627
# Unit test for function curried_map
def test_curried_map():
    collection_to_test = [1, 2, 3, 4]
    result = curried_map(increase)(collection_to_test)
    assert result == [2, 3, 4, 5]


# Generated at 2022-06-21 19:47:37.757072
# Unit test for function curried_map
def test_curried_map():
    x = list(range(10))
    y = curried_map(lambda x: x + 1)(x)
    assert y == list(range(1, 11))


# Generated at 2022-06-21 19:47:48.296426
# Unit test for function curried_filter
def test_curried_filter():
    result = curried_filter(lambda x: x == 3, [1, 2, 3, 4, 5, 6])([1, 2, 3, 4, 5, 6])
    expected_result = [3, 3]
    assert expected_result == result, f"Expected: {expected_result}, actual: {result}"

    result = curried_filter(lambda x: x == 3)([1, 2, 3, 4, 5, 6], [1, 2, 3, 4, 5, 6])
    expected_result = [3, 3]
    assert expected_result == result, f"Expected: {expected_result}, actual: {result}"

    result = curried_filter(lambda x: x == 3)([1, 2, 3, 4, 5, 6])([1, 2, 3, 4, 5, 6])
   

# Generated at 2022-06-21 19:47:53.583700
# Unit test for function compose
def test_compose():
    """
    >>> f = compose(3, increase, increase, increase)
    >>> f
    6
    """


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 19:47:55.839521
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-21 19:48:03.647801
# Unit test for function curry
def test_curry():
    """
    Function test for function currying.
    """
    def cal(first, second, third):
        return first + second + third

    assert cal(1, 2, 3) == 6

    cal_curry = curry(cal)

    assert cal_curry(1)(2)(3) == 6
    assert cal_curry(1, 2)(3) == 6
    assert cal_curry(1)(2, 3) == 6
    assert cal_curry(1, 2, 3) == 6

    print("Test curry passed")



# Generated at 2022-06-21 19:48:08.793439
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq(eq(1)(1))(True) == True
    assert eq(eq(1)(1))(False) == False
    assert eq(2)(2)(True) == True
    assert eq(2)(2)(False) == False
    assert eq(2)(1)(True) == False
    assert eq(2)(1)(False) == True



# Generated at 2022-06-21 19:48:13.877020
# Unit test for function increase
def test_increase():
    test_value1 = 1
    test_value2 = 2
    test_value3 = 0
    assert increase(test_value1) == 2, \
        "The 'increase' function returns wrong value. " + \
        "Argument 'test_value1' should be equal to " + \
        str(test_value1) + " and return value should be equal to " +\
        str(test_value2) + \
        "."
    assert increase(test_value1) == 0, \
        "The 'increase' function returns wrong value. " + \
        "Argument 'test_value1' should be equal to " + \
        str(test_value1) + " and return value should be equal to " +\
        str(test_value3) + \
        "."

# Generated at 2022-06-21 19:48:19.101079
# Unit test for function find
def test_find():
    assert find([1, 2], lambda x: x == 2) == 2
    assert find([1, 2], lambda x: x == 3) is None



# Generated at 2022-06-21 19:48:24.061562
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x == 0, lambda: 'zero'),
        (lambda x: x % 2 == 0, lambda x: 'even'),
        (lambda x: True, lambda x: 'odd')
    ])(1) == 'odd'


if __name__ == '__main__':
    test_cond()

# Generated at 2022-06-21 19:48:28.145585
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-21 19:48:34.525529
# Unit test for function memoize
def test_memoize():
    def function_with_side_effect():
        function_with_side_effect.counter += 1
        return function_with_side_effect.counter

    function_with_side_effect.counter = 0

    mem_function_with_side_effect = memoize(function_with_side_effect)

    assert mem_function_with_side_effect(1) == 1
    assert mem_function_with_side_effect(1) == 1



# Generated at 2022-06-21 19:48:36.249035
# Unit test for function memoize
def test_memoize():
    assert  memoize(increase)(0) == 1
    assert  memoize(increase)(0) == 1

# Generated at 2022-06-21 19:48:45.868367
# Unit test for function pipe
def test_pipe():
    from nose.tools import assert_equal

    def echo_x(x):
        return x

    def echo_xx(x):
        return echo_x(echo_x(x))

    def echo_xxx(x):
        return echo_xx(echo_x(x))

    assert_equal(pipe(1, [echo_x, echo_xx, echo_xxx]), 1)
    assert_equal(pipe(2, [echo_x, echo_xx, echo_xxx]), 2)
    assert_equal(pipe(3, [echo_x, echo_xx, echo_xxx]), 3)

    assert_equal(pipe([1], curried_map(echo_x)), [1])
    assert_equal(pipe([2], curried_map(echo_x)), [2])


# Generated at 2022-06-21 19:48:50.596315
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-21 19:48:53.427334
# Unit test for function curried_map
def test_curried_map():
    assert curried_map([1, 2, 3, 4], increase)([1, 2, 3, 4]) == [2, 3, 4, 5]



# Generated at 2022-06-21 19:48:57.221125
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-21 19:49:03.216804
# Unit test for function cond
def test_cond():
    def execute_value(value):
        return value

    def is_true_value(value):
        return value == True

    def is_false_value(value):
        return value == False

    get_true_or_false = cond([
        (is_true_value, execute_value),
        (is_false_value, execute_value),
    ])

    assert get_true_or_false(True) == True
    assert get_true_or_false(False) == False


# Generated at 2022-06-21 19:49:08.499831
# Unit test for function curried_filter
def test_curried_filter():
    def is_even(x):
        return x % 2 == 0

    numbers = [1, 2, 3, 4, 5]
    result = curried_filter(is_even, numbers)
    assert result == [2, 4]



# Generated at 2022-06-21 19:49:13.521546
# Unit test for function find
def test_find():
    assert None == find([], lambda x: x == 42)
    assert None == find([1, 2, 3, 4, 5], lambda x: x == 42)
    assert 1 == find([1, 2, 3, 4, 5], lambda x: x == 1)



# Generated at 2022-06-21 19:49:15.342935
# Unit test for function identity
def test_identity():
    assert identity(2) == 2
    assert identity("asd") == "asd"
    assert identity("asd") != "as"



# Generated at 2022-06-21 19:49:26.571148
# Unit test for function curried_map
def test_curried_map():
    """
    Test if curried_map works correctly
    """

    # create function increase to increase list element
    increase_elem = lambda x: x + 1
    # create a list of elements to increase
    list_to_increase = [1, 2, 3, 4, 5]
    # call curried_map to map list of items
    increased_map_num = curried_map(increase_elem, list_to_increase)
    # check if map returned expected results
    assert increased_map_num == [2, 3, 4, 5, 6]
    # call curried_map with one argument
    partially_curried_map = curried_map(increase_elem)
    # call curried_map with second argument

# Generated at 2022-06-21 19:49:35.705857
# Unit test for function memoize
def test_memoize():
    def concat_str(a: str, b: str):
        return a + b

    memoized_concat_str = memoize(concat_str)
    assert memoized_concat_str('a', 'b') == 'ab'
    assert memoized_concat_str('a', 'b') == 'ab'

    def fib(x):
        if x <= 0:
            return 0
        if x == 1:
            return 1
        return fib(x - 1) + fib(x - 2)

    fib = memoize(fib)
    assert fib(2) == 1
    assert fib(3) == 2
    assert fib(3) == 2

# Generated at 2022-06-21 19:49:39.047264
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False
    assert eq('1', 1) is False
    assert eq('1', '1') is True


# Generated at 2022-06-21 19:49:41.377563
# Unit test for function memoize
def test_memoize():
    @memoize
    def f(x):
        return x + 1

    assert f(0) == 1
    assert f(0) == 1



# Generated at 2022-06-21 19:49:51.618728
# Unit test for function curried_filter
def test_curried_filter():
    """
    >>> curried_filter(lambda i: i % 2 == 0, [1, 2, 3, 4])
    [2, 4]
    >>> curried_filter(lambda i: i % 2 == 0)([1, 2, 3, 4])
    [2, 4]
    >>> curried_filter(lambda i: i % 2 == 0, range(10))
    [0, 2, 4, 6, 8]
    >>> curried_filter(lambda i: i % 2 == 0)(range(10))
    [0, 2, 4, 6, 8]
    """
    return None



# Generated at 2022-06-21 19:49:53.450478
# Unit test for function pipe
def test_pipe():
    """
    Unit test for function pipe
    """
    assert pipe(8, increase, lambda x: x*5) == 45

# Generated at 2022-06-21 19:49:54.699318
# Unit test for function compose
def test_compose():
    assert compose(3, increase, increase) == 5



# Generated at 2022-06-21 19:50:09.940876
# Unit test for function cond
def test_cond():
    def flip(value):
        return not value

    def identity(value):
        return value

    def concat():
        return 'concat'

    def concat1():
        return 'concat1'

    def concat2():
        return 'concat2'

    def concat3():
        return 'concat3'

    test = cond([
        (lambda value: value is True, concat),
        (lambda value: value is False, concat1),
        (lambda value: value == 'concat1', concat2),
        (lambda value: value == 'concat2', concat3)
    ])

    assert test(True) == 'concat'
    assert test(False) == 'concat1'
    assert test('concat1') == 'concat2'
    assert test('concat2')

# Generated at 2022-06-21 19:50:10.943796
# Unit test for function increase
def test_increase():
    assert increase(3) == 4



# Generated at 2022-06-21 19:50:16.147779
# Unit test for function memoize
def test_memoize():
    import time

    @memoize
    def memoized_fn(argument):
        time.sleep(1)
        return argument + 10

    start = time.time()
    result = memoized_fn(10)
    assert result == 20
    assert time.time() - start > 1

    start = time.time()
    result = memoized_fn(10)
    assert result == 20
    assert time.time() - start < 1



# Generated at 2022-06-21 19:50:18.832761
# Unit test for function curried_map
def test_curried_map():
    map_reducer = curried_map(lambda x: x + 1)
    assert map_reducer([1, 2, 3, 5]) == [2, 3, 4, 6]



# Generated at 2022-06-21 19:50:23.453831
# Unit test for function curried_map
def test_curried_map():
    """
    function curried_map test

    :returns: result of curried_map and assert
    :rtype: None
    """
    def double(value):
        return value * 2

    assert curried_map(double, [1, 2, 3]) == [2, 4, 6]



# Generated at 2022-06-21 19:50:31.263692
# Unit test for function eq
def test_eq():
    assert eq(2, 2)
    assert not eq("hello", "hella")
    assert eq("hello", "hello")
    assert eq("hello", compose(str.upper, compose(str.lower, identity("HELLO"))))
    assert not eq("hello", identity("hell0"))
    assert eq(2, increase(1))
    function_eq = curry(eq, 2)
    assert function_eq(2, 2)
    assert not function_eq(1, 2)


# Generated at 2022-06-21 19:50:36.162969
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq([1, 2], [1, 2])
    assert not eq([1, 2], [1, 3])
    assert eq({1: 1}, {1: 1})
    assert not eq({1: 1}, {1: 2})



# Generated at 2022-06-21 19:50:38.382392
# Unit test for function curried_filter
def test_curried_filter():
    even = curried_filter(lambda x: x % 2 == 0)
    assert even(range(5)) == [0, 2, 4]



# Generated at 2022-06-21 19:50:41.972208
# Unit test for function cond
def test_cond():
    print(
        cond([
            (lambda x: x == '1', lambda _: 'one'),
            (lambda x: x == '2', lambda _: 'two'),
            (lambda x: x == '3', lambda _: 'three')
        ])('2')
    )



# Generated at 2022-06-21 19:50:46.107622
# Unit test for function cond
def test_cond():
    f = cond([
        (lambda x: x > 0, increase),
        (lambda x: x == 0, identity)
    ])

    assert f(2) == 3
    assert f(0) == 0



# Generated at 2022-06-21 19:50:56.312648
# Unit test for function cond
def test_cond():
    def test_eq(a, b):
        return a == b

    def condition_function(a):
        return True

    def execute_function(a):
        return 'execute_function'

    condition_list = [
        (test_eq, condition_function),
        (test_eq, condition_function),
    ]


# Generated at 2022-06-21 19:50:59.490186
# Unit test for function compose
def test_compose():
    """
    Test compose function.

    :returns: None
    :rtype: _
    """
    def double(value):
        return value * 2

    assert compose(1, double, increase) == 4, \
        'Composition of increasing and doubling function is not equal to 4'

# Generated at 2022-06-21 19:51:03.142686
# Unit test for function curried_map
def test_curried_map():
    assert (curried_map(increase)([1, 2, 3, 4]) == [2, 3, 4, 5])


# Generated at 2022-06-21 19:51:04.170986
# Unit test for function pipe
def test_pipe():
    assert pipe(True, identity, increase) == 2

# Generated at 2022-06-21 19:51:07.752675
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 3]
    filterer = lambda value: value % 2 == 0
    assert curried_filter(filterer)(collection) == [2]


# Generated at 2022-06-21 19:51:10.286837
# Unit test for function compose
def test_compose():
    assert compose(1, lambda x: x + 1, lambda x: x * 2) == 4
    assert compose(4, increase, increase) == 6


# Generated at 2022-06-21 19:51:11.951389
# Unit test for function curried_map
def test_curried_map():
    assert [3, 4, 5] == curried_map(increase, [2, 3, 4])

# Generated at 2022-06-21 19:51:14.509538
# Unit test for function compose
def test_compose():
    assert compose(2, increase, increase) == 4
    assert compose(10, lambda x: x + 1, lambda x: x * 2) == 22



# Generated at 2022-06-21 19:51:18.630470
# Unit test for function cond
def test_cond():
    assert cond([(lambda x: x == 1, identity), (lambda x: x == 2, increase)])(1) == 1
    assert cond([(lambda x: x == 1, identity), (lambda x: x == 2, increase)])(2) == 3



# Generated at 2022-06-21 19:51:29.516384
# Unit test for function find
def test_find():
    collection = [
        {'id': 1},
        {'id': 2},
        {'id': 3},
        {'id': 4},
        {'id': 5}
        ]
    result = find(collection, lambda item: item['id'] == 1)
    assert result == {'id': 1}
    result = find(collection, lambda item: item['id'] == 2)
    assert result == {'id': 2}
    result = find(collection, lambda item: item['id'] == 3)
    assert result == {'id': 3}
    result = find(collection, lambda item: item['id'] == 4)
    assert result == {'id': 4}
    result = find(collection, lambda item: item['id'] == 5)
    assert result == {'id': 5}



# Generated at 2022-06-21 19:51:35.335377
# Unit test for function curried_filter
def test_curried_filter():
    filtered_list = curried_filter(lambda x: x > 0, [1, 2, 3, 4, 5])

    assert filtered_list == [1, 2, 3, 4, 5]



# Generated at 2022-06-21 19:51:39.126893
# Unit test for function curried_filter
def test_curried_filter():
    is_even = lambda x: x % 2 == 0
    curried_filter_even = curried_filter(is_even)

    assert [2, 4] == curried_filter_even([1, 2, 3, 4])



# Generated at 2022-06-21 19:51:41.669223
# Unit test for function pipe
def test_pipe():
    assert pipe(1, identity, increase) == 2
    assert pipe(1, increase, increase) == 3

    assert pipe('a', identity, identity) == 'a'



# Generated at 2022-06-21 19:51:44.273702
# Unit test for function compose
def test_compose():
    pipe_result = pipe(1, increase, increase, lambda x: x * 2)
    assert pipe_result == 6
    compose_result = compose(1, lambda x: x * 2, increase, increase)
    assert compose_result == 6



# Generated at 2022-06-21 19:51:53.023389
# Unit test for function curried_filter
def test_curried_filter():
    list_of_numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    # first way of using curried_filter
    number_filter = curried_filter(lambda number: number > 5)
    assert number_filter(list_of_numbers) == [6, 7, 8, 9, 10]
    # second way of using curried_filter
    number_filter = curried_filter(lambda number: number > 7)
    assert number_filter(list_of_numbers) == [8, 9, 10]


# Generated at 2022-06-21 19:51:56.056383
# Unit test for function memoize
def test_memoize():
    fn = lambda x: x + random.randint(0, 10)
    mem = memoize(fn)
    result = mem(1)
    assert mem(1) == result
    assert fn(1) == result

# Generated at 2022-06-21 19:52:07.238859
# Unit test for function curried_filter
def test_curried_filter():
    filter_greater_than_2 = curried_filter(lambda x: x > 2)
    assert filter_greater_than_2([0, 1, 2, 3, 4]) == [3, 4]

    filter_greater_than_2 = curried_filter(lambda x: x > 2, [0, 1, 2, 3, 4])
    assert filter_greater_than_2 == [3, 4]

    filter_greater_than_2 = curried_filter(lambda x: x > 2)
    assert filter_greater_than_2([1, 2, 3, 4]) == [3, 4]

    filter_greater_than_2 = curried_filter(lambda x: x > 2, [1, 2, 3, 4])
    assert filter_greater_than_2 == [3, 4]

# Generated at 2022-06-21 19:52:14.068409
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 3, 4, 5, 6, 7, 8]
    even = curried_filter(lambda x: x % 2 == 0)
    assert even(collection) == [2, 4, 6, 8]
    assert curried_filter(lambda x: x % 2 == 0, collection) == [2, 4, 6, 8]
    assert curried_filter(lambda x: x > 2 and x < 7, collection) == [3, 4, 5, 6]
    assert curried_filter(lambda x: x < 3)(collection) == [1, 2]

    # Unit test for function curried_map
    def test_curried_map():
        collection = [1, 2, 3, 4, 5, 6, 7, 8]
        x2 = curried_map(lambda x: x * 2)
       

# Generated at 2022-06-21 19:52:17.224196
# Unit test for function curry
def test_curry():
    assert increase(1) == 2
    assert curry(increase)(1) == 2



# Generated at 2022-06-21 19:52:19.584026
# Unit test for function find
def test_find():
    assert (find([1, 2, 3, 4, 5], lambda x: x % 2 == 0) == 2)



# Generated at 2022-06-21 19:52:25.483097
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x % 2 == 0) == 2
    assert find([1, 2, 3, 4, 5], lambda x: x < 0) is None



# Generated at 2022-06-21 19:52:27.901001
# Unit test for function find
def test_find():
    """
    Test for function find
    """
    assert find([2, 4, 6, 8], eq(4)) == 4
    assert find([2, 4, 6, 8], eq(3)) is None



# Generated at 2022-06-21 19:52:30.278528
# Unit test for function find
def test_find():
    collection = [1, 2, 3]
    assert find(collection, lambda item: item == 2) == 2
    assert find(collection, lambda item: item == 5) is None



# Generated at 2022-06-21 19:52:33.167711
# Unit test for function curry
def test_curry():
    assert lambda a, b: a + b(1) == curry(lambda a, b: a + b(1), 2)



# Generated at 2022-06-21 19:52:36.520226
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x * y)(3)(4) == 12
    assert curry(lambda x, y, z: x * y * z)(3)(4)(5) == 60



# Generated at 2022-06-21 19:52:40.516934
# Unit test for function curried_map
def test_curried_map():
    data = [1, 2, 3]
    assert curried_map(increase)(data) == [2, 3, 4]
    assert curried_map(increase, data) == [2, 3, 4]


# Generated at 2022-06-21 19:52:42.058127
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(21) == 22



# Generated at 2022-06-21 19:52:43.969576
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False



# Generated at 2022-06-21 19:52:49.298723
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 3, 4, 5]
    print('collection =', collection)
    print('curried_filter(eq(3), collection) =', curried_filter(eq(3), collection))
    print('curried_filter(eq(2), collection) =', curried_filter(eq(2), collection))
    print('curried_filter(eq(1), collection) =', curried_filter(eq(1), collection))
    print('curried_filter(eq(0), collection) =', curried_filter(eq(0), collection))



# Generated at 2022-06-21 19:52:58.834768
# Unit test for function curried_filter
def test_curried_filter():
    collection = [
        {'a': 1},
        {'a': 2},
        {'a': 3},
        {'a': 4},
        {'a': 2},
    ]

    assert [{'a': 1}, {'a': 2}, {'a': 2}] == curried_filter(eq(1), collection)
    assert [{'a': 2}, {'a': 2}] == curried_filter(eq(2), collection)
    assert [{'a': 3}, {'a': 4}] == curried_filter(increase, curried_filter(eq(2), collection))



# Generated at 2022-06-21 19:53:10.852165
# Unit test for function curried_map
def test_curried_map():
    list_ = [1, 2, 3]
    add2 = lambda x: x+2
    assert curried_map(add2, list_) == [3, 4, 5]


# Generated at 2022-06-21 19:53:14.752835
# Unit test for function eq
def test_eq():
    """
    Unit test for function eq
    Check function eq return true for the same arguments and false for different arguments
    """
    assert eq(1, 1)
    assert not eq("String", "Another string")



# Generated at 2022-06-21 19:53:19.172880
# Unit test for function find
def test_find():
    """
    Run unit tests for function find.
    """
    collection = [1, 2, 3]
    function = lambda x: x == 2
    assert find(collection, function) == 2

    function = lambda x: x == 4
    assert find(collection, function) is None



# Generated at 2022-06-21 19:53:23.782082
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return not is_even(value)

    transform_even = lambda value: value + 2
    transform_odd = lambda value: 3 * value

    transform = cond([
        (is_even, transform_even),
        (is_odd, transform_odd)
    ])

    assert transform(3) == 9
    assert transform(4) == 6



# Generated at 2022-06-21 19:53:25.866684
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-21 19:53:29.896280
# Unit test for function eq
def test_eq():
    a_eq_a = eq(1, 1)
    a_eq_b = eq(1, 2)
    assert a_eq_a
    assert not a_eq_b


# Generated at 2022-06-21 19:53:32.933247
# Unit test for function curried_filter
def test_curried_filter():
    coll = [1, 2, 3]
    mapped = curried_filter(lambda x: x > 1, coll)
    assert mapped == [2, 3]


# Generated at 2022-06-21 19:53:36.419384
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity([]) == []
    assert identity([1]) == [1]
    assert identity([1, 2, 3]) == [1, 2, 3]
    assert identity('Test') == 'Test'


# Generated at 2022-06-21 19:53:38.589088
# Unit test for function eq
def test_eq():
    assert(True == eq(1)(1))
    assert(False == eq(1)(2))



# Generated at 2022-06-21 19:53:41.477670
# Unit test for function memoize
def test_memoize():
    def add(x):
        if x > 10:
            return x
        return x + 1

    mem_add = memoize(add)

    assert mem_add(5) == 6
    assert mem_add(5) == 6


test_memoize()

# Generated at 2022-06-21 19:54:01.560985
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6

    assert curry(lambda x, y: x + y, 1)(1) == 2
    assert curry(lambda x, y: x + y, 1)(2) == 3

    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z, 2)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z, 3)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z, 4)(1)(2)(3) == 6



# Generated at 2022-06-21 19:54:10.317308
# Unit test for function compose
def test_compose():
    number_list = list(range(10))
    increase_compose = compose(
        number_list,
        curried_map(increase),
        curried_filter(lambda x: x % 2 == 0),
        curried_filter(lambda x: x % 4 == 0),
    )

    assert increase_compose == [2, 6, 10, 14, 18]

    increase_compose = compose(
        number_list,
        curried_map(increase),
        curried_map(increase),
        curried_filter(lambda x: x % 4 == 0),
    )

    assert increase_compose == [3, 7, 11, 15]



# Generated at 2022-06-21 19:54:15.227854
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x == 1, [1, 2, 3]) == [1]
    assert curried_filter(lambda x: x == 2)([1, 2, 3]) == [2]
    assert curried_filter(lambda x: x == 3, [1, 2, 3]) == [3]
    assert curried_filter(lambda x: x == 3, [1, 2, 3]) == [3]
    assert curried_filter(lambda x: x == 3, [4, 5, 6, 7]) == []



# Generated at 2022-06-21 19:54:22.549154
# Unit test for function memoize
def test_memoize():
    # Prepare
    test_value = 0
    # Test

    @memoize
    def memoized_fn(x):
        global test_value
        test_value += 1
        return x

    memoized_fn(True)
    memoized_fn(True)
    memoized_fn(False)
    memoized_fn(False)
    memoized_fn(False)
    memoized_fn(False)
    memoized_fn(True)
    # Assert
    assert test_value == 4



# Generated at 2022-06-21 19:54:24.775299
# Unit test for function pipe
def test_pipe():
    assert pipe("test", lambda x: x + "test", lambda x: x + "test") == "testtesttest"
    print("test_pipe - OK")



# Generated at 2022-06-21 19:54:25.406651
# Unit test for function increase
def test_increase():
    assert increase(5) == 6

# Generated at 2022-06-21 19:54:27.223560
# Unit test for function identity
def test_identity():
    assert identity(0) == 0
    assert identity([1, 2]) == [1, 2]
    assert identity('Hello!') == 'Hello!'



# Generated at 2022-06-21 19:54:29.676310
# Unit test for function eq
def test_eq():
    eq_int = eq(1)

    assert eq_int(1) == True
    assert eq_int(0) == False



# Generated at 2022-06-21 19:54:31.862961
# Unit test for function eq
def test_eq():
    assert True is eq(3,3)
    assert False is eq(3,4)
    assert True is eq(3)(3)


# Generated at 2022-06-21 19:54:33.007252
# Unit test for function compose
def test_compose():
    ...



# Generated at 2022-06-21 19:54:59.787389
# Unit test for function curried_filter
def test_curried_filter():
    filter_function = curried_filter(lambda x: x % 2 == 0)
    filter_result = filter_function([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    assert filter_result == [2, 4, 6, 8, 10]

    filter_function = curried_filter(eq(4))
    filter_result = filter_function([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    assert filter_result == [4]


# Generated at 2022-06-21 19:55:01.027132
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity("string") == "string"
    assert identity(None) is None



# Generated at 2022-06-21 19:55:05.495073
# Unit test for function curried_map
def test_curried_map():
    increase_curry = curry(increase)
    list_of_numbers = [1, 2, 3, 4]
    result_list = map(increase_curry, list_of_numbers)
    from_curried_list = curried_map(increase_curry)(list_of_numbers)
    assert result_list == from_curried_list
    # Unit test for function curried_filter


# Generated at 2022-06-21 19:55:15.568516
# Unit test for function memoize
def test_memoize():
    from timeit import timeit

    def factorial(n):
        if n < 0:
            raise ValueError('Factorial is only defined for non-negative integers.')
        if n == 0:
            return 1
        return n * factorial(n - 1)

    start_time = timeit()
    factorial_10 = factorial(10)
    end_time = timeit()
    difference_in_time = end_time - start_time

    start_time = timeit()
    factorial_10 = factorial(10)
    end_time = timeit()
    difference_in_time_after_memoization = end_time - start_time

    assert factorial_10 == 3628800
    assert difference_in_time - difference_in_time_after_memoization > 0
    assert difference_in_

# Generated at 2022-06-21 19:55:17.367230
# Unit test for function curry
def test_curry():
    x = lambda: 1
    assert curry(x)(1)() == 1



# Generated at 2022-06-21 19:55:21.486435
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-21 19:55:23.156061
# Unit test for function identity
def test_identity():
    assert identity('foo') == 'foo'
    assert identity(1) == 1
    assert identity(None) == None



# Generated at 2022-06-21 19:55:27.142026
# Unit test for function curried_filter
def test_curried_filter():
    is_even = lambda x: not x % 2

    assert curried_filter(is_even, [1, 2, 3]) == [2]
    assert curried_filter(is_even)([1, 2, 3]) == [2]
    assert curried_filter(is_even, []) == []

    assert filter(is_even, [1, 2, 3]) == [2]
    assert filter(is_even, []) == []



# Generated at 2022-06-21 19:55:30.965488
# Unit test for function curried_map
def test_curried_map():
    curried_map_increase = curried_map(increase)
    for lst in [[1, 2, 3], [4, 5, 6]]:
        assert curried_map_increase(lst) == [increase(item) for item in lst]


# Generated at 2022-06-21 19:55:34.179676
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq(1)(1)
    assert not eq(1)(2)
    assert eq(2)(2)(2)(2)(2)(2)(2)


# Generated at 2022-06-21 19:55:57.749715
# Unit test for function compose
def test_compose():
    """
    Unit test function

    :return: None
    """

    def add(value):
        return value + 3

    def increase(value):
        return value + 1

    assert 6 == compose(5, add, increase)



# Generated at 2022-06-21 19:56:00.381810
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq('a', 'a') is True
    assert eq('a', 'b') is False
    assert eq(1, 'a') is False
    assert eq([1, 2, 3], [1, 2, 3]) is False



# Generated at 2022-06-21 19:56:02.114295
# Unit test for function increase
def test_increase():
    assert increase(0) == 1



# Generated at 2022-06-21 19:56:07.241040
# Unit test for function find
def test_find():
    data = [1, 2, 3]
    result = find(data, lambda x: x > 2)
    assert result == 3

    data = []
    result = find(data, lambda x: x > 2)
    assert result is None


# Unit tests for function cond

# Generated at 2022-06-21 19:56:10.680819
# Unit test for function eq
def test_eq():
    assert(eq(2, 2)())
    assert(not(eq(2, 3)()))
    f = eq(4)
    g = eq(4)
    assert(f == g)
    assert(f(4))



# Generated at 2022-06-21 19:56:14.790090
# Unit test for function compose
def test_compose():
    value = 2
    assert compose(
        value,
        lambda value: value * 2,
        lambda value: value * 3,
        lambda value: value * 4
    ) == (value * 2) * 3 * 4



# Generated at 2022-06-21 19:56:19.340580
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x > 0)([1, 2, 3, 4, -5]) == [True, True, True, True, False]
    assert curried_map(lambda x: x > 0, [1, 2, 3, 4, -5]) == [True, True, True, True, False]



# Generated at 2022-06-21 19:56:20.225315
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:56:23.479129
# Unit test for function memoize
def test_memoize():
    def is_odd(x):
        print('calculate {}'.format(x))
        return x % 2 == 1

    is_odd_memoized = memoize(is_odd)

    assert is_odd_memoized(5) == True
    assert is_odd_memoized(5) == True

# Generated at 2022-06-21 19:56:24.389525
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:56:46.980554
# Unit test for function memoize
def test_memoize():
    def add_count(x):
        i = 0
        while i < 9000000:
            i += 1
        return x+1
    add_count_memoized = memoize(add_count)
    assert add_count_memoized(2) == add_count(2)


# Generated at 2022-06-21 19:56:49.423139
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert eq('tmp', 'tmp')
    assert not eq('tmp', 'tmp2')



# Generated at 2022-06-21 19:56:56.123722
# Unit test for function curried_filter
def test_curried_filter():
    """
    test curried_filter implementation

    :param None
    :type None
    :returns: None
    :rtype: None
    """
    is_even = lambda value: value % 2 == 0
    collection = [1, 2, 3, 4, 5, 6]
    even_filter = curried_filter(is_even)
    filtered_collection = even_filter(collection)
    assert filtered_collection == [2, 4, 6]



# Generated at 2022-06-21 19:57:00.473458
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b, c: a + b + c)(1)(2)(3) == 6
    assert curry(lambda a, b, c: a + b + c)(10)(20)(30) == 60
    assert curry(lambda a, b, c: a + b + c)(100)(200)(300) == 600
    assert curry(lambda a, b, c: a + b + c)(1000)(2000)(3000) == 6000



# Generated at 2022-06-21 19:57:05.023404
# Unit test for function memoize
def test_memoize():
    @memoize
    def factorial(n):
        if n == 1:
            return 1

        return n * factorial(n - 1)

    assert factorial(10) == 3628800
    assert factorial(20) == 2432902008176640000

# Generated at 2022-06-21 19:57:09.457789
# Unit test for function curried_filter
def test_curried_filter():
    plus_one = lambda x: x + 1
    collection = [1, 2, 3, 4, 5]
    assert curried_filter(lambda x: x % 2 == 0)(collection) == [2, 4]
    assert curried_filter(lambda x: x % 2 == 0, curried_map(plus_one, collection)) == [3, 5]


# Generated at 2022-06-21 19:57:17.420609
# Unit test for function curried_filter
def test_curried_filter():
    is_odd = lambda argument: argument % 2 == 1
    is_negative = lambda argument: argument < 0
    get_odd_negative_numbers = compose(
        curried_filter(is_negative),
        curried_filter(is_odd),
    )
    assert get_odd_negative_numbers([1, 2, -1, -2, 3, 4, -3]) == [-1, -3]



# Generated at 2022-06-21 19:57:20.824348
# Unit test for function memoize
def test_memoize():
    """
    Unit test for function memoize.
    """
    def inc(x):
        print("inc")
        return x + 1

    inc = memoize(inc)

    assert inc(1) == 2
    assert inc(1) == 2
    assert inc(2) == 3
    assert inc(2) == 3

