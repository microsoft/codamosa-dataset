

# Generated at 2022-06-21 19:47:21.312791
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(-10) == -9



# Generated at 2022-06-21 19:47:27.326097
# Unit test for function memoize
def test_memoize():
    f = memoize(lambda n: n * n)

    assert f(3) == 9
    assert f.__closure__[0].cell_contents == [(3, 9)]
    assert f(5) == 25
    assert f(3) == 9
    assert f(5) == 25
    assert f.__closure__[0].cell_contents == [(3, 9), (5, 25)]



# Generated at 2022-06-21 19:47:34.062694
# Unit test for function curry
def test_curry():
    def function(a, b, c):
        return a + b + c

    curried_function = curry(function)
    assert curried_function(1)(2)(3) == 6

    curried_function = curry(function, 2)
    assert curried_function(1, 2)(3) == 6

    curried_function = curry(function, 2)
    assert curried_function(1)(2, 3) == 6

    curried_function = curry(function, 2)
    assert curried_function(1, 2, 3) == 6



# Generated at 2022-06-21 19:47:39.209403
# Unit test for function curry
def test_curry():
    print('start curry test')

    sum = curry(lambda a, b: a + b)
    assert sum(1, 2) == 3
    assert sum(1)(2) == 3

    print('end curry test')



# Generated at 2022-06-21 19:47:41.354840
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda item: item == 1, [0, 1, 2, 3, 1, 0]) == [1, 1]



# Generated at 2022-06-21 19:47:42.402917
# Unit test for function identity
def test_identity():
    assert identity(2) == 2


# Generated at 2022-06-21 19:47:46.467396
# Unit test for function curried_filter
def test_curried_filter():
    list_of_numbers = [1, 2, 3, 4, 5]
    filtered_list = curried_filter(lambda x: x % 2 == 0, list_of_numbers)
    assert filtered_list == [2, 4]
    filtered_list = curried_filter(lambda x: x % 2 == 1, list_of_numbers)
    assert filtered_list == [1, 3, 5]


# Generated at 2022-06-21 19:47:48.950535
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(3), [1, 2, 3, 4, 5, 6, 7, 8, 9]) == [3]



# Generated at 2022-06-21 19:47:58.311515
# Unit test for function pipe
def test_pipe():
    def foo(a):
        return a * 2

    def bar(a):
        return a + 2

    # 2(2+2)+2 = 2*2+2+2 = 2+2+2+2 = 2+2+2+2 = 8
    assert pipe(2, foo, bar, foo, bar) == 8

    # 2(2+2)+2 = 2*2+2+2 = 2+2+2+2 = 2+2+2+2 = 8
    assert compose(2, bar, foo, bar, foo) == 8



# Generated at 2022-06-21 19:48:04.075196
# Unit test for function cond
def test_cond():
    assert cond([(
        lambda x: x < 0,
        lambda x: a * x + b * 2 * x
    ),
        (
            lambda x: x == 0,
            lambda x: a * x + b * x
        ),
        (
            lambda x: x > 0,
            lambda x: a * x + b * x
        ),
    ])(2) == 12



# Generated at 2022-06-21 19:48:10.984547
# Unit test for function cond
def test_cond():
    fn = cond([(lambda x: x < 0, increase)])
    assert fn(-4) == -3



# Generated at 2022-06-21 19:48:16.247864
# Unit test for function compose
def test_compose():
    fn_add_1 = lambda x: x + 1
    fn_sum = lambda x, y: x + y
    assert compose(1, fn_add_1, fn_add_1) == 3

    assert compose(1, fn_sum, fn_add_1) == 3



# Generated at 2022-06-21 19:48:17.746569
# Unit test for function compose
def test_compose():
    result = compose(2, increase, increase)
    assert result == 4



# Generated at 2022-06-21 19:48:21.085499
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity("hello") == "hello"
    assert identity(None) is None
    assert identity(1.0) == 1.0


# Generated at 2022-06-21 19:48:23.144965
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4]) == [3, 4]


# Generated at 2022-06-21 19:48:27.480499
# Unit test for function compose
def test_compose():
    assert compose(1, increase) == 2
    assert compose(1, increase, increase) == 3
    assert compose("hello", lambda word: word + " world") == "hello world"



# Generated at 2022-06-21 19:48:31.032136
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, range(3)) == [0]
    assert curried_filter(lambda x: x % 2 == 0)(range(3)) == [0]



# Generated at 2022-06-21 19:48:36.739259
# Unit test for function memoize
def test_memoize():
    def factorial(n):
        assert n >= 0, "n must be >= 0"

        if n == 0:
            return 1
        else:
            return n * factorial(n - 1)

    factorial = memoize(factorial)
    for n in range(1, 21):
        assert factorial(n) == math.factorial(n), "factorial({}) should be {}".format(n, math.factorial(n))

# Generated at 2022-06-21 19:48:46.368158
# Unit test for function memoize
def test_memoize():
    a = -10
    b = 10
    c = a
    d = 5
    f = 7

    @memoize
    def fibonacci(n):
        assert n is not None
        if n < 2:
            return n
        return fibonacci(n-2) + fibonacci(n-1)

    for n in range(11):
        if n < 2:
            x = n
        else:
            x = fibonacci(n-2) + fibonacci(n-1)

        print("fibonacci(" + str(n) + ") is " + str(fibonacci(n)))
        assert fibonacci(n) == x

    @memoize
    def sum(a, b, c):
        x = a + b + c
        return x


# Generated at 2022-06-21 19:48:50.647338
# Unit test for function curried_filter
def test_curried_filter():
    # Should filter list
    filter_result = curried_filter(is_even)([1, 2, 3, 4, 5, 6, 7, 8])
    assert filter_result == [2, 4, 6, 8]


# Generated at 2022-06-21 19:49:00.636252
# Unit test for function eq
def test_eq():
    assert eq(2)(2)
    assert eq(2, 2)
    assert not eq(3)(2)
    assert eq(3)(3)
    assert eq(3, 3)


# Generated at 2022-06-21 19:49:02.055319
# Unit test for function pipe
def test_pipe():
    assert pipe(2, increase, increase) == 4


# Generated at 2022-06-21 19:49:03.226598
# Unit test for function increase
def test_increase():
    assert increase(100) == 101



# Generated at 2022-06-21 19:49:09.077333
# Unit test for function find
def test_find():
    assert find([7, 8, 9], lambda x: x < 8) == 7
    assert find([7, 8, 9], lambda x: x == 8) == 8
    assert find([7, 8, 9], lambda x: x > 8) == 9
    assert find([7, 8, 9], lambda x: x > 9) is None
    assert find([7, 8, 9], lambda x: x == 10) is None

    assert find([], lambda x: x < 8) is None



# Generated at 2022-06-21 19:49:21.279113
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq(1, 1.0) == True
    assert eq(1, '1') == False
    assert eq(True, True) == True
    assert eq(None, None) == True
    assert eq(True, False) == False
    assert eq([], []) == True
    assert eq({}, {}) == True
    assert eq([1, 2], [1, 2]) == True
    assert eq([1, 2], [1, 2, 3]) == False
    assert eq([1, 2], [3, 2]) == False
    assert eq({1: 'q', 2: 'w'}, {1: 'q', 2: 'w'}) == True

# Generated at 2022-06-21 19:49:22.927256
# Unit test for function increase
def test_increase():
    assert increase(2) == 3



# Generated at 2022-06-21 19:49:24.385781
# Unit test for function pipe
def test_pipe():
    assert pipe(0, identity, increase) == 1


# Generated at 2022-06-21 19:49:27.679231
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(2), [1, 2, 3, 2]) == [2, 2]

    assert curried_filter(eq('a'), 'abc') == ['a']

    assert curried_filter(eq('a'), ['abc', 'bvc']) == []



# Generated at 2022-06-21 19:49:30.762487
# Unit test for function find
def test_find():
    test_data = [0, 2, 3]
    assert find(test_data, lambda x: (x == 0)) == 0


# Generated at 2022-06-21 19:49:33.872652
# Unit test for function compose
def test_compose():
    """
    Testing compose function.
    """
    function1 = lambda x: x + 1
    function2 = lambda x: x * 2
    compose_result = compose(1, function1, function2)
    assert compose_result == 4



# Generated at 2022-06-21 19:49:41.566094
# Unit test for function pipe
def test_pipe():
    from functools import reduce

    def add(value):
        return value + 1

    def sub(value):
        return value - 1

    def mul(value):
        return value * 2

    def div(value):
        return value / 2

    assert pipe(0, add, sub, mul, div) == 0
    assert pipe(1, add, sub, mul, div) == 1

# Generated at 2022-06-21 19:49:45.645924
# Unit test for function cond
def test_cond():
    from operator import add, sub

    condition_list = [
        (lambda x, y: x % y == 0, add),
        (lambda x, y: x % y == 1, sub),
        (lambda x, y: True, sub),
    ]

    assert cond(condition_list)(1, 0) == 2
    assert cond(condition_list)(1, 1) == 0
    assert cond(condition_list)(2, 1) == 0



# Generated at 2022-06-21 19:49:49.866919
# Unit test for function find
def test_find():
    assert find([], lambda x: x == 1) is None
    assert find([1, 2, 3], lambda x: x == 1) == 1
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-21 19:49:50.623002
# Unit test for function increase
def test_increase():
    result = increase(1)
    assert result == 2



# Generated at 2022-06-21 19:49:51.931704
# Unit test for function curry
def test_curry():
    c = curry(identity)
    assert c(1) == 1



# Generated at 2022-06-21 19:49:57.540597
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [1, 2, 3]) == [1, 2, 3] # test empty map
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4] # test increase function
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4] # test currying
    assert curried_map(increase, [1, 2, 3, 4, 5])([4, 5, 6]) == [5, 6, 7, 5, 6, 7] # test multiply apply


# Generated at 2022-06-21 19:50:01.428931
# Unit test for function find
def test_find():
    assert find([], identity) is None
    assert find([], eq(1)) is None
    assert find([1, 2, 3], eq(1)) == 1
    assert find([1, 2, 3], eq(4)) is None



# Generated at 2022-06-21 19:50:08.522718
# Unit test for function pipe
def test_pipe():
    assert pipe(1, lambda x: x + 1) == 2
    assert pipe(1, lambda x: x + 1, lambda x: x * 2) == 4
    assert pipe(1, lambda x: x + 2, lambda x: x * 2) == 6
    assert pipe(1, lambda x: x + 2, lambda x: x * 2, lambda x: x / 3) == 2



# Generated at 2022-06-21 19:50:12.267463
# Unit test for function curried_filter
def test_curried_filter():
    filter_even = curried_filter(lambda number: number % 2 == 0)

    assert filter_even([1, 2, 3, 4]) == [2, 4]
    assert filter_even([1, 3, 5]) == []

# Generated at 2022-06-21 19:50:18.565659
# Unit test for function curry
def test_curry():
    add_curry = curry(lambda a, b, c, d: a + b + c + d)
    assert add_curry(1, 2, 3, 4) == 10
    add_curry1 = add_curry(1, 2)
    assert add_curry1(3, 4) == 10
    add_curry2 = add_curry(1, 2, 3)
    assert add_curry2(4) == 10



# Generated at 2022-06-21 19:50:28.305113
# Unit test for function curried_map
def test_curried_map():
    curried_map_inc = curried_map(increase)
    assert curried_map_inc(list(range(5))) == list(range(1, 6))
    assert curried_map_inc(list(range(5))) == list(map(increase, list(range(5))))


# Generated at 2022-06-21 19:50:31.934469
# Unit test for function eq
def test_eq():
    assert eq(1)(1) is True
    assert eq(1)(2) is False
    assert eq(1, 1) is True
    assert eq(1, 2) is False



# Generated at 2022-06-21 19:50:41.172320
# Unit test for function cond
def test_cond():
    def is_truly(value):
        return value

    def is_false(value):
        return not value

    condition_list = [
        (is_truly, identity),
        (is_false, increase)
    ]
    test_cond_fn = cond(condition_list)
    assert test_cond_fn(False) == 1
    assert test_cond_fn(True) == True
    assert test_cond_fn(0) == 1
    assert test_cond_fn(1) == 1
    assert test_cond_fn('') == 1
    assert test_cond_fn([]) == 1
    assert test_cond_fn(dict()) == 1
    assert test_cond_fn(None) == 1



# Generated at 2022-06-21 19:50:45.301723
# Unit test for function pipe
def test_pipe():
    def square(value):
        return value ** 2

    def dec(value):
        return value - 1

    def inc(value):
        return value + 1

    def identity(value):
        return value

    test_data = [
        (
            pipe(2, square, dec, inc),
            9
        ),
        (
            pipe(2, square, inc),
            5
        ),
        (
            pipe(2, identity),
            2
        )
    ]

    for data in test_data:
        fn, result = data
        assert fn() == result


# Generated at 2022-06-21 19:50:49.911507
# Unit test for function curried_filter
def test_curried_filter():
    list_of_numbers = [1, 2, 3, 4, 5]
    is_even = lambda x: x % 2 == 0
    assert [2, 4] == curried_filter(is_even, list_of_numbers)
    assert [2, 4] == curried_filter(is_even)(list_of_numbers)


# Generated at 2022-06-21 19:50:52.378904
# Unit test for function identity
def test_identity():
    assert identity(1) == 1


# Generated at 2022-06-21 19:50:53.455001
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:51:02.144908
# Unit test for function curry
def test_curry():
    add42 = curry(lambda a, b: a + b)
    assert isinstance(add42, type(lambda: None)), "curried function instance should be a function"
    assert add42(1) == add42(1), "curried function should return a curried function"
    assert add42(1, 2) == add42(1)(2), "curried function should work with any number of arguments"
    assert add42(1, 2, 3) == add42(1)(2, 3), "curried function should work with any number of arguments"
    assert add42(1, 2, 3, 4) == add42(1)(2)(3, 4), "curried function should work with any number of arguments"

# Generated at 2022-06-21 19:51:04.323173
# Unit test for function curried_filter
def test_curried_filter():
    """
    Unit test for curried_filter.
    """
    assert curried_filter(lambda x: x > 1)([0, 1, 2, 3, 4]) == [2, 3, 4]



# Generated at 2022-06-21 19:51:06.667747
# Unit test for function identity
def test_identity():
    assert identity(True) is True, "Failed for True"
    assert identity(False) is False, "Failed for False"



# Generated at 2022-06-21 19:51:22.979728
# Unit test for function curry
def test_curry():
    def add(x: int, y: int) -> int:
        return x + y

    fn1 = curry(add)
    fn2 = fn1(1)
    fn3 = fn2(2)
    fn4 = fn1(1, 2)
    fn5 = curry(add, 3)

    assert fn3 == 3
    assert fn4 == 3
    assert fn5(2, 3) == 5



# Generated at 2022-06-21 19:51:28.449072
# Unit test for function pipe
def test_pipe():
    multiply = lambda x, y, z: x * y * z
    assert pipe(5, lambda x: multiply(x, x, x), increase) == 126
    assert pipe(5, lambda x: multiply(x, x, x), increase, lambda x: x % 2) == 0
    assert pipe(5, lambda x: multiply(x, x, x), increase, lambda x: x % 2 == 0)



# Generated at 2022-06-21 19:51:33.051635
# Unit test for function pipe
def test_pipe():
    """
    Run test for function pipe.
    """

# Generated at 2022-06-21 19:51:36.183102
# Unit test for function curried_filter
def test_curried_filter():
    print("test_curried_filter")
    print(curried_filter(eq(1))([1, 2, 3]))
    # [1]



# Generated at 2022-06-21 19:51:40.019724
# Unit test for function memoize
def test_memoize():
    some_function = memoize(lambda arg: arg + 1)
    assert some_function(1) == 2
    assert some_function(1) == 2
    assert some_function(1) == 2
    assert some_function(2) == 3
    assert some_function(2) == 3

# Generated at 2022-06-21 19:51:41.021827
# Unit test for function identity
def test_identity():
    assert identity(1) == 1


# Generated at 2022-06-21 19:51:43.267041
# Unit test for function pipe
def test_pipe():
    assert pipe(1, lambda x: x + 1) == 2
    assert pipe(1, lambda x: x + 1, lambda x: x * 2) == 4



# Generated at 2022-06-21 19:51:45.015791
# Unit test for function identity
def test_identity():
    assert identity(5) == 5



# Generated at 2022-06-21 19:51:48.110551
# Unit test for function pipe
def test_pipe():
    pipe_result = pipe(
        2,
        lambda value: value*value,
        lambda value: value+value,
        lambda value: value+2
    )
    assert pipe_result == 18



# Generated at 2022-06-21 19:51:54.863098
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0

    def is_odd(value):
        return value % 2 == 1

    is_even_or_odd = cond([
        (is_even, lambda value: 'even'),
        (is_odd, lambda value: 'odd'),
    ])

    assert is_even_or_odd(2) == 'even'
    assert is_even_or_odd(3) == 'odd'



# Generated at 2022-06-21 19:52:06.793907
# Unit test for function eq
def test_eq():
    """
    Test for function eq
    """
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-21 19:52:07.884138
# Unit test for function increase
def test_increase():
    assert increase(42) == 43


# Generated at 2022-06-21 19:52:13.586064
# Unit test for function cond
def test_cond():
    def odd(x: int) -> bool:
        return x % 2 == 1

    def lower(x: int) -> str:
        return x * 2

    def upper(x: int) -> str:
        return x * 3

    cases = [
        (odd, lower),
        (identity, upper),
    ]

    f = cond(cases)
    print(f(5))
    print(f(2))



# Generated at 2022-06-21 19:52:17.775771
# Unit test for function compose
def test_compose():
    assert compose(1, increase, identity) == 2
    assert compose(1, compose, compose) == 3
    assert compose(1, identity, increase) == 2

# Generated at 2022-06-21 19:52:21.438287
# Unit test for function curried_filter
def test_curried_filter():
    """
    Test function curried_filter
    """
    even_numbers = curried_filter(lambda number: number % 2 == 0, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9])
    assert even_numbers == [0, 2, 4, 6, 8]



# Generated at 2022-06-21 19:52:23.199726
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x * y)(4)(4) == 16



# Generated at 2022-06-21 19:52:30.052825
# Unit test for function cond
def test_cond():
    def isNegative(x):
        return x < 0
    def isPositive(x):
        return x > 0
    def isZero(x):
        return x == 0

    @cond([
        (isNegative, lambda x: 'negative'),
        (isZero, lambda x: 'zero'),
        (isPositive, lambda x: 'positive'),
    ])
    def result(argument):
        return None
    print('test cond()')
    print(result(1))
    print(result(0))
    print(result(-1))
    print(result(None))



# Generated at 2022-06-21 19:52:33.309747
# Unit test for function pipe
def test_pipe():
    assert pipe(1, lambda x: x + 2) == 3
    assert pipe(1, lambda x: x * 2, lambda x: x ** 2) == 4



# Generated at 2022-06-21 19:52:34.815744
# Unit test for function pipe
def test_pipe():
    assert pipe(2, increase, increase, increase) == 5



# Generated at 2022-06-21 19:52:42.748598
# Unit test for function cond
def test_cond():
    def to_upper_case(string):
        return string.upper()

    def to_lower_case(string):
        return string.lower()

    def is_upper(string):
        return string == string.upper()

    def is_lower(string):
        return string == string.lower()

    converter = cond([
        (is_upper, to_lower_case),
        (is_lower, to_upper_case),
    ])

    assert converter("string") == "STRING"
    assert converter("STRING") == "string"



# Generated at 2022-06-21 19:52:54.513060
# Unit test for function curry
def test_curry():
    # GIVEN
    def add(a, b):
        return a + b

    # WHEN
    add_curry = curry(add)

    # THEN
    assert isinstance(add_curry, Callable)
    assert isinstance(add_curry(1), Callable)
    assert add_curry(1)(1) == 2



# Generated at 2022-06-21 19:52:56.697589
# Unit test for function curried_map
def test_curried_map():
    count = 4
    mapped_list = []
    for i in range(count):
        mapped_list.append(i + 1)

    assert curried_map(increase)(mapped_list) == list(range(1,count+1))
    assert curried_map(lambda x: x * 2, [1, 2, 3, 4]) == [2, 4, 6, 8]


# Generated at 2022-06-21 19:53:01.595619
# Unit test for function curry
def test_curry():

    def add_two_things(a, b):
        return a + b

    assert curry(add_two_things)(1)(2) == 3

    assert curry(add_two_things, 1)(1) == 2
    assert curry(add_two_things, 2)(1, 1) == 2

    assert curry(add_two_things)(1)(1) == 2



# Generated at 2022-06-21 19:53:10.592803
# Unit test for function cond
def test_cond():
    def double(value):
        return value * 2

    def get_first_item(item):
        return item[0]

    def always_a():
        return 'a'

    def always_b():
        return 'b'

    def always_c():
        return 'c'

    def is_not_b(item):
        return item != 'b'

    def is_not_a(item):
        return item != 'a'


# Generated at 2022-06-21 19:53:11.247212
# Unit test for function increase
def test_increase():
    assert increase(1) == 2


# Generated at 2022-06-21 19:53:15.989451
# Unit test for function identity
def test_identity():
    """
    Test for testing identity function
    """
    assert identity(1) == 1
    assert identity(True) is True
    assert identity(None) is None
    assert identity([]) == []
    assert identity(()) == ()
    assert identity({}) == {}



# Generated at 2022-06-21 19:53:20.408738
# Unit test for function memoize
def test_memoize():
    prevCount = len(memoize_fn.__code__.co_code)
    memoize_fn()
    newCount = len(memoize_fn.__code__.co_code)
    assert prevCount < newCount



# Generated at 2022-06-21 19:53:23.343096
# Unit test for function compose
def test_compose():
    # compose two functions
    assert compose("name", lambda x: f"Hello {x}") == "Hello name"

    # compose list of functions
    f = compose("name", lambda x: f"Hello {x}", lambda x: f"{x}!")
    assert f == "Hello name!"



# Generated at 2022-06-21 19:53:27.123901
# Unit test for function memoize
def test_memoize():
    @memoize
    def factorial(n):
        if n <= 1:
            return 1
        return n * factorial(n-1)

    assert factorial(5) == 5*4*3*2*1


# Generated at 2022-06-21 19:53:28.983384
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:53:42.559955
# Unit test for function curried_map
def test_curried_map():
    print("UNIT TEST for function curried_map")
    assert curried_map(increase, [1, 5, 9, 4]) == [2, 6, 10, 5]
    assert curried_map(increase, [1]) == [2]
    assert curried_map(increase, []) == []
    print("UNIT TEST end")



# Generated at 2022-06-21 19:53:45.956454
# Unit test for function find
def test_find():
    assert None == find([], lambda x: x == 0)
    assert None == find([1, 2, 3], lambda x: x == 0)
    assert 3 == find([1, 2, 3], lambda x: x == 3)

# Generated at 2022-06-21 19:53:47.818756
# Unit test for function compose
def test_compose():
    from string import upper, capitalize

    fun = compose(
        'GOD is DEAD',
        upper,
        capitalize,
        lambda x: x[1:]
    )

    assert fun == 'Od is dead'



# Generated at 2022-06-21 19:53:48.768921
# Unit test for function identity
def test_identity():
    assert identity(12) == 12



# Generated at 2022-06-21 19:53:55.635182
# Unit test for function memoize
def test_memoize():
    """
    assert memoize(increase)(2) == increase(2)
    assert memoize(increase)(2) == increase(2)
    """
    parameter = 1
    result = memoize(increase)(parameter)
    assert result == increase(parameter)
    result2 = memoize(increase)(parameter)
    assert result2 == increase(parameter)
    result3 = memoize(increase)(parameter)
    assert result3 == increase(parameter)



# Generated at 2022-06-21 19:53:56.482168
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:54:00.488385
# Unit test for function compose
def test_compose():
    assert(compose(2, lambda x: x * 2, lambda x: x + 1) == 6)
    assert(compose(3, lambda x: x * 2, lambda x: x + 1) == 7)
    assert(pipe(1, lambda x: x + 1, lambda x: x * 2) == 4)
    assert(pipe(10, lambda x: x + 1, lambda x: x * 2) == 22)


# Generated at 2022-06-21 19:54:05.159145
# Unit test for function eq
def test_eq():
    func = eq
    assert func(1, 1) is True
    assert func(1, 2) is False
    assert func('a', 'a') is True
    assert func('a', 'b') is False
    assert func(['a'], ['a']) is False



# Generated at 2022-06-21 19:54:08.508649
# Unit test for function curried_filter
def test_curried_filter():
    test = [1, 2, 3, 4]
    less_than_three = curried_filter(lambda item: item < 3)
    assert list(less_than_three(test)) == [1, 2]



# Generated at 2022-06-21 19:54:10.083980
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-21 19:54:32.190135
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity('test') == 'test'
    assert identity(None) is None
    assert identity(identity) == identity



# Generated at 2022-06-21 19:54:37.628868
# Unit test for function find
def test_find():
    assert None == find([], (lambda x: True))
    assert None == find([1, 2, 3], (lambda x: x == 4))
    assert 1 == find([1, 2, 3], (lambda x: x == 1))
    assert 2 == find([1, 2, 3], (lambda x: x == 2))
    assert 3 == find([1, 2, 3], (lambda x: x == 3))



# Generated at 2022-06-21 19:54:44.694099
# Unit test for function curried_map
def test_curried_map():
    list_1 = [1,2,3,4]
    f_inc = map_f = curried_map(lambda x: x + 1)
    f_add = map_f = curried_map(lambda x, y: x + y)

    assert(list(f_inc(list_1)) == [2,3,4,5])
    assert(list(f_add(list_1, [5,7,9,12])) == [6,9,12,16])


# Generated at 2022-06-21 19:54:46.556097
# Unit test for function pipe
def test_pipe():
    assert pipe(
        1,
        lambda x: x + 1,
        lambda x: x * 2
    ) == 4

# Generated at 2022-06-21 19:54:47.131395
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-21 19:54:50.612678
# Unit test for function curried_map
def test_curried_map():
    curried_map_incr = curried_map(increase)
    assert curried_map_incr([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-21 19:54:53.186854
# Unit test for function identity
def test_identity():
    assert identity("test") == "test"
    assert identity(123) == 123
    assert identity(True) is True
    assert identity(None) is None
    assert identity([]) == []


# Generated at 2022-06-21 19:54:59.111734
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 1) == 1
    assert find([1, 2, 3], lambda x: x == 4) is None
    assert find([1, 2, 3], lambda x: x > 1) == 2
    assert find([1, 2, 3], lambda x: x < 0) is None
    assert find([], lambda x: False) is None



# Generated at 2022-06-21 19:55:03.086649
# Unit test for function identity
def test_identity():
    assert identity(2) == 2
    assert identity('value') == 'value'
    assert identity(['1', '2', '3']) == ['1', '2', '3']
    assert identity((1, 2, 3, 4)) == (1, 2, 3, 4)



# Generated at 2022-06-21 19:55:06.094736
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x == 1, [1, 2]) == [1]
    assert curried_filter(lambda x: x == 2, [1, 2]) == [2]
    assert curried_filter(lambda x: x == 3, [1, 2]) == []

test_curried_filter()

# Generated at 2022-06-21 19:55:50.280538
# Unit test for function curried_map
def test_curried_map():
    assert curried_map([0, 1, 2, 3])(inc) == [1, 2, 3, 4]
    assert curried_map([0, 1, 2, 3])(lambda x: x ** 2) == [0, 1, 4, 9]
    assert curried_map(lambda x: x ** 2)([0, 1, 2, 3]) == [0, 1, 4, 9]


# Generated at 2022-06-21 19:55:58.367040
# Unit test for function eq
def test_eq():
    eq_test_arguments = (
        (1, 2, False),
        (2, 2, True),
        ('foo', 'bar', False),
        ('foo', 'foo', True),
        (True, False, False),
        (True, True, True),
        (None, None, True),
    )

    for (arg1, arg2, expected_result) in eq_test_arguments:
        assert expected_result == eq(arg1, arg2), \
            'Fails with curried args: \n' + \
            '    arg1 = ' + str(arg1) + '\n' + \
            '    arg2 = ' + str(arg2)



# Generated at 2022-06-21 19:56:04.183593
# Unit test for function find
def test_find():
    # Define collection
    collection = [
        {'name': 'James', 'age': 40, 'country': 'Australia'},
        {'name': 'Anna', 'age': 20, 'country': 'Russia'},
        {'name': 'Andrew', 'age': 40, 'country': 'Russia'},
        {'name': 'Anna', 'age': 20, 'country': 'Poland'},
    ]

    # Find all of element where age less than 40
    albert_age_less_than_40 = find(
        collection,
        lambda person: person['age'] < 40)
    assert albert_age_less_than_40 == {
        'name': 'Anna', 'age': 20, 'country': 'Russia'}

    # Find all of element with name Albert

# Generated at 2022-06-21 19:56:07.589150
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2
    assert increase(100) == 101



# Generated at 2022-06-21 19:56:18.342390
# Unit test for function cond
def test_cond():
    def sum(a, b=0):
        return a + b

    def minus(a, b=0):
        return a - b

    def multiply(a, b=1):
        return a * b

    def divide(a, b=1):
        return a / b

    def is_positive(a):
        return a > 0

    def is_negative(a):
        return a < 0

    result_zero = cond([
        (is_positive, sum),
        (is_negative, minus),
    ])(5, 10)

    result_positive = cond([
        (is_positive, sum),
        (is_negative, minus),
    ])(5)

    result_negative = cond([
        (is_positive, sum),
        (is_negative, minus),
    ])(-5)

    real

# Generated at 2022-06-21 19:56:22.930365
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert curried_map(identity, [1, 2, 3, 4]) == [1, 2, 3, 4]
    assert curried_map(increase, [1, 2, 3, 4]) == [2, 3, 4, 5]


# Generated at 2022-06-21 19:56:24.186412
# Unit test for function pipe
def test_pipe():
    assert pipe(0, increase, increase, increase, increase) == 4


# Generated at 2022-06-21 19:56:25.470669
# Unit test for function identity
def test_identity():
    assert identity(1) == 1

# Generated at 2022-06-21 19:56:35.288283
# Unit test for function memoize
def test_memoize():
    def times3(number):
        return number * 3

    def times2(number):
        return number * 2

    def times5(number):
        return number * 5

    def times6(number):
        return times2(times3(number))

    memoized_times2 = memoize(times2)
    memoized_times3 = memoize(times3)
    memoized_times5 = memoize(times5)
    memoized_times6 = memoize(times6)

    assert memoized_times2(4) == 8
    assert memoized_times2(4) == 8
    assert memoized_times3(11) == 33
    assert memoized_times3(11) == 33

    memoized_times6(4) == 24
    memoized_times6(4) == 24

# Generated at 2022-06-21 19:56:38.027765
# Unit test for function curried_map
def test_curried_map():
    collection = [1, 2, 3, 4]

    assert curried_map(lambda number: number+1)(collection) == [2, 3, 4, 5]
