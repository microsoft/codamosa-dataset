

# Generated at 2022-06-21 19:47:16.462796
# Unit test for function compose
def test_compose():
    assert compose(0, increase, increase) == 2
    assert compose(0, lambda x: x + 1) == 1

# Generated at 2022-06-21 19:47:19.631967
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 4) is None



# Generated at 2022-06-21 19:47:24.300866
# Unit test for function curried_map
def test_curried_map():
    def mapper(value):
        return value + 1

    collection = [0, 1, 2, 3]

    result = [1, 2, 3, 4]
    assert curried_map(mapper)(collection) == result
    assert curried_map(mapper, collection) == result


# Generated at 2022-06-21 19:47:26.598561
# Unit test for function curry
def test_curry():
    increase_by_2 = curry(lambda x, y: x + y)(2)
    assert increase_by_2(2) == 4



# Generated at 2022-06-21 19:47:29.126835
# Unit test for function pipe
def test_pipe():
    assert pipe(
        1,
        lambda x: x + 10,
        lambda x: x * 2
    ) == 22


# Generated at 2022-06-21 19:47:31.637177
# Unit test for function memoize
def test_memoize():
    func = lambda x: x + 2
    memoized_func = memoize(func)
    assert memoized_func(1) == memoized_func(1)



# Generated at 2022-06-21 19:47:36.784030
# Unit test for function memoize
def test_memoize():
    import time
    import random

    # create random list with random length
    n = random.randint(1, 10)
    xs = [random.randint(-100, 100) for _ in range(n)]

    # create function to work with
    simple_fn = lambda xs: sum(x * x for x in xs)

    # create memoized function to work with
    def fn(xs):
        time.sleep(0.1)
        return sum(x * x for x in xs)
    memoized_fn = memoize(fn)

    # compare work time of two function
    assert 0.1 <= time.clock() - time.clock() <= 0.2
    assert memoized_fn(xs) == fn(xs)
    assert 0.1 <= time.clock() - time.clock() <= 0.2
   

# Generated at 2022-06-21 19:47:40.616845
# Unit test for function identity
def test_identity():
    return identity(1), identity(True), identity(None), identity(False),



# Generated at 2022-06-21 19:47:42.362320
# Unit test for function eq
def test_eq():
    assert eq(5,5) == True
    assert eq(5,4) == False


# Generated at 2022-06-21 19:47:50.849296
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5]) == [2, 4]
    assert curried_filter(lambda x: x > 0, [1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert curried_filter(lambda x: x > 0, []) == []
    assert curried_filter(lambda x: x % 5 == 0, [1, 2, 3, 4, 5]) == [5]
    assert curried_filter(lambda x: x > 10, [1, 2, 3, 4, 5]) == []



# Generated at 2022-06-21 19:48:02.340316
# Unit test for function compose
def test_compose():
    fn = lambda x, y: x + y
    fn1 = lambda x, y: x * y

    assert compose(
        1,
        lambda x: x + 2,
        fn1,
        lambda x, y: x + y,
        fn,
        lambda x: x * 2
    ) == 18


# Generated at 2022-06-21 19:48:04.949283
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)(range(10)) == [0, 2, 4, 6, 8]



# Generated at 2022-06-21 19:48:10.374629
# Unit test for function pipe
def test_pipe():
    happy_path_func = pipe(1, lambda a: a + 2, lambda a: a + 3)
    assert happy_path_func() == 6
    # happy_path_func = pipe(1, lambda a: a + 2, lambda a: a + '-Hello-')
    # assert happy_path_func() == '3-Hello-'
    happy_path_func = pipe([1, 2, 3], lambda a: [4, 5, 6], lambda a: [7, 8, 9])
    assert happy_path_func() == [7, 8, 9]



# Generated at 2022-06-21 19:48:12.451529
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(True) == True
    assert identity("string") == "string"



# Generated at 2022-06-21 19:48:16.085711
# Unit test for function identity
def test_identity():
    assert identity(5) == 5
    assert identity(False) is False
    assert identity([1, 2, 3]) == [1, 2, 3]



# Generated at 2022-06-21 19:48:20.181965
# Unit test for function memoize
def test_memoize():
    assert memoize(
        lambda x: x*x
    )(3) == 9

    memoized_mul = memoize(
        lambda x: x*x
    )
    assert memoized_mul(3) == 9

# Generated at 2022-06-21 19:48:21.609172
# Unit test for function compose
def test_compose():
    assert compose(1, increase, increase, increase) == 4



# Generated at 2022-06-21 19:48:27.717451
# Unit test for function curried_map
def test_curried_map():
    log = "Eq: "
    is_equal = (
        (curried_map(identity)([1, 2, 3]), [1, 2, 3]),
        (curried_map(identity, [1, 2, 3]), [1, 2, 3]),
        (curried_map(increase, [1, 2, 3]), [2, 3, 4]),
    )
    counter = 0
    for test in is_equal:
        test_eq = test[0] == test[1]
        log += (str(counter) + ' ' + str(test[0]) + ' == ' + str(test[1]) + ' is ' + str(test_eq) + '\n')
        counter += 1
    return log


# Generated at 2022-06-21 19:48:29.138488
# Unit test for function identity
def test_identity():
    assert identity(2) == 2

# Generated at 2022-06-21 19:48:33.064131
# Unit test for function curry
def test_curry():
    assert identity(2) == 2
    identity_curry = curry(identity, 1)
    assert identity_curry(2) == 2
    increase_2_curry = curry(increase, 1)
    assert increase_2_curry(1) == 2


# Generated at 2022-06-21 19:48:46.488185
# Unit test for function pipe
def test_pipe():
    # we have
    x = [1, 2, 3]

    # and we have not
    assert not x == [1, 5, 3]
    assert not x == [5, 2, 3]

    # then when we try to find 1 then we get True
    assert find(x, eq(1)) == 1

    # when we try to map all elements to 10 then we get [10, 10, 10]
    assert curried_map(lambda x: x + 7, x) == [8, 9, 10]

    # when we try to increase all elements by 1 and map to 10 then we get [10, 10, 10]
    assert pipe(x, curried_map(increase), curried_map(lambda x: x + 7)) == [8, 9, 10]

    # when we try to increase all elements by 1 and map to 10

# Generated at 2022-06-21 19:48:50.697098
# Unit test for function curried_filter
def test_curried_filter():
    curried_filter_is_even = curried_filter(lambda x: x % 2 == 0)
    assert curried_filter_is_even([1, 2, 3, 4, 5]) == [2, 4]


# Generated at 2022-06-21 19:48:53.202604
# Unit test for function curry
def test_curry():
    assert curried_map([1, 2, 3])(lambda value: value + 1) == [2, 3, 4]



# Generated at 2022-06-21 19:49:01.889221
# Unit test for function memoize
def test_memoize():
    counter = [0]

    def heavy_function(argument):
        counter[0] += 1
        return argument

    memoized_fn = memoize(heavy_function, key=eq)
    # invoke memoized_fn with same argument to cache
    memoized_fn('foo')
    memoized_fn('foo')
    # invoke memoized_fn with different argument
    memoized_fn('bar')
    # counter should be increased only twice
    assert counter == [2]


# Generated at 2022-06-21 19:49:05.762773
# Unit test for function curried_map
def test_curried_map():
    map_incr = curried_map(increase)
    assert map_incr([1, 2, 3]) == [2, 3, 4]
    assert map_incr([4, 5, 6]) == [5, 6, 7]



# Generated at 2022-06-21 19:49:08.635765
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(0) == 0
    assert identity(-1) == -1


# Generated at 2022-06-21 19:49:11.194924
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 0, [-1, 0, 1, -2, 2]) == [1, 2]



# Generated at 2022-06-21 19:49:23.786390
# Unit test for function cond
def test_cond():
    if __name__ == '__main__':
        can_divided_by_7 = lambda number: number % 7 == 0
        can_divided_by_5 = lambda number: number % 5 == 0
        is_negative = lambda number: number < 0

        check_number = lambda number: cond([
            (can_divided_by_7, lambda number: 'Can be divided by 7'),
            (can_divided_by_5, lambda number: 'Can be divided by 5'),
            (is_negative, lambda number: 'Negative number'),
        ])(number)

        print(check_number(13))  # Negative number
        print(check_number(35))  # Can be divided by 5
        print(check_number(-49))  # Negative number
        print(check_number(0))  # Can be divided by 7

# Generated at 2022-06-21 19:49:24.921820
# Unit test for function identity
def test_identity():
    assert identity('test_identity') == 'test_identity'


# Generated at 2022-06-21 19:49:33.598729
# Unit test for function cond
def test_cond():
    def is_true(value): return value == True
    def return_true(): return True
    def return_false(): return False

    assert cond([
        (is_true, return_true),
        (is_true, return_false),
    ])(True) == True

    assert cond([
        (is_true, return_false),
        (is_true, return_true),
    ])(True) == False

    assert cond([
        (is_true, return_false),
        (is_true, return_true),
    ])(False) == False



# Generated at 2022-06-21 19:49:47.886267
# Unit test for function identity
def test_identity():
    assert identity('test') == 'test'
    assert identity(2) == 2



# Generated at 2022-06-21 19:49:50.480039
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x > 0, lambda x: "Positive"),
        (lambda x: x < 0, lambda x: "Negative"),
        (lambda x: x == 0, lambda x: "Zero"),
    ])(-1) == "Negative"

# Generated at 2022-06-21 19:49:56.721598
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2
    assert increase(123) == 124
    assert increase(-123) == -122
    assert increase(-1) == 0
    assert increase(-0) == 1
    assert increase(0.0) == 1.0
    assert increase(1.0) == 2.0
    assert increase(123.0) == 124.0
    assert increase(-123.0) == -122.0
    assert increase(-1.0) == 0.0
    assert increase(-0.0) == 1.0



# Generated at 2022-06-21 19:50:01.124481
# Unit test for function pipe
def test_pipe():
    assert pipe(
        'test',
        lambda text: text.capitalize(),
        lambda text: map(lambda letter: chr(ord(letter) + 5), text)
    ) == ['Y', 'I', 'X', 'X']



# Generated at 2022-06-21 19:50:09.033669
# Unit test for function curry
def test_curry():
    curried_add_two_numbers = curry(
        lambda number1, number2: number1 + number2
    )
    assert curried_add_two_numbers(1)(2) == 3
    assert curried_add_two_numbers(1) == curry(
        lambda number1: 1 + number1
    )
    assert curried_add_two_numbers == curry(
        lambda number1, number2: number1 + number2
    )



# Generated at 2022-06-21 19:50:17.095229
# Unit test for function curried_filter
def test_curried_filter():

    # Function to test curried_filter
    def curried_filterTest(collection, filterer):
        return curried_filter(filterer)(collection)

    # Check function curried_filter with arguments collection and filterer
    assert curried_filterTest([1, 2, 3], lambda x: x > 2) == [3]
    assert curried_filterTest([1, 2, 3], lambda x: x < 2) == [1]
    assert curried_filterTest([1, 2, 3], lambda x: x == 2) == [2]



# Generated at 2022-06-21 19:50:22.824465
# Unit test for function curried_map
def test_curried_map():
    """
    Test function curried_map

    :returns:
    :rtype:
    """
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == \
           curried_map(lambda x: x + 1)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    assert curried_map(lambda x: x + 1)([1, 2, 3])([4, 5, 6]) == [2, 3, 4, 5, 6, 7]

# Generated at 2022-06-21 19:50:23.885039
# Unit test for function identity
def test_identity():
    assert identity(1) == 1


# Generated at 2022-06-21 19:50:26.482902
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)(list(range(3))) == [0, 1, 2]



# Generated at 2022-06-21 19:50:31.993339
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4], lambda x: x == 5) is None
    assert find([1, 2, 3, 4], lambda x: x == 4) == 4
    assert find([1, 2, 3, 4], lambda x: x == 2) == 2



# Generated at 2022-06-21 19:50:52.748394
# Unit test for function curry
def test_curry():
    assert curry(identity)(1) == 1
    assert curry(increase)(1) == 2



# Generated at 2022-06-21 19:50:54.652550
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3


# Generated at 2022-06-21 19:51:00.741787
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y, 2)('Hello', 'world') == 'Helloworld'
    assert curry(lambda x, y: x + y, 1)('Hello')('world') == 'Helloworld'
    assert curry(lambda x, y: x + y)('Hello')('world') == 'Helloworld'
    assert curry(lambda x, y, z: x + y + z)('Hello')('world')('!!!') == 'Helloworld!!!'



# Generated at 2022-06-21 19:51:09.421485
# Unit test for function curry
def test_curry():
    '''
    Tests for curry function
    '''
    assert curry(lambda x: x)(1) == 1
    assert curry(lambda x, y: x + y)(2)(2) == 4
    assert curry(lambda x, y, z: x + y + z)(2)(2)(3) == 7
    assert curry(lambda x, y, z: x + y + z)(2, 2)(3) == 7
    assert curry(lambda x, y, z: x + y + z)(2, 2, 3) == 7



# Generated at 2022-06-21 19:51:13.681359
# Unit test for function compose
def test_compose():
    assert compose(0, increase, increase, increase) == 3
    assert compose(0, increase, increase) == 2
    assert compose(0, identity, increase) == 1
    assert compose(0, identity, identity) == 0
    assert compose(0, lambda a: a * a * a, lambda a: a + 1) == 1



# Generated at 2022-06-21 19:51:16.959851
# Unit test for function curry
def test_curry():
    add = lambda x, y: x + y
    add_five = curry(add)(5)
    assert add_five(3) == 8



# Generated at 2022-06-21 19:51:18.563358
# Unit test for function curried_map
def test_curried_map():
    assert [2, 4, 6] == curried_map(increase)([1, 2, 3])



# Generated at 2022-06-21 19:51:19.878683
# Unit test for function compose
def test_compose():
    assert compose(1, str, increase) == '2'



# Generated at 2022-06-21 19:51:25.477508
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6



# Generated at 2022-06-21 19:51:30.423105
# Unit test for function find
def test_find():
    empty_dict = []
    print(find(empty_dict, lambda x: x == 1))
    assert find(empty_dict, lambda x: x == 1) is None

    dict_to_search = [1, 2, 3, 4]
    print(find(dict_to_search, lambda x: x == 2))
    assert find(dict_to_search, lambda x: x == 2) == 2


# Generated at 2022-06-21 19:51:57.678380
# Unit test for function memoize
def test_memoize():
    import unittest
    from operator import add
    from random import randint

    class Test(unittest.TestCase):
        def test_memoize(self):
            memoized_add = memoize(add)
            self.assertEqual(memoized_add(1, 2), 3)
            self.assertEqual(len(memoized_add.__closure__[0].cell_contents), 1)
            self.assertEqual(memoized_add(1, 2), 3)
            self.assertEqual(len(memoized_add.__closure__[0].cell_contents), 1)

            def check_number(number):
                return number < 0

            memoized_check_number = memoize(check_number)

# Generated at 2022-06-21 19:52:00.732900
# Unit test for function identity
def test_identity():
    assert identity(42) == 42
    # Identity is pure
    assert identity(42) == identity(42)



# Generated at 2022-06-21 19:52:05.423715
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b, c: a + b + c)(1)(2, 3) == 6
    assert curry(lambda a, b, c: a + b + c)(1, 2)(3) == 6
    assert curry(lambda a, b, c: a + b + c)(1, 2, 3) == 6



# Generated at 2022-06-21 19:52:06.801017
# Unit test for function pipe
def test_pipe():
    assert pipe(increase(0), increase) == 2
    assert pipe(2, increase) == 3


# Generated at 2022-06-21 19:52:08.628753
# Unit test for function cond
def test_cond():
    assert pipe(True, cond([
        (eq(False), increase),
        (eq(True), identity),
    ])) == True



# Generated at 2022-06-21 19:52:11.193027
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-21 19:52:21.101198
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(1, "1")
    assert eq("1", "1")
    assert eq((1, 2, 3), (1, 2, 3))
    assert not eq((1, 2, 3), (1, 2, 4))
    assert eq([1, 2, 3], [1, 2, 3])
    assert not eq([1, 2, 3], [1, 2, 4])
    assert not eq(1, (1,))
    assert not eq(1, [1])
    assert not eq([1], [1, 2])
    assert not eq([1, ], [1])



# Generated at 2022-06-21 19:52:23.248752
# Unit test for function compose
def test_compose():
    test_list = [1, 2, 3, 4]
    value = compose(1, increase, increase)
    assert value == 3



# Generated at 2022-06-21 19:52:25.435863
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda value: value + 5, [1, 2, 3]) == [6, 7, 8]


# Generated at 2022-06-21 19:52:26.319098
# Unit test for function increase
def test_increase():
    assert increase(1) == 2

# Generated at 2022-06-21 19:53:04.543780
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-21 19:53:06.218858
# Unit test for function identity
def test_identity():
    assert identity(1) == 1, 'identity should return arg of function'


# Generated at 2022-06-21 19:53:07.032139
# Unit test for function increase
def test_increase():
    assert increase(2) == 3


# Generated at 2022-06-21 19:53:10.120424
# Unit test for function curried_map
def test_curried_map():
    from functools import partial
    map_increase = partial(curried_map, increase)
    print(list(map_increase(range(10))))
    print(list(map(map_increase, [[1, 2, 3], [], range(10)])))



# Generated at 2022-06-21 19:53:11.645762
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4]) == [2, 4]



# Generated at 2022-06-21 19:53:14.058750
# Unit test for function eq
def test_eq():
    assert eq(2, 2)


# Generated at 2022-06-21 19:53:18.520843
# Unit test for function eq
def test_eq():
    assert eq(4,4) == True
    assert eq(4,5) == False
    assert eq(4,4)(4) == True
    assert eq(4,5)(5) == False
    assert eq(4)(4) == True
    assert eq(4)(5) == False


# Generated at 2022-06-21 19:53:24.558881
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3, 'curry(lambda x, y: x + y)(1)(2) == 3'
    f = curry(lambda x, y, z: x + y + z, 3)
    g = curry(lambda x, y, z: x * y * z, 2)
    assert f(1, 2, 3) == 6, 'f(1, 2, 3) == 6'
    assert f(1, 2)(3) == 6, 'f(1, 2)(3) == 6'
    assert g(4)(5) == 20, 'g(4)(5) == 20'



# Generated at 2022-06-21 19:53:30.368934
# Unit test for function memoize
def test_memoize():
    def test(x):
        if x == 2:
            return 1
        return 0
    # expected 0
    print(memoize(test, key=lambda x, y: x == 2)(2))
    # expected 0
    print(memoize(test)(3))
    # expected 0
    print(memoize(test)(3))



# Generated at 2022-06-21 19:53:35.435552
# Unit test for function eq
def test_eq():
    eq_values = [('a', 'a', True),
                 ('a', 'b', False),
                 ('a', 1, False),
                 ('a', 'A', False)]

    for first, second, expected_result in eq_values:
        assert expected_result == eq(first, second)


# Generated at 2022-06-21 19:54:14.946157
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(2)(2) == 4


# Generated at 2022-06-21 19:54:19.229412
# Unit test for function memoize
def test_memoize():
    """
    Unit test for function memoize
    """

    @memoize
    def summ(a, b):
        return (a + b)

    assert summ(3, 7) == 10



# Generated at 2022-06-21 19:54:21.049969
# Unit test for function pipe
def test_pipe():
    assert pipe(1)(increase)(increase)(increase)(identity) == 4



# Generated at 2022-06-21 19:54:22.235861
# Unit test for function compose
def test_compose():
    """
    This function test correctness of function compose
    """
    assert compose(1, increase) == 2



# Generated at 2022-06-21 19:54:24.098701
# Unit test for function pipe
def test_pipe():
    assert pipe(2, lambda x: x + 1, lambda x: x + 2) == 5

    return True



# Generated at 2022-06-21 19:54:25.633445
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(True) is True
    assert identity('X') == 'X'


# Generated at 2022-06-21 19:54:26.640470
# Unit test for function pipe
def test_pipe():
    assert pipe(3, increase, increase) == 5



# Generated at 2022-06-21 19:54:28.038418
# Unit test for function eq
def test_eq():
    """
    Test function eq.
    """
    assert eq(4, 5) is False
    assert eq(4, 4)



# Generated at 2022-06-21 19:54:33.180757
# Unit test for function cond
def test_cond():
    is_even = lambda x: x % 2 == 0
    is_odd = lambda x: x % 2 != 0

    assert cond([
        (is_even, identity),
        (is_odd, increase)
    ])(1) == 2
    assert cond([
        (is_even, identity),
        (is_odd, increase)
    ])(2) == 2



# Generated at 2022-06-21 19:54:35.592327
# Unit test for function curried_filter
def test_curried_filter():
    val = curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4])
    assert val == [2, 4]

# Generated at 2022-06-21 19:55:29.570907
# Unit test for function curry
def test_curry():
    assert curry(increase)(2) == 3
    assert curry(increase, 1)(2) == 3
    assert curry(increase, 1)("a") == "aa"
    assert curry(increase, 2)("a") == "aaa"



# Generated at 2022-06-21 19:55:36.172648
# Unit test for function curried_map
def test_curried_map():
    assert [2, 3, 4] == curried_map(increase, [1, 2, 3])
    assert [2, 3, 4] == curried_map(increase)([1, 2, 3])
    assert [2, 3, 4] == curried_map(increase, [1, 2, 3])
    assert [2, 3, 4] == curried_map(increase)([1, 2, 3])


# Generated at 2022-06-21 19:55:41.164641
# Unit test for function compose
def test_compose():
    assert compose(0, lambda x: x + 1, lambda x: x * 3)(0) == 3, "compose should return 3"

    assert compose(5, lambda x: x + 1, lambda x: x + 1, lambda x: x * 3)(0) == 18, \
        "compose with 3 functions should return 18"



# Generated at 2022-06-21 19:55:42.651198
# Unit test for function memoize
def test_memoize():
    @memoize
    def add(x):
        return x + 10

    assert add(10) == add(10)

# Generated at 2022-06-21 19:55:43.358430
# Unit test for function increase
def test_increase():
    assert increase(3) == 4



# Generated at 2022-06-21 19:55:54.595244
# Unit test for function curry
def test_curry():
    """Test function curry"""
    # Example curried function
    curried_function = lambda a: lambda b: a + b
    # curried_function(1)(2)
    assert curried_function(1)(2) == curry(curried_function, 2)(1, 2)
    # curried_function(2)(1)
    assert curried_function(2)(1) == curry(curried_function, 2)(2, 1)
    # curried_function(1)(1)
    assert curried_function(1)(1) == curry(curried_function, 2)(1, 1)
    # curried_function(2)(2)
    assert curried_function(2)(2) == curry(curried_function, 2)(2, 2)



# Generated at 2022-06-21 19:55:55.386556
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-21 19:55:56.189439
# Unit test for function increase
def test_increase():
    assert increase(3) == 4



# Generated at 2022-06-21 19:55:59.089089
# Unit test for function curry
def test_curry():
    def g(a, b, c):
        return a * b * c

    h = curry(g, 3)

    assert h(1)(2)(3) == 6
    assert h(1, 2)(3) == 6



# Generated at 2022-06-21 19:56:04.934326
# Unit test for function memoize
def test_memoize():
    add = lambda x, y: x + y
    mem_add = memoize(add)
    assert mem_add(2, 3) == 5
    assert mem_add(5, 5) == 10
    assert mem_add(2, 3) == 5



# Generated at 2022-06-21 19:56:40.836516
# Unit test for function pipe
def test_pipe():
    """
    Test if pipe works correctly
    """
    assert pipe(1, increase, identity) == 2
    assert pipe(2, increase, increase, increase) == 5
    assert pipe(1, identity, identity, identity) == 1


# Generated at 2022-06-21 19:56:47.431130
# Unit test for function pipe
def test_pipe():
    assert pipe(
        0,
        lambda x: x + 1,
        lambda x: x + 1
    ) == 2
    assert pipe(
        0,
        curried_map(lambda x: x + 1),
        curried_map(lambda x: x + 1)
    ) == [2, 2]
    assert pipe(
        0,
        lambda x: x + 1,
        curried_map(lambda x: x + 1)
    ) == [2]



# Generated at 2022-06-21 19:56:49.218797
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert eq('a', 'a')



# Generated at 2022-06-21 19:56:56.272237
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x == 'A', increase),
        (lambda x: x == 'B', increase)
    ])('A') == 2
    assert cond([
        (lambda x: x == 'A', increase),
        (lambda x: x == 'B', increase)
    ])('B') == 2
    assert cond([
        (lambda x: x == 'A', increase),
        (lambda x: x == 'B', increase)
    ])('C') is None


# Generated at 2022-06-21 19:56:57.836400
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False



# Generated at 2022-06-21 19:57:03.739214
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda _: True, lambda _: 1),
        (lambda _: False, lambda _: 2)
    ])(1) == 1
    assert cond([
        (lambda _: False, lambda _: 1),
        (lambda _: True, lambda _: 2)
    ])(1) == 2



# Generated at 2022-06-21 19:57:10.589999
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x == 'foo', lambda x: 'foo'),
        (lambda x: x == 'bar', lambda x: 'bar'),
    ])('foo') == 'foo'

    assert cond([
        (lambda x: x == 'foo', lambda x: 'foo'),
        (lambda x: x == 'bar', lambda x: 'bar'),
    ])('bar') == 'bar'

    assert cond([
        (lambda x: x == 'foo', lambda x: 'foo'),
        (lambda x: x == 'bar', lambda x: 'bar'),
    ])('baz') is None

