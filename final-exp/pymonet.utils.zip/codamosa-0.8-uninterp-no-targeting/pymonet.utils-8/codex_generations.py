

# Generated at 2022-06-21 19:47:25.839512
# Unit test for function cond
def test_cond():
    def add(x, y):
        return x + y

    def multiply(x, y):
        return x * y

    def math_fn(x, y):
        return cond([
            (lambda a, b: b == 0, lambda a, b: a),
            (lambda a, b: b % 2 == 1, lambda a, b: multiply(math_fn(x, b - 1), a)),
            (lambda a, b: True, lambda a, b: multiply(add(a, a), math_fn(x, b / 2)))
        ])(x, y)

    assert math_fn(3, 2) == 6
    assert math_fn(3, 3) == 27
    assert math_fn(3, 0) == 3
    assert math_fn(3, 4) == 81



# Generated at 2022-06-21 19:47:26.861389
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-21 19:47:29.823866
# Unit test for function increase
def test_increase():
    """Test case for function increase."""
    assert increase(1) == 2, "Increase by 1"
    assert increase(5) == 6, "Increase by 1"



# Generated at 2022-06-21 19:47:31.804305
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(0) == 1
    assert increase(10) == 11



# Generated at 2022-06-21 19:47:35.513812
# Unit test for function pipe
def test_pipe():
    result_one = pipe(
        1,
        lambda value: value + 1,
        lambda value: value * 2
    )
    assert result_one == 4, "First test"

    result_two = pipe(
        1,
        lambda value: value + 1,
        lambda value: value * 2,
        lambda value: value + 2
    )
    assert result_two == 6, "Second test"



# Generated at 2022-06-21 19:47:37.658528
# Unit test for function compose
def test_compose():
    assert compose(2, identity, increase) == 3
    assert compose(None, identity, increase) is None



# Generated at 2022-06-21 19:47:40.617823
# Unit test for function compose
def test_compose():
    assert compose(1, identity, increase) == 2
    assert compose(1, increase, identity) == 2



# Generated at 2022-06-21 19:47:41.301965
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:47:48.034983
# Unit test for function cond
def test_cond():
    def first_condition(x):
        return x > 0

    def first_execute(x):
        return x * 2

    def second_condition(x):
        return x == 0

    def second_execute(x):
        return 1

    def third_condition(x):
        return x < 0

    def third_execute(x):
        return -x

    execute_function = cond([
        (first_condition, first_execute),
        (second_condition, second_execute),
        (third_condition, third_execute),
    ])

    assert execute_function(2) == 4
    assert execute_function(0) == 1
    assert execute_function(-2) == 2



# Generated at 2022-06-21 19:47:50.336384
# Unit test for function identity
def test_identity():
    assert identity(1) == 1


# Generated at 2022-06-21 19:47:56.790536
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity('string') == 'string'



# Generated at 2022-06-21 19:47:59.531694
# Unit test for function pipe
def test_pipe():
    assert pipe(
        'test',
        lambda x: x.upper(),
        lambda x: f'{x}2',
    ) == 'TEST2'



# Generated at 2022-06-21 19:48:01.541005
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3



# Generated at 2022-06-21 19:48:02.673903
# Unit test for function increase
def test_increase():
    assert increase(1) == 2


# Generated at 2022-06-21 19:48:11.053147
# Unit test for function curry
def test_curry():
    def add(a, b, c, d):
        return a + b + c + d
    add_curry = curry(add, 4)

    assert add_curry(1, 2, 3, 4) == 10
    assert add_curry(1, 2)(3)(4) == 10
    assert add_curry(1)(2)(3)(4) == 10
    assert add_curry(1)(2)(3, 4) == 10
    assert add_curry(1)(2, 3, 4) == 10
    assert add_curry(1, 2, 3)(4) == 10
    assert add_curry(1, 2, 3, 4) == 10
    assert curry(lambda a, b, c: a + b + c, 3)(1)(2)(3) == 6

# Generated at 2022-06-21 19:48:12.092631
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:48:14.141966
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x % 2 == 0) == 2



# Generated at 2022-06-21 19:48:17.699055
# Unit test for function curried_map
def test_curried_map():
    testMap = curried_map(lambda x: x * 2)
    assert testMap([1, 2, 3]) == [2, 4, 6]


# Generated at 2022-06-21 19:48:25.059227
# Unit test for function curry
def test_curry():
    add_two = curry(lambda a, b: a + b)
    add_three = curry(lambda a, b, c: a + b + c)
    assert add_two(2, 3) == 5
    assert add_two(2) == curry(lambda b: 2 + b, 1)
    assert add_three(2, 3, 4) == 9
    assert add_three(2, 3) == curry(lambda c: 2 + 3 + c)
    assert add_three(2) == curry(lambda b, c: 2 + b + c, 2)



# Generated at 2022-06-21 19:48:26.179409
# Unit test for function eq
def test_eq():
    assert eq(5)(5)



# Generated at 2022-06-21 19:48:31.984146
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:48:34.329325
# Unit test for function identity
def test_identity():
    assert identity(5) == 5
    assert identity(True) is True
    assert identity(None) is None


# Generated at 2022-06-21 19:48:35.349996
# Unit test for function eq
def test_eq():
    assert bool(eq(4,4)()), 'Eq does not return true for the same arguments'


# Generated at 2022-06-21 19:48:38.153519
# Unit test for function compose
def test_compose():
    print("Test compose")
    assert compose("hello", lambda x: x.upper(), lambda x: x + '!', lambda x: x[0]) == 'H!'
    assert compose("hello", lambda x: x[0]) == 'h'


# Generated at 2022-06-21 19:48:43.219656
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 3, [1, 2, 3])(2) == [3, 4, 5]



# Generated at 2022-06-21 19:48:45.867248
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(1) == 2
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6



# Generated at 2022-06-21 19:48:48.313126
# Unit test for function compose
def test_compose():
    assert compose(2, increase, increase) == 4



# Generated at 2022-06-21 19:48:49.461455
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:48:53.603937
# Unit test for function pipe
def test_pipe():
    assert (
            pipe(
                5,
                increase,
                compose(
                    curried_map(increase),
                    list
                ),
                curried_map(increase)
            ) == [7, 7, 7, 7, 7]
    )

# Generated at 2022-06-21 19:48:56.784532
# Unit test for function eq
def test_eq():
    assert True is eq(True, True)



# Generated at 2022-06-21 19:48:59.855176
# Unit test for function increase
def test_increase():
    assert increase(2) == 3


# Generated at 2022-06-21 19:49:02.541476
# Unit test for function find
def test_find():
    assert find([1,2,3], lambda x: x == 2) == 2
    assert find([1,2,3], lambda x: x == 4) is None



# Generated at 2022-06-21 19:49:04.372033
# Unit test for function eq
def test_eq():
    assert eq(2, 3) is False
    assert eq(2, 2) is True



# Generated at 2022-06-21 19:49:05.373659
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-21 19:49:07.096463
# Unit test for function identity
def test_identity():
    assert identity(1) == 1


# Generated at 2022-06-21 19:49:11.821808
# Unit test for function find
def test_find():
    assert find(
        [],
        lambda x: True
    ) is None, 'Should return None when empty collection'

    assert find(
        [1, 2, 3],
        lambda x: x == 1
    ) == 1, 'Should return 1'

    assert find(
        [1, 2, 3],
        lambda x: x > 2
    ) == 3, 'Should return 3'

    assert find(
        [1, 2, 3],
        lambda x: x > 4
    ) is None, 'Should return None'


# Test for function cond

# Generated at 2022-06-21 19:49:15.409525
# Unit test for function curried_filter
def test_curried_filter():
    res = curried_filter(lambda x: x % 2 == 0, [1, 4, 5, 6, 7, 8, 9, 10])
    assert res == [4, 6, 8, 10]


# Generated at 2022-06-21 19:49:26.612474
# Unit test for function curried_map
def test_curried_map():
    add_one = curried_map(increase)
    assert [2, 3, 4, 5] == add_one([1, 2, 3, 4])


if __name__ == '__main__':
    # Unit test for function curried_map
    test_curried_map()

    # Unit test for function curried_filter
    assert [2, 4] == curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4])

    # Unit test for curry function
    assert curry(lambda x, y, z: x + y + z, 3)(1, 2, 3) == 6

    # Unit test for function identity
    assert identity(1) == 1

    # Unit test for function increase
    assert increase(1) == 2

    # Unit test for function eq

# Generated at 2022-06-21 19:49:32.648690
# Unit test for function compose
def test_compose():
    # https://youtu.be/mFidV_dF1So?t=9m55s
    assert compose(3, lambda x: x + 1, lambda x: x * 2) == 8
    assert compose(3, lambda x: x * 2, lambda x: x + 1) == 7



# Generated at 2022-06-21 19:49:41.295614
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda value: value == 1) == 1
    assert find([1, 2, 3, 4], lambda value: value == 2) == 2
    assert find([1, 2, 3, 4], lambda value: value == 3) == 3
    assert find([1, 2, 3, 4], lambda value: value == 4) == 4
    assert find([1, 2, 3, 4], lambda value: value == 0) is None
    assert find([1, 2, 3, 4], lambda value: value == 5) is None



# Generated at 2022-06-21 19:49:49.866904
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [2, 3]) == [2, 3]
    assert curried_map(increase, [2, 3]) == [3, 4]
    assert curried_map(increase)([2, 3]) == [3, 4]



# Generated at 2022-06-21 19:49:54.229017
# Unit test for function compose
def test_compose():
    def add_a(x: str) -> str:
        return x + 'a'

    def add_b(x: str) -> str:
        return x + 'b'

    assert compose('', add_b, add_a) == 'ab'
    assert compose('', add_a, add_b) == 'ba'



# Generated at 2022-06-21 19:50:01.901120
# Unit test for function cond
def test_cond():
    def f1(a):
        return a > 0

    def f2(a):
        return a + 2

    def f3(a):
        return a + 3

    def f4(a):
        return a + 4

    fn = cond([(f1, f2), (f1, f3), (f1, f4)])
    assert(fn(1) == 3)
    assert(fn(0) == 5)

# Generated at 2022-06-21 19:50:04.116603
# Unit test for function curried_filter
def test_curried_filter():
    test_list = [1, 2, 3]

    curried_filter_test = curried_filter(increase)
    result = curried_filter_test(test_list)

    assert test_list == [1, 2, 3]
    assert result == [2, 3, 4]



# Generated at 2022-06-21 19:50:05.445267
# Unit test for function eq
def test_eq():
    assert eq(1)(1) == True



# Generated at 2022-06-21 19:50:14.074280
# Unit test for function curry
def test_curry():
    # pylint: disable=invalid-name
    mul_three = curry(lambda x, y, z: x * y * z)
    assert mul_three(1, 2, 3) == 6
    assert mul_three(1, 2)(3) == 6
    assert mul_three(1)(2)(3) == 6
    assert mul_three(1)(2, 3) == 6
    assert mul_three(1, 2, 3) == 6



# Generated at 2022-06-21 19:50:19.456983
# Unit test for function pipe
def test_pipe():
    from unittest import TestCase

    class TestPipe(TestCase):
        def test_pipe(self):
            test_input1 = 'input'
            fn1 = lambda x: x + '1'
            fn2 = lambda x: x + '2'
            self.assertEqual(pipe(test_input1, fn1, fn2), 'input12')

    TestPipe().test_pipe()



# Generated at 2022-06-21 19:50:22.399045
# Unit test for function pipe
def test_pipe():
    from math import pi, sin

    assert pipe(1, identity, increase, lambda value: value * pi, sin) == sin(pi * increase(identity(1)))



# Generated at 2022-06-21 19:50:26.570548
# Unit test for function curried_map
def test_curried_map():
    """
    Test case

    :returns: Test status
    :rtype: Boolean
    """
    if curried_map(lambda x: x + 1)([1, 2, 3]) != [2, 3, 4]:
        return False

    return True

# Generated at 2022-06-21 19:50:27.908745
# Unit test for function increase
def test_increase():
    assert increase(20) == 21
    assert increase(7) == 8



# Generated at 2022-06-21 19:50:34.160021
# Unit test for function compose
def test_compose():
    assert compose(
        0,
        lambda value: value + 1,
        lambda value: value + 2
    ) == 3


# Generated at 2022-06-21 19:50:40.854868
# Unit test for function curry
def test_curry():
    assert compose(
        3,
        curried_map(increase),
        curried_filter(lambda x: x % 2 == 0)
    ) == 2

    assert compose(
        [1, 2, 3],
        pipe,
        curried_map(increase),
        curried_filter(lambda x: x % 2 == 0),
        curried_map(increase),
        curried_map(increase),
        curried_map(increase)
    ) == [6, 8]



# Generated at 2022-06-21 19:50:42.134906
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 3, 4]
    function = lambda value: value % 2 == 0
    assert curried_filter(function)(collection) == [2, 4]


# Generated at 2022-06-21 19:50:50.384899
# Unit test for function curried_map
def test_curried_map():
    def add_one(x):
        return x + 1

    def add(x, y):
        return x + y

    double = curried_map(lambda x: x * 2)
    assert(double([1, 2, 3]) == [2, 4, 6])

    map_add_one = curried_map(add_one)
    assert(map_add_one([1, 2, 3]) == [2, 3, 4])

    map_add = curried_map(add)
    assert(map_add([1, 2, 3], [4, 5, 6]) == [5, 7, 9])



# Generated at 2022-06-21 19:51:00.922499
# Unit test for function memoize
def test_memoize():
    result = []

    @memoize
    def memoized_fn(argument):
        result.append(argument)
        return len(result)

    assert memoized_fn(1) == 1
    assert memoized_fn(1) == 1
    assert memoized_fn(2) == 2
    assert memoized_fn(1) == 1
    assert memoized_fn(2) == 2
    assert memoized_fn(3) == 3
    assert memoized_fn(1) == 1
    assert memoized_fn(2) == 2
    assert memoized_fn(3) == 3
    assert memoized_fn(2) == 2
    assert memoized_fn(1) == 1
    assert memoized_fn(2) == 2



# Generated at 2022-06-21 19:51:06.423154
# Unit test for function memoize
def test_memoize():
    def to_upper(argument):
        print("hello")
        return argument.upper()

    memoized = memoize(to_upper)

    print(memoized("Hello"))
    print(memoized("World"))

    print(memoized("Hello"))
    print(memoized("World"))



# Generated at 2022-06-21 19:51:11.910765
# Unit test for function cond
def test_cond():
    assert cond([(lambda x: x < 10, lambda x: str(x) + " < 10")])(0) == "0 < 10"
    assert cond([
        (lambda x: x < 10, lambda x: str(x) + " < 10"),
        (lambda x: x > 10, lambda x: str(x) + " > 10")
    ])(20) == "20 > 10"



# Generated at 2022-06-21 19:51:17.884597
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x % 2 == 0) == 2
    assert find(range(20), lambda x: x == 10) == 10
    assert find(list(range(20)), lambda x: x == 10) == 10
    assert find(range(20), lambda x: x > 1000) is None
    assert find([], lambda x: True) is None



# Generated at 2022-06-21 19:51:25.677177
# Unit test for function cond
def test_cond():
    def gt5(x: int) -> bool:
        return x > 5

    def sqr(x: int) -> int:
        return x * x

    def cube(x: int) -> int:
        return x * x * x

    result = cond([
        [gt5, sqr],
        [identity, cube],
    ])(4)
    assert result == 16

    result = cond([
        [gt5, sqr],
        [identity, cube],
    ])(9)
    assert result == 81


test_cond()

# Generated at 2022-06-21 19:51:27.120525
# Unit test for function increase
def test_increase():
    assert increase(3) == 4, "increase"



# Generated at 2022-06-21 19:51:37.984508
# Unit test for function curried_filter
def test_curried_filter():

    assert curried_filter(eq(2))([1, 2, 3]) == [2]
    assert curried_filter(eq(4))([1, 2, 3]) == []


# Generated at 2022-06-21 19:51:40.268028
# Unit test for function pipe
def test_pipe():
    """
    Unit test for function pipe.
    """
    assert pipe(2,
                increase,
                increase) == 4



# Generated at 2022-06-21 19:51:42.004676
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)


# Generated at 2022-06-21 19:51:43.773623
# Unit test for function pipe
def test_pipe():
    assert pipe(10, increase, identity) == 11
    assert pipe(10, increase, increase) == 12


test_pipe()



# Generated at 2022-06-21 19:51:49.640260
# Unit test for function increase
def test_increase():
    expected = 5
    actual = decrease(6)

    assert expected == actual, "Expected {0}, but got {1}".format(expected, actual)


if __name__ == "__main__":
    print(curry(increase)(1))
    print(curry(identity)(1))
    test_increase()

# Generated at 2022-06-21 19:51:52.476761
# Unit test for function curry
def test_curry():
    def add(x, y, z):
        return x + y + z

    result = curry(add)(1)(2)(3)
    assert result == 6



# Generated at 2022-06-21 19:51:53.671970
# Unit test for function compose
def test_compose():
    assert compose(1, increase, increase, increase) == 4


# Generated at 2022-06-21 19:52:05.318781
# Unit test for function memoize
def test_memoize():
    import unittest
    import random
    import string

    class TestMemoize(unittest.TestCase):
        def test_memoize_with_random(self):
            random_list = [
                random.choice(string.ascii_letters)
                for random_idx in range(random.randint(1, 100))
            ]

            @memoize
            def random_f(argument):
                return random.choice(random_list)

            random_dict = {
                argument: random_f(argument)
                for argument in random_list
            }

            for argument in random_list:
                self.assertEqual(random_f(argument), random_dict.get(argument))


# Generated at 2022-06-21 19:52:08.677001
# Unit test for function curry
def test_curry():
    def add(first, second):
        return first + second

    curried_add = curry(add)
    assert curried_add(1)(2) == curried_add(1, 2)
    assert curried_add(1)(2) == 3



# Generated at 2022-06-21 19:52:10.992229
# Unit test for function increase
def test_increase():

    assert(increase(1) == 2)



# Generated at 2022-06-21 19:52:22.107218
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-21 19:52:24.659272
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], eq(3)) == 3
    assert find([1, 2, 3, 4, 5], eq(10)) is None



# Generated at 2022-06-21 19:52:27.216750
# Unit test for function compose
def test_compose():
    composed_function = compose(1, lambda x: x + 1, lambda x: x + 2)
    assert composed_function == 4

    composed_function = compose(1, lambda x: x + 1, lambda x: x + 2, lambda x: x + 3)
    assert composed_function == 7



# Generated at 2022-06-21 19:52:30.056416
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x * 2)([1, 2, 3]) == [2, 4, 6]
    assert curried_map(lambda x: x * 2, [1, 2, 3]) == [2, 4, 6]



# Generated at 2022-06-21 19:52:31.895778
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(0))([1, 2, 3, 0]) == [0]



# Generated at 2022-06-21 19:52:34.398343
# Unit test for function compose
def test_compose():
    compose_test = compose(1, increase, increase, increase)
    assert compose_test == 4



# Generated at 2022-06-21 19:52:36.519139
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-21 19:52:46.841101
# Unit test for function cond
def test_cond():
    """
    Test function cond

    :returns: result of testing
    :rtype: Boolean
    """
    assert cond([
        (lambda x: x == 0,
         lambda x: 'Zero'),
        (lambda x: x % 2 == 0,
         lambda x: 'Even'),
        (lambda x: x % 2 != 0,
         lambda x: 'Odd'),
    ])(0) == 'Zero'
    assert cond([
        (lambda x: x == 0,
         lambda x: 'Zero'),
        (lambda x: x % 2 == 0,
         lambda x: 'Even'),
        (lambda x: x % 2 != 0,
         lambda x: 'Odd'),
    ])(1) == 'Odd'

# Generated at 2022-06-21 19:52:48.274675
# Unit test for function compose
def test_compose():
    assert 3 == compose(2, increase, increase, increase)



# Generated at 2022-06-21 19:52:51.247369
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2
    assert increase(10) == 11
    assert increase(100) == 101



# Generated at 2022-06-21 19:53:00.602922
# Unit test for function pipe
def test_pipe():
    assert pipe(
        2,
        increase,
        lambda x: x * x
    ) == 9


# Generated at 2022-06-21 19:53:05.323664
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x < 2)([1, 2, 3]) == [1]
    assert curried_filter(lambda x: x > 2)([1, 2, 3]) == [3]
    assert curried_filter(lambda x: x > 1, [1, 2, 3]) == [2, 3]



# Generated at 2022-06-21 19:53:06.725538
# Unit test for function increase
def test_increase():
    assert increase(5) == 6
    print("Test: test_increase() - success!")



# Generated at 2022-06-21 19:53:10.417396
# Unit test for function curried_map
def test_curried_map():
    # Mapping
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]

    # curried Mapping
    addOne = curried_map(lambda x: x + 1)
    assert addOne([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-21 19:53:15.976338
# Unit test for function compose
def test_compose():
    assert eq(2, compose(1, increase))
    assert eq(3, compose(1, increase, increase))
    assert eq(4, compose(1, increase, increase, increase))
    assert eq(5, compose(1, increase, increase, increase, increase))
    assert eq(6, compose(1, increase, increase, increase, increase, increase))
    assert eq(7, compose(1, increase, increase, increase, increase, increase, increase))
    assert eq(8, compose(1, increase, increase, increase, increase, increase, increase, increase))
    assert eq(9, compose(1, increase, increase, increase, increase, increase, increase, increase, increase))
    assert eq(10, compose(1, increase, increase, increase, increase, increase, increase, increase, increase, increase))



# Generated at 2022-06-21 19:53:24.399060
# Unit test for function memoize
def test_memoize():
    from random import randint
    random_numbers = [randint(1, 100000) for _ in range(100)]

    is_even = lambda x: x % 2 == 0
    is_odd = lambda x: not is_even(x)

    even_memoizer = memoize(is_even)
    even_counter = 0
    for number in random_numbers:
        if even_memoizer(number):
            even_counter += 1

    assert even_counter == len(list(filter(is_even, random_numbers)))

    odd_memoizer = memoize(is_odd)
    odd_counter = 0
    for number in random_numbers:
        if odd_memoizer(number):
            odd_counter += 1


# Generated at 2022-06-21 19:53:26.481747
# Unit test for function pipe
def test_pipe():
    my_func = pipe(increase, increase)
    assert my_func(5) == 7



# Generated at 2022-06-21 19:53:29.238663
# Unit test for function pipe
def test_pipe():
    assert pipe(2, increase, increase) == 4, "Failed pipe test"



# Generated at 2022-06-21 19:53:31.529313
# Unit test for function curry
def test_curry():
    def sum_two(a, b):
        return a + b

    assert curry(sum_two, 2)(1, 2) == 3



# Generated at 2022-06-21 19:53:34.482024
# Unit test for function eq
def test_eq():
    eq1 = eq(1)
    assert eq1(1)
    assert not eq1(2)

# Generated at 2022-06-21 19:53:44.425797
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-21 19:53:49.916951
# Unit test for function cond
def test_cond():
    def func_1(x: int) -> Any:
        return x

    def func_2(x: int) -> Any:
        return x

    assert cond([
        (lambda x: x > 2, func_1),
        (lambda x: x < 0, func_2),
    ])(-5) == -5



# Generated at 2022-06-21 19:53:56.834520
# Unit test for function memoize
def test_memoize():
    def function_to_memoize(argument):
        return 2 * argument

    memoized_function = memoize(function_to_memoize)

    assert memoized_function(2) == 4
    assert memoized_function(3) == 6

    def function_to_memoize1(argument):
        return 2 + argument

    memoized_function = memoize(function_to_memoize1, lambda x, y: x == y + 1)

    assert memoized_function(2) == 4
    assert memoized_function(5) == 7

# Generated at 2022-06-21 19:53:59.511816
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(None) is None
    assert identity('string') == 'string'



# Generated at 2022-06-21 19:54:06.634179
# Unit test for function curried_filter
def test_curried_filter():
    collection = [
        {'name': 'first', 'something': 2},
        {'name': 'second', 'something': 2},
        {'name': 'third', 'something': 1}
    ]
    filterer = curried_filter(lambda x: x['something'] == 2)
    assert filterer(collection) == [{'name': 'first', 'something': 2}, {'name': 'second', 'something': 2}]


# Generated at 2022-06-21 19:54:08.825386
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda n: n % 2 == 0)([1, 2, 3, 4, 5]) == [2, 4]



# Generated at 2022-06-21 19:54:09.862276
# Unit test for function identity
def test_identity():
    """
    Test identidy function.

    :returns:
    :rtype:
    """
    return identity(1) == 1



# Generated at 2022-06-21 19:54:12.546186
# Unit test for function pipe
def test_pipe():
    assert pipe(1, (lambda x: x + 1), (lambda x: x * 2)) == 4
    assert pipe(1, (lambda x: x + 1), (lambda x: x * 2), (lambda x: x ** 2)) == 16



# Generated at 2022-06-21 19:54:19.371512
# Unit test for function curried_map
def test_curried_map():
    """
    Unit test for function curried_map

    :returns: None
    :rtype: None
    """
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-21 19:54:21.187354
# Unit test for function compose
def test_compose():
    """
    Test composition of two functions
    """
    assert compose(1, increase, identity) == 2



# Generated at 2022-06-21 19:54:39.669225
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-21 19:54:42.302485
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False


# Generated at 2022-06-21 19:54:51.877095
# Unit test for function cond
def test_cond():
    """
    Test for function cond().
    """
    def check_for_positive(value):
        return value > 0

    def return_true():
        return True

    def return_false():
        return False

    def return_value(value):
        return value

    assert cond([
        (
            check_for_positive,
            return_true
        ),
        (
            eq(1),
            return_false
        )
    ])(1) is return_true()

    assert cond([
        (
            check_for_positive,
            return_true
        ),
        (
            eq(1),
            return_false
        )
    ])(0) is return_false()


# Generated at 2022-06-21 19:54:53.186581
# Unit test for function compose
def test_compose():
    assert compose(4, increase, increase) == 6


# Generated at 2022-06-21 19:54:55.370209
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-21 19:55:04.907199
# Unit test for function curry
def test_curry():
    """
    Unit testing for function currying.
    """
    # sum function with two arguments
    def sum_two_number(number1, number2):
        return number1 + number2
    
    curried_sum_two_number = curry(sum_two_number)
    assert curried_sum_two_number(5, 6) == 11
    assert curried_sum_two_number(5)(6) == 11
    
    # sum function with three arguments
    def sum_three_number(number1, number2, number3):
        return number1 + number2 + number3
    
    curried_sum_three_number = curry(sum_three_number)
    assert curried_sum_three_number(5, 6, 7) == 18

# Generated at 2022-06-21 19:55:09.728218
# Unit test for function compose
def test_compose():
    assert compose(1, identity, identity) == 1
    assert compose(1, lambda x: x + 1, lambda x: x + 1) == 3
    assert compose(1, lambda x: x + 1, lambda x: x + 2) == 4
    assert compose(1, lambda x: x + 1, lambda x: x + 3) == 5



# Generated at 2022-06-21 19:55:18.614498
# Unit test for function memoize
def test_memoize():
    def gen_fib(count):
        a, b = 0, 1
        for _ in range(count):
            yield b
            a, b = b, a + b

    source: List[int] = list(gen_fib(10))

    function_count = [0]

    @memoize
    def fib(i):
        function_count[0] += 1
        return source[i]

    assert fib(2) == 1
    assert fib(3) == 2
    assert fib(2) == 1
    assert function_count[0] == 2
    assert fib(4) == 3
    assert fib(4) == 3
    assert function_count[0] == 3



# Generated at 2022-06-21 19:55:22.629721
# Unit test for function curried_filter
def test_curried_filter():
    curried_filter_by_even = curried_filter(lambda x: x % 2 == 0)
    assert curried_filter_by_even([1, 2, 3, 4, 5, 6]) == [2, 4, 6]



# Generated at 2022-06-21 19:55:25.129379
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4]) == [3, 4]
    assert curried_filter(lambda x: x > 2)([1, 2]) == []



# Generated at 2022-06-21 19:55:49.251043
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y) == curry(lambda x, y: x + y)
    assert curry(lambda x, y: x + y)(3)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6



# Generated at 2022-06-21 19:55:52.620855
# Unit test for function curried_map
def test_curried_map():
    """
    expect: curried_map()
    assert:  curried_map({'a': 1}, {'a': 1})
    """
    assert curried_map({'a': 1}, {'a': 1}) == {}



# Generated at 2022-06-21 19:55:55.646240
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity, [1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-21 19:55:58.200200
# Unit test for function eq
def test_eq():
    assert eq(2, 2)
    assert not eq(2, 3)
    assert eq(
        eq,
        curry(lambda x, y: x == y)
    )



# Generated at 2022-06-21 19:56:00.052465
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y: x + y, 1)(2) == 3



# Generated at 2022-06-21 19:56:05.411097
# Unit test for function curry
def test_curry():
    add_three_nums = lambda num1, num2, num3: num1 + num2 + num3

    curried_add_three_nums = curry(add_three_nums)

    assert curried_add_three_nums(1)(2)(3) == 6



# Generated at 2022-06-21 19:56:09.119383
# Unit test for function eq
def test_eq():
    # Arrange
    value1 = 3
    value2 = 3
    # Assert
    assert eq(value1, value2)
    assert not eq(value1, 4)



# Generated at 2022-06-21 19:56:10.784649
# Unit test for function pipe
def test_pipe():
    """
    Test pipe function.
    """
    assert pipe(2, increase, increase) == 4



# Generated at 2022-06-21 19:56:14.916685
# Unit test for function cond
def test_cond():
    assert cond([
        (eq(0), lambda value: 'zero'),
        (eq(1), lambda value: 'one'),
        (lambda value: value > 1, lambda value: 'more')
    ])(2) == 'more'

# Generated at 2022-06-21 19:56:23.718418
# Unit test for function curry
def test_curry():
    # 1.a
    input : List[int] = [1,2,3,4,5]
    output : List[int] = [3,4,5,6,7]
    assert curried_map(increase)(input) == output
    # 1.b
    input1 : List[int] = [1,2,3,4,5]
    output1 : List[int] = [2,3,4,5,6]
    assert curried_map(increase)(input1) == output1
    # 2.a
    assert compose(0, lambda x: x + 1, lambda x: x * 2) == 2
    # 2.b
    assert compose(0, lambda x: x * 2, lambda x: x + 1) == 1
    # 3.a

# Generated at 2022-06-21 19:57:08.627208
# Unit test for function memoize
def test_memoize():

    @memoize
    def add(a: int) -> int:
        return a + 1

    assert add(1) == 2
    assert add(2) == 3
    assert add(3) == 4
    assert add.__closure__[0].cell_contents == [(1, 2), (2, 3), (3, 4)]
    # Memoize using different key
    @memoize(key=lambda a, b: a is b)
    def add_by_one(a: int) -> int:
        return a + 1

    assert add_by_one(1) == 2
    assert add_by_one(2) == 3
    assert add_by_one(3) == 4
    assert add_by_one(1) == 2
    assert add_by_one.__closure__[0].cell_

# Generated at 2022-06-21 19:57:11.473332
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2
    assert increase(5) == 6



# Generated at 2022-06-21 19:57:17.811116
# Unit test for function curry
def test_curry():
    def sum(a, b, c):
        return a + b + c
    assert curry(sum)(1, 2, 3) == 6
    assert curry(sum)(1)(2, 3) == 6
    assert curry(sum)(1, 2)(3) == 6
    assert curry(sum)(1)(2)(3) == 6

