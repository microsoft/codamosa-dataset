

# Generated at 2022-06-21 19:47:21.002697
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-21 19:47:24.772346
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [])([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-21 19:47:27.701554
# Unit test for function identity
def test_identity():
    assert identity('value') == 'value'
    assert identity(10) == 10
    assert identity(True) is True
    assert identity(None) is None



# Generated at 2022-06-21 19:47:30.792228
# Unit test for function find
def test_find():
    items = [1, 2, 3, 4, 5]
    assert find(items, lambda x: x == 3) == 3
    assert find(items, lambda x: x == 10) is None



# Generated at 2022-06-21 19:47:33.541398
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(1))([1, 2, 3]) == [1]
    assert curried_filter(eq(1))([1, 1, 3]) == [1, 1]
    assert curried_filter(eq(1))([2, 3, 3]) == []



# Generated at 2022-06-21 19:47:37.260693
# Unit test for function compose
def test_compose():
    """
    Test to check if function compose work correctly.

    :return: boolean
    """
    assert compose(5, increase, increase) == 7

# Generated at 2022-06-21 19:47:40.869909
# Unit test for function pipe
def test_pipe():
    composed = pipe(1, lambda a: a + 1, lambda b: b * 2)
    assert composed == 4



# Generated at 2022-06-21 19:47:42.928565
# Unit test for function increase
def test_increase():
    print('Test function increase:', end='')
    assert (increase(2) == 3)
    print(' Passed!')



# Generated at 2022-06-21 19:47:46.015845
# Unit test for function pipe
def test_pipe():
    result = pipe(1,
              increase,
              increase,
              lambda x: x + 1
    )

    assert(result == 4)


# Generated at 2022-06-21 19:47:51.701993
# Unit test for function cond
def test_cond():
    to_int = lambda value: int(value)
    is_even = lambda value: value % 2 == 0
    is_odd = lambda value: value % 2 != 0
    condition_list = [
        (is_even, to_int),
        (is_odd, identity)
    ]
    to_int_or_identity = cond(condition_list)
    assert(1 == to_int_or_identity("1"))


# Generated at 2022-06-21 19:48:02.389410
# Unit test for function identity
def test_identity():
    assert identity("Hello") == "Hello"
    assert identity("1") == "1"
    assert identity("") == ""
    assert identity("[]") == "[]"
    assert identity("{}") == "{}"
    assert identity(1) == 1
    assert identity(0) == 0
    assert identity([]) == []



# Generated at 2022-06-21 19:48:06.023322
# Unit test for function curry
def test_curry():
    def curryTest(a, b):
        return a + b

    curryTestCurried = curry(curryTest)

    assert curryTest(2, 4) == 6
    assert curryTestCurried(3)(9) == 12



# Generated at 2022-06-21 19:48:07.791455
# Unit test for function increase
def test_increase():
    assert increase(6) == 7
    assert increase(0) == 1
    assert increase(-1) == 0



# Generated at 2022-06-21 19:48:09.223267
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-21 19:48:11.428666
# Unit test for function memoize
def test_memoize():
    def factorial(n):
        return 1 if n == 0 else n * factorial(n - 1)

    factorial = memoize(factorial)
    assert factorial(10000) == factorial(10000)



# Generated at 2022-06-21 19:48:12.352825
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:48:17.746900
# Unit test for function curried_filter
def test_curried_filter():
    test_collection = [i for i in range(10)]
    curried_filter_even = curried_filter(lambda number: number % 2 == 0)
    result_collection = curried_filter_even(test_collection)
    assert result_collection == [0, 2, 4, 6, 8]


# Generated at 2022-06-21 19:48:22.960860
# Unit test for function pipe
def test_pipe():
    assert pipe(1, identity) == 1
    assert pipe(1, increase) == 2
    assert pipe(1, increase, identity) == 2
    assert pipe(1, identity, increase) == 2
    assert pipe(1, identity, increase, identity) == 2
    assert pipe(1, identity, increase, increase) == 3



# Generated at 2022-06-21 19:48:27.480721
# Unit test for function compose
def test_compose():
    return compose(
        5,
        lambda x: x * 3,
        lambda x: x + 2
    )


if __name__ == '__main__':
    print(test_compose())

# Generated at 2022-06-21 19:48:37.827352
# Unit test for function cond
def test_cond():
    print('TEST COND')


    def condition_function(value):
        return value > 0

    def execute_function(value):
        return value + 1


    def condition_function1(value):
        return value % 2 == 0

    def execute_function1(value):
        return value + 2

    print(cond([
        (condition_function, execute_function),
        (condition_function1, execute_function1),
    ])(1))  # 2
    print(cond([
        (condition_function, execute_function),
        (condition_function1, execute_function1),
    ])(-100))  # None
    print(cond([
        (condition_function, execute_function),
        (condition_function1, execute_function1),
    ])(4))  # 6



# Generated at 2022-06-21 19:48:44.071901
# Unit test for function compose
def test_compose():
    assert(compose(2, lambda x: x * 2, lambda x: x + 2, lambda x: x / 2)) == 4



# Generated at 2022-06-21 19:48:54.801970
# Unit test for function cond
def test_cond():
    #
    #function cond return result of second tuple argument
    #
    assert cond([
        (lambda x: x == 1, lambda y: 'one'),
        (lambda x: x == 2, lambda y: 'two'),
    ])(2) == 'two'

    assert cond([
        (lambda x: x == 1, lambda y: 'one'),
        (lambda x: x == 2, lambda y: 'two'),
    ])(1) == 'one'

    #
    #function cond return None if condition is None
    #
    assert cond([
        (lambda x: x == 1, lambda y: 'one'),
        (lambda x: x == 2, lambda y: 'two'),
    ])(3) is None



# Generated at 2022-06-21 19:48:57.607790
# Unit test for function pipe
def test_pipe():
    value = pipe(10, lambda x: x + 10)
    assert value == 20



# Generated at 2022-06-21 19:49:00.415632
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter([1, 2, 3, 4])(lambda value: value % 2 == 0) == [2, 4]



# Generated at 2022-06-21 19:49:05.894376
# Unit test for function curried_filter
def test_curried_filter():
    test_list = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    even_filter_lambda = lambda x: x % 2 == 0
    even_filter_curried = curried_filter(even_filter_lambda)
    assert even_filter_curried(test_list) == [2, 4, 6, 8]

test_curried_filter()

# Generated at 2022-06-21 19:49:10.274262
# Unit test for function compose
def test_compose():
    """
    Composition test
    """
    assert compose(1, increase, increase) == 3
    assert compose(1, increase, increase, increase, increase) == 5
    assert compose(3, increase, increase, increase) == 6



# Generated at 2022-06-21 19:49:12.097952
# Unit test for function pipe
def test_pipe():
    assert pipe(1, lambda x: x + 1, lambda x: x * 2) == 4

# Generated at 2022-06-21 19:49:24.160609
# Unit test for function memoize
def test_memoize():
    def operation(x):
        return x + 1

    memoized_operation = memoize(operation, key=eq)
    assert memoized_operation(1) == 2
    assert memoized_operation(1) == 2
    assert memoized_operation(2) == 3
    assert memoized_operation(2) == 3
    assert memoized_operation(1) == 2
    assert memoized_operation(2) == 3
    assert memoized_operation(3) == 4
    assert memoized_operation(3) == 4
    assert memoized_operation(1) == 2
    assert memoized_operation(2) == 3
    assert memoized_operation(3) == 4
    assert memoized_operation(4) == 5
    assert memoized_operation(4) == 5
    assert memoized_operation(1) == 2

# Generated at 2022-06-21 19:49:30.166385
# Unit test for function curry
def test_curry():
    curried_add = curry(lambda x, y, z: x + y + z)
    assert curried_add(1, 2, 3) == 6
    assert curried_add(1)(2)(3) == 6
    assert curried_add(1)(2, 3) == 6
    assert curried_add(1, 2)(3) == 6



# Generated at 2022-06-21 19:49:37.856569
# Unit test for function curry
def test_curry():
    add = lambda a, b, c, d, e, f: a + b + c + d + e + f
    add6 = curry(add, 6)
    assert add6(1, 2, 3, 4, 5, 6) == 21

    add5 = add6(1, 2, 3, 4)
    assert add5(5, 6) == 21



# Generated at 2022-06-21 19:49:53.143619
# Unit test for function cond
def test_cond():
    even = lambda x: x % 2 == 0
    odd = lambda x: x % 2 != 0
    cond_even = cond([
        (even, identity),
    ])
    cond_odd = cond([
        (odd, identity),
    ])
    cond_both = cond([
        (even, cond_even),
        (odd, cond_odd),
    ])
    assert cond_even(2) == 2
    assert cond_even(3) is None
    assert cond_odd(2) is None
    assert cond_odd(3) == 3
    assert cond_both(2) == 2
    assert cond_both(3) == 3



# Generated at 2022-06-21 19:49:54.665584
# Unit test for function eq
def test_eq():
    assert eq(1, 2) == False
    assert eq(1, 1) == True
    # Test for currying
    assert eq(1)(1) == True


    assert eq(2)(2) == True


# Generated at 2022-06-21 19:49:58.279512
# Unit test for function curried_map
def test_curried_map():
    curried_double = curried_map(lambda a: a * 2)
    assert curried_double([1, 2, 3]) == [2, 4, 6]



# Generated at 2022-06-21 19:50:03.257603
# Unit test for function curried_filter
def test_curried_filter():
    a = [1, 2, 3, 4, 5, 6]
    filterer = lambda x: x % 2 == 0
    assert(curried_filter(filterer)(a) == [2, 4, 6])
    assert(curried_filter(filterer, a) == [2, 4, 6])



# Generated at 2022-06-21 19:50:16.037000
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 1, [1, 2, 3]) == [1, 3]
    assert curried_filter(lambda x: x % 2 == 1)([1, 2, 3]) == [1, 3]
    assert curried_filter(lambda x: x % 2 == 1, range(1, 10)) == [1, 3, 5, 7, 9]
    assert curried_filter(lambda x: x % 2 == 1)(range(1, 10)) == [1, 3, 5, 7, 9]
    assert curried_filter(lambda x: x % 2 == 1)(range(1, 10)) == [1, 3, 5, 7, 9]
    assert curried_filter(lambda x: x % 2 == 1)(range(1, 10)) == [1, 3, 5, 7, 9]

# Generated at 2022-06-21 19:50:20.732998
# Unit test for function curried_map
def test_curried_map():
    array = [1, 2, 3, 4, 5]
    assert curried_map(increase, array) == [2, 3, 4, 5, 6]

    double = curried_map(lambda x: x * 2)
    assert double(array) == [2, 4, 6, 8, 10]




# Generated at 2022-06-21 19:50:22.012076
# Unit test for function compose
def test_compose():
    assert compose(0, increase, identity) == 1



# Generated at 2022-06-21 19:50:28.452132
# Unit test for function cond
def test_cond():
    test_list = [
        (lambda x: x < 0, lambda x: x * -1),
        (lambda x: x == 0, lambda x: 0),
        (lambda x: x > 0, lambda x: x),
    ]
    test_function = cond(test_list)

    assert test_function(-1) == 1
    assert test_function(0) == 0
    assert test_function(1) == 1



# Generated at 2022-06-21 19:50:30.334406
# Unit test for function identity
def test_identity():
    assert identity('hello') == 'hello'



# Generated at 2022-06-21 19:50:37.235236
# Unit test for function curried_map
def test_curried_map():
    array = [1, 2, 3, 4]
    assert curried_map(curried_map(curried_map(lambda x: x + 1))) == [2, 3, 4, 5]
    assert curried_map(curried_map(lambda x: x * 2))(curried_map(lambda x: x + 1))(array) == [4, 6, 8, 10]
    assert curried_map(lambda x: x * 2)(array) == [2, 4, 6, 8]



# Generated at 2022-06-21 19:50:46.410873
# Unit test for function cond
def test_cond():
    def condition_1(value):
        return value > 0

    def condition_2(value):
        return value < 0

    def execute_1(value):
        return "Bigger than 0"

    def execute_2(value):
        return "Less than 0"

    cmp_execute_1 = cond([
        (condition_1, execute_1),
        (condition_2, execute_2),
    ])

    assert cmp_execute_1(11) == "Bigger than 0"
    assert cmp_execute_1(-11) == "Less than 0"



# Generated at 2022-06-21 19:50:54.794258
# Unit test for function cond
def test_cond():
    def is_even(number):
        return number % 2 == 0

    def is_odd(number):
        return number % 2 == 1

    def even_inc(number):
        return number + 1

    def odd_dec(number):
        return number - 1

    even_odd_inc_dec = cond([
        (is_even, even_inc),
        (is_odd, odd_dec)
    ])

    assert even_odd_inc_dec(10) == 11
    assert even_odd_inc_dec(9) == 8


# Generated at 2022-06-21 19:51:01.320831
# Unit test for function cond
def test_cond():
    def true_key(n):
        return n == 1

    def false_key(n):
        return n == 2

    def true_execute(n):
        return "true"

    def false_execute(n):
        return "false"

    condition_list = [
        (true_key, true_execute),
        (false_key, false_execute),
    ]

    result1 = cond(condition_list)(1)
    result2 = cond(condition_list)(2)

    assert result1 == "true" and result2 == "false"



# Generated at 2022-06-21 19:51:08.469871
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 3, [1, 2, 3, 4, 5, 6, 7, 8, 9]
                         ) == [4, 5, 6, 7, 8, 9]
    assert curried_filter(lambda x: x > 3)([1, 2, 3, 4, 5, 6, 7, 8, 9]
                                           ) == [4, 5, 6, 7, 8, 9]



# Generated at 2022-06-21 19:51:11.332291
# Unit test for function curry
def test_curry():
    def foo(a, b, c, d):
        return a*b*c*d

    assert foo(1, 2, 3, 4) == curry(foo)(1)(2)(3)(4)



# Generated at 2022-06-21 19:51:16.422423
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([0, 1, 2]) == [0, 1, 2]
    assert curried_map(increase)([0, 1, 2]) == [1, 2, 3]
    assert curried_map(increase, [0, 1, 2]) == [1, 2, 3]


# Generated at 2022-06-21 19:51:20.624042
# Unit test for function cond
def test_cond():
    def double(x):
        return x * 2

    def triple(x):
        return x * 3

    def identity(x):
        return x

    condition_list = [(lambda x: x % 2 == 0, double), (lambda x: True, triple)]
    result_function = cond(condition_list)
    assert result_function(0) == 0
    assert result_function(1) == 3
    assert result_function(2) == 4


# Generated at 2022-06-21 19:51:22.129052
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:51:23.162143
# Unit test for function increase
def test_increase():
    assert increase(1) == 2


# Generated at 2022-06-21 19:51:25.873538
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], eq(2)) == 2
    assert find([1, 2, 3, 4], eq(5)) is None



# Generated at 2022-06-21 19:51:35.025733
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2)([1, 2, 3]) == [3]



# Generated at 2022-06-21 19:51:38.395425
# Unit test for function curried_filter
def test_curried_filter():
    l = [1, 2, 3, 4, 5, 6]
    f = curried_filter(lambda x: x < 5)
    assert(f(l) == [1, 2, 3, 4])

# Generated at 2022-06-21 19:51:42.414211
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(3), [1, 2, 3]) == [3]
    assert curried_filter(eq(3), [1, 2, 4]) == []
    assert curried_filter(increase, [1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-21 19:51:48.537383
# Unit test for function curried_filter
def test_curried_filter():
    assert(
        curried_filter(
            lambda x: x > 5,
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
        ) == [6, 7, 8, 9, 10]
    )


# Generated at 2022-06-21 19:51:51.834249
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x*x, [1, 2, 3, 4, 5]) == [1, 4, 9, 16, 25]


# Generated at 2022-06-21 19:51:54.149904
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2)(list(range(3, 6))) == [3, 4, 5]



# Generated at 2022-06-21 19:51:56.636556
# Unit test for function curried_map
def test_curried_map():
    square = lambda x: x ** 2
    assert curried_map(square)([1, 2, 3, 4]) == [1, 4, 9, 16]



# Generated at 2022-06-21 19:52:00.181257
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(2) == 3
    assert increase(3) == 4
    assert increase(4) == 5



# Generated at 2022-06-21 19:52:07.239701
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 1) == 1
    assert find([1, 2, 3, 4], lambda x: x == 2) == 2
    assert find([1, 2, 3, 4], lambda x: x == 3) == 3
    assert find([1, 2, 3, 4], lambda x: x == 4) == 4
    assert find([1, 2, 3, 4], lambda x: x == 5) is None
    assert find([], lambda x: x == 1) is None



# Generated at 2022-06-21 19:52:18.597094
# Unit test for function memoize
def test_memoize():
    """
    Unit test for function memoize
    """
    @memoize
    def add(x: int) -> int:
        """
        Add two ints together.

        :param x:
        :type x: int
        :returns:
        :rtype: int
        """
        return x + 1

    assert add(2) == 3
    assert add(2) == 3  # result should be taken from cache
    assert add(3) == 4
    assert add(4) == 5

    @memoize
    def fib(n: int) -> int:
        """
        Return the nth fibonacci number.

        :param n:
        :type n: int
        :returns:
        :rtype: int
        """
        if n <= 0:
            return 0

# Generated at 2022-06-21 19:52:40.758679
# Unit test for function pipe
def test_pipe():
    a = pipe(
        'a',
        lambda x: x + 'b',
        lambda x: x + 'c',
        lambda x: x + 'd'
    )
    assert a == 'abcd'

    b = pipe(
        [1, 2, 3, 4],
        lambda x: list(map(lambda y: y * 2, x)),
        lambda x: list(filter(lambda y: y % 3 == 0, x)),
        lambda x: list(map(lambda y: y % 4, x))
    )
    assert b == [0]



# Generated at 2022-06-21 19:52:42.656090
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False



# Generated at 2022-06-21 19:52:50.091200
# Unit test for function cond
def test_cond():
    def is_tag_with_color(tag):
        return "color" in tag

    def create_tag_with_color(tag):
        return "<{tag} style='color: {color}'>".format(tag=tag["tag"], color=tag["color"])

    def create_tag_without_color(tag):
        return "<{tag}>".format(tag=tag["tag"])

    def create_tag(tag):
        return cond([
            (is_tag_with_color, create_tag_with_color),
            (lambda _: True, create_tag_without_color)
        ])(tag)

    assert create_tag({"tag": "b", "color": "red"}) == "<b style='color: red'>"
    assert create_tag({"tag": "b"}) == "<b>"

# Generated at 2022-06-21 19:53:01.244761
# Unit test for function cond
def test_cond():
    is_even = lambda x: x % 2 == 0
    is_positive = lambda x: x > 0
    is_zero = lambda x: x == 0

    is_even_and_positive = cond([
        (is_even, lambda x: True),
        (is_positive, lambda x: False),
        (is_zero, lambda x: False),
        (lambda x: True, lambda x: False),
    ])
    is_even_and_positive2 = lambda x: is_even(x) and is_positive(x)

    assert is_even_and_positive(4), '4 is even and positive'
    assert is_even_and_positive(2), '2 is even and positive'
    assert not is_even_and_positive(1), '1 is not even and positive'
    assert not is_even_and

# Generated at 2022-06-21 19:53:09.375812
# Unit test for function compose
def test_compose():
    assert(compose(2, increase, increase, increase) == 5)
    assert(compose(2, lambda x: x + 1, lambda x: x + 1) == 4)
    assert(compose(2, lambda x: x + 1, lambda x: x + 1, lambda x: x + 1) == 5)
    assert(compose(2, lambda x: x + 1, lambda x: x + 1, lambda x: x + 1, lambda x: x + 1) == 6)
    assert(compose(2, lambda x: x + 1, lambda x: x + 1, lambda x: x + 1, lambda x: x + 1, lambda x: x + 1) == 7)



# Generated at 2022-06-21 19:53:10.124710
# Unit test for function increase
def test_increase():
    assert increase(1) == 2


# Generated at 2022-06-21 19:53:11.581436
# Unit test for function curry
def test_curry():
    def add(x, y):
        return x + y

    assert curry(add)(1, 2) == 3



# Generated at 2022-06-21 19:53:13.751266
# Unit test for function identity
def test_identity():
    assert identity(3) == 3



# Generated at 2022-06-21 19:53:16.113212
# Unit test for function pipe
def test_pipe():
    assert pipe(
        1,
        lambda arg: arg + 2,
        lambda arg: arg * 2,
        lambda arg: arg / 2,
    ) == 3



# Generated at 2022-06-21 19:53:18.517315
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False


# Generated at 2022-06-21 19:53:57.944632
# Unit test for function memoize
def test_memoize():
    """
    Test case for unary function memoize.
    """
    def test_function(argument):
        if argument == 'a':
            return 'A'
        return 'B'

    memoized_function = memoize(test_function)
    test_function('a')
    test_function('b')

    assert memoized_function('a') == 'A'
    assert memoized_function('b') == 'B'



# Generated at 2022-06-21 19:53:59.113821
# Unit test for function identity
def test_identity():
    assert identity(1) == 1, 'identity doesn\'t work'



# Generated at 2022-06-21 19:54:03.253241
# Unit test for function compose
def test_compose():
    new_function = compose(
        'test',
        lambda x: x + '1',
        lambda x: x + '2'
    )
    assert new_function == 'test12'



# Generated at 2022-06-21 19:54:09.072261
# Unit test for function cond
def test_cond():
    """
    Test for function cond.
    """
    cond_test = cond(
        [(lambda x: x > 0, lambda x: 'positive'),
         (lambda x: x < 0, lambda x: 'negative'),
         (lambda x: True, lambda _: 'zero')]
    )
    assert cond_test(0) == 'zero'
    assert cond_test(-1) == 'negative'
    assert cond_test(1) == 'positive'



# Generated at 2022-06-21 19:54:12.205681
# Unit test for function curry
def test_curry():
    assert (curry(lambda a, b, c: a + b + c)(1)(3)(4) == 8)
    assert (curry(lambda a, b, c: a + b + c)(1)(3)(4)(5) == 8)



# Generated at 2022-06-21 19:54:19.321698
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(identity(3), 3) is True
    assert eq([1, 2], [1, 2]) is True
    assert eq("Hello", "Hello") is True
    assert eq("Hello", "hello") is False
    assert eq(1, 2) is False



# Generated at 2022-06-21 19:54:20.366943
# Unit test for function increase
def test_increase():
    assert increase(1) == 2


# Generated at 2022-06-21 19:54:25.408318
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 4]) == [2, 3, 5]
    assert curried_map(
        lambda x: x + 1,
        [1, 2, 4]
    ) == [2, 3, 5]
    assert curried_map(increase, [1, 2, 4, 6]) == [2, 3, 5, 7]
    assert isinstance(curried_map(increase, [1, 2, 4, 6]), list)


# Generated at 2022-06-21 19:54:28.297051
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 1)([1, 2, 3]) == [2, 3]
    assert curried_filter(lambda x: x < 3)([1, 2, 3]) == [1, 2]


# Generated at 2022-06-21 19:54:31.118357
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 5) is None

# Generated at 2022-06-21 19:55:56.890485
# Unit test for function increase
def test_increase():
    assert increase(1) == 2


# Generated at 2022-06-21 19:56:03.212917
# Unit test for function cond
def test_cond():
    """
    Unit test for function cond
    """
    def test_fn_1(value):
        return value + 1
    def test_fn_2(value):
        return value - 1
    def test_fn_3(value):
        return value

    condition_list = [
        (lambda value: value % 2 == 0, test_fn_1),
        (lambda value: value % 2 == 1, test_fn_2),
        (lambda value: True, test_fn_3)
    ]

    test_cond_fn = cond(condition_list)

    assert test_cond_fn(1) == test_fn_2(1)
    assert test_cond_fn(2) == test_fn_1(2)
    assert test_cond_fn(3) == test_fn_2(3)
    assert test

# Generated at 2022-06-21 19:56:05.262965
# Unit test for function eq
def test_eq():
    assert eq(5)(5) == True
    assert eq(4)(5) == False


# Generated at 2022-06-21 19:56:07.689877
# Unit test for function identity
def test_identity():
    result = identity(1)
    assert result == 1



# Generated at 2022-06-21 19:56:10.935492
# Unit test for function curried_map
def test_curried_map():

    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-21 19:56:21.230584
# Unit test for function curried_map
def test_curried_map():
    # curriedMap(mapper, collection)
    # curriedMap(mapper)(collection)

    # curriedMap(identity(7), [])
    # curriedMap(identity)([])
    assert curried_map(identity)([]) == []
    assert curried_map(identity, []) == []

    # curriedMap(identity, [1, 2, 3, 4])
    # curriedMap(identity)([1, 2, 3, 4])
    assert curried_map(identity)([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert curried_map(identity, [1, 2, 3, 4]) == [1, 2, 3, 4]

    # curriedMap(increase, [1, 2, 3, 4])
    #

# Generated at 2022-06-21 19:56:24.346913
# Unit test for function eq
def test_eq():
    assert eq(2, 2)
    assert not eq(2, 3)
    assert eq(3)(3)



# Generated at 2022-06-21 19:56:27.885892
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda a: a > 5, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [6, 7, 8, 9, 10]


# Generated at 2022-06-21 19:56:28.748601
# Unit test for function increase
def test_increase():
    assert increase(5) == 6

# Generated at 2022-06-21 19:56:32.872615
# Unit test for function find
def test_find():
    assert find([], identity) is None
    assert find([1, 2, 3], eq(2)) == 2
    assert find([1, 2, 3], eq(3)) == 3
    assert find([1, 2, 3], eq(4)) is None

