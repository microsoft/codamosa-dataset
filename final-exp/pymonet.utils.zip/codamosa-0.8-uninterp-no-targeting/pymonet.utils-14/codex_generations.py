

# Generated at 2022-06-21 19:47:22.005285
# Unit test for function pipe
def test_pipe():
    pipe.__name__ = 'test_pipe'
    assert pipe('value', identity, increase, str) == '3', \
        "Wrong result of pipe application."


# Generated at 2022-06-21 19:47:26.848379
# Unit test for function find
def test_find():
    key = lambda x: x == 11
    collection = [0, 10, 11, 4, 5]
    assert find(collection, key) == 11
    assert find(collection, lambda x: x > 11) is None
    assert find(collection, lambda x: True) == 0
    assert find([], lambda x: True) is None


# Generated at 2022-06-21 19:47:28.186646
# Unit test for function pipe
def test_pipe():
    assert pipe(1, increase, increase, increase) == 4



# Generated at 2022-06-21 19:47:32.817602
# Unit test for function eq
def test_eq():
    assert eq(3, 3) is True
    assert eq(3, 4) is False
    assert eq(3, '3') is False
    assert eq(3, '4') is False
    assert eq(3)(3) is True
    assert eq(3)(4) is False
    assert eq(3)('3') is False
    assert eq(3)('4') is False



# Generated at 2022-06-21 19:47:38.631165
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity((1, 2)) == (1, 2)
    assert identity('1') == '1'
    assert identity(None) is None
    print('test identity success')  # pragma: no cover



# Generated at 2022-06-21 19:47:39.626682
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:47:45.235693
# Unit test for function memoize
def test_memoize():
    import random

    def check_fibonacci(number):
        if number == 0:
            return 0
        if number == 1:
            return 1
        return check_fibonacci(number - 1) + check_fibonacci(number - 2)

    memoize_fibonacci = memoize(check_fibonacci)

    assert check_fibonacci(random.randint(5, 20)) == memoize_fibonacci(random.randint(5, 20))

# Generated at 2022-06-21 19:47:50.405884
# Unit test for function memoize
def test_memoize():
    def test_fun(a):
        return a
    assert memoize(test_fun)('a') == 'a'
    assert memoize(test_fun)('a') == 'a'

    assert memoize(test_fun)('b') == 'b'
    assert memoize(test_fun)('b') == 'b'
# End of unit test


# Generated at 2022-06-21 19:47:53.589138
# Unit test for function pipe
def test_pipe():
    assert pipe(
        3,
        curry(lambda x, y: x + y)[5],
        curry(lambda x, y: x * y)[5],
        lambda x: x - 5
    ) == 10
    assert pipe(
        'test',
        lambda x: x[0],
        lambda x: x.upper()
    ) == 'T'



# Generated at 2022-06-21 19:48:02.162215
# Unit test for function curried_filter
def test_curried_filter():
    original_list = [0, 1, 2, 3, 4, 5]
    expected_result = [0, 1, 2, 3]

    my_filter = curried_filter(lambda x: x < 4)
    res = my_filter(original_list)

    try:
        assert res == expected_result
    except AssertionError:
        print(f'\x1b[31mexpected {expected_result}, got {res}\x1b[0m')



# Generated at 2022-06-21 19:48:08.573676
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2
    assert increase(2) == 3
    assert increase(3) == 4
    assert increase(4) == 5
    assert increase(5) == 6
    assert increase(6) == 7
    assert increase(7) == 8
    assert increase(8) == 9


# Generated at 2022-06-21 19:48:16.090419
# Unit test for function curried_map
def test_curried_map():
    new_list = curried_map(increase)([1, 2, 3])
    assert new_list == [2, 3, 4], '1. Wrong result of curried_map'
    new_list = curried_map(increase, [2, 3, 4])
    assert new_list == [3, 4, 5], '2. Wrong result of curried_map'
    new_list = curried_map(increase, [])
    assert new_list == [], '3. Wrong result of curried_map'


# Generated at 2022-06-21 19:48:23.949368
# Unit test for function cond
def test_cond():
    f = cond([
        (lambda x: True, lambda x: x + 1),
        (lambda x: True, lambda x: x)
    ])
    assert f(1) == 2

    f = cond([
        (lambda x: False, lambda x: x + 1),
        (lambda x: True, lambda x: x)
    ])
    assert f(1) == 1

    f = cond([
        (lambda x: False, lambda x: x + 1),
        (lambda x: False, lambda x: x)
    ])
    assert f(1) is None



# Generated at 2022-06-21 19:48:31.396407
# Unit test for function find
def test_find():
    def key(item):
        return True if item == 'test_value' else False

    # Test failed case
    assert find(['test_value1', 'test_value2'], key) is None

    # Test successful case
    found_item = 'test_value'
    assert find([found_item], key) == found_item, \
        'Expect: {}\nGot: {}'.format(found_item, find([found_item], key))



# Generated at 2022-06-21 19:48:34.185295
# Unit test for function curry
def test_curry():
    multi = lambda x, y: x * y
    double = curry(multi, 2)
    print(double(3))
    print(double(4))



# Generated at 2022-06-21 19:48:35.944112
# Unit test for function identity
def test_identity():
    assert identity(42) == 42
    assert identity('identity') == 'identity'



# Generated at 2022-06-21 19:48:43.416372
# Unit test for function compose
def test_compose():
    """
    Test for compose function.
    test_compose function should return True if function compose works properly.

    :returns: if compose works properly
    :rtype: Boolean
    """
    # compose function
    composition = compose(
        # argument for composition
        100,
        # functions for composition
        lambda a: a / 10,
        lambda a: a * 2
    )
    # expected value of composition
    expected_result = 200

    assert composition == expected_result, \
        "Composition result must be {} but {}".format(expected_result, composition)



# Generated at 2022-06-21 19:48:47.457705
# Unit test for function curried_filter
def test_curried_filter():
    coll = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

    predicate = lambda x: x % 2 == 0

    assert curried_filter(predicate, coll) == [2, 4, 6, 8, 10]
    assert curried_filter(predicate)(coll) == [2, 4, 6, 8, 10]


# Generated at 2022-06-21 19:48:50.546576
# Unit test for function cond
def test_cond():
    assert cond([(eq(1), lambda x: '1'), (eq(2), lambda x: '2')])(1) == '1', 'Wrong working cond'


# Generated at 2022-06-21 19:48:59.613783
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x > 0, lambda x: 'x is positive'),
        (lambda x: x < 0, lambda x: 'x is negative')
    ])(0) == 'x is positive'
    assert cond([
        (lambda x: x > 0, lambda x: 'x is positive'),
        (lambda x: x < 0, lambda x: 'x is negative')
    ])(-1) == 'x is negative'
    assert cond([
        (lambda x: x > 0, lambda x: 'x is positive'),
        (lambda x: x < 0, lambda x: 'x is negative')
    ])(1) == 'x is positive'



# Generated at 2022-06-21 19:49:11.951012
# Unit test for function cond
def test_cond():
    def func1(x):
        print("func1({})".format(x))
        return x

    def func2(x):
        print("func2({})".format(x))
        return x

    def func3(x):
        print("func3({})".format(x))
        return x

    list_of_tuples = [
        (lambda x: x == 1, func1),
        (lambda x: x == 2, func2),
        (lambda x: x == 3, func3)
    ]

    test_function = cond(list_of_tuples)

    print("Input 1 => Expected func1(1):", test_function(1))
    print("Input 2 => Expected func2(2):", test_function(2))

# Generated at 2022-06-21 19:49:15.651163
# Unit test for function eq
def test_eq():
    list_of_items = [1, 2, 3, 4, 5]

    eq_2 = eq(2)
    eq_3 = eq(3)
    eq_4 = eq(4)

    assert(eq_2(2))
    assert(2 not in curried_filter(eq_2, list_of_items))
    assert(eq_4(4))
    assert(4 in curried_filter(eq_4, list_of_items))



# Generated at 2022-06-21 19:49:20.064511
# Unit test for function pipe
def test_pipe():
    assert pipe(2, increase, increase, increase) == 5
    assert pipe('ant', lambda x: '{} is {}'.format(x, 'ok'), lambda x: '{} and {}'.format(x, 'ok')) == 'ant and ok'

# Generated at 2022-06-21 19:49:27.009798
# Unit test for function curried_map
def test_curried_map():
    curried_map_ = curried_map
    assert curried_map_(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map_(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map_(increase, [1, 2, 3]) == [2, 3, 4]
    assert curried_map_(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-21 19:49:36.726199
# Unit test for function cond
def test_cond():
    is_even = lambda x: x % 2 == 0
    is_odd = lambda x: not is_even(x)
    even_action = lambda x: str(x) + ' is even'
    odd_action = lambda x: str(x) + ' is odd'
    test1 = lambda x: str(x) + ' is zero'

    cond_test = cond([
        (is_even, even_action),
        (is_odd, odd_action),
        (lambda x: x == 0, test1),
    ])
    assert cond_test(4) == '4 is even'
    assert cond_test(5) == '5 is odd'
    assert cond_test(0) == '0 is zero'
    assert cond_test(3) == '3 is odd'



# Generated at 2022-06-21 19:49:38.090362
# Unit test for function identity
def test_identity():
    assert identity("asd") == "asd"
    assert identity(1) == 1
    assert identity(None) is None



# Generated at 2022-06-21 19:49:41.646918
# Unit test for function identity
def test_identity():
    assert identity(1) == 1, "identity(1) should return 1"
    assert identity(1) != 2, "identity(1) should not return 2"
    assert identity(1) != True, "identity(1) should not return True"


# Generated at 2022-06-21 19:49:47.395702
# Unit test for function eq
def test_eq():
    assert eq(2, 2) == True
    assert eq(1, 2) == False
    assert eq(-1, 1) == False
    assert eq(2, 1) == False
    assert eq(None, 2) == False
    assert eq(2, None) == False
    assert eq(None, None) == True
    assert eq(None, "") == False
    assert eq("", None) == False
    assert eq("", "") == True
    assert eq("None", "") == False
    assert eq("", "None") == False
    assert eq("None", "None") == True
    assert eq(1, 1.0) == True
    assert eq(2, 2.0) == True
    assert eq(-1, -1.0) == True
    assert eq(1, -1.0) == False
    assert eq

# Generated at 2022-06-21 19:49:50.404859
# Unit test for function memoize
def test_memoize():
    def add(value):
        return value + 1

    fn = memoize(add)
    assert fn(1) == 2
    assert fn(1) == 2

# Generated at 2022-06-21 19:49:52.109424
# Unit test for function pipe
def test_pipe():
    assert pipe(
        1,
        lambda val: val + 1,
        lambda val: val * 5
    ) == 10

# Generated at 2022-06-21 19:50:09.940622
# Unit test for function eq
def test_eq():
    assert eq(1, 2) == False
    assert eq(2, 2) == True
    assert eq(2, "2") == False



# Generated at 2022-06-21 19:50:11.713235
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity('hello') == 'hello'
    assert identity(True) is True
    assert identity(None) is None



# Generated at 2022-06-21 19:50:15.273884
# Unit test for function find
def test_find():
    assert find(lambda x: x == 1, [1, 1, 2, 3, 4]) == 1
    assert find(lambda x: x == 5, [1, 1, 2, 3, 4]) is None



# Generated at 2022-06-21 19:50:19.509079
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 3, 4]

    filtered_collection = curried_filter(lambda x: x % 2 == 0)(collection)
    assert [2, 4] == filtered_collection

    filtered_collection = curried_filter(lambda x: x % 2 == 0, collection)
    assert [2, 4] == filtered_collection



# Generated at 2022-06-21 19:50:22.011824
# Unit test for function pipe
def test_pipe():
    assert pipe('abc', list, reversed, ''.join) == 'cba'


# Generated at 2022-06-21 19:50:24.556620
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2
    assert increase(2) == 3
    assert increase(3) == 4


# Generated at 2022-06-21 19:50:30.683274
# Unit test for function eq
def test_eq():
    assert eq(2,2) == True
    assert eq(2,3) == False
    assert eq(2)(2) == True
    assert eq(2)(3) == False
    #(Curry, eq(2)) == (Curry, True)
    assert eq(2,2) == True
    assert eq(2,3) == False


# Generated at 2022-06-21 19:50:34.366829
# Unit test for function find
def test_find():
    def int_to_bool(item): return item > 0
    collection = [-1, 0, 1]
    assert find(collection, int_to_bool) == 1
    assert find(collection, lambda item: item > 2) is None

# Generated at 2022-06-21 19:50:41.330517
# Unit test for function curried_filter
def test_curried_filter():
    """
    Test curried_filter.
    """
    test_collection = [0, 1, 2, 3, 4, 5]
    test_filterer_less_than_3 = lambda item: item < 3
    test_filterer_greater_than_3 = lambda item: item > 3

    assert curried_filter(test_filterer_less_than_3)(test_collection) == [0, 1, 2]
    assert curried_filter(test_filterer_greater_than_3)(test_collection) == [4, 5]

# Generated at 2022-06-21 19:50:43.475320
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 2) == 2
    assert find([1, 2, 3, 4], lambda x: x == 5) is None



# Generated at 2022-06-21 19:51:04.096874
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(10) == 11
    assert increase(12) == 13



# Generated at 2022-06-21 19:51:08.086406
# Unit test for function curry
def test_curry():
    curried_increase = curry(increase)
    curried_increase(1)  # 2
    curried_increase(1)(1)  # 3
    curried_increase(1)(1)(1)  # 4



# Generated at 2022-06-21 19:51:10.242135
# Unit test for function identity
def test_identity():
    """
    Unit test for function identity
    """
    assert identity(1) == 1
    assert identity(1) != 2

# Generated at 2022-06-21 19:51:18.816386
# Unit test for function cond
def test_cond():
    is_even = lambda number: number % 2 == 0
    is_string = lambda value: isinstance(value, str)
    double = lambda number: number * 2
    increment = lambda number: number + 1

    result = cond([
        (is_even, double),
        (is_string, identity)
    ])

    assert result(2) == 4
    assert result(3) == 3
    assert result(1) == 1
    assert result('bla') == 'bla'

    assert cond([
        (is_even, double),
        (is_string, identity),
        (lambda _: True, increment)
    ])(2) == 4



# Generated at 2022-06-21 19:51:24.623618
# Unit test for function pipe
def test_pipe():
    result = pipe(
        '<body>Hello, world!</body>',
        lambda x: x.replace('body', 'html'),
        lambda x: x.replace('Hello, world!', 'Hello, function programming!')
    )

    assert isinstance(result, str)
    assert result == '<html>Hello, function programming!</html>'



# Generated at 2022-06-21 19:51:30.743099
# Unit test for function cond
def test_cond():
    def is_even(value):
        return value % 2 == 0
    def is_odd(value):
        return value % 2 != 0

    def even_increase(value):
        return increase(value)
    def odd_increase(value):
        return value

    cond_increase = cond([
        (is_even, even_increase),
        (is_odd, odd_increase)
    ])

    assert cond_increase(2) == 3
    assert cond_increase(1) == 1

# Generated at 2022-06-21 19:51:41.794154
# Unit test for function cond
def test_cond():
    def zero_condition(value):
        return value == 0

    def odd_condition(value):
        return value % 2 == 1

    def even_condition(value):
        return value % 2 == 0

    def increase_execute(value):
        return value + 1

    def multiply_execute(value):
        return value * 2

    assert cond([
        (zero_condition, increase_execute),
        (odd_condition, multiply_execute),
        (even_condition, increase_execute)
    ])(0) == 1

    assert cond([
        (zero_condition, increase_execute),
        (odd_condition, multiply_execute),
        (even_condition, increase_execute)
    ])(1) == 2


# Generated at 2022-06-21 19:51:44.594007
# Unit test for function pipe
def test_pipe():
    value = [1, 2, 3]
    assert pipe(value, curried_map(increase), curried_map(increase), curried_filter(eq(2))) == [3, 4]


if __name__ == '__main__':
    test_pipe()

# Generated at 2022-06-21 19:51:49.420300
# Unit test for function curried_map
def test_curried_map():
    """ function test_curried_map

    test for function curried_map

    :returns: void
    :rtype: void
    """
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-21 19:51:52.279357
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x < 0, lambda _: 'less then zero'),
        (lambda x: x == 0, lambda _: 'equal zero'),
        (lambda x: x > 0, lambda _: 'great then zero')
    ])(10) == 'great then zero'



# Generated at 2022-06-21 19:52:06.656431
# Unit test for function eq
def test_eq():
    assert eq(1, 2) is False
    assert eq(3, 3) is True



# Generated at 2022-06-21 19:52:10.870513
# Unit test for function cond
def test_cond():
    def cond_decorator(fn):
        return cond([
            (eq(0), identity),
            (eq(1), compose(increase)),
            (eq(2), compose(increase, increase)),
        ])

    fn = cond_decorator(identity)
    assert fn(0) == 0
    assert fn(1) == 2
    assert fn(2) == 4

# Generated at 2022-06-21 19:52:11.891668
# Unit test for function identity
def test_identity():
    assert identity('test') == 'test'



# Generated at 2022-06-21 19:52:13.732651
# Unit test for function compose
def test_compose():
    assert compose(2, increase, identity) == 3
    assert compose(2, identity) == 2



# Generated at 2022-06-21 19:52:25.298200
# Unit test for function memoize
def test_memoize():
    from random import randint
    from time import time

    @memoize
    def factorial(n):
        if n in (0, 1):
            return 1
        return n * factorial(n - 1)

    assert factorial(0) == 1
    assert factorial(1) == 1
    assert factorial(2) == 2

    assert factorial(3) == 6
    assert factorial(4) == 24
    assert factorial(5) == 120

    assert factorial(6) == 720
    assert factorial(7) == 5040
    assert factorial(8) == 40320

    assert factorial(9) == 362880
    assert factorial(10) == 3628800
    assert factorial(11) == 39916800

    @memoize
    def new_randint():
        return randint

# Generated at 2022-06-21 19:52:30.487753
# Unit test for function curried_filter
def test_curried_filter():
    """
    Unit test for function curried_filter

    :returns: None
    :rtype: None
    """
    collection = [1, 3, 4, 5]
    expected_result = [3, 4, 5]
    filtered = curried_filter(lambda x: x > 2, collection)
    assert expected_result == filtered, \
        "function curried_filter returns wrong result for [1, 3, 4, 5] and x > 2"



# Generated at 2022-06-21 19:52:34.605128
# Unit test for function pipe
def test_pipe():
    assert pipe(2, lambda x: x ** 2, lambda x: x + 2) == 6
    assert pipe(2, lambda x: x ** 2, lambda x: x + 2, lambda x: x + 2) == 8



# Generated at 2022-06-21 19:52:39.140832
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(1)) == 1
    assert find([1, 2, 3], eq(2)) == 2
    assert find([1, 2, 3], eq(3)) == 3
    assert find([1, 2, 3], eq(4)) is None



# Generated at 2022-06-21 19:52:41.124626
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-21 19:52:46.807924
# Unit test for function find
def test_find():
    assert find([1, 5, 8, 9, 10], lambda x: x % 2 == 0) == 8
    assert find([1, 5, 8, 9, 10], lambda x: x > 10) is None
    assert find([1, 5, 8, 9, 10], lambda x: x == 10) == 10
    assert find([], lambda x: False) is None
    assert find([], lambda x: True) is None



# Generated at 2022-06-21 19:53:02.281221
# Unit test for function eq
def test_eq():
    result = eq(5)(5)
    assert result == True
    result = eq(5)(4)
    assert result == False


# Generated at 2022-06-21 19:53:05.247289
# Unit test for function identity
def test_identity():
    assert identity(5) == 5
    assert identity((5, 10)) == (5, 10)
    assert identity("test") == "test"


# Generated at 2022-06-21 19:53:09.835620
# Unit test for function curry
def test_curry():
    @curry
    def sum_three(a, b, c):
        return a + b + c
    assert sum_three(1)(2)(3) == 6
    assert sum_three(1, 2)(3) == 6
    assert sum_three(1)(2, 3) == 6
    assert sum_three(1, 2, 3) == 6
    assert sum_three(1)(2)(3) == 6



# Generated at 2022-06-21 19:53:11.877877
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase)(range(3)) == [1, 2, 3]



# Generated at 2022-06-21 19:53:16.774250
# Unit test for function compose
def test_compose():
    """
    Unit test for function compose

    >>> compose(2, increase, increase, increase)
    5

    >>> compose(2,  increase)
    3

    >>> compose(None, increase, increase)
    None
    """
    pass



# Generated at 2022-06-21 19:53:20.054982
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert eq(1, 1.0)
    assert not eq(1, 2)
    assert not eq(1, '1')



# Generated at 2022-06-21 19:53:21.471330
# Unit test for function eq
def test_eq():
    assert not eq(1, 2)
    assert eq(1, 1)



# Generated at 2022-06-21 19:53:29.039366
# Unit test for function memoize
def test_memoize():
    def test_fn(x):
        print('Function invoked')
        return x + 1

    test_fn = memoize(test_fn)

    # First invocation
    assert test_fn(10) == 11

    # Second invocation with same argument
    assert test_fn(10) == 11

    # Third invocation with different argument
    assert test_fn(20) == 21



# Generated at 2022-06-21 19:53:30.094570
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-21 19:53:34.977116
# Unit test for function pipe
def test_pipe():
    assert pipe('Hello', identity, str.upper, str.lower) == 'hello'
    assert pipe('Hello', str.upper, identity, str.lower, str.capitalize) == 'Hello'
    assert pipe(10, increase, increase, increase, lambda x: x / 3) == 4



# Generated at 2022-06-21 19:53:51.000250
# Unit test for function find
def test_find():
    assert find([
        {'id': 1, 'name': 'John'},
        {'id': 2, 'name': 'Emma'},
        {'id': 3, 'name': 'Jack'},
        {'id': 4, 'name': 'Sara'},
    ], lambda x: x['id'] == 2) == {'id': 2, 'name': 'Emma'}



# Generated at 2022-06-21 19:53:53.167911
# Unit test for function pipe
def test_pipe():
    assert pipe([], curried_map(increase), curried_filter(eq(3))) == [3]


# Generated at 2022-06-21 19:54:00.801235
# Unit test for function find
def test_find():
    data = [
        {
            "id": 1,
            "firstName": "Bob",
            "lastName": "Morane",
            "email": "bob.morane@mail.com"
        },
        {
            "id": 2,
            "firstName": "Charlie",
            "lastName": "Morane",
            "email": "charlie.morane@mail.com"
        },
        {
            "id": 3,
            "firstName": "Alice",
            "lastName": "Morane",
            "email": "alice.morane@mail.com"
        },
    ]
    result = find(data, lambda user: user['id'] == 2)
    assert result == data[1]


# Generated at 2022-06-21 19:54:06.973335
# Unit test for function memoize
def test_memoize():
    def add(value, value1):
        return value + value1

    curried_add = memoize(curry(add))

    assert curried_add(1)(2) == 3
    assert curried_add(1)(2) == 3
    assert curried_add(2)(2) == 4
    assert curried_add(1)(2) == 3
    assert curried_add(2)(2) == 4

# Generated at 2022-06-21 19:54:10.846616
# Unit test for function compose
def test_compose():
    assert compose(1, lambda x: 2 * x, lambda x: x + 1) == 4
    assert compose(0, lambda x: x + 1, lambda x: x * 2) == 2
    assert compose(10, lambda x: x + 10, lambda x: x * 2) == 40

    # Unit test for function cond

# Generated at 2022-06-21 19:54:11.944676
# Unit test for function compose
def test_compose():
    assert(compose(1, increase, increase, increase) == 4)



# Generated at 2022-06-21 19:54:15.287389
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False
    assert eq(2)(2) is True
    assert eq(1)(2) is False
    assert eq(1, 2) is False
    assert eq(1, 1) is True
    assert eq(2)(2) is True
    assert eq(2)(1) is False



# Generated at 2022-06-21 19:54:23.253637
# Unit test for function curry
def test_curry():
    @curry
    def concat(x, y, z):
        return x + y + z

    assert concat('a', 'b', 'c') == 'abc'
    assert concat('a', 'b')('c') == 'abc'
    assert concat('a')('b')('c') == 'abc'
    assert concat(1, 2, 3) == 6
    assert concat(1, 2)(3) == 6
    assert concat(1)(2)(3) == 6



# Generated at 2022-06-21 19:54:24.014779
# Unit test for function increase
def test_increase():
    assert increase(1) == 2


# Generated at 2022-06-21 19:54:24.885174
# Unit test for function eq
def test_eq():
    assert eq(1, 1)



# Generated at 2022-06-21 19:54:42.346997
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:54:45.310624
# Unit test for function compose
def test_compose():
    assert compose(1, lambda x: x + 1, lambda x: x * 2) == 4
    assert compose(1, lambda x: x * 2, lambda x: x + 1, lambda x: x * 2) == 6



# Generated at 2022-06-21 19:54:47.460487
# Unit test for function pipe
def test_pipe():
    assert pipe(
        0,
        lambda x: x + 2,
        lambda x: x ** 2,
        lambda x: x / 3,
    ) == 2



# Generated at 2022-06-21 19:54:50.216319
# Unit test for function pipe
def test_pipe():
    assert pipe(1, lambda x: x+2, lambda x: x**2, lambda x: x+1) == 16



# Generated at 2022-06-21 19:54:53.470559
# Unit test for function curried_map
def test_curried_map():
    """
    Unit test for function curried_map.
    For correctly implementation of curried_map we have to be sure that four calls of curried_map with
    one argument returning same curried_map function.
    """
    assert(callable(curried_map()))



# Generated at 2022-06-21 19:54:56.751006
# Unit test for function pipe
def test_pipe():
    @pipe
    def add(x: int, y: int) -> int:
        return x + y

    assert add(1, 2) == 3, 'Pipe should be applied functions from left to right'



# Generated at 2022-06-21 19:54:59.524507
# Unit test for function curried_map
def test_curried_map():
    function = curried_map(increase)

    assert function([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-21 19:55:05.528019
# Unit test for function pipe
def test_pipe():
    string_to_upper = lambda string : string.upper()
    string_to_lower = lambda string : string.lower()
    string_to_title = lambda string: string.title()
    string_to_capitalize = lambda string: string.capitalize()

    assert pipe('hello', string_to_upper, string_to_lower) == 'hello'
    assert pipe('hello', string_to_upper, string_to_title) == 'Hello'
    assert pipe('hello', string_to_capitalize, string_to_lower) == 'hello'


# Generated at 2022-06-21 19:55:12.242436
# Unit test for function cond
def test_cond():
    def even(n: int) -> bool:
        return n % 2 == 0
    def odd(n: int) -> bool:
        return not even(n)
    a = cond([
        (even, increase),
        (odd, identity)
    ])
    assert a(1) == 1
    assert a(2) == 3
    assert a(10) == 11
    assert a(11) == 11
    assert a(22) == 23
    print('Test for cond complete')


# Generated at 2022-06-21 19:55:14.366293
# Unit test for function find
def test_find():
    assert find([], lambda x: x == 1) is None
    assert find([1], lambda x: x == 1) == 1
    assert find([1, 2], lambda x: x == 1) == 1
    assert find([1, 2, 3], lambda x: x == 2) == 2
    assert find([1, 2, 3], lambda x: x == 3) == 3



# Generated at 2022-06-21 19:55:52.543384
# Unit test for function curried_filter
def test_curried_filter():
    filtered_list = curried_filter(lambda x: x % 2 == 0, range(5))
    assert filtered_list == [0, 2, 4]

    curried = curried_filter(lambda x: x % 2 == 0)
    filtered_list = curried(range(5))
    assert filtered_list == [0, 2, 4]



# Generated at 2022-06-21 19:55:57.638987
# Unit test for function curry
def test_curry():
    def fn(x, y, z):
        return x + y + z

    fn_curry_curried = curry(fn)
    fn_curry_curried_1 = fn_curry_curried(1)
    fn_curry_curried_1_2 = fn_curry_curried_1(2)
    assert 4 == fn_curry_curried_1_2(1)



# Generated at 2022-06-21 19:56:01.331252
# Unit test for function curried_filter
def test_curried_filter():
    L = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    odd = lambda x: (x % 2) == 1
    even = lambda x: (x % 2) == 0
    assert curried_filter(odd, L) == [1, 3, 5, 7, 9]
    assert curried_filter(even, L) == [2, 4, 6, 8, 10]



# Generated at 2022-06-21 19:56:05.151261
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-21 19:56:07.591200
# Unit test for function increase
def test_increase():
    assert increase(10) == 11
    assert increase(None) is None


# Generated at 2022-06-21 19:56:15.227591
# Unit test for function compose
def test_compose():
    assert compose(
        30, increase, increase, increase, increase, increase, increase)(30) == 36
    assert compose(
        'Hello',
        lambda value: f'{value}, World!',
        lambda value: f'{value} from Python')('Hello') == 'Hello from Python, World!'
    assert compose(
        'Hello, World!',
        lambda string: string.split(' '),
        lambda string: string[0],
        lambda string: string.replace('o', '0')) == 'Hell0, World!'



# Generated at 2022-06-21 19:56:22.862304
# Unit test for function eq
def test_eq():

    # True
    assert(eq(1, 1) == True)
    assert(eq(1)(1) == True)
    assert(curry(eq)(1)(1) == True)
    assert(eq(1, 1, 1) == True)
    assert(eq(1, 1, 1, 1, 1) == True)

    # False
    assert(eq(1, 2) == False)
    assert(eq(1)(2) == False)
    assert(curry(eq)(1)(2) == False)
    assert(eq(1, 1, 1, 2) == False)
    assert(eq(1, 1, 1, 1, 2) == False)


# Generated at 2022-06-21 19:56:27.084860
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(int)(['1','2','3','4']) == [1,2,3,4]
    assert curried_map(lambda x: x*2)([1,2,3]) == [2, 4, 6]


# Generated at 2022-06-21 19:56:35.572062
# Unit test for function curried_map
def test_curried_map():
    def add(a, b):
        return a + b

    # curried_map is function for apply function on collection
    # curried_map :: Collection a -> Function(a -> b) -> Collection b
    # curried_map function return function to apply function on collection
    # curried_map(collection) :: Function(a -> b) -> Collection b
    double = curried_map(add(1))
    assert double([1, 2, 3]) == [2, 3, 4]
    assert double([2, 3, 4]) == [3, 4, 5]
    assert double([3, 4, 5]) == [4, 5, 6]
    assert double([4, 5, 6]) == [5, 6, 7]



# Generated at 2022-06-21 19:56:38.356666
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity('hello') == 'hello'
    assert identity([1, 2, 3]) == [1, 2, 3]