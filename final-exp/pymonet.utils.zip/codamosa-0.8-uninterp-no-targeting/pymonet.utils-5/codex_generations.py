

# Generated at 2022-06-21 19:47:22.841633
# Unit test for function cond
def test_cond():
    test_iterator = [
        (True, 'First'),
        (False, 'Second'),
        (True, 'Third'),
    ]

    condition_list = [
        (lambda x: x, lambda x: test_iterator[0][1]),
        (lambda x: x, lambda x: test_iterator[1][1]),
        (lambda x: x, lambda x: test_iterator[2][1]),
    ]

    test_function = cond(condition_list)

    for item in test_iterator:
        assert item[1] == test_function(item[0])

# Generated at 2022-06-21 19:47:26.055719
# Unit test for function compose
def test_compose():
    assert(compose(1, lambda x: x + 1) == 2)
    assert(compose(2, lambda x: x + 3, lambda x: x * 5) == 25)



# Generated at 2022-06-21 19:47:29.418588
# Unit test for function pipe
def test_pipe():
    assert pipe(
        [1, 2, 3],
        curried_map(increase),
        curried_filter(
            curried_map(eq(2))
        )
    ) == [2, 3]

# Generated at 2022-06-21 19:47:32.024728
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq(1, 2, 3) == False



# Generated at 2022-06-21 19:47:33.420321
# Unit test for function increase
def test_increase():
    """
    Test if function increase return right result
    """
    assert increase(1) == 2


# Generated at 2022-06-21 19:47:35.803926
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-21 19:47:37.452603
# Unit test for function pipe
def test_pipe():
    assert pipe(2, increase, increase) == 4


# Generated at 2022-06-21 19:47:40.870223
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(True)
    assert identity(0) == 0
    assert identity(False) == False



# Generated at 2022-06-21 19:47:41.742191
# Unit test for function identity
def test_identity():
    value = 42
    assert identity(value) == value



# Generated at 2022-06-21 19:47:46.640429
# Unit test for function pipe
def test_pipe():
    assert pipe(1, lambda x: x + 2, lambda x: x * x) == 1 + 2 * (1 + 2)



# Generated at 2022-06-21 19:47:58.742590
# Unit test for function curried_map
def test_curried_map():
    li = [1, 2, 3, 4]
    assert li == curried_map(identity, li)
    assert [2, 3, 4, 5] == curried_map(increase, li)
    assert [2, 3, 4, 5] == curried_map(increase)(li)
    assert [1, 2, 3, 4] == curried_map(identity)(li)

# Unit tests for function curried_filter

# Generated at 2022-06-21 19:48:01.173678
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2
    assert increase(4) == 5



# Generated at 2022-06-21 19:48:06.765418
# Unit test for function curried_map
def test_curried_map():
    """
    Unit test.

    :returns: None
    :rtype: None
    """
    result = curried_map(increase)([1, 2, 3])

    assert result == [2, 3, 4], 'Failed to curried function'

    assert curried_map(increase, [1, 2, 3]) == result, 'Failed to curried function'



# Generated at 2022-06-21 19:48:08.204236
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(0, 1)



# Generated at 2022-06-21 19:48:09.288225
# Unit test for function pipe
def test_pipe():
    assert pipe(1, increase, increase) == 3



# Generated at 2022-06-21 19:48:11.505408
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5]) == [2, 4]



# Generated at 2022-06-21 19:48:12.830047
# Unit test for function compose
def test_compose():
    assert compose(1, increase, increase, increase) == 4



# Generated at 2022-06-21 19:48:16.037216
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)([1, 2, 3, 4]) == [2, 4]


# Generated at 2022-06-21 19:48:17.121941
# Unit test for function increase
def test_increase():
    assert increase(0), 1



# Generated at 2022-06-21 19:48:18.954777
# Unit test for function eq
def test_eq():
    assert (eq(1, 1))
    assert (not eq(1, 2))



# Generated at 2022-06-21 19:48:25.677777
# Unit test for function increase
def test_increase():
    """
    Test function increase.
    Function increase should increase number by 1.

    :returns:
    :rtype: Boolean
    """
    assert increase(1) == 2
    assert increase(2) == 3
    assert increase(10) == 11
    assert increase(0.5) == 1.5
    return True


# Generated at 2022-06-21 19:48:36.583184
# Unit test for function cond
def test_cond():
    def is_even(a):
        return a % 2 == 0

    def is_positive(a):
        return a > 0

    def double_value(a):
        return a * 2

    def triple_value(a):
        return a * 3

    def half_value(a):
        return a * 0.5

    def half_minus_value(a):
        return - a * 0.5

    cond_fn = cond([
        (is_even, double_value),
        (is_positive, triple_value),
        (lambda a: True, half_value),
    ])

    cond_fn_with_default = cond([
        (is_even, double_value),
        (is_positive, triple_value),
        (lambda a: True, half_minus_value),
    ])

    assert cond_

# Generated at 2022-06-21 19:48:40.200998
# Unit test for function memoize
def test_memoize():
    fun = lambda x: x + 5
    fun_result = 10
    fun_memoized = memoize(fun, key=eq)

    assert fun_memoized(5) == fun_result
    assert fun_memoized(5) == fun_result
    assert fun_memoized(5) == fun_result
    assert fun_memoized(5) == fun_result



# Generated at 2022-06-21 19:48:43.136294
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda value: value > 2) == 3
    assert find([1, 2, 3, 4], lambda value: value > 100) is None



# Generated at 2022-06-21 19:48:50.353707
# Unit test for function cond
def test_cond():
    f = cond(
        [(eq(0), lambda x: 0),
         (eq(1), lambda x: 1),
         (eq(2), lambda x: 2),
         (eq(3), lambda x: 3),
         (eq(4), lambda x: 4),
         (eq(5), lambda x: 5),
         (eq(6), lambda x: 6),
         (eq(7), lambda x: 7),
         (eq(8), lambda x: 8),
         (eq(9), lambda x: 9),
         ])
    assert f(0) == 0
    assert f(1) == 1
    assert f(2) == 2
    assert f(3) == 3
    assert f(4) == 4
    assert f(5) == 5
    assert f(6) == 6

# Generated at 2022-06-21 19:48:57.139812
# Unit test for function curried_filter
def test_curried_filter():
    def test_eq(a):
        return a[0] == a[1]

    assert curried_filter(test_eq)([(1, 1), (1, 2), (1, 3)]) == [(1, 1)]
    assert curried_filter(test_eq)([(1, 1), (1, 2)]) == [(1, 1)]
    assert curried_filter(test_eq)([(1, 1)]) == [(1, 1)]
    assert curried_filter(test_eq)([]) == []


# Generated at 2022-06-21 19:48:58.936111
# Unit test for function pipe
def test_pipe():
    result = pipe(5, increase, increase)
    assert result == 7, 'Result must be 7'


# Generated at 2022-06-21 19:49:02.112073
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-21 19:49:05.943273
# Unit test for function pipe
def test_pipe():
    def add(x, y):
        return x + y

    add1 = curry(add, 2)
    assert pipe(1, increase, add1) == 3
    assert pipe(2, add1) == 4
    assert pipe(3, increase) == 4



# Generated at 2022-06-21 19:49:18.379961
# Unit test for function memoize
def test_memoize():
    def expensive():
        global count
        count += 1
        return count

    global count
    count = 0

    memoized = memoize(expensive)
    memoized_eq = memoize(expensive, eq)

    #first call
    assert memoized([]) == memoized_eq([]) == memoized(()) == memoized_eq(()) == memoized({}) == memoized_eq({}) == 1
    #second call
    assert memoized([]) == memoized_eq([]) == 1
    assert memoized(()) == memoized_eq(()) == 1
    assert memoized({}) == memoized_eq({}) == 1
    #third call
    assert memoized([]) == memoized_eq([]) == 1
    assert memoized(()) == memoized_eq(()) == 1
    assert memoized({}) == memoized_eq({})

# Generated at 2022-06-21 19:49:23.834982
# Unit test for function pipe
def test_pipe():
    assert pipe(2, identity, increase, increase) == 4
    assert pipe('qwerty', identity, lambda x: x.upper()) == 'QWERTY'

# Generated at 2022-06-21 19:49:27.278657
# Unit test for function cond
def test_cond():
    """
    Run unit tests for function cond.
    """
    assert cond([
       (lambda x: x % 2 == 0,
        lambda x: x / 2),
       (lambda x: x % 2 != 0,
        lambda x: x + 1)
    ])(1) == 2



# Generated at 2022-06-21 19:49:29.331067
# Unit test for function identity
def test_identity():
    print(identity(3))



# Generated at 2022-06-21 19:49:35.388913
# Unit test for function curried_map
def test_curried_map():
    assert(
        curried_map(lambda x: x + 1, [1, 2, 3, 4]) == [2, 3, 4, 5]
    )
    assert(
        curried_map(lambda x: x + 1)([1, 2, 3, 4]) == [2, 3, 4, 5]
    )
    assert(
        curried_map(lambda x: x + 1, []) == []
    )
    assert(
        curried_map(lambda x: x + 1) == []
    )


# Generated at 2022-06-21 19:49:37.954428
# Unit test for function curried_map
def test_curried_map():
    assert(curried_map(increase)([1, 2, 3]) == [2, 3, 4])


# Generated at 2022-06-21 19:49:43.899381
# Unit test for function cond
def test_cond():
    """
    Testing for function cond.
    """
    _test_function = cond([
        (lambda x: x < 5, lambda x: x ** 2),
        (lambda x: x < 10, lambda x: x ** 3),
        (lambda x: True, lambda x: print('foo')),
    ])

    assert _test_function(1) == 1
    assert _test_function(3) == 9
    assert _test_function(7) == 343
    assert _test_function(15) == None


# Generated at 2022-06-21 19:49:47.645159
# Unit test for function compose
def test_compose():
    assert compose(
        0,
        lambda x: x + 1,
        lambda x: x * 2,
        lambda x: x ** 2,
    ) == 4



# Generated at 2022-06-21 19:49:49.911014
# Unit test for function eq
def test_eq():
    assert(eq(1, 1) is True)
    assert(eq(2, 3) is False)



# Generated at 2022-06-21 19:49:51.618890
# Unit test for function compose
def test_compose():
    """
    Unit test for compose
    """
    assert compose(5, increase, increase) == 7



# Generated at 2022-06-21 19:49:53.814809
# Unit test for function identity
def test_identity():
    assert identity(0) == 0, "Identity function not working"
    assert identity("") == "", "Identity function not working"


# Generated at 2022-06-21 19:50:02.633935
# Unit test for function curried_filter
def test_curried_filter():
    def is_even(value: int) -> bool:
        return value % 2 == 0

    curried_filter(is_even)([1, 2, 3, 4, 6]) == [2, 4, 6]


# Generated at 2022-06-21 19:50:07.649924
# Unit test for function compose
def test_compose():
    assert compose(1, identity, identity) == 1
    assert compose(1, increase, increase) == 3
    assert compose(1, increase) == 2
    assert compose(1, increase, increase, identity) == 3



# Generated at 2022-06-21 19:50:08.829735
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:50:15.446202
# Unit test for function memoize
def test_memoize():
    print("test memoize with fn: (x) -> x + 1")
    fn = (lambda x: x + 1)
    fn = memoize(fn)
    print("\ttest fn(1)")
    assert 1 == fn(1)
    print("\ttest fn(1)")
    assert 1 == fn(1)
    print("\ttest fn(2)")
    assert 2 == fn(2)



# Generated at 2022-06-21 19:50:18.132662
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(None, 1)
    assert not eq(1, None)
    assert eq(None, None)



# Generated at 2022-06-21 19:50:19.033663
# Unit test for function pipe
def test_pipe():
    assert pipe(2, lambda x: x * 3, lambda x: x + 1) == 7

# Generated at 2022-06-21 19:50:21.441629
# Unit test for function curry
def test_curry():
    def fn(x, y, z):
        return x + y + z
    assert curry(fn)(1)(2)(3) == 6
    assert curry(fn, 2)(1)(2) == 3
    assert curry(fn, 3)(1, 2, 3) == 6


test_curry()

# Generated at 2022-06-21 19:50:24.447165
# Unit test for function compose
def test_compose():
    assert compose(1, identity) == 1
    assert compose(1, increase) == 2
    assert compose(1, lambda x: x + 1, lambda x: x + 1) == 3
    assert compose(1, lambda x: x - 1, lambda x: x - 1) == -1
    assert compose(1, lambda x: x - 1, lambda x: x + 1) == 1
    assert compose(1, lambda x: x - 1, lambda x: x + 1, lambda x: x + 5) == 7


# Generated at 2022-06-21 19:50:36.163125
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1, [1, 2, 3]) == curried_map(lambda x: x + 1)([1, 2, 3])
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == curried_map(lambda x: x + 1, [1, 2, 3])
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(lambda x: x + 1)([1, 2, 3]) == curried_

# Generated at 2022-06-21 19:50:48.538992
# Unit test for function curry
def test_curry():
    def foo(a, b, c, d, e):
        return a, b, c, d, e

    assert curry(foo)(1, 2, 3, 4, 5) == (1, 2, 3, 4, 5)
    assert curry(foo, 1)(1) == (1, None, None, None, None)
    assert curry(foo, 1)(1, b=2) == (1, 2, None, None, None)
    assert curry(foo, 1)(1, b=2, c=3) == (1, 2, 3, None, None)
    assert curry(foo, 1)(1, b=2, c=3, d=4) == (1, 2, 3, 4, None)

# Generated at 2022-06-21 19:50:55.669114
# Unit test for function pipe
def test_pipe():
    assert pipe(1, identity, identity, increase) == 2



# Generated at 2022-06-21 19:50:56.998006
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x < 3, [1, 2, 3, 4]) == [1, 2]



# Generated at 2022-06-21 19:51:00.240463
# Unit test for function curried_map
def test_curried_map():
    curried_map_increase = curried_map(increase)
    curried_map_increase_test_list = curried_map_increase([1, 2, 3])
    assert curried_map_increase_test_list == [2, 3, 4]



# Generated at 2022-06-21 19:51:03.269150
# Unit test for function compose
def test_compose():
    assert compose(3, increase, increase) == 5


# Generated at 2022-06-21 19:51:09.525041
# Unit test for function cond
def test_cond():
    def equal_5(x: int) -> bool:
        return x == 5

    assert cond([
        (equal_5, lambda _: "a"),
        (lambda _: True, lambda _: "b")
    ])(5) == "a"

    assert cond([
        (equal_5, lambda _: "a"),
        (lambda _: True, lambda _: "b")
    ])(6) == "b"



# Generated at 2022-06-21 19:51:15.038785
# Unit test for function cond
def test_cond():
    condition_list = [
        (lambda x: x[0] > x[1], lambda x: x[0] + x[1]),
        (lambda x: x[0] < x[1], lambda x: x[0] - x[1]),
        (lambda x: x[0] == x[1], lambda x: x[0] * x[1]),
    ]

    assert cond(condition_list)(2, 2) == 4



# Generated at 2022-06-21 19:51:18.726518
# Unit test for function pipe
def test_pipe():
    assert pipe([1, 2, 3, 4],
                lambda collection: list(map(lambda item: item + 1, collection)),
                lambda collection: list(filter(lambda item: item % 2 == 0, collection))) == [3, 5]



# Generated at 2022-06-21 19:51:27.486479
# Unit test for function memoize
def test_memoize():
    state = 0

    @memoize
    def add_one(x: int) -> int:
        global state
        prev_state = state
        state += 1
        return x + state - prev_state

    assert(add_one(3) == 4)
    assert(add_one(3) == 4)
    assert(add_one(3) == 4)
    assert(add_one(2) == 3)
    assert(add_one(2) == 3)
    assert(add_one(2) == 3)
    assert(add_one(3) == 4)



# Generated at 2022-06-21 19:51:28.448987
# Unit test for function increase
def test_increase():
    assert increase(1) == 2


# Generated at 2022-06-21 19:51:30.629391
# Unit test for function eq
def test_eq():
    assert eq(1)(1)
    assert not eq(1)(2)
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-21 19:51:39.527187
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda value: value > 1, [1, 2, 3, 4]) == [2, 3, 4]
    assert curried_filter(lambda value: value > 1)([1, 2, 3, 4]) == [2, 3, 4]



# Generated at 2022-06-21 19:51:41.668666
# Unit test for function pipe
def test_pipe():
    value = identity(2)
    functions = (increase, identity)
    assert pipe(value, *functions) == 3



# Generated at 2022-06-21 19:51:48.184182
# Unit test for function curry
def test_curry():
    def test_function(*args):
        return reduce(lambda acc, v: acc + v, args)

    assert curry(test_function)(1, 1, 1) == 3
    assert curry(test_function, 2)(1)(2) == 3
    assert curry(test_function, 3)(1)(2)(3) == 6



# Generated at 2022-06-21 19:51:56.761933
# Unit test for function cond
def test_cond():
    assert 31 == cond(
        [
            (eq(1), identity),
            (eq(2), increase),
            (identity, lambda x: x + 10)
        ]
    )(1)

    assert 32 == cond(
        [
            (eq(1), identity),
            (eq(2), increase),
            (identity, lambda x: x + 10)
        ]
    )(2)

    assert 33 == cond(
        [
            (eq(1), identity),
            (eq(2), increase),
            (identity, lambda x: x + 10)
        ]
    )(3)



# Generated at 2022-06-21 19:51:57.839171
# Unit test for function increase
def test_increase():
    assert increase(10) == 11



# Generated at 2022-06-21 19:52:03.449485
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda x: x % 2 == 0) == 2
    assert find([1, 2, 3, 4, 5], lambda x: x % 2 == 1) == 1
    assert find([1, 2, 3, 4, 5], lambda x: x > 10) is None



# Generated at 2022-06-21 19:52:06.793970
# Unit test for function curried_map
def test_curried_map():

    curried_map_inc = curried_map(increase)
    test_list = [1, 2, 3]

    assert curried_map_inc(test_list) == [2, 3, 4]



# Generated at 2022-06-21 19:52:07.692014
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:52:08.597494
# Unit test for function identity
def test_identity():
    assert identity(1) == 1


# Generated at 2022-06-21 19:52:10.101434
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-21 19:52:19.896479
# Unit test for function curried_filter
def test_curried_filter():
    """
    Test for function curried_filter for using as a partial function.
    """
    assert curried_filter(lambda x: x == 2)([1, 2, 3]) == [2]



# Generated at 2022-06-21 19:52:20.798502
# Unit test for function identity
def test_identity():
    assert identity(2) == 2


# Generated at 2022-06-21 19:52:24.851043
# Unit test for function curry
def test_curry():
    """
    Test case for curry function.

    :returns: Unit test result
    :rtype: Boolean
    """
    def sum(a, b):
        return a + b

    curried_sum = curry(sum)
    return curried_sum(1)(2) == 3



# Generated at 2022-06-21 19:52:26.873834
# Unit test for function find
def test_find():
    assert find([1, 2, 3], eq(1)) == 1
    assert find([1, 2, 3], eq(4)) is None


# Generated at 2022-06-21 19:52:29.661279
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda value: value == 2) == 2
    assert find([1, 2, 3], lambda value: value == 5) is None
    assert find([], lambda value: value == 5) is None


# Generated at 2022-06-21 19:52:31.741826
# Unit test for function increase
def test_increase():  # pragma: no cover
    assert increase(1) == 2
    assert increase(2) == 3
    assert increase(3) == 4



# Generated at 2022-06-21 19:52:35.655038
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4, 5], lambda value: value == 3) == 3
    assert find([1, 2, 3, 4, 5], lambda value: value == 10) == None



# Generated at 2022-06-21 19:52:42.148721
# Unit test for function identity
def test_identity():
    assert identity(1) == 1, 'identity({}) is not 1'.format(identity(1))
    assert identity('hello') == 'hello', 'identity({}) is not "hello"'.format(identity(
        'hello'))
    assert identity([1, 2, 3]) == [1, 2, 3], 'identity({}) is not [1, 2, 3]'.format(
        identity([1, 2, 3]))


test_identity()



# Generated at 2022-06-21 19:52:49.819167
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x+5, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]) == [5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
    assert curried_map(lambda x: x+5, curried_map(lambda x: x+5, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]))  == [10, 11, 12, 13, 14, 15, 16, 17, 18, 19]
    assert curried_map(lambda x: x*x, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]) == [0, 1, 4, 9, 16, 25, 36, 49, 64, 81]

# Generated at 2022-06-21 19:52:51.520374
# Unit test for function identity
def test_identity():
    assert identity("hello") == "hello"



# Generated at 2022-06-21 19:53:10.524425
# Unit test for function curry
def test_curry():
    def simple_func(x, y):
        return x + y

    curried_func = curry(simple_func)
    assert 2 == curried_func(1, 1)
    assert 3 == curried_func(1)(2)



# Generated at 2022-06-21 19:53:21.435945
# Unit test for function cond
def test_cond():
    from operator import eq
    from operator import ne
    from collections import namedtuple
    from collections import deque
    from unittest import TestCase

    class TestCond(TestCase):
        def test_list_of_tuples_or_list_of_any(self):
            result = cond([
                (lambda x: eq(x, 1), lambda x: x + 1),  # if x equals to 1 then x + 1
                (lambda x: ne(x, 1), lambda x: x),      # if x not equals to 1 then x
            ])(1)  # result should be 2
            self.assertEqual(result, 2)


# Generated at 2022-06-21 19:53:28.497404
# Unit test for function curried_filter
def test_curried_filter():
    func = curried_filter(lambda x: x > 5)
    assert func([1, 2, 3, 4, 5, 6]) == [6]
    assert func([1, 2, 3, 4, 5]) == []
    assert func([6, 7, 8, 9, 10]) == [6, 7, 8, 9, 10]



# Generated at 2022-06-21 19:53:29.590070
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-21 19:53:33.128646
# Unit test for function curried_map
def test_curried_map():
    curried_map_test = curried_map(identity)
    assert curried_map_test([1, 2, 3]) == [1, 2, 3]
    assert curried_map_test([4, 5, 6]) == [4, 5, 6]



# Generated at 2022-06-21 19:53:37.561414
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x > 2,
         lambda x: x + 1),
        (lambda x: x < -2,
         lambda x: x - 3),
        (lambda x: True,
         lambda x: x + 2)
    ])(2) == 4



# Generated at 2022-06-21 19:53:41.714038
# Unit test for function identity
def test_identity():
    assert identity(3) == 3
    assert identity('3') == '3'
    assert identity(None) is None
    assert identity([]) == []
    assert identity(identity) == identity
    assert identity([1, 2]) == [1, 2]
    assert identity({}) == {}
    assert identity({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}



# Generated at 2022-06-21 19:53:45.917230
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda item: item == 2) == 2
    assert find([1, 2, 3], lambda item: item == 4) is None
    assert find([], lambda item: item == 4) is None



# Generated at 2022-06-21 19:53:46.929010
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-21 19:53:51.503668
# Unit test for function curried_map
def test_curried_map():
    collection = [1, 2, 3, 4, 5]
    assert curried_map(identity)(collection) == collection
    assert curried_map(increase)(collection) == [2, 3, 4, 5, 6]



# Generated at 2022-06-21 19:54:30.900784
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-21 19:54:36.985289
# Unit test for function cond
def test_cond():
    test = cond([
        # (<Condition>, <Function>),
        (lambda x: x < 0, lambda x: x - 1),
        (lambda x: x == 0, lambda x: x),
        (lambda x: x > 0, lambda x: x + 1)
    ])

    assert test(2) == 3
    assert test(-2) == -3
    assert test(0) == 0


if __name__ == "__main__":
    test_cond()

# Generated at 2022-06-21 19:54:42.440480
# Unit test for function eq
def test_eq():
    assert eq(2, 2)
    assert not eq(2, 1)

    eq_1 = eq(1)
    eq_2 = eq(2)

    assert eq_1(1)
    assert not eq_1(2)

    assert eq_2(2)
    assert not eq_2(1)



# Generated at 2022-06-21 19:54:46.998307
# Unit test for function memoize
def test_memoize():
    def function_to_memoize():
        function_to_memoize.call_counter += 1
        return function_to_memoize.call_counter

    function_to_memoize.call_counter = 0

    memoized_function = memoize(function_to_memoize)

    assert 1 == memoized_function()
    assert 1 == memoized_function()



# Generated at 2022-06-21 19:54:48.506152
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, '1')



# Generated at 2022-06-21 19:54:51.085943
# Unit test for function eq
def test_eq():
    assert eq(10, 10)
    assert not eq(10, 11)


# Generated at 2022-06-21 19:55:01.529648
# Unit test for function find
def test_find():
    assert(find([], lambda truthy: truthy) is None)
    assert(find([False], lambda truthy: truthy) is None)
    assert(find([True], lambda truthy: truthy) is not None)
    assert(find(["item"], lambda _: True) == "item")
    assert(find(["item1", "item2"], lambda string: string == "item2") == "item2")
    assert(find(["item1", "item2"], lambda string: string == "item") is None)
    assert(find([{"key": 1}, {"key": 2}], lambda obj:  obj["key"] == 1) == {"key": 1})
    assert(find([{"key": 1}, {"key": 2}], lambda obj:  obj["key"] == 3) is None)



# Generated at 2022-06-21 19:55:05.882581
# Unit test for function memoize
def test_memoize():
    from random import random

    future_is_now = memoize(lambda num: "It's {} now".format(num), lambda x, y: x == y)
    current_time_1 = future_is_now(42)
    current_time_2 = future_is_now(42)
    new_time = future_is_now(random())

    assert current_time_1 == current_time_2
    assert new_time != current_time_2

# Generated at 2022-06-21 19:55:07.413935
# Unit test for function increase
def test_increase():
    assert increase(5) == 6
    assert increase(1) == 2
    assert increase(0) == 1
    assert increase(-1) == 0



# Generated at 2022-06-21 19:55:09.141228
# Unit test for function curry
def test_curry():
    @curry
    def test_div(a, b):
        return a / b

    result1 = test_div(1, 2)
    result2 = test_div(2)
    result3 = result2(1)
    assert result1 == result3 == 0.5

