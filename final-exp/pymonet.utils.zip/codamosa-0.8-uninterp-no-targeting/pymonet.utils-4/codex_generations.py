

# Generated at 2022-06-21 19:47:27.325314
# Unit test for function curried_filter
def test_curried_filter():
    data = [1, 2, 3, 4, 5]
    assert curried_filter(eq(2), data) == [2]
    assert curried_filter(eq(6), data) == []
    assert curried_filter(eq)(2)(data) == [2]
    assert curried_filter(eq, data)(2) == [2]
    assert curried_filter(eq, data, 2) == [2]



# Generated at 2022-06-21 19:47:34.062487
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 1, [1]) == []
    assert curried_filter(lambda x: x > 1, [1, 2, 3, 4]) == [2, 3, 4]
    assert curried_filter(lambda x: x > 2, [1, 2, 3, 4]) == [3, 4]
    assert curried_filter(lambda x: x > 3, [1, 2, 3, 4]) == [4]
    assert curried_filter(lambda x: x > 4, [1, 2, 3, 4]) == []

# Generated at 2022-06-21 19:47:41.837374
# Unit test for function curried_map
def test_curried_map():
    map_function = curried_map(lambda x: x ** 2)
    assert map_function([1, 2, 3]) == [1, 4, 9]
    assert map_function([4, 5, 6]) == [16, 25, 36]
    assert map_function([2, 3, 4, 5, 6, 7, 8, 9, 10]) == [
        4, 9, 16, 25, 36, 49, 64, 81, 100
    ]



# Generated at 2022-06-21 19:47:47.470771
# Unit test for function identity
def test_identity():
    assert identity('a') == 'a'
    assert identity(1) == 1
    assert identity(1.0) == 1.0
    assert identity([1]) == [1]
    assert identity((1,)) == (1,)



# Generated at 2022-06-21 19:47:51.284899
# Unit test for function compose
def test_compose():
    value = 0
    functions = [increase, increase, increase]
    assert compose(value, *functions) == 3



# Generated at 2022-06-21 19:47:55.472154
# Unit test for function eq
def test_eq():
    """
    Unit test for function eq.
    """
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(2, 1)



# Generated at 2022-06-21 19:47:59.629491
# Unit test for function eq
def test_eq():
    assert(eq(2, 2) == True)
    assert(eq(1, 2) == False)
    assert(eq('2', 2) == False)
    assert(eq(None, None) == True)
    assert(eq(None, 1) == False)



# Generated at 2022-06-21 19:48:02.335531
# Unit test for function find
def test_find():
    assert find([], identity) is None
    assert find([1, 2, 3, 4], eq(1)) == 1
    assert find([1, 2, 3, 4], eq(2)) == 2
    assert find([1, 2, 3, 4], eq(5)) is None



# Generated at 2022-06-21 19:48:09.619347
# Unit test for function curry
def test_curry():
    @curry
    def add(x, y):
        return x + y

    assert add(1)(2) == 3
    assert add(1, 2) == 3

    @curry
    def concat(sep, a, b):
        return sep.join([a, b])

    assert concat(', ')('a')('b') == 'a, b'
    assert concat(', ')('a', 'b') == 'a, b'
    assert concat(', ', 'a')('b') == 'a, b'
    assert concat(', ', 'a', 'b') == 'a, b'



# Generated at 2022-06-21 19:48:12.402396
# Unit test for function cond
def test_cond():
    def equal(val: int, val1: int):
        return val == val1

    assert cond([(equal(1), increase), (equal(2), identity)])(1) == 2



# Generated at 2022-06-21 19:48:20.137438
# Unit test for function curried_filter
def test_curried_filter():
    def is_even(number):
        return number % 2 == 0

    assert pipe(range(1, 11), curried_filter(is_even)) == [2, 4, 6, 8, 10]



# Generated at 2022-06-21 19:48:23.059960
# Unit test for function pipe
def test_pipe():
    fn = lambda x: x + x
    assert pipe(1, fn) == 2, 'Should be 2'
    assert pipe(1, fn, fn) == 4, 'Should be 4'



# Generated at 2022-06-21 19:48:25.706687
# Unit test for function identity
def test_identity():
    argument = 50
    assert argument == identity(argument)



# Generated at 2022-06-21 19:48:29.779583
# Unit test for function curried_filter
def test_curried_filter():
    even = lambda x: x % 2 == 0
    curried_filtered = curried_filter(even)
    assert [2, 4, 6] == curried_filtered([1, 2, 3, 4, 5, 6])



# Generated at 2022-06-21 19:48:30.820442
# Unit test for function increase
def test_increase():
    assert increase(0) == 1



# Generated at 2022-06-21 19:48:31.835194
# Unit test for function identity
def test_identity():
    assert identity(1) == 1


# Generated at 2022-06-21 19:48:35.395414
# Unit test for function pipe
def test_pipe():
    assert compose(
        'FFF',
        lambda s: s.lower(),
        lambda s: len(s),
        lambda x: (x > 1)
    ) is True


if __name__ == '__main__':
    test_pipe()

# Generated at 2022-06-21 19:48:37.519749
# Unit test for function eq
def test_eq():
    assert eq(1, 1) is True
    assert eq(1, 2) is False



# Generated at 2022-06-21 19:48:44.530172
# Unit test for function curry
def test_curry():
    assert curry(lambda x: x + 1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z, 6)(1)(2)(3)(4)(5)(6) == 21



# Generated at 2022-06-21 19:48:48.134635
# Unit test for function increase
def test_increase():
    assert increase(1) == 2

    incr = increase
    assert incr(1) == 2



# Generated at 2022-06-21 19:48:54.442816
# Unit test for function find
def test_find():
    collection: List[int] = [1, 2, 3, 4, 5, 6]
    assert find(collection, lambda x: x == 3) == 3
    assert find(collection, lambda x: x == 10) is None
    assert find(collection, lambda x: x % 2 == 0) == 2



# Generated at 2022-06-21 19:48:58.651105
# Unit test for function curry
def test_curry():
    def add(x, y):
        return x + y

    assert eq(curry(add, 2)(1, 1), 2)
    assert eq(curry(add, 1)(1), add)



# Generated at 2022-06-21 19:49:02.692069
# Unit test for function curried_map
def test_curried_map():
    test = [1,2,3,4,5]
    assert curried_map(lambda x: x + 1, test) == [2,3,4,5,6]
    assert curried_map(lambda x: x - 1)(test) == [0,1,2,3,4]


# Generated at 2022-06-21 19:49:04.512805
# Unit test for function identity
def test_identity():
    """
    Test identity function.
    """
    result = identity(1)
    assert result == 1



# Generated at 2022-06-21 19:49:05.214849
# Unit test for function increase
def test_increase():
    assert increase(5) == 6



# Generated at 2022-06-21 19:49:10.128753
# Unit test for function pipe
def test_pipe():
    assert pipe(
        1,
        lambda x: x + 2,
        lambda x: x + 3
    ) == 6
    assert pipe(1, lambda _: 2, lambda x: x + 3) == 5
    assert pipe(1) == 1



# Generated at 2022-06-21 19:49:12.554658
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-21 19:49:16.669132
# Unit test for function cond
def test_cond():
    assert cond([
        (eq(1), identity),
        (eq(2), increase)
    ])(1) == 1

    assert cond([
        (eq(1), identity),
        (eq(2), increase)
    ])(2) == 3


# Generated at 2022-06-21 19:49:23.588665
# Unit test for function cond
def test_cond():
    functions_list = [(lambda x: x == 1, lambda x: x), (lambda x: x == 2, lambda x: x**2)]
    tests = [
        (cond(functions_list)(1), 1),
        (cond(functions_list)(2), 4),
    ]
    test_cond = [test_eq(item[0], item[1]) for item in tests]
    return test_cond



# Generated at 2022-06-21 19:49:31.602257
# Unit test for function curried_filter
def test_curried_filter():
    is_even = lambda n: n % 2 == 0
    assert curried_filter(is_even, range(10)) == [0, 2, 4, 6, 8]
    assert curried_filter(is_even)(range(10)) == [0, 2, 4, 6, 8]
    assert curried_filter(is_even, range(9)) == [0, 2, 4, 6, 8]
    assert curried_filter(is_even)(range(9)) == [0, 2, 4, 6, 8]
    assert curried_filter(is_even, range(11)) == [0, 2, 4, 6, 8, 10]
    assert curried_filter(is_even)(range(11)) == [0, 2, 4, 6, 8, 10]


# Generated at 2022-06-21 19:49:38.998259
# Unit test for function identity
def test_identity():
    """
    >>> identity(1)
    1
    >>> identity(None)
    >>> identity(False)
    False
    >>> identity(True)
    True
    """



# Generated at 2022-06-21 19:49:42.631126
# Unit test for function curry
def test_curry():
    def add(x, y): return x + y

    assert curry(add)(1)(2) == add(1, 2)

    assert curry(add, 1)(2) == add(2)

    assert curry(add, 2)(1)(2) == add(1, 2)



# Generated at 2022-06-21 19:49:49.866781
# Unit test for function curry
def test_curry():
    def f(a, b, c, d):
        return a + b + c + d

    g = curry(f)
    assert g(1)(2)(3)(4) == 10
    assert g(1, 2)(3, 4) == 10
    assert g(1, 2, 3)(4) == 10
    assert g(1, 2, 3, 4) == 10



# Generated at 2022-06-21 19:49:56.345154
# Unit test for function curry
def test_curry():
    """
    Unit testing for currying technique.
    """
    def f(*args):
        return sum(args)
    assert f(1, 2, 3) == 6
    f_curried = curry(f)
    assert f_curried(1, 2, 3) == 6
    assert f_curried(1)(2)(3) == 6
    assert f_curried(1)(2)(3)(4) == 10
    assert f_curried(1, 2)(3) == 6
    assert f_curried(1)(2, 3) == 6


# Generated at 2022-06-21 19:50:00.231628
# Unit test for function compose
def test_compose():
    """
    Test function compose

    :returns: Nothing
    :rtype: None
    """
    assert compose(1, lambda x: x + 1, lambda x: x * 2) == 4



# Generated at 2022-06-21 19:50:03.590233
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-21 19:50:04.841521
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-21 19:50:08.630502
# Unit test for function pipe
def test_pipe():
    assert pipe(1, increase, increase, identity) == 3
    assert pipe(2, increase, increase, identity) == 4



# Generated at 2022-06-21 19:50:12.369982
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(identity)([1, 2, 3]) == [1, 2, 3]
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-21 19:50:16.252935
# Unit test for function eq
def test_eq():
    print("TEST EQ")
    assert eq(1)(1)
    assert not eq(1)(2)
    assert eq(1, 1)
    assert not eq(1, 2)
    print("TEST EQ END")



# Generated at 2022-06-21 19:50:24.556918
# Unit test for function curried_map
def test_curried_map():
    res = curried_map(lambda x: x + 1)([1, 2, 3])
    res1 = curried_map(lambda x: x + 1, [1, 2, 3])
    assert res == [2, 3, 4]
    assert res1 == [2, 3, 4]



# Generated at 2022-06-21 19:50:31.513080
# Unit test for function identity
def test_identity():
    assert identity(0) == 0
    assert identity(1) == 1
    assert identity(-1) == -1
    assert identity('foo') == 'foo'
    assert identity(1.0) == 1.0
    assert identity((1, 2, 3)) == (1, 2, 3)
    assert identity({'foo': 'bar'}) == {'foo': 'bar'}
    assert identity(True)



# Generated at 2022-06-21 19:50:37.201032
# Unit test for function curried_map
def test_curried_map():
    test_list = [1, 2, 3]
    assert curried_map(increase, test_list) == [2, 3, 4]
    assert curried_map(increase)(test_list) == [2, 3, 4]
    increase_map = curried_map(increase)
    assert increase_map(test_list) == [2, 3, 4]



# Generated at 2022-06-21 19:50:38.261716
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:50:43.272603
# Unit test for function curry
def test_curry():

    def test_fn1(a, b, c):
        return a + b + c

    def test_fn2(a, b, c, d):
        return a + b + c + d

    assert curry(test_fn1)(1)(2)(3) == test_fn1(1, 2, 3)
    assert curry(test_fn2)(1)(2)(3)(4) == test_fn2(1, 2, 3, 4)



# Generated at 2022-06-21 19:50:52.502291
# Unit test for function curried_map
def test_curried_map():
    list1 = [1, 2, 3]
    inverse_list = [list1, list1, list1]
    list2 = [-1, -2, -3]
    list3 = [0, 0, 0]
    increase_list1 = [2, 3, 4]
    increase_list2 = [0, 0, 0]
    increase_list3 = [-2, -3, -4]

    def test_inverse(value):
        return value * (-1)

    def test_inverse_inverse(value):
        return value * (-1) * (-1)

    def test_increase(value):
        return value + 1

    def test_increase_increase(value):
        return value + 1 + 1

    assert curried_map(identity, list1) == list1
    assert curried

# Generated at 2022-06-21 19:50:56.311696
# Unit test for function curried_filter
def test_curried_filter():
    evens = curried_filter(lambda x: 0 == x % 2)
    print(evens([1, 2, 3, 4]))
    print(evens([5, 6, 7, 8]))


# Generated at 2022-06-21 19:50:58.279522
# Unit test for function increase
def test_increase():
    """
    Increase numbers.

    :returns:
    :rtype:
    """
    assert increase(1) == 2



# Generated at 2022-06-21 19:51:00.740688
# Unit test for function compose
def test_compose():
    to_upper = lambda x: x.upper()
    to_list = lambda x: [x]

    assert compose('abcd', to_list, to_upper) == ['ABCD']



# Generated at 2022-06-21 19:51:09.420289
# Unit test for function memoize
def test_memoize():
    def add(a, b):
        return a + b

    memoized_add = memoize(add)
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 3) == 4
    assert memoized_add(1, 2) == 3
    assert memoized_add(1, 3) == 4



# Generated at 2022-06-21 19:51:17.695102
# Unit test for function curry
def test_curry():
    function_with_two_argument = lambda x, y: x + y

    result = curry(function_with_two_argument)
    assert result(1, 1) == 2
    assert callable(result)



# Generated at 2022-06-21 19:51:19.753535
# Unit test for function curried_filter
def test_curried_filter():
    """
    >>> result = curried_filter(increase)([1])
    >>> result == [2]
    True

    """



# Generated at 2022-06-21 19:51:25.326787
# Unit test for function identity
def test_identity():
    assert identity(0) == 0
    assert identity("") == ""
    assert identity("test") == "test"
    assert identity("1") == "1"
    assert identity(1) == 1
    assert identity("test", 1) == (("test", 1))
    assert identity("test", "test") == ("test", "test")



# Generated at 2022-06-21 19:51:26.339835
# Unit test for function eq
def test_eq():
    assert(eq(1, 1))



# Generated at 2022-06-21 19:51:27.888750
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert eq(1, 1, 1)
    assert not eq(1, 2, 1)
    assert not eq(1, 1, 2)



# Generated at 2022-06-21 19:51:30.743002
# Unit test for function compose
def test_compose():
    assert compose(
        0,
        lambda value: value + 1,
        lambda value: value - 1,
        lambda value: value + value,
        lambda value: value * 10,
        lambda value: value / 3,
    ) == 10

# Generated at 2022-06-21 19:51:32.918359
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase, [1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-21 19:51:37.243011
# Unit test for function curried_map
def test_curried_map():
    test_collection = [1, 2, 3, 4, 5]
    curried_map_function = curried_map(increase)
    assert curried_map_function(test_collection) == [2, 3, 4, 5, 6]



# Generated at 2022-06-21 19:51:39.478065
# Unit test for function pipe
def test_pipe():
    assert pipe('abc',
                lambda value: value + 'd',
                lambda value: value + 'e') == 'abcd'



# Generated at 2022-06-21 19:51:44.086378
# Unit test for function eq
def test_eq():
    """
    Test if return True if arguments are equal, else False
    """
    assert eq(1, 1) is True
    assert eq([1, 2, 3], [1, 2, 3]) is True
    assert eq("a", "a") is True
    assert eq("a", "b") is False
    assert eq("a", "ab") is False
    assert eq("abc", "abc") is True



# Generated at 2022-06-21 19:51:51.599446
# Unit test for function compose
def test_compose():
    assert compose(
        1,
        lambda x: x + 1,
        lambda x: x + 2,
        lambda x: x + 3
    ) == 7

    assert compose(
        1,
        lambda x: x + 1,
        lambda x: x + 2,
        lambda x: x + 3,
        lambda x: x + 4
    ) == 9



# Generated at 2022-06-21 19:51:52.682484
# Unit test for function increase
def test_increase():
    assert increase(10) == 11


# Generated at 2022-06-21 19:51:58.769516
# Unit test for function cond
def test_cond():
    """
    Test for function cond
    """
    # Test for function for return itself function
    # when function get collection
    is_number_equals_two = (lambda number: number == 2)
    return_number = (lambda number: number)

    first_number: int = cond([
        (is_number_equals_two, return_number),
    ])(2)
    second_number: int = cond([
        (is_number_equals_two, return_number),
    ])(3)
    assert first_number == 2
    assert second_number is None

# Generated at 2022-06-21 19:52:06.320472
# Unit test for function cond
def test_cond():
    assert (
        cond([
            (lambda x: x % 2 == 0, lambda x: 'even'),
            (lambda x: x % 2 == 1, lambda x: 'odd')
        ])(2)
        ==
        'even'
    )

    assert (
        cond([
            (lambda x: x % 2 == 0, lambda x: 'even'),
            (lambda x: x % 2 == 1, lambda x: 'odd')
        ])(3)
        ==
        'odd'
    )



# Generated at 2022-06-21 19:52:08.273578
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 1)([1, 2, 3]) == [2, 3]



# Generated at 2022-06-21 19:52:12.609136
# Unit test for function compose
def test_compose():
    functions = [
        identity,
        increase,
        identity,
        increase,
        increase,
        increase
    ]

    result = compose(
        functions[0],
        functions[1],
        functions[2],
        functions[3],
        functions[4],
        functions[5]
    )(0)

    assert result == 4, f'compose({functions}, 0) should return 4, but returned {result}'



# Generated at 2022-06-21 19:52:17.651884
# Unit test for function pipe
def test_pipe():
    assert(pipe(1, increase, increase) == 3)
    assert(pipe(1, increase, increase, increase) == 4)
    assert(pipe(1, increase, increase, increase, increase) == 5)


# Generated at 2022-06-21 19:52:20.313621
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(1.0) == 1.0
    assert identity(True) == True
    assert identity(False) == False
    assert identity([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-21 19:52:25.110128
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(0), [0, 1, 2, 0, 0]) == [0, 0, 0]
    assert curried_filter(eq(2), [0, 1, 2, 0, 0]) == [2]
    assert curried_filter(eq(0), [6, 7, 8, 9, 10]) == []



# Generated at 2022-06-21 19:52:27.866934
# Unit test for function curry
def test_curry():
    assert curry((lambda x, y: x + y))(1)(2) == 3
    assert curry(lambda x, y: x + y, 2)(1, 2) == 3
    assert curry(lambda x, y: x + y)(1, 2) == 3



# Generated at 2022-06-21 19:52:33.512127
# Unit test for function increase
def test_increase():
    assert increase(10) == 11



# Generated at 2022-06-21 19:52:36.061755
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(2) == 3
    assert increase(3) == 4



# Generated at 2022-06-21 19:52:41.717903
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(1), [1, 2, 1, 1]) == [1, 1, 1]
    assert curried_filter(eq(2), [1, 2, 1, 2]) == [2, 2]
    assert curried_filter(eq(3), [1, 2, 1, 2]) == []
    assert curried_filter(eq(1), []) == []



# Generated at 2022-06-21 19:52:43.150454
# Unit test for function compose
def test_compose():
    assert compose(1, identity, increase) == 2



# Generated at 2022-06-21 19:52:48.322941
# Unit test for function curried_filter
def test_curried_filter():
    def is_even(number):
        return number % 2 == 0

    collection = [1, 2, 3, 4]
    expected = [2, 4]

    result = curried_filter(is_even)(collection)

    assert result == expected



# Generated at 2022-06-21 19:52:51.304615
# Unit test for function curried_filter
def test_curried_filter():
    import random
    assert curried_filter((lambda num: num < 50))(range(100)) == [
        num for num in range(100) if num < 50]



# Generated at 2022-06-21 19:52:57.197969
# Unit test for function memoize
def test_memoize():
    cache = []
    add: Callable[[int, int], int] = memoize(lambda x, y: x + y, key=lambda t1, t2: t1[0] == t2[0])
    assert add(4, 5) == 9
    assert add(4, 6) == 10
    assert add(4, 5) == 9
    assert add(4, 6) == 10

# Generated at 2022-06-21 19:53:02.320568
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z, v: x + y + z + v)(1)(2)(3)(4) == 10
    assert curry(lambda x, y: x + y)(1)(2) == 3

# Generated at 2022-06-21 19:53:07.458951
# Unit test for function find
def test_find():
    assert find([0, 1, 2], lambda x: x > 1) == 2
    assert find([0, 1, 2], lambda x: x > 1) == find([0, 1, 2], lambda x: x > 1)
    assert find([0, 1, 2], lambda x: x > 3) is None
    assert find(['', 'a', 'abc'], len) == 1



# Generated at 2022-06-21 19:53:08.636398
# Unit test for function identity
def test_identity():
    assert identity('foo') == 'foo'



# Generated at 2022-06-21 19:53:18.162557
# Unit test for function pipe
def test_pipe():
    assert pipe(1, lambda a: a + 1) == 2
    assert pipe(1, lambda a: a + 1, lambda a: a * 2) == 4
    assert pipe(1, lambda a: a + 1, lambda a: a * 2, lambda a: a - 2) == 2



# Generated at 2022-06-21 19:53:19.052603
# Unit test for function increase
def test_increase():
    assert increase(2) == 3



# Generated at 2022-06-21 19:53:21.793366
# Unit test for function curried_filter
def test_curried_filter():
    list = [1,2,3,4]
    assert curried_filter(lambda x: x > 2, list) == curried_filter(lambda x: x > 2)(list)
    return True


# Generated at 2022-06-21 19:53:24.365987
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(10) == 11



# Generated at 2022-06-21 19:53:34.664895
# Unit test for function curry
def test_curry():
    assert(curry(sum, 3)(1, 3, 4) == 8)
    assert(curry(sum, 3)(1)(3)(4) == 8)
    assert(curry(sum, 1)(1) == 1)
    assert(curry(sum, 1)(1, 3) == 1)
    assert(curry(max, 2)(1, 3) == 3)
    assert(curry(max, 2)(1)(3) == 3)
    assert(curry(max, 1)(1) == 1)
    assert(curry(max, 1)(1, 3) == 1)
    assert(curry(identity, 1)(1) == 1)
    assert(curry(identity, 1)(1, 4) == 1)



# Generated at 2022-06-21 19:53:39.566376
# Unit test for function curried_map
def test_curried_map():
    assert(curried_map(identity)([1, 2, 3]) == [1, 2, 3])
    assert(curried_map(identity, [1, 2, 3]) == [1, 2, 3])

    assert(curried_map(increase)([1, 2, 3]) == [2, 3, 4])
    assert(curried_map(increase, [1, 2, 3]) == [2, 3, 4])



# Generated at 2022-06-21 19:53:43.193519
# Unit test for function curried_filter
def test_curried_filter():
    x = [1, 2, 3, 4]
    y = curried_filter(lambda x: x % 2 == 0)
    z = y(x)
    assert z == [2, 4]



# Generated at 2022-06-21 19:53:44.232792
# Unit test for function increase
def test_increase():
    assert increase(0) == 1



# Generated at 2022-06-21 19:53:54.234400
# Unit test for function memoize
def test_memoize():
    # Define new function for testing
    counter = 0
    def func(x):
        global counter
        counter += 1
        return x + 1

    # Memoize the function
    memoized_func = memoize(func)

    # Invoke the function 3 times with the same argument
    memoized_func(1)
    memoized_func(1)
    memoized_func(1)

    # Function should has been invoke once
    assert counter == 1

    # Invoke the function 3 times with different argument
    memoized_func(2)
    memoized_func(3)
    memoized_func(4)

    # Function should has been invoke 4 times
    assert counter == 4



# Generated at 2022-06-21 19:53:55.248406
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:54:11.008903
# Unit test for function curry
def test_curry():
    assert identity(None) is None
    assert identity(1) == 1
    assert identity("test") == "test"
    assert identity("1test") == "1test"
    assert identity(True) is True
    assert identity(False) is False

    c_identity = curry(identity)

    assert c_identity(None) is None
    assert c_identity(1) == 1
    assert c_identity("test") == "test"
    assert c_identity("1test") == "1test"
    assert c_identity(True) is True
    assert c_identity(False) is False



# Generated at 2022-06-21 19:54:13.708695
# Unit test for function eq
def test_eq():
    assert eq(1)(1) is True
    assert eq(1)(2) is False



# Generated at 2022-06-21 19:54:23.739860
# Unit test for function curried_filter
def test_curried_filter():
    # filter only even numbers
    is_even = lambda x: x % 2 == 0
    filter_even_numbers = curried_filter(is_even)
    assert filter_even_numbers([1, 2, 3]) == [2]
    assert filter_even_numbers([1, 2, 3, 4, 5]) == [2, 4]
    assert filter_even_numbers([]) == []
    assert filter_even_numbers([1, 1, 1, 1]) == []

    filter_even_numbers_with_one_arguments = curried_filter(is_even, [1, 2, 3])
    assert filter_even_numbers_with_one_arguments == [2]



# Generated at 2022-06-21 19:54:28.770978
# Unit test for function curried_filter
def test_curried_filter():
    """
    Test curried_filter with normal data and curried_filter with right-to-left functions composition.

    :returns: nothing
    :rtype: nothing
    """
    collection = [1, 2, 3, 4, 5]

    assert curried_filter(lambda item: item % 2 == 0, collection) == [2, 4]
    assert curried_filter(lambda item: item % 2 == 0)(collection) == [2, 4]

    assert compose(collection, curried_filter(lambda item: item % 2 == 0)) == [2, 4]



# Generated at 2022-06-21 19:54:32.229112
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(None) == None
    assert identity([]) == []
    assert identity(['1', '2', '3']) == ['1', '2', '3']



# Generated at 2022-06-21 19:54:36.172314
# Unit test for function find
def test_find():
    assert find([(1, 2), (2, 3)], lambda item: item[0] == 1) == (1, 2)
    assert find([(1, 2), (2, 3)], lambda item: item[0] == 3) is None



# Generated at 2022-06-21 19:54:38.777869
# Unit test for function curry
def test_curry():
    def sum_3(x, y, z):
        return x + y + z

    assert curry(sum_3)(1)(2)(3) == 6



# Generated at 2022-06-21 19:54:41.766943
# Unit test for function identity
def test_identity():
    assert identity('x') == 'x'
    assert identity(1) == 1
    assert identity(None) is None



# Generated at 2022-06-21 19:54:42.709628
# Unit test for function increase
def test_increase():
    assert increase(5) == 6



# Generated at 2022-06-21 19:54:45.310989
# Unit test for function eq
def test_eq():
    """
    Test module function eq
    """
    assert eq(2, 2) is True
    assert eq(2, 2)(2) is True
    assert eq(1, 2) is False

# Generated at 2022-06-21 19:55:12.151262
# Unit test for function compose
def test_compose():
    """
    Test function compose.
    """
    # given
    functions = [
        lambda x: x,
        lambda x: x,
        lambda x: x,
    ]
    value = 0

    # when
    result = compose(value, *functions)

    # then
    assert result == value

    # given
    functions = [
        lambda x: x + 1,
        lambda x: x + 1,
        lambda x: x + 1,
        lambda x: x + 1,
        lambda x: x + 1,
    ]
    value = 0

    # when
    result = compose(value, *functions)

    # then
    assert result == value + 5



# Generated at 2022-06-21 19:55:14.416726
# Unit test for function curry
def test_curry():
    def sum(x, y):
        return x - y
    incr = curry(sum, args_count=1)
    assert incr(1) == 1



# Generated at 2022-06-21 19:55:18.765028
# Unit test for function memoize
def test_memoize():
    count = 0

    def dummy_fn(argument):
        nonlocal count
        count += 1
        return argument**2

    fn = memoize(dummy_fn)

    assert fn(5) == 25
    assert fn(5) == 25
    assert count == 1


if __name__ == "__main__":
    test_memoize()

# Generated at 2022-06-21 19:55:19.928377
# Unit test for function increase
def test_increase():
    assert increase(1) == 2


# Generated at 2022-06-21 19:55:26.335408
# Unit test for function curried_filter
def test_curried_filter():
    array = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    function = lambda x: x < 5
    assert curried_filter(array, function) == [1, 2, 3, 4]
    assert curried_filter(function)(array) == [1, 2, 3, 4]
    assert curried_filter(function, array) == [1, 2, 3, 4]
    assert curried_filter(function)(array) == [1, 2, 3, 4]
    assert curried_filter(function)(array) == [1, 2, 3, 4]


# Generated at 2022-06-21 19:55:32.481435
# Unit test for function curried_map
def test_curried_map():
    map_identity = curried_map(identity)
    assert map_identity([1, 2, 3]) == [1, 2, 3]

    map_increase = curried_map(increase)
    assert map_increase([1, 2, 3]) == [2, 3, 4]

    map_string = curried_map(increase)
    assert map_string([1, 2, 3]) == [2, 3, 4]


# Generated at 2022-06-21 19:55:42.920813
# Unit test for function cond
def test_cond():
    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    def add_three(a):
        return a + 3

    def is_zero(a):
        return a == 0

    def is_one(a):
        return a == 1

    def add_result(a):
        return cond([
            (is_zero, add_three),
            (is_one, add_two),
            (None, add_one),
        ])(a)

    assert add_result(1) == 3
    assert add_result(0) == 3
    assert add_result(2) == 3
    assert add_result(-1) == 0
    assert add_result(-9) == -8
    assert add_result(-12) == -11
    assert add_result

# Generated at 2022-06-21 19:55:44.060988
# Unit test for function compose
def test_compose():
    assert compose(1, increase, increase) == 3
    assert compose(1, increase, identity) == 2


# Generated at 2022-06-21 19:55:45.032907
# Unit test for function eq
def test_eq():
    assert eq(1, 1)



# Generated at 2022-06-21 19:55:49.151724
# Unit test for function curried_map
def test_curried_map():
    """
    Test curried_map.

    :returns: True if all tests passed
    :rtype: Boolean
    """
    assert curried_map(lambda x: x * 2)([1, 2, 3]) == [2, 4, 6]
    assert curried_map(lambda x: x * 2, [1, 2, 3]) == [2, 4, 6]
    assert curried_map(lambda x: x * 2)([1, 2, 3, 4, 5]) == [2, 4, 6, 8, 10]
    assert curried_map(lambda x: x * 2, [1, 2, 3, 4, 5]) == [2, 4, 6, 8, 10]

    # If all tests passed then return True
    return True


# Generated at 2022-06-21 19:56:08.859580
# Unit test for function increase
def test_increase():
    assert(increase(1) == 2)



# Generated at 2022-06-21 19:56:12.311379
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda element: element < 3)([1, 2, 3, 4]) == [1, 2]
    assert curried_filter(lambda element: element < 8)(range(10)) == [0, 1, 2, 3, 4, 5, 6, 7]



# Generated at 2022-06-21 19:56:15.362497
# Unit test for function find
def test_find():
    collection = [1, 2, 3, 4, 5]

    assert find(collection, lambda item: item == 1) == 1
    assert find(collection, lambda item: item == 6) is None



# Generated at 2022-06-21 19:56:19.709673
# Unit test for function memoize
def test_memoize():

    def fib(n):
        if n <= 1:
            return 1
        return fib(n - 1) + fib(n - 2)

    fib = memoize(fib)
    assert fib(36) == 24157817
    assert fib(36) == 24157817
    assert fib(36) == 24157817

# Generated at 2022-06-21 19:56:21.473637
# Unit test for function find
def test_find():
    """
    Test for find function

    :returns:
    :rtype:
    """
    assert find([1, 2, 3], lambda x: x % 2 == 0) == 2
    assert find([1, 2, 3], lambda x: x > 4) is None



# Generated at 2022-06-21 19:56:25.419989
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase('1') == '11'
    assert increase(increase)(1) == 3
    assert increase(1)(1) == 2


# Generated at 2022-06-21 19:56:33.462484
# Unit test for function cond
def test_cond():
    perform_increase = lambda value: cond([
        (eq(0), identity),
        (eq(1), lambda x: x),
        (lambda x: x % 2 == 0, lambda x: x // 2),
        (lambda x: True, lambda x: x * 3 + 1)
    ])
    assert perform_increase(0) == 0
    assert perform_increase(1) == 1
    assert perform_increase(2) == 1
    assert perform_increase(3) == 10
    assert perform_increase(4) == 2
    assert perform_increase(5) == 16



# Generated at 2022-06-21 19:56:36.174737
# Unit test for function curry
def test_curry():
    @curry
    def fn(x, y):
        return x + y

    assert fn(1)(2) == 3
    assert fn(1, 2) == 3



# Generated at 2022-06-21 19:56:41.819564
# Unit test for function pipe
def test_pipe():
    assert pipe(
        10,
        lambda x: x * x,
        lambda x: x + 2
    ) == 102
    assert pipe(
        "string",
        lambda x: x + "1",
        lambda x: x + "2",
        lambda x: x + "3",
    ) == "string123"



# Generated at 2022-06-21 19:56:45.630796
# Unit test for function curry
def test_curry():
    @curry
    def test_function_curry(x, y):
        return x + y

    assert test_function_curry(1, 2) == 3
    assert test_function_curry(1)(2) == 3



# Generated at 2022-06-21 19:57:08.771716
# Unit test for function compose
def test_compose():
    assert compose(
        1,
        lambda x: x * 2,
        lambda x: x + 2,
        lambda x: x ** 2
    ) == 9



# Generated at 2022-06-21 19:57:17.638354
# Unit test for function find
def test_find():
    assert find(["test", "test1"], lambda x: x == "test") == "test"
    assert find(["test", "test1"], lambda x: x == "test2") is None
    assert find([{'key': 'test1', 'value': 'test'}, {'key': 'test2', 'value': 'test'}], lambda x: x['key'] == 'test1') == {'key': 'test1', 'value': 'test'}

