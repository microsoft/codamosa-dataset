

# Generated at 2022-06-21 19:47:25.277563
# Unit test for function memoize
def test_memoize():
    @memoize
    def add(x, y):
        return x + y

    assert add(1, 2) == 3
    assert add(1, 2) == 3

    @memoize
    def increment(x):
        return x + 1

    assert increment(1) == 2
    assert increment(1) == 2



# Generated at 2022-06-21 19:47:28.203755
# Unit test for function compose
def test_compose():
    assert compose(2, increase) == 3
    assert compose(3, lambda x: x**2, increase, lambda x: x + 1) == 49



# Generated at 2022-06-21 19:47:30.080283
# Unit test for function pipe
def test_pipe():
    assert(pipe(1, lambda x: x + 1, lambda x: x + 2) == 4)



# Generated at 2022-06-21 19:47:34.011861
# Unit test for function memoize
def test_memoize():
    def fn_with_state(state) -> int:
        state[1] += 1
        return state[0]

    state = [1, 0]
    f = memoize(lambda: fn_with_state(state))
    assert f() == 1
    assert f() == 1
    assert f() == 1
    assert f() == 1
    assert state[1] == 1

# Generated at 2022-06-21 19:47:37.321466
# Unit test for function pipe
def test_pipe():
    assert pipe(
        value=1,
        functions=[
            identity,
            increase,
            increase
        ]
    ) == 3



# Generated at 2022-06-21 19:47:42.897178
# Unit test for function memoize
def test_memoize():
    @memoize
    def get_result(x):
        return x

    lst = list(range(10))
    lst1 = lst[:5]
    lst2 = lst[5:]
    result1 = list(map(get_result, lst1))
    result2 = list(map(get_result, lst2))
    assert result1 == result2



# Generated at 2022-06-21 19:47:44.866087
# Unit test for function identity
def test_identity():
    assert identity('qwerty') == 'qwerty'



# Generated at 2022-06-21 19:47:49.005813
# Unit test for function pipe
def test_pipe():
    assert 1 == pipe(
        1,
        lambda x: x + 1,
        lambda x: x + 1,
    )
    assert 5 == pipe(
        1,
        lambda x: x * 2,
        lambda x: x + 2,
        lambda x: x * 1,
    )



# Generated at 2022-06-21 19:47:54.709533
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x % 2 == 1) == 1
    assert find([1, 2, 3], lambda x: x % 2 == 0) == 2
    assert find([1, 2, 3], lambda x: x == 5) is None


# Unit tests for function memoize

# Generated at 2022-06-21 19:48:03.115758
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x + y)(1)(2) == 3
    assert curry(lambda x, y, z: x + y + z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2)(3) == 6
    assert curry(lambda x, y, z: x + y + z)(1)(2, 3) == 6
    assert curry(lambda x, y, z: x + y + z)(1, 2, 3) == 6


# Unit Test for function compose

# Generated at 2022-06-21 19:48:09.128454
# Unit test for function pipe
def test_pipe():
    print('Should return 3')
    print(
        pipe(1, lambda x: x + 1, lambda y: y + 1)()
    )
    print('Should return 3')
    print(
        pipe(1, increase, increase)()
    )
    print('Should return 6')
    print(
        pipe(1, lambda x: x + 1, lambda y: y + 1, lambda z: z + 3)()
    )



# Generated at 2022-06-21 19:48:11.792545
# Unit test for function memoize
def test_memoize():
    def sum(a, b):
        return a + b
    memoized_sum = memoize(sum, key=eq)

    assert memoized_sum(1, 2) == 3
    assert memoized_sum(1, 1) == 2
    assert memoized_sum(2, 3) == 5


# Generated at 2022-06-21 19:48:13.807237
# Unit test for function compose
def test_compose():
    composed_function = compose(10, increase, increase, increase)
    assert composed_function == 13

# Generated at 2022-06-21 19:48:23.402987
# Unit test for function curry
def test_curry():
    def fn(a, b, c):
        return a + b + c

    assert fn(1, 2, 3) == curry(fn, 3)(1, 2, 3)
    assert fn(1, 2, 3) == curry(fn, 3)(1, 2)(3)
    assert fn(1, 2, 3) == curry(fn, 3)(1)(2, 3)
    assert fn(1, 2, 3) == curry(fn, 3)(1)(2)(3)
    assert fn(1, 2, 3) == curry(fn, 3)(1)(2)(3)
    print('Test for function curry passed!')


# Generated at 2022-06-21 19:48:27.068712
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2), 2
    assert find([1, 1, 1], lambda x: x == 2), None


# Generated at 2022-06-21 19:48:32.246093
# Unit test for function curry
def test_curry():
    @curry
    def sum(x, y, z):
        return x + y + z

    assert sum(1, 2, 3) == 6
    assert sum(1, 2)(3) == 6
    assert sum(1)(2, 3) == 6
    assert sum(1)(2)(3) == 6



# Generated at 2022-06-21 19:48:33.793510
# Unit test for function find
def test_find():
    assert find(range(20), eq(15)) == 15



# Generated at 2022-06-21 19:48:36.291508
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(0) == 1
    assert increase(9) == 10
    assert increase(20) == 21



# Generated at 2022-06-21 19:48:40.641989
# Unit test for function find
def test_find():
    """
    Unit test for function find.
    """
    test_collection = [
        {"foo": "bar"},
        {"baz": "qux"}
    ]
    assert find(test_collection, lambda item: item.get("foo", False)) is test_collection[0]
    assert find(test_collection, lambda item: item.get("baz", False)) is test_collection[1]
    assert find(test_collection, lambda item: item.get("qux", False)) is None



# Generated at 2022-06-21 19:48:43.183040
# Unit test for function compose
def test_compose():
    assert compose(3, increase, increase) == 5
    assert compose(3, increase, identity) == 4
    assert compose(3, identity, identity) == 3



# Generated at 2022-06-21 19:48:49.930018
# Unit test for function curry
def test_curry():
    def add(x, y):
        return x + y

    assert 4 == curry(add)(2)(2)
    assert 6 == curry(add, 2)(2)(2)



# Generated at 2022-06-21 19:48:51.026156
# Unit test for function increase
def test_increase():
    assert increase(4) == 5



# Generated at 2022-06-21 19:48:57.506562
# Unit test for function curry
def test_curry():
    def add(x, y):
        return x + y

    assert curry(add, 2)(1, 1) == 2
    assert curry(add, 2)(1)(1) == 2
    assert curry(add)(1)(1) == 2
    assert curry(add)(1, 1) == 2



# Generated at 2022-06-21 19:48:59.454384
# Unit test for function identity
def test_identity():
    assert identity(42) == 42


# Generated at 2022-06-21 19:49:01.530218
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(2) == 3
    assert increase(3) == 4


# Generated at 2022-06-21 19:49:03.525590
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-21 19:49:09.005718
# Unit test for function cond
def test_cond():
    def condition_function(value: Any) -> bool:
        return value < 10

    def execute_function(value: Any) -> int:
        return value + 1

    curried_cond = cond(
        [
            (lambda value: value < 5, lambda value: value),
            (condition_function, execute_function),
        ]
    )
    assert curried_cond(2) == 2
    assert curried_cond(7) == 8



# Generated at 2022-06-21 19:49:10.327424
# Unit test for function pipe
def test_pipe():
    assert pipe(1, increase, increase, increase) == 4

# Generated at 2022-06-21 19:49:18.569572
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b, c: a + b + c)(1, 2, 3) == 6
    assert curry(lambda a, b, c: a + b + c)(1)(2, 3) == 6
    assert curry(lambda a, b, c: a + b + c)(1)(2)(3) == 6
    assert curry(lambda a, b, c: a + b + c)(1, 2)(3) == 6
    assert curry(lambda a, b, c: a + b + c)(1)(2, 3) == 6



# Generated at 2022-06-21 19:49:28.409761
# Unit test for function find

# Generated at 2022-06-21 19:49:36.402142
# Unit test for function find
def test_find():
    collection = [{'name': 'John', 'age': 20}, {'name': 'Jane', 'age': 18}]
    assert find(collection, lambda item: item['age'] == 18) == {'name': 'Jane', 'age': 18}
    assert find(collection, lambda item: item['name'] == 'John') == {'name': 'John', 'age': 20}
    assert find(collection, lambda item: item['name'] == 'Richard') is None
    assert find(collection, lambda item: item['surname'] == 'Smirnov') is None



# Generated at 2022-06-21 19:49:40.041916
# Unit test for function curried_filter
def test_curried_filter():
    number_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    even_filter = curried_filter(lambda number: number % 2 == 0)
    assert even_filter(number_list) == [2, 4, 6, 8, 10]
    odd_filter = curried_filter(lambda number: number % 2 == 1)
    assert odd_filter(number_list) == [1, 3, 5, 7, 9]



# Generated at 2022-06-21 19:49:51.795443
# Unit test for function compose
def test_compose():
    """
    Unit test for function compose.

    :returns: result of unit test
    :rtype: bool
    """
    assert compose(
        42,
        identity
    ) == 42
    assert compose(
        42,
        lambda x: x + 1
    ) == 43
    assert compose(
        [0, 1, 2],
        list,
        map,
        lambda collection: list(map(lambda x: x + 1, collection))
    ) == [1, 2, 3]
    assert compose(
        [0, 1, 2],
        list,
        map,
        lambda collection: list(map(lambda x: x + 1, collection)),
        list,
        lambda collection: [collection, list(collection)]
    ) == [[1, 2, 3], [1, 2, 3]]


# Unit test

# Generated at 2022-06-21 19:49:56.410979
# Unit test for function eq
def test_eq():
    a, b, c = eq(1), eq(2), eq(3)

    assert (a(1))
    assert not (a(2))
    assert not (a(3))

    assert not (b(1))
    assert (b(2))
    assert not (b(3))

    assert not (c(1))
    assert not (c(2))
    assert (c(3))



# Generated at 2022-06-21 19:50:01.962508
# Unit test for function eq
def test_eq():
    assert eq(1, 2) is False
    assert eq(1, 1) is True
    assert eq(None, None) is True
    assert eq(2)(2) is True
    assert eq(2)(1) is False
    assert eq(1)(1)(1) is True
    assert eq(1)(1)(2) is False



# Generated at 2022-06-21 19:50:03.581637
# Unit test for function curried_filter
def test_curried_filter():
    filter_greater_10 = curried_filter(lambda x: x > 10)
    assert filter_greater_10([1, 2, 3, 10, 11, 12]) == [11, 12]



# Generated at 2022-06-21 19:50:05.643116
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-21 19:50:08.981516
# Unit test for function compose
def test_compose():
    assert compose(
        2,
        increase,
        increase
    ) == 4



# Generated at 2022-06-21 19:50:16.344798
# Unit test for function find
def test_find():
    assert find(
        [{"x": 1, "y": 2}, {"x": 2, "y": 3}, {"x": 2, "y": 4}],
        lambda i: i["x"] == 2
    ) == {"x": 2, "y": 3}
    assert find(
        [{"x": 1, "y": 2}, {"x": 2, "y": 3}, {"x": 2, "y": 4}],
        lambda i: i["x"] == 3
    ) is None



# Generated at 2022-06-21 19:50:20.577520
# Unit test for function memoize
def test_memoize():
    def test_func(value):
        print(f"invoked {value}")
        return value * 2

    f = memoize(test_func)

    assert f(12) == 24
    assert f(12) == 24
    assert f(13) == 26
    assert f(12) == 24



# Generated at 2022-06-21 19:50:27.866184
# Unit test for function identity
def test_identity():
    """
    It tests that identity returns the same value which have been given

    """
    assert identity(1) == 1
    assert identity("test word") == "test word"



# Generated at 2022-06-21 19:50:31.875064
# Unit test for function find
def test_find():
    assert None == find([1, 2, 3, 4], lambda x: x == 5)
    assert 3 == find([1, 2, 3, 4], lambda x: x == 3)


if __name__ == '__main__':
    test_find()

# Generated at 2022-06-21 19:50:33.323532
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert eq(1)(1)



# Generated at 2022-06-21 19:50:39.701272
# Unit test for function cond
def test_cond():
    fact = cond([
        (eq(0), identity(1)),
        (eq(1), identity(1)),
        (lambda x: True, lambda x: x * cond(
            [(eq(0), identity(1)), (eq(1), identity(1)), (lambda y: True, lambda y: y * fact(y - 1))])(x - 1))
    ])
    print(fact(3))


if __name__ == '__main__':
    test_cond()

# Generated at 2022-06-21 19:50:45.204363
# Unit test for function pipe
def test_pipe():
    assert pipe("hello", lambda s: s.upper(), identity) == "HELLO"
    assert pipe("hello", lambda s: s.upper(), lambda s: s.lower()) == "hello"


# Generated at 2022-06-21 19:50:51.505741
# Unit test for function memoize
def test_memoize():
    assert memoize(lambda x: x)(1) == 1

    counter = 0

    def fn(x):
        nonlocal counter
        counter += 1
        return x

    memoized_fn = memoize(fn)

    assert counter == 0
    assert memoized_fn(1) == 1
    assert counter == 1
    assert memoized_fn(1) == 1
    assert memoized_fn(1) == 1
    assert memoized_fn(1) == 1
    assert counter == 1


if __name__ == '__main__':
    test_memoize()

# Generated at 2022-06-21 19:50:58.062755
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda x: x == 3) == 3
    assert find(['a', 'b', 'c', 'd'], lambda x: x == 'b') == 'b'

    assert find([1, 2, 3, 4], lambda x: x == 5) == None
    assert find(['a', 'b', 'c', 'd'], lambda x: x == 'e') == None



# Generated at 2022-06-21 19:51:03.848206
# Unit test for function find
def test_find():
    list_0 = list(range(10))
    assert find(list_0) is None
    assert find(list_0, lambda item: item > 5) == 6
    assert find(list_0, lambda item: item == 6) == 6
    assert find(list_0, lambda item: item == 10) is None
    print('test_find success')


# Generated at 2022-06-21 19:51:06.718987
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(0, False)
    assert eq(None, None)



# Generated at 2022-06-21 19:51:09.525298
# Unit test for function curry
def test_curry():
    x = lambda: [1]
    x = curry(x, 2)
    x = x(True)
    x = x(4)
    assert x()



# Generated at 2022-06-21 19:51:15.139421
# Unit test for function increase
def test_increase():
    assert increase(3), 4


# Generated at 2022-06-21 19:51:16.715967
# Unit test for function eq
def test_eq():
    assert eq(1, 1, False)



# Generated at 2022-06-21 19:51:22.329156
# Unit test for function curry
def test_curry():
    def mult(x, y, z):
        return x * y * z

    curry_mult = curry(mult)
    assert curry_mult(1)(2)(3) == 6
    assert curry_mult(1, 2)(3) == 6
    assert curry_mult(1)(2, 3) == 6
    assert curry_mult(1, 2, 3) == 6



# Generated at 2022-06-21 19:51:25.771980
# Unit test for function eq
def test_eq():
    """
    Unit test for function eq
    :returns: Equality of values
    :rtype: Equality
    """
    assert eq(2, 2) is True
    assert eq(2, 5) is False


# Generated at 2022-06-21 19:51:31.540739
# Unit test for function cond
def test_cond():
    is_even = lambda x: x % 2 == 0
    is_positive = lambda x: x > 0
    is_negative = lambda x: x < 0

    power = lambda x: x**2
    times_three = lambda x: x*3

    execute = cond([
        (is_even, power),
        (is_positive, times_three),
    ])

    assert execute(2) == 4
    assert execute(-5) == -5
    assert execute(-3) == 9



# Generated at 2022-06-21 19:51:33.062529
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(lambda x: x+2)([1, 2, 3]) == [3, 4, 5]

# Generated at 2022-06-21 19:51:36.592998
# Unit test for function curried_filter
def test_curried_filter():
    list_of_numbers = [1, 2, 3, 4, 5]
    assert curried_filter(lambda x: x % 2 is 0, list_of_numbers) == [2, 4]


# Generated at 2022-06-21 19:51:44.751590
# Unit test for function pipe
def test_pipe():
    assert pipe(
        1,
        lambda value: value + 1,
        lambda value: value + 2,
        lambda value: value + 3,
    ) == 7
    assert pipe(
        ['1', '2', '3'],
        curried_map(str.strip),
        curried_map(int),
        curried_filter(lambda value: value % 2),
        list
    ) == [1, 3]
    assert pipe(
        '1, 2, 3',
        lambda value: value.strip().split(','),
        curried_map(str.strip),
        curried_map(int),
        curried_filter(lambda value: value % 2),
        list
    ) == [1, 3]



# Generated at 2022-06-21 19:51:46.371246
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:51:49.825350
# Unit test for function curried_map
def test_curried_map():
    curried_mapped = curried_map(lambda x: x + 1, [1, 2, 3])
    assert curried_mapped == [2, 3, 4], 'unexpected value'



# Generated at 2022-06-21 19:52:00.832114
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-21 19:52:10.333601
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda x: x < 0, lambda x: "Less then zero"),
        (lambda x: x == 0, lambda x: "Zero"),
        (lambda x: x > 0, lambda x: "More then zero")
    ])(-2) == "Less then zero"
    assert cond([
        (lambda x: x < 0, lambda x: "Less then zero"),
        (lambda x: x == 0, lambda x: "Zero"),
        (lambda x: x > 0, lambda x: "More then zero")
    ])(0) == "Zero"
    assert cond([
        (lambda x: x < 0, lambda x: "Less then zero"),
        (lambda x: x == 0, lambda x: "Zero"),
        (lambda x: x > 0, lambda x: "More then zero")
    ])(2)

# Generated at 2022-06-21 19:52:16.864191
# Unit test for function curry
def test_curry():
    assert increase(5) == 6
    assert increase(5) == 6
    assert curry(increase)(5) == 6
    assert curry(increase)(5) == 6
    assert curry(increase)(5) == 6
    assert curry(increase)(5) == 6
    assert curry(increase)(5) == 6
    assert curry(lambda a, b: a + b)(5, 0) == 5



# Generated at 2022-06-21 19:52:17.776373
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:52:20.415410
# Unit test for function find
def test_find():
    assert find([1, 2, 3], lambda x: x == 2) == 2, 'find should return the first item with matching function'
    assert find([1, 2, 3], lambda x: x == 5) is None, 'find should return none if no item matches'


# Generated at 2022-06-21 19:52:22.066481
# Unit test for function eq
def test_eq():
    assert eq(1)(1)
    assert not eq(1)(2)



# Generated at 2022-06-21 19:52:24.606783
# Unit test for function curried_map
def test_curried_map():
    curried_mapper: Callable = curried_map(increase)
    assert curried_mapper([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-21 19:52:27.355109
# Unit test for function find
def test_find():
    assert find([1, 2, 3, 4], lambda item: item == 3) == 3
    assert find([1, 2, 3, 4], lambda item: item == 5) is None



# Generated at 2022-06-21 19:52:33.562793
# Unit test for function curry
def test_curry():
    assert curry(lambda a, b: a + b)(1)(1) == 2
    assert curry(lambda a, b, c: a + b + c)(1)(1)(1) == 3
    assert curry(lambda a, b, c, d: a + b + c + d)(1)(1)(1)(1) == 4
    assert curry(lambda a, b, c, d, e: a + b + c + d + e)(1)(1)(1)(1)(1) == 5



# Generated at 2022-06-21 19:52:36.121268
# Unit test for function identity
def test_identity():
    """
    Unit test for identity
    """
    assert identity(10) == 10
    assert identity([]) == []



# Generated at 2022-06-21 19:52:56.436455
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-21 19:53:00.054321
# Unit test for function curried_filter
def test_curried_filter():
    x = curried_filter(lambda x : x >= 2)([1,2,3,4,5])
    y = [2,3,4,5]
    print(x==y)
    print(x)



# Generated at 2022-06-21 19:53:01.280002
# Unit test for function increase
def test_increase():
    print(increase(5))
    assert increase(5) == 6



# Generated at 2022-06-21 19:53:06.549844
# Unit test for function cond
def test_cond():
    def is_less(a, b):
        return a < b

    def double(x):
        return x * 2

    def triple(x):
        return x * 3

    cond_func = cond([(is_less, double), (identity, triple)])
    assert cond_func(1, 2) == 2
    assert cond_func(3, 2) == 3



# Generated at 2022-06-21 19:53:09.338691
# Unit test for function curried_filter
def test_curried_filter():
    numbers = [1, 2, 3, 4]

    filter_by_two = curried_filter(lambda x: x % 2 == 0)

    assert filter_by_two(numbers) == [2, 4]



# Generated at 2022-06-21 19:53:12.019947
# Unit test for function compose
def test_compose():
    assert eq(compose(
        'test',
        lambda value: value.lower()
    ), 'test')

    assert eq(compose(
        'test',
        lambda value: value.lower(),
        lambda value: value.upper()
    ), 'TEST')



# Generated at 2022-06-21 19:53:15.565368
# Unit test for function curried_filter
def test_curried_filter():
    assert type(curried_filter(lambda x: x)) == type(curried_map(lambda x: x))



# Generated at 2022-06-21 19:53:24.170384
# Unit test for function cond

# Generated at 2022-06-21 19:53:30.372911
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(True)([1, 2, 3, 4, 5]) == [1, 2, 3, 4, 5]
    assert curried_filter(False)([1, 2, 3, 4, 5]) == []
    assert curried_filter(lambda x: x < 3)([1, 2, 3, 4, 5]) == [1, 2]



# Generated at 2022-06-21 19:53:33.269636
# Unit test for function increase
def test_increase():
    assert 1 == increase(0)
    assert 2 == increase(1)
    assert 3 == increase(2)


# Generated at 2022-06-21 19:54:12.095579
# Unit test for function identity
def test_identity():
    assert identity('value') == 'value'
    assert identity(1) == 1
    assert identity([]) == []
    assert identity(()) == ()



# Generated at 2022-06-21 19:54:19.321596
# Unit test for function curry
def test_curry():
    double_increase = lambda a, b: ((a + b) ** 2)
    curried_double_increase = curry(double_increase)
    returned_value = curried_double_increase(3)(4)

    expected_value = double_increase(3, 4)

    assert returned_value == expected_value


# Generated at 2022-06-21 19:54:21.140405
# Unit test for function pipe
def test_pipe():
    assert pipe(1, lambda x: x + 1, lambda x: x + 2) == 4


# Generated at 2022-06-21 19:54:24.371491
# Unit test for function pipe
def test_pipe():
    add = lambda a, b: a + b
    mult = lambda a, b: a * b
    pipe_result = pipe(
        2,
        lambda a: add(a, 2),
        lambda a: mult(a, 4)
    )
    assert pipe_result == 12


# Generated at 2022-06-21 19:54:25.129321
# Unit test for function increase
def test_increase():
    assert increase(10) == 11



# Generated at 2022-06-21 19:54:26.937226
# Unit test for function curried_map
def test_curried_map():
    curried_increase = curried_map(increase)
    assert curried_increase([1, 2, 3]) == [2, 3, 4]



# Generated at 2022-06-21 19:54:29.311516
# Unit test for function compose
def test_compose():
    assert compose(1, lambda num: num + 1) == 2
    assert compose(1, lambda num: num + 1, lambda num: num + 1) == 3
    assert compose(1, lambda num: num + 1, lambda num: num + 1, lambda num: num + 1) == 4



# Generated at 2022-06-21 19:54:35.757928
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x > 2)([1, 2, 3, 4]) == [3, 4]
    assert curried_filter(lambda x: x > 2)([2, 3]) == [3]
    assert curried_filter(lambda x: x > 2)([3, 4]) == [3, 4]
    assert curried_filter(lambda x: x > 2)([2, 3, 4]) == [3, 4]


# Generated at 2022-06-21 19:54:43.299320
# Unit test for function cond
def test_cond():
    assert cond([(eq(1), identity), (eq(2), increase)]) == identity
    assert cond([(eq(1), identity), (eq(2), increase)])(2) == identity(2)
    assert cond([(eq(2), identity), (eq(1), increase)]) == increase
    assert cond([(eq(2), identity), (eq(1), increase)])(2) == increase(2)
    assert cond([(eq(3), identity), (eq(1), increase)])(3) == identity(3)



# Generated at 2022-06-21 19:54:45.530010
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2
    assert increase(2) == 3
    assert increase(13) == 14


# Generated at 2022-06-21 19:56:11.815779
# Unit test for function curry
def test_curry():
    def add(a, b, c):
        return a + b + c
    assert curry(add)(1)(2)(3) == 6
    assert curry(add, 2)(1, 2)(3) == 6
    assert curry(add)(1)(2, 3) == 6
    assert curry(add)(1, 2)(3) == 6



# Generated at 2022-06-21 19:56:14.505364
# Unit test for function pipe
def test_pipe():
    assert compose(
        2,
        increase,
        increase
    ) == 4

    assert pipe(
        2,
        increase,
        increase
    ) == 4



# Generated at 2022-06-21 19:56:20.100043
# Unit test for function curried_map
def test_curried_map():
    list_of_numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    curried_mapper = curried_map(lambda x: x + 1)
    new_list_of_numbers = curried_mapper(list_of_numbers)

    assert(new_list_of_numbers == [2, 3, 4, 5, 6, 7, 8, 9, 10])


# Generated at 2022-06-21 19:56:24.540570
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x < 10)([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]) == [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert curried_filter(lambda x: x < 10)(x for x in range(20)) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]



# Generated at 2022-06-21 19:56:34.877533
# Unit test for function cond
def test_cond():
    def func1(x):
        print('executed func1')
        return x + 1


    def func2(x):
        print('executed func2')
        return x * 2


    def func3(x):
        print('executed func3')
        return x * x


    def func4(x):
        print('executed func4')
        return x / 2


    def cond_func1(x):
        return x > 5


    def cond_func2(x):
        return x < 10


    def cond_func3(x):
        return x == 10


    assert cond(
        [(cond_func1, func1), (cond_func2, func2), (cond_func3, func3)])(1) == 2

# Generated at 2022-06-21 19:56:38.558669
# Unit test for function find
def test_find():
    print('Unit test for find function')
    assert find([1, 2, 3, 4, 5, 6], lambda x: x % 2 == 0) == 2
    assert find([1, 3, 5], lambda x: x % 2 == 0) is None
    assert find(['A', 'B', 'C'], lambda x: x == 'B') == 'B'
    assert find([], lambda x: True) is None
    print('Test successfully finished\n')



# Generated at 2022-06-21 19:56:41.464619
# Unit test for function pipe
def test_pipe():
    assert pipe('one', lambda x: x + 'two', lambda x: x + 'three') == 'onetwothree'



# Generated at 2022-06-21 19:56:47.349514
# Unit test for function find
def test_find():
    t1 = (1, "one")
    t2 = (2, "two")
    t3 = (3, "three")
    t4 = (4, "four")

    test_list = [t1, t2, t3, t4]

    assert find(test_list, lambda x: x[0] == 3) == t3
    assert find(test_list, lambda x: x[0] == 5) == None



# Generated at 2022-06-21 19:56:52.139319
# Unit test for function find
def test_find():
    """
    >>> find([(1, 2), (3, 4), (5, 6)], lambda x: x[1] == 3)
    (3, 4)
    >>> find([(1, 2), (3, 4), (5, 6)], lambda x: x[1] == 5)
    """


# Generated at 2022-06-21 19:56:55.149357
# Unit test for function curry
def test_curry():
    assert increase(1) == 2
    curried_increase = curry(increase)
    assert curried_increase(1) == 2
    assert curry(increase, 3)(1) == 2

