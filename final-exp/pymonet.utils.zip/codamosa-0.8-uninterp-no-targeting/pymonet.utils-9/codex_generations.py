

# Generated at 2022-06-21 19:47:17.263243
# Unit test for function compose
def test_compose():
    def sum_one(x):
        return x + 1
    sum_one_compose = compose(1, sum_one)
    assert sum_one_compose() == 2, "Not compose"

# Generated at 2022-06-21 19:47:20.004593
# Unit test for function pipe
def test_pipe():
    pipe_test = pipe(5, lambda x: x * 3, lambda x: x + 2)
    assert pipe_test == 17


# Generated at 2022-06-21 19:47:22.143292
# Unit test for function pipe
def test_pipe():
    assert pipe(1, increase, increase) == 3
    assert pipe(1, increase, increase, increase) == 4

# Generated at 2022-06-21 19:47:23.268069
# Unit test for function increase
def test_increase():
    assert increase(3) == 4


# Generated at 2022-06-21 19:47:28.783259
# Unit test for function find
def test_find():
    def test(value, expected):
        result = find(value[0], value[1])
        assert result == expected

    test([[1, 2, 3], lambda x: x == 2], 2)
    test([[1, 2, 3], lambda x: x == 4], None)
    # test('a', lambda x: True, None)


# Generated at 2022-06-21 19:47:30.952059
# Unit test for function compose
def test_compose():
    assert compose(
        1,
        lambda x: x + 2,
        lambda y: y * 3
    ) == 9



# Generated at 2022-06-21 19:47:34.808890
# Unit test for function curried_map
def test_curried_map():
    """
    >>> curried_map(lambda x: x*x)(range(10))
    [0, 1, 4, 9, 16, 25, 36, 49, 64, 81]
    >>> increase_ = curried_map(increase)
    >>> increase_(range(10))
    [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    """
    pass



# Generated at 2022-06-21 19:47:40.210267
# Unit test for function find
def test_find():
    """Test for find"""
    assert find([1, 2, 3], lambda item: item == 1) == 1
    assert find([1, 2, 3], lambda item: item == 3) == 3
    assert find([1, 2, 3], lambda item: item == 5) is None



# Generated at 2022-06-21 19:47:41.140774
# Unit test for function increase
def test_increase():
    assert increase(1) == 2

# Generated at 2022-06-21 19:47:42.191905
# Unit test for function identity
def test_identity():
    assert identity(1) == 1



# Generated at 2022-06-21 19:47:55.404515
# Unit test for function cond
def test_cond():
    is_even = lambda x: x % 2 == 0
    is_divide_by_3 = lambda x: x % 3 == 0
    is_divide_by_6 = lambda x: x % 6 == 0
    print_even = lambda x: print('x is even')
    print_divide_by_3 = lambda x: print('x is divide by 3')
    print_divide_by_6 = lambda x: print('x is divide by 6')
    print_default = lambda x: print('x is not even, not divide by 3 and not divide by 6')


# Generated at 2022-06-21 19:48:04.656049
# Unit test for function pipe
def test_pipe():
    # Define functions to test
    def func_1(value):
        return value + 1

    def func_2(value):
        return value * 3

    # Get result
    result_1 = pipe(2, func_2, func_1, func_2)
    result_2 = pipe(5, func_1, func_2)
    result_3 = pipe(5, func_2, func_1, func_1)
    # Test result
    assert result_1 == 27
    assert result_2 == 18
    assert result_3 == 14


if __name__ == '__main__':
    test_pipe()

# Generated at 2022-06-21 19:48:08.357262
# Unit test for function memoize
def test_memoize():
    counter = 0

    @memoize
    def f(x):
        nonlocal counter
        counter += 1
        return counter

    assert f(1) == 1
    assert f(1) == 1
    assert f(2) == 2
    assert f(2) == 2
    assert f(1) == 1
    assert f(1) == 1
    assert f(3) == 3



# Generated at 2022-06-21 19:48:11.904510
# Unit test for function find
def test_find():
    assert find([], identity) is None
    assert find([1, 2, 3], identity) == 1
    assert find([1, 2, 3, 4], lambda value: value % 2 == 0) == 2
    assert find([1, 2, 3, 4], lambda value: value % 2 == 1) == 1
    assert find([1, 2, 3, 4], lambda value: value > 10) is None



# Generated at 2022-06-21 19:48:14.331786
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity(True) is True
    assert identity("test") == "test"


# Generated at 2022-06-21 19:48:18.711361
# Unit test for function find
def test_find():
    assert find(['a', 'b', 'c'], lambda x: x == 'a') == 'a'
    assert find(['a', 'b', 'c'], lambda x: x == 'd') is None



# Generated at 2022-06-21 19:48:26.073663
# Unit test for function compose
def test_compose():
    # Test with functions without arguments
    data = [1, 2, 3]
    assert data == compose(*[identity for _ in data])(data)

    # Test with functions with arguments
    data = [1, 2, 3]
    assert data == compose(*[lambda y: y + 1 for _ in data])(data)

    # Test with functions with multiple arguments
    data = [1, 2, 3]
    assert data == compose(*[lambda x, y: x + y for _ in data])(data, 0)

    # Test with empty list of functions
    data = [1, 2, 3]
    assert data == compose()(data)



# Generated at 2022-06-21 19:48:32.196813
# Unit test for function memoize
def test_memoize():
    def to_do_fn(number):
        print('Doing some work')
        return number ** 2

    to_do_fn_memoized = memoize(to_do_fn)

    assert to_do_fn(5) == 25
    assert to_do_fn_memoized(5) == 25
    assert to_do_fn_memoized(5) == 25


# Generated at 2022-06-21 19:48:40.363658
# Unit test for function cond
def test_cond():
    def true(*_args):
        return True

    def false(*_args):
        return False

    def first(*_args):
        return 1

    def second(*_args):
        return 2

    def third(*_args):
        return 3

    # Test simple cond
    assert cond([
        (true, first),
        (false, second),
    ])(1) == 1

    assert cond([
        (false, first),
        (true, second),
    ])(1) == 2

    # Test multiple true conditions
    assert cond([
        (true, first),
        (true, second),
    ])(1) == 1

    # Test return value of function
    assert cond([
        (true, first),
        (false, second),
    ])(1) == 1

    # Test multiple args

# Generated at 2022-06-21 19:48:43.654731
# Unit test for function curried_filter
def test_curried_filter():
    """
    Unit test for curried_filter.

    :returns: True
    :rtype: boolean
    """
    assert curried_filter(lambda x: x == 10, [1, 10, 20, 30]) == [10]



# Generated at 2022-06-21 19:48:57.456595
# Unit test for function cond
def test_cond():
    def is_number(number):
        return isinstance(number, int)

    def is_zero(number: int):
        return number == 0

    def is_positive(number: int):
        return number > 0

    def is_negative(number: int):
        return number < 0

    def square_number(number: int):
        return number ** 2

    def cube_number(number: int):
        return number ** 3

    def increase_number(number: int):
        return number + 1

    def decrease_number(number: int):
        return number - 1

    def increase_string(string: str):
        return '+' + string


# Generated at 2022-06-21 19:49:00.052829
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-21 19:49:07.987599
# Unit test for function cond
def test_cond():
    """
    Test for the cond function
    """
    condition_list = [
        (
            lambda a: a % 2 == 0,
            lambda a: a / 2
        ),
        (
            lambda a: a % 2 == 1,
            lambda a: (a + 1) / 2
        )
    ]

    @cond(condition_list)
    def func(a):
        pass

    assert func(4) == 2, "4 / 2 must be 2"
    assert func(5) == 3, "(5 + 1) / 2 must be 3"
    assert func(20) == 10, "20 / 2 must be 10"


# Generated at 2022-06-21 19:49:10.543400
# Unit test for function curried_filter
def test_curried_filter():
    assert(
        curried_filter(lambda x: x > 1)([1, 2, 3]) == [2, 3]
    )



# Generated at 2022-06-21 19:49:13.986211
# Unit test for function pipe
def test_pipe():
    increase_by_2 = pipe(2, lambda x: x + 1, lambda x: x + 1)
    assert increase_by_2 == 4


# Generated at 2022-06-21 19:49:17.615153
# Unit test for function pipe
def test_pipe():
    assert pipe(2, increase, identity) == 3
    assert pipe(2, increase, identity, identity) == 4
    assert pipe(2, increase, lambda x: x + 1, lambda x: x + 2) == 6


# Generated at 2022-06-21 19:49:27.881460
# Unit test for function find
def test_find():
    import unittest
    from unittest import TestCase
    from collections import deque

    class TestFind(TestCase):
        def test_should_find_element_from_list(self):
            self.assertEqual(find([1,2,3], lambda item: item == 2), 2)

        def test_should_find_element_from_tuple(self):
            self.assertEqual(find((1, 2, 3), lambda item: item == 2), 2)

        def test_should_find_element_from_deque(self):
            self.assertEqual(find(deque([1, 2, 3]), lambda item: item == 2), 2)


# Generated at 2022-06-21 19:49:30.449883
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)



# Generated at 2022-06-21 19:49:35.511207
# Unit test for function curried_filter
def test_curried_filter():
    x = curried_filter(lambda x: x > 2, [1, 2, 3, 4, 5, 6])
    y = [3, 4, 5, 6]
    assert x == y



# Generated at 2022-06-21 19:49:38.842628
# Unit test for function curry
def test_curry():
    curried_add = curry(lambda x, y: x + y)
    assert curried_add(3)(5) == 8
    assert curried_add(3, 5) == 8



# Generated at 2022-06-21 19:49:42.634101
# Unit test for function increase
def test_increase():
    for i in range(10):
        assert(i == increase(i) - 1)



# Generated at 2022-06-21 19:49:46.255850
# Unit test for function pipe
def test_pipe():
    """
    Unit test for function pipe
    """
    assert pipe(3, lambda x: x + 1, lambda x: x * 2) == 8



# Generated at 2022-06-21 19:49:51.169851
# Unit test for function pipe
def test_pipe():
    assert pipe(1, increase, increase, identity) == 3
    assert pipe(1, increase, increase) == 3
    assert pipe(1, increase) == 2
    assert pipe(1) == 1
    assert pipe(1, identity) == 1
    assert pipe(-1, increase) == 0



# Generated at 2022-06-21 19:49:52.996528
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False



# Generated at 2022-06-21 19:49:56.113519
# Unit test for function memoize
def test_memoize():
    global counter
    counter = 0

    @memoize
    def inc_counter():
        global counter
        counter += 1
        return counter

    assert inc_counter() == 1
    assert counter == 1
    assert inc_counter() == 1
    assert counter == 1

# Generated at 2022-06-21 19:49:58.787123
# Unit test for function identity
def test_identity():
    assert identity(1) == 1
    assert identity('test') == 'test'
    assert identity(None) is None



# Generated at 2022-06-21 19:50:00.173596
# Unit test for function increase
def test_increase():
    assert increase(0) == 1


# Generated at 2022-06-21 19:50:04.300623
# Unit test for function pipe
def test_pipe():
    assert pipe(
        1,
        lambda x: x + 2,
        lambda x: x - 1,
    ) == 2

    assert pipe(
        1,
        lambda x: x + 2,
        lambda x: x - 1,
        lambda x: x * 2,
    ) == 4



# Generated at 2022-06-21 19:50:08.357694
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
    assert increase(-1) == 0
    assert increase(1) == 2


# Generated at 2022-06-21 19:50:10.807790
# Unit test for function eq
def test_eq():
    assert eq(1, 1)
    assert not eq(1, 2)
    assert not eq(2, 1)



# Generated at 2022-06-21 19:50:21.888560
# Unit test for function cond
def test_cond():
    def add(a, b): return a + b

    def multiply(a, b): return a * b

    def divides(a, b): return a / b

    def power(a, b): return a ** b

    f = cond([
        (eq(0), lambda a, b: 0),
        (eq(1), lambda a, b: a + b),
        (eq(2), lambda a, b: a * b),
        (eq(3), lambda a, b: a / b),
        (eq(4), lambda a, b: a ** b),
    ])
    assert f(0, 10, 2) == 0
    assert f(1, 10, 2) == 12
    assert f(2, 10, 2) == 20
    assert f(3, 10, 2) == 5

# Generated at 2022-06-21 19:50:23.025719
# Unit test for function compose
def test_compose():
    assert compose(2, identity, increase, increase) == 4
    assert compose(3, identity, increase, increase) == 5



# Generated at 2022-06-21 19:50:24.028256
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:50:33.521251
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(eq(1))([1, 2, 3]) == [1]
    assert curried_filter(eq(1))([1]) == [1]
    assert curried_filter(eq(1))([2, 3]) == []
    assert curried_filter(eq(1))([]) == []
    assert curried_filter(eq(1), [1, 2, 3]) == [1]
    assert curried_filter(eq(1), [1]) == [1]
    assert curried_filter(eq(1), [2, 3]) == []
    assert curried_filter(eq(1), []) == []


# Generated at 2022-06-21 19:50:35.862611
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False
    assert eq(1)(1) == True


# Generated at 2022-06-21 19:50:38.844558
# Unit test for function pipe
def test_pipe():
    # compose(value, *functions):
    assert pipe(2, increase, increase, increase) == 5
    assert pipe(2, lambda x: x*2, increase) == 5



# Generated at 2022-06-21 19:50:45.635187
# Unit test for function cond
def test_cond():
    not_none = lambda x: x is not None
    gt_ten = lambda x: x > 10
    lt_twenty = lambda x: x < 20

    def fn(value):
        return 'not_none'

    def fn1(value):
        return 'gt_ten'

    def fn2(value):
        return 'lt_twenty'

    def fn3(value):
        return 'else'

    assert cond([(not_none, fn), (gt_ten, fn1), (lt_twenty, fn2)]) is fn
    assert cond([(not_none, fn), (gt_ten, fn1), (lt_twenty, fn2)])(None) is fn3



# Generated at 2022-06-21 19:50:48.656438
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) == [2, 4, 6, 8, 10]



# Generated at 2022-06-21 19:50:54.558652
# Unit test for function curried_filter
def test_curried_filter():
    list1 = [1, 2, 3, 4, 5, 6]
    list2 = [2, 4, 6]
    my_filter = curried_filter(lambda x: x % 2 == 0)

    assert my_filter(list1) == list2
    return 'test_curried_filter passed'


# Generated at 2022-06-21 19:50:57.346020
# Unit test for function find
def test_find():
    assert find([4, 4, 2, 3], eq(4)) == 4
    assert find([4, 3, 2, 3], eq(4)) == None



# Generated at 2022-06-21 19:51:06.768800
# Unit test for function compose
def test_compose():
    assert compose(
        'Hello',
        lambda x: x + ' world!',
        lambda x: x.capitalize()
    ) == 'hello world!'



# Generated at 2022-06-21 19:51:17.548394
# Unit test for function pipe
def test_pipe():
    class InsuranceClaim:
        def __init__(self, cost: float, is_valid: bool) -> None:
            self.cost: float = cost
            self.valid: bool = is_valid

    def claim_cost(claim: InsuranceClaim) -> float:
        return claim.cost

    def is_valid_claim(claim: InsuranceClaim) -> bool:
        return claim.valid

    def is_expired(days: int) -> bool:
        return days > 30

    def claim_expired_days(claim: InsuranceClaim) -> int:
        return 40

    def multiply(number: float, multiplier: float) -> int:
        return number * multiplier


# Generated at 2022-06-21 19:51:19.970006
# Unit test for function eq
def test_eq():
    """
    Test curried function eq

    :returns:
    :rtype: Boolean
    """
    eq1 = eq(1)
    return eq1(1)



# Generated at 2022-06-21 19:51:23.118577
# Unit test for function pipe
def test_pipe():
    assert pipe(1, increase, increase, increase) == 4
    assert pipe(None, identity, identity, identity) is None


# Generated at 2022-06-21 19:51:25.820551
# Unit test for function compose
def test_compose():
    assert compose("test", lambda string: string + "_test", lambda string: string * 2) == \
        "test_test_test_test"



# Generated at 2022-06-21 19:51:30.026406
# Unit test for function memoize
def test_memoize():
    """
    Test for function memoize
    """
    print('TESTS FOR MEMOIZE')
    @memoize
    def f(x):
        return x

    t1 = time.time()
    print('%d == %d' % (f(2), 2))
    t2 = time.time()
    print('%d == %d' % (f(2), 2))
    t3 = time.time()
    print(t3 - t2 < t2 - t1)

if __name__ == '__main__':
    test_memoize()


# Generated at 2022-06-21 19:51:41.754640
# Unit test for function pipe
def test_pipe():
    # Test case data
    list_ = [i for i in range(1, 6)]
    positive_list = [i for i in range(1, 6)]
    negative_list = [-1, -2, -3, -4, -5]
    mix_list = [i for i in range(-2, 3)]
    test_cases = [
        (list_, [i + 1 for i in range(1, 6)]),
        (positive_list, [1, 2, 3, 4, 5]),
        (negative_list, [-2, -3, -4, -5, -6]),
        (mix_list, [-1, 0, 1, 2, 3])
    ]

    def get_test_case_result(test_case):
        (in_data, out_data) = test_case

# Generated at 2022-06-21 19:51:46.151296
# Unit test for function compose
def test_compose():
    double = lambda x: x*2
    add = lambda x: x+2
    composed = compose(3, double, add)
    assert composed == 10



# Generated at 2022-06-21 19:51:52.630967
# Unit test for function curry
def test_curry():
    add = curry(lambda x, y: x + y)
    add_partially = add(1)
    assert add_partially(2) == 3

    map_curried = curry(map)
    map_curried_with_one = map_curried(lambda x: x + x)
    assert list(map_curried_with_one([1, 2, 3])) == [2, 4, 6]



# Generated at 2022-06-21 19:51:54.506884
# Unit test for function identity
def test_identity():
    assert identity(4) == 4
    assert identity('JoJo') == 'JoJo'


# Generated at 2022-06-21 19:52:10.854655
# Unit test for function curried_map
def test_curried_map():
    assert curried_map(increase)(range(10)) == [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]



# Generated at 2022-06-21 19:52:12.130760
# Unit test for function eq
def test_eq():
    assert eq(1)(1) == True
    assert eq(2)(1) == False



# Generated at 2022-06-21 19:52:20.757432
# Unit test for function curry
def test_curry():
    add = lambda x, y: x + y
    add_one = curry(add, 2)
    assert add_one(1)(1) == 2
    assert add_one(1)(2) == 3
    assert add_one(2)(1) == 3
    assert add_one(2)(2) == 4
    assert add_one(1)(1) == 2
    assert add_one(1)(2) == 3
    assert add_one(2)(1) == 3
    assert add_one(2)(2) == 4



# Generated at 2022-06-21 19:52:21.712994
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:52:25.060499
# Unit test for function identity
def test_identity():
    assert identity('identity test') == 'identity test'
    assert identity(0) == 0
    assert identity([1, 2]) == [1, 2]
    assert identity((1, 2)) == (1, 2)



# Generated at 2022-06-21 19:52:26.051073
# Unit test for function increase
def test_increase():
    assert increase(1) == 2


# Generated at 2022-06-21 19:52:30.745100
# Unit test for function cond
def test_cond():
    assert cond([
        (lambda value: value == None,
            lambda value: "value is None"),
        (lambda value: value < 5,
            lambda value: "value is less than 5"),
        (lambda value: value > 10,
            lambda value: "value is greater than 10"),
        (lambda value: value > 100,
            lambda value: "value is greater than 100")
    ])(4) == "value is less than 5"



# Generated at 2022-06-21 19:52:35.324324
# Unit test for function curry
def test_curry():
    @curry
    def f(x, y, z):
        return x + y + z

    assert f(1, 2, 3) == f(1)(2, 3) == f(1, 2)(3) == f(1)(2)(3)



# Generated at 2022-06-21 19:52:37.152097
# Unit test for function compose
def test_compose():
    assert compose(
        1,
        increase
    ) == 2



# Generated at 2022-06-21 19:52:40.314559
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x % 2 == 0)(range(5)) == [0, 2, 4]
    assert curried_filter(lambda x: x < 4)(range(5)) == [0, 1, 2, 3]



# Generated at 2022-06-21 19:53:13.923470
# Unit test for function compose
def test_compose():
    assert compose('a', identity) == 'a'
    assert compose(1, increase) == 2
    assert compose(1, increase, increase) == 3
    assert compose(1, increase, increase, increase) == 4
    assert compose(1, increase, increase, increase, increase) == 5



# Generated at 2022-06-21 19:53:16.192931
# Unit test for function increase
def test_increase():
    assert increase(0) == 1
    assert increase(1) == 2
    assert increase(10) == 11
    assert increase(100) == 101



# Generated at 2022-06-21 19:53:18.942498
# Unit test for function identity
def test_identity():
    assert identity(True) is True
    assert identity(False) is False
    assert identity(None) is None


# Generated at 2022-06-21 19:53:22.775181
# Unit test for function curried_filter
def test_curried_filter():
    collection = [1, 2, 3, 4, 5, 6]
    odd = curried_filter(lambda x: x % 2)
    assert odd(collection) == [1, 3, 5]

    even = curried_filter(lambda x: x % 2 == 0)
    assert even(collection) == [2, 4, 6]



# Generated at 2022-06-21 19:53:24.873569
# Unit test for function eq
def test_eq():
    assert eq(1, 1) == True
    assert eq(1, 2) == False


# Generated at 2022-06-21 19:53:26.091325
# Unit test for function increase
def test_increase():
    assert increase(1) == 2



# Generated at 2022-06-21 19:53:28.285379
# Unit test for function increase
def test_increase():
    assert increase(1) == 2
test_increase()


# Generated at 2022-06-21 19:53:32.525993
# Unit test for function pipe
def test_pipe():
    assert pipe(100, increase, increase) == 102
    assert pipe(100, increase, increase, increase) == 103
    assert pipe(100, increase, increase, increase, increase, increase, increase) == 106
    assert pipe(100, increase, increase, increase, increase, increase, increase, identity) == 106



# Generated at 2022-06-21 19:53:35.235514
# Unit test for function memoize
def test_memoize():
    @memoize
    def sum(a):
        return a * 2 + 1

    assert sum(1) == 3
    assert sum(1) == 3


if __name__ == '__main__':
    test_memoize()

# Generated at 2022-06-21 19:53:38.162375
# Unit test for function compose
def test_compose():
    def first(value):
        return value + 1

    def second(value):
        return value + 2

    assert compose(
        1, first, second
    ) == 4



# Generated at 2022-06-21 19:54:42.159853
# Unit test for function curried_filter
def test_curried_filter():
    assert curried_filter(lambda x: x == 1)([1]) == [1]
    assert curried_filter(lambda x: x)([1]) == [1]
    assert curried_filter(lambda x: x == 2)([1]) == []


# Generated at 2022-06-21 19:54:47.732187
# Unit test for function curry
def test_curry():
    assert curry(lambda x, y: x * y)(1, 2) == 2
    assert curry(lambda x, y, z: x * y * z)(1, 2, 3) == 6
    assert curry(lambda x, y, z: x * y * z)(1)(2)(3) == 6
    assert curry(lambda x, y, z: x * y)(1)(2)(3) == 2
    assert curry(lambda x, y, z: x * y)(1, 2)(3) == 2



# Generated at 2022-06-21 19:54:51.881778
# Unit test for function pipe
def test_pipe():
    """
    Function for unit testing function pipe.

    :returns: assertion result
    :rtype: Boolean
    """
    assert pipe(1, lambda x: x+1, lambda x: x*2, lambda x: x-1) == 3



# Generated at 2022-06-21 19:55:02.319272
# Unit test for function cond
def test_cond():
    is_number = lambda x: type(x) == type(1)
    add = lambda x, y: x + y
    multiply = lambda x, y: x * y
    exponent = lambda x, y: x ** y
    function = cond([
        (lambda x, y: is_number(x), add),
        (lambda x, y: is_number(y), multiply),
        (lambda x, y: is_number(x) and is_number(y), exponent)
    ])
    assert function(2, 3) == 5
    assert function(4, 'a') == 'a'
    assert function('b', 4) == 'bbbb'
    assert function('b', 'a') == 'b' ** 'a'
    assert function(2, 1) == 2
    assert function(2, 2) == 2 ** 2


# Generated at 2022-06-21 19:55:07.577936
# Unit test for function find
def test_find():
    case = [
        (([], lambda x: True), None),
        (([1, 2, 3], lambda x: x == 1), 1),
        (([1, 2, 3], lambda x: x == 2), 2),
        (([1, 2, 3], lambda x: x == 3), 3),
        (([1, 2, 3], lambda x: x == 4), None)
    ]
    for argument, result in case:
        assert find(*argument) is result, f"find(*{argument}) != {result} != {find(*argument)}"
    print('find: OK')



# Generated at 2022-06-21 19:55:12.454363
# Unit test for function memoize
def test_memoize():

    @memoize
    def some_function(argument):
        return argument

    assert some_function('test1') == 'test1'
    assert some_function('test2') == 'test2'
    assert some_function('test1') == 'test1'


test_memoize()



# Generated at 2022-06-21 19:55:14.714378
# Unit test for function memoize
def test_memoize():
    assert memoize(increase)(1) == memoize(increase)(1)
    assert memoize(increase)(1) != memoize(increase)(2)



# Generated at 2022-06-21 19:55:18.358556
# Unit test for function pipe
def test_pipe():
    data = [1, 2, 3, 4, 5]

    result = pipe(
        data,
        curried_filter(lambda x: x % 2 == 0),
        curried_map(lambda x: x ** 2)
    )

    assert result == [4, 16]



# Generated at 2022-06-21 19:55:24.120364
# Unit test for function curried_map
def test_curried_map():
    first = curried_map(lambda x: x + 2)
    second = first([1, 2, 3])
    third = first([2, 3, 4])
    fourth = curried_map(lambda x: x + 2)([3, 4, 5])

    assert second == [3, 4, 5]
    assert third == [4, 5, 6]
    assert fourth == [5, 6, 7]


# Generated at 2022-06-21 19:55:28.404161
# Unit test for function find
def test_find():
    find_test_list = [{'a': 1, 'b': 2}, {'a': 2, 'b': 3}, {'a': 1, 'b': 2}]
    find_test_fn = lambda obj: obj["a"] == 1 and obj["b"] == 2

    def test_find_1():
        assert find(find_test_list, find_test_fn) == {'a': 1, 'b': 2}

    def test_find_2():
        assert find([], find_test_fn) is None

    test_find_1()
    test_find_2()

