

# Generated at 2022-06-23 17:43:06.471803
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        pass
    with work_in_progress("Testing work_in_progress with context"):
        def f():
            time.sleep(3)
        f()
    with work_in_progress("Testing work_in_progress with context and exception"):
        def f():
            time.sleep(3)
            raise Exception("foo")
        try:
            f()
        except Exception as e:
            pass

# Generated at 2022-06-23 17:43:16.013902
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(0.1)
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "/bin/sh"

    # Call the decorated function
    obj = load_file(path)

    assert obj is not None
    assert type(obj) is bytes

    # Call the decorated function again
    obj = load_file(path)

    assert obj is not None
    assert type(obj) is bytes


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:43:24.347683
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        with open("/path/to/some/file", "rb") as f:
            obj = pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    save_file("/path/to/some/other/file", obj)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:43:31.683759
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        import pickle
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "./tests/resources/pickled_list_0.0.1.dat"

    with work_in_progress("Loading file"):
        obj = load_file(path)

    assert obj == [1, 2, 3]

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    import os
    assert os.path.exists(path)

# Generated at 2022-06-23 17:43:36.648177
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Dummy task"):
        time.sleep(1.0)
    time.sleep(1.0)


if __name__ == '__main__':
    os.chdir(os.path.dirname(__file__))
    test_work_in_progress()

# Generated at 2022-06-23 17:43:47.383825
# Unit test for function work_in_progress
def test_work_in_progress():
    # Define some tasks
    def do_nothing():
        time.sleep(1)

    def do_something():
        time.sleep(2)

    # Execute some tasks with the @work_in_progress decorator
    @work_in_progress("Do nothing")
    def test1():
        do_nothing()

    @work_in_progress("Do something")
    def test2():
        do_something()

    # Execute some tasks in with the work_in_progress context manager
    with work_in_progress("Do nothing"):
        do_nothing()

    with work_in_progress("Do something"):
        do_something()

    # Execute the tests
    test1()
    test2()
    test1()
    test2()


if __name__ == '__main__':
    import doct

# Generated at 2022-06-23 17:43:52.751735
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Loading file"):
        obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)



# Generated at 2022-06-23 17:44:02.130344
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test the functionality of the work_in_progress decorator/context
    manager.
    """

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    print(f"Object loaded: {obj}")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    print("File saved")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:44:14.514297
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import random
    import shutil

    @work_in_progress("Copying file")
    def copy_file(src: str, dst: str):
        with open(src, "rb") as inf:
            with open(dst, "wb") as outf:
                shutil.copyfileobj(inf, outf)

    with NamedTemporaryFile() as f:
        content = f.file.read()
        assert os.path.getsize(f.name) == len(content)
        assert content == b"Testing work_in_progress"

        with NamedTemporaryDirectory() as outdir:
            outpath = os.path.join(outdir, "outfile")
            copy_file(f.name, outpath)
            with open(outpath, "rb") as outf:
                out_content

# Generated at 2022-06-23 17:44:22.918349
# Unit test for function work_in_progress
def test_work_in_progress():
    if __name__ == "__main__":
        @work_in_progress("Loading file")
        def load_file(path):
            with open(path, "rb") as f:
                return pickle.load(f)

        obj = load_file("../README.md")
        print(obj.__class__.__name__)

        with work_in_progress("Saving file"):
            with open("./work_in_progress.md", "wb") as f:
                pickle.dump(obj, f)



# Generated at 2022-06-23 17:44:26.058997
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Test"):
        time.sleep(1)
    print("done.")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:44:33.042856
# Unit test for function work_in_progress
def test_work_in_progress():
    from .diff import compare_output
    from .test import tmp_test_file

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with tmp_test_file("a.pkl", "wb") as f_path:
        obj = {'a': 1, 'b': 2, 'c': 3}
        save_file(obj, f_path)


# Generated at 2022-06-23 17:44:42.754927
# Unit test for function work_in_progress
def test_work_in_progress():
    from pathlib import Path
    from datetime import datetime
    from tempfile import TemporaryDirectory

    def randint(low, high):
        from random import randint
        return randint(low, high)

    # Generate a temporary file to be processed
    with TemporaryDirectory() as tempdir:
        # Generate a temporary file to be processed
        path = Path(tempdir) / f"test_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}.pkl"
        obj = []
        for _ in range(randint(10, 500)):
            obj.append(randint(-10000, 10000))
        with open(path, "wb") as f:
            pickle.dump(obj, f)

        # Test function work_in_progress

# Generated at 2022-06-23 17:44:53.932560
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    import sys
    import tempfile

    with tempfile.TemporaryFile() as tmp:
        print("Testing module 'misc.display'...")
        sys.stdout = io.TextIOWrapper(tmp)
        with work_in_progress("Step 0"):
            time.sleep(0.25)
        with work_in_progress():
            time.sleep(1)
        sys.stdout = sys.__stdout__
        print("... done")
        tmp.seek(0)
        assert tmp.read().decode() == "Testing module 'misc.display'...\n" \
                                      "Step 0... done. (0.25s)\n" \
                                      "... done. (1.00s)\n"
        tmp.flush()



# Generated at 2022-06-23 17:44:56.548116
# Unit test for function work_in_progress
def test_work_in_progress():
    for i in range(5):
        with work_in_progress():
            time.sleep(random.random())

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:45:06.872976
# Unit test for function work_in_progress
def test_work_in_progress():

    def assert_about_equal(expected, actual, tolerance=0.02):
        assert abs(expected - actual) < tolerance, f"got {actual} expected {expected}"

    with work_in_progress("Testing work_in_progress") as progress:
        progress.assert_message("Testing work_in_progress... ")
        time.sleep(3)

    with work_in_progress("Details\nhere") as progress:
        progress.assert_message("Details\nhere... ")
        time.sleep(0.01)
        with work_in_progress("Foo") as progress_foo:
            progress_foo.assert_message("Foo... ")
            time.sleep(0.1)
        progress.assert_message("Details\nhere... ")
        time.sleep(0.02)

# Generated at 2022-06-23 17:45:12.579343
# Unit test for function work_in_progress
def test_work_in_progress():
    try:
        with work_in_progress("Test 1"):
            time.sleep(1)
        with work_in_progress("Test 2"):
            time.sleep(2)
    except KeyboardInterrupt:
        pass

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:45:24.315339
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import os
    file_name = os.path.join(tempfile.gettempdir(), "tmp_file")

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    dic = {"a": {"a1": 1, "a2": 2}, "b": [1, 2, {"b1": 1}, {"b1": 2}]}

    with open(file_name, "wb") as f:
        pickle.dump(dic, f)

    with work_in_progress("Saving file"):
        with open(file_name, "rb") as f:
            obj = pickle.load(f)


# Generated at 2022-06-23 17:45:27.071094
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("test function")
    def func():
        time.sleep(1)
    func()

# Generated at 2022-06-23 17:45:37.765995
# Unit test for function work_in_progress
def test_work_in_progress():
    class Foo:
        pass

    foo = Foo()

    foo.fun_1 = lambda : "foo"
    foo.fun_2 = lambda x: x
    foo.fun_3 = lambda x, y: x + y

    with work_in_progress():
        time.sleep(1)

    fun = foo.fun_1
    with work_in_progress("Type: {}, id: {}".format(type(fun), id(fun))):
        time.sleep(2)

    fun = foo.fun_1
    with work_in_progress("Type: {}, id: {}".format(type(fun), id(fun))):
        time.sleep(3)

    fun = lambda x: foo.fun_2(x)

# Generated at 2022-06-23 17:45:43.131881
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def test_func():
        s_time = time.time()
        while time.time() - s_time < 2:
            pass

    test_func()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:45:46.219204
# Unit test for function work_in_progress
def test_work_in_progress():
    def func():
        time.sleep(1)
        1 / 0

    with pytest.raises(ZeroDivisionError):
        with work_in_progress("test", 5, "s"):
            func()
    assert True

# Generated at 2022-06-23 17:45:50.310528
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.2)

# unit test for module clevercsv
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:45:52.129774
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.5)
    assert True

# Generated at 2022-06-23 17:45:55.856760
# Unit test for function work_in_progress
def test_work_in_progress():
    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:45:57.360759
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sleeping"):
        time.sleep(0.125)

# Generated at 2022-06-23 17:45:59.170537
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("This is a test"):
        time.sleep(0.1)

# Generated at 2022-06-23 17:46:01.387612
# Unit test for function work_in_progress
def test_work_in_progress():
    import contextlib

    @work_in_progress("Testing work_in_progress")
    def test():
        time.sleep(0.1)

    assert test() is None

# Generated at 2022-06-23 17:46:12.000773
# Unit test for function work_in_progress

# Generated at 2022-06-23 17:46:20.467545
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("../../README.md")
    save_file(obj, "temp.pkl")


# ======== run ========

# Generated at 2022-06-23 17:46:22.334965
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(0.5)

# Generated at 2022-06-23 17:46:24.737625
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def _test_work_in_progress():
        time.sleep(1)

    _test_work_in_progress()

# Generated at 2022-06-23 17:46:31.451211
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("work_in_progress.py")
    with work_in_progress("Saving file"):
        with open("work_in_progress.py", "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:46:34.150107
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(1)
    with work_in_progress("Test"):
        time.sleep(1)

# Generated at 2022-06-23 17:46:45.160998
# Unit test for function work_in_progress
def test_work_in_progress():
    from unittest.mock import patch
    from io import StringIO

    def load_file(path):
        time.sleep(3)

    def save_file(path):
        time.sleep(5)

    load_file_output = StringIO()
    save_file_output = StringIO()

    with patch('sys.stdout', new=load_file_output):
        with work_in_progress():
            load_file("foo")

    with patch('sys.stdout', new=save_file_output):
        with work_in_progress():
            save_file("foo")

    assert load_file_output.getvalue() == "Work in progress... done. (3.00s)\n"
    assert save_file_output.getvalue() == "Work in progress... done. (5.00s)\n"

# Generated at 2022-06-23 17:46:49.762928
# Unit test for function work_in_progress
def test_work_in_progress():
    print()
    with work_in_progress("Loading file"):
        time.sleep(1.50)
    def func():
        time.sleep(2.50)
    func = work_in_progress("Saving file")(func)
    func()

# test_work_in_progress()

# Generated at 2022-06-23 17:47:00.265715
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import pickle
    from .logger import get_logger

    logger = get_logger()

    description_1 = "Test description 1"
    description_2 = "Test description 2"

    # A function decorated by work_in_progress
    @work_in_progress(description_1)
    def test_function_decorator(path):
        with open(path, "wb") as f:
            logger.info(f"Creating a temporary file in {path}")
            pickle.dump(None, f)

    # The same function but with work_in_progress as a context manager
    def test_context_manager(path):
        logger.info(f"Creating a temporary file in {path}")

# Generated at 2022-06-23 17:47:08.038839
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("tests/test_data/test.pickle")
    assert isinstance(obj, dict)
    assert "test_dict" in obj
    assert obj["test_dict"]["hello"] == "world"


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:47:10.436985
# Unit test for function work_in_progress
def test_work_in_progress():
    import math
    with work_in_progress("Loading file"):
        math.factorial(200)

# Generated at 2022-06-23 17:47:17.551538
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test for context manager
    with work_in_progress("Saving file"):
        time.sleep(5)
    # Test for decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

# Generated at 2022-06-23 17:47:21.351861
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(5)
    @work_in_progress("Saving file")
    def save():
        time.sleep(15)
    save()

# Generated at 2022-06-23 17:47:26.673278
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Counting to 10"):
        for i in range(10):
            time.sleep(0.05)
            print(i, end=', ', flush=True)
        print("done")

# Generated at 2022-06-23 17:47:34.680491
# Unit test for function work_in_progress
def test_work_in_progress():

    class Thing:
        pass

    # Test for a code block
    with work_in_progress("Doing work"):
        thing = Thing()
        for i in range(10):
            time.sleep(0.1)

    # Test for a function
    @work_in_progress("Doing more work")
    def do_more_work(thing: Thing):
        for i in range(10):
            time.sleep(0.1)

    do_more_work(thing)

# Generated at 2022-06-23 17:47:37.988082
# Unit test for function work_in_progress
def test_work_in_progress():
    from .stub import Stub

    stub = Stub()

    def f():
        with work_in_progress("Loading file"):
            stub.call()

    f()
    assert stub.called and "Loading file... done" in stub.log[0]

# Generated at 2022-06-23 17:47:41.104891
# Unit test for function work_in_progress
def test_work_in_progress():
    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:47:44.074856
# Unit test for function work_in_progress
def test_work_in_progress():
    for i in range(4):
        time.sleep(i)
        with work_in_progress(desc=f"Processing {i}"):
            pass

# Generated at 2022-06-23 17:47:54.152680
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress()."""
    count, size = 0, 100
    time_begin = time.time()
            
    with work_in_progress("Test work in progress"):
        for i in range(size):
            count += 1
            time.sleep(.01)

    time_end = time.time()
    time_consumed = time_end - time_begin

    try:
        assert count == size
        assert (time_consumed - size * 0.01) < 0.05
    except:
        print("Test failed!")
    else:
        print("Test passed!")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:48:02.881994
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            return pickle.dump(obj, f)

    tempfile_path = pathlib.Path("test.work_in_progress.pickle")

    obj = {"one": 1, "two": 2, "three": 3}
    save_file(tempfile_path, obj)
    assert load_file(tempfile_path) == obj

    tempfile_path.unlink()

# Generated at 2022-06-23 17:48:08.484188
# Unit test for function work_in_progress
def test_work_in_progress():
    for desc in (
        "Work in progress",
        "Loading file",
        "Saving file",
        "",
    ):
        with work_in_progress(desc):
            time.sleep(2.5)

# Generated at 2022-06-23 17:48:15.140012
# Unit test for function work_in_progress
def test_work_in_progress():
    load_file = lambda path: time.sleep(3)
    with work_in_progress("Loading file"):
        load_file("/path/to/some/file")
    save_file = lambda path, obj: time.sleep(4)
    with work_in_progress("Saving file"):
        save_file("/path/to/some/file", obj)

# Generated at 2022-06-23 17:48:21.432770
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    path = "result/data.pkl"
    obj = [i for i in range(1000000)]
    save_file(obj)
    assert load_file(path) == obj

# Generated at 2022-06-23 17:48:31.897634
# Unit test for function work_in_progress
def test_work_in_progress():
    import sys
    import inspect
    from io import StringIO

    # Replace stdout with a buffer
    old_stdout = sys.stdout
    sys.stdout = output_buffer = StringIO()

    # Run testing commands
    @work_in_progress("Loading file...")
    def load_file(file):
        time.sleep(0.01)
        return file

    obj = load_file(1)
    assert obj == 1

    with work_in_progress("Saving file..."):
        time.sleep(0.01)

    # Restore stdout
    sys.stdout = old_stdout

    # Evaluate output
    buffered_output = output_buffer.getvalue()

# Generated at 2022-06-23 17:48:39.476302
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test file path
    file_path = Path(__file__).parent.parent / 'test_data' / 'test_file.pkl'
    # Test object
    test_obj = ['Test string', 1, None]

    # Test context manager
    with work_in_progress("Saving file") as w:
        with open(file_path, 'wb') as f:
            pickle.dump(test_obj, f)

    # Test function decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, 'rb') as f:
            return pickle.load(f)
    loaded_obj = load_file(file_path)
    assert test_obj == loaded_obj

    # Clean up
    if file_path.exists(): file_path.un

# Generated at 2022-06-23 17:48:43.059062
# Unit test for function work_in_progress
def test_work_in_progress():
    def test_func():
        with work_in_progress("Testing work in progress..."):
            time.sleep(2)

    test_func()


# Generated at 2022-06-23 17:48:54.257813
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()


# -----------------------------------------------------------------------------
# Copyright (c) 2014--, The Qiita Development Team.
#
# Distributed under the terms of the BSD 3-clause License.
#
# The full license is in the file LICENSE, distributed with this software.
# -----------------------------------------------------------------------------

from .base import QiitaObject


# Generated at 2022-06-23 17:48:58.584905
# Unit test for function work_in_progress
def test_work_in_progress():
    from pathlib import Path

    # Test context manager
    with work_in_progress("Slow task"):
        time.sleep(5)
    # "Slow task... done. (5.00s)"

    # Test decorated function
    @work_in_progress("Test time-consuming")
    def time_consuming():
        time.sleep(1)

    time_consuming()
    # "Test time-consuming... done. (1.00s)"



# Generated at 2022-06-23 17:49:02.638602
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import pickle

    with work_in_progress("Test"):
        time.sleep(1)
    with work_in_progress("Test"):
        time.sleep(1)

    @work_in_progress("Save file")
    def save(path):
        with open(path, "wb") as f:
            pickle.dump({"a": 1, "b": 2}, f)

    @work_in_progress("Load file")
    def load(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    save("saved.pkl")
    print(load("saved.pkl"))

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:05.017262
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(0.1)

# Generated at 2022-06-23 17:49:11.839200
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test 1")
    def f1():
        time.sleep(2)
    f1()

    @work_in_progress("Test 2")
    def f2():
        time.sleep(1)
    f2()

    @work_in_progress("Test 3")
    def f3():
        time.sleep(0.5)
    f3()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:15.957189
# Unit test for function work_in_progress
def test_work_in_progress():
    print("testing function work_in_progress")
    with work_in_progress("Counting to 1 million"):
        for i in range(1000000):
            pass
    with work_in_progress("Counting to 1 million"):
        time.sleep(0.1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:24.309882
# Unit test for function work_in_progress
def test_work_in_progress():
    from io import BytesIO
    from pickle import dumps, loads

    class TestCase:
        def __init__(self, obj):
            self.obj = obj

        def check(self, obj: object):
            assert self.obj == obj, "work_in_progress may not be working well."

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj: object):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
        return obj


# Generated at 2022-06-23 17:49:30.521516
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("test.pckl")

    with work_in_progress("Saving file"):
        with open("test.pckl", "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:34.732326
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(2)
    with work_in_progress("Saving file"):
        time.sleep(3)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:49:39.521868
# Unit test for function work_in_progress
def test_work_in_progress():
    def _test_func(*args, **kwargs):
        with work_in_progress("This is a test ", desc="This is a test"):
            time.sleep(0.5)
        return _test_func(*args, **kwargs)

    with pytest.raises(Exception, match="Too many arguments"):
        _test_func()


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:49:42.920421
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.01)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:49:50.509979
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    def do_nothing():
        time.sleep(random.random())

    def do_something():
        for _ in range(1000000):
            pass

    print("Testing work_in_progress() on a function doing nothing")
    with work_in_progress("Loading file"):
        do_nothing()
    print("Testing work_in_progress() on a function doing something")
    with work_in_progress("Saving file"):
        do_something()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:55.639124
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("__init__.py")

    with work_in_progress("Saving file"):
        time.sleep(0.5)

# Generated at 2022-06-23 17:50:02.718069
# Unit test for function work_in_progress
def test_work_in_progress():
    import sys
    import os
    import tempfile
    import time

    INPUTS = [10, 100, 1000, 10000, 100000, 1000000]
    OUTPUTS = [0, 1, 2, 3, 4, 5, 6]

    src_path = os.path.join(tempfile.gettempdir(), "module.py")
    with open(src_path, "w") as f:
        f.write(
            f"""\
"""
        )

    with work_in_progress("Testing function"):
        for i in INPUTS:
            assert i in OUTPUTS

    with work_in_progress("Loading module"):
        import module


# Generated at 2022-06-23 17:50:14.088940
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    from tempfile import NamedTemporaryFile
    from pickle import dump

    with work_in_progress("Saving file"):
        with open(os.devnull, "w") as f:
            for i in range(1000000):
                dump(i, f)

    with work_in_progress("Saving file to a temp file"):
        with NamedTemporaryFile("wb") as f:
            for i in range(1000000):
                dump(i, f)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return load(f)

    with open(os.devnull, "wb") as f:
        for i in range(1000000):
            dump(i, f)


# Generated at 2022-06-23 17:50:17.907598
# Unit test for function work_in_progress
def test_work_in_progress():
    from unittest.mock import patch

    with patch('builtins.print') as mock_print:
        with work_in_progress("Work in progress"):
            assert True
        mock_print.assert_has_calls([
            ('Work in progress... ',),
            ('done. (0.00s)',),
        ])

# Generated at 2022-06-23 17:50:28.709316
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test case 1
    with work_in_progress("Loading file"):
        with open("../test_data/test_data.pickle", "rb") as f:
            data = pickle.load(f)
    # Test case 2
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    data = load_file("../test_data/test_data.pickle")
    # Test case 3
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

# Generated at 2022-06-23 17:50:29.814603
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(2)

# Generated at 2022-06-23 17:50:34.418454
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(1)
    @work_in_progress("Test Decorator")
    def func():
        time.sleep(1)
    func()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:50:37.025219
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(1)
    with work_in_progress("Some task"):
        time.sleep(2)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:50:46.307400
# Unit test for function work_in_progress
def test_work_in_progress():
    filepath = os.path.join(os.path.dirname(__file__), "test.pkl")

    # Test decorator usage
    @work_in_progress("Loading file")
    def test_decor():
        with open(filepath, "rb") as f:
            return pickle.load(f)

    test_decor()

    # Test context manager usage
    with work_in_progress("Saving file"):
        with open(filepath, "wb") as f:
            pickle.dump(0, f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:50:51.599953
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    >>> with work_in_progress("Loading file"):
    ...     time.sleep(1)
    Loading file... done. (1.00s)
    >>> with work_in_progress("Saving file"):
    ...     time.sleep(2)
    Saving file... done. (2.00s)
    """
    pass

# Generated at 2022-06-23 17:50:58.359830
# Unit test for function work_in_progress
def test_work_in_progress():
    from tempfile import NamedTemporaryFile
    from io import StringIO

    def load_file(path: str):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path: str, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


    s = "Lorem ipsum dolor sit amet, consectetur adipiscing elit."
    with NamedTemporaryFile() as f:
        obj = {(i, s[i:]) for i in range(len(s))}
        save_file(f.name, obj)

        with work_in_progress("Loading file"):
            res = load_file(f.name)


# Generated at 2022-06-23 17:51:00.952071
# Unit test for function work_in_progress
def test_work_in_progress():
    import doctest
    doctest.run_docstring_examples(work_in_progress, globals(), verbose=True)

# Generated at 2022-06-23 17:51:04.951752
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def some_func(x):
        time.sleep(x)
    some_func(0.03)
    # work_in_progress() as a context manager.
    with work_in_progress():
        time.sleep(0.05)

# Generated at 2022-06-23 17:51:15.580030
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    class SomeClass:
        @work_in_progress("Initializing object")
        def __init__(self):
            self.time_consuming_data = [1] * 10**7
            # do some other stuff that takes time
            time.sleep(0.1)

    class SomeOtherClass:
        @classmethod
        @work_in_progress("Loading object")
        def load(cls, path):
            with open(path, "rb") as f:
                return pickle.load(f)

    obj1 = SomeClass()
    path = "/tmp/test_work_in_progress.pkl"

    with work_in_progress("Saving object"):
        with open(path, "wb") as f:
            pickle.dump(obj1, f)

    obj2 = SomeOtherClass

# Generated at 2022-06-23 17:51:18.344964
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(1)
    with work_in_progress("Waiting one second"):
        time.sleep(1)

# Generated at 2022-06-23 17:51:29.948160
# Unit test for function work_in_progress
def test_work_in_progress():

    from pathlib import Path

    dirs = (Path(__file__).parent / "test_dirs").glob("*")
    with work_in_progress("Listing directories"):
        dir_list = list(dirs)

    with work_in_progress("Listing files"):
        files_list = [file for dir in dir_list for file in Path(dir).glob("*")]

    @work_in_progress("Loading files")
    def load_files(files):
        return [load_file(file) for file in files]

    @work_in_progress("Saving files")
    def save_files(files):
        for file in files:
            save_file(file)


# Generated at 2022-06-23 17:51:34.998388
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:51:40.536877
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:51:44.257225
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("./logs/airpress")



# Generated at 2022-06-23 17:51:50.682307
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with work_in_progress("Loading file"):
        obj = load_file("/tmp/my_object")
    with work_in_progress("Saving file"):
        save_file("/tmp/my_object", obj)
    assert True



# Generated at 2022-06-23 17:51:53.652144
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test function :func:`~wys_core.work_in_progress`."""
    def _worker():
        with work_in_progress(desc="Test progress"):
            time.sleep(0.6)
    _worker()
    assert True

# Generated at 2022-06-23 17:51:57.609222
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def foo():
        time.sleep(2)
    foo()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:07.454320
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import numpy as np

    n_sample = 1e6

    def fib(x):
        # fibonacci function
        if x <= 1:
            return 1
        return x * fib(x-1)

    print("# Test function work_in_progress")

    with work_in_progress("Computing fibonacci numbers"):
        for _ in range(2, int(n_sample)):
            fib(_)

    with work_in_progress("Creating a huge matrix"):
        m = np.random.rand(int(n_sample), int(n_sample))

    with work_in_progress("Saving the matrix"):
        np.save("m", m)

    with work_in_progress("Loading the matrix"):
        m = np.load("m.npy")



# Generated at 2022-06-23 17:52:12.061171
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test")
    def foo():
        time.sleep(0.2)

    with work_in_progress("Test 2"):
        time.sleep(0.2)

    foo()


if __name__ == "__main__":
    # Unit test
    test_work_in_progress()

# Generated at 2022-06-23 17:52:14.271686
# Unit test for function work_in_progress
def test_work_in_progress():
    def test():
        for i in range(3):
            print('a' * i)
            time.sleep(1)

    assert work_in_progress(test) is None

# Generated at 2022-06-23 17:52:21.690869
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile
    @work_in_progress("Test for work_in_progress")
    def test():
        with open(os.path.join(tempfile.gettempdir(), "test_work_in_progress"), "wb") as f:
            for i in range(2**20):
                f.write(bytes([i & 255]))

    test()
    try:
        os.remove(os.path.join(tempfile.gettempdir(), "test_work_in_progress"))
    except:
        pass

# Generated at 2022-06-23 17:52:29.057308
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Waiting")
    def wait(delay: float, output: bool = False):
        time.sleep(delay)
        if output:
            print("It works!")

    wait(1)
    wait(2, True)
    wait(3)
    with work_in_progress("This is a long task"):
        for _ in range(4):
            wait(1)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:52:33.956319
# Unit test for function work_in_progress
def test_work_in_progress():
    def fake_work(n):
        time.sleep(n)

    @work_in_progress("Testing Work in progress")
    def test_fake_work():
        fake_work(5)

    test_fake_work()


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:52:39.463847
# Unit test for function work_in_progress
def test_work_in_progress():
    def _try():
        # Test for function
        @work_in_progress("Fetching data")
        def fetch_data(url):
            time.sleep(1)
            return requests.get(url)

        # Test for block
        with work_in_progress("Saving data"):
            time.sleep(2)

    _try()


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:52:46.509340
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test function")
    def test_function():
        pass
    
    @work_in_progress
    def test_function2():
        pass

    with work_in_progress("Test context") as c:
        pass

    print("Output should have three times of 'work_in_progress':")
    test_function()
    test_function2()
    with work_in_progress("Test context") as c:
        pass

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:52:53.717037
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path: str):
        with open(path, "rb") as f:
            return pickle.load(f)

    # On the first time the file is read, the file must be saved to cache,
    # so it will take some time. On the second run, the file is directly read
    # from the cache, so it will be quick. This checks whether the function works
    # as expected.
    with work_in_progress("Saving file"):
        data = load_file("tests/data/test_data.pickle")
    with work_in_progress("Reading file"):
        data = load_file("tests/data/test_data.pickle")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:57.005924
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sleeping"):
        time.sleep(0.5)
    time.sleep(0.5)

# Generated at 2022-06-23 17:52:58.512853
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Initialising"):
        time.sleep(1)



# Generated at 2022-06-23 17:53:09.473826
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Test create a work_in_progress manager inside function...")
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    print("Loaded file via load_file(path).")

    print("Test work_in_progress manager inside a with-context...")
    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)
    print("Saved file with pickle.dump(obj, f).")

if __name__ == '__main__':
    test_work_in_progress()