

# Generated at 2022-06-23 17:43:06.189569
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "test work_in_progress"
    begin_time = time.time()

    with work_in_progress(desc):
        a = 1
        a = a ** 100000000

    time_consumed = time.time() - begin_time
    print(f"{desc}... done. ({time_consumed:.2f}s)")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:43:11.095359
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def f():
        time.sleep(0.1)
    f()
    with work_in_progress():
        time.sleep(0.1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:43:22.736536
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile
    import os
    import warnings

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


    with tempfile.NamedTemporaryFile(suffix=".pkl") as f:
        obj = dict(a=1, b=2)
        save_file(f.name, obj)
        assert(obj == load_file(f.name))


# Generate unit tests for this file.
if __name__ == "__main__":
    import doctest

# Generated at 2022-06-23 17:43:29.217882
# Unit test for function work_in_progress
def test_work_in_progress():
    from time import sleep
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "tests/testdata/"
    obj = load_file(path)
    assert isinstance(obj, str)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    assert isinstance(obj, str)
    assert obj == "SAMPLE DATA"

# Generated at 2022-06-23 17:43:31.852570
# Unit test for function work_in_progress
def test_work_in_progress():
    pass


# Generated at 2022-06-23 17:43:37.565885
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Calculating")
    def factorial(n):
        return n if n <= 1 else n * factorial(n - 1)

    for n in [3, 5, 7]:
        assert factorial(n) == n * factorial(n - 1)

    with work_in_progress("Waiting"):
        time.sleep(0.3)

# Generated at 2022-06-23 17:43:47.768343
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile
    import os

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    del obj

    with tempfile.TemporaryDirectory() as desc:
        with work_in_progress("Saving file"):
            with open("/path/to/some/file", "wb") as f:
                pickle.dump("testing", f)

        os.unlink("/path/to/some/file")

if __name__ == "__main__":
    # Run the unit test
    test_work_in_progress()

# Generated at 2022-06-23 17:43:51.497116
# Unit test for function work_in_progress
def test_work_in_progress():
    from time import sleep

    print("Testing function work_in_progress")
    with work_in_progress("Task 1"):
        sleep(0.4)

    @work_in_progress("Task 2")
    def task_2():
        sleep(1)

    task_2()



# Generated at 2022-06-23 17:44:02.539196
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import pickle
    import os
    import random

    # Test progress bar context manager
    with work_in_progress("Breaking the atom") as progress_bar:
        objects = [random.randint(0, 1) for _ in range(1000000)]
        for i in range(len(objects)):
            objects[i] = objects[i]
            if (i % 100000 == 0):
                progress_bar.update(i)
        progress_bar.set_finished()
    assert objects == [random.randint(0, 1) for _ in range(1000000)], "Random generation failed"

    # Test normal context manager
    with tempfile.NamedTemporaryFile(delete=False) as f:
        objects = [random.randint(0, 1) for _ in range(1000000)]
        pick

# Generated at 2022-06-23 17:44:07.226311
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Counting integers")
    def count_integers(n):
        i = 0
        while i < n:
            i += 1
        return i

    assert count_integers(100) == 100

# Generated at 2022-06-23 17:44:16.661686
# Unit test for function work_in_progress
def test_work_in_progress():
    import os

    # We will create a dummy file to load and save
    path = os.path.join(os.path.dirname(__file__), "dummy_file.pkl")
    data = {"a": list(range(1000000))}
    with open(path, "bw") as f:
        pickle.dump(data, f)

    with work_in_progress("Loading file"):
        with open(path, "rb") as f:
            pickle.load(f)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(data, f)

    os.remove(path)


# -----------------------------------------------------------------------------
# Command line interface


# Generated at 2022-06-23 17:44:20.368130
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Doing something..."):
        time.sleep(1)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:44:27.410214
# Unit test for function work_in_progress
def test_work_in_progress():
    import sys
    import io

    with work_in_progress("Test work_in_progress"):
        sys.stdout = io.StringIO()
        time.sleep(1)
        sys.stdout = io.TextIOWrapper(sys.stdout.detach(), encoding='utf-8')
        assert(sys.stdout.getvalue() == "Test work_in_progress... done. (1.00s)\n")
    pass

# Generated at 2022-06-23 17:44:39.874540
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/etc/passwd")
    with tempfile.TemporaryDirectory() as tmpdir:
        save_file(f"{tmpdir}/dump", obj)

    # Expected output:
    # Loading file... done.
    # Saving file... done.


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:44:46.920676
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test with context manager
    with unittest.mock.patch('sys.stdout', new=io.StringIO()) as mocked_stdout:
        with work_in_progress("Loading file"):
            time.sleep(1)
            print('I am doing something')
    assert mocked_stdout.getvalue() == "Loading file... I am doing somethingdone. (1.00s)\n"

    # Test with decorator
    @work_in_progress("Loading file")
    def test():
        time.sleep(1)
        print('I am doing something')
    with unittest.mock.patch('sys.stdout', new=io.StringIO()) as mocked_stdout:
        test()

# Generated at 2022-06-23 17:44:54.333894
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""
    Test for function work_in_progress
    """
    import warnings
    warnings.filterwarnings("ignore")

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:45:02.108168
# Unit test for function work_in_progress
def test_work_in_progress():

    with work_in_progress("Doing something"):
        time.sleep(1)

    with work_in_progress("Doing something else"):
        time.sleep(1.5)

    @work_in_progress("Doing it again")
    def do_it_again(x, y):
        time.sleep(x + y)

    do_it_again(1.1, 2.2)


if __name__ == "__main__":
    work_in_progress()

# Generated at 2022-06-23 17:45:08.355409
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open("/path/to/other/file", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:45:18.318851
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile
    import pickle
    import sys

    class DummyObject:
        def __init__(self, x, y):
            self.x = x
            self.y = y
        def __eq__(self, other):
            return self.x == other.x and self.y == other.y

    obj = DummyObject("Test", 3.1415926)

    # Save to temporary file...
    path = os.path.join(tempfile.gettempdir(), "work-in-progress-test.pkl")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    # ... and load it

# Generated at 2022-06-23 17:45:21.645124
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test task")
    def long_job(x):
        for _ in range(x):
            time.sleep(.5)

    long_job(5)
    assert True

test_work_in_progress()

# Generated at 2022-06-23 17:45:29.317042
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:45:29.934461
# Unit test for function work_in_progress
def test_work_in_progress():
    pass

# Generated at 2022-06-23 17:45:39.766730
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile

    def worker(desc: str, sleep: float):
        with work_in_progress(desc):
            time.sleep(sleep)

    tmpdir = tempfile.TemporaryDirectory()
    print(f"Temporary directory: {tmpdir.name}")

    worker("Work 01", 0.1)
    worker("Work 02", 0.2)
    worker("Work 03", 0.3)

    worker("Work 04", 0.4)
    worker("Work 05", 0.5)
    worker("Work 06", 0.6)

    @work_in_progress
    def work_07():
        return time.sleep(0.7)

    @work_in_progress
    def work_08():
        return time.sleep(0.8)


# Generated at 2022-06-23 17:45:45.422341
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:45:49.769642
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test for function
    @work_in_progress("Processing data")
    def func():
        time.sleep(0.1)
    func()

    # Test for context block
    with work_in_progress("Processing data"):
        time.sleep(0.1)

# =============================================================================

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:45:52.396346
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(1)
    with work_in_progress("Test"):
        time.sleep(1)
    return True

# Generated at 2022-06-23 17:46:04.266738
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
            
test_work_in_progress()

## @brief Prints progress bar in terminal.
#
#  Usage:
#
#  .. code:: python
#
#      from progbar import Progbar
#
#      items = range(10000)
#      # You can use tqdm for progress bar.
#      for item in Progbar(items, use_tqdm=False):
#          #

# Generated at 2022-06-23 17:46:09.154962
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Counting to 100")
    def count_to_hundred():
        for i in range(100):
            time.sleep(0.01)
    
    assert True

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:46:12.574460
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("A")
    def a(n):
        time.sleep(n)

    a(0.01)
    a(1.01)

    with work_in_progress("B"):
        time.sleep(0.01)

# Generated at 2022-06-23 17:46:20.511673
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Test"
    print(desc + "... ", end='', flush=True)
    begin_time = time.time()
    with work_in_progress("Calling function"):
        time.sleep(1)
    time_consumed = time.time() - begin_time
    print(f"done. ({time_consumed:.2f}s)")
    assert f"{time_consumed:.2f}" == "1.00"


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:46:23.404055
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    with work_in_progress():
        time.sleep(0.1)

    @work_in_progress()
    def test():
        time.sleep(0.1)

    test()

# Generated at 2022-06-23 17:46:25.514698
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1)
    time.sleep(1)

# Generated at 2022-06-23 17:46:34.565945
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    with work_in_progress("Testing work_in_progress function"):
        time.sleep(.2)
        obj = []
        for _ in range(1000):
            obj.append([])
        for _ in range(1000):
            with work_in_progress("Loading file"):
                with open("test_work_in_progress_file.pickle", 'wb') as f:
                    pickle.dump(obj, f)
            with work_in_progress("Saving file"):
                with open("test_work_in_progress_file.pickle", 'rb') as f:
                    pickle.load(f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:46:35.102883
# Unit test for function work_in_progress
def test_work_in_progress():
    assert 1 == 1

# Generated at 2022-06-23 17:46:41.607061
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("TEST: Sleep")
    def test():
        time.sleep(0.5)
    test()

    print()

    with work_in_progress("TEST: Sleep"):
        time.sleep(0.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:46:45.799323
# Unit test for function work_in_progress
def test_work_in_progress():
    mock_time = MagicMock()
    mock_time.time.return_value = 0
    with patch("time.time", new=mock_time.time):
        with work_in_progress("Loading file") as _:
            mock_time.time.return_value = 5
    mock_time.time.assert_called_once()
    mock_time.time.assert_called_with()

# Generated at 2022-06-23 17:46:52.859029
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile

    temp_path = tempfile.mktemp()
    print(temp_path)
    with work_in_progress("Testing work_in_progress") as f:
        with open(temp_path, "wt") as f:
            f.write("Hello, world!")
    assert os.path.exists(temp_path)
    os.remove(temp_path)
    assert not os.path.exists(temp_path)

# Generated at 2022-06-23 17:46:59.511760
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile
    with work_in_progress("Test work_in_progress"):
        time.sleep(1)
    with tempfile.TemporaryDirectory() as tmpdir:
        with work_in_progress("Test work_in_progress"):
            with open(os.path.join(tmpdir, "dummy"), "x") as f:
                f.write("dummy")
            assert os.path.exists(os.path.join(tmpdir, "dummy"))


# Generated at 2022-06-23 17:47:10.346989
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Beginning unit test for function work_in_progress...")

    # Unit test #0
    try:
        work_in_progress(desc="Loading file")
    except Exception as e:
        print(e)
        print("Unit test #0 failed.")
        return
    print("Unit test #0 succeeded.")

    # Unit test #1
    print()
    try:
        with work_in_progress(desc="Saving file") as f:
            time.sleep(1.0)
    except Exception as e:
        print(e)
        print("Unit test #1 failed.")
        return
    print("Unit test #1 succeeded.")

    # Unit test #2
    print()

# Generated at 2022-06-23 17:47:14.853441
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Creating a new array")
    def create_numpy_array():
        return np.arange(10000)
    create_numpy_array()
    print("test_work_in_progress passed")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:47:16.709312
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test the function work_in_progress with the doctest."""
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:47:22.767100
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    print(obj)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:47:25.797442
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress()"):
        time.sleep(.01)
    assert True

# Generated at 2022-06-23 17:47:35.684803
# Unit test for function work_in_progress
def test_work_in_progress():
    import sys
    import os
    import io
    import pickle

    filepath = "/tmp/test_work_in_progress.pickle"

    # Save `test_obj`
    saved_stdout = sys.stdout
    sys.stdout = io.StringIO()
    test_obj = "test"
    with work_in_progress("Saving file"):
        with open(filepath, "wb") as f:
            pickle.dump(test_obj, f)
    out = sys.stdout.getvalue()
    sys.stdout.close()
    sys.stdout = saved_stdout

    # Load `test_obj`
    saved_stdout = sys.stdout
    sys.stdout = io.StringIO()

# Generated at 2022-06-23 17:47:42.532626
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile
    from andata.record import DataRecord

    data_record = DataRecord()
    data_record.test = 42
    data_record.other = "asdf"

    # Create temporary file
    with work_in_progress("Creating temporary file"):
        tmp_path = tempfile.mkstemp()[-1]
    print(f"\tCreated temporary file at {tmp_path}")

    # Save DataRecord to temporary file
    with work_in_progress("Saving DataRecord"):
        data_record.save(tmp_path)
    print(f"\tSize of saved file: {os.path.getsize(tmp_path):0,} bytes")

    # Load DataRecord from temporary file

# Generated at 2022-06-23 17:47:47.988530
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path) as f:
            return f.read()

    with work_in_progress("Saving file"):
        with open("/tmp/abc", "w") as f:
            f.write("abc")

    assert load_file("/tmp/abc") == "abc"

# Generated at 2022-06-23 17:47:54.388047
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert obj == {'a': 1, 'b': 'test'}

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

# vim: ts=4 sw=4 sts=4 expandtab

# Generated at 2022-06-23 17:47:59.390508
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test for function work_in_progress"""
    # Test for function work_in_progress
    with work_in_progress("Processing data"):
        time.sleep(2)
    try:
        with work_in_progress("Processing data"):
            time.sleep(2)
            raise Exception("Something's wrong")
        raise Exception("Catch clause not working?")
    except Exception:
        pass

# Run test for function work_in_progress
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:48:03.646484
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test the function :func:`~IMTreatment.common.work_in_progress`.
    """
    with work_in_progress("Work in progress"):
        time.sleep(5)

# Generated at 2022-06-23 17:48:11.876670
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test function `work_in_progress`."""
    import os
    import tempfile
    import pickle

    print("Testing function `work_in_progress`.", flush=True)

    # Test 1:
    with work_in_progress("This function is not implemented"):
        time.sleep(3)

    # Test 2:
    @work_in_progress("Loading file")
    def _load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    _path = os.path.join(tempfile.gettempdir(), f"{os.getpid()}.pickle")
    with open(_path, "wb") as f:
        pickle.dump({'a': 1, 'b': 2, 'c': 3}, f)
    _d = _

# Generated at 2022-06-23 17:48:18.833975
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for :func:`work_in_progress`"""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:48:23.466295
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("test 1")
    def func():
        time.sleep(0.5)
    func()

    with work_in_progress("test 2"):
        time.sleep(0.5)

# Generated at 2022-06-23 17:48:29.105917
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    with work_in_progress("Loading file"):
        time.sleep(0.1)
    print()
    with work_in_progress("Loading file"):
        time.sleep(0.1)
    print()

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)


# Generated at 2022-06-23 17:48:32.401899
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1.0)
    with work_in_progress("Saving file"):
        time.sleep(0.5)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:48:33.780468
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(2)


if __name__ == "__main__":

    # Test work_in_progress
    test_work_in_progress()

# Generated at 2022-06-23 17:48:35.287959
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(3.3)

# Generated at 2022-06-23 17:48:44.263307
# Unit test for function work_in_progress
def test_work_in_progress():
    # Check if the print message is formatted as expected
    with mock.patch("builtins.print") as mock_print:
        with work_in_progress("Loading file"):
            pass
        mock_print.assert_called_once_with("Loading file... ")

    # Check if time consumed is more than 0.0.
    begin_time = time.time()
    with work_in_progress("Saving file"):
        end_time = time.time()
    time_consumed = end_time - begin_time
    assert time_consumed > 0.0

# Generated at 2022-06-23 17:48:54.298473
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    path = "example.pkl"
    obj = {"a": 1, "b": [2, 3]}
    obj_ = load_file(path)
    assert obj_ == obj
    save_file(path, obj_)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:00.533570
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    assert load_file("test.pickle") == [1, 2, 3, 4]

    with work_in_progress("Saving file"):
        with open("test.pickle", "wb") as f:
            pickle.dump([1, 2, 3, 4], f)

# Generated at 2022-06-23 17:49:11.883983
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)


    path = "bob.test.test_script.test_work_in_progress"
    with open(path, "wb") as f:
        pickle.dump(None, f)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file(path)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:19.766355
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with io.StringIO() as buf, contextlib.redirect_stdout(buf):
        obj = load_file("/path/to/some/file")
        print(buf.getvalue())

    with io.StringIO() as buf, contextlib.redirect_stdout(buf):
        with work_in_progress("Saving file"):
            with open("/path/to/some/file", "wb") as f:
                pickle.dump(obj, f)

        print(buf.getvalue())

# Generated at 2022-06-23 17:49:24.014484
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test function")
    def test_function():
        pass

    test_function()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:26.507756
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test work in progress"):
        time.sleep(0.5)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:29.143093
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing WIP"):
        time.sleep(2)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:49:30.730656
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("hello", desc="description"):
        time.sleep(1.0)

# Generated at 2022-06-23 17:49:34.959213
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Sample task")
    def sample_task():
        time.sleep(1)

    # Unit test for function work_in_progress
    sample_task()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:41.677448
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    from unittest import mock
    from datetime import timedelta

    def foo(path, any_data):
        with open(path, "wb") as f:
            pickle.dump(any_data, f)
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress(desc="Unittest")
    def bar(path, any_data):
        time.sleep(0.01)  # To make sure the time consumption is more than 0
        return foo(path, any_data)

    with mock.patch("sys.stdout", new=io.StringIO()) as mocked_stdout:
        value = bar("my_test.pkl", 4)

# Generated at 2022-06-23 17:49:45.711809
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.7)
    with work_in_progress("Saving file"):
        time.sleep(1.8)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:49:57.225637
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    from io import StringIO
    from tempfile import NamedTemporaryFile

    def test_function(path, seconds):
        with open(path, "rb") as f:
            time.sleep(seconds)
            pickle.load(f)

    # Test function
    with NamedTemporaryFile() as f_src, StringIO() as f_dst:

        with work_in_progress("Loading file") as p:
            pickle.dump({"a": 1, "b": 2, "c": 3}, f_src)
            f_src.flush()
            test_function(f_src.name, 1)
        assert p.total_seconds() >= 1


# Generated at 2022-06-23 17:49:59.898523
# Unit test for function work_in_progress
def test_work_in_progress():
    for _ in range(10):
        with work_in_progress("Loading file"):
            time.sleep(0.2)
    with work_in_progress():
        time.sleep(0.5)

# Generated at 2022-06-23 17:50:03.410445
# Unit test for function work_in_progress
def test_work_in_progress():
    # test function
    @work_in_progress()
    def function_1():
        time.sleep(1)

    # test with statement
    with work_in_progress():
        time.sleep(2)


# Test case
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:50:14.447346
# Unit test for function work_in_progress

# Generated at 2022-06-23 17:50:18.379938
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test with function
    @work_in_progress("Loading file")
    def dummy_func():
        time.sleep(1)
        return True

    assert dummy_func()

    # Test with context manager
    def dummy_func2():
        time.sleep(1)
        return True

    with work_in_progress("Loading file"):
        assert dummy_func2()

# Generated at 2022-06-23 17:50:20.088177
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sleeping"):
        time.sleep(1)

# Generated at 2022-06-23 17:50:26.928330
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import io

    start_t = time.time()
    with io.StringIO() as buf, redirect_stdout(buf):
        with work_in_progress("Work progress"):
            time.sleep(0.2)
        time.sleep(0.2)
    now = time.time()
    assert now - start_t < 0.5


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:50:29.529323
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3.52)
    print()

    with work_in_progress("Saving file"):
        time.sleep(3.78)
    print()

# Generated at 2022-06-23 17:50:39.981918
# Unit test for function work_in_progress
def test_work_in_progress():
    def fn1(t):
        with work_in_progress():
            time.sleep(t / 100)

    def fn2(t):
        with work_in_progress(desc="Processing"):
            time.sleep(t / 100)

    with pytest.raises(TypeError):
        work_in_progress(desc=0)

    with pytest.raises(TypeError):
        with work_in_progress(desc=0):
            pass

    with pytest.raises(TypeError):
        with work_in_progress(desc="Hi"):
            fn1(1)

    with pytest.raises(TypeError):
        with work_in_progress(desc="Hi"):
            fn2(1)

    with work_in_progress(desc="Hi"):
        pass


# Generated at 2022-06-23 17:50:48.834033
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = __file__  # python file itself
    obj = load_file(path)
    assert isinstance(obj, str)

    with work_in_progress("Saving file"):
        with open(path, "w") as f:
            f.write(obj)
    with open(path, "r") as f:
        obj = f.read()
    assert isinstance(obj, str)

# Generated at 2022-06-23 17:50:54.918242
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import random
    random.seed(0)

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    path = "/tmp/work_in_progress_test.pkl"
    with work_in_progress("Loading file"):
        obj = load_file(path)
    assert all(obj == [float(i) for i in range(1000)])
    with work_in_progress("Saving file"):
        save_file([float(i) for i in range(1000)], path)


if __name__ == '__main__':
    test_work_in_progress

# Generated at 2022-06-23 17:50:56.867531
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Making COWs fly") as t:
        time.sleep(2.53)

    assert t == 2.53

# Generated at 2022-06-23 17:51:06.199325
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    # A task that is supposed to take no less than 1.5s
    with work_in_progress("Task 1"):
        time.sleep(1.5 + random.random() * 0.5)
    # A task that is supposed to take no less than 3.25s
    with work_in_progress("Task 2"):
        time.sleep(3.25 + random.random() * 0.5)
    # A task that is supposed to take no less than 5s
    @work_in_progress("Task 3")
    def task_3():
        time.sleep(5 + random.random() * 0.5)
    task_3()

# Generated at 2022-06-23 17:51:09.112540
# Unit test for function work_in_progress
def test_work_in_progress():
    global variable

    variable = None
    with work_in_progress("Loading file"):
        variable = "def"

    assert variable == "def"


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:11.364777
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump("test", f)

    load_file("../README.md")
    save_file("tmp")

# Generated at 2022-06-23 17:51:16.529204
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:51:23.441940
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Perform unit test for work_in_progress."""
    from random import random
    from .gauge import gauge
    # Test for generator
    with work_in_progress("Testing"):
        for i in gauge(list(range(10**4))):
            time.sleep(random() / 10)
    # Test for function
    @work_in_progress("Testing")
    def test_func(string: str) -> str:
        return string
    
    assert test_func("Hello") == "Hello"

if __name__ == "__main__":
    r"""Run unit tests when script is called directly."""
    test_work_in_progress()

# Generated at 2022-06-23 17:51:27.472213
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.001)
    with work_in_progress("Saving file"):
        time.sleep(0.002)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:35.804735
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            return pickle.dump(obj, f)

    path = "/tmp/test.pickle"
    obj = dict(a=1, b=2, c=3, d=4, e=5)

    save_file(path, obj)
    loaded_obj = load_file(path)

    assert loaded_obj == obj
    assert loaded_obj["a"] == obj["a"]
    assert loaded_obj["b"] == obj["b"]
    assert loaded_obj

# Generated at 2022-06-23 17:51:42.880898
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    object_ = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(object_, f)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:51:47.237553
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/etc/passwd")
    assert obj is not None
    assert isinstance(obj, str)

# Generated at 2022-06-23 17:51:57.758544
# Unit test for function work_in_progress
def test_work_in_progress():
    def _assert(name: str, task: contextlib.contextmanager):
        begin_time = time.time()
        with task:
            time_consumed = time.time() - begin_time
            assert time_consumed >= 1, name
        time_consumed = time.time() - begin_time
        assert time_consumed >= 1, name

    # test with a context manager
    def _task():
        with work_in_progress("Working"):
            time.sleep(1)

    _assert("context manager", _task)

    # test with a function
    @work_in_progress("Working")
    def _task():
        time.sleep(1)

    _assert("function", _task)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:04.974564
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1.5)
        print("    Some operations...")
        time.sleep(1)
    time.sleep(1)
    @work_in_progress("Saving file")
    def save_file(path, obj):
        time.sleep(1.2)
        print("    Some operations...")
        time.sleep(0.3)
    save_file("/path/to/some/file", object())

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:08.092682
# Unit test for function work_in_progress
def test_work_in_progress():
    for _ in range(5):
        with work_in_progress("Sleeping for 2 seconds"):
            time.sleep(2)

# Generated at 2022-06-23 17:52:12.401139
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3.5)

    with work_in_progress("Saving file"):
        time.sleep(3.7)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:14.401642
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(1.0)

# Generated at 2022-06-23 17:52:17.904853
# Unit test for function work_in_progress
def test_work_in_progress():
    def function(x):
        time.sleep(x)

    with work_in_progress("Loading"):
        function(1)
    print()

    @work_in_progress("Saving")
    def save():
        function(2)

    save()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:52:26.276933
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    assert load_file("/path/to/file")

    with work_in_progress("Saving file"):
        with open("/path/to/file", "wb") as f:
            pickle.dump("value", f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:33.371894
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    # Use pickle to avoid having to create an actual file
    the_obj = {
        'a': 1,
        'b': 2,
        'c': 3
    }

    with work_in_progress("Testing work_in_progress"):
        time.sleep(1)
        with open("/tmp/temp.pickle", "wb") as f:
            pickle.dump(the_obj, f)
        time.sleep(1)

# Generated at 2022-06-23 17:52:39.987765
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with open("test.log", "ab") as f:
        pickle.dump(None, f)

    with work_in_progress("Saving file"):
        time.sleep(0.4)

    print("\n")
    obj = load_file("test.log")
    os.remove("test.log")
    assert obj is None

# Generated at 2022-06-23 17:52:46.183840
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("test_work_in_progress"):
        time.sleep(1)
    @work_in_progress("test_work_in_progress_with_function")
    def test_work_in_progress_with_function():
        time.sleep(1)
    test_work_in_progress_with_function()
    print("test_work_in_progress passed")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:52.225870
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    @work_in_progress()
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("{}/tsn_train_data.pkl".format(DATA_ROOT))
    assert isinstance(obj, list) and len(obj)==1 and isinstance(obj[0], dict)

    with work_in_progress("Saving file"):
        with open("{}/tsn_train_data.pkl".format(DATA_ROOT), "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:52:56.285362
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test function work_in_progress"""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("test/test.pkl")

    with work_in_progress("Saving file"):
        with open("test/test.pkl", "wb") as f:
            pickle.dump(obj, f)


# Test this module
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:53:00.802461
# Unit test for function work_in_progress
def test_work_in_progress():
    arr = np.arange(10 ** 6)

    with work_in_progress("Creating array"):
        arr = np.arange(10 ** 6)

    with work_in_progress("Decreasing elements in array"):
        arr[:] -= 2

    with work_in_progress("Squaring elements in array"):
        arr **= 2