

# Generated at 2022-06-23 17:43:05.720652
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:43:17.163496
# Unit test for function work_in_progress
def test_work_in_progress():
    import sys
    import tempfile, os
    import shutil
    import subprocess
    import io
    import contextlib

    # create a temporary directory
    tmp = tempfile.mkdtemp()
    # save the current file as a fake module in that temporary directory
    shutil.copy(__file__, os.path.join(tmp, "test_work_in_progress.py"))


# Generated at 2022-06-23 17:43:25.316789
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import pickle
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        obj = {}
        with work_in_progress("Loading file"):
            with open(os.path.join(tmp, "save.pkl"), "wb") as f:
                pickle.dump(obj, f)
        with work_in_progress("Saving file"):
            with open(os.path.join(tmp, "save.pkl"), "rb") as f:
                pickle.load(f)
    print("Done")

# Generated at 2022-06-23 17:43:37.827845
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import os

    with open("/tmp/test_work_in_progress", "wb") as f:
        pickle.dump({"test": "file"}, f)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open("/tmp/test_work_in_progress", "wb") as f:
            pickle.dump({"test": "file"}, f)

    assert load_file("/tmp/test_work_in_progress") == {"test": "file"}
    os.remove("/tmp/test_work_in_progress")


# Generated at 2022-06-23 17:43:41.032470
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:43:45.663698
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(1)
    with work_in_progress("Loading file"):
        time.sleep(1)
    with work_in_progress("Saving file"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:43:50.477647
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Work in progress"

    @work_in_progress(desc)
    def work_in_progress_func():
        time.sleep(1)

    with work_in_progress(desc):
        time.sleep(1)

    assert True

# Generated at 2022-06-23 17:43:56.878144
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Here's a test"):
        time.sleep(0.5)
    with work_in_progress("And a test with a very long description to see if it will break the layout of the terminal"):
        time.sleep(0.5)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:44:02.254548
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1.123)

    with work_in_progress("Saving file"):
        time.sleep(0.987)

    with work_in_progress("Performing complex computation"):
        time.sleep(2.357)


if __name__ == '__main__':
    # Run unit test
    test_work_in_progress()

# Generated at 2022-06-23 17:44:13.500902
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import io
    import sys

    # Run the context manager with a command that takes only a few seconds
    with io.StringIO() as buf, contextlib.redirect_stdout(buf):
        with work_in_progress("Test work in progress..."):
            time.sleep(1.2)
        output = buf.getvalue()
    assert "done." in output

    # Test if the output is printed to stderr instead of stdout
    sys.stderr = io.StringIO()
    with work_in_progress("Test work in progress..."):
        time.sleep(1.2)
    output = sys.stderr.getvalue()
    assert "done." in output

# Generated at 2022-06-23 17:44:18.769752
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:44:25.754237
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    @work_in_progress("Loading some file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving some file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:44:32.844191
# Unit test for function work_in_progress
def test_work_in_progress():
    # ================================================================================================ #
    # Example #1
    with work_in_progress("Testing"):
        time.sleep(1)

    # Example #2
    @work_in_progress("Testing")
    def func1(n: int = 3):
        time.sleep(n)
        return "OK"

    assert func1(1) == "OK"
    assert func1(2) == "OK"

    # Example #3
    @work_in_progress("Testing")
    def func2(n: int = 3):
        time.sleep(n)
        yield "OK"

    for item in func2():
        assert item == "OK"
# /test_work_in_progress()


# Run as script
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:44:39.702128
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def _test_load_file(path):
        with open(__file__, "rb") as f:
            return pickle.load(f)
    obj = _test_load_file(__file__)

    with work_in_progress("Saving file"):
        with open(__file__, "wb") as f:
            pickle.dump(obj, f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:44:41.856197
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        with open("/path/to/some/file", "rb") as f:
            pickle.load(f)

# Generated at 2022-06-23 17:44:44.750004
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test work in progress"):
        time.sleep(0.2)

# Generated at 2022-06-23 17:44:47.800682
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test work in progress")
    def test_func():
        time.sleep(1)

    test_func()

# Generated at 2022-06-23 17:44:49.621167
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("hello")
    def foo():
        time.sleep(1)

    foo()


# Generated at 2022-06-23 17:44:53.555456
# Unit test for function work_in_progress
def test_work_in_progress():
    DUMMY_OP = 0.1
    temp_obj = {}

    @work_in_progress("Doing some dummy work")
    def test_work():
        for i in range(1000000):
            temp_obj[i] = i
            time.sleep(DUMMY_OP)

    test_work()

# Generated at 2022-06-23 17:44:58.444284
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    print()
    with work_in_progress("Saving file"):
        time.sleep(1)
    return


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:45:06.806407
# Unit test for function work_in_progress
def test_work_in_progress():
    from io import StringIO

    out = StringIO()
    with contextlib.redirect_stdout(out):
        with work_in_progress():
            time.sleep(0.005)
    assert "done" in out.getvalue() and "s" in out.getvalue()

    out = StringIO()
    with contextlib.redirect_stdout(out):
        with work_in_progress():
            time.sleep(1)
    assert "done" in out.getvalue() and "s" in out.getvalue()

    out = StringIO()
    with contextlib.redirect_stdout(out):
        with work_in_progress():
            time.sleep(123)
    assert "done" in out.getvalue() and "s" in out.getvalue()

# Generated at 2022-06-23 17:45:17.640751
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import sys
    import tempfile

    print(work_in_progress)
    temp_dir = tempfile.TemporaryDirectory(
        prefix="nuketools-work_in_progress"
    )
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file(os.path.join(
        temp_dir.name,
        "test_work_in_progress.pickle"
    ))
    print(obj)


# Generated at 2022-06-23 17:45:23.338226
# Unit test for function work_in_progress
def test_work_in_progress():
    print("==> Testing the `work_in_progress` function:")

    import time

    @work_in_progress("Task 1")
    def task_1():
        time.sleep(1)

    @work_in_progress("Task 2")
    def task_2():
        time.sleep(2)

    @work_in_progress("Task 3")
    def task_3():
        time.sleep(3)

    task_1()
    task_2()
    task_3()

    print("PASSED")



# Generated at 2022-06-23 17:45:26.200513
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(1)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:45:36.624662
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Loading file"):
        time.sleep(0.2)
    with work_in_progress("Loading file"):
        time.sleep(0.5)
    with work_in_progress("Loading file"):
        time.sleep(1.0)
    with work_in_progress("Loading file"):
        time.sleep(1.5)
    with work_in_progress("Loading file"):
        time.sleep(2.0)

    for i in range(10):
        with work_in_progress("Loading file"):
            pass
        time.sleep(0.1)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:45:45.882225
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress"""

    def func1():
        time.sleep(2)

    def func2():
        time.sleep(1.5)

    try:
        # Test work_in_progress as a decorator
        @work_in_progress(desc='Description of task1')
        def task1():
            func1()

        task1()

        # Test work_in_progress as a context manager
        with work_in_progress('Description of task2'):
            func2()
    except Exception as e:
        raise e

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:45:52.786974
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:46:00.976709
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Load file")
    def load_file(path):
        time.sleep(1.5)

    @work_in_progress("Save file")
    def save_file(path):
        time.sleep(2.5)

    load_file("/path/to/file")
    save_file("/path/to/file")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:46:04.009975
# Unit test for function work_in_progress
def test_work_in_progress():
    def foo():
        print("Hello world!")

    with work_in_progress("Running foo()"):
        foo()

# Generated at 2022-06-23 17:46:11.182794
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    >>> import pickle
    >>> import os
    >>> from ..utils import work_in_progress, temp_dir_with_files
    >>> with temp_dir_with_files({"b": pickle.dumps([])}) as temp_dir:
    ...     path = os.path.join(temp_dir, "b")
    ...     with work_in_progress("Test"):
    ...         with open(path, "rb") as f:
    ...             pickle.load(f)
    ...     with work_in_progress("Test"):
    ...         with open(path, "wb") as f:
    ...             pickle.dump([], f)
    ...     Test... done. (0.01s)
    ...     Test... done. (0.00s)
    """

# Generated at 2022-06-23 17:46:20.290919
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    data = load_file("a.pickle")
    assert len(data) == 100

    with work_in_progress("Saving file"):
        with open("b.pickle", "wb") as f:
            pickle.dump(data, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:46:26.368699
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, 'rb') as f:
            return pickle.load(f)

    obj = load_file("../data/transcript.pkl")
    assert isinstance(obj, pd.DataFrame)

    with work_in_progress("Saving file"):
        with open("../data/transcript_copy.pkl", 'wb') as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:46:30.818683
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing"):
        time.sleep(2)

# Generated at 2022-06-23 17:46:34.195970
# Unit test for function work_in_progress
def test_work_in_progress():
    # Function test
    @work_in_progress("Function test")
    def test():
        time.sleep(3)
    # Block test
    with work_in_progress("Block test"):
        time.sleep(3)

# Generated at 2022-06-23 17:46:42.036514
# Unit test for function work_in_progress
def test_work_in_progress():
    t = time.time
    time.time = lambda: t() - 1
    task = work_in_progress("Work in progress")
    output = StringIO()
    sys.stdout = output
    with task:
        task.__exit__()
    assert output.getvalue() == "Work in progress... done. (1.00s)\n"
    time.time = t


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:46:47.619569
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    @work_in_progress()
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    time.sleep(1)

# Generated at 2022-06-23 17:46:52.858993
# Unit test for function work_in_progress
def test_work_in_progress():
    import sys
    import io

    with io.StringIO() as buf, contextlib.redirect_stdout(buf):
        with work_in_progress("work_in_progress"):
            time.sleep(1)
        output = buf.getvalue()

    assert output == "work_in_progress... done. (1.00s)"

# Generated at 2022-06-23 17:47:01.965225
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import pickle

    obj = {
        "numbers": list(range(int(1e6)))
    }
    path = ".tmp"

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    print("Expect time to load saved obj:")
    new_obj = load_file(path)
    assert new_obj == obj

    print("Expect time to save obj:")
    save_file(path)
    new_obj = load_file(path)
    assert new_

# Generated at 2022-06-23 17:47:04.272075
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Finding prime numbers"):
        time.sleep(2)

# Generated at 2022-06-23 17:47:08.208130
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    with tempfile.NamedTemporaryFile() as f:
        save_file(f.name)

# Generated at 2022-06-23 17:47:10.536636
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    with work_in_progress("Test work in progress"):
        time.sleep(0.1)

# Generated at 2022-06-23 17:47:16.519342
# Unit test for function work_in_progress
def test_work_in_progress():
    def func():
        time.sleep(0.3)
        return True

    # Test for decorated function
    assert func()
    func = work_in_progress("Test")(func)
    assert func()

    # Test for context manager
    with work_in_progress("Test context manager"):
        time.sleep(1)


# Run unit tests
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:47:20.301788
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Something"):
        time.sleep(1)


# run unit test when this script is called
if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:47:22.557507
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress() as wp:
        import time
        time.sleep(2.0)
    assert wp is None


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:47:31.402270
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            time.sleep(1)
            return pickle.load(f)
    
    obj = load_file("/path/to/some/file")
    time.sleep(2)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            time.sleep(1)
            pickle.dump(obj, f)
    
    time.sleep(2)

# Generated at 2022-06-23 17:47:37.785448
# Unit test for function work_in_progress
def test_work_in_progress():
    # with statement
    time.sleep(1)
    with work_in_progress("Saving file"):
        time.sleep(2)
    # closure decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")


# Generated at 2022-06-23 17:47:40.499002
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Unit test"
    begin_time = time.time()

# Generated at 2022-06-23 17:47:49.856728
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_obj(obj, path):
        with open(path, "wb") as f:
            return pickle.dump(obj, f)

    obj = load_file("__init__.py")
    save_obj(obj, "test_work_in_progress")
    os.remove("test_work_in_progress")

# Run test when invoked
if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:47:57.328171
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/Users/hunor/Documents/GitHub/PyUtilities/pyutilities/__init__.py")

    with work_in_progress("Saving file"):
        with open("/Users/hunor/Documents/GitHub/PyUtilities/pyutilities/__init__2.py", "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:48:05.554852
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    # Run the unit test
    test_work_in_progress()

# Generated at 2022-06-23 17:48:12.783998
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import time

    with tempfile.NamedTemporaryFile(mode="wb") as f:
        @work_in_progress("Saving file")
        def save_data():
            with open(f.name, "wb") as f:
                pickle.dump(data, f)

        data = "Some random string"

        def untimed_save():
            with open(f.name, "wb") as f:
                pickle.dump(data, f)

        time.sleep(0.3)
        # a time-consuming task
        save_data()

        time.sleep(0.3)
        # saving without timing
        untimed_save()
        time.sleep(0.3)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:48:21.354320
# Unit test for function work_in_progress
def test_work_in_progress():
    import subprocess
    import os

    non_existent_file_path = os.path.join(os.environ["HOME"], "non-existent-file")

    def _test(cmd, expected_output):
        output = subprocess.run(["bash", "-c", cmd], capture_output=True, text=True).stdout
        assert expected_output in output

    _test(f"with work_in_progress; do sleep 2; done", "done. (2.00s)")
    _test(f"with work_in_progress 'Calculating Pi'; do sleep 2; done", "Calculating Pi... done. (2.00s)")

# Generated at 2022-06-23 17:48:23.568994
# Unit test for function work_in_progress
def test_work_in_progress():
    print(work_in_progress)



# Generated at 2022-06-23 17:48:27.844110
# Unit test for function work_in_progress
def test_work_in_progress():
    def _foo():
        time.sleep(0.1)
        return 100

    with work_in_progress("Executing foo"):
        print(_foo())


if __name__ == "__main__":
    """Run the unit test for ``work_in_progress`` function."""
    test_work_in_progress()

# Generated at 2022-06-23 17:48:30.372402
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    with work_in_progress("Random simulation"):
        time.sleep(random.uniform(0, 5))


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:48:32.658816
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Dummy work"):
        time.sleep(1)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:48:37.629216
# Unit test for function work_in_progress
def test_work_in_progress():
    import random

    @work_in_progress("Generating random number")
    def random_number():
        r = random.randint(1, 10**9)
        time.sleep(1)
        return r

    r = random_number()
    assert 1 <= r < 10**9

    with work_in_progress("Testing work_in_progress"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:48:43.932511
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:48:49.760125
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    return load_file


if __name__ == '__main__':
    # Output
    test_work_in_progress()()
    """
    Loading file... done. (3.52s)
    """

# Generated at 2022-06-23 17:48:54.850730
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test function")
    def foo():
        time.sleep(0.1)

    # Testing context manager
    with work_in_progress("Test context"):
        time.sleep(0.1)

    # Testing function
    foo()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:00.646680
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test the function :func:`work_in_progress`."""
    # should not raise error
    with work_in_progress("Nothing"):
        pass
    with work_in_progress("Sleeping for a second"):
        time.sleep(1)
    print("Work in progress successfully tested.")


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:49:09.212456
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    load_file("../tests/tests_files/test_object.pkl")

    with work_in_progress("Saving file"):
        with open("../tests/tests_files/test_object_working.pkl", "wb") as f:
            pickle.dump({'a': 1}, f)



# Execute Unit-tests if file called as main
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:16.208056
# Unit test for function work_in_progress
def test_work_in_progress():
    from io import StringIO

    saved_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out
        with work_in_progress("Saving file"):
            time.sleep(0.5)
        assert "Saving file... done. (0.50s)" == out.getvalue()[:-1]
    finally:
        sys.stdout = saved_stdout
    print("test_work_in_progress() passed")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:23.123818
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    from .test import (
        assert_exception,
    )

    def func_with_wip(desc):
        with work_in_progress(desc):
            time.sleep(0.1)

    assert_exception("Exception not raised", TypeError, func_with_wip, None)

    def func_with_time_consumed(desc):
        with work_in_progress(desc) as context:
            time.sleep(0.1)
            return context.time_consumed

    assert (
        0.1 - func_with_time_consumed("Testing time consumed") < 0.01
    )

# Generated at 2022-06-23 17:49:26.015006
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Doing something")
    def do_work():
        time.sleep(1)
        return "done"

    assert do_work() == "done"

# Generated at 2022-06-23 17:49:35.566830
# Unit test for function work_in_progress
def test_work_in_progress():
    from pprint import pprint
    @work_in_progress("Testing work_in_progress")
    def do_something():
        time.sleep(2)
        return {
            "message": "Hello world",
            "nums": range(10),
        }
    result = do_something()
    assert result.get("message") == "Hello world"
    assert result.get("nums") == list(range(10))
    with work_in_progress("Testing work_in_progress with context manager") as context_manager:
        time.sleep(1)
        result = {
            "message": "Hello world",
            "nums": range(10),
        }
        context_manager.result = result
    assert context_manager.result.get("message") == "Hello world"
    assert context_manager.result.get

# Generated at 2022-06-23 17:49:42.867806
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress."""
    from os.path import exists, join
    from os import remove
    from pickle import dump, load
    from numpy import random, zeros

    # Create a test data file
    path_test_data = "testdata.pkl"
    if exists(path_test_data):
        remove(path_test_data)
    with work_in_progress("Generating test data"):
        test_data = random.standard_normal((2, 3))
        with open(path_test_data, "wb") as f:
            dump(test_data, f)
    assert exists(path_test_data)

    # Load data file

# Generated at 2022-06-23 17:49:48.945252
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with open("temporary_test_file", "wb") as f:
        pickle.dump({"test" : 1}, f)

    obj = load_file("temporary_test_file")
    assert obj == {"test" : 1}
    os.remove("temporary_test_file")

# Generated at 2022-06-23 17:49:55.974326
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1)

# %%

from contextlib import contextmanager
from typing import TYPE_CHECKING, List, Optional, Union
from urllib.parse import quote_plus
from .registry import Registry

if TYPE_CHECKING:
    from .config import Config
    from .data.source import DataSource



# Generated at 2022-06-23 17:49:57.889709
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(0.1)
    with work_in_progress("Sleeping"):
        time.sleep(1)
    assert True

# Generated at 2022-06-23 17:50:02.824732
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    load_file(__file__)
    assert True

    with work_in_progress("Saving file"):
        with open(__file__, "wb") as f:
            pickle.dump(__file__, f)
    assert True

# Generated at 2022-06-23 17:50:11.230716
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Executing unit test for work_in_progress"):
        with open("../README.md", "rb") as f:
            print(f.read()[:100])
            f.seek(0)
            print(f.read()[:100])
            f.seek(0)
            print(f.read()[:100])
            f.seek(0)
            print(f.read()[:100])
            f.seek(0)
            print(f.read()[:100])



# Generated at 2022-06-23 17:50:15.512917
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    with work_in_progress("Loading file"):
        time.sleep(2)
    with work_in_progress("Loading file"):
        time.sleep(3)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:50:17.871744
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def func():
        time.sleep(3.14159)

    func()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:50:19.877930
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Work in progress") as foo:
        time.sleep(0.1)
    assert True

# Generated at 2022-06-23 17:50:26.684972
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
        
    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:50:29.548413
# Unit test for function work_in_progress
def test_work_in_progress():
    counter = 0
    for i in range(10):
        with work_in_progress("Loading file"):
            counter += 1
            time.sleep(1)
    assert counter == 10

# Generated at 2022-06-23 17:50:32.932655
# Unit test for function work_in_progress
def test_work_in_progress():
    def test_function(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Loading file"):
        obj = test_function("/path/to/some/file")

# Generated at 2022-06-23 17:50:36.337569
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test the function :py:func:`work_in_progress`.
    """
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    assert load_file("/dev/null") is None

# Generated at 2022-06-23 17:50:40.268962
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("A"):
        time.sleep(1)
    # A... done. (1.00s)

    with work_in_progress("B"):
        time.sleep(1)
    # B... done. (1.00s)



# Generated at 2022-06-23 17:50:45.419172
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Loading file"
    with work_in_progress(desc):
        time.sleep(1)
    print()
    with work_in_progress():
        time.sleep(0.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:50:50.313866
# Unit test for function work_in_progress
def test_work_in_progress():
    import os

    with work_in_progress():
        time.sleep(1)

    with work_in_progress("I'm sleepy"):
        time.sleep(1)

    @work_in_progress()
    def foo():
        time.sleep(1)
        return 10

    assert foo() == 10

# Generated at 2022-06-23 17:50:56.520375
# Unit test for function work_in_progress
def test_work_in_progress():  # noqa: D103
    r"""Unit test for function work_in_progress."""

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert True

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    assert True

# Generated at 2022-06-23 17:51:04.089534
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        save_file("/path/to/some/file", obj)

# Generated at 2022-06-23 17:51:10.579489
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3.5)
    time.sleep(0.2)
    @work_in_progress("Saving file")
    def save_file(obj, path):
        time.sleep(3.8)
    save_file(None, "/path/to/some/file")
    print("All done.")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:19.708111
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    path = "/tmp/test.pickle"
    if os.path.exists(path):
        os.remove(path)

    obj = parse_args(
        ["--checkpoint", "tensorflow/python/training/checkpoint_state_pb2.py",
         "--output", path,
         "--save-codec", "msgpack"])
    load_file(path)
    save_file(path)


# Generated at 2022-06-23 17:51:31.107324
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(3.52)
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path):
        time.sleep(3.78)
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with open("./tmp/file.pkl", "wb") as f:
        pickle.dump([1, 2, 3, 4], f)

    try:
        obj = load_file("./tmp/file.pkl")
    except FileNotFoundError:
        print("File not found!")


# Generated at 2022-06-23 17:51:32.624900
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1.5)


# Generated at 2022-06-23 17:51:41.466186
# Unit test for function work_in_progress
def test_work_in_progress():
    from io import BytesIO
    from random import randint, seed
    from gzip import GzipFile

    with work_in_progress("Compressing data"):
        compressed_data = GzipFile(fileobj=BytesIO()).compress(b"Hello world!")

    def compress_data(s):
        with work_in_progress("Compressing data"):
            return GzipFile(fileobj=BytesIO()).compress(s)

    seed(0)
    compressed_data = compress_data(b"".join(chr(randint(0, 255)) for i in range(1000000)))



# Generated at 2022-06-23 17:51:50.071097
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("test/test_user.pickle")
    assert obj["name"] == "tests"

    with work_in_progress("Saving file"):
        with open("test/test_user.pickle", "wb") as f:
            pickle.dump({
                "name": "tests",
                "full_name": "Test Users",
                "avatar_url": "https://avatars0.githubusercontent.com/" \
                "u/3075245?v=4",
            }, f)

# Generated at 2022-06-23 17:51:55.545587
# Unit test for function work_in_progress
def test_work_in_progress():
    """Generate unit test for function work_in_progress."""
    @work_in_progress()
    def random_sleep(t):
        """Sleep for t seconds."""
        time.sleep(t)
    random_sleep(1)
    random_sleep(0.1)

if __name__ == '__main__':
    # Unit test for function work_in_progress
    test_work_in_progress()

# Generated at 2022-06-23 17:52:00.269017
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Timing unit test"
    with work_in_progress(desc):
        time.sleep(0.01)
    print("Checking if the print is correct")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:09.840303
# Unit test for function work_in_progress
def test_work_in_progress():
    # For testing purposes, we replace the print function.

    # We store the original print function
    original_print = __builtins__.print

    # The mock print function will store the printed message in a list.
    printed = []

    def mock_print(msg, end='\n', flush=False):
        printed.append(msg)

    # We replace the original print function with the mock version.
    __builtins__.print = mock_print

    # Testing code
    with work_in_progress("Loading file") as nop:
        time.sleep(.5)

    assert(printed == ["Loading file... ", "done. (0.50s)"])

    # We set the printed message to an empty list.
    printed[:] = []

    with work_in_progress("Loading file") as nop:
        pass

   

# Generated at 2022-06-23 17:52:11.885825
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test function work_in_progress."""
    with work_in_progress("Loading file"):
        time.sleep(3)

# Generated at 2022-06-23 17:52:15.031768
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("This is a simple function")
    def func():
        pass

    func()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:20.693318
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")
    assert obj is not None
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:26.031019
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("A work in progress"):
        time.sleep(0.2)
    with work_in_progress("A work in progress"):
        time.sleep(0.1)
    with work_in_progress("A work in progress"):
        time.sleep(0.3)


# Generated at 2022-06-23 17:52:34.997944
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    load_file("__init__.py")
    save_file("__init__.pkl", {"a": 2})


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:36.404426
# Unit test for function work_in_progress
def test_work_in_progress():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-23 17:52:40.222546
# Unit test for function work_in_progress
def test_work_in_progress():
    def fn1():
        with work_in_progress("Loading file"):
            time.sleep(1)

    def fn2():
        def load_file(path):
            with work_in_progress("Loading file"):
                time.sleep(1)
        load_file(__file__)

    fn1()
    fn2()

# Generated at 2022-06-23 17:52:47.038212
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    print(load_file("/path/to/some/file"))

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump("Hello, world!", f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:50.508319
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)
        time.sleep(3.78)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:52:54.889629
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path: str):
        with open(path, "rb") as f:
            return pickle.load(f)

    time.sleep(0.5)
    obj = load_file(__file__)
    assert isinstance(obj, Program)

    with work_in_progress("Saving file"):
        with open("/tmp/tmp.test", "wb") as f:
            pickle.dump(obj, f)

    os.remove("/tmp/tmp.test")

# Generated at 2022-06-23 17:52:58.603822
# Unit test for function work_in_progress
def test_work_in_progress():
    time_consumed = 0
    for desc in ["Loading file", "Saving file"]:
        with work_in_progress(desc):
            time.sleep(1)
            time_consumed += 1
        assert abs(time_consumed - time.time()) < 1

# Generated at 2022-06-23 17:53:06.214740
# Unit test for function work_in_progress
def test_work_in_progress():
    # With a function
    def my_func(foo):
        time.sleep(3)
        return foo

    @work_in_progress("My func")
    def my_wrapper(foo):
        return my_func(foo)

    ret = my_wrapper(1)
    # My func... done. (3.01s)

    # With a code block
    with work_in_progress("Code block"):
        time.sleep(3)
    # Code block... done. (3.00s)