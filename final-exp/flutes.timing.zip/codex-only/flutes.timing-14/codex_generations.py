

# Generated at 2022-06-23 17:43:10.751841
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            time.sleep(0.1)
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            time.sleep(0.1)
            pickle.dump(obj, f)


if __name__ == "__main__":
    @work_in_progress("Working...")
    def f():
        time.sleep(0.1)

    f()

# Generated at 2022-06-23 17:43:15.969039
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test for work_in_progress")
    def func(n):
        for i in range(n):
            pass

    func(100000)


if __name__ == "__main__":
    import sys
    import doctest
    doctest.testmod()

    if "--test" in sys.argv:
        test_work_in_progress()

# Generated at 2022-06-23 17:43:20.224084
# Unit test for function work_in_progress
def test_work_in_progress():
    # Within a function
    @work_in_progress("In a function")
    def slow_function():
        time.sleep(1)
    slow_function()

    # Within a context manager
    with work_in_progress("In a context manager"):
        time.sleep(1)

# Generated at 2022-06-23 17:43:29.963918
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file_with_decorator(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    obj = load_file_with_decorator("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:43:42.500764
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress."""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    # Create a file
    path = "./temp.pkl"
    obj = None
    with work_in_progress("Creating file"):
        save_file(path, obj)

    # Load file and test the correctness
    assert load_file(path) == obj

    # Remove the file
    with work_in_progress("Removing file"):
        os.remove(path)


# Generated at 2022-06-23 17:43:44.735607
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("test")
    def f():
        time.sleep(2)
    f()
    with work_in_progress("test"):
        time.sleep(2)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:43:54.186002
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import subprocess as sp
    import sys
    import pickle
    import numpy as np

    def run_code(code):
        with tempfile.NamedTemporaryFile(mode="w+") as f:
            f.write(code)
            f.flush()
            sp.run([sys.executable, f.name])

    obj = np.random.rand(100, 100)
    obj_serialized = pickle.dumps(obj)


# Generated at 2022-06-23 17:43:59.735923
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Testing work_in_progress..."
    with work_in_progress(desc):
        print("in progress...")
        time.sleep(1)
        print("...still in progress...")
        time.sleep(2)
    print("Done.")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:44:04.128589
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:44:11.643826
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("../tests/data/jubilee.pkl")
    with work_in_progress("Saving file"):
        with open("/tmp/jubilee.pkl", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:44:23.003069
# Unit test for function work_in_progress
def test_work_in_progress():
    from pathlib import Path
    from tempfile import mkdtemp
    from shutil import rmtree
    from json import dump

    # Utility function to generate a file with a specified size
    def gen_file(file, size: int = 1024*1024):
        file.touch()
        for _ in range(size):
            file.write_bytes(bytes([(i % 10) + 97 for i in range(10)]))

    # Create a temporary directory
    with Path(mkdtemp()) as tmpdir:

        # Create a file
        with tmpdir.joinpath("file.txt") as file:
            gen_file(file)

            # Test efficiency of cp command with work_in_progress

# Generated at 2022-06-23 17:44:31.406300
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import pickle
    import random
    import shutil
    import tempfile

    assert os.path.exists("some_file"), "Make some_file exist before running unit test"
    with work_in_progress("Loading file"):
        with open("some_file", "rb") as f:
            some_data = pickle.load(f)

    with tempfile.TemporaryDirectory() as td:
        with work_in_progress("Saving file"):
            with open(os.path.join(td, "some_file"), "wb") as f:
                pickle.dump(some_data, f)

    def random_work(data):
        with work_in_progress("Random work"):
            random.shuffle(data)


# Generated at 2022-06-23 17:44:40.744419
# Unit test for function work_in_progress
def test_work_in_progress():
    import os

    # Create a temporary directory
    tmp_dir = os.path.abspath("./_tmp")
    os.makedirs(tmp_dir, exist_ok=True)

    # Function to test
    @work_in_progress("Test 1")
    def test1():
        time.sleep(1.5)

    # Function to test
    def test2():
        time.sleep(0.3)

    # Test the function
    with work_in_progress("Test 2"):
        test2()

    # Test the function
    test1()

# If the script is run directly...
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:44:44.526294
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Generating list"):
        a = list(range(int(1e6)))
    print()
    with work_in_progress("Creating dictionary"):
        a_dict = {i: i for i in range(int(1e6))}

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:44:48.094632
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file():
        time.sleep(0.1)
        return {}

    assert load_file() == {}

# Generated at 2022-06-23 17:44:52.284104
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Waiting")
    def wait(ms):
        time.sleep(ms / 1000)

    wait(2300)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:44:56.544277
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Working hard")
    def run():
        time.sleep(.5)
    run()


if __name__ == "__main__":
    print(f"{__file__}: unit test: start")
    test_work_in_progress()
    print(f"{__file__}: unit test: end")

# Generated at 2022-06-23 17:45:00.505112
# Unit test for function work_in_progress
def test_work_in_progress():
    print("==> Unit testing function work_in_progress")
    with work_in_progress("Work in progress"):
        time.sleep(1)


# Generated at 2022-06-23 17:45:05.589845
# Unit test for function work_in_progress
def test_work_in_progress():
    def dummy_func(task_name: str = "Dummy task",
                   sleep: float = 0.5):
        """Dummy function for testing work_in_progress."""
        with work_in_progress(task_name):
            time.sleep(sleep)


    for i in range(5):
        dummy_func()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:45:16.477663
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit testing for function work_in_progress"""

    import random
    import pylint_helper  # pylint: disable=import-error  # Pylint is wrong here

    with work_in_progress("Generating random list"):
        lst = []
        for _ in range(1000000):
            lst.append(random.normalvariate(mu=0, sigma=1))
    assert isinstance(lst, list)

    for x in lst:
        assert isinstance(x, float)

    @work_in_progress("Loading pickle file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("tests/data/magicdata.pkl")

# Generated at 2022-06-23 17:45:19.936794
# Unit test for function work_in_progress
def test_work_in_progress():
    k = 0
    for i in range(100000):
        k += i ** 2 + 3 ** (i / 2) % 3
    print(k)


# Generated at 2022-06-23 17:45:23.692198
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file") as prog:
        for i in range(100):
            time.sleep(0.1)
            prog.update(i)

if __name__ == "__main__":
    test_work_in_progress()


# Standard Library
import contextlib
import multiprocessing

__all__ = [
    "MultiprocessRunner",
]



# Generated at 2022-06-23 17:45:28.737062
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Counting to 10000000"):
        for i in range(10000000):
            pass
    print("The number is %d" % i)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:45:34.801418
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import time

    random.seed(0)
    with work_in_progress("Testing work_in_progress function"):
        time.sleep(0.5)

    @work_in_progress()
    def do_nothing():
        time.sleep(0.5)

    do_nothing()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:45:42.699274
# Unit test for function work_in_progress
def test_work_in_progress():
    import unittest

    class TestWorkInProgress(unittest.TestCase):

        @work_in_progress("Loading file")
        def load_file(self, path):
            with open(path, "rb") as f:
                return pickle.load(f)

        def test_function_decorator(self):
            obj = self.load_file("/path/to/some/file")
            self.assertEqual(type(obj), str)

        def test_context_manager(self):
            with work_in_progress("Saving file"):
                with open(path, "wb") as f:
                    pickle.dump(obj, f)

    unittest.main(verbosity=2)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:45:46.177048
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1.234)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

# Generated at 2022-06-23 17:45:55.512834
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with open("test.pkl", "wb") as f:
        pickle.dump(list(range(10000000)), f)

    obj = load_file("test.pkl")

    time.sleep(1)

    with work_in_progress("Saving file"):
        with open("test.pkl", "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:46:03.350663
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("./test_data/file.pickle")
    assert obj == 123

    with work_in_progress("Saving file"):
        with open("./test_data/file.pickle", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:46:05.287378
# Unit test for function work_in_progress
def test_work_in_progress():
    def foo():
        time.sleep(1.2)

    with work_in_progress("Some testing"):
        foo()

# Generated at 2022-06-23 17:46:13.356748
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("test.pkl")
    save_file("test.pkl", obj)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:46:16.248654
# Unit test for function work_in_progress
def test_work_in_progress():
    # pylint: disable=eval-used

    def generator():
        yield None
        yield None

    def test_with_generator():
        with work_in_progress("Testing generator"):
            for _ in generator():
                pass

    test_with_generator()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:46:23.233426
# Unit test for function work_in_progress
def test_work_in_progress():
    from pickle import load, dump

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            dump(obj, f)

    path = __file__
    obj = load_file(path)
    save_file(obj, path)

# Generated at 2022-06-23 17:46:25.994453
# Unit test for function work_in_progress
def test_work_in_progress():
    def foo():
        time.sleep(0.5)

    with work_in_progress("Sleeping"):
        foo()


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:46:32.832482
# Unit test for function work_in_progress
def test_work_in_progress():
    for name, f in dict(
            manager=work_in_progress,
            decorator=load_file,
    ).items():
        with f("Loading file"):
            pass
        print(f"Test {name} pass")



# Generated at 2022-06-23 17:46:44.116013
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    Unit test for function work_in_progress
    """
    import pickle

    def load_file(path):
        """
        A dummy function for loading file
        """
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path):
        """
        A dummy function for saving file
        """
        with open(path, "wb") as f:
            pickle.dump([2, 3, 4], f)

    with work_in_progress("Loading file"):
        load_file("test_file")

    @work_in_progress("Saving file")
    def save_file_decorator():
        save_file("test_file")

    save_file_decorator()

# Generated at 2022-06-23 17:46:50.844205
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Sorting numbers")
    def sort_numbers(numbers: list) -> list:
        time.sleep(0.1)
        return sorted(numbers)

    assert sort_numbers([5, 3, 2, 1, 4]) == [1, 2, 3, 4, 5]


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:47:00.942715
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile
    from datetime import datetime, timedelta

    def test_load_file(path):
        load_file(path)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            obj = pickle.load(f)
        # Consume time, like loading a file.
        time.sleep(0.5)
        return obj

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
        # Consume time, like saving a file.
        time.sleep(0.5)

    # Work in progress in a with block

# Generated at 2022-06-23 17:47:03.077216
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing"):
        time.sleep(0.3)

# Generated at 2022-06-23 17:47:09.293577
# Unit test for function work_in_progress
def test_work_in_progress():
    class Foo:
        pass

    with work_in_progress("Test"):
        obj = Foo()
        for _ in range(10000):
            obj.append("test")
    print("==========================")

    @work_in_progress("Test")
    def test():
        obj = Foo()
        for _ in range(10000):
            obj.append("test")

    test()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:47:11.348305
# Unit test for function work_in_progress
def test_work_in_progress():
    import doctest
    doctest.testmod(globs={'work_in_progress': work_in_progress})

# Generated at 2022-06-23 17:47:13.336775
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Test")
    def do_work():
        time.sleep(10)

    do_work()

# Generated at 2022-06-23 17:47:19.577464
# Unit test for function work_in_progress
def test_work_in_progress():
    import random

    def randomizer():
        # does nothing, just randomize CPU usage
        a = random.random()
        return a

    with work_in_progress("Randomizing all the things"):
        for _ in range(10_000):
            randomizer()


# Run the unit test
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:47:22.743324
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Unit test"
    expected = "Unit test... done. (0.00s)\n"
    with mock.patch("sys.stdout", new=io.StringIO()) as fake_stdout:
        with work_in_progress(desc):
            pass
        assert fake_stdout.getvalue() == expected

# Generated at 2022-06-23 17:47:27.441719
# Unit test for function work_in_progress
def test_work_in_progress():

    with work_in_progress("Loading file"):
        time.sleep(.5)

    @work_in_progress("Loading file")
    def test():
        time.sleep(.5)

    test()

# Generated at 2022-06-23 17:47:34.512521
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile

    tempdir = tempfile.TemporaryDirectory()
    path = os.path.join(tempdir.name, "test_file")

    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(0.1)
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file(path)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:47:36.299790
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test Work in progress"):
        time.sleep(1.2)

# Generated at 2022-06-23 17:47:38.648087
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sleeping"):
        time.sleep(0.1)
    with work_in_progress("Sleeping"):
        time.sleep(1)

# Generated at 2022-06-23 17:47:42.612517
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(1)
    with work_in_progress("Loading file"):
        time.sleep(3.5)

# Generated at 2022-06-23 17:47:45.643144
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(1.0)
    assert True


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:47:47.692932
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Function under test"):
        time.sleep(1)

# Generated at 2022-06-23 17:47:56.599332
# Unit test for function work_in_progress
def test_work_in_progress():
    # noinspection PyUnusedLocal
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # noinspection PyUnusedLocal
    def save_file(path):
        with work_in_progress("Saving file"):
            with open(path, "wb") as f:
                pickle.dump(time.time(), f)

    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, "file.pkl")
        save_file(path)
        load_file(path)



# Generated at 2022-06-23 17:48:05.181424
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import pathlib
    import random
    import string
    import pickle

    with tempfile.TemporaryDirectory() as temp_dir:
        temp_dir = pathlib.Path(temp_dir)
        path = temp_dir / "tmp.pickle"

        @work_in_progress("Loading file")
        def load_file(path):
            with open(path, "rb") as f:
                return pickle.load(f)

        @work_in_progress("Saving file")
        def save_file(obj, path):
            with open(path, "wb") as f:
                return pickle.dump(obj, f)

        def random_str(length):
            return "".join(random.choices(string.ascii_lowercase, k=length))

        obj = random_

# Generated at 2022-06-23 17:48:09.943231
# Unit test for function work_in_progress
def test_work_in_progress():
    begin_time = time.time()
    success = True
    with work_in_progress("Testing function work_in_progress()"):
        try:
            time.sleep(1)
            assert time.time() - begin_time >= 1, "Function work_in_progress() is run at least 1 second."
        except Exception as e:
            print(e)
            success = False
    print()
    return success

# Generated at 2022-06-23 17:48:15.846585
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(0.3)
    desc = "Loading file"
    with work_in_progress(desc):
        time.sleep(0.1)
        with open("work_in_progress.py", "rb") as f:
            f.read()
        time.sleep(0.2)
    assert True

# Generated at 2022-06-23 17:48:19.665986
# Unit test for function work_in_progress
def test_work_in_progress():
    begin_time = time.time()
    with work_in_progress("Please wait"):
        time.sleep(1)
    time_consumed = time.time() - begin_time
    assert time_consumed > 1
    assert time_consumed < 1.1

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:48:27.849548
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:48:30.367900
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Time consuming task!!!"):
        time.sleep(0.5)
    with work_in_progress("Time consuming task!!!"):
        time.sleep(2)

# Generated at 2022-06-23 17:48:36.531335
# Unit test for function work_in_progress
def test_work_in_progress():

    class DummyClass:
        def __init__(self):
            self.num = 1

        @work_in_progress()
        def calculate(self, a, b):
            return (a + b) / self.num

        @work_in_progress("Doing something")
        def complex_calculation(self, a, b, c):
            time.sleep(1)
            return a + b + c

    dc = DummyClass()

    assert dc.calculate(1, 2) == 3
    assert dc.complex_calculation(1, 2, 3) == 6


if __name__ == "__main__":
    test_work_in_progress()
    print("All tests pass!")

# Generated at 2022-06-23 17:48:39.299852
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Working..."):
        time.sleep(1.2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:48:44.796917
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Executing unit tests")
    def func():
        print("Hello, World!")
        time.sleep(1)
        print("This is a test ... ")
        time.sleep(1)

    func()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:48:55.761039
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import pickle

    # Unit test 1: pickle loading
    @work_in_progress("Loading pickle data")
    def load_pickle(path: str):
        with open(path, "rb") as f:
            return pickle.load(f)

    # Unit test 2: pickle saving
    @work_in_progress("Saving pickle data")
    def save_pickle(obj, path: str):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    # Clean up previous testing stuff
    try:
        os.remove("./data/test.pkl")
    except FileNotFoundError:
        pass

    # Prepare test data
    data = dict()
    data["string"] = "Hello world!"
    data["number"] = 2019

# Generated at 2022-06-23 17:48:58.768476
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Loading file"):
        load_file("/path/to/file")

# Generated at 2022-06-23 17:49:01.371996
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(1)

    with work_in_progress("Test"):
        pass

# Generated at 2022-06-23 17:49:03.136818
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Some work"):
        time.sleep(0.5)

# Generated at 2022-06-23 17:49:06.167710
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Working"):
        time.sleep(1)
    time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:08.657760
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        pass
    assert True


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:13.246550
# Unit test for function work_in_progress
def test_work_in_progress():
    # Testing with a code block
    with work_in_progress("Saving file"):
        time.sleep(1.23)
    # Testing with a function
    @work_in_progress("Printing something")
    def print_something():
        time.sleep(0.56)
    print_something()

# Generated at 2022-06-23 17:49:20.208321
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress(desc="Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress(desc="Saving file"):
        with open(path, 'wb') as f:
            pickle.dump(obj, f)

# TODO:
# 1. test for type
# 2. test for equality
# 3. test for raise error:
# with pytest.raises(AttributeError):

# Generated at 2022-06-23 17:49:31.233726
# Unit test for function work_in_progress
def test_work_in_progress():
    class MockFile(object):
        def __init__(self):
            self.called = False
            self.content = b""

        def __enter__(self):
            self.called = True
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            pass

        def write(self, content):
            self.content += content

    with MockIO() as mock_io:
        with work_in_progress("Loading file"):
            time.sleep(0.1)

        assert mock_io.getvalue() == "Loading file... done. (0.10s)\n"

        mock_io.reset()
        with work_in_progress("Saving file"):
            mock_f = MockFile()
            assert mock_f.called

        assert mock_io.getvalue

# Generated at 2022-06-23 17:49:36.381051
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(3)
        with open(path, "r") as f:
            return f.read()

    obj = load_file("CONTRIBUTING.md")
    assert obj

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:38.532243
# Unit test for function work_in_progress
def test_work_in_progress():
    import subprocess

    with work_in_progress("Running unit tests"):
        assert subprocess.run(["python", "-m", "unittest", f"{__file__}"])

# Generated at 2022-06-23 17:49:40.238115
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Work in progress"
    progress = work_in_progress(desc)
    progress.__enter__()
    progress.__exit__(None, None, None)

# Generated at 2022-06-23 17:49:43.810006
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.34)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:45.219433
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(1)
    with work_in_progress("Loading file"):
        time.sleep(0.5)

# Generated at 2022-06-23 17:49:55.728103
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file(__file__)
    assert obj.split("\n")[:2] == [
        "import pickle",
        "import contextlib",
    ]

    with work_in_progress("Saving file"):
        with open("wip_test.tmp", "wb") as f:
            pickle.dump(obj, f)
    with open("wip_test.tmp", "rb") as f:
        obj_ = pickle.load(f)
    assert obj_ == obj

# Generated at 2022-06-23 17:50:00.494194
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:50:07.422466
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function work_in_progress.
    
    Do not call this directly.
    """
    # TODO: support non-detach mode
    # TODO: support non-verbose mode

    class TempDir:
        def __enter__(self):
            self.path = tempfile.mkdtemp()
            return self.path
        def __exit__(self, *args):
            shutil.rmtree(self.path)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)


# Generated at 2022-06-23 17:50:11.865555
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    # Loading file... done. (3.52s)

# Generated at 2022-06-23 17:50:18.664938
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import os
    import random
    import numpy as np

    filename = "tmp_dump"
    # Create random ndarray of size 10 x 10
    obj = np.random.randn(10, 10)
    with open(filename, "wb") as f:
        with work_in_progress("Saving file"):
            pickle.dump(obj, f)
    with open(filename, "rb") as f:
        with work_in_progress("Loading file"):
            obj_back = pickle.load(f)
    assert np.allclose(obj, obj_back)
    os.remove(filename)

# Generated at 2022-06-23 17:50:23.836767
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    with work_in_progress("Saving file"):
        time.sleep(2)

if __name__ == "__main__":
    work_in_progress()
    work_in_progress("Loading file")
    work_in_progress("Saving file")

# Generated at 2022-06-23 17:50:25.567366
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(2)

# Generated at 2022-06-23 17:50:35.751437
# Unit test for function work_in_progress
def test_work_in_progress():
    from tqdm.auto import trange

    # Test with function
    @work_in_progress("Test work_in_progress with function")
    def func():
        time.sleep(2)
        return 1

    assert func() == 1

    # Test with context manager
    with work_in_progress("Test work_in_progress with context manager"):
        for i in trange(10000000):
            pass


if __name__ == '__main__':
    # Test
    test_work_in_progress()

    # Benchmark
    from tqdm.auto import trange
    from tqdm import tqdm
    import time

    n = 100000

    # Work in progress

# Generated at 2022-06-23 17:50:41.744200
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    assert obj is not None

# Generated at 2022-06-23 17:50:43.738415
# Unit test for function work_in_progress
def test_work_in_progress():
    print(__doc__)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:50:50.850338
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Performing some heavy task"
    # Test context manager
    with work_in_progress(desc) as timed:
        time.sleep(0.5)
    # Test decorator
    @work_in_progress(desc)
    def heavy_task():
        time.sleep(0.5)
    @work_in_progress
    def heavy_task_2():
        time.sleep(0.5)
    heavy_task()
    heavy_task_2()

# Generated at 2022-06-23 17:50:52.352766
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work in progress"):
        time.sleep(0.9)

# Generated at 2022-06-23 17:50:56.557749
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with open("test_data/test.pkl", "wb") as f:
        pickle.dump([1, 2, 3, 4], f)

    obj = load_file("test_data/test.pkl")
    print(obj)

# Generated at 2022-06-23 17:51:02.748159
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def test():
        time.sleep(0.01)
    test()
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.01)

# Test the module
if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:51:06.540855
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def test():
        time.sleep(3.14)
    test()
    with work_in_progress("Testing context manager"):
        time.sleep(3.14)


# Generated at 2022-06-23 17:51:12.539517
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:51:15.103003
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Work in progress"):
        time.sleep(0.1)

if __name__ == "__main__":

    test_work_in_progress()

# Generated at 2022-06-23 17:51:21.746676
# Unit test for function work_in_progress
def test_work_in_progress():
    begin_time = time.time()
    with work_in_progress("test"):
        time.sleep(0.01)
    end_time = time.time()
    assert end_time - begin_time >= 0.01

    begin_time = time.time()
    with work_in_progress("test 2"):
        time.sleep(0.02)
    end_time = time.time()
    assert end_time - begin_time >= 0.02

# Generated at 2022-06-23 17:51:25.069684
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3.52)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:51:28.548343
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import shutil
    import tempfile

    # Test: @work_in_progress
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # Test: work_in_progress()
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:51:30.440458
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Unit test"):
        time.sleep(1)

# Generated at 2022-06-23 17:51:38.069637
# Unit test for function work_in_progress
def test_work_in_progress():
    fname = "./test.tmp"
    obj = list(range(10000))
    @work_in_progress(desc="loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
        return None
    @work_in_progress(desc="saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    # save and load the file
    save_file(fname)
    ret = load_file(fname)
    assert ret == obj
    # clean up
    os.remove(fname)
    return

# Main function call
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:46.365488
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("task1"):
        time.sleep(0.05)
    with work_in_progress("task2"):
        time.sleep(0.1)
    with work_in_progress("task3"):
        time.sleep(0.3)
    with work_in_progress("task4"):
        time.sleep(0.7)
    with work_in_progress("task5"):
        time.sleep(1)
    with work_in_progress("task6"):
        time.sleep(5)
    with work_in_progress("task7"):
        time.sleep(10)

# Generated at 2022-06-23 17:51:51.773214
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test that the doc string examples work.
    with work_in_progress("Loading file"):
        with open("work_in_progress.py", "rb") as f:
            content = f.read()

    with work_in_progress("Saving file"):
        with open("work_in_progress.py.bak", "wb") as f:
            f.write(content)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:51:54.500838
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(1.0)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:56.430409
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(0.5)

# Generated at 2022-06-23 17:52:06.758431
# Unit test for function work_in_progress

# Generated at 2022-06-23 17:52:13.254561
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        with open("../tests/test_dumps/list.pickle", "rb") as f:
            content = pickle.load(f)
    assert content == ["This", "is", "a", "file", "containing", "a", "list"]
    with work_in_progress("Saving file"):
        with open("../tests/test_dumps/list.pickle", "wb") as f:
            pickle.dump(content, f)



# Generated at 2022-06-23 17:52:15.284463
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("A work in progress"):
        time.sleep(0.1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:19.500794
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Work in progress")
    def load_file(path):
        time.sleep(1)
        return None

    load_file("/path/to/some/file")

    with work_in_progress("Work in progress"):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:23.279050
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress():
        time.sleep(1)

    @work_in_progress("TESTING DECORATOR")
    def test():
        time.sleep(1)

    test()

# Generated at 2022-06-23 17:52:25.404989
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("test")
    def func():
        time.sleep(1)

    func()

# Generated at 2022-06-23 17:52:28.123556
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(1)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:52:30.392475
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def unit_test():
        time.sleep(0.01)

    unit_test()

# Generated at 2022-06-23 17:52:33.561928
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def _test():
        time.sleep(1)

    _test()

# Generated at 2022-06-23 17:52:41.893310
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Saving file")
    def save_file(path, *, flush=True):
        try:
            with open(path, "wb") as f:
                f.write(b"This is just a test file with dummy content.")
        except Exception:
            pass
        if flush:
            os.remove(path)

    path = os.path.abspath("/tmp/__work_in_progress.txt")
    try:
        save_file(path)
        assert not os.path.exists(path)
    finally:
        if os.path.exists(path):
            os.remove(path)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return f.read()

   

# Generated at 2022-06-23 17:52:44.570043
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Trying out"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:47.857728
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test work_in_progress context manager
    with work_in_progress("Context manager"):
        time.sleep(1)
    assert 1

    # Test work_in_progress decorator
    @work_in_progress("Decorator")
    def decorated_func():
        time.sleep(1)

    decorated_func()
    assert 1

# Generated at 2022-06-23 17:52:53.034562
# Unit test for function work_in_progress
def test_work_in_progress():
    def load(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Loading"):
        obj = load("/path/to/some/file/bigger_than/1s")

    with work_in_progress("Saving"):
        with open("/path/to/some/file/bigger_than/1s", "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    # test_work_in_progress()
    pass

# Generated at 2022-06-23 17:53:03.471483
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            return pickle.dump(obj, f)

    data = {chr(x): x for x in range(ord('a'), ord('z') + 1)}
    save_file("test_work_in_progress.pkl", data)
    obj = load_file("test_work_in_progress.pkl")
    assert obj == data


if __name__ == '__main__':
    test_work_in_progress()