

# Generated at 2022-06-23 17:43:12.306450
# Unit test for function work_in_progress
def test_work_in_progress():
    expected_output = "A work in progress... done. (1.00s)\n"

    with mock.patch("builtins.print") as mock_print:
        with mock.patch("time.time") as mock_time:
            mock_time.return_value = 0
            with work_in_progress("A work in progress"):
                mock_time.return_value = 1
            mock_time.assert_has_calls([
                mock.call.return_value,
                mock.call.return_value,
            ])
            mock_print.assert_has_calls([
                mock.call("A work in progress... ", end='', flush=True),
                mock.call("done. (1.00s)"),
            ])

# Generated at 2022-06-23 17:43:23.568593
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress('Loading file')
    def load_file(path):
        time.sleep(2)
        with open(path, 'r') as file:
            return file.read()
    load_file('README.md')
    with work_in_progress('Saving file'):
        time.sleep(3)
        with open('README.md', 'w') as file:
            file.write('This file is created by test_work_in_progress')
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
test_work_in_progress()

# Generated at 2022-06-23 17:43:28.641594
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile
    import shutil
    import numpy as np
    import tempfile
    import time

    t = tempfile.mktemp()
    print(t)
    try:
        with work_in_progress("Testing work_in_progress"):
            with open(t, "w") as f:
                f.write("\n".join(["hello"] * 10000))
    finally:
        os.remove(t)

# Generated at 2022-06-23 17:43:37.478618
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Test work_in_progress():")
    @work_in_progress("Loading file")
    def _load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def _save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    path = "/tmp/test.pkl"
    obj = pickle.load(_load_file(path))
    _save_file(path)

# Generated at 2022-06-23 17:43:44.822050
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert isinstance(obj, type(None))
    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:43:49.506145
# Unit test for function work_in_progress
def test_work_in_progress():
    for desc in ["Loading file", "Saving file"]:
        with work_in_progress(desc):
            time.sleep(1)


# Generated at 2022-06-23 17:43:52.073509
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(2)

    with work_in_progress("Printing numbers"):
        for i in range(10):
            print(i)
            time.sleep(0.1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:44:02.848832
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import pickle

    class Foo:
        pass

    # With context manager
    obj = Foo()
    with tempfile.TemporaryDirectory() as tmp:
        path = tmp + "/foo.pickle"
        with work_in_progress("Saving file"):
            with open(path, "wb") as f:
                pickle.dump(obj, f)
        with work_in_progress("Loading file"):
            with open(path, "rb") as f:
                assert obj == pickle.load(f)

    # As decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)


# Generated at 2022-06-23 17:44:11.143217
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    import tempfile
    temp_file = tempfile.NamedTemporaryFile(delete=False)

    pickle.dump([1, 2, 3], temp_file)
    temp_file.close()

    obj = load_file(temp_file.name)


# Generated at 2022-06-23 17:44:13.361068
# Unit test for function work_in_progress
def test_work_in_progress():
    def _work():
        time.sleep(3.141592)
    with work_in_progress("Sleep"):
        _work()

# Generated at 2022-06-23 17:44:22.732315
# Unit test for function work_in_progress
def test_work_in_progress():
    path = "/tmp/test_work_in_progress.pkl"

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump({'a': 1, 'b': 2}, f)

    obj = load_file(path)
    assert obj == {'a': 1, 'b': 2}
    save_file(path)

    os.remove(path)

# Generated at 2022-06-23 17:44:28.017634
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert obj is not None

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:44:37.906890
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Motor starting")
    def motor_start():
        time.sleep(2)

    @work_in_progress("Motor stopping")
    def motor_stop():
        time.sleep(1)

    test_success = True
    try:
        motor_start()
    except Exception as e:
        test_success = False
    assert test_success

    test_success = True
    try:
        motor_stop()
    except Exception as e:
        test_success = False
    assert test_success


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:44:45.813542
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle, tempfile, random
    import numpy as np

    # Check the work_in_progress decorator.
    @work_in_progress()
    def load_data(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with tempfile.TemporaryDirectory() as tempdir:
        path = tempdir + "/pickled_data.pkl"

        with open(path, "wb") as f:
            pickle.dump(np.random.rand(30000, 30000).astype(np.float32), f)

        print(load_data(path))

    # Check the work_in_progress context manager.

# Generated at 2022-06-23 17:44:54.689199
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for module ``dezero.utils``
    """
    import dezero

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return dezero.pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            dezero.pickle.dump(obj, f)

    path = '/tmp/dezero.test'
    obj = {'x': 1, 'y': 'a'}

    save_file(path, obj)
    obj_ = load_file(path)
    assert obj == obj_, f"Objects are different: {obj}, {obj_}"

# Generated at 2022-06-23 17:45:00.892886
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Work1")
    def work1(x, y):
        time.sleep(x)
        return x + y

    @work_in_progress("Work2")
    def work2(x):
        time.sleep(x)
        return x

    assert work1(1, 2) == 3
    assert work2(1) == 1

# Generated at 2022-06-23 17:45:02.550897
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.5)


# Generated at 2022-06-23 17:45:06.536341
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return f.read()

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            f.write(obj)

# Generated at 2022-06-23 17:45:17.383980
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import os.path as osp
    import tempfile
    import shutil

    tmpdir = tempfile.mkdtemp()

    try:
        @work_in_progress("Loading file")
        def load_file(path):
            with open(path, "rb") as f:
                return pickle.load(f)

        @work_in_progress("Saving file")
        def save_file(path, obj):
            with open(path, "wb") as f:
                pickle.dump(obj, f)

        path = osp.join(tmpdir, "file.pkl")
        save_file(path, [1, 2, 3, 4])
        print(load_file(path))
    finally:
        shutil.rmtree(tmpdir)


# Generated at 2022-06-23 17:45:21.239777
# Unit test for function work_in_progress
def test_work_in_progress():
    from contextlib import redirect_stdout
    from io import StringIO
    with redirect_stdout(StringIO()) as f:
        with work_in_progress("My task"):
            time.sleep(1)
        assert f.getvalue().rstrip() == "My task... done. (1.00s)"

# Generated at 2022-06-23 17:45:26.302835
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("This is a test"):
        time.sleep(0.3)



if __name__ == '__main__':
    x = test_work_in_progress()

# Generated at 2022-06-23 17:45:34.510640
# Unit test for function work_in_progress
def test_work_in_progress():
    path = "/tmp/foo.file"
    obj = {
        "foo": "bar",
        "hello": "world",
        "1": 2,
    }
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    assert load_file(path) == obj

# Generated at 2022-06-23 17:45:40.306072
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile

    # Create a temporary file
    test = tempfile.NamedTemporaryFile(mode="w+")

    # Test the with syntax
    with work_in_progress("Writing to file"):
        test.write("This is a test.")
        test.seek(0)

    # Test the function decorator with a function
    @work_in_progress("Writing to file")
    def write_to_file():
        test.write("This is a test.")
        test.seek(0)

    write_to_file()

# Generated at 2022-06-23 17:45:47.111375
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("tests/data/sentiment_analysis/train_data.pkl")
    save_file(obj, "tests/data/sentiment_analysis/train_data_copy.pkl")

# Generated at 2022-06-23 17:45:53.705644
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile
    import os

    with tempfile.NamedTemporaryFile() as temp:
        with work_in_progress("Saving file"):
            pickle.dump(list(range(1000000)), temp)

        with work_in_progress("Loading file"):
            obj = pickle.load(open(temp.name, "rb"))

        assert obj == list(range(1000000))
        with work_in_progress("Removing file"):
            os.remove(temp.name)

    print("Test complete.")


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:46:04.359616
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    # Create a random object that is non-trivial to serialize/deserialize
    # (in terms of time complexity)
    import random
    import torch
    obj = (torch.tensor(random.randint(0, 100) for _ in range(10000)),)

    # Save and load the object to ensure that the code actually works
    path = "/tmp/work_in_progress_test.data"
    save_

# Generated at 2022-06-23 17:46:13.580468
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    
    path = os.path.join(PATH_TO_DATA, "titanic.pkl")
    with work_in_progress("Loading file"):
        obj = load_file(path)

    path = os.path.join(PATH_TO_DATA, "test.pkl")
    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            return pickle.dump(obj, f)

    save_file(obj, path)

# Generated at 2022-06-23 17:46:16.960555
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file.pkl")

    with work_in_progress("Saving file"):
        with open("/path/to/some/file.pkl", "wb") as f:
            pickle.dump(obj, f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:46:20.765194
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Sleeping for 5 seconds"):
        time.sleep(5)
    with work_in_progress("Sleeping for 5 seconds") as timer:
        time.sleep(5)
        assert(time.time() - timer.begin_time <= 5)
    assert(time.time() - timer.begin_time >= 5)
    assert(timer.time_consumed == timer.time_used)

# Run unit test
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:46:25.514128
# Unit test for function work_in_progress
def test_work_in_progress():
    # test code block
    with work_in_progress("Test code block"):
        time.sleep(1)

    # test function
    @work_in_progress("Test function")
    def test_func():
        time.sleep(1)

    test_func()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:46:28.781873
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

# Generated at 2022-06-23 17:46:34.482915
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)


# Generated at 2022-06-23 17:46:38.969302
# Unit test for function work_in_progress
def test_work_in_progress():

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    @work_in_progress("Loading file")
    def load_file_with_mark(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file_with_mark(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    dict_a = {"a": 1, "b": 2}
    src_path = "tmp_a.pkl"

# Generated at 2022-06-23 17:46:42.467354
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Some random task"
    with work_in_progress(desc) as work:
        time.sleep(0.1)
        assert work == None

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:46:43.722955
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Time until 10 seconds"):
        time.sleep(10)

# Generated at 2022-06-23 17:46:49.055795
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Something important"):
        time.sleep(0.3)
    with work_in_progress("Something more important"):
        time.sleep(0.4)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:46:55.130782
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Task 1")
    def task1():
        time.sleep(1)

    @work_in_progress("Task 2")
    def task2():
        time.sleep(0.5)

    @work_in_progress("Task 3")
    def task3():
        time.sleep(0.75)

    task1()
    task2()
    task3()

# Generated at 2022-06-23 17:46:58.200361
# Unit test for function work_in_progress
def test_work_in_progress():

    def test_function(name):
        with work_in_progress(f"{name}_work"):
            time.sleep(2)

    test_function("test1")
    test_function("test2")

# Generated at 2022-06-23 17:47:00.451619
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing Work In Progress") as w:
        time.sleep(0.01)

# Generated at 2022-06-23 17:47:11.607898
# Unit test for function work_in_progress
def test_work_in_progress():
    from contextlib import redirect_stdout
    import io

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with io.StringIO() as buf, redirect_stdout(buf):
        obj = load_file("test.pickle")
        out = buf.getvalue()
        assert out.strip() == "Loading file... done. (0.00s)"

    with io.StringIO() as buf, redirect_stdout(buf):
        save_file("test.pickle")
        out = buf.get

# Generated at 2022-06-23 17:47:12.923920
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(2)

# Generated at 2022-06-23 17:47:17.550459
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test WIP 1")
    def foo():
        time.sleep(1)

    foo()


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:47:19.848601
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.5)

# Generated at 2022-06-23 17:47:23.549050
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import time

    for sleep_time in [0.5, 1.0, 2.0]:
        with work_in_progress(f"Sleeping for {sleep_time} s"):
            time.sleep(sleep_time)

        @work_in_progress(f"Sleeping for {sleep_time} s")
        def sleep(sleep_time):
            time.sleep(sleep_time)

        sleep(sleep_time)

# Generated at 2022-06-23 17:47:28.497455
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    print("Testing function work_in_progress...")
    with work_in_progress():
        time.sleep(0.7)
    time.sleep(0.1)
    print("Test done.")
    print()

# Generated at 2022-06-23 17:47:33.072801
# Unit test for function work_in_progress
def test_work_in_progress():
    # noinspection PyUnusedLocal
    @work_in_progress()
    def work_in_progress_test1():
        time.sleep(1)

    with work_in_progress():
        time.sleep(1)

# Generated at 2022-06-23 17:47:41.467723
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test the context manager
    with work_in_progress("Saving file"):
        time.sleep(2)
    assert_equal(
        out.getvalue().strip(),
        "Saving file... done. (2.00s)",
    )
    out.truncate(0)

    # Test the decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")
    assert_equal(out.getvalue().strip(), "Loading file... done. (3.52s)")


if __name__ == "__main__":
    import pytest

# Generated at 2022-06-23 17:47:52.784275
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import mock

    with mock.patch("sys.stdout", new=mock.Mock(), create=True) as stdout:
        with mock.patch("time.time", return_value=3.0) as mock_time:
            with work_in_progress("Loading file"):
                mock_time.return_value = 6.0
        mock_time.assert_has_calls([
            mock.call(),
            mock.call(),
        ])
        stdout.write.assert_called_with("Loading file... ")
        stdout.write.assert_called_with("done. (3.00s)\n")
        stdout.flush.assert_has_calls([
            mock.call(),
            mock.call(),
        ])

if __name__ == "__main__":
    test_

# Generated at 2022-06-23 17:48:02.340384
# Unit test for function work_in_progress
def test_work_in_progress():
    import re
    import sys
    import os

    with contextlib.redirect_stdout(sys.stderr):
        with contextlib.redirect_stderr(sys.stdout):
            with work_in_progress("Testing work_in_progress function"):
                time.sleep(1)
    out = sys.stdout.getvalue()
    assert isinstance(out, str)
    matched = re.match(r"Testing work_in_progress function... done. \(([\d.]+)s\)", out.strip())
    assert matched is not None
    time_consumed = float(matched.groups()[0])
    assert time_consumed >= 1 and time_consumed < 2
    sys.stdout.close()
    sys.stdout = sys.__stdout__
    sys.stderr.close()

# Generated at 2022-06-23 17:48:06.803011
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test")
    def func():
        time.sleep(1)

    func()

# Generated at 2022-06-23 17:48:13.037895
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing work_in_progress...")
    import pickle
    import io
    import time

    @work_in_progress("Loading file")
    def load_file(f):
        return pickle.load(f)

    f = io.BytesIO(b'\x80\x03X\x08\x00\x00\x00Hello Woq\x94.')
    assert load_file(f) == "Hello World"

    with work_in_progress("Saving file"):
        time.sleep(1)

    print("Passed.")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:48:16.701067
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test work_in_progress")
    def f():
        time.sleep(0.1)
    f()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:48:21.003833
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    d = load_file(__file__)
    assert len(d) > 0

    with work_in_progress("Saving file"):
        with open(__file__, "wb") as f:
            pickle.dump(d, f)


# Generated at 2022-06-23 17:48:28.377545
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("This takes a few seconds")
    def wait():
        for i in range(3):
            time.sleep(i + 1)
            print(".")
    wait()
    with work_in_progress("This takes a few seconds, too"):
        for i in range(3):
            time.sleep(i + 1)
            print(".")

if __name__ == "__main__":
    print("Testing function work_in_progress...")
    test_work_in_progress()

# Generated at 2022-06-23 17:48:32.911362
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:48:38.125080
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test case 1
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    assert work_in_progress("Loading file")
    assert load_file("/path/to/some/file")
    # Test case 2
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            return pickle.dump(obj, f)


print(test_work_in_progress())

# Generated at 2022-06-23 17:48:40.214301
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress") as wp:
        time.sleep(1.5)

# Generated at 2022-06-23 17:48:42.442543
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Printing"):
        print("Hi!")

# Generated at 2022-06-23 17:48:48.053617
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:48:52.190231
# Unit test for function work_in_progress
def test_work_in_progress():
    assert (
            work_in_progress("A long task")
            is contextlib.nullcontext()
    )
    assert (
            work_in_progress("A long task")
            is contextlib.nullcontext()
    )

# Generated at 2022-06-23 17:48:57.008968
# Unit test for function work_in_progress
def test_work_in_progress():
    # Without args
    with work_in_progress():
        time.sleep(0.1)

    # With args
    with work_in_progress("Wait 0.3 seconds"):
        time.sleep(0.1)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:48:59.857488
# Unit test for function work_in_progress
def test_work_in_progress():
    assert work_in_progress.__doc__ is not None


if __name__ == '__main__':
    # Test the module by running doctest
    import doctest

    doctest.testmod()

# Generated at 2022-06-23 17:49:08.266910
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""
    >>> @work_in_progress("Loading file")
    ... def load_file(path):
    ...     with open(path, "rb") as f:
    ...         return pickle.load(f)
    ...
    ... obj = load_file("/path/to/some/file")
    Loading file... done. (3.52s)

    >>> with work_in_progress("Saving file"):
    ...     with open(path, "wb") as f:
    ...         pickle.dump(obj, f)
    Saving file... done. (3.78s)
    """
    pass

# Generated at 2022-06-23 17:49:12.259058
# Unit test for function work_in_progress
def test_work_in_progress():
    for desc in ("Computing",
                 "Computing solution for the 'half-smile' problem",
                 "Reading configs ..."):
        with work_in_progress(desc):
            time.sleep(0.12)

# Generated at 2022-06-23 17:49:18.529194
# Unit test for function work_in_progress
def test_work_in_progress():
    def dummy_func():
        return len([x for x in range(2, 1000000) if not any(x % d == 0 for d in range(2, x))])

    with work_in_progress("Doing nothing"):
        pass

    @work_in_progress("Counting prime numbers")
    def count_primes():
        return dummy_func()

    assert count_primes() == 78498


# Unit test:
if __name__ == "__main__":
    test_work_in_progress()

# vim: foldmethod=marker

# Generated at 2022-06-23 17:49:24.103822
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress") as wip:
        time.sleep(0.01)
    assert wip is None, "Context manager returned a value"


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:33.282019
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert obj is not None

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    save_file("/path/to/some/file", obj)
    assert os.path.isfile("/path/to/some/file")

# Generated at 2022-06-23 17:49:39.869859
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Dummy task"):
        time.sleep(2)
    with work_in_progress("Dummy task"):
        time.sleep(1)
    @work_in_progress("Dummy function")
    def dummy_function():
        time.sleep(2)
    dummy_function()
    @work_in_progress("Dummy class method")
    def dummy_class_method(self):
        time.sleep(1)
    class DummyClass(object):
        pass
    DummyClass.dummy_method = dummy_class_method
    DummyClass().dummy_method()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:43.956840
# Unit test for function work_in_progress
def test_work_in_progress():
    import math
    with work_in_progress("Calculating pi"):
        math.pi

# Run unit test if run as a script.
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:55.550400
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    pwd = os.getcwd()
    with work_in_progress("Working in progress"):
        time.sleep(0.5)
    load_json_file = work_in_progress("Loading JSON file")
    with load_json_file:
        time.sleep(0.5)
    load_yaml_file = work_in_progress("Loading YAML file")
    with load_yaml_file:
        time.sleep(0.5)
    load_pickle_file = work_in_progress("Loading Pickle file")
    with load_pickle_file:
        time.sleep(0.5)
    load_csv_file = work_in_progress("Loading CSV file")
    with load_csv_file:
        time.sleep(0.5)



# Generated at 2022-06-23 17:49:58.822285
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing function work_in_progress()")
    with work_in_progress("Timing function sleep"):
        time.sleep(2)
    @work_in_progress("Timing function sleep")
    def sleep():
        time.sleep(2)
    sleep()

# Generated at 2022-06-23 17:50:03.374664
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:50:06.639692
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("task"):
        time.sleep(2)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:50:16.270333
# Unit test for function work_in_progress
def test_work_in_progress():
    class File:
        def __init__(self, file_path: str) -> None:
            self.file_path = file_path
        
        def __enter__(self):
            self.handle = open(self.file_path, "rb")
            return self.handle
        
        def __exit__(self, *exc_info):
            self.handle.close()
    
    file_handle = File("/path/to/some/file")
    with work_in_progress("Loading file"):
        with file_handle as f:
            obj = pickle.load(f)

    with work_in_progress("Saving file"):
        with file_handle as f:
            obj = pickle.dump(obj, f)

# test_work_in_progress()

# Generated at 2022-06-23 17:50:20.128846
# Unit test for function work_in_progress
def test_work_in_progress():
    num = np.random.randn(100000)
    with work_in_progress("Creating random array"):
        time.sleep(1)
        print(np.sum(num))

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:50:23.419871
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("A test")
    def test():
        time.sleep(0.01)
    test()


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:50:27.964286
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:50:31.016799
# Unit test for function work_in_progress
def test_work_in_progress():
    result = None
    with work_in_progress("Loading"):
        result = random.random()
    assert result is not None, "Random returned None!"

# Generated at 2022-06-23 17:50:40.066673
# Unit test for function work_in_progress
def test_work_in_progress():
    # TODO: Rewrite the test
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    with open("tmp_out.tmp", "wb") as f:
        pickle.dump(list(range(1 << 20)), f)
    obj = load_file("tmp_out.tmp")

    with work_in_progress("Saving file"):
        with open("tmp_out2.tmp", "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:50:50.337486
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert(os.path.isfile("/path/to/some/file"))

    with work_in_progress("Saving file"):
        with open("/path/to/some/file2", "wb") as f:
            pickle.dump(obj, f)
    assert(os.path.isfile("/path/to/some/file"))

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:50:53.002676
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress"""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    path = os.path.join(os.path.dirname(__file__), "__init__.py")
    assert load_file(path)

# Generated at 2022-06-23 17:50:54.120182
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing task"):
        time.sleep(2.5)

# Generated at 2022-06-23 17:50:57.887556
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing work_in_progress...")
    with work_in_progress("Sleep for a second"):
        time.sleep(1)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:51:05.353679
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path: str):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("test.dat")
    print(obj)

    with work_in_progress("Saving file"):
        with open("test.dat", "wb") as f:
            pickle.dump(obj, f)


# Only run unit test when directly executed
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:12.056540
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test basic usage
    with work_in_progress("Test1"):
        time.sleep(0.2)

    # Test basic usage
    print("testing")
    @work_in_progress("Test2")
    def test2():
        time.sleep(0.2)
    test2()

    # Test absence of semicolon
    @work_in_progress("Test3")
    def test3():
        time.sleep(0.2)
    test3()

# Generated at 2022-06-23 17:51:16.486355
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("A")
    @work_in_progress("B")
    def f(n):
        time.sleep(n)
    with work_in_progress("C"):
        time.sleep(1)
    f(2)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:51:19.207270
# Unit test for function work_in_progress
def test_work_in_progress():
    def fun():
        time.sleep(0.5)
    with work_in_progress("Work in progress"):
        fun()

# Generated at 2022-06-23 17:51:27.477613
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test function work_in_progress"""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:31.280050
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Running unit test of function work_in_progress()...")
    with work_in_progress("Test"):
        time.sleep(1.234)
    print("Done.")
    print()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:36.972632
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Loading file")
    def load_file():
        time.sleep(1)

    load_file()

    # with work_in_progress("Loading file"):
    #     time.sleep(1)



if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:51:42.868840
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file_with_progress(path):
        return load_file(path)

    @work_in_progress("Loading file")
    def load_file_with_progress_direct(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file_with_progress("/path/to/file")
    obj = load_file_with_progress_direct("/path/to/file")

    with work_in_progress("Saving file"):
        with open("/path/to/file", "wb") as f:
            pickle.dump(obj, f)



# Generated at 2022-06-23 17:51:49.362485
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test of work_in_progress as function decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

    # Test of work_in_progress as context manager
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:51:57.858807
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/tmp/file")  # doctest: +ELLIPSIS +NORMALIZE_WHITESPACE
    save_file("/tmp/file", obj)

# Generated at 2022-06-23 17:52:02.973887
# Unit test for function work_in_progress
def test_work_in_progress():
    obj = []

    with work_in_progress("Loading file"):
        time.sleep(3.52)
        obj = [1, 2, 3]

    assert obj == [1, 2, 3]


# Run tests if run from command line
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:13.721013
# Unit test for function work_in_progress
def test_work_in_progress():
    from pathlib import Path
    from math import sin
    from random import random
    from tempfile import TemporaryDirectory

    def test_case(func, desc, **kwargs):
        begin_time = time.time()
        kwargs["func"](**kwargs)
        actual_time_consumed = time.time() - begin_time
        print(f"{desc}... ", end='', flush=True)
        begin_time = time.time()
        func(**kwargs)
        expected_time_consumed = time.time() - begin_time
        print(f"done. ({expected_time_consumed:.2f}s)")
        assert abs(actual_time_consumed - expected_time_consumed) < 0.5


# Generated at 2022-06-23 17:52:21.835335
# Unit test for function work_in_progress
def test_work_in_progress():
    with mock.patch("builtins.print") as mock_print:
        mock_print.side_effect = iter(
            ["Loading file... ", "Loading file... done. (3.52s)"]
        )

        with work_in_progress("Loading file"):
            time.sleep(.5)

        mock_print.assert_called_once_with("Loading file... ", end='', flush=True)
        mock_print.reset_mock()

        mock_print.side_effect = iter(
            ["Saving file... ", "Saving file... done. (3.78s)"]
        )

        with work_in_progress("Saving file"):
            time.sleep(.5)

        mock_print.assert_called_once_with("Saving file... ", end='', flush=True)
        mock_

# Generated at 2022-06-23 17:52:26.063673
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Short task")
    def short_task():
        time.sleep(0.01)

    @work_in_progress("Long task")
    def long_task():
        time.sleep(0.1)

    short_task()
    long_task()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:37.325894
# Unit test for function work_in_progress
def test_work_in_progress():
    log_file = "work_in_progress.log"
    sys.stdout = open(log_file, "w")

    def test_func(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Loading file"):
        obj = test_func("work_in_progress.pkl")
    with work_in_progress("Saving file"):
        with open("work_in_progress.tmp.pkl", "wb") as f:
            pickle.dump(obj, f)

    sys.stdout.close()
    with open(log_file) as f:
        log_contents = f.read()

# Generated at 2022-06-23 17:52:43.367017
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test a simple print
    print("Work in progress...", end='', flush=True)
    time.sleep(1)
    print("done.")

    # Test a function decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    # Test a context manager
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    test_work_in_progress()

# Generated at 2022-06-23 17:52:49.180905
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file(__file__)
    assert obj is not None

    with work_in_progress("Saving file"):
        with open(__file__, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:55.549299
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import pickle
    import os

    # Create a file
    with open("test.bin", "wb") as f:
        f.write(b"\x00" * 1024*1024*32)

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file_with_wip(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file_with_wip("test.bin")
    obj = load_file("test.bin")

# Generated at 2022-06-23 17:53:06.381698
# Unit test for function work_in_progress
def test_work_in_progress():
    import pytest
    import os
    import tempfile

    # Unit test function with context manager
    with work_in_progress("Testing work in progress"):
        time.sleep(1.5)

    # Unit test decorator
    @work_in_progress("Testing work in progress")
    def test_work_in_progress():
        time.sleep(1.5)

    test_work_in_progress()

    # Unit test decorator with multiple levels
    def dummy_decorator(func):
        def dummy_wrapped(*args, **kwargs):
            return func(*args, **kwargs)
        return dummy_wrapped

    @dummy_decorator
    @work_in_progress("Testing work in progress")
    def test_work_in_progress2():
        time.sleep(1.5)

   