

# Generated at 2022-06-23 17:43:04.430153
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test function"):
        time.sleep(0.1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:43:08.125266
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:43:16.102458
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress(desc="Loading file"):
        time.sleep(1)
        with work_in_progress(desc="Loading corpus"):
            time.sleep(0.5)
            with work_in_progress(desc="Loading item"):
                time.sleep(0.7)
        with work_in_progress(desc="Loading file"):
            time.sleep(1.5)
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:43:25.459206
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    .. code:: python

        >>> test_work_in_progress()
        Load file... done. (2.13s)
        Save file... done. (0.94s)
    """
    # Test in function
    @work_in_progress("Load file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    # Test in context
    with work_in_progress("Save file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:43:35.993330
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import string

    def rand_str(n):
        return ''.join(random.choices(string.ascii_letters, k=n))

    def some_expensive_task(size):
        return "".join(sorted(rand_str(size), reverse=True))

    list_ = [some_expensive_task(random.randint(10, 20)) for _ in range(5)]

    with work_in_progress("Sorting list"):
        sorted(list_, reverse=True)

    with work_in_progress("Performing some random tasks"):
        time.sleep(3)

# Generated at 2022-06-23 17:43:46.842184
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    import sys

    # Capture the standard output
    old_stdout = sys.stdout
    buffer = io.StringIO()
    try:
        sys.stdout = buffer

        @work_in_progress("Testing work_in_progress")
        def test_function():
            time.sleep(1.23)

        test_function()
        assert buffer.getvalue() == "Testing work_in_progress... done. (1.23s)\n"
    finally:
        sys.stdout = old_stdout

    # Capture the standard output
    old_stdout = sys.stdout
    buffer = io.StringIO()

# Generated at 2022-06-23 17:43:48.022826
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(2.0)

# Generated at 2022-06-23 17:43:52.879544
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")
    save_file(obj, "/path/to/some/other/file")

# Generated at 2022-06-23 17:43:57.127902
# Unit test for function work_in_progress
def test_work_in_progress():
    def run():
        time.sleep(1)
    
    with work_in_progress("Sleep for 1 second"):
        run()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:44:04.761464
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("task1"):
        # do something
        time.sleep(3)
    def func2():
        with work_in_progress("task2"):
            # do something
            time.sleep(4)
    func2()
    with work_in_progress("task3"):
        # do something
        time.sleep(5)
    @work_in_progress("task4")
    def func4():
        time.sleep(6)
    func4()

if __name__ == "__main__":
    test_work_in_progress()

# Reference:
# 1. https://www.python.org/dev/peps/pep-0346/#id8

# Generated at 2022-06-23 17:44:08.484999
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(0.5)
    # Output:
    # Saving file... done. (0.5s)

# Generated at 2022-06-23 17:44:17.355606
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile

    @work_in_progress("Load file")
    def load_file(path):
        with open(path, "r") as f:
            res = f.read()
        return res

    @work_in_progress("Save file")
    def save_file(path, data):
        with open(path, "w") as f:
            f.write(data)

    # Test
    with tempfile.TemporaryDirectory() as tmp_dir:
        path = os.path.join(tmp_dir, "test.txt")
        save_file(path, "Hello world")
        data = load_file(path)
        assert data == "Hello world"

# Generated at 2022-06-23 17:44:26.039329
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function work_in_progress"""

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, 'rb') as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, 'wb') as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:44:29.701507
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    load_file("test_work_in_progress.pickle")
    # Loading file... done. (3.52s)


# Generated at 2022-06-23 17:44:38.594009
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")
    save_file(obj, "/path/to/some/other/file")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:44:46.219528
# Unit test for function work_in_progress
def test_work_in_progress():
    from tempfile import NamedTemporaryFile
    import pickle

    def create_random_picle_data():
        obj = []
        for i in range(10000):
            obj.append((i, i / 100))
        return obj

    with work_in_progress("Creating random picle data"):
        obj = create_random_picle_data()

    with NamedTemporaryFile(suffix=".pkl") as f:
        with work_in_progress("Saving file"):
            pickle.dump(obj, f)
        f.flush()
        with work_in_progress("Loading file"):
            obj_loaded = pickle.load(f)
        assert obj == obj_loaded


if __name__ == "__main__":
    import doctest
    doctest.testmod()

    test_work_

# Generated at 2022-06-23 17:44:51.206239
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1)
    print()

    @work_in_progress("Testing work_in_progress")
    def work_in_progress_test():
        time.sleep(1)
    work_in_progress_test()
    print()


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:44:54.840198
# Unit test for function work_in_progress
def test_work_in_progress():
    # Simulate some slow loading process
    with work_in_progress("Loading file"):
        time.sleep(3)

    # Simulate some slow saving process
    with work_in_progress("Saving file"):
        time.sleep(3)

# Generated at 2022-06-23 17:45:02.590800
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    def slow_work():
        time.sleep(2)

    with work_in_progress():
        slow_work()

    with work_in_progress("Loading file"):
        obj = pickle.load(open("tests/fixtures/some_object.pickle", "rb"))

    with work_in_progress("Saving file", newline=False):
        pickle.dump(obj, open("tests/fixtures/some_object_copy.pickle", "wb"))

# Generated at 2022-06-23 17:45:13.624145
# Unit test for function work_in_progress
def test_work_in_progress():
    import random

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/dev/zero")
    save_file(obj, "./rand.dat")
    obj = load_file("./rand.dat")
    save_file(obj, "./rand.dat")
    os.remove("./rand.dat")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:45:16.207300
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test")
    def something():
        time.sleep(1)
    something()

if __name__=="__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:45:18.686431
# Unit test for function work_in_progress
def test_work_in_progress():
    def func():
        time.sleep(1)
        return True
    with work_in_progress(desc="Counting 1s"):
        assert func()

# Generated at 2022-06-23 17:45:21.837220
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress()")
    def _test():
        time.sleep(0.1)
    return _test()

# Run unit tests
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:45:31.202520
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    # Run unit tests
    test_work_in_progress()

# Generated at 2022-06-23 17:45:36.153657
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing function work_in_progress ...")
    with work_in_progress("Doing some boring work"):
        time.sleep(1.0)
    with work_in_progress("Doing some interesting work"):
        time.sleep(2.0)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:45:46.947496
# Unit test for function work_in_progress
def test_work_in_progress():
    from io import BytesIO
    import pickle
    import random

    path = "/tmp/file.pickle"
    obj = [random.random() for _ in range(100)]

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with work_in_progress("Loading file"):
        assert obj == load_file(path)

    with work_in_progress("Saving file"):
        save_file(path, obj)

    with work_in_progress("Loading file to buffer"):
        f = BytesIO()
        pickle.dump(obj, f)

# Generated at 2022-06-23 17:45:51.812759
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Test work_in_progress"
    actual_time = 0.0
    with work_in_progress(desc) as w:
        time.sleep(1.0)
        actual_time = time.time() - w.begin_time()
    expected_time = 1.0
    assert actual_time >= expected_time, f"Actual time={actual_time:.2f} < Expected time={expected_time:.2f}"
test_work_in_progress()

# Generated at 2022-06-23 17:45:57.049866
# Unit test for function work_in_progress
def test_work_in_progress():
    # pylint: disable=invalid-name
    # pylint: disable=unused-variable
    # pylint: disable=redefined-outer-name
    with redirect_stdout(StringIO()) as stdout:
        @work_in_progress("Loading file")
        def load_file(path):
            with open(path, "rb") as f:
                return pickle.load(f)

        obj = load_file("LICENSE.txt")
    assert stdout.getvalue() == "Loading file... done. (0.00s)\n"

    with redirect_stdout(StringIO()) as stdout:
        with work_in_progress("Saving file"):
            with open(path, "wb") as f:
                pickle.dump(obj, f)
    assert stdout.getvalue()

# Generated at 2022-06-23 17:46:04.088535
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:46:09.417217
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function work_in_progress.
    """
    # Test the context manager
    with work_in_progress("Sleeping for a second"):
        time.sleep(1)
    print("")

    # Test the decorator
    @work_in_progress("Sleeping for a second")
    def foo():
        time.sleep(1)
    foo()
    print("")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:46:15.585207
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file2(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    obj = load_file2("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:46:26.031800
# Unit test for function work_in_progress
def test_work_in_progress():
    from pathlib import Path
    from io import BytesIO
    from pickle import dumps
    from tempfile import TemporaryDirectory

    def sample_function(path: str):
        with open(path, "rb") as f:
            return pickle.load(f)

    with TemporaryDirectory() as temp_path:
        temp_path = Path(temp_path)
        temp_file = temp_path / "temp.pickle"
        with temp_file.open("wb") as f:
            pickle.dump(list(range(100000)), f)

        with work_in_progress("Loading file"):
            obj = sample_function(temp_file)
        assert obj == list(range(100000))

        with work_in_progress("Saving file"):
            obj = sample_function(temp_file)
        assert obj

# Generated at 2022-06-23 17:46:31.615471
# Unit test for function work_in_progress
def test_work_in_progress():
    from .testutils import TemporaryDirectory
    with work_in_progress("Printing 'x'"):
        print("x")


# Generated at 2022-06-23 17:46:35.303197
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    # Work in progress
    with work_in_progress("Unit test for function work_in_progress"):
        time.sleep(1)

# Unit test
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:46:43.121286
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert obj is not None
    assert obj[0] == "Hello world!"

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:46:44.304932
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sample task"):
        time.sleep(0.1)

# Generated at 2022-06-23 17:46:52.762346
# Unit test for function work_in_progress
def test_work_in_progress():

    # Test work_in_progress as a context manager
    with work_in_progress() as w:
        time.sleep(1)

    # Test work_in_progress as a decorator
    @work_in_progress()
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    load_file("/path/to/some/file")

    print("Test complete.")

if __name__ == '__main__':

    test_work_in_progress()

# Generated at 2022-06-23 17:47:00.082795
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert obj == 42

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == '__main__':
    import pytest
    pytest.main(["-x", __file__])

# Generated at 2022-06-23 17:47:05.843128
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function work_in_progress."""
    def test_function():
        with work_in_progress("Test function"):
            time.sleep(0.1)

    test_function()
    # Test with statement
    with work_in_progress("Test with"):
        time.sleep(0.1)


# Generated at 2022-06-23 17:47:07.672554
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test")
    def foo():
        return 123

    assert foo() == 123

# Generated at 2022-06-23 17:47:10.926842
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:47:15.049584
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function work_in_progress."""
    with work_in_progress("Testing work_in_progress (this should take 3 seconds)"):
        time.sleep(3)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:47:20.495785
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:47:24.195517
# Unit test for function work_in_progress
def test_work_in_progress():
    print()  # newline

    print("== Output from test_work_in_progress() ==")
    msg = "Testing work_in_progress()..."
    begin_time = time.time()

    # simulate a slow operation
    time.sleep(1)

    time_consumed = time.time() - begin_time
    print(f"{msg} done. ({time_consumed:.2f}s)")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:47:34.980463
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test function work_in_progress."""
    import io
    import sys

    # pylint: disable=protected-access
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # save OUTPUT
    saved_stdout = sys.stdout
    saved_stderr = sys.stderr

    # Load test data
    modules_root = os.path.dirname(os.path.abspath(__file__))
    test_data_root = os.path.join(modules_root, "test_data")
    sys.stdout = io.StringIO()
    sys.stderr = io.StringIO()

# Generated at 2022-06-23 17:47:39.754645
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:47:46.693888
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test as a function decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # Test as a context manager
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:47:52.128125
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with work_in_progress("Saving file"):
        save_file("/path/to/some/file", "hello world")
    load_file("/path/to/some/file")

# Generated at 2022-06-23 17:47:58.704034
# Unit test for function work_in_progress
def test_work_in_progress():
    def f1(x):
        with work_in_progress(f"Computing {x}"):
            time.sleep(1)

    f1(1)
    f1(2)

    start = time.time()
    with work_in_progress("Loading file"):
        obj = list(range(1000000))

    assert time.time() - start >= 1

    obj = None
    start = time.time()
    with work_in_progress("Saving file"):
        obj = list(range(10000000))

    assert time.time() - start >= 1

# Generated at 2022-06-23 17:48:07.664652
# Unit test for function work_in_progress
def test_work_in_progress():
    for desc in ["", "Ready", "Testing work_in_progress", "123456789012345678901234567890"]:
        @work_in_progress(desc)
        def function_x():
            time.sleep(2)
        function_x()
    with work_in_progress():
        time.sleep(2)
    with work_in_progress("Long enough text"):
        time.sleep(2)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:48:19.152728
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile

    test_path = os.path.join(tempfile.mkdtemp(), "test_work_in_progress")

    @work_in_progress("Writing content to temporary file")
    def write_content():
        with open(test_path, "w") as f:
            f.write("Hello world!")

    write_content()

    assert os.path.exists(test_path)

    @work_in_progress("Reading contents from temporary file")
    def read_content():
        with open(test_path) as f:
            return f.read()

    assert read_content() == "Hello world!"


# Non-recursive traversal of directory structure
import os
from typing import Iterator, Callable, Tuple

__all__.append("traverse_dir_structure")

# Generated at 2022-06-23 17:48:26.347164
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:48:30.885235
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:48:34.994683
# Unit test for function work_in_progress
def test_work_in_progress():
    i = 0
    with work_in_progress("Loading file") as w:
        while i < int(1e8):
            i += 1
    assert w.__next__() is None


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:48:38.959177
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:48:42.963898
# Unit test for function work_in_progress
def test_work_in_progress():

    # Test normal behavior
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:48:45.851933
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Unit testing function work_in_progress"):
        time.sleep(2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:48:49.416893
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Sleeping for a while"):
        time.sleep(2)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:48:57.912198
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    @work_in_progress("Loading file")
    def load_file():
        with open("test_work_in_progress.txt", "rb") as f:
            return pickle.load(f)

    with open("test_work_in_progress.txt", "wb") as f:
        pickle.dump([1, 2, 3], f)

    with work_in_progress("Saving file"):
        with open("test_work_in_progress.txt", "wb") as f:
            pickle.dump([1, 2, 3], f)

    load_file()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:04.764491
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Reading file")
    def f():
        with open("tests/io/dummy_file", "r") as file:
            file.read()
    f()

    def f():
        with open("tests/io/dummy_file", "r") as file:
            file.read()
    with work_in_progress("Reading file"):
        f()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:10.264474
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:49:13.362808
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress..."):
        time.sleep(3.3)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:22.096599
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(file_path):
        with open(file_path, "rb") as f:
            return pickle.load(f)

    save_file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "save_file.pkl")
    sample_obj = {'a': [1, 2, 3],
                  'b': [4, 5, 6]}
    with open(save_file_path, "wb") as f:
        pickle.dump(sample_obj, f)

    loaded_obj = load_file(save_file_path)
    assert loaded_obj == sample_obj


# Generated at 2022-06-23 17:49:24.491921
# Unit test for function work_in_progress
def test_work_in_progress():
    def f():
        time.sleep(1)

    with work_in_progress("Waiting"):
        f()

# Generated at 2022-06-23 17:49:27.040403
# Unit test for function work_in_progress
def test_work_in_progress():

    with work_in_progress("Loading file"):
        time.sleep(0.12345678)
    assert True

# Generated at 2022-06-23 17:49:30.531959
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")



# Generated at 2022-06-23 17:49:33.627374
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:41.601849
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress()."""
    import random
    import pprint
    from io import BytesIO

    def save_data(path: str, data: bytes):
        """Save binary data."""
        with open(path, "wb") as f:
            f.write(data)

    def load_data(path: str) -> bytes:
        """Load binary data."""
        with open(path, "rb") as f:
            data = f.read()
        return data

    def save_pickled_object(path: str, obj):
        """Save pickled object."""
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    def load_pickled_object(path: str):
        """Load pickled object."""

# Generated at 2022-06-23 17:49:44.252424
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def experiment():
        time.sleep(1)

    experiment()

# Generated at 2022-06-23 17:49:47.768009
# Unit test for function work_in_progress
def test_work_in_progress():
    for i in range(4):
        with work_in_progress(desc = f"Sleeping for {i+1} seconds"):
            time.sleep(i+1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:56.441465
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress"""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:50:02.228831
# Unit test for function work_in_progress
def test_work_in_progress():

    # Test work_in_progress as a context manager
    with work_in_progress("Loading image"):
        time.sleep(0.6)
    with work_in_progress("Loading image"):
        time.sleep(4.8)

    # Test work_in_progress as a decorator
    @work_in_progress("Loading audio")
    def load_audio(path):
        time.sleep(1.6)

    @work_in_progress("Loading audio")
    def load_audio(path):
        time.sleep(0.1)

    load_audio("/path/to/audio/file")

# Generated at 2022-06-23 17:50:06.080374
# Unit test for function work_in_progress
def test_work_in_progress():
    def task():
        time.sleep(1)

    with work_in_progress("Testing"):
        task()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:50:11.472795
# Unit test for function work_in_progress
def test_work_in_progress():

    # case 1
    with work_in_progress("Loading file"):
        time.sleep(1.2)
    # case 2
    @work_in_progress("Saving file")
    def save_file():
        time.sleep(1.6)

    save_file()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:50:17.872151
# Unit test for function work_in_progress
def test_work_in_progress():
    # ---------- Test for context manager ----------
    with work_in_progress("Saving file"):
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
    # ---------- Test for decorator ----------
    @work_in_progress("Loading file")
    def load_file(path: str):
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
    load_file("/path/to/some.file")

# Generated at 2022-06-23 17:50:23.700512
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:50:29.529892
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with work_in_progress("Saving file"):
        save_file("Hello world!", "hello.txt")

# Generated at 2022-06-23 17:50:35.914901
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "/path/to/some/file"
    load_file(path)

    obj = {'a': 1}
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:50:40.510198
# Unit test for function work_in_progress
def test_work_in_progress():
    from pytest import approx

    def load_file(path):
        time.sleep(0.2)  # Simulate file loading time.
        return path

    with work_in_progress():
        assert load_file("file.py") == "file.py"

    assert load_file("file.py") == "file.py"

# Generated at 2022-06-23 17:50:44.943386
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress('Test work_in_progress')
    def test():
        time.sleep(0.01)

    test()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:50:49.821900
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Loading file"):
        time.sleep(1.2)
    with work_in_progress("Loading another file"):
        time.sleep(1.9)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:50:56.591040
# Unit test for function work_in_progress
def test_work_in_progress():
    def test_func():
        time.sleep(1.0)

    test_cases = (
        ("", "[{}] Work in progress..."),
        ("abc", "[abc] Work in progress..."),
        ("abc def ghi", "[abc def ghi] Work in progress..."),
    )

    for (desc, expected) in test_cases:
        with patch("builtins.print") as mock_print:
            with work_in_progress(desc):
                test_func()
            mock_print.assert_any_call(expected, end="", flush=True)
            mock_print.assert_any_call(re.compile(r"^done. \(1\.\d+s\)$"))

# Generated at 2022-06-23 17:50:59.631816
# Unit test for function work_in_progress
def test_work_in_progress():
    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:51:02.149168
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Simulating work in progress"):
        time.sleep(1)
        print("Some work in progress.")
        time.sleep(2)

# Generated at 2022-06-23 17:51:05.661460
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    @work_in_progress("Testing work_in_progress")
    def test():
        time.sleep(1)

    test()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:11.412663
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import pickle

    @work_in_progress("Loading file")
    def load_file(path: str):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path: str, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    tmp_dir = tempfile.TemporaryDirectory()
    try:
        obj = {'a': 1, 'b': 2}
        path = os.path.join(tmp_dir.name, 'test')
        save_file(path, obj)
        obj_loaded = load_file(path)
        assert obj_loaded == obj
    finally:
        tmp_dir.cleanup()

# Generated at 2022-06-23 17:51:16.564266
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(0.5)
    
    def test_func(x, y):
        with work_in_progress("Test func"):
            time.sleep(0.5)

        return x*y

    assert test_func(2, 3) == 6


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:21.060356
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
        
    obj = load_file("resources/test.pkl")
    print(obj)

#test_work_in_progress()


# Generated at 2022-06-23 17:51:28.189846
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import pickle
    import os

    with work_in_progress("Loading file"):
        with open("test.pkl", "rb") as f:
            obj = pickle.load(f)

    with work_in_progress("Saving file"):
        with open(os.path.join(tempfile.gettempdir(), "file.pkl"), "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:51:33.688175
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    >>> @work_in_progress("Loading file")
    ... def load_file(path):
    ...     with open(path, "rb") as f:
    ...         return pickle.load(f)
    ...
    ... obj = load_file("/path/to/some/file")
    Loading file... done. (3.52s)
    """
    return True

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:51:35.816020
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Test progress"):
        time.sleep(0.5)

# Generated at 2022-06-23 17:51:41.736934
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:45.728634
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("This is a test"):
        time.sleep(1)
    with work_in_progress("A different test"):
        time.sleep(2)
    with work_in_progress("An even longer test"):
        time.sleep(5)

# Generated at 2022-06-23 17:51:53.477551
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with work_in_progress("Loading file"):
        with open("/path/to/some/file", "rb") as f:
            obj = pickle.load(f)

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

# Generated at 2022-06-23 17:52:02.402374
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress
    """
    from .utils import capture_stdout
    with capture_stdout():
        with work_in_progress("Loading"):
            for _ in range(1000000):
                a = 1 + 1
        with work_in_progress("Saving"):
            for _ in range(1000000):
                a = 1 + 1
        try:
            with work_in_progress("error"):
                raise KeyError
        except:
            pass
        # no output here
        with work_in_progress():
            pass

# Generated at 2022-06-23 17:52:13.129668
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    import sys
    import time
    from contextlib import redirect_stdout

    for _ in range(10):
        with io.StringIO() as buf, redirect_stdout(buf):
            with work_in_progress("Work in progress"):
                time.sleep(0.2)
            got_output = buf.getvalue()
        assert got_output.strip() == "Work in progress... done. (0.20s)", \
                "Output mismatch. Got output \"{}\", expected output \"{}\".".format(
                    got_output, "Work in progress... done. (0.20s)")
    print("All tests passed!")

# Automatically run the unit test if the module is executed
if __name__ == "__main__":
    import sys
    test_work_in_progress()

# Generated at 2022-06-23 17:52:19.095917
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Starting long task")
    def long_task():
        with work_in_progress("Initializing"):
            time.sleep(.1)
        print("Performing task... ", end='', flush=True)
        with work_in_progress("Computing"):
            time.sleep(.5)
        print("done.")
        with work_in_progress("Finalizing"):
            time.sleep(.2)
    print("Main task...", end='', flush=True)
    time.sleep(.3)
    print("done.")
    long_task()


# Generated at 2022-06-23 17:52:26.991852
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:30.110912
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test function"):
        time.sleep(0.5)

# Test call
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:35.686367
# Unit test for function work_in_progress
def test_work_in_progress():
    begin_time = time.time()
    with work_in_progress("Sleeping for 5 seconds"):
        time.sleep(5.0)
    time_consumed = time.time() - begin_time
    assert time_consumed >= 5.0


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:39.714054
# Unit test for function work_in_progress
def test_work_in_progress():

    # Test context manager
    with work_in_progress("Loading file"):
        time.sleep(1)

    # Test decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb"):
            time.sleep(1)

    load_file("/path/to/file")

# Generated at 2022-06-23 17:52:46.306616
# Unit test for function work_in_progress
def test_work_in_progress():
    class DummyObj:
        pass
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")
    assert isinstance(obj, DummyObj)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:52:48.399978
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("test progress"):
        time.sleep(1)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:52:49.757212
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def func():
        time.sleep(1)

    func()

# Generated at 2022-06-23 17:52:55.929576
# Unit test for function work_in_progress
def test_work_in_progress():
    l = 10**7
    with work_in_progress("Building test array"):
        a = np.random.randint(0, l, l)
    with work_in_progress("Fetching elements"):
        b = [a[i] for i in range(l)]
    with work_in_progress("Vectorized fetching"):
        c = a[np.arange(l)]
    with work_in_progress("Sorting"):
        d = a[a.argsort()]
    with work_in_progress("Built-in sorting"):
        e = np.sort(a)
    with work_in_progress("Check if b matches a"):
        assert (b == a).all()
    with work_in_progress("Check if c matches a"):
        assert (c == a).all()


# Generated at 2022-06-23 17:53:03.190513
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            time.sleep(random.randint(3, 5))
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            time.sleep(random.randint(1, 10))
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()