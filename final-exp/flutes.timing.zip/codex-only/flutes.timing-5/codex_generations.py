

# Generated at 2022-06-23 17:43:03.889969
# Unit test for function work_in_progress
def test_work_in_progress():
    # Load a file
    with work_in_progress("Loading file"):
        time.sleep(3)

    # Save a file
    with work_in_progress("Saving file"):
        time.sleep(2)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:43:14.474990
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import pickle
    path = "/tmp/test_wip"
    if os.path.exists(path):
        os.remove(path)

    @work_in_progress("Loading file", verbose=2)
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file", verbose=2)
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file(path)
    save_file(path, obj)

# Generated at 2022-06-23 17:43:18.876955
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test 1: Test context manager
    with work_in_progress("Test context manager") as w:
        time.sleep(0.5)
    assert w is None

    # Test 2: Test context manager with a function
    @work_in_progress()
    def f():
        time.sleep(0.5)
    f()



# Generated at 2022-06-23 17:43:24.500954
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress(desc="Unit testing work_in_progress")
    def unit_test(max_num=10**5):
        for i in range(max_num):
            assert i % 2 == 0
    unit_test(10)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:43:30.601375
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:43:34.457544
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Working")
    def worker():
        time.sleep(1)
    worker()

    with work_in_progress("Working"):
        time.sleep(1)

# Generated at 2022-06-23 17:43:37.999559
# Unit test for function work_in_progress
def test_work_in_progress():

    with work_in_progress("Loading file"):
        with open(__file__, "rb") as f:
            obj = pickle.load(f)

    obj = load_file(__file__)



# Generated at 2022-06-23 17:43:45.397163
# Unit test for function work_in_progress
def test_work_in_progress():
    from pathlib import Path
    import numpy as np

    dbg = False

    path = Path("/tmp") / ".test_wip"

    @work_in_progress("Vectors computation")
    def compute_vectors(size: int):
        return np.random.rand(size, size)

    @work_in_progress("Saving data")
    def save_data(path: Path):
        with open(path, "wb") as f:
            pickle.dump(compute_vectors(5000), f)

    @work_in_progress("Loading data")
    def load_data(path: Path):
        with open(path, "rb") as f:
            data = pickle.load(f)
        return data

    def deterministic_test(path: Path):
        save_data(path)

# Generated at 2022-06-23 17:43:48.663228
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        pass

# Generated at 2022-06-23 17:43:50.353131
# Unit test for function work_in_progress
def test_work_in_progress():
    def func():
        time.sleep(3)
    with work_in_progress():
        func()

# Generated at 2022-06-23 17:43:55.411484
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    # Testing context manager
    with work_in_progress("Loading file"):
        time.sleep(0.1)

    # Testing decorator
    @work_in_progress("Saving file")
    def save():
        time.sleep(0.2)

    save()

# Generated at 2022-06-23 17:43:57.474331
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress('Test'):
        time.sleep(2)

# Generated at 2022-06-23 17:44:03.261955
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file():
        with open("data.pickle", "rb") as f:
            return pickle.load(f)
    data = load_file()
    with work_in_progress("Saving file"):
        with open("data.pickle", "wb") as f:
            pickle.dump(data, f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:44:14.590997
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    path = "/tmp/test_work_in_progress.pickle"
    obj = [1, 2, 3, 4, 5]
    with open(path, "wb") as f:
        pickle.dump(obj, f)

    obj_load = load_file(path)
    assert obj == obj_load

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    time.sleep(0.01)
    os.remove(path)

# Generated at 2022-06-23 17:44:26.040520
# Unit test for function work_in_progress
def test_work_in_progress():
    import pytest
    import sys
    import subprocess
    import signal

    print = lambda *args: sys.stdout.write(args[0])

    with pytest.raises(Exception):
        with work_in_progress("Error mode"):
            raise Exception()

    @work_in_progress("Test func")
    def test_func():
        time.sleep(0.1)

    test_func()
    assert True

    if sys.platform == "win32":
        with pytest.raises(subprocess.CalledProcessError):
            subprocess.check_output(
                "timeout 0.1 /t && echo hello".split(),
                creationflags=subprocess.CREATE_NEW_PROCESS_GROUP
            ).decode()

# Generated at 2022-06-23 17:44:28.131674
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        pass
    print("Test finished.")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:44:32.800329
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Task"):
        time.sleep(1)
    @work_in_progress("Task")
    def task():
        time.sleep(1)
        return 1
    task()

# Generated at 2022-06-23 17:44:39.305703
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


# vim: filetype=python
# vim: foldmethod=marker

# Generated at 2022-06-23 17:44:46.618187
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile
    import pickle

    IO_TIME_ESTIMATE = 0.1
    obj = []
    for i in range(1000):
        obj.append(i)

    filepath = os.path.join(tempfile.gettempdir(), "test.pickle")

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    def test_load():
        with work_in_progress("Loading file"):
            data = load_file(filepath)
            assert data == obj


# Generated at 2022-06-23 17:44:49.543243
# Unit test for function work_in_progress
def test_work_in_progress():
    f = work_in_progress("test work_in_progress")
    assert f.__name__ == 'work_in_progress'
    print("test_work_in_progress()... done. (0.00s)")

# Generated at 2022-06-23 17:44:56.217272
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress."""
    def _assert_output(s, expected):
        with io.StringIO() as buf, redirect_stdout(buf):
            with work_in_progress("Saving file"):
                for i in range(s):
                    time.sleep(1)
            output = buf.getvalue()
            assert expected in output
    _assert_output(1, "done. (1.00s)")
    _assert_output(5, "done. (5.00s)")
    _assert_output(10, "done. (10.00s)")
    _assert_output(100, "done. (100.00s)")
    _assert_output(1000, "done. (1000.00s)")

# Generated at 2022-06-23 17:45:00.128747
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    with work_in_progress("Saving file"):
        time.sleep(1)

# Generated at 2022-06-23 17:45:03.618304
# Unit test for function work_in_progress
def test_work_in_progress():
    """Tests work_in_progress function."""
    import time

    @work_in_progress("Testing work_in_progress")
    def inner():
        time.sleep(0.2)

    inner()

# Generated at 2022-06-23 17:45:13.760751
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    r"""
    >>> @work_in_progress("Loading file")
    ... def load_file(path):
    ...     with open(path, "rb") as f:
    ...         return pickle.load(f)
    ...
    ... obj = load_file("/path/to/some/file")
    Loading file... done. (3.52s)

    >>> with work_in_progress("Saving file"):
    ...     time.sleep(0.21)
    Saving file... done. (0.21s)
    """


if __name__ == "__main__":
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-23 17:45:16.934894
# Unit test for function work_in_progress
def test_work_in_progress():
    a = None
    with work_in_progress("Loading file"):
        with open("test/test_work_in_progress.txt", "r") as f:
            a = f.read()

    with work_in_progress("Saving file"):
        with open("test/test_work_in_progress_2.txt", "w") as f:
            f.write(a)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:45:19.043556
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test")
    def f():
        time.sleep(1)
    f()


# Generated at 2022-06-23 17:45:23.665672
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    print(obj)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:45:29.985624
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file(__file__)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:45:36.284893
# Unit test for function work_in_progress
def test_work_in_progress():
    import unittest
    import time
    class WorkInProgressTester(unittest.TestCase):
        def test_with_block(self):
            with work_in_progress("Testing 1 2 3"):
                time.sleep(3)
        def test_function(self):
            @work_in_progress("Testing 1 2 3")
            def tester():
                time.sleep(3)
            tester()
    unittest.main()

# Generated at 2022-06-23 17:45:43.648393
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import pickle
    import os

    @work_in_progress("Testing work_in_progress")
    def test():
        str_list = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j",
                    "k", "l", "m", "n", "o", "p", "q", "r", "s", "t",
                    "u", "v", "w", "x", "y", "z"]

        with tempfile.NamedTemporaryFile(mode="wb",
                                         prefix="test_work_in_progress",
                                         suffix=".tmp",
                                         delete=False) as f:
            pickle.dump(str_list, f)


# Generated at 2022-06-23 17:45:53.233165
# Unit test for function work_in_progress
def test_work_in_progress():
    path = "/tmp/test_work_in_progress.with_context"
    with work_in_progress("Dumping file"):
        time.sleep(1)
        with open(path, "wb") as f:
            pickle.dump(np.random.rand(100, 100), f)
    with work_in_progress("Loading file"):
        time.sleep(2)
        with open(path, "rb") as f:
            a = pickle.load(f)
    assert a.shape == (100, 100)
    os.remove(path)

# Generated at 2022-06-23 17:46:01.742564
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:46:05.361326
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        with open(__file__, "r") as f:
            f.readlines()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:46:14.750659
# Unit test for function work_in_progress
def test_work_in_progress():
    from time import sleep
    print("Test function: work_in_progress")
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    with work_in_progress("Testing work_in_progress()"):
        save_file("__test__.pickle", {1:2, 3:4})
        print(load_file("__test__.pickle"))
        sleep(1)

test_work_in_progress()

# Generated at 2022-06-23 17:46:17.633968
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1)
    # TODO: make unit test

# Generated at 2022-06-23 17:46:19.886446
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def test_fn():
        time.sleep(0.5)
    assert test_fn

# Generated at 2022-06-23 17:46:21.547070
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1)

# Generated at 2022-06-23 17:46:24.872214
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# vim:sw=4:ts=4:et:

# Generated at 2022-06-23 17:46:27.439819
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress function")
    def test_work():
        time.sleep(1)
    test_work()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:46:37.315191
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile

    @work_in_progress("Loading test file")
    def load_test_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving test file")
    def save_test_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with tempfile.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, "test")
        data = {
            "lorem": "ipsum",
            "dolor": "sit",
            "amet": "consectetur",
            "adipiscing": "elit",
        }

# Generated at 2022-06-23 17:46:42.420684
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Running unit test")
    def _run_unit_test():
        pass

    _run_unit_test()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:46:44.000775
# Unit test for function work_in_progress
def test_work_in_progress():
    def foo(num):
        with work_in_progress():
            time.sleep(num)
    foo(1)

# Generated at 2022-06-23 17:46:46.938808
# Unit test for function work_in_progress
def test_work_in_progress():
    def test_func():
        time.sleep(1)
    with work_in_progress("Test"): test_func()

# Generated at 2022-06-23 17:46:58.065631
# Unit test for function work_in_progress
def test_work_in_progress():
    import subprocess
    import os.path
    import shutil
    import tempfile

    workspace = tempfile.mkdtemp(suffix="_work_in_progress")

# Generated at 2022-06-23 17:47:06.506474
# Unit test for function work_in_progress
def test_work_in_progress():
    # Create file to load
    t = time.time()
    with open("tmp_progress.pkl", "wb") as f:
        pickle.dump(t, f)

    # Test the progress func
    with work_in_progress("Loading file"):
        with open("tmp_progress.pkl", "rb") as f:
            t_ = pickle.load(f)
    assert(t == t_)

    # Create file to save
    with work_in_progress("Saving file"):
        wi

# Generated at 2022-06-23 17:47:10.436254
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Work in progress"):
        time.sleep(1)
# Unit test end

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:47:20.965532
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as d:
        path = d + "/file"
        with open(path, "wb") as f:
            # Save some object to disk so that loading it
            # takes a bit of time.
            pickle.dump(range(1000000), f)
        @work_in_progress("Loading file")
        def load_file(path):
            with open(path, "rb") as f:
                return pickle.load(f)
        with work_in_progress("Saving file"):
            with open(path, "wb") as f:
                pickle.dump(range(1000000), f)
        obj = load_file(path)
        assert obj == list(range(1000000))

# Generated at 2022-06-23 17:47:33.055666
# Unit test for function work_in_progress
def test_work_in_progress():
    # Wrapping a function
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # Wrapping a code block
    with work_in_progress("Creating file"):
        with open("/tmp/test_wip.temp", "wb") as f:
            pickle.dump({"foo": [1, 2, 3], "bar": [4, 5, 6]}, f)

    # Load the file back
    dct = load_file("/tmp/test_wip.temp")
    assert dct["foo"] == [1, 2, 3]
    assert dct["bar"] == [4, 5, 6]

# Generated at 2022-06-23 17:47:36.437982
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Task"):
        time.sleep(1)

# Run the unit test
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:47:39.344338
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test work_in_progress")
    def test_func():
        time.sleep(1)
    test_func()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:47:41.723186
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(1) # Sleep for one second

# Generated at 2022-06-23 17:47:43.490802
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(0.1)

# Generated at 2022-06-23 17:47:46.693688
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:47:54.198258
# Unit test for function work_in_progress
def test_work_in_progress():
    from time import sleep

    @work_in_progress("Test 1")
    def test_1():
        sleep(0.5)
        print('-> done')
        return 1

    @work_in_progress("Test 2")
    def test_2():
        sleep(0.7)
        print('-> done')
        return 1

    with work_in_progress("Test 3"):
        sleep(0.2)
        print('-> done')

    # test_1()
    # test_2()
    # test_3()

    sleep(1)
    print('\nall tests passed...')

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:47:57.205761
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("sleeping"):
        time.sleep(2.341)
    with work_in_progress():
        time.sleep(3.421)
if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:48:05.559739
# Unit test for function work_in_progress
def test_work_in_progress():
    import json

    class JsonDumper:
        @work_in_progress("Loading JSON file")
        def dump(self, json_file, content):
            with open(json_file, "w") as f:
                json.dump(content, f)

        @work_in_progress("Loading JSON file")
        def load(self, json_file):
            with open(json_file, "r") as f:
                return json.load(f)

    content = {
        "name": "Foo",
        "email": "foo@bar.com",
    }

    with work_in_progress("Saving JSON file"):
        with open("content.json", "w") as f:
            json.dump(content, f)

    print("Load JSON file")
    print("==============")

# Generated at 2022-06-23 17:48:12.783527
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import os
    path = os.path.join(os.path.dirname(__file__), "test.dat")
    with open(path, "wb") as f:
        pickle.dump([i for i in range(1000000)], f)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file(path)
    assert obj == [i for i in range(1000000)]

    del obj

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump([i for i in range(1000000)], f)

    os.remove(path)

# Generated at 2022-06-23 17:48:19.220556
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert isinstance(obj, int)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj + 1, f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:48:30.326866
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time

# Generated at 2022-06-23 17:48:36.278376
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test function work_in_progress."""

    def foo():
        """A dummy function."""
        time.sleep(1)

    print("Testing function work_in_progress()")

    with work_in_progress("Dummy task 1"):
        time.sleep(1)
    assert True

    with work_in_progress("Dummy task 2"):
        foo()
    assert True

# Generated at 2022-06-23 17:48:39.690162
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("This is a test") as w:
        time.sleep(2)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:48:43.980988
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test context manager
    with work_in_progress("Testing"):
        time.sleep(1)

    # Test as decorator
    @work_in_progress()
    def _empty_function():
        pass

    _empty_function()

# Generated at 2022-06-23 17:48:46.526533
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing"):
        time.sleep(.001)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:48:54.257914
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    assert load_file(__file__) is not None
    assert True
    with work_in_progress("Saving file"):
        obj = load_file(__file__)
        with open(__file__+".pickle", "wb") as f:
            pickle.dump(obj, f)


# Generated at 2022-06-23 17:48:59.713500
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            data = pickle.load(f)
        return data

    assert load_file(__file__)

if __name__ == "__main__":
    import doctest

    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-23 17:49:04.956465
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        print("Loaded")
    with work_in_progress("Saving file"):
        print("Saved")
    with work_in_progress():
        print("Done")


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-23 17:49:12.425754
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:18.700324
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""The function work_in_progress uses print and time, it's not easy to test
    but here is a simple example that checks its docstring.

    .. code:: python

        >>> with open("test_work_in_progress", "w") as f:
        ...     print("mock_data", file=f)
        ...
        >>> with work_in_progress("Test"), open("test_work_in_progress", "r") as f:
        ...     mock_data = f.read()
        ...
        Test... done. (0.00s)

    """
    assert True

# Generated at 2022-06-23 17:49:29.227935
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unittest for the ``work_in_progress`` context manager."""

    import time
    import pickle

    # Test with a function
    def load_file(path):
        """Load a binary Python object from a file."""
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Loading file") as _:
        time.sleep(0.1)

    obj = load_file("/path/to/some/file")

    # Test with a context manager
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:49:30.478476
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test function"):
        time.sleep(1)

# Generated at 2022-06-23 17:49:39.890417
# Unit test for function work_in_progress
def test_work_in_progress():
    import io

    begin_time = time.time()
    time.sleep(1)
    assert io.StringIO() == io.StringIO()
    with io.StringIO() as p1:
        with io.StringIO() as p2:
            time.sleep(1)
            assert p1 != p2
            time.sleep(1)
            p1.write("Hello,")
            time.sleep(1)
            p2.write("World!")
    print(p1)
    assert p1 is not None
    assert p2 is not None
    assert str(p1) == "Hello,"
    assert str(p2) == "World!"
    assert time.time() - begin_time >= 5

    with work_in_progress("Testing function") as w:
        time.sleep(1)

# Generated at 2022-06-23 17:49:51.367833
# Unit test for function work_in_progress
def test_work_in_progress():
    # Dummy function to be timed
    def time_consuming_function(sleep_time=1):
        time.sleep(sleep_time)

    with work_in_progress():
        time_consuming_function()
    with work_in_progress(desc=""):
        time_consuming_function()
    with work_in_progress(desc="No description"):
        time_consuming_function()
    with work_in_progress(desc="Some description"):
        time_consuming_function()
    with work_in_progress(desc="Some description with a long line"):
        time_consuming_function()
    with work_in_progress(desc="Some description with a long line " * 2):
        time_consuming_function()
    with work_in_progress(desc="A longer description"):
        time_consuming_function()


# Generated at 2022-06-23 17:49:53.083721
# Unit test for function work_in_progress

# Generated at 2022-06-23 17:49:59.377090
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for :func:`work_in_progress`"""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:50:04.116148
# Unit test for function work_in_progress
def test_work_in_progress():
    print(expect(
        work_in_progress,
        "Loading file",
        "Loading file... done. (0.00s)\n",
        lambda: time.sleep(0.01)
    ))
    print(expect(
        work_in_progress,
        "Saving file",
        "Saving file... done. (0.00s)\n",
        lambda: time.sleep(0.01)
    ))


# Generated at 2022-06-23 17:50:08.585490
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Executing some task")
    def long_task():
        time.sleep(1)

    long_task()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:50:09.020424
# Unit test for function work_in_progress
def test_work_in_progress():
    assert True

# Generated at 2022-06-23 17:50:10.758760
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(2)

# Generated at 2022-06-23 17:50:14.445399
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    @work_in_progress("Unit test for function work_in_progress")
    def test():
        time.sleep(0.01)
    test()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:50:15.672412
# Unit test for function work_in_progress
def test_work_in_progress():
    assert True # TODO: implement your test here


# Generated at 2022-06-23 17:50:22.110468
# Unit test for function work_in_progress
def test_work_in_progress():
    def f(n):
        with work_in_progress(f"Computing sum of 1 to {n}"):
            time.sleep(1)
            return sum(range(n + 1))

    assert f(1) == 1
    assert f(2) == 3

    with work_in_progress(f"Computing sum of 1 to {n}"):
        time.sleep(1)
        assert sum(range(n + 1)) == 3


# Generated at 2022-06-23 17:50:28.343062
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    data = load_file("data.bin")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:50:31.131603
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(1) # Just a placeholder code block for test

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:50:35.791305
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.01)
    with work_in_progress("Saving file"):
        time.sleep(0.01)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:50:46.963202
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file_with_wip(path: str):
        with work_in_progress(f"Loading {path}"):
            with open(path, "rb") as f:
                return pickle.load(f)

    def save_file_with_wip(obj, path: str):
        with work_in_progress(f"Saving {path}"):
            with open(path, "wb") as f:
                pickle.dump(obj, f)

    with tempfile.TemporaryDirectory() as tmp_dir:
        filename = os.path.join(tmp_dir, "obj")
        obj = range(10000000)
        save_file_with_wip(obj, filename)

        loaded_obj = load_file_with_wip(filename)
        assert(obj == loaded_obj)

# Generated at 2022-06-23 17:50:49.356974
# Unit test for function work_in_progress
def test_work_in_progress():
    pass

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:50:56.976359
# Unit test for function work_in_progress
def test_work_in_progress():
    from io import BytesIO
    from random import randint
    from time import sleep
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Dumping file")
    def dump_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = {str(i): randint(0, 10000) for i in range(50)}
    buffer = BytesIO()

    with work_in_progress("Saving object"):
        dump_file(obj, buffer)

    sleep(1)

    with work_in_progress("Loading object"):
        buffer.seek(0)

# Generated at 2022-06-23 17:51:01.634533
# Unit test for function work_in_progress
def test_work_in_progress():
    def test_function(timeout=1):
        with work_in_progress("Testing work_in_progress"):
            time.sleep(timeout)
    test_function()
    repr(test_function)
    repr(work_in_progress("foo"))



# Generated at 2022-06-23 17:51:08.345086
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path: str):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "./tests/test_data/test.pickle"
    obj = load_file(path)
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:11.149174
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("test"):
        time.sleep(0.5)


# Generated at 2022-06-23 17:51:16.040732
# Unit test for function work_in_progress
def test_work_in_progress():
    def test_func(t):
        with work_in_progress("Inner loop"):
            time.sleep(t)

    with work_in_progress("Outer loop"):
        for t in (1.5, 1.4, 0.5):
            test_func(t)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:51:21.644606
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test as context manager
    with work_in_progress("Checking file"):
        time.sleep(2)
        # Checking file... done. (2.00s)

    # Test as decorator
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(3)
        # Loading file... done. (3.00s)
        return path

    load_file('/')


# Generated at 2022-06-23 17:51:24.568848
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.5)

# vim: ts=8 sts=4 sw=4 et:

# Generated at 2022-06-23 17:51:33.995464
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test function work_in_progress.

    .. code:: python

        >>> test_work_in_progress()
        Saving file... done. (0.00s)
        Loading file... done. (0.00s)
    """
    @work_in_progress("Saving file")
    def save_file(path: str, obj: object):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    @work_in_progress("Loading file")
    def load_file(path: str):
        with open(path, "rb") as f:
            return pickle.load(f)

    import tempfile
    _, p = tempfile.mkstemp()
    obj = (1, 2, 3)
    save_file(p, obj)

# Generated at 2022-06-23 17:51:37.344135
# Unit test for function work_in_progress
def test_work_in_progress():
    for i in range(5):
        with work_in_progress("Calling function"):
            time.sleep(2.34)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:46.945526
# Unit test for function work_in_progress
def test_work_in_progress():
    d = {1: 2}

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(d, f)

    obj = load_file("/path/to/some/file")
    save_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(d, f)

# Generated at 2022-06-23 17:51:48.466053
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Test") as x:
        time.sleep(1)

# Generated at 2022-06-23 17:51:54.785115
# Unit test for function work_in_progress
def test_work_in_progress():
    class Testing:
        """Testing.

        :param freq: Frequency of the sound.
        :param duration: Duration of the sound in seconds.
        :param amplitude: Amplitude of the sound.
        :param sample_rate: Sample rate for the output
        """

        def __init__(self, freq, duration, amplitude, sample_rate):
            self.freq = freq
            self.duration = duration
            self.amplitude = amplitude
            self.sample_rate = sample_rate
            self.sound = []
            self.time = []
            self.sample_rate_range = range(sample_rate)
            self.sample_rate_duration_range = range(sample_rate * duration)

            # generate data
            with work_in_progress("Generating data"):
                self.generate_data()

            #

# Generated at 2022-06-23 17:52:00.268990
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import functools

    @work_in_progress("Test")
    def test():
        time.sleep(1.)

    with work_in_progress("Multiply"):
        functools.reduce(lambda a, b: a*b, range(1, 100000))

# Generated at 2022-06-23 17:52:03.806229
# Unit test for function work_in_progress
def test_work_in_progress():
    obj = None
    path = os.path.realpath(__file__)
    with work_in_progress("Test"):
        with open(path, 'rb') as f:
            obj = pickle.load(f) # noqa
    assert obj is not None

# Generated at 2022-06-23 17:52:05.729778
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(5.5)

# Generated at 2022-06-23 17:52:08.837392
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Long task"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:12.318671
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("utils/test.dat")
    assert obj == "Hello world!"

# Generated at 2022-06-23 17:52:20.046298
# Unit test for function work_in_progress
def test_work_in_progress():
    import os

    @work_in_progress("Creating the file")
    def create_file_with_numbers(path, num_entries):
        with open(path, mode="w+") as f:
            for i in range(num_entries):
                f.write(str(i) + '\n')

    @work_in_progress("Reading the file")
    def read_file(path):
        with open(path) as f:
            num_lines = 0
            for line in f:
                num_lines += 1
            return num_lines

    @work_in_progress("Counting the lines in the file")
    def count_lines_in_file(path):
        with open(path) as f:
            return sum(1 for line in f)


# Generated at 2022-06-23 17:52:31.359595
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path: str) -> None:
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path: str) -> None:
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with work_in_progress("Loading file"):
        obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        save_file("/temp/file.pkl")

    @work_in_progress("Loading file")
    def load_file(path: str) -> None:
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")



# Generated at 2022-06-23 17:52:35.733574
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving test file"):
        for x in range(10000):
            assert x ** 4 == x ** 4


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:52:42.809126
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test the function :func:`pyhelpers.prettify.work_in_progress`."""
    print("\n# function work_in_progress")
    print(work_in_progress)
    print()

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

#    assert obj == 'random_list'

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

#    assert obj == 'random_list'


# Unit test: if this file is run as a script


# Generated at 2022-06-23 17:52:48.435253
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit tests for function work_in_progress."""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")


    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    pass

# Generated at 2022-06-23 17:52:53.506354
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "./test.pkl"
    d = {'a': 1, 'b': [1, 2, 3]}
    with open(path, 'wb') as f:
        pickle.dump(d, f)

    obj = load_file(path)
    assert d == obj

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:53:00.012188
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("The first example")
    def example_1():
        time.sleep(1)
        return True

    with work_in_progress("The second example"):
        example_2 = True
        time.sleep(0.5)
    
    assert example_1() == example_2

if __name__ == "__main__":
    test_work_in_progress()