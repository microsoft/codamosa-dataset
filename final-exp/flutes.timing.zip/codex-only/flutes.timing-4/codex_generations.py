

# Generated at 2022-06-23 17:43:07.486599
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Unit test for function work_in_progress"):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:43:12.020345
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Counting to 10"):
        time.sleep(0.01)
        for i in range(11):
            time.sleep(0.01)
    print()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:43:19.147803
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/Users/ben/Downloads/yelp_dataset")

    with work_in_progress("Saving file"):
        with open("/Users/ben/Downloads/yelp_dataset_copy", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:43:29.286990
# Unit test for function work_in_progress
def test_work_in_progress():
    # noinspection PyStatementEffect
    """Unit test for function work_in_progress."""
    import pickle

    def load_file(path):
        """Example function that is timed on loading a file."""
        with work_in_progress("Loading file"):
            with open(path, "rb") as f:
                return pickle.load(f)

    def save_file(path, obj):
        """Example function that is timed on saving a file."""
        with work_in_progress("Saving file"):
            with open(path, "wb") as f:
                pickle.dump(obj, f)

    with tempfile.TemporaryDirectory() as tmpdir:
        # Load regular Python object
        obj = load_file(__file__)
        # Save regular Python object

# Generated at 2022-06-23 17:43:33.071580
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress
    def some_func():
        print('some_func')
        time.sleep(0.5)

    some_func()

# Generated at 2022-06-23 17:43:36.435904
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Function `work_in_progress` tests"
    with work_in_progress(desc=desc) as _:
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:43:45.916195
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    from tempfile import NamedTemporaryFile

    test_pickle = pickle.dumps({"a": 1, "b": 2})
    with NamedTemporaryFile() as tmpf:
        path = tmpf.name
        with work_in_progress("Saving file"):
            with open(path, "wb") as f:
                pickle.dump(test_pickle, f)

        with work_in_progress("Loading file"):
            with open(path, "rb") as f:
                loaded = pickle.load(f)

        assert loaded == test_pickle


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:43:49.002984
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Working hard but not too much")
    def load():
        time.sleep(1)
        return "zzz"

    assert load() == "zzz"
    with work_in_progress("Doing it faster"):
        time.sleep(0.1)

# Generated at 2022-06-23 17:43:53.784062
# Unit test for function work_in_progress
def test_work_in_progress():

    class Foo:
        pass

    foo = Foo()
    foo.bar = "Hello World!"
    foo.baz = 3.14159
    foo.qux = 42

    with work_in_progress("Serializing Foo object"):
        with open("foo.pickle", "wb") as f:
            pickle.dump(foo, f)

    with work_in_progress("Loading Foo object"):
        with open("foo.pickle", "rb") as f:
            foo = pickle.load(f)

    assert(isinstance(foo, Foo))
    assert(foo.bar == "Hello World!")
    assert(foo.baz == 3.14159)
    assert(foo.qux == 42)

# Generated at 2022-06-23 17:44:02.084576
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile
    path = tempfile.mktemp()
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(list(range(1000000)), f)
    with work_in_progress("Loading file"):
        with open(path, "rb") as f:
            obj = pickle.load(f)
    assert obj == list(range(1000000))
    print("All tests passed!")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:44:14.199340
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test as context manager
    with work_in_progress("Test context"):
        print("In context")

    # Test as decorator
    @work_in_progress("Test decorator")
    def decorated_function():
        print("In decorator")

    decorated_function()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:44:15.744038
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Working..."):
        time.sleep(0.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:44:18.152917
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing")
    def test_func():
        time.sleep(1.1)
    test_func()

# Generated at 2022-06-23 17:44:22.252875
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(2)
    with work_in_progress():
        time.sleep(0.5)
    print("done.")

# Generated at 2022-06-23 17:44:24.764381
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing function"):
        time.sleep(0.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:44:32.404458
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import time
    import tempfile
    import datetime
    import numpy as np

    tmppath = tempfile.mktemp()
    with work_in_progress("Creating temporary file"):
        n = int(7e6)
        a = np.random.rand(n, n)
        b = np.random.rand(n, n)
        c = np.dot(a, b)
        print(c)
        assert c.shape == (n, n)

    with work_in_progress("Saving to temporary file"):
        with open(tmppath, "wb") as f:
            pickle.dump(c, f)

    with work_in_progress("Loading from temporary file"):
        with open(tmppath, "rb") as f:
            c_loaded = pick

# Generated at 2022-06-23 17:44:37.806250
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test 1"):
        time.sleep(2)
    with work_in_progress("Test 2"):
        time.sleep(1)
    with work_in_progress("Test 3"):
        time.sleep(3)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:44:42.156984
# Unit test for function work_in_progress
def test_work_in_progress():
    def _slow_function(min_delay: float, max_delay: float):
        import random
        delay_sec = min_delay + random.random() * (max_delay - min_delay)
        time.sleep(delay_sec)

    for _ in range(10):
        with work_in_progress("Testing..."):
            _slow_function(1, 2)

# Generated at 2022-06-23 17:44:51.960380
# Unit test for function work_in_progress
def test_work_in_progress():
    from unittest import TestCase, main

    class TestWorkInProgress(TestCase):
        def test_with(self):
            global g
            with work_in_progress("Counting to ten"):
                for i in range(10):
                    time.sleep(0.1)
            with self.assertRaises(NameError):
                print(g) # This should raise a NameError

        def test_decorator(self):
            @work_in_progress("Counting to ten")
            def foo():
                for i in range(10):
                    time.sleep(0.1)
            foo()

    main()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:44:54.556497
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(5)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:45:02.311639
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert isinstance(obj, str)

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump("Hello world!", f)



# Generated at 2022-06-23 17:45:05.732746
# Unit test for function work_in_progress
def test_work_in_progress():
    def foo1():
        with work_in_progress("foo1"):
            time.sleep(2)
        with work_in_progress("foo2"):
            time.sleep(1.5)
    foo1()


# Generated at 2022-06-23 17:45:08.925147
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Working"):
        time.sleep(0.1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:45:14.915200
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("test.pkl")
    with work_in_progress("Saving file"):
        with open("test.pkl", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:45:21.901319
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert os.path.exists("/path/to/some/file")
    assert isinstance(obj, dict)

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)
    assert os.path.exists("/path/to/some/file")

# Generated at 2022-06-23 17:45:30.234020
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert True

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)
    assert True

# Generated at 2022-06-23 17:45:39.985349
# Unit test for function work_in_progress
def test_work_in_progress():
    import contextlib
    import io
    import sys

    @contextlib.contextmanager
    def captured_output():
        """Temporarily capture the stdout and stderr.

        Returns:
            A tuple of `(sys.stdout, sys.stderr)`
        """
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err
    

# Generated at 2022-06-23 17:45:43.607226
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(1)

# ## Unit tests
if __name__ == '__main__':
    # Unit test for function work_in_progress
    test_work_in_progress()

# Generated at 2022-06-23 17:45:53.195827
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    load_file("test_pickle.pkl")

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    save_file("test_pickle.pkl")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:46:03.228837
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")
    time.sleep(2)
    save_file("/path/to/some/file", obj)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:46:09.333464
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test for a function
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert obj is not None

    # Test for a code block
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:46:13.641656
# Unit test for function work_in_progress
def test_work_in_progress():
    from modules.utils.tqdm_utils import tqdm_ctx
    with tqdm_ctx():
        with work_in_progress("Testing work_in_progress"):
            time.sleep(1)
            pass
    print("\n")

# Generated at 2022-06-23 17:46:15.561419
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1.5)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:46:21.546294
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:46:30.388678
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test function work_in_progress"""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    return True

if __name__ == "__main__":
    import doctest
    doctest.testmod()
    print(test_work_in_progress())

# Generated at 2022-06-23 17:46:33.124625
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress(desc="Testing work_in_progress"):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:46:44.662371
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.5)
    with work_in_progress(desc="Saving file"):
        time.sleep(1.5)
    #
    from typing import List, NamedTuple
    class Point(NamedTuple):
        x: float
        y: float
    def get_points():
        return [Point(x=x, y=x*x) for x in range(0, 1000)]
    with work_in_progress(desc="Generating points"):
        points = get_points()
    with work_in_progress(desc="Drawing graph"):
        import matplotlib.pyplot as plt
        xs = [point.x for point in points]
        ys = [point.y for point in points]
        plt.plot

# Generated at 2022-06-23 17:46:50.947285
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:46:55.710664
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.5)


if __name__ == '__main__':
    if "-d" in sys.argv:
        import doctest
        doctest.testmod(optionflags=doctest.ELLIPSIS, verbose=True)

# Generated at 2022-06-23 17:46:59.386366
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("test_work_in_progress")
    def _test_work_in_progress():
        time.sleep(1)
    _test_work_in_progress()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:47:03.899888
# Unit test for function work_in_progress
def test_work_in_progress():
    origin = time.time()
    with work_in_progress():
        time.sleep(1)
    assert time.time() - origin > 1

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:47:15.400758
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import random
    import time

    def generate_file(path, size, delay=0.0):
        with open(path, 'wb') as f:
            with work_in_progress("Generating %d bytes file" % size):
                time.sleep(delay)
                f.write(os.urandom(size))

    def test_func(size, delay=0.0):
        tmpdir = tempfile.TemporaryDirectory()
        path = tmpdir.name + "/test.file"
        with work_in_progress("Generating file in temporary directory"):
            generate_file(path, size, delay)

    with work_in_progress("Test work_in_progress"):
        with work_in_progress("Testing with a delay"):
            test_func(10**6, 0.1)


# Generated at 2022-06-23 17:47:18.606669
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(0.5)


if __name__ == "__main__":
    # Test the function
    test_work_in_progress()

# Generated at 2022-06-23 17:47:24.487346
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path: str):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path: str, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with open("/tmp/test.pkl", "wb") as f:
        pickle.dump({"hello": "world",}, f)

    load_file("/tmp/test.pkl")

    save_file("/tmp/test.pkl", {"hello": "world"})


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:47:33.098441
# Unit test for function work_in_progress
def test_work_in_progress():
    import unittest.mock

    with unittest.mock.patch("builtins.print") as mock_print:
        with unittest.mock.patch("time.time", return_value=5):
            with work_in_progress("Description"):
                with unittest.mock.patch("time.time", return_value=15):
                    pass
    mock_print.assert_has_calls([
        unittest.mock.call("Description... ", end='', flush=True),
        unittest.mock.call("done. (10.00s)")
    ])

# Generated at 2022-06-23 17:47:41.468026
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import os
    import pickle
    from collections import OrderedDict

    from . import work_in_progress as wip
    from . import ensure_path_exists

    path = os.path.join("/tmp", "wip_test_vars.pkl")
    if os.path.exists(path):
        os.remove(path)
    ensure_path_exists(path)

    obj = OrderedDict([(i, i) for i in range(10)])
    desc = "Testing work_in_progress function"

    @wip(desc)
    def save_obj_to_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


# Generated at 2022-06-23 17:47:43.709683
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Work in progress"):
        time.sleep(1.5)

# Generated at 2022-06-23 17:47:49.497840
# Unit test for function work_in_progress
def test_work_in_progress():

    # test for context manager
    assert tuple(range(5)) == yield_with_time(range(5))
    assert tuple(range(5)) == yield_with_time(range(5))

    # test for function decorator
    assert tuple(range(5)) == yield_with_time_func(range(5))
    assert tuple(range(5)) == yield_with_time_func(range(5))



# Generated at 2022-06-23 17:47:56.256001
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    # Test the decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("test_work_in_progress.pickle")
    assert obj == [1, 2, 3]

    # Test the context manager
    with work_in_progress("Saving file"):
        with open("test_work_in_progress.pickle", "wb") as f:
            pickle.dump([1, 2, 3], f)

# Generated at 2022-06-23 17:47:59.944298
# Unit test for function work_in_progress
def test_work_in_progress():
    class MyException(Exception): pass
    try:
        with work_in_progress("Loading file"):
            raise MyException("Test exception")
    except MyException:
        pass
    try:
        @work_in_progress("Loading file")
        def load_file(path):
            raise MyException("Test exception")
        load_file("/path/to/some/file")
    except MyException:
        pass


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:48:10.252029
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import pickle

    obj = {
        "foo": "bar",
        "spam": "egg",
        "ham": "spam",
    }

    with tempfile.TemporaryDirectory() as tmpdir:
        filepath = tmpdir + "/test.pickle"

        # Test the context manager
        with work_in_progress(f"Saving file at {filepath}"):
            with open(filepath, "wb") as f:
                pickle.dump(obj, f)

        # Test the decorator
        @work_in_progress("Loading file")
        def load_file(path):
            with open(path, "rb") as f:
                return pickle.load(f)

        assert load_file(filepath) == obj



# Generated at 2022-06-23 17:48:15.574829
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress
    """
    with work_in_progress("Loading file"):
        pass

# Initiate unit test if the module is the main program
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:48:16.217536
# Unit test for function work_in_progress
def test_work_in_progress():
    pass

# Generated at 2022-06-23 17:48:18.329061
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("test"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:48:25.385351
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:48:28.127250
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress
    def foo():
        time.sleep(1.23)
    foo()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:48:35.758080
# Unit test for function work_in_progress
def test_work_in_progress():
    from pathlib import Path
    from random import randint
    from tempfile import gettempdir

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = Path(gettempdir()) / f"syncthing-{randint(0, pow(2, 32))}"
        obj = {"foo": "bar", "foobar": "foobar"}
        save_file(temp_path)

# Generated at 2022-06-23 17:48:47.871581
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import tempfile
    import pickle

    def load_file(path, desc="Load file"):
        with work_in_progress(desc):
            with open(path, "rb") as f:
                return pickle.load(f)

    def save_file(path, obj, desc="Save file"):
        with work_in_progress(desc):
            with open(path, "wb") as f:
                pickle.dump(obj, f)

    with tempfile.TemporaryDirectory() as tempdir:
        save_file(tempdir + "/some_file.pickle", "abcd")
        time.sleep(2)
        assert load_file(tempdir + "/some_file.pickle") == "abcd"


if __name__ == "__main__":
    test_work_in

# Generated at 2022-06-23 17:48:52.048591
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

# Generated at 2022-06-23 17:48:56.264748
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.1)
        load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        save_file("/path/to/some/file")

# Generated at 2022-06-23 17:48:58.983395
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(random.uniform(1, 5))


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:49:05.153305
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test first"):
        time.sleep(1)
    with work_in_progress("Test second"):
        time.sleep(1)
    @work_in_progress("Test third")
    def test():
        time.sleep(1)
        return 0
    test()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:08.135852
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(4)

    @work_in_progress("Saving file")
    def save_file():
        time.sleep(5)

    save_file()

# Generated at 2022-06-23 17:49:11.427498
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("test"):
        time.sleep(1)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:49:20.382014
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    # Creating files for testing
    data_dir = "./tmp"
    if not os.path.exists(data_dir):
        os.makedirs(data_dir)

    # Test saving file
    array = np.random.rand(10, 10, 10)
    array_path = os.path.join(data_dir, "test_array.npy")
    save_file(array_path, array)

    # Test loading file

# Generated at 2022-06-23 17:49:24.022291
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3)
    with work_in_progress("Saving file"):
        time.sleep(3.5)

# Generated at 2022-06-23 17:49:27.658586
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(2)


# Execute a doctest if the module is run as a script.
if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:49:30.731906
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Calling the function")
    def foo():
        time.sleep(0.3)
    assert foo() is None

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:34.240281
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Sleeping for 2 seconds"):
        time.sleep(2)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:49:37.845342
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Creating a list"):
        lst = list(range(12345))
    with work_in_progress("Hashing the list"):
        lst_hash = hash(lst)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:48.401154
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test function work_in_progress."""

    import pickle
    import tempfile

    # Test for contextmanager
    with tempfile.TemporaryDirectory() as tmpdir:
        tmpfile = str(tmpdir) + "/test_data"
        obj = {'a': 10, 'b': 20}

        print()
        with work_in_progress("Saving data"):
            with open(tmpfile, "wb") as f:
                pickle.dump(obj, f)

        print()
        with work_in_progress("Loading data"):
            with open(tmpfile, "rb") as f:
                obj2 = pickle.load(f)
        assert obj == obj2

    # Test for decorator
    print()

# Generated at 2022-06-23 17:49:57.433610
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(1)
    with work_in_progress("Test"):
        time.sleep(1)
    print(iaspa.progress_bar())
    for i in iaspa.progress_bar(range(2), desc="foo", end="", verbose=False):
        time.sleep(0.5)
    print(iaspa.progress_bar(verbose=False))
    for i in iaspa.progress_bar(range(10), "Bar", unit_scale=True):
        time.sleep(0.1)


# Generated at 2022-06-23 17:50:05.560429
# Unit test for function work_in_progress
def test_work_in_progress():
    from os import remove
    from os.path import exists
    from tempfile import gettempdir
    from random import randint
    from shutil import rmtree, copytree

    with work_in_progress("Removing files"):
        if exists("temp"):
            remove("temp")
        rmtree("temp", ignore_errors=True)

    with work_in_progress("Creating files"):
        with open("temp", "w") as f:
            for i in range(10000):
                f.write("\nSome words" + str(i))

    with work_in_progress("Copying files"):
        copytree("temp", "test_work_in_progress")

    with work_in_progress("Deleting files"):
        remove("temp")

# Generated at 2022-06-23 17:50:15.356390
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test 1: Test the case when the task performed is a function
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    # Load file... done. (3.52s)

    # Test 2: Test the case when the task performed is within a code block
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    # Saving file... done. (3.78s)

# Run the unit test:
# test_work_in_progress()

# Generated at 2022-06-23 17:50:17.796636
# Unit test for function work_in_progress
def test_work_in_progress():
    import doctest
    doctest.testmod(extraglobs={
        "work_in_progress": work_in_progress
    })

# Generated at 2022-06-23 17:50:26.344474
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile
    import time
    with tempfile.NamedTemporaryFile("wb+", delete=False) as f:
        obj = list(range(10000))
        pickle.dump(obj, f)
    with work_in_progress("Loading file"):
        with open(f.name, "rb") as f:
            assert pickle.load(f) == obj
    with work_in_progress("Saving file"):
        with open(f.name, "wb") as f:
            pickle.dump(obj, f)
    os.unlink(f.name)

# Generated at 2022-06-23 17:50:34.477932
# Unit test for function work_in_progress
def test_work_in_progress():
    callable_test = [
        (0.005, "Callable test 1", "Callable test 1 ... done. (0.01s)"),
        (0.0025, "Callable test 2", "Callable test 2 ... done. (0.00s)"),
    ]
    for expected_time, desc, expected_output in callable_test:
        @work_in_progress(desc)
        def callable_test():
            time.sleep(expected_time)
            return True
        output_capture = StringIO()
        with redirect_stdout(output_capture):
            callable_test()
            assert output_capture.getvalue().strip() == expected_output

# Generated at 2022-06-23 17:50:44.656289
# Unit test for function work_in_progress
def test_work_in_progress():
    import uuid
    @work_in_progress("Generating a random word")
    def random_word():
        random.uniform(0, 1)
        return uuid.uuid4()

    @work_in_progress("Generating random words")
    def random_words():
        words = []
        for _ in range(1000):
            words.append(random_word())
        return words

    random_words()
    # Generating random words...
    # Generating a random word... done. (0.00s)
    # Generating a random word... done. (0.00s)
    # ...
    # Generating a random word... done. (0.00s)
    # Generating random words... done. (0.34s)

# Generated at 2022-06-23 17:50:51.673423
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:50:53.672283
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(3.53)
    with work_in_progress("Loading file"):
        time.sleep(3.79)

# Generated at 2022-06-23 17:50:57.328370
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Doing stuff"):
        time.sleep(1)
        with work_in_progress("Nested stuff"):
            time.sleep(1)

    # with work_in_progress("Doing stuff"):
    #    assert False
    #    time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:05.877235
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile

    temp_dir = tempfile.TemporaryDirectory()
    path = os.path.join(temp_dir.name, "test.bin")

    with work_in_progress("Creating test file"):
        with open(path, "wb") as f:
            f.write(b"\x01\x02\x03\x04")

    with work_in_progress("Removing test file"):
        os.remove(path)

    temp_dir.cleanup()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:16.369932
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test function work_in_progress.
    """
    # Test case 1: function decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file(os.path.join(os.path.dirname(__file__), "test_data", "fibonacci.pickle"))
    assert obj == [0, 1, 1, 2, 3, 5, 8]
    # Test case 2: context manager

# Generated at 2022-06-23 17:51:21.059324
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:32.040448
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress."""
    from tempfile import TemporaryDirectory
    from itertools import repeat, chain
    from random import sample, randint

    # Use a temporary directory to avoid polluting the filesystem.
    with TemporaryDirectory() as tmpdir:
        # Generate a random filename to save the file
        filename = os.path.join(tmpdir, "example")
        # Generate a sample of random data.
        data = sample(range(10000), randint(1000, 10000))

        # Save the data to the file.
        with work_in_progress("Saving data"):
            with open(filename, "wb") as f:
                pickle.dump(data, f)

        # Load the data from the file.

# Generated at 2022-06-23 17:51:39.005459
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("test/test.pkl")

    with work_in_progress("Saving file"):
        with open("test/test_out.pkl", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:51:42.575254
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1.0)
    with work_in_progress("Saving file"):
        time.sleep(2.0)
    with work_in_progress("Printing something"):
        time.sleep(2.0)

# Generated at 2022-06-23 17:51:46.168967
# Unit test for function work_in_progress
def test_work_in_progress():
    try:
        raise NotImplementedError
    except Exception:
        pass
    return
    @work_in_progress()
    def test():
        time.sleep(1)
    test()
    time.sleep(2)

# Generated at 2022-06-23 17:51:50.187662
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)

    @work_in_progress("Saving file")
    def save_file_to_disk():
        time.sleep(1)
    save_file_to_disk()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:01.402023
# Unit test for function work_in_progress
def test_work_in_progress():
    def _test_wip(verbose=False):
        @work_in_progress("Loading file")
        def load_file(path):
            with open(path, "rb") as f:
                return pickle.load(f)

        with work_in_progress("Saving file"):
            with open(path, "wb") as f:
                pickle.dump(obj, f)

    import sys
    import os.path
    import unittest

    class WorkInProgressTest(unittest.TestCase):
        def test_work_in_progress(self):
            _test_wip(verbose=True)

    if __name__ == "__main__":
        if len(sys.argv) > 1:
            cache_dir = sys.argv[1]
        else:
            cache_dir

# Generated at 2022-06-23 17:52:05.069118
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test work_in_progress"):
        time.sleep(0.05)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:52:08.198706
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Some working progress")
    def long_task():
        time.sleep(2)
        return "some result"

    result = long_task()
    assert result == "some result"
    assert result is not None

# Generated at 2022-06-23 17:52:18.520950
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "/tmp/test_work_in_progress.pickle"
    with open(path, 'wb') as f:
        pickle.dump(list(range(10000)), f)

    t0 = time.time()
    obj = load_file(path)
    assert obj == list(range(10000))
    t1 = time.time()
    print(f"Loading file...")
    assert 1 > t1 - t0 > 0.5

    with work_in_progress("Loading file") as _:
        with open(path, "rb") as f:
            obj = pickle.load(f)
    assert obj

# Generated at 2022-06-23 17:52:26.951242
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("../assets/example/example.pkl")

    with work_in_progress("Saving file"):
        with open("../assets/example/example.pkl", "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:31.992620
# Unit test for function work_in_progress

# Generated at 2022-06-23 17:52:37.452892
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test working without description
    with work_in_progress():
        time.sleep(1)

    # Test working with description
    with work_in_progress("Doing something"):
        pass

    # Test working as a decorator
    @work_in_progress("Doing something")
    def do_something():
        pass

    do_something()

# Generated at 2022-06-23 17:52:43.653701
# Unit test for function work_in_progress
def test_work_in_progress():
    print('''

    def sum_of_n(n):
        start = time.time()

        the_sum = 0
        for i in range(1, n+1):
            the_sum = the_sum + i

        end = time.time()

        return the_sum, end-start


    for i in range(5):
        print(f"Sum is {sum_of_n(10000)[0]} required {sum_of_n(10000)[1]}")

    ### with work_in_progress()
    with work_in_progress("Calculating Sum"):
        sum_of_n(10000)
    ''')

    def sum_of_n(n):
        start = time.time()

        the_sum = 0
        for i in range(1, n+1):
            the_sum

# Generated at 2022-06-23 17:52:45.320677
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test in progress"):
        time.sleep(0.001)

# Generated at 2022-06-23 17:52:50.995143
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    path = "tmp.pickle"
    os.makedirs("/".join(path.split("/")[:-1]), exist_ok=True)  # ensure dir exists
    with open(path, "wb") as f:
        pickle.dump(np.random.rand(10000, 1000), f)
    with work_in_progress("Loading file"):
        with open(path, "rb") as f:
            obj = pickle.load(f)
    assert isinstance(obj, np.ndarray)
    os.remove(path)



# Generated at 2022-06-23 17:53:02.054662
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        with open("test.pkl", "rb") as f:
            pickle.load(f)

# ----------------------------------------------------------------------------------------------------------------------
# Test code

if __name__ == "__main__":
    import os
    import sys
    import pickle
    import doctest

    # generate test.pkl
    d = {
        "__name__": __name__,
        "__file__": __file__,
        "__doc__" : __doc__,
        "sys": sys
    }
    with open("test.pkl", "wb") as f:
        pickle.dump(d, f)

    # run doctest

# Generated at 2022-06-23 17:53:03.155073
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(2)

# Generated at 2022-06-23 17:53:06.837830
# Unit test for function work_in_progress
def test_work_in_progress():
    "Unit test for work_in_progress"
    with work_in_progress("Testing work_in_progress()"):
        time.sleep(0.5)