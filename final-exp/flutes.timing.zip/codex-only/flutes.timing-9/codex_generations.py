

# Generated at 2022-06-23 17:43:07.387663
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(0.3)

if __name__ == "__main__":
    with work_in_progress("Testing work_in_progress"):
        test_work_in_progress()

# Generated at 2022-06-23 17:43:09.831778
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sleeping for 2 seconds"):
        time.sleep(2)

# Generated at 2022-06-23 17:43:19.044547
# Unit test for function work_in_progress
def test_work_in_progress():
    # This test need to be integrated into the source code for being tested
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    del load_file
    # Re-define function to let garbage collector free the previous function
    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    save_file(obj, "/path/to/some/file")

# Generated at 2022-06-23 17:43:24.641379
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test 1")
    def test_1():
        time.sleep(2)

    with work_in_progress("Test 2"):
        time.sleep(2)

    test_1()
    try:
        test_1
    except Exception as e:
        print("Exception:", e)


# Generated at 2022-06-23 17:43:37.174399
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1.23)
    
    with work_in_progress("Saving file"):
        time.sleep(3.45)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")
    save_file("/path/to/some/file", obj)

# Generated at 2022-06-23 17:43:43.268821
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    
    obj = load_file("file.txt")
    with work_in_progress("Saving file"):
        with open("result.txt", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:43:49.938512
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Something")
    def f():
        time.sleep(1)
    f()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:43:53.807352
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving"):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:43:58.913519
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Doing something")
    def do_something(n):
        for i in range(10):
            time.sleep(n/10)

    with work_in_progress("Doing something else"):
        time.sleep(0.5)

    do_something(0.5)

# Generated at 2022-06-23 17:44:01.184547
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test progress"):
        time.sleep(0.5)
    assert True

# Unit tests for module core.progress

# Generated at 2022-06-23 17:44:08.034869
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import random

    with work_in_progress() as w:
        for _ in range(100000):
            r = random.random()
        time.sleep(0.1)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:44:18.530664
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import numpy as np

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return np.load(f)

    @work_in_progress("Slow process")
    def slow_process(n):
        return 2 ** n

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, 'wb') as f:
            np.save(f, obj)

    with open("/tmp/test.npy", "wb") as f:
        np.save(f, np.random.rand(500, 500))

    start = time.time()
    a = slow_process(50)
    a.shape

# Generated at 2022-06-23 17:44:26.857428
# Unit test for function work_in_progress
def test_work_in_progress():
    from StringIO import StringIO
    old_stdout = sys.stdout

    try:
        out = StringIO()
        sys.stdout = out

        with work_in_progress("This is a test") as w:
            print("I'm inside the with block")
            w.__exit__(None, None, None)  # Override to prevent error
        output = out.getvalue().strip()
        assert output == "This is a test... I'm inside the with block... done. (0.00s)"
    finally:
        sys.stdout = old_stdout

# Generated at 2022-06-23 17:44:39.701994
# Unit test for function work_in_progress
def test_work_in_progress():
    # Enable this test if pytest-trio is installed.
    import pytest
    @pytest.mark.trio
    async def test_work_in_progress_trio():
        begin_time = time.time()
        with work_in_progress("Work in progress"):
            await trio.sleep(1)
        time_consumed = time.time() - begin_time
        assert time_consumed > 0.9 and time_consumed < 1.1

        async def with_work_in_progress():
            with work_in_progress("Work in progress"):
                await trio.sleep(1)

        begin_time = time.time()
        await with_work_in_progress()
        time_consumed = time.time() - begin_time
        assert time_consumed > 0.9 and time_consumed

# Generated at 2022-06-23 17:44:43.745361
# Unit test for function work_in_progress
def test_work_in_progress():
    import random

    with work_in_progress("Making excuses"):
        with open("/usr/share/dict/words", "r") as f:
            all_words = f.read().splitlines()
        time.sleep(random.randint(1, 5))

    @work_in_progress("Scrambling eggs")
    def scramble_eggs():
        time.sleep(random.randint(1, 5))

    scramble_eggs()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:44:45.153441
# Unit test for function work_in_progress
def test_work_in_progress():
    assert False

# Generated at 2022-06-23 17:44:48.838406
# Unit test for function work_in_progress
def test_work_in_progress():

    # Should print counting number
    with work_in_progress("Counting number..."):
        for n in range(1, 100000):
            pass


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:44:54.274520
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with patch("sys.stdout", new=StringIO()) as actual_stdout:
        _ = load_file("tests/fixtures/pycharm.png")

    expected_stdout = dedent("""
    Loading file... done. (0.00s)
    """)

    assert actual_stdout.getvalue() == expected_stdout


# Generated at 2022-06-23 17:45:00.795805
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:45:08.225724
# Unit test for function work_in_progress
def test_work_in_progress():
    import os, sys, tempfile
    temp_file_path = os.path.join(tempfile.gettempdir(), "temp_file")
    print(f"Saving in temp file: {temp_file_path}")
    with open(temp_file_path, "w+") as tmp_f:
        with work_in_progress("Saving file"):
            tmp_f.write("File content.")
        if not os.path.exists(temp_file_path):
            print(f"File {temp_file_path} NOT ACTUALLY SAVED.")
            sys.exit(1)
    with open(temp_file_path, "r") as tmp_f:
        tmp_f_content = tmp_f.read()

# Generated at 2022-06-23 17:45:18.252036
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress"""
    import pickle
    import tempfile
    import os

    with work_in_progress("Writing file"):
        d = {"a": 1, "b": 2}
        with open("./tmp.pkl", "bw") as f:
            pickle.dump(d, f)
        os.remove("./tmp.pkl")
    output, err = capsys.readouterr()
    assert output == "Writing file... done. (0.10s)\n"

    d = {"a": 1.0, "b": 2.0}
    with tempfile.NamedTemporaryFile("bw", delete=False) as f:
        filename = f.name
        pickle.dump(d, f)

# Generated at 2022-06-23 17:45:21.908110
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    with work_in_progress("Saving file"):
        time.sleep(1)


if __name__ == "__main__":
    # Unit test for function work_in_progress
    test_work_in_progress()

# Generated at 2022-06-23 17:45:23.409175
# Unit test for function work_in_progress
def test_work_in_progress():
    pass

# Generated at 2022-06-23 17:45:26.938864
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import math
    with work_in_progress("Computing √2"):
        sqrt_2 = math.sqrt(2)
    time.sleep(3)

# Generated at 2022-06-23 17:45:29.882871
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test work in progress"):
        time.sleep(0.1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:45:36.875663
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test function work_in_progress."""

    @work_in_progress("Work in progress")
    def test():
        time.sleep(3)

    # Capture stdout for unit test
    import io
    import sys
    captured_stdout = io.StringIO()
    sys.stdout = captured_stdout
    test()
    sys.stdout = sys.__stdout__
    assert captured_stdout.getvalue().strip().endswith("done. (3.00s)")

# Generated at 2022-06-23 17:45:44.670128
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading test file")
    def load_test_file(path):
        time.sleep(3)
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving test file"):
        time.sleep(3)
        with open("/tmp/test.pickle", "wb") as f:
            pickle.dump("test", f)

    print(load_test_file("/tmp/test.pickle"))

# Generated at 2022-06-23 17:45:46.545750
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test")
    def func():
        time.sleep(1)
    func()


# Jupyter extension

# Generated at 2022-06-23 17:45:49.273253
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test work_in_progress") as proc:
        time.sleep(0.2)


# Unit test of this module
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:45:51.080627
# Unit test for function work_in_progress
def test_work_in_progress():
    pass

# Test the module
if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:45:58.449134
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for module level function work_in_progress."""
    import os

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file(os.path.expanduser('~/Downloads/test_100.pkl'))

    with work_in_progress("Saving file"):
        with open(os.path.expanduser('~/Downloads/test_101.pkl'), "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:45:59.681905
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Calculating pi"):
        time.sleep(5)

# Generated at 2022-06-23 17:46:03.599278
# Unit test for function work_in_progress
def test_work_in_progress():
    from .compat import suppress

    def f():
        time.sleep(0.5)

    def f2():
        with work_in_progress():
            time.sleep(0.5)

    with suppress(Exception):
        with work_in_progress():
            f()
    with suppress(Exception):
        f2()

# Generated at 2022-06-23 17:46:08.572721
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

test_work_in_progress()

# Generated at 2022-06-23 17:46:10.367355
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import sys

    with work_in_progress("Counting time"):
        time.sleep(1)

# Generated at 2022-06-23 17:46:19.607171
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test working in progress with a context manager
    t0 = time.time()
    with work_in_progress("Started"):
        time.sleep(0.5)
    assert time.time() - t0 > 0.5

    # Test working in progress with a decorator
    def test_decorator():
        time.sleep(0.5)
    t0 = time.time()
    test_decorator = work_in_progress("Started")(test_decorator)
    test_decorator()
    assert time.time() - t0 > 0.5

# Generated at 2022-06-23 17:46:22.512233
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    def w():
        time.sleep(3)

    with work_in_progress("Test"):
        w()


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:46:28.331452
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""
    .. code:: python

        >>> import time
        >>> with work_in_progress("Creating a list"):
        ...     time.sleep(1.38)
        ...     x = [0] * 10
        Creating a list... done. (1.38s)

        >>> def func():
        ...     with work_in_progress("Creating a list"):
        ...         time.sleep(1.38)
        ...         x = [0] * 10
        ...
        >>> func()
        Creating a list... done. (1.38s)
    """

# Generated at 2022-06-23 17:46:31.414466
# Unit test for function work_in_progress
def test_work_in_progress():
    pass


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-23 17:46:38.465413
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:46:41.605632
# Unit test for function work_in_progress
def test_work_in_progress():
    from pathlib import Path

    path = Path("/tmp/some-file")
    with work_in_progress(f"Saving file to '{path}'"):
        path.touch()
    path.unlink()

# Generated at 2022-06-23 17:46:44.193245
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Waiting for 1000000 seconds"):
        time.sleep(1000000)

if __name__ == "__main__":
    test_work_in_progress()
    pass

# Generated at 2022-06-23 17:46:48.208118
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def f():
        time.sleep(1)
    f()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:46:53.547828
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("test_work_in_progress")


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:46:56.632774
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# endregion

# Generated at 2022-06-23 17:46:59.511681
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Work in progress"):
        time.sleep(0.5)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:47:01.897750
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import random
    with work_in_progress("Saving file"):
        time.sleep(random.uniform(1, 3))

# Generated at 2022-06-23 17:47:05.988994
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Work in progress") as _:
        time.sleep(0.1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:47:07.817300
# Unit test for function work_in_progress
def test_work_in_progress():
    print()
    with work_in_progress("Hello"):
        time.sleep(1.15)

# Generated at 2022-06-23 17:47:12.504457
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test function context manager
    with work_in_progress("Loading file"):
        time.sleep(1.234)
    # Test function decorator
    @work_in_progress("Saving file")
    def save_file():
        time.sleep(0.567)

    save_file()

# Generated at 2022-06-23 17:47:14.894433
# Unit test for function work_in_progress
def test_work_in_progress():
    def func():
        time.sleep(0.01)

    with work_in_progress():
        func()

# Generated at 2022-06-23 17:47:21.678723
# Unit test for function work_in_progress
def test_work_in_progress():
    with open("/tmp/test_work_in_progress_file", 'wb') as f:
        pickle.dump(np.arange(10 ** 8), f)
    with work_in_progress("Loading file"):
        with open("/tmp/test_work_in_progress_file", 'rb') as f:
            pickle.load(f)
    time.sleep(3)
    with work_in_progress("Saving file"):
        time.sleep(4)
    os.remove("/tmp/test_work_in_progress_file")

# Generated at 2022-06-23 17:47:23.532190
# Unit test for function work_in_progress
def test_work_in_progress():
    # See the docstring of this function.
    pass

# Generated at 2022-06-23 17:47:34.670238
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import contextlib
    from contextlib import redirect_stdout

    with open('test.out', 'w') as f:
        with redirect_stdout(f):
            with work_in_progress("Saving file"):
                time.sleep(0.2)
            time.sleep(0.1)
            with work_in_progress():
                time.sleep(0.3)
            time.sleep(0.1)
            with work_in_progress("Doing something"):
                time.sleep(0.5)
            time.sleep(0.1)
    with open('test.out') as f:
        output = f.read().strip()

# Generated at 2022-06-23 17:47:38.610890
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with open(path, "wb") as f:
        pickle.dump(1, f)

    _ = load_file(path)

# Generated at 2022-06-23 17:47:50.126363
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    import matplotlib.pyplot as plt
    import pickle
    import pathlib
    import tempfile

    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_dir = pathlib.Path(tmp_dir)
        with work_in_progress("Loading file"):
            with open(tmp_dir / "large_file.pkl", "rb") as f:
                obj = pickle.load(f)
        with work_in_progress("Saving file"):
            with open(tmp_dir / "another_large_file.pkl", "wb") as f:
                pickle.dump(obj, f)
        out_image = tmp_dir / "image.png"
        with work_in_progress("Creating image"):
            plt.imshow(obj)
            plt

# Generated at 2022-06-23 17:47:58.821246
# Unit test for function work_in_progress
def test_work_in_progress():
    # set up
    import sys, os

    # case 1:
    def _case1():
        class A(object):
            def __init__(self):
                self.a = 1
                self.b = 2

        old_stdout = sys.stdout
        sys.stdout = open(os.devnull, 'w')
        with work_in_progress("Loading file"):
            a = A()
        sys.stdout = old_stdout

        assert(a.a == 1)
        assert(a.b == 2)

    # case 2:
    def _case2():
        def fcn(a):
            @work_in_progress("Loading file")
            def _fcn(b):
                c = a + b
                return c
            return _fcn


# Generated at 2022-06-23 17:48:07.625544
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1)
        return {"a": 1, "b": 2}

    def test_load_file():
        return load_file("/path/to/some/file")

    assert test_load_file() == {"a": 1, "b": 2}

    with work_in_progress("Saving file"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:48:16.388130
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")
    save_file("/path/to/some/file", obj)

# Generated at 2022-06-23 17:48:18.177318
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test work_in_progress")
    def do_nothing():
        time.sleep(0.1)
    do_nothing()

# Generated at 2022-06-23 17:48:23.004343
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file():
        time.sleep(2)
    load_file()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:48:28.788826
# Unit test for function work_in_progress
def test_work_in_progress():
    from tempfile import NamedTemporaryFile
    from pickle import dumps, loads
    from time import sleep

    @work_in_progress("Loading file")
    def load_file(path: str) -> str:
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(text: str, path: str):
        with open(path, "wb") as f:
            pickle.dump(text, f)

    with NamedTemporaryFile("wb") as f:
        save_file("Hello, world!", f.name)
        assert loads(open(f.name, "rb").read()) == "Hello, world!"


# Generated at 2022-06-23 17:48:33.535174
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3)
    print()
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    load_file("/path/to/some/file")

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:48:39.253848
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    >>> @work_in_progress("Loading file")
    ... def load_file(path):
    ...     with open(path, "rb") as f:
    ...         return pickle.load(f)
    ...
    ... obj = load_file("/path/to/some/file")
    Loading file... done. (3.52s)

    >>> with work_in_progress("Saving file"):
    ...     with open(path, "wb") as f:
    ...         pickle.dump(obj, f)
    Saving file... done. (3.78s)
    """
    pass

# Generated at 2022-06-23 17:48:41.840571
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1)



# Generated at 2022-06-23 17:48:48.049640
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    with work_in_progress("Waiting 1 second"):
        time.sleep(1.0)
    time.sleep(1.0)

    @work_in_progress("Waiting 2 seconds")
    def wait_2s():
        time.sleep(2.0)
    wait_2s()
    time.sleep(1.0)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:48:51.334288
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:48:59.314015
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path: str) -> str:
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "/tmp/test_work_in_progress.pickle"
    obj = "This is a test."
    with open(path, "wb") as f:
        pickle.dump(obj, f)

    out = load_file(path)

    assert(out == obj)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    assert(out == obj)


# Main
if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:49:05.391205
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:49:12.428999
# Unit test for function work_in_progress
def test_work_in_progress():
    with pytest.raises(TypeError):
        with work_in_progress(3):
            pass
    output = io.StringIO()
    with contextlib.redirect_stdout(output):
        with work_in_progress("Hello"):
            pass
    assert output.getvalue().startswith("Hello... done. (")
    output = io.StringIO()
    with contextlib.redirect_stdout(output):
        @work_in_progress("Hello")
        def hello():
            pass
        hello()
    assert output.getvalue().startswith("Hello... done. (")
    output = io.StringIO()
    with contextlib.redirect_stdout(output):
        @work_in_progress()
        def hello():
            pass
        hello()
    assert output.getvalue().startsw

# Generated at 2022-06-23 17:49:17.468479
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert True

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    assert True

# Generated at 2022-06-23 17:49:26.580394
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import numpy as np

    @work_in_progress("Loading file")
    def load_file(path: Path):
        with open(path, "rb") as f:
            return pickle.load(f)
    
    @work_in_progress("Saving file")
    def save_file(path: Path, data):
        with open(path, "wb") as f:
            pickle.dump(data, f)

    # Create a large array of zeros
    arr = np.zeros((100, 100), dtype=np.float32)
    path = Path() / "test_work_in_progress.pkl"
    save_file(path, arr)
    arr2 = load_file(path)
    path.unlink()

    # Check if the array was loaded correctly
   

# Generated at 2022-06-23 17:49:34.950785
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1.5)
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    print('=====')
    with work_in_progress("Saving file"):
        time.sleep(2.5)
        with open(path, "wb") as f:
            pickle.dump(obj, f)


# ================== main and unit tests ==================
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:38.551753
# Unit test for function work_in_progress
def test_work_in_progress():
    # test code_block
    with work_in_progress("Hi"):
        time.sleep(2.3)
    with work_in_progress("Hi", 10):
        time.sleep(2.3)

    # test function
    @work_in_progress("Hi")
    def foo():
        time.sleep(2.3)

    foo()

# Generated at 2022-06-23 17:49:44.152383
# Unit test for function work_in_progress
def test_work_in_progress():
    def dummy():
        time.sleep(3)
    
    with work_in_progress("Dummy task"):
        pass
    
    with work_in_progress("Dummy task"):
        dummy()
    
    @work_in_progress("Dummy task")
    def dummy2():
        time.sleep(3)

    dummy2()

# Generated at 2022-06-23 17:49:55.767950
# Unit test for function work_in_progress

# Generated at 2022-06-23 17:49:56.127164
# Unit test for function work_in_progress
def test_work_in_progress():
    assert False

# Generated at 2022-06-23 17:50:02.616290
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("test1.pkl")
    assert obj == {'a': 1, 'b': 2, 'c': 3}

    with work_in_progress("Saving file"):
        with open("test2.pkl", "wb") as f:
            pickle.dump(obj, f)

    with open("test2.pkl", "rb") as f:
        assert pickle.load(f) == {'a': 1, 'b': 2, 'c': 3}
    # Remove output file
    os.remove("test2.pkl")

# Generated at 2022-06-23 17:50:07.114733
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work in progress")
    def sleep():
        time.sleep(1)
    sleep()


# Main function of the file
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:50:08.437920
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(0.123)

    load_file("/path/to/file")

# Generated at 2022-06-23 17:50:15.110564
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "/path/to/some/file"
    obj = load_file(path)
    # Loading file... done. (3.52s)


    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    # Saving file... done. (3.78s)

# Generated at 2022-06-23 17:50:19.088427
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file(__file__)

    with work_in_progress("Saving file"):
        with open(__file__, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:50:28.212706
# Unit test for function work_in_progress
def test_work_in_progress():
    # pylint: disable=invalid-name
    def load_file(path):
        """
        Dummy function
        """
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")
    print(f"{repr(obj)!r}")

# This code is used to test the decorator.
# To run the test, execute:
# python -m udr.core.progress.work_in_progress
#
# pylint: disable=wrong-import-position
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:50:35.694298
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import subprocess
    import tempfile

    @work_in_progress("Random number generation")
    def generate(size: int) -> bytes:
        # Generate random bytes. It should take a long time.
        return subprocess.check_output(["dd", f"if=/dev/urandom", f"bs={size}", f"count=1"])

    def test_generate():
        with tempfile.TemporaryDirectory() as dirpath:
            path = dirpath + "/file"

            # Generate a large file
            with open(path, "wb") as f:
                f.write(generate(10 * 1024 * 1024))

            # Load the file.
            with work_in_progress("Loading"):
                with open(path, "rb") as f:
                    assert os.path.getsize

# Generated at 2022-06-23 17:50:39.492864
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Work in progress")
    def sleep(t):
        time.sleep(t)

    sleep(5)


if __name__ == "__main__":
    # Test function work_in_progress
    test_work_in_progress()

# Generated at 2022-06-23 17:50:51.053660
# Unit test for function work_in_progress
def test_work_in_progress():
    import os

    @work_in_progress
    def print_file(path):
        with open(path, "rb") as f:
            print(f.read().decode())

    assert not os.path.exists("/tmp/test_work_in_progress.txt")

    print_file("/tmp/test_work_in_progress.txt")

    with open("/tmp/test_work_in_progress.txt", "w") as f:
        f.write("This is a test file for function work_in_progress.")

    print_file("/tmp/test_work_in_progress.txt")

    os.remove("/tmp/test_work_in_progress.txt")

    assert not os.path.exists("/tmp/test_work_in_progress.txt")


# Test

# Generated at 2022-06-23 17:50:54.704864
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def _(d: float = 0.1):
        time.sleep(d)
    _()
    _(d=0.2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:04.818708
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "/path/to/some/file"
    obj = ""

    with work_in_progress("Loading file"):
        obj = load_file(path)

    assert obj == "hello world"
    time.sleep(2)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    os.remove(path)

# Execute only if run as a script
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:12.247244
# Unit test for function work_in_progress
def test_work_in_progress():
    # Time a dummy function
    def test_func():
        time.sleep(1)

    with work_in_progress("Test function"):
        test_func()

    # Time a dummy function without "with"
    work_in_progress("Test function")()

    # Run in a function
    @work_in_progress("Test function")
    def test_func_decorated():
        time.sleep(1)

    test_func_decorated()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:16.900171
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test function work_in_progress."""
    import random

    with work_in_progress("Generating random list"):
        lst = [random.random() for i in range(100000)]

    with work_in_progress("Sorting list"):
        lst.sort()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:21.712728
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("../README")
    assert obj

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    assert True

# Generated at 2022-06-23 17:51:32.160595
# Unit test for function work_in_progress
def test_work_in_progress():
    from pathlib import Path
    from tempfile import TemporaryDirectory

    def dummy_load_pickle(path):
        time.sleep(1.4)
        with open(path, 'rb') as f:
            return pickle.load(f)

    def dummy_save_pickle(obj, path):
        time.sleep(2.5)
        with open(path, 'wb') as f:
            pickle.dump(obj, f)

    def test_work_in_progress_in_decorator():
        with TemporaryDirectory() as d:
            path = Path(d) / "test_work_in_progress.pkl"
            dummy_save_pickle({"data": "foobar"}, path)

            with work_in_progress("Loading file"):
                f = dummy_load_pickle(path)


# Generated at 2022-06-23 17:51:35.637890
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sleeping"):
        time.sleep(2)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:37.440820
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1.25)

    assert True

# Generated at 2022-06-23 17:51:44.029306
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:47.236164
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test work_in_progress"):
        time.sleep(1)


if __name__ == "__main__":
    # Test code
    test_work_in_progress()

# Generated at 2022-06-23 17:51:48.505466
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.3)

# Generated at 2022-06-23 17:51:52.469974
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1.2)
        return

    load_file("/tmp/some/file")
    with work_in_progress("Saving file"):
        time.sleep(1.2)

    return

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:55.847386
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(0.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:02.450097
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:52:04.666158
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Fooing bar")
    def foo():
        time.sleep(0.25)
    foo()

# Generated at 2022-06-23 17:52:10.897575
# Unit test for function work_in_progress
def test_work_in_progress():
    # Do some work, which takes some time
    with work_in_progress("Loading file"):
        time.sleep(3.5)
    print()

    # Do some other work, which takes some time
    with work_in_progress("Saving file"):
        time.sleep(3.7)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:16.728215
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test the ``work_in_progress`` context manager.
    """
    @work_in_progress("Loading file")
    def load_file(path, secs=1):
        time.sleep(secs)
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/etc/passwd", 2.5)
    assert isinstance(obj, dict)

# Generated at 2022-06-23 17:52:24.962886
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file(__file__)
    save_file(__file__, obj)

# Generated at 2022-06-23 17:52:28.674224
# Unit test for function work_in_progress
def test_work_in_progress():

    with work_in_progress("Fibonacci 50"):
        def fib(n):
            if n <= 1:
                return n
            else:
                return fib(n - 1) + fib(n - 2)
        fib(50)

# Generated at 2022-06-23 17:52:38.632320
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test if code reports execution time properly
    obj = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    with work_in_progress("Saving list"):
        with open("/tmp/test.pkl", "wb") as f:
            pickle.dump(obj, f)
    with work_in_progress("Loading list"):
        with open("/tmp/test.pkl", "rb") as f:
            loaded_obj = pickle.load(f)
    assert loaded_obj == obj
    # Test if description is printed properly
    with work_in_progress("Close file"):
        pass

if __name__ == "__main__":
    _test_all_functions()

# Generated at 2022-06-23 17:52:41.834523
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        with open("test.txt", "w") as f:
            f.write("test")
        with open("test.txt", "r") as f:
            assert f.read() == "test"
        os.remove("test.txt")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:46.272279
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Task 01")
    def task_01():
        time.sleep(1.23)

    task_01()

    with work_in_progress("Task 02"):
        time.sleep(2.34)


# Unit test entry point
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:49.259443
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3.52)

    with work_in_progress("Saving file"):
        time.sleep(3.78)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:56.173044
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Loading file"

    @work_in_progress(desc=desc)
    def load_file(path):
        time.sleep(3.52)
        return path

    assert load_file("/path/to/some/file") == "/path/to/some/file"

    with work_in_progress(desc="Saving file"):
        time.sleep(3.78)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:53:03.828900
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for the function work_in_progress.

    .. code:: python

        >>> test_work_in_progress()
        Work in progress... done. (0.00s)

        >>> @work_in_progress()
        ... def sleep_1_second():
        ...     time.sleep(1)
        ...
        ... sleep_1_second()
        Work in progress... done. (1.00s)
    """
    with work_in_progress():
        time.sleep(0)

if __name__ == "__main__":
    import doctest
    doctest.testmod()