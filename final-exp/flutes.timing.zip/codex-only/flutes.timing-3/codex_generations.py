

# Generated at 2022-06-23 17:43:14.041657
# Unit test for function work_in_progress
def test_work_in_progress():
    '''
    test code:
        >>> @work_in_progress("Loading file")
        ... def load_file(path):
        ...     with open(path, "rb") as f:
        ...         return pickle.load(f)
        ...
        ... obj = load_file("/path/to/some/file")
        Loading file... done. (3.52s)

        >>> with work_in_progress("Saving file"):
        ...     with open(path, "wb") as f:
        ...         pickle.dump(obj, f)
        Saving file... done. (3.78s)
    '''
    pass

# Generated at 2022-06-23 17:43:17.775935
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

# Generated at 2022-06-23 17:43:23.570331
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:43:28.934905
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file(__file__)
    save_file("/tmp/test_file", obj)

# Generated at 2022-06-23 17:43:32.297772
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test WIP"):
        time.sleep(1)

# Generated at 2022-06-23 17:43:39.430578
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:43:47.455166
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test the work_in_progress() function. """
    print(__doc__)
    expected_output = "Work in progress... done. (0.00s)\n"
    import sys
    from contextlib import redirect_stdout
    from io import StringIO
    with redirect_stdout(StringIO()) as buf, \
            work_in_progress("Work in progress"):
        time.sleep(0.01)
    assert buf.getvalue() == expected_output, \
        f"\n{expected_output} !=\n{buf.getvalue()}"

# Generated at 2022-06-23 17:43:48.946466
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file") as f:
        pass
    @work_in_progress("Loading file")
    def f():
        pass
    f()

# Generated at 2022-06-23 17:43:50.622816
# Unit test for function work_in_progress
def test_work_in_progress():
    for i in range(1, 11):
        with work_in_progress(f"Task {i}"):
            time.sleep(random.randint(1, 3) / 10)

# Generated at 2022-06-23 17:43:54.520901
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        with open("/path/to/a/file", "w") as f:
            for i in range(1000000):
                f.write(str(i*i))

# Generated at 2022-06-23 17:43:57.130990
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test")
    def test():
        time.sleep(1.23)
    test()

# Generated at 2022-06-23 17:44:05.361466
# Unit test for function work_in_progress
def test_work_in_progress():
    # The following snippet should print "Loading file... done. (3.52s)",
    # assuming that it takes 3.52 seconds to load the file.
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    # The following snippet should print "Saving file... done. (3.78s)",
    # assuming that it takes 3.78 seconds to save the file.
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
        time.sleep(3)

if __name__ == "__main__":
    test_work_in_

# Generated at 2022-06-23 17:44:14.199277
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test function `work_in_progress`."""

    with work_in_progress("Processing long task", verbose=1):
        # Do long task
        time.sleep(1.4)

    with work_in_progress("Processing short task", verbose=1):
        # Do short task
        time.sleep(0.1)

    @work_in_progress("Processing a function", verbose=1)
    def _dummy_func():
        time.sleep(1.1)
    time.sleep(0.3)
    _dummy_func()

# Generated at 2022-06-23 17:44:15.743316
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(1)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:44:17.440302
# Unit test for function work_in_progress
def test_work_in_progress():

    with work_in_progress("Executing tests"):
        for _ in range(1000000):
            pass

# Generated at 2022-06-23 17:44:20.768894
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(0.1)
    with work_in_progress("Testing progress"):
        time.sleep(0.2)

# Generated at 2022-06-23 17:44:30.861532
# Unit test for function work_in_progress
def test_work_in_progress():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    import shutil
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with TemporaryDirectory() as tmpdir:
        tmpdir = Path(tmpdir)
        save_file(tmpdir / "test.pkl", [1, 2, 3, 4, 5])
        save_file(tmpdir / "test.pkl", [1, 2, 3, 4, 5])

# Generated at 2022-06-23 17:44:39.409128
# Unit test for function work_in_progress
def test_work_in_progress():
    class TestClass:
        @work_in_progress("Loading file")
        def load_file(self, path):
            with open(path, "rb") as f:
                return pickle.load(f)
    
    path = os.path.join(os.path.dirname(__file__), "../../data/lena_gray.npy")
    obj = TestClass().load_file(path)
    assert isinstance(obj, np.ndarray)
    assert obj.shape == (512, 512)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:44:44.924408
# Unit test for function work_in_progress
def test_work_in_progress():
    for _ in range(10):
        time.sleep(0.1)
        with work_in_progress("Sleeping"):
            time.sleep(0.5)


if __name__ == "__main__":
    import pickle
    import sys
    test_work_in_progress()
    try:
        from . import io

        @io.work_in_progress("Writing")
        def write(path):
            with open(path, "w") as f:
                print(__name__, file=f)

        @io.work_in_progress("Reading")
        def read(path):
            with open(path, "r") as f:
                return f.read()

        write("test.txt")
        print(read("test.txt"))
    except ImportError:
        pass

# Generated at 2022-06-23 17:44:54.066346
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with open('./test_work_in_progress.pkl', 'wb') as f:
        pickle.dump([[1,2,3,4],[5,6,7,8]], f)

    obj = load_file("./test_work_in_progress.pkl")
    assert obj == [[1,2,3,4],[5,6,7,8]], "Incorrectly loaded file"
    os.remove("./test_work_in_progress.pkl")

#test_work_in_progress()

# Generated at 2022-06-23 17:44:58.336773
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("This is a test")
    def do_something():
        time.sleep(1)

    do_something()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:45:05.068754
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:45:05.581125
# Unit test for function work_in_progress
def test_work_in_progress():
    pass

# Generated at 2022-06-23 17:45:09.116542
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Work in progress"):
        for _ in range(10000000):
            pass

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:45:14.339757
# Unit test for function work_in_progress
def test_work_in_progress():
    import random

    # Function decorator
    @work_in_progress("Testing work_in_progress")
    def test_decorator():
        time.sleep(random.uniform(.1, .5))

    with work_in_progress("Testing context manager"):
        time.sleep(random.uniform(.1, .5))

# Generated at 2022-06-23 17:45:15.534253
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test work_in_progress")
    def test():
        time.sleep(1)

    test()

# Generated at 2022-06-23 17:45:20.576617
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
        return file_obj

    with open("/tmp/test.pkl", "wb") as f:
        pickle.dump(["a", "b", "c", "d"], f)

    obj = load_file("/tmp/test.pkl")
    assert obj == ["a", "b", "c", "d"]

    with work_in_progress("Saving file"):
        with open("/tmp/test.pkl", "wb") as f:
            pickle.dump(["a", "b", "c", "d"], f)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:45:24.636376
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    pickle.dump([1, 2, 3, 4, 5], open('/tmp/data', 'wb'))

    data = load_file('/tmp/data')
    assert data == [1, 2, 3, 4, 5]
    os.system('rm /tmp/data')

# Generated at 2022-06-23 17:45:28.017061
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.5)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:45:32.622645
# Unit test for function work_in_progress
def test_work_in_progress():

    # Test for context manager
    with work_in_progress("Test for context manager"):
        time.sleep(1.0)

    # Test for decorator
    @work_in_progress("Test for decorator")
    def foo(t):
        time.sleep(t)

    foo(5.0)

# Generated at 2022-06-23 17:45:34.753881
# Unit test for function work_in_progress
def test_work_in_progress():
    from random import random
    with work_in_progress("Testing"):
        time.sleep(random())

# Generated at 2022-06-23 17:45:39.311040
# Unit test for function work_in_progress
def test_work_in_progress():
    from random import randint

    @work_in_progress("Loading file")
    def load_file(filename):
        time.sleep(randint(1, 5))
        return filename

    filename = "/path/to/some/file"
    filename2 = load_file(filename)
    assert filename == filename2

    with work_in_progress("Saving file"):
        time.sleep(randint(1, 5))

# Generated at 2022-06-23 17:45:48.845706
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress(desc="Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            obj = pickle.load(f)
        return obj

    path = "../tests/files/model_predictions.p"
    obj = load_file(path)
    assert isinstance(obj, pd.DataFrame)
    with work_in_progress(desc="Saving file"):
        path = "../tests/files/model_predictions_copied.p"
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    path = "../tests/files/model_predictions_copied.p"
    assert os.path.isfile(path)
    os.remove(path)

# Generated at 2022-06-23 17:45:50.610364
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test")
    def f():
        time.sleep(1)
    f()



# Generated at 2022-06-23 17:45:56.529688
# Unit test for function work_in_progress
def test_work_in_progress():
    from io import StringIO
    import sys

    test_str = "test_string"
    expected_out = f"{test_str}... done. (0.00s)\n"

    old_stdout = sys.stdout
    captured_output = StringIO()
    sys.stdout = captured_output

    with work_in_progress(test_str):
        time.sleep(0.01)

    # Restore stdout
    captured_output.seek(0)
    assert captured_output.read() == expected_out

# Generated at 2022-06-23 17:46:00.229471
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing") as w:
        time.sleep(0.2)
    assert isinstance(w, contextlib.AbstractContextManager)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:46:05.194423
# Unit test for function work_in_progress
def test_work_in_progress():
    """Work in progress"""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert obj is not None

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:46:09.154988
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work in progress function")
    def test():
        time.sleep(0.5)
    test()

# vim: set ft=python et ts=4 sw=4:

# Generated at 2022-06-23 17:46:11.692006
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1)
    with work_in_progress():
        time.sleep(1)

# Generated at 2022-06-23 17:46:15.297495
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Executing test"):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:46:22.020626
# Unit test for function work_in_progress
def test_work_in_progress():
    def _load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = _load_file(__file__)

    def _save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    _save_file(__file__)

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:46:28.688441
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("test_work_in_progress.pkl")

    with work_in_progress("Saving file"):
        with open("test_work_in_progress.pkl", "wb") as f:
            pickle.dump(obj, f)

    os.remove("test_work_in_progress.pkl")


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:46:35.024820
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)


# -------------------------------------------------------------------------

# Generated at 2022-06-23 17:46:42.901143
# Unit test for function work_in_progress
def test_work_in_progress():
    def dummy_task(duration):
        begin_time = time.time()
        while time.time() < begin_time + duration: pass

    def inner_context(duration):
        with work_in_progress("Inner task"):
            dummy_task(duration)

    with work_in_progress("Outer task"):
        dummy_task(1)
        inner_context(1)
        dummy_task(1)

# test_work_in_progress()

# Generated at 2022-06-23 17:46:48.494633
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test case for the function work_in_progress()."""
    import time
    import pickle
    import io

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    def _test():
        obj = {"a": 1}
        save_file(obj, "test.pkl")
        loaded_obj = load_file("test.pkl")
        assert obj == loaded_obj

    # Perform test
    _test()
    print("Test passed!")

# Generated at 2022-06-23 17:46:56.733589
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import pickle

    desc = "Loading file"
    with work_in_progress(desc):
        time.sleep(0.2)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with tempfile.TemporaryDirectory() as tmpdirname:
        path = os.path.join(tmpdirname, "file")
        save_file(path, (1, 2, 3))

    assert True

# Generated at 2022-06-23 17:47:01.009117
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(0.3)
    with work_in_progress("Work in progress") as w:
        time.sleep(0.3)
    time.sleep(0.1)
    work_in_progress("Work in progress")
    time.sleep(0.1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:47:04.222043
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("This is a test"):
        time.sleep(0.5)
    assert True


# Generated at 2022-06-23 17:47:11.607496
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file") as p:
        time.sleep(1)
        p.update_message("Loading file 2")
        time.sleep(1)
        p.update_message("Loading file 3")
        time.sleep(1)
        p.update_message("Loading file 4")
        time.sleep(1)
        p.update_message("Loading file 5")
        time.sleep(1)
        p.update_message("Loading file 6")
    assert True

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:47:20.125794
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    data = "a" * 1024 * 1024 * 1024  # Create 1GB of data
    with work_in_progress("Save data"):
        with open("/tmp/test.data", "wb") as f:
            f.write(data)
        time.sleep(1)
    with work_in_progress("Load data"):
        with open("/tmp/test.data", "rb") as f:
            f.read()
        time.sleep(1)

# vim: fenc=utf-8 ts=4 et sw=4 sts=4:

# Generated at 2022-06-23 17:47:22.171062
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(2)
    with work_in_progress("Saving file"):
        time.sleep(3)

# Generated at 2022-06-23 17:47:33.141747
# Unit test for function work_in_progress
def test_work_in_progress():
    """Tests function work_in_progress()."""
    @work_in_progress("Loading file")
    def load_file(path: str):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "./tools.py"
    obj = load_file(path)
    assert obj is not None, "work_in_progress: loading file failed"

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


#######################
#    Application      #
#######################
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:47:38.910462
# Unit test for function work_in_progress
def test_work_in_progress():
    # test the function in return mode
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    # test the function in with mode
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


# Generated at 2022-06-23 17:47:50.199411
# Unit test for function work_in_progress
def test_work_in_progress():
    # Globals for testing
    work_in_progress_global = None

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with open("__work_in_progress__.pickle", "wb") as f:
        pickle.dump({"key": 0}, f)
    work_in_progress_global = load_file("__work_in_progress__.pickle")
    assert work_in_progress_global is not None

    with work_in_progress("Saving file"):
        with open("__work_in_progress__.pickle", "wb") as f:
            pickle.dump(["key"], f)

# unit test

# Generated at 2022-06-23 17:47:57.968883
# Unit test for function work_in_progress
def test_work_in_progress():
    from io import StringIO
    from contextlib import redirect_stdout

    buf = StringIO()
    with redirect_stdout(buf):
        with work_in_progress():
            # slow computation
            time.sleep(2)
            print("hello world")
    output = buf.getvalue()
    assert output == "Work in progress... done. (2.00s)\n", output

    buf = StringIO()
    with redirect_stdout(buf):
        with work_in_progress("Loading file"):
            # slow computation
            time.sleep(3)
            print("hello world")
    output = buf.getvalue()
    assert output == "Loading file... done. (3.00s)\n", output

# Generated at 2022-06-23 17:48:09.323833
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import pickle
    import tempfile
    with tempfile.TemporaryDirectory() as temp_dir:
        with open(os.path.join(temp_dir, 'file.pkl'), 'wb+') as f:
            pickle.dump(1, f)
        file_path = os.path.join(temp_dir, 'file.pkl')
        @work_in_progress('Loading file')
        def load_file(path):
            with open(path, 'rb') as f:
                return pickle.load(f)
        assert load_file(file_path) == 1
        with work_in_progress('Trying to save file'):
            time.sleep(2)
            with open(file_path, 'wb') as f:
                pickle.dump(2, f)

# Generated at 2022-06-23 17:48:13.171182
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1.3)
    with work_in_progress():
        time.sleep(0.8)
    print()

# Generated at 2022-06-23 17:48:18.365948
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:48:21.205744
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def long_time_function():
        time.sleep(0.05)
    long_time_function()

# Generated at 2022-06-23 17:48:28.171072
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test function :code:`work_in_progress`."""
    from .func.load_file import load_file
    # @work_in_progress("Loading file")
    # def load_file(path):
    #     return pickle.load(open(path, "rb"))
    with work_in_progress("Loading file"):
        obj = load_file("/home/jovyan/data/gnao1_subset_from_proteomicsdb.pickle")

# Generated at 2022-06-23 17:48:30.366340
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("test work_in_progress"):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:48:34.039187
# Unit test for function work_in_progress
def test_work_in_progress():
    def slow_func(x):
        with work_in_progress("A slow function"):
            total = 0
            for i in range(10**7):
                total += 1
        return x

    result = slow_func("a result")
    # A slow function... done. (1.15s)
    assert result == 'a result'

# Generated at 2022-06-23 17:48:36.880867
# Unit test for function work_in_progress
def test_work_in_progress():
    t1 = time.time()
    with work_in_progress("Test in progress"):
        time.sleep(0.1)
    print("{:.2f}".format(time.time() - t1) + "s")

# Generated at 2022-06-23 17:48:46.333972
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test if work_in_progress works

    Create a test file first by running the following before the tests:

        $ cat /tmp/test_data.txt
        Hello World

    Then run the test
    """
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/tmp/test_data.txt")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


test_work_in_progress()

# Generated at 2022-06-23 17:48:52.442189
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Test case 1")
    with work_in_progress("Run unit test"):
        time.sleep(3)
    print("Test case 2")
    @work_in_progress("Run unit test")
    def unit_test():
        time.sleep(3)
    unit_test()


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:48:59.999044
# Unit test for function work_in_progress
def test_work_in_progress():

    with work_in_progress("do nothing"):
        pass
    print()

    with work_in_progress("do nothing"):
        return
    print()

    def fn():
        with work_in_progress("do nothing"):
            pass

    with work_in_progress("call function"):
        fn()

    obj = {"a": "value"}

    with work_in_progress("save to file"):
        with open("data/tmp.pkl", "wb") as f:
            pickle.dump(obj, f)

    with work_in_progress("load from file"):
        with open("data/tmp.pkl", "rb") as f:
            obj2 = pickle.load(f)

    assert obj == obj2, "save and load not equal"


# Generated at 2022-06-23 17:49:08.742036
# Unit test for function work_in_progress
def test_work_in_progress():
    filename = "test_work_in_progress_docstring.p"
    try:
        with open(filename, "wb") as f:
            pickle.dump({1:2, 3:4}, f)

        with work_in_progress("Loading file"):
            with open(filename, "rb") as f:
                obj = pickle.load(f)
        assert obj == {1:2, 3:4}

        with work_in_progress("Saving file"):
            with open(filename, "wb") as f:
                pickle.dump({1:2, 3:4}, f)
    finally:
        os.remove(filename)

# Generated at 2022-06-23 17:49:11.330654
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test function"):
        time.sleep(.75)
        pass

# Generated at 2022-06-23 17:49:19.177545
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile

    def save_obj(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    def load_obj(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = tempfile.mktemp()
    obj = {'a':1, 'b':'test', 'c':[1, 2, 3]}

    with work_in_progress("Loading file"):
        save_obj(obj, path)

    with work_in_progress("Saving file"):
        ret = load_obj(path)
        assert ret == obj, "unexpected result"

# Generated at 2022-06-23 17:49:24.448476
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress."""
    WORK_HARD_TO_FINISH = 0.15

    @work_in_progress("Unit testing")
    def __test():
        time.sleep(WORK_HARD_TO_FINISH)

    __test()

# Generated at 2022-06-23 17:49:33.969199
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("__init__.py")

    with work_in_progress("Saving file"):
        with open("__init__.py.bak", "wb") as f:
            pickle.dump(obj, f)
    os.remove("__init__.py.bak")


# Explicitly defining the name '__main__'
#
# The following is needed so that the unit test can be started
# with 'python -m common.context_managers'
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:36.954096
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("do some work")
    def do_work():
        time.sleep(1)
    do_work()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:38.449349
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("This is a description"):
        time.sleep(1.0)

# Generated at 2022-06-23 17:49:42.369997
# Unit test for function work_in_progress
def test_work_in_progress():
    import random

    @work_in_progress("Make a new lucky number")
    def make_lucky_number():
        time.sleep(1)
        lucky_number = random.randint(100000, 999999)
        print(f"Your lucy number is {lucky_number}")
        return lucky_number

    lucky_number = make_lucky_number()
    assert 100000 <= lucky_number <= 999999

# Generated at 2022-06-23 17:49:46.210520
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def test():
        time.sleep(1)
    test()

    with work_in_progress():
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:50.617576
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Simple task"):
        time.sleep(1.6)
    print()
    with work_in_progress("'a' + 'b'"):
        "a" + "b"
    print()
    with work_in_progress("<do nothing>"):
        pass

# Generated at 2022-06-23 17:49:53.922823
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(1)
    with work_in_progress("Sleeping"):
        time.sleep(2)
    assert True

# Generated at 2022-06-23 17:50:01.205628
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file(__file__)
    save_file("test_work_in_progress.pickle", obj)
    assert os.path.exists("test_work_in_progress.pickle")
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:50:11.183883
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    # Run all the functions with sample input
    from inspect import getmembers, isfunction

    functions = getmembers(sys.modules[__name__], isfunction)
    for _, func in functions:
        func()

# Generated at 2022-06-23 17:50:13.285714
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("This is a test")
    def test():
        time.sleep(0.5)
    test()

# Generated at 2022-06-23 17:50:14.179211
# Unit test for function work_in_progress
def test_work_in_progress():
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:50:19.693471
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function work_in_progress"""
    @work_in_progress("Saving file")
    def save_file(path):
        # Do something here
        with open(path, "wb") as f:
            # Do other stuff here
            pass

    # Expect no error
    save_file("/path/to/some/file")

# Unit test

# Generated at 2022-06-23 17:50:26.878905
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:50:29.409838
# Unit test for function work_in_progress
def test_work_in_progress():

    desc = "Working hard"

    def func():
        time.sleep(5)

    with work_in_progress(desc):
        func()

# Generated at 2022-06-23 17:50:32.045612
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress
    def func():
        for _ in range(10_000_000):
            pass

    func()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:50:39.717421
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/Users/abc/Downloads/22.pkl")
    
    with work_in_progress("Saving file"):
        with open("/Users/abc/Downloads/1111.pkl", "wb") as f:
            pickle.dump(obj, f)

# test_work_in_progress()

# Generated at 2022-06-23 17:50:44.279690
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test 1"):
        time.sleep(1.5)

    def test_2():
        time.sleep(2.5)

    with work_in_progress("Test 2"):
        test_2()

    @work_in_progress("Test 3")
    def test_3():
        time.sleep(3.5)

    test_3()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:50:48.826699
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test the context manager
    with work_in_progress("Execution"):
        time.sleep(0.5)
    # Test the decorator
    @work_in_progress("Execution")
    def exec():
        time.sleep(0.5)
    exec()

# Generated at 2022-06-23 17:50:56.776034
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        count = 0
        for i in range(100000):
            count += i
    with work_in_progress("Loading file"):
        count = 0
        for i in range(1000000):
            count += i
    with work_in_progress("Saving file"):
        count = 0
        for i in range(10000):
            count += i
    with work_in_progress("Loading file"):
        count = 0
        for i in range(100000):
            count += i
    with work_in_progress("Saving file"):
        count = 0
        for i in range(1000):
            count += i
    with work_in_progress("Loading file"):
        count = 0
        for i in range(10000):
            count += i
   

# Generated at 2022-06-23 17:51:07.888697
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function work_in_progress."""
    # create a dummy file
    with open("_testing_file.txt", "w") as f:
        f.write("1234567890")

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # load the dummy file
    obj = load_file("_testing_file.txt")

    with work_in_progress("Saving file"):
        with open("_testing_file.txt", "wb") as f:
            pickle.dump(obj, f)

    # delete the dummy file
    os.remove("_testing_file.txt")


if __name__ == '__main__':
    test_work_in_

# Generated at 2022-06-23 17:51:12.538646
# Unit test for function work_in_progress
def test_work_in_progress():
    import subprocess


# Generated at 2022-06-23 17:51:20.467701
# Unit test for function work_in_progress
def test_work_in_progress():
    with open("dump_data.txt", "rb") as f:
        obj = pickle.load(f)
    obj = np.random.randint(0, 10, (1000000, 100))
    with work_in_progress("Saving file"):
        with open("dump_data.txt", "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:25.215818
# Unit test for function work_in_progress
def test_work_in_progress():
    # Note that random.random() is a pseudo random number generator and has
    # a non-deterministic output.
    random_number = random.random()
    with work_in_progress() as w:
        time.sleep(random_number)
        assert w is not None

# Generated at 2022-06-23 17:51:27.185684
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("work_in_progress testing"):
        time.sleep(2)

# Generated at 2022-06-23 17:51:28.904999
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading some stuff"):
        time.sleep(1.5432)

# Generated at 2022-06-23 17:51:36.656941
# Unit test for function work_in_progress
def test_work_in_progress():
    path = "/tmp/tmp.txt"
    with open(path, "w") as f:
        f.write("hello world")

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Reading file"):
        with open(path) as f:
            assert f.read() == "hello world"

    obj = load_file(path)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


# Generated at 2022-06-23 17:51:40.309351
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Computing Fibonacci numbers"):
        for n in range(30):
            i = 0
            j = 1
            for _ in range(n):
                i, j = j, i + j
    assert True

# Generated at 2022-06-23 17:51:48.076562
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress"""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = Path(__file__).parent / "test_pickle.pkl"
    obj = load_file(path)
    assert obj == {"a": list(range(10000))}
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    assert path.exists()

# Generated at 2022-06-23 17:51:50.532474
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(0.5)
    assert 1

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:51:55.545450
# Unit test for function work_in_progress
def test_work_in_progress():
    file_path = "/tmp/work_in_progress_test.pickle.npz"

    try:
        with work_in_progress('Loading file'):
            time.sleep(3.54)
        print()

        with work_in_progress('Saving file'):
            time.sleep(3.78)
    finally:
        os.remove(file_path)

# Generated at 2022-06-23 17:51:57.758446
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Task"):
        time.sleep(0.5)
    assert True

# Generated at 2022-06-23 17:52:02.111741
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(2)
    with work_in_progress("Task #1"):
        time.sleep(1)
    
    time.sleep(0.5)
    with work_in_progress("Task #2"):
        time.sleep(1.5)

# Generated at 2022-06-23 17:52:07.143089
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Reading file")
    def read_file(path):
        with open(path, "rb") as file:
            return file.read()

    assert read_file("/etc/hosts")
    return

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:14.154348
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with open("/tmp/tmp.txt", "wb") as f:
        pickle.dump("hello world", f)

    obj = load_file("/tmp/tmp.txt")
    assert obj == "hello world"

    with work_in_progress("Saving file"):
        with open("/tmp/tmp.txt", "wb") as f:
            pickle.dump("hello world", f)

# Generated at 2022-06-23 17:52:21.383677
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import random
    import tempfile
    from tempfile import NamedTemporaryFile

    # Setup
    tmp_file = NamedTemporaryFile(delete=False)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    data = random.randrange(1, 100)
    # Act
    with open(tmp_file.name, "wb") as f:
        pickle.dump(data, f)

    # Assert
    assert data == load_file(tmp_file.name)

    # Cleanup
    os.remove(tmp_file.name)

    # Act
    data = random.randrange(100, 1000)

# Generated at 2022-06-23 17:52:32.472506
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import tempfile
    import pickle
    import os.path as osp

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    tmp_file = tempfile.TemporaryFile()
    tmp_path = osp.realpath(tmp_file.name)

    # Test decorator mode
    @work_in_progress("Loading file")
    def decorated_load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = decorated_load_file(tmp_path)

    # Test with block mode

# Generated at 2022-06-23 17:52:38.590096
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file") as w:
        time.sleep(1)
        with work_in_progress("Processing file") as w:
            time.sleep(2)

    @work_in_progress("Processing file")
    def foo():
        time.sleep(1.5)
        with work_in_progress("Processing file"):
            time.sleep(0.5)
        print()

    foo()

# Generated at 2022-06-23 17:52:40.054388
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(2)


# Generated at 2022-06-23 17:52:45.238055
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Doing task")
    def task():
        with open(__file__, "rb") as f:
            return f.read()

    assert task() == open(__file__, "rb").read()
    print("test_work_in_progress passed")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:47.709746
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Loading file"):
        time.sleep(0.1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:50.819839
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    import time
    with io.StringIO() as buf, contextlib.redirect_stdout(buf):
        with work_in_progress("Test"):
            time.sleep(.1)
        assert buf.getvalue() == "Test... done. (0.10s)\n"

# Generated at 2022-06-23 17:53:01.853251
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    class Dummy:
        def __init__(self, a=123, b="abc"):
            self.a = a
            self.b = b
            self.list_ = list(range(100))

    dummy = Dummy()

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with open("tmp.txt", "wb") as f:
        pickle.dump(dummy, f)

    with work_in_progress("Loading file"):
        d = load_file("tmp.txt")

    assert d.a == dummy.a
    assert d.b == dummy.b
    assert d.list_ == dummy.list_


# Generated at 2022-06-23 17:53:08.813198
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    import doctest
    doctest.testmod()