

# Generated at 2022-06-23 17:43:08.654429
# Unit test for function work_in_progress
def test_work_in_progress():
    def foo(x, *, y):
        with work_in_progress("foo body"):
            print(x, y)
            time.sleep(1)
    foo(1, y=(2,))


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:43:14.228612
# Unit test for function work_in_progress
def test_work_in_progress():
    def test_function():
        time.sleep(1)
        return 42

    with work_in_progress("Running test_function"):
        assert test_function() == 42

    @work_in_progress("Running test_function")
    def test_function():
        time.sleep(1)
        return 42

    assert test_function() == 42

# Generated at 2022-06-23 17:43:21.254619
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(2)
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        time.sleep(3)
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:43:26.909316
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:43:38.245914
# Unit test for function work_in_progress
def test_work_in_progress():
    import os.path
    import pickle
    from pytest import fixture

    tmpdir = fixture(lambda: os.path.join(os.path.dirname(__file__), "fixtures", "work_in_progress"))

    @fixture(scope="module")
    def original_file(tmpdir):
        file_path = os.path.join(tmpdir, "file.pickle")
        obj = {"a": 42, "b": "Hello, world!", 2: None, "none": None}
        with open(file_path, "wb") as f:
            pickle.dump(obj, f)
        return file_path

    def test_with_savings(original_file):
        """Check that a file is properly saved."""

# Generated at 2022-06-23 17:43:41.522024
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function ``work_in_progress``.
    """
    with work_in_progress("Test function"):
        time.sleep(0.5)

# Generated at 2022-06-23 17:43:50.245660
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile
    import pickle

    class _TestWorkInProgress:
        def __init__(self):
            self.test_val = 1

    def _create_and_load_file():
        test_obj = _TestWorkInProgress()

        with tempfile.TemporaryDirectory() as tmp_dir_path:
            tmp_file_path = os.path.join(tmp_dir_path, "test_file.pkl")

            with work_in_progress("Save file"):
                with open(tmp_file_path, "wb") as f:
                    pickle.dump(test_obj, f)

            with work_in_progress("Load file"):
                with open(tmp_file_path, "rb") as f:
                    obj = pickle.load(f)

        return obj

   

# Generated at 2022-06-23 17:43:54.911968
# Unit test for function work_in_progress
def test_work_in_progress():
    def slow_func():
        print("Doing something...")
        time.sleep(0.5)
        print("Done with something.")

    with work_in_progress("To test work_in_progress"):
        slow_func()

# Generated at 2022-06-23 17:44:03.598236
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/home/fstolcke/test")

    with work_in_progress("Saving file"):
        with open("/tmp/test2", "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:44:14.856763
# Unit test for function work_in_progress
def test_work_in_progress():

    # Work in progress
    @work_in_progress("Work in progress")
    def wasted_time():
        time.sleep(0.5)

    # Test description
    @work_in_progress()
    def wasted_time2():
        time.sleep(5)

    with work_in_progress("Work in progress"):
        time.sleep(1)

    # Test unit time
    with work_in_progress("Work in progress", unit_time=3600):
        time.sleep(2)

    with work_in_progress("Work in progress", unit_time=1):
        time.sleep(2)

    # Test string interpolation
    with work_in_progress("Work in progress %s"):
        time.sleep(2)

# Generated at 2022-06-23 17:44:23.303071
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Ensure context manager work_in_progress functions as intended."""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    # Run unit tests
    test_work_in_progress()

# Generated at 2022-06-23 17:44:29.524505
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file(__file__)
    assert len(obj) == 0

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    save_file(obj, __file__)
    assert True


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:44:33.272617
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test function")
    def test_work_in_progress_fn():
        pass
    test_work_in_progress_fn()

# Generated at 2022-06-23 17:44:42.856497
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import os

    def load_file(path):
        @work_in_progress("Loading file")
        def impl():
            with open(path, "rb") as f:
                return pickle.load(f)
        return impl()

    obj = load_file(os.path.join(
        os.path.dirname(__file__), "test_files", "test_work_in_progress.pkl"))
    assert obj == {"a": 1, "b": 2}

    def save_file(path):
        @work_in_progress("Saving file")
        def impl():
            with open(path, "wb") as f:
                return pickle.dump(obj, f)
        return impl()


# Generated at 2022-06-23 17:44:45.936410
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(2)

# Generated at 2022-06-23 17:44:50.048981
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""
    .. code:: python

        >>> import time
        >>> @work_in_progress("Slow task")
        ... def my_func():
        ...     time.sleep(1)
        ...
        >>> my_func()
        Slow task... done. (1.00s)

    """
    pass

# Generated at 2022-06-23 17:44:53.784887
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Sleeping"):
        time.sleep(0.05)
    return True

# Generated at 2022-06-23 17:44:59.279300
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Tests for function work_in_progress."""

    @work_in_progress("Doing some task")
    def some_task():
        time.sleep(1)

    # Test with function
    some_task()

    # Test with context manager
    with work_in_progress("Doing another task"):
        time.sleep(1)

# Generated at 2022-06-23 17:45:04.760443
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    # Output: Loading file... done. (3.52s)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:45:15.613483
# Unit test for function work_in_progress
def test_work_in_progress():
    # Has no return value, based on context manager
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1)
        with open(path, "rb") as f:
            return pickle.load(f)

    # We have a return value, based on context manager
    @work_in_progress("Saving file")
    def save_file(path, obj):
        time.sleep(1)
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    # Generate random data
    data = {}
    for i in range(5000):
        data[i] = random.randint(100000, 1000000)

    # Write data to file
    save_file("/tmp/tmpfile", data)

    # Read data from file

# Generated at 2022-06-23 17:45:18.668988
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    import sys
    import time
    import traceback
    old_sys_stdout = sys.stdout
    sys.stdout = io.StringIO()
    with work_in_progress("Work in progress"):
        time.sleep(1.23)
    assert "Work in progress... done. (1.23s)" in sys.stdout.getvalue()
    sys.stdout = old_sys_stdout

# Generated at 2022-06-23 17:45:20.740494
# Unit test for function work_in_progress
def test_work_in_progress():
    def foo():
        time.sleep(1)

    with work_in_progress("Testing work_in_progress function"):
        foo()

# Generated at 2022-06-23 17:45:25.494778
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for work_in_progress."""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with tempfile.TemporaryDirectory() as dir:
        path = os.path.join(dir, "data")
        save_file(path, [i for i in range(10, 20)])
        print(load_file(path))

# Generated at 2022-06-23 17:45:36.710659
# Unit test for function work_in_progress
def test_work_in_progress():
    import pathlib
    import pickle

    obj = {
        "name": "Undefined",
        "age": "Unknown",
        "constellation": "Aquarius"
    }

    # Create a temp file for pickle
    tmp_dir = pathlib.Path(__file__).parent / "tmp"
    tmp_dir.mkdir(parents=True, exist_ok=True)
    tmp_file = tmp_dir / "test_work_in_progress.pickle"

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)


# Generated at 2022-06-23 17:45:40.669328
# Unit test for function work_in_progress
def test_work_in_progress():
    pass


if __name__ == "__main__":
    import pytest
    pytest.main(["-v", "--durations=20", __file__])

# Generated at 2022-06-23 17:45:49.659155
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test for function :func:`work_in_progress`."""
    import datetime
    import tempfile
    from pickle import dumps
    from .tests_util import work_in_progress as wip

    @wip("Testing function")
    def func():
        time.sleep(2)

    def func2():
        time.sleep(3)

    # Test
    func()
    with wip():
        func2()
    with wip("Testing function"):
        time.sleep(2)
    with wip("Testing function"):
        time.sleep(2)
    with wip("Testing function"):
        time.sleep(2)
    with wip("Testing function"):
        time.sleep(2)
    with tempfile.TemporaryFile() as f:
        with wip("Testing function"):
            f.write

# Generated at 2022-06-23 17:45:53.944741
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("test")
    assert obj == "test"

    with work_in_progress("Saving file"):
        with open("test", "wb") as f:
            pickle.dump("test", f)

# Generated at 2022-06-23 17:45:55.571902
# Unit test for function work_in_progress
def test_work_in_progress():

    assert True

# Generated at 2022-06-23 17:46:04.691224
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    def save_file(path, obj):
        with open(path, "wb") as f:
            return pickle.dump(obj, f)
    with tempfile.TemporaryDirectory() as tdir:
        tpath = os.path.join(tdir, "tmp.obj")
        data = {"a": 1, "b": ["b", "1", 2], "c": {1: "a", 2: "b"}}
        with work_in_progress("Saving file"):
            save_file(tpath, data)
        with work_in_progress("Loading file"):
            loaded_data = load_file(tpath)
        assert data

# Generated at 2022-06-23 17:46:08.619001
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:46:12.109222
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.5)
    with work_in_progress("Saving file"):
        time.sleep(1.5)
    with work_in_progress("Quitting server"):
        time.sleep(3.5)

# Generated at 2022-06-23 17:46:14.186573
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("test"):
        time.sleep(0.1)

# Generated at 2022-06-23 17:46:14.777609
# Unit test for function work_in_progress
def test_work_in_progress():
    pass

# Generated at 2022-06-23 17:46:20.813508
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:46:22.680372
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Hello World")
    def test():
        time.sleep(2)
    test()

# Generated at 2022-06-23 17:46:24.381907
# Unit test for function work_in_progress
def test_work_in_progress():
    print(__doc__)
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:46:27.372298
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading data"):
        time.sleep(1.5)
    with work_in_progress("Saving data"):
        time.sleep(2.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:46:35.247148
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test the work_in_progress context manager."""
    import time

    text = ""

    @work_in_progress("Loading file")
    def load_file():
        nonlocal text
        with open("output.txt", "rb") as f:
            text = f.read()

    load_file()
    assert text == b"Hello world!\n"


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:46:42.035475
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Loading dict"):
        time.sleep(0.2)
    with work_in_progress("Loading dict"):
        time.sleep(0.1)
    with work_in_progress("Loading dict"):
        time.sleep(0.3)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:46:46.510275
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:46:57.669297
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    from io import BytesIO
    from pickle import dumps, loads
    from tempfile import SpooledTemporaryFile

    class Test:
        def __init__(self, a, b):
            self._a = a
            self._b = b

        def __eq__(self, other):
            return self._a == other._a and self._b == other._b

    with SpooledTemporaryFile() as f:
        @work_in_progress("Loading file")
        def load_file(f):
            return pickle.load(f)

        obj = Test(1, 2)
        pickle.dump(obj, f)
        f.seek(0)
        obj_1 = load_file(f)
        assert obj == obj_1


# Generated at 2022-06-23 17:47:09.411332
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import shutil
    import tempfile
    import sys

    desc = "Work in progress"
    tempdir = tempfile.TemporaryDirectory()
    tempdir_name = tempdir.name
    tempdir.cleanup = lambda: None  # Need to disable it before testing

    # Test in function
    @work_in_progress(desc)
    def work():
        with open(os.path.join(tempdir_name, "some_file.txt"), "w") as f:
            f.write("hello world")

    sys.stdout = open(os.devnull, "w")
    work()
    sys.stdout = sys.__stdout__

# Generated at 2022-06-23 17:47:16.434388
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            time.sleep(3.52)
            return pickle.load(f)

    with work_in_progress("Saving file"):
        time.sleep(3.78)

    obj = load_file("/path/to/some/file")



# Generated at 2022-06-23 17:47:18.234665
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(0.5)

# vim:sw=4:et:

# Generated at 2022-06-23 17:47:21.921332
# Unit test for function work_in_progress
def test_work_in_progress():
    import datetime
    print(f"{'Beginning':=^40}")
    with work_in_progress("Sleeping"):
        time.sleep(3.1415926)
    print(f"{'End':=^40}")

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:47:33.963257
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import pickle
    import shutil
    import tempfile

    # Test the contextmanager decorator
    dummy_content = """
    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
    """


# Generated at 2022-06-23 17:47:40.075350
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import pickle
    import numpy as np
    from io import BytesIO

    # Generate fake image array
    image = np.random.random((256, 256, 3))

    # Pickle the image for 3 seconds
    @work_in_progress("Saving file")
    def save_image(image):
        with BytesIO() as f:
            pickle.dump(image, f)

    # Unpickle the image for 4 seconds
    @work_in_progress("Loading file")
    def load_image():
        with BytesIO() as f:
            image = pickle.load(f)

    # Pickle image
    save_image(image)
    time.sleep(3)

    # Unpickle image
    load_image()
    time.sleep(4)

# Generated at 2022-06-23 17:47:42.665479
# Unit test for function work_in_progress
def test_work_in_progress():
    import doctest
    doctest.testmod(verbose=True)
    doctest.testmod()

# Generated at 2022-06-23 17:47:49.055183
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("my_pickle/test.pkl")

    assert type(obj) is np.ndarray
    assert obj.shape == (3,3)
    np.testing.assert_array_equal(obj, np.arange(1,10).reshape(3,3))

# Generated at 2022-06-23 17:47:54.001064
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file") as progress:
        time.sleep(2.2)
        progress("Loading frame 1")
        time.sleep(2.2)
        progress("Loading frame 2")
        time.sleep(2.2)
        progress("Loading frame 3")
        time.sleep(2.2)
        progress("loading frame 4")
        time.sleep(2.2)
        progress("Loading frame 5")



# Generated at 2022-06-23 17:48:02.073588
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/etc/passwd")
    assert obj is not None, f"File '/etc/passwd' should not be empty."

    with work_in_progress():
        with open("/etc/passwd", "wb") as f:
            pickle.dump(obj, f)

    with open("/etc/passwd", "rb") as f:
        obj_ = pickle.load(f)

    assert obj == obj_, f"The dumped object should be the same as the loaded object."

# Generated at 2022-06-23 17:48:10.781829
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import numpy as np
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.02)
    time.sleep(0.2)
    with work_in_progress("Lagrangian interpolation"):
        for i in range(3):
            time.sleep(0.04)
    time.sleep(0.01)
    with work_in_progress("Generating random numbers"):
        data = np.random.randn(3, 2, 4)
    print(data)

# Generated at 2022-06-23 17:48:18.977189
# Unit test for function work_in_progress
def test_work_in_progress():
    # Time it with function decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")
    assert isinstance(obj, object)

    # Time it with context manager
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:48:20.096162
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Doing work"):
        time.sleep(1)

# Generated at 2022-06-23 17:48:25.309084
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    def foo():
        time.sleep(3)

    with work_in_progress("Testing work_in_progress"):
        foo()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:48:32.208047
# Unit test for function work_in_progress
def test_work_in_progress():
    no_op = lambda: None
    with work_in_progress("Testing work_in_progress") as w:
        w.assert_running("Testing work_in_progress... ")
        time.sleep(0.1)
        w.assert_running("Testing work_in_progress... ")
        time.sleep(0.1)
        w.assert_running("Testing work_in_progress... ")
        time.sleep(0.1)
    assert w.get_running_time() >= 0.3


if __name__ == '__main__':
    # Unit tests
    test_work_in_progress()

# Generated at 2022-06-23 17:48:34.559378
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(0.1)
    with work_in_progress("Test work in progress"):
        time.sleep(0.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:48:38.652486
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:48:44.408857
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3.5)

    with work_in_progress("Saving file"):
        time.sleep(3.78)


if __name__ == "__main__":
    import sys
    import doctest
    doctest.testmod()

    print("All tests passed!")

# Generated at 2022-06-23 17:48:54.429047
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    >>> @work_in_progress("Loading file")
    ... def load_file(path):
    ...     with open(path, "rb") as f:
    ...         return pickle.load(f)
    ...
    ... obj = load_file("/path/to/some/file")
    Loading file... done. (3.52s)

    >>> with work_in_progress("Saving file"):
    ...     with open(path, "wb") as f:
    ...         pickle.dump(obj, f)
    Saving file... done. (3.78s)
    """
    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:48:56.527040
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Simple progress bar"):
        time.sleep(0.5)

# Generated at 2022-06-23 17:49:03.692419
# Unit test for function work_in_progress
def test_work_in_progress():
    # context manager
    with work_in_progress("Testing context manager"):
        time.sleep(1)

    # decorator
    @work_in_progress("Testing decorator")
    def foo():
        time.sleep(1)
    foo()

    # decorator but not using it as context manager
    @work_in_progress("Testing decorator")
    def foo():
        return 1
    foo()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:12.341334
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    with work_in_progress("Test pickle saving"):
        with open("temp.test", "wb") as f:
            pickle.dump([1, 2, 3, ], f)
    with work_in_progress("Test pickle loading"):
        with open("temp.test", "rb") as f:
            loaded_data = pickle.load(f)
    assert loaded_data == [1, 2, 3]
    os.remove("temp.test")

if __name__ == "__main__":
    import doctest
    doctest.testmod()
    test_work_in_progress()

# Generated at 2022-06-23 17:49:18.119712
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    import pickle

    path = "/home/aalvarez/Development/projects/python/cameratools/cameratools/tests/test_data/test.pkl"
    # Loading a 100MB file should take more than 0.1s
    obj = load_file(path)
    assert obj


# Migrating stuff here

# Generated at 2022-06-23 17:49:26.196723
# Unit test for function work_in_progress
def test_work_in_progress():
    # Setup
    path = "./test.pickle"
    with open(path, "wb") as f:
        pickle.dump(12345, f)

    # Actual function
    with work_in_progress("Loading file"):
        with open(path, "rb") as f:
            obj = pickle.load(f)
    assert obj == 12345

    # Teardown
    os.remove(path)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:49:31.491350
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function :func:`~model_factory.utils.work_in_progress`."""
    with work_in_progress("Unit test"):
        time.sleep(1.1)

if __name__ == "__main__":
    # Run unit tests
    try:
        test_work_in_progress()
    except AssertionError as e:
        print(e)

# Generated at 2022-06-23 17:49:37.804900
# Unit test for function work_in_progress
def test_work_in_progress():
    import unittest

    class Test_work_in_progress(unittest.TestCase):
        def test_context_manager(self):
            with work_in_progress("Testing the function"):
                time.sleep(0.7)

        def test_decorator(self):
            @work_in_progress("Testing the function")
            def test():
                time.sleep(0.7)

            test()

    unittest.main(argv=["first-arg-is-ignored"], exit=False)

# Generated at 2022-06-23 17:49:44.762093
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Fetching data"):
        data = {
            "name": "Caio",
            "surname": "Belotti",
            "address": "Piazza Roentgen N.1, Milano"
        }
        time.sleep(1)
    assert data['address'] == "Piazza Roentgen N.1, Milano"

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:46.305370
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Solving the riddle of life"):
        time.sleep(1)

if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-23 17:49:49.154859
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Test Work in Progress"
    with work_in_progress(desc) as wip:
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:57.224220
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:50:02.937984
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import os

    # Unit test
    list_ = list(range(1000000))
    with work_in_progress("Unit test"):
        random.shuffle(list_)
        assert random.sample(list_, 10) == sorted(random.sample(list_, 10))
        print(f"{os.path.abspath(__file__)}: assert successfully.")


if __name__ == '__main__':
    # Test work_in_progress
    test_work_in_progress()

# Generated at 2022-06-23 17:50:13.238057
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress"""

    # Add a dummy task that takes 2 seconds
    def dummy_task_2s():
        begin_time = time.time()
        while time.time() - begin_time < 2:
            pass

    # Add a dummy task that takes 3 seconds
    def dummy_task_3s():
        begin_time = time.time()
        while time.time() - begin_time < 3:
            pass

    # Case 1
    with work_in_progress("Loading file"):
        dummy_task_2s()

    # Case 2
    dummy_task_3s()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:50:14.335464
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Time the execution of a task"):
        time.sleep(1)


# Generated at 2022-06-23 17:50:15.749897
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(3)

# Generated at 2022-06-23 17:50:23.054821
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test the function work_in_progress()."""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
        pass

    obj = load_file("/path/to/some/file")
    pass

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    return True

# Generated at 2022-06-23 17:50:26.829849
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing")
    def some_time_consuming_func():
        time.sleep(2)
    try:
        some_time_consuming_func()
    except KeyboardInterrupt as e:
        pass

# Generated at 2022-06-23 17:50:35.626501
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import pickle

    r"""Unit Test for function work_in_progress
    """
    with work_in_progress("Dummy Work"):
        time.sleep(1)

    obj = range(10000)
    with tempfile.TemporaryDirectory() as dir:
        path = dir + "/obj.pickle"
        with work_in_progress("Saving Object"):
            with open(path, "wb") as f:
                pickle.dump(obj, f)
        with work_in_progress("Loading Object"):
            with open(path, "rb") as f:
                obj = pickle.load(f)



# Generated at 2022-06-23 17:50:45.138871
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj, expected_path = 1, os.path.join(os.path.dirname(__file__), "test.pkl")
    with open(expected_path, "wb") as f:
        pickle.dump(obj, f)

    assert load_file(expected_path) == obj
    os.remove(expected_path)

# Execution of the unit test only if the script is called directly
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:50:48.386081
# Unit test for function work_in_progress
def test_work_in_progress():
    assert True


if __name__ == "__main__":
    # Running this document will execute all 
    # code and documentation strings.
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:50:51.136167
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    from contextlib import contextmanager

    @contextmanager
    def sleep_1_sec():
        time.sleep(1)
        yield

    @contextmanager
    def sleep_10_sec():
        time.sleep(10)
        yield

    with work_in_progress("Should be faster"):
        with sleep_1_sec():
            pass

    with work_in_progress("Should be slower"):
        with sleep_10_sec():
            pass


# Generated at 2022-06-23 17:50:55.225216
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for the function work_in_progress.

    .. code:: python

        >>> test_work_in_progress()
        Work in progress... done. (0.00s)
        Done.
    """
    with work_in_progress("Work in progress"):
        pass
    print("Done.")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:50:58.133220
# Unit test for function work_in_progress
def test_work_in_progress():
    with pytest.raises(AssertionError):
        with work_in_progress("msg"):
            raise AssertionError("some error")

# Generated at 2022-06-23 17:51:08.345782
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import pickle
    from contextlib import redirect_stdout

    class Foo(object):
        def __init__(self, x, y, z):
            self.x = x
            self.y = y
            self.z = z

    path = os.path.join(os.path.dirname(__file__), "tmp.file")

    with redirect_stdout(open(os.devnull, 'w')):
        obj = Foo(1, 2, 3)
        with work_in_progress("Saving file"):
            with open(path, "wb") as f:
                pickle.dump(obj, f)

        obj.x = 10

# Generated at 2022-06-23 17:51:16.167656
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:22.955072
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test work_in_progress

    :return: A boolean, True if the test is passed without error.
    """
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:28.715061
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path: str):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:51:31.662970
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Executing task"):
        time.sleep(0.3)

if __name__ != "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:36.912553
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function :func:`work_in_progress`."""
    @work_in_progress("Test work_in_progress")
    def test_work_in_progress_func():
        time.sleep(0.5)
    test_work_in_progress_func()


# Generated at 2022-06-23 17:51:45.388318
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1.0)
        with open(path, "rb") as f:
            return pickle.load(f)

    path = os.path.join(os.path.dirname(__file__), "../LICENSE")
    obj = load_file(path)

    with work_in_progress("Saving file"):
        with tempfile.NamedTemporaryFile(delete=False) as f:
            pickle.dump(obj, f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:51:49.244565
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Function Work In Progress"
    with work_in_progress(desc = desc):
        time.sleep(2)
    # Output should be in the form:
    #    "Function Work In Progress... done. (2.00s)"

# *****************************************************************************

import random
import string


# Generated at 2022-06-23 17:51:53.419949
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
        return None
    load_file.__name__ = "load_file"
    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:51:57.391046
# Unit test for function work_in_progress
def test_work_in_progress():

    def test_function(waiting_time: int):
        with work_in_progress("Test function"):
            time.sleep(waiting_time)

    test_function(0.01)

# Generated at 2022-06-23 17:52:04.147702
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "r") as f:
            return f.read()

    with work_in_progress("Computing"):
        _ = load_file(__file__)

    with work_in_progress():
        _ = load_file(__file__)


# Run the unit test if executed as the main program
if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:52:10.808619
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            time.sleep(3)
            return pickle.load(f)

    with open("test.pickle", "wb") as f:
        pickle.dump(dict(), f)

    obj = load_file("test.pickle")
    assert obj == dict()
    os.remove("test.pickle")

# Generated at 2022-06-23 17:52:18.324998
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    with work_in_progress("Saving file"):
        with open("/tmp/test_work_in_progress", "wb") as f:
            pickle.dump({"a": 1}, f)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/tmp/test_work_in_progress")

    # Clean up
    os.remove("/tmp/test_work_in_progress")

    assert obj == {"a": 1}

# Generated at 2022-06-23 17:52:21.086733
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Stubbing out database"):
        time.sleep(1)
    with work_in_progress("Loading database"):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:31.314410
# Unit test for function work_in_progress
def test_work_in_progress():
    import sys
    import os
    from io import BytesIO
    from . import new_temp_file

    temp_file = new_temp_file(suffix='.pkl')

    # with statement
    with BytesIO() as f:
        with work_in_progress("Saving file"):
            pickle.dump(dict(one=1, two=2), f)

    # decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file(temp_file)

    assert obj == dict(one=1, two=2)

    os.remove(temp_file)

# Generated at 2022-06-23 17:52:40.608038
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    time.sleep(0.1)
    @work_in_progress(desc="Loading a file")
    def load_a_file(path: str):
        time.sleep(0.1)
        return open(path).read()
    load_a_file("nonexistent_file")
    with work_in_progress(desc="Working on some string data"):
        time.sleep(0.1)
        data = "a" * 1e6
        time.sleep(0.1)
        hash_value = hash(data)
        time.sleep(0.1)
        print(f"hash value is {hash_value}")
    print("Done.")

# test_work_in_progress()

# Generated at 2022-06-23 17:52:43.872407
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(1)
    with work_in_progress("Sleep 1 second"):
        time.sleep(1)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:52:46.834679
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def func():
        time.sleep(0.0015)
     
    with work_in_progress("Saving file"):
        time.sleep(0.0009)
    
    func()

# Generated at 2022-06-23 17:52:48.892039
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(0.5)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:54.148307
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    save_file(obj, "/path/to/some/file")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:56.219348
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3.52)

# Generated at 2022-06-23 17:53:06.589746
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1)
        with open(path, "rb") as f:
            return pickle.load(f)

    with tempfile.TemporaryDirectory() as folder:
        with open(os.path.join(folder, "foo.txt"), "wb") as f:
            pickle.dump({"foo": "bar"}, f)

        o = load_file(os.path.join(folder, "foo.txt"))

        with work_in_progress("Saving file"):
            time.sleep(1.2)
            with open(os.path.join(folder, "bar.txt"), "wb") as f:
                pickle.dump(o, f)