

# Generated at 2022-06-23 17:43:12.260973
# Unit test for function work_in_progress
def test_work_in_progress():
    class Test:
        @work_in_progress("Loading file")
        def load_file(self, path):
            """Load an object from a file."""
            with open(path + ".bin", "rb") as f:
                return pickle.load(f)

        @work_in_progress("Saving file")
        def save_file(self, obj, path):
            """Save an object to a file."""
            with open(path + ".bin", "wb") as f:
                pickle.dump(obj, f)

        @work_in_progress("Appending an item")
        def append_item(self, obj, item):
            """Append an item to an object."""
            time.sleep(1)
            obj.append(item)


# Generated at 2022-06-23 17:43:18.633994
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("test.pkl")
    assert(isinstance(obj, Module))

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:43:23.762098
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress."""
    print(__doc__)

    with work_in_progress("Work in progress"):
        time.sleep(3.14)
        time.sleep(3.14)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:43:30.553285
# Unit test for function work_in_progress
def test_work_in_progress():

    # Work in progress (function)
    @work_in_progress("Loading file")
    def load_file(path: str = "dummy.txt"):
        """Dummy function to test work_in_progress()"""
        # Take some time to execute
        time.sleep(0.1)
        with open(path, "r") as f:
            return f.read()

    load_file()


    # Work in progress (code block)
    with work_in_progress("Saving file"):
        # Take some time to execute
        time.sleep(0.5)
        with open("dummy.txt", "w") as f:
            f.write("dummy")

# Generated at 2022-06-23 17:43:35.013064
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("A task")
    def foo():
        time.sleep(1.0)
    time.sleep(0.2)
    foo()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:43:46.033633
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test function work_in_progress."""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("./test/test_data/utils.pickle")
    assert obj == {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': 4,
        'e': 5,
        'f': 6,
        'g': 7,
        'h': 8,
        'i': 9,
        'j': 10,
    }
    with work_in_progress("Saving file"):
        with open("./test/test_data/utils.pickle", "wb") as f:
            pickle.dump

# Generated at 2022-06-23 17:43:52.186407
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert isinstance(obj, int)

    with work_in_progress("Saving file"):
        with open("/path/to/some/other/file", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:43:55.881986
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test")
    def test_func():
        time.sleep(0.1)
    test_func()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:43:59.928382
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Doing some meaningless job", end='', flush=True)
    time.sleep(2.4)
    print("... done. (2.40s)")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:44:03.228757
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Processing user data"):
        time.sleep(0.371)
    print("Processing user data... done. (0.37s)")

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:44:15.168128
# Unit test for function work_in_progress
def test_work_in_progress():
    print("[test_work_in_progress]")

    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(3)
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path):
        time.sleep(4)
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    path = "C:\\Matching\\test.pkl"
    data = [1, 2, 3, 4, 5]
    obj = {'a': 'b', 'c': 'd'}

    with open(path, "wb") as f:
        pickle.dump(data, f)

    data_loaded = load

# Generated at 2022-06-23 17:44:25.999636
# Unit test for function work_in_progress
def test_work_in_progress():
    info = []

    def callback(desc, time_consumed):
        info.append((desc, time_consumed))

    with contextlib.ExitStack() as stack:
        stack.enter_context(unittest.mock.patch("sys.stdout.write"))
        stack.enter_context(unittest.mock.patch("time.time", return_value=1234))
        with work_in_progress("foo"):
            pass
        callback("foo", 1234 - 1234)
        time.sleep(0.1)
        with work_in_progress("bar"):
            pass
        callback("bar", 1234 - 1234)

    assert info == [("foo", 0.0), ("bar", 0.1)]

# Generated at 2022-06-23 17:44:28.093467
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Loading file"
    with work_in_progress(desc) as w:
        pass
    assert desc + "... done. (0.00s)" == str(w)

# Generated at 2022-06-23 17:44:32.800947
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def work():
        time.sleep(1)

    with work_in_progress("Testing work_in_progress"):
        time.sleep(1)

# Generated at 2022-06-23 17:44:36.512464
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3.52)
    # Loading file... done. (3.52)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:44:40.827400
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test for context manager
    with work_in_progress("Test context manager"):
        pass

    # Test for decorator
    @work_in_progress("Test decorator")
    def my_func():
        pass

    my_func()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:44:42.703261
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress()"):
        time.sleep(0.125)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:44:48.959799
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:44:54.274585
# Unit test for function work_in_progress
def test_work_in_progress():
    fname = "/tmp/test_work_in_progress.pkl"
    with work_in_progress("Saving file"):
        with open(fname, "wb") as f:
            pickle.dump(dict(a=1), f)
    assert(os.path.exists(fname))
    with work_in_progress("Loading file"):
        with open(fname, "rb") as f:
            ret = pickle.load(f)
    assert(ret == dict(a=1))
    os.remove(fname)

# Generated at 2022-06-23 17:45:05.390697
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Initializing"):
        time.sleep(1)
        with work_in_progress("Loading data"):
            time.sleep(2)

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    dict = load_file("/home/zvyagin/stuff/dictionary.pickle")

    with work_in_progress("Saving file"):
        with open("/home/zvyagin/stuff/dictionary_copy.pickle", "wb") as f:
            pickle.dump(dict, f)



# Generated at 2022-06-23 17:45:14.297668
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    obj = load_file("test/test_file.pickle")
    save_file("test/test_file.pickle", obj)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:45:16.536465
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile
    with tempfile.TemporaryDirectory() as tempdir:
        with work_in_progress("Saving file"):
            with open(os.path.join(tempdir, "file.txt"), "wb") as f:
                f.write(b"Hello world!")

# Generated at 2022-06-23 17:45:24.662771
# Unit test for function work_in_progress
def test_work_in_progress():
    '''Test the work_in_progress function'''
    assert work_in_progress.__doc__ == 'Time the execution time of a code ' \
        'block or function.\n\n    .. code:: python\n\n        ' \
        '>>> @work_in_progress("Loading file")\n        ... def load_file(path):\n' \
        '        ...     with open(path, "rb") as f:\n        ...         return ' \
        'pickle.load(f)\n        ...\n        ... obj = load_file("/path/to/' \
        'some/file")\n        Loading file... done. (3.52s)\n\n        >>> with ' \
        'work_in_progress("Saving file"):\n        ...     with open(path, ' \
       

# Generated at 2022-06-23 17:45:29.780364
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    with open("test.pickle", "wb") as f:
        pickle.dump({"foo": "bar"}, f)

    with open("test.pickle", "rb") as f:
        obj = pickle.load(f)


# Generated at 2022-06-23 17:45:34.219181
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def test():
        with work_in_progress("Subtask"):
            time.sleep(1)

    test()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:45:39.543751
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress."""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:45:43.320098
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work in progress"):
        time.sleep(1)

if __name__ == '__main__':
    import doctest
    doctest.testmod()
    test_work_in_progress()

# Generated at 2022-06-23 17:45:45.979008
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test work in progress"):
        time.sleep(1)

# Generated at 2022-06-23 17:45:50.274176
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def func():
        time.sleep(1)
    func()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:45:56.132707
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress(" Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")
    save_file(obj, "/path/to/some/other/file")

# Generated at 2022-06-23 17:46:03.599339
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import random

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert obj, "Cannot identify the obj, or file is empty."

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    assert obj, "Cannot identify the obj, or file is empty."

# Generated at 2022-06-23 17:46:06.824836
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Hi")
    def foo():
        time.sleep(2)
    foo()

    with work_in_progress("Hi"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:46:10.554717
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3)


if __name__ == "__main__":
    test_work_in_progress()
    #
    # import doctest
    # doctest.testmod()

# Generated at 2022-06-23 17:46:20.599132
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing function work_in_progress"):
        time.sleep(0.2)
    with work_in_progress("Testing function work_in_progress"):
        time.sleep(3.2)
    @work_in_progress("Testing function work_in_progress")
    def test_func():
        time.sleep(0.2)
    test_func()
    @work_in_progress("Testing function work_in_progress")
    def test_func():
        time.sleep(3.2)
    test_func()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:46:26.607582
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 17:46:31.655595
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Testing... "
    with work_in_progress(desc):
        time.sleep(0.2)
    assert True

# Generated at 2022-06-23 17:46:34.353600
# Unit test for function work_in_progress
def test_work_in_progress():
    total = 10
    with work_in_progress("Performing some loop"):
        for i in range(total):
            time.sleep(1)
    assert True

# Generated at 2022-06-23 17:46:42.902316
# Unit test for function work_in_progress
def test_work_in_progress():
    def test_func_1(secs):
        with work_in_progress(f"Test 1 (in {secs} secs)"):
            time.sleep(secs)
    test_func_1(1)

    @work_in_progress("Test in 2 secs")
    def test_func_2(secs):
        time.sleep(secs)
    test_func_2(2)

    print('\n'*2)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:46:48.627323
# Unit test for function work_in_progress
def test_work_in_progress():

    # Test the function in class context
    class TestClass:
        def __init__(self, text):
            self.text = text

        def is_empty(self):
            with work_in_progress(f"Checking string \"{self.text}\"") as work:
                work.step('Initialising')
                time.sleep(0.05)

            return self.text == ''

        def times_two(self):
            with work_in_progress(f"Multiplying string \"{self.text}\" by 2"):
                return self.text * 2

        def split_string(self):
            with work_in_progress(f"Splitting string \"{self.text}\"") as work:
                work.step('Splitting')
                time.sleep(0.05)

                work.step('Cleaning up')

# Generated at 2022-06-23 17:46:56.491714
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    save_file("/path/to/some/other/file", obj)

# Generated at 2022-06-23 17:47:03.443413
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "tests/test_data/test_data.pickle"
    obj = load_file(path)
    assert obj == {"a": "b"}

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump({"a": "c"}, f)

    obj = load_file(path)
    assert obj == {"a": "c"}

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:47:09.213121
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("16.2"):
        time.sleep(0.5)
    with work_in_progress("16.2"):
        time.sleep(0.5)
        with work_in_progress("16.2"):
            time.sleep(0.5)
        time.sleep(0.5)
    with work_in_progress("16.2"):
        time.sleep(0.5)

# Generated at 2022-06-23 17:47:15.582969
# Unit test for function work_in_progress
def test_work_in_progress():
    obj = dict()

    with work_in_progress("Loading file"):
        with open("/path/to/some/file", "rb") as f:
            obj = pickle.load(f)

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:47:18.234838
# Unit test for function work_in_progress
def test_work_in_progress():
    desc_work_in_progress = "Loading file"

    @work_in_progress(desc_work_in_progress)
    def dummy_function():
        time.sleep(0.5)

    dummy_function()

# Generated at 2022-06-23 17:47:20.726021
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(1)

# Generated at 2022-06-23 17:47:27.841098
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Waiting"):
        time.sleep(1)

    @work_in_progress("Waiting")
    def sleep(sec: float = 1.0):
        time.sleep(sec)

    sleep()


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:47:33.228127
# Unit test for function work_in_progress
def test_work_in_progress():
    # 1. Using class
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.5)

    # 2. Using decorator
    @work_in_progress("Testing work_in_progress")
    def some_function():
        time.sleep(0.5)

    some_function()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:47:35.523053
# Unit test for function work_in_progress
def test_work_in_progress():
    def foo():
        time.sleep(0.5)
    with work_in_progress("Sleeping"):
        foo()

# Generated at 2022-06-23 17:47:41.086756
# Unit test for function work_in_progress
def test_work_in_progress():
    from unittest import TestCase, main
    from io import StringIO
    from contextlib import redirect_stdout

    class TestWorkInProgress(TestCase):
        def test_work_in_progress(self):
            with redirect_stdout(StringIO()) as stdout:
                with work_in_progress("Loading file"):
                    time.sleep(3.52)
            self.assertEqual("Loading file... done. (3.52s)\n", stdout.getvalue())

    main(argv=[__file__])

# Generated at 2022-06-23 17:47:48.972688
# Unit test for function work_in_progress
def test_work_in_progress():
    import unittest.mock as mock
    with mock.patch("pyutils.misc.time.time") as mock_time:
        obj = object()
        mock_time.return_value = 1.0
        with work_in_progress("Test block"):
            mock_time.return_value = 1.1
            assert not "obj" in locals()
            obj = object()
        mock_time.return_value = 1.2
        assert "obj" in locals()
        assert locals()["obj"] is obj


# Generated at 2022-06-23 17:47:52.784867
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert type(obj)==type(1)

# Generated at 2022-06-23 17:47:54.927076
# Unit test for function work_in_progress
def test_work_in_progress():
    import contextlib
    import time

    @work_in_progress(desc="Test")
    def w():
        time.sleep(0.01)

    with work_in_progress():
        time.sleep(0.01)

# Generated at 2022-06-23 17:48:00.157497
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress"""
    import random
    print("Testing function work_in_progress...", end="")

    # Test with a context manager
    with work_in_progress("Testing context manager"):
        time.sleep(1.0)

    # Test with a decorator
    @work_in_progress("Testing decorator")
    def __some_work():
        time.sleep(1.0)

    __some_work()

    print("Done.")

# Main program of this module

# Generated at 2022-06-23 17:48:04.493353
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test work_in_progress function
    assert work_in_progress("About To Open a File")

# Execute functions with Ctrl+F5 in Python Idle
if __name__ == "__main__":
    test_work_in_progress()
    input("Done! Press any key to exit ...")

# Generated at 2022-06-23 17:48:12.255808
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    def func1(sec: float):
        time.sleep(sec)
        return "Success"

    def func2():
        time.sleep(2.0)
        return "Success"

    class Loader:
        def __init__(self, load_time: float):
            self.load_time = load_time

        def load(self):
            time.sleep(self.load_time)
            return "Success"

    @work_in_progress("Test 1")
    def test1():
        return func1(3.0)

    @work_in_progress("Test 2")
    def test2():
        return func2()

    @work_in_progress("Test 3")
    def test3():
        loader = Loader(5.0)
        return loader.load()


# Generated at 2022-06-23 17:48:17.302056
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test context manager with block
    with work_in_progress("Block"):
        time.sleep(2)

    # Test context manager with function
    @work_in_progress("Function")
    def do_work():
        time.sleep(3)

    do_work()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:48:23.569427
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-23 17:48:32.323857
# Unit test for function work_in_progress
def test_work_in_progress():
    from .test_utils import TestCase, TemporaryDirectory
    from io import StringIO
    import os

    class TestCase(TestCase):
        def test_progress_timer(self):
            with TemporaryDirectory() as temp_dir:
                filename = os.path.join(temp_dir, "test_progress_timer")
                with open(filename, "w") as f:
                    f.write("This is a test file.")

                with StringIO() as stdout:
                    with work_in_progress("Loading file", stdout=stdout):
                        with open(filename, "rb") as f:
                            f.read()

                    self.assertRegexpMatches(stdout.getvalue(),
                                             "Loading file\s+\.\.\.\s+done\.")

# Generated at 2022-06-23 17:48:35.594384
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Caching data")
    def func_for_test():
        """This function has a short running time but does nothing useful."""
        time.sleep(0.1)

    func_for_test()
    with work_in_progress("Caching data"):
        time.sleep(0.1)



# Generated at 2022-06-23 17:48:38.593398
# Unit test for function work_in_progress
def test_work_in_progress():
    for desc in ["Making the thing", "Cooking the food"]:
        with work_in_progress(desc):
            time.sleep(1.5)

# Generated at 2022-06-23 17:48:42.823873
# Unit test for function work_in_progress
def test_work_in_progress():
    try:
        with work_in_progress("Testing work_in_progress"):
            time.sleep(0.1)
    except KeyboardInterrupt as e:
        print(e)



# Generated at 2022-06-23 17:48:54.042202
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress()
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("files/test_file.pickle")
    assert isinstance(obj, list)
    obj = load_file(path="files/test_file.pickle")
    assert isinstance(obj, list)


# Generated at 2022-06-23 17:48:59.842667
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import time
    import sys

    @work_in_progress("Test function")
    def test_func():
        time.sleep(random.random() / 10)

    @work_in_progress("Test function")
    def test_func_fail():
        raise RuntimeError("foo")

    saved_stdout = sys.stdout
    sys.stdout = sys.stderr

    test_func()
    try:
        test_func_fail()
    except:
        pass

    sys.stdout = saved_stdout


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:03.135744
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress
    def func():
        time.sleep(2)

    func()


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:49:06.167537
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.75)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:12.052569
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1)
        return path

    path = load_file("/path/to/some/file")
    assert path == "/path/to/some/file"

    with work_in_progress("Saving file"):
        time.sleep(1)


# vim:sw=4:ts=4:et:

# Generated at 2022-06-23 17:49:17.212162
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress('Test function'):
        time.sleep(1)


if __name__ == '__main__':
    test_work_in_progress()

# References
# [1] https://github.com/r9y9/nnmnkwii/blob/master/tests/test_util.py#L7
# [2] https://github.com/r9y9/nnmnkwii/blob/master/tests/test_util.py#L112

# Generated at 2022-06-23 17:49:21.968954
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Unit test for work_in_progress"):
        time.sleep(1.23)
    assert 1.2 <= time.time() - begin_time <= 1.25
    print("test_work_in_progress passed.")

# Unit test
if __name__ == "__main__":
    begin_time = time.time()
    test_work_in_progress()

# Generated at 2022-06-23 17:49:32.558563
# Unit test for function work_in_progress
def test_work_in_progress():
    # Example of working with WorkInProgress:
    # 1. Create a function
    # 2. Create a WorkInProgress instance
    # 3. Call function with WorkInProgress instance.
    #
    # :param desc: Description of the task performed.
    # :type desc: str, optional
    # :return:
    # :rtype:
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    # Data to save and test
    obj = 'helloworld'

    # Test loading
    save_

# Generated at 2022-06-23 17:49:36.460611
# Unit test for function work_in_progress
def test_work_in_progress():
    with pytest.raises(ZeroDivisionError):
        with work_in_progress("Test"):
            1 / 0
    with work_in_progress("Test"):
        time.sleep(1)
    with work_in_progress("Test"):
        pass

# Generated at 2022-06-23 17:49:41.108977
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Doing stuff")
    def do_stuff():
        time.sleep(1)
        return "All done"

    assert do_stuff() == "All done"

    @work_in_progress("Doing stuff")
    def do_stuff():
        with time.localtime() as t:
            time.sleep(2)

    do_stuff()

# Generated at 2022-06-23 17:49:47.174224
# Unit test for function work_in_progress
def test_work_in_progress():
    def test_print():
        with work_in_progress("Unit test"):
            print("Unit test")
    test_print()

    def test_save():
        with work_in_progress("Unit test"):
            with open("test.txt", "w") as f:
                f.write("Unit test")
    test_save()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:50.096721
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Task"):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:49:56.342022
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress()"):
        time.sleep(0.5)
    with work_in_progress("Testing work_in_progress() (default desc)"):
        time.sleep(0.5)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:50:05.037851
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import tempfile

    time.sleep(0.5)
    with work_in_progress(desc="Working on it"):
        time.sleep(0.5)
        for _ in range(2): # emulate the work
            time.sleep(0.1)
    print()

    with tempfile.TemporaryDirectory() as tmpdir:
        fname = f"{tmpdir}/dummy.txt"
        @work_in_progress(desc=f"Writing to file {fname}")
        def write_file(fname):
            with open(fname, "w") as f:
                f.write("Hello, world")

        write_file(fname)
        print()


# Generated at 2022-06-23 17:50:08.691022
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(0.5)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:50:10.424452
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Test"):
        time.sleep(1)

# Generated at 2022-06-23 17:50:18.757676
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    >>> delete_file = work_in_progress("Checking if file exists")
    >>> with delete_file:
    ...     time.sleep(0.1)
    ...
    Checking if file exists... done. (0.10s)
    >>> def load_file(path):
    ...     load = work_in_progress("Loading file {}".format(path))
    ...     with load:
    ...         time.sleep(2)
    ...     return 5
    ...
    >>> load_file("/path/to/file")
    Loading file /path/to/file... done. (2.00s)
    5
    """
    pass

if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-23 17:50:27.083214
# Unit test for function work_in_progress
def test_work_in_progress():

    # Test for context block
    with work_in_progress("Saving file"):
        time.sleep(1)

    # Test for context manager
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

    assert(True)
    print("Test work_in_progress passed.")

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:50:32.833173
# Unit test for function work_in_progress
def test_work_in_progress():
    # Unit test for function work_in_progress
    @work_in_progress("Loading file")
    def load_file(path: str):
        with open(path, "rb") as f:
            obj = pickle.load(f)
        return obj

    path = "./test/data/pickle_object.pkl"
    obj = load_file(path)

    with work_in_progress("Saving file"):
        with open("./test/data/pickle_object.pkl", "wb") as f:
            pickle.dump(obj, f)

    print("Done.")

# Generated at 2022-06-23 17:50:35.639595
# Unit test for function work_in_progress
def test_work_in_progress():
    def my_function(x: str, y: str) -> str:
        time.sleep(0.1)
        return x + y

    with work_in_progress("My function"):
        my_function("Hello", "world")

    assert True

# Generated at 2022-06-23 17:50:43.410738
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    s = "Some text"
    t = time.time()
    with work_in_progress("Test"):
        time.sleep(1.0)
        with open("temp.txt", "wb") as f:
            pickle.dump(s, f)
    with work_in_progress("Test"):
        time.sleep(1.0)
        with open("temp.txt", "rb") as f:
            assert pickle.load(f) == s
    t = time.time() - t
    assert abs(t - 2) < 0.2

# Generated at 2022-06-23 17:50:54.493187
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1)
        with open(path, "rb") as f:
            return pickle.load(f)

    class Obj:
        def __init__(self, value):
            self.value = value

    with tempfile.TemporaryDirectory() as tempdir:
        path = os.path.join(tempdir, "temp.pkl")
        with open(path, "wb") as f:
            pickle.dump(Obj("My data"), f)
        obj = load_file(path)
        assert obj.value == "My data"

        with work_in_progress("Saving file"):
            time.sleep(1)
            with open(path, "rb") as f:
                return pickle

# Generated at 2022-06-23 17:50:55.829878
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)

# Generated at 2022-06-23 17:51:06.905273
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    from pathlib import Path

    test_file = Path('test.pkl')
    test_data = {'data': 'test'}

    assert(work_in_progress)

    # work_in_progress with function
    @work_in_progress("Test file pickle load")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # work_in_progress with context manager
    with work_in_progress("Test file pickle dump") as dump_file:
        with open(test_file, "wb") as f:
            pickle.dump(test_data, f)
        time.sleep(3)

    assert(load_file(test_file) == test_data)
    test_file.unlink()




# Generated at 2022-06-23 17:51:10.530860
# Unit test for function work_in_progress
def test_work_in_progress():
    DESC = "Test work_in_progress"
    with work_in_progress(DESC):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:16.566223
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(2)
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        time.sleep(1)

    obj = load_file("/path/to/some/file")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:24.008166
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import pickle

    # Test function
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1)
        with open(path, "rb") as f:
            return pickle.load(f)

    test_obj = load_file("/path/to/test/file")
    assert test_obj.get("key") == "value", "Test object should be {'key': 'value'}"

    # Test context
    with work_in_progress("Saving file"):
        time.sleep(1)
        with open("/path/to/save/file", "wb") as f:
            pickle.dump(test_obj, f)

# Generated at 2022-06-23 17:51:33.546911
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        return open(path, "rb").read()

    with open("tests/data/file.1", "wb") as f:
        f.write(b"a" * (1 << 16))

    load_file("tests/data/file.1")

    with work_in_progress("Saving file"):
        with open("tests/data/file.2", "wb") as f:
            f.write(b"a" * (1 << 16))

    os.remove("tests/data/file.1")
    os.remove("tests/data/file.2")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:51:42.569097
# Unit test for function work_in_progress
def test_work_in_progress():

    # define the test function
    def test_function(iterations=1000, sleep_time=0.001):

        # loop
        time.sleep(sleep_time)

    # Unit Test
    import time
    with work_in_progress('Testing work_in_progress function'):
        test_function(1000, 0.1)

    # Unit Test
    import sys
    print('Testing work_in_progress function with assert', file=sys.stderr)
    with work_in_progress('Testing work_in_progress function with assert'):
        assert test_function(1000, 0.1)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:51:48.081939
# Unit test for function work_in_progress
def test_work_in_progress():

    def some_task(t: float):
        time.sleep(t)

    tasks = []  # type: List[Tuple[str, float]]
    tasks.append(("a task with a large time", 20.0))
    tasks.append(("a task with a small time", 0.1))

    for desc, t in tasks:
        with work_in_progress(desc):
            some_task(t)

# Generated at 2022-06-23 17:51:48.497419
# Unit test for function work_in_progress
def test_work_in_progress():
    assert True

# Generated at 2022-06-23 17:51:52.937948
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def my_func():
        time.sleep(1.1)
        return "File loaded"

    obj = my_func()
    assert obj == "File loaded"
    assert True

    with work_in_progress("Saving file"):
        time.sleep(1.1)
    assert True

# Generated at 2022-06-23 17:52:04.258011
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import sys

    def fake_io(t: float):
        time.sleep(t)

    def test():
        with work_in_progress("Loading file"):
            fake_io(1.34)

        with work_in_progress("Saving file"):
            fake_io(1.44)

    # Capture output.
    sys.stdout = io.StringIO()
    test()
    output = sys.stdout.getvalue()
    sys.stdout = sys.__stdout__

    import unittest.mock
    with unittest.mock.patch.object(time, "time") as mock_time:
        mock_time.return_value = 0.0
        test()
        output_ref = sys.stdout.getvalue()
        assert output_ref == output




# Generated at 2022-06-23 17:52:06.280312
# Unit test for function work_in_progress
def test_work_in_progress():
    # Function is tested by the example in its docstring
    pass

# Generated at 2022-06-23 17:52:09.256226
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Sleeping for a bit")
    def sleeper():
        time.sleep(0.3)
    sleeper()


# Generated at 2022-06-23 17:52:16.633151
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-23 17:52:23.097699
# Unit test for function work_in_progress
def test_work_in_progress():
    import unittest
    import io
    import sys

    class TestWorkInProgress(unittest.TestCase):
        def setUp(self):
            sys.stdout = self.__stdout = io.StringIO()

        def tearDown(self):
            sys.stdout = sys.__stdout__

        def test_work_in_progress(self):
            with work_in_progress("Doing something"):
                time.sleep(0.5)
            self.assertTrue("Doing something... done. (0.50s)" in self.__stdout.getvalue())

    unittest.main(verbosity=2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:26.954440
# Unit test for function work_in_progress
def test_work_in_progress():
    def foo():
        time.sleep(0.1)

    with work_in_progress():
        foo()

    @work_in_progress()
    def bar():
        time.sleep(0.2)

    bar()

# Generated at 2022-06-23 17:52:35.451461
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("work_in_progress.py")
    assert obj is not None

    with work_in_progress("Saving file"):
        path = "work_in_progress.py.copy"
        with open(path, "wb") as f:
            pickle.dump(obj, f)
        os.unlink(path)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:42.316212
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing function work_in_progress...", end=' ')
    try:
        @work_in_progress("Testing function work_in_progress")
        def test_work_in_progress_decorator():
            time.sleep(5)
        test_work_in_progress_decorator()
        print("passed.")
    except:
        traceback.print_exc()
        print("failed!")
    try:
        with work_in_progress("Testing function work_in_progress") as w:
            time.sleep(5)
        print("passed.")
    except:
        traceback.print_exc()
        print("failed!")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:46.060286
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress(desc="Some task"):
        time.sleep(1)
    with work_in_progress():
        time.sleep(2)
    print()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-23 17:52:49.650324
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)

    @work_in_progress("Saving file")
    def save_file():
        time.sleep(2)

    save_file()


if __name__ == "__main__":
    # Run unit test
    test_work_in_progress()

# Generated at 2022-06-23 17:52:54.263487
# Unit test for function work_in_progress
def test_work_in_progress():
    # FIXME: hoist functions below in unit test
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open("tests/dummy.pkl", "wb") as f:
            pickle.dump("hello, world!", f)

    obj = load_file("tests/dummy.pkl")
    assert obj == "hello, world!"

# Generated at 2022-06-23 17:52:57.827963
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test work in progress"):
        time.sleep(1)
    assert True


if __name__ == '__main__':
    # Unit tests:
    test_work_in_progress()

# Generated at 2022-06-23 17:53:05.157625
# Unit test for function work_in_progress
def test_work_in_progress():
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        print(f"tmpdir: {tmpdir}")

        for i in range(5):
            path = Path(tmpdir) / f"file_{i}.txt"

            @work_in_progress(f"Saving file {i}")
            def _save_file(path):
                time.sleep(0.2)
                path.open("w").close()

            _save_file(path)