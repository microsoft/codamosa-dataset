

# Generated at 2022-06-21 12:22:54.875786
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("test_file_io.pickle")

    with work_in_progress("Saving file"):
        with open("test_file_io.pickle", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:22:59.748188
# Unit test for function work_in_progress
def test_work_in_progress():
    """Randomly selected test of function work_in_progress

    To run:
        In console, run
        ```
        python3 -m pytest
        ```
        or run
        ```
        pytest
        ```
        depending on your system settings.
    """
    with work_in_progress("Testing work in progress"):
        time.sleep(0.2)

# Generated at 2022-06-21 12:23:08.418178
# Unit test for function work_in_progress
def test_work_in_progress():
    obj = dict(a = [1, 2, 3])

    with open('temp.pkl', 'wb') as f:
        with work_in_progress('Saving file'):
            pickle.dump(obj, f)

    with open('temp.pkl', 'rb') as f:
        with work_in_progress('Loading file'):
            obj = pickle.load(f)

    print(obj)
    os.remove('temp.pkl')


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:17.785889
# Unit test for function work_in_progress
def test_work_in_progress():
    class A:
        pass

    data = A()
    data.name = "Hello"
    data.priority = 5

    # Test 1:
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    assert obj.name == "Hello"
    assert obj.priority == 5
    assert obj.has_milk == False
    assert obj.has_candy == True

    # Test 2:
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

#
# if __name__ == "__main__":
#     test

# Generated at 2022-06-21 12:23:25.278105
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle, time, os
    from pathlib import Path
    from tempfile import TemporaryDirectory

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path, obj):
        with open(path, "wb") as f:
            return pickle.dump(obj, f)

    assert 'load_file' not in globals()
    assert 'save_file' not in globals()

    with TemporaryDirectory() as d:
        test_data = {'test': 1, 'lorem': 'ipsum'}
        test_file = Path(os.path.join(d, 'test.pickle'))

        with work_in_progress("Saving file"):
            save_file(test_file, test_data)



# Generated at 2022-06-21 12:23:27.184066
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1)

# Generated at 2022-06-21 12:23:37.440738
# Unit test for function work_in_progress
def test_work_in_progress():

    import copy
    import pickle
    import time

    class Dummy:

        def __init__(self, n):
            self.n = n

        def foo(self, x):
            time.sleep(0.05)
            return x + self.n

        def __getstate__(self):
            return copy.copy(self.__dict__)

        def __setstate__(self, d):
            self.__dict__.update(d)

    obj = Dummy(10)
    with work_in_progress("Writing to file"):
        with open("foo.pickle", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:23:45.285242
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    print("=" * 80)
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")
    print("=" * 80)
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    print("=" * 80)

# Generated at 2022-06-21 12:23:49.889322
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sleepy time"):
        time.sleep(0.5)

    sleep_time = 1.5

    def sleepy_func():
        time.sleep(sleep_time)

    sleepy_func = work_in_progress("Sleepy func")(sleepy_func)
    sleepy_func()

# Generated at 2022-06-21 12:23:52.284517
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.3)


# Generated at 2022-06-21 12:23:57.480603
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing"):
        time.sleep(0.2)

# Generated at 2022-06-21 12:24:03.356845
# Unit test for function work_in_progress
def test_work_in_progress():
    def test_func():
        time.sleep(2)
    # begin_time = time.time()
    with work_in_progress("Testing work_in_progress"):
        test_func()
    # time_consumed = time.time() - begin_time
    # print(f"Test work_in_progress: {time_consumed:.2f}s")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:24:12.126100
# Unit test for function work_in_progress
def test_work_in_progress():
    import unittest.mock

    def mock_print(*args, **kwargs):
        assert args == ("Calculating something... ",)
        assert "end" in kwargs.keys()
        assert kwargs["end"] == ''
        assert "flush" in kwargs.keys()
        assert kwargs["flush"] == True

    time_consumed = 3.1415926
    def mock_time():
        return time_consumed
    def mock_time_n():
        return time_consumed


# Generated at 2022-06-21 12:24:17.105532
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(.5)
        return {"path": path}

    with work_in_progress("Saving file"):
        time.sleep(.5)

    assert load_file("/path/to/file")["path"] == "/path/to/file"

# Generated at 2022-06-21 12:24:19.481047
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Counting to 10,000...")
    def count_to_10000():
        for i in range(10000):
            pass

    count_to_10000()

# Generated at 2022-06-21 12:24:23.138062
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Printing hello world"):
        print("Hello world!")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:24:31.519383
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert obj

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    return "Test work_in_progress(): OK"

if __name__ == "__main__":
    print(test_work_in_progress())

# Generated at 2022-06-21 12:24:38.641115
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import tempfile
    import pickle

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = random.random()
    path = tempfile.mktemp()

    with work_in_progress("Loading file"):
        load_file(path)

    assert obj == load_file(path)
    with work_in_progress("Saving file"):
        save_file(path, obj)

    assert obj == load_file(path)

# Generated at 2022-06-21 12:24:46.637588
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    # Loading file... done. (3.52s)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    # Saving file... done. (3.78s)

# Generated at 2022-06-21 12:24:49.799677
# Unit test for function work_in_progress
def test_work_in_progress():


    with work_in_progress("Measuring code execution time") as ctx:
        time.sleep(0.25)
        time.sleep(0.25)
    assert ctx.time_consumed >= 0.5

# Generated at 2022-06-21 12:24:58.328311
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("test.pickle")
    assert isinstance(obj, dict)

    with work_in_progress("Saving file"):
        with open("test.pickle", "wb") as f:
            pickle.dump(obj, f)


# Generated at 2022-06-21 12:24:59.865776
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sleep for 1 second"):
        time.sleep(1)

# Generated at 2022-06-21 12:25:02.696301
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import random
    with work_in_progress("Loading a file") as print:
        time.sleep(random.random())

# Generated at 2022-06-21 12:25:14.396618
# Unit test for function work_in_progress
def test_work_in_progress():
    import nose.tools as nt
    import sys
    import io

    # Test the context manager
    # Test decription (default)
    with io.StringIO() as f:
        sys.stdout = f
        with work_in_progress():
            time.sleep(1)
        nt.assert_equal(f.getvalue(), 'Work in progress... done. (1.00s)\n')
        sys.stdout = sys.__stdout__

    # Test decription with custom decription
    with io.StringIO() as f:
        sys.stdout = f
        with work_in_progress("Custom"):
            time.sleep(1)
        nt.assert_equal(f.getvalue(), 'Custom... done. (1.00s)\n')
        sys.stdout = sys.__stdout__

# Generated at 2022-06-21 12:25:17.456498
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    print()

    with work_in_progress():
        time.sleep(1)

# Generated at 2022-06-21 12:25:25.599594
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import random
    import string
    import os

    def random_string(string_length=10):
        """Generate a random string of fixed length."""
        letters = string.ascii_lowercase
        return ''.join(random.choice(letters) for i in range(string_length))

    desc = random_string(10)
    obj = {random_string(10): random.randint(1, 100) for _ in range(100)}

    path = os.path.expanduser("~/test_work_in_progress_save.pickle")
    with work_in_progress(f"Writing {desc}"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


# Generated at 2022-06-21 12:25:29.083671
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Work in progress")
    def test_work():
        time.sleep(1.5)

    test_work()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:25:36.519751
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test function ``work_in_progress``."""
    with io.StringIO() as buf, redirect_stdout(buf):
        with work_in_progress("Loading file"):
            time.sleep(1.12)

        assert (
            buf.getvalue()
            == "Loading file... done. (1.12s)\n"
        )


# Scripting
if __name__ == "__main__":
    import pytest
    pytest.main(__file__)

# Generated at 2022-06-21 12:25:45.828681
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @contextlib.contextmanager
    def tmp_file(data, suffix='', prefix='tmp', dir=None):
        path = tempfile.mkstemp(suffix, prefix, dir)[1]
        with open(path, "wb") as f:
            pickle.dump(data, f)
        yield path
        os.remove(path)

    test_data = {
        'a': [1, 2, 3],
        'b': 'abc'
    }

    res = None

    with tmp_file(test_data) as path:
        res = load_file(path)

    return res

# Generated at 2022-06-21 12:25:54.573249
# Unit test for function work_in_progress
def test_work_in_progress():
    spec = [work_in_progress, work_in_progress("Some work in progress")]
    with ExitStack() as stack:
        hooks = [stack.enter_context(mock.patch(s)) for s in spec]
        hooks[1].__enter__.return_value = None
        with work_in_progress(), work_in_progress("Some work in progress"):
            pass
        assert hooks[0].__enter__.called
        assert hooks[1].__enter__.called
        assert hooks[0].__exit__.called
        assert hooks[1].__exit__.called


if __name__ == "__main__":
    """Run the unit test."""
    import sys
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)
    del doctest

# Generated at 2022-06-21 12:26:00.158844
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test")
    def foobar():
        time.sleep(0.01)

    foobar()


# Generated at 2022-06-21 12:26:09.616140
# Unit test for function work_in_progress
def test_work_in_progress():
    import warnings

    with warnings.catch_warnings(record=True) as w:
        # Cause all warnings to always be triggered.
        warnings.simplefilter("always")

        # With function
        @work_in_progress("Loading file")
        def load_file(path):
            with open(path, "rb") as f:
                return pickle.load(f)

        obj = load_file("/path/to/some/file")
        # assert ("do not use this method")
        time.sleep(1)

        # With context
        with work_in_progress("Saving file"):
            with open("file", "wb") as f:
                pickle.dump(obj, f)
            time.sleep(1)

        assert len(w) == 0


# Generated at 2022-06-21 12:26:13.164095
# Unit test for function work_in_progress
def test_work_in_progress():
    # The first test case for the function work_in_progress
    time.sleep(1)
    with work_in_progress("Saving file"):
        pass
    assert True

# Generated at 2022-06-21 12:26:19.770543
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:31.729859
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = [(i, i) for i in range(100)]
    save_file(obj, "tmp.obj")

    with work_in_progress("Loading file"):
        with open("tmp.obj", "rb") as f:
            obj = pickle.load(f)

    assert obj == load_file("tmp.obj")

    with work_in_progress("Deleting file"):
        os.remove("tmp.obj")




# Generated at 2022-06-21 12:26:39.511327
# Unit test for function work_in_progress
def test_work_in_progress():
    from tempfile import TemporaryFile

    from PIL import Image

    with TemporaryFile() as f:
        with work_in_progress("Loading file"):
            im = Image.open("image.jpg")
            im.save(f, "JPEG")
        # Do other stuff

        with work_in_progress("Saving file"):
            f.seek(0)
            im = Image.open(f)
            im.save("image.jpg")
        # Do other stuff

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:43.941524
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path: str):
        with open(path, "r") as file:
            return file.read()

    path = "/Users/chihyu/Documents/GitHub/TIPS/TIPS/tips/base/random_graph/random_graph_generator.py"
    print(load_file(path))

# Generated at 2022-06-21 12:26:46.480761
# Unit test for function work_in_progress
def test_work_in_progress():
    begin_time = time.time()
    with work_in_progress("Do a thing"):
        time.sleep(1)
    time_consumed = time.time() - begin_time
    assert (time_consumed - 1) <= 0.2

# Generated at 2022-06-21 12:26:49.248096
# Unit test for function work_in_progress
def test_work_in_progress():
    # TODO: This function shall be tested
    return True


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:26:51.600029
# Unit test for function work_in_progress
def test_work_in_progress():
    pass


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:57.206985
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Working"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:27:01.871688
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/Users/tong.zhang/Documents/Project/NLP/Pretrained_Word_Embedding/glove.6B.100d.txt")
    print(obj[:10])

# Generated at 2022-06-21 12:27:07.718136
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    
    @work_in_progress()
    def a():
        time.sleep(2)

    a()

    @work_in_progress()
    def b():
        print('\n')
    
    b()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:27:14.755080
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    path = "/tmp/file.pkl"

    obj = dict()
    for i in range(100):
        obj[i] = i**2

    with work_in_progress("Saving file"):
        save_file(obj, path)

    with work_in_progress("Loading file"):
        obj_loaded = load_file(path)
        assert obj == obj_loaded



# Generated at 2022-06-21 12:27:20.050509
# Unit test for function work_in_progress
def test_work_in_progress():
    # A closure for testing
    def fib(n):
        a, b = 0, 1
        for _ in range(n):
            a, b = b, a + b
        return a

    with work_in_progress("Calculating fibonacci number"):
        fib(10 ** 6)

# Generated at 2022-06-21 12:27:22.079272
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing"):
        time.sleep(0.5)
    assert True

# Generated at 2022-06-21 12:27:26.465411
# Unit test for function work_in_progress
def test_work_in_progress():
    i = 0
    for verbosity in (0, -1):
        with work_in_progress():
            time.sleep(1)
            i += 1
    assert i == 2
    i = 0
    for verbosity in (0, -1):
        with work_in_progress("Loading file"):
            time.sleep(1)
        i += 1
    assert i == 2
    assert True

# Generated at 2022-06-21 12:27:31.782813
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Test 1 (method decorator)")
    def test_method():
        time.sleep(1.23)

    test_method()

    with work_in_progress("Test 2 (context manager)"):
        time.sleep(3.21)

# Execute unit tests when this file is run as a script

# Generated at 2022-06-21 12:27:34.797367
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Some dummy work"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:27:40.814665
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test whether the context manager decomposed correctly.
    with work_in_progress("Load file") as t:
        assert t is None
    
    # Test whether the context manager worked correctly.
    with work_in_progress("Load file"):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:27:52.879295
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(__file__, "rb") as f:
            return pickle.load(f)

    obj = load_file(__file__)

    with work_in_progress("Saving file"):
        with open(__file__, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:27:57.583443
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress."""
    with work_in_progress("Loading file"):
        time.sleep(0.3)
    time.sleep(0.2)
    with work_in_progress("Saving file"):
        time.sleep(0.4)

# Generated at 2022-06-21 12:28:08.849040
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import os
    import os.path as osp
    import tempfile

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    @work_in_progress("Generating test data")
    def generate_data():
        data = [
            {"hello": "world", "x": [1, 2, 3]},
            {"key": "val", "x": [4, 5, 6]},
            {"another": "one", "x": [7, 8, 9]},
        ]
        return data


# Generated at 2022-06-21 12:28:18.337357
# Unit test for function work_in_progress
def test_work_in_progress():
    from test_util import create_temp_file

    with work_in_progress() as _:
        @work_in_progress("Loading file")
        def load_file(path):
            with open(path, "rb") as f:
                return pickle.load(f)

        @work_in_progress("Saving file")
        def save_file(path, obj):
            with open(path, "wb") as f:
                pickle.dump(obj, f)

        obj = [3,4,5,6]
        with create_temp_file() as (tmp_path, _):
            save_file(tmp_path, obj)

        ret_obj = load_file(tmp_path)
        assert obj == ret_obj



# Generated at 2022-06-21 12:28:21.545825
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test")
    def a():
        time.sleep(2)

    with work_in_progress("Test"):
        time.sleep(2)

# Generated at 2022-06-21 12:28:25.486248
# Unit test for function work_in_progress
def test_work_in_progress():
    def func(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except TypeError:
            pass

    with work_in_progress("Testing work_in_progress"):
        func()

# Generated at 2022-06-21 12:28:28.966558
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def func():
        time.sleep(1)

    try:
        func()
    except Exception:
        assert False, "work_in_progress has error"

    with work_in_progress():
        time.sleep(1)

# Generated at 2022-06-21 12:28:40.555285
# Unit test for function work_in_progress
def test_work_in_progress():
    fpath = r"D:\GitHub\python-exercises\intermediate\test_data\file.pkl"

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file_decorated(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    print("1.")
    obj = load_file(fpath)
    print("\n2.")
    obj = load_file_decorated(fpath)

    with work_in_progress("Saving file"):
        with open(fpath, "wb") as f:
            pickle.dump(obj, f)


# Generated at 2022-06-21 12:28:45.785828
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("tests/test_work_in_progress.pkl")
    with work_in_progress("Saving file"):
        with open("tests/test_work_in_progress_2.pkl", "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:28:51.394848
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Sleeping")
    def sleep():
        time.sleep(0.1)

    @work_in_progress()
    def sleep_more():
        time.sleep(0.1)

    sleep()
    sleep_more()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:29:06.066045
# Unit test for function work_in_progress
def test_work_in_progress():
    class TestFile:
        def __init__(self, path, data):
            self.path = path
            self.data = data

        def save(self):
            with open(self.path, "wb") as f:
                pickle.dump(self.data, f)

        @classmethod
        def load(cls, path):
            with open(path, "rb") as f:
                return cls(path, pickle.load(f))

    with tempfile.TemporaryDirectory() as dirpath:
        def _test_work_in_progress(test_case, desc: str, code_block):
            path = dirpath + "/.test_work_in_progress.dat"
            test_case.assertFalse(os.path.exists(path))
            print()
            code_block(path)
           

# Generated at 2022-06-21 12:29:12.472046
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import random
    from pathlib import Path

    from template import load_template
    from utils import get_random_str
    from utils import get_str

    filename = Path(__file__).with_name("work_in_progress_unit_test.txt")

# Generated at 2022-06-21 12:29:15.998341
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("test.pickle")

# Generated at 2022-06-21 12:29:21.820686
# Unit test for function work_in_progress
def test_work_in_progress():
    import math
    
    with work_in_progress("Calculating pi"):
        pi = 4 * math.atan(1)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:29:27.721394
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import os
    import tempfile
    random_data = b"".join(os.urandom(1024) for _ in range(1024))
    with tempfile.TemporaryFile(mode="rb+") as f:
        with work_in_progress("Writing to file"):
            f.write(random_data)
        f.seek(0)
        with work_in_progress("Reading from file"):
            assert random_data == f.read()

# Generated at 2022-06-21 12:29:32.691836
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(0.1)
    with work_in_progress("Working"):
        time.sleep(0.1)
    time.sleep(0.1)
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    pickle.dump({"a": 1}, open("/tmp/testing.pkl", "wb"))
    time.sleep(0.1)
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    d = load_file("/tmp/testing.pkl")
    assert d["a"] == 1
    time.sleep(0.1)

# Generated at 2022-06-21 12:29:36.907059
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        pass
    with work_in_progress("Saving file"):
        pass


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:29:44.676691
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import shutil
    import tempfile
    from tad4bj.db import open_database
    from tad4bj.data.serialize import to_pickle

    path = os.path.join(tempfile.gettempdir(), "test_work_in_progress")

    @work_in_progress("Creating database")
    def create_database():
        nonlocal path
        open_database(path)

    @work_in_progress("Writing data")
    def write_data(db):
        for i in range(100000):
            to_pickle(db, f"test{i}", range(i))

    create_database()
    with open_database(path) as db:
        write_data(db)
    shutil.rmtree(path)


# Force function to be called at module import time

# Generated at 2022-06-21 12:29:49.105933
# Unit test for function work_in_progress
def test_work_in_progress():
    print(">>> func version")
    @work_in_progress("func version")
    def func():
        time.sleep(2)
    func()

    print(">>> with version")
    with work_in_progress("with version"):
        time.sleep(2)


# Generated at 2022-06-21 12:29:55.565730
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:30:21.636134
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test with function
    @work_in_progress("Loading file")
    def load_file(path: str):
        return open(path, 'r').read()

    path = "/tmp/test.txt"

    with open(path, 'w') as f:
        f.write("test")

    assert load_file(path) == 'test'

    # Test with context manager
    with work_in_progress("Loading file") as w:
        with open(path, 'r') as f:
            assert f.read() == 'test'

    os.remove(path)

# Generated at 2022-06-21 12:30:23.057164
# Unit test for function work_in_progress
def test_work_in_progress():
    assert True

# Generated at 2022-06-21 12:30:27.809435
# Unit test for function work_in_progress
def test_work_in_progress():
    for name in ("testing", "testing "):
        with work_in_progress(name):
            print(".")
            time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:30:31.233487
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test function")
    def _f():
        time.sleep(3)
        return "Test result"

    res = _f()
    assert res == "Test result"

# Generated at 2022-06-21 12:30:38.252400
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    >>> test_work_in_progress()
    Loading file... done. (2.50e-06s)
    Saving file... done. (2.50e-06s)
    """
    with work_in_progress("Loading file"):
        time.sleep(0.0002)
    with work_in_progress("Saving file"):
        time.sleep(0.0002)

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:30:48.848090
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing work_in_progress...")

    def _load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file(path):
        return _load_file(path)

    obj = load_file("/path/to/some/file")
    assert obj is not None
    assert obj["test"] == "test"

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    print("Testing work_in_progress passed!")


# If this module is run as main, will run all the doctests
if __name__ == "__main__":
    import doctest

# Generated at 2022-06-21 12:30:51.643487
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test work_in_progress") as progress:
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:31:01.810501
# Unit test for function work_in_progress
def test_work_in_progress():
    import filecmp

    with work_in_progress("Loading file") as w1:
        time.sleep(2)

    with work_in_progress("Saving file") as w2:
        time.sleep(3)

    r"""
    Loading file... done. (2.00s)
    Saving file... done. (3.00s)
    """

    correct_output = """
    Loading file... done. (2.00s)
    Saving file... done. (3.00s)
    """

    assert (sys.stderr.getvalue() == correct_output)


if __name__ == '__main__':
    import pytest
    pytest.main(["-s", __file__])

# Generated at 2022-06-21 12:31:09.626890
# Unit test for function work_in_progress
def test_work_in_progress():
    from unittest import mock
    # Test function with a code block
    with mock.patch("sys.stdout", new=io.StringIO()) as fake_stdout:
        with work_in_progress("Test description"):
            time.sleep(1)
        assert fake_stdout.getvalue() == "Test description... done. (1.00s)\n"
    # Test function with a function call
    @work_in_progress("Test description")
    def output():
        time.sleep(1)
        return 0
    assert output() == 0


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:31:15.430943
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Doing some work")
    def func():
        time.sleep(5)

    @work_in_progress()
    def func2():
        time.sleep(3)

    with work_in_progress("Doing some other work"):
        time.sleep(4)

    with work_in_progress():
        time.sleep(1)

    func()
    func2()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:32:05.615948
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "/path/to/some/file"
    with work_in_progress("Loading file"):
        obj = load_file(path)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:32:16.252238
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    from pychk.util import readyaml, chktype

    # Load test cases
    yml = readyaml("""
        - desc: ""
          secs: 0
          result: "Work in progress... done. (0.00s)"
        - desc: "Loading file"
          secs: 2
          result: "Loading file... done. (2.00s)"
        - desc: "Doing something"
          secs: 1.1
          result: "Doing something... done. (1.10s)"
        - desc: "Foo"
          secs: 0.001
          result: "Foo... done. (0.00s)"
        - desc: "Bar"
          secs: 0.5
          result: "Bar... done. (0.50s)"
        """)

    #

# Generated at 2022-06-21 12:32:25.601956
# Unit test for function work_in_progress
def test_work_in_progress():
    from pycharm.logger import Logger
    from tempfile import TemporaryDirectory
    from random import shuffle

    # Generate random list to sort
    rnd_lst = [i for i in range(1000)]
    shuffle(rnd_lst)

    # Test function work_in_progress
    with TemporaryDirectory() as log_path:
        log_file = log_path + "/log"
        logger = Logger(log_file)

        logger.print_headline("Test function work_in_progress")
        with work_in_progress("Sorting random list"):
            rnd_lst.sort()
        logger.print_to_log_file()

        logger.print_headline("Test class WorkInProgress")
        with WorkInProgress("Sorting another random list"):
            shuffle(rnd_lst)

# Generated at 2022-06-21 12:32:30.040388
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        print("loading")
        time.sleep(0.5)
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert obj == [1, 2, 3]

    with work_in_progress("Saving file"):
        time.sleep(0.5)
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:32:37.407388
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def unit_test_work_in_progress(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    out = unit_test_work_in_progress(test_file_path)
    assert np.allclose(out, test_file_content)

    with work_in_progress():
        with open(test_file_path, "wb") as f:
            pickle.dump(test_file_content, f)

    out = unit_test_work_in_progress(test_file_path)
    assert np.allclose(out, test_file_content)

# Generated at 2022-06-21 12:32:42.952143
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:32:48.119231
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    path = tempfile.mktemp()
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            f.write(b"Hello world")
    os.remove(path)
    with work_in_progress("Loading file"):
        with open(path, "rb") as f:
            f.read()