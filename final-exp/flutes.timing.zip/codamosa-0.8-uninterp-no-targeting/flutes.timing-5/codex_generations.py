

# Generated at 2022-06-21 12:22:54.165590
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("load.pickle")

    with work_in_progress("Saving file"):
        with open("save.pickle", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:22:55.869731
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress function") as w:
        time.sleep(1)
    assert w is None


# Generated at 2022-06-21 12:22:59.201969
# Unit test for function work_in_progress
def test_work_in_progress():
    # Check context manager usage
    with work_in_progress("Processing"):
        time.sleep(.7)

    # Check function usage
    @work_in_progress("Loading file")
    def load_file():
        time.sleep(.8)
        return 42

    load_file()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:09.792699
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    time.sleep(1)
    obj = load_file("/path/to/some/file")
    assert obj is not None
    time.sleep(2)

    with work_in_progress("Saving file"):
        time.sleep(3)
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    assert os.path.exists(path)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:13.257777
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sleeping for a while"):
        time.sleep(.5)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:23:23.671634
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import tempfile
    import pickle
    import contextlib
    import os

    with contextlib.change_dir(tempfile.TemporaryDirectory().name):
        @work_in_progress("Doing something")
        def f():
            time.sleep(1)

        f()
        # Doing something... done. (1.00s)

    with contextlib.change_dir(tempfile.TemporaryDirectory().name):
        obj = {'a': list(range(10))}

        @work_in_progress("Loading file")
        def load_file(path):
            with open(path, "rb") as f:
                return pickle.load(f)


# Generated at 2022-06-21 12:23:28.285473
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def foo():
        time.sleep(0.1)
    # Testing work_in_progress... done. (0.10s)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:23:32.653634
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = os.path.join(temp_dir, "temp")

# Generated at 2022-06-21 12:23:34.000222
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing"):
        time.sleep(0.01)

# Generated at 2022-06-21 12:23:40.229927
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("unit_test/lena.jpeg")

    with open("unit_test/lena_jpeg.dat", "wb") as f:
        pickle.dump(obj, f)


# Generated at 2022-06-21 12:23:45.929466
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("TEST"):
        time.sleep(0.5)
    print()
    with work_in_progress():
        time.sleep(0.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:56.195363
# Unit test for function work_in_progress
def test_work_in_progress():  # pragma: no cover
    from .test_utils import capture_stdout, capture_stderr
    from .test_utils import test_equal, test_not_equal
    from .test_utils import test_true, test_false

    def _test_logging_func(output_stream):
        @work_in_progress("Test function")
        def fake_func():
            time.sleep(0.1)
        with output_stream:
            fake_func()

    # Test with positive result
    with capture_stdout() as stdout:
        with capture_stderr() as stderr:
            _test_logging_func(stdout)
    test_equal(len(stdout), 1)
    test_equal(len(stderr), 0)

    # Test with negative result

# Generated at 2022-06-21 12:23:59.940011
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Sleeping for 2 secs"):
        time.sleep(2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:24:02.290089
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading data")
    def load_data():
        with open("/tmp/data.txt", "w") as f:
            time.sleep(1)
            f.write("hello world")

    load_data()



# Generated at 2022-06-21 12:24:11.233630
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import tempfile
    import os
    import pickle

    def load_file(path):
        with work_in_progress(f"Load file '{path}'"):
            with open(path, "rb") as f:
                return pickle.load(f)

        obj = load_file(path)

    with tempfile.TemporaryDirectory() as root:
        data = [random.uniform(0, 1) for _ in range(100000)]
        filepath = os.path.join(root, "file.pickle")
        with open(filepath, "wb") as f:
            pickle.dump(data, f)

        print("Loading file...")

# Generated at 2022-06-21 12:24:15.888686
# Unit test for function work_in_progress
def test_work_in_progress():
    from time import sleep
    with work_in_progress("Loading file"):
        sleep(0.5)
    with work_in_progress("Saving file"):
        sleep(1)

# Unit test
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:24:17.882771
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sleep"):
        time.sleep(0.1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:24:23.192758
# Unit test for function work_in_progress
def test_work_in_progress():
    fn_path = "/tmp/dummy.pkl"
    fn_contents = "dummy"
    with work_in_progress("Saving dummy file"):
        with open(fn_path, 'w') as f:
            f.write(fn_contents)
    with work_in_progress("Loading dummy file"):
        with open(fn_path, 'r') as f:
            contents = f.read()
    assert contents == fn_contents


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:24:32.948837
# Unit test for function work_in_progress
def test_work_in_progress():
    import random, string
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return f.read()

    @work_in_progress("Saving file")
    def save_file(path, content):
        with open(path, "wb") as f:
            f.write(content)

    def rands(n):
        return ''.join(random.choice(string.ascii_uppercase) for _ in range(n))

    data = rands(10000000)
    save_file("temp", data)
    d = load_file("temp")
    assert data == d

# Generated at 2022-06-21 12:24:37.018511
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:24:44.513830
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(3)

# Generated at 2022-06-21 12:24:51.187503
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:24:52.666499
# Unit test for function work_in_progress
def test_work_in_progress():
    # pylint: disable=unused-variable
    @work_in_progress("Testing...")
    def test():
        time.sleep(0.1)
    test()

# Generated at 2022-06-21 12:24:58.247148
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

test_work_in_progress()

# Generated at 2022-06-21 12:25:05.026213
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit testing for function work_in_progress
    """
    @work_in_progress("Testing function")
    def test_func_fail():
        time.sleep(3)
        raise Exception("Error")

    @work_in_progress("Testing function")
    def test_func():
        time.sleep(3)

    with pytest.raises(Exception):
        test_func_fail()
    
    test_func()

# Generated at 2022-06-21 12:25:14.153642
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test with function
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    assert load_file(os.path.join(os.path.dirname(__file__), "__init__.pyc"))

    # Test with context manager
    with work_in_progress("Saving file"):
        time.sleep(0.5)
    print()  # Add an extra line break


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:25:19.064228
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    @work_in_progress("Saving file")
    def save_file():
        time.sleep(2)
    save_file()


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:25:27.005463
# Unit test for function work_in_progress
def test_work_in_progress():
    import sys
    from .testing import capture_print_and_return_stdout

    # Redirect printing to a text buffer
    if sys.version_info < (3, 0):
        from StringIO import StringIO
        StringIO = StringIO
    else:
        from io import StringIO

    sys_stdout = sys.stdout
    sys.stdout = StringIO()

    with work_in_progress("Test"):
        time.sleep(1)

    assert sys.stdout.getvalue().strip() == "Test... done. (1.00s)"

    # Restore printing
    sys.stdout.close()
    sys.stdout = sys_stdout

# Generated at 2022-06-21 12:25:29.426848
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test for function :func:`work_in_progress`."""
    with work_in_progress():
        time.sleep(0.1)

# Generated at 2022-06-21 12:25:36.877958
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile

    desc = "Testing work_in_progress"
    @work_in_progress(desc)
    def test_function(path):
        with open(path, "wb") as f:
            f.write(b"test")
    with tempfile.TemporaryDirectory() as tempdir:
        test_path = os.path.join(tempdir, "test")
        test_function(test_path)
        assert os.path.exists(test_path)

# Generated at 2022-06-21 12:25:55.564593
# Unit test for function work_in_progress
def test_work_in_progress():
    for func in ["work_in_progress",]:
        assert hasattr(work_in_progress, func), f"Missing function {func}"
        func = getattr(work_in_progress, func)
        assert callable(func), f"Function {func} is not callable"

    from pathlib import Path
    import pickle

    data = (
        [1, 2, 3],
        {'a': 1, 'b': 2},
        {i: bytes(i) for i in range(1000)},
        ((i, i+1) for i in range(10)),
    )

    # Testing simple decorator
    tmp = '/tmp/' + next(tempfile._get_candidate_names())
    

# Generated at 2022-06-21 12:26:04.476303
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test for function work_in_progress."""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "/path/to/some/file"
    obj = load_file(path)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


# If running as script
if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:26:06.985276
# Unit test for function work_in_progress
def test_work_in_progress():

    import time
    import math

    with work_in_progress("Computing square root"):
        time.sleep(1.234)
        x = math.sqrt(2)

    assert math.isclose(x, 1.141)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:12.974688
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1)
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert True

# Generated at 2022-06-21 12:26:22.848681
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import pickle

    test_file = "tmp.test"
    test_obj = {"a": 1, "b": 2}

    with open(test_file, "wb") as f:
        pickle.dump(test_obj, f)

    with work_in_progress("Loading file"):
        with open(test_file, "rb") as f:
            assert pickle.load(f) == test_obj

    with work_in_progress("Saving file"):
        with open(test_file, "wb") as f:
            pickle.dump(test_obj, f)

    os.remove(test_file)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:26:29.284751
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path: str):
        time.sleep(1)
        return path

    assert load_file("/path/to/some/file") == "/path/to/some/file"

    with work_in_progress("Saving file") as wrk:
        wrk.id = 1
        time.sleep(1)
    assert wrk.id == 1

# Generated at 2022-06-21 12:26:31.013527
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("I'm being timed"):
        time.sleep(3)

# Generated at 2022-06-21 12:26:39.229656
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Calculating square root")
    def sqrt(x):
        return x ** 0.5

    assert abs(sqrt(10) - 3.16) < 1e-2
    assert abs(sqrt(2) - 1.41) < 1e-2

    @work_in_progress("Calculating square")
    def square(x):
        return x ** 2

    assert square(5) == 25
    print("Running work_in_progress() unit test... done.")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:41.332021
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    with work_in_progress("Work in progress"):
        pass

if "__main__" == __name__:
    test_work_in_progress()

# Generated at 2022-06-21 12:26:46.384832
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Loading file"):
        time.sleep(2)
    with work_in_progress("Saving file"):
        time.sleep(3)

if __name__ == "__main__":
    from pprint import pprint
    from doctest import testmod
    print("{:=^40}".format("TESTING"))
    testmod()
    print("{:=^40}".format("END TESTING"))

# Generated at 2022-06-21 12:27:13.347292
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(2)
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        time.sleep(2)
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:27:17.524735
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(1)
        with work_in_progress('Second'):
            time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:27:26.219603
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with open("/tmp/dump", "wb") as f:
        pickle.dump(range(100000), f)

    obj = load_file("/tmp/dump")

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    save_file("/tmp/dump2")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:27:34.152152
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test function :func:`work_in_progress`."""
    
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("./data/example.pkl")
    
    with work_in_progress("Saving file"):
        with open("./data/example.pkl", "wb") as f:
            pickle.dump(obj, f)


# Unit test

# Generated at 2022-06-21 12:27:37.112845
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(1)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:27:40.860445
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Running work_in_progress")
    def _():
        time.sleep(1)
    _()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:27:50.285455
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("tests/data/sample_pickle.pkl")
    save_file("/tmp/sample_pickle.pkl", obj)

# Generated at 2022-06-21 12:27:52.359343
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test function for method work_in_progress.

    This test should always succeed.
    """
    # Execute a dummy function with work_in_progress
    with work_in_progress("Test w/i/p"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:28:04.459078
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file(os.path.join(os.path.dirname(__file__), "data/example_video.pkl"))
    save_file(obj, os.path.join(os.path.dirname(__file__), "data/example_video_copy.pkl"))


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:28:10.902209
# Unit test for function work_in_progress
def test_work_in_progress():
    def dummy_func(time_consume: float, desc: str = "dummy"):
        with work_in_progress(desc):
            time.sleep(time_consume)

    def dummy_block(time_consume: float, desc: str = "dummy"):
        with work_in_progress(desc):
            time.sleep(time_consume)

    dummy_func(0.1, "test")
    dummy_block(0.2, "test")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:28:59.257066
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Processing file")
    def process(file):
        print(f"Processing file '{file}'")
        time.sleep(2)
    process("C:\\temp\\1.txt")
    try:
        with work_in_progress("Processing file"):
            print(f"Processing file '{file}'")
            time.sleep(2)
    except NameError:
        pass

# Generated at 2022-06-21 12:29:02.230466
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    with work_in_progress("Saving file"):
        time.sleep(3)
    with work_in_progress("Working..."):
        time.sleep(5)

# Generated at 2022-06-21 12:29:03.714908
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test work in progress"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:29:11.525006
# Unit test for function work_in_progress
def test_work_in_progress():
    import sys
    import io
    import time

    class Capturing(list):
        def __enter__(self):
            self._stdout = sys.stdout
            sys.stdout = self._stringio = io.StringIO()
            return self

        def __exit__(self, *args):
            self.extend(self._stringio.getvalue().splitlines())
            del self._stringio
            sys.stdout = self._stdout

    with Capturing() as output:
        with work_in_progress("Loading file"):
            time.sleep(0.5)

    assert output == ['Loading file... done. (0.50s)']


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:29:16.357466
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress(desc="testing work_in_progress function"):
        time.sleep(0.5)
    with work_in_progress(desc="testing work_in_progress function"):
        time.sleep(0.5)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:29:24.188676
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        save_file("/path/to/some/file", obj)

# Generated at 2022-06-21 12:29:27.301095
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sleeping for 3 seconds"):
        time.sleep(3)
    try:
        assert time_consumed <= 3.1
        assert time_consumed >= 2.9
    except:
        assert False

# Generated at 2022-06-21 12:29:31.602884
# Unit test for function work_in_progress
def test_work_in_progress():

    # Testing work_in_progress as a context manager
    with work_in_progress("Saving file"):
        time.sleep(0.5)

    # Testing work_in_progress as a function decorator
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(0.5)
        return

    load_file("/path/to/some/file")

# Generated at 2022-06-21 12:29:36.085962
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        with work_in_progress("Testing nested work_in_progress"):
            time.sleep(0.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:29:38.823293
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading data")
    def load_data():
        time.sleep(1.5)
    load_data()

# Generated at 2022-06-21 12:31:08.458245
# Unit test for function work_in_progress
def test_work_in_progress():
    pass

# Generated at 2022-06-21 12:31:14.706296
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    >>> work_in_progress_unit_test()
    Loading file... done. (3.52s)
    Saving file... done. (3.78s)
    """

    @work_in_progress("Loading file")
    def load_file():
        time.sleep(3.52)
        return None

    with work_in_progress("Saving file"):
        time.sleep(3.78)

    load_file()


if __name__ == "__main__":
    doctest.testmod()

# Generated at 2022-06-21 12:31:22.975054
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    
    obj = load_file("/path/to/some/file")
    assert isinstance(obj, type(pickle.dumps(obj)))

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    assert isinstance(obj, type(pickle.dumps(obj)))

# Generated at 2022-06-21 12:31:27.006534
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(1)
    @work_in_progress()
    def test():
        time.sleep(2)
    test()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:31:33.246923
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test work_in_progress()."""
    from .echos import echo

    @work_in_progress("Test function")
    def foo(a, b):
        """Test function."""
        echo(a, b)

    foo(1, 2)
    foo(3, 4)

    with work_in_progress("Test block"):
        echo(1, 2)

    with work_in_progress("Test block"):
        echo(3, 4)


# Generated at 2022-06-21 12:31:37.546877
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Working in progress")
    def do_something():
        time.sleep(0.1)

    with work_in_progress("Working in progress"):
        time.sleep(0.1)

    do_something()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:31:40.155754
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Long operation")
    def long_operation(time_to_sleep):
        time.sleep(time_to_sleep)

    long_operation(2)

# Generated at 2022-06-21 12:31:51.785613
# Unit test for function work_in_progress
def test_work_in_progress():
    import sys
    import os
    import pathlib
    import pytest

    def _test(work_in_progress):
        # 1
        with work_in_progress("Loading file"):
            time.sleep(1.2)
        # 2
        @work_in_progress("Saving file")
        def save_file():
            time.sleep(2.3)
        save_file()

    # Clear the output function
    def f():
        pass
    save_stdout = sys.stdout
    sys.stdout = f

    # Save and clear stdout
    with pytest.raises(AssertionError):
        work_in_progress()
    with pytest.raises(AssertionError):
        work_in_progress(123)

# Generated at 2022-06-21 12:31:57.368891
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with work_in_progress("Loading file"):
        obj = load_file("/tmp/test.dat")

    with work_in_progress("Saving file"):
        save_file(obj, "/tmp/test.dat")

# Generated at 2022-06-21 12:32:00.692726
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("work_in_progress"):
        time.sleep(0.1)

if __name__ == "__main__":
    test_work_in_progress()