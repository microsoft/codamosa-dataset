

# Generated at 2022-06-21 12:22:56.655461
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    @work_in_progress()
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with open("/path/to/some/file", "rb") as f:
        obj = load_file(f)
    print(obj)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:03.692805
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3.14)
    @work_in_progress("Saving file")
    def save_file():
        time.sleep(4.0)
        return "done"
    res = save_file()
    assert res == "done"

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:23:14.895778
# Unit test for function work_in_progress
def test_work_in_progress():
    begin_time = None
    def _sleep(time_to_sleep: float, time_passed: float):
        nonlocal begin_time
        begin_time = time.time()
        time.sleep(time_to_sleep)
        time_consumed = time.time() - begin_time
        assert time_consumed - time_passed <= 0.01

    with work_in_progress("Loading file"):
        _sleep(2, 0)
    with work_in_progress("Loading file"):
        time.sleep(2)
        print("Loading file... ", end='', flush=True)
        _sleep(2, 2)
    with work_in_progress("Loading file"):
        print("Loading file... ", end='', flush=True)
        _sleep(2, 0)

# Generated at 2022-06-21 12:23:20.666788
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.5)
    
    with work_in_progress("Loading file"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:25.186541
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("foo") as f:
        time.sleep(0.2)
    with work_in_progress("bar"):
        time.sleep(0.3)
    @work_in_progress("baz")
    def func():
        time.sleep(0.4)
    func()
    @work_in_progress()
    def func2():
        time.sleep(0.5)
    func2()

# Generated at 2022-06-21 12:23:28.451994
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test Work in Progress")
    def test_func():
        time.sleep(1)
    test_func()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:23:34.433125
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(3)
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:45.211167
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    Test for method ``work_in_progress``

    .. code:: python

        >>> @work_in_progress("Loading file")
        ... def load_file(path):
        ...     with open(path, "rb") as f:
        ...         return pickle.load(f)
        ...
        ... obj = load_file("/path/to/some/file")
        Loading file... done. (3.52s)

        >>> with work_in_progress("Saving file"):
        ...     with open(path, "wb") as f:
        ...         pickle.dump(obj, f)
        Saving file... done. (3.78s)
    """
    import subprocess
    import os
    DIR_NAME = os.path.dirname(__file__)
    UNIT_TEST_FILE

# Generated at 2022-06-21 12:23:52.068609
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert isinstance(obj, pickle._Unpickler)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    assert True

# Generated at 2022-06-21 12:23:55.280633
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Performing slow task")
    def slow_task():
        time.sleep(2)

    slow_task()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:24:06.506283
# Unit test for function work_in_progress
def test_work_in_progress():
    import pprint
    import unittest

    class TestWorkInProgress(unittest.TestCase):

        def test_work_in_progress(self):
            @work_in_progress("Loading file")
            def load_file(path):
                with open(path, "rb") as f:
                    return pickle.load(f)
            obj = load_file("/path/to/some/file")
            assert obj is not None

        def test_work_in_progress_contextmanager(self):
            with work_in_progress("Saving file") as f:
                pass

    suite = unittest.TestLoader().loadTestsFromTestCase(TestWorkInProgress)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-21 12:24:10.895263
# Unit test for function work_in_progress
def test_work_in_progress():
    from .python import uprint, ERROR, WARNING
    with work_in_progress("Testing work in progess"):
        time.sleep(1.2)
    uprint(f"{WARNING}", "Exit code should be 0", f"{ERROR}")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:24:14.707103
# Unit test for function work_in_progress
def test_work_in_progress():

    def calculate(n):
        time.sleep(1)
        return n * 2

    with work_in_progress("Calculating"):
        result = calculate(10)
    assert result == 20

# Generated at 2022-06-21 12:24:17.966638
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing"):
        time.sleep(1.5)
    print("Done.")


# Test the functions in this module
if __name__ == '__main__':

    test_work_in_progress()

# Generated at 2022-06-21 12:24:19.482518
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Fake work"):
        time.sleep(0.5)


# Generated at 2022-06-21 12:24:31.675422
# Unit test for function work_in_progress
def test_work_in_progress():
    import sys
    import io
    import contextlib

    @contextlib.contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)


# Generated at 2022-06-21 12:24:37.752429
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def test_func(x, y):
        time.sleep(1.5)
        return x + y

    # Test the decorator version
    assert test_func(1, 2) == 3

    with work_in_progress() as ctx:
        time.sleep(2)


if __name__ == '__main__':
    import pytest
    pytest.main(['-vv', '--durations=3', '--color=auto', '-s', 'pytoolbox/utils/progress.py'])

# Generated at 2022-06-21 12:24:40.341173
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Unit test"):
        time.sleep(1.4)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:24:48.782311
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("../tests/data/model.pkl")
    assert obj is not None
    assert isinstance(obj, TransformerMixin)

    with work_in_progress("Saving file"):
        with open("tmp.pkl", "wb") as f:
            pickle.dump(obj, f)


# Generated at 2022-06-21 12:24:50.372209
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3)

# Generated at 2022-06-21 12:24:59.478523
# Unit test for function work_in_progress
def test_work_in_progress():
    TOLERANCE = 0.05
    with work_in_progress("Sleep for 1 second"):
        time.sleep(1)
    with work_in_progress("Sleep for 0.5 second"):
        time.sleep(0.5)
    begin_time = time.time()
    print("Sleep for 1.5 second...")
    time.sleep(1.5)
    assert time.time() - begin_time < 1.5 + TOLERANCE
    
if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:25:05.820515
# Unit test for function work_in_progress
def test_work_in_progress():
    def main():
        try:
            with work_in_progress("Test"):
                time.sleep(0.5)
            with work_in_progress("Test 2"):
                time.sleep(0.8)
        except KeyboardInterrupt:
            return 1

    import sys
    sys.exit(main())

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:25:13.533094
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:25:16.623908
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("test"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:25:18.387692
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.01)

# Generated at 2022-06-21 12:25:27.489125
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    
    @work_in_progress("Test")
    def test_func(x):
        time.sleep(x)
        return x
    
    x = test_func(3)
    assert x == 3
    print("-------")
    
    with work_in_progress("Test 2"):
        time.sleep(4)
    print("-------")
    
    with work_in_progress("Time for save"):
        with open("temp_file", "wb") as f:
            pickle.dump(x, f)
    with work_in_progress("Time for load"):
        with open("temp_file", "rb") as f:
            y = pickle.load(f)
    assert x == y
    print("-------")

test_work_in_progress()

# Generated at 2022-06-21 12:25:35.393149
# Unit test for function work_in_progress
def test_work_in_progress():

    obj = [1, 2, 3, 4, 5]

    with work_in_progress("Saving"):
        with open("test_store.pkl", "wb") as f:
            pickle.dump(obj, f)

    with work_in_progress("Loading"):
        with open("test_store.pkl", "rb") as f:
            new_obj = pickle.load(f)

    assert obj == new_obj

if __name__ == "__main__":

    pass

# Generated at 2022-06-21 12:25:42.402914
# Unit test for function work_in_progress
def test_work_in_progress():
    # Case 1: Case of using a with statement
    with work_in_progress("Case 1"):
        time.sleep(1)
    # Case 2: Case of using a decorator
    @work_in_progress("Case 2")
    def test():
        time.sleep(1)
    test()
    # Case 3: Case of calling a function
    def test2():
        time.sleep(1)
    with work_in_progress("Case 3"):
        test2()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:25:50.932766
# Unit test for function work_in_progress
def test_work_in_progress():
    import os

    @work_in_progress("Reading file")
    def read_file(path):
        with open(path, "rb") as f:
            return f.read()

    # Create a sample file
    path = "sample_file.txt"
    if not os.path.exists(path):
        with open(path, "w") as f:
            for i in range(10000):
                f.write("0123456789" * 256 + "\n")

    # Read file
    read_file(path)
    os.remove(path)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:25:58.125561
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test function work_in_progress."""
    @work_in_progress("Testing work_in_progress")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump("obj", f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:09.709467
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import os
    with work_in_progress("Loading file"):
        with open(os.path.join(tempfile.gettempdir(), "work_in_progress_test.tmp"), "wb") as f:
            f.write(os.urandom(1024*1024*1024))
    with work_in_progress("Cleaning up"):
        os.remove(os.path.join(tempfile.gettempdir(), "work_in_progress_test.tmp"))
    print("All tests passed.")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:15.607466
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for ``work_in_progress``."""
    desc = "This is a test"
    A = np.random.randn(10, 10)
    with work_in_progress(desc):
        B = A @ A
    with work_in_progress(desc):
        C = A + A
    with work_in_progress(desc):
        D = A - A

# Generated at 2022-06-21 12:26:18.676262
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(0.5)
    time.sleep(0.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:21.745865
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing"):
        time.sleep(0.8)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:23.019438
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(.1)

# Generated at 2022-06-21 12:26:26.632505
# Unit test for function work_in_progress
def test_work_in_progress():
    expected_time = 0.1
    with work_in_progress() as progress:
        time.sleep(expected_time)
    assert progress.time_consumed - expected_time < 0.01

# Generated at 2022-06-21 12:26:38.043257
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("../tests/objfile.pickle")
    assert(isinstance(obj, dict))
    assert(obj["key1"] == "value1")

    with work_in_progress("Saving file"):
        with open("../tests/objfile_2.pickle", "wb") as f:
            pickle.dump(obj, f)

    obj_2 = load_file("../tests/objfile_2.pickle")
    assert(obj == obj_2)


if __name__ == "__main__":
    import doctest
    doctest.testmod()
    test_work_in_progress()

# Generated at 2022-06-21 12:26:41.489472
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress."""
    @work_in_progress()
    def test_fn():
        time.sleep(0.5)
    test_fn()


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:26:43.818707
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(0.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:48.850984
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")
    save_file(obj, "/path/to/some/other/file")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:27:01.709606
# Unit test for function work_in_progress
def test_work_in_progress():
    def dummy_func():
        time.sleep(0.1)

# Generated at 2022-06-21 12:27:04.052575
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test work in progress"):
        time.sleep(1.5)


# Generated at 2022-06-21 12:27:06.429365
# Unit test for function work_in_progress
def test_work_in_progress():

    def foo():
        with work_in_progress("Saving file"):
            time.sleep(0.5)

    foo()



# Generated at 2022-06-21 12:27:13.498333
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""
    .. code:: python

        >>> @work_in_progress("Loading file")
        ... def load_file(path):
        ...     with open(path, "rb") as f:
        ...         return pickle.load(f)
        ...
        ... obj = load_file("/path/to/some/file")
        Loading file... done. (3.52s)

        >>> with work_in_progress("Saving file"):
        ...     with open(path, "wb") as f:
        ...         pickle.dump(obj, f)
        Saving file... done. (3.78s)

    """
    pass

# Generated at 2022-06-21 12:27:24.690697
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import pathlib

    tmp_dir = pathlib.Path(__file__).parent / "tmp"
    tmp_dir.mkdir(parents=True, exist_ok=True)
    tmp_file = tmp_dir / "wip.pkl"

    obj = list(range(1000))

    with work_in_progress("Loading file"):
        with open(tmp_file, "wb") as f:
            pickle.dump(obj, f)

    with work_in_progress("Saving file"):
        with open(tmp_file, "rb") as f:
            loaded_obj = pickle.load(f)

    assert obj == loaded_obj


if __name__ == "__main__":
    from . import profile_func

# Generated at 2022-06-21 12:27:28.406985
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test function 1")
    def test_func1():
        time.sleep(0.5)
        print("I'm here")
        time.sleep(0.5)
        return True

    @work_in_progress("Test function 2")
    def test_func2():
        time.sleep(1)

    assert test_func1()
    test_func2()

# Generated at 2022-06-21 12:27:32.555316
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(1.2)
    with work_in_progress("Working..."):
        time.sleep(1.2)
        assert True

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:27:34.692316
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.5)

# Generated at 2022-06-21 12:27:38.296617
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test work_in_progress"):
        time.sleep(0.2)

if __name__ == '__main__':
    # unit test code
    test_work_in_progress()

# Generated at 2022-06-21 12:27:47.000929
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import os
    import tempfile
    temp_dir = tempfile.gettempdir()
    temp_file_path = os.path.join(temp_dir, "test_work_in_progress_")

    with work_in_progress(f"Loading file {temp_file_path}"):
        with open(temp_file_path, "wb") as f:
            pickle.dump([i for i in range(2**20)], f)
    with work_in_progress(f"Loading file {temp_file_path}"):
        with open(temp_file_path, "rb") as f:
            pickle.load(f)
    # with work_in_progress(f"Loading file {temp_file_path}"):
    #     with open(temp_file_path, "rb") as f

# Generated at 2022-06-21 12:28:16.073123
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Local Variables:
# # tab-width:4
# # indent-tabs-mode:nil
# # End:
# vim: set syntax=python expandtab tabstop=4 shiftwidth=4:

# Generated at 2022-06-21 12:28:27.935003
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file_with_wip(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # Load a file without work_in_progress
    load_file("data/test_data.dat")
    # Load the same file with work_in_progress
    load_file_with_wip("data/test_data.dat")

    obj = load_file("data/test_data.dat")
    # Save the file with work_in_progress

# Generated at 2022-06-21 12:28:35.759480
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import shutil

    print("Testing work_in_progress")
    print("- Loading data.pkl ")
    with work_in_progress("Loading data"):
        with open("data.pkl", "rb") as f:
            data = pickle.load(f)

    print("- Saving data.pkl")
    with work_in_progress("Saving data"):
        with open("data.pkl", "wb") as f:
            pickle.dump(data, f)
    os.remove("data.pkl")

# Generated at 2022-06-21 12:28:37.255878
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing..."):
        time.sleep(1.5)

# Generated at 2022-06-21 12:28:41.224405
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.1)
    with work_in_progress("Saving file"):
        time.sleep(1.2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:28:42.104383
# Unit test for function work_in_progress

# Generated at 2022-06-21 12:28:53.351601
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    .. code:: python

        >>> @work_in_progress("Loading file")
        ... def load_file(path):
        ...     with open(path, "rb") as f:
        ...         return pickle.load(f)
        ...
        ... obj = load_file("/path/to/some/file")
        Loading file... done. (3.52s)

        >>> with work_in_progress("Saving file"):
        ...     with open(path, "wb") as f:
        ...         pickle.dump(obj, f)
        Saving file... done. (3.78s)
    """
    pass  # For sake of doctest


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:28:56.728661
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(1)
    with work_in_progress("Slept for 1 second"):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:28:58.489507
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work in progress"):
        time.sleep(0.5)



# Generated at 2022-06-21 12:29:01.528501
# Unit test for function work_in_progress
def test_work_in_progress():
    def dummy(x):
        return x ** 2

    assert dummy(10) == 100
    with work_in_progress():
        dummy(10)
    with work_in_progress("Dummy"):
        dummy(10)

# Generated at 2022-06-21 12:29:50.753390
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as tmpdir:
        obj = [1, 2, 3, 4, 5]
        path = str(Path(tmpdir) / "tmp.pkl")
        @work_in_progress("Saving file")
        def save_file(path):
            time.sleep(2)
            with open(path, "wb") as f:
                pickle.dump(obj, f)

        @work_in_progress("Loading file")
        def load_file(path):
            with open(path, "rb") as f:
                return pickle.load(f)

        save_file(path)
        assert load_file(path) == obj

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:29:52.681336
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.11)

# Generated at 2022-06-21 12:29:57.675876
# Unit test for function work_in_progress
def test_work_in_progress():
    obj = None
    with work_in_progress('Loading file'):
        obj = np.random.uniform(size=(1_000_000, 1_000_000))
    assert obj is not None

    with work_in_progress('Saving file'):
        obj = np.random.uniform(size=(1_000_000, 1_000_000))
    assert obj is not None

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:30:01.660960
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "tests/resources/test.pkl"
    with work_in_progress("Loading file"):
        obj = load_file(path)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:30:09.866707
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test work_in_progress()."""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file(__file__)
    assert len(obj) > 10
    with work_in_progress("Saving file"):
        with open(__file__, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:30:18.096120
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test case 1
    try:
        with work_in_progress("Sleeping for 5 seconds"):
            time.sleep(5)
    except Exception as e:
        print('test_work_in_progress:')
        print('Case 1: Unexpected Exception: {}'.format(e))
        return 1

    # Test case 2
    try:
        @work_in_progress("Sleeping for 5 seconds")
        def sleep_5s():
            time.sleep(5)
        sleep_5s()
    except Exception as e:
        print('test_work_in_progress:')
        print('Case 2: Unexpected Exception: {}'.format(e))
        return 1

    return 0

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:30:21.638254
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Sorting array")
    def sort_array(a):
        time.sleep(3.4)
        return sorted(a)

    print(sort_array([1, 3, 2]))

# Generated at 2022-06-21 12:30:29.052704
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("tests/io/test_io.pickle")


# Generated at 2022-06-21 12:30:35.207952
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:30:45.054892
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = os.path.join(os.path.dirname(__file__), "data.pkl")
    obj = load_file(path)
    assert len(obj) == 3, f"fail to load data from file '{path}'."

    with work_in_progress("Saving file"):
        a = {"name": "A", "gender": "male"}
        b = {"name": "B", "gender": "female"}
        c = {"name": "C", "gender": "male"}
        with open(path, "wb") as f:
            pickle.dump((a, b, c), f)
    assert os.path

# Generated at 2022-06-21 12:32:24.811297
# Unit test for function work_in_progress
def test_work_in_progress():
    # Pickle a long list, which should take a while
    l = list(range(1000000))
    obj = None
    print()

    def _load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # Pickle the list with work_in_progress
    print("\n" + "-" * 80)
    for desc in [None, "Loading file"]:
        with open("data.pickle", "wb") as f:
            pickle.dump(l, f)
        print()

        @work_in_progress(desc)
        def load_file(path):
            with open(path, "rb") as f:
                return pickle.load(f)

        obj = load_file("data.pickle")
        assert l == obj



# Generated at 2022-06-21 12:32:26.447688
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(1.5)


# Generated at 2022-06-21 12:32:28.634231
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Task")
    def task():
        print(" ", end='', flush=True)
        time.sleep(1)
        print(" ", end='', flush=True)
        time.sleep(1)
        print(" ", end='', flush=True)
        time.sleep(1)
        print(" ", end='', flush=True)

    task()

# Generated at 2022-06-21 12:32:33.983665
# Unit test for function work_in_progress
def test_work_in_progress():
    def test_func():
        time.sleep(1)

    with work_in_progress("Test"):
        test_func()
    
    @work_in_progress("Test2")
    def test_func2():
        time.sleep(1)
    test_func2()
    

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:32:36.386631
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Sleep")
    def sleep(t):
        time.sleep(t)

    sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:32:39.776497
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def count_to(n):
        for _ in range(n + 1):
            time.sleep(0.1)

    count_to(10)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:32:46.191264
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    path = "/path/to/some/file"
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:32:49.121820
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        # pretend to load file
        time.sleep(1)
        return {}

    with work_in_progress("Saving file"):
        # pretend to save file
        time.sleep(1)

    @work_in_progress(desc="Loading files")
    def load_files(paths):
        for path in paths:
            load_file(path)
            time.sleep(1)

    with work_in_progress(desc="Saving files"):
        with open("path/to/some/file", "wb") as f:
            while True:
                # pretend to save file
                time.sleep(1)