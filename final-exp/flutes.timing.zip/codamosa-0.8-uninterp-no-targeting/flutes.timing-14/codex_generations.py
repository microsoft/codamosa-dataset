

# Generated at 2022-06-21 12:22:50.619328
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function :func:`work_in_progress`.
    """
    with work_in_progress("Testing") as testing:
        time.sleep(1)
        testing.stop()
    assert True

# Generated at 2022-06-21 12:22:54.631012
# Unit test for function work_in_progress
def test_work_in_progress():
    test_str = "work_in_progress function test"
    print(test_str)
    with work_in_progress():
        time.sleep(1)
    print("Passed!")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:22:59.045847
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    @work_in_progress("Generating random values")
    def gen_random_values(n):
        time.sleep(random.randint(1,10))
        return [random.random() for _ in range(n)]
    r = gen_random_values(100)
    assert len(r) == 100

# Generated at 2022-06-21 12:23:10.032332
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    begin_time = time.time()
    obj = load_file("/path/to/obj_file")
    save_file(obj, "/path/to/obj_file2")
    assert abs(time.time() - begin_time - 2) < 1
    os.remove("/path/to/obj_file2")

# Generated at 2022-06-21 12:23:17.652154
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    path = os.path.join(os.path.dirname(__file__), "tests", "data", "test.pickle")
    obj = load_file(path)
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


# Initiate unit test when module is run as a script
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:21.643243
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test code block")
    def test_code_block():
        for i in range(1000000):
            for j in range(1000000):
                pass
    test_code_block()

    with work_in_progress("Test function"):
        pass

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:26.733782
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Adding")
    def sum_numbers():
        time.sleep(3)
        return 1 + 2

    assert sum_numbers() == 3

# Generated at 2022-06-21 12:23:36.835132
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump("Saved file", f)

    # Test for context manager
    time.sleep(0.1)
    
    with work_in_progress("Timeout"):
        time.sleep(0.2)
    # Test for decorator
    load_file("/tmp/test")
    save_file("/tmp/test2")

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:23:38.090417
# Unit test for function work_in_progress
def test_work_in_progress():
    # TODO
    assert True


# Generated at 2022-06-21 12:23:41.290431
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing"):
        time.sleep(0.1)
    time.sleep(0.1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:51.050375
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Processing file")
    def process_file(path):
        time.sleep(1.1)
        with open(path, 'rb') as f:
            return f.read()

    process_file('/dev/null')
    process_file('/dev/null')
    process_file('/dev/null')
    process_file('/dev/null')

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:23:57.994447
# Unit test for function work_in_progress
def test_work_in_progress():
    def mysleep():
        time.sleep(1)

    with work_in_progress("Loading file"):
        with open("../README.md", "r") as f:
            print(f.read(), end='')
    mysleep()

    @work_in_progress("Loading file")
    def load_file(path):
        with open("../README.md", "r") as f:
            print(f.read(), end='')

    load_file("../README.md")
    mysleep()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:24:02.345578
# Unit test for function work_in_progress
def test_work_in_progress():
    # TODO: This test fails on Travis-CI
    if utils.is_travis_ci():
        return

    for desc in ["First test", "Second test"]:
        print(f"\n{desc}:")
        with work_in_progress("Work in progress"):
            time.sleep(0.5)
        print("")

# Generated at 2022-06-21 12:24:09.350334
# Unit test for function work_in_progress
def test_work_in_progress():
    def test_func():
        with work_in_progress("Loading file") as wp:
            with open("/path/to/some/file", "rb") as f:
                return pickle.load(f)

    obj = test_func()
    assert isinstance(obj, list)

    with work_in_progress("Saving file") as wp:
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:24:16.957374
# Unit test for function work_in_progress
def test_work_in_progress():
    from .test_tools import Dummy
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    d = Dummy(n=10, s="test")
    path = "test_work_in_progress.pkl"
    with open(path, "wb") as f:
        pickle.dump(d, f)

    obj = load_file(path)

    assert isinstance(obj, Dummy)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    import os
    os.remove(path)


if __name__ == "__main__":
    test

# Generated at 2022-06-21 12:24:19.315020
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Work in progress"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:24:21.901422
# Unit test for function work_in_progress
def test_work_in_progress():

    with work_in_progress("Sleeping"):
        time.sleep(2.0)

    @work_in_progress("Sleeping")
    def test():
        time.sleep(1.0)
    test()



# Generated at 2022-06-21 12:24:27.360607
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file") as w:
        time.sleep(0.5)
        assert str(w) == "Work in progress..."

    with work_in_progress("Saving file") as w:
        time.sleep(0.3)
        assert "Work in progress..." in str(w)



# Generated at 2022-06-21 12:24:29.557518
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sleeping for a second",):
        time.sleep(1)


# Generated at 2022-06-21 12:24:37.719506
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        time.sleep(0.1)
        with open(path, "rb") as f:
            return pickle.load(f)
    @work_in_progress("Loading file")
    def load_file2(path):
        time.sleep(0.1)
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    obj2 = load_file2("/path/to/some/file")
    if obj != obj2:
        raise AssertionError("work_in_progress does not work as expected")

# Generated at 2022-06-21 12:24:46.829379
# Unit test for function work_in_progress
def test_work_in_progress():
    try:
        @work_in_progress("Test for work_in_progress")
        def foo():
            time.sleep(0.01)
        foo()
    except:
        assert False, "work_in_progress failed"

# Generated at 2022-06-21 12:24:55.692849
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path: str):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    """ Command-line interface for the utilities.
    """
    import sys
    if len(sys.argv) >= 2:
        if sys.argv[1] == "test":
            test_work_in_progress()

# Generated at 2022-06-21 12:25:03.540894
# Unit test for function work_in_progress
def test_work_in_progress():
    import unittest
    import tempfile
    import pickle
    import os
    import shutil

    class TestWorkInProgress(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.TemporaryDirectory()
            self.file = os.path.join(self.tmpdir.name, "test.file")

        def test_with_statement(self):
            with work_in_progress("Saving file"):
                with open(self.file, "wb") as f:
                    pickle.dump(self, f)

        def test_decorator(self):
            @work_in_progress("Loading file")
            def load_file(path):
                with open(path, "rb") as f:
                    return pickle.load(f)


# Generated at 2022-06-21 12:25:12.372666
# Unit test for function work_in_progress
def test_work_in_progress():

    with work_in_progress("Loading file"):
        with open('samples/test.txt', 'r') as f:
            #load_file(f)
            time.sleep(2)  # simulate the process
        #time.sleep(1)

    #with work_in_progress("Saving file"):
    #    with open('samples/test.txt', 'r') as f:
    #        time.sleep(2)  # simulate the process
        #time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:25:18.250552
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:25:22.527610
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:25:26.114613
# Unit test for function work_in_progress
def test_work_in_progress():
    # This function is meant to be used on the function being tested.
    def to_test_func(n):
        for i in range(n):
            for j in range(n):
                pass

    with work_in_progress():
        to_test_func(10000)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:25:37.929393
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import random
    import time


# Generated at 2022-06-21 12:25:40.472321
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress(desc="Test"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:25:48.229199
# Unit test for function work_in_progress
def test_work_in_progress():
    assert True


if __name__ == "__main__":
    # Run this file as a script
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

    try:
        import pytest

        __test__ = {name: value for name, value in locals().items() if name.startswith('test_')}
        test_discovery = [f"--cov={__name__}", "--cov-branch", "--cov-report=term-missing", "--verbose"]
        errno = pytest.main(test_discovery)

    except ImportError:
        import unittest


# Generated at 2022-06-21 12:26:05.312005
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def test1(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = test1("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:26:09.416876
# Unit test for function work_in_progress
def test_work_in_progress():
    path = None
    try:
        path = 'test_work_in_progress.dat'

        obj = [1, 2, 3]
        with work_in_progress("Saving file"):
            with open(path, "wb") as f:
                pickle.dump(obj, f)

        with work_in_progress("Loading file"):
            with open(path, "rb") as f:
                data = pickle.load(f)
        assert data == obj
    finally:
        if path is not None and os.path.exists(path):
            os.remove(path)

# Generated at 2022-06-21 12:26:18.481296
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert np.array_equal(obj, np.random.randn(10, 10))

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:23.363809
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(0.5)
        with work_in_progress("Saving subfile"):
            time.sleep(0.2)
        time.sleep(0.3)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:26:32.130512
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    with work_in_progress("Loading test file"):
        time.sleep(random.random() * 5)
    @work_in_progress("Loading test file 2")
    def load():
        time.sleep(random.random() * 5)
    load()
    time.sleep(random.random() * 5)
    with work_in_progress("Loading test file 3"):
        time.sleep(random.random() * 5)

# Call test if executed directly
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:37.222865
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    sleep_time = .5
    with work_in_progress():
        time.sleep(sleep_time)
    load_file_time = 0
    with work_in_progress("Loading file"):
        time.sleep(sleep_time)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:26:41.809480
# Unit test for function work_in_progress
def test_work_in_progress():
    import random

    obj = [random.random() for _ in range(10000)]
    with work_in_progress("Sorting list"):
        obj.sort()
    with work_in_progress("Sorting list (descending order)"):
        obj.sort(reverse=True)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:48.916930
# Unit test for function work_in_progress
def test_work_in_progress():
    import functools
    import tempfile

    @functools.wraps(work_in_progress)
    def test_context(func, desc: str = "Work in progress", *args, **kwargs):
        print(f"Context with {desc}")
        with work_in_progress(desc):
            func(*args, **kwargs)

    def test_decorator(func, desc: str = "Work in progress", *args, **kwargs):
        print(f"Decorator with {desc}")
        func = work_in_progress(desc)(func)
        func(*args, **kwargs)

    def test_func(func, desc: str = "Work in progress", *args, **kwargs):
        print(f"Function with {desc}")
        func(*args, **kwargs)


# Generated at 2022-06-21 12:26:53.064243
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing") as w:
        time.sleep(3)
    assert w is None # w is a context object with no attributes


if __name__ == "__main__":
    print(test_work_in_progress())

# Generated at 2022-06-21 12:26:54.215173
# Unit test for function work_in_progress
def test_work_in_progress():
    assert work_in_progress is not None

# Generated at 2022-06-21 12:27:22.914119
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file('./data/img_{}.pkl'.format(1))

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:27:29.740343
# Unit test for function work_in_progress
def test_work_in_progress():
    import unittest
    import contextlib
    import random
    import string

    class WorkInProgressTest(unittest.TestCase):
        def test_run_time(self):
            @contextlib.contextmanager
            def work_in_progress(desc: str = "Work in progress"):
                print(desc + "... ", end='', flush=True)
                begin_time = time.time()
                yield
                time_consumed = time.time() - begin_time
                print(f"done. ({time_consumed:.2f}s)")

            random.seed(0)
            for _ in range(2):
                string_len = random.randint(1, 5)

# Generated at 2022-06-21 12:27:38.503302
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    
    def random_sleep(n):
        time.sleep(random.random() * n)
    
    with work_in_progress("test_work_in_progress"):
        random_sleep(1)
        
        with work_in_progress("test_work_in_progress 1"):
            random_sleep(2)
            
            with work_in_progress("test_work_in_progress 1.1"):
                random_sleep(3)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:27:45.805705
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1.23)
    print()

    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1.23)

    load_file("/path/to/some/file")
    print()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:27:50.516001
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    from contextlib import redirect_stdout

    out = io.StringIO()
    with redirect_stdout(out):
        with work_in_progress("test"):
            time.sleep(1)
        assert out.getvalue() == 'test... done. (1.00s)\n'

# Generated at 2022-06-21 12:27:59.335527
# Unit test for function work_in_progress
def test_work_in_progress():
    import doctest
    import os
    from tempfile import NamedTemporaryFile

    with NamedTemporaryFile(suffix=".pkl") as f:
        def load_file(path):
            with open(path, "rb") as f:
                return pickle.load(f)

        obj = {"a": 1, "b": "b"}
        with open(f.name, "wb") as f:
            pickle.dump(obj, f)

        os.remove(f.name)

        result = doctest.testmod()

        assert result.failed == 0

# Generated at 2022-06-21 12:28:09.391845
# Unit test for function work_in_progress
def test_work_in_progress():
    # Mock to check if message is printed correctly
    with mock.patch("sys.stdout", new_callable=io.StringIO) as mock_stdout:
        with work_in_progress("Loading file"):
            pass
        assert mock_stdout.getvalue() == "Loading file... done. (0.00s)\n"

    # Mock to check if time is correctly computed
    with mock.patch("time.time") as mock_time:
        # Set time to fake time
        mock_time.return_value = 10000
        with work_in_progress("Loading file"):
            # Set time to fake time
            mock_time.return_value = 10010
        assert mock_time.return_value - mock_time.return_value == 10

# Generated at 2022-06-21 12:28:14.271673
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    time.sleep(1)
    with work_in_progress("Loading file"):
        time.sleep(2)

# The above function can be called from command line using the following command.
# $python -m xltp.utils.timer.work_in_progress

# Generated at 2022-06-21 12:28:18.296921
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Adding numbers"):
        for _ in range(1_000_000):
            a = 1 + 1


if __name__ == "__main__":
    try:
        test_work_in_progress()
    except Exception as e:
        print(f"{e.__class__.__name__}: {e}")

# Generated at 2022-06-21 12:28:21.495460
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(1)
    return


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:29:09.377994
# Unit test for function work_in_progress
def test_work_in_progress():
    import doctest
    results = doctest.testmod(verbose=True)
    print(f"{results.attempted} attempted, {results.failed} failed, {results.passed} passed")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:29:11.070604
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress('Test work in progress'):
        time.sleep(1.234)

# Generated at 2022-06-21 12:29:18.553980
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test that the context manager works as expected
    def fun():
        time.sleep(3)
    with work_in_progress("I'm working"):
        fun()
    # Test that the function decorator works as expected
    @work_in_progress("I'm working")
    def fun():
        time.sleep(3)
    fun()
    # Test that the function decorator works with function arguments
    @work_in_progress("I'm working")
    def fun(arg: int):
        time.sleep(3)
    fun(3)

# Generated at 2022-06-21 12:29:28.416736
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import os
    import tempfile
    import contextlib

    path = None
    with tempfile.NamedTemporaryFile(delete=False) as tmp:
        path = tmp.name

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file(path)

    assert path is not None
    assert os.path.isfile(path)

    count = 3
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    assert os.path.isfile(path)

# Generated at 2022-06-21 12:29:32.199713
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")
    save_file("/path/to/other/file", obj)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:29:40.589767
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.5)
    with work_in_progress("Saving file"):
        time.sleep(1.0)
    def load_file(path):
        with work_in_progress("Loading file"):
            time.sleep(0.5)
        with work_in_progress("Saving file"):
            time.sleep(1.0)
    load_file("/tmp/test")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:29:43.775907
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Printing things")
    def print_things(n):
        for i in range(n):
            print(i, flush=True)
    print_things(100)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:29:51.149677
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import tempfile

    @work_in_progress("Testing file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with tempfile.TemporaryDirectory(prefix="work_in_progress_test") as tmpdir:
        obj = {
            "a": 1,
            "b": "2",
            "c": [1, 2, 3, "4"],
        }
        with open(os.path.join(tmpdir, "test.pickle"), "wb") as f:
            pickle.dump(obj, f)

        time.sleep(1)

        assert load_file(os.path.join(tmpdir, "test.pickle")) == obj

        time.sleep(1)

# Generated at 2022-06-21 12:29:53.987628
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test")
    def f():
        time.sleep(1)

    f()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:29:56.492020
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("The Fibonacci sequence") as w:
        for x in range(11):
            print(f"{x:2d} {x:4d}")
            time.sleep(.5)

# Generated at 2022-06-21 12:31:31.086284
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
        # end with
    # end func

    obj = load_file("pickle_test.pk")
    assert obj == range(10)
    with work_in_progress("Saving file"):
        with open("pickle_test.pk", "wb") as f:
            pickle.dump(obj, f)
    # end with
# end func

# Generated at 2022-06-21 12:31:34.530065
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Starting test"):
        time.sleep(1)
    for i in range(10):
        with work_in_progress("Task #{}".format(i)):
            time.sleep(.1)

# Generated at 2022-06-21 12:31:42.107215
# Unit test for function work_in_progress
def test_work_in_progress():
    def wait_time(seconds: float):
        time.sleep(seconds)

    # Test 1: context manager
    with work_in_progress("Testing context manager..."):
        wait_time(1.23)

    # Test 2: function decorator
    @work_in_progress("Testing function decorator...")
    def test():
        wait_time(2.34)

    test()


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "test":
        test_work_in_progress()

# Generated at 2022-06-21 12:31:51.029016
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import time

    def slow_function():
        r"""Slow function that takes four seconds to complete.
        """
        time.sleep(4)

    print("Calling slow_function... ")
    with work_in_progress("Slow function in progress"):
        slow_function()

    for i in range(4):
        print("\n" + "Calling slow_function twice... ", end="")
        with work_in_progress("Slow function in progress"):
            slow_function()
            slow_function()
            time.sleep(random.uniform(0.00, 0.05))


# Generated at 2022-06-21 12:31:58.742409
# Unit test for function work_in_progress
def test_work_in_progress():

    import os
    import random
    import unittest

    def random_string(length):
        return "".join(random.choices(string.ascii_letters, k=length))

    class TestWorkInProgress(unittest.TestCase):
        def test(self):
            # Create a random file that takes time to copy
            filename = random_string(20)
            filepath = os.path.join(os.getcwd(), filename)
            with open(filepath, "w") as f:
                for i in range(100000):
                    f.write(random_string(100) + "\n")
            # Copy the file
            with work_in_progress("Copying file"):
                os.system(f"cp {filepath} {filepath}_copy")
            # Remove the file

# Generated at 2022-06-21 12:32:06.974276
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    print("obj = load_file(\"/path/to/some/file\")")
    obj = load_file("/path/to/some/file")
    print("obj = load_file(\"/path/to/some/file\")")
    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open("/path/to/some/file2", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:32:12.196980
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing function work_in_progress"):
        time.sleep(2)
    @work_in_progress("Testing function work_in_progress")
    def test(x):
        time.sleep(x)
        return x
    test(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:32:13.459634
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test work_in_progress")
    def test():
        time.sleep(1)
    test()

# Generated at 2022-06-21 12:32:22.952786
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile
    import os
    os.environ["COLUMNS"] = "80"

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with tempfile.NamedTemporaryFile() as f:
        save_file({"spam": "eggs"}, f.name)
        assert load_file(f.name) == {"spam": "eggs"}


if __name__ == '__main__':
    import pytest

# Generated at 2022-06-21 12:32:33.480881
# Unit test for function work_in_progress
def test_work_in_progress():
    # TODO: Find a better way to test the function
    from contextlib import redirect_stdout
    import io
    import os
    import pytest
    import tempfile

    # Format: (expected, code)