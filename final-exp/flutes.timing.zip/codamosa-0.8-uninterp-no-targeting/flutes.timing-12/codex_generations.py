

# Generated at 2022-06-21 12:22:55.834397
# Unit test for function work_in_progress
def test_work_in_progress():
    for i in range(10):
        with work_in_progress(desc=f"Iteration {i}"):
            time.sleep(0.5)

if __name__ == '__main__':
    print(__doc__)
    print(f"{__file__} is not a standalone script.")
    test_work_in_progress()

# Generated at 2022-06-21 12:22:59.623504
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
# unit_test_end

# Generated at 2022-06-21 12:23:04.439335
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import random

    def sleep_for_n_seconds(n):
        time.sleep(n)

    with work_in_progress("Sleeping for 5 seconds"):
        sleep_for_n_seconds(5)


# Generated at 2022-06-21 12:23:10.678571
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import pickle
    import os
    from contextlib import redirect_stdout

    # Make a temporary file
    with tempfile.NamedTemporaryFile(delete=False) as fp:
        path = fp.name
        obj = {"test": 123}
        pickle.dump(obj, fp)

    # Redirect the output, and run the test
    with open(os.devnull, "w") as fp:
        with redirect_stdout(fp):
            @work_in_progress("Loading file")
            def load_file(path):
                with open(path, "rb") as f:
                    return pickle.load(f)

            load_file(path)


# Generated at 2022-06-21 12:23:14.959192
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(2.5)

    @work_in_progress("Loading file")
    def load_file():
        time.sleep(3)

    load_file()

# Generated at 2022-06-21 12:23:25.075066
# Unit test for function work_in_progress
def test_work_in_progress():
    from pathlib import Path
    import tempfile
    from time import sleep

    with tempfile.TemporaryDirectory() as tmpdirname:
        path = Path(tmpdirname) / "my_dump"

        @work_in_progress("Loading file")
        def load_file(path):
            sleep(0.2)  # To simulate a long loading time
            with path.open("rb") as f:
                return pickle.load(f)

        obj = load_file(path)

        assert obj == {"a": 1, "b": 2, "c": {"d": None}}

        sleep(0.2)

        with work_in_progress("Saving file"):
            sleep(0.2)  # To simulate a long saving time

# Generated at 2022-06-21 12:23:27.625846
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Work in progress"):
        time.sleep(0.001)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:31.374235
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1.5)
    assert True


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:33.234503
# Unit test for function work_in_progress
def test_work_in_progress():
    import doctest
    doctest.run_docstring_examples(work_in_progress, globals())

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:38.673895
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("test")
    def f():
        time.sleep(2)
    f()

    with work_in_progress("test2"):
        time.sleep(1)

################################################################################

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:42.242634
# Unit test for function work_in_progress
def test_work_in_progress():
    pass
    # TODO

# Generated at 2022-06-21 12:23:46.331836
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(1)
    with work_in_progress("Test work_in_progress"):
        time.sleep(1)

# Generated at 2022-06-21 12:23:56.541492
# Unit test for function work_in_progress
def test_work_in_progress():
    import os, tempfile, shutil, pickle

    with work_in_progress("Creating temporary directory") as _:
        tmp_dir = tempfile.mkdtemp()

    print("Creating empty files...")
    for i in range(10):
        with work_in_progress(f"Creating empty file #{i}") as _:
            tmp_path = os.path.join(tmp_dir, f"empty_file_{i}.txt")
            with open(tmp_path, "w") as f:
                f.write("")

    @work_in_progress("Creating non-empty files while picking their names")
    def create_non_empty_files():
        names = []
        for i in range(10):
            names.append("non_empty_file_{}.txt".format(i))

# Generated at 2022-06-21 12:23:58.841400
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test work in progress"):
        time.sleep(2.5)

# Generated at 2022-06-21 12:24:06.279631
# Unit test for function work_in_progress
def test_work_in_progress():
    # Mock time.time() to always return 1
    def mock_time():
        return 1

    # Start test
    with patch.object(time, 'time', mock_time) as mock_time:
        # Test @work_in_progress decorator
        @work_in_progress("Loading file")
        def load_file(path):
            return path

        assert load_file('path') == 'path'
        # Increase time.time() to 2
        mock_time.return_value += 1
        # Test context manager
        with work_in_progress("Saving file"):
            pass


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:24:09.721460
# Unit test for function work_in_progress
def test_work_in_progress():
    data = np.random.rand(10000000)
    with work_in_progress("Sorting random data"):
        data.sort()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:24:15.199758
# Unit test for function work_in_progress
def test_work_in_progress():
    def foo():
        with work_in_progress("In foo"):
            time.sleep(0.05)

    @work_in_progress("In bar")
    def bar():
        time.sleep(0.1)

    foo()
    bar()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:24:16.185483
# Unit test for function work_in_progress

# Generated at 2022-06-21 12:24:17.439997
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.03)

# Generated at 2022-06-21 12:24:25.127394
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    >>> @work_in_progress("Testing")
    ... def wait(time_delay: float) -> None:
    ...     time.sleep(time_delay)
    ...
    >>> wait(1.0)
    Testing... done. (1.00s)
    >>> with work_in_progress(desc="Testing again"):
    ...     time.sleep(1.0)
    Testing again... done. (1.00s)
    """

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:24:30.063382
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Printing something")
    def print_something():
        print("something")

    print_something()

# Generated at 2022-06-21 12:24:37.787137
# Unit test for function work_in_progress
def test_work_in_progress():
    print("work_in_progress")
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file(os.path.join(test_dir, "test_data.pkl"))

    with work_in_progress("Saving file"):
        with open(os.path.join(test_dir, "test_data_copy.pkl"), "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:24:45.811593
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "/path/to/some/file"
    obj = load_file("/path/to/some/file")

    with work_in_progress("saving file") as saving_file:
        with open(path, "wb") as f:
            pickle.dump(obj, f)


# Generated at 2022-06-21 12:24:51.341363
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:24:53.443657
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(1)

# Generated at 2022-06-21 12:24:55.917434
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing"):
        time.sleep(0.3)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:24:58.411417
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        pass

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:25:10.678271
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    import sys
    import unittest

    class TestWorkInProgress(unittest.TestCase):
        def test_basic(self):
            buf = io.StringIO()
            stdout = sys.stdout

            try:
                sys.stdout = buf
                with contextlib.redirect_stdout(buf):
                    with work_in_progress("Testing"):
                        time.sleep(0.1)
                
                result = buf.getvalue()
            finally:
                sys.stdout = stdout

            self.assertIn("Testing... ", result)
            self.assertIn("done. (", result)
            self.assertIn("s)", result)

    unittest.main()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:25:14.894505
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import time

    random.seed(0)
    with work_in_progress("Importing Pandas") as _:
        import pandas as pd

    time.sleep(.5)
    with work_in_progress("Sleep"):
        time.sleep(2)


if __name__ == "__main__":
    # Run the unit test
    test_work_in_progress()

# Generated at 2022-06-21 12:25:24.271663
# Unit test for function work_in_progress
def test_work_in_progress():
    # Helper function for testing work_in_progress function
    def assert_time(expected_time: float, func: Callable, *args, **kwargs):
        with work_in_progress():
            time.sleep(expected_time)
            func(*args, **kwargs)
    # Unit test for work_in_progress context manager
    def mgr_test():
        assert_time(1, lambda : None)
        # Under Windows, process creation and termination is not as fast as
        # under Linux, so sleep time is increased to 2 seconds
        if os.name == "nt":
            assert_time(2, os.system, "sleep 1")
        else:
            assert_time(1, os.system, "sleep 1")
    # Unit test for work_in_progress function decorator

# Generated at 2022-06-21 12:25:40.685334
# Unit test for function work_in_progress
def test_work_in_progress():
    from random import random
    from random import choice
    from string import ascii_letters

    def random_str(length):
        return "".join(choice(ascii_letters) for _ in range(length))

    with work_in_progress("1") as _:
        time.sleep(random())
    with work_in_progress("2") as _:
        time.sleep(random())
    with work_in_progress("3") as _:
        time.sleep(random())
    with work_in_progress("4") as _:
        time.sleep(random())
    with work_in_progress(random_str(10)) as _:
        time.sleep(random())
    with work_in_progress(random_str(10)) as _:
        time.sleep(random())

# Generated at 2022-06-21 12:25:50.188512
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test if work_in_progress works as expected."""

    @work_in_progress("Loading file")
    def load_file(path: str):
        with open(path, "rb") as f:
            return pickle.load(f)

    assert load_file("/path/to/some/file") == [1, 2, 3, 4]

    obj = [1, 2, 3, 4]
    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:25:54.044632
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "~/.bashrc"
    obj = load_file(path)
    assert obj != None

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:05.588826
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # TODO: Generate a test file, and use that file to do the testing here
    obj = load_file("./sir_learner.py")
    assert isinstance(obj, dict)
    assert "title" in obj.keys()
    assert obj["title"] == "sir_learner"
    assert "author" in obj.keys()
    assert type(obj["author"]) == list

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    # TODO: Generate a test

# Generated at 2022-06-21 12:26:16.654185
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import os
    import tempfile
    import numpy as np
    import pandas as pd

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(df: pd.DataFrame, path: str):
        with open(path, "wb") as f:
            pickle.dump(df, f)

    arr = np.random.rand(100000, 100)
    df = pd.DataFrame(arr)


# Generated at 2022-06-21 12:26:22.238205
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Task A"):
        time.sleep(0.5)
        pass
    with work_in_progress("Task B"):
        time.sleep(0.5)


if __name__ == "__main__":
    print("Testing module utils/profiler.py...")
    test_work_in_progress()
    print("Done.")

# Generated at 2022-06-21 12:26:32.120395
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path: str) -> str:
        return ''.join([path, " loaded"])
    assert(load_file("/path/to/some/file") == "/path/to/some/file loaded")

    @work_in_progress("Saving file")
    def save_file(path: str, content: str) -> str:
        return ".".join([path, content])
    assert(save_file("/path/to/some/file", "content") \
        == "/path/to/some/file.content")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:35.087527
# Unit test for function work_in_progress
def test_work_in_progress():
    import doctest
    doctest.testmod()


if __name__ == "__main__":

    # Unit test
    test_work_in_progress()

# Generated at 2022-06-21 12:26:37.372758
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def test():
        time.sleep(0.3)  # pretend to do some work

    test()

# Generated at 2022-06-21 12:26:39.869251
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.1)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:26:53.746986
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
        raise RuntimeError()
    time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:27:03.071461
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("test_file")

    with work_in_progress("Saving file"):
        with open("test_file_save", "wb") as f:
            pickle.dump(obj, f)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open("test_file_save", "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("test_file")

# Generated at 2022-06-21 12:27:12.730343
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
 
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:27:18.742458
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(0.2)
        return {'a': 1, 'b': 2}

    obj = load_file("/path/to/some/file")
    assert isinstance(obj, dict)
    assert obj == {'a': 1, 'b': 2}

# Generated at 2022-06-21 12:27:25.531687
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with work_in_progress("Loading file"):
        obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        save_file(obj, "/path/to/some/file")

# Generated at 2022-06-21 12:27:31.179731
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    # Test pickling
    obj = dict(a=1, b=[1, 2, 3], c=[i*1.0 for i in range(100000)])
    tmp_file = "./test_work_in_progress.tmp"
    save_file(tmp_file, obj)
    obj2 = load_file(tmp_file)
    assert len(obj) == len(obj2)
    assert obj["a"]

# Generated at 2022-06-21 12:27:40.908848
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        print("Loading file...")
    print()

    @work_in_progress("Loading file")
    def load_file(path: str):
        with open(path, "rb") as f:
            time.sleep(1)
            return pickle.load(f)

    obj = load_file("./pickle_test.txt")
    print(obj)


if __name__ == "__main__":
    test_work_in_progress()
    # test_progress_info()
    # test_progress_bar()
    # test_progress_bar_auto_fill()

# Generated at 2022-06-21 12:27:49.449122
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import pickle

    path = tempfile.mktemp()
    obj = {
        "name": "foo",
        "value": 42,
    }
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    with work_in_progress("Loading file"):
        with open(path, "rb") as f:
            obj = pickle.load(f)

# Generated at 2022-06-21 12:27:50.514847
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(2)

# Generated at 2022-06-21 12:27:58.903846
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


# Unit test
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:28:29.184956
# Unit test for function work_in_progress
def test_work_in_progress():
    with open("test_work_in_progress.txt", "w") as f:
        fd = f.fileno()
        with work_in_progress("Test"):
            with open("/dev/zero", "rb") as fin:
                f.write(fin.read(1024*1024*1024))
    with open("test_work_in_progress.txt", "r") as f:
        assert f.read(1) == b"\0"
    os.unlink("test_work_in_progress.txt")


if __name__ == '__main__':
    print("This module is a utility module, containing only functions and "
          "does not have executable code. Please run tests/unittest_util.py "
          "to test this module.")

# Generated at 2022-06-21 12:28:39.645094
# Unit test for function work_in_progress
def test_work_in_progress():
    file_list = [
        "/usr/bin/vim",
        "/usr/bin/python3.8",
        "/usr/bin/python3.7",
        "/usr/bin/python3.6",
        "/usr/bin/python3.5"
    ]
    for _ in range(10):
        start = time.time()
        with work_in_progress("Work in progress"):
            for file_ in file_list:
                if os.path.exists(file_):
                    os.remove(file_)
        end = time.time()
        print(f"\t{end-start}")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:28:41.310412
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("This is a test"):
        time.sleep(0.5)

# Generated at 2022-06-21 12:28:43.665192
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(0.1)
    with work_in_progress("Segmenting image"):
        time.sleep(0.1)
    with work_in_progress():
        time.sleep(0.2)

# Generated at 2022-06-21 12:28:50.272371
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test function work_in_progress."""
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.5)

    print()
    @work_in_progress("Testing work_in_progress")
    def test_func():
        time.sleep(0.5)
    test_func()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:28:51.261169
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "This is a test"
    with work_in_progress(desc=desc):
        time.sleep(0.05)

# Generated at 2022-06-21 12:29:01.737732
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import os
    from contextlib import suppress
    import pickle

    def testload(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def testsave(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with tempfile.TemporaryDirectory() as tmpdir:
        testdatapath = os.path.join(tmpdir, "testdata.pickle")

        with work_in_progress("Loading file"):
            loaded = testload(testdatapath)

        with work_in_progress("Saving file"):
            testsave(testdatapath, loaded)

        with work_in_progress("Testing"):
            time.sleep(1)


# Generated at 2022-06-21 12:29:05.868515
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.25)

    @work_in_progress("Loading file")
    def fn():
        time.sleep(0.25)
    fn()

# Generated at 2022-06-21 12:29:11.080364
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert True

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)
    assert True

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:29:15.434199
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("tests/data/2d_array.p")
    assert obj.shape == (64, 64, 3)

# Generated at 2022-06-21 12:29:59.032941
# Unit test for function work_in_progress
def test_work_in_progress():
    import math
    print("Testing function `work_in_progress`.")

    @work_in_progress("Testing function `work_in_progress`")
    def test():
        time.sleep(0.1)
        math.sqrt(100.0)

    test()

# Generated at 2022-06-21 12:30:00.791871
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Sleep")
    def test():
        time.sleep(0.5)

    test()



# Generated at 2022-06-21 12:30:05.489206
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def foo(i):
        time.sleep(i)
    foo(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:30:15.099409
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import pickle
    import tempfile

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, data):
        with open(path, "wb") as f:
            pickle.dump(data, f)

    with tempfile.TemporaryDirectory() as temp_dir:
        file_path = os.path.join(temp_dir, "temp.txt")

        save_file(file_path, "some data")
        loaded = load_file(file_path)

    assert loaded == "some data"


if __name__ == "__main__":
    # Run unit test
    test_work

# Generated at 2022-06-21 12:30:16.966463
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sleeping"):
        time.sleep(1.0)

# Generated at 2022-06-21 12:30:22.612055
# Unit test for function work_in_progress
def test_work_in_progress():
    """ Unit test for function work_in_progress """
    with work_in_progress("Testing..."):
        time.sleep(0.5)

# Start program
if __name__ == "__main__":
    # Do something
    print("\nThis program is being run by itself")
    test_work_in_progress()
else:
    print("\nI am being imported from another module")

# Generated at 2022-06-21 12:30:28.026927
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Intensive calculation")
    def intensive_calc():
        for i in range(10000000):
            pass
    intensive_calc()
    assert True


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:30:35.158142
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def add(a, b):
        return a + b

    @work_in_progress("Test work_in_progress")
    def sub(a, b):
        return a - b

    with work_in_progress("Sleeping for a second"):
        time.sleep(1)

    with work_in_progress():
        time.sleep(1)

    with work_in_progress():
        time.sleep(1)



# Generated at 2022-06-21 12:30:41.923393
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile

    @work_in_progress("Time consuming task")
    def time_consuming_task():
        time.sleep(1)

    time_consuming_task()

    obj = {"Hello": "World"}

    file = tempfile.TemporaryFile()
    with work_in_progress("Saving data"):
        pickle.dump(obj, file)
    file.seek(0)
    with work_in_progress("Loading data"):
        assert pickle.load(file) == obj

# Generated at 2022-06-21 12:30:44.554304
# Unit test for function work_in_progress
def test_work_in_progress():
    # It works as a context manager
    with work_in_progress("Test"):
        time.sleep(0.5)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:32:21.409475
# Unit test for function work_in_progress
def test_work_in_progress():
    def calculate_pi(n, f):
        # Calculate pi using Monte-Carlo method
        s = 0
        for i in range(n):
            x = random.random()
            y = random.random()
            if pow(x, 2) + pow(y, 2) <= 1:
                s += 1
        pi = s * 4.0 / n
        print(f(pi))

    calculate_pi(100000000, lambda pi: f"Pi: {pi}")

if __name__ == "__main__":
    test_work_in_progress()
    print()

    with work_in_progress("Loading file"):
        with open("../../data/plot/plot_data.json", "r") as f:
            pass
    print()


# Generated at 2022-06-21 12:32:31.972569
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress."""
    from . import is_equal

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file_wip(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # Test if the timing is about the same
    with work_in_progress("Loading file"):
        obj = load_file("/path/to/some/file")
    obj2 = load_file_wip("/path/to/some/file")
    assert is_equal(obj, obj2)

    # Test if callable is callable after decorated by work_in_progress

# Generated at 2022-06-21 12:32:37.374842
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    @work_in_progress("Test function")
    def f():
        a = []
        for _ in range(10000):
            a.append(random.random())

    @work_in_progress("Test context manager")
    def f2():
        a = []
        for _ in range(10000):
            a.append(random.random())

    f()
    with f2():
        pass


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:32:39.336404
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sleeping for 3 seconds"):
        time.sleep(3)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:32:49.356811
# Unit test for function work_in_progress
def test_work_in_progress():

    # Test with a function.
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    # Test with a context manager.
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    # Test with a for loop.
    for i in work_in_progress("Stepping"):
        print(i)
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()