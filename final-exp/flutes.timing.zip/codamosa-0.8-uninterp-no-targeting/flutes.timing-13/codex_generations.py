

# Generated at 2022-06-21 12:22:52.208359
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test Work in progress"):
        time.sleep(1.2)
    with work_in_progress("Test Work in progress"):
        print("This should be printed")
        time.sleep(0.3)

# Generated at 2022-06-21 12:22:58.139068
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function :py:func:`work_in_progress`.
    """
    import time
    # Test with function decorator
    @work_in_progress("Loading file")
    def load_file(path):
        return "s" * (1 << 25)
    load_file("/path/to/some/file")
    # Test with context manager
    with work_in_progress("Saving file"):
        time.sleep(0.2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:09.790901
# Unit test for function work_in_progress
def test_work_in_progress():
    import random

    @work_in_progress("Loading file")
    def load(path: str):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save(path: str, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    path = "temp"
    obj = list(range(random.randint(1000, 100000)))
    save(path, obj)
    assert load(path) == obj, "File save/load fail"
    # Remove the temporary file
    os.remove(path)



if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:23:13.256837
# Unit test for function work_in_progress
def test_work_in_progress():
    # No need to test it on Travis.
    if "TRAVIS" in os.environ:
        return
    with work_in_progress("Foo"):
        time.sleep(2)

# Generated at 2022-06-21 12:23:16.450453
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1.5)

# test_work_in_progress()

# Generated at 2022-06-21 12:23:24.186685
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    >>> @work_in_progress("Importing module")
    ... def import_module(name):
    ...     import importlib
    ...     return importlib.import_module(name)
    ...
    >>> torch = import_module("torch")
    Importing module... done. (0.82s)
    >>> with work_in_progress("Creating Tensor"):
    ...     t = torch.empty(3, 5)
    Creating Tensor... done. (2.04s)
    >>> isinstance(t, torch.Tensor)
    True
    """
    pass

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:23:31.118771
# Unit test for function work_in_progress
def test_work_in_progress():
    __test__ = True
    with work_in_progress("Coucou"):
        time.sleep(0.01)
    with work_in_progress("Test 1"):
        time.sleep(0.1)
    with work_in_progress("Test 2"):
        time.sleep(1)


if __name__ == "__main__":
    if "--test" in sys.argv:
        test_work_in_progress()

# Generated at 2022-06-21 12:23:37.473361
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    # Loading file... done. (3.52s)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    # Saving file... done. (3.78s)
    pass

# Generated at 2022-06-21 12:23:39.257218
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def func():
        time.sleep(1)

    func()

# Generated at 2022-06-21 12:23:46.554883
# Unit test for function work_in_progress
def test_work_in_progress():
    from os import path

    test_pickle_file = path.join(path.dirname(__file__), "example.pickle")

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    with work_in_progress("Loading file"):
        obj = load_file(test_pickle_file)

    with work_in_progress("Saving file"):
        with open(test_pickle_file, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:52.125835
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:23:58.022047
# Unit test for function work_in_progress
def test_work_in_progress():
    from threading import Thread
    from unittest import TestCase, main

    class TestWorkInProgress(TestCase):
        def test_work_in_progress(self):
            def worker(t: float):
                with work_in_progress(f"Sleep {t} seconds"):
                    time.sleep(t)

            t = Thread(target=worker, args=(1,))
            t.start()
            t.join()

    main(verbosity=2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:24:03.403429
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert obj == some_object

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:24:05.138378
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1.7)

# Generated at 2022-06-21 12:24:16.095062
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import random
    import pickle
    import shutil
    import tempfile
    import string

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            return pickle.dump(obj, f)

    tmp_path = tempfile.mktemp()
    obj = random.sample(string.ascii_letters, 256)
    save_file(obj, tmp_path)
    res = load_file(tmp_path)
    os.remove(tmp_path)
    
    assert obj == res



# Generated at 2022-06-21 12:24:21.656398
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    begin_time = time.time()
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    time_consumed = time.time() - begin_time

# Generated at 2022-06-21 12:24:27.180132
# Unit test for function work_in_progress
def test_work_in_progress():
    for k in range(10):
        with work_in_progress("Loading file"):
            time.sleep(1)
    for k in range(10):
        with work_in_progress("Loading file"):
            time.sleep(0.1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:24:37.545175
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import filecmp
    import hashlib

    TEST_FILENAME = "/tmp/test_work_in_progress"

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return f.read()

    @work_in_progress("Saving file")
    def save_file(path, data):
        with open(path, "wb") as f:
            f.write(data)

    with work_in_progress("Making test string"):
        time.sleep(2)
        TEST_STRING = "".join(map(str, range(int(1e5))))

    with work_in_progress("Saving file"):
        save_file(TEST_FILENAME, TEST_STRING)


# Generated at 2022-06-21 12:24:40.845746
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Task 1")
    def func1():
        time.sleep(1)

    with work_in_progress("Task 2"):
        time.sleep(2)

    func1()

# test_work_in_progress()

# Generated at 2022-06-21 12:24:46.493648
# Unit test for function work_in_progress
def test_work_in_progress():
    class Class:
        @work_in_progress("Some task")
        def work(self):
            time.sleep(0.03)
            return self

    c = Class()
    assert c.work() is c

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:25:00.884173
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    import os
    import pytest
    import sys

    print(f"Python {sys.version}")
    print(f"Pytest {pytest.__version__}")

    # Uncomment these lines if you want to run the unit tests in this file
    # print(os.listdir())
    # test_work_in_progress()
    # test_method1()

# Generated at 2022-06-21 12:25:03.444701
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(0.5)
    with work_in_progress("Waiting"):
        time.sleep(0.5)

# Generated at 2022-06-21 12:25:12.699082
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "w") as f:
            f.write("0" * 1024)
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            return pickle.dump({"a": 1, "b": "test"}, f)

    load_file("test.pickle")
    save_file("test.pickle")

# Generated at 2022-06-21 12:25:22.285899
# Unit test for function work_in_progress
def test_work_in_progress():
    import sys
    import pickle
    import tempfile

    dummy_object = "A" * (1<<30)

    def test_decorator(path):
        @work_in_progress("Loading object")
        def load_object(path):
            with open(path, "rb") as f:
                return pickle.load(f)

        return load_object(path)

    def test_context_manager(path):
        with work_in_progress("Saving object"):
            with open(path, "wb") as f:
                pickle.dump(dummy_object, f)

    with tempfile.TemporaryDirectory() as dirpath:
        path = dirpath + "/test.pkl"

# Generated at 2022-06-21 12:25:24.938059
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def func():
        pass

    func()


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:25:28.873713
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(1.5)
        with work_in_progress("Loading file"):
            time.sleep(2.3)
    print("Done.")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:25:36.203413
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        path = "/path/to/some/file"
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:25:42.658191
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            return pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")
    save_file(obj, "/path/to/some/other/file")

# Generated at 2022-06-21 12:25:47.247180
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert obj is not None

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:25:50.593318
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing function work_in_progress")
    def test():
        time.sleep(0.5)
    test()


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:26:03.058969
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:08.124696
# Unit test for function work_in_progress
def test_work_in_progress():
    from pyfakefs.fake_filesystem_unittest import TestCase
    import random

    class TestWorkInProgress(TestCase):
        def setUp(self):
            self.setUpPyfakefs()

        def test_work_in_progress(self):
            with open("file", "w") as f:
                for _ in range(3):
                    f.write(str(random.random()))

            with work_in_progress("Writing"):
                with open("file", "w") as f:
                    for _ in range(3):
                        f.write(str(random.random()))

            self.assertTrue(os.path.exists("file"))

    from nose.tools import assert_equal, assert_raises


# Generated at 2022-06-21 12:26:17.493331
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test 1
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    # Test 2
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    # Test
    test_work_in_progress()

# Generated at 2022-06-21 12:26:28.664696
# Unit test for function work_in_progress
def test_work_in_progress():
    # Checking that the context manager works as a function decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
        time.sleep(2)

    obj = load_file(__file__)
    assert isinstance(obj, type(sys.modules[__name__])), "'load_file' is not working properly"

    # Checking that the context manager works as a context manager
    with work_in_progress("Saving file"):
        with open(__file__, "wb") as f:
            pickle.dump(obj, f)
        time.sleep(2)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:30.399660
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("This is a test"):
        time.sleep(3)

# Generated at 2022-06-21 12:26:33.025301
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:42.360884
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Creating a large list")
    def create_large_list(n):
        return list(range(n))

    large_list = create_large_list(1000000)
    assert len(large_list) == 1000000

    with work_in_progress("Creating a second large list") as w:
        large_list2 = create_large_list(1000000)
        assert len(large_list2) == 1000000

    with work_in_progress("Creating a third large list") as w:
        large_list3 = create_large_list(1000000)
        assert len(large_list3) == 1000000

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:44.344392
# Unit test for function work_in_progress
def test_work_in_progress():
    description = "Compiling package"

    with work_in_progress(description):
        time.sleep(0.1)
    assert True

# Generated at 2022-06-21 12:26:49.994929
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with tempfile.TemporaryDirectory() as tempdir:
        path = os.path.join(tempdir, "file.pkl")
        with open(path, "wb") as f:
            pickle.dump({
                "hello": "world",
                "foo": [1, 2, 3],
            }, f)

        assert load_file(path) == {
            "hello": "world",
            "foo": [1, 2, 3],
        }

# Generated at 2022-06-21 12:26:59.822666
# Unit test for function work_in_progress
def test_work_in_progress():
    # Prepare the test file
    print("Preparing test file...")
    obj = np.random.randn(1000, 1000)
    with open("temp_file.npy", "wb") as f:
        np.save(f, obj)

    @work_in_progress("Loading test file")
    def load_file(path):
        with open(path, "rb") as f:
            return np.load(f)

    obj1 = load_file("temp_file.npy")

    with work_in_progress("Saving test file"):
        with open(path, "wb") as f:
            np.save(f, obj)

    assert np.all(obj == obj1)

# Generated at 2022-06-21 12:27:19.324249
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    Test of function work_in_progress
    """
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
        
    obj = load_file("/path/to/some/file")
    # Loading file... done. (3.52s)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    # Saving file... done. (3.78s)

# Generated at 2022-06-21 12:27:21.193459
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Unit Test"):
        time.sleep(1.0)

# Generated at 2022-06-21 12:27:28.652870
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    import sys
    from typing import Any, Callable

    old_stdout: Any = sys.stdout
    sys.stdout = io.StringIO()

    @work_in_progress("Loading file")
    def load_file(path: str) -> str:
        return "".join(open(path).readlines())

    def _do_assertion() -> None:
        assert sys.stdout.getvalue().startswith("Loading file... done. (")

    _do_assertion()
    g = (line for line in load_file(__file__))
    assert next(g).startswith("import functools")
    sys.stdout = old_stdout

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:27:33.773244
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    with work_in_progress("Cleaning up"):
        os.remove("test.txt")
    with work_in_progress():
        with open("test.txt", "w") as f:
            for i in range(100000):
                f.write(f"{i}\n")

# Generated at 2022-06-21 12:27:38.297065
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Initializing"):
        time.sleep(.5)
    with work_in_progress("Loading file"):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:27:44.893461
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    x = [1, 2, 3, 4, 5]
    with work_in_progress("Saving list"):
        with open("out.pkl", "wb") as f:
            pickle.dump(x, f)
    with work_in_progress("Loading list"):
        with open("out.pkl", "rb") as f:
            y = pickle.load(f)
    assert x == y

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:27:54.111316
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        time.sleep(0.1)
        return path

    with work_in_progress("Loading file") as manager:
        file_path = load_file("/path/to/file")
        assert file_path == "/path/to/file"
    print()

    obj = {'name': 'Foo', 'gender': 'male', 'age': 20}
    with work_in_progress("Saving file"):
        time.sleep(0.2)
    print()


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:28:00.954170
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:28:03.470688
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    dummy_desc = "Waiting for 5 seconds"
    with work_in_progress(dummy_desc):
        time.sleep(5)

# Generated at 2022-06-21 12:28:12.089506
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "r") as f:
            return f.read()

    @work_in_progress("Saving file")
    def save_file(path, content):
        with open(path, "w") as f:
            f.write(content)

    # Read file
    content = load_file(__file__)
    assert content

    # Write file
    save_file("work_in_progress.tmp.py", content)
    assert os.path.isfile("work_in_progress.tmp.py")

    # Clean up
    os.remove("work_in_progress.tmp.py")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:28:38.527195
# Unit test for function work_in_progress
def test_work_in_progress():
    def w(desc=""):
        with work_in_progress(desc=desc):
            time.sleep(1)

    w("A simple desc")
    w("A simple desc with time.sleep(1)")
    w("A desc with a long time.sleep(1)")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:28:43.024725
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Loading file"):
        obj = load_file("/path/to/some/file")
    assert obj == 24242


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:28:54.581412
# Unit test for function work_in_progress
def test_work_in_progress():
    data = {
            "a": 1,
            "b": [
                "abc",
                "def",
                "ghi",
            ],
            "c": {
                "jkl": [1, 2, 3, 4, 5],
                "mno": {
                    "pqr": {},
                    "stu": [],
                    "vwxyz": {}
                },
            },
        }

    # Test in a function
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    assert load_file("/tmp/foo.pickle") == data

    # Test in a code block

# Generated at 2022-06-21 12:29:05.350555
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test the contextmanager work_in_progress."""
    old_print = print
    output_string = ""
    def new_print(*args, **kwargs):
        nonlocal output_string
        old_print(*args, **kwargs)
        output_string += "".join(args)
    with patch("builtins.print", new_print):
        with work_in_progress("Testing work_in_progress"):
            time.sleep(0.1)
        assert "Testing work_in_progress... done. (0.10s)" in output_string
        output_string = ""
        @work_in_progress("Testing work_in_progress")
        def tmp_func(*args, **kwargs):
            time.sleep(1)
        tmp_func()

# Generated at 2022-06-21 12:29:10.947254
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    from contextlib import redirect_stdout

    f = io.StringIO()

    loading_file = ("Loading file... done. (3.52s)\n"
                    "Saving file... done. (3.78s)\n")
    with redirect_stdout(f):
        with work_in_progress("Loading file"):
            time.sleep(3.52)
        with work_in_progress("Saving file"):
            time.sleep(3.78)
    assert f.getvalue() == loading_file

# Generated at 2022-06-21 12:29:14.577901
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.5)

if __name__ == "__main__":
    import doctest
    doctest.testmod()
    test_work_in_progress()

# Generated at 2022-06-21 12:29:18.323213
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress(desc="Testing work_in_progress") as _:
        time.sleep(0.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:29:21.723730
# Unit test for function work_in_progress
def test_work_in_progress():
    def _mock_func():
        time.sleep(1)
    with work_in_progress():
        _mock_func()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:29:30.869786
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file, part 1"):
        with open("./test_file_01.pickle", "wb") as f:
            pickle.dump({"1": 1, "2": 2}, f)
    with work_in_progress("Saving file, part 2"):
        with open("./test_file_02.pickle", "wb") as f:
            pickle.dump({"3": 3, "4": 4}, f)
    with work_in_progress("Loading file"):
        obj = load_file("./test_file_01.pickle")
    with work_in_progress("Loading file"):
        obj = load_file

# Generated at 2022-06-21 12:29:37.502157
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:30:28.871079
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = 'C:\\Users\\13686\\Desktop\\kaggle01\\test.pickle'
    obj = load_file(path)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:30:40.057566
# Unit test for function work_in_progress
def test_work_in_progress():
    # pylint: disable=unused-variable,invalid-name
    @work_in_progress("Unit test for function work_in_progress")
    def test_func():
        pass
    # pylint: enable=unused-variable,invalid-name
    test_func()
    @work_in_progress("Unit test for function work_in_progress")
    def test_func2():
        time.sleep(0.1)
    test_func2()
    with work_in_progress("Unit test for function work_in_progress"):
        pass
    with work_in_progress("Unit test for function work_in_progress"):
        time.sleep(0.1)
    return True

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:30:44.185904
# Unit test for function work_in_progress
def test_work_in_progress():
    from pytest import raises
    with raises(SystemExit):
        with work_in_progress("Saving file"):
            raise SystemExit
    with raises(Exception):
        with work_in_progress("Saving file"):
            raise Exception

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:30:48.499507
# Unit test for function work_in_progress
def test_work_in_progress():
    def test_func():
        time.sleep(2)
    for i in range(10):
        with work_in_progress("Testing"):
            test_func()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:30:50.971136
# Unit test for function work_in_progress
def test_work_in_progress():
    def f():
        time.sleep(3.0)

    with work_in_progress("Testing work_in_progress"):
        f()


# Generated at 2022-06-21 12:30:56.147359
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert obj.shape == (28, 28, 3)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    assert os.path.exists(path)

# Generated at 2022-06-21 12:30:59.453684
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Counting to 100"

    with work_in_progress(desc):
        i = 1
        while i <= 100:
            i += 1


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:31:05.194689
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:31:11.794464
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with work_in_progress("Doing something totally useless"):
        time.sleep(1)
        print("This is something totally useless")
        time.sleep(2)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:31:18.576582
# Unit test for function work_in_progress
def test_work_in_progress():
    import random

    for _ in range(5):
        with work_in_progress("Doing something complicated"):
            time.sleep(random.uniform(0, 1))
        print("")

    for _ in range(5):
        @work_in_progress("Doing something very complicated")
        def do_something_complicated():
            time.sleep(random.uniform(0, 1))
        do_something_complicated()
        print("")

    @work_in_progress("Doing something very complicated", )
    def do_something_very_complicated():
        pass
    do_something_very_complicated()

if __name__ == "__main__":
    test_work_in_progress()