

# Generated at 2022-06-21 12:22:55.733352
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    with work_in_progress("Loading file"):
        obj = load_file("/path/to/some/file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    with work_in_progress("Saving file"):
        save_file("/path/to/some/file")


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:22:57.873700
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        # Do something
        time.sleep(0.01)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:23:05.054706
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = os.path.join(os.path.dirname(__file__),
                             "../data/embedding_word2vec.pickle")
    obj = load_file(path)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:08.884233
# Unit test for function work_in_progress
def test_work_in_progress():
    def test_func():
        time.sleep(3)
        return 4

    # Checks that the output of the function is correct
    with work_in_progress("Testing work_in_progress"):
        assert test_func() == 4

# Generated at 2022-06-21 12:23:11.997881
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("test_work_in_progress")
    def test_function():
        time.sleep(1.23)

    test_function()


# Generated at 2022-06-21 12:23:18.180580
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(3)
        with open(path, 'rb') as f:
            return pickle.load(f)

    obj = load_file('/path/to/some/file')

    with work_in_progress("Saving file"):
        time.sleep(3)
        with open('/path/to/some/file', 'wb') as f:
            pickle.dump(obj, f)


### Test ###
if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:23:20.609846
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Counting to 100000"):
        for i in range(100000):
            pass

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:26.851609
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(2)
    time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:35.909462
# Unit test for function work_in_progress
def test_work_in_progress():
    from pathlib import Path
    from fake.fake_object import FakeObject
    from fake.fake_object import assert_correct_fake_object

    fake_obj = FakeObject()
    path = Path('test_pickle.dat')

    # Pickle
    with work_in_progress('Pickling'):
        with path.open('wb') as f:
            pickle.dump(fake_obj, f)
    # Unpickle
    with work_in_progress('Unpickling'):
        with path.open('rb') as f:
            unpickled_obj = pickle.load(f)

    assert_correct_fake_object(unpickled_obj)

# Generated at 2022-06-21 12:23:44.139267
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import pickle

    try:
        os.remove("test")
    except OSError:
        pass
    with work_in_progress("Saving file"):
        with open("test", "wb") as f:
            pickle.dump(123, f)
    with work_in_progress("Loading file"):
        with open("test", "rb") as f:
            assert(pickle.load(f) == 123)
    os.remove("test")


if __name__ == '__main__':
    # Unit test
    test_work_in_progress()

# Generated at 2022-06-21 12:23:51.342450
# Unit test for function work_in_progress
def test_work_in_progress():
    import doctest
    doctest.testmod(verbose=True, optionflags=doctest.ELLIPSIS)

if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=True, optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-21 12:23:59.908621
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    import pickle
    from contextlib import redirect_stdout
    from tempfile import NamedTemporaryFile

    # Define a dummy function
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # Capture all text printed to stdout
    f = io.StringIO()
    with redirect_stdout(f):
        # Save and load an object
        with NamedTemporaryFile() as fp:
            with open(fp.name, "wb") as f:
                pickle.dump(["a", "b", "c"], f)
            load_file(fp.name)

    # Check the printout

# Generated at 2022-06-21 12:24:04.519885
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Running unit tests"):
        time.sleep(1)
        with work_in_progress("Testing contextlib"):
            time.sleep(1)
            with work_in_progress("Testing function work_in_progress"):
                time.sleep(1)
        with work_in_progress("Testing os"):
            time.sleep(1)
    print("All unit tests were run successfully!")

# --------------------------------------------------------------------

if __name__ == "__main__":
    pi = 3.141592653589793238462643
    with work_in_progress("Calculating Pi"):
        for i in range(10000000):
            pi += i
    print(pi)

    test_work_in_progress()

# Generated at 2022-06-21 12:24:09.773368
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:24:20.255710
# Unit test for function work_in_progress
def test_work_in_progress():
    def _load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def _save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    @work_in_progress("Loading file")
    def _load_file_with_progress(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        _save_file("_test_work_in_progress.pkl", "test string")

    obj1 = _load_file("_test_work_in_progress.pkl")

# Generated at 2022-06-21 12:24:22.433677
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing")
    def _():
        time.sleep(0.5)
    _()

# Generated at 2022-06-21 12:24:27.265339
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    from contextlib import contextmanager
    from io import StringIO
    import sys
    import time

    # Decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # Context manager
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    # Fake stdout
    @contextmanager
    def fake_stdout():
        f = StringIO()
        real_stdout = sys.stdout
        sys.stdout = f
        try:
            yield f
        finally:
            sys.stdout = real_stdout


# Generated at 2022-06-21 12:24:31.136111
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test")
    def fun():
        time.sleep(1)

    fun()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:24:37.976802
# Unit test for function work_in_progress
def test_work_in_progress():
    def _load_file(path):
        with open(path, "rb") as f:
            time.sleep(1)
            return pickle.load(f)

    with work_in_progress("Loading file"):
        obj1 = _load_file("/tmp/obj1")
        obj2 = _load_file("/tmp/obj2")

    with work_in_progress("Saving file"):
        with open("/tmp/test_dump.pkl", "wb") as f:
            pickle.dump(obj1, f)
            pickle.dump(obj2, f)

# Generated at 2022-06-21 12:24:40.385223
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing..."):
        time.sleep(1)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:24:48.956990
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test function work_in_progress."""
    with work_in_progress("Test"):
        time.sleep(0.5)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:24:50.851818
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1)

# Generated at 2022-06-21 12:24:53.739720
# Unit test for function work_in_progress
def test_work_in_progress():
    def f():
        with work_in_progress("Long duration task"):
            time.sleep(2)

    f()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:25:02.800074
# Unit test for function work_in_progress
def test_work_in_progress():
    from .test_util import random_string

    print("Test work_in_progress...")

    @work_in_progress("Loading file")
    def load_file(path: str):
        with open(path, "r") as f:
            time.sleep(1)
            return f.read()

    content = random_string()
    with open("test_work_in_progress.txt", "w") as f:
        f.write(content)

    assert load_file("test_work_in_progress.txt") == content

    with work_in_progress("Saving file"):
        with open("test_work_in_progress_2.txt", "w") as f:
            time.sleep(1)
            f.write(random_string())

    print("Test work_in_progress... Done!")



# Generated at 2022-06-21 12:25:05.180207
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(0.21)
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.21)

# Generated at 2022-06-21 12:25:13.825340
# Unit test for function work_in_progress
def test_work_in_progress():
    def function():
        print("")
        time.sleep(0.3)
        print("")
    
    # Test the context manager
    with work_in_progress("Testing work_in_progress"):
        function()
    # Test the decorator
    @work_in_progress("Testing work_in_progress decorator")
    def function_decorator():
        print("")
        time.sleep(0.3)
        print("")
    function_decorator()

# Unit test
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:25:17.317065
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing file"):
        time.sleep(2)

# Run unit test for work_in_progress
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:25:25.495249
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile
    import os

    time_consumed = None

    @work_in_progress("Loading file")
    def load_file(path):
        nonlocal time_consumed
        with open(path, "rb") as f:
            data = pickle.load(f)
            time_consumed = time.time() - begin_time
            return data

    with tempfile.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, "data")
        with open(path, "wb") as f:
            pickle.dump(None, f)

        begin_time = time.time()
        obj = load_file(path)
        assert obj is None
        assert time.time() - begin_time - time_consumed < 10.0



# Generated at 2022-06-21 12:25:30.486392
# Unit test for function work_in_progress
def test_work_in_progress():
    print(f"Running test for {os.path.basename(__file__)}", flush=True)
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:25:33.611044
# Unit test for function work_in_progress
def test_work_in_progress():
    for i in range(10):
        desc = "Processing file " + str(i)
        with work_in_progress(desc):
            time.sleep(0.1)

# Generated at 2022-06-21 12:25:51.911137
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    def load_file(path):
        @work_in_progress("Loading file")
        def _load_file():
            with open(path, "rb") as f:
                return pickle.load(f)
        return _load_file()

    obj = load_file("fixtures/face_detection.pickle")

    with work_in_progress("Saving file"):
        with open("fixtures/face_detection_copy.pickle", "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:25:53.559548
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("A very long task"):
        time.sleep(0.1)

# Generated at 2022-06-21 12:26:03.869777
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import os

    # Creating a dummy file
    path = 'temp.txt'
    with open(path, 'w') as f:
        f.write("test")

    # Testing function work_in_progress
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, 'rb') as f:
            time.sleep(3)
            return f.read()

    # Calling the function
    obj = load_file(path)
    assert obj == b'test'

    # Deleting the file
    os.remove(path)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:11.312778
# Unit test for function work_in_progress
def test_work_in_progress():
    def _load_file(path):
        with open(path, "rb") as f:
            time.sleep(1)
            return pickle.load(f)

    with tempfile.TemporaryDirectory() as tmp_dir:
        path = os.path.join(tmp_dir, "file.pkl")
        with open(path, "wb") as f:
            pickle.dump("object", f)

        assert _load_file(path) == "object"

        with work_in_progress("Loading file"):
            obj = _load_file(path)

        obj = _load_file(path)
        assert obj == "object"
        with work_in_progress("Loading file"):
            obj = _load_file(path)

        assert obj == "object"



# Generated at 2022-06-21 12:26:18.049234
# Unit test for function work_in_progress
def test_work_in_progress():
    import copy

    def _function():
        with work_in_progress("Subfunction"):
            time.sleep(.5)

    @work_in_progress("Function")
    def function():
        time.sleep(.5)
        _function()

    @work_in_progress("Doing something")
    def do_something():
        time.sleep(.5)

    with work_in_progress("Doing something else"):
        time.sleep(.5)
    do_something()
    function()

# Generated at 2022-06-21 12:26:20.792712
# Unit test for function work_in_progress
def test_work_in_progress():
    begin_time = time.time()
    with work_in_progress("Long task"):
        while time.time() - begin_time <= 1:
            pass
    assert True

# Generated at 2022-06-21 12:26:25.085994
# Unit test for function work_in_progress
def test_work_in_progress():
    print("The following is the output of work_in_progress...")
    @work_in_progress("Testing work_in_progress")
    def test():
        time.sleep(3.14)
    test()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:37.122730
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
            time.sleep(1)

    @contextlib.contextmanager
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
            time.sleep(1)

    data = {
        "a": 1,
        "b": "2",
        "c": [2, 3, 4],
        "d": [0.1, 0.2, 0.3],
    }

    file_path = "__tempfile__.pkl"
    with work_in_progress("Saving file"):
        with save_file(file_path):
            pass

    obj

# Generated at 2022-06-21 12:26:41.722061
# Unit test for function work_in_progress
def test_work_in_progress():
    def function_based_example(path):
        with work_in_progress("Loading file"):
            with open(path, "rb") as f:
                return pickle.load(f)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    assert True

# Generated at 2022-06-21 12:26:45.012106
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.01)
    with work_in_progress("Saving file"):
        time.sleep(0.01)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:27:08.947638
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def foo():
        for i in range(1000000):
            i ** 2
    foo()
    foo()
    foo()

# Generated at 2022-06-21 12:27:17.151929
# Unit test for function work_in_progress
def test_work_in_progress():
    obj = None
    @work_in_progress("Loading file")
    def load_file(path):
        nonlocal obj
        with open(path, "rb") as f:
            obj = pickle.load(f)
    @work_in_progress("Saving file")
    def save_file(path):
        nonlocal obj
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    with tempfile.NamedTemporaryFile() as f:
        load_file(f.name)
        save_file(f.name)

# Generated at 2022-06-21 12:27:21.631224
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    with work_in_progress("Copying file"):
        os.system("cp test_work_in_progress.py test_work_in_progress.py.backup")


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:27:25.817453
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
        obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:27:35.933882
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert obj is not None
    time.sleep(random.randrange(3, 5))

    with work_in_progress("Saving file"):
        with open("/tmp/some/file", "wb") as f:
            pickle.dump(obj, f)
        time.sleep(random.randrange(2, 3))


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:27:42.416344
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing function work_in_progress...", end="", flush=True)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    print(" done")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:27:52.006528
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert obj == "test"
    print()

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)
    print()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:27:57.081493
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing")
    def inner_test():
        time.sleep(0.05)

    inner_test()

    with work_in_progress("Testing"):
        time.sleep(0.05)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:28:08.570574
# Unit test for function work_in_progress
def test_work_in_progress():
    from os.path import join
    from tempfile import mkdtemp
    from shutil import rmtree
    from fnmatch import fnmatch
    from pickle import dump, load

    tempdir = mkdtemp()

# Generated at 2022-06-21 12:28:12.389711
# Unit test for function work_in_progress
def test_work_in_progress():
    code = r"""
    >>> @work_in_progress("Loading file")
    ... def load_file(path):
    ...     with open(path, "rb") as f:
    ...         return pickle.load(f)
    ...
    ... obj = load_file("/path/to/some/file")

    >>> with work_in_progress("Saving file"):
    ...     with open(path, "wb") as f:
    ...         pickle.dump(obj, f)
    """
    exec(dedent(code))

# Generated at 2022-06-21 12:29:00.404713
# Unit test for function work_in_progress
def test_work_in_progress():
    from contextlib import redirect_stdout
    with redirect_stdout(sys.stdout):
        with work_in_progress("Sleep for 5 seconds"):
            time.sleep(5)
    with redirect_stdout(sys.stdout):
        @work_in_progress("Sleep for 3 seconds")
        def work():
            time.sleep(3)
        work()

# Generated at 2022-06-21 12:29:10.101928
# Unit test for function work_in_progress
def test_work_in_progress():
    from contextlib import suppress
    with suppress(Exception):
        import os
        import tempfile
        def load_file(path):
            with open(path, "rb") as f:
                return pickle.loads(f.read())

        def save_file(path, obj):
            with open(path, "wb") as f:
                f.write(pickle.dumps(obj))

        with tempfile.TemporaryDirectory() as tmp:
            obj = list(range(10000000))
            with work_in_progress("Loading file"):
                obj1 = load_file(tmp + "/file1")

            with work_in_progress("Saving file"):
                save_file(tmp + "/file1", obj)


# Generated at 2022-06-21 12:29:11.847864
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test")
    def test():
        time.sleep(1)
    test()

# Generated at 2022-06-21 12:29:22.716396
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import sys
    import time

    if sys.version_info >= (3, 7, 0):

        # Test with context manager
        with work_in_progress("Generating random numbers"):
            time.sleep(random.randint(0, 3) / 10)

        # Test with a function
        @work_in_progress("Sorting integers")
        def sort_ints(data):
            return sorted(data)
        sort_ints([random.randint(0, 100) for _ in range(1, 100)])

        # Test that an Exception is raised as usual
        with pytest.raises(TypeError):
            @work_in_progress("Sorting integers")
            def sort_ints(data):
                return sorted("TEST")
            sort_ints("test")


# Generated at 2022-06-21 12:29:27.809511
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:29:32.737603
# Unit test for function work_in_progress
def test_work_in_progress():
    begin_time = time.time()

    @work_in_progress("Test function 1")
    def test_function1(time_to_sleep):
        time.sleep(time_to_sleep)

    @work_in_progress("Test function 2")
    def test_function2(time_to_sleep):
        time.sleep(time_to_sleep)

    test_function1(0.5)
    test_function2(0.6)

    assert (time.time() - begin_time) > 1

    with work_in_progress("Test work in progress") as wi:
        time.sleep(0.7)
        assert (time.time() - begin_time) > 1
        wi.send("Done!")
        time.sleep(0.8)

# Generated at 2022-06-21 12:29:43.331869
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test for the function :func:`work_in_progress`.

    .. code:: python

        >>> test_work_in_progress()
        Loading file... done. (0.00s)
        Saving file... done. (0.00s)
    """

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open("test_work_in_progress.tmp", "wb") as f:
            pickle.dump("test", f)
    os.remove("test_work_in_progress.tmp")


if __name__ == "__main__":
    import doctest
    doctest.testmod()
    test_work

# Generated at 2022-06-21 12:29:45.171708
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        a = 1
        time.sleep(2)
    print("OK")

# Generated at 2022-06-21 12:29:51.624456
# Unit test for function work_in_progress
def test_work_in_progress():  # pragma: no cover
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:29:56.333232
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "r") as f:
            return f.read()

    obj = load_file(__file__)

    with work_in_progress("Saving file"):
        with open("tmp.txt", "w") as f:
            f.write(obj)

    os.remove("tmp.txt")

# Generated at 2022-06-21 12:31:33.387454
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test work_in_progress 1")
    def test1():
        time.sleep(1)
    test1()

    @work_in_progress("Test work_in_progress 2")
    def test2():
        time.sleep(2)
    test2()

    with work_in_progress("Test work_in_progress 3"):
        time.sleep(3)

# Some examples

# Generated at 2022-06-21 12:31:39.733695
# Unit test for function work_in_progress
def test_work_in_progress():
    import pytest
    switcher = {
        0: "Loading file",
        1: "Saving file",
        2: "Computing 3 things at once",
    }
    with pytest.raises(KeyError):
        work_in_progress(switcher[4])

    for key in range(len(switcher)):
        with work_in_progress(switcher[key]):
            time.sleep(0.3)


if __name__ == "__main__":

    import sys

    try:
        module = sys.argv[1]
    except IndexError:
        print(f"Usage: python {__file__} <function or module>")
    else:
        if module in globals():
            globals()[module]()
        else:
            import importlib


# Generated at 2022-06-21 12:31:43.387490
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/Users/yuanj/Desktop/test.txt")

# Generated at 2022-06-21 12:31:47.232780
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test work_in_progress")
    def work_in_progress_test():
        for i in range(10000000):
            pass
    work_in_progress_test()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:31:56.112115
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    PATH = "/tmp/t.pkl"

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # Write the pickled object into the file
    with open(PATH, "wb") as f:
        pickle.dump(None, f)

    # Load the file and print the loading time
    ret = load_file(PATH)
    print(repr(ret))

if __name__ == "__main__":
    _test()

# Generated at 2022-06-21 12:32:04.317574
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")
    save_file("/path/to/some/file", obj)


# Generated at 2022-06-21 12:32:09.200649
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Task 1"):
        time.sleep(0.2)
    with work_in_progress("Task 2"):
        time.sleep(0.7)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:32:19.750863
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = {"a": 1, "b": [1, 2, 3]}

    with work_in_progress("Test saving/loading data"):
        time.sleep(1)
        save_file(obj, "tmp.pkl")
        time.sleep(1)
        loaded_obj = load_file("tmp.pkl")
        assert loaded_obj == obj

    print("\nAll tests passed!")

# Generated at 2022-06-21 12:32:24.784508
# Unit test for function work_in_progress
def test_work_in_progress():
    def f1(i: int) -> int:
        time.sleep(0.05)
        return i**2

    def f2(i: int) -> int:
        with work_in_progress(desc=f"f2({i})"):
            time.sleep(0.05)
        return i**2

    assert f1(5) == f2(5)


if __name__ == "__main__":
    # Unit test
    test_work_in_progress()

# Generated at 2022-06-21 12:32:29.046715
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test function work_in_progress."""
    def foo():
        time.sleep(1.23)
        return 1
    f = work_in_progress("Test progress")(foo)
    assert f() == 1


if __name__ == '__main__':
    import doctest
    doctest.testmod()