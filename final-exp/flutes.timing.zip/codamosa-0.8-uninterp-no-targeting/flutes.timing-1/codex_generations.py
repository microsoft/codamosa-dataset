

# Generated at 2022-06-21 12:22:51.932757
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    with work_in_progress("This is a test"):
        time.sleep(random.random())


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:22:58.489633
# Unit test for function work_in_progress
def test_work_in_progress():
    from common.testing import UnitTestCase
    from unittest.mock import patch

    class TestCase(UnitTestCase):
        def test(self):
            with patch.object(sys.stdout, "write") as mock_stdout:
                with work_in_progress("test"):
                    time.sleep(0.1)
                mock_stdout.assert_any_call("test... ")
                mock_stdout.assert_any_call("done. (0.10s)\n")

    TestCase().run_test()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:06.172917
# Unit test for function work_in_progress
def test_work_in_progress():
    def too_long(duration: int):
        time.sleep(duration)

    def try_catch_work_in_progress():
        try:
            with work_in_progress("Sleeping"):
                too_long(0.5)
        except:
            print("Failed to finish")
        else:
            print("Slept")

    try_catch_work_in_progress()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:12.552956
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test 1")
    def test_1():
        time.sleep(1)
    test_1()
    with work_in_progress("Test 2"):
        time.sleep(1)
    with work_in_progress():
        time.sleep(1)

# Test
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:14.959419
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Adding"):
        time.sleep(random.random())

# Generated at 2022-06-21 12:23:23.813422
# Unit test for function work_in_progress
def test_work_in_progress():
    from .test_util import check_outputs
    with check_outputs(
        'work_in_progress: Loading file... done. (0.10s)\n'
    ):
        @work_in_progress("Loading file")
        def load_file(path):
            time.sleep(0.1)
            return path
        obj = load_file("/path/to/some/file")
    with check_outputs(
        'work_in_progress: Saving file... done. (0.01s)\n'
    ):
        with work_in_progress("Saving file"):
            time.sleep(0.01)
    # No new-line after the last work

# Generated at 2022-06-21 12:23:27.265654
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Work in progress"):
        time.sleep(0.3)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:30.945765
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    N = 5
    with work_in_progress("Waiting for a while"):
        time.sleep(N)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:36.478397
# Unit test for function work_in_progress
def test_work_in_progress():
    def square(x: int) -> int:
        time.sleep(x)
        return x ** 2

    # Inner function
    @work_in_progress("Squaring number")
    def square2(x: int) -> int:
        time.sleep(x)
        return x ** 2

    assert square(3) == square2(3)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:23:40.507056
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")



# Generated at 2022-06-21 12:23:54.948286
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test of function work_in_progress."""

    class A(object):
        def __init__(self, name: str, delay: float = 0.1, multiplier: float = 1.0):
            self.name = name
            self.delay = delay
            self.multiplier = multiplier

        def __str__(self):
            return self.name

        def __eq__(self, other):
            return isinstance(other, A) and self.name == other.name

        def __hash__(self):
            return hash(self.name)

    def do_work(name: str) -> A:
        time.sleep(0.1)
        return A(name)

    def heavy_work(name: str) -> A:
        time.sleep(1)

# Generated at 2022-06-21 12:23:59.237428
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(.5)
        print("content")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:24:02.387263
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Working hard") as t:
        time.sleep(1.23)
    print(f"Time consumed: {t.time_consumed}")
    assert t.time_consumed == 1.23

# Generated at 2022-06-21 12:24:06.608446
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Working")
    def some_work():
        time.sleep(1)

    with work_in_progress("Working"):
        time.sleep(1)

    some_work()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:24:13.023359
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function :func:`work_in_progress`"""

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:24:20.135559
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Load file")
    def foo(path):
        time.sleep(random.random())
        with open(path, "r") as f:
            return f.read()

    with work_in_progress("Save file"):
        time.sleep(random.random())
        with open("/tmp/foo.txt", "w") as f:
            f.write("foo")

    foo("/tmp/foo.txt")
# End of unit test for function work_in_progress

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:24:23.182921
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test context manager")
    def f():
        time.sleep(1)

    f()


# Generated at 2022-06-21 12:24:28.180739
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress(desc="Importing numpy"):
        import numpy as np
    with work_in_progress(desc="Importing scipy"):
        import scipy
    with work_in_progress(desc="Importing cvxpy"):
        import cvxpy


# Pipe operator

# Generated at 2022-06-21 12:24:29.954687
# Unit test for function work_in_progress
def test_work_in_progress():
    """ Unit test for function work_in_progress"""
    @work_in_progress("fake work")
    def fake_work():
        """fake work to simulate the actual work"""
        time.sleep(0.001)
    fake_work()

# Generated at 2022-06-21 12:24:33.152312
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("test"):
        time.sleep(5)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:24:47.745904
# Unit test for function work_in_progress
def test_work_in_progress():
    # With function decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return f.read()
    print(load_file("__init__.py")[:20])

    # With context manager
    with work_in_progress("Saving file"):
        with open("__init__.py", "rb") as f:
            obj = f.read()

    # Without context manager
    with work_in_progress("Loading file"):
        with open("__init__.py", "rb") as f:
            obj = f.read()
    with work_in_progress("Saving file"):
        with open("./work_in_progress.tmp", "wb") as f:
            f.write(obj)



# Generated at 2022-06-21 12:24:58.220231
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    
    # Create some obj to be saved to file
    obj = "The quick brown fox jumped over the lazy dog." * 100000
    save_file("tmp.pickle", obj)

    # Loading the file
    loaded_obj = load_file("tmp.pickle")

    # Ensure that the object returned by load_file() is the same object
    # that was passed to save_file()
    assert obj == loaded

# Generated at 2022-06-21 12:25:00.511526
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("The task description")
    def task():
        time.sleep(0.5)
    assert task.__name__ == "task"
    task()


# Generated at 2022-06-21 12:25:05.307924
# Unit test for function work_in_progress
def test_work_in_progress():
    def slow_func(n):
        for i in range(n):
            time.sleep(0.01)

    with work_in_progress("Executing slow_func"):
        slow_func(100)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:25:11.907066
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(1)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    load_file("/path/to/some/file")


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:25:21.758542
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import time

    # Test work_in_progress with a dummy function
    def f():
        time.sleep(0.1)

    with work_in_progress("Loading dummy"):
        f()

    # Test work_in_progress with a dummy function
    def g():
        time.sleep(0.1)

    g = work_in_progress("Loading dummy")(g)
    g()

    # Test work_in_progress on a file loading procedure
    obj = [1, 2, 3]
    with tempfile.NamedTemporaryFile() as f:
        # Dump
        with work_in_progress("Saving file") as w:
            begin_time = time.time()
            pickle.dump(obj, f)
            time.consumed = time.time() - begin_time


# Generated at 2022-06-21 12:25:27.529289
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    save_file("/path/to/a/file", obj)

# Generated at 2022-06-21 12:25:31.500267
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Testing function work_in_progress"

    with work_in_progress(desc) as timer_utility:
        time.sleep(2)
    pass

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:25:32.880245
# Unit test for function work_in_progress
def test_work_in_progress():
    pass


# Generated at 2022-06-21 12:25:36.203069
# Unit test for function work_in_progress
def test_work_in_progress():
    from pytest import raises
    @work_in_progress("Testing work_in_progress")
    def func(arg):
        return arg

    res = func(1)
    assert res == 1

# Generated at 2022-06-21 12:25:45.950681
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress."""
    # First test: decorator
    @work_in_progress("Loading file")
    def load_file(path: str) -> bytes:
        """Load a file.

        :param path: Path of the file to load.
        :returns: Loaded bytes.
        """
        with open(path, "rb") as file:
            return file.read()

    # Second test: context manager
    with work_in_progress("Saving file"):
        with open("tmp/test_work_in_progress.txt", "w") as file:
            file.write("I am a simple file.")

    # Clean the mess
    os.remove("tmp/test_work_in_progress.txt")

# Generated at 2022-06-21 12:25:50.137631
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    Unit test for function work_in_progress

    1. Assert that the time consumed by sleep(1.5) with @work_in_progress
       is >= 1.5
    """
    with work_in_progress("Test Work in Progress"):
        time.sleep(1.5)

# Generated at 2022-06-21 12:25:57.199597
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    from contextlib import redirect_stdout

    with tempfile.TemporaryDirectory() as tempdir:
        with open(tempdir + "/test.txt", "w") as f:
            with redirect_stdout(f):
                @work_in_progress("Foo bar")
                def foo(n):
                    for i in range(n):
                        time.sleep(0.1)

                foo(10)

                with work_in_progress("Baz quux"):
                    for i in range(10):
                        time.sleep(0.1)

        with open(tempdir + "/test.txt", "r") as f:
            assert f.read() == "Foo bar... done. (1.00s)\n" \
                               "Baz quux... done. (1.00s)\n"


# Generated at 2022-06-21 12:26:06.762367
# Unit test for function work_in_progress
def test_work_in_progress():
    import random

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/tmp/file.pkl")
    save_file("/tmp/file.pkl", obj)
    time.sleep(random.random())

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:26:11.321836
# Unit test for function work_in_progress
def test_work_in_progress():
    time0 = time.time()
    with work_in_progress("Work in progress"):
        time.sleep(5)
    time1 = time.time()
    assert time1 - time0 >= 5

# Generated at 2022-06-21 12:26:16.999887
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import os
    obj = {
        "a": 1,
        "b": 2
    }

    path = os.path.expanduser("~/.work_in_progress-test.pickle")
    if os.path.exists(path):
        os.remove(path)

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    save_file(path)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    assert obj == load_file(path)
    os.remove(path)



# Generated at 2022-06-21 12:26:17.994877
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1.23)
    assert True

# Generated at 2022-06-21 12:26:29.520962
# Unit test for function work_in_progress
def test_work_in_progress():
    import sys
    import os
    import pickle
    import tempfile
    obj = dict(x=1, y=2.5, z="Hello World!")
    stdout = sys.stdout
    sys.stdout = open(os.devnull, "w")
    dummy_file = tempfile.NamedTemporaryFile("w+t", delete=False)
    dummy_file.close()

    # the stdout is redirected to /dev/null, we don't care what will be printed,
    # we just want to check the execution time and if the output is correct
    with work_in_progress("Testing work_in_progress function..."):
        time.sleep(1.1)


# Generated at 2022-06-21 12:26:36.791341
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    obj = load_file("/etc/lsb-release")
    save_file("/tmp/lsb-release-test", obj)

# Generated at 2022-06-21 12:26:42.513705
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:27:01.939762
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import tempfile
    with tempfile.TemporaryDirectory() as dirpath:
        filepath = dirpath + "/test.pickle"
        obj = [1, 2, 3, 4]
        with work_in_progress("Saving file"):
            with open(filepath, "wb") as f:
                time.sleep(1)
                pickle.dump(obj, f)
        with work_in_progress("Loading file"):
            with open(filepath, "rb") as f:
                time.sleep(2)
                assert pickle.load(f) == obj
        print("Function work_in_progress passed unit test")


# Generated at 2022-06-21 12:27:04.495849
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Doing nothing"):
        pass

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:27:06.068210
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(2)

# Generated at 2022-06-21 12:27:08.067769
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test function")
    def test_function():
        time.sleep(1)
    test_function()

# Generated at 2022-06-21 12:27:09.706868
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing function"):
        time.sleep(0.5)



# Generated at 2022-06-21 12:27:14.874538
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    print(load_file(__file__))

    with work_in_progress("Saving file"):
        with open(__file__, "wb") as f:
            pickle.dump(__file__, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:27:21.981779
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Run time out of context."""
    def _work_in_progress(desc: str):
        print(f"{desc}... ", end='', flush=True)
        work_in_progress(desc)

    _work_in_progress("Test")

if __name__ == "__main__":
    # Test routines
    with work_in_progress("Testing work_in_progress"):
        test_work_in_progress()

# Generated at 2022-06-21 12:27:24.289796
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing"):
        print(f"Testing Elapsed time")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:27:25.421297
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress():
        time.sleep(3)

# Generated at 2022-06-21 12:27:29.571638
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(3.518)
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert obj == 42
    del obj

    with work_in_progress("Saving file"):
        time.sleep(3.781)
        with open(path, "wb") as f:
            pickle.dump(42, f)
    assert True

# Generated at 2022-06-21 12:27:54.654666
# Unit test for function work_in_progress
def test_work_in_progress():
    path = "/tmp/test.txt"
    try:
        with open(path, "w") as f:
            f.write("Some content")
        with work_in_progress("Loading file"):
            with open(path, "r") as f:
                content = f.read()
        assert content == "Some content"
        with work_in_progress("Saving file"):
            with open(path, "w") as f:
                f.write("Some other content")
        with open(path, "r") as f:
            content = f.read()
        assert content == "Some other content"
    finally:
        os.remove(path)



# Generated at 2022-06-21 12:28:06.575442
# Unit test for function work_in_progress
def test_work_in_progress():
    begin_time = time.time()
    time_consumed_1 = 0
    time_consumed_2 = 0
    time_consumed_3 = 0

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    time_consumed_1 = time.time() - begin_time
    time.sleep(1.234)
    time_consumed_2 = time.time() - begin_time
    time.sleep(2.345)
    time_consumed_3 = time.time() - begin_time

# Generated at 2022-06-21 12:28:11.476852
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/dev/null")


# Generated at 2022-06-21 12:28:20.196541
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import os
    with work_in_progress():
        time.sleep(1)
    with work_in_progress("Test"):
        time.sleep(2)
    with work_in_progress("Test", end=" "):
        time.sleep(3)
    @work_in_progress(desc="Test + func")
    def test_func():
        time.sleep(1)
    test_func()
    @work_in_progress(desc="Test + func ./ nested")
    def test_nested_func():
        time.sleep(1)
        test_func()
        time.sleep(1)
    test_nested_func()
    path = "test_work_in_progress.pickle"

# Generated at 2022-06-21 12:28:22.052090
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        pass
    assert True

# Generated at 2022-06-21 12:28:29.691429
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(0.01)
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("__init__.py")
    assert obj is not None

    with work_in_progress("Saving file"):
        time.sleep(0.01)
        with open("__init__.py", "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:28:31.988223
# Unit test for function work_in_progress
def test_work_in_progress():
    a = "Hello World"
    with work_in_progress("Example"):
        time.sleep(1)

# test_work_in_progress()

# Generated at 2022-06-21 12:28:43.024864
# Unit test for function work_in_progress
def test_work_in_progress():
    import pytest
    from contextlib import redirect_stdout

    class MockClock:
        def __init__(self, time=0, step=1):
            self.time = time
            self.step = step

        def __enter__(self):
            self.old_time = time.time
            time.time = lambda: self.time
            return self

        def __exit__(self, *args):
            time.time = self.old_time

        def tick(self):
            self.time += self.step


    def get_output(f):
        with io.StringIO() as buffer, redirect_stdout(buffer):
            f()
            return buffer.getvalue()


    @work_in_progress("test1")
    def test_func_1():
        time.sleep(1)

    test_

# Generated at 2022-06-21 12:28:51.177383
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test function work_in_progress."""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    assert load_file("/path/to/some/file")

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    assert save_file("/path/to/some/file", obj)

# Generated at 2022-06-21 12:28:59.591260
# Unit test for function work_in_progress
def test_work_in_progress():
    from pathlib import Path
    assert Path("/tmp/test_file.pickle").exists() == False
    with work_in_progress("Loading file"):
        with open("/tmp/test_file.pickle", "wb") as f:
            pickle.dump(np.random.uniform(size=(1000,1000)), f)
        with open("/tmp/test_file.pickle", "rb") as f:
            pickle.load(f)
    assert Path("/tmp/test_file.pickle").exists() == True
    Path("/tmp/test_file.pickle").unlink()

# Generated at 2022-06-21 12:29:47.174688
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "sample description"
    with work_in_progress(desc) as w:
        time.sleep(1)
    assert True

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-21 12:29:53.721732
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert obj == 4

    context_manager = work_in_progress("Saving file")
    with context_manager:
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:29:54.289695
# Unit test for function work_in_progress
def test_work_in_progress():
    assert True

# Generated at 2022-06-21 12:29:56.782615
# Unit test for function work_in_progress
def test_work_in_progress():
    def fake(time_to_sleep: float):
        time.sleep(time_to_sleep)

    with work_in_progress("Loading file"):
        fake(3.52)
    fake(3.78)

# Generated at 2022-06-21 12:30:02.684929
# Unit test for function work_in_progress
def test_work_in_progress():
    import subprocess

    script = (f"import sys; "
              f"import {__name__}; "
              f"with {__name__}.work_in_progress(sys.argv[1]): "
               "    print('message in code block')")

    expected_output = "message in code block\n"
    output = subprocess.check_output(f"python3 -c '{script}' 'Hello'", shell=True).decode()
    assert expected_output in output

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:30:09.361596
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    
    obj = load_file("/path/to/some/file")
    assert True
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    assert True

# Generated at 2022-06-21 12:30:13.580023
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test case for :func:`work_in_progress`.
    """
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "data/test.pkl"
    obj = load_file(path)
    with open(path, "rb") as f:
        assert obj == pickle.load(f)

    with work_in_progress("Writing file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    with open(path, "rb") as f:
        assert obj == pickle.load(f)

# Generated at 2022-06-21 12:30:21.600532
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    import sys
    from contextlib import redirect_stdout

    @work_in_progress("Saving file")
    def save_file():
        for i in range(100000):
            i += i
        time.sleep(1)

    f = io.StringIO()
    with redirect_stdout(f):
        save_file()
    output = f.getvalue()
    assert output == "Saving file... done. (1.00s)\n"

# Generated at 2022-06-21 12:30:28.805381
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:30:33.777268
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work in progress")
    def get_square(n):
        time.sleep(1)
        return n ** 2

    assert get_square(2) == 4
    assert get_square(3) == 9

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:32:10.655363
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def test_function():
        for _ in range(10 ** 7):
            pass

    assert test_function

# Generated at 2022-06-21 12:32:19.318626
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test the function work_in_progress.

    .. code:: python
        test_work_in_progress(5)
    """
    def sleep(interval):
        time.sleep(interval)

    @work_in_progress("Some work")
    def work():
        time.sleep(random.randint(0, 5))

    print("Test the function work_in_progress.")
    print("Execute the function sleep(3).")
    sleep(3)
    print("Execute the function work().")
    work()

if __name__ == "__main__":
    # test_work_in_progress(5)
    pass

# Generated at 2022-06-21 12:32:20.877033
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)



# Generated at 2022-06-21 12:32:25.845862
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing work_in_progress...")
    desc = "Testing work_in_progress"
    begin_time = time.time()
    time.sleep(0.1)
    time_consumed = time.time() - begin_time
    print(f"{desc}... done. ({time_consumed:.2f}s)")


# Generated at 2022-06-21 12:32:26.784470
# Unit test for function work_in_progress
def test_work_in_progress():
    def foo():
        time.sleep(1)

    with work_in_progress("Fooing"):
        foo()
    print("Fooing done.")

# Generated at 2022-06-21 12:32:28.419478
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(0.1)

# Generated at 2022-06-21 12:32:32.347814
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress") as timer:
        time.sleep(2)
    assert timer.completed


if __name__ == "__manin__":
    test_work_in_progress()

# Generated at 2022-06-21 12:32:34.103176
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test") as w:
        print("foo")
        time.sleep(1)

# Generated at 2022-06-21 12:32:38.109222
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Fetching data")
    def fetch(url: str, timeout: float) -> Iterator[str]:
        for _ in range(randint(10, 20)):
            yield url
        time.sleep(timeout)

    for url in fetch("http://example.com/", timeout=0.5):
        print(url)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:32:48.795838
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    import sys
    import pickle
    import tempfile

    temp_file = tempfile.NamedTemporaryFile(mode="wb", delete=False)
    temp_file.write(b'\x80\x03X\x0b\x00\x00\x00abcdefghijq\x86q\x87.')
    temp_file.close()

    # First test
    obj = []
    with work_in_progress("Loading file"):
        with open(temp_file.name, "rb") as f:
            obj = pickle.load(f)

    assert obj == list("abcdefghij")

    # Second test
    obj = list("abcdefghij")
    stdout_bak = sys.stdout