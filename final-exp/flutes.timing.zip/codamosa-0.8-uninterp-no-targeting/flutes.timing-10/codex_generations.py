

# Generated at 2022-06-21 12:22:57.971487
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import pickle

    with tempfile.TemporaryDirectory() as tmp_dir:
        data = {
            "hello": "world",
            "pi": 3.14,
        }

        with work_in_progress("Saving file"):
            path = os.path.join(tmp_dir, "data.pkl")

            with open(path, "wb") as f:
                pickle.dump(data, f)

        with work_in_progress("Loading file"):
            with open(path, "rb") as f:
                data_loaded = pickle.load(f)

        assert data == data_loaded

# Generated at 2022-06-21 12:23:02.942305
# Unit test for function work_in_progress
def test_work_in_progress():
    for i in range(5):
        with work_in_progress("Loading data"):
            time.sleep(0.1)
    @work_in_progress("Loading data")
    def load_data():
        time.sleep(0.1)
    load_data()

# Generated at 2022-06-21 12:23:12.328702
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    
    obj = load_file("/path/to/some/file")
    assert obj is not None, "load_file failed"

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    
    assert os.path.exists(path), "save_file failed"


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:16.158143
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test")
    def function():
        time.sleep(1.1)

    function()


# Generated at 2022-06-21 12:23:22.851743
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("../tests/files/dummy_module.pickle")
    assert callable(obj)

    with work_in_progress("Saving file"):
        with open("../tests/files/dummy_module.pickle", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:23:26.216271
# Unit test for function work_in_progress
def test_work_in_progress():
    from unit_test import assert_equal

    @work_in_progress("Testing work_in_progress")
    def work():
        time.sleep(1)

    @work_in_progress("Testing work_in_progress")
    def work2():
        pass

    with work_in_progress("Testing work_in_progress") as w:
        time.sleep(0.5)
        assert_equal(type(w), type(lambda: None))

    work()
    work2()

# Generated at 2022-06-21 12:23:31.813022
# Unit test for function work_in_progress
def test_work_in_progress():
    from time import sleep
    import random
    import numpy as np

    @work_in_progress()
    def f():
        sleep(random.uniform(0, 0.5))
        return np.random.randn(10, 10)

    X = f()
    assert np.all(np.isfinite(X))

# Generated at 2022-06-21 12:23:33.680996
# Unit test for function work_in_progress
def test_work_in_progress():
    import random

    @work_in_progress
    def func():
        time.sleep(random.random())

    func()

# Generated at 2022-06-21 12:23:37.023603
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Computing 1+1"):
        time.sleep(1)
    with work_in_progress("Computing 1+2"):
        time.sleep(2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:43.862421
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(3.52)

    load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        time.sleep(3.78)


#-----------------------------------------------------------------------------
# Local Variables:
# mode: python
# coding: utf-8
# python-indent-offset: 4
# python-indent: 4
# End:

# Generated at 2022-06-21 12:23:53.878929
# Unit test for function work_in_progress
def test_work_in_progress():
    import contextlib

    @contextlib.contextmanager
    def dummy_context_manager() -> None:
        # Simply do nothing
        yield

    def dummy_function(arg):
        # Simply do nothing
        arg

    with work_in_progress(desc="Testing work_in_progress"):
        dummy_function(1)
        with work_in_progress(desc="Testing work_in_progress"):
            dummy_context_manager()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:24:01.825717
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Task 1")
    def task_1():
        time.sleep(1)
    task_1()

    @work_in_progress("Task 2")
    def task_2():
        pass
    task_2()

    with work_in_progress("Task 3"):
        time.sleep(1)
    with work_in_progress("Task 4"):
        pass

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:24:10.820995
# Unit test for function work_in_progress
def test_work_in_progress():
    def test_case1():
        @work_in_progress("Loading file")
        def load_file(path):
            with open(path, "rb") as f:
                return pickle.load(f)

        obj = load_file(__file__)

    def test_case2():
        with work_in_progress("Saving file"):
            with open(__file__, "wb") as f:
                pickle.dump(None, f)

    for test_case in (test_case1, test_case2):
        with capture_print() as captured:
            test_case()
        assert captured.stdout.splitlines() == [
            f"Loading file... done. ({captured.time_consumed:.2f}s)",
            "",
        ]



# Generated at 2022-06-21 12:24:16.808534
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:24:19.475346
# Unit test for function work_in_progress
def test_work_in_progress():

    with work_in_progress("test work_in_progress"):
        time.sleep(0.1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:24:21.926257
# Unit test for function work_in_progress
def test_work_in_progress():
    def w(d):
        with work_in_progress(d):
            time.sleep(3)

    w("Task with description")
    w("")

# Generated at 2022-06-21 12:24:28.680311
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:24:34.868682
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:24:39.901963
# Unit test for function work_in_progress
def test_work_in_progress():
    def _get_time_consumed(fun):
        with work_in_progress("Test"):
            fun()
    time1 = _get_time_consumed(lambda: time.sleep(1.5))
    time2 = _get_time_consumed(lambda: time.sleep(1))
    assert 1.5 <= time1 <= 1.6
    assert 1 <= time2 <= 1.1

# Generated at 2022-06-21 12:24:43.603913
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(1.0)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:24:51.565492
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file(__file__)
    with work_in_progress("Saving file"):
        with open(__file__, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:24:58.585252
# Unit test for function work_in_progress
def test_work_in_progress():
    for fname in [
        "fname1.pickle",
        "fname2.pickle",
    ]:
        with open(fname, "wb") as f:
            data = list(range(10000000))
            pickle.dump(data, f)

    for fname in [
        "fname1.pickle",
        "fname2.pickle",
    ]:
        with work_in_progress(f"Loading {fname}"):
            with open(fname, "rb") as f:
                data = pickle.load(f)

# Generated at 2022-06-21 12:25:10.028654
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with open("test.pkl", "wb") as f:
        pickle.dump(["a", "b", "c"], f)

    load_file("test.pkl")
    os.remove("test.pkl")

    with work_in_progress("Saving file"):
        with open("test.pkl", "wb") as f:
            pickle.dump(["a", "b", "c"], f)

    os.remove("test.pkl")


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:25:14.494342
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test 1"):
        time.sleep(1)
    @work_in_progress("Test 2")
    def test_func():
        time.sleep(2)
    test_func()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:25:21.209921
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("test.pickle")

    with work_in_progress("Saving file"):
        with open("test.pickle", "wb") as f:
            pickle.dump(obj, f)

    os.remove("test.pickle")

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:25:23.435174
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test if the function works as intended."""
    with work_in_progress("Processing data"):
        time.sleep(1.0)



# Generated at 2022-06-21 12:25:26.478396
# Unit test for function work_in_progress
def test_work_in_progress():
    import pstats, cProfile
    cProfile.runctx("work_in_progress.test()", globals(), locals(), "Profile.prof")
    s = pstats.Stats("Profile.prof")
    s.strip_dirs().sort_stats("time").print_stats()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:25:38.272233
# Unit test for function work_in_progress
def test_work_in_progress():

    # Test whether the string is printed
    with unittest.mock.patch('builtins.print') as mock_print:
        with work_in_progress("Loading file"):
            pass
        mock_print.assert_any_call("Loading file... ", end='', flush=True)

    # Test whether time is printed
    with unittest.mock.patch('builtins.print') as mock_print:
        with work_in_progress("Loading file"):
            time.sleep(0.5)
        mock_print.assert_any_call(f"done. (0.50s)")

    # Test whether time is printed in float format

# Generated at 2022-06-21 12:25:46.823440
# Unit test for function work_in_progress
def test_work_in_progress():
    def fake_long_run():
        time.sleep(1)

    print("Testing work_in_progress...")
    with work_in_progress("Testing 1: no yield"):
        fake_long_run()
    print(f"Testing 2: yield a value")
    print(f"Return value: {work_in_progress('Testing 2: yield a value'):}")
    fake_long_run()
    print(f"Testing 3: yield a function")
    for ret in work_in_progress('Testing 3: yield a function'):
        fake_long_run()
        yield ret
    print(f"Testing 4: yield a generator")
    def test_gen():
        for i in range(3):
            fake_long_run()
            yield i

# Generated at 2022-06-21 12:25:53.440689
# Unit test for function work_in_progress
def test_work_in_progress():

    # Time a function with a context manager
    @work_in_progress("Loading file")
    def load_file(path: str):
        with open(path, "rb") as f:
            return pickle.load(f)

    # Time a context manager with the context manager
    with work_in_progress("Saving file"):
        with open("test.pkl", "wb") as f:
            pickle.dump([x for x in range(100000)], f)

    # Load file
    obj = load_file("test.pkl")
    print(obj[:10])

# Generated at 2022-06-21 12:26:02.590832
# Unit test for function work_in_progress
def test_work_in_progress():
    for x in range(2):
        with work_in_progress(f"test #{x}"):
            time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:08.233548
# Unit test for function work_in_progress
def test_work_in_progress():
    import pathlib
    import tempfile

    # Verify output for function
    def foo():
        time.sleep(1)

    with work_in_progress() as _:
        foo()

    # Verify output for context manager
    with tempfile.TemporaryDirectory() as tmpdir:
        output_path = str(pathlib.Path(tmpdir) / "out")
        with work_in_progress() as _:
            with open(output_path, "wt") as f:
                foo()

# Generated at 2022-06-21 12:26:14.287228
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import time

    with work_in_progress("Computing something"):
        start_time = time.time()
        while time.time() < start_time + random.random() * 10:
            time.sleep(random.random() * 0.01)

# Generated at 2022-06-21 12:26:19.724358
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
        with work_in_progress("Loading subfile"):
            time.sleep(1.5)
    with work_in_progress("Saving file"):
        time.sleep(1.5)
        with work_in_progress("Saving subfile"):
            time.sleep(0.8)
    print("Done.")

# Generated at 2022-06-21 12:26:31.680350
# Unit test for function work_in_progress
def test_work_in_progress():
    ########################################################################
    # Test case 1: Test context manager
    ########################################################################
    with work_in_progress("Loading file"):
        time.sleep(1)
    # Expected print:
    #  >>>
    #  Loading file... done. (1.00s)

    ########################################################################
    # Test case 2: Test context manager
    ########################################################################
    @work_in_progress("Saving file")
    def save_file(path: str, obj: object):
        # Pretend that this function is time consuming
        time.sleep(1)

        with open(path, "wb") as f:
            return pickle.dump(obj, f)

    save_file("test_work_in_progress.pkl", {"test": "123"})
    # Expected print:


# Generated at 2022-06-21 12:26:36.212245
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test")
    def inner_func():
        time.sleep(0.5)

    with work_in_progress("Test"):
        time.sleep(0.5)
    assert True

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:38.883417
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    with work_in_progress("Saving file"):
        time.sleep(2)

# Generated at 2022-06-21 12:26:41.528869
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(0.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:44.797610
# Unit test for function work_in_progress
def test_work_in_progress():
    def func(x):
        time.sleep(x)
        return x

    with work_in_progress("Test loading"):
        func(0.5)

    @work_in_progress("Test loading 2")
    def func2(x):
        time.sleep(x)
        return x

    func2(0.52)

# Generated at 2022-06-21 12:26:47.625271
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress context manager"):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:52.970495
# Unit test for function work_in_progress
def test_work_in_progress():  # pylint: disable = missing-function-docstring
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-21 12:26:58.081476
# Unit test for function work_in_progress
def test_work_in_progress():
    def test_print():
        print("Test print")

    test_print()
    with work_in_progress("Test work_in_progress"):
        time.sleep(2)
    test_print()
    with work_in_progress():
        time.sleep(2)
    test_print()

# test_work_in_progress()

# Generated at 2022-06-21 12:27:03.252521
# Unit test for function work_in_progress
def test_work_in_progress():

    def noop():
        time.sleep(0.1)

    with work_in_progress("Test Task"):
        noop()
    noop()
    noop()
    noop()

    @work_in_progress("Test Task Decorator")
    def noop_decorated():
        time.sleep(0.1)

    noop_decorated()
    noop()
    noop()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:27:08.991901
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test case 1
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    # Test case 2
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:27:15.372401
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import time
    from io import StringIO
    from unittest.mock import patch

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file(__file__)
    out = StringIO()
    with patch("sys.stdout", new=out) as out:
        with work_in_progress("Saving file"):
            time.sleep(0.1)
        assert out.getvalue().strip().endswith("(0.10s)")

# Generated at 2022-06-21 12:27:25.937544
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    This function tests the function work_in_progress using pythons unittest module.
    """
    import unittest
    from unittest.mock import patch

    class TestWorkInProgress(unittest.TestCase):
        def test_work_in_progress(self):
            """
            This function tests the function work_in_progress of the module helpers.
            """
            with patch("sys.stdout", new=io.StringIO()) as fake_out:
                with work_in_progress("test"):
                    pass
                self.assertEqual(fake_out.getvalue(), "test... done. (0.00s)\n")
        def test_work_in_progress_exception(self):
            """
            This function tests the function work_in_progress of the module helpers.
            """


# Generated at 2022-06-21 12:27:35.415340
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import pickle
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert type(obj) is bytes
    assert len(obj) == 134217728

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:27:40.045222
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Hello world"
    with work_in_progress(desc):
        time.sleep(0.001)
    assert desc + "... done." in caplog.text
    assert "0.00" in caplog.text
    assert "s" in caplog.text

# Generated at 2022-06-21 12:27:41.890687
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(3.7)

# Generated at 2022-06-21 12:27:44.293443
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(3)

# Generated at 2022-06-21 12:27:52.914031
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/our/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:28:05.391327
# Unit test for function work_in_progress
def test_work_in_progress():
    TEST_DESC = "Loading file"

    @work_in_progress(TEST_DESC)
    def load_file(path):
        time.sleep(2)
        with open(path, "rb") as f:
            return pickle.load(f)

    class Dummy:
        pass

    testobj = Dummy()
    testobj.data = "INFO: This file is for testing purpose only."

    with open("test_funcs.pickle", "wb") as f:
        pickle.dump(testobj, f)

    obj = load_file("test_funcs.pickle")
    if testobj.data != obj.data:
        raise AssertionError("Data not match.")

# Generated at 2022-06-21 12:28:09.849264
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:28:13.018904
# Unit test for function work_in_progress

# Generated at 2022-06-21 12:28:15.651050
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:28:22.362564
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    with open("test_work_in_progress.txt", "w") as f:
        pickle.dump({"1": "1"}, f)

    with work_in_progress("Loading file"):
        with open("test_work_in_progress.txt", "rb") as f:
            file = pickle.load(f)
    assert file == {"1": "1"}

    with open("test_work_in_progress.txt", "wb") as f:
        pickle.dump({"1": "1"}, f)
    with work_in_progress("Saving file"):
        with open("test_work_in_progress.txt", "rb") as f:
            file = pickle.load(f)
    assert file == {"1": "1"}



# Generated at 2022-06-21 12:28:26.540954
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3)
    with work_in_progress("Saving file"):
        time.sleep(4)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:28:31.897628
# Unit test for function work_in_progress
def test_work_in_progress():
    from os.path import expanduser
    from .misc import shutil_which
    sys.path.insert(0, expanduser("~"))
    try:
        shutil_which("ffmpeg").wait()
    except:
        print(
            "ffmpeg not found. ",
            "Install ffmpeg to test work_in_progress()."
        )
    else:
        for _ in range(4):
            with work_in_progress("Sleeping for 3 seconds"):
                time.sleep(3)


if __name__ == "__main__":
    sys.exit(test_work_in_progress())

# Generated at 2022-06-21 12:28:35.508861
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(1)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:28:44.745620
# Unit test for function work_in_progress
def test_work_in_progress():
    import pandas as pd
    import os
    import subprocess
    import fnmatch
    import tempfile
    import shutil
    import pickle

    def fib(n):
        if n > 1:
            return fib(n-1) + fib(n-2)
        else:
            return 1

    # Test work_in_progress in a function
    @work_in_progress("Computing fib")
    def fib_wrapper(n):
        return fib(n)

    assert fib_wrapper(30) == 1346269

    # Test work_in_progress in a for loop
    for i in range(1,4):
        with work_in_progress("Computing fib {}".format(i)):
            assert fib(i) == 1

    # Test work_in_progress in a context manager

# Generated at 2022-06-21 12:28:57.283745
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Time the execution time of a code block or function.
    """
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb"):
            time.sleep(3.52)
    load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        time.sleep(3.78)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:29:03.798742
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:29:07.657530
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        return path

    with work_in_progress():
        pass

    assert load_file("/path/to/some/file") == "/path/to/some/file"

# Generated at 2022-06-21 12:29:13.225978
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file") as w:
        time.sleep(1.23)
    assert w is None

    obj = None
    @work_in_progress("Loading file")
    def load_file():
        nonlocal obj
        time.sleep(1.23)
        obj = 1
    try:
        load_file()
    except Exception:
        pass
    assert obj == 1

# Generated at 2022-06-21 12:29:23.818036
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test function work_in_progress."""
    from tempfile import TemporaryDirectory
    from os import path

    print("----- Testing function work_in_progress -----")

    # create a temporary directory for testing
    with contextlib.closing(TemporaryDirectory()) as test_dir:
        test_path = path.join(test_dir, "test")

        @work_in_progress("Loading file")
        def load_file(path):
            time.sleep(3.52)
            with open(path, "rb") as f:
                return pickle.load(f)

        @work_in_progress("Saving file")
        def save_file(path):
            time.sleep(3.78)
            with open(path, "wb") as f:
                pickle.dump(0, f)


# Generated at 2022-06-21 12:29:29.926824
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function ``work_in_progress``."""
    @work_in_progress("Loading file")
    def load_file(path: str):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path: str, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with tempfile.TemporaryDirectory() as temp_dir:
        path = os.path.join(temp_dir, "data.pkl")

        # Create data
        obj = {
            "a": [1, 2, 3],
            "b": [4, 5],
            "c": [6, 7, 8, 9],
        }

        #

# Generated at 2022-06-21 12:29:33.593730
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress") as progress:
        for i in range(10):
            time.sleep(0.1)
            progress.step()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:29:36.128308
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Testing work_in_progress"
    with work_in_progress(desc):
        time.sleep(0.5)

# Generated at 2022-06-21 12:29:40.908307
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file") as progress:
        progress.report("Reading file")
        time.sleep(0.01)
        progress.report("Processing data")
        time.sleep(0.01)
    print("Done.")


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:29:48.254251
# Unit test for function work_in_progress
def test_work_in_progress():
    from sys import stderr
    import io
    import time

    # Mock the output
    stdout = io.StringIO()
    stderr_old = stderr
    stderr = io.StringIO()

    # Mock time.time()
    time_old = time.time
    time.time = lambda: 0.00

    # Test

# Generated at 2022-06-21 12:30:10.022676
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        import time
        time.sleep(0.54)

    with work_in_progress("Saving file"):
        import time
        time.sleep(0.5)

    def _load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    import pathlib

# Generated at 2022-06-21 12:30:13.923842
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress('Custom description')
    def do_it():
        time.sleep(1)
    with work_in_progress('Auto-generated description'):
        time.sleep(2)
    do_it()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:30:19.228106
# Unit test for function work_in_progress
def test_work_in_progress():
    from io import StringIO
    from contextlib import redirect_stdout

    with StringIO() as buf, redirect_stdout(buf):
        with work_in_progress("Hello World"):
            time.sleep(1)

    assert "Hello World... done. (1.00s)" in buf.getvalue()

# Generated at 2022-06-21 12:30:24.019347
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Unit test with context manager")
    def f():
        time.sleep(1.23)
    with f:
        pass

    @work_in_progress("Unit test with decorator")
    def g():
        time.sleep(2.34)
    with g:
        pass


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:30:29.194572
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:30:34.124585
# Unit test for function work_in_progress
def test_work_in_progress():
    # A function call with the context
    @work_in_progress("Counting...")
    def count_to(n):
        time.sleep(n)

    count_to(3)

    # A block with the context
    with work_in_progress("Counting..."):
        time.sleep(5)


# Generated at 2022-06-21 12:30:44.465593
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    import sys
    from contextlib import redirect_stdout

    def capture_stdout(func):
        def wrapper(*args, **kwargs):
            f = io.StringIO()
            with redirect_stdout(f):
                func(*args, **kwargs)
            return f.getvalue()
        return wrapper

    In, Out = str, str
    @capture_stdout
    def run_test(*args: In) -> Out:
        with work_in_progress(*args):
            time.sleep(0.5)
        return ""

    expected = "Work in progress... done. (0.50s)\n"
    assert run_test("Work in progress") == expected

    expected = "Loading... done. (0.50s)\n"
    assert run_test("Loading") == expected

# Generated at 2022-06-21 12:30:47.941616
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test function")
    def do_nothing():
        pass

    do_nothing()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:30:54.184543
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file(__file__)

    with work_in_progress("Saving file"):
        with tempfile.TemporaryFile("wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:30:56.937595
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3.35)
    time.sleep(0.1)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:31:09.862817
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Task 1"):
        time.sleep(0.5)
    with work_in_progress("Task 2"):
        time.sleep(1.5)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:31:16.219521
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1)
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file.__wrapped__("test.pkl")
    assert obj == 1
    with work_in_progress("Saving file"):
        time.sleep(1)
        with open("test.pkl", "wb") as f:
            pickle.dump(obj, f)
    os.remove("test.pkl")

# Generated at 2022-06-21 12:31:20.049729
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Testing work_in_progress")
    def test_function():
        time.sleep(3)

    test_function()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:31:22.559795
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test if the timing of this function is working as expected.

    .. code:: python

        >>> test_work_in_progress()
        Work in progress... done. (0.34s)
    """
    with work_in_progress("Work in progress"):
        time.sleep(0.34)


if __name__ == '__main__':
    # For testing, use the doctest module
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:31:26.471887
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def test_func():
        time.sleep(3.5)
    test_func()
    with work_in_progress("Testing work_in_progress 2"):
        time.sleep(3.5)

# Generated at 2022-06-21 12:31:29.181268
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(0.1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:31:33.664377
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Task1")
    def task1():
        time.sleep(2)
        pass

    with work_in_progress("Task2"):
        time.sleep(3)

    task1()
    # Task1... done. (2.01s)
    # Task2... done. (3.01s)

# Generated at 2022-06-21 12:31:36.120666
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("A simple task"):
        time.sleep(3)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:31:41.752521
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:31:51.446085
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress."""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    assert load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    # Running this document will execute all >>> comments as test of this module
    import doctest
    doctest.testmod()
    # test_work_in_progress()

# Generated at 2022-06-21 12:32:15.295469
# Unit test for function work_in_progress
def test_work_in_progress():
    pass

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:32:21.728098
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading data")
    def load_data(path):
        time.sleep(4)
        return 0

    with work_in_progress("Saving data"):
        time.sleep(5)

    load_data("/path/to/data")
    time.sleep(1)
    with work_in_progress("Some slow process"):
        time.sleep(3)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:32:26.863458
# Unit test for function work_in_progress
def test_work_in_progress():
    from data_io_beta import work_in_progress

    with work_in_progress("Testing"):
        time.sleep(0.6)
    def func():
        with work_in_progress("Testing"):
            time.sleep(0.6)
    func()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:32:30.638869
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Sleep time")
    def _sleep_time(seconds):
        time.sleep(seconds)

    _sleep_time(5)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:32:32.891145
# Unit test for function work_in_progress
def test_work_in_progress():
    from .test import do_test_work_in_progress

    do_test_work_in_progress.do_test(work_in_progress)

# Generated at 2022-06-21 12:32:36.349889
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3.52)

    print("")

    with work_in_progress("Saving file"):
        time.sleep(3.78)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:32:43.354104
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1.5)
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    # equal(actual, expected)

    with work_in_progress("Saving file"):
        time.sleep(1.5)
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:32:48.785046
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import random

    with work_in_progress("Sleeping for a while"):
        time.sleep(random.random())

    def foo():
        time.sleep(random.random())

    with work_in_progress("Testing foo"):
        foo()

    @work_in_progress("Testing bar")
    def bar():
        time.sleep(random.random())

    bar()