

# Generated at 2022-06-21 12:22:56.830351
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    # Case 1
    with work_in_progress("Loading file"):
        time.sleep(3)
    # Case 2
    @work_in_progress("Loading file")
    def load_file(path):
        import os

        with open(path, "rb") as f:
            return os.fstat(f.fileno())

    load_file("/proc/self/mounts")


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:23:03.128726
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")


# Local Variables:
# python-indent-offset: 4
# End:

# Generated at 2022-06-21 12:23:09.185058
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file_test(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    load_file_test("/path/to/some/file")

# Generated at 2022-06-21 12:23:13.089775
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Sleeping for 1 second")
    def sleep_1sec():
        time.sleep(1)

    sleep_1sec()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:23.571667
# Unit test for function work_in_progress
def test_work_in_progress():
    from unittest import TestCase
    from io import StringIO
    import sys

    def test_work_in_progress():
        class TestWorkInProgress(TestCase):
            def test_function(self):
                def foo(a, b):
                    for _ in range(a):
                        for _ in range(b):
                            pass
                    return a, b
                output_stream = StringIO()
                with self.subTest("Print to stdout"), stdout_redirector(output_stream):
                    foo = work_in_progress("Multiplying two numbers")(foo)
                    self.assertEqual(foo(8, 125), (8, 125))
                    self.assertIn("Multiplying two numbers", output_stream.getvalue())

# Generated at 2022-06-21 12:23:30.771476
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:23:33.073729
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def test_func():
        time.sleep(3)

    test_func()

# Generated at 2022-06-21 12:23:38.807373
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test if the execution of ``work_in_progress()`` is executed as expected.
    """
    # Test if work_in_progress is executed as expected
    # - in context manager
    with work_in_progress("Test context manager")  as _:
        time.sleep(0.1)
    # - decorator
    @work_in_progress("Test decorator")
    def test():
        time.sleep(0.1)
    test()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:45.173142
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Slow task (1s)"):
        time.sleep(1)
    import os, sys
    with work_in_progress("Slow task (2s)"):
        time.sleep(2)
    with work_in_progress("Slow task (3s)"):
        time.sleep(3)
    with work_in_progress("Slow task (4s)"):
        time.sleep(4)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:52.023402
# Unit test for function work_in_progress
def test_work_in_progress():
    from .assertions import assert_between, assert_regex
    with work_in_progress("Testing") as test:
        time.sleep(0.1)
    output = test.stdout.getvalue().strip()
    assert_between(0.09, 0.11, float(output.split("(")[1].split("s)")[0]))
    assert_regex(r"^Testing\.\.\. done\. \([0-9\.]+s\)$", output)

# Generated at 2022-06-21 12:24:00.258307
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    test_obj = {"a": 1, "b": 2, 3: 3}
    save_file("test.bin", test_obj)
    obj = load_file("test.bin")
    print(obj)

# Generated at 2022-06-21 12:24:03.933131
# Unit test for function work_in_progress
def test_work_in_progress():
    # Use a decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    # Use a context manager
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:24:10.357301
# Unit test for function work_in_progress
def test_work_in_progress():
    # it should print information in the right format
    import sys

    @work_in_progress("Testing")
    def f():
        time.sleep(0.1)

    saver = sys.stdout
    try:
        with io.StringIO() as fout:
            sys.stdout = fout
            f()
            sys.stdout.flush()
            assert fout.getvalue().strip() == "Testing... done. (0.10s)"
    finally:
        sys.stdout = saver

# Generated at 2022-06-21 12:24:12.423615
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Working"):
        time.sleep(1)

# Generated at 2022-06-21 12:24:21.055864
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    assert os.path.exists("data/example.pkl")
    obj = load_file("data/example.pkl")
    assert obj is not None
    assert obj["name"] == "example"
    assert obj["desc"] == "This is an example data file."

    with work_in_progress("Saving file"):
        with open("data/save.pkl", "wb") as f:
            pickle.dump(obj, f)

    assert os.path.exists("data/save.pkl")
    os.remove("data/save.pkl")

# Generated at 2022-06-21 12:24:23.990258
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Working on something")
    def _test():
        time.sleep(2)
    _test()

# Generated at 2022-06-21 12:24:32.488714
# Unit test for function work_in_progress
def test_work_in_progress():
    # Your path to some file
    path = "/home/username/Downloads/some_file.pkl"
    with work_in_progress("Loading file"):
        with open(path, "rb") as f:
            obj = pickle.load(f)
    # Perform some operation
    # ...
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Run the unit test
if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:24:34.184899
# Unit test for function work_in_progress
def test_work_in_progress():
    ...


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:24:35.211342
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(1)



# Generated at 2022-06-21 12:24:37.626621
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        with open(__file__, "r") as f:
            lines = [line for line in f]
    assert lines

# Generated at 2022-06-21 12:24:41.146677
# Unit test for function work_in_progress
def test_work_in_progress():
    # TODO
    assert True

# Generated at 2022-06-21 12:24:47.867452
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:24:57.877914
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    assert load_file("../data/mnist.pkl").__class__.__name__ == "Data"
    assert load_file("../data/cifar_10.pkl").__class__.__name__ == "Data"

    with work_in_progress("Saving file"):
        with open("../data/test.pkl", "wb") as f:
            pickle.dump(load_file("../data/mnist.pkl"), f)

    with work_in_progress("Loading file"):
        with open("../data/test.pkl", "rb") as f:
            assert pickle.load(f).__class

# Generated at 2022-06-21 12:25:04.414534
# Unit test for function work_in_progress
def test_work_in_progress():
    def foo(a, b):
        return a + b

    with work_in_progress("Testing work_in_progress"):
        assert foo(2, 3) == 5
        time.sleep(1)


# Local Variables:
# # tab-width:4
# # indent-tabs-mode:nil
# # End:
# vim: set syntax=python expandtab tabstop=4 shiftwidth=4:

# Generated at 2022-06-21 12:25:10.028888
# Unit test for function work_in_progress
def test_work_in_progress():
    __doc__ = r"""Test function work_in_progress"""

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # obj = load_file("/path/to/some/file")
    path = "/data/predict/bznet_ss/voc2012/voc2012_trainval_numerical_data.pkl"
    obj = load_file(path)
    print(obj)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Invoke the unit test
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:25:17.318432
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:25:25.521863
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test for function work_in_progress."""

    @work_in_progress("loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return f.read()

    @work_in_progress("saving file")
    def save_file(path):
        with open(path, "wb") as f:
            f.write(b"1" * 100 * 1 * 1024 * 1024)

    @work_in_progress("saving file")
    def save_file2(path):
        with open(path, "wb") as f:
            time.sleep(1)
            f.write(b"1" * 100 * 1 * 1024 * 1024)

    assert load_file("/etc/passwd")
    save_file("/tmp/test_work_in_progress")

# Generated at 2022-06-21 12:25:36.982423
# Unit test for function work_in_progress
def test_work_in_progress():
    # Define a function that will be decorated with work_in_progress
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "r") as f:
            for line in f:
                # Do something with the line
                pass

    # Define a function that will be decorated with work_in_progress
    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "w") as f:
            # Do something with lines
            pass

    # Define a function that will be decorated with work_in_progress
    @work_in_progress("Doing something that takes a long time")
    def something_that_takes_a_long_time():
        time.sleep(0.5)

    # Call the functions
   

# Generated at 2022-06-21 12:25:42.291953
# Unit test for function work_in_progress
def test_work_in_progress():
    def _work():
        time.sleep(0.05)
    
    print("1. Test function")
    @work_in_progress("Function Test")
    def _test():
        _work()

    _test()

    print("2. Test context manager")
    with work_in_progress("Context Manager Test"):
        _work()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:25:51.178917
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function work_in_progress."""

    tic = time.time()

    with work_in_progress("Saving file"):
        time.sleep(3)

    toc = time.time()

    assert(toc - tic >= 3)

    @work_in_progress("Loading file")
    def load_file():
        time.sleep(3)

    tic = time.time()
    load_file()
    toc = time.time()

    assert(toc - tic >= 3)

    print("Work in progress unit test PASS.")


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:25:58.520000
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file") as wp:
        time.sleep(1)
        wp.__exit__(None, None, None)
        pass


# This is only run when called by name from command line
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:08.819934
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import os
    import tempfile
    import shutil

    original = {
        "foo": "bar",
        "boo": [1, "a", (1, 2, 3)],
        "fizz": "buzz",
    }

    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-21 12:26:20.939804
# Unit test for function work_in_progress
def test_work_in_progress():
    from contextlib import suppress
    from functools import partial

    # Invalid argument
    with pytest.raises(TypeError):
        with work_in_progress():
            pass

    def _test_progress(desc: str = "Work in progress", file=sys.stdout):
        print(f"{desc}... ", end='', file=file)
        time.sleep(1)
        print("done.", file=file)
        file.flush()

    with tempfile.TemporaryDirectory() as tmpdir:
        # Function with standard output
        _test_progress(file=sys.stdout)
        with suppress(Exception):
            with open(tmpdir + "/tmp.txt", "w") as file:
                _test_progress(file=file)
        # Function with work_in_progress

# Generated at 2022-06-21 12:26:22.937324
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("My work"):
        time.sleep(0.6)


# Generated at 2022-06-21 12:26:34.903069
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    import sys
    import time
    import unittest
    import unittest.mock

    def test_function():
        with work_in_progress("Test function") as progress:
            time.sleep(0.1)
            if progress.exception_info is not None:
                raise progress.exception_info[1]

    class Test(unittest.TestCase):
        def setUp(self):
            self.printed_messages = []
            self.output_stream = io.StringIO()
            self.original_stdout = sys.stdout
            sys.stdout = self.output_stream

        def tearDown(self):
            sys.stdout = self.original_stdout
            self.output_stream.close()


# Generated at 2022-06-21 12:26:41.262361
# Unit test for function work_in_progress
def test_work_in_progress():
    class Obj:
        pass

    obj = Obj()
    with work_in_progress("test loading file"):
        time.sleep(1)
    with work_in_progress("test saving file"):
        time.sleep(2)

    @work_in_progress("test loading function")
    def load_file():
        time.sleep(3)
        return obj

    obj = load_file()
    assert obj is not None


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:26:42.872991
# Unit test for function work_in_progress
def test_work_in_progress():

    with work_in_progress("Testing work_in_progress"):
        time.sleep(1)

# Generated at 2022-06-21 12:26:46.619286
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress"""
    print("#" * 40)
    @work_in_progress("Test")
    def foo():
        time.sleep(2)
    foo()
    assert True

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:26:55.693655
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(1)
    with work_in_progress("Loading file"):
        time.sleep(1)
    with work_in_progress():
        time.sleep(1)
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    load_file("/path/to/some/file")

# Generated at 2022-06-21 12:26:59.777284
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file():
        time.sleep(3.5)

    with work_in_progress("Saving file"):
        time.sleep(3.78)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:27:13.727353
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    path = "data.pkl"
    obj = list(range(100))
    with open(path, "wb") as f:
        pickle.dump(obj, f)
    with work_in_progress("Loading file"):
        with open(path, "rb") as f:
            obj = pickle.load(f)
    assert obj == list(range(100))
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    obj = None
    with open(path, "rb") as f:
        obj = pickle.load(f)
    assert obj == list(range(100))
    import os
    os.remove(path)



# Generated at 2022-06-21 12:27:20.632905
# Unit test for function work_in_progress
def test_work_in_progress():
    begin_time = time.time()
    sleep_time = 3
    with work_in_progress("Sleep for 3 seconds"):
        time.sleep(sleep_time)
    time_consumed = time.time() - begin_time
    assert abs(time_consumed - sleep_time) < 0.1, "Function work_in_progress failed"

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:27:23.689819
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Compute Fibonacci number"):
        time.sleep(1.5)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:27:26.437067
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test function")
    def test_func():
        time.sleep(2)

    test_func()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:27:28.170096
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Timing me")
    def print_time():
        time.sleep(0.5)

    print_time()

# Generated at 2022-06-21 12:27:37.312897
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    import sys
    # Make stdout to an io buffer
    stdout = io.StringIO()
    sys.stdout = stdout
    # Test function
    @work_in_progress("test")
    def test():
        time.sleep(1)

    # Test context manager
    with work_in_progress("test"):
        time.sleep(1)

    # Restore stdout
    sys.stdout = sys.__stdout__

    assert stdout.getvalue()[:5] == "test."
    assert stdout.getvalue()[-4:].strip() == "(1.00s)"

# Generated at 2022-06-21 12:27:43.798276
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert(obj is not None)
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


# Generated at 2022-06-21 12:27:48.441424
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    with work_in_progress("Saving file"):
        time.sleep(2)
    with work_in_progress("Deleting file"):
        time.sleep(3)

# Generated at 2022-06-21 12:27:50.854733
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress(desc="Test work_in_progress") as progress:
        time.sleep(0.01)
        progress.done()

# Generated at 2022-06-21 12:27:56.297480
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


# Generated at 2022-06-21 12:28:10.146388
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.5)

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:28:13.266226
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    >>> with work_in_progress("Testing work_in_progress"):
    ...     time.sleep(1)
    Testing work_in_progress... done. (1.00s)
    """



# Generated at 2022-06-21 12:28:16.766774
# Unit test for function work_in_progress
def test_work_in_progress():
    from .generic import timer
    
    with timer():
        with work_in_progress("Work in progress"):
            time.sleep(2)
    assert 1 < timer.time_elapsed < 3

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:28:23.139747
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test for function work_in_progress.
    """
    def _test_func():
        time.sleep(1.5)

    with work_in_progress("Testing"):
        _test_func()

    @work_in_progress("Testing")
    def _test_func2():
        time.sleep(1.5)

    _test_func2()

# Generated at 2022-06-21 12:28:28.741201
# Unit test for function work_in_progress
def test_work_in_progress():
    def fake_load_file(path):
        time.sleep(3)
        return path

    def fake_save_file(path):
        time.sleep(3.5)
        return path

    assert work_in_progress(fake_load_file, "/path/to/file") == "/path/to/file"
    assert work_in_progress(fake_save_file, "/path/to/file") == "/path/to/file"

# Generated at 2022-06-21 12:28:35.073930
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test for description with/without dots
    for desc in ["A", "A.", "A.."]:
        with work_in_progress(desc):
            time.sleep(2)

    # Test for multi-line block
    with work_in_progress():
        print()
        time.sleep(2)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:28:42.226672
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Trying to sleep"):
        time.sleep(1)
    load_file.__doc__ = load_file.__doc__.strip().rstrip("`.")
    output = check_output([sys.executable, "-c", load_file.__doc__]).decode()
    assert "done. (1.00s)" in output
    assert "Loading file... done. (3.52s)" in output


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:28:48.017197
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)



# Generated at 2022-06-21 12:28:57.151526
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Performing a task"):
        time.sleep(1.5)

    import pickle
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    path = "/path/to/some/file"
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)



# Generated at 2022-06-21 12:29:00.020380
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Some task") as w:
        time.sleep(3.52)
        w.send(None)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:29:26.680299
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Initializing... "):
        time.sleep(2.00)
    with work_in_progress("Loading..."):
        time.sleep(2.00)
    try:
        with work_in_progress("Wait..."):
            raise KeyboardInterrupt
    except KeyboardInterrupt:
        pass
    try:
        with work_in_progress("Wait..."):
            raise KeyboardInterrupt
    except:
        pass
    with work_in_progress("Wait..."):
        time.sleep(0.01)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:29:28.353947
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Waiting for 3 seconds"):
        time.sleep(3)

# Generated at 2022-06-21 12:29:29.118616
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test code"):
        time.sleep(1)

# Generated at 2022-06-21 12:29:39.482048
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work in progress"):
        time.sleep(1)
    assert True # If we reach here, all went well

# Examples of how to use this library
if __name__ == "__main__":

    # Testing work_in_progress function
    test_work_in_progress()

    # Example 1
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

    # Example 2
    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:29:44.968373
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:29:50.664310
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    # Run the unit test for this module
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-21 12:29:54.330072
# Unit test for function work_in_progress
def test_work_in_progress():
    expected_str = "Saving file... done. (3.78s)"
    with capture_output() as (out, err):
        with work_in_progress("Saving file"):
            time.sleep(3.78)
        assert out.getvalue().strip() == expected_str

# Generated at 2022-06-21 12:29:56.822905
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test code for class")
    def test():
        time.sleep(1.0)
    test()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:29:59.032773
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""
    >>> with work_in_progress("Test"):
    ...     time.sleep(0.2)
    Test... done. (0.20s)
    """
    pass

# Generated at 2022-06-21 12:30:02.911372
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing"):
        time.sleep(0.3)
    assert True

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:30:53.218086
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import functools
    import random
    import pkg_resources
    import tempfile

    def load_obj():
        return pickle.load(pkg_resources.resource_stream(__name__, "test-data/test_obj.pkl"))

    def slow_save_obj(obj: object, path: str):
        time.sleep(random.random() * 0.5)
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_obj()
    assert obj["key1"] == "value1"
    assert obj["key2"] == "value2"
    assert obj["key3"] == "value3"

# Generated at 2022-06-21 12:31:04.372066
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    # Using the context manager without a 'with' statement
    obj = load_file("/path/to/some/file")
    save_file("/path/to/other/file", obj)

    # Using the context manager with a 'with' statement
    with work_in_progress("Loading another file"):
        obj = load_file("/path/to/some/other/file")

    # Testing the description

# Generated at 2022-06-21 12:31:08.835012
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)



# Generated at 2022-06-21 12:31:15.088824
# Unit test for function work_in_progress
def test_work_in_progress():
    #
    # The timer should work correctly with function
    #
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("utils.py")

    #
    # The timer should work correctly with context
    #
    with work_in_progress("Saving file"):
        with open("utils.py", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:31:25.497399
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import pickle
    import os
    import time

    def dup_unit_test():
        obj = []
        with work_in_progress("Generating data"):
            for _ in range(0, 100000):
                obj.append(os.urandom(1))
        with work_in_progress("Writting data"):
            with tempfile.TemporaryFile(mode="wb", buffering=0) as f:
                pickle.dump(obj, f)

        time.sleep(0.12)
        with work_in_progress("Loading data"):
            with tempfile.TemporaryFile(mode="rb", buffering=0) as f:
                pickle.load(f)

    dup_unit_test()

# Generated at 2022-06-21 12:31:30.494455
# Unit test for function work_in_progress
def test_work_in_progress():
    def f():
        time.sleep(1)
    print("Should take 1.00s")
    with work_in_progress():
        f()
    print("Should take 3.00s")
    with work_in_progress("Some text"):
        time.sleep(3)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:31:36.486261
# Unit test for function work_in_progress
def test_work_in_progress():
    obj = list(range(1000000))
    with work_in_progress("Making a list"):
        assert obj == list(range(1000000))
    obj = tuple(range(1000000))
    with work_in_progress("Making a tuple"):
        assert obj == tuple(range(1000000))
    obj = set(range(10000000))
    with work_in_progress("Making a set"):
        assert obj == set(range(10000000))


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:31:39.668220
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)


# Generated at 2022-06-21 12:31:43.655050
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test if the ``work_in_progress`` context manager works."""
    import time
    import random

    with work_in_progress():
        time.sleep(random.randrange(1, 5))


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:31:45.845479
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test function work_in_progress")
    def test(p):
        time.sleep(p)
    test(3)