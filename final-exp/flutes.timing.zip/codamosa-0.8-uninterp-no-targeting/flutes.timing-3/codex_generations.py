

# Generated at 2022-06-21 12:22:51.034499
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("test") as test:
        time.sleep(1)

# Generated at 2022-06-21 12:22:54.050979
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("This is a test"):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:22:56.098053
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Testing function")
    def foo():
        time.sleep(3)
        return 1

    assert foo() == 1

# Generated at 2022-06-21 12:22:59.174297
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Sleeping")
    def sleep(secs):
        time.sleep(secs)

    sleep(2)
    with work_in_progress("Sleeping"):
        time.sleep(2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:09.790556
# Unit test for function work_in_progress
def test_work_in_progress():
    # TODO: Use unittest module
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/home/lucas/Documents/data/corona/corona-data.pp")

    with work_in_progress("Saving file"):
        with open("/home/lucas/Documents/data/corona/corona-data.pp", "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:13.574010
# Unit test for function work_in_progress
def test_work_in_progress():
    begin_time = time.time()
    with work_in_progress():
        time.sleep(1)
    end_time = time.time()
    assert abs(end_time - begin_time - 1) < 0.2

# Generated at 2022-06-21 12:23:18.846462
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test for function :func:`work_in_progress"""
    def foo():
        with work_in_progress():
            time.sleep(1)

    foo()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:27.758143
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test contextlib.contextmanager
    with work_in_progress("Test work_in_progress function"):
        time.sleep(3)

    # Test function decorator
    @work_in_progress("Test work_in_progress function")
    def func():
        time.sleep(3)
    
    func()

# Generated at 2022-06-21 12:23:37.061484
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("test_file.pkl")

    assert obj.test == "test"

    with work_in_progress("Saving file") as w:
        with open("test_file.pkl", "wb") as f:
            obj.test = "test_two"
            pickle.dump(obj, f)

    obj = load_file("test_file.pkl")

    assert obj.test == "test_two"

    os.remove("test_file.pkl")


# Generated at 2022-06-21 12:23:46.235286
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test if this actually works first
    with work_in_progress("Foo Bar") as _:
        time.sleep(5)

    # Test if this is re-entrant
    with work_in_progress("Foo Bar") as _:
        time.sleep(3)
        with work_in_progress("Bar Foo") as _:
            time.sleep(5)
        time.sleep(3)
    # Test if this is re-entrant, no custom message
    with work_in_progress() as _:
        time.sleep(3)
        with work_in_progress() as _:
            time.sleep(5)
        time.sleep(3)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:52.697383
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    
    class Foo:
        def __init__(self):
            self.a = "a"
        
        def __eq__(self, other):
            return self.a == other.a

    with work_in_progress("Time this block"):
        time.sleep(0.5)

    @work_in_progress("Time this function")
    def get_foo():
        time.sleep(0.5)
        return Foo()

    foo = get_foo()
    assert foo == Foo(), "unit test failed"

# Generated at 2022-06-21 12:23:59.658901
# Unit test for function work_in_progress
def test_work_in_progress():
    from pathlib import Path
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    print(f"Returned object: {obj}")

    path = Path("file_to_save.pickle")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:24:04.429196
# Unit test for function work_in_progress
def test_work_in_progress():
    log = ""
    def fake_print(*args, **kwargs):
        nonlocal log
        log += " ".join(args)

    with patch("builtins.print", side_effect=fake_print, create=True) as print_mock:
        with work_in_progress():
            time.sleep(1)
    assert log == "Work in progress... done. (1.00s)"

# Generated at 2022-06-21 12:24:10.402784
# Unit test for function work_in_progress
def test_work_in_progress():
    def fib(n):
        return 1 if n <= 2 else fib(n - 1) + fib(n - 2)

    with work_in_progress("Calculating the 10th Fibonacci number"):
        assert fib(10) == 89

    with work_in_progress("Calculating the 30th Fibonacci number"):
        assert fib(30) == 1346269

    with work_in_progress("Calculating the 70th Fibonacci number"):
        assert fib(70) == 190392490709135

# Generated at 2022-06-21 12:24:13.482060
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Starting up")
    def _dummy_operation():
        return
    _ = _dummy_operation()

# Generated at 2022-06-21 12:24:21.165494
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import os
    obj = [1,2,'a','b']
    with tempfile.TemporaryDirectory() as tmpdirname:
        path = os.path.join(tmpdirname,'file.pickle')
        with work_in_progress("Saving file",):
            with open(path, "wb") as f:
                pickle.dump(obj, f)
        with work_in_progress("Loading file",):
            with open(path, "rb") as f:
                new_obj = pickle.load(f)
        assert(obj==new_obj)
if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:24:28.128207
# Unit test for function work_in_progress
def test_work_in_progress():
    path = "/tmp/wip_test.pkl"
    with work_in_progress("Loading file"):
        with open(path, "rb") as f:
            pickle.load(f)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(None, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:24:31.674870
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Counting to 1,000,000"):
        for _ in range(1000000):
            pass

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:24:36.592725
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:24:48.396078
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    # Work on a file
    obj = list(range(1000000))
    path = "test.tmp"

# Generated at 2022-06-21 12:24:51.974418
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(2)

# Generated at 2022-06-21 12:24:55.865941
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path: str):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path: str, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    a = torch.randn(10000, 10000)
    with work_in_progress("Loading file"):
        a = load_file("/home/yk/testfile")
    with work_in_progress("Saving file"):
        save_file("/home/yk/testfile", a)

# test_work_in_progress()

# Generated at 2022-06-21 12:25:03.623224
# Unit test for function work_in_progress
def test_work_in_progress():
    from .test import TestCase, run_tests

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    class WorkInProgressTest(TestCase):
        def test_load_file(self):
            obj = load_file("/path/to/some/file")

        def test_save_file(self):
            with save_file("/path/to/some/file"):
                pass

    run_tests()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:25:07.813458
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")

    time.sleep(0.001)
    obj = save_file("/path/to/some/file")

# Generated at 2022-06-21 12:25:18.808390
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import os
    import tempfile

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    data = {str(x): x for x in range(1000)}
    with tempfile.TemporaryDirectory() as tmp_path:
        save_file(os.path.join(tmp_path, "temp.dat"), data)
        data_ = load_file(os.path.join(tmp_path, "temp.dat"))
    assert data == data_

# Generated at 2022-06-21 12:25:25.920056
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function work_in_progress from module `trio_repl`.

    .. code:: python

        >>> from trio_repl import work_in_progress
        >>> import random
        >>> import time

        >>> def more_intense_task():
        ...     time.sleep(random.randrange(10) * 0.1)

        >>> # Work in progress
        ... with work_in_progress("Loading file"):
        ...     more_intense_task()
        Loading file... done. (0.11s)

        >>> # Work in progress
        ... with work_in_progress():
        ...     more_intense_task()
        Work in progress... done. (0.32s)

    """
    import trio_repl

# Generated at 2022-06-21 12:25:27.383294
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progressr"):
        time.sleep(1)

# Generated at 2022-06-21 12:25:37.882082
# Unit test for function work_in_progress
def test_work_in_progress():
    import math
    import time

    # Using as a context manager
    with work_in_progress("Calculating square root"):
        time.sleep(0.3)
        sqrt = math.sqrt(2)

    # Using as a decorator
    @work_in_progress("Calculating cube root")
    def cub_root(n):
        time.sleep(0.3)
        return math.pow(n, 1/3)

    print(f"sqrt(2) is {sqrt}")
    print(f"cub_root(2) is {cub_root(2)}")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:25:45.369215
# Unit test for function work_in_progress
def test_work_in_progress():
    obj = None

    # test function with work_in_progress as a decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("RWExecutor/work_in_progress.py")

    # test function with work_in_progress as a context manager
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:25:54.279549
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    output_file = os.path.join(os.path.expanduser("~"), "test.pickle")

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file(output_file)
    assert type(obj) is dict and len(obj) == 10

    with work_in_progress("Saving file"):
        with open(output_file, "wb") as f:
            pickle.dump({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6, 'g': 7, 'h': 8, 'i': 9, 'j': 10}, f)

# Generated at 2022-06-21 12:26:09.218515
# Unit test for function work_in_progress
def test_work_in_progress():
    class Container:
        def __init__(self):
            self.value = None

    @work_in_progress("Loading")
    def load_obj(path: str, obj: Container):
        with open(path, 'rb') as f:
            obj.value = pickle.load(f)

    @work_in_progress("Saving")
    def save_obj(path: str, obj: Container):
        with open(path, 'wb') as f:
            pickle.dump(obj, f)

    obj = Container()
    obj.value = "test"
    load_obj("test.pkl", obj)
    assert obj.value == None
    save_obj("test.pkl", obj)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:26:13.646635
# Unit test for function work_in_progress
def test_work_in_progress():
    def test(a: str = "test", b: int = 0):
        if b > 0:
            time.sleep(b)

    with work_in_progress("test"):
        test(b=1)

# Generated at 2022-06-21 12:26:15.819027
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Waiting for 2 seconds"):
        time.sleep(2)
    # Loading file... done. (2.00s)

# Generated at 2022-06-21 12:26:22.145754
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Testing work_in_progress"
    task = lambda: time.sleep(1)
    with work_in_progress(desc):
        task()


# TODO: Add `log` decorator:
# def log(func):
#     def wrapper(*args, **kwds):
#         # Log inputs
#         pass
#         func(*args, **kwds)
#         # Log outputs
#
#     return wrapper

# Generated at 2022-06-21 12:26:29.670682
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:33.025662
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress(desc="Test function")
    def func():
        time.sleep(3)
    func()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:26:40.694367
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test the function work_in_progress."""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open("/path/to/another/file", "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:42.999445
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(1)


# Test whole module
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:54.165772
# Unit test for function work_in_progress
def test_work_in_progress():
    import inspect
    import os
    import pickle
    import time
    with open("work_in_progress.py", "rb") as f:
        src = f.read()
    lines = src.decode("utf-8").splitlines()
    src = "\n".join(lines[lines.index("@contextlib.contextmanager")+1:])
    lines = src.splitlines()[:1]
    code = compile(src, "work_in_progress.py", "exec")
    obj = {}
    eval(code, obj)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)


# Generated at 2022-06-21 12:26:58.666377
# Unit test for function work_in_progress
def test_work_in_progress():

    def function_with_work_in_progress():
        with work_in_progress():
            time.sleep(0.1)

    with work_in_progress("Work in progress"):
        function_with_work_in_progress()
        time.sleep(0.1)

    return True

# Generated at 2022-06-21 12:27:14.799958
# Unit test for function work_in_progress
def test_work_in_progress():

    time.sleep(1)
    print()

    with work_in_progress("Work in progress"):
        time.sleep(2)

    print()

    @work_in_progress("Work in progress")
    def something():
        time.sleep(2)

    something()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:27:21.487590
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:27:28.630145
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle, pathlib

    def get_path(fname: str) -> pathlib.Path:
        return pathlib.Path(__file__).parent.resolve() / f"test_files/{fname}"

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file(get_path("data_obj.pkl"))
    assert obj == {'name': 'James', 'age': '26'}

    with work_in_progress("Saving file"):
        with open(get_path("data_obj.pkl"), "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work

# Generated at 2022-06-21 12:27:30.370324
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sleeping"):
        time.sleep(3)

# Generated at 2022-06-21 12:27:34.902706
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(1)
        print("Finished.")
    # Finished.
    # done. (1.00s)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:27:40.523304
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress."""
    begin_time = time.time()
    with work_in_progress():
        time.sleep(1)
    end_time = time.time()
    assert begin_time < end_time
    assert 1 - 0.1 <= end_time - begin_time <= 1 + 0.1

# Generated at 2022-06-21 12:27:54.259380
# Unit test for function work_in_progress
def test_work_in_progress():
    from io import StringIO
    import sys

    @work_in_progress("Evaluating")
    def slow_fn():
        time.sleep(0.05)
        return True

    string_io = StringIO()
    sys.stdout = string_io
    slow_fn()
    sys.stdout = sys.__stdout__

    assert string_io.getvalue() == "Evaluating... done. (0.05s)\n"

    with work_in_progress("Evaluating") as w:
        time.sleep(0.05)

    assert string_io.getvalue()[-16:-1] == "Evaluating... "
    assert string_io.getvalue()[-1:] == "\n"
    assert w.total_time >= 0.05


# Generated at 2022-06-21 12:28:05.067461
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def make_a_lot_of_work():
        time.sleep(0.01)
        return {"result": 1, "something": "else"}

    # Test a single result
    result = make_a_lot_of_work()
    assert result["result"] == 1
    assert result["something"] == "else"

    # Test a context manager
    with work_in_progress("Waiting for context manager to end"):
        time.sleep(0.01)

    # Test a context manager, no print
    @work_in_progress("")
    def should_not_print():
        time.sleep(0.01)
    should_not_print()

# Generated at 2022-06-21 12:28:12.314947
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    print()
    with work_in_progress("Saving file"):
        time.sleep(2)
    print()

    @work_in_progress("Loading file")
    def load_file():
        time.sleep(1)

    load_file()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:28:15.846849
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")


# Generated at 2022-06-21 12:28:42.578249
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        for idx in range(1000000):
            pass
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:28:45.856325
# Unit test for function work_in_progress
def test_work_in_progress():
    def dummy_func():
        time.sleep(1)

    with work_in_progress("Dummy func test"):
        dummy_func()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:28:52.210239
# Unit test for function work_in_progress
def test_work_in_progress():
    def foo():
        time.sleep(1)
    with work_in_progress("test #1"):
        pass
    with work_in_progress("test #2"):
        foo()
    with work_in_progress():
        foo()

# If called as a script
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:28:55.226160
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(0.2)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:29:00.742298
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == '__main__':
    test_work_in_progress()
    exit(0)

# Generated at 2022-06-21 12:29:04.629183
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile
    with tempfile.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, "test.pkl")
        with work_in_progress("Loading file"):
            with open(path, "wb") as f:
                time.sleep(3)
                f.write(b"test")
        with work_in_progress("Saving file"):
            with open(path, "rb") as f:
                time.sleep(4)
                buf = f.read()
        assert buf == b"test"

# Generated at 2022-06-21 12:29:09.842619
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Doing something")
    def f():
        time.sleep(1)

    # The following assertion will fail if we remove the trailing space
    # in print() statement of function work_in_progress() and hence,
    # will fail the test.
    assert len(StringIO().getvalue()) == 0


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:29:12.801307
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    # Saving file... done. (3.78s)

# Generated at 2022-06-21 12:29:22.665881
# Unit test for function work_in_progress
def test_work_in_progress():
    # Define a work in progress decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # Define a work in progress context manager
    def save_file(path, obj):
        with work_in_progress("Saving file"):
            with open(path, "wb") as f:
                pickle.dump(obj, f)

    # Try load and save a file
    obj = load_file("/path/to/some/file")
    save_file("/path/to/some/file", obj)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:29:25.204213
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(0.1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:30:16.181853
# Unit test for function work_in_progress
def test_work_in_progress():
    from io import BytesIO

    with work_in_progress("Loading file"):
        with open("test/test_ds.pickle", "rb") as f:
            ds = pickle.load(f)

    with work_in_progress("Saving file"):
        encode_ds = ds.encode(encoding='utf-8')
        with open("test/test_ds_encoded.pickle", "wb") as f:
            f.write(encode_ds)

    with work_in_progress("Loading file"):
        with open("test/test_ds_encoded.pickle", "rb") as f:
            ds = decode_ds = pickle.load(f, encoding="utf-8")

# Generated at 2022-06-21 12:30:18.380436
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def foo():
        import time
        time.sleep(0.5)

    foo()

# Generated at 2022-06-21 12:30:26.549770
# Unit test for function work_in_progress
def test_work_in_progress():
    # Data structure: nested dict
    d = {i: {j: {k: None for k in range(5)} for j in range(5)} for i in range(5)}

    with work_in_progress("Building nested dict"):
        for i in d.keys():
            for j in d[i].keys():
                for k in d[i][j].keys():
                    d[i][j][k] = i * j * k

    # Data structure: nested list
    l = [[[None for k in range(5)] for j in range(5)] for i in range(5)]

    with work_in_progress("Building nested list"):
        for i in range(5):
            for j in range(5):
                for k in range(5):
                    l[i][j][k] = i * j * k



# Generated at 2022-06-21 12:30:33.076049
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:30:38.252449
# Unit test for function work_in_progress
def test_work_in_progress():
    # In this test, we should see some "Work in progress...", "done.", and
    # time-consuming information.
    @work_in_progress("Test")
    def test_func(time_cost):
        time.sleep(time_cost)

    test_func(0.005)

    with work_in_progress("Test"):
        time.sleep(0.005)

# Generated at 2022-06-21 12:30:41.921951
# Unit test for function work_in_progress
def test_work_in_progress():
    begin_time = time.time()
    with work_in_progress("This is a test") as test:
        time.sleep(3)
    end_time = time.time()
    assert (end_time - begin_time) - 3 <= 0.05

# Generated at 2022-06-21 12:30:50.627758
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import os
    with tempfile.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, "tmpfile")
        @work_in_progress("Saving file")
        def save_file(obj, path):
            with open(path, "wb") as f:
                pickle.dump(obj, f)

        @work_in_progress("Loading file")
        def load_file(path):
            with open(path, "rb") as f:
                return pickle.load(f)

        obj = {"testing": True}
        save_file(obj, path)
        assert obj == load_file(path)

# Generated at 2022-06-21 12:30:51.320355
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress():
        time.sleep(0.01)

# Generated at 2022-06-21 12:30:53.829156
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test")
    def foo():
        time.sleep(1)
    foo()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:30:56.561285
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Counting to 100")
    def count_to_100():
        for i in range(100):
            pass

    count_to_100()

# Generated at 2022-06-21 12:32:34.842412
# Unit test for function work_in_progress
def test_work_in_progress():
    # Function version
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

    # Context manager version
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:32:37.839287
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1.23)
    def load_file(path: str):
        with work_in_progress("Loading file"):
            time.sleep(4.56)
    load_file("/path/to/file")

# Generated at 2022-06-21 12:32:47.482174
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path: str):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path: str, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    data = []
    for i in range(10_000):
        data.append((i, i**2, i**3))

    save_file("/tmp/data.pkl", data)
    data_reload = load_file("/tmp/data.pkl")
    assert data == data_reload