

# Generated at 2022-06-21 12:22:54.797354
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing work_in_progress...")

    time.sleep(0.01)
    with work_in_progress("testing..."):
        time.sleep(0.1)

    @work_in_progress("loading...")
    def load():
        time.sleep(0.1)
        return "done"

    assert(load() == "done")

    print("Testing work_in_progress... Done")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:22:57.269948
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def f():
        time.sleep(1)
    f()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:22:58.999737
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function work_in_progress."""
    assert 1 == 1

# Generated at 2022-06-21 12:23:09.135754
# Unit test for function work_in_progress
def test_work_in_progress():
    # First scenario
    with work_in_progress("Loading file"):
        time.sleep(2.5)

    # Second scenario
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")
    with open("/path/to/some/file", "wb") as f:
        pickle.dump(obj, f)

# Generated at 2022-06-21 12:23:13.379284
# Unit test for function work_in_progress
def test_work_in_progress():
    def foo():
        with open("resources.txt", "rb") as f:
            return pickle.load(f)

    with work_in_progress("Loading resources"):
        foo()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:22.591204
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Running tests for function work_in_progress...", end='', flush=True)
    import pickle
    filepath = "data/tmp.pkl"

    # Test 1: Decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # Test 2: Context manager
    with work_in_progress("Saving file"):
        with open(filepath, "wb") as f:
            pickle.dump("Hello world!", f)

    # Delete the test file
    import os
    os.remove(filepath)

    print("done.")

# Generated at 2022-06-21 12:23:31.732318
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Running test_work_in_progress...")

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("test/test_file.pkl")

    with work_in_progress("Saving file"):
        with open("test/test_file2.pkl", "wb") as f:
            pickle.dump(obj, f)

    with work_in_progress("Reading file"):
        with open("test/test_file2.pkl", "rb") as f:
            o = pickle.load(f)

    if o != obj:
        raise Exception("Objects different!")

    assert o == obj
    print("done.")

# Generated at 2022-06-21 12:23:36.378509
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
        return True

    obj = load_file("/path/to/some/file")
    assert obj, "The file must be loaded"
    with work_in_progress("Saving file"):
        with open("/tmp/work_in_progress.txt", "wb") as f:
            pickle.dump(True, f)
    assert os.path.exists("/tmp/work_in_progress.txt"), "The file must be saved"

#-- END Unit test for function work_in_progress --#


# Generated at 2022-06-21 12:23:38.387660
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work in progress"):
        time.sleep(0.5)

# Generated at 2022-06-21 12:23:42.522303
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def spend_time():
        time.sleep(1)
    spend_time()

    with work_in_progress():
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:51.373485
# Unit test for function work_in_progress
def test_work_in_progress():

    # Test with a function
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # Test with a code block
    with work_in_progress("Saving file"):
        time.sleep(0.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:23:56.426040
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:24:05.825282
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import os
    import numpy as np

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = np.random.random((101, 101))
    path = os.path.join(os.path.expanduser("~"), "tmp", "L3882l2Q.pkl")
    save_file(path, obj)
    assert np.all(load_file(path) == obj)
    os.remove(path)

# Generated at 2022-06-21 12:24:11.126436
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Waiting")
    def wait(x):
        time.sleep(x)
        return x

    @work_in_progress("Counting")
    def count(x):
        return sum(range(x))

    assert wait(3)
    assert count(100)


if __name__ == "__main__":
    with work_in_progress("Testing"):
        test_work_in_progress()

# Generated at 2022-06-21 12:24:18.173800
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import pickle

    # Function with decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # Load file
    obj = load_file("/path/to/some/file")

    # Function with context manager
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:24:20.944558
# Unit test for function work_in_progress
def test_work_in_progress():
    def dummy(arg1: int, arg2: str) -> None:
        time.sleep(0.2)

    with work_in_progress("Testing work_in_progress function"):
        dummy(1234, "Hello!")


# Generated at 2022-06-21 12:24:25.809471
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def f():
        for _ in range(1000000):
            pass
    f()
    with work_in_progress():
        for _ in range(1000000):
            pass

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:24:30.709623
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing the work_in_progress function"):
        for i in range(10):
            if i == 8:
                time.sleep(1)
        time.sleep(1)

# if __name__ == '__main__':
#     test_work_in_progress()

# Generated at 2022-06-21 12:24:39.134439
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    # Loading file
    filepath = "/path/to/some/file"
    data = "test"
    with open(filepath, 'wb') as f:
        pickle.dump(data, f)
    time.sleep(1)
    assert load_file(filepath) == data

    # Saving file
    save_file(filepath, "test2")
    time.sleep(1)

# Generated at 2022-06-21 12:24:47.166700
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    # Loading file... done. (3.52s)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    # Saving file... done. (3.78s)

# Generated at 2022-06-21 12:24:59.515612
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("../../utils/time.py")
    save_file(obj, "/tmp/out.pickle")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:25:02.745845
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress") as w:
        time.sleep(0.2)
        assert w is None



# Generated at 2022-06-21 12:25:08.876186
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Work in progress")
    def test_func(i):
        time.sleep(i)
        return i
    assert test_func(0.5) == 0.5
    assert test_func(1.2) == 1.2

    with work_in_progress("Work in progress"):
        time.sleep(0.5)

# Generated at 2022-06-21 12:25:13.775162
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("A")
    def a():
        time.sleep(1)

    @work_in_progress("B")
    def b():
        time.sleep(2)

    with work_in_progress("C"):
        time.sleep(3)

    a()
    b()
    print("d")

# Generated at 2022-06-21 12:25:17.269459
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(0.2)
    with work_in_progress():
        time.sleep(3)


# Test
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:25:24.563276
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import os
    import random

    with open("wip.test", "wb") as f:
        pickle.dump([random.randint(0, 1000) for _ in range(100000)], f)
    with work_in_progress("Loading file"):
        with open("wip.test", "rb") as f:
            pickle.load(f)
    with work_in_progress("Saving file"):
        with open("wip.test", "wb") as f:
            pickle.dump([], f)
    os.remove("wip.test")


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:25:26.455711
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:25:37.437718
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    path = "/Users/huaze/Desktop/test.pkl"
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
        obj = load_file(path)
    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    for _ in range(10):
        save_file(_, path)
    for _ in range(10):
        obj = load_file(path)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:25:38.807470
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Testing work_in_progress"):
        time.sleep(2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:25:49.226836
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile
    import os

    @work_in_progress("Write a temporary file")
    def write_temp_file(content):
        with tempfile.NamedTemporaryFile(mode="w") as f:
            f.write(content)
            return f.name

    @work_in_progress("Read a temporary file")
    def read_temp_file(path):
        with open(path, "r") as f:
            return f.read()

    @work_in_progress("Dump and load a class")
    def dump_load_object(obj):
        with tempfile.NamedTemporaryFile(mode="wb") as f:
            pickle.dump(obj, f)
            f.seek(0)
            return pickle.load(f)


# Generated at 2022-06-21 12:25:58.538024
# Unit test for function work_in_progress
def test_work_in_progress():
    from pickle import dumps, loads

    with work_in_progress("Generating random 1000x1000 matrix"):
        A = np.random.rand(1000, 1000)
    with work_in_progress("Pickling A"):
        pickled_obj = dumps(A)
    with work_in_progress("Unpickling A"):
        B = loads(pickled_obj)
    assert A.shape == B.shape, "Should be the same shape"
    assert np.allclose(A, B), "Should be the same value"


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:26:08.819148
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Tests the function work_in_progress"""
    print("Testing function work_in_progress...", end='', flush=True)
    sys.stdout = StringIO()

    with work_in_progress("Loading file A") as w:
        time.sleep(0.5)

    with work_in_progress("Loading file B"):
        time.sleep(0.5)

    sys.stdout = sys.__stdout__
    assert sys.stdout.getvalue().strip() == """\
Loading file A... done. (0.50s)
Loading file B... done. (0.50s)"""
    print(" done!")


if __name__ == "__main__":
    try:
        test_work_in_progress()
    except AssertionError:
        print("Test failed!")

# Generated at 2022-06-21 12:26:20.939969
# Unit test for function work_in_progress
def test_work_in_progress():
    import math
    import random

    # Timing function
    @work_in_progress("Computing Pi")
    def compute_pi():
        time.sleep(3)
        return math.pi

    pi = compute_pi()
    assert math.isclose(pi, 3.14159, rel_tol=0.001)

    # Timing context manager
    with work_in_progress("Waiting time"):
        time.sleep(3)

    # Timing a file operation
    path = "work_in_progress.pickle"
    pi_ref = random.uniform(3.1, 3.2)
    with open(path, "wb") as f:
        pickle.dump(pi_ref, f, protocol=4)


# Generated at 2022-06-21 12:26:29.915870
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")
    save_file(obj, "/path/to/some/file")
    print("This should be executed after \"Saving file... done.\"")

# Generated at 2022-06-21 12:26:37.662239
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    path = "/path/to/some/file"
    obj = np.random.random((10, 10))

    with work_in_progress("Saving file"):
        save_file(obj, path)

    assert np.all(obj == load_file(path))

# Generated at 2022-06-21 12:26:46.352484
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test function work_in_progress."""
    try:
        import colorama
    except ImportError:
        colorama = None

    if colorama is not None:
        colorama.init()

    def task_a():
        with work_in_progress("Task A"):
            time.sleep(0.500)

    def task_b():
        @work_in_progress(desc="Task B")
        def _task_b():
            time.sleep(0.300)

        return _task_b()

    def task_c():
        try:
            with work_in_progress("With a potentially long message"):
                time.sleep(0.5)
        except:
            pass


# Generated at 2022-06-21 12:26:53.697676
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            time.sleep(3)
            data = pickle.load(f)
        return data

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            return pickle.dump(obj, f)

# Generated at 2022-06-21 12:26:58.397024
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    with tempfile.TemporaryDirectory() as dirpath:
        path = os.path.join(dirpath, "test.bin")
        with work_in_progress("Saving file"):
            with open(path, "wb") as f:
                pickle.dump({"foo": "bar"}, f)

# Generated at 2022-06-21 12:26:59.260302
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3)

# Generated at 2022-06-21 12:27:10.319929
# Unit test for function work_in_progress
def test_work_in_progress():
    import unittest

    import sys

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    class TestWorkInProgress(unittest.TestCase):

        def setUp(self):
            self.string_to_write = """\
                Here is the string to be written.
                It contains several lines.
                It contains a lot of spaces, too.
                """

            self.temp_file = tempfile.NamedTemporaryFile(mode="w", dir="/tmp", delete=False)
            self.temp_file.write(self.string_to_write)
            self.temp_file.close()

        def tearDown(self):
            import os

# Generated at 2022-06-21 12:27:28.519353
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    @work_in_progress("Generating data")
    def generate():
        time.sleep(1.0)
        return {
            'key1': 'value1',
            'key2': 'value2',
            'key3': 'value3',
            'key4': 'value4',
        }


# Generated at 2022-06-21 12:27:34.592329
# Unit test for function work_in_progress
def test_work_in_progress():
    assert_output(work_in_progress, args=("Work in progress",), expected="Work in progress... done. (0.00s)")
    assert_output(work_in_progress, args=("Work in progress",), expected="Work in progress... done. (0.00s)")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:27:38.193173
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("This is a test")
    def test():
        time.sleep(0.123)

    test()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:27:45.421826
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("./test.pickle")
    assert type(obj) is dict
    assert obj["a"] == 0
    assert obj["b"] == 1

    with work_in_progress("Saving file"):
        with open("./test.pickle", "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:27:55.882566
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Run unit tests
if __name__ == "__main__":
    status = unittest.TextTestRunner().run(
        unittest.TestLoader().loadTestsFromModule(sys.modules[__name__])
    ).wasSuccessful()
    sys.exit(0 if status else 1)

# Generated at 2022-06-21 12:28:07.449405
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import os

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("./test_data/sample.bin")
    assert obj == [10, 20, 30]
    save_file(obj, "/tmp/sample2.bin")
    assert obj == load_file("/tmp/sample2.bin")
    os.remove("/tmp/sample2.bin")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:28:14.118352
# Unit test for function work_in_progress
def test_work_in_progress():
    d = {'a': [1, 2, 3], 'b': [4.5, 6.7]}

    def err():
        raise ValueError("oops")

    # Check with a context manager
    with work_in_progress("Loading file"):
        time.sleep(2)
        pickle.loads(pickle.dumps(d))

    # Check with a function
    @work_in_progress("Saving file")
    def load_file(path):
        time.sleep(2)
        pickle.loads(pickle.dumps(d))

    # Check with a function that raises an exception
    @work_in_progress("Loading file with error")
    def load_file_err(path):
        time.sleep(2)
        err()
        pickle.loads(pickle.dumps(d))



# Generated at 2022-06-21 12:28:21.505543
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        pass


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "-t", "--test", dest="run_test", action="store_true",
        help="run the unit test")
    parser.add_argument(
        "-v", "--verbose", dest="verbose", action="store_true",
        help="verbose mode")
    args = parser.parse_args()

    if args.run_test:
        test_work_in_progress()

    if args.verbose:
        logging.basicConfig(level=logging.DEBUG)
    else:
        logging.basicConfig(level=logging.INFO)

# Generated at 2022-06-21 12:28:25.106682
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(0.2)
    with work_in_progress("Work in progress (no flush)"):
        time.sleep(0.5)
        print("This should be flushed", flush=True)
    assert True

# Generated at 2022-06-21 12:28:29.827926
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:28:59.508076
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import pickle

    with work_in_progress("Testing work_in_progress"):
        # Testing pickle
        data = {}
        with open("test.pkl", "wb") as f:
            for i in range(10000):
                data[i] = random.random()
            pickle.dump(data, f)
        with open("test.pkl", "rb") as f:
            new_data = pickle.load(f)
        assert data == new_data

        # Testing time.sleep
        time.sleep(0.5)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:29:06.065583
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function work_in_progress."""

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


# vim: nu ft=python columns=120 :

# Generated at 2022-06-21 12:29:15.722737
# Unit test for function work_in_progress
def test_work_in_progress():
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as tmp_dir:
        file_path = os.path.join(tmp_dir, "test_file.pickle")
        test_obj = {
            "a": 1,
            "b": 2,
            "c": 3
        }
        with work_in_progress("Saving file"):
            with open(file_path, "wb") as f:
                pickle.dump(test_obj, f)
        with work_in_progress("Loading file"):
            with open(file_path, "rb") as f:
                obj = pickle.load(f)
        print(obj)
        assert obj == test_obj

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-21 12:29:24.420153
# Unit test for function work_in_progress
def test_work_in_progress():
    path = "/path/to/some/file"

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file(path)
    save_file(path, obj)

    with work_in_progress("Printing file"):
        print(open(path, "rb").read())

# Generated at 2022-06-21 12:29:28.200684
# Unit test for function work_in_progress
def test_work_in_progress():
    # Work for 0.1 seconds to be fast in unit tests
    with work_in_progress("Sleeping"):
        time.sleep(0.1)
    # Work for 0.2 seconds to be fast in unit tests
    with work_in_progress("Sleeping"):
        time.sleep(0.2)

# Generated at 2022-06-21 12:29:30.937006
# Unit test for function work_in_progress
def test_work_in_progress():
    _ = work_in_progress


# Local Variables:
# # tab-width:4
# # indent-tabs-mode:nil
# # End:
# vim: set syntax=python expandtab tabstop=4 shiftwidth=4:

# Generated at 2022-06-21 12:29:38.909414
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    
    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    
    obj = load_file("/path/to/some/file")
    save_file("/path/to/some/file")

# Generated at 2022-06-21 12:29:43.349824
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test with function decorator
    @work_in_progress("Loading file")
    def a_long_task(path):
        sleep(0.01)

    a_long_task("/")
    # Test with context manager
    with work_in_progress("Saving file"):
        sleep(0.01)

# Generated at 2022-06-21 12:29:45.977346
# Unit test for function work_in_progress
def test_work_in_progress():
    from timeit import default_timer as timer
    start = timer()

    time.sleep(0.04)
    with work_in_progress("Loading file") as file:
        time.sleep(0.03)

# Generated at 2022-06-21 12:29:52.308031
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile
    import os

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with tempfile.TemporaryDirectory() as tmpdir:
        test_data = {
            'key1': "I'm a string",
            'key2': 1,
            'key3': [1, 2, 3, 4],
            'key4': "I'm a string",
            'key5': 1,
        }

# Generated at 2022-06-21 12:30:39.339393
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Performing test") as w:
        print("  Testing should be seen")
        time.sleep(1)
        print("  This too")


# Generated at 2022-06-21 12:30:42.092472
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    t1 = time.time()
    with work_in_progress("loading..."):
        time.sleep(3)
    t2 = time.time()
    assert (t2 - t1) >= 3

# Generated at 2022-06-21 12:30:49.270698
# Unit test for function work_in_progress
def test_work_in_progress():
    x = np.random.random((100, 100))
    with work_in_progress("My first progress") as w:
        w.update(0.5)
        time.sleep(1)
        w.update(1)
    with work_in_progress("My second progress"):
        time.sleep(1)
        x ** 2
    with work_in_progress("My third progress"):
        time.sleep(2)
        x ** 3
    with work_in_progress():
        time.sleep(3)
        x ** 4

# Generated at 2022-06-21 12:30:50.972415
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress(r"Work in progress\n") as manager:
        time.sleep(0.1)

# Generated at 2022-06-21 12:30:51.839623
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.05)

# Generated at 2022-06-21 12:31:00.826972
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Testing fucntion work_in_progress."""

    def testfunction(vec, n):
        with work_in_progress("Processing list"):
            for x in range(n):
                time.sleep(0.1)
            for i in range(len(vec)):
                vec[i] += 1

    vec = [1, 2, 3, 4]
    testfunction(vec, 10)
    assert vec == [7, 8, 9, 10]

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:31:04.685015
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Do work"):
        time.sleep(1)

    with work_in_progress():
        time.sleep(1)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-21 12:31:09.139205
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-21 12:31:16.793853
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    >>> @work_in_progress("Loading file")
    ... def load_file(path):
    ...     with open(path, "rb") as f:
    ...         return pickle.load(f)
    ...
    ... obj = load_file("/path/to/some/file")
    Loading file... done. (3.52s)

    >>> with work_in_progress("Saving file"):
    ...     with open(path, "wb") as f:
    ...         pickle.dump(obj, f)
    Saving file... done. (3.78s)
    """

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 12:31:19.218976
# Unit test for function work_in_progress
def test_work_in_progress():
    # This function is tested by doctest
    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()