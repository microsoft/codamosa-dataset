

# Generated at 2022-06-11 21:49:49.005628
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work in progress")
    def test_work_in_progress_func():
        time.sleep(1)
    test_work_in_progress_func()
    with work_in_progress("Testing work in progress"):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:49:54.175169
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:49:57.013632
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:02.660231
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "r") as f:
            return pickle.load(f)
    obj = load_file("../data/test.txt")

# Generated at 2022-06-11 21:50:09.412185
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test with a function decorator
    @work_in_progress("Loading file")
    def function():
        time.sleep(0.123)

    function()

    # Test with a with-statement context manager
    with work_in_progress("Saving file"):
        time.sleep(0.123)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:11.769988
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Executing code"):
        time.sleep(2)

# Generated at 2022-06-11 21:50:17.053343
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:50:27.088949
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    TEST_FILE_PREFIX = "file"
    TEST_FILE_NAME = f"{TEST_FILE_PREFIX}.pkl"
    TEST_FILE_PATH = os.path.join(tempfile.gettempdir(), TEST_FILE_NAME)
    TEST_OBJECT = {"a": 1, "b": 2.5, "c": "str"}


# Generated at 2022-06-11 21:50:34.722647
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "test_data/test_work_in_progress/test_file.pkl"
    obj = load_file(path)
    assert obj == "Hello world!"

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:45.197145
# Unit test for function work_in_progress
def test_work_in_progress():
    from tempfile import TemporaryDirectory
    import pickle

    # Create test file
    with TemporaryDirectory() as dirname:
        with open(dirname + "/test.pkl", "wb") as f:
            pickle.dump(["a", "b", "c"], f)

        # Test pickle.load
        with work_in_progress("Loading file"):
            with open(dirname + "/test.pkl", "rb") as f:
                obj = pickle.load(f)

        assert obj == ["a", "b", "c"]

        # Test pickle.dump
        with work_in_progress("Saving file"):
            with open(dirname + "/test2.pkl", "wb") as f:
                pickle.dump(obj, f)

        # Compare files

# Generated at 2022-06-11 21:50:51.247898
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Unit test for work_in_progress")
    def get_the_answer():
        time.sleep(0.5)
        return 42

    assert get_the_answer() == 42

# Generated at 2022-06-11 21:50:59.756634
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path: str):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path: str, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with work_in_progress("Loading"):
        obj = load_file("tests/data/int150")

    with work_in_progress("Saving"):
        save_file("tests/data/int150-copy", obj)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:04.286528
# Unit test for function work_in_progress
def test_work_in_progress():
    def fibo(n):
        if n < 2:
            return 1
        return fibo(n-1) + fibo(n-2)

    with work_in_progress("Computing Fibonacci sequence"):
        fibo(40)

# Generated at 2022-06-11 21:51:06.993946
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Waiting for 2 seconds"):
        time.sleep(2)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:51:08.887614
# Unit test for function work_in_progress
def test_work_in_progress():
    # TODO: I don't know how to test this one.
    pass

# Generated at 2022-06-11 21:51:13.719401
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    with work_in_progress("Saving file"):
        time.sleep(1.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:16.705414
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing"):
        time.sleep(0.5)

    @work_in_progress("Testing")
    def a():
        time.sleep(0.5)
        return 1
    assert a() == 1

# Generated at 2022-06-11 21:51:20.612072
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile
    import os

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with tempfile.NamedTemporaryFile("wb", delete=False) as f:
            pickle.dump({"name": "foo"}, f)

    obj = load_file(f.name)
    assert obj["name"] == "foo"

    os.remove(f.name)

# Generated at 2022-06-11 21:51:27.735386
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # path must be a valid file path
    path = os.path.abspath(__file__)
    obj = load_file(path)
    assert os.path.isabs(path)

    with work_in_progress("Saving file"):
        with open(path, "w") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:30.559934
# Unit test for function work_in_progress
def test_work_in_progress():
    print(
        f'test_work_in_progress: {"pass" if True else "fail"}')

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:51:38.025469
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(2)
        with work_in_progress("Loading sub_file"):
            time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:40.118459
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def test():
        time.sleep(3)

    test()

# Generated at 2022-06-11 21:51:43.303114
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        with open("pickle_test.txt", "rb") as f:
            x = pickle.load(f)
    assert True == True

# Generated at 2022-06-11 21:51:48.249499
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    import sys

    with io.StringIO() as buf, contextlib.redirect_stdout(buf):
        with work_in_progress("This is a test"):
            time.sleep(1)
    assert buf.getvalue().strip() == "This is a test... done. (1.00s)"

# Generated at 2022-06-11 21:51:52.815446
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(random.choice([0.01, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]))

# Generated at 2022-06-11 21:51:55.754143
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""No unit test is needed here, since the function is mainly used as a
    decorator."""
    pass

# Generated at 2022-06-11 21:52:03.142822
# Unit test for function work_in_progress
def test_work_in_progress():
    # Function
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    # Context manager
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    # Manually start/stop
    with work_in_progress("Computing something"):
        time.sleep(0.1)

# Generated at 2022-06-11 21:52:15.382076
# Unit test for function work_in_progress
def test_work_in_progress():
    from io import BytesIO
    import pickle
    import psutil
    obj = {
        "int": 1,
        "float": 1.2345,
        "string": "string",
        "bytes": b"bytes",
        "dict": {"dict": 1},
        "list": [1, 2, 3],
    }
    with work_in_progress("Saving file"):
        f = BytesIO()
        pickle.dump(obj, f)
        data = f.getvalue()
    with work_in_progress("Loading file"):
        f = BytesIO(data)
        obj_ = pickle.load(f)
    assert obj == obj_

    proc = psutil.Process()
    with work_in_progress("Memory consumption"):
        memory = proc.memory_info().rss


# Generated at 2022-06-11 21:52:18.656092
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    with work_in_progress("Loading file"):
        time.sleep(0.5)
    with work_in_progress("Loading file"):
        time.sleep(2.5)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:52:25.104234
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    with tempfile.NamedTemporaryFile("wb") as f:
        obj = {"a": 0, "b": 1}
        pickle.dump(obj, f)
        obj_loaded = load_file(f.name)
    assert obj == obj_loaded


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:52:32.660826
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test work_in_progress")
    def test_func():
        time.sleep(0.6)
    test_func()



# Generated at 2022-06-11 21:52:36.085222
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading"):
        print("Hello")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:37.555670
# Unit test for function work_in_progress
def test_work_in_progress():
    # TODO: Write this test
    pass

# Generated at 2022-06-11 21:52:39.290343
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test work_in_progress()") as p:
        time.sleep(1)

# Generated at 2022-06-11 21:52:46.005101
# Unit test for function work_in_progress
def test_work_in_progress():
    def test_func(n):
        time.sleep(n)

    with work_in_progress("1"):
        time.sleep(1)
    with work_in_progress("2"):
        time.sleep(2)

    @work_in_progress("3")
    def f():
        time.sleep(3)

    f()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:54.446009
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import pickle

    def _load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def _save_file(path, obj):
        with open(path, "wb") as f:
            return pickle.dump(obj, f)

    with work_in_progress("Loading file"):
        obj = _load_file("/tmp/file")
    
    with work_in_progress("Saving file"):
        _save_file("/tmp/file", obj)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)


# Generated at 2022-06-11 21:52:59.744206
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    load_file__wip = work_in_progress(load_file)

    with work_in_progress("Loading file"):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:53:00.551978
# Unit test for function work_in_progress
def test_work_in_progress():
    assert True

# Generated at 2022-06-11 21:53:06.395269
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:53:10.093005
# Unit test for function work_in_progress
def test_work_in_progress():
    def test_func():
        for i in range(1000000):
            pass
    with work_in_progress("Testing work_in_progress"):
        test_func()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:53:22.323490
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    with work_in_progress("Saving file"):
        time.sleep(2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:53:28.285404
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function :func:`work_in_progress`."""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)



# Generated at 2022-06-11 21:53:30.594688
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Working hard"):
        time.sleep(2)

# Generated at 2022-06-11 21:53:33.043938
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3.52)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:53:36.162900
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(0.1)
    exit()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:53:38.054154
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(1)
    assert True

# Generated at 2022-06-11 21:53:43.053952
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "test.pkl"
    with open(path, "wb") as f:
        pickle.dump(np.random.random((100, 100)), f)
    _ = load_file(path)

# Generated at 2022-06-11 21:53:45.636269
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Looping")
    def work():
        for i in range(1000):
            i**2

    work()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:53:47.470616
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(2)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:53:50.809592
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(0.2)
        pass

# Generated at 2022-06-11 21:54:13.796108
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(1)

# Generated at 2022-06-11 21:54:18.198209
# Unit test for function work_in_progress
def test_work_in_progress():
    # Check whether the basic usage of the function you want to test is correct
    with work_in_progress(desc="Testing") as tester:
        time.sleep(1)
    
    print(tester) # None

# Test the unit test function
if __name__ == "__main__":
    test_work_in_progress()

# import time
# import contextlib
# @contextlib.contextmanager
# def timer(name=None):
#     t0 = time.time()
#     yield
#     print('[{}] done in {} s'.format(name, time.time() - t0))

# Generated at 2022-06-11 21:54:23.807735
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(1)
    def w():
        with work_in_progress():
            time.sleep(1)
    w()
    @work_in_progress()
    def ww():
        time.sleep(1)
    ww()
    with work_in_progress():
        time.sleep(1)

# Generated at 2022-06-11 21:54:27.883747
# Unit test for function work_in_progress
def test_work_in_progress():
    # pylint: disable=W0612
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io
    import io


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:35.675784
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Work in progress")
    def time_consuming_function(path):
        for i in range(100):
            with open(path, 'rb') as f:
                pickle.load(f)

    with work_in_progress("Work in progress"):
        for i in range(100):
            with open('/mnt/d/Users/piers/OneDrive/work/TUDelft/Deep_learning_and_beyond/assignment_2/data/dataset_mnist_test.pkl', 'rb') as f:
                pickle.load(f)

# Generated at 2022-06-11 21:54:38.322129
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Waiting"):
        time.sleep(3)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:42.078492
# Unit test for function work_in_progress
def test_work_in_progress():
    for i in range(5):
        with work_in_progress(f"work in progress {i}"):
            time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:43.526651
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(1)

# Generated at 2022-06-11 21:54:55.712195
# Unit test for function work_in_progress
def test_work_in_progress():
    def fail():
        raise RuntimeError

    with work_in_progress():
        time.sleep(.5)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with open(__file__, "rb") as f:
        this_script = pickle.load(f)

    with work_in_progress("Loading file"):
        with open(__file__, "rb") as f:
            this_script = pickle.load(f)

    @work_in_progress(desc="Loading this_script")
    def load_this_script():
        with open(__file__, "rb") as f:
            return pickle.load(f)


# Generated at 2022-06-11 21:55:03.720961
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    >>> @work_in_progress("Loading file")
    ... def load_file(path):
    ...     with open(path, "rb") as f:
    ...         return pickle.load(f)
    ...
    ... obj = load_file("test_work_in_progress.pickle")
    Loading file... done. (0.00s)

    >>> with work_in_progress("Saving file"):
    ...     with open(path, "wb") as f:
    ...         pickle.dump(obj, f)
    Saving file... done. (0.00s)
    """
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-11 21:55:59.353121
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import os

    file_name = "/tmp/test_work_in_progress.pkl"
    file_size = 1024 * 1024

    # Make sure the test file doesn't already exist
    if os.path.isfile(file_name):
        raise RuntimeError("Test file already exists: " + file_name)

    # Generate a test file
    @work_in_progress("Generate test file")
    def generate_file():
        with open(file_name, "wb") as f:
            for _ in range(file_size):
                f.write(bytes([random.randint(0, 255)]))

    # Try to read the file

# Generated at 2022-06-11 21:56:03.973766
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def test_code_block():
        time.sleep(1)

    test_code_block()

    with work_in_progress("Testing work_in_progress"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:09.198604
# Unit test for function work_in_progress
def test_work_in_progress():
    import sys
    import time
    import os
    import glob

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    def test_function():
        for i in range(100):
            pass

    with work_in_progress("Loading file"):
        load_file(os.path.join(os.path.dirname(os.path.abspath(__file__)), "../setup.py"))

# Generated at 2022-06-11 21:56:12.140832
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Counting to 10"):
        time.sleep(0.1)

    assert True

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:56:13.826695
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work in progress"):
        time.sleep(0.1)
test_work_in_progress()

# Generated at 2022-06-11 21:56:22.847773
# Unit test for function work_in_progress
def test_work_in_progress():
    with mock.patch('builtins.print') as mock_print:
        mock_print.return_value = None
        with mock.patch('time.time') as mock_time:
            mock_time.side_effect = [0, 5]
            with work_in_progress("Test"):
                time.sleep(5)

        mock_print.assert_has_calls([
            mock.call("Test... "),
            mock.call(f"done. (5.00s)"),
        ])

# Generated at 2022-06-11 21:56:29.234808
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import threading
    from concurrent.futures import ThreadPoolExecutor

    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.23)

    def some_function():
        with work_in_progress("This is a test function"):
            time.sleep(0.23)

    some_function()

    @work_in_progress("This is a test function")
    def some_function_decorated():
        time.sleep(0.23)

    some_function_decorated()

    def aynsc_function():
        time.sleep(0.23)

    executor = ThreadPoolExecutor(max_workers=16)
    futures = [executor.submit(aynsc_function) for i in range(16)]

# Generated at 2022-06-11 21:56:36.674291
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path: str):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:42.175706
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump([1, 2, 3, 4], f)

    load_file(__file__), save_file(__file__)
    # Loading file... done. (0.01s)
    # Saving file... done. (0.00s)

# Generated at 2022-06-11 21:56:52.272495
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile

    @work_in_progress("Generating random pickle")
    def gen_random_pickle(path):
        obj = {str(i): i for i in range(int(1e5))}
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    with tempfile.TemporaryDirectory() as tmp:
        gen_random_pickle(tmp + "/test.pickle")

    @work_in_progress("Saving random pickle")
    def save_random_pickle(path):
        obj = {str(i): i for i in range(int(1e5))}
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:58:31.524854
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import contextlib
    import tempfile
    import random

    def pkl_load(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def pkl_save(path, obj):
        with open(path, "wb") as f:
             pickle.dump(obj, f)

    def test_work_in_progress(f):
        _, path = tempfile.mkstemp(".pkl")

        def test_context_manager(use_yield):
            if use_yield:
                with f("Loading file"):
                    obj = pkl_load(path)
                assert obj == 42
            else:
                obj = f("Loading file", pkl_load)(path)
                assert obj == 42


# Generated at 2022-06-11 21:58:37.780142
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    with work_in_progress("Loading file"):
        with open(__file__, "rb") as f:
            pickle.load(f)

    with work_in_progress("Saving file"):
        with open(__file__, "rb") as f, open("/dev/null", "wb") as f2:
            pickle.dump(f.read(), f2)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:58:50.420601
# Unit test for function work_in_progress
def test_work_in_progress():
    # case 1
    # test if the output is correct
    with work_in_progress("Loading file"):
        time.sleep(5)
    # case 1 expected output
    # "Loading file... done. (5.00s)"
    # case 2
    # test if nested work_in_progress has no effect
    with work_in_progress("Loading file"):
        with work_in_progress("Loading file"):
            time.sleep(5)
    # case 2 expected output
    # "Loading file... done. (5.00s)"
    # case 3
    # test if the function with work_in_progress decorator works
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(5)
    load_file("/path/to/some/file")
    #

# Generated at 2022-06-11 21:59:00.008825
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    >>> @work_in_progress("Loading file")
    ... def load_file(path):
    ...     with open(path, "rb") as f:
    ...         return pickle.load(f)
    ...
    ... obj = load_file("/path/to/some/file")
    Loading file... done. (3.52s)
    >>> with work_in_progress("Saving file"):
    ...     with open(path, "wb") as f:
    ...         pickle.dump(obj, f)
    Saving file... done. (3.78s)
    """
    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:59:01.689977
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1)
    assert 1

# Generated at 2022-06-11 21:59:13.751540
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile

    def must_not_raise(func, *args, **kwargs):
        func(*args, **kwargs)

    # Test call as context manager
    with work_in_progress("Testing context manager"):
        time.sleep(1)
    # Test call as function
    @work_in_progress("Testing function")
    def func():
        time.sleep(1)
    func()
    # Test with error
    with pytest.raises(Exception):
        with work_in_progress("Error"):
            raise Exception()
    # Test with object that has __enter__ and __exit__

# Generated at 2022-06-11 21:59:18.335803
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3.52)
    with work_in_progress():
        time.sleep(3.78)

# Script execution
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:59:24.335871
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3)
    with work_in_progress("Saving file"):
        time.sleep(3.78)

if __name__ == "__main__":
    if len(sys.argv) > 1:
        if sys.argv[1] == "--test":
            test_work_in_progress()
    else:
        with work_in_progress("This program does nothing"):
            time.sleep(3.14)

# Generated at 2022-06-11 21:59:29.987819
# Unit test for function work_in_progress
def test_work_in_progress():
    import datetime
    begin_time = datetime.datetime.now()
    with work_in_progress("Test work in progress..."):
        result = 0
        for i in range(1, 1000000):
            result += i
        result += 1
    time_consumed = datetime.datetime.now() - begin_time
    print(time_consumed)

# Generated at 2022-06-11 21:59:32.592834
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sleep"):
        time.sleep(1)

if __name__ == '__main__':
    test_work_in_progress()