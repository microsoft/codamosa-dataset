

# Generated at 2022-06-11 21:49:54.151823
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import os
    import tempfile
    from pprint import pformat

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with tempfile.TemporaryDirectory() as tmpdir:
        obj = {"a": [1, 2, 3], "b": {"c": "d"}}
        path = os.path.join(tmpdir, "test.pickle")
        save_file(obj, path)
        obj_ret = load_file(path)
        assert obj == obj_

# Generated at 2022-06-11 21:49:57.013382
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress"""
    with work_in_progress("Test for function work_in_progress"):
        time.sleep(0.1)

# Generated at 2022-06-11 21:50:05.324033
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(5)
    with work_in_progress("Subtracting a list"):
        time.sleep(3)
        print("subtracted a list")
    with work_in_progress("Loading file"):
        time.sleep(3.5)
    with work_in_progress("Saving file"):
        time.sleep(3.78)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:09.922983
# Unit test for function work_in_progress
def test_work_in_progress():
    with pytest.raises(UnboundLocalError):
        with work_in_progress():
            print(x)
        print("should not reach here")

    def f():
        with work_in_progress("Work in progress"):
            pass
    f()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:16.291693
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Work in progress")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("./test_file.pickle")
    assert obj == {
        "lorem": "ipsum",
        "dolor": [1, 2, 3, 4, 5, 6, 7],
    }

    with work_in_progress("Saving file"):
        with open("./test_file.pickle", "wb") as f:
            pickle.dump(obj, f)

    print("All test passed!")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:19.890584
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Simple task"):
        time.sleep(0.2)

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    with work_in_progress("Loading file"):
        load_file("./test_data/test_word2vec.pickle")

    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    with work_in_progress("Saving file"):
        save_file("./test_data/test_word2vec.pickle", {"1": 1, "2": 2, "3": 3})

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:29.341584
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import shutil
    import tempfile
    from .run_test_module import run_test_module


# Generated at 2022-06-11 21:50:38.258425
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import pickle
    import shutil
    import tempfile

    def _test(desc: str, task, obj):
        with work_in_progress(desc):
            task()
        assert task() == obj

    with tempfile.TemporaryDirectory() as tempdir:
        # Test for function
        def _load_obj():
            with open(os.path.join(tempdir, "obj.pkl"), "rb") as f:
                return pickle.load(f)

        _test("Loading file", _load_obj, {"key": "value"})
        with open(os.path.join(tempdir, "obj.pkl"), "wb") as f:
            pickle.dump({"key": "value"}, f)

        # Test for context

# Generated at 2022-06-11 21:50:43.541285
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:50:48.788548
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    import pickle

    obj = {
        "hello": "world",
        "timestamp": time.time(),
    }
    with io.BytesIO() as f:
        pickle.dump(obj, f)
        f.seek(0)
        with work_in_progress("Loading file"):
            data = pickle.load(f)
        with work_in_progress("Saving file"):
            pickle.dump(data, f)

# Generated at 2022-06-11 21:50:54.867063
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

# Generated at 2022-06-11 21:50:58.253080
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1.2)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:01.205726
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test work_in_progress")
    def test():
        time.sleep(1)
    test()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:05.127767
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:13.463407
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file") as w:
        with open("/dev/null", "w") as f:
            for i in range(10000):
                f.write("0" * 50000)
    assert w is None
    assert "Saving file" in sys.stdout.getvalue()
    assert "done" in sys.stdout.getvalue()



# Generated at 2022-06-11 21:51:20.145919
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    print()
    with work_in_progress():
        time.sleep(1)
    print()
    with work_in_progress("Saving file"):
        time.sleep(1)
    print()
    with work_in_progress("Loading file"):
        time.sleep(1)
        with work_in_progress("Fetching data"):
            time.sleep(1)
        time.sleep(1)


# Generated at 2022-06-11 21:51:24.594328
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.1)
    with work_in_progress("Saving file"):
        time.sleep(0.2)

if __name__ == "__main__":
    import doctest
    doctest.testmod()
    test_work_in_progress()

# Generated at 2022-06-11 21:51:30.301324
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress."""
    for func in [
        lambda: time.sleep(1),
        lambda: print("Hello"),
    ]:
        with work_in_progress("Test function"):
            func()

# Generated at 2022-06-11 21:51:33.133726
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress(desc="Test work_in_progress")
    def dummy_func():
        time.sleep(1)
    dummy_func()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:41.332903
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    
    filepath = "/tmp/test_work_in_progress"
    obj = ["a", "b", "c"]
    save_file(filepath, obj)
    assert load_file(filepath) == obj


# Generated at 2022-06-11 21:51:52.720003
# Unit test for function work_in_progress
def test_work_in_progress():
    with CaptureOutput(relay=False) as capturer:
        with work_in_progress("This is a test"):
            time.sleep(0.05)

    captured = capturer.get_text()
    assert captured == "This is a test... done. (0.05s)\n"

if __name__ == "__main__":
    import sys
    sys.exit(pytest.main(["-qq", "-s", "--tb=native"] + sys.argv))

# Generated at 2022-06-11 21:52:03.763774
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile
    import os

    path = os.path.join(tempfile.mkdtemp(), "test_file")
    obj = {"this": "is", "a": "test", "file": 47}

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    save_file(path)
    res = load_file(path)

    assert res == obj, "Unexpected result from load_file"
    assert os.remove(path), "Could not delete test file"



# Generated at 2022-06-11 21:52:09.154654
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        pass
    @work_in_progress("Loading file")
    def load_file(path):
        pass

    assert True


if __name__ == "__main__":
    from doctest import testmod
    testmod()

# Generated at 2022-06-11 21:52:16.277147
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test the work_in_progress context manager, using a sleep function."""
    # Test using function
    @work_in_progress("Loading file")
    def load_file(delay: float = 0.0) -> int:
        time.sleep(delay)
        return 42

    assert load_file(1.0) == 42

    # Test using context manager
    with work_in_progress("Saving file"):
        time.sleep(0.5)

    print("Test passed.")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:23.401402
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Slow process #1")
    def slow_process_1():
        time.sleep(0.5)

    @work_in_progress("Slow process #2")
    def slow_process_2():
        time.sleep(0.6)

    slow_process_1()
    slow_process_2()
    with work_in_progress("Slow process #3"):
        time.sleep(0.7)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:30.286988
# Unit test for function work_in_progress
def test_work_in_progress():
    from time import sleep

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":

    test_work_in_progress()

# Generated at 2022-06-11 21:52:32.541371
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:39.248075
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:52:47.581468
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing function")
    def func():
        with work_in_progress("with work_in_progress()"):
            time.sleep(1)
            print("sub_func()...", end='', flush=True)
            time.sleep(1)
            print("done.")

        time.sleep(1)
        print("sub_func()...", end='', flush=True)
        time.sleep(1)
        print("done.")

    func()


if __name__ == "__main__":
    # Import test functions here
    test_work_in_progress()

# Generated at 2022-06-11 21:52:55.735928
# Unit test for function work_in_progress
def test_work_in_progress():
    import unittest
    import os
    import sys
    import errno

    import numpy as np

    class TestWorkInProgress(unittest.TestCase):
        def setUp(self):
            self.stdout = sys.stdout
            self.assertIsNone(os.environ.get("DO_NOT_REDIRECT_STDOUT"))
            self.temp_filename = "_test.out"

        def tearDown(self):
            if os.path.exists(self.temp_filename):
                os.remove(self.temp_filename)

        def _test_work_in_progress(self, desc: str, expected_text: str):
            sys.stdout = open(self.temp_filename, "w")

            value = np.random.rand(100, 100)


# Generated at 2022-06-11 21:53:13.077000
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("test.pkl")
    with work_in_progress("Saving file"):
        with open("test.pkl", "wb") as f:
            pickle.dump(obj, f)
    # with work_in_progress("Loading file... ", end=": "):
    #     time.sleep(2)
    #     print("done.")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:53:20.942054
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import pickle
    with work_in_progress("Waiting"):
        time.sleep(1)
    @work_in_progress("Serializing")
    def save_obj(obj):
        with open("/tmp/test_work_in_progress", "wb") as f:
            pickle.dump(obj, f)
    obj = {'a': [1, 2, 3], 'b': 'foo'}
    save_obj(obj)


# Doctest
if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:53:23.974468
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:53:27.661319
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    with work_in_progress("Loading file"):
        time.sleep(3)

    @work_in_progress("Loading file")
    def load_file():
        time.sleep(3)

    load_file()

# Generated at 2022-06-11 21:53:39.160439
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import shutil
    import subprocess
    import tempfile

    with tempfile.TemporaryDirectory() as folder:
        file_path = os.path.join(folder, "test.txt")

        with open(file_path, 'w') as f:
            f.write("Hello, World!")

        with work_in_progress("Loading file"):
            with open(file_path, 'r') as f:
                f.read()

        with work_in_progress("Saving file"):
            with open(file_path, 'w') as f:
                f.write("Hello, World!")

        with work_in_progress("Deleting file"):
            os.remove(file_path)


# Generated at 2022-06-11 21:53:45.454852
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import pathlib

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    path = pathlib.Path(__file__).parent / "data" / "test_work_in_progress.pickle"
    obj = load_file(path)
    print(obj)

    path = pathlib.Path(__file__).parent / "data" / "test_work_in_progress_out.pickle"
    save_file(obj, path)
    print(obj)




# Generated at 2022-06-11 21:53:46.796285
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(0.5)

# Generated at 2022-06-11 21:53:55.866159
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test :func:`~util.timer.work_in_progress`
    """
    def _test_case(desc: str, sleep_time: float):
        begin_time = time.time()
        with work_in_progress(desc) as w:
            time.sleep(sleep_time)
        end_time = time.time()

        return end_time - begin_time

    for desc, sleep_time in itertools.product(
            [None, "", "Task"],
            [0.01, 2.3, 5.0]):
        assert abs(_test_case(desc, sleep_time) - sleep_time) < 0.05

# Generated at 2022-06-11 21:54:05.990071
# Unit test for function work_in_progress
def test_work_in_progress():
    # Import modules
    import time
    import pickle

    # Test with context manager
    with work_in_progress("Testing context manager"):
        time.sleep(1)
    # Testing context manager... done. (1.00s)

    # Test with function decorator
    @work_in_progress("Testing function decorator")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "./test_file"
    obj = {i: i for i in range(100)}
    with open(path, "wb") as f:
        pickle.dump(obj, f)

    obj2 = load_file(path)
    # Testing function decorator... done. (2.41s)

    # Clean up
    import os
    os

# Generated at 2022-06-11 21:54:08.827190
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing a slow process"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:30.148960
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Some task")
    def test():
        time.sleep(0.1)

    test()

# Generated at 2022-06-11 21:54:36.225521
# Unit test for function work_in_progress
def test_work_in_progress():
    import contextlib
    import time

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("some/file")

    with work_in_progress("Saving file"):
        with open("other/file", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:54:41.254152
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:54:45.839752
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Counting to 10000000"):
        sum(range(1000_000))

    def func():
        with work_in_progress("Counting to 1000"):
            sum(range(1000))

    func()

#test_work_in_progress()

# Generated at 2022-06-11 21:54:49.473980
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test work_in_progress")
    def test():
        time.sleep(1.1)
    test()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:54:54.395120
# Unit test for function work_in_progress
def test_work_in_progress():

    # Test the function
    with work_in_progress("Loading file"):
        time.sleep(1)
    time.sleep(0.1)
    with work_in_progress("Saving file"):
        time.sleep(1)

# Generated at 2022-06-11 21:55:00.179223
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(1)
    with work_in_progress("My work"):
        time.sleep(1.5)
    with work_in_progress("Some work"):
        pass
    with work_in_progress():
        pass

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:55:02.281778
# Unit test for function work_in_progress
def test_work_in_progress():
    def f():
        time.sleep(3)
        return 123

    with work_in_progress("Testing"):
        product = f()

    assert product == 123

# Generated at 2022-06-11 21:55:05.864841
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Task #1")
    def task1():
        time.sleep(0.5)

    @work_in_progress("Task #2")
    def task2():
        time.sleep(0.5)

    with work_in_progress("Task #3"):
        time.sleep(0.5)

###############################################################################

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:55:14.270850
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    n = 100
    with work_in_progress("Saving file"):
        with open("temp.txt", "wb") as f:
            pickle.dump([i for i in range(n)], f)

    data = load_file("temp.txt")
    assert len(data) == n

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:05.278842
# Unit test for function work_in_progress
def test_work_in_progress():
    import sys
    import os
    import pickle
    import tempfile
    from contextlib import redirect_stdout

    obj = dict(a=1, b=2, c=3)
    with tempfile.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, "data.pk")
        obj_loaded = None
        
        with open(os.devnull, 'w') as fd:
            with redirect_stdout(fd):
                with work_in_progress("Testing work_in_progress..."):
                    with open(path, "wb") as f:
                        pickle.dump(obj, f)
                    time.sleep(1)
                    with open(path, "rb") as f:
                        obj_loaded = pickle.load(f)

        assert obj == obj_loaded



# Generated at 2022-06-11 21:56:09.645350
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test function work_in_progress."""
    with work_in_progress("Processing in progress"):
        time.sleep(0.6)
        print("Processing complete.")

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:56:16.895528
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file():
        with open("test_work_in_progress.txt", "rb") as f:
            return pickle.load(f)

    obj = load_file()
    assert obj == "test_work_in_progress"

    with work_in_progress("Saving file"):
        with open("test_work_in_progress.txt", "wb") as f:
            pickle.dump("test_work_in_progress", f)

    os.remove("test_work_in_progress.txt")

# Generated at 2022-06-11 21:56:18.055625
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def sleep():
        time.sleep(3.0)
    sleep()


if __name__ == "__main__":

    test_work_in_progress()

# Generated at 2022-06-11 21:56:26.916574
# Unit test for function work_in_progress
def test_work_in_progress():
    import sys
    import io
    import unittest
    import doctest

    class TestWorkInProgress(unittest.TestCase):
        def setUp(self):
            self.stdout = sys.stdout
            sys.stdout = self.buf = io.StringIO()

        def tearDown(self):
            sys.stdout = self.stdout

        def test_work_in_progress(self):
            with work_in_progress("Saving file"):
                time.sleep(1)
            self.assertEqual(self.buf.getvalue(), "Saving file... done. (1.00s)\n")

    unittest.main(module=__name__, buffer=True, exit=False)

# Generated at 2022-06-11 21:56:28.299533
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(1)

# Generated at 2022-06-11 21:56:36.587575
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test the work_in_progress context manager."""
    with work_in_progress("Tasking the easy task"):
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)

    # Context manager as decorator
    @work_in_progress("Tasking the dummy task")
    def task_the_dummy_task():
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)

    task_the_dummy_task()

# Generated at 2022-06-11 21:56:43.723178
# Unit test for function work_in_progress
def test_work_in_progress():
    class Test:
        def __init__(self, desc: str) -> None:
            if desc == "Loading file":
                self.status = "Loading..."
                self.time = 3.52
            else:
                self.status = "Saving..."
                self.time = 3.78
            # end if
        # end def

        def __enter__(self) -> None:
            print(self.status, end='', flush=True)
        # end def

        def __exit__(self, type, value, traceback) -> None:
            print(f"... done ({self.time}s)")
        # end def
    # end class

    saved = sys.stdout
    sys.stdout = io.StringIO()

# Generated at 2022-06-11 21:56:46.918087
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress()")
    def foo():
        pass

    foo()


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:56:51.508236
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:58:19.249549
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(2)
        return path

    assert load_file("/path/to/file") == "/path/to/file"
    with work_in_progress("Loading file"):
        time.sleep(2)
        assert True


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:58:22.565037
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Sleeping for 3 seconds"):
        time.sleep(3)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:58:32.447345
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    tests = [
        # Test 1
        {
            "desc": "Loading file",
            "func": lambda: pickle.load(open('text.txt', "rb")),
        },
        # Test 2
        {
            "desc": "Loading file",
            "func": lambda: pickle.load(open('text.txt', "rb")),
            "sleep_time": 3,
        },
    ]

    for test in tests:
        desc = test.get("desc")
        func = test.get("func")
        sleep_time = test.get("sleep_time")

# Generated at 2022-06-11 21:58:37.603834
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Simple test"):
        pass
    with work_in_progress("Test with function"):
        def test_func():
            pass
        test_func()
    with work_in_progress("Test with sleep"):
        time.sleep(0.2)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:58:50.129529
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:58:54.881611
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    
    @work_in_progress("Loading file")
    def load_file(path):
        import pickle
        with open(path, "rb") as f:
            return pickle.load(f)
    
    obj = load_file("/path/to/some/file")
    
    with work_in_progress("Saving file"):
        import pickle
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:59:00.956061
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import time

    def test_function():
        with open("/dev/null", "w") as f:
            print("\n".join([str(random.random()) for _ in range(int(1e6))]), file=f)

    with work_in_progress("test_function"):
        test_function()


if "__main__" == __name__:
    test_work_in_progress()

# Generated at 2022-06-11 21:59:09.923028
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    assert work_in_progress.py
    """
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:59:18.292686
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    return 0

# Generated at 2022-06-11 21:59:21.074346
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Work in progress"):
        time.sleep(0.5)

if __name__ == "__main__":
    test_work_in_progress()