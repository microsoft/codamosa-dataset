

# Generated at 2022-06-11 21:49:52.429974
# Unit test for function work_in_progress
def test_work_in_progress():
    file = "/path/to/some/file"
    data = [[1, 2, 3], ["a", "b", "c"], [0.1, 0.2, 0.3]]
    with work_in_progress("Loading file"):
        with open(file, "wb") as f:
            pickle.dump(data, f)
    with work_in_progress("Saving file"):
        with open(file, "rb") as f:
            assert pickle.load(f) == data
    with work_in_progress("Removing file"):
        os.remove(file)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:04.515210
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import pickle
    import os

    with tempfile.TemporaryDirectory() as tmp:
        test_obj = {'a': 1, 'b': 5, 'c': 'I am string'}
        test_path = os.path.join(tmp, 'test.pkl')

        def load_file(path):
            with open(path, "rb") as f:
                return pickle.load(f)

        def save_file(path, obj):
            with open(path, "wb") as f:
                pickle.dump(obj, f)

        with work_in_progress("Saving file"):
            save_file(test_path, test_obj)

        with work_in_progress("Loading file"):
            obj = load_file(test_path)


# Generated at 2022-06-11 21:50:13.619466
# Unit test for function work_in_progress
def test_work_in_progress():
    cwd = os.getcwd()
    with tempfile.TemporaryDirectory() as tempdir:
        os.chdir(tempdir)
        with open("output", "w") as f:

            @work_in_progress()
            def work(text="test"):
                time.sleep(1)
                print(f"{text}")

            work(text="test")
            f.write(open("output").read())
        assert (open("output").read().replace('\x1b[0m', '') ==
            "\x1b[32mWork in progress...\x1b[0m \x1b[32mdone. (1.00s)\x1b[0m\ntest\n")
    os.chdir(cwd)


if __name__ == "__main__":
    test

# Generated at 2022-06-11 21:50:25.902313
# Unit test for function work_in_progress
def test_work_in_progress():
    with open("a.out", "w") as fout:
        with contextlib.redirect_stdout(fout):
            @work_in_progress("Loading file")
            def load_file(path):
                with open(path, "rb") as f:
                    return pickle.load(f)

            obj = load_file("/path/to/some/file")
            assert "Loading file... done." in fout.read()

            with work_in_progress("Saving file"):
                with open(path, "wb") as f:
                    pickle.dump(obj, f)
            assert "Saving file... done." in fout.read()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:32.999280
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import time
    print("Testing work_in_progress")
    print("Testing contextlib.contextmanager")
    with work_in_progress("Contextlib Manager"):
        time.sleep(random.random() * 10 + 0.1)
    print("Testing decorator")
    @work_in_progress("Decorator")
    def test():
        time.sleep(random.random() * 10 + 0.1)
    test()

# Generated at 2022-06-11 21:50:37.921536
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Waiting for test"):
        time.sleep(2.0)
    with work_in_progress("Waiting for test"):
        time.sleep(0.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:38.992111
# Unit test for function work_in_progress
def test_work_in_progress():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:50:49.249586
# Unit test for function work_in_progress
def test_work_in_progress():
    import unittest
    import io
    import pdb
    import pickle

    class TestWorkInProgress(unittest.TestCase):
        def setUp(self):
            self.stdout = io.StringIO()
            self.data = list(range(100))
            self.path = "tmp.pkl"
            with open(self.path, "wb") as f:
                pickle.dump(self.data, f)

        def tearDown(self):
            # pdb.set_trace()
            os.remove(self.path)

        def test_basic_functionality(self):
            @work_in_progress()
            def func():
                time.sleep(1)
            with self.assertOutput("... done. (1.00s)"):
                func()


# Generated at 2022-06-11 21:50:50.846446
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(1)
    return True

# Generated at 2022-06-11 21:50:51.684170
# Unit test for function work_in_progress
def test_work_in_progress():
    assert work_in_progress

# Generated at 2022-06-11 21:50:59.208620
# Unit test for function work_in_progress
def test_work_in_progress():
    with pytest.raises(FileNotFoundError):
        try:
            with work_in_progress("Try to open nonexisting file"):
                with open("/path/to/nonexisting/file", "rb") as f:
                    data = f.read()
        except:
            raise

# Generated at 2022-06-11 21:51:10.400800
# Unit test for function work_in_progress
def test_work_in_progress():
    from unittest import TestCase, mock, main
    from unittest.mock import MagicMock
    from io import BytesIO

    obj = {'a': 1, 'b': 2}
    s = pickle.dumps(obj)
    obj_ = pickle.loads(s)

    with mock.patch('sys.stdout', new=BytesIO()) as mock_stdout:
        with work_in_progress("Saving file"):
            with open('./test.pickle', 'wb') as f:
                pickle.dump(obj, f)

        mock_stdout.seek(0)
        with open('./test.pickle', 'rb') as f:
            obj_ = pickle.load(f)
        assert obj_ == obj


# Generated at 2022-06-11 21:51:13.420452
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test function work_in_progress."""
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1)

# Generated at 2022-06-11 21:51:19.572028
# Unit test for function work_in_progress
def test_work_in_progress():
    load_time = 0
    save_time = 0
    with work_in_progress("Loading file"):
        with open("test.txt", "rb") as f:
            f.read()
            load_time = time.time()
    with work_in_progress("Saving file"):
        with open("test.txt", "wb") as f:
            f.write(b'a')
            save_time = time.time()

    assert load_time != 0 and save_time != 0

# Generated at 2022-06-11 21:51:22.206411
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(1.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:26.262855
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("test")
    def foo():
        pass

    @work_in_progress()
    def foo():
        pass

    with work_in_progress("test"):
        pass

    with work_in_progress():
        pass


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:35.762776
# Unit test for function work_in_progress
def test_work_in_progress():
    with open("./__test_work_in_progress.txt", "w") as f:
        print("Before work_in_progress block.", file=f)
        with work_in_progress(desc="Printing", file=f):
            print("Work in progress block.", file=f)
        print("After work_in_progress block.", file=f)
        f.flush()
    with open("./__test_work_in_progress.txt", "r") as f:
        output = f.read()
    # os.remove("./__test_work_in_progress.txt")
    assert output == "Before work_in_progress block.\nPrinting... done. (0.00s)\nAfter work_in_progress block.\n"


# Generated at 2022-06-11 21:51:41.433057
# Unit test for function work_in_progress
def test_work_in_progress():
    from contextlib import contextmanager
    from io import StringIO
    from unittest.mock import patch

    with patch("sys.stdout", new=StringIO()) as mock_stdout:
        @contextmanager
        def fake_sleep(duration):
            yield

        with patch("time.sleep", new=fake_sleep):
            with work_in_progress("Loading file..."):
                time.sleep(1)
    assert mock_stdout.getvalue() == "Loading file... done. (1.00s)\n"

# Generated at 2022-06-11 21:51:42.589028
# Unit test for function work_in_progress
def test_work_in_progress():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:51:50.270704
# Unit test for function work_in_progress
def test_work_in_progress():
    import unittest

    class TestCase(unittest.TestCase):
        def test_func(self):
            with work_in_progress() as ctx:
                time.sleep(3.8)
                self.assertIsNotNone(ctx)

        def test_context(self):
            with work_in_progress("Test") as ctx:
                time.sleep(4.5)
                self.assertIsNotNone(ctx)

    unittest.main()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:52:00.105130
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test for @work_in_progress decorator
    @work_in_progress("Decorated function")
    def decorated_func():
        time.sleep(1)

    decorated_func()

    # Test for with clause
    with work_in_progress("with clause function"):
        time.sleep(1)

# Generated at 2022-06-11 21:52:04.467211
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:52:11.078018
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Work in progress..."):
        time.sleep(1)

    def test():
        time.sleep(1)

    @work_in_progress()
    def test2():
        time.sleep(1)

    test()
    test2()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:19.097765
# Unit test for function work_in_progress
def test_work_in_progress():
    # pylint: disable=unsubscriptable-object
    @work_in_progress("Loading file")
    # pylint: enable=unsubscriptable-object
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    fake_file = io.BytesIO(
        b"\x80\x04\x95\x0c\x00\x00\x00Some object\x94."
    )

    with open("/tmp/pickle_test", "wb") as f:
        f.writelines(fake_file)

    with open("/tmp/pickle_test", "rb") as f:
        obj = pickle.load(f)

    # pylint: disable=unsubscriptable-object
    assert load_

# Generated at 2022-06-11 21:52:24.360858
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import pickle

    with work_in_progress("Loading file"):
        with open("/path/to/some/file", "rb") as f:
            obj = pickle.load(f)
    with work_in_progress("Saving file"):
        with open("/path/to/some/other/file", "wb") as f:
            obj = pickle.dump(obj, f)

# Generated at 2022-06-11 21:52:31.597042
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:37.578752
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile
    from contextlib import redirect_stdout, redirect_stderr
    import pickle
    from io import StringIO
    import sys

    # Create an object for pickle test
    obj = []
    for i in range(1024):
        obj.append(os.urandom(128*1024))  # 128 kb


# Generated at 2022-06-11 21:52:39.670828
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test work_in_progress"):
        result = 1
        time.sleep(1)
        assert result == 1

# Generated at 2022-06-11 21:52:49.283093
# Unit test for function work_in_progress
def test_work_in_progress():
    EXPECTED_OUTPUT = [
        "Work in progress... done. (0.00s)",
        "Work in progress... done. (0.00s)",
    ]

    with contextlib.redirect_stdout(io.StringIO()):
        with work_in_progress("Work in progress"):
            pass

        with work_in_progress("Work in progress"):
            time.sleep(1)

    with contextlib.redirect_stdout(io.StringIO()) as f:
        print("Work in progress... ", end='', flush=True)
        time.sleep(1)
        print("done. (1.00s)")
        assert f.getvalue() == EXPECTED_OUTPUT[1]


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:55.593976
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump('test', f)

    obj = load_file("/path/to/some/file")
    save_file("/path/to/some/file")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:53:09.281652
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    @work_in_progress("Saving file")
    def load_file():
        time.sleep(1)
    load_file()

# Generated at 2022-06-11 21:53:10.908166
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test")
    def func():
        time.sleep(1.5)
    func()

# Generated at 2022-06-11 21:53:14.917407
# Unit test for function work_in_progress
def test_work_in_progress():

    def unit_test(t1: float, t2: float):
        @work_in_progress("Loading file")
        def load_file():
            time.sleep(t1)
            return 1

        obj = load_file()
        with work_in_progress("Saving file"):
            time.sleep(t2)

    unit_test(0.5, 0.5)

# Generated at 2022-06-11 21:53:26.013309
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, content):
        with open(path, "wb") as f:
            return pickle.dump(content, f)

    path = "/".join(["/tmp", "test.pkl"])
    content = {"x": 0, "y": []}

    with work_in_progress("Loading file"):
        obj = load_file(path)
    print(obj == content)

    save_file(path, content)
    with work_in_progress("Saving file"):
        obj = load_file(path)
    print(obj == content)



# Generated at 2022-06-11 21:53:32.312338
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function work_in_progress."""
    import io
    import sys

    # Setup dummy stdout
    stdout = sys.stdout
    sys.stdout = io.StringIO()

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with pytest.raises(FileNotFoundError):
        load_file("/dummy/path")

    output = sys.stdout.getvalue()
    sys.stdout = stdout

    assert output.endswith("Loading file... done. (0.00s)\n")

# Generated at 2022-06-11 21:53:41.017659
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(3.52)
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        time.sleep(3.78)
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:53:43.766009
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Calculating 10 million digits of Pi"):
        pi = str(Decimal(22) / Decimal(7))[:10000001]

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:53:46.232572
# Unit test for function work_in_progress
def test_work_in_progress():
    try:
        with work_in_progress("Testing"):
            time.sleep(3)
    except KeyboardInterrupt:
        pass


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:53:50.767235
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Processing data"):
        # Do some fake processing
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:53:52.848890
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Counting..."):
        time.sleep(1.23)
    assert True

# Generated at 2022-06-11 21:54:23.890028
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path="test/dummy.pkl"):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file()
    assert isinstance(obj, (list, tuple))
    assert len(obj) == 10
    assert obj[0] == "Item #0"

    with work_in_progress("Saving file"):
        with open("test/dummy_2.pkl", "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:26.856258
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.512)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:33.229178
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test work in progress"):
        time.sleep(0.1)
    print()

    class LoadFile:
        @work_in_progress("Loading file")
        def __call__(self, path):
            with open(path, "rb") as f:
                return pickle.load(f)

    obj = LoadFile()("__init__.py")
    print(obj)
    print()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:38.909277
# Unit test for function work_in_progress
def test_work_in_progress():
    import doctest
    doctest.testmod()
    print("Test for work_in_progress... passed.")

###############################################################################
# This if statement does the trick of running the unit test when this file is
# run as a script, but not running the unit test when this file is imported by
# some other module.
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:41.483938
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Work in progress")
    def func():
        time.sleep(0.5)

    assert func == func


# Generated at 2022-06-11 21:54:46.205409
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Counting to million")
    def count_to_million():
        for i in range(10 ** 6):
            pass

    count_to_million()

if __name__ == "__main__":
    test = print
    test_work_in_progress()

# Generated at 2022-06-11 21:54:51.130665
# Unit test for function work_in_progress
def test_work_in_progress():
    def foo():
        time.sleep(1.0)

    with work_in_progress("Sleeping"):
        foo()
    foo()
    # assert (1.0 > time_consumed > 0.9)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:55:00.299236
# Unit test for function work_in_progress
def test_work_in_progress():
    obj = {'foo': 'bar'}
    with work_in_progress("Loading file"):
        with open("test.pkl", "wb") as f:
            pickle.dump(obj, f)
    with work_in_progress("Saving file"):
        with open("test.pkl", "rb") as f:
            obj = pickle.load(f)
    assert obj == {'foo': 'bar'}
    os.remove("test.pkl")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:55:02.137232
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Working")
    def do_work():
        time.sleep(2.0)
    do_work()

# Generated at 2022-06-11 21:55:06.783325
# Unit test for function work_in_progress
def test_work_in_progress():
    print("=" * 10, "Begin mock test", "=" * 10)

    @work_in_progress("Test function")
    def test_func():
        time.sleep(1)

    # Inside a with statement
    with work_in_progress("Test w/o function"):
        time.sleep(1)

    # Test execution time
    with work_in_progress("Test execution time"):
        time.sleep(0.1)

    print("=" * 10, "End mock test", "=" * 10)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:55:53.491379
# Unit test for function work_in_progress
def test_work_in_progress():
    def _f():
        time.sleep(2)
    with work_in_progress("Test"):
        _f()

# Generated at 2022-06-11 21:56:00.890281
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file_2(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    assert len(load_file(test_data_path)) == len(load_file_2(test_data_path))

# Generated at 2022-06-11 21:56:05.494679
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Doing somthing"):
        time.sleep(1.235)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:14.744216
# Unit test for function work_in_progress
def test_work_in_progress():
    print('''
    @work_in_progress("Load file")
    def load_file(path):
        with open(path, "rb") as f:
            time.sleep(1)
            return pickle.load(f)
    ''')
    @work_in_progress("Load file")
    def load_file(path):
        with open(path, "rb") as f:
            time.sleep(1)
            return pickle.load(f)
    load_file("/some/file")

    print('\n')
    print('''
    with work_in_progress("Load file"):
        time.sleep(1)
    ''')
    with work_in_progress("Load file"):
        time.sleep(1)

# Generated at 2022-06-11 21:56:24.253735
# Unit test for function work_in_progress
def test_work_in_progress():
    # Create a dummy file for testing
    dummy_data = {"name": "work_in_progress"}
    with open("/tmp/work_in_progress", "wb") as f:
        pickle.dump(dummy_data, f)

    # Test work_in_progress
    with work_in_progress("Loading file"):
        with open("/tmp/work_in_progress", "rb") as f:
            data = pickle.load(f)
    assert data == dummy_data
    os.remove("/tmp/work_in_progress")
    print("Test passed")

# Generated at 2022-06-11 21:56:33.216432
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")
    save_file(obj, "/path/to/some/file")

# Generated at 2022-06-11 21:56:38.227945
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress()"""

    time.sleep(1)
    with work_in_progress("Work in progress 1"):
        time.sleep(1)

    @work_in_progress("Work in progress 2")
    def func(a, b):
        time.sleep(1)
        return a + b

    func(1, 2)

# Generated at 2022-06-11 21:56:40.254374
# Unit test for function work_in_progress
def test_work_in_progress():
    assert 1 == 1

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:47.092751
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:56:53.855936
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        time.sleep(0.1)
        with open(path, "rb") as f:
            return pickle.load(f)
    
    def save_file(obj, path):
        time.sleep(0.1)
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with work_in_progress("Loading file"):
        obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        save_file(obj, "/path/to/some/file")
    

# Generated at 2022-06-11 21:58:28.154708
# Unit test for function work_in_progress
def test_work_in_progress():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:58:33.641534
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Local Variables:
# # tab-width:4
# # indent-tabs-mode:nil
# # End:
# vim: set syntax=python expandtab tabstop=4 shiftwidth=4:

# Generated at 2022-06-11 21:58:40.869729
# Unit test for function work_in_progress
def test_work_in_progress():
    target_output = """
        Work in progress... done. (7.26s)
        A task... done. (1.02s)
        Another task... done. (4.78s)
    """
    import io
    buff = io.StringIO()
    with contextlib.redirect_stdout(buff):
        with work_in_progress("Work in progress"):
            time.sleep(3)

        with work_in_progress("A task"):
            time.sleep(1)

        with work_in_progress("Another task"):
            time.sleep(4)

    buff.seek(0)
    assert target_output == buff.read()

# Generated at 2022-06-11 21:58:41.261293
# Unit test for function work_in_progress
def test_work_in_progress():
    assert True

# Generated at 2022-06-11 21:58:42.773207
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("test"):
        time.sleep(1)

# Generated at 2022-06-11 21:58:44.715276
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work progress"):
        time.sleep(1)


# Generated at 2022-06-11 21:58:53.313840
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    obj = {"x": [1, 2, 3],
           "y": {"a": 0.5, "b": 2.345},
           "z": "string"}

    # Save
    with work_in_progress("Saving file"):
        with open("test_work_in_progress.pkl", "wb") as f:
            pickle.dump(obj, f)

    # Load
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("test_work_in_progress.pkl")
    print(obj)

# test_work_in_progress()

# Generated at 2022-06-11 21:59:00.991440
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # wrapped with work_in_progress
    @work_in_progress(desc="Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # Using context manager
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:59:10.261913
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:59:17.491623
# Unit test for function work_in_progress
def test_work_in_progress():
    begin_time = time.time()
    with work_in_progress("Testing"):
        time.sleep(2)
    time_consumed = time.time() - begin_time
    assert time_consumed >= 2, f"Time consumed: {time_consumed:.4f}"
