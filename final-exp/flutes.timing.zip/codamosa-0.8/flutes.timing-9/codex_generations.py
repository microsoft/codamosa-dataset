

# Generated at 2022-06-11 21:49:48.615095
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test for function work_in_progress."""
    from contextlib import redirect_stdout
    from io import StringIO
    
    with redirect_stdout(StringIO()) as buf, \
            work_in_progress("test_work_in_progress") as progress:
        time.sleep(0.5)
    buf.seek(0)
    output = buf.read()

    assert output.startswith("test_work_in_progress... ")
    assert output.endswith(" (0.50s)\n")

# Generated at 2022-06-11 21:49:56.646552
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(2)
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:50:06.677523
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import pickle
    from contextlib import ExitStack

    # Setup
    STATE_PATH = "/tmp/pickle_test"
    state0 = {'a': 1}

    # Run the function
    with ExitStack() as stack:
        stack.enter_context(work_in_progress("Loading state"))
        with open(STATE_PATH, "wb") as f:
            pickle.dump(state0, f)
        with open(STATE_PATH, "rb") as f:
            state = pickle.load(f)
        assert state == state0
    # Cleanup
    if os.path.exists(STATE_PATH):
        os.remove(STATE_PATH)

# Generated at 2022-06-11 21:50:17.229397
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test 1: Delay 1 second"):
        time.sleep(1)
    with work_in_progress("Test 2: Delay 2 second"):
        time.sleep(2)

    def _test_work_in_progress_inner(i):
        time.sleep(i)

    @work_in_progress("Test 3: Delay 3 seconds")
    def _test_work_in_progress_1():
        _test_work_in_progress_inner(3)

    _test_work_in_progress_1()

    @work_in_progress("Test 4: Delay 4 seconds")
    def _test_work_in_progress_2():
        with work_in_progress("Delay 3 seconds"):
            _test_work_in_progress_inner(3)

# Generated at 2022-06-11 21:50:20.473989
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing...")
    def foo():
        time.sleep(3.79)

    foo()


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:50:27.400919
# Unit test for function work_in_progress
def test_work_in_progress():

    # Short task
    with work_in_progress("Test 1"):
        time.sleep(1)

    # Long task
    with work_in_progress("Test 2"):
        time.sleep(2)

    # Nested tasks
    with work_in_progress("Test 3"):
        time.sleep(0.5)
        with work_in_progress("Test 4"):
            time.sleep(0.5)
            with work_in_progress("Test 5"):
                time.sleep(0.5)
            time.sleep(1)

# Generated at 2022-06-11 21:50:32.951693
# Unit test for function work_in_progress
def test_work_in_progress():
    from time import sleep

    @work_in_progress("Test task")
    def test_task():
        sleep(1)
        print("Hello from test_task()")

    test_task()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:50:40.288381
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:50:46.560213
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import pickle
    class TestClass:
        pass
    obj = TestClass()
    path = "/tmp/toyplot_utils_test_work_in_progress.pkl"
    with work_in_progress("Loading file"):
        time.sleep(0.5)
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
        time.sleep(0.5)
    os.unlink(path)

# Generated at 2022-06-11 21:50:55.252149
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(1)
    with work_in_progress("Testing work_in_progress."):
        time.sleep(1)

# -----------------------------------------------------------------------------
# Copyright (C) 2019 Angelos Evripiotis.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# Generated at 2022-06-11 21:51:04.256678
# Unit test for function work_in_progress
def test_work_in_progress():
    # Load file
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    # Save file
    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    save_file("/path/to/some/file", obj)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:51:11.804408
# Unit test for function work_in_progress
def test_work_in_progress():
    print()
    with work_in_progress("Testing function"):
        time.sleep(1)
        print()
        with work_in_progress("Nested function"):
            print()
            time.sleep(3)

# Unit testing
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:15.254389
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading some file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    print(obj)
    # print(f"{obj}")

    with work_in_progress("Saving some file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:18.748465
# Unit test for function work_in_progress
def test_work_in_progress():
    from .utils import time_this

    with time_this("work_in_progress"):
        with work_in_progress("Test 1"):
            time.sleep(1)

        with work_in_progress("Test 2"):
            time.sleep(2)

        with work_in_progress("Test 3"):
            time.sleep(3)

# Generated at 2022-06-11 21:51:22.686198
# Unit test for function work_in_progress
def test_work_in_progress():
    def test_func(idx):
        time.sleep(idx / 10)

    for idx in range(10):
        with work_in_progress(f"Test task #{idx}"):
            test_func(idx)

# Generated at 2022-06-11 21:51:30.183068
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    def load_file(path):
        with work_in_progress("Loading file"):
            with open(path, "rb") as f:
                return pickle.load(f)

    def save_file(path, data):
        with work_in_progress("Saving file"):
            with open(path, "wb") as f:
                pickle.dump(data, f)

    data = [
        {"name": "Aaron", "age": 25},
        {"name": "Bob", "age": 21},
        {"name": "Claire", "age": 27},
        {"name": "David", "age": 32},
        {"name": "Eve", "age": 19},
    ]

    save_file("data.pickle", data)
    data = load_file("data.pickle")

# Generated at 2022-06-11 21:51:34.546621
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test if the `work_in_progress` contextmanager works as expected."""
    with work_in_progress("Creating a random file"):
        with open("/tmp/__test", "wb") as f:
            f.write(os.urandom(128))
        os.remove("/tmp/__test")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:40.122676
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file") as w:
        class Foo:
            def __init__(self):
                self.attribute = 0
                time.sleep(3.5)
        foo = Foo()
        assert isinstance(foo, Foo)
    assert w is None
    time.sleep(0.2)

if __name__ == '__main__':
    test_work_in_progress()
    print("Done!")

# Generated at 2022-06-11 21:51:46.579731
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:51:56.308274
# Unit test for function work_in_progress
def test_work_in_progress():
    test_file_path = "/tmp/test_work_in_progress.pkl"
    with open(test_file_path, "wb") as f:
        pickle.dump({"foo": "bar", "spam": range(1e3)}, f)
    with work_in_progress("Loading file"):
        with open(test_file_path, "rb") as f:
            d = pickle.load(f)
    assert d["foo"] == "bar"
    assert d["spam"] == list(range(1e3))


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:02.915560
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Test for function work_in_progress")
    import time
    with work_in_progress("Waiting"):
        time.sleep(0.23)
    time.sleep(0.1)
    print("OK")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:12.322955
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("README.md")
    assert isinstance(obj, str)

    with work_in_progress("Saving file"):
        with tempfile.TemporaryFile("wb") as f:
            pickle.dump(obj, f)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:52:15.102944
# Unit test for function work_in_progress
def test_work_in_progress():
    with open("readme.md", "w") as f:
        with work_in_progress("Writing 'readme.md'"):
            for _ in range(1000000):
                print("Hello, world!", file=f)

# Generated at 2022-06-11 21:52:24.251330
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile
    path = os.path.join(tempfile.gettempdir(), "test_work_in_progress.txt")

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with work_in_progress("Saving file"):
        save_file(path)

    obj = load_file(path)

# Execute only if it is run as a script
if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:52:34.170614
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function work_in_progress.

    .. code:: python

        >>> @work_in_progress("Loading file")
        ... def load_file(path):
        ...     with open(path, "rb") as f:
        ...         return pickle.load(f)
        ...
        ... obj = load_file("/path/to/some/file")
        Loading file... done. (3.52s)

        >>> with work_in_progress("Saving file"):
        ...     with open(path, "wb") as f:
        ...         pickle.dump(obj, f)
        Saving file... done. (3.78s)
    """
    class TestArgs:
        desc: str = "Testing"


# Generated at 2022-06-11 21:52:44.173922
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress."""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
        # It should print "Loading file... done. (3.52s)"

    obj = load_file(__file__)
    assert obj is not None

    with work_in_progress("Saving file"):
        with open(__file__, "wb") as f:
            pickle.dump(obj, f)
        # It should print "Saving file... done. (3.52s)"


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:48.238063
# Unit test for function work_in_progress
def test_work_in_progress():
    from .example_utils import pickle_written_file
    try:
        obj = None
        with work_in_progress("Loading file"):
            obj = pickle_written_file()
        with work_in_progress("Saving file"):
            pickle_written_file(obj)
    finally:
        if obj is not None:
            del obj

# Generated at 2022-06-11 21:52:54.362796
# Unit test for function work_in_progress
def test_work_in_progress():
    def _load(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def _save(path):
        with open(path, "wb") as f:
            return pickle.dump(path, f)

    @work_in_progress("Loading file")
    def load_file(path):
        return _load(path)

    @work_in_progress("Saving file")
    def save_file(path):
        return _save(path)

    save_file("/path")
    load_file("/path")

# Generated at 2022-06-11 21:53:05.589946
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing work_in_progress")
    t1 = time.time()
    with work_in_progress("Loading file"):
        with open(__file__, "rb") as f:
            load_file = pickle.load(f)
    t2 = time.time()
    print(f"Time consumed: {t2 - t1:.2f}s")
    print()

    t1 = time.time()
    @work_in_progress("Saving file")
    def save_file():
        with open(__file__, "wb") as f:
            time.sleep(1)
            pickle.dump(save_file, f)
    save_file()
    t2 = time.time()
    print(f"Time consumed: {t2 - t1:.2f}s")
   

# Generated at 2022-06-11 21:53:12.440387
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")
    save_file("/some/other/path")

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:53:22.209698
# Unit test for function work_in_progress
def test_work_in_progress():
    def func_a():
        time.sleep(1)
    def func_b():
        for i in range(100):
            time.sleep(0.01)

    # Test for function implementation
    work_in_progress(func_a)
    work_in_progress(func_b)

    # Test for context manager implementation
    def test():
        with work_in_progress():
            func_a()
        with work_in_progress():
            func_b()
    test()


# Generated at 2022-06-11 21:53:30.258304
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import shutil
    import tempfile

    tmp_dir = tempfile.mkdtemp()

    # Work with function decorator
    @work_in_progress("Creating file")
    def create_file(path, content="123"):
        with open(path, "w") as f:
            f.write(content)

    create_file(os.path.join(tmp_dir, "some_file"))

    # Work with context manager
    with work_in_progress("Writing file"):
        with open(os.path.join(tmp_dir, "some_file"), "w") as f:
            f.write("123")

    # Clean up
    shutil.rmtree(tmp_dir)

# Generated at 2022-06-11 21:53:35.403740
# Unit test for function work_in_progress
def test_work_in_progress():
    # Construct a dummy file
    if "dummy.pkl" in os.listdir():
        os.remove("dummy.pkl")
    with open("dummy.pkl", "wb") as f:
        pickle.dump({"obj": 1}, f)


# Generated at 2022-06-11 21:53:43.906360
# Unit test for function work_in_progress
def test_work_in_progress():
    
    def foo():
        with work_in_progress("Loading file"):
            time.sleep(1.23)
        with work_in_progress("Saving file"):
            time.sleep(1.34)

    class Bar(object):
        @work_in_progress("Loading file")
        def load_file(self):
            time.sleep(1.23)

        @work_in_progress("Saving file")
        def save_file(self):
            time.sleep(1.34)

    # Method of module
    foo()
    # Method of class
    Bar().save_file()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:53:51.906836
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1.23)
    
    print()
    
    obj = None
    path = "/tmp/test.obj"
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    
    obj = load_file(path)
    print(obj)

if __name__ == "__main__":
    test_work_in_progress

# Generated at 2022-06-11 21:53:57.945321
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file2(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = {"some": "data"}

    with open("./some_file.pkl", "wb") as f:
        pickle.dump(obj, f)

    with work_in_progress("Loading file"):
        data = load_file("./some_file.pkl")

    assert data == obj

    data = load_file2("./some_file.pkl")
    assert data == obj



# Generated at 2022-06-11 21:54:01.263087
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file..."):
        time.sleep(3)
    
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:07.864150
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sleeping 5 seconds"):
        time.sleep(5)

    @work_in_progress("Sleeping 5 seconds")
    def sleep_5_seconds():
        time.sleep(5)
    sleep_5_seconds()

# Generated at 2022-06-11 21:54:10.731072
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        for i in range(10):
            time.sleep(0.01)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:22.496598
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Calculating sum")
    def sum_of_numbers(numbers):
        return sum(numbers)

    sum_of_numbers([1,2,3,4,5])
    # Calculating sum... done. (0.00s)
    # 15


##############################################################################
#                                Main
##############################################################################

if __name__ == '__main__':
    # Test
    import os
    import sys
    sys.path.insert(0, os.path.abspath(
        os.path.join(os.path.dirname(__file__), '..')))
    from utils.template import test
    test(__file__, [
        '-v', '--tb=line', '--strict'
    ])

# Generated at 2022-06-11 21:54:29.140247
# Unit test for function work_in_progress
def test_work_in_progress():
    import random

    a = []
    n = 100
    with work_in_progress(f"Generating {n} random numbers"):
        for _ in range(n):
            a.append(random.random())

    assert len(a) == n


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:32.208718
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(0.2)
    with work_in_progress("test"):
        time.sleep(0.1)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:54:42.846733
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import time

    print("Testing function work_in_progress...", end='', flush=True)

    obj = {'hello': 'world'}

    with tempfile.TemporaryDirectory() as temp_dir_path:
        obj_path = os.path.join(temp_dir_path, "obj.pickle")

        # Pickle-friendly objects
        with work_in_progress("Saving file"):
            with open(obj_path, "wb") as f:
                pickle.dump(obj, f)

        with work_in_progress("Loading file"):
            with open(obj_path, "rb") as f:
                obj1 = pickle.load(f)

        # Numpy array

# Generated at 2022-06-11 21:54:43.878730
# Unit test for function work_in_progress
def test_work_in_progress():
    # This is tested by functional tests!
    pass

# Generated at 2022-06-11 21:54:56.038581
# Unit test for function work_in_progress
def test_work_in_progress():
    # Imports
    import os
    import tempfile
    import subprocess

    # Create temporary file
    with tempfile.TemporaryDirectory() as tmpdir_name:
        file_name = os.path.join(tmpdir_name, "my_file")
        with open(file_name, "w") as f:
            f.write("Hello, world!\n")

        # Print timing information
        def print_timing(text, ls_output=None):
            if ls_output is None:
                ls_output = subprocess.check_output(["ls", "-l", file_name])
            st = os.stat(file_name)
            mtime = time.localtime(st.st_mtime)

# Generated at 2022-06-11 21:55:00.179905
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    import sys

    stream = io.StringIO()
    sys.stdout = stream
    work_in_progress()
    assert(stream.getvalue() == "Work in progress... done. (0.00s)\n")

# Generated at 2022-06-11 21:55:03.850860
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path : str):
        with open(path, 'rb') as f:
            return pickle.load(f)

    obj = load_file("/Users/wangyongbo/PycharmProjects/python-utils/tests/test_a.pkl")
    assert obj == 1


# Generated at 2022-06-11 21:55:11.690897
# Unit test for function work_in_progress
def test_work_in_progress():
    def slow_func():
        time.sleep(1.2)

    print("Test Work In Progress:")

    # Context manager
    print("\tContext Manager:", end=' ')
    with work_in_progress("Test"):
        slow_func()
    print()

    # Decorator
    print("\tDecorator:", end=' ')
    @work_in_progress("Test")
    def test_decorator():
        slow_func()
    test_decorator()
    print()



# Generated at 2022-06-11 21:55:18.751315
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function :func:`~pyhelpers.work_in_progress`.

    :return: a dict containing the results of unit tests

        - key 'message': a string indicating the result of tests
        - key 'result': a boolean indicating if the unit test passed
        - key 'others': a dict of other informations

    :rtype: dict
    """
    results = {}

    print("Testing function pyhelpers.work_in_progress...")

    with work_in_progress("Work in progress 1"):
        time.sleep(3)

    with work_in_progress("Work in progress 2"):
        time.sleep(4.4)

    results["message"] = "OK"
    results["result"] = True

    print("Done")

    return results

# Generated at 2022-06-11 21:55:26.839381
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = dict(foo="bar", bar="baz", baz="qux")

    with work_in_progress("Loading file"):
        obj1 = load_file("unit_test/test_work_in_progress.pkl")

    obj2 = dict(foo="bar", bar="baz", baz="qux")

    with work_in_progress("Saving file"):
        save_file(obj2, "unit_test/test_work_in_progress.pkl")


# Generated at 2022-06-11 21:55:34.372284
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing function work_in_progress...", end=' ', flush=True)
    import time

    begin_time = time.time()
    with work_in_progress():
        time.sleep(1.23)
    time_consumed = time.time() - begin_time
    if time_consumed - 1.23 > 0.0001:
        print("ERROR")
    else:
        print("ok")


# Generated at 2022-06-11 21:55:45.864932
# Unit test for function work_in_progress
def test_work_in_progress():
    import subprocess
    import sys
    import os
    import pickle

    path = "/tmp/ttttt_work_in_progress_test"
    obj = {
        "hello": ["world", "work_in_progress"],
    }


# Generated at 2022-06-11 21:55:54.734110
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import random

    @work_in_progress("Generating test data")
    def generate_test_data():
        return random.random()

    @work_in_progress("Cleaning test data")
    def clean_test_data():
        time.sleep(0.1)

    test_data = generate_test_data()
    with work_in_progress("Running test"):
        time.sleep(0.5)
    clean_test_data()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:55:59.566898
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test work_in_progress(desc)")
    def foo():
        time.sleep(0.01)
    with work_in_progress("Test work_in_progress()"):
        time.sleep(0.01)

# Generated at 2022-06-11 21:56:07.431293
# Unit test for function work_in_progress
def test_work_in_progress():
    import random, string
    print("Running unit test for `work_in_progress`")

    # test function work_in_progress
    @work_in_progress("Unit test")
    def test_work_in_progress_function():
        time.sleep(1.00)

    # test context manager work_in_progress
    with work_in_progress("Unit test"):
        time.sleep(1.00)

    print("\n".join([
        "If the execution of `work_in_progress` takes more than 1 second",
        "and the end result is `done. (1.00s)`, the test passed.",
        "Otherwise, you messed up somewhere...",
    ]))
    return False

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:14.227079
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file(__file__)
    save_file(__file__ + '-duplicate', obj)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:56:26.081141
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("./test/test.pickle")
    assert obj == {'a': 1, 'b': 2}

    with work_in_progress("Saving file"):
        with open("./test/test2.pickle", "wb") as f:
            pickle.dump(obj, f)
    
    with open("./test/test2.pickle", "rb") as f:
        obj2 = pickle.load(f)
    assert obj2 == {'a': 1, 'b': 2}

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:31.485809
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        with open("/path/to/some/file", "rb") as f:
            pickle.load(f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:38.267847
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:49.926549
# Unit test for function work_in_progress
def test_work_in_progress():
    # This block tests the functionality of the decorator
    @work_in_progress(desc="Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    # Output: Loading file... done. (3.52s)
    print(obj)

    # This block tests the functionality of the context manager
    with work_in_progress(desc="Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    # Output: Saving file... done. (3.78s)


if __name__ == "__main__":
    # Initialize the logger
    logging.basicConfig(level=logging.DEBUG)

   

# Generated at 2022-06-11 21:56:57.747719
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.5)
    with work_in_progress("Saving file"):
        time.sleep(0.75)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:57:05.973170
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with tempfile.TemporaryDirectory() as tmp_dir:
        path = os.path.join(tmp_dir, "default.pkl")
        with open(path, "wb") as f:
            pickle.dump(obj, f)
        with work_in_progress("Saving file"):
            with open(path, "rb") as f:
                output = pickle.load(f)
        assert output == obj


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:57:09.174033
# Unit test for function work_in_progress
def test_work_in_progress():
    def some_time_consuming_task():
        for i in range(10):
            time.sleep(.5)

    with work_in_progress(desc="Just some time consuming task"):
        some_time_consuming_task()
    
    @work_in_progress(desc="Some other time consuming task")
    def other_time_consuming_task():
        for i in range(10):
            time.sleep(.5)
    
    other_time_consuming_task()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:57:11.517508
# Unit test for function work_in_progress
def test_work_in_progress():
    pass

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:57:17.277746
# Unit test for function work_in_progress
def test_work_in_progress():
    from math import pi
    from random import choice
    from time import sleep

    with work_in_progress():
        sleep(choice((0.2, 0.5, 1)))
        x = sum([pi**i for i in range(300000)])
    assert x == pi**300000

# Generated at 2022-06-11 21:57:28.121463
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import os
    import shutil
    import tempfile

    # Test work_in_progress as a function decorator
    @work_in_progress("Uploading some file...")
    def upload_file(file_path, dest_path):
        time.sleep(3.14)  # Simulate upload time
        with open(dest_path, "wb") as f:
            with open(file_path, "rb") as f_src:
                f.write(f_src.read())

    tmp_dir = tempfile.mkdtemp()
    upload_file("__init__.py", os.path.join(tmp_dir, "file.py"))
    shutil.rmtree(tmp_dir)

    # Test work_in_progress as a context manager

# Generated at 2022-06-11 21:57:38.895629
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function work_in_progress and associated functions."""
    import pickle
    import tempfile
    from shutil import rmtree
    import os

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(obj, path):
        with work_in_progress("Saving file"):
            with open(path, "wb") as f:
                pickle.dump(obj, f)

    with tempfile.TemporaryDirectory() as tempdir:
        path = os.path.join(tempdir, "file")

# Generated at 2022-06-11 21:57:50.042941
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test the correctness of implementation of work_in_progress."""
    import sys
    import os
    import tempfile
    import pickle

    path = os.path.join(tempfile.gettempdir(), 'temp.pkl')

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    @work_in_progress("Loading file")
    def test_load_file(path):
        return load_file(path)

    with work_in_progress("Saving file"):
        save_file(path, [1, 2, 3])

    obj = test_load_file(path)

# Generated at 2022-06-11 21:58:01.773586
# Unit test for function work_in_progress
def test_work_in_progress():
    with open("test_work_in_progress.pickle", "wb") as f:
        pickle.dump({"test": 1}, f)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("test_work_in_progress.pickle")
    assert obj["test"] == 1
    os.remove("test_work_in_progress.pickle")

    with work_in_progress("Saving file"):
        with open("test_work_in_progress.pickle", "wb") as f:
            pickle.dump(obj, f)

    assert os.path.exists("test_work_in_progress.pickle")
    obj = load_file

# Generated at 2022-06-11 21:58:06.881321
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Adding")
    def add_func(a: int, b: int) -> int:
        return a + b

    assert add_func(1, 1) == 2

    @work_in_progress("Multiplying")
    def multiply_func(a: int, b: int) -> int:
        return a * b

    assert multiply_func(1, 1) == 1

    with work_in_progress("Subtracting"):
        result = 1 - 1

    assert result == 0

    with work_in_progress("Dividing"):
        result = 1 / 1

    assert result == 1

# Generated at 2022-06-11 21:58:20.894538
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with work_in_progress("Loading file"):
        obj = load_file(path)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-11 21:58:31.592944
# Unit test for function work_in_progress
def test_work_in_progress():
    class TestDummyClass(object):
        def __init__(self):
            self.value = 0

        @work_in_progress("Setting value")
        def set_value(self, value: int):
            self.value = value

        @work_in_progress("Getting value")
        def get_value(self) -> int:
            return self.value

    print("Test with dummy class:")
    dummy = TestDummyClass()
    print("Before:", dummy.get_value())
    dummy.set_value(100)
    print("After: ", dummy.get_value())

    with work_in_progress("Test with dummy class"):
        print("Before:", dummy.get_value())
        dummy.set_value(200)
        print("After: ", dummy.get_value())


# Generated at 2022-06-11 21:58:40.127313
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import tempfile
    import pickle
    from contextlib import redirect_stdout

    DATA = {"a": [str(i) for i in range(10 ** 4)], "b": [str(i) for i in range(10 ** 4, 0, -1)]}
    _, OBJ_PATH = tempfile.mkstemp()

    def test_work_in_progress_case(desc: str = "Work in progress", capture_stdout: bool = False):
        with open(OBJ_PATH, "wb") as f:
            pickle.dump(DATA, f)

        @work_in_progress(desc)
        def load_file(path):
            with open(path, "rb") as f:
                return pickle.load(f)

        # main

# Generated at 2022-06-11 21:58:42.302768
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Doing nothing"):
        time.sleep(2)

# Generated at 2022-06-11 21:58:44.946328
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Work in progress"):
        time.sleep(2)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:58:50.417777
# Unit test for function work_in_progress
def test_work_in_progress():
    repeat_time = 1000
    total_time = 0

    with work_in_progress("Calculating number of Pi"):
        for _ in range(repeat_time):
            math.pi

    print(f"Total time consumed: {total_time:.2f}s")

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:58:55.762049
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing function 'work_in_progress'...", end='')
    try:
        with work_in_progress():
            pass
        print('passed!')
    except Exception as e:
        print(e)
        print('failed!')
        raise

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:59:04.242595
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Creating toy dataset for demo"):
        time.sleep(0.12)
        pass
    with work_in_progress("Creating toy dataloader for demo"):
        time.sleep(0.38)
        pass
    with work_in_progress("Creating toy model for demo"):
        time.sleep(0.33)
        pass
    with work_in_progress("Training toy model"):
        time.sleep(3.15)
        pass
    with work_in_progress("Testing toy model"):
        time.sleep(2.87)
        pass

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:59:11.030221
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("test_file")

    with work_in_progress("Saving file"):
        with open("test_file", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:59:18.161485
# Unit test for function work_in_progress
def test_work_in_progress():
    import random

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    time.sleep(random.random())