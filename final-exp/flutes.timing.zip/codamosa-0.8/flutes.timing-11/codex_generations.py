

# Generated at 2022-06-11 21:49:53.709504
# Unit test for function work_in_progress
def test_work_in_progress():
    from .misc_lib import is_file_readable
    import pickle

    path = "/tmp/test_work_in_progress.pkl"
    content = "test"
    with open(path, "wb") as f:
        pickle.dump(content, f)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open(path + ".2", "wb") as f:
            pickle.dump(content, f)

    assert load_file(path) == content
    assert is_file_readable(path + ".2")

# Generated at 2022-06-11 21:50:04.918997
# Unit test for function work_in_progress
def test_work_in_progress():
    print("\nTest for function work_in_progress:")
    print("-" * len("Test for function work_in_progress:"))
    with work_in_progress("Test function 1"):
        time.sleep(0.2118)
    @work_in_progress("Test function 2")
    def f(x, y, z=True):
        time.sleep(0.4096)
    f(1, 2)
    @work_in_progress("Test function 3")
    def f(x, y, z=True):
        time.sleep(0.6174)
    f(1, 2, z=False)
    print()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:10.994291
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1.5)  # Fake file loading
    print()
    with work_in_progress("Saving file"):
        time.sleep(2.3)  # Fake file saving


if __name__ == '__main__':
    import doctest
    doctest.testmod()

    print("Testing the function work_in_progress")
    test_work_in_progress()

# Generated at 2022-06-11 21:50:14.740300
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:20.136307
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
        obj = load_file("/path/to/some/file")
        print(obj)

# Generated at 2022-06-11 21:50:29.486710
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    # Let's load a file (should take some time)
    path = "tests/resources/test_file.pickle"
    obj = load_file(path)
    assert obj == {"test": 1}

    # Let's save a file (should take some time)
    path = "tests/resources/test_file.pickle"
    save_file(path, obj)
    assert os.path.exists(path)

    # Let's load

# Generated at 2022-06-11 21:50:32.308876
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test work_in_progress")
    def some_func():
        print("Hello world!")
    some_func()

# Generated at 2022-06-11 21:50:37.268989
# Unit test for function work_in_progress
def test_work_in_progress():
    # Implement sleep using busy-waiting
    def sleep(seconds):
        t = time.clock()
        while time.clock() - t < seconds:
            pass

    # Test
    with work_in_progress("Testing work_in_progress"):
        sleep(1)
        assert True
    with work_in_progress():
        sleep(0.5)
        assert True

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:42.509760
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(0.4)

    load_file("/path/to/nothingness")

    with work_in_progress("Saving file"):
        time.sleep(0.8)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:44.655892
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing in progress"):
        time.sleep(3)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:52.086321
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing work_in_progress...", end=' ', flush=True)
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1)
    print("Done testing work_in_progress.")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:56.675723
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    with work_in_progress("Saving file"):
        time.sleep(2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:04.202538
# Unit test for function work_in_progress
def test_work_in_progress():

    with work_in_progress("Sleeping for 1.2s"):
        time.sleep(1.2)

    with work_in_progress():
        time.sleep(0.5)

    with work_in_progress("Sleeping for 2.0s"):
        time.sleep(2)

    with work_in_progress("Sleeping for 3.0s"):
        time.sleep(3)

    @work_in_progress("Working on some object")
    def work_on(obj: object) -> object:
        time.sleep(0.3)
        return "Done"

    obj = work_on(None)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:15.749779
# Unit test for function work_in_progress
def test_work_in_progress():
    def _test_wrk_in_prgrss(time_len):
        with work_in_progress("Test"):
            time.sleep(time_len)  # Delay some time

    _test_wrk_in_prgrss(0.0001)
    _test_wrk_in_prgrss(0.1234)
    _test_wrk_in_prgrss(1.2345)
    _test_wrk_in_prgrss(12.345)
    _test_wrk_in_prgrss(123.45)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:22.403175
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":

    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:51:30.011966
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    example_dict = {"a": 1, "b": 2, "c": 3, "d": 4}
    with open("example.pkl", "wb") as f:
        pickle.dump(example_dict, f)
    assert load_file("example.pkl") == example_dict
    os.remove("example.pkl")

    with work_in_progress("Saving file"):
        with open("example.pkl", "wb") as f:
            pickle.dump(example_dict, f)
    assert load_file("example.pkl") == example_dict
    os.remove("example.pkl")


# Generated at 2022-06-11 21:51:33.814585
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:51:39.737947
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:51:46.839883
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import random
    import pickle
    import os

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:51:53.385544
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "./test.pkl"
    obj = {'a': 1, 'b': 2, 'c': 3}
    with open(path, 'wb') as f:
        pickle.dump(obj, f)
    obj_loaded = load_file(path)
    print(obj)
    print(obj_loaded)
    assert obj == obj_loaded

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    os.remove(path)


if __name__ == "__main__":
    test_work_in_progress

# Generated at 2022-06-11 21:52:02.364390
# Unit test for function work_in_progress
def test_work_in_progress():
    # Should not raise any exceptions
    with work_in_progress("Fixing a bug"):
        time.sleep(1.234)

if __name__ == '__main__':
    import doctest
    doctest.testmod()
    test_work_in_progress()

# Generated at 2022-06-11 21:52:08.966687
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(0.5)
    with work_in_progress("Test"):
        time.sleep(5)
    with work_in_progress("Test"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:10.784378
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Sorting list")
    def sort_list(l):
        time.sleep(0.01)
        return sorted(l)
    a = "This is a test, done!"
    assert a == sort_list(a)

# Generated at 2022-06-11 21:52:13.962512
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(0.2)
    try:
        with work_in_progress("Test function"):
            time.sleep(0.5)
            raise ValueError
    except:
        pass

# Generated at 2022-06-11 21:52:15.444831
# Unit test for function work_in_progress
def test_work_in_progress():
    pass


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:22.195073
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress(desc="Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file(os.path.join(os.path.dirname(__file__), "test_work_in_progress.pkl"))
    assert obj == {"Test": "OK"}


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:24.198226
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(2)

# Generated at 2022-06-11 21:52:30.335092
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:52:31.935008
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Unit test")
    def test():
        time.sleep(0.01)

    test()

# Generated at 2022-06-11 21:52:42.896630
# Unit test for function work_in_progress
def test_work_in_progress():

    # Test function
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # Mock pickle.load
    with unittest.mock.patch("pickle.load") as load:
        load.return_value = 1
        assert load_file("/path/to/some/file") == 1

    # Test context manager
    with unittest.mock.patch("time.time") as time:
        time.return_value = 0
        with work_in_progress("Saving file"):
            time.return_value = 1


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:59.131328
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    import numpy as np

    with work_in_progress("Working in progress"):
        time.sleep(0.002)

    obj = np.random.rand(100, 100)

    with work_in_progress("Loading some array"):
        for _ in range(1000000):
            obj = obj + obj

    with work_in_progress("Saving some array"):
        for _ in range(1000000):
            obj = obj - obj


# -----------------------------------------------------------------------------

if __name__ == '__main__':  # pragma: no cover
    import doctest
    doctest.testmod(verbose=True)
    test_work_in_progress()

# Generated at 2022-06-11 21:53:10.326068
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test work_in_progress with both function decorator and context manager."""
    from pyutils.assertutils import assert_log, assert_log_empty

    def load_file(path):
        time.sleep(0.05)

    assert_log_empty()
    with work_in_progress("Loading file"):
        load_file("/path/to/some/file")
    assert_log("Loading file... done.")  # or, "done. (0.xxs)"
    assert_log_empty()

    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(0.05)

    assert_log_empty()
    load_file("/path/to/some/file")
    assert_log("Loading file... done.")  # or, "done. (0.xx

# Generated at 2022-06-11 21:53:18.118554
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile
    import os

    with tempfile.TemporaryDirectory() as tmp_dirpath:
        filepath = os.path.join(tmp_dirpath, "data.obj")

        def save_data(data):
            with open(filepath, "wb") as f:
                pickle.dump(data, f)

        def load_data():
            with open(filepath, "rb") as f:
                return pickle.load(f)

        @work_in_progress(desc="Saving data")
        def save_data_timed(data):
            with open(filepath, "wb") as f:
                pickle.dump(data, f)


# Generated at 2022-06-11 21:53:21.658250
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("./example.pkl")
    assert obj == "Hello, world!"



# Generated at 2022-06-11 21:53:27.976846
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test function
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # Test context manager
    with work_in_progress("Saving file"):
        with open("/tmp/test-work-in-progress.log", "wb") as f:
            pickle.dump("hello", f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:53:39.887944
# Unit test for function work_in_progress
def test_work_in_progress():
    from pathlib import Path
    from tempfile import TemporaryDirectory
    from importlib import util

    mock = util.find_spec("mock")
    if mock is None:
        return

    import mock

    with TemporaryDirectory() as tmp_dir:
        # noinspection PyUnresolvedReferences
        with mock.patch("sascalc.util.os.chdir"):
            # noinspection PyUnresolvedReferences
            with mock.patch("sascalc.util.os.getcwd") as getcwd:
                with mock.patch("sascalc.util.os.path.abspath") as abspath:
                    getcwd.return_value = Path("/home/user").resolve()
                    abspath.return_value = Path("/home/user/file").resolve()


# Generated at 2022-06-11 21:53:46.910699
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    # Test 1
    obj1 = load_file(os.path.join(os.path.dirname(__file__), "test_file1.pk"))
    assert isinstance(obj1, list)
    assert obj1 == [1, 2, 3]

    # Test 2
    obj2 = load_file(os.path.join(os.path.dirname(__file__), "test_file2.pk"))

# Generated at 2022-06-11 21:53:57.079294
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import pickle
    from tempfile import TemporaryDirectory

    with work_in_progress("Creating a file"):
        path = "/tmp/somefile"
        with open(path, "x") as f:
            f.write("Some contents")
    assert os.path.exists(path)
    os.remove(path)

    with TemporaryDirectory() as d:
        path = d + "/somefile"
        with open(path, "wb") as f:
            pickle.dump({}, f)

        @work_in_progress("Loading file")
        def load_file(path):
            with open(path, "rb") as f:
                return pickle.load(f)
        obj = load_file(path)
        assert obj == {}


# Generated at 2022-06-11 21:54:00.382210
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.25)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:54:02.383027
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("My task"):
        pass

# Generated at 2022-06-11 21:54:33.783434
# Unit test for function work_in_progress
def test_work_in_progress():
    from .future import capture_stdout
    from unittest.case import TestCase
    from unittest.mock import Mock

    class Tester(TestCase):
        def setUp(self):
            self._patch()

        def tearDown(self):
            self._unpatch()

        def _patch(self):
            self.print_mock = Mock()
            self.time_mock = Mock()
            self.time_mock.time.side_effect = [
                123,  # _begin_time
                246,  # time_consumed,
            ]
            self.print_patch = self.patch(
                "sklearn_lvq.utils.time._print", self.print_mock
            )

# Generated at 2022-06-11 21:54:38.229259
# Unit test for function work_in_progress
def test_work_in_progress():
    def dummy(*d_args, **d_kwargs):
        time.sleep(1)

    dummy = work_in_progress()(dummy)
    dummy()

    def dummy2(*d_args, **d_kwargs):
        with work_in_progress():
            time.sleep(1)

    dummy2()

# Generated at 2022-06-11 21:54:44.152446
# Unit test for function work_in_progress
def test_work_in_progress():
    import utix.utilxtest

    @work_in_progress("Loading the data")
    def load_data():
        import time
        time.sleep(0.4)

    @work_in_progress("Saving the data")
    def save_data():
        import time
        time.sleep(0.7)

    def func():
        load_data()
        save_data()

    utix.utilxtest.run_test(func)

# Generated at 2022-06-11 21:54:56.164402
# Unit test for function work_in_progress
def test_work_in_progress():
    import pathlib
    temp_folder = pathlib.Path("/tmp/test_work_in_progress")

    def save_obj(obj):
        file_path = temp_folder / "test_file" 
        with work_in_progress("Saving file"):
            with open(file_path, "wb") as f:
                pickle.dump(obj, f)
        
    def load_obj():
        file_path = temp_folder / "test_file"
        with work_in_progress("Loading file"):
            with open(file_path, "rb") as f:
                return pickle.load(f)

    def remove_file():
        file_path = temp_folder / "test_file"
        os.remove(file_path)


# Generated at 2022-06-11 21:55:03.529434
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/tmp/file.pickle")
    # Loading file... done. (3.52s)
    assert obj == (1, 2, 3)

    with work_in_progress("Saving file"):
        with open("/tmp/file.pickle", "wb") as f:
            pickle.dump((1, 2, 3), f)
    # Saving file... done. (3.78s)

# Generated at 2022-06-11 21:55:07.032927
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Saving file")
    def load_file(path):
        time.sleep(2)

    load_file(None)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:55:09.927067
# Unit test for function work_in_progress
def test_work_in_progress():
    for i in range(3):
        with work_in_progress("Loading file"):
            time.sleep(1)
        time.sleep(1)

# Generated at 2022-06-11 21:55:13.113848
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        a = 1
        for _ in range(10**8):
            a += 1
    assert a == 10**8+1

# Generated at 2022-06-11 21:55:16.519054
# Unit test for function work_in_progress
def test_work_in_progress():
    data = []
    with work_in_progress("Generating random data"):
        for _ in range(10 ** 3):
            data.append(random.random())

# Generated at 2022-06-11 21:55:23.507616
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Execution as a script
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:12.015941
# Unit test for function work_in_progress
def test_work_in_progress():
    # pylint: disable=unused-variable
    # This is to test whether the context manager works as expected
    with work_in_progress("Task 1") as wip1:
        time.sleep(1)
    with work_in_progress("Task 2"):
        time.sleep(1)
    # pylint: enable=unused-variable

# Generated at 2022-06-11 21:56:17.571763
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import io
    import io
    import pickle
    import pandas as pd

    class dummy_df(pd.DataFrame):
        """A dummy class for pandas dataframe.

        This is a very simple class that does nothing more than extend
        the class pd.DataFrame and add a property `base_uri`.
        """
        @property
        def base_uri(self):
            return self._base_uri

        @base_uri.setter
        def base_uri(self, uri):
            self._base_uri = uri


    # Test saving and loading
    @work_in_progress("Loading dataframe")
    def load_df(path):
        with open(path, "rb") as f:
            return pickle.load(f)


# Generated at 2022-06-11 21:56:24.212325
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open("/tmp/file.bin", "wb") as f:
            pickle.dump(load_file("/tmp/file.bin"), f)

# Generated at 2022-06-11 21:56:32.057267
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test function `work_in_progress`.
    """

    # Test `work_in_progress` used as a decorator.
    @work_in_progress("Test work_in_progress")
    def f1():
        time.sleep(2.0)

    # Test `work_in_progress` used as a context manager.
    with work_in_progress("Test work_in_progress"):
        time.sleep(2.0)

# Generated at 2022-06-11 21:56:40.975336
# Unit test for function work_in_progress
def test_work_in_progress():
    # Mock a function to measure the execution time.
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(fp=f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, fp=f)

    # Prepare a demo file.
    test_dict = {
        "foo": 1,
        "bar": None,
        "baz": [1, "2", 3.0],
    }
    test_path = os.path.join(os.path.expanduser("~/.demo"), "demo.pkl")

# Generated at 2022-06-11 21:56:50.766710
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    
    # Test work_in_progress as a decorator
    obj = load_file("./__init__.py")
    assert type(obj) is dict
    # Test work_in_progress as a context manager
    with work_in_progress("Saving file"):
        with open("./test_work_in_progress.pkl", "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:55.154619
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress(desc="Work in progress")
    def sleep_func(duration):
        time.sleep(duration)

    sleep_func(duration=10)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:56.475308
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        pass

# Generated at 2022-06-11 21:57:05.115771
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time

# Generated at 2022-06-11 21:57:06.878435
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Work in progress"):
        time.sleep(1)



# Generated at 2022-06-11 21:58:38.333435
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    with work_in_progress("Saving file"):
        pass

# Generated at 2022-06-11 21:58:43.851423
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert obj is not None

# Generated at 2022-06-11 21:58:51.088535
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    @work_in_progress("Load file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Save file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")
    save_file("/path/to/save/file", obj)

# Generated at 2022-06-11 21:59:01.179991
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("../other/model.pkl")
    assert len(obj) > 0
    with work_in_progress("Saving file"):
        with open("../other/test.pkl", "wb") as f:
            pickle.dump(obj, f)
        time.sleep(1)

    time.sleep(4)
    with work_in_progress():
        time.sleep(1)
        
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:59:13.716187
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path:str = "../tests/test_file.pkl"):
        with open(path, "rb") as f:
            return pickle.load(f)
    loaded_file = load_file()
    assert len(loaded_file) == 10
    time.sleep(2)
    print("\n")
    with work_in_progress("Saving file") as f:
        with open("../tests/test_file.pkl", "wb") as f:
            pickle.dump(loaded_file, f)
    assert os.path.exists("../tests/test_file.pkl")
    os.remove("../tests/test_file.pkl")

if __name__ == "__main__":
    test_work_in_

# Generated at 2022-06-11 21:59:18.292385
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    with work_in_progress("Saving file"):
        time.sleep(2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:59:18.600328
# Unit test for function work_in_progress
def test_work_in_progress():
    pass

# Generated at 2022-06-11 21:59:20.267016
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Doing something"):
        time.sleep(0.0001)

    @work_in_progress("Doing something else")
    def do_something_else():
        time.sleep(0.0001)

    do_something_else()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:59:26.401591
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file", show_time=False)
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file", show_time=False):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


# Generated at 2022-06-11 21:59:34.249280
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3)
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    assert load_file("/path/to/some/file") == (1, 2, 3)
    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump((1, 2, 3), f)
