

# Generated at 2022-06-11 21:49:49.480379
# Unit test for function work_in_progress
def test_work_in_progress():
    # Case 1
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    # Case 2
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:49:52.622712
# Unit test for function work_in_progress
def test_work_in_progress():
    def func(n):
        with work_in_progress("Processing %d" % (n,)):
            time.sleep(n / 10)

    func(1)
    func(2)
    func(3)



# Generated at 2022-06-11 21:49:54.043722
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Progress"):
        time.sleep(0.2)

# Generated at 2022-06-11 21:50:02.899888
# Unit test for function work_in_progress
def test_work_in_progress():
    def func1(a=10, b=2): time.sleep(a/b)
    def func2(c=100, d=10): time.sleep(c/d)
    def func3(e): time.sleep(e)
    
    with work_in_progress("Test 1"):
        func1()
    with work_in_progress("Test 2"):
        func2(d=2)
    with work_in_progress("Test 3"):
        func3(1)


# Generated at 2022-06-11 21:50:10.912257
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:15.253914
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump({}, f)
    
    load_file("/path/to/some/file")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:21.287139
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    assert load_file.__name__ == "load_file"

    obj = load_file(__file__)
    assert obj == open(__file__, "rb").read()

# Generated at 2022-06-11 21:50:25.433450
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Test work_in_progress_context...", end=" ", flush=True)
    begin_time = time.time()
    with work_in_progress("Loading file"):
        with open("work_in_progress.py", "rb") as f:
            pickle.load(f)
    time_consumed = time.time() - begin_time
    print(f"done. ({time_consumed:.2f}s)")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:31.935058
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(0.5)
        with open(path, "rb") as f:
            return pickle.load(f)

    with open("data.pkl", 'wb') as f:
        pickle.dump(None, f)

    obj = load_file("data.pkl")

# Generated at 2022-06-11 21:50:36.783987
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    @work_in_progress("Saving file")
    def save_file():
        time.sleep(2)
    save_file()

if __name__ == "__main__":
    try:
        test_work_in_progress()
    except:
        traceback.print_exc()
        input("Press any key to quit...")

# Generated at 2022-06-11 21:50:44.550328
# Unit test for function work_in_progress
def test_work_in_progress():
    print(
        "This unit test for function work_in_progress prints a message that"
        " looks like this:"
        "\n"
        "Work in progress... done. (2.34s)"
    )
    with work_in_progress("Work in progress"):
        time.sleep(2.34)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:50:47.693457
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import random

    with work_in_progress("Sorting array"):
        a = []
        for _ in range(10000):
            a.append(random.random())
        a.sort()
    # Output
    # Sorting array... done. (0.04s)

# Generated at 2022-06-11 21:50:58.778176
# Unit test for function work_in_progress
def test_work_in_progress():
    from unittest.mock import patch
    @patch("sys.stdout")
    def test_decorator(stdout):
        @work_in_progress("Loading file")
        def func():
            time.sleep(0.1)
        func()
        stdout.write.assert_called_with("Loading file... ")
        stdout.flush.assert_called_with()

    def test_context_manager():
        with patch("sys.stdout") as stdout:
            with work_in_progress("Loading file"):
                time.sleep(0.1)
            stdout.write.assert_called_with("Loading file... ")
            stdout.flush.assert_called_with()
    test_decorator()
    test_context_manager()

# Generated at 2022-06-11 21:51:04.160367
# Unit test for function work_in_progress
def test_work_in_progress():
    import unittest
    import random
    import time

    class TestWorkInProgress(unittest.TestCase):
        def test(self):
            def foo():
                with work_in_progress("foo"):
                    time.sleep(0.2 + random.random() * 0.8)

            foo()

# Generated at 2022-06-11 21:51:07.451231
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing function work_in_progress"):
        time.sleep(1.0)
    print("Passed!")

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:51:15.045873
# Unit test for function work_in_progress
def test_work_in_progress():
    test_path = osp.expanduser("~/test_file")

    with open(test_path, "wb") as f:
        pickle.dump(['a', 'b', 'c', 'd'], f)

    # test function call
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    _ = load_file(test_path)

    # test context manager
    with work_in_progress("Saving file"):
        with open(test_path, "wb") as f:
            pickle.dump(['a', 'b', 'c', 'd'], f)

    os.remove(test_path)

# Generated at 2022-06-11 21:51:20.916435
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test nohup mode
    with work_in_progress("Doing nothing"):
        pass

    # Check exception cases
    try:
        with work_in_progress("Raising exception"):
            raise RuntimeError("I am an exception!")
    except RuntimeError:
        pass

import pickle
import random
import string

__all__ = [
    "save_pickle",
    "load_pickle",
]


# Generated at 2022-06-11 21:51:29.264631
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import string
    import os

    desc = "".join(random.choices(string.ascii_letters, k=8))
    with work_in_progress(desc):
        time.sleep(random.random())

    @work_in_progress(desc)
    def work():
        time.sleep(random.random())

    work()

    path1 = "tmp.bin"
    data1 = os.urandom(10 * 1024 * 1024)
    path2 = "tmp.bin"
    data2 = os.urandom(20 * 1024 * 1024)
    with work_in_progress("Testing") as w:
        with open(path1, "wb") as f:
            f.write(data1)

# Generated at 2022-06-11 21:51:31.562982
# Unit test for function work_in_progress
def test_work_in_progress():
    def dummy_func():
        time.sleep(3.7)

    with work_in_progress():
        dummy_func()
    dummy_func()



# Generated at 2022-06-11 21:51:40.312815
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test that function work_in_progress works as expected.
    """
    # Test the context manager
    with work_in_progress("Testing work_in_progress") as test:
        time.sleep(0.3)
    assert True, "work_in_progress context manager did not work"

    # Test the decorator
    @work_in_progress("Testing work_in_progress")
    def test():
        time.sleep(0.3)
    test()
    assert True, "work_in_progress decorator did not work"

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:51.743993
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path) as f:
            return f.read()

    @work_in_progress("Saving file")
    def save_file(path, content):
        with open(path, "w+") as f:
            f.write(content)

    with tempfile.TemporaryDirectory() as tmp_dir:
        file_path = os.path.join(tmp_dir, "test.txt")
        save_file(file_path, "testing")

        with work_in_progress("Removing files"):
            os.remove(file_path)

        load_file(file_path)

# Generated at 2022-06-11 21:51:55.558298
# Unit test for function work_in_progress
def test_work_in_progress():
    with contextlib.redirect_stdout(None):
        with work_in_progress("Testing work_in_progress"):
            time.sleep(0.1)

# Generated at 2022-06-11 21:52:04.693884
# Unit test for function work_in_progress
def test_work_in_progress():
    def func():
        time.sleep(1)

    func_desc = "function"
    # Simple coverage test
    func()

    start_time = time.time()
    func()
    assert abs(time.time() - start_time - 1) < 1e-3

    # Test function decorator
    @work_in_progress(func_desc)
    def func():
        time.sleep(1)
    start_time = time.time()
    func()
    assert abs(time.time() - start_time - 1) < 1e-3

    # Test with statement
    with work_in_progress(func_desc):
        time.sleep(1)
    assert abs(time.time() - start_time - 1) < 1e-3

    # Test with context manager in function

# Generated at 2022-06-11 21:52:08.733918
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test work in progress"):
        time.sleep(0.5)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:15.333448
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:52:20.975545
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import os
    import tempfile

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with tempfile.TemporaryDirectory() as tmpdir:
        obj = {"foo": "bar"}
        with open(os.path.join(tmpdir, "some_file"), "wb") as f:
            pickle.dump(obj, f)
        assert load_file(os.path.join(tmpdir, "some_file")) == obj

    with work_in_progress("Saving file"):
        with tempfile.TemporaryDirectory() as tmpdir:
            with open(os.path.join(tmpdir, "some_file"), "wb") as f:
                pickle.dump

# Generated at 2022-06-11 21:52:24.358888
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing: work_in_progress", end="")
    assert 0

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:28.458171
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing logging")
    def test_func(num: int):
        time.sleep(num)

    test_func(3)
    with work_in_progress("Testing with contextlib"):
        time.sleep(5)

# Generated at 2022-06-11 21:52:32.099745
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Working in process"):
        time.sleep(1)
    #
    with work_in_progress("Working in process"):
        time.sleep(2)


if __name__ == '__main__':

    test_work_in_progress()

# Generated at 2022-06-11 21:52:43.652226
# Unit test for function work_in_progress
def test_work_in_progress():
    import sys
    import io
    import os
    import pickle

    backup = sys.stdout
    sys.stdout = io.StringIO()

    def create_test_file(path):
        with open(path, "wb") as f:
            pickle.dump(range(100_000), f)

    with work_in_progress("Creating test file") as t:
        create_test_file("test_file")
    # t: loading...
    assert "Loading" in t._enter_message()

    with work_in_progress("Loading test file") as t:
        load_file("test_file")
    # t: loading... done. (3.52s)
    assert "Loading" in t._exit_message(None, None, None)

# Generated at 2022-06-11 21:52:53.920003
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "test/test_encoding_output.pkl"
    with open(path, "wb") as f:
        pickle.dump(obj=np.random.rand(100, 100), file=f)
    load_file(path)

# Generated at 2022-06-11 21:52:56.674570
# Unit test for function work_in_progress
def test_work_in_progress():
    def f():
        time.sleep(1)
    with work_in_progress("Loading file"):
        f()
    with work_in_progress("Loading file"):
        pass

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:53:07.857529
# Unit test for function work_in_progress
def test_work_in_progress():
    def await_asyncio_sleep(seconds):
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(asyncio.sleep(seconds))
        loop.close()

    @work_in_progress("Work item 1")
    def work_item_1():
        time.sleep(1)

    @work_in_progress("Work item 2")
    def work_item_2():
        await_asyncio_sleep(1)

    work_item_1()
    work_item_2()

    with work_in_progress("Work item 3"):
        time.sleep(1)

    with work_in_progress("Work item 4"):
        await_asyncio_sleep(1)

# Generated at 2022-06-11 21:53:16.206499
# Unit test for function work_in_progress
def test_work_in_progress():
    # Work in progress decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # Print to stdout.

# Generated at 2022-06-11 21:53:18.962326
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(2)
    print("Hello World!")


# Generated at 2022-06-11 21:53:26.245317
# Unit test for function work_in_progress
def test_work_in_progress():

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load():
        return load_file("/path/to/some/file")

    def save(content):
        with open(path, "wb") as f:
            pickle.dump(content, f)

    with work_in_progress("Saving object"):
        save(obj)

    time.sleep(0.02)
    load()
    time.sleep(0.02)
    assert True

# Generated at 2022-06-11 21:53:31.533280
# Unit test for function work_in_progress
def test_work_in_progress():
    # Loading file
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    # Saving file
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:53:34.824048
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(.15)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:53:42.293041
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    path = "/path/to/some/other/file"
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:53:44.545557
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(0.07)
    def func():
        with work_in_progress("Test2"):
            time.sleep(0.07)
    func()

# Generated at 2022-06-11 21:54:02.842763
# Unit test for function work_in_progress
def test_work_in_progress():
    for i in range(5):
        with work_in_progress("Doing something"):
            time.sleep(0.5)

    def do_something():
        time.sleep(0.5)

    @work_in_progress("Doing something")
    def do_something():
        time.sleep(0.5)

    for i in range(5):
        do_something()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:09.683680
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    return 0

# Generated at 2022-06-11 21:54:15.156992
# Unit test for function work_in_progress
def test_work_in_progress():
    # Set a dummy function
    def _f():
        time.sleep(3)
    # Test context manager
    with work_in_progress("Test context manager"):
        _f()
    # Test decorator
    @work_in_progress("Test decorator")
    def _g():
        _f()
    _g()

# Generated at 2022-06-11 21:54:23.632859
# Unit test for function work_in_progress
def test_work_in_progress():
    class Object:
        pass

    path = "/path/to/some/file"
    obj = Object()

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with open(path, "wb") as f:
        pickle.dump(obj, f)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    assert load_file(path) == obj

# Generated at 2022-06-11 21:54:28.704131
# Unit test for function work_in_progress
def test_work_in_progress():
    def test1():
        with work_in_progress("Work in progress..."):
            time.sleep(2)

    def test2():
        @work_in_progress("Work in progress...")
        def inner():
            time.sleep(2)
        inner()

    import unittest
    unittest.TestCase().assertTrue(test1)
    unittest.TestCase().assertTrue(test2)

# Generated at 2022-06-11 21:54:32.592776
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1.5)
    print()

    @work_in_progress("Saving file")
    def save_file():
        time.sleep(1.5)

    save_file()



# Generated at 2022-06-11 21:54:39.104015
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Loading file"):
        obj = load_file("/path/to/some/file")

    path = "/path/to/some/file"
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:54:45.282200
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/file")
    save_file("/path/to/file", obj)

# Generated at 2022-06-11 21:54:49.566106
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    
    assert load_file(os.path.join(os.path.dirname(__file__), "test.bin")) == 42

# Generated at 2022-06-11 21:54:53.664195
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def f(x, y):
        time.sleep(0.2)
        return x + y
    assert f(1, 2) == 3

# Generated at 2022-06-11 21:55:23.733902
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj1 = load_file("test_data/test.pkl")
    begin_time = time.time()
    with open("test_data/test.pkl", "rb") as f:
        obj2 = pickle.load(f)
    time_consumed = time.time() - begin_time
    assert obj1 == obj2

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:55:28.664003
# Unit test for function work_in_progress
def test_work_in_progress():
    t0 = time.time()
    with work_in_progress("Test work in progress"):
        for i in range(100):
            time.sleep(0.1)
    t1 = time.time()
    assert(t1 - t0 > 10)

# Generated at 2022-06-11 21:55:32.594577
# Unit test for function work_in_progress
def test_work_in_progress():
    def func():
        time.sleep(1)
        return 42
    with work_in_progress("Running test"):
        num = func()
        assert num == 42

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:55:36.688026
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("test_data/test_work_in_progress.pickle")
    assert obj == "hello world!"
    assert isinstance(obj, str)

    with work_in_progress():
        time.sleep(0.5)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:55:43.880485
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    
    obj = load_file("/path/to/some/file")
    assert type(obj) is dict


# In terminal/command line, you can run the unit test using the following command:
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:55:55.684533
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import random
    import tempfile

    @work_in_progress("Creating temporary directory")
    def create_tempdir():
        return tempfile.TemporaryDirectory()

    @work_in_progress("Creating temporary file")
    def create_tempfile():
        f = tempfile.TemporaryFile()
        f.write(bytes(random.randint(0, 255) for _ in range(1024 ** 2)))
        f.seek(0)
        return f

    @work_in_progress("Loading file")
    def read_file(f):
        return f.read()

    @work_in_progress("Saving file")
    def write_file(buf):
        with tempfile.TemporaryFile() as f:
            f.write(buf)
            return f


# Generated at 2022-06-11 21:56:05.589959
# Unit test for function work_in_progress
def test_work_in_progress():

    print("Testing work_in_progress()")

    with work_in_progress("Loading file"):
        for i in range(10000000):
            pass

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "data/test.txt"

    with open(path, "w") as f:
        f.write("Test text file.\n")

    with work_in_progress("Loading file"):
        text = load_file(path)

    assert text == "Test text file.\n", text


# Generated at 2022-06-11 21:56:15.035209
# Unit test for function work_in_progress
def test_work_in_progress():
    import pathlib

    # /!\ Allow to run unit tests with pytest from project root folder
    # or from this module's folder
    TEST_FILE = pathlib.Path(__file__).parent.resolve() / "work_in_progress.pickle"
    # TEST_FILE = pathlib.Path(__file__).parent.parent.resolve() / "work_in_progress.pickle"

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(data, path):
        with open(path, "wb") as f:
            pickle.dump(data, f)


# Generated at 2022-06-11 21:56:19.130254
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Very important task"):
        time.sleep(1)

    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-11 21:56:23.397538
# Unit test for function work_in_progress
def test_work_in_progress():
    import sys
    import pickle

    def load_file(path: str) -> int:
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file_wip(path: str) -> int:
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path: str, obj: int) -> None:
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    @work_in_progress("Saving file")
    def save_file_wip(path: str, obj: int) -> None:
        with open(path, "wb") as f:
            pickle.dump(obj, f)

   

# Generated at 2022-06-11 21:57:08.958756
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress
    def slow_func():
        time.sleep(2)
    slow_func()


# Common functions for unit testing

# Generated at 2022-06-11 21:57:14.884052
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Loading file"):
        obj = load_file("/path/to/some/file")

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


# Generated at 2022-06-11 21:57:19.887128
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file", n_iter=1):
        time.sleep(3.52)
    with work_in_progress("Saving file", n_iter=1):
        time.sleep(3.78)



if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:57:23.879987
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(1.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:57:26.065825
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test work in progress")
    def test_func():
        time.sleep(0.5)
    test_func()

# Generated at 2022-06-11 21:57:31.826475
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")



# Generated at 2022-06-11 21:57:38.490932
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:57:49.299733
# Unit test for function work_in_progress
def test_work_in_progress():
    from io import StringIO
    from contextlib import redirect_stdout
    from tempfile import gettempdir, TemporaryDirectory
    from os import path

    f = StringIO()
    with redirect_stdout(f):
        with work_in_progress("This is a work in progress"):
            time.sleep(1)
    assert f.getvalue() == "This is a work in progress... done. (1.00s)\n"

    f = StringIO()

# Generated at 2022-06-11 21:57:57.761337
# Unit test for function work_in_progress
def test_work_in_progress():
    # A basic example usage.
    with work_in_progress("Loading file"):
        time.sleep(random.random())

    # A basic example usage of a decorator.
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(random.random())

    load_file("/path/to/some/file")


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:58:02.559757
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("tests/files/test_files.pickle")

    with work_in_progress("Saving file"):
        with open("tests/files/test_files.pickle", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:59:34.906738
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:59:38.167191
# Unit test for function work_in_progress
def test_work_in_progress():
    for i in range(40000):
        time.sleep(0.1)
        with work_in_progress("hello") as w:
            print("hello")
            time.sleep(w)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:59:42.354154
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test function ``work_in_progress``.
    """
    desc = "work_in_progress"
    with work_in_progress(desc):
        time.sleep(1)
    assert True


if __name__ == "__main__":
    pass