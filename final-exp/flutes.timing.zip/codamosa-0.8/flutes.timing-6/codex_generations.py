

# Generated at 2022-06-11 21:49:49.437029
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Loading file...", end='', flush=True)
    begin_time = time.time()
    time.sleep(1.23)
    time_consumed = time.time() - begin_time
    print(f" done. ({time_consumed:.2f}s)")

# Generated at 2022-06-11 21:49:57.520915
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test cases for function work_in_progress."""

    # Testing context manager
    with work_in_progress():
        time.sleep(0.5)

    # Testing function decorator
    @work_in_progress()
    def f():
        time.sleep(0.3)

    f()

    # Testing both
    @work_in_progress("Working")
    def g():
        time.sleep(0.2)

    g()

# pylint: disable=unused-import
# Testing the module
from pytoolcore.testing.context_testing import test_context
test_context(test_work_in_progress, __file__)

# Generated at 2022-06-11 21:50:01.749754
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work in progress")
    def work():
        time.sleep(0.1)

    work()


# Main function.

# Generated at 2022-06-11 21:50:05.230467
# Unit test for function work_in_progress
def test_work_in_progress():
    # Work In Progress test
    with work_in_progress("Wait 3 second"):
        time.sleep(3)
    assert(True)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:50:12.185901
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("../tests/file.pickle")

    with work_in_progress("Saving file"):
        with open("../tests/file.pickle", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:50:14.664115
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress", "test_log.txt"):
        time.sleep(1)
        assert True

# Generated at 2022-06-11 21:50:20.521804
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("test"):
        time.sleep(1)
    # just to make sure it's working in a context or not
    load_file = work_in_progress("load file")(lambda path: None)
    assert "with" in load_file.__code__.co_varnames



# Generated at 2022-06-11 21:50:29.001321
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(3.52)  # 3.52s
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert obj is not None

    with work_in_progress("Saving file"):
        time.sleep(3.78)  # 3.78s
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()
    # TODO: test function with_spinner

# Generated at 2022-06-11 21:50:37.078235
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    path = "test/test_work_in_progress.pkl"
    obj = load_file(path)
    assert isinstance(obj, dict)
    assert obj["a"] == 1
    assert obj["b"] == "hello"

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with work_in_progress():
        time.sleep(3)

# Generated at 2022-06-11 21:50:42.465764
# Unit test for function work_in_progress
def test_work_in_progress():
    l = []
    with work_in_progress("Performing 5 dummy operations"):
        for i in range(5):
            time.sleep(.1)
            l.append(i)

    assert l == [0, 1, 2, 3, 4]


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:50:46.572056
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing..."):
        print("Work in progress")



# Generated at 2022-06-11 21:50:49.519498
# Unit test for function work_in_progress
def test_work_in_progress():
    out = io.StringIO()
    with contextlib.redirect_stdout(out):
        with work_in_progress("do foo"):
            time.sleep(1)
    assert out.getvalue() == "do foo... done. (1.00s)\n"

# Generated at 2022-06-11 21:50:52.553447
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(2)

    with work_in_progress("Saving file"):
        time.sleep(3)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-11 21:50:59.488816
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    >>> @work_in_progress("Loading file")
    ... def load_file(path):
    ...     with open(path, "rb") as f:
    ...         return pickle.load(f)
    ...
    >>> load_file("/path/to/some/file")
    Loading file... done. (1.00s)

    """
    pass # pylint: disable=unnecessary-pass

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:51:03.473397
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    print("end")


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:51:09.815416
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    with work_in_progress("Loading file"):
        with open("/path/to/some/file", "rb") as f:
            obj = pickle.load(f)
    
    with work_in_progress("Saving file"):
        with open("/path/to/another/file", "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:18.513883
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    path = "/tmp/__test_work_in_progress.pkl"
    obj = "Hello World!"

    with work_in_progress("Saving file"):
        save_file(path)

    with work_in_progress("Loading file"):
        obj_loaded = load_file(path)

    assert os.path.exists(path)
    assert obj_loaded == obj

    os.remove(path)

# Generated at 2022-06-11 21:51:25.310899
# Unit test for function work_in_progress
def test_work_in_progress():
    # 1. Load a large file
    with work_in_progress("Loading large file"):
        time.sleep(12)
    # 2. Save a large file
    with work_in_progress("Save large file"):
        time.sleep(15)
    # 3. Run a function call
    @work_in_progress("Executing function")
    def foo():
        time.sleep(20)
    foo()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:30.958711
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert isinstance(obj, dict)

# Generated at 2022-06-11 21:51:41.605822
# Unit test for function work_in_progress
def test_work_in_progress():
    import sys
    import io
    import unittest
    import subprocess

    class TestWorkInProgress(unittest.TestCase):
        def setUp(self):
            self.saved_stdout = sys.stdout
            self.saved_stderr = sys.stderr
            self.devnull = open(os.devnull, "w")
            sys.stdout = self.devnull
            sys.stderr = self.devnull

        def tearDown(self):
            self.devnull.close()
            sys.stdout = self.saved_stdout
            sys.stderr = self.saved_stderr


# Generated at 2022-06-11 21:51:47.531026
# Unit test for function work_in_progress
def test_work_in_progress():
    def foo():
        time.sleep(3)
    with work_in_progress() as w:
        foo()
    assert "Work in progress" in w
    assert "done" in w


# Generated at 2022-06-11 21:51:49.741904
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test work in progress"):
        time.sleep(1)

test_work_in_progress()

# Generated at 2022-06-11 21:51:55.308799
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test")
    def foo(x, y):
        time.sleep(2)
        return x + y
    assert foo(1, 2) == 3

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:58.871441
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    with work_in_progress():
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:03.561122
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test for function work_in_progress."""

    @work_in_progress("Loading file")
    def load_file():
        time.sleep(1)

    with work_in_progress("Saving file"):
        time.sleep(2)

    load_file()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:52:05.746164
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress(desc="Loading file"):
        time.sleep(2)
    with work_in_progress(desc="Saving file"):
        time.sleep(3)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:52:15.418931
# Unit test for function work_in_progress
def test_work_in_progress():
    # Use work_in_progress in a context manager
    with work_in_progress("Saving file"):
        with open("tests/test_work_in_progress.txt", "w") as f:
            f.write("")

    # Use work_in_progress as a decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "r") as f:
            return f.read()

    # Trigger the decorated function
    load_file("tests/test_work_in_progress.txt")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:16.852148
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(2)

# Generated at 2022-06-11 21:52:20.404770
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
        # Saving file... done. (3.78s)

# Generated at 2022-06-11 21:52:23.135238
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test of work_in_progress"):
        time.sleep(1)
        assert True

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:31.289722
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        # Simulate loading
        time.sleep(2)
        return 0

    load_file("/path/to/some/file")

# Generated at 2022-06-11 21:52:35.781289
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    load_file("/path/to/some/file")
    save_file("/path/to/some/file")

# Generated at 2022-06-11 21:52:41.719948
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test with a context manager
    with work_in_progress("Testing context manager"):
        time.sleep(1)

    # Test with a decorator
    @work_in_progress("Testing decorator")
    def func():
        time.sleep(1)

    func()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:43.592173
# Unit test for function work_in_progress

# Generated at 2022-06-11 21:52:49.120737
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:53.567314
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:52:56.181800
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Testing"):
        time.sleep(0.5)

# Execute unit tests
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:53:07.620046
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile
    from datetime import datetime
    import pickle

    def in_tempdir(func):
        path = tempfile.TemporaryDirectory().name
        print(path)
        @contextlib.contextmanager
        def wrapper():
            try:
                with work_in_progress(f"Creating dir in {path!r}"):
                    os.makedirs(path)
                yield path
            finally:
                with work_in_progress(f"Deleting dir {path!r}"):
                    os.rmdir(os.path.split(path)[0])

        return wrapper()

    from .dict_utils import dotdict
    from . import color


# Generated at 2022-06-11 21:53:13.043871
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


# Unit test the module.
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:53:19.885479
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3)
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:53:32.111260
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sleeping"):
        time.sleep(2)

# Entry point for the test suite

# Generated at 2022-06-11 21:53:33.163248
# Unit test for function work_in_progress
def test_work_in_progress():
    fast_work()
    slow_work()


# Generated at 2022-06-11 21:53:35.018970
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing"):
        time.sleep(0.5)

# Generated at 2022-06-11 21:53:41.778944
# Unit test for function work_in_progress
def test_work_in_progress():
    # Loading file
    with work_in_progress("Loading file"):
        time.sleep(1.5)

    # Saving file
    with work_in_progress("Saving file"):
        time.sleep(2)

    # Test with error case
    try:
        with work_in_progress("Error"):
            raise ValueError("Something wrong")
    except ValueError:
        pass


if __name__ == "__main__":
    # Running unit tests
    test_work_in_progress()

# Generated at 2022-06-11 21:53:44.647439
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def f():
        time.sleep(1)
    f()
    with work_in_progress():
        time.sleep(1)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:53:53.452228
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import pickle

    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump("I'm a very big file", f)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "/tmp/file"

    with work_in_progress("Saving file"):
        save_file(path)

    obj = load_file(path)

    # Cleanup
    os.remove(path)

# Generated at 2022-06-11 21:53:55.183981
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        obj = []
        for i in range(50000):
            obj.append(i)
        time.sleep(0.01)

# Generated at 2022-06-11 21:54:00.479469
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)
        time.sleep(0.52)

    assert True

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:05.481821
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:54:09.788829
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("I'm doing some trivial task.")
    def _do_something_trivial():
        time.sleep(2)

    _do_something_trivial()

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:54:41.252599
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import os

    def tmp_path(suffix: str = "") -> str:
        """Return a path to a temporary file.

        :param suffix: Suffix of the temporary file. (default = "")
        :type suffix: str
        :return: A path to a temporary file.
        :rtype: str
        """
        from tempfile import gettempdir
        from uuid import uuid4
        return os.path.join(gettempdir(), str(uuid4()) + suffix)

    def load_file(path: str) -> dict:
        """Same as ``pickle.load``."""
        return pickle.load(open(path, "rb"))

    def save_file(obj: dict, path: str):
        """Same as ``pickle.dump``."""
        pickle.dump

# Generated at 2022-06-11 21:54:45.840514
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def main(test_str):
        time.sleep(1)
        return test_str

    r = main("hello, world")
    print(r)
    assert r == "hello, world"

# Generated at 2022-06-11 21:54:54.158823
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import string

    # test case 1
    with work_in_progress("Do something random"):
        time.sleep(0.2)

    # test case 2
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:55:01.478558
# Unit test for function work_in_progress
def test_work_in_progress():
    timeout = time.time() + 1  # Time out in 1 seconds
    begin_time = time.time()
    with work_in_progress():
        while time.time() < timeout:
            pass
    time_consumed = time.time() - begin_time
    print(f"{time_consumed:.2f}s is consumed by work_in_progress.")
    assert abs(time_consumed - 1.0) < 0.1


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:55:02.790566
# Unit test for function work_in_progress
def test_work_in_progress():
    def f():
        time.sleep(1)

    with work_in_progress("Test"):
        f()

# Generated at 2022-06-11 21:55:12.833376
# Unit test for function work_in_progress
def test_work_in_progress():
    # A simple function wrapped in @work_in_progress
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # A simple pass with @work_in_progress as it is a context manager
    with work_in_progress("Saving file"):
        pass

    # A function wrapped in a with block of @work_in_progress
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with work_in_progress("Saving file"):
        save_file("/path/to/some/file")

# Generated at 2022-06-11 21:55:14.987144
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def test_func():
        time.sleep(1)
    test_func()

test_work_in_progress()

# Generated at 2022-06-11 21:55:21.024269
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test function :func:`work_in_progress`."""
    with work_in_progress("Test"):
        time.sleep(0.5)

# runs test if file executed as script
if __name__ == "__main__":
    import pytest # import pytest before testing to make sure pytest is installed correctly
    pytest.main(['-s', __file__])

# Generated at 2022-06-11 21:55:29.202705
# Unit test for function work_in_progress
def test_work_in_progress():
    print("# Testing 'work_in_progress'")

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    # Loading file... done. (3.52s)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    # Saving file... done. (3.78s)

# Generated at 2022-06-11 21:55:35.950232
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test work_in_progress in function
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    path = "test/test.pickle"
    load_file(path) # Should output 'Loading file... done. (0.01s)'

    # Test work_in_progress in block
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump({"Test": "test"}, f)
    # Should output 'Saving file... done. (0.01s)'


# Generated at 2022-06-11 21:56:21.465151
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.25)
        print("Some functionality")
        time.sleep(0.25)

# Generated at 2022-06-11 21:56:26.590588
# Unit test for function work_in_progress
def test_work_in_progress():
    with open("/dev/null", "w") as f:
        with contextlib.redirect_stdout(f):
            with work_in_progress("Unit tests"):
                time.sleep(0.1)
            with work_in_progress("Unit tests"):
                time.sleep(1)
            with work_in_progress("Unit tests"):
                time.sleep(2)
            with work_in_progress("Unit tests"):
                time.sleep(5)

# Generated at 2022-06-11 21:56:30.391449
# Unit test for function work_in_progress
def test_work_in_progress():
    # works if no exception raised
    time.sleep(1)
    with work_in_progress("Sleeping for 1s"):
        time.sleep(1)


# Generated at 2022-06-11 21:56:39.597440
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    import pickle
    import random
    import sys

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    buffer = io.BytesIO()
    with open(__file__, "rb") as f:
        buffer.write(f.read())
    buffer.seek(0)

    with work_in_progress("Saving file"):
        with open(__file__, "wb") as f:
            pickle.dump(buffer.read(), f)

    buffer.seek(0)
    obj = load_file(__file__)
    assert obj == buffer.read()

# Generated at 2022-06-11 21:56:44.662439
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3)
    with work_in_progress("Saving file"):
        time.sleep(4)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:46.640860
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.1)
    with work_in_progress("Saving file"):
        time.sleep(0.1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:49.885159
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Test Work in progress")
    def test_sleep():
        time.sleep(0.1)

    test_sleep()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:59.076112
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile
    import pickle

    dest_path = os.path.join(tempfile.gettempdir(), "test_work_in_progress_data.test")
    test_data = {
        "test": "data",
        "test1": "data2",
    }

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    for func in [save_file, load_file]:
        with work_in_progress():
            func(dest_path, test_data)
        assert obj == test_data, "Data not equal"
    os.remove(dest_path)

# Generated at 2022-06-11 21:57:00.781368
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Work in progress"):
        time.sleep(1)

# Generated at 2022-06-11 21:57:04.780808
# Unit test for function work_in_progress
def test_work_in_progress():
    # function work_in_progress
    with work_in_progress("Loading file"):
        time.sleep(3.5)

    # context manager work_in_progress
    with work_in_progress("Saving file"):
        time.sleep(3.8)

# Generated at 2022-06-11 21:58:32.312443
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Something"):
        time.sleep(2)

# Generated at 2022-06-11 21:58:40.794349
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    import sys

    # Change stdout to buffer in order to capture output.
    old_stdout = sys.stdout
    sys.stdout = buffer = io.StringIO()

    # Test context manager
    with work_in_progress("Context Manager"):
        time.sleep(0.01)

    # Test decorator
    @work_in_progress("Decorator")
    def sleep():
        time.sleep(0.01)

    sleep()

    # Reset stdout to original value.
    # This is required since the unit tests are run in parallel.
    sys.stdout = old_stdout
    print(buffer.getvalue())

# Generated at 2022-06-11 21:58:46.372003
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(3.5)

    load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        time.sleep(3.7)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:58:52.341589
# Unit test for function work_in_progress
def test_work_in_progress():
    func_list = [
        lambda: time.sleep(0.01),
        lambda: time.sleep(0.1),
        lambda: time.sleep(1),
        lambda: time.sleep(10),
    ]
    for func in func_list:
        with work_in_progress(desc="Testing"):
            func()


if __name__ == "__main__":
    import doctest
    doctest.testmod()
    test_work_in_progress()

# Generated at 2022-06-11 21:59:03.121999
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit Test for function work_in_progress."""

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("test"):
        time.sleep(0.1)

    @work_in_progress("test1")
    def test1():
        time.sleep(0.1)

    test1()

    path = "/tmp/test.p"

    with open(path, "wb") as f:
        pickle.dump(list(range(100)), f)

    with work_in_progress("Load"):
        load_file(path)


if __name__ == '__main__':
    # If a simple test was requested, run it
    import argparse
    parser = argparse.ArgumentParser()

# Generated at 2022-06-11 21:59:13.569817
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import os
    import pickle
    n = 1000
    a_list = list(range(n))
    with work_in_progress("Creating a large list"):
        time.sleep(0.5)

    # with work_in_progress("Saving a large list"):
    #     with open("tmp.pkl", "wb") as f:
    #         pickle.dump(a_list, f)
    #     os.remove("tmp.pkl")
    #
    # with work_in_progress("Loading a large list"):
    #     with open("tmp.pkl", "rb") as f:
    #         pickle.load(f)

# Generated at 2022-06-11 21:59:18.204592
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    with work_in_progress("Saving file"):
        time.sleep(2)


# Run unit tests
if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:59:22.887116
# Unit test for function work_in_progress
def test_work_in_progress():
    def test_function():
        with work_in_progress("Work in progress in function"):
            time.sleep(0.5)
    test_function()

    @work_in_progress("Work in progress in decorator")
    def test_function2():
        time.sleep(0.5)
    test_function2()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:59:30.254527
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:59:32.710685
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(2)

if __name__ == "__main__":
    test_work_in_progress()