

# Generated at 2022-06-11 21:49:52.429926
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "../test_file.pkl"
    test = load_file(path)

    with work_in_progress("Saving file"):
        path = "../test_file.pkl"
        with open(path, "wb") as f:
                pickle.dump(test, f)

    return True


# Generated at 2022-06-11 21:49:57.566710
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("loading"):
        time.sleep(0.5)
    with work_in_progress("processing"):
        time.sleep(0.5)
    with work_in_progress("saveing"):
        time.sleep(0.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:00.161911
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test work_in_progress"):
        time.sleep(1)


# Generated at 2022-06-11 21:50:02.679742
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for the function `work_in_progress`."""
    import doctest
    return doctest.testmod(verbose=True)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:50:09.412916
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    
    obj = load_file("data/random_int.pkl")
    return obj


if __name__ == '__main__':
    obj = test_work_in_progress()
    print(obj)

# Generated at 2022-06-11 21:50:15.354528
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test work_in_progress"""

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert True


# Generated at 2022-06-11 21:50:25.948478
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import logging

    logging.basicConfig(level=logging.WARNING)

    def _random_sleep(n=3):
        time.sleep(random.uniform(0.1, n))

    for i in range(20):
        print()
        with work_in_progress("Running a task"):
            _random_sleep()
        with work_in_progress("Running a task with logging"):
            logging.info("This is a test log.")
            _random_sleep(5)
        with work_in_progress("Running a failed task"):
            _random_sleep()
            raise RuntimeError("The task failed!")

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:50:36.321961
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile
    import pickle

    with tempfile.TemporaryDirectory() as path:
        @work_in_progress("Loading file")
        def load_file(path):
            with open(path, "rb") as f:
                return pickle.load(f)

        @work_in_progress("Saving file")
        def save_file(obj, path):
            with open(path, "wb") as f:
                pickle.dump(obj, f)

        save_file(os.urandom(10000), os.path.join(path, "file"))
        assert load_file(os.path.join(path, "file")) == os.urandom(10000)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:44.334879
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    with open("tests/data/dataset.pickle", "wb") as f:
        pickle.dump(list(range(10000000)), f)
    with work_in_progress("Saving file"):
        with open("tests/data/dataset.pickle", "wb") as f:
            pickle.dump(list(range(10000000)), f)
    assert True

# Generated at 2022-06-11 21:50:46.615000
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(3)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:56.341488
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(load_file(path), f)

    with open("_tmp_file", "wb") as f:
        pickle.dump(1, f)

    load_file("_tmp_file")
    save_file("_tmp_file")
    os.remove("_tmp_file")

# Generated at 2022-06-11 21:51:01.156177
# Unit test for function work_in_progress
def test_work_in_progress():
    from tempfile import TemporaryFile

    with work_in_progress("Saving file"):
        with TemporaryFile("wb") as f:
            obj = {"a": 1, "b": 2, "c": [3, 4, 5]}
            pickle.dump(obj, f)
    with work_in_progress("Loading file"):
        with TemporaryFile("rb") as f:
            pickle.load(f)

# Generated at 2022-06-11 21:51:11.768057
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for work_in_progress context manager."""
    with work_in_progress("Desc"):
        time.sleep(1.0)
    with work_in_progress("Desc"):
        time.sleep(2.0)
    with work_in_progress("Desc"):
        time.sleep(3.0)
    with work_in_progress("Desc"):
        time.sleep(4.0)
    with work_in_progress("Desc"):
        time.sleep(5.0)
    with work_in_progress("Desc"):
        time.sleep(6.0)
    with work_in_progress("Desc"):
        time.sleep(7.0)
    with work_in_progress("Desc"):
        time.sleep(8.0)

# Generated at 2022-06-11 21:51:18.072042
# Unit test for function work_in_progress
def test_work_in_progress():
    import subprocess

    with open(sys.argv[0], "rb") as f:
        code = f.read()

    for i in range(10):
        with work_in_progress("Running program"):
            subprocess.run(["python", sys.argv[0]], stdin=subprocess.PIPE,
                           stdout=subprocess.PIPE, input=code)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:19.864579
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("My task"):
        time.sleep(0.1)

# Generated at 2022-06-11 21:51:25.674522
# Unit test for function work_in_progress
def test_work_in_progress():
    # Testing as a context manager
    with work_in_progress("Testing as a context manager"):
        time.sleep(0.01)
    # Testing as a function decorator
    @work_in_progress("Testing as a function decorator")
    def test_decorator(x):
        time.sleep(0.01)
        return x
    test_decorator(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:35.713462
# Unit test for function work_in_progress
def test_work_in_progress():
    from pickle import dumps
    from pathlib import Path

    def slow_pickling():
        for _ in range(10000):
            dumps(None)

    # Saved file is removed in the end.
    saved_file_path = Path(__file__).parent / "saved_file"

    with work_in_progress("Pickling"):
        slow_pickling()

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file(saved_file_path)

    with work_in_progress("Saving file"):
        with open(saved_file_path, "wb") as f:
            pickle.dump(obj, f)

    saved_file_

# Generated at 2022-06-11 21:51:39.658793
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Loading file"):
        time.sleep(2.22)
    with work_in_progress("Saving file"):
        time.sleep(1.55)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:40.816946
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test 0"):
        time.sleep(3)

# Generated at 2022-06-11 21:51:44.713375
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Raising exception")
    def f():
        pass

    with raises(Exception):  # pylint: disable=pointless-statement
        f()

# vim: foldmethod=indent

# Generated at 2022-06-11 21:51:50.819598
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test-work_in_progress"):
        for i in range(1, 1000000):
            pass
    # Test whether the function returns True
    assert(True)


# Unit test

# Generated at 2022-06-11 21:51:52.406745
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("do this"):
        time.sleep(1)

# Generated at 2022-06-11 21:51:57.641949
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.5)
        raise KeyError("Stop here")
        time.sleep(0.5)
    with work_in_progress("Saving file"):
        time.sleep(0.5)



# Generated at 2022-06-11 21:52:03.731137
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:06.066725
# Unit test for function work_in_progress
def test_work_in_progress():

    def dummy_function():
        time.sleep(0.02)

    with work_in_progress("Doing something"):
        dummy_function()

# Generated at 2022-06-11 21:52:10.121771
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress():
        time.sleep(1.2345)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:16.626801
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/tmp/foo.dat")
    assert obj == "bar"

    with work_in_progress("Saving file"):
        with open("/tmp/foo.dat", "wb") as f:
            pickle.dump("bar", f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:22.101940
# Unit test for function work_in_progress
def test_work_in_progress():
    # Case 1: Simple usage
    with work_in_progress("Computing"):
        time.sleep(0.1)

    # Case 2: Wrong usage
    try:
        with work_in_progress(0):
            pass
    except TypeError as e:
        pass


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:28.761687
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # Test that the object loaded is a dict
    obj = load_file("/path/to/some/file")
    assert isinstance(obj, dict)

    # Test that the output is correct
    # NOTE: Linux color codes are stripped
    print(obj)

# Generated at 2022-06-11 21:52:31.645867
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.01)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:52:40.811041
# Unit test for function work_in_progress
def test_work_in_progress():
    def some_work(param):
        with work_in_progress("Work in progress"):
            time.sleep(param)

    some_work(0.3)
    print()

    with work_in_progress("Non-blocking work in progress"):
        time.sleep(0.5)
    print()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:44.743743
# Unit test for function work_in_progress
def test_work_in_progress():
    sample_function = work_in_progress("Testing work_in_progress")
    with sample_function:
        pass
    # The above should print out:
    # Testing work_in_progress... done. (0.00s)

# Generated at 2022-06-11 21:52:47.579635
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    
    obj = load_file("/path/to/some/file")

# Generated at 2022-06-11 21:52:49.652688
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(0.5)
    with work_in_progress("Sleeping..."):
        time.sleep(0.5)
    assert True

# Generated at 2022-06-11 21:52:50.809421
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("loading file"):
        time.sleep(2)

# Generated at 2022-06-11 21:52:58.242788
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import random

    import numpy
    import pandas
    from pandas.testing import assert_frame_equal

    from . import randomize_columns

    # https://docs.python.org/3.8/library/random.html#random.seed
    # In python there is a random seed and a numpy random seed.
    # The random seed is used by python pseudo-random number generators,
    # while the numpy seed is used by numpy pseudo-random number generators.
    # Changing the numpy seed will not affect the python seed.
    numpy.random.seed(0)
    random.seed(0)

    # Create a random pandas dataframe
    df = pandas.DataFrame(numpy.random.uniform(size=(100, 11)))

# Generated at 2022-06-11 21:53:07.950297
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")
    save_file(obj, "/path/to/some/file")
    return True

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:53:13.664890
# Unit test for function work_in_progress
def test_work_in_progress():
    test_desc = "This is a test string"
    test_function = work_in_progress(test_desc)
    sample_time = 5e-3
    assert not work_in_progress.__annotations__
    with test_function:
        time.sleep(sample_time)
    assert work_in_progress.__annotations__
    assert test_function.__annotations__
    assert test_function.__annotations__['desc'] is str
    assert test_function.__annotations__['return'] is None

# Generated at 2022-06-11 21:53:16.700088
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.5)
    with work_in_progress("Saving file"):
        time.sleep(0.5)

# Main
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:53:20.862122
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    with work_in_progress():
        time.sleep(1)

    @work_in_progress()
    def _():
        time.sleep(1)
    _()


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:53:30.223422
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    # Test the context manager
    with work_in_progress("Work #1"):
        time.sleep(2)

    # Test the context manager
    @work_in_progress("Work #2")
    def func():
        time.sleep(2)
    func()

    # Test the context manager
    @work_in_progress()
    def func():
        time.sleep(2)
    func()

# Generated at 2022-06-11 21:53:36.480338
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert obj is not None

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:53:41.261893
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test")
    def func():
        time.sleep(1)

    func()

    with work_in_progress("Test"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()
    # import IPython
    # IPython.embed()

# Generated at 2022-06-11 21:53:47.677255
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test work_in_progress."""
    @work_in_progress("Loading file")
    def load_file(path):
        """Load a file, sleeping some time."""
        with open(path, "rb") as f:
            data = pickle.load(f)
        time.sleep(1)
        return data

    @work_in_progress("Saving file")
    def save_file(path, data):
        """Save a file, sleeping some time."""
        with open(path, "wb") as f:
            pickle.dump(data, f)
        time.sleep(1)

    obj = load_file("/path/to/some/file")
    save_file("/path/to/some/file", obj)


if __name__ == "__main__":
    test_work_

# Generated at 2022-06-11 21:53:57.250199
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test function work_in_progress."""
    class Test(object):
        def __init__(self):
            self.a = 0

        @work_in_progress
        def dummy_method(self):
            self.a = 1

        @staticmethod
        @work_in_progress
        def dummy_method_static():
            i = 1 + 1

        @classmethod
        @work_in_progress
        def dummy_method_class(cls):
            s = "X" * 1000

        @staticmethod
        @work_in_progress
        def dummy_method_static_with_arg(arg1, arg2=None):
            if arg1 > 0 and arg2:
                i = arg1 + arg2

    tst = Test()
    # Instance method
    tst.dummy_method()


# Generated at 2022-06-11 21:54:02.794153
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress"""
    @work_in_progress("Test work in progress")
    def test(time_to_wait: float):
        time.sleep(time_to_wait)
    test(2.0)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:54:07.359808
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress function"):
        time.sleep(0.5)

# Comment to disable the unit test
test_work_in_progress()

# Generated at 2022-06-11 21:54:13.374761
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, "a.txt")
        with open(path, "w") as f:
            f.write("hello world")
        assert "hello world" == load_file(path)

# Generated at 2022-06-11 21:54:15.862138
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(1)
    pass


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:19.631030
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Count to 1,000,000 with for loop")
    def test_loop():
        count = 0
        for i in range(1_000_000):
            count = i

    test_loop()

# Generated at 2022-06-11 21:54:33.733637
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    print("")
    @work_in_progress("Saving file")
    def save_file():
        time.sleep(1)
    save_file()
    assert True # FIXME

# Generated at 2022-06-11 21:54:41.436890
# Unit test for function work_in_progress
def test_work_in_progress():
    path = '/tmp/some_file.pkl'

    # Using the decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file(path)

    # Using the context manager
    with open(path, "wb") as f:
        pickle.dump(obj, f)


# Generated at 2022-06-11 21:54:47.699626
# Unit test for function work_in_progress
def test_work_in_progress():
    test_object = [i for i in range(500)]  # Push it on the stack
    res = None  # Do not change the result

    def test_func():
        nonlocal res
        with work_in_progress("Testing work_in_progress"):
            res = test_object
        print(f"Result = {res}")

    test_func()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:54:55.478967
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress(desc="Testing work_in_progress"):
        time.sleep(0.5)

    @work_in_progress("Testing work_in_progress")
    def test_work_in_progress_decorator():
        time.sleep(0.5)

    test_work_in_progress_decorator()

# Module test
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:55:04.179735
# Unit test for function work_in_progress
def test_work_in_progress():
    test_data = b"0123456789" * 8192
    with work_in_progress("Creating large dummy data"):
        with open("_test_work_in_progress.tmp", "wb") as f:
            f.write(test_data)
    try:
        with work_in_progress("Removing dummy data"):
            os.remove("_test_work_in_progress.tmp")
    except Exception:
        pass
    @work_in_progress("Creating large dummy data")
    def create_large_dummy(path):
        with open(path, "wb") as f:
            f.write(test_data)
    create_large_dummy("_test_work_in_progress.tmp")

# Generated at 2022-06-11 21:55:04.755174
# Unit test for function work_in_progress
def test_work_in_progress():
    assert 1 == 1

# Generated at 2022-06-11 21:55:07.635170
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test the work_in_progress function.
    """
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1)

# Generated at 2022-06-11 21:55:14.800739
# Unit test for function work_in_progress
def test_work_in_progress():
    from collections import OrderedDict

    # Test 1:
    obj_1 = OrderedDict()
    obj_1["a"] = 1
    obj_1["b"] = 2
    obj_1["c"] = 3

    with work_in_progress("Loading file"):
        obj_2 = pickle.loads(pickle.dumps(obj_1, protocol=pickle.HIGHEST_PROTOCOL))

    assert obj_1 == obj_2

    # Test 2:
    pat

# Generated at 2022-06-11 21:55:22.316273
# Unit test for function work_in_progress
def test_work_in_progress():
    with mock.patch("sys.stdout") as mock_stdout:
        with work_in_progress("Test work_in_progress"):
            time.sleep(1.23)
    assert mock_stdout.write.call_args_list == [
        mock.call("Test work_in_progress... "),
        mock.call("done. (1.23s)"),
    ]


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:55:28.414507
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress."""
    # Error: desc missing
    with pytest.raises(TypeError):
        work_in_progress()


# This goes at the end to avoid circular imports
from .. import utils  # noqa: E402,F401

# Backward compatibility
_ = utils

# Generated at 2022-06-11 21:55:58.148658
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path, name):
        time.sleep(1)
        return [path, name]

    obj = load_file("/path/to/some/file", "cell")
    assert obj == ["/path/to/some/file", "cell"]

    with work_in_progress("Saving file"):
        time.sleep(1)
    return

# Generated at 2022-06-11 21:56:00.777423
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("test work in progress"):
        for i in range(2):
            time.sleep(1)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:56:07.837274
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:56:13.896357
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    # Loading file... done. (3.52s)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    # Saving file... done. (3.78s)



# Generated at 2022-06-11 21:56:16.943801
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(1.5)

# test_work_in_progress()

# Generated at 2022-06-11 21:56:17.722946
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test")
    def test():
        time.sleep(1)
    test()

# Generated at 2022-06-11 21:56:26.828439
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing work_in_progress()")

    #######################################################################
    print("\nExample of function decorator...")

    @work_in_progress("Calculating result")
    def calc_result() -> int:
        time.sleep(2)
        return 42

    result = calc_result()
    print(f"Function returned: {result}")

    #######################################################################
    print("\nExample of function decorator...")

    with work_in_progress("Calculating result"):
        time.sleep(2)
        result = 42

    print(f"Function returned: {result}")


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:56:33.361816
# Unit test for function work_in_progress
def test_work_in_progress():
    import unittest.mock
    with unittest.mock.patch("sys.stdout", new_callable=StringIO) as mock_stdout:
        with work_in_progress("Loading file"):
            pass
        assert mock_stdout.getvalue() == "Loading file... done. (0.00s)\n"


# Generated at 2022-06-11 21:56:33.926187
# Unit test for function work_in_progress
def test_work_in_progress():
    pass

# Generated at 2022-06-11 21:56:37.616831
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def run_test():
        time.sleep(0.01)
    run_test()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:57:24.808673
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("test"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:57:36.413871
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test the function work_in_progress.
    """
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    # Loading file... done. (3.52s)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    # Saving file... done. (3.78s)


if __name__ == "__main__":
    import pytest

# Generated at 2022-06-11 21:57:40.382147
# Unit test for function work_in_progress
def test_work_in_progress():
    assert True == True

if __name__ == "__main__":
    import pytest
    pytest.main(__file__)

# Generated at 2022-06-11 21:57:44.428249
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    
    obj = load_file("/path/to/some/file")


# Generated at 2022-06-11 21:57:50.386344
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    from .utility import compare_output

    @work_in_progress("Loading an array of 0s")
    def zero_array():
        time.sleep(0.1)
        return np.zeros(shape=(10, 10), dtype=np.float64)
    with compare_output("test_work_in_progress.out"):
        zero_array()
    assert (zero_array() == 0).all()

# Generated at 2022-06-11 21:57:58.252560
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    try:
        st = load_file("test_strings.pkl")
    except:
        print("Unable to load file.")
    else:
        assert st == "Test for progress function.\n"


# vim:sw=4:ts=4:et:

# Generated at 2022-06-11 21:57:59.410700
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("haha"):
        time.sleep(1)

# Generated at 2022-06-11 21:58:09.017618
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    # Test a function decorated with work_in_progress
    obj = load_file("/home/jyeh1/dev/python/jyio/.config/user.pkl")
    assert type(obj) == dict

    # Test a context manager
    obj = {"key": "value"}
    with work_in_progress("Saving file"):
        save_file("/tmp/some_file.pkl", obj)
    obj_loaded = load_file("/tmp/some_file.pkl")
    assert obj == obj

# Generated at 2022-06-11 21:58:18.446203
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import random

    def sample_func(size):
        return [random.random() for _ in range(size)]

    with work_in_progress("Sampling random numbers"):
        result = sample_func(int(1e6))
    print("OK")

    with work_in_progress("Saving data"):
        with open("sample_data.pkl", "wb") as f:
            pickle.dump(result, f)
    print("OK")

    def load_func(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading data")
    def load_func_with_decorator(path):
        with open(path, "rb") as f:
            return pickle.load(f)



# Generated at 2022-06-11 21:58:29.384145
# Unit test for function work_in_progress
def test_work_in_progress():
    time_consumed_1 = 0.0
    time_consumed_2 = 0.0
    def save_obj(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    def load_obj(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    @work_in_progress("Loading file")
    def load_file(path):
        global time_consumed_1
        time_consumed_1 = time.time()
        return load_obj(path)
    @work_in_progress("Saving file")
    def save_file(path, obj):
        global time_consumed_2
        time_consumed_2 = time.time()
        save_obj(path, obj)

