

# Generated at 2022-06-11 21:49:52.429923
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import pickle

    path = tempfile.mktemp()
    obj = {"test": True}

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    assert load_file(path) == obj

# Generated at 2022-06-11 21:49:56.280570
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Wait for 5 seconds"):
        time.sleep(5)
    with work_in_progress("Wait for 2 seconds"):
        time.sleep(2)

# Run unit test for function work_in_progress
# test_work_in_progress()

# Generated at 2022-06-11 21:50:04.996291
# Unit test for function work_in_progress
def test_work_in_progress():
    try:
        import pandas as pd
        import pandas.util.testing as pdt
    except ModuleNotFoundError:
        pytest.skip("Test file test_work_in_progress is skipped because pandas is not installed.")
    time.sleep(1)
    with work_in_progress("Creating Pandas DataFrame"):
        df = pdt.makeDataFrame()
    time.sleep(1)
    with work_in_progress("Creating Pandas DataFrame"):
        df = pdt.makeDataFrame()
    assert True

# Generated at 2022-06-11 21:50:09.936555
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


# Generated at 2022-06-11 21:50:17.041746
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    from .test_utility import CaptureStdout

    def f():
        time.sleep(1)

    with CaptureStdout() as stdout:
        with work_in_progress("1"):
            f()
    assert stdout.getvalue() == "1... done. (1.00s)"

    with CaptureStdout() as stdout:
        with work_in_progress():
            f()
    assert stdout.getvalue() == "Work in progress... done. (1.00s)"

    @work_in_progress("2")
    def g():
        f()

    with CaptureStdout() as stdout:
        g()
    assert stdout.getvalue() == "2... done. (1.00s)"

    with CaptureStdout() as stdout:
        work_

# Generated at 2022-06-11 21:50:22.198139
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:50:29.790431
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("t.pickle")

    import random
    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    save_file("t2.pickle", obj)

    import os
    try:
        os.remove("t.pickle")
        os.remove("t2.pickle")
    except:
        pass

# Generated at 2022-06-11 21:50:38.327201
# Unit test for function work_in_progress
def test_work_in_progress():
    begin_time = time.time()
    with work_in_progress("Test work_in_progress"):
        return time.time() - begin_time



# Generated at 2022-06-11 21:50:48.710476
# Unit test for function work_in_progress
def test_work_in_progress():

    import os
    import tempfile
    import pickle

    # Load a file
    # TODO: find a way to measure the time spent on I/O operations
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Loading file"):
        obj = load_file("/usr/share/dict/words")

    # Save a file
    with work_in_progress("Saving file"):
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "words.pickle")
            with open(path, "wb") as f:
                pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:55.438074
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1.5)
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")
    assert obj is not None
    with work_in_progress("Saving file"):
        time.sleep(1.7)
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    assert path.exists()

# Generated at 2022-06-11 21:50:59.525854
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sleep 10s"):
        time.sleep(10)



# Generated at 2022-06-11 21:51:05.928401
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:51:14.054931
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    import os
    import pickle
    import unittest.mock

    class CaptureStdout(io.StringIO):

        def __enter__(self):
            self.buffer = sys.stdout
            sys.stdout = self
            return self

        def __exit__(self, exc_type, exc_value, exc_traceback):
            sys.stdout = self.buffer

    def test_case_contextmgr():
        # 1: Normal usage
        with CaptureStdout() as captured:
            with work_in_progress("Testing work_in_progress"):
                time.sleep(0.5)

        assert "Testing work_in_progress... " in captured.getvalue()
        assert "done. (" in captured.getvalue()

        # 2: Exception raised in the with-block

# Generated at 2022-06-11 21:51:18.152284
# Unit test for function work_in_progress
def test_work_in_progress():
    def func(a, b, c):
        time.sleep(a)
        return a+b+c

    with work_in_progress("Testing function"):
        assert func(0.2, 0.1, 0.3) == 0.6

    assert func(0.1, 0.1, 0.2) == 0.4

# Generated at 2022-06-11 21:51:27.665266
# Unit test for function work_in_progress
def test_work_in_progress():
    try:
        from contextlib import redirect_stdout
    except ImportError:
        from contextlib2 import redirect_stdout

    import io
    import unittest
    import time

    class _TestWorkInProgress(unittest.TestCase):
        def _test_progress_bar(self, expected_output) -> None:
            buf = io.StringIO()
            with redirect_stdout(buf), work_in_progress("TEST DESCRIPTION"):
                time.sleep(0.3)
            self.assertEqual(buf.getvalue(), expected_output)

        def test_with_progress_bar(self):
            self._test_progress_bar("TEST DESCRIPTION... done. (0.30s)\n")


# Generated at 2022-06-11 21:51:30.561581
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test Work in progress"):
        time.sleep(1.0)
    return True

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:51:32.747803
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress('Testing the function')
    def _test_work_in_progress():
        time.sleep(1)
    _test_work_in_progress()

# Generated at 2022-06-11 21:51:38.372632
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.5)

    @work_in_progress("Saving file")
    def save_file():
        time.sleep(0.1)
    save_file()


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:51:47.186523
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")
    save_file("/path/to/some/file", obj)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:51:56.021292
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    @work_in_progress("Loading file")
    def load_file(path: str):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:00.901119
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("test")
    def test_func():
        time.sleep(1)
    test_func()


# Generated at 2022-06-11 21:52:03.425858
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sorting list"):
        for i in range(1000000):
            pass
    assert True

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:06.862862
# Unit test for function work_in_progress
def test_work_in_progress():
    from .testengine import run_tests
    run_tests(open(__file__).read())

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:10.531728
# Unit test for function work_in_progress
def test_work_in_progress():

    # Test 1
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:52:18.800908
# Unit test for function work_in_progress
def test_work_in_progress():
    def read_a_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    beginning_time = time.time()

    @work_in_progress("Loading a file")
    def load_file():
        return read_a_file("data_example.pickle")

    def create_a_file(data):
        with open("data_example.pickle", "wb") as f:
            pickle.dump(data, f)

    @work_in_progress("Creating a file")
    def create_file():
        create_a_file([1, 2, 3])

    create_file()
    load_file()

    print(f"Done in {time.time() - beginning_time}s")



# Generated at 2022-06-11 21:52:21.150329
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sleeping..."):
        time.sleep(1)
        assert True

# Generated at 2022-06-11 21:52:24.897883
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Processing data"):
        time.sleep(0.5)
        print("Data processed")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:29.630228
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        with open("data.pkl", "rb") as f:
            obj = pickle.load(f)
        print(obj)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:52:33.244791
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test function work_in_progress."""
    desc = "Test description"
    with work_in_progress(desc) as w:
        time.sleep(0.25)
        w.status = "Aborted."
        w.abort()
        time.sleep(0.25)
    assert True

# Generated at 2022-06-11 21:52:41.090485
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file(__file__)
    with work_in_progress("Saving file"):
        with open(__file__, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:48.023832
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:52:51.304640
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1.234)
    with work_in_progress("Other operation"):
        time.sleep(3.456)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:53:00.859991
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    from .file_tools import TemporaryDirectory
    from .random_tools import random_string

    # Check no error is raised
    with work_in_progress():
        time.sleep(0.1)
    time.sleep(2)

    # Check time is correct
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with TemporaryDirectory() as tmp_dir:
        path = os.path.join(tmp_dir, "test")
        with open(path, "wb") as f:
            pickle.dump(random_string(), f)

        @work_in_progress
        def load():
            return load_file(path)

        with work_in_progress():
            load()



# Generated at 2022-06-11 21:53:03.629155
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Counting up to 1000")
    def up_to_1000():
        for i in range(1001):
            pass
    up_to_1000()

# Generated at 2022-06-11 21:53:10.408495
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test the function :func:`~.work_in_progress`
    """
    # Test a context manager
    with pytest.raises(NameError):
        with work_in_progress("Raise a name error"):
            1 / 0

    # Test a decorator
    @work_in_progress("Test decorator")
    def func(arg, kwarg=1):
        return arg, kwarg

    assert func(0, kwarg=2) == (0, 2)

# Generated at 2022-06-11 21:53:20.663228
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    import sys

    def capture_print(func, *args, **kwargs):
        """Executes a function and captures its print output."""
        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            func(*args, **kwargs)
        return out.getvalue()

    @work_in_progress("Task 1")
    def task1():
        pass

    @work_in_progress("Task 2")
    def task2():
        time.sleep(1)

    # Mock time.time (because it changes during several seconds)
    real_time = time.time
    time.time = lambda: 10.0
    assert 'Task 1... done. (10.00s)' in capture_print(task1)
    time.time = lambda: 20.0

# Generated at 2022-06-11 21:53:23.826804
# Unit test for function work_in_progress
def test_work_in_progress():
    a = 1000000.0
    b = 2000000.0
    c = 0
    print("Initializing matrix...", end="")
    for i in range(1, 1000000):
        c += a * b
    time_consumed = time.time() - time.time()
    assert time_consumed == 0, "The time consumed should be zero"

# Generated at 2022-06-11 21:53:32.253776
# Unit test for function work_in_progress
def test_work_in_progress():
    try:
        @work_in_progress("Loading file")
        def load_file(path):
            with open(path, "rb") as f:
                return pickle.load(f)

        @work_in_progress("Saving file")
        def save_file(path, obj):
            with open(path, "wb") as f:
                pickle.dump(obj, f)

        obj = load_file("/path/to/some/file")
        save_file("/path/to/some/file", obj)

    except Exception as err:
        print(f'Function work_in_progress raised {type(err).__name__}')
        return False
    else:
        return True

# Test function
if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:53:39.226019
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test if work_in_progress prints out the right string
    and return the right value

    .. code:: python

        >>> with work_in_progress("Loading file") as f:
        ...     f = 'loaded'
        Loading file... done. (0.00s)
        >>> assert(f == 'loaded')
    """


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:53:43.443552
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing function work_in_progress...", end='')
    with work_in_progress(desc="Calculating the square root of 2"):
        square_root_2 = math.sqrt(2)
    with work_in_progress(desc="Calculating the square root of 3"):
        square_root_3 = math.sqrt(3)
    assert square_root_2 == 2 ** 0.5 and square_root_3 == 3 ** 0.5
    print(" done.")

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:53:53.371235
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Doing something")
    def do_something():
        time.sleep(0.5)

    with work_in_progress("Doing something else"):
        time.sleep(0.5)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:03.706326
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    obj = dict(a=1, b=2)
    path = "/tmp/test_work_in_progress.pickle"

    # Case 1: function decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    with open(path, "wb") as f:
        pickle.dump(obj, f)
    got = load_file(path)
    assert got == obj, "Loaded object is incorrect"

    # Case 2: context manager
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    got = load_file(path)
    assert got == obj

# Generated at 2022-06-11 21:54:11.781426
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")
    save_file(obj, "/path/to/some/file")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:23.218404
# Unit test for function work_in_progress
def test_work_in_progress():

    # import os
    # dir_path = os.path.dirname(os.path.realpath(__file__))
    # from pmaxcut import pmc

    # with work_in_progress("Solving PmaxCut"):
    #     pmc.solve(os.path.join(dir_path, "../data/sts_p3.txt"))

    # with work_in_progress("Solving PmaxCut"):
    #     pmc.solve(os.path.join(dir_path, "../data/4-stochastic_graph.txt"))

    # with work_in_progress("Solving PmaxCut"):
    #     pmc.solve(os.path.join(dir_path, "../data/k-pp.txt"))

    def my_trivial_test():
        time

# Generated at 2022-06-11 21:54:24.492541
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3)

# Generated at 2022-06-11 21:54:30.900858
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Creating object")
    def create_obj():
        time.sleep(1)
        return object()

    time.sleep(1)
    obj = create_obj()
    print(f"Object is: {obj}")

    with work_in_progress("Creating object"):
        time.sleep(1)
        obj = object()

    print(f"Object is: {obj}")

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:54:33.465704
# Unit test for function work_in_progress
def test_work_in_progress():
    def foo():
        pass

    with work_in_progress():
        foo()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:35.981215
# Unit test for function work_in_progress
def test_work_in_progress():
    import doctest
    doctest.testmod(verbose=True, optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-11 21:54:39.437797
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        # Fills the CPU for `duration` seconds
        duration = 1
        start = time.time()
        while time.time() - start < duration:
            pass



# Generated at 2022-06-11 21:54:42.563875
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.5)
    with work_in_progress("Saving file"):
        time.sleep(0.5)


# Generated at 2022-06-11 21:54:54.122039
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress()")
    def test_function():
        time.sleep(0.5)

    test_function()

# Generated at 2022-06-11 21:54:57.383611
# Unit test for function work_in_progress
def test_work_in_progress():
    from math import sqrt
    with work_in_progress():
        for i in range(1000000):
            sqrt(i)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:55:00.451374
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def inner_test():
        time.sleep(1)

    inner_test()


# Generated at 2022-06-11 21:55:04.336153
# Unit test for function work_in_progress
def test_work_in_progress():

    # Test for function call
    @work_in_progress("Testing work_in_progress")
    def test_function():
        time.sleep(1)

    test_function()

    # Test for code block
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:55:10.520247
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:55:15.537810
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:55:17.957630
# Unit test for function work_in_progress
def test_work_in_progress():
    print()
    with work_in_progress("Counting to 10"):
        for i in range(10):
            time.sleep(0.05)
        print("10!")

# Generated at 2022-06-11 21:55:25.338492
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import tempfile

    obj = random.random()
    with tempfile.TemporaryDirectory() as tmp_dir:
        with work_in_progress("Loading file"):
            with open(tmp_dir + "/test", "wb") as f:
                pickle.dump(obj, f)
        with work_in_progress("Saving file"):
            with open(tmp_dir + "/test", "rb") as f:
                assert(obj == pickle.load(f))


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:55:34.539825
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import threading
    import multiprocessing

    def long_running_function():
        time.sleep(0.3)

    def long_running_method(self):
        time.sleep(0.3)

    class LongRunningMethod(threading.Thread):
        def run(self):
            time.sleep(0.3)

    class LongRunningObject:
        def long_running_method(self):
            time.sleep(0.3)

    @work_in_progress()
    def test_work_in_progress_in_function():
        long_running_function()

    @work_in_progress()
    def test_work_in_progress_in_method(self):
        long_running_method(self)


# Generated at 2022-06-11 21:55:42.060547
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:56:10.762471
# Unit test for function work_in_progress
def test_work_in_progress():
    path = "tests/data/test.pickle"
    with open(path, "wb") as f:
        pickle.dump(list(range(10000)), f)
    with work_in_progress("Loading file"):
        with open(path, "rb") as f:
            pickle.load(f)
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(list(range(10000)), f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:14.448038
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test 1") as _:
        time.sleep(.3)
    def load_file(path):
        with open(path, 'rb') as f:
            return pickle.load(f)
    with work_in_progress("Test 2") as load_file:
        time.sleep(.3)

# Generated at 2022-06-11 21:56:26.147038
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import os
    path = os.path.abspath(__file__)
    with open(path, "rb") as f:
        data = pickle.load(f)

    assert isinstance(data, bytes)

    with work_in_progress("Loading file"):
        with open(path, "rb") as f:
            data = pickle.load(f)
    
    with work_in_progress("Saving file") as w:
        with open(__file__, "wb") as f:
            pickle.dump(data, f)
    
    with open(path, "rb") as f:
        data = pickle.load(f)
        assert isinstance(data, bytes)

if __name__ == "__main__":
    print(__doc__)

# Generated at 2022-06-11 21:56:27.874232
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Test work_in_progress"):
        time.sleep(1)

# Generated at 2022-06-11 21:56:32.840020
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(2)
    print("OK")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:40.866785
# Unit test for function work_in_progress
def test_work_in_progress():
    import os.path

    @work_in_progress("Function called")
    def call_me():
        time.sleep(0.5)

    @work_in_progress("Reading directory")
    def read_directory():
        return os.listdir('.')

    @work_in_progress("Deleting directory")
    def delete_directory():
        os.rmdir('new_directory')

    @work_in_progress("Creating directory")
    def create_directory():
        os.mkdir('new_directory')

    def test_function():
        with work_in_progress("Context manager"):
            time.sleep(0.5)

    call_me()
    read_directory()
    delete_directory()
    create_directory()
    test_function()

# Generated at 2022-06-11 21:56:45.651282
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(1.1)
    with work_in_progress("Test1"):
        pass

if __name__ == "__main__":
    test_work_in_progress()

# vim:sw=4:ts=4:et:

# Generated at 2022-06-11 21:56:53.296081
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing work_in_progress")
    time.sleep(1)
    with work_in_progress("Testing work_in_progress"):
        time.sleep(2)
    # Test loading
    obj = None
    @work_in_progress("Loading module test_work_in_progress")
    def load_module():
        nonlocal obj
        import test_work_in_progress
        obj = test_work_in_progress
    load_module()
    assert obj is not None
    assert obj is test_work_in_progress
    # Test saving

# Generated at 2022-06-11 21:56:59.263475
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    total_time = 0
    @work_in_progress("Testing work_in_progress...")
    def _test():
        nonlocal total_time
        total_time = 0
        while total_time < 2:
            time.sleep(0.01 + random.random() * 0.01)
            total_time += 0.01 + random.random() * 0.01

    _test()
    assert total_time >= 2

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:57:02.653973
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Taring up"):
        time.sleep(0.3)

    with work_in_progress("Testing"):
        time.sleep(0.9)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:57:46.631696
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for work_in_progress"""
    @work_in_progress("test_work_in_progress")
    def _test():
        time.sleep(1)
        return 0

    _test()

# Generated at 2022-06-11 21:57:53.761123
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test the function :py:func:`~pymaid.utils.timing.work_in_progress`."""
    from .cargo import test_package_installed
    import pickle

    if not test_package_installed("napari[all]"):
        return

    with work_in_progress(desc="Saving file"):
        time.sleep(3.78)
    print("Saving file... done. (3.78s)")

    import napari

    @work_in_progress(desc="Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    load_file("data/em_segmentation.pkl")
    print("Loading file... done. (3.52s)")



# Generated at 2022-06-11 21:58:01.110986
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path: str):
        with open(path, "r") as f:
            return f.read()

    with work_in_progress("Saving file"):
        with open("/tmp/for_test", "w") as f:
            f.write("this is a test")

    assert load_file("/tmp/for_test") == "this is a test"

    import os
    os.remove("/tmp/for_test")

# Generated at 2022-06-11 21:58:07.028102
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    # test_work_in_progress()
  pass

# Generated at 2022-06-11 21:58:17.341404
# Unit test for function work_in_progress
def test_work_in_progress():
    import copy

    class Obj:
        def __init__(self, value, child=None):
            self.value = value
            self.child = child

    obj1 = Obj(123)

    def test_copy():
        # This is only to test if multiple calls to work_in_progress work
        # as expected - this is not always the case when using print.
        @work_in_progress("Copying list")
        def copy_list(l):
            return list(l)

        @work_in_progress("Copying dict")
        def copy_dict(d):
            return dict(d)

        def copy_obj(obj):
            @work_in_progress("Copying object")
            def dcpy(obj):
                return copy.deepcopy(obj)

            return dcpy(obj)

        # Copy a list

# Generated at 2022-06-11 21:58:23.431699
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            time.sleep(3)
            return pickle.load(f)

    obj = load_file("/path/to/file")
    with work_in_progress("Saving file"):
        time.sleep(4)
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:58:33.279575
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    from random import randint
    from itertools import chain
    try:
        from textwrap import indent
    except ImportError:
        def indent(s, prefix):
            return '\n'.join(prefix + line for line in s.splitlines())
    try:
        from contextlib import redirect_stdout
    except ImportError:
        @contextlib.contextmanager
        def redirect_stdout(new_target):
            old_target, sys.stdout = sys.stdout, new_target
            try:
                yield new_target
            finally:
                sys.stdout = old_target

    class _MockStdout(StringIO):
        def flush(self):
            self.truncate(0)
            self.seek(0)


# Generated at 2022-06-11 21:58:39.305503
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Unit tests for work in progress.
if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:58:44.762887
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    >>> with work_in_progress("Saving file"):
    ...   time.sleep(1)
    Saving file... done. (1.00s)
    """
    pass


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:58:47.194869
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(3)
    # Saving file... done. (3.00s)