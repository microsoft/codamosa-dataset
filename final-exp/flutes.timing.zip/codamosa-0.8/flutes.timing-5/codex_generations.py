

# Generated at 2022-06-11 21:49:50.401763
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def a_function():
        time.sleep(1)
    a_function()

if __name__ == "__main__":
    test_work_in_progress()
    @work_in_progress("Work in progress")
    def a_function():
        time.sleep(1)
    a_function()

# Generated at 2022-06-11 21:49:57.197308
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    import sys
    # Assign function to a variable
    _work_in_progress = work_in_progress
    # Capture the script output
    sys.stdout = io.StringIO()
    with _work_in_progress("Test"):
        time.sleep(0.3)
    # Restore the stdout
    stdout = sys.stdout.getvalue()
    sys.stdout = sys.__stdout__
    assert "Test" in stdout
    assert "done." in stdout and "(0.30s)" in stdout

# Generated at 2022-06-11 21:50:06.111325
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert type(obj) is dict

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

    path = "/path/to/some/file"
    os.remove(path)

# Generated at 2022-06-11 21:50:14.398572
# Unit test for function work_in_progress
def test_work_in_progress():
    def to_be_timed_function(a, b, wait=1):
        time.sleep(wait)
        return a + b

    assert to_be_timed_function(1, 2, 0) == 3
    assert to_be_timed_function(1, 2) == 3

    # -- with statement
    with work_in_progress("Task in progress"):
        to_be_timed_function(1, 2)

    # -- timeit decorator
    @work_in_progress()
    def timed_function(a, b, wait=1):
        time.sleep(wait)
        return a + b

    assert timed_function(1, 2, 0) == 3
    assert timed_function(1, 2) == 3


if __name__ == "__main__":
    test_work_in

# Generated at 2022-06-11 21:50:18.965024
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit tests for function 'work_in_progress'"""
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1)

# Generated at 2022-06-11 21:50:23.528235
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        with open("./tests/test_utils.py", "rb") as f:
            pickle.load(f)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:50:27.205276
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress(desc="Downloading"):
        time.sleep(2)
    with work_in_progress(desc="Uploading"):
        time.sleep(5)

# Generated at 2022-06-11 21:50:34.721890
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress."""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    
    obj = load_file("/path/to/some/file")
    print(obj)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:50:44.550427
# Unit test for function work_in_progress
def test_work_in_progress():
    def test_load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def test_save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    path = "/tmp/test_work_in_progress.pkl"
    obj = {"hello": "world"}
    with work_in_progress("Loading file"):
        obj_loaded = test_load_file(path)
    assert obj == obj_loaded
    with work_in_progress("Saving file"):
        test_save_file(path, obj)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:46.758030
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:50:53.067869
# Unit test for function work_in_progress
def test_work_in_progress():
    from time import sleep
    with work_in_progress("Sleeping"):
        sleep(1)
    def foo():
        sleep(2)
    @work_in_progress()
    def bar():
        sleep(3)
    foo()
    bar()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:00.228098
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    with work_in_progress("Saving file"):
        time.sleep(2)
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1.5)
    load_file("/path/to/file")
    @work_in_progress("Saving file")
    def save_file(path):
        time.sleep(2.5)
    save_file("/path/to/file")


# Generated at 2022-06-11 21:51:06.575745
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test if work_in_progress works correctly."""
    with work_in_progress("Saving file") as progress:
        time.sleep(1)
        progress.update_message("Saving file")
        time.sleep(2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:08.929595
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        import time
        time.sleep(2)

# Generated at 2022-06-11 21:51:19.817574
# Unit test for function work_in_progress
def test_work_in_progress():
    """Denpendency:
    - python >= 3.7

    """

    import sys

    if sys.version_info < (3, 7):
        return

    from contextlib import redirect_stdout

    import io

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    output = io.StringIO()
    with redirect_stdout(output):
        _ = load_file(__file__)

    assert output.getvalue() == "Loading file... done. (0.00s)\n"

    # Test the contextmanager
    output = io.StringIO()
    with redirect_stdout(output):
        with work_in_progress("Saving file"):
            pass

    assert output.get

# Generated at 2022-06-11 21:51:22.403146
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress...") as w:
        time.sleep(1.234)
        assert isinstance(w, contextlib.closing)

# Generated at 2022-06-11 21:51:29.509484
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:33.968719
# Unit test for function work_in_progress
def test_work_in_progress():
    try:
        with work_in_progress("Sleeping for 2 seconds") as w:
            time.sleep(2)
        assert w.progress == "done"
        assert w.time_consumed > 2
    except:
        assert False
    else:
        print("work_in_progress passed")

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:51:38.119061
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(0.1)
    with work_in_progress("Sleeping for 100ms"):
        time.sleep(0.1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:41.042924
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Start")
    def start():
        pass

    with work_in_progress("Working"):
        time.sleep(0.1)

    start()
    time.sleep(0.2)

# Generated at 2022-06-11 21:51:47.108840
# Unit test for function work_in_progress
def test_work_in_progress():
    now = time.time()
    time.sleep(0.3)
    with work_in_progress("I'm sleeping"):
        time.sleep(0.2)
    time.sleep(0.1)
    print(f"All is done in {time.time() - now} seconds.")

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:51:55.510623
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:52:02.682928
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open("/tmp/file", "wb") as f:
            pickle.dump("Hello World!", f)

    print("Loading file...")
    obj = load_file("/tmp/file")

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:52:08.521520
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Calculate Fibonacci number"):
        print("Calculated Fibonacci number")
        time.sleep(1)


if __name__ == '__main__':
    # Run the unit test for this module
    test_work_in_progress()

# Generated at 2022-06-11 21:52:13.767409
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    >>> @work_in_progress("Loading file")
    ... def load_file(path):
    ...     with open(path, "rb") as f:
    ...         return pickle.load(f)
    ...
    ... obj = load_file("/path/to/some/file")
    Loading file... done. (3.52s)
    """

# Generated at 2022-06-11 21:52:21.009587
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress.

    .. code:: python

        >>> import time
        >>> with work_in_progress("Test work_in_progress function"):
        ...     time.sleep(1)
        Test work_in_progress function... done. (1.00s)
    """  # noqa
    import time
    with work_in_progress("Test work_in_progress function"):
        time.sleep(1)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-11 21:52:32.384154
# Unit test for function work_in_progress
def test_work_in_progress():
    # f'... done. ({3.52:.2f}s)' -> '... done. (3.52s)'
    # f'... done. ({0.08:.2f}s)' -> '... done. (0.08s)'
    with work_in_progress("1"):
        time.sleep(1)
    with work_in_progress("2"):
        time.sleep(2)
    with work_in_progress("3"):
        time.sleep(3)
    with work_in_progress("4"):
        time.sleep(4)
    with work_in_progress("5"):
        time.sleep(5)


if __name__ == "__main__":
    # Unit test for function work_in_progress
    test_work_in_progress()

# Generated at 2022-06-11 21:52:42.934325
# Unit test for function work_in_progress
def test_work_in_progress():
    filename = "./test_work_in_progress_function.pkl"

    # Constructing a very large dict
    print("Preparing test file...")
    large_dict = {}
    for i in range(100):
        for j in range(100):
            key = (i, j)
            large_dict[key] = i * j

    with work_in_progress("Saving test file"):
        with open(filename, "wb") as f:
            pickle.dump(large_dict, f)

    with work_in_progress("Loading test file"):
        with open(filename, "rb") as f:
            loaded_dict = pickle.load(f)
            assert loaded_dict == large_dict

# Generated at 2022-06-11 21:52:46.405418
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress(desc="Task 1"):
        time.sleep(2)
    @work_in_progress(desc="Task 2")
    def task2():
        time.sleep(2)
        return "result 2"
    assert task2() == "result 2"

# Generated at 2022-06-11 21:52:55.209059
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    import sys
    import unittest
    from contextlib import redirect_stdout

    class WorkInProgressTestCase(unittest.TestCase):
        def setUp(self):
            # Determine the current operating system encoding
            self._encoding = sys.getfilesystemencoding()

        def test_work_in_progress(self):
            with io.StringIO() as buf, redirect_stdout(buf):
                with work_in_progress("Test work in progress"):
                    time.sleep(1.0)
                output = buf.getvalue()
                expected_output = "Test work in progress... done. (1.00s)\n"
                self.assertEqual(output, expected_output)

    # Run unit tests
    unittest.main(WorkInProgressTestCase, exit=False)



# Generated at 2022-06-11 21:53:09.422499
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    Unit test for function work_in_progress
    """
    import random
    import pickle
    import os

    def load_file(path: str):
        r"""Load a file with pickle.

        :param str path: Path of the file.
        """
        with work_in_progress("Loading file"):
            with open(path, "rb") as f:
                return pickle.load(f)

    def save_file(obj, path):
        r"""Save a obj with pickle.

        :param obj: Object to be saved.
        :param str path: Path of the file.
        """
        with work_in_progress("Saving file"):
            with open(path, "wb") as f:
                pickle.dump(obj, f)

    # Create a test file

# Generated at 2022-06-11 21:53:12.678596
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:53:19.437971
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing function work_in_progress...", end="")

    def my_func():
        with work_in_progress("Hey"):
            time.sleep(0.1)

    def my_func2():
        time.sleep(0.1)

    output = io.StringIO()
    with contextlib.redirect_stdout(output):
        my_func()

    # Asserts that Hey appears in the print
    assert "Hey" in output.getvalue()

    output = io.StringIO()
    with contextlib.redirect_stdout(output):
        with work_in_progress("Hey"):
            my_func2()

    # Asserts that Hey appears in the print
    assert "Hey" in output.getvalue()

    print("Test passed")
    return True



# Generated at 2022-06-11 21:53:22.885794
# Unit test for function work_in_progress
def test_work_in_progress():

    def wait(s: float):
        time.sleep(s)
        return 0

    @work_in_progress("Task A")
    def t1():
        return wait(2)

    @work_in_progress("Task B")
    def t2():
        return wait(1)

    with work_in_progress("Task C"):
        wait(1)

    with work_in_progress("Task D"):
        wait(0.5)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:53:28.475632
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import time

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:53:35.549503
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file(__file__)
    assert isinstance(obj, str)

    with work_in_progress("Saving file"):
        with open(__file__, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:53:37.521215
# Unit test for function work_in_progress
def test_work_in_progress():
    def f():
        time.sleep(1)

    with work_in_progress("Test"):
        f()

# Generated at 2022-06-11 21:53:44.149007
# Unit test for function work_in_progress
def test_work_in_progress():
    # Initialize test variables
    desc = "A test"
    time_consumed = 0.7

    # Mock time function to simulate 2 seconds consumed.
    real_time = time.time
    time.time = lambda: real_time() + time_consumed

    # Unit test
    with work_in_progress(desc) as _:
        assert True

    # Restore time function
    time.time = real_time

if __name__ == '__main__':
    import pytest
    pytest.main(["--capture=no", __file__])

# Generated at 2022-06-11 21:53:54.731419
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function work_in_progress."""
    import sys
    import tempfile
    import pickle

    def function0():
        pass
    function1 = lambda: None

    @work_in_progress("Function0")
    def function2():
        pass

    @work_in_progress("Function1")
    def function3():
        pass

    @work_in_progress("Function2")
    def function4():
        1 / 0

    @work_in_progress("Function3")
    def function5():
        return 1 / 0

    class A:
        def method0(self):
            pass
        @classmethod
        def method1(cls):
            pass
        @staticmethod
        def method2():
            pass

# Generated at 2022-06-11 21:54:04.623214
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("test_progress.pickle")
    assert obj == 1

    with work_in_progress("Saving file"):
        with open("test_progress.pickle", "wb") as f:
            pickle.dump(1, f)
    os.remove("test_progress.pickle")


if __name__ == "__main__":
    import sys
    import pytest

    # Test the various functions in this module.
    test_work_in_progress()
    pytest.main(sys.argv)

# Generated at 2022-06-11 21:54:14.955481
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Work in progress"):
        time.sleep(1)

    @work_in_progress("Work in progress")
    def work():
        time.sleep(0.5)
    
    work()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:15.502197
# Unit test for function work_in_progress
def test_work_in_progress():
    pass

# Generated at 2022-06-11 21:54:18.173748
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test function work_in_progress."""
    with work_in_progress("Test work_in_progress function"):
        time.sleep(0.2)

# Generated at 2022-06-11 21:54:22.401431
# Unit test for function work_in_progress
def test_work_in_progress():
    # Function work_in_progress is completly tested in unittest_misc
    # This is just a reminder that the test exists
    from tests.unittest_misc import test_work_in_progress
    test_work_in_progress()

# Generated at 2022-06-11 21:54:25.554644
# Unit test for function work_in_progress
def test_work_in_progress():
    from random import randint
    from random import seed

    seed(42)
    for _ in range(1000):
        sleep = randint(0, 100) / 100
        with work_in_progress("Random sleep"):
            time.sleep(sleep)

# Generated at 2022-06-11 21:54:26.498415
# Unit test for function work_in_progress
def test_work_in_progress():
    # TODO: Test work_in_progress
    pass

# Generated at 2022-06-11 21:54:28.782815
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Task"):
        time.sleep(2)

# Execute tests
if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:54:31.094191
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test work_in_progress") as c:
        time.sleep(0.01)
    print("Done")

# Generated at 2022-06-11 21:54:36.770672
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:54:44.786700
# Unit test for function work_in_progress
def test_work_in_progress():
    from tempfile import TemporaryDirectory
    from os.path import join

    with TemporaryDirectory() as tempdir:
        # Write a dummy file and load it back
        with open(join(tempdir, "testfile.pkl"), "wb") as f:
            pickle.dump(list(range(1000)), f)
        with work_in_progress("Loading file"):
            with open(join(tempdir, "testfile.pkl"), "rb") as f:
                loaded = pickle.load(f)
        assert loaded == list(range(1000))


if __name__ == '__main__':
    # test_work_in_progress()
    pass

# Generated at 2022-06-11 21:54:59.425443
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")
    save_file(obj, "/path/to/another/file")

# vim: nu ft=python columns=120 :

# Generated at 2022-06-11 21:55:04.138679
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:55:10.764914
# Unit test for function work_in_progress
def test_work_in_progress():
    # Manually setting the time.
    with mock.patch('time.time', return_value=5, autospec=True):
        with work_in_progress("Loading file"):
            pass
    print_mock = mock.MagicMock()
    print_mock.assert_has_calls([
        mock.call("Loading file... "),
        mock.call("Loading file... done. (0.00s)"),
    ])

# Generated at 2022-06-11 21:55:18.540288
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import os
    path = "/tmp/some_object"
    obj = {1: "Hello", 2: "world!"}
    begin_time = time.time()
    with work_in_progress("Saving object"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    time_consumed = time.time() - begin_time
    assert time_consumed < 1.5, f"time_consumed = {time_consumed} should be smaller than 1.5"
    begin_time = time.time()
    with work_in_progress("Loading object"):
        with open(path, "rb") as f:
            obj = pickle.load(f)
    time_consumed = time.time() - begin_time
    assert time_cons

# Generated at 2022-06-11 21:55:24.093856
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def foo():
        time.sleep(2)
        return 42

    @work_in_progress("Testing work_in_progress in context")
    def bar():
        time.sleep(2)

    assert foo() == 42
    bar()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:55:27.041303
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress function")
    def test():
        time.sleep(0.5)
    test()

# Generated at 2022-06-11 21:55:28.914366
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("This is a test"):
        time.sleep(0.01)
    return

# Generated at 2022-06-11 21:55:33.522301
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(5)
    print()

    @work_in_progress("Saving file")
    def save_file():
        time.sleep(5)

    save_file()


if __name__ == '__main__':
    # Run test case if this module is executed directly
    test_work_in_progress()

# Generated at 2022-06-11 21:55:43.355508
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test the output of the work_in_progress function"""
    import random
    random.seed(1)

    with work_in_progress("Finding a random number"):
        for i in range(1000):
            if i % 100 == 0:
                time.sleep(0.01)
    with work_in_progress("Generating a random number"):
        for i in range(1000):
            if i % 100 == 0:
                time.sleep(0.001)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:55:49.803963
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test work in progress")
    # Can be enter-exit, but too slow
    def test_function():
        pass

    test_function()
    print()

    # Test enter-exit
    with work_in_progress("Test enter-exit"):
        pass

    print()

    # Test some process
    with work_in_progress("Test some process"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:03.463246
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    dummy = {'a': 'b'}
    with open('dummy.pkl', 'wb') as f:
        pickle.dump(dummy, f)

    assert load_file('dummy.pkl') == dummy

# Generated at 2022-06-11 21:56:09.882394
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:56:11.472190
# Unit test for function work_in_progress
def test_work_in_progress():
    f = work_in_progress("Test")
    with f:
        time.sleep(0.5)

# Generated at 2022-06-11 21:56:13.755678
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test work_in_progress func"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:16.408898
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Mocking data"):
        time.sleep(0.3)

# Generated at 2022-06-11 21:56:24.212101
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress."""
    # Test use as function decorator
    @work_in_progress("Trying function decorator")
    def foo():
        time.sleep(0.1)

    foo()
    # Test use as context manager
    with work_in_progress("Trying context manager"):
        time.sleep(0.1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:27.675919
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test")
    def do_something():
        time.sleep(1.23)

    do_something()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:30.828691
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing progress bar"):
        time.sleep(0.01)

# Generated at 2022-06-11 21:56:39.561195
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import os
    import filecmp

    path = os.path.dirname(__file__)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file(path + "/test_data")

    out = path + "/tmp"
    with work_in_progress("Saving file"):
        with open(out, "wb") as f:
            pickle.dump(obj, f)

    assert filecmp.cmp(path + "/test_data", out)
    os.remove(out)

# Generated at 2022-06-11 21:56:45.061503
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test for context manager
    with work_in_progress("Saving file"):
        time.sleep(1.0)

    # Test for decorator
    @work_in_progress("Loading file")
    def load_file():
        time.sleep(1.0)

    load_file()
    return True

# Generated at 2022-06-11 21:57:13.541276
# Unit test for function work_in_progress
def test_work_in_progress():
    from contextlib import redirect_stdout
    from io import StringIO

    stdout = StringIO()
    with redirect_stdout(stdout):
        begin_time = time.time()

        with work_in_progress("Saving file"):
            assert (time.time() - begin_time) < 0.2
            time.sleep(0.3)
    assert "Saving file... done. (0.30s)\n" in stdout.getvalue()


if __name__ == "__main__":
    # execute only if run as a script
    print("This is a module to be imported, NOT to be run as a script")

# Generated at 2022-06-11 21:57:17.467414
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        print("something")
        time.sleep(0.5)

# Generated at 2022-06-11 21:57:19.776634
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress()"):
        time.sleep(2.0)

# Generated at 2022-06-11 21:57:25.162596
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(2)
    with work_in_progress("Saving file"):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:57:30.532740
# Unit test for function work_in_progress
def test_work_in_progress():
    # Testing in a very dumb way
    import os
    path = os.path.join(os.path.dirname(__file__), "test_work_in_progress.pickle")
    data = None
    with work_in_progress("Loading file"):
        with open(path, "rb") as f:
            data = pickle.load(f)
    assert data == 1

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(2, f)

    with work_in_progress("Loading file"):
        with open(path, "rb") as f:
            data = pickle.load(f)
    assert data == 2

    os.remove(path)

# Generated at 2022-06-11 21:57:37.805115
# Unit test for function work_in_progress
def test_work_in_progress():
    obj = None
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open("test.pickle", "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("test.pickle")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:57:49.643095
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import string

    def random_string(N: int = 10) -> str:
        return ''.join(random.choices(string.ascii_letters, k=N))

    # Function decorator
    @work_in_progress("Test decorator")
    def test_decorator():
        return random_string(random.randint(1, 100))

    assert test_decorator() is not None

    # Context manager
    def test_context_manager():
        text = random_string(random.randint(1, 100))

        with work_in_progress("Test context manager"):
            time.sleep(1.0)

        return text

    assert test_context_manager() is not None


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:57:54.505406
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test work_in_progress output format."""
    @work_in_progress()
    def f():
        time.sleep(1)
    for _ in range(4):
        time.sleep(1)
        f()


# Generated at 2022-06-11 21:58:02.296711
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(3.52)
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        time.sleep(3.78)
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:58:08.795962
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test suite for class work_in_progress."""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open("tempfile", "wb") as f:
            pickle.dump({"a": 1, "b": 2}, f)

    print(load_file("tempfile"))
    os.remove("tempfile")

# Generated at 2022-06-11 21:59:01.180366
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    from .utility import noop
    from .utility import disable_logger

    @work_in_progress("Test function", end="\n")
    def test_func(n: int = 10):
        for _ in range(n):
            time.sleep(random.random() * 0.5)
    with disable_logger():
        test_func()

    @work_in_progress("Test function", end="\n")
    def test_func(n: int = 10):
        for _ in range(n):
            time.sleep(random.random() * 0.5)
    with disable_logger():
        test_func()


# Generated at 2022-06-11 21:59:13.717385
# Unit test for function work_in_progress
def test_work_in_progress():
    from pathlib import Path
    import pickle

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    data_path = Path("test_output/test_work_in_progress/test_data.dat")
    data_path.parent.mkdir(parents=True, exist_ok=True)
    with open(str(data_path), "wb") as f:
        pickle.dump(list(range(50000)), f)

    with work_in_progress("Loading file"):
        obj = load_file(data_path)
    assert obj == list(range(50000))


# Generated at 2022-06-11 21:59:15.759335
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work in progress"):
        time.sleep(2)


# Generated at 2022-06-11 21:59:21.034620
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Sorting")
    def sort_array(arr: List) -> List:
        time.sleep(.1)
        return sorted(arr)
    assert sort_array(list(range(1000000, 0, -1))) == list(range(1000000))


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:59:31.217589
# Unit test for function work_in_progress
def test_work_in_progress():
    path = "./temp.tmp"

    with work_in_progress("Creating file"):
        with open(path, "w+", encoding="utf-8") as f:
            f.write("Hello world!")

    time.sleep(1)

    with work_in_progress("Appending file"):
        with open(path, "a", encoding="utf-8") as f:
            f.write("\nThe cat is on the table.")

    time.sleep(1)

    with work_in_progress("Reading file"):
        with open(path, "r", encoding="utf-8") as f:
            data = f.read()
            assert data == "Hello world!\nThe cat is on the table.", "read does not match write"

    time.sleep(1)


# Generated at 2022-06-11 21:59:37.435533
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(0.25)
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        time.sleep(0.3)
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    path = "./example.pkl"
    obj = [1, 2, 3, 4]
    try:
        save_file(path, obj)
        loaded = load_file(path)
        assert (obj == loaded)
    finally:
        os.remove(path)

# Invoke unit test if this file was launched directly.

# Generated at 2022-06-11 21:59:39.422861
# Unit test for function work_in_progress
def test_work_in_progress():
    import doctest
    doctest.testmod()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:59:45.522437
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Work in progress"
    for _ in range(2):
        begin_time = time.time()
        with work_in_progress(desc=desc):
            time.sleep(0.5)
        end_time = time.time()
        time_consumed = end_time - begin_time
        print(f"Time consumed: {time_consumed:.2f}s")
        assert time_consumed > 0.5 and time_consumed < 1
        print()


if __name__ == "__main__":
    test_work_in_progress()