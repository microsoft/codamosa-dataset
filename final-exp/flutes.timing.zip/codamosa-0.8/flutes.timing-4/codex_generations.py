

# Generated at 2022-06-11 21:49:47.631174
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Task"):
        time.sleep(1)

# Generated at 2022-06-11 21:49:51.707446
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    with tempfile.TemporaryDirectory() as folder:
        with work_in_progress("Saving file"):
            with open(folder + "/file", "wb") as f:
                f.write(b"hello world!!!")
        assert os.path.exists(folder + "/file")

# Generated at 2022-06-11 21:49:57.934067
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:50:01.094734
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test")
    def s():
        time.sleep(2)

    s()

# Generated at 2022-06-11 21:50:04.515685
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def test_function():
        for _ in range(10):
            time.sleep(0.1)
    test_function()


# Generated at 2022-06-11 21:50:12.113580
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("tests/data/test_file_exists_dir.pickle")
    assert os.path.exists(obj)

    with work_in_progress("Saving file"):
        with open("tests/data/test_file_exists_dir.pickle", "wb") as f:
            pickle.dump(obj, f)

    assert os.path.exists(obj)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:19.954533
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import os
    import sys

    # Test context manager
    with open("__test_work_in_progress__.tmp", "wb") as f:
        pickle.dump(list(range(int(1e6))), f)

    with work_in_progress("Reading big file"):
        with open("__test_work_in_progress__.tmp", "rb") as f:
            pickle.load(f)

    os.remove("__test_work_in_progress__.tmp")

    # Test decorator
    @work_in_progress("Doing some more work")
    def do():
        with open("__test_work_in_progress__.tmp", "wb") as f:
            pickle.dump(list(range(int(1e6))), f)

    do()


# Generated at 2022-06-11 21:50:22.102688
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing function")
    def test_func():
        time.sleep(1)
    test_func()

# Generated at 2022-06-11 21:50:29.735708
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    path = "__test_work_in_progress"
    obj = (1, 2, 3)

    try:
        with work_in_progress("Saving file"):
            save_file(path, obj)
        with work_in_progress("Loading file"):
            obj2 = load_file(path)
        print(obj == obj2)
    finally:
        os.remove(path)

# Generated at 2022-06-11 21:50:38.303919
# Unit test for function work_in_progress
def test_work_in_progress():
    import csv
    import tempfile
    import pathlib
    import pickle

    with tempfile.TemporaryDirectory() as tmpdir:
        path = pathlib.Path(tmpdir) / "foo.csv"
        iterable = [
            ["Name", "Age"],
            ["Paul", "37"],
            ["Boris", "42"],
        ]

        with work_in_progress("Saving file"):
            with path.open("w", encoding="utf-8", newline='') as f:
                writer = csv.writer(f)
                writer.writerows(iterable)

        with work_in_progress("Loading file"):
            with path.open("r", encoding="utf-8", newline='') as f:
                reader = csv.reader(f)
                rows = list(reader)



# Generated at 2022-06-11 21:50:44.292947
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("In progress"):
        time.sleep(1)


if __name__ == "__main__":
    # import doctest
    # doctest.testmod()
    # time.sleep(1)
    test_work_in_progress()

# Generated at 2022-06-11 21:50:48.047863
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work in progress"):
        time.sleep(0.1)
    with work_in_progress("Testing work in progress"):
        time.sleep(0.5)

# Short usage example of function work_in_progress
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:56.907884
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1.2)
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        time.sleep(1.2)
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")
    save_file("/path/to/some/file", obj)

# Generated at 2022-06-11 21:50:58.053397
# Unit test for function work_in_progress
def test_work_in_progress():
    print(work_in_progress)
    # TODO

# Generated at 2022-06-11 21:51:04.202911
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile
    import os
    import os.path

    # Test function decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # Test context manager
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    # NOTE: No output is expected unless the unit test itself is slow enough.

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:51:13.708990
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/dev/zero")
    save_file(obj, "/dev/null")

# Generated at 2022-06-11 21:51:18.112732
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing function work_in_progress...", end='', flush=True)
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    
    obj = load_file("/path/to/some/file")
    print("done.")

# Generated at 2022-06-11 21:51:25.237134
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("__init__.py")

    with work_in_progress("Saving file"):
        with open("work_in_progress.pkl", "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:29.556200
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(0.1)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:51:34.006542
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:51:38.664276
# Unit test for function work_in_progress
def test_work_in_progress():
    import doctest
    doctest.testmod()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:40.393699
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.05)

# Generated at 2022-06-11 21:51:49.984050
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(2)
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/Users/kim/Documents/Research/Codepack/codepack/save.pkl")

    with work_in_progress("Saving file"):
        time.sleep(4)
        with open("/Users/kim/Documents/Research/Codepack/codepack/save.pkl", "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:56.159897
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import random
    import time
    with work_in_progress("Running Function"):
        time.sleep(1)
    with work_in_progress("Running Function"):
        print(random.randint(0, 1))

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:01.831268
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(3)
    print("")
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1)
        return path
    load_file("/path/to/some/file")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:05.311979
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing work_in_progress()")
    with work_in_progress("Loading file"):
        with open("/path/to/some/file", "rb") as f:
            pickle.load(f)

# Generated at 2022-06-11 21:52:13.963050
# Unit test for function work_in_progress
def test_work_in_progress():
    import unittest.mock
    with unittest.mock.patch('sys.stdout', new=unittest.mock.StringIO()) as stdout_mock:
        with work_in_progress("Test"):
            time.sleep(0.2)
        output = stdout_mock.getvalue()
    #"""Test... done. (0.20s)
    assert len(output) == 20
    assert output.startswith("Test... done")
    assert output.endswith("(0.20s)\n")

# Generated at 2022-06-11 21:52:17.483025
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Foo") as f:
        time.sleep(0.2)


##############################################################################
# Execute code
##############################################################################

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:52:18.879626
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(1)

# Generated at 2022-06-11 21:52:24.177470
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress
    def f():
        time.sleep(0.05)

    @work_in_progress("Some function")
    def f2():
        time.sleep(0.05)

    f()
    f2()

    with work_in_progress():
        time.sleep(0.05)

    with work_in_progress("Some context"):
        time.sleep(0.05)

# Generated at 2022-06-11 21:52:34.431555
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1)
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        time.sleep(1)

    # Just to be sure that it works
    obj = load_file("/path/to/some/file")
    test_file = "/tmp/test_file"
    with open(test_file, "wb") as f:
        pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:38.088821
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Hello"):
        pass

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:43.919529
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function work_in_progress."""
    import io
    import sys

    @work_in_progress("Loading file")
    def load_file(path):
        return "loaded"
    output = io.StringIO()
    sys.stdout = output
    load_file("/path/to/some/file")
    sys.stdout = sys.__stdout__
    assert output.getvalue() == "Loading file... done. (0.00s)\n"

# Generated at 2022-06-11 21:52:50.813386
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            time.sleep(2)
            return pickle.load(f)

    obj = load_file("/Users/yangdongze/Desktop/temp/python/pytest.pickle")

    with work_in_progress("Saving file"):
        with open("/Users/yangdongze/Desktop/temp/python/pytest_copy.pickle", "wb") as f:
            time.sleep(2)
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:53.306547
# Unit test for function work_in_progress
def test_work_in_progress():
    # Simple example
    import time
    with work_in_progress("Computing stuff"):
        time.sleep(2.5)

    # Decorator example
    @work_in_progress("Computing stuff")
    def do_stuff():
        time.sleep(1.7)

    do_stuff()

# Generated at 2022-06-11 21:52:57.945856
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import os

    def run(fn):
        with tempfile.TemporaryDirectory() as dirname:
            path = os.path.join(dirname, "obj")
            with work_in_progress("Loading file"):
                with open(path, "rb") as f:
                    return pickle.load(f)

    obj = run(lambda: 1)
    assert obj == 1

# Generated at 2022-06-11 21:53:00.807309
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Some time-consuming task"):
        time.sleep(0.2)

# Generated at 2022-06-11 21:53:02.781132
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1.02)



# Generated at 2022-06-11 21:53:03.769389
# Unit test for function work_in_progress
def test_work_in_progress():
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:53:07.903866
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Working")
    def my_func():
        time.sleep(1.55)

    my_func()


################################################################################

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:53:14.955230
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Processing data"):
        time.sleep(3)
    with work_in_progress("Waiting for network"):
        time.sleep(5)
    with work_in_progress("Generating files"):
        time.sleep(10)
    with work_in_progress("Loading files"):
        time.sleep(2)
    with work_in_progress("Trying again"):
        time.sleep(1)

# Generated at 2022-06-11 21:53:22.209928
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Loading file"):
        obj = load_file(__file__)
    assert obj

    with work_in_progress("Saving file"):
        with open(__file__, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    # test_work_in_progress()
    pass

# Generated at 2022-06-11 21:53:27.581892
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Doing some stuff"

    def foo(n: int = 100) -> int:
        with work_in_progress(desc):
            for i in range(n):
                j = 0
                for k in range(100):
                    j += k
            return j

    assert foo() == 4950

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:53:33.978508
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile
    import random
    fd, path = tempfile.mkstemp(suffix='.pkl')
    os.close(fd)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump({str(i): random.random() for i in range(2**11)}, f)

    save_file(path)
    load_file(path)

    os.remove(path)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:53:37.520393
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import sys

    with work_in_progress("Test 1"):
        time.sleep(1)
    assert sys.stdout.getvalue() == 'Test 1... done. (1.00s)\n'

# Generated at 2022-06-11 21:53:41.380693
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Long running task"):
        time.sleep(5)
    with work_in_progress("Long running task"):
        time.sleep(3)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:53:47.743744
# Unit test for function work_in_progress
def test_work_in_progress():
    def time_sleep(sec: int = 1):
        time.sleep(sec)

    @work_in_progress("Loading file")
    def load_file(path: str):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path: str, obj: object):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with work_in_progress("Sleeping for 10 seconds"):
        time_sleep(10)

    obj = load_file("/etc/hosts")
    assert isinstance(obj, list)
    save_file("/tmp/hosts", obj)

# Generated at 2022-06-11 21:53:54.875716
# Unit test for function work_in_progress
def test_work_in_progress():
    print()
    obj = None
    with work_in_progress("Loading file"):
        with open(__file__, "rb") as f:
            obj = pickle.load(f)
    obj = None
    with work_in_progress("Saving file"):
        with open(__file__, "wb") as f:
            pickle.dump(obj, f)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:53:58.914332
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test function `work_in_progress`."""
    import os
    with work_in_progress("Removing files"):
        os.remove("/path/to/file")
        os.remove("/path/to/another/file")

# Generated at 2022-06-11 21:54:08.704271
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with open("/path/to/some/file", "wb") as f:
        pickle.dump(1, f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    save_file("/path/to/some/file", 2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:15.846707
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test")
    def f():
        time.sleep(1)

    with work_in_progress("Test2"):
        time.sleep(1)

# Generated at 2022-06-11 21:54:21.252828
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function ``work_in_progress``.

    .. code:: python

        >>> from pytoolcore.test import test_work_in_progress
        >>> test_work_in_progress()
        >>> # Documentation test
        >>> import doctest
        >>> doctest.testmod()
    """
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:54:23.671748
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing..."):
        time.sleep(2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:26.963711
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1.0)


if __name__ == "__main__":
    # Unit test for function work_in_progress
    test_work_in_progress()

# Generated at 2022-06-11 21:54:36.865943
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with tempfile.TemporaryDirectory() as temp_dir:
        path = os.path.join(temp_dir, "obj.p")
        obj = {i: i**2 for i in range(100)}
        save_file(path, obj)
        assert load_file(path) == obj


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:54:42.806134
# Unit test for function work_in_progress
def test_work_in_progress():
    # test the code block style usage
    with work_in_progress("Loading file"):
        time.sleep(1)
    # test the function decorator style usage
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1)
    load_file("/path/to/some/file")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:50.535101
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile
    from .shell import shell

    with tempfile.NamedTemporaryFile(mode="w", delete=False) as f:
        with work_in_progress("Writing to file"):
            f.write("this is a test")
            time.sleep(0.1)

    with work_in_progress("Reading file"):
        with open(f.name) as f:
            assert f.read() == "this is a test"
            time.sleep(0.2)

    with work_in_progress("Removing file") as _:
        time.sleep(0.3)
        os.unlink(f.name)

    shell("echo '1' | busybox")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:54.735728
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(3.52)
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        time.sleep(3.78)
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("tests/files/some_file.pickle")
    save_file("tests/files/some_file_copy.pickle", obj)

# Generated at 2022-06-11 21:54:57.714154
# Unit test for function work_in_progress
def test_work_in_progress():
    for message in ["Work in progress", "Saving file", "Loading file", None, ""]:
        with work_in_progress(message):
            time.sleep(1)

# Generated at 2022-06-11 21:55:01.471608
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Loading file"
    time_consumed = 3.52
    with work_in_progress(desc) as w:
        assert w.sentinel == "Loading file... ", "Description is not printed"
        time.sleep(time_consumed)


# Generated at 2022-06-11 21:55:18.409686
# Unit test for function work_in_progress
def test_work_in_progress():
    try:
        input = raw_input
    except NameError:
        pass

    with work_in_progress("Test"):
        print("Hello")
        time.sleep(2)
        print("World")
        time.sleep(2)
        print("Finished")
        time.sleep(2)

    input("Press enter to continue")

    @work_in_progress("Test")
    def f():
        print("Hello")
        time.sleep(2)
        print("World")
        time.sleep(2)
        print("Finished")
        time.sleep(2)

    f()
    input("Press enter to exit.")


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:55:24.300365
# Unit test for function work_in_progress
def test_work_in_progress():
    def _f1():
        with work_in_progress("Progress 1"):
            time.sleep(1)

    def _f2():
        @work_in_progress("Progress 2")
        def _f2_1():
            time.sleep(2)

        _f2_1()

    _f1()
    _f2()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:55:29.079046
# Unit test for function work_in_progress
def test_work_in_progress():
    begin_time = time.time()
    with work_in_progress("Loading file"):
        time.sleep(3.345)
        print("Inside")
    time_consumed = time.time() - begin_time
    print(f"{time_consumed:.2f}s")

# Generated at 2022-06-11 21:55:35.041064
# Unit test for function work_in_progress
def test_work_in_progress():
    for i in range(100):
        with work_in_progress(f"task {i}"):
            time.sleep(0.02)

if __name__ == "__main__":
    # Parse command line arguments
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("-t", "--test", action="store_true",
                        help="Run unit tests.")
    args = parser.parse_args()

    if args.test:
        test_work_in_progress()

# Generated at 2022-06-11 21:55:45.949716
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import pickle
    for i in range(5):
        with work_in_progress("Loading file"):
            time.sleep(i / 5)
        with work_in_progress("Saving file"):
            time.sleep(i / 5)
    time.sleep(1)
    obj = list(range(1, 10))
    with open("/tmp/temp_file.pkl", "wb") as f:
        pickle.dump(obj, f)
    with work_in_progress("Loading file"):
        with open("/tmp/temp_file.pkl", "rb") as f:
            obj = pickle.load(f)
    with work_in_progress("Saving file"):
        with open("/tmp/temp_file.pkl", "wb") as f:
            pick

# Generated at 2022-06-11 21:55:59.188003
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import pickle
    from tempfile import TemporaryDirectory, NamedTemporaryFile

    @work_in_progress("Loading dict")
    def load_dict(name: str):
        with open(name, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving dict")
    def save_dict(dict_, name: str):
        with open(name, "wb") as f:
            pickle.dump(dict_, f)

    # Test with a regular function
    with NamedTemporaryFile("wb") as f:
        pickle.dump({"hello": "world"}, f)
        f.seek(0)
        assert load_dict(f.name) == {"hello": "world"}

    # Test with a contextmanager

# Generated at 2022-06-11 21:56:00.733348
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test the function work_in_progress."""
    with work_in_progress():
        time.sleep(1)

# Generated at 2022-06-11 21:56:05.802404
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Taking a long nap")
    def do_nothing():
        time.sleep(5)

    do_nothing()


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:56:09.121163
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(0.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:16.462536
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
        # obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        # with open(path, "wb") as f:
        #     pickle.dump(obj, f)
        time.sleep(2)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:37.824759
# Unit test for function work_in_progress
def test_work_in_progress():
    sleep_time = 1.0
    with work_in_progress("Sleeping"):
        time.sleep(sleep_time)
    assert True

# Generated at 2022-06-11 21:56:49.885247
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress."""
    import pickle

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file_wrapped(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with open("__tempfile.pickle", "rb") as f:
        obj = pickle.load(f)
    with open("__tempfile.pickle", "wb") as f:
        pickle.dump(obj, f)

    with work_in_progress("Saving file"):
        with open("__tempfile.pickle", "wb") as f:
            pickle.dump(obj, f)



# Generated at 2022-06-11 21:56:54.771733
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading")
    def dummy_one():
        time.sleep(0.1)

    with work_in_progress("Loading"):
        time.sleep(0.2)

    dummy_one()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:59.411188
# Unit test for function work_in_progress
def test_work_in_progress():
    from contextlib import redirect_stdout, redirect_stderr

    with open("_work_in_progress_test1.txt", "w") as f:
        with redirect_stdout(f):
            with work_in_progress("Loading file"):
                time.sleep(0.1)


# Generated at 2022-06-11 21:57:06.708292
# Unit test for function work_in_progress
def test_work_in_progress():
    import os

    def assert_equal_func(a, b):
        assert a == b

    fpath = "test_file_work_in_progress.txt"
    data = b"foo" * 1024 * 1024 * 20 # 20 MB
    text = data.decode()

    with work_in_progress("Writing"):
        with open(fpath, "wb") as f:
            f.write(data)

    with work_in_progress("Writing"):
        with open(fpath, "w") as f:
            f.write(text)

    with work_in_progress("Reading"):
        with open(fpath, "rb") as f:
            data_read = f.read()

    with work_in_progress("Reading"):
        with open(fpath, "r") as f:
            text

# Generated at 2022-06-11 21:57:08.866148
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing function work_in_progress")
    def _():
        time.sleep(1)

    _()

# Generated at 2022-06-11 21:57:16.938611
# Unit test for function work_in_progress
def test_work_in_progress():
    class Foo:
        def __init__(self, n):
            self.n = n

        def __getitem__(self, i):
            return i ** self.n

    class Bar:
        def __init__(self, n):
            self.n = n

        def compute(self, x, y):
            return x ** self.n + y ** self.n

    for i in range(5):
        print()
        with work_in_progress():
            time.sleep(i)

    for i in range(5):
        print()
        with work_in_progress("Loading a Foo instance"):
            foo = Foo(i)

    for i in range(5):
        print()
        with work_in_progress("Loading a Bar instance"):
            bar = Bar(i)


# Generated at 2022-06-11 21:57:24.125189
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:57:26.182096
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test") as _:
        time.sleep(1)
    with work_in_progress("Test 2") as _:
        time.sleep(0.1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:57:35.319334
# Unit test for function work_in_progress
def test_work_in_progress():
    sample_size = 10000
    a = np.random.randn(sample_size, sample_size)
    b = np.random.randn(sample_size, sample_size)
    begin_time = time.time()
    c = a @ b
    end_time = time.time()
    print(f"Matrix multiplication of a matrix of size {sample_size:} took {end_time - begin_time:.2f}s")

# Generated at 2022-06-11 21:58:21.035600
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def dummy_function():
        time.sleep(0.1)

    with work_in_progress():
        time.sleep(0.1)

    print()

    @work_in_progress("Write file")
    def dummy_function():
        time.sleep(0.1)

    with work_in_progress("Write file"):
        time.sleep(0.1)


# Generated at 2022-06-11 21:58:22.763790
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(0.56)

# Generated at 2022-06-11 21:58:29.844859
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import io

    # test context manager
    with io.StringIO() as f, contextlib.redirect_stdout(f):
        with work_in_progress("test"):
            time.sleep(1)
        f.seek(0)
        assert re.match("test\\.\\.\\. done\\. \\([0-9\\.]+s\\)\\n$", f.read())

    # test decorator
    @work_in_progress("test")
    def _test():
        time.sleep(1)

    with io.StringIO() as f, contextlib.redirect_stdout(f):
        _test()
        f.seek(0)

# Generated at 2022-06-11 21:58:35.655654
# Unit test for function work_in_progress
def test_work_in_progress():
    import subprocess

    start_time = time.time()
    subprocess.run("sleep 2".split())
    duration = time.time() - start_time
    assert duration >= 2 and duration <= 2.01

    with work_in_progress("Sleeping"):
        subprocess.run("sleep 2".split())

    start_time = time.time()
    @work_in_progress("Sleeping")
    def sleep_and_return(n):
        subprocess.run("sleep 2".split())
        return n

    assert sleep_and_return(n=1) == 1
    duration = time.time() - start_time
    assert duration >= 2 and duration <= 2.01

# Generated at 2022-06-11 21:58:37.129458
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing")
    def do_work_in_progress():
        time.sleep(0.5)
    do_work_in_progress()

# Generated at 2022-06-11 21:58:43.348777
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Loading file")
    def load_file():
        time.sleep(0.01)
        return 42

    assert load_file() == 42

    with work_in_progress("Saving file"):
        time.sleep(0.02)
    return True

# Generated at 2022-06-11 21:58:49.608111
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        with open("/path/to/some/file", "rb") as f:
            obj = pickle.load(f)
    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:58:51.585776
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress(desc="Test")
    def _test():
        pass
    _test()

# Generated at 2022-06-11 21:58:59.403729
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Loading file"):
        obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:59:03.883661
# Unit test for function work_in_progress
def test_work_in_progress():
    try:
        # Just run the function, assume work_in_progress
        # can be used correctly if no Exception occurs
        with work_in_progress("Test work_in_progress function"):
            pass
    except:
        raise AssertionError("work_in_progress function failed")


if __name__ == "__main__":
    test_work_in_progress()