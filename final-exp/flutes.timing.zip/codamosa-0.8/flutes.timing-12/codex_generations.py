

# Generated at 2022-06-11 21:49:52.429921
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Task"):
        time.sleep(1.0)
    with work_in_progress("Task"):
        time.sleep(2.0)
    with work_in_progress("Task"):
        time.sleep(0.1)

    @work_in_progress("Task")
    def some_task():
        time.sleep(1.0)

    some_task()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:50:02.813558
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    import sys

    # Set up stdout mock
    @contextlib.contextmanager
    def stdout_mock():
        origin = sys.stdout
        fake = io.StringIO()
        sys.stdout = fake
        yield
        sys.stdout = origin

    # Start to test function
    with stdout_mock() as fake:
        with work_in_progress("Saving file"):
            pass
        fake.seek(0)
        assert fake.read() == "Saving file... done. (0.00s)\n"


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:07.631959
# Unit test for function work_in_progress
def test_work_in_progress():
    def func(x: float):
        time.sleep(x)
        return x

    r"""Test if the time is correct."""
    with work_in_progress("Waiting 4.20 seconds..."):
        assert func(4.2) == 4.2

# Generated at 2022-06-11 21:50:14.778859
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3.52)

    with work_in_progress("Saving file"):
        time.sleep(3.78)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:50:26.641690
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    class A:
        def __init__(self):
            self.x = 1

    obj = A()
    save_file("/tmp/work_in_progress.tmp", obj)
    obj_loaded = load_file("/tmp/work_in_progress.tmp")

    # Test if the loaded object was identical to the original object
    assert obj.x == obj_loaded.x

    # Test whether the time taken to perform the operation was above 1

# Generated at 2022-06-11 21:50:37.769743
# Unit test for function work_in_progress
def test_work_in_progress():
    from pathlib import Path
    from .write_files import write_files

    temp_dir_path = Path("temp")
    temp_dir_path.mkdir(exist_ok=True)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file():
        with open("temp/test.dat", "wb") as f:
            pickle.dump("Test", f)

    # Test outside a code block
    obj = load_file("temp/test.dat")

    # Test inside a code block

# Generated at 2022-06-11 21:50:44.441743
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("test.bin")

    with work_in_progress("Saving file"):
        with open("test.bin", "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    # No unit test for this module currently.
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:50:46.371911
# Unit test for function work_in_progress
def test_work_in_progress():
    # time.sleep()
    with work_in_progress("Test work_in_progress"):
        time.sleep(5)

# Generated at 2022-06-11 21:50:54.990091
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import string
    import tempfile
    desc = ''.join(random.choices(string.ascii_letters, k=10))
    with work_in_progress(desc):
        time.sleep(1)
    print(f"Subtest {desc} passed")

    with tempfile.TemporaryDirectory() as tempdir:
        desc = ''.join(random.choices(string.ascii_letters, k=10))
        @work_in_progress(desc)
        def load_file(path):
            with open(path, "rb") as f:
                return pickle.load(f)
            time.sleep(1)
        filename = os.path.join(tempdir, "test")

# Generated at 2022-06-11 21:50:57.063936
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing..."):
        time.sleep(1)

# Generated at 2022-06-11 21:51:08.538103
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1)
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("./test.pickle")

    with work_in_progress("Saving file"):
        time.sleep(2)
        with open("./test.pickle", "wb") as f:
            pickle.dump(obj, f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:51:12.285875
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test for method work_in_progress"""
    with work_in_progress("Test"):
        time.sleep(1)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:51:18.748123
# Unit test for function work_in_progress
def test_work_in_progress():
    # Create a dummy function
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(obj, path):
        with open(file, "wb") as f:
            pickle.dump(obj, f)

    # Load test file
    path = pathlib.Path(__file__).parent / "test_data" / "test_file.p"
    obj = load_file(str(path))

    # Save test file
    path = pathlib.Path(__file__).parent / "test_data" / "test_file_copy.p"
    save_file(obj, str(path))

# Generated at 2022-06-11 21:51:23.824310
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
        return None

    obj = load_file("/path/to/some/file")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:26.379728
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test function")
    def f():
        time.sleep(1)

    f()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:29.704696
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Dummy work")
    def dummy_work():
        time.sleep(2)
    dummy_work()

# Generated at 2022-06-11 21:51:36.540123
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import tempfile

    for _ in range(10):
        with tempfile.TemporaryDirectory() as dir:
            with work_in_progress(" > Creating tempfile"):
                filepath = tempfile.mktemp(dir=dir)
                with open(filepath, "wb") as f:
                    f.write(bytes(random.choices(range(0, 255), k=1000000)))

            with work_in_progress(" > Writing result to a new file"):
                new_filepath = tempfile.mktemp(dir=dir)
                with open(filepath, "rb") as f:
                    with open(new_filepath, "wb") as f2:
                        f2.write(f.read())


# Generated at 2022-06-11 21:51:42.133132
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test for the work_in_progress function."""
    from .printer import COLOR_GREEN, COLOR_RESET
    with mock.patch('sys.stdout', new_callable=io.StringIO) as mocked_stdout:
        with work_in_progress("Test description"):
            time.sleep(1)
        assert mocked_stdout.getvalue().strip() == "Test description... " \
            + COLOR_GREEN + "done." + COLOR_RESET + " (1.00s)"



# Generated at 2022-06-11 21:51:48.661250
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            time.sleep(1.2)
            return pickle.load(f)

    obj = load_file(__file__)

    with work_in_progress("Saving file"):
        with open(__file__, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:52:01.282074
# Unit test for function work_in_progress
def test_work_in_progress():
    # test with function
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # test with context manager
    class SomeClass:
        def __init__(self, path):
            self.path = path

        def __enter__(self):
            print(f"Opening file {self.path}...", end='', flush=True)
            self.file = open(self.path, "rb")

        def __exit__(self, exc_type, exc_val, exc_tb):
            print(f"done.")
            self.file.close()

    with work_in_progress("Loading file"):
        with SomeClass("test_work_in_progress.py") as f:
            s

# Generated at 2022-06-11 21:52:15.654718
# Unit test for function work_in_progress
def test_work_in_progress():
    # time.sleep(3)
    with work_in_progress("Loading file"):
        time.sleep(3)
    # with work_in_progress("Loading file"):
    #     obj = pickle.load(open("/home/michael/Workspace/tensorflow-tutorial/dataset/dataset.pkl", "rb"))
    #     pickle.dump(obj, open("/home/michael/Workspace/tensorflow-tutorial/cifar-10-batches-py/test_batch", "wb"))
    #     # print(obj)
    # with work_in_progress("Testing"):
    #     # time.sleep(3)
    #     pass
    # obj = pickle.load(open("./cifar-10-batches-py/test_batch

# Generated at 2022-06-11 21:52:23.327449
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Test context manager"
    with work_in_progress(desc) as w:
        time.sleep(random.uniform(0, 10))
    time.sleep(1)

    desc = "Test function decorator"
    @work_in_progress(desc)
    def test_function(a, b):
        time.sleep(random.uniform(0, 1))
        return a + b
    test_function(1, 2)
    time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:28.611098
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    with work_in_progress("Counting to 10"):
        for i in range(10):
            time.sleep(random.random())
    with work_in_progress("Counting to 10"):
        for i in range(10):
            time.sleep(random.random())

# Generated at 2022-06-11 21:52:36.010842
# Unit test for function work_in_progress
def test_work_in_progress():
    import unittest

    class TestWorkInProgress(unittest.TestCase):
        def test_work_in_progress(self):
            with self.assertRaises(AttributeError):
                with work_in_progress("Some error will occur"):
                    raise AttributeError("Test error")
        def test_load_file(self):
            with work_in_progress("Loading file"):
                with open("/dev/urandom", "rb") as f:
                    f.read(100)
        def test_save_file(self):
            with work_in_progress("Saving file"):
                with open("/dev/urandom", "wb") as f:
                    f.write(bytearray([69]*1024*1024*32))
    unittest.main()

# Generated at 2022-06-11 21:52:39.463342
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test 'work_in_progress'"):
        time.sleep(1)


if __name__ != "__main__":
    pass
else:
    test_work_in_progress()

# Generated at 2022-06-11 21:52:49.283574
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test :code:`work_in_progress` function.
    """
    def load_file(path: str) -> Dict:
        r"""Load a file given file path.
        """
        with work_in_progress("Loading file"):
            with open(path, "rb") as f:
                return pickle.load(f)

    def save_file(obj: Any, path: str) -> None:
        r"""Save an object to the specified path.
        """
        with work_in_progress("Saving file"):
            with open(path, "wb") as f:
                pickle.dump(obj, f)

    file_path = "/path/to/some/file"

    obj = load_file(file_path)

    save_file(obj, file_path)


# Automatically

# Generated at 2022-06-11 21:52:54.439390
# Unit test for function work_in_progress
def test_work_in_progress():
    def sleep_some_time(seconds):
        time.sleep(seconds)

    # test a function
    @work_in_progress("Loading file")
    def load_file():
        sleep_some_time(3.52)
        return 1

    assert load_file() == 1

    # test a block
    with work_in_progress("Saving file") as save_file:
        sleep_some_time(3.78)
    assert save_file is None

# Generated at 2022-06-11 21:52:56.703974
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing function"):
        time.sleep(1)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:53:06.304994
# Unit test for function work_in_progress
def test_work_in_progress():
    import inspect
    import pickle
    import io
    def f(x, y=None):
        pass

    with io.StringIO() as out:
        func_name = inspect.getsource(f)
        print(func_name, file=out)
        code = out.getvalue()

        r = pickle.dumps(inspect.getsource)
        with work_in_progress("Testing work in progress"):
            x = inspect.getsource(f)
            time.sleep(0.1)

        time.sleep(0.1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:53:15.166336
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile
    import pickle
    import random

    obj = [random.random() for _ in range(3)]

    def test_work_in_progress_func(obj):
        with work_in_progress():
            with tempfile.TemporaryFile() as f:
                pickle.dump(obj, f)

    def test_work_in_progress_context(obj):
        with work_in_progress():
            with tempfile.TemporaryFile() as f:
                pickle.dump(obj, f)

    def test_work_in_progress_decorator(obj):
        @work_in_progress()
        def save_obj(obj, f):
            pickle.dump(obj, f)


# Generated at 2022-06-11 21:53:19.929075
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("long task")
    def long_task():
        time.sleep(3)
    long_task()

# Generated at 2022-06-11 21:53:23.124307
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        with open("todo_list.txt", "r") as f:
            time.sleep(1)
        time.sleep(2)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:53:26.494116
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress()"):
        time.sleep(3)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:53:27.977136
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Test"):
        time.sleep(1)

# Generated at 2022-06-11 21:53:30.501919
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import random
    with work_in_progress("Testing work_in_progress"):
        time.sleep(random.random())

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:53:34.479850
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Inside test_work_in_progress")
    def func():
        time.sleep(0.5)
    func()


if __name__ == "__main__":
    # Unit test
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:53:37.812617
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file", "test_open_file.txt"):
        time.sleep(3)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:53:43.372248
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for :func:`work_in_progress`.

    .. code:: python

        >>> import time
        >>> from functools import partial
        >>> from .utils import work_in_progress
        ...
        >>> @work_in_progress("Loading file")
        ... def load_file(path):
        ...     with open(path, "rb") as f:
        ...         return pickle.load(f)
        ...
        ... obj = load_file("/path/to/some/file")
        Loading file... done. (3.52s)
        >>>
        >>> with work_in_progress("Saving file"):
        ...     with open(path, "wb") as f:
        ...         pickle.dump(obj, f)
        Saving file... done. (3.78s)
    """
   

# Generated at 2022-06-11 21:53:44.761970
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress function"):
        time.sleep(0.01)

# Generated at 2022-06-11 21:53:49.052929
# Unit test for function work_in_progress
def test_work_in_progress():
    def test_fn(d):
        time.sleep(0.5)

    with work_in_progress("Test"):
        test_fn("test")

# Execute unit test
if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:53:57.397780
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Testing")
    def _test():
        time.sleep(2)

    _test()

    with work_in_progress("Testing"):
        time.sleep(2)

    print("ok")

# Generated at 2022-06-11 21:54:00.001976
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress"""
    with work_in_progress("Doing something"):
        time.sleep(2)
    assert True

# Generated at 2022-06-11 21:54:08.064971
# Unit test for function work_in_progress
def test_work_in_progress():
    file_path = "Untitled Drawing.png"
    with open(file_path, 'rb') as f:
        img = imageio.imread(f)

    with work_in_progress("Loading file"):
        with open(file_path, 'rb') as f:
            img = imageio.imread(f)

    with work_in_progress("Saving file"):
        with open('test_work_in_progress.jpg', 'wb') as f:
            imageio.imwrite(f, img, format='jpg', quality=100)
    os.remove('test_work_in_progress.jpg')

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:54:10.297342
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1.5)


# Generated at 2022-06-11 21:54:13.747750
# Unit test for function work_in_progress
def test_work_in_progress():
    def func():
        time.sleep(2.0)
    with work_in_progress("test"):
        func()
test_work_in_progress()

# Generated at 2022-06-11 21:54:17.219229
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test function work_in_progress()"""

    @work_in_progress("Sample task")
    def sample_task():
        time.sleep(0.2)
    sample_task()

    with work_in_progress("Sample task"):
        time.sleep(0.2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:27.880704
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
        with work_in_progress("Loading another file"):
            time.sleep(1)
    with work_in_progress("GENERAL LAYOUT"):
        with work_in_progress("Generating node tree"):
            time.sleep(0.1)
        with work_in_progress("Generating polygons"):
            time.sleep(0.1)
    with work_in_progress("Generating node lattice"):
        time.sleep(0.1)
    with work_in_progress("Generating boundary lines"):
        time.sleep(0.1)
    with work_in_progress("Generating FEM components"):
        time.sleep(0.1)

# Generated at 2022-06-11 21:54:36.225152
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(0.00001)
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        time.sleep(0.00001)
        with open(path, "wb") as f:
            pickle.dump(obj, f)


# Run unit test if executed as main program
if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:54:45.796363
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with open("data/test.pkl", "wb") as f:
        pickle.dump({"foo": "bar", "spam": 123}, f)

    obj = load_file("data/test.pkl")
    assert obj["foo"] == "bar"

    with work_in_progress("Saving file"):
        with open("data/test.pkl", "wb") as f:
            pickle.dump(obj, f)

    try:
        os.remove("data/test.pkl")
    except OSError as e:
        print(e)


if __name__ == "__main__":
    test

# Generated at 2022-06-11 21:54:56.552354
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import os

    obj = {'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5}

    with work_in_progress("Saving file"):
        with open('/tmp/work_in_progress.pickle', 'wb') as f:
            pickle.dump(obj, f)

    @work_in_progress("Loading file")
    def load_file(name):
        with open(name, 'rb') as f:
            return pickle.load(f)

    assert load_file('/tmp/work_in_progress.pickle') == obj
    os.remove('/tmp/work_in_progress.pickle')

# Generated at 2022-06-11 21:55:14.034733
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Sleep")
    def foo():
        time.sleep(1)
    foo()


if __name__ == "__main__":
    import unittest
    suite = unittest.TestSuite()
    suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestRunSqlScript))
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)

# Generated at 2022-06-11 21:55:18.938973
# Unit test for function work_in_progress
def test_work_in_progress():

    with work_in_progress("Loading file"):
        time.sleep(1)

    time.sleep(1)
    with work_in_progress("Saving file"):
        time.sleep(2)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:55:23.242363
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress
    def test1():
        time.sleep(0.5)

    with work_in_progress():
        time.sleep(1)


if __name__ == '__main__':
    # test()
    _test_time()

# Generated at 2022-06-11 21:55:29.773406
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("First"):
        time.sleep(1)
    with work_in_progress("Second"):
        time.sleep(2)
    with work_in_progress("Third"):
        time.sleep(3)
    with work_in_progress():
        time.sleep(4)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:55:32.367730
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(0.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:55:34.885939
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing"):
        print("Test")

if __name__ == '__main__':
    # Unit test
    test_work_in_progress()

# Generated at 2022-06-11 21:55:42.496082
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file():
        time.sleep(1.6)
        return 1

    @work_in_progress("Saving file")
    def save_file():
        time.sleep(1.1)
        return 2

    assert load_file() == 1
    assert save_file() == 2


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:55:50.762730
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path:str):
        with open(path, 'rb') as f:
            return pickle.load(f)

    obj = load_file('./data/test_open.pickle')

    with work_in_progress("Saving file"):
        with open('./data/test_save.pickle', 'wb') as f:
            pickle.dump(obj, f)

    if os.path.exists('./data/test_save.pickle'):
        os.remove('./data/test_save.pickle')

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:55:53.276255
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work in progress")
    def test():
        time.sleep(2)

    test()

# Generated at 2022-06-11 21:56:03.108648
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("test.pkl")
    save_file(obj, "test2.pkl")
    assert obj == {"name": "Kitty"}

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:33.697495
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    ##################################
    # Test work_in_progress as decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    ##################################
    # Test work_in_progress as context manager
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:56:34.216813
# Unit test for function work_in_progress
def test_work_in_progress():
    pass

# Generated at 2022-06-11 21:56:34.799666
# Unit test for function work_in_progress
def test_work_in_progress():
    assert True

# Generated at 2022-06-11 21:56:38.687687
# Unit test for function work_in_progress
def test_work_in_progress():
    def some_time_consuming_function():
        time.sleep(0.2)

    assert work_in_progress(desc="test")
    assert work_in_progress(desc="test")
    with work_in_progress(desc="test"):
        time.sleep(0.2)

# Generated at 2022-06-11 21:56:40.293100
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test in progress"):
        time.sleep(0.2)

# Generated at 2022-06-11 21:56:46.392384
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test 1"):
        time.sleep(0.1)
        assert True
    with work_in_progress("Test 2"):
        time.sleep(0.5)
    @work_in_progress("Test 3")
    def _():
        time.sleep(0.1)
    _()

# Generated at 2022-06-11 21:56:53.578999
# Unit test for function work_in_progress
def test_work_in_progress():
    import unittest
    import io
    import random

    class TestWorkInProgress(unittest.TestCase):
        """Test class for work_in_progress."""

        def test_work_in_progress(self):
            """Test the function work_in_progress."""
            for _ in range(5):
                with io.StringIO() as buf:
                    # Capture stdout
                    __std_out__ = sys.stdout
                    sys.stdout = buf
                    time.sleep(random.randint(100,999)/100.0)
                    print("The quick brown fox jumps over the lazy dog")
                    sys.stdout = __std_out__
                    buf.seek(0)
                    output = buf.read()


# Generated at 2022-06-11 21:56:57.155687
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test 1")
    def test_1():
        for i in range(1000000):
            pass

    with work_in_progress("Test 2"):
        for i in range(1000000):
            pass

# Generated at 2022-06-11 21:57:05.338426
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Counting to ten")
    def count_to_ten():
        answer = 0
        for i in range(10):
            # The sleep command is needed to raise the time taken to execute the
            # code block so that it does not go unnoticed by the unit test.
            time.sleep(0.1)
            answer += i
        return answer
    assert count_to_ten() == 45

    with work_in_progress("Counting from ten to twenty"):
        answer = 0
        for i in range(10, 20):
            # The sleep command is needed to raise the time taken to execute the
            # code block so that it does not go unnoticed by the unit test.
            time.sleep(0.1)
            answer += i
    assert answer == 145

# Generated at 2022-06-11 21:57:13.575842
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress
    def f():
        pass

    with work_in_progress():
        pass

    @work_in_progress('My progress')
    def f():
        pass

    with work_in_progress('My progress'):
        pass

    @work_in_progress()
    def f():
        pass

    with work_in_progress():
        pass

    @work_in_progress('')
    def f():
        pass

    with work_in_progress(''):
        pass

    @work_in_progress('  ')
    def f():
        pass

    with work_in_progress('  '):
        pass

# Generated at 2022-06-11 21:58:05.791630
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path, content=None):
        with open(path, "w") as f:
            if content is not None:
                f.write(content)
            else:
                f.write("This is a test.")
            time.sleep(0.2)

    @work_in_progress("Saving file")
    def save_file(path, content=None):
        with open(path, "r") as f:
            text = f.read()
            time.sleep(0.1)
            return text

    with tempfile.TemporaryDirectory() as tdir:
        path = os.path.join(tdir, "test.txt")
        load_file(path)
        assert save_file(path) == "This is a test."
        load_

# Generated at 2022-06-11 21:58:10.643841
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def test():
        time.sleep(1)
        print("Test function executed!")
    test()
    assert True

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:58:16.705538
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test that the context manager `work_in_progress` displays the correct
    message.
    """
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert obj is None, "Context manager should not have changed the value"

    with work_in_progress("Saving file"):
        pass

# Generated at 2022-06-11 21:58:24.085618
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    import contextlib
    import unittest

    class WorkInProgressTest(unittest.TestCase):
        def setUp(self):
            # redirect stdout to string buffer
            self.output = io.StringIO()
            self.saved_stdout = sys.stdout
            sys.stdout = self.output

        def tearDown(self):
            # restore stdout
            sys.stdout = self.saved_stdout

        def test_work_in_progress_print(self):
            # capture output
            with work_in_progress("Solving ABC"):
                time.sleep(1)

            # check result
            stdout = self.output.getvalue().strip()
            stdout = stdout.split('\n')

# Generated at 2022-06-11 21:58:30.511053
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("./test_data/test_file.bin")
    assert obj == 1

    with work_in_progress("Saving file"):
        with open("./test_data/test_file.bin", "wb") as f:
            pickle.dump(obj, f)


# Generated at 2022-06-11 21:58:33.275225
# Unit test for function work_in_progress
def test_work_in_progress():
    out = io.StringIO()

    @work_in_progress()
    def _():
        time.sleep(0.01)

    with redirect_stdout(out):
        _()

    assert out.getvalue() == "Work in progress... done. (0.01s)\n"

# Generated at 2022-06-11 21:58:38.838172
# Unit test for function work_in_progress
def test_work_in_progress():
    demo_path = "/tmp/demo"
    with open(demo_path, "wb") as f:
        pickle.dump(np.eye(800), f)
    print("Writing file...")
    def write():
        with open(demo_path, "wb") as f:
            pickle.dump(np.eye(800), f)
    with work_in_progress("Writing file"):
        write()
    print("Reading file...")
    def read():
        with open(demo_path, "rb") as f:
            return pickle.load(f)
    with work_in_progress("Reading file"):
        read()
    os.unlink(demo_path)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:58:44.104946
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress()
    def wait_5s():
        time.sleep(5)

    wait_5s()

if __name__ == "__main__":
    import doctest
    doctest.testmod()
    test_work_in_progress()

# Generated at 2022-06-11 21:58:49.509469
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import time

    def fn():
        time.sleep(random.random() * 3 + 1)
        return random.randint(1, 10)

    with work_in_progress("Test"):
        result = fn()
    print(f"Result = {result}")


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:58:58.464421
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "/tmp/test.dat"
    obj = [1, 2, 3]
    with open(path, "wb") as f:
        pickle.dump(obj, f)

    with work_in_progress("Loading file"):
        obj_loaded = load_file(path)
    assert obj == obj_loaded, "Object not loaded correctly!"
    os.remove(path)


if __name__ == "__main__":
    test_work_in_progress()