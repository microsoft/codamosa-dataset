

# Generated at 2022-06-11 21:49:49.191149
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test case: work_in_progress") as t:
        r"""We do not want to waste much time to test this function."""
        print("Hello, world!")
        time.sleep(0.1)

# Generated at 2022-06-11 21:49:50.947193
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1)

# Generated at 2022-06-11 21:49:52.275866
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing working in progress"):
        time.sleep(1)

# Generated at 2022-06-11 21:49:57.936033
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function `work_in_progress`"""
    # Test contextlib.contextmanager version
    with work_in_progress("Testing work_in_progress function"):
        time.sleep(0.5)

    # Test decorator version
    @work_in_progress("Testing work_in_progress decorator")
    def test_func():
        time.sleep(0.5)

    test_func()

# Generated at 2022-06-11 21:50:03.391476
# Unit test for function work_in_progress
def test_work_in_progress():
    time_consumed = 0.00
    desc = "Test task"
    with work_in_progress(desc):
        time_consumed = time.time() - time_consumed
    assert time_consumed >= 0.00

# Generated at 2022-06-11 21:50:09.104883
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test1")
    def test1():
        time.sleep(1)
        return True

    @work_in_progress("Test2")
    def test2():
        time.sleep(1)
        return False

    assert test1()
    assert not test2()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:19.248098
# Unit test for function work_in_progress
def test_work_in_progress():
    from importlib import reload
    import contextlib; reload(contextlib)
    from contextlib import contextmanager

# Generated at 2022-06-11 21:50:21.625546
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file():
        time.sleep(1)
        return

    load_file()

# Generated at 2022-06-11 21:50:28.063827
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress"""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:50:35.456021
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:50:40.783460
# Unit test for function work_in_progress
def test_work_in_progress():
    x = []
    with work_in_progress('Test for work in progress'):
        for i in range(1000000):
            x.append(i)


# Generated at 2022-06-11 21:50:48.713800
# Unit test for function work_in_progress
def test_work_in_progress():
    import os

    @work_in_progress("Checking for path existence")
    def path_exists(path):
        return os.path.exists(path)

    print("Path exists:", path_exists("/bin/python"))
    print("Path exists:", path_exists("/path/does/not/exist"))
    print("Path exists:", path_exists("/usr"))

    with work_in_progress("Sleeping for one second"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:54.206081
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test interactive mode
    with work_in_progress("Loading file") as _:
        time.sleep(5)
    # Test decorator mode
    @work_in_progress("Saving file")
    def save_file(path):
        time.sleep(5)

    obj = {"key": "value"}
    save_file("/tmp/test.pkl")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:01.837460
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert hasattr(obj, "read")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    print("All tests for function `work_in_progress` passed!")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:06.610284
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.5)
    with work_in_progress("Saving file"):
        time.sleep(2.5)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:51:11.798454
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert isinstance(obj, (str, list, set, dict, np.ndarray, type(None)))

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:14.272346
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
        with work_in_progress("Saving file"):
            time.sleep(2)
    # Loading file...
    #     Saving file... done. (2.00s)
    # done. (3.00s)

# Generated at 2022-06-11 21:51:23.871963
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(3)
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        time.sleep(3)
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    test_path = os.path.join(os.path.dirname(__file__), "test.pickle")

    def test_load():
        obj = load_file(test_path)

    def test_save():
        save_file(test_path, {"test": 1})

    test_save()
    test_load()

# Generated at 2022-06-11 21:51:31.564776
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3.52)

    def load_file(path):
        with work_in_progress("Loading file"):
            time.sleep(3.52)
            return True

    assert load_file("/path/to/some/file")
    time.sleep(3.78)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:41.694481
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test for function ``work_in_progress``."""

    from collections import namedtuple
    from glob import glob
    from os import path
    from re import match

    from modules.util import Random

    rand = Random.get_random()

    shape = (2000, 2000)
    array = np.random.randint(256, size=np.prod(shape)).reshape(shape)

    # Test on functions
    with work_in_progress("Loading Foo file"):
        obj = array
        time.sleep(0.25)  # random latency
    assert obj.shape == shape
    with work_in_progress("Loading Bar file"):
        obj = array + 2
        time.sleep(0.25)  # random latency
    assert obj.shape == shape

# Generated at 2022-06-11 21:51:49.872441
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test with a function
    @work_in_progress("Loading file")
    def load_file(path):
        return "This is a test"

    file_loaded = load_file("/path/to/some/file")
    assert file_loaded == "This is a test", "Loading file failed"

    # Test with a context manager
    with work_in_progress("Saving file"):
        pass

    print("All tests passed.")

# Generated at 2022-06-11 21:51:54.367200
# Unit test for function work_in_progress
def test_work_in_progress():
    mock_func = mock.Mock()
    mock_func.return_value = 5

    with work_in_progress("Test work_in_progress"):
        mock_func()

    mock_func.assert_called_once_with()

# Generated at 2022-06-11 21:52:03.919938
# Unit test for function work_in_progress
def test_work_in_progress():
    beg_time = time.time()
    with work_in_progress():
        # Wait for 100ms
        time.sleep(0.1)
    end_time = time.time()
    time_consumed = end_time - beg_time
    assert 0.1 - 0.01 <= time_consumed <= 0.1 + 0.01
    # TODO: Find a better way to test this.
    #       Now I'm just testing whether it's working as expected by looking at the stdout.
    with open("__test_work_in_progress.txt", "wb") as f:
        with redirect_stdout(f):
            test_work_in_progress()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:52:15.334426
# Unit test for function work_in_progress
def test_work_in_progress():
    from os.path import join
    from pkg_resources import resource_filename
    from pickle import load, dump
    from numpy.random import randint

    path = resource_filename(__name__, "__init__.py")

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return load(f)

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            dump(randint(10000), f)

    load_file(path)
    save_file(join("temp", "foo.pkl"))


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:52:19.144219
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(0.1)
        with work_in_progress():
            time.sleep(0.03)

if __name__ == "__main__":
    # self-test code
    test_work_in_progress()

# Generated at 2022-06-11 21:52:28.009134
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    import sys
    from contextlib import redirect_stdout

    sys.stdout = io.StringIO()
    obj = {'a': 0, 'b': 1, 'c': 2}
    with work_in_progress("Saving file"):
        with open("/tmp/test_work_in_progress.pkl", "wb") as f:
            pickle.dump(obj, f)
    out_stream = sys.stdout.getvalue().strip()
    assert out_stream.endswith("done. (0.00s)"), "Fail to time the execution."

    sys.stdout = io.StringIO()

# Generated at 2022-06-11 21:52:30.672198
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Checking file"):
        time.sleep(0.10)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:33.171790
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Executing work_in_progress") as t:
        time.sleep(0.5)
    assert t < 0.6 and t > 0.4



# Generated at 2022-06-11 21:52:36.851046
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Testing work_in_progress()"
    with work_in_progress(desc):
        time.sleep(0.5)

# Generated at 2022-06-11 21:52:44.184045
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""
    >>> @work_in_progress("Loading file")
    ... def load_file(path):
    ...     with open(path, "rb") as f:
    ...         return pickle.load(f)
    ...
    ... obj = load_file("/path/to/some/file")

    >>> with work_in_progress("Saving file"):
    ...     with open(path, "wb") as f:
    ...         pickle.dump(obj, f)
    """


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:52:50.323307
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Processing lines")
    def process_lines(path):
        with open(path) as f:
            for line in f:
                yield line

    result = list(process_lines("/proc/cpuinfo"))
    assert len(result) == 8


# Generated at 2022-06-11 21:52:55.942296
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle


    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with open(__file__, "rb") as f:
        obj = pickle.load(f)

    assert load_file(__file__) == obj


    with work_in_progress("Saving file"):
        time.sleep(3)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:57.813094
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(0.25)
    with work_in_progress("Work"):
        time.sleep(0.25)
        pass

# Generated at 2022-06-11 21:53:09.512073
# Unit test for function work_in_progress
def test_work_in_progress():
    import sys
    import os
    import tempfile
    import time
    import pickle

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump("Some content", f)

    def print_object(obj):
        print("    " + repr(obj))

    def catch_work_in_progress_output(fn):
        # XXX: Context manager does no work at all.
        # This try/except hack is a quick fix.
        # For more details: https://stackoverflow.com/a/39850573
        try:
            with work_in_progress():
                fn()
        except Exception:
            pass


# Generated at 2022-06-11 21:53:14.659630
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open("tmp", "wb") as f:
            pickle.dump(list(range(1000000)), f)

    obj = load_file("tmp")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:53:23.251663
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    # Loading file... done. (3.52s)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    # Saving file... done. (3.78s)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:53:31.598950
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    def assert_work_in_progress(desc: str, expected: str):
        import io
        import sys
        out = io.StringIO()
        sys.stdout = out
        with work_in_progress(desc):
            time.sleep(1.23)
        result = out.getvalue()
        sys.stdout = sys.__stdout__
        assert result.strip() == expected.strip()

    def test_format(desc: str, expected: str):
        print("\nTest: " + desc)
        assert_work_in_progress(desc, expected)

    test_format("", "Work in progress... done. (1.23s)")
    test_format("Loading file", "Loading file... done. (1.23s)")

# Generated at 2022-06-11 21:53:37.948824
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:53:46.094493
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import pickle
    import tempfile

    # To generate a random data file
    obj = []
    for i in range(1000000):
        obj.append(random.randrange(-100, 100))
    with tempfile.NamedTemporaryFile() as f:
        pickle.dump(obj, f)
        f.seek(0)
        obj_copy = pickle.load(f)

    # To load the file
    with work_in_progress(desc="Loading file"):
        with open(f.name, "rb") as f:
            obj_loaded = pickle.load(f)

    # To save the file
    with work_in_progress(desc="Saving file"):
        with tempfile.NamedTemporaryFile() as f:
            pickle.dump(obj, f)


# Generated at 2022-06-11 21:53:53.170908
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:53:58.868482
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("This is a test"):
        time.sleep(0.2)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:54:06.831302
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3)

    with work_in_progress("Saving file"):
        time.sleep(4)

    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(3)
    load_file("/path/to/some/file")

    @work_in_progress("Saving file")
    def save_file(path, obj):
        time.sleep(4)
    save_file("/path/to/some/file", None)

    print("work_in_progress() successful")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:15.501946
# Unit test for function work_in_progress
def test_work_in_progress():
    # Function method
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    # Context manager method
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:23.931090
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert obj is not None, "Work in progress failed to load file."

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:25.788866
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Something") as result:
        time.sleep(1)
    assert result == None

# Generated at 2022-06-11 21:54:29.139340
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3.5)
    with work_in_progress():
        time.sleep(3.8)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:54:36.485903
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test for the :py:func:`work_in_progress` function."""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    
    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# test_work_in_progress()

# Generated at 2022-06-11 21:54:40.358942
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Test work_in_progress")
    def work_in_progress_tester(a, b):
        time.sleep(1)

    work_in_progress_tester(1, 2)


# Generated at 2022-06-11 21:54:43.748023
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Time this function")
    def tester():
        time.sleep(3)
    tester()

# Generated at 2022-06-11 21:54:49.144281
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Time this function")
    def time_me():
        time.sleep(0.3)

    time_me()
    with work_in_progress("Time this context"):
        time.sleep(0.2)

if __name__ == '__main__':
    # Unit test for this module
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:54:54.739514
# Unit test for function work_in_progress

# Generated at 2022-06-11 21:54:59.114885
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Test work in progress")
    def test_work_in_progress_helper(long_time=1):
        time.sleep(long_time)
    test_work_in_progress_helper()

# Generated at 2022-06-11 21:55:01.471434
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress function"):
        time.sleep(2)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:55:03.313372
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sleeping"):
        time.sleep(2)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:55:12.973981
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test module work_in_progress."""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert isinstance(obj, list)
    assert obj == [1, 2, 3]

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump([1, 2, 3], f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:55:24.057083
# Unit test for function work_in_progress
def test_work_in_progress():
    """Tests for module work_in_progress."""

    from pyhelpers import test
    from . import work_in_progress

    print("Test 1")
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file(test.func_sample_data_file_path("sample_obj.pickle"))

    print("Test 2")
    with work_in_progress("Saving file"):
        with open(test.func_sample_data_file_path("sample_obj_copy.pickle"),
                  "wb") as f:
            pickle.dump(obj, f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:55:26.706811
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress
    def do_something():
        time.sleep(1.234)

    do_something()

# Generated at 2022-06-11 21:55:34.506774
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test the decorator
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(0.1)
        with open(path, "rb") as f:
            return pickle.load(f)

    # Load the pickle file
    obj = load_file("/path/to/some/file")

    # Test the context manager
    with work_in_progress("Saving file"):
        time.sleep(0.1)
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:55:45.865758
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile
    import os

    obj = {
        "key1": "value1",
        "key2": "value2",
        "key3": {
            "key3_1": "value3_1",
            "key3_2": "value3_2",
        }
    }

    with tempfile.TemporaryDirectory() as tmpdirname:
        filepath = os.path.join(tmpdirname, "obj.pkl")

        # original object
        print(obj)
        print()
        # saving...
        with work_in_progress("Saving file"):
            with open(filepath, "wb") as f:
                pickle.dump(obj, f)
        print()

        # loading...
        new_obj = None

# Generated at 2022-06-11 21:55:52.859899
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("./data.pkl")
    assert obj is not None

    with work_in_progress("Saving file"):
        with open("./data.pkl", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:56:05.666632
# Unit test for function work_in_progress
def test_work_in_progress():
    def foo():
        time.sleep(0.15)

    with work_in_progress():
        foo()

    with work_in_progress("Executing task"):
        foo()



# Generated at 2022-06-11 21:56:11.239758
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import time
    with work_in_progress("Sleeping 2s"):
        time.sleep(2)
    @work_in_progress("Sleep 1s")
    def sleep_1s():
        time.sleep(1)
    sleep_1s()

# Test
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:12.702059
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing function `work_in_progress`"):
        time.sleep(1)

# Generated at 2022-06-11 21:56:21.709947
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f, encoding="utf-8")

    path = "./data/stopwords_en.txt"
    obj = load_file(path)

    assert len(obj) == 6

    with work_in_progress():
        with open(path, "wb") as f:
            pickle.dump(obj, f, encoding="utf-8")

# Generated at 2022-06-11 21:56:26.999403
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")
    save_file("/path/to/another/file", obj)

# Generated at 2022-06-11 21:56:30.391614
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Waiting"):
        time.sleep(1)

# Alias
wip = work_in_progress

# Generated at 2022-06-11 21:56:34.757140
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Trying out"):
        time.sleep(0.3)
    def f():
        with work_in_progress("Trying out again"):
            time.sleep(0.3)
    f()

test_work_in_progress()

# Generated at 2022-06-11 21:56:38.025748
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work in progress"):
        time.sleep(0.24)

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:56:47.221768
# Unit test for function work_in_progress
def test_work_in_progress():
    # Dummy fuction
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    time.sleep(1)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:56:50.687360
# Unit test for function work_in_progress
def test_work_in_progress():
    # Intentionally slow because we want to test this
    @work_in_progress("Slow work")
    def slow_work():
        time.sleep(1)
    slow_work()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:57:18.066269
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Loading file"):
        obj = load_file("/path/to/some/file")
    print("Result:", obj)

# Generated at 2022-06-11 21:57:21.796118
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3.52)

    with work_in_progress("Saving file"):
        time.sleep(3.78)

# Generated at 2022-06-11 21:57:29.759805
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile
    import time
    import os

    path = os.path.join(tempfile.gettempdir(), "temp_file.pkl")

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path: str, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    # Prepare test object
    obj = list(range(1000000))

    # Save test object
    save_file(path, obj)

    # Load test object
    _obj = load_file(path)

    # Clean up
    os.remove(path)

# Generated at 2022-06-11 21:57:35.522881
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def test_function():
        """Test function for work_in_progress."""
        time.sleep(1)
    test_function()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:57:36.922316
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Initializing test"
    with work_in_progress(desc):
        time.sleep(2)

# Generated at 2022-06-11 21:57:49.492317
# Unit test for function work_in_progress
def test_work_in_progress():
    TEST_STR1 = "Hello World"
    TEST_STR2 = "This is Python"

    def test_loading_file(file_name):
        with work_in_progress("Loading file"):
            with open(file_name, "rb") as f:
                obj = pickle.load(f)
                assert obj == TEST_STR1

    def test_saving_file(file_name):
        with work_in_progress("Saving file"):
            time.sleep(1)
            with open(file_name, "wb") as f:
                pickle.dump(TEST_STR2, f)

    def test_file_exist(file_name):
        assert os.path.exists(file_name)


# Generated at 2022-06-11 21:58:01.518221
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with open("tests/data/example_dict.pickle", "wb") as f:
        pickle.dump({0:0, 1:1}, f, protocol=4)

    obj = load_file("tests/data/example_dict.pickle")
    try:
        assert obj == {0:0, 1:1}
        os.remove("tests/data/example_dict.pickle")
    except:
        raise Exception("Function failed")
    

# Generated at 2022-06-11 21:58:06.034223
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:58:08.294488
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(0.4) # temporary wait for the purpose of testing

# Generated at 2022-06-11 21:58:11.029612
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test work_in_progress"):
        time.sleep(1)

# Generated at 2022-06-11 21:59:03.692167
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import os
    import test.temporary
    from test.expect import expect
    from test.temporary import TemporaryDirectory

    PATH = os.path.join(test.temporary.TMP_DIR, "file.pickle")
    with TemporaryDirectory(PATH):
        with work_in_progress("Getting data"):
            time.sleep(1)
            DATA = dict(hello="world")
        with work_in_progress("Saving data"):
            time.sleep(1.5)
            with open(PATH, "wb") as f:
                pickle.dump(DATA, f)
        with work_in_progress("Loading data"):
            time.sleep(1)
            with open(PATH, "rb") as f:
                expect(pickle.load(f)).to_be(DATA)


# Generated at 2022-06-11 21:59:07.523372
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress() as ctx:
        time.sleep(1)
    time.sleep(1)



# Generated at 2022-06-11 21:59:10.637664
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Dummy progress"):
        time.sleep(0.5)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:59:19.199060
# Unit test for function work_in_progress
def test_work_in_progress():
    wait_time = .25

    # Test in function
    @work_in_progress("Waiting a bit")
    def wait():
        time.sleep(wait_time)
    wait()

    # Test in context manager
    with work_in_progress("Waiting a bit"):
        time.sleep(wait_time)

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:59:29.626842
# Unit test for function work_in_progress
def test_work_in_progress():
    from .text import indent

    with work_in_progress(desc="Testing work_in_progress"):
        time.sleep(1)
    print()

    @work_in_progress(desc="Testing work_in_progress as a decorator")
    def fib(n: int) -> int:
        """Returns the n-th Fibonacci number."""
        if n < 0:
            raise ValueError(f"n cannot be less than 0, but got {n}")
        elif n in (0, 1):
            return n
        else:
            return fib(n - 1) + fib(n - 2)

    assert fib(6) == 8
    print()


# Generated at 2022-06-11 21:59:39.481887
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile
    import random
    import string

    with tempfile.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, "test.pkl")
        with work_in_progress("Creating file"):
            with open(path, "wb") as f:
                pickle.dump(
                    "".join(random.choices(string.printable, k=random.randint(1, 1e6))),
                    f,
                )
        with work_in_progress("Loading file"):
            with open(path, "rb") as f:
                pickle.load(f)
        with work_in_progress("Removing file"):
            os.remove(path)

# Generated at 2022-06-11 21:59:42.783821
# Unit test for function work_in_progress
def test_work_in_progress():
    # Testing the context manager only
    with work_in_progress("Testing"):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()