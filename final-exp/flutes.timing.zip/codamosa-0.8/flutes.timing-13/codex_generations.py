

# Generated at 2022-06-11 21:49:48.373648
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test work in progress") as wi:
        time.sleep(1)

test_work_in_progress()

# Generated at 2022-06-11 21:49:50.947298
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Loading file"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:49:56.193241
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:50:08.111898
# Unit test for function work_in_progress
def test_work_in_progress():

    class Images:
        def __init__(self):
            self.data = list()

        def append(self, img):
            self.data.append(img)

        def __len__(self):
            return len(self.data)

        def __getitem__(self, key):
            return self.data[key]

    def test_work_in_progress_decorator():
        # We simulate a long loading time.
        @work_in_progress("Loading images")
        def load_images(path, num_images):
            images = Images()
            for i in range(num_images):
                time.sleep(1)
                images.append(i)
            return images

        num_images = 10
        images = load_images("/path/to/some/file", num_images)

# Generated at 2022-06-11 21:50:14.169215
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test Work in Progress")
    def f():
        time.sleep(1)
    f()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:20.187968
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work in progress..."):
        time.sleep(1)
    with work_in_progress():
        time.sleep(1.5)
    with work_in_progress("Testing work in progress..."):
        time.sleep(0.5)

# Generated at 2022-06-11 21:50:25.394575
# Unit test for function work_in_progress
def test_work_in_progress():
    def test_fnc(val):
        with work_in_progress():
            time.sleep(val)
    test_fnc(0.5)
    test_fnc(0.25)


if __name__ == "__main__":
    # Run the unit tests if the file is run directly
    logging.basicConfig(level="INFO")
    test_work_in_progress()

# Generated at 2022-06-11 21:50:32.213084
# Unit test for function work_in_progress
def test_work_in_progress():
    # Setup and context manager
    desc = ""
    timer = None
    with work_in_progress(desc) as timer:
        time.sleep(1)

    # Test that the description is modified by the context manager
    assert desc == "Work in progress"
    # Test that the work_in_progress function yields a float
    assert isinstance(timer, float)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:37.454530
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file(__file__)
    assert obj is not None

    with work_in_progress("Saving file"):
        with tempfile.NamedTemporaryFile() as f:
            pickle.dump(obj, f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:50:46.883716
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, data):
        with open(path, "wb") as f:
            pickle.dump(data, f)

    path = os.path.expanduser("~/.local/lib/python3.7/site-packages/psutil/_psutil_windows.cpython-37m-win_amd64.pyd")
    obj = load_file(path)
    path = os.path.join("..", "tmp", "test.obj")
    save_file(path, obj)

if __name__ == "__main__":
    test_work_in

# Generated at 2022-06-11 21:50:53.202848
# Unit test for function work_in_progress
def test_work_in_progress():
    from io import StringIO
    from contextlib import redirect_stdout

    sio = StringIO()
    with redirect_stdout(sio):
        with work_in_progress():
            for i in range(int(1e6)):
                pass
    assert sio.getvalue()[:26] == 'Work in progress... done. ('

# Generated at 2022-06-11 21:50:55.624124
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    with work_in_progress("Testing..."):
        time.sleep(1)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:50:59.827282
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Module import")
    def module_import():
        time.sleep(1)
        import pandas

    module_import()

    with work_in_progress("Importing numpy"):
        time.sleep(2)
        import numpy

# Generated at 2022-06-11 21:51:06.186147
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:51:08.538197
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Working in progress"):
        time.sleep(1)
    assert True

# Generated at 2022-06-11 21:51:17.992774
# Unit test for function work_in_progress
def test_work_in_progress():
    try:
        @work_in_progress("Loading file")
        def load_file(path):
            time.sleep(2)
            with open(path, "rb") as f:
                return pickle.load(f)

        obj = load_file("/path/to/some/file")
        assert True
    except Exception as e:
        assert False
    try:
        with work_in_progress("Saving file"):
            time.sleep(1)
            with open(path, "wb") as f:
                pickle.dump(obj, f)
        assert True
    except Exception as e:
        assert False

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:21.771362
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def test_func():
        time.sleep(2)
    test_func()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:28.347725
# Unit test for function work_in_progress
def test_work_in_progress():
    _sep = "-" * 40
    print(_sep)
    print("Unit test for function work_in_progress")

    _desc, _time = "Loading file", 3.52

    @work_in_progress(_desc)
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    _result = load_file("/path/to/some/file")

    assert f"{_desc}... done. ({_time:.2f}s)"


if __name__ == "__main__":

    test_work_in_progress()

# Generated at 2022-06-11 21:51:34.823451
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    path = "work_in_progress.pkl"
    obj = list(range(100_000))
    save_file(obj, path)
    assert load_file(path) == obj
    os.remove(path)

# Generated at 2022-06-11 21:51:42.615480
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import os

    # Try the context manager
    with work_in_progress("Sleeping"):
        time.sleep(1)

    # Try the decorator
    @work_in_progress("Sleeping")
    def sleep():
        time.sleep(1)
    sleep()

    # Try the context manager with a 'with' statement
    with work_in_progress("Opening file"):
        with open("work_in_progress.py", "r") as f:
            code = f.read()

    # Try the decorator with a function that returns something
    @work_in_progress("Getting current directory")
    def get_cwd():
        return os.getcwd()
    cwd = get_cwd()

# Generated at 2022-06-11 21:51:48.241610
# Unit test for function work_in_progress
def test_work_in_progress():
    begin_time = time.time()
    with work_in_progress("Loading file"):
        time.sleep(2)
    time_consumed = time.time() - begin_time
    assert time_consumed >= 2.0

# Generated at 2022-06-11 21:51:52.069181
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sleeping"):
        time.sleep(0.5)
    print("")
    with work_in_progress("Sleeping"):
        time.sleep(0.5)

# Generated at 2022-06-11 21:52:01.330535
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file(os.path.join(os.path.dirname(__file__), "test.pkl.bz2"))
    assert 0 == obj

    with work_in_progress("Saving file"):
        with open(os.path.join(os.path.dirname(__file__), "test.pkl.bz2"), "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:52:03.980643
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test function"):
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:10.634354
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Start") as progress:
        time.sleep(0.1)
        action = ""
        for i in range(10):
            time.sleep(0.1)
            action = "action " + str(i)
            print(action)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:52:18.627594
# Unit test for function work_in_progress
def test_work_in_progress():
    # A context manager with a function
    def _test_1():
        with work_in_progress("Saving file"):
            time.sleep(1)
    # A decorator with a function
    @work_in_progress("Loading file")
    def _test_2():
        time.sleep(1)

    # A context manager with a code block
    with work_in_progress("Demo 1"):
        time.sleep(1)
    # A decorator with a function
    @work_in_progress("Demo 2")
    def _test_3():
        time.sleep(1)

    _test_1()
    _test_2()
    _test_3()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:22.054686
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    def time_consume(seconds):
        time.sleep(seconds)

    with work_in_progress(desc="A job"):
        time_consume(0.5)

# Generated at 2022-06-11 21:52:23.102967
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(1)

# Generated at 2022-06-11 21:52:33.837355
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit tests for function work_in_progress"""
    import pickle
    import tempfile

    # Test work_in_progress via decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # Test work_in_progress via contextmanager
    def save_file(path):
        with work_in_progress("Saving file"):
            with open(path, "wb") as f:
                pickle.dump(obj, f)

    with tempfile.TemporaryDirectory() as tmpdirname:
        load_file(__file__)
        save_file(tmpdirname + "/tmp.pkl")

    print("All tests have passed.")



# Generated at 2022-06-11 21:52:37.407538
# Unit test for function work_in_progress
def test_work_in_progress():
    def myfunc():
        time.sleep(0.1)

    with work_in_progress("Testing work_in_progress"):
        myfunc()

# Generated at 2022-06-11 21:52:47.196635
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        with open("/path/to/file") as f:
            pass
    with work_in_progress("Saving file"):
        with open("/path/to/file", "w") as f:
            pass

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:49.226558
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function work_in_progress"""
    assert True

# Execute as standalone script
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:57.107518
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import random
    import string

    def make_rand_file(path, n_bytes=100*1024*1024):
        with open(path, "wb") as f:
            # n_bytes = random.randint(1, 1024*1024)
            f.write(random.choice(string.ascii_letters).encode() * n_bytes)
        return os.path.getsize(path)

    def read_rand_file(path):
        with open(path, "rb") as f:
            f.read()

    rand_file = os.path.join(os.path.dirname(__file__), "random.bin")
    if not os.path.isfile(rand_file):
        make_rand_file(rand_file)


# Generated at 2022-06-11 21:53:07.997433
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import pickle

    # Save object
    with work_in_progress("Saving file"):
        obj = {'k': 'v'}
        with open(".temp_file", "wb") as f:
            pickle.dump(obj, f)

    # Load object
    with work_in_progress("Loading file"):
        with open(".temp_file", "rb") as f:
            loaded_obj = pickle.load(f)
        assert loaded_obj == obj

     # Remove temp file
    try:
        os.remove(".temp_file")
    except FileNotFoundError:
        pass


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:53:10.783188
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Unit-testing work_in_progress"):
        time.sleep(0.5)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:53:15.894903
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:53:26.291245
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(2)
        with open(path, "rb") as f:
            return pickle.load(f)

    data = load_file("README.md")
    assert len(data) == 1852, "The file README.md should be 1852 bytes long"

    @work_in_progress("Saving file")
    def save_file(path):
        time.sleep(2)
        with open(path, "wb") as f:
            return pickle.dump(data, f)

    save_file("README.md.bak")
    assert os.path.exists("README.md.bak"), "The file README.md.bak should exist"

# Generated at 2022-06-11 21:53:27.702089
# Unit test for function work_in_progress
def test_work_in_progress():
    def print_hello(name:str):
        print(f"hello {name}")
    with work_in_progress("print hello"):
        print_hello("world")

# Generated at 2022-06-11 21:53:38.053746
# Unit test for function work_in_progress
def test_work_in_progress():
    def wget(url):
        import requests
        return requests.get(url)

    test_url = "http://www.google.com"

    def test_work_in_progress_decorator():
        @work_in_progress("Downloading google.com")
        def get_google():
            return wget(test_url)
        get_google()

    def test_work_in_progress_context_manager():
        with work_in_progress("Download google.com"):
            wget(test_url)
    test_work_in_progress_decorator()
    test_work_in_progress_context_manager()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:53:46.122559
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    Test two scenarios: decorator and context manager.
    """
    # Test decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("test.pkl")
    assert isinstance(obj, list)
    assert obj == [1, 2, 3]

    # Test context manager
    with work_in_progress("Saving file"):
        with open("test.pkl", "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    import sys
    import doctest


# Generated at 2022-06-11 21:53:56.400919
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test if the ``work_in_progress`` function works as expected."""

    @work_in_progress("First test")
    def first_test():
        time.sleep(1)
        return True

    assert first_test() is True

    with work_in_progress("Second test"):
        time.sleep(1)


# Main code
if __name__ == "__main__":
    """Run the unit test for the module `progress.py`."""
    test_work_in_progress()

# Generated at 2022-06-11 21:54:02.054518
# Unit test for function work_in_progress
def test_work_in_progress():

    # Testing context manager
    with work_in_progress("Counting to one million"):
        _ = [i for i in range(1000000)]

    # Testing decorator
    @work_in_progress("Counting to one million again")
    def count():
        _ = [i for i in range(1000000)]

    count()

# Generated at 2022-06-11 21:54:07.558698
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Work in progress") as w:
        time.sleep(1)
        print("Done")
        time.sleep(2)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:13.064241
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with tempfile.NamedTemporaryFile() as f:
        pickle.dump(list(range(100000)), f)
        f.seek(0)
        obj = load_file(f.name)

    assert len(obj) == 100000


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:54:17.983910
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            for _ in range(100_000):
                pickle.load(f)
    obj = load_file("/path/to/some/file")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:23.259964
# Unit test for function work_in_progress
def test_work_in_progress():
    def test_func(x):
        with work_in_progress(f"Test function: x={x}"):
            time.sleep(x)
    test_func(1)
    test_func(2)
    test_func(0.1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:26.904232
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import random

    with work_in_progress("Generating 100 random numbers"):
        for _ in range(100):
            random.random()

    with work_in_progress("Sleeping for 0.5 second"):
        time.sleep(0.5)

# Generated at 2022-06-11 21:54:32.542747
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    from .test_func import create_testdata, test_root
    from .test_desc import desc_testdata

    desc = "Creating testdata"

    with work_in_progress(desc):
        create_testdata(force=True)

    desc_testdata(test_root)

    with work_in_progress(f"Cleaning test_root ({test_root})"):
        os.removedirs(test_root)

# Generated at 2022-06-11 21:54:43.246311
# Unit test for function work_in_progress
def test_work_in_progress():
    import unittest
    import random
    import math

    class TestWorkInProgress(unittest.TestCase):
        """Unit test for function nkutils.metrics.work_in_progress"""

        @work_in_progress("Loading file")
        def load_file(self, path):
            with open(path, "rb") as f:
                return pickle.load(f)

        def test_decorator_work_in_progress(self):
            try:
                self.load_file("/path/to/some/file")
            except FileNotFoundError:
                pass


# Generated at 2022-06-11 21:54:46.571781
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.5)
    @work_in_progress()
    def fake_work():
        time.sleep(0.5)

    fake_work()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:55:03.120696
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:55:10.277452
# Unit test for function work_in_progress
def test_work_in_progress():
    def test_func():
        time.sleep(0.1)
    test_desc = "Test in progress"

    # Testing decorator
    @work_in_progress(test_desc)
    def wrapped():
        test_func()
    wrapped()

    # Testing context manager
    with work_in_progress(test_desc):
        test_func()

if __name__ == "__main__":
    try:
        test_work_in_progress()
    except KeyboardInterrupt:
        pass

# Generated at 2022-06-11 21:55:18.330189
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import pickle
    import tempfile
    import unittest.mock as mock

    with mock.patch("sys.stdout") as mock_stdout:
        with mock.patch("time.time") as mock_time:
            mock_time.side_effect = [0, 1, 2, 3]
            with work_in_progress("Test"):
                time.sleep(2)
            assert mock_stdout.write.call_args_list == [
                mock.call("Test... "),
                mock.call("\n"),
                mock.call("Test... done. (2.00s)"),
            ]
            mock_time.assert_called_once_with()
            mock_time.reset_mock()

            path = None

# Generated at 2022-06-11 21:55:25.053807
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("tests/test_work_in_progress.pickle")
    assert obj == {"a": 1, "b": 2}

    with work_in_progress("Saving file"):
        with open("tests/test_work_in_progress.pickle", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-11 21:55:30.172762
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test work_in_progress."""
    import pickle

    with work_in_progress("Loading file"):
        with open("tmp.pkl", "rb") as f:
            obj = pickle.load(f)

    with work_in_progress("Saving file"):
        with open("tmp.pkl", "wb") as f:
            pickle.dump(obj, f)

    print(obj)

# Generated at 2022-06-11 21:55:35.101916
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:55:44.266299
# Unit test for function work_in_progress
def test_work_in_progress():
    from time import sleep
    import tempfile
    
    def do_something():
        with work_in_progress("Sleeping for 3 seconds"):
            sleep(3)
    
    with work_in_progress("Saving file to temporary directory"):
        tmpdir = tempfile.mkdtemp()
        tmpfile = os.path.join(tmpdir, "test.txt")
        with open(tmpfile, "w") as f:
            f.write("test")
    
    do_something()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:55:48.849540
# Unit test for function work_in_progress
def test_work_in_progress():
    list_ = [random.randint(1, 100) for _ in range(1000)]

    with work_in_progress("Sorting a list of integers"):
        list_.sort()

    @work_in_progress("Sorting a list of integers")
    def sort_list(data):
        data.sort()

    sort_list(list_)

# Generated at 2022-06-11 21:55:52.628760
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing function work_in_progress()"):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:01.362402
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        with open('README.md', 'rb') as f:
            f.read()
    def load_file(path):
        with open(path, "rb") as f:
            return f.read()
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return f.read()
    load_file('README.md')

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:27.544728
# Unit test for function work_in_progress
def test_work_in_progress():
    # Unit test for context manager
    with work_in_progress("Test work_in_progress") as _:
        time.sleep(0.1)

    # Unit test for decorator
    @work_in_progress("Test work_in_progress")
    def test_decorator():
        time.sleep(0.2)

    test_decorator()

# Unit test
if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:56:36.714905
# Unit test for function work_in_progress
def test_work_in_progress():
    from .testing import UnitTest
    from .testing import capture_stdout

    @UnitTest
    def test():
        @work_in_progress("Loading file")
        def load_file(path):
            with open(path, "rb") as f:
                return pickle.load(f)
        # ...
        with capture_stdout() as out:
            obj = load_file("/path/to/some/file")
        return out.getvalue()

    assert test() == "Loading file... done. (3.52s)\n"


# Generated at 2022-06-11 21:56:39.766550
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress
    def compute_long_running_task(i):
        time.sleep(i)

    for i in [0.1, 0.2, 0.3]:
        compute_long_running_task(i)

# Generated at 2022-06-11 21:56:50.824341
# Unit test for function work_in_progress
def test_work_in_progress():
    class TreeNode:
        def __init__(self, val=0, left=None, right=None):
            self.val = val
            self.left = left
            self.right = right

        def __repr__(self):
            return f"TreeNode(val={self.val}, left={self.left}, right={self.right})"

    def is_symmetric(root: TreeNode) -> bool:
        def is_symmetric_recurse(left, right):
            if left is None:
                return right is None
            if right is None:
                return False
            return left.val == right.val and is_symmetric_recurse(left.left, right.right) and is_symmetric_recurse(left.right, right.left)


# Generated at 2022-06-11 21:56:51.889115
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(1)

# Generated at 2022-06-11 21:56:59.832173
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open("/tmp/test.pkl", "wb") as f:
            pickle.dump("lorem ipsum", f)

    with open("/tmp/test.pkl", "rb") as f:
        assert pickle.load(f) == "lorem ipsum"

    load_file("/tmp/test.pkl")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:57:02.249624
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1.0)

# Generated at 2022-06-11 21:57:12.879286
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress."""

    import time
    import unittest

    def test_work_in_progress_func(desc, sleep):
        with work_in_progress(desc):
            time.sleep(sleep)

    class TestWorkInProgress(unittest.TestCase):

        def test_work_in_progress_with_1_sec(self):
            test_work_in_progress_func("Work in progress", 1)

        def test_work_in_progress_with_2_sec(self):
            test_work_in_progress_func("Work in progress", 2)

        def test_work_in_progress_with_3_sec(self):
            test_work_in_progress_func("Work in progress", 3)

    suite = unittest.TestSuite()
   

# Generated at 2022-06-11 21:57:20.156381
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Testing work_in_progress() with function")
    def function():
        time.sleep(0.05)
        return 99

    @work_in_progress("Testing work_in_progress() with context manager")
    def do_stuff_in_context_manager():
        time.sleep(0.1)

    assert function() == 99
    do_stuff_in_context_manager()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:57:25.303110
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    with work_in_progress("Saving file"):
        time.sleep(1.5)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:58:19.192157
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    import sys
    import contextlib

    def capture_print(func):
        @functools.wraps(func)
        def wrapped(*args, **kw):
            with contextlib.redirect_stdout(io.StringIO()) as buf:
                func(*args, **kw)

            return buf.getvalue()
        return wrapped

    @work_in_progress("Test")
    def myfunc(arg1, arg2):
        return arg1 + arg2

    @capture_print
    def print_test():
        with work_in_progress("Test"):
            pass

    assert myfunc(1, 2) == 3
    assert print_test() == "Test... done. (0.00s)\n"


# Generated at 2022-06-11 21:58:22.522224
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test work in progress")
    def wait_1s():
        time.sleep(1.0)

    assert wait_1s() is None


test_work_in_progress()

# Generated at 2022-06-11 21:58:25.611301
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1)

    with work_in_progress("A long task:"):
        time.sleep(3)

# Generated at 2022-06-11 21:58:35.296659
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, data):
        with open(path, "wb") as f:
            pickle.dump(data, f)

    with open("/tmp/test_work_in_progress.txt", "wb") as f:
        pickle.dump([1, 2, 3, 4, 5], f)

    assert load_file("/tmp/test_work_in_progress.txt") == [1, 2, 3, 4, 5]
    save_file("/tmp/test_work_in_progress.txt", [1, 2, 3, 4, 5])


#

# Generated at 2022-06-11 21:58:37.392040
# Unit test for function work_in_progress
def test_work_in_progress():
    assert(work_in_progress())

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:58:44.340684
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import random
    for i in range(1, 10):
        with work_in_progress(f"Work in progress #{i}"):
            time.sleep(random.random())

if __name__ == "__main__":
    import doctest
    doctest.testmod()

    print("Testing function work_in_progress")
    test_work_in_progress()

# Generated at 2022-06-11 21:58:51.813918
# Unit test for function work_in_progress
def test_work_in_progress():
    def test_code_block(duration):
        """Simulate a code block with a certain run duration."""
        with work_in_progress("Sleep for {} seconds".format(duration)):
            time.sleep(duration)

    def test_function(duration):
        @work_in_progress("Sleep for {} seconds".format(duration))
        def func():
            time.sleep(duration)
        func()

    test_code_block(2)
    test_function(1.5)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:58:55.030602
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    with work_in_progress("Saving file"):
        time.sleep(2)

# Generated at 2022-06-11 21:58:56.812019
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(0.02)

# Generated at 2022-06-11 21:59:06.049153
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1.23)
    with work_in_progress("Saving file"):
        time.sleep(2.34)
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    path = "pysimple/tests/data/work_in_progress.data"
    some_data = load_file(path)
    assert some_data == [1, 2, 3]
    @work_in_progress("Saving file")
    def save_file(path, data):
        with open(path, "wb") as f:
            return pickle.dump(data, f)