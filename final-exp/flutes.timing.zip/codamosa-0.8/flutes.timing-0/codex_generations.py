

# Generated at 2022-06-11 21:49:50.477217
# Unit test for function work_in_progress
def test_work_in_progress():
    begin_time = time.time()
    with work_in_progress("Loading file"):
        time.sleep(1)
    end_time = time.time()
    assert end_time - begin_time >= 1.0, "Function work_in_progress is working incorrectly"

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:01.571529
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("./test_files/test_work_in_progress.pkl")
    # Loading file... done. (3.52s)
    assert obj == {1: 1, 2: 4, 3: 9}

    obj = {"test": "test", "test2": "test2"}
    with work_in_progress("Saving file"):
        with open("./test_files/test_work_in_progress.pkl", "wb") as f:
            pickle.dump(obj, f)
    # Saving file... done. (3.78s)

# Generated at 2022-06-11 21:50:09.334667
# Unit test for function work_in_progress
def test_work_in_progress():
    orig_print = print
    captured_output = []

    def mocked_print(*args, **kwargs):
        captured_output.append(" ".join(str(arg) for arg in args))

    try:
        print = mocked_print
        with work_in_progress("test"):
            time.sleep(1.23)
        assert captured_output[-1] == "test... done. (1.23s)"
    finally:
        print = orig_print


if __name__ == '__main__':
    import doctest
    doctest.testmod()

    # Run unit tests
    #test_work_in_progress()

# Generated at 2022-06-11 21:50:16.830857
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import shutil
    import tempfile
    import glob

    temp_dir = tempfile.TemporaryDirectory()
    file_name_list = [
        'foo.txt',
        'bar.mp4',
        'foobar.bin',
        'barfoo.pptx',
        'tmp.gif'
    ]

    # create test files
    for file_name in file_name_list:
        with open(os.path.join(temp_dir.name, file_name), 'w') as f:
            f.write('foobar')

    # remove files
    with work_in_progress('Removing files'):
        for file_name in file_name_list:
            os.remove(os.path.join(temp_dir.name, file_name))

    # find files

# Generated at 2022-06-11 21:50:26.929257
# Unit test for function work_in_progress
def test_work_in_progress():
    # testing decorator style
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            return pickle.dump(obj, f)

    # testing with statement
    data = list(range(10**7))
    path = "./tmp-test-file"

    with work_in_progress("Constructing data"):
        pass

    with work_in_progress("Storing data"):
        save_file(data, path)

    with work_in_progress("Retrieving data"):
        loaded_data = load_file(path)


# Generated at 2022-06-11 21:50:28.196463
# Unit test for function work_in_progress
def test_work_in_progress():
    ...

# Generated at 2022-06-11 21:50:33.434454
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    with work_in_progress("Saving file"):
        time.sleep(2)

# Execute unit tests
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:36.188122
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import random
    with work_in_progress("Fetching api"):
        time.sleep(random.random())

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:50:46.526593
# Unit test for function work_in_progress
def test_work_in_progress():

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    @work_in_progress("Work in progress")
    def do_work():
        return "done"

    with work_in_progress("Loading file"):
        obj = load_file(os.path.abspath(__file__))
    with work_in_progress("Saving file"):
        save_file("/tmp/test_work_in_progress.txt", obj)

    assert do_work() == "done"


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:50:47.030777
# Unit test for function work_in_progress
def test_work_in_progress():
    assert True

# Generated at 2022-06-11 21:50:51.605879
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def twice(x):
        time.sleep(x)
        return 2*x

    assert twice(3) == 6

# Generated at 2022-06-11 21:51:01.694623
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    import sys
    import pickle
    from contextlib import redirect_stdout

    class TestClass:
        def __init__(self, N):
            self.listOfInts = [i for i in range(N)]

    def make_obj(N):
        x = TestClass(N)
        return x

    # Making object to test with
    path = "data.pickle"
    obj = make_obj(int(1e6))
    # Saving object
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    # Loading object
    with work_in_progress("Loading file"):
        with open(path, "rb") as f:
            obj = pickle.load(f)
    #

# Generated at 2022-06-11 21:51:05.883581
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("This is a test")
    def test():
        time.sleep(1)
    test()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:14.527161
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Getting online"):
        time.sleep(0.5)

    class A:
        __slots__ = ("x", "y")
        @work_in_progress("Initializing")
        def __init__(self, x, y):
            self.x = x
            self.y = y
            time.sleep(0.2)

    obj = A(3, 4)
    assert obj.x == 3
    assert obj.y == 4

# Generated at 2022-06-11 21:51:15.748206
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(5)

# Generated at 2022-06-11 21:51:17.416940
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Slow process"

    with work_in_progress(desc):
        time.sleep(1)

# Generated at 2022-06-11 21:51:18.591542
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(0.5)

# Generated at 2022-06-11 21:51:25.060969
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = os.path.join(os.path.dirname(os.path.dirname(__file__)), "tests", "data", "object.gz")
    obj = load_file(path)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:35.663207
# Unit test for function work_in_progress
def test_work_in_progress():
    from tempfile import NamedTemporaryFile
    import pickle
    import random

    def read_obj(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def write_obj(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    # Create a random dictionary of size 1MB
    test_dict = {str(i): random.random() for i in range(1000000)}
    with NamedTemporaryFile() as f:
        test_file = f.name

        # Test read_obj
        write_obj(test_file, test_dict)
        with work_in_progress("Reading dict"):
            new_dict = read_obj(test_file)

# Generated at 2022-06-11 21:51:42.364411
# Unit test for function work_in_progress
def test_work_in_progress():
    path = "test.pkl"
    data = list(range(1000000))

    # Test function decorator version
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    assert data == load_file(path)

    # Test context manager version
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(data, f)

    os.remove(path)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:51:50.220408
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Test work in progress"):
        time.sleep(1)
    assert 1


# Generated at 2022-06-11 21:51:50.998057
# Unit test for function work_in_progress
def test_work_in_progress():
    assert True

# Generated at 2022-06-11 21:51:54.324059
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(2)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:52:02.122086
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    _test_contextlib_work_in_progress()
    test_work_in_progress()

# Generated at 2022-06-11 21:52:05.747083
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("wait for 1 second")
    def wait_time():
        time.sleep(1)
    wait_time()


if __name__ == "__main__":
    pass

# Generated at 2022-06-11 21:52:16.833377
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import pickle
    
    @work_in_progress("loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            return pickle.dump(obj, f)

    path = "/tmp/sample_object.pkl"
    if not os.path.exists(path):
        print("Construct sample object")
        with work_in_progress("Constructing sample object"):
            obj = load_file("/home/louis/Robot/python/sample_object.pkl")
            save_file(obj, path)

# Generated at 2022-06-11 21:52:24.465064
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    from tempfile import TemporaryDirectory

    def func(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = {"a": 1, "b": "Hello"}

    with TemporaryDirectory() as tmpdir:
        path = tmpdir + "/obj.pickle"
        with work_in_progress("Saving file"):
            with open(path, "wb") as f:
                pickle.dump(obj, f)
        with work_in_progress("Loading file"):
            loaded_obj = func(path)

    assert loaded_obj == obj

# Generated at 2022-06-11 21:52:29.036636
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1.2345)
        return None
    load_file("some/file")
    with work_in_progress("Saving file"):
        time.sleep(1.2345)

# Generated at 2022-06-11 21:52:35.361194
# Unit test for function work_in_progress
def test_work_in_progress():
    with open("_test.txt", "w") as file:
        for _ in range(100):
            file.write("a")

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("_test.txt")

    with work_in_progress("Saving file"):
        with open("_test.txt", "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:39.292810
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("This should take about 1 second"):
        time.sleep(1.0)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:52:53.687355
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Function call")
    def test():
        time.sleep(0.1)

    with work_in_progress("Context manager"):
        time.sleep(0.1)

    test()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:53:04.229403
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function work_in_progress."""
    for test_case in [
        # pylint: disable=invalid-name
        ("Work in progress", "Work in progress..."),
        ("A second work in progress", "A second work in progress..."),
        ("A long work in progress" * 8, "A long work in progress" * 7 + "..."),
    ]:
        with patch("sys.stdout", new_callable=StringIO) as mock_output:
            with work_in_progress(test_case[0]):
                time.sleep(2)
        assert test_case[1] in mock_output.getvalue()


##############################################################################

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:53:13.664261
# Unit test for function work_in_progress
def test_work_in_progress():
    def foo():
        for i in range(1000):
            time.sleep(0.001)
        return "return value"

    def bar(filename):
        for i in range(1000):
            time.sleep(0.001)
        with open(filename, "w") as f:
            f.write("1234567890")

    obj = None

    with work_in_progress("Testing function foo"):
        obj = foo()
    assert obj == "return value"
    assert os.path.isfile("tmp.txt") is False

    with work_in_progress("Testing function bar"):
        bar("tmp.txt")
    assert os.path.isfile("tmp.txt") is True


# Generated at 2022-06-11 21:53:18.143472
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test function work_in_progress."""
    import time

    @work_in_progress("Task 1")
    def task1():
        time.sleep(1)

    with work_in_progress("Task 2"):
        time.sleep(1)
    task1()


if __name__ == "__main__":
    """Run unit tests if this file is executed. This is useful when
    I'm developing this module.
    """
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:53:27.503524
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work in progress"):
        time.sleep(1)
    load_file = work_in_progress("Loading file")(pickle.load)
    dump_file = work_in_progress("Saving file")(pickle.dump)
    # Trigger IOError when performing pickle operations on non existent file
    with pytest.raises(IOError):
        load_file("/non/existent/file")
    with pytest.raises(IOError):
        dump_file("/non/existent/file", "")
    # Try serializing an object
    obj = [1, 2, 3, 4, 5]
    dump_file("/tmp/test.pkl", obj)
    loaded_obj = load_file("/tmp/test.pkl")
    assert obj == loaded_obj

# Generated at 2022-06-11 21:53:30.703849
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Helloworld")
    def test():
        time.sleep(2)
    test()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:53:41.463602
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile
    import os

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_path = os.path.join(tmp_dir, "temp.pickle")
        obj = [0] * int(1e6)

        save_file(obj, tmp_path)
        loaded_obj = load_file(tmp_path)
        assert loaded_obj == obj



# Generated at 2022-06-11 21:53:47.787047
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import pickle

    path = os.path.join(os.path.dirname(__file__), "test_data.pkl")

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    loaded_data = load_file(path)
    assert loaded_data == {0: 'a', 1: 'b', 2: 'c'}

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(loaded_data, f)

    loaded_data = load_file(path)
    assert loaded_data == {0: 'a', 1: 'b', 2: 'c'}



# Generated at 2022-06-11 21:53:55.441225
# Unit test for function work_in_progress
def test_work_in_progress():
    # Saving file
    with work_in_progress("Saving file"):
        time.sleep(0.1)
    assert True

    # Loading file
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert True

# Generated at 2022-06-11 21:54:03.857328
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress"""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:54:29.451849
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    with work_in_progress("Saving file"):
        time.sleep(2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:33.279570
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress(desc="Testing function work_in_progress"):
        time.sleep(1)


if __name__ == "__main__":
    try:
        test_work_in_progress()
    except KeyboardInterrupt:
        pass

# Generated at 2022-06-11 21:54:41.747780
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test for function work_in_progress.
    """
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert obj is not None
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()
    pass

# Generated at 2022-06-11 21:54:46.244531
# Unit test for function work_in_progress
def test_work_in_progress():
    def func(i):
        time.sleep(0.02 * i)
    for i in range(6):
        with work_in_progress(f"#{i}"):
            func(i)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:54:55.199383
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing function work_in_progress() ...")
    # Test the context manager version
    with work_in_progress("Testing the context manager version"):
        time.sleep(3.14)

    # Test the decorator version
    @work_in_progress("Testing the decorator version")
    def test_decorator_version():
        time.sleep(3.14)

    test_decorator_version()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:55:02.409381
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            time.sleep(3.524)
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file_with_wip(path):
        with open(path, "rb") as f:
            time.sleep(3.524)
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    obj = load_file_with_wip("/path/to/some/file")

# Generated at 2022-06-11 21:55:07.010752
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Work in progress"):
        time.sleep(1.5)
    # Output:
    # Work in progress... done. (1.50s)

    time.sleep(0.5)

    @work_in_progress("Work in progress 2")
    def sleeping():
        time.sleep(1)
    sleeping()
    # Output:
    # Work in progress 2... done. (1.00s)

    time.sleep(0.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:55:15.466680
# Unit test for function work_in_progress
def test_work_in_progress():
    """Functional test for ``work_in_progress``."""
    import time
    begin_tick = time.monotonic()

    @work_in_progress("Testing function")
    def test_function():
        time.sleep(1)

    test_function()
    end_tick = time.monotonic()
    assert 1 <= end_tick - begin_tick <= 2, "Time consumed is not correct."

    with work_in_progress("Testing context manager"):
        time.sleep(1)

    end_tick = time.monotonic()
    assert 1 <= end_tick - begin_tick <= 2, "Time consumed is not correct."

# Generated at 2022-06-11 21:55:24.128807
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress."""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    logging.info("obj = %s", obj)

    with work_in_progress("Saving file"):
        with open("/path/to/some/other/file", "wb") as f:
            pickle.dump(obj, f)
    return True


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:55:29.366368
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Creating a matrix")
    def work():
        return np.matrix(np.linspace(0, 1000, 1000000))
    mat = work()
    assert mat[0, 0] == 0
    assert mat[0, -1] == 1000
    assert mat.shape == (1000000, 1)

# Generated at 2022-06-11 21:56:17.137488
# Unit test for function work_in_progress
def test_work_in_progress():
    # FIXME: check if stdout prints the right thing
    with work_in_progress("test work in progress"):
        time.sleep(1)

# Generated at 2022-06-11 21:56:23.721377
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import math

    with work_in_progress("Testing work_in_progress()"):
        time.sleep(2.5)

    with work_in_progress("Testing work_in_progress()"):
        time.sleep(0.5)

# Test cases
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:25.759481
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Doing something")
    def something():
        time.sleep(1)

    something()

# Generated at 2022-06-11 21:56:30.828249
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress decorator")
    def _test_work_in_progress():
        time.sleep(1)
    _test_work_in_progress()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-11 21:56:40.615067
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Task 1")
    def task1():
        time.sleep(0.1)

    task1()
    print("")

    @work_in_progress("Task 2")
    def task2():
        time.sleep(0.2)

    task2()
    print("")

    @work_in_progress("Task 3")
    def task3():
        time.sleep(0.3)

    task3()
    print("")

    @work_in_progress("Task 4")
    def task4():
        time.sleep(0.4)

    task4()
    print("")

    @work_in_progress("Task 5")
    def task5():
        time.sleep(0.5)

    task5()
    print("")


# Generated at 2022-06-11 21:56:42.121009
# Unit test for function work_in_progress
def test_work_in_progress():
    import doctest
    doctest.testmod(verbose=True)
    return

# Generated at 2022-06-11 21:56:51.779360
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test the function :func:`work_in_progress`."""
    # Setup a function to test
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # Test the function
    obj = load_file(__file__)

    # Test the context manager
    with work_in_progress("Saving file"):
        with open("/tmp/test.pkl", "wb") as f:
            pickle.dump(obj, f)


# If this Python module is the main module, run unit test for the module
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:56:58.040889
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile
    import pickle
    import random
    output = tempfile.SpooledTemporaryFile()
    data = [random.randint(1, 10) for _ in range(10**6)]
    with contextlib.redirect_stdout(output):
        with work_in_progress("Saving data"):
            pickle.dump(data, output)
        pickle.load(output)
    output.close()

# Generated at 2022-06-11 21:57:06.183694
# Unit test for function work_in_progress
def test_work_in_progress():
    import os

    # Check that the context manager is called correctly
    with work_in_progress("The task description"):
        assert 2 == 2

    # Load a pickle file
    @work_in_progress("Loading file")
    def load_file(path):
        import pickle
        with open(path, "rb") as f:
            return pickle.load(f)

    path = os.path.join(os.path.dirname(__file__), "../../data/bpkg.pkl")
    obj = load_file(path)
    assert isinstance(obj, dict)
    assert "b" in obj
    assert "a" in obj

    # Save a pickle file
    with work_in_progress("Saving file"):
        import pickle

# Generated at 2022-06-11 21:57:07.308562
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    Test the function work_in_progress.

    """

    assert True

# Generated at 2022-06-11 21:58:51.631402
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    from string import ascii_letters
    from pathlib import Path
    import pickle
    from tempfile import gettempdir

    temp_dir = Path(gettempdir())
    temp_file = temp_dir / "__test__.pickle"
    obj = {k: random.random() for k in ascii_letters}

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    @work_in_progress("Loading file")
    def load_file_decorated(path):
        with open(path, "rb") as f:
            return pickle.load(f)

# Generated at 2022-06-11 21:58:55.239461
# Unit test for function work_in_progress
def test_work_in_progress():

    with work_in_progress("Waiting"):
        time.sleep(0.03)

    assert True

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:59:00.525461
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import random

    @work_in_progress("Sorting {0} elements".format(10**6))
    def sleep_and_sort():
        arr = [random.random() for _ in range(10**6)]
        time.sleep(3.0)
        sorted(arr)
        return arr

    assert isinstance(sleep_and_sort(), list)

# Generated at 2022-06-11 21:59:09.838337
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("test work_in_progress"):
        time.sleep(2)
        return 0


# Some text about the module
__doc__ = f"""
Working with contexts.

.. currentmodule:: {__name__}

.. autosummary::
    :toctree: _autosummary

    work_in_progress

"""

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:59:15.328297
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work in progress"):
        time.sleep(1.2)

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 21:59:17.172392
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("hello"):
        time.sleep(0.1)

# Generated at 2022-06-11 21:59:25.583217
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import pickle

    # Fake file content
    nums = [random.randint(1, 10000) for _ in range(100)]

    # test for function
    @work_in_progress("Initializing file")
    def create_file_content(nums: list) -> bytes:
        return pickle.dumps(nums)

    # test for context manager
    with work_in_progress("Saving file"):
        with open('test_work_in_progress.pkl', "wb") as f:
            pickle.dump(nums, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-11 21:59:29.297512
# Unit test for function work_in_progress
def test_work_in_progress():
    with pytest.raises(FileNotFoundError):
        with work_in_progress("Loading file"):
            with open("/path/to/a/nonexistent/file", "rb") as f:
                pickle.load(f)

# Generated at 2022-06-11 21:59:31.058113
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)

    assert True

# Generated at 2022-06-11 21:59:33.467056
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sleep for a second"):
        time.sleep(1)