

# Generated at 2022-06-25 16:58:57.350063
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 16:59:05.799241
# Unit test for function work_in_progress
def test_work_in_progress():
    # UNIT TEST ERRORS:
    # 1. @work_in_progress is not a function.
    #   @work_in_progress("Loading file") is not a function, the syntax is wrong.
    # 2. work_in_progress need a parameter.
    #   work_in_progress doesn't need a parameter.
    # 3. Saving file... done. (3.78s):
    #   1. The time is not correct, because the excution of pickle.dump is not time consuming.
    #      So there is no need to print the time comsumed.
    #   2. The description is wrong
    #      It is "Saving file" rather than "Save file".
    @work_in_progress("Save file")
    def test_0():
        pass

    test_0()



# Generated at 2022-06-25 16:59:09.385945
# Unit test for function work_in_progress
def test_work_in_progress():
    # Testing
    #         @work_in_progress("Loading file")
    #         def load_file(path):
    #             with open(path, "rb") as f:
    #                 return pickle.load(f)
    #
    #         obj = load_file("/path/to/some/file")
    #     Loading file... done. (3.52s)
    #
    #         with work_in_progress("Saving file"):
    #             with open(path, "wb") as f:
    #                 pickle.dump(obj, f)
    #         Saving file... done. (3.78s)
    pass

# Generated at 2022-06-25 16:59:15.132127
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test whether the function works properly."""
    # Define a decorator for the same.
    with work_in_progress("Timer 0"):
        some_list = []
        for i in range(10000):
            some_list.append(i)

    @work_in_progress("Timer 1")
    def test_case_1():
        some_list = []
        for i in range(10000):
            some_list.append(i)
    test_case_1()

# Generated at 2022-06-25 16:59:19.437005
# Unit test for function work_in_progress
def test_work_in_progress():
    var_0 = work_in_progress("Loading file")
    var_1 = work_in_progress("Saving file")


# Generated at 2022-06-25 16:59:21.587185
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1)

# Generated at 2022-06-25 16:59:29.386673
# Unit test for function work_in_progress
def test_work_in_progress():
    import unittest.mock as mock
    with mock.patch('builtins.print') as mock_print:
        with mock.patch('time.time') as mock_time:
            mock_time.return_value = 10
            var_0 = work_in_progress()
            mock_time.return_value = 20
            with var_0:
                pass

    mock_print.assert_has_calls([mock.call('Work in progress... '), mock.call('done. (10.00s)')])


if __name__ == '__main__':
    import sys
    sys.exit(unittest.main())

# Generated at 2022-06-25 16:59:38.368341
# Unit test for function work_in_progress
def test_work_in_progress():
    assert True

# Run the test
if __name__ == '__main__':
    import sys
    import pdb
    uuid = "3e3a53c2-e68a-11e9-9fbb-1c1b0d3fe7e0"

    # Check if there is any argument
    if len(sys.argv) > 1:
        # Check if it's the uuid of the test case to run
        if sys.argv[1] == uuid:
            # Run the test
            test_case_0()

    # Check if there is any breakpoint
    elif len(pdb.breakpoints) > 0:
        # Just run this file
        test_case_0()

# Generated at 2022-06-25 16:59:40.943840
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test 0") as var_0:
        time.sleep(1)

# Generated at 2022-06-25 16:59:44.175088
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Downloading latest NLP Model"):
        time.sleep(0.5)
        print("Downloading latest NLP Model... done.")

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 16:59:47.304561
# Unit test for function work_in_progress
def test_work_in_progress():
    assert True

# Generated at 2022-06-25 16:59:55.341947
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Load file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Save file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump("test string", f)

    load_file("/dev/null")
    save_file("/dev/null")
    return True


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 16:59:57.406808
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress():
        time.sleep(1)

# Generated at 2022-06-25 17:00:04.246718
# Unit test for function work_in_progress
def test_work_in_progress():

    # Test work_in_progress as a decorator
    @work_in_progress  # noqa: MC0001
    def load_file(path):
        time.sleep(3)

    load_file("/path/to/some/file")

    # Test work_in_progress as a context manager
    with work_in_progress():  # noqa: MC0001
        time.sleep(3)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:09.058288
# Unit test for function work_in_progress
def test_work_in_progress():
    try:
        work_in_progress().__enter__()
        raise AssertionError("No exception is raised.")
    except AssertionError as e:
        assert_equal(str(e), "Invalid description.")

# Generated at 2022-06-25 17:00:13.194734
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file") as timer:
        time.sleep(2)
    assert timer.elapsed_time > 2
    with work_in_progress("Loading file") as timer:
        time.sleep(0.5)
    assert timer.elapsed_time < 1

# Generated at 2022-06-25 17:00:14.289481
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("testing"):
        time.sleep(2)

# Generated at 2022-06-25 17:00:15.418393
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing"):
        pass

# Generated at 2022-06-25 17:00:19.370359
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Unit test"):
        time.sleep(0.01)


if __name__ == "__main__":
    import doctest
    doctest.testmod()
    work_in_progress()

# Generated at 2022-06-25 17:00:25.011171
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress
    def test1():
        time.sleep(1)

    @work_in_progress("first")
    def test2():
        time.sleep(1)

    @work_in_progress("first")
    def test3():
        time.sleep(1)

    test1()
    test2()
    test3()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:00:35.695147
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Testing work_in_progress function"):
        time.sleep(0.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:40.882466
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import uuid
    with work_in_progress("Testing work_in_progress()..."):
        path = os.path.join(os.getcwd(), 'test_work_in_progress_{}.pkl'.format(uuid.uuid4()))
        with open(path, "wb") as f:
            pickle.dump({"work_in_progress": "test data"}, f)
        os.unlink(path)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:46.518711
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:00:55.168373
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_files(files: List[str]):
        return [load_file(path) for path in files]
    load_files(["/usr/bin/zsh", "/usr/bin/bash", "/bin/sh"])

    with work_in_progress("Saving file"):
        with open("test.data", "wb") as f:
            pickle.dump([1,2,"123"], f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:05.732241
# Unit test for function work_in_progress
def test_work_in_progress():
    # Import resources
    import os
    import random
    import string
    import pickle

    # Generate a random file name
    letters = string.ascii_lowercase
    file_name = ''.join(random.choice(letters) for i in range(10)) + ".pickle"
    file_path = os.path.join(os.environ["TMP"], file_name)
    file_content = [os.getpid(), [random.randint(0, 9000) for _ in range(10)]]

    # Testing work_in_progress
    with work_in_progress("Writing file"):
        with open(file_path, "wb") as f:
            pickle.dump(file_content, f)


# Generated at 2022-06-25 17:01:10.700334
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:01:14.011965
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing")
    def test():
        with open("/dev/null", "a") as dev_null:
            for i in range(100000):
                dev_null.write("test")
        return dev_null

    test()

# Generated at 2022-06-25 17:01:16.477879
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    for i in range(10):
        with work_in_progress("Generating random int"):
            rand_int = random.randint(0, 100)
        assert rand_int <= 100
        assert rand_int >= 0

# Generated at 2022-06-25 17:01:19.029683
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def _test():
        time.sleep(1.0)
        return 42

    assert _test() == 42

# Generated at 2022-06-25 17:01:23.831419
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Allocating memory"):
        time.sleep(1.23)
    with work_in_progress():
        time.sleep(1.23)
    print()


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:01:42.366694
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:46.236138
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:01:48.266191
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    with work_in_progress("Loading file"):
        time.sleep(1)

# Generated at 2022-06-25 17:01:58.873897
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import random
    import tempfile

    with tempfile.TemporaryDirectory() as tmpdir:
        file_path = os.path.join(tmpdir, "test.pkl")
        obj = random.random()
        with work_in_progress("Saving object"):
            with open(file_path, "wb") as f:
                pickle.dump(obj, f)
        assert os.path.isfile(file_path)

        with work_in_progress("Loading object"):
            with open(file_path, "rb") as f:
                obj_loaded = pickle.load(f)
        assert obj == obj_loaded

# Generated at 2022-06-25 17:02:02.816344
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(1.0)

    with work_in_progress("Loading file"):
        time.sleep(1.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:02:11.980091
# Unit test for function work_in_progress
def test_work_in_progress():
    with contextlib.suppress(FileNotFoundError):
        os.remove("test.temp")

    # Method 1: Context manager as function
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # Method 2: Context manager as a context manager.
    with work_in_progress("Saving file"):
        with open("test.temp", "wb") as f:
            pickle.dump(b"test", f)

    # Test if the file appears after the loading command is called.
    assert not os.path.exists("test.temp")
    assert load_file("test.temp") == b"test"

    # Delete the test file created.
    os.remove("test.temp")

# Generated at 2022-06-25 17:02:23.484839
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test that work_in_progress is working correctly.

    Raise an assertion error if the expected string is not output.
    """
    # Set up, capture stdout, and run function
    func_to_run = lambda : time.sleep(2)
    expected_output = "My Task... done. (2.00s)"
    with unittest.mock.patch("sys.stdout", new=StringIO()) as mock_out:
        with work_in_progress("My Task"):
            func_to_run()
    # Assert
    mock_out.seek(0)
    actual_output = mock_out.read()
    assert actual_output == expected_output

# Generated at 2022-06-25 17:02:28.141906
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress(desc="Sleep for 1 second"):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:02:39.837889
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import pickle
    import string

    def random_string(length):
        return "".join(random.choices(string.ascii_uppercase + string.digits, k=length))

    def random_dict(max_len=5, max_val_len=5):
        return {random_string(max_len): random_string(max_val_len) for _ in range(random.randint(1, max_len))}

    # Test with a context manager
    with work_in_progress("Generating random content"):
        obj = random_dict()

    # Test with a function
    @work_in_progress("Generating more random content")
    def generate_more_random_content():
        return random_dict()

    more_obj = generate_more_random_content()

   

# Generated at 2022-06-25 17:02:45.478408
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3)

    @work_in_progress("Saving file")
    def save_file():
        time.sleep(3)

    save_file()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:03:19.181620
# Unit test for function work_in_progress
def test_work_in_progress():

    import random
    @work_in_progress("Testing function")
    def foo():
        time.sleep(random.random())

    foo()
    time.sleep(0.5)
    with work_in_progress("Testing context manager"):
        time.sleep(random.random())

# Generated at 2022-06-25 17:03:30.701972
# Unit test for function work_in_progress
def test_work_in_progress():
    from pathlib import Path
    from os import makedirs
    from os.path import exists

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(data, path):
        with open(path, "wb") as f:
            pickle.dump(data, f)

    with work_in_progress(f"Unit test for function work_in_progress"):
        # Test with function
        if not exists("./data"):
            makedirs("./data")
        with work_in_progress(f"Save file to ./data"):
            save_file(list(range(10000)), "./data/test.bin")
        with work_in_progress(f"Load file from ./data"):
            assert load_

# Generated at 2022-06-25 17:03:33.834161
# Unit test for function work_in_progress
def test_work_in_progress():
    def my_func():
        for i in range(1000000):
            pass

    with work_in_progress("Executing a function"):
        my_func()



# Generated at 2022-06-25 17:03:37.356978
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def foo():
        time.sleep(2)
    foo()
    with work_in_progress():
        time.sleep(2)

# Generated at 2022-06-25 17:03:50.365755
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    def load_file(fname):
        begin_time = time.time()
        with open(fname, 'rb') as f:
            var = pickle.load(f)
        time_consumed = time.time() - begin_time
        print(f"Loading file... done. ({time_consumed:.2f}s)")
        return var

    def save_file(fname, var):
        begin_time = time.time()
        with open(fname, 'wb') as f:
            pickle.dump(var, f)
        time_consumed = time.time() - begin_time
        print(f"Saving file... done. ({time_consumed:.2f}s)")

    print("Working without work_in_progress")

# Generated at 2022-06-25 17:03:55.700227
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:03:58.685388
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test the function work_in_progress.
    """
    with work_in_progress("Loading file"):
        pass

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:04:07.369419
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1.2)
    with work_in_progress("Saving file"):
        time.sleep(1.5)
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    return True

# Generated at 2022-06-25 17:04:13.131699
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:04:19.548666
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:05:15.417636
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(2)

# Generated at 2022-06-25 17:05:19.172531
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function ``work_in_progress``.

    .. code:: python

        >>> with work_in_progress("Test"):
        ...     time.sleep(1)
        Test... done. (1.00s)
    """
    with work_in_progress("Test"):
        time.sleep(1)

# Generated at 2022-06-25 17:05:22.788243
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Hello World")
    def do_nothing():
        pass

    do_nothing()
    with work_in_progress("Hello World"):
        pass


# Generated at 2022-06-25 17:05:27.232225
# Unit test for function work_in_progress
def test_work_in_progress():
    import os

    with work_in_progress("Trying to delete a file"):
        os.unlink("/tmp/some_file")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:05:28.746189
# Unit test for function work_in_progress
def test_work_in_progress():
    def func():
        time.sleep(0.1)

    with work_in_progress():
        func()

# Generated at 2022-06-25 17:05:32.823269
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "/path/to/some/file"
    obj = load_file(path)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:05:40.463894
# Unit test for function work_in_progress
def test_work_in_progress():
    def _fib(n: int):
        if n == 0 or n == 1:
            return 1
        return _fib(n - 1) + _fib(n - 2)

    # Using a simple function
    @work_in_progress("Calculating the fibonacci number of 10")
    def test_function():
        _fib(10)

    # Using a context manager
    with work_in_progress("Calculating the fibonacci number of 10"):
        _fib(10)

    # Using a class method
    class Fibonacci(object):
        @work_in_progress("Calculating the fibonacci number of 10")
        def test_method(self):
            _fib(10)

    Fibonacci().test_method()

# Generated at 2022-06-25 17:05:45.843924
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, 'rb') as f:
            return pickle.load(f)

    obj = load_file(__file__)

    with work_in_progress("Saving file"):
        with open(__file__, "wb") as f:
            pickle.dump(obj, f)

# test_work_in_progress()

# Generated at 2022-06-25 17:05:49.345804
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(0.1)
    with work_in_progress("Sleeping"):
        time.sleep(0.1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:06:00.709904
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @contextlib.contextmanager
    def work_in_progress(desc: str = "Work in progress"):
        print(desc + "... ", end='', flush=True)
        begin_time = time.time()
        yield
        time_consumed = time.time() - begin_time
        print(f"done. ({time_consumed:.2f}s)")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(dict(), f)

# Generated at 2022-06-25 17:08:08.247945
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:08:09.138541
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file") as _:
        time.sleep(.5)

# Generated at 2022-06-25 17:08:15.078387
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work in progress"):
        time.sleep(0.001)
        assert 1 == 1

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:08:16.889009
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Task")
    def f(*args, **kwargs):
        return
    f()

# Generated at 2022-06-25 17:08:29.019998
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing work_in_progress() ...")
    @work_in_progress("No sleep")
    def no_sleep():
        pass

    @work_in_progress("5 seconds")
    def five_seconds():
        time.sleep(5)

    @work_in_progress("2 seconds")
    def two_seconds():
        time.sleep(2)
        no_sleep()

    @work_in_progress("2 seconds")
    def two_seconds():
        time.sleep(2)
        with work_in_progress("1 second"):
            time.sleep(1)

    no_sleep()
    five_seconds()
    two_seconds()
    two_seconds()
    print("Testing work_in_progress() ... [OK]")


if __name__ == "__main__":
    test_work

# Generated at 2022-06-25 17:08:32.082795
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import numpy as np

    test_data = np.random.rand(1000, 1000)

    with tempfile.NamedTemporaryFile() as fp:
        with work_in_progress("Saving file"):
            np.save(fp, test_data)
        with work_in_progress("Loading file"):
            assert (test_data == np.load(fp)).all()

# Generated at 2022-06-25 17:08:36.268370
# Unit test for function work_in_progress
def test_work_in_progress():
    if False:
        import doctest
        doctest.testmod()


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:08:43.729057
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "r") as f:
            return f.read()

    obj = load_file(__file__)
    assert obj

    with work_in_progress("Saving file"):
        time.sleep(0.5)

# Generated at 2022-06-25 17:08:52.010075
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file():
        time.sleep(1)
        with open("filename", "rb") as f:
            return pickle.load(f)

    load_file()

    with work_in_progress("Saving file"):
        time.sleep(1)
        with open("filename", "wb") as f:
            pickle.dump(object, f)

