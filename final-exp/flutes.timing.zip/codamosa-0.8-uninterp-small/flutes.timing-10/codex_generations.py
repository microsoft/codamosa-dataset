

# Generated at 2022-06-25 16:58:57.489283
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""
    If you want to test this file, run this command:
    $ python -m pytest tests/test_utils.py
    """
    assert True


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 16:59:01.712784
# Unit test for function work_in_progress
def test_work_in_progress():
    assert test_case_0() is None


if __name__ == "__main__":
    print(
        "Executing test cases for " +
        os.path.basename(__file__, os.path.extsep) +
        "... "
    )
    test_work_in_progress()
    print("All done!")

# Generated at 2022-06-25 16:59:07.114481
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            time.sleep(0.5)
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open("/tmp/out.pkl", "wb") as f:
            time.sleep(0.5)
            pickle.dump(obj, f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 16:59:08.551003
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress() as var_0:
        pass


# Generated at 2022-06-25 16:59:12.858283
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test work_in_progress"""
    with var_0:
        with var_0:
            pass
            pass
    with var_0:
        with var_0:
            pass
        with var_0:
            pass
            pass

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 16:59:14.873671
# Unit test for function work_in_progress
def test_work_in_progress():
    desc: str = "Work in progress"
    with work_in_progress(desc) as var_0:
        assert var_0 is None

# Generated at 2022-06-25 16:59:21.495710
# Unit test for function work_in_progress
def test_work_in_progress():
    var_1 = work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    var_2 = work_in_progress("Saving file")
    with open(path, "wb") as f:
        pickle.dump(obj, f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 16:59:23.175933
# Unit test for function work_in_progress
def test_work_in_progress():
    test_case_0()

# Generated at 2022-06-25 16:59:24.547534
# Unit test for function work_in_progress
def test_work_in_progress():
    work_in_progress()


# Generated at 2022-06-25 16:59:28.128664
# Unit test for function work_in_progress
def test_work_in_progress():
    assert callable(work_in_progress)


if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-25 16:59:33.028702
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def fun():
        time.sleep(0.3)

    fun()

# Generated at 2022-06-25 16:59:36.091867
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress(desc="Testing function work_in_progress")
    def testing_work_in_progress():
        time.sleep(5)
    
    testing_work_in_progress()

# test_work_in_progress()

# Generated at 2022-06-25 16:59:39.005739
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test function"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 16:59:43.423825
# Unit test for function work_in_progress
def test_work_in_progress():
    def _test(num: int = 100000) -> float:
        time.sleep(0.2)
        for i in range(num):
            _ = [_ for _ in range(i)]
        return 1

    with work_in_progress("Test"):
        _test()

# Generated at 2022-06-25 16:59:47.787499
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test case 1: do nothing
    with work_in_progress("Do nothing"):
        pass
    # Test case 2: sleep 1 second
    with work_in_progress("Sleep 1 second"):
        time.sleep(1)
    # Test case 3: loop for one million times
    with work_in_progress("Loop for one million times"):
        for _ in range(1_000_000):
            pass

# Generated at 2022-06-25 16:59:53.593163
# Unit test for function work_in_progress
def test_work_in_progress():
    """This function is for testing only."""
    print("Loading file... ", end='', flush=True)
    time.sleep(1)
    print("done. (1.00s)")
    time.sleep(2)
    with work_in_progress("Saving file"):
        time.sleep(3)
    print("Updated! (3.00s)")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 16:59:59.009930
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Num a"):
        time.sleep(1.0)
    with work_in_progress("Num b"):
        time.sleep(2.0)
    with work_in_progress("Num c"):
        time.sleep(3.0)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:09.261679
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1)
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path):
        time.sleep(1)
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with tempfile.NamedTemporaryFile() as f:
        obj = list(range(2**24))
        save_file(f.name)
        res = load_file(f.name)

    assert res == obj


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:00:13.429749
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")



# Generated at 2022-06-25 17:00:15.119081
# Unit test for function work_in_progress
def test_work_in_progress():
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:00:27.934891
# Unit test for function work_in_progress
def test_work_in_progress():
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:00:35.614768
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = [1, 2, 3]
    with tempfile.TemporaryDirectory() as path:
        path = os.path.join(path, "testFile.pkl")
        save_file(obj, path)
        loaded_obj = load_file(path)

    assert loaded_obj == obj

# Generated at 2022-06-25 17:00:39.570201
# Unit test for function work_in_progress
def test_work_in_progress():
    """TODO: Unit test for work_in_progress"""
    import time
    with work_in_progress("Loading file", log_level=logging.INFO):
        time.sleep(1)
        logging.info("Hello")
        logging.warning("world")
        time.sleep(1)
    return


if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    # logging.basicConfig(level=logging.INFO)
    test_work_in_progress()

# Generated at 2022-06-25 17:00:48.773802
# Unit test for function work_in_progress
def test_work_in_progress():
    dummy_obj = list(range(10000))
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    def save_file(path, obj):
        with open(path, "wb") as f:
            return pickle.dump(obj, f)

    with tempfile.TemporaryDirectory() as temp_dir:
        temp_path = os.path.join(temp_dir, "test.pickle")
        with work_in_progress("Loading file"):
            load_file(temp_path)
        with work_in_progress("Saving file"):
            save_file(temp_path, dummy_obj)
        with work_in_progress("Loading file"):
            load_file(temp_path)

# Generated at 2022-06-25 17:00:59.165609
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import pickle
    import random
    import os

    # A dumb load function
    @work_in_progress("Loading file")
    def load_file(path: str) -> int:
        with open(path, "rb") as f:
            return pickle.load(f)

    # A dumb save function
    @work_in_progress("Saving file")
    def save_file(path: str, data: int):
        with open(path, "wb") as f:
            pickle.dump(data, f)

    # Create a temporary file and write some random integers to it
    with tempfile.NamedTemporaryFile(delete=False) as f:
        path = f.name
        data = random.randint(0, 100)
        save_file(path, data)

    # Load

# Generated at 2022-06-25 17:01:03.793202
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing @work_in_progress")
    def _test():
        time.sleep(1)
    _test()
    with work_in_progress("Testing contextlib.contextmanager"):
        time.sleep(2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:09.935935
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test a code block
    with work_in_progress("Test work_in_progress"):
        time.sleep(2)

    # Test a function
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:13.585903
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sleeping for a bit"):
        time.sleep(0.5)
    with work_in_progress("Sleeping for some time"):
        time.sleep(2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:15.191173
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1.0)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:18.038431
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.2)
    print()
    with work_in_progress("Saving file"):
        time.sleep(0.5)


"""DisabledContent
"""

# Generated at 2022-06-25 17:01:36.030205
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function work_in_progress."""
    test_path = Path(__file__).parent / "work_in_progress_tester.p"
    obj = {"a": 1, "b": 2, "c": 3}

    with work_in_progress("Saving file"):
        with open(test_path, "wb") as f:
            pickle.dump(obj, f)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    assert obj == load_file(test_path)

    test_path.unlink()

# Generated at 2022-06-25 17:01:39.822355
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3)

# Generated at 2022-06-25 17:01:46.618409
# Unit test for function work_in_progress
def test_work_in_progress():
    sample = list(range(1, 1000000))
    @work_in_progress("Time elapsed")
    def test(x):
        for i in x:
            if i % 1000 == 0:
                time.sleep(0.01)
    test(sample)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:01:59.195717
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test for function :func:`work_in_progress`."""
    def test_load_file(path):
        r"""Test function that loads a file."""
        with open(path, "rb") as f:
            return pickle.load(f)

    def test_save_file(path):
        r"""Test function that saves a file."""
        with open(path, "wb") as f:
            pickle.dump("Hello, World!", f)


    test_file = tempfile.NamedTemporaryFile(delete=False)
    test_file.close()

    @work_in_progress("Loading file")
    def load_file(path):
        return test_load_file(path)

    obj = load_file(test_file.name)
    assert obj == "Hello, World!"

   

# Generated at 2022-06-25 17:02:08.957828
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Load file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Save file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    dataset_path = os.path.join("data", "test.bin")
    dataset = np.random.random((1000000, 5))

    # Save file
    save_file(dataset_path, dataset)

    # Load file
    dataset_retrieved = load_file(dataset_path)

    # Test
    assert np.all(dataset == dataset_retrieved)

    # Remove file

# Generated at 2022-06-25 17:02:15.291733
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")



# Generated at 2022-06-25 17:02:26.778557
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import string
    import pickle
    import os
    import shutil

    def random_string(n: int = 10) -> str:
        r"""Generate a random string of given length."""
        return ''.join(random.choices(string.ascii_lowercase, k=n))

    def _test1():
        @work_in_progress("Loading file")
        def load_file(path: str):
            with open(path, "rb") as f:
                return pickle.load(f)

        obj = load_file("/path/to/some/file")
        assert obj is not None

    def _test2():
        with work_in_progress("Saving file"):
            obj = {random_string(): random_string() for _ in range(100)}
            tmp_dir

# Generated at 2022-06-25 17:02:27.943833
# Unit test for function work_in_progress
def test_work_in_progress():
    # TODO
    pass

# Generated at 2022-06-25 17:02:38.067680
# Unit test for function work_in_progress
def test_work_in_progress():
    from os import urandom
    from io import BytesIO
    import pickle

    # Test the use in a regular function
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file(BytesIO(urandom(5000)))

    # Test the use inside a context manager
    with work_in_progress("Saving file"):
        with BytesIO() as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:02:43.907523
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Not fast"):
        time.sleep(0.1)
    with work_in_progress():
        time.sleep(0.1)



# Generated at 2022-06-25 17:03:19.909988
# Unit test for function work_in_progress
def test_work_in_progress():
    try:
        os.remove("./test/test_work_in_progress.pkl")
    except FileNotFoundError:
        pass

    with work_in_progress("Loading file"):
        with open("./test/test_work_in_progress.pkl", "wb") as f:
            time.sleep(3.52)
            pickle.dump({"a": 1}, f)
    with work_in_progress("Saving file"):
        with open("./test/test_work_in_progress.pkl", "rb") as f:
            time.sleep(3.78)
            pickle.load(f)

# Generated at 2022-06-25 17:03:24.468205
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing function work_in_progress")
    with work_in_progress("Testing function"):
        time.sleep(1.0)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:03:27.434973
# Unit test for function work_in_progress
def test_work_in_progress():
    pass
    # @work_in_progress("Testing work_in_progress()")
    # def work():
    #     import time
    #     time.sleep(2)
    #
    # work()

# Generated at 2022-06-25 17:03:28.844031
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        pass

# Generated at 2022-06-25 17:03:35.717309
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test function work_in_progress().
    """
    # Unit test for function load_file
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:03:38.035480
# Unit test for function work_in_progress
def test_work_in_progress():
    def function():
        time.sleep(3)
    with work_in_progress(desc="Sleeping for 3 seconds"):
        function()


# Generated at 2022-06-25 17:03:50.651695
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import pathlib
    import random
    import shutil

    path = pathlib.Path("tmp_bin")
    if os.path.isdir(path):
        shutil.rmtree(path)
    os.mkdir(path)

    def generate():
        def generate_bytes_array(size):
            return bytes(random.randint(0, 255) for _ in range(size))

        with work_in_progress("Generating 1024.bin"):
            with open(path / "1024.bin", "wb") as f:
                f.write(generate_bytes_array(1024))
        with work_in_progress("Generating 2048.bin"):
            with open(path / "2048.bin", "wb") as f:
                f.write(generate_bytes_array(2048))

# Generated at 2022-06-25 17:03:58.410847
# Unit test for function work_in_progress
def test_work_in_progress():
    from uuid import uuid4
    from .util import tmp_file

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    OBJ = uuid4()
    with work_in_progress(desc="Loading file"):
        assert load_file(tmp_file(OBJ)) == OBJ

    with work_in_progress(desc="Saving file"):
        save_file(tmp_file(OBJ), OBJ)

# Generated at 2022-06-25 17:04:02.008662
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Work in progress"):
        pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()
    # test_work_in_progress()

# Generated at 2022-06-25 17:04:09.235488
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:05:13.348593
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:05:23.948383
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file1(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # Test with 'with'
    for i in range(3):
        with work_in_progress("Saving file"):
            with open(path, "wb") as f:
                pickle.dump(obj, f)

    # Test as a decorator
    load_file1(path)

# Generated at 2022-06-25 17:05:29.860919
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile
    import os

    with work_in_progress("Loading file"):
        obj = [1, 2, 3]
    path = tempfile.mktemp()
    with open(path, "wb") as f:
        pickle.dump(obj, f)
    size = os.path.getsize(path)
    with work_in_progress("Loading file"):
        with open(path, "rb") as f:
            obj2 = pickle.load(f)
    os.remove(path)
    if obj != obj2:
        raise Exception("Failed to save and load the test object")
    print(f"The file was {size} bytes long.")

# Generated at 2022-06-25 17:05:37.844801
# Unit test for function work_in_progress
def test_work_in_progress():
    def test_func(sleep=1):
        time.sleep(sleep)
        return True

    assert not test_func(0.1)
    with work_in_progress("Test"):
        assert test_func(0.1)
    with work_in_progress("Test"):
        assert test_func(0.5)
    with work_in_progress("Test"):
        assert test_func(0.7)
    with work_in_progress("Test"):
        assert test_func(1.3)
    with work_in_progress("Test"):
        assert test_func(1.7)
    with work_in_progress("Test"):
        assert test_func(3.3)

# Generated at 2022-06-25 17:05:42.355112
# Unit test for function work_in_progress
def test_work_in_progress():
    import doctest
    doctest.run_docstring_examples(work_in_progress, globals())


# Make sure we import test_work_in_progress into __main__ namespace
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:05:53.526272
# Unit test for function work_in_progress
def test_work_in_progress():
    from datetime import datetime
    from os import remove

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    file_path = "__test_" + datetime.now().strftime("%Y%m%d-%H%M%S")
    obj = (1, "test", [range(10)], dict(test="test"))
    save_file(obj, file_path)
    assert load_file(file_path) == obj
    remove(file_path)



# Generated at 2022-06-25 17:05:59.352223
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(0.1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:06:06.965520
# Unit test for function work_in_progress
def test_work_in_progress():
    # Version 1
    @work_in_progress("Load csv")
    def load_csv(path, delimiter=','):
        return np.loadtxt(path, delimiter=delimiter)
    rand_mat = load_csv('/Users/Ethan/Desktop/capstone/data/matrix_data/rand_mat_10000.csv', delimiter=',')
    print(rand_mat)

    # Version 2
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:06:14.260980
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:06:24.441864
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile

    with tempfile.TemporaryDirectory() as tmp_dir:
        # Already exists
        path = os.path.join(tmp_dir, 'text1.txt')
        with open(path, 'w') as f:
            f.write('hello\n')

        file_path = os.path.join(tmp_dir, 'test.txt')
        with work_in_progress("Creating file"):
            with open(file_path, 'w') as f:
                f.write('hello\n')

        with work_in_progress("Deleting file"):
           os.remove(file_path)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:08:36.194775
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:08:42.898041
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test")
    def long_task():
        time.sleep(2)
    long_task()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:08:46.806924
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.5)
    with work_in_progress("Saving file"):
        time.sleep(1.1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:08:52.090010
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def f():
        time.sleep(0.5)
    f()

if __name__ == "__main__":
    test_work_in_progress()