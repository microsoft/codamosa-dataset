

# Generated at 2022-06-25 16:58:55.697799
# Unit test for function work_in_progress
def test_work_in_progress():
    var_0 = work_in_progress()


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 16:58:57.151210
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress() as var_0:
        pass

# Generated at 2022-06-25 16:58:59.627199
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(.5)

if __name__ == '__main__':
    # Begin unit tests
    test_work_in_progress()

# Generated at 2022-06-25 16:59:00.842848
# Unit test for function work_in_progress
def test_work_in_progress():
    pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 16:59:03.735531
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        pass
    with work_in_progress():
        pass

if __name__ == "__main__":
    # test_case_0()
    test_work_in_progress()

# Generated at 2022-06-25 16:59:04.491738
# Unit test for function work_in_progress
def test_work_in_progress():

    test_case_0()

# vim: ai ts=4 sts=4 et sw=4 ft=python

# Generated at 2022-06-25 16:59:07.919741
# Unit test for function work_in_progress
def test_work_in_progress():
    with open('./tests/test_work_in_progress_output.txt', 'r') as test_output:
        with redirect_stdout(StringIO()) as test_stdout:
            test_case_0()
            assert test_stdout.getvalue() == test_output.read()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 16:59:17.261701
# Unit test for function work_in_progress
def test_work_in_progress():
    # Define variables
    desc = "Loading file"
    path = "/path/to/some/file"
    obj = {"foo": [1, 2, 3]}

    @work_in_progress(desc)
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with open(path, "wb") as f:
        pickle.dump(obj, f)

    assert load_file(path) == obj

    with work_in_progress(desc):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    assert load_file(path) == obj

if __name__ == "__main__":
    test_case_0()
    test_work_in_progress()

# Generated at 2022-06-25 16:59:23.692982
# Unit test for function work_in_progress
def test_work_in_progress():
    
    with work_in_progress("Testing") as _var_0:
        var_0 = work_in_progress()
    with work_in_progress("Testing done") as _var_1:
        pass
    with work_in_progress("Testing") as _var_2:
        with work_in_progress("Testing done") as _var_3:
            pass
    

if (__name__ == '__main__'):
    from . import test
    test.run_tests()

# Generated at 2022-06-25 16:59:31.264017
# Unit test for function work_in_progress
def test_work_in_progress():

    #### Setup

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file_profiled(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    @work_in_progress("Saving file")
    def save_file_profiled(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    #### Tests

    #### Tests for with statement usage


# Generated at 2022-06-25 16:59:44.029536
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test Work in progress"):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 16:59:49.725094
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1)
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("test_work_in_progress.pkl")

    with work_in_progress("Saving file"):
        time.sleep(1)
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 16:59:55.503212
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Sleep 1s")
    def test_func():
        time.sleep(1)

    test_func()
    # Sleep 1s... done. (1.00s)
    with work_in_progress("Sleep 2s"):
        time.sleep(2)
    # Sleep 2s... done. (2.00s)

# Generated at 2022-06-25 17:00:04.623060
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, 'rb') as f:
                return pickle.load(f)

    work_in_progress('Loading file')
    a = load_file('/path/to/some/file')

    @work_in_progress("Saving file")
    def save_file(obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    save_file(a)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:12.612119
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:16.754491
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/home/i/python/test/test.pkl")

    with work_in_progress("Saving file"):
        with open("/home/i/python/test/test2.pkl", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:00:23.446629
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("../data/compressed_data.pkl")
    save_file("../data/save_compressed_data.pkl")

# Generated at 2022-06-25 17:00:30.530044
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1.0)

    @work_in_progress("Loading file")
    def load_file():
        time.sleep(1.0)
        return "data"

    data = load_file()
    print(data)

# Generated at 2022-06-25 17:00:36.192624
# Unit test for function work_in_progress
def test_work_in_progress():

    # Wait for 3 seconds
    with work_in_progress("Waiting for 3 seconds"):
        time.sleep(3)

    # Decorator
    @work_in_progress("Waiting for 4 seconds")
    def wait():
        time.sleep(4)

    wait()

# Generated at 2022-06-25 17:00:40.343038
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test function work_in_progress in module timeutil."""
    # Test 1: context manager
    with work_in_progress("Test 1"):
        time.sleep(1)

    # Test 2: Decorator
    @work_in_progress("Test 2")
    def foo():
        time.sleep(1)

    # Test 3: Decorator
    @work_in_progress()
    def bar():
        time.sleep(1)

    foo()
    bar()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:00:49.539065
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test for work_in_progress")
    def test():
        time.sleep(2)

    test()

if __name__ == "__main__":
    test_work_in_progress()
else:
    import logging
    import sys
    logging.basicConfig(stream=sys.stderr, level=logging.DEBUG)
    logging.info(f"Loaded {__file__}")

# Generated at 2022-06-25 17:00:54.146588
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test work_in_progress")
    def test_function():
        time.sleep(0.01)

    @work_in_progress("Test work_in_progress with context")
    def test_function2():
        with work_in_progress("Test nested work_in_progress"):
            time.sleep(0.01)

    test_function()
    test_function2()


if __name__ == "__main__":
    with work_in_progress("Loading"):
        time.sleep(1)
    test_work_in_progress()

# Generated at 2022-06-25 17:01:01.941494
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")
    save_file("/path/to/some/other/file", obj)



# Generated at 2022-06-25 17:01:06.710737
# Unit test for function work_in_progress
def test_work_in_progress():
    # @work_in_progress
    @work_in_progress()
    def f():
        time.sleep(0.01)
    # with work_in_progress
    with work_in_progress("Work in progress"):
        time.sleep(0.01)
    f()
    time.sleep(0.01)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:01:15.534175
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress"""
    import os
    import random

    from .file_utils import mkdir_if_missing

    # create temporary directory for this test
    tmpdir = "tmp/test/work_in_progress"
    mkdir_if_missing(tmpdir)

    with work_in_progress("Create random noise file"):
        with open(os.path.join(tmpdir, "noise.npy"), "wb") as f:
            np.save(f, np.random.randint(0, 255, size=(100,)))

    # clean up temporary directory
    os.remove(os.path.join(tmpdir, "noise.npy"))
    os.removedirs(tmpdir)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:01:17.691049
# Unit test for function work_in_progress
def test_work_in_progress():
    t0 = time.time()
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1)
    assert time.time() - t0 > 1

# Generated at 2022-06-25 17:01:21.656742
# Unit test for function work_in_progress
def test_work_in_progress():
    x = 0
    t0 = time.time()
    with work_in_progress("Testing"):
        while time.time() - t0 < 0.2:
            x += 1
    assert x > 0

# Generated at 2022-06-25 17:01:24.132997
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test work_in_progress."""
    import doctest
    with work_in_progress("Testing work_in_progress"):
        doctest.testmod()

# Generated at 2022-06-25 17:01:32.275200
# Unit test for function work_in_progress
def test_work_in_progress():
    def run_test(task):
        if(task == "read"):
            with work_in_progress("read"):
                with open("customer_details.csv", "r") as file:
                    line = file.readline()
                    while line:
                        line = file.readline()
        elif(task == "write"):
            with work_in_progress("write"):
                with open("test.csv", "a") as file:
                    for i in range(10):
                        file.write("customer name, mobile no, age, gender, address\n")
        elif(task == "delete"):
            with work_in_progress("delete"):
                os.remove("test.csv")
        else:
            pass
    run_test("read")
    run_test("write")
    run_

# Generated at 2022-06-25 17:01:37.921504
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(1)
    work_in_progress()
    with work_in_progress():
        time.sleep(1)
    with work_in_progress():
        time.sleep(1)
        raise ValueError()
    try:
        with work_in_progress():
            time.sleep(1)
            raise ValueError()
    except ValueError:
        pass

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:50.574692
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test for WIP"):
        time.sleep(1)

# Generated at 2022-06-25 17:01:57.827569
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing function `work_in_progress`...")
    print("Please compare the printed output with the docstring.")
    with work_in_progress():
        time.sleep(0.1)
    @work_in_progress()
    def func():
        time.sleep(0.2)
    func()

# Test functions

# Generated at 2022-06-25 17:02:07.043028
# Unit test for function work_in_progress
def test_work_in_progress():
    import logging
    import sys
    import time

    logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
        time.sleep(1)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
        time.sleep(3)

    obj = load_file(__file__)
    save_file(__file__ + ".backup", obj)

# Generated at 2022-06-25 17:02:10.607174
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Working"):
        time.sleep(3)


# Generated at 2022-06-25 17:02:19.270548
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file():
        with open("/dev/null", "rb") as f:
            contents = f.read()
        return contents

    with work_in_progress("Saving file"):
        time.sleep(1)
    load_file()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:02:29.679984
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    import tempfile
    from torch.utils.data import Dataset

    obj = Dataset()
    _, path = tempfile.mkstemp()
    try:
        obj.save(path)

        obj = load_file(path)
    finally:
        os.remove(path)
    assert isinstance(obj, Dataset)
    print("Test passed!")

# Generated at 2022-06-25 17:02:34.835137
# Unit test for function work_in_progress
def test_work_in_progress():
    time_to_sleep = 0.2
    with work_in_progress(f"Sleeping for {time_to_sleep} secs"):
        time.sleep(time_to_sleep)
    print(f"Done!")

# Generated at 2022-06-25 17:02:49.934894
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import pickle

    path = os.path.join(os.path.dirname(__file__), 'bar.txt')
    with open(path, 'wb') as f:
        pickle.dump("bar", f)

    @work_in_progress("Loading foo")
    def load_foo(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    assert load_foo(path) == "bar"

    tmp_path = os.path.join(os.path.dirname(__file__), 'tmp.txt')
    with work_in_progress("saving foo") as f:
        with open(tmp_path, 'wb') as f:
            pickle.dump("foo", f)


# Generated at 2022-06-25 17:02:57.655760
# Unit test for function work_in_progress
def test_work_in_progress():
    path = "/tmp/test_work_in_progress.pkl"

    with open(path, "wb") as f:
        pickle.dump({}, f)

    @work_in_progress("Loading file")
    def load_file():
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file()

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump({}, f)

    os.remove(path)

# Generated at 2022-06-25 17:03:05.706973
# Unit test for function work_in_progress
def test_work_in_progress():
    import unittest
    import tempfile
    import pickle
    from random import randint
    from unittest.mock import patch

    class WorkInProgressTest(unittest.TestCase):
        def test_outer(self):
            with patch('sys.stdout', new=StringIO()) as fake_out:
                with work_in_progress():
                    pass
            self.assertSequenceEqual(fake_out.getvalue().split(),
                                     ("Work", "in", "progress...",
                                      "done.", "(3.52s)"))

        def test_inner(self):
            with patch('sys.stdout', new=StringIO()) as fake_out:
                with work_in_progress("Loading"):
                    pass

# Generated at 2022-06-25 17:03:36.588591
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""
    Examples:
    >>> @work_in_progress("Loading file")
    ... def load_file(path):
    ...     with open(path, "rb") as f:
    ...         return pickle.load(f)
    ...
    ... obj = load_file("/path/to/some/file")
    Loading file... done. (3.52s)

    >>> with work_in_progress("Saving file"):
    ...     with open(path, "wb") as f:
    ...         pickle.dump(obj, f)
    Saving file... done. (3.78s)
    """
    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:03:45.452544
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress."""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


# Generated at 2022-06-25 17:03:48.158032
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing function"):
        time.sleep(0.2)
test_work_in_progress()

# Generated at 2022-06-25 17:03:50.524776
# Unit test for function work_in_progress
def test_work_in_progress():
    # The doctest should suffice for this function.
    pass


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:03:57.679820
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("tests/temp/file.txt")

    with work_in_progress("Saving file"):
        with open("tests/temp/file.txt", "wb") as f:
            pickle.dump(obj, f)

    print(f"SUCCESS: {__file__}")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:04:05.956952
# Unit test for function work_in_progress
def test_work_in_progress():
    import random

    def _test_work_in_progress(desc: str = "Test"):
        time_s = random.random()
        time.sleep(time_s)
        print(f"{desc}: {time_s}s")

    with work_in_progress():
        _test_work_in_progress()

    with work_in_progress():
        _test_work_in_progress(desc="Hello world")


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:04:08.054489
# Unit test for function work_in_progress
def test_work_in_progress():
    _ = work_in_progress("test")

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:04:17.815183
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile
    import os

    def save(path):
        with work_in_progress("Saving file"):
            with open(path, "wb") as f:
                obj = list(range(10**4))
                pickle.dump(obj, f)

    def load(path):
        with work_in_progress("Loading file"):
            with open(path, "rb") as f:
                obj = pickle.load(f)
                return obj

    with tempfile.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, "test.pickle")
        save(path)
        obj = load(path)
    assert obj == list(range(10**4))

# Generated at 2022-06-25 17:04:25.152135
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file():
        with open("test.csv", "rb") as f:
            return pickle.load(f)

    obj = load_file()
    assert len(obj) > 0

    with work_in_progress("Saving file"):
        with open("test2.csv", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:04:36.898038
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import pickle
    from tempfile import TemporaryDirectory
    from random import random

    class Test:
        def __init__(self, test_val):
            self.test_val = test_val

        def __eq__(self, other):
            return self.__dict__ == other.__dict__

    def load_test(test_obj):
        with work_in_progress("Loading file"):
            with open(test_obj.test_val, "rb") as f:
                data = pickle.load(f)
        return data

    def save_test(test_obj, data):
        with work_in_progress("Saving file"):
            with open(test_obj.test_val, "wb") as f:
                pickle.dump(data, f)


# Generated at 2022-06-25 17:05:35.380897
# Unit test for function work_in_progress
def test_work_in_progress():
    def file_size(path):
        with open(path, "rb") as f:
            f.seek(0, os.SEEK_END)
            return f.tell()

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading very large file")
    def load_very_large_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    class DelayObject:
        def __reduce__(self):
            time.sleep(0.5)
            return DelayObject


# Generated at 2022-06-25 17:05:38.078933
# Unit test for function work_in_progress
def test_work_in_progress():
    print("\nUnit test for function work_in_progress")
    def test_func():
        time.sleep(1)
        print("test_func()")
        time.sleep(2)
    with work_in_progress("test_func()"):
        test_func()

# Generated at 2022-06-25 17:05:42.790801
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing function")
    def f():
        time.sleep(0.3)
    f()
    with work_in_progress("Testing context"):
        time.sleep(0.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:05:50.002561
# Unit test for function work_in_progress
def test_work_in_progress():
    # using as function decorator
    @work_in_progress("Loading all files")
    def load_all_files(path):
        _list = []
        for _ in range(5):
            _list.append(np.random.rand(10, 10))
        time.sleep(1)

    load_all_files("./")

    # using in with block
    with work_in_progress("Saving all files"):
        for i, mat in enumerate(load_all_files("./")):
            np.save(f"{i}.npy", mat)
            time.sleep(1)

# Generated at 2022-06-25 17:05:51.805513
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing function")
    def func():
        time.sleep(0.1)

    func()

# Generated at 2022-06-25 17:05:54.500408
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(0.2)
    with work_in_progress("This is a test for work_in_progress"):
        time.sleep(0.5)


# Generated at 2022-06-25 17:06:07.250873
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    >>> @work_in_progress("Loading file")
    ... def load_file(path):
    ...     with open(path, "rb") as f:
    ...         return pickle.load(f)
    ...
    ... obj = load_file("dummy_data/test_file.dummydata")
    Loading file... done. (0.00s)

    >>> with work_in_progress("Saving file"):
    ...     with open("dummy_data/test_file.dummydata.test_work_in_progress", "wb") as f:
    ...         pickle.dump(obj, f)
    Saving file... done. (0.00s)
    """


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:06:14.772516
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test for function work_in_progress."""
    @work_in_progress("Test")
    def load_file(path):
        with open(path, "r") as f:
            data = f.read()

    def dummy():
        with work_in_progress("Test"):
            pass

    path = "./test/test_file.txt"

    load_file(path)
    dummy()


# Generated at 2022-06-25 17:06:22.959176
# Unit test for function work_in_progress
def test_work_in_progress():
    strs = []
    def fake_print(s="", end="", flush=False):
        strs.append(s)

    with mock.patch("builtins.print", fake_print):
        with work_in_progress("loading file"):
            time.sleep(0.1)

    # difflib.SequenceMatcher(a=...) gives the longest common subsequence
    ratio = difflib.SequenceMatcher(a=strs[0], b="loading file").ratio()
    assert ratio == 1.0

# Generated at 2022-06-25 17:06:29.232236
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.5)
    # Output
    # Testing work_in_progress... done. (0.50s)



# Generated at 2022-06-25 17:08:36.567132
# Unit test for function work_in_progress
def test_work_in_progress():
    pass


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:08:43.821205
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    from tempfile import TemporaryDirectory

    desc = "Creating temporary file"
    tmp_dir = TemporaryDirectory(prefix="__test_work_in_progress_")
    path = os.path.join(tmp_dir.name, "tmp.txt")

    with work_in_progress(desc):
        with open(path, "wt") as f:
            [f.write("s" * 1024) for _ in range(int(1e4))]

    assert os.path.isfile(path)

    desc = "Removing temporary file"
    with work_in_progress(desc):
        os.rmdir(tmp_dir.name)

    assert not os.path.isdir(tmp_dir.name)

    tmp_dir.cleanup()


if __name__ == '__main__':
    test_

# Generated at 2022-06-25 17:08:55.157409
# Unit test for function work_in_progress
def test_work_in_progress():
    from .testing import check_output_in, check_output_notin, check_func_args

    # Disable this test, since it is too slow.
    return
    with check_func_args(["Loading file... done. (", "s)"]), check_output_notin("Loading file... "), work_in_progress("Loading file") as _:
        time.sleep(3.5)

    with check_func_args(["Loading file... done. (", "s)"]), check_output_in("Loading file... "), work_in_progress("Loading file"):
        time.sleep(3.5)