

# Generated at 2022-06-25 16:58:58.468017
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        # ...do something...
        time.sleep(10.0)
    with work_in_progress("Saving file"):
        # ...do something...
        time.sleep(10.0)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 16:59:01.978120
# Unit test for function work_in_progress
def test_work_in_progress():
    var_0 = work_in_progress("Loading file")
    var_1 = work_in_progress("Saving file")
    with work_in_progress("Loading file"):
        pass
    with work_in_progress("Saving file"):
        pass

# Generated at 2022-06-25 16:59:06.639866
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        pass


if __name__ == "__main__":
    # execute only if run as a script
    test_case_0()

# Generated at 2022-06-25 16:59:08.954281
# Unit test for function work_in_progress
def test_work_in_progress():
    obj = work_in_progress('Saving file')
    print("enclosed")
    obj.__exit__()
    print("done")


# Generated at 2022-06-25 16:59:16.575597
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing function work_in_progress...")
    print(" Case 0 (sanity):")
    try:
        test_case_0()
        print(" Case 1 (sanity):")
        try:
            test_case_1()
        except Exception as e:
            print("  Error! {0}".format(e))
            print("  ...Case 1 didn't pass\n")
        else:
            print("  Case 1 passed!\n")
    except Exception as e:
        print("  FAIL: {0}".format(e))


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 16:59:19.765487
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("test"):
        time.sleep(1e-2)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 16:59:28.093987
# Unit test for function work_in_progress
def test_work_in_progress():
    var_0 = work_in_progress()
    try:
        with var_0:
            time.sleep(1)
    except Exception as var_1:
        print(var_1)
        assert False
    else:
        assert True
        print("work_in_progress function passed all tests")
    try:
        with var_0:
            raise Exception("")
    except Exception as var_1:
        print(var_1)
        assert False
    else:
        assert True
        print("work_in_progress function passed all tests")


if __name__ == "__main__":
    test_case_0()
    print("Unit tests done")

# Generated at 2022-06-25 16:59:28.691030
# Unit test for function work_in_progress
def test_work_in_progress():
    assert True

# Generated at 2022-06-25 16:59:29.233760
# Unit test for function work_in_progress
def test_work_in_progress():
    assert True



# Generated at 2022-06-25 16:59:32.981505
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file") as w:
        print("loading...")
        time.sleep(0.2)
        print("completed loading.")


if __name__ == "__main__":
    test_case_0()
    test_work_in_progress()

# Generated at 2022-06-25 16:59:46.460401
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import tempfile
    import pickle

    class Person:
        def __init__(self, name, age):
            self.name = name
            self.age = age

    with tempfile.TemporaryDirectory() as d:
        p = Person("Bob", age=12)
        f = os.path.join(d, "person.dump")
        with work_in_progress(f"Saving {p.name} to {f}") as pkl:
            with open(f, "wb") as f:
                pickle.dump(p, f)
            time.sleep(2)
        with work_in_progress(f"Loading from {f}"):
            with open(f, "rb") as f:
                p_new = pickle.load(f)
                time.sleep(2)
       

# Generated at 2022-06-25 16:59:48.447860
# Unit test for function work_in_progress
def test_work_in_progress():

    import random

    @work_in_progress("Sleep")
    def sleep_random():
        time.sleep(random.random())

    sleep_random()

# Generated at 2022-06-25 16:59:57.377840
# Unit test for function work_in_progress
def test_work_in_progress():
    def _test_work_in_progress(desc, func, *args, **kwargs):
        with work_in_progress(desc) as w:
            func(*args, **kwargs)

        # time.sleep() is used to verify the actual time consumed.
        begin_time = time.time()
        time.sleep(0.1)

        time_delta = time.time() - begin_time
        assert time_delta != 0.0

    def _test():
        _test_work_in_progress("Task 1", time.sleep, 0.1)
        _test_work_in_progress("Task 2", time.sleep, 0.2)

# Generated at 2022-06-25 17:00:03.594446
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test for the function work_in_progress"""
    import io
    import sys
    sys.stdout = io.StringIO()
    @work_in_progress("Work in progress")
    def work():
        time.sleep(10)

    sys.stdout.seek(0)
    assert re.match(r"Work in progress\.\.\. done\. \(10\.\d+s\)", sys.stdout.read())

# Generated at 2022-06-25 17:00:15.320582
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile
    import pickle

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with tempfile.TemporaryDirectory() as tmp_dir:
        path = os.path.join(tmp_dir, "test.pkl")

        with open(path, "wb") as f:
            pickle.dump([1, 2, 3], f)

        @work_in_progress("Loading file")
        def load_file(path):
            with open(path, "rb") as f:
                return pickle.load(f)

        obj = load_file(path)
        assert obj == [1, 2, 3]


# Generated at 2022-06-25 17:00:19.141528
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(0.1)


if __name__ == '__main__':
    test_work_in_progress()
    with work_in_progress("A simple task"):
        time.sleep(0.1)

# Generated at 2022-06-25 17:00:22.370779
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1.23)
    with work_in_progress("Done"):
        time.sleep(0.0)

# Generated at 2022-06-25 17:00:27.452925
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function ``work_in_progress``."""
    with work_in_progress("Loading file"):
        time.sleep(2)

    @work_in_progress("Saving file")
    def save_file():
        time.sleep(0.5)

    save_file()

# Generated at 2022-06-25 17:00:30.895735
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Test")
    def test():
        time.sleep(1)

    test()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:37.137548
# Unit test for function work_in_progress
def test_work_in_progress():
    """Tests for function work_in_progress."""
    import time
    with work_in_progress("Sleeping for 3 seconds"):
        time.sleep(3.0)
    @work_in_progress("Sleeping for 3 seconds")
    def sleep():
        time.sleep(3.0)
    sleep()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:53.114156
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress()
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    tmp_file = '__test_work_in_progress.pkl'
    obj = 'test_work_in_progress_obj'
    save_file(tmp_file, obj)
    assert load_file(tmp_file) == obj
    os.remove(tmp_file)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:54.677645
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.5)

# Generated at 2022-06-25 17:01:01.301785
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    with open("__pycache__/dtype.dat", "wb") as f:
        pickle.dump(type, f)
    obj = load_file("__pycache__/dtype.dat")
    assert obj == type


# Generated at 2022-06-25 17:01:07.762023
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert obj == "test obj"

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-25 17:01:14.011095
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    print("All tests passed.")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:15.598935
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(1.23)
    with work_in_progress("Loading file"):
        time.sleep(3.51)

# Generated at 2022-06-25 17:01:16.039157
# Unit test for function work_in_progress
def test_work_in_progress():
    pass

# Generated at 2022-06-25 17:01:21.822873
# Unit test for function work_in_progress
def test_work_in_progress():
    # Imports
    import pickle

    # Functions
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # Execute
    obj = load_file("/tmp/test.pickle")

    # Verify
    assert obj == "This is a test"

# Generated at 2022-06-25 17:01:26.192863
# Unit test for function work_in_progress
def test_work_in_progress():
    # test code block
    with work_in_progress("Doing something"):
        time.sleep(0.1)

    # test function
    @work_in_progress("Doing something")
    def do_something():
        time.sleep(0.1)

    do_something()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:01:28.626408
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test function")
    def foo():
        time.sleep(2)

    foo()


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:01:46.142556
# Unit test for function work_in_progress
def test_work_in_progress():
    def foo():
        time.sleep(1)
        with work_in_progress("Inside foo"):
            time.sleep(2)
    foo()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:49.294022
# Unit test for function work_in_progress
def test_work_in_progress():
    def foo():
        time.sleep(3)

    with work_in_progress("Testing progress bar") as progress:
        foo()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:59.971412
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert type(obj) is dict

    path = "/path/to/some/file"
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    with open(path, "rb") as f:
        obj2 = pickle.load(f)
    assert obj2 == obj


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:02:06.459055
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:02:13.289798
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile
    import pickle

    data = [[None] * 1024] * 1024
    tmp_file = tempfile.mkstemp(prefix="work_in_progress_test_")[1]
    print("Testing work_in_progress...", end='')

    # Test function with pickle
    with work_in_progress("Test function"):
        with open(tmp_file, "wb") as f:
            pickle.dump(data, f)
    with open(tmp_file, "rb") as f:
        data = pickle.load(f)

    # Test context manager with pickle
    @work_in_progress("Test context manager")
    def test_cm():
        with open(tmp_file, "wb") as f:
            pickle.dump(data, f)
    test

# Generated at 2022-06-25 17:02:26.473466
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test function work_in_progress.

    .. code:: python

        >>> test_work_in_progress()
        Loading file... done. (0.00s)
        Saving file... done. (0.00s)
    """

# Generated at 2022-06-25 17:02:32.645037
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, data):
        with open(path, "wb") as f:
            pickle.dump(data, f)

    path = "work_in_progress.test.dat"
    data = [(i, i+1) for i in range(100000)]
    save_file(path, data)

    load_file(path)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:02:39.060754
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.1)
    assert True

if __name__ == "__main__":
    # Run unit test for function work_in_progress
    test_work_in_progress()

# Generated at 2022-06-25 17:02:48.874618
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # obj = load_file("/path/to/some/file")
    obj = load_file("/Users/jianzhang/Downloads/test.dat")

    with work_in_progress("Saving file"):
        with open("/Users/jianzhang/Downloads/test.dat2", "wb") as f:
            pickle.dump(obj, f)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:02:50.476452
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test") as w:
        time.sleep(1)
    assert w.__name__ == "w"

# Generated at 2022-06-25 17:03:23.350144
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert True

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:03:32.973844
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    >>> @work_in_progress("Loading file")
    ... def load_file(path):
    ...     with open(path, "rb") as f:
    ...         return pickle.load(f)
    ...
    ... obj = load_file("/path/to/some/file")
    Loading file... done. (3.52s)

    >>> with work_in_progress("Saving file"):
    ...     with open(path, "wb") as f:
    ...         pickle.dump(obj, f)
    Saving file... done. (3.78s)
    """

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:03:43.858893
# Unit test for function work_in_progress
def test_work_in_progress():
    def fake_load(path: str) -> int:
        time.sleep(1)
        return 1

    with work_in_progress("Loading file") as outer_ctx:
        with work_in_progress("Loading file #1"):
            time.sleep(0.5)
        with work_in_progress("Loading file #2"):
            with work_in_progress("Loading file #3"):
                time.sleep(1.5)
        with work_in_progress("Loading file #4") as inner_ctx:
            with work_in_progress("Loading file #5"):
                time.sleep(2.5)
            inner_ctx.__enter__()
            with work_in_progress("Loading file #6"):
                time.sleep(3.5)

# Generated at 2022-06-25 17:03:51.888179
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")
    # Loading file... done. (3.52s)
    
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    # Saving file... doe. (3.78s)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:03:56.775468
# Unit test for function work_in_progress
def test_work_in_progress():
    # function decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # context manager
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:04:05.117839
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:04:11.193076
# Unit test for function work_in_progress
def test_work_in_progress():
    """Simple unit test for function work_in_progress."""
    data = []
    with work_in_progress("Loading file"):
        for i in range(10):
            for j in range(10000000):
                data.append((i, j))
    assert len(data) == 10 * 10000000

# Execution of code begins here
if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:04:15.553088
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Running test"):
        for i in range(1000000):
            i*2

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:04:27.018950
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file_with_progress(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


# Generated at 2022-06-25 17:04:36.039307
# Unit test for function work_in_progress
def test_work_in_progress():
    content = """
This is
a multi-line
string
"""
    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "w+") as f:
            f.write(content)
            f.flush()
            return f

    f = save_file("./test")
    assert f.read() == content
    f.close()

if __name__ == '__main__':
    try:
        test_work_in_progress()
    except AssertionError as e:
        print(e)

# Generated at 2022-06-25 17:05:37.353178
# Unit test for function work_in_progress
def test_work_in_progress():
    
    # Test with 'with' statement
    with work_in_progress():
        time.sleep(1)

    # Test with decorator
    @work_in_progress()
    def sleep():
        time.sleep(1)
    
    sleep()

# Generated at 2022-06-25 17:05:48.394019
# Unit test for function work_in_progress
def test_work_in_progress():
    try:
        import pickle
    except ImportError:
        print(
            "Install dependencies to run unit test of "
            f"{__file__}:\n"
            '    pip install pickle\n'
            '    pip install pickle5\n'
        )
        return

    def _pickle_test():
        X = np.random.randn(100, 100)
        with work_in_progress("Saving file"):
            with open("test.pickle", "wb") as f:
                pickle.dump(X, f)
        with work_in_progress("Loading file"):
            with open("test.pickle", "rb") as f:
                Y = pickle.load(f)
        return (X == Y).all()


# Generated at 2022-06-25 17:05:56.079796
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:06:05.141394
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for work_in_progress.

    .. code:: python

        >>> from pyquickhelper.pycode import work_in_progress
        >>> from time import sleep
        >>> with work_in_progress("Work in progress"):
        ...     sleep(0.6)
        Work in progress... done. (0.60s)
    """
    pass

# Generated at 2022-06-25 17:06:09.655378
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Loading file"):
        obj = load_file("/path/to/some/file")

    time.sleep(1)
    with work_in_progress("Saving file"):
        with open("/path/to/output/file", "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:06:22.044951
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    Unit test for work_in_progress.

    To run unittest:

        >>> pytest test_work_in_progress.py

    :return:
    """
    time_consumed = 5
    desc = "Test work_in_progress"

    @work_in_progress(desc)
    def fun():
        time.sleep(time_consumed)

    fun()
    assert (f"{desc}... done. ({time_consumed:.2f}s)"
            == capsys.readouterr().out.split("\n")[1])

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:06:25.430574
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:06:33.772551
# Unit test for function work_in_progress
def test_work_in_progress():
    def _test_work_in_progress_function(desc):
        #@work_in_progress(desc)
        def function_to_decorate():
            return

        function_to_decorate()

    for i in range(10):
        _test_work_in_progress_function(f"test_{i}")

    with work_in_progress("test_with"):
        time.sleep(0.1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:06:35.297576
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(1)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:06:42.814295
# Unit test for function work_in_progress
def test_work_in_progress():
    import random, string # nosec
    def random_str(str_len):
        return "".join([random.choice(string.ascii_letters + string.digits) for i in range(str_len)])

    # Generate data
    target_str = random_str(10000)

    def string_op1(str):
        for i, c in enumerate(str):
            if i % 2 == 0:
                str = str[:i] + str[i+1:]
        return str
    
    def string_op2(str):
        return str.replace('a', 'A')
    
    def string_op3(str):
        return str.upper()

    def string_op4(str):
        return str.lower()


# Generated at 2022-06-25 17:08:54.047707
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing")
    def do_test():
        time.sleep(1)

    with work_in_progress("Testing"):
        time.sleep(1)

    do_test()


# Main
if __name__ == "__main__":
    test_work_in_progress()