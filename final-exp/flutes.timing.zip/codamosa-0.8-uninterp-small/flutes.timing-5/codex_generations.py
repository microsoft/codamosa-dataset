

# Generated at 2022-06-25 16:59:00.842212
# Unit test for function work_in_progress
def test_work_in_progress():
    # assert work_in_progress(desc="Loading file") == "Loading file... done. (3.52s)"
    # assert work_in_progress("Loading file") == "Loading file... done. (3.52s)"
    with work_in_progress("Loading file") as work_in_progress:
        print("Loading file... done. (3.52s)")
    assert work_in_progress == "Loading file... done. (3.52s)"
    # assert work_in_progress("Loading file", 1) == "Loading file... done. (1s)"
    # assert work_in_progress("Loading file", 1, False) == "Loading file... done. (1s)"
    # assert work_in_progress("Loading file", 1, False, True) == "Loading file... done. (1s)"
    # assert work_

# Generated at 2022-06-25 16:59:08.688340
# Unit test for function work_in_progress
def test_work_in_progress():
    time_0 = time.time()

    with work_in_progress('loading...'):
        time.sleep(0.01)

    assert abs(time.time() - time_0 - 0.01) < 0.01


if __name__ == "__main__":
    test_case_0()
    test_work_in_progress()

# Generated at 2022-06-25 16:59:12.675619
# Unit test for function work_in_progress
def test_work_in_progress():
    # Work in progress...
    try:
        test_case_0()
    except Exception:
        import sys
        raise sys.exc_info()[1]


if __name__ == '__main__':
    # Unit test for function work_in_progress
    test_work_in_progress()

# Generated at 2022-06-25 16:59:17.690510
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test case for function work_in_progress.
    """
    contextlib.redirect_stdout(None)
    with open(os.devnull, "w") as f, contextlib.redirect_stdout(f):
        test_case_0()

if __name__ == '__main__':
    import doctest
    doctest.testmod()
    # test_work_in_progress()

# Generated at 2022-06-25 16:59:20.770837
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(2)

# Check if this file is the main program
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 16:59:27.141372
# Unit test for function work_in_progress
def test_work_in_progress():
    # Create the testing data
    time.sleep(0.1)
    with work_in_progress():
        time.sleep(1)
        assert int(time.time()) == 1580982324 or int(time.time()) == 1580982325


# Test the functions
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 16:59:28.459943
# Unit test for function work_in_progress
def test_work_in_progress():
    import doctest
    doctest.testmod()



# Generated at 2022-06-25 16:59:30.651338
# Unit test for function work_in_progress
def test_work_in_progress():
    x = 0
    try:
        work_in_progress()
    except:
        x += 1
    assert x == 0, "work_in_progress failed"



# Generated at 2022-06-25 16:59:40.479299
# Unit test for function work_in_progress
def test_work_in_progress():

    # Cleaning up workspace


    # Testing the function
    work_in_progress(desc="testing")

    # Checking the tpe of the output
    assert isinstance(var_0, type(None)), f"expecting type(None), got {type(var_0).__name__}"

    # Checking the output
    assert var_0 == None, f"expecting None, got {var_0}"

    # Printing the output
    # print(var_0)


# Closing the file
test_case_0()

# Printing unsuccessful test cases
print("==================\nUnsuccessful:\n==================", end='\n')

# Closing the file
test_0()

##============= End of file ==========================================================

# Generated at 2022-06-25 16:59:41.963449
# Unit test for function work_in_progress
def test_work_in_progress():
    assert var_0 == "Test of function work_in_progress"

# Generated at 2022-06-25 16:59:47.430732
# Unit test for function work_in_progress
def test_work_in_progress():
    def read():
        time.sleep(3)
        return 0

    with work_in_progress("begin"):
        r = read()
    return r

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 16:59:55.449609
# Unit test for function work_in_progress
def test_work_in_progress():
    from io import BytesIO
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("../docs/index.pickle")

    with work_in_progress("Saving file"):
        with open("index.pickle", "wb") as f:
            pickle.dump(obj, f)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:00:00.528004
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("../tools/test.pkl")

    with work_in_progress("Saving file"):
        with open("../tools/test.pkl", "wb") as f:
            pickle.dump(obj, f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:00:10.631144
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    Unit test for work_in_progress()
    """
    import subprocess

    file_path = "/tmp/test_work_in_progress.pkl"

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            time.sleep(0.1)
            pickle.dump(None, f)

    save_file(file_path)
    print(f"Saved file {file_path}.")

    @work_in_progress("Removing file")
    def remove_file(path):
        subprocess.call(["rm", "-f", path])

    remove_file(file_path)
    print(f"Removed file {file_path}.")

if __name__ == "__main__":
    test_

# Generated at 2022-06-25 17:00:14.749149
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(2)
        return None

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        time.sleep(3)
    return True

# Generated at 2022-06-25 17:00:25.243879
# Unit test for function work_in_progress
def test_work_in_progress():
    import subprocess

    # Function with decorator
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file_decorated(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # Save and load the file
    obj = {"test": [1, 2, 3]}
    tmp_file = "/tmp/test_work_in_progress.pkl"
    with open(tmp_file, "wb") as f:
        pickle.dump(obj, f)

    # Test the function
    assert load_file(tmp_file) == obj

    # Test the function with decorator

# Generated at 2022-06-25 17:00:34.541312
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test function wokr_in_progress."""
    @work_in_progress("Loading file")
    def load_file(path: str):
        time.sleep(0.5)
        with open(path, 'rb') as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open("test.pkl", 'wb') as f:
            pickle.dump({1, 2}, f)
        time.sleep(1)

    obj = load_file("test.pkl")
    assert obj == {1, 2}


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:40.011301
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file(__file__)
    assert obj is not None

    with work_in_progress("Saving file"):
        with open(__file__, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:00:45.090161
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Function test")
    def test_func():
        time.sleep(0.5)

    with work_in_progress("Context test"):
        time.sleep(0.5)

    test_func()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:00:46.443528
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Executing computation"):
        time.sleep(1)

# Generated at 2022-06-25 17:01:01.408362
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import pickle

    from bob.stream.functional import as_tuple

    @work_in_progress("Loading file")
    def load_file(path: str):
        with open(path, "rb") as f:
            return pickle.load(f)

    sample = as_tuple(range(100))
    with tempfile.TemporaryDirectory() as dirpath:
        path = os.path.join(dirpath, "sample.pkl")
        with work_in_progress("Saving file"):
            with open(path, "wb") as f:
                pickle.dump(sample, f)

        data = load_file(path)
        assert sample == data

# Generated at 2022-06-25 17:01:06.712807
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path: str, desc: str = "Loading file"):
        with work_in_progress(desc):
            with open(path, "rb") as f:
                return pickle.load(f)

    obj = load_file("/path/to/some/file")


if __name__ == "__main__":
    import doctest
    doctest.testmod()
    # test_work_in_progress()

# Generated at 2022-06-25 17:01:15.534169
# Unit test for function work_in_progress
def test_work_in_progress():

    def slow_load_file(path: str):
        time.sleep(0.1)
        return pickle.load(open(path, "rb"))

    def slow_save_file(path: str, obj):
        time.sleep(0.1)
        pickle.dump(obj, open(path, "wb"))

    def w_load(path):
        with work_in_progress("Loading file"):
            return slow_load_file(path)

    def w_save(path, obj):
        with work_in_progress("Saving file"):
            slow_save_file(path, obj)

    assert os.path.exists(os.path.join(EXAMPLES_DIR, "test.pkl"))

# Generated at 2022-06-25 17:01:16.965599
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("This is a task"):
        time.sleep(2.34)

# Generated at 2022-06-25 17:01:27.204581
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile
    path1 = os.path.join(tempfile.gettempdir(), "test1.txt")
    path2 = os.path.join(tempfile.gettempdir(), "test2.txt")

    # Write to a file, then read the file using `work_in_progress`
    def func1():
        with open(path1, "w") as w:
            w.write("foobar")
        with work_in_progress("Loading file"):
            with open(path1, "r") as r:
                r.read()

    # Use `work_in_progress` to write to a file, then read the file

# Generated at 2022-06-25 17:01:29.273767
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function work_in_progress"""
    with work_in_progress("Initializing"):
        time.sleep(0.225)

# Generated at 2022-06-25 17:01:31.321870
# Unit test for function work_in_progress
def test_work_in_progress():
    print()
    with work_in_progress("Testing foo"):
        time.sleep(2)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:37.309047
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:47.264523
# Unit test for function work_in_progress
def test_work_in_progress():
    import random

    with work_in_progress("Loading all files"):
        # Do some work
        time.sleep(1)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    files = []
    for i in range(4):
        files.append(load_file(str(i)))

    with work_in_progress("Saving file"):
        # Do some work
        time.sleep(1)

    def pick_random_file():
        return random.choice(files)

    with work_in_progress("Picking random file"):
        pick_random_file()

# Generated at 2022-06-25 17:01:53.681378
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(2)
    with work_in_progress("Testing work_in_progress"):
        time.sleep(2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:02:09.859259
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test work_in_progress"):
        for x in range(100):
            print(x, end='', flush=True)
            time.sleep(0.01)
        print()


if __name__ == '__main__':
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS | doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-25 17:02:23.253337
# Unit test for function work_in_progress
def test_work_in_progress():
    import pkg_resources
    import os

    # Unit test for context manager
    with work_in_progress("Doing tons of stuff..."):
        time.sleep(0.5)
    # Unit test for decorator
    @work_in_progress("Loading some file")
    def load_file(path: str) -> float:
        with open(path, "rb") as f:
            data = pickle.load(f)
        return data['pi']
    pi = load_file(os.path.abspath(pkg_resources.resource_filename(__name__, "PI.pckl")))
    assert isclose(pi, math.pi, rel_tol=1e-8)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:02:29.680390
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:02:40.235854
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            return pickle.dump(obj, f)

    data = {
        "name": "Darmawan Salihun",
        "email": "darmawan.salihun@gmail.com",
        "website": "https://darmawansalihun.github.io",
    }

    save_file("test_file.pkl", data)
    data2 = load_file("test_file.pkl")

    assert(data == data2)

# Generated at 2022-06-25 17:02:51.108929
# Unit test for function work_in_progress
def test_work_in_progress():
    from tempfile import TemporaryDirectory
    from pathlib import Path
    from datetime import datetime

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with TemporaryDirectory() as tmpdirname:
        with work_in_progress("Loading file"):
            obj = load_file("./tests/data/test_dict.pickle")
        assert isinstance(obj, dict)
        assert obj["datetime"].isoformat() == "2019-01-01T00:02:00+00:00"


# Generated at 2022-06-25 17:02:59.733955
# Unit test for function work_in_progress
def test_work_in_progress():
    # Helper function used in test_work_in_progress()
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    buf = io.BytesIO()
    with open("requirements.txt", "rb") as f:
        pickle.dump(f.read(), buf)
    file_content = load_file(buf)
    assert file_content.startswith(b"attrs")
    assert file_content.endswith(b"xlrd")

# Generated at 2022-06-25 17:03:05.797428
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test: print the time consumed by a function
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("../tests/data/test_work_in_progress.pkl")
    assert isinstance(obj, dict)
    assert obj.get("a") == 1

    # Test: print the time consumed by a code block
    @work_in_progress("Saving file")
    def save_file():
        path = "../tests/data/test_work_in_progress.pkl"
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    save_file()

# Generated at 2022-06-25 17:03:15.113571
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
        return False

    obj = load_file("/path/to/some/file")
    assert obj == True

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:03:21.012797
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:03:27.887434
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "./test/data/test.pkl"
    obj = load_file(path)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:03:52.101354
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing"):
        time.sleep(1)



# Generated at 2022-06-25 17:03:56.235716
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test1"):
        time.sleep(1)
        print("This should be after the timer.")

    def test2():
        with work_in_progress("Test2"):
            time.sleep(1)
            print("This should be after the timer.")

    test2()

# Generated at 2022-06-25 17:04:07.133358
# Unit test for function work_in_progress
def test_work_in_progress():
    base_name = "test_work_in_progress"
    file_path = Path.cwd() / f"{base_name}.pkl"

    try:
        os.remove(file_path)
    except FileNotFoundError:
        pass

    # Block works
    def save(text: str, path: Path) -> None:
        with open(path, "wt") as f:
            f.write(text)

    with work_in_progress(f"Saving file to {file_path}"):
        save("Hello world!", file_path)

    # Function works
    @work_in_progress(f"Loading file from {file_path}")
    def load() -> str:
        with open(file_path, "rt") as f:
            return f.read()

    result = load()


# Generated at 2022-06-25 17:04:17.749907
# Unit test for function work_in_progress
def test_work_in_progress():

    with work_in_progress("Loading file") as progress:
        time.sleep(1)
        progress.__next__()
        time.sleep(1)
        progress.__next__()
        time.sleep(1)
        progress.__next__()

    @work_in_progress("Loading file")
    def sleep():
        time.sleep(1)
        yield
        time.sleep(1)
        yield
        time.sleep(1)
        yield

    sleep()

    with work_in_progress("Loading file"):
        time.sleep(1)
        with work_in_progress("Loading file"):
            time.sleep(1)
        time.sleep(1)


# Generated at 2022-06-25 17:04:21.761312
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(random.random())

# Generated at 2022-06-25 17:04:24.580513
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1.5)


# ############################## END OF FILE ################################# #

# Generated at 2022-06-25 17:04:30.274364
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("This is a test"):
        time.sleep(0.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:04:33.193896
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function work_in_progress."""
    import random

    @work_in_progress("Test")
    def test():
        time.sleep(random.random())

    test()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:04:36.012745
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    with work_in_progress("Saving file"):
        time.sleep(2)


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-25 17:04:45.715771
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test for ``work_in_progress`` function."""
    @work_in_progress("Work in progress")
    def delay():
        time.sleep(10)

    with work_in_progress("Work in progress"):
        time.sleep(10)

    delay()


# Generated at 2022-06-25 17:05:41.355287
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:05:44.231503
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1.4)
    print("Testing done.")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:05:54.800609
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit testing for function *work_in_progress*."""
    from .show import show

    class Test(object):

        def __init__(self):
            pass

        @work_in_progress("Initializing the class")
        def init(self):
            time.sleep(1)

        @work_in_progress("Do stuff")
        def do_stuff(self):
            time.sleep(1.5)

        def test_method(self):
            self.init()
            self.do_stuff()

        def test_function(self):
            with work_in_progress("Initialization"):
                time.sleep(2)
            with work_in_progress("Doing stuff"):
                time.sleep(2.2)

    t = Test()
    t.test_method()
    t.test_function

# Generated at 2022-06-25 17:06:05.309059
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    loaded = load("test_work_in_progress.pickle")
    assert(all(loaded["a"] == range(1000)))

    with work_in_progress("Saving file"):
        with open("test_work_in_progress.pickle", "wb") as f:
            pickle.dump({"a": range(1000)}, f)


# if __name__ == "__main__":
#     test_work_in_progress()

# Generated at 2022-06-25 17:06:08.157932
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("test")
    def work_in_progress_test(x):
        time.sleep(x)
    work_in_progress_test(0.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:06:11.065879
# Unit test for function work_in_progress
def test_work_in_progress():
    def slow_function():
        with work_in_progress("Slow function"):
            time.sleep(0.1)

    slow_function()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:06:15.796962
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(1)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:06:17.055589
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(1)

# Generated at 2022-06-25 17:06:24.354839
# Unit test for function work_in_progress
def test_work_in_progress():
    path = tempfile.mkstemp()[1]
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump({"1": 1, "2": 2}, f)

    with work_in_progress("Loading file") as w:
        with open(path, "rb") as f:
            obj = pickle.load(f)
    assert obj == {"1": 1, "2": 2}

# Generated at 2022-06-25 17:06:33.202128
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:08:45.494163
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress."""
    with work_in_progress("Loading file"):
        time.sleep(1)
    with work_in_progress("Saving file"):
        time.sleep(1)

# Generated at 2022-06-25 17:08:53.785484
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1)
        return load_file.__name__

    assert load_file("") == "load_file"
    print("Work in progress: Passed")


if __name__ == '__main__':
    test_work_in_progress()