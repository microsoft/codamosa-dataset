

# Generated at 2022-06-25 16:58:55.194657
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        pass


if __name__ == "__main__":
    try:
        import pytest
        pytest.main(["-q", __file__])
    except (ImportError, AttributeError):
        pass

# Generated at 2022-06-25 16:59:04.507565
# Unit test for function work_in_progress
def test_work_in_progress():
    # Init test
    f1 = work_in_progress()
    with work_in_progress():
       f2 = work_in_progress()
    # Create file to load from
    file = open("test_file", "w")
    file.write("This is a test")
    file.close()
    # Load test file
    with work_in_progress("Loading file"):
        with open("test_file", "rb") as f:
            var_2 = pickle.load(f)
    # Save test file
    with work_in_progress("Saving file"):
        with open(file, "wb") as f:
            pickle.dump(f, var_2)
    # Test if file has been saved

# Generated at 2022-06-25 16:59:05.268966
# Unit test for function work_in_progress
def test_work_in_progress():
    assert test_case_0() == 'None'

# Generated at 2022-06-25 16:59:10.333492
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("sudoku") as result:
        assert True
    with work_in_progress("sudoku", "sudoku") as result:
        assert True
    with work_in_progress("sudoku", "sudoku", "sudoku") as result:
        assert True

test_case_0()
test_work_in_progress()

# Generated at 2022-06-25 16:59:13.947917
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Work in progress"):
        _var_0 = None
        for _var_1 in range(10):
            time.sleep(0.1)
    print("Expected output: Work in progress... done. (1.00s)")

# Generated at 2022-06-25 16:59:17.691717
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress() as var_0:
        var_0 = 1

    with work_in_progress() as var_0:
        var_1 = 1
        var_2 = 1.25
        var_0 = 1
        var_1 = 1
        var_1 = 1
        var_0 = 1
        var_3 = 2.25
        var_1 = 1
        var_1 = 1
        var_2 = 1.25
        var_1 = 1
        var_2 = 1.25
        var_3 = 2.25
        var_1 = 1
        var_1 = 1
        var_0 = 1
        var_1 = 1
        var_2 = 1.25
        var_1 = 1
        var_0 = 1
        var_1 = 1

# Generated at 2022-06-25 16:59:27.258554
# Unit test for function work_in_progress
def test_work_in_progress():
    # Testing the following function:
    var_0 = work_in_progress()
    assert var_0


if __name__ == '__main__':
    # test_work_in_progress()

    # Launch the unit tests for this module
    # unittest.main(exclusions=['test_case_0', 'test_case_1'])

    # Run all unit tests for this module (excludes exclusions)
    with open('test-reports/test-report-work_in_progress.xml', 'wb') as output:
        unittest.main(
            testRunner=xmlrunner.XMLTestRunner(output=output),
            exit=False
        )

    # Run all unit tests for this file
    # unittest.main(argv=[__file__])

# Generated at 2022-06-25 16:59:27.843688
# Unit test for function work_in_progress
def test_work_in_progress():
    pass

# Generated at 2022-06-25 16:59:29.467000
# Unit test for function work_in_progress
def test_work_in_progress():
    print('Passed.')


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 16:59:29.965882
# Unit test for function work_in_progress
def test_work_in_progress():
    pass

# Generated at 2022-06-25 16:59:36.977354
# Unit test for function work_in_progress
def test_work_in_progress():
    dummy = 2 ** 16
    with work_in_progress(desc="Wait for a few seconds"):
        counter = 0
        for i in range(10000):
            counter += 1
        print(f"Counter: {counter}")

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 16:59:41.523679
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Work in progress"):
        time.sleep(1.23)
    assert(True)


if __name__ == '__main__':
    import sys
    import pytest

    pytest.main([__file__] + sys.argv[1:])

# Generated at 2022-06-25 16:59:48.331949
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("data/logging.pickle")
    save_file("data/logging2.pickle", obj)


if __name__ == '__main__':
    # run the unit test
    test_work_in_progress()

# Generated at 2022-06-25 16:59:52.416828
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    with work_in_progress("Saving file"):
        time.sleep(2)
        with work_in_progress("Saving file"):
            time.sleep(1)
    time.sleep(4)



# Generated at 2022-06-25 16:59:55.796980
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def test():
        time.sleep(1.23)
    test()

# Generated at 2022-06-25 17:00:00.608695
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Computing 5!..."):
        time.sleep(1)

    @work_in_progress("Computing 10!...")
    def compute_ten_factorial():
        time.sleep(2)
    compute_ten_factorial()

if __name__ == "__main__":
    # Run test if this file is invoked as main script
    # This allows a programmer to quickly test functions during development
    test_work_in_progress()

# Generated at 2022-06-25 17:00:02.793815
# Unit test for function work_in_progress

# Generated at 2022-06-25 17:00:08.064696
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sleeping"):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:09.479036
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("HELLO WORLD!"):
        time.sleep(3)

# Generated at 2022-06-25 17:00:12.612084
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3.52)
    with work_in_progress("Saving file"):
        time.sleep(3.78)

# Generated at 2022-06-25 17:00:23.517356
# Unit test for function work_in_progress
def test_work_in_progress():
    def dummy():
        pass

    assert work_in_progress.__doc__ is not None

    with contextlib.redirect_stdout(StringIO()):
        with work_in_progress("dummy"):
            dummy()


if __name__ == "__main__":
    import pytest
    pytest.main(__file__)

# Generated at 2022-06-25 17:00:30.895671
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:00:39.336316
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import pickle
    import tempfile

    prefix = 'work_in_progress_'
    obj = os.urandom(1 << 18)
    with tempfile.TemporaryDirectory(prefix=prefix) as tempdir:
        path = os.path.join(tempdir, 'file')
        with work_in_progress("Saving file"):
            with open(path, "wb") as f:
                pickle.dump(obj, f)
        with work_in_progress("Loading file"):
            with open(path, "rb") as f:
                assert pickle.load(f) == obj
    assert os.path.exists(tempdir) == False, 'Leaked temporary directory'

# Generated at 2022-06-25 17:00:47.159168
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import pickle
    import shutil

    # Pickle some sample data
    tpath = tempfile.mkdtemp()
    try:
        with open(tpath + "/sample.pkl", "wb") as f:
            pickle.dump({"data": [1, 2, 3, 4, 5]}, f)

        with work_in_progress("Loading file"):
            with open(tpath + "/sample.pkl", "rb") as f:
                return pickle.load(f)
    finally:
        shutil.rmtree(tpath)

# Generated at 2022-06-25 17:00:56.914568
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            time.sleep(0.01)
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            time.sleep(0.01)
            pickle.dump(obj, f)

    with tempfile.TemporaryDirectory() as tmp_dir:
        path = os.path.join(tmp_dir, "obj")
        orig_obj = [1, 2, 3]
        save_file(path, orig_obj)
        loaded_obj = load_file(path)

    assert orig_obj == loaded_obj



# Generated at 2022-06-25 17:01:05.564607
# Unit test for function work_in_progress
def test_work_in_progress():
    # @work_in_progress() as a decorator:
    @work_in_progress("Loading file")
    def load_file():
        with open("test.dat", "rb") as f:
            return pickle.load(f)

    # @work_in_progress() as a context manager:
    with work_in_progress("Saving file"):
        with open("test.dat", "wb") as f:
            pickle.dump(np.random.rand(100, 100), f)

    print(load_file())


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:12.081197
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    obj = [1, 2, 3, 4, 5]

    with work_in_progress("Loading file"):
        with open("/tmp/testfile.dat", "wb") as f:
            pickle.dump(obj, f)

    with work_in_progress("Loading file"):
        with open("/tmp/testfile.dat", "rb") as f:
            assert(pickle.load(f) == obj)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:01:14.759199
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Work in progress"):
        time.sleep(0.5)

# Run unit test if invoked in the command line
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:19.737782
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile
    import pickle

    path = os.path.join(tempfile.gettempdir(), "test.obj")
    os.environ["ENV_FILE"] = path

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = {"hello": "world"}
    with open(path, "wb") as f:
        pickle.dump(obj, f)
    print(load_file(path))

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    print(load_file(path))

# Generated at 2022-06-25 17:01:26.783030
# Unit test for function work_in_progress
def test_work_in_progress():
    import os, pickle, tempfile
    import numpy as np
    with tempfile.TemporaryDirectory() as temp_dir:
        with work_in_progress("Loading file"):
            path = os.path.join(temp_dir, "data")
            with open(path, "wb") as f:
                pickle.dump(np.ones([100,100]), f)
        os.remove(path)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:01:46.236241
# Unit test for function work_in_progress
def test_work_in_progress():
    import random

    with work_in_progress("Loading file"):
        X = [random.random() for _ in range(3000)]

    @work_in_progress("Saving file")
    def save_file(X):
        with open("test_work_in_progress_output", "w") as f:
            f.write(''.join(X))

    save_file(X)
    print()


# If this file is executed, run its unit tests
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:53.389497
# Unit test for function work_in_progress
def test_work_in_progress():
    def slow_code():
        time.sleep(3)

    with work_in_progress("Testing work_in_progress"):
        slow_code()

    @work_in_progress("Testing work_in_progress")
    def f():
        slow_code()

    f()


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:02:00.496153
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file(__file__)

    with work_in_progress("Saving file"):
        with open(__file__, "wb") as f:
            pickle.dump(obj, f)



# Generated at 2022-06-25 17:02:07.874531
# Unit test for function work_in_progress
def test_work_in_progress():
    from io import BytesIO

    with work_in_progress("Testing work in progress"):
        # Pickle the 3 bytes in 4 seconds.
        for _ in range(4):
            output = BytesIO()
            pickle.dump(bytes(3), output, protocol=0)

    with work_in_progress("Testing work in progress"):
        # Unpickle the 3 bytes in 1 second.
        for _ in range(1):
            buf = bytes(3)
            input = BytesIO(buf)
            bytes(pickle.load(input))

# Generated at 2022-06-25 17:02:13.619256
# Unit test for function work_in_progress

# Generated at 2022-06-25 17:02:16.106332
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("system is testing"):
        time.sleep(3)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:02:27.247188
# Unit test for function work_in_progress
def test_work_in_progress():
    import sys
    import io
    import time

    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(0.1)
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, data):
        time.sleep(0.1)
        with open(path, "wb") as f:
            pickle.dump(data, f)

    # Test the function in a context manager
    with io.StringIO() as f, contextlib.redirect_stdout(f):
        with work_in_progress("Compiling some code"):
            time.sleep(0.1)
        assert "Compiling some code... done. (0.10s)" in f

# Generated at 2022-06-25 17:02:31.262966
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Task 1"):
        time.sleep(.5)
    with work_in_progress("Task 2"):
        time.sleep(1.5)
    with work_in_progress("Task 3"):
        time.sleep(3.3)
    with work_in_progress("Task 4"):
        time.sleep(10.3)
    with work_in_progress("Task 5"):
        time.sleep(.2)

#test_work_in_progress()

# Generated at 2022-06-25 17:02:40.861520
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import contextlib
    import io
    import sys

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    @contextlib.contextmanager
    def redirect_stdout(new_stdout):
        old_stdout = sys.stdout
        sys.stdout = new_stdout
        try:
            yield
        finally:
            sys.stdout = old_stdout


# Generated at 2022-06-25 17:02:47.593556
# Unit test for function work_in_progress
def test_work_in_progress():
    def loads_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    with work_in_progress("Loading file"):
        loads_file("/path/to/some/file")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:03:18.422022
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def foo():
        time.sleep(0.5)

    with work_in_progress("testing"):
        time.sleep(0.2)

# Generated at 2022-06-25 17:03:28.797289
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    load_file("/path/to/some/file")
    save_file({}, "/path/to/some/file")
    with work_in_progress("Save to file"):
        save_file({}, "/path/to/some/file")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:03:35.423827
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    print(load_file(__file__))

    with work_in_progress("Saving file"):
        with open(__file__, "wb") as f:
            pickle.dump(load_file, f)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:03:40.882343
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Calculating Fibonacci number"):
        a, b = 0, 1
        for i in range(100_000):
            a, b = b, a + b
    with work_in_progress("Sorting file"):
        time.sleep(3)

# Generated at 2022-06-25 17:03:42.803751
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    with work_in_progress("Testing work_in_progress"):
        time.sleep(.5)

# Generated at 2022-06-25 17:03:52.571992
# Unit test for function work_in_progress
def test_work_in_progress():
    # Cannot write a unit test that actually tests the function work_in_progress,
    # because it prints stuff into the STDOUT.

    # That is why I am restricting myself to testing that function does not crash,
    # and does not have any side effects. To do so, I will use the time module
    # and a mocked time.time() function.

    # In the future, I should consider refactoring the code of this function
    # in order to make it testable.

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @contextlib.contextmanager
    def mocked_time():
        begin_time = time.time()
        yield
        end_time = time.time()


# Generated at 2022-06-25 17:03:58.737502
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:04:08.485499
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test for function :func:`work_in_progress`."""
    from .testing import capture_stdout

    with capture_stdout() as printed:
        with work_in_progress("Loading file"):
            time.sleep(0.2)
    assert printed.string == "Loading file... done. (0.20s)\n"

    with capture_stdout() as printed:
        with work_in_progress("Saving file") as w:
            w.__enter__()
            time.sleep(0.1)
            w.__exit__()
    assert printed.string == "Saving file... done. (0.10s)\n"

    @work_in_progress("Loading file")
    def load_file():
        time.sleep(0.3)


# Generated at 2022-06-25 17:04:15.388924
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test a context manager
    with work_in_progress("Working"):
        time.sleep(0.1)
    with work_in_progress("Working"):
        time.sleep(0.3)

    # Test a context manager used in a decorator
    @work_in_progress("Working")
    def work():
        time.sleep(0.1)

    work()
    work()


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:04:26.053349
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test function work_in_progress."""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert obj

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Run unit tests for function test_work_in_progress
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:05:24.820379
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress."""
    with work_in_progress("Test"):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:05:33.065035
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file_with_except(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = {
        "a": 1,
        "b": [1, 2, 3],
        "c": [1, 2, 3, {
            "d": 1,
            "e": 2,
            "f": 3
        }]
    }

    with open("test.pickle", "wb") as f:
        pickle.dump(obj, f)


# Generated at 2022-06-25 17:05:38.211623
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(0.123)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:05:42.613747
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test that the output of work_in_progress is correct."""
    with work_in_progress("Task1"):
        time.sleep(0.2)

    @work_in_progress()
    def func2():
        time.sleep(0.3)

    func2()

# Generated at 2022-06-25 17:05:44.448759
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1)

# Generated at 2022-06-25 17:05:45.314521
# Unit test for function work_in_progress
def test_work_in_progress():
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:05:50.322787
# Unit test for function work_in_progress
def test_work_in_progress():
    """Simple test code"""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    import pickle
    obj = load_file("/path/to/some/file")
    # Loading file... done. (3.52s)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:05:52.661014
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    for i in range(4):
        with work_in_progress(f"task {i}", ):
            time.sleep(0.5)


# Generated at 2022-06-25 17:05:54.851855
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:06:06.123337
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def _wait_10_seconds():
        time.sleep(10)
    _wait_10_seconds()
    assert True


if __name__ == "__main__":
    import sys
    import doctest

    print()
    result = doctest.testmod()
    if not result.failed:
        try:
            test_work_in_progress()
        except AssertionError:
            print("\nUnit test for function work_in_progress failed", file=sys.stderr)
            sys.exit(1)
        else:
            print("Unit test for function work_in_progress passed")
    sys.exit(0)

# Generated at 2022-06-25 17:08:16.824123
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sleeping"):
        time.sleep(1)

# Generated at 2022-06-25 17:08:21.455197
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Doing something"):
        time.sleep(1)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:08:24.102490
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Working"):
        pass


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:08:26.242426
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Unit testing"):
        time.sleep(0.5)
    assert True

# Generated at 2022-06-25 17:08:30.842086
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with open("/tmp/test.pkl", "wb") as f:
        pickle.dump(np.zeros((128,128)), f)

    obj = load_file("/tmp/test.pkl")
    assert obj.shape == (128, 128)
    os.remove("/tmp/test.pkl")

# Generated at 2022-06-25 17:08:32.556251
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Dummy"):
        time.sleep(1.0)

# Generated at 2022-06-25 17:08:35.905264
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Counting to 100000"):
        for counter in range(100000):
            pass

# Generated at 2022-06-25 17:08:44.437467
# Unit test for function work_in_progress
def test_work_in_progress():
    # First, test the function block example case
    @work_in_progress
    def slow_func():
        time.sleep(2)

    before_time = time.time()
    slow_func()
    after_time = time.time()

    assert "Work in progress... done." in capture_stdout(slow_func)
    assert after_time - before_time >= 2.0

# Capture stdout, stderr helper function

# Generated at 2022-06-25 17:08:46.806854
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test work_in_progress()"""
    with work_in_progress("Sleeping for 5 seconds"):
        time.sleep(5)

# Generated at 2022-06-25 17:08:57.461849
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
        time.sleep(0.2)

    with open("data", "wb") as f:
        pickle.dump([1, 2, 3], f)

    obj = load_file("data")
    assert obj == [1, 2, 3]

    with open("data", "rb") as f:
        assert pickle.load(f) == [1, 2, 3]

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
            time.sleep(0.2)

    with open("data", "rb") as f:
        assert pick