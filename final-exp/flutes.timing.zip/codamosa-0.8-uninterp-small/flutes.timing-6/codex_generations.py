

# Generated at 2022-06-25 16:58:57.009357
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress() as var_0:
        assert True
        return


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 16:59:00.856938
# Unit test for function work_in_progress
def test_work_in_progress():
    var_0 = work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as var_1:
            return pickle.load(var_1)

    obj = load_file("/path/to/some/file")


# Generated at 2022-06-25 16:59:04.618034
# Unit test for function work_in_progress
def test_work_in_progress():
    assert callable(work_in_progress)
    with pytest.raises(TypeError):
        work_in_progress(1)
        work_in_progress(1.0)
        work_in_progress(1.0j)
        work_in_progress(object())
        work_in_progress(lambda: None)

# Generated at 2022-06-25 16:59:08.681660
# Unit test for function work_in_progress
def test_work_in_progress():
    from dtoolcore.utils import TempDir
    from dtoolcore import DataSet
    with TempDir() as tmp_dir:
        tmp_path = os.path.join(tmp_dir, "double_dtool_blessing")
        dataset = DataSet(tmp_path)
        with work_in_progress("Blessing dataset"):
            dataset.bless()
        assert dataset.is_blessed()
        dataset.bless()
        with work_in_progress("Double blessing dataset"):
            dataset.bless()
        assert dataset.is_blessed()

# Generated at 2022-06-25 16:59:18.264399
# Unit test for function work_in_progress
def test_work_in_progress():
    with unittest.TestCase() as test_case:
        @work_in_progress(desc="Loading file")
        def load_file(path):
            with open(path, "rb") as f:
                return pickle.load(f)
        @work_in_progress(desc="Saving file")
        def save_file(obj, path):
            with open(path, "wb") as f:
                pickle.dump(obj, f)

        test_obj = {
            "hello": "world",
        }

        with tempfile.TemporaryDirectory() as temp_dir:
            test_path = os.path.join(temp_dir, "test_file.pickle")
            save_file(test_obj, test_path)
            load_obj = load_file(test_path)

        test_

# Generated at 2022-06-25 16:59:21.444884
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test case 0
    with contextlib.redirect_stdout(None):
        test_case_0()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 16:59:26.811160
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    
    obj = load_file("/path/to/some/file")
    assert True

# Benchmark for function work_in_progress

# Generated at 2022-06-25 16:59:28.754357
# Unit test for function work_in_progress
def test_work_in_progress():
    assert test_case_0() == None, "work_in_progress failed"

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 16:59:29.271962
# Unit test for function work_in_progress
def test_work_in_progress():
    assert True

# Generated at 2022-06-25 16:59:31.876607
# Unit test for function work_in_progress
def test_work_in_progress():
    try:
        _0 = work_in_progress()
        assert isinstance(_0, contextlib.AbstractContextManager)
    except Exception as e:
        pass

# Generated at 2022-06-25 16:59:37.592026
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Work in progress test")
    def work_in_progress_test():
        time.sleep(1)

    work_in_progress_test()

test_work_in_progress()

# Generated at 2022-06-25 16:59:47.142194
# Unit test for function work_in_progress
def test_work_in_progress():
    with open("test_work_in_progress.txt", "w+") as f:
        with contextlib.redirect_stdout(f):
            with work_in_progress("Sleep for 2 seconds"):
                time.sleep(2)
            with work_in_progress("Sleeping for 3 seconds"):
                time.sleep(3)
    with open("test_work_in_progress.txt", "r") as f:
        content = f.read()
    assert re.match(r"Sleep for 2 seconds... done. \(2\.00s\)\nSleeping for 3 seconds... done. \(3\.00s\)", content)
    os.remove("test_work_in_progress.txt")

# Functional test for function work_in_progress

# Generated at 2022-06-25 16:59:50.062697
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        with open("/dev/null", "rb") as f:
            pass

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 16:59:56.671804
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 16:59:58.418187
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        for _ in range(100):
            time.sleep(0.01)
        open(path, "rb")

    load_file("/path/to/file")

# Generated at 2022-06-25 17:00:05.212772
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file...")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file..."):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


# test
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:15.453761
# Unit test for function work_in_progress
def test_work_in_progress():
    class Foo:
        def __init__(self, val=0.0):
            self.val = val

        def __str__(self):
            return str(self.val)

        def __repr__(self):
            return f"Foo({self.val})"

        @work_in_progress("Doing foo bar")
        def do_foo_bar(self):
            time.sleep(1)
            self.val += 1

    foo = Foo()
    foo.do_foo_bar()
    assert foo.val == 1
    assert str(foo) == "1"
    print(f"foo: {foo!r}")
    assert repr(foo) == "Foo(1)"

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:17.088034
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("A long task"):
        time.sleep(1)

# Generated at 2022-06-25 17:00:26.342030
# Unit test for function work_in_progress
def test_work_in_progress():

    # Time a simple function
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # Time a code block
    with work_in_progress("Loading file"):
        obj = load_file("/path/to/some/file")

    # Time a simple function
    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    # Time a code block
    with work_in_progress("Saving file"):
        save_file("/path/to/some/file", obj)


if __name__ == "__main__":
    test_work_in

# Generated at 2022-06-25 17:00:33.481187
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")
    save_file("/path/to/some/file", obj)

# Generated at 2022-06-25 17:00:45.786981
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(0.1)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    load_file("/dev/null")

    with work_in_progress("Saving file"):
        with open("/dev/null", "wb") as f:
            pickle.dump(None, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:50.409269
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import tempfile

    with tempfile.NamedTemporaryFile() as f:
        path = f.name

        with work_in_progress():
            with open(path, "w") as f:
                f.write("Hello")

        with work_in_progress("Loading file"):
            with open(path, "r") as f:
                content = f.read()

        assert content == "Hello"

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:54.388687
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            time.sleep(3)
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    time.sleep(3)

# Generated at 2022-06-25 17:01:00.758245
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import contextlib
    import time

    @contextlib.contextmanager
    def mktemp():
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            yield d

    @work_in_progress("Creating tmp dir")
    def create_tmp_dir():
        return mktemp()

    with create_tmp_dir() as d:
        time.sleep(1)
        assert os.path.exists(d)

# Generated at 2022-06-25 17:01:03.142415
# Unit test for function work_in_progress
def test_work_in_progress():
    import doctest
    doctest.testmod()
    
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:11.761006
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import random
    with tempfile.TemporaryDirectory() as tmpdir:
        idx = random.randint(0, 100000)
        path = os.path.join(tmpdir, f"{idx}.dat")
        with work_in_progress(f"Saving file of `{idx}`"):
            with open(path, "wb") as f:
                f.write(bytes(range(random.randint(0, 10000))))

        with work_in_progress(f"Loading file of `{idx}`"):
            with open(path, "rb") as f:
                data = f.read()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:15.688725
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    with work_in_progress("Loading file") as w:
        with open("test.txt", "rb") as f:
            pickle.load(f)
    with work_in_progress("Saving file") as w:
        with open("test.txt", "wb") as f:
            pickle.dump([0] * 1000000, f)


########################################################################
# Command line interface
########################################################################

if __name__ == "__main__":
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-25 17:01:23.957981
# Unit test for function work_in_progress
def test_work_in_progress():
    obj = []
    with work_in_progress("Storing list"):
        obj.append(1)
    assert len(obj) == 1
    with work_in_progress("Storing list"):
        obj.append(1)
        obj.append(2)
    assert len(obj) == 3
    @work_in_progress("Storing list")
    def store_list(obj, i):
        obj.append(i)
    store_list(obj, 3)
    assert len(obj) == 4

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:01:25.469560
# Unit test for function work_in_progress
def test_work_in_progress():
    def test():
        with work_in_progress("test"):
            time.sleep(1)

    test()

# Generated at 2022-06-25 17:01:27.319624
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(1)

    with work_in_progress("Loading file"):
        time.sleep(1)

# Generated at 2022-06-25 17:01:44.740649
# Unit test for function work_in_progress
def test_work_in_progress():
    from tempfile import TemporaryDirectory

    def long_processing(t):
        time.sleep(t)

    with TemporaryDirectory() as temp_dir:
        for i in range(2):
            func = globals()[f'long_processing_{i}']
            with work_in_progress(f"Processing {i}"):
                func(i)

# Generated at 2022-06-25 17:01:46.825939
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Sleep for 5 seconds"):
        time.sleep(5)



# Generated at 2022-06-25 17:01:54.485062
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
        ...
    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:02:01.289376
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Calculating 42")
    def calc_42():
        time.sleep(0.05)
        return 42

    assert calc_42() == 42

    with work_in_progress("Calculating 24"):
        time.sleep(0.05)
        answer = 24

    assert answer == 24

test_work_in_progress()

# Generated at 2022-06-25 17:02:04.850567
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Some process"):
        time.sleep(0.3)



# Generated at 2022-06-25 17:02:08.670546
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Function called")
    def do_work():
        time.sleep(2)

    with work_in_progress("Context manager called"):
        time.sleep(3)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:02:16.533607
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    from contextlib import redirect_stdout
    from io import StringIO
    output = None
    desc = "Performing calculation"
    with work_in_progress(desc):
        time.sleep(1)
    with redirect_stdout(StringIO()) as stdout:
        with work_in_progress(desc):
            time.sleep(1)
    output = stdout.getvalue()
    assert "Performing calculation... done." in output

# Generated at 2022-06-25 17:02:23.413474
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:02:30.625695
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/file")
    with work_in_progress("Saving file"):
        path = "/path/to/another/file"
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:02:39.152434
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


# Test if this is run as a program
if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:03:12.753864
# Unit test for function work_in_progress
def test_work_in_progress():
    start_time = datetime.datetime.now()
    with work_in_progress("Loading file"):
        # Emulate a lengthy task
        time.sleep(2)
    end_time = datetime.datetime.now()

    actual_time = end_time - start_time
    assert actual_time.seconds >= 2
    assert actual_time.seconds <= 3


if __name__ == "__main__":
    with work_in_progress("Loading file"):
        # Emulate a lengthy task
        time.sleep(2)

# Generated at 2022-06-25 17:03:26.830946
# Unit test for function work_in_progress
def test_work_in_progress():
    result = ''
    print(result, end='', flush=True)

    with work_in_progress("Loading file"):
        result = "Loading file... done. (3.52s)\n"
        with open("test.txt", "r") as f:
            time.sleep(3.52)
    print(result)

    with work_in_progress("Saving file"):
        result = "Saving file... done. (3.78s)\n"
        with open("test2.txt", "w") as f:
            time.sleep(3.78)
    print(result)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:03:28.152526
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(1.5)

# Generated at 2022-06-25 17:03:36.320909
# Unit test for function work_in_progress
def test_work_in_progress():

    # Test the use of work_in_progress as function decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    # Test the use of work_in_progress as contextmanager
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    # Code for debugging this module
    from doctest import testmod
    testmod()

# Generated at 2022-06-25 17:03:37.555734
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(1)

# Generated at 2022-06-25 17:03:42.277727
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    assert work_in_progress.__doc__ is not None

    with work_in_progress("Loading file"):
        time.sleep(1)



# Generated at 2022-06-25 17:03:44.046228
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test work_in_progress"):
        time.sleep(1)

# Generated at 2022-06-25 17:03:49.250423
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:03:53.084250
# Unit test for function work_in_progress
def test_work_in_progress():
    def test(desc: str = "Test"):
        with work_in_progress(desc):
            time.sleep(1)
    test()


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:04:04.787433
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import random
    import pickle
    from pprint import pprint

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # random data to save
    data = {
        "pi": 3.14,
        "e": 2.718,
        "random": [random.uniform(-1.0, 1.0) for _ in range(1000)],
    }

    save_file(data, "/tmp/python-scripting-tools-test.data")
    loaded_data

# Generated at 2022-06-25 17:04:58.392164
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    from .context import work_in_progress

    begin_time = time.time()
    with work_in_progress("Test work_in_progress"):
        time.sleep(1)
    end_time = time.time()

    assert end_time - begin_time >= 1
    assert end_time - begin_time < 1.5

# Generated at 2022-06-25 17:05:01.018904
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing")
    def test():
        time.sleep(0.5)

    test()

# ----
# Script
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:05:05.820557
# Unit test for function work_in_progress
def test_work_in_progress():
    def foo():
        time.sleep(3)
    with work_in_progress("Testing work_in_progress"):
        foo()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:05:11.133675
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Task 1")
    def task_1():
        time.sleep(1)

    with work_in_progress("Task 2"):
        time.sleep(2)
    print("Done.")



# Generated at 2022-06-25 17:05:19.161209
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function work_in_progress.
    """
    import io
    import sys
    @work_in_progress("Time consuming task")
    def time_consuming_task(n):
        time.sleep(n)
        return n

    buf = io.StringIO()
    sys.stdout = buf
    time_consuming_task(1)
    print()
    sys.stdout = sys.__stdout__
    assert buf.getvalue() == 'Time consuming task... done. (1.00s)\n'

    buf.close()

# Generated at 2022-06-25 17:05:30.646766
# Unit test for function work_in_progress
def test_work_in_progress():
    print(work_in_progress)
    from contextlib import redirect_stderr, redirect_stdout
    from io import StringIO

    def testable_function(desc):
        # TODO: Make this function into a context manager
        with redirect_stderr(StringIO()) as err:
            with redirect_stdout(StringIO()) as out:
                # TODO: test the code
                with work_in_progress(desc):
                    time.sleep(1)
                return out.getvalue(), err.getvalue()

    out, err = testable_function("Testing work_in_progress")
    assert not err
    assert out == "Testing work_in_progress... done. (1.00s)\n"


if __name__ == "__main__":
    # This script's unit tests
    test_work_in_

# Generated at 2022-06-25 17:05:37.603004
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test")
    def test():
        print("__test__")

    test()
    with work_in_progress('Test'):
        print('__test__')


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:05:44.888640
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if '__main__' == __name__:
    test_work_in_progress()

# Generated at 2022-06-25 17:05:49.240946
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("fast"):
        time.sleep(0.2)
    with work_in_progress("slow"):
        time.sleep(0.5)


if __name__ == "__main__":
    import pytest

    pytest.main(["-q", "--tb=native", "-x", __file__])

# Generated at 2022-06-25 17:05:52.170571
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:07:51.523497
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(1)

# Generated at 2022-06-25 17:07:56.532667
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""
    .. code:: python

        >>> with work_in_progress("Testing work_in_progress"):
        ...     time.sleep(0.5)
        Testing work_in_progress... done. (0.50s)
    """
    pass

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:08:02.125407
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress(desc="Function to test work_in_progress")
    def inner():
        time.sleep(0.1)
        time.sleep(0.2)
    
    inner()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:08:04.776464
# Unit test for function work_in_progress
def test_work_in_progress():
    for desc in ["Bar", "Foo"]:
        with work_in_progress(desc):
            time.sleep(0.1)

# Generated at 2022-06-25 17:08:16.932169
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    import io
    import pickle

    class Mock:
        def __init__(self):
            self.load_file = None
            self.save_file = None
            self.time_consumed = None
            self.save_file_content = None

        def __call__(self, path):
            with open(path, "rb") as f:
                self.load_file = pickle.load(f)

        def __enter__(self):
            self.save_file = io.BytesIO()

        def __exit__(self, exc_type, exc_val, exc_tb):
            self.save_file_content = self.save_file.getvalue()
            self.save_file.close()

    mock = Mock()

# Generated at 2022-06-25 17:08:18.314652
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Doing something"):
        time.sleep(1.23)

# Generated at 2022-06-25 17:08:27.933531
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:08:31.702362
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:08:36.409297
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    with work_in_progress("Initializing"):
        time.sleep(random.randrange(100) / 1000)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:08:43.734414
# Unit test for function work_in_progress
def test_work_in_progress():
    import io
    import sys
    import unittest.mock
    from contextlib import redirect_stdout

    with unittest.mock.patch.object(sys, "stdout", new_callable=io.StringIO) as stdout:
        with work_in_progress():
            time.sleep(0.1)
        time.sleep(0.3)
        assert stdout.getvalue().startswith('... done. (0.10s)')
    with unittest.mock.patch.object(sys, "stdout", new_callable=io.StringIO) as stdout:
        with work_in_progress(desc="some description"):
            time.sleep(0.1)
        time.sleep(0.3)