

# Generated at 2022-06-25 16:58:56.221484
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""
    Function work_in_progress is tested with the following cases:

      - testing function work_in_progress with no parameters
    """
    work_in_progress()

if __name__ == '__main__':
    import sys
    import pytest

    pytest.main(sys.argv)

# Generated at 2022-06-25 16:58:58.886579
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test #0
    time.sleep(1)
    work_in_progress()
    with work_in_progress("Doing something"):
        time.sleep(1)

# Generated at 2022-06-25 16:59:00.841809
# Unit test for function work_in_progress
def test_work_in_progress():
    assert work_in_progress() == work_in_progress()

__all__ = [
    "work_in_progress",
]

# Generated at 2022-06-25 16:59:09.781304
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test 0
    with work_in_progress("Loading file"):
        with open("data.pkl", "rb") as f:
            obj = pickle.load(f)
    # Test 1
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("data.pkl")

# Generated at 2022-06-25 16:59:12.982701
# Unit test for function work_in_progress
def test_work_in_progress():
    "Unit test for function work_in_progress"
    with work_in_progress("Loading file"):
        with open("../data/samples.pt", "rb") as f:
            obj = pickle.load(f)
    assert obj is not None

# Generated at 2022-06-25 16:59:22.130745
# Unit test for function work_in_progress
def test_work_in_progress():
    num_iter = 100
    array_size = 100
    test_array = np.random.rand(array_size)
    test_code_block = """\
    def test_func(a):
        f = lambda x: x ** 2
        return sum(map(f, a))
    """
    exec(test_code_block)
    assert test_func(test_array) == sum(x ** 2 for x in test_array)

    for name, func in [
            ("test_func", test_func),
            ("work_in_progress", work_in_progress)]:
        with timed_block(f"{name}: {num_iter}x"):
            for _ in range(num_iter):
                test_func(test_array)

# Generated at 2022-06-25 16:59:23.217041
# Unit test for function work_in_progress
def test_work_in_progress():
    # assert 1 == 0
    test_case_0()

# Generated at 2022-06-25 16:59:31.022658
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    try:
        tmp = tempfile.NamedTemporaryFile(mode='w+')
        import sys
        if sys.version_info.major < 3:
            from StringIO import StringIO
        else:
            from io import StringIO
        old_stdout = sys.stdout
        sys.stdout = StringIO()
        try:
            test_case_0()
            assert False, "Should have raised"
        except TypeError as e:
            assert str(e) == "Required argument 'desc' (pos 1) not found"
        sys.stdout = old_stdout
    finally:
        tmp.close()

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()

# Generated at 2022-06-25 16:59:33.655214
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("1"):
        time.sleep(1)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 16:59:44.297513
# Unit test for function work_in_progress
def test_work_in_progress():
    # Mock class for Path
    class Path:
        def __init__(self, path: str = None):
            self._path = path
            self._name = os.path.basename(self._path)

        @property
        def name(self) -> str:
            return self._name

    # Mock class for Link
    class Link:
        def __init__(self, link: str = None):
            self._link = link
            self._name = os.path.basename(self._link)

        @property
        def name(self) -> str:
            return self._name

        def unlink(self) -> None:
            pass

    # Mock class for File
    class File:
        def __init__(self, path: str = None):
            self._path = path

# Generated at 2022-06-25 16:59:55.041663
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
        
    @work_in_progress("Saving file")
    def save_file(path, data):
        with open(path, "wb") as f:
            pickle.dump(data, f)

    path = "__test_work_in_progress.bin"
    save_file(path, [1] * 1000)
    load_file(path)
    os.remove(path)

# Generated at 2022-06-25 16:59:57.856185
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Computing sin(x)"):
        for i in range(10000):
            math.sin(i)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:05.342765
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function work_in_progress."""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")
    save_file("/path/to/some/file")

# Generated at 2022-06-25 17:00:10.064364
# Unit test for function work_in_progress
def test_work_in_progress():
    """docstring"""
    desc = "Test status"
    with work_in_progress(desc) as w:
        time.sleep(0.5)
    print(f"\nReturn: {w}")
    time.sleep(0.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:16.995516
# Unit test for function work_in_progress
def test_work_in_progress():
    obj = "dummy"

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "test.pkl")
    save_file(obj, path)
    obj = load_file(path)
    assert obj == "dummy"

# Generated at 2022-06-25 17:00:21.769200
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import random

    with work_in_progress("Loading a random file"):
        with open(os.urandom(16).hex(), "w") as f:
            f.write("A" * random.randint(0, 1e5))


# Generated at 2022-06-25 17:00:31.535160
# Unit test for function work_in_progress
def test_work_in_progress():
    from .utils import get_random_obj
    obj = get_random_obj()
    path = "/tmp/myobj.pkl"
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    assert obj == load_file(path)

# Generated at 2022-06-25 17:00:34.554813
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing"):
        time.sleep(1)

# Generated at 2022-06-25 17:00:42.318365
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    
    print("Loading file... ", end='', flush=True)
    begin_time = time.time()
    with open("test_work_in_progress.pkl", "rb") as f:
        obj = pickle.load(f)
    time_consumed = time.time() - begin_time
    print(f"done. ({time_consumed:.2f}s)")
    assert isinstance(obj, dict)

# Generated at 2022-06-25 17:00:44.942630
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress('test function')
    def test_function():
        time.sleep( 0.123456 )

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:56.230396
# Unit test for function work_in_progress
def test_work_in_progress():

    with work_in_progress("Loading file"):
        time.sleep(1)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/etc/passwd")
    print(obj)

if __name__ == "__main__":

    # Run unit tests
    test_work_in_progress()

# Generated at 2022-06-25 17:01:00.978932
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def dummy_function_work_in_progress():
        time.sleep(3)

    dummy_function_work_in_progress()

    with work_in_progress("Testing work_in_progress with context manager"):
        time.sleep(3)

# Generated at 2022-06-25 17:01:04.330329
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        for _ in range(10000):
            math.sqrt(41)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:10.698084
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing function work_in_progress...", end="", flush=True)

    def inner_work():
        for i in range(10 ** 7):
            # Do 10000 comparisons and assignments
            a, b = i, i + 1

    # Test the decorator form
    @work_in_progress("Test decorator form")
    def outer_work():
        inner_work()

    outer_work()

    # Test the context manager form
    with work_in_progress("Test context manager form"):
        inner_work()

    print(" done")

# Generated at 2022-06-25 17:01:18.120020
# Unit test for function work_in_progress
def test_work_in_progress():
    # Work in progress function can be use as a decorator.
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # It can also be used as a context manager
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    # Example of use with a progress bar
    progress = tqdm(
        iterable=[0, 0.5, 1.0, 1.5, 2.0, 2.5],
        desc="Computing",
    )
    for i in progress:
        time.sleep(0.1)
        # Update the progress bar

# Generated at 2022-06-25 17:01:23.660332
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test function work_in_progress"""
    begin_time = time.time()
    with work_in_progress("Test"):
        time.sleep(1)
    time_consumed = time.time() - begin_time
    assert time_consumed > 1


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:25.507939
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    with work_in_progress():
        time.sleep(2)

# Generated at 2022-06-25 17:01:27.320215
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress."""
    with work_in_progress():
        time.sleep(0.5)

# Generated at 2022-06-25 17:01:30.899190
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:32.108047
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing..."):
        time.sleep(5)

# Generated at 2022-06-25 17:01:47.291204
# Unit test for function work_in_progress
def test_work_in_progress():
    try:
        time.time = lambda: 0
        with patch('sys.stdout', new=StringIO()) as mock_stdout:
            with work_in_progress("Testing work_in_progress"):
                time.sleep(0.1)
            captured = mock_stdout.getvalue().strip()
            print(captured)
            assert captured == "Testing work_in_progress... done. (0.10s)"
    finally:
        time.time = time_func

# Generated at 2022-06-25 17:01:50.345659
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.5)

if __name__ == "__main__":
    pass

# Generated at 2022-06-25 17:01:55.466253
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Adding two integers")
    def add(a: int, b: int) -> int:
        time.sleep(3.2)
        return a + b

    a = add(23, 77)
    assert a == 100

# Generated at 2022-06-25 17:01:59.345190
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test work_in_progress"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:02:01.288756
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Testing work_in_progress"
    with work_in_progress(desc):
        time.sleep(1)
    assert True

# Generated at 2022-06-25 17:02:06.026189
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def test_fun():
        time.sleep(1)
        return True

    assert test_fun()


# Unit test of the module.

# Generated at 2022-06-25 17:02:10.072422
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function :func:`work_in_progress`."""
    # Declare some mock object
    class _MockObject(object):
        pass
    class _MockFileObject(object):
        pass
    mock_obj = _MockObject()
    mock_obj.__dict__["some_attribute"] = "Hello"
    mock_obj.__dict__["some_int"] = 11
    mock_obj.__dict__["some_list"] = [3, 2, 1]
    mock_obj.__dict__["some_dict"] = {"hello": 1, "world": 2}
    mock_obj.__dict__["some_tuple"] = (1, 2, 3, 4, 5)
    mock_obj.__dict__["some_float"] = 4.678
    # Define some mock functions


# Generated at 2022-06-25 17:02:23.630821
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path: str) -> List[str]:
        r"""Load a file and return a list of its lines.

        :param path: Path to the file to load.
        :return: List of lines in the file.
        """
        with open(path, "r") as f:
            return f.readlines()

    def save_file(path: str, lines: List[str]):
        r"""Save a list of lines to a file.

        :param path: Path to the file to save.
        :param lines: The lines to save in the file.
        """
        with open(path, "w") as f:
            for l in lines:
                f.write(l + "\n")


# Generated at 2022-06-25 17:02:31.331523
# Unit test for function work_in_progress
def test_work_in_progress():

    import pytest
    from io import StringIO
    from contextlib import redirect_stdout

    # Test without description.
    with redirect_stdout(StringIO()) as f:
        with work_in_progress():
            time.sleep(1)
    assert "Work in progress... done. (1.00s)" in f.getvalue()

    # Test with description.
    with redirect_stdout(StringIO()) as f:
        with work_in_progress("Loading file"):
            time.sleep(0.1)
    assert "Loading file... done. (0.10s)" in f.getvalue()


# Generated at 2022-06-25 17:02:40.860450
# Unit test for function work_in_progress
def test_work_in_progress():
    def run_test(test_cases):
        for desc, code, expected in test_cases:
            print(f"Testing {desc}")
            with work_in_progress(desc):
                code()
            assert expected is True


    def test_decorator():
        @work_in_progress("Decorated function test")
        def func():
            time.sleep(0.5)
        return func()

    def test_context_manager():
        with work_in_progress("Context manager test"):
            time.sleep(0.5)

    @work_in_progress("Decorator with context manager")
    def script():
        time.sleep(0.5)


# Generated at 2022-06-25 17:03:14.442533
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path: str):
        time.sleep(2)
        return path

    file_path = "/path/to/some/file"
    file_path_actual = load_file(file_path)
    assert file_path == file_path_actual

    with work_in_progress("Saving file"):
        time.sleep(2)

# vim: ts=4 sw=4 sts=4 expandtab

# Generated at 2022-06-25 17:03:17.942755
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Working")
    def do_work():
        time.sleep(1)
        return "done"

    assert do_work() == "done"

# Generated at 2022-06-25 17:03:24.383592
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        import random
        rand = [random.random() for _ in range(10**5)]
    with work_in_progress("Saving file"):
        import random
        rand = [random.random() for _ in range(10**5)]
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:03:34.288801
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    data = list(range(1000000))
    print("Loading data...", end='', flush=True)
    obj = load_file("/path/to/some/file")
    print("done.")
    print("Saving data...", end='', flush=True)
    save_file("/path/to/some/other/file")
    print("done.")

# Generated at 2022-06-25 17:03:44.184533
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    >>> import pprint
    >>> @work_in_progress("Loading file")
    ... def load_file(path):
    ...     with open(path, "rb") as f:
    ...         return pickle.load(f)
    ...
    >>> obj = load_file("/path/to/some/file")
    Loading file... done. (3.52s)
    >>> pprint.pprint(obj)
    {
        'k1': 'v1'
        'k2': 'v2'
    }

    >>> with work_in_progress("Saving file"):
    ...     with open(path, "wb") as f:
    ...         pickle.dump(obj, f)
    Saving file... done. (3.78s)
    """
    pass

# Generated at 2022-06-25 17:03:45.536362
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading data"):
        time.sleep(0.01)

# Generated at 2022-06-25 17:03:53.953411
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    path = str(pathlib.Path.home() / ".test_work_in_progress.pickle")

    try:
        os.remove(path)
    except FileNotFoundError:
        pass

    assert not os.path.isfile(path)
    obj = load_file(path)
    assert obj == {}
    obj = {"abc": 123, "xyz": list(range(10))}
    save_file(path, obj)

# Generated at 2022-06-25 17:03:57.946979
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("This is a test")
    def do_something():
        time.sleep(3.14)

    with work_in_progress("This is another test"):
        time.sleep(2.71)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:04:08.062171
# Unit test for function work_in_progress
def test_work_in_progress():
    class DummyClass:
        def __init__(self):
            pass

    @work_in_progress("Dummy task")
    def dummy_task():
        pass

    @work_in_progress("Dummy task 2")
    def dummy_task2():
        time.sleep(1)

    @work_in_progress("Dummy task 3")
    def dummy_task3():
        time.sleep(3)

    @work_in_progress("Dummy task 4")
    def dummy_task4():
        pass

    with work_in_progress("Dummy task 5"):
        time.sleep(1)

    with work_in_progress("Dummy task 6"):
        time.sleep(5)

    with work_in_progress("Dummy task 7"):
        time.sleep(1)


# Generated at 2022-06-25 17:04:18.306803
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import pickle

    def save_obj(obj: object, path: str):
        with work_in_progress("Saving file"):
            with open(path, "wb") as f:
                pickle.dump(obj, f)

    def load_obj(path: str) -> object:
        with work_in_progress("Loading file"):
            with open(path, "rb") as f:
                return pickle.load(f)

    obj = {
        "one": "abcd",
        "two": 123,
        "three": {
            4.56: "efgh",
            78.90: "ijkl",
        },
    }

    save_obj(obj, "test_file")
    assert os.path.exists("test_file")

    assert obj == load_obj

# Generated at 2022-06-25 17:05:23.191022
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress."""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:05:24.565668
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.1)

# Generated at 2022-06-25 17:05:27.348539
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("One task"):
        time.sleep(1)
    print()
    with work_in_progress("Multi tasks"):
        time.sleep(1)
        time.sleep(1)
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:05:30.236280
# Unit test for function work_in_progress
def test_work_in_progress():
    total = 0
    for i in range(1, 10):
        with work_in_progress(f"i is {i}"):
            time.sleep(3)
            total += i
    assert total == 45

# Generated at 2022-06-25 17:05:37.389689
# Unit test for function work_in_progress
def test_work_in_progress():
    obj = [None]
    path = "/tmp/example.pkl"
    with work_in_progress("Loading file"):
        time.sleep(0.5) # Simulate reading time.
        with open(path, "rb") as f:
            obj[0] = pickle.load(f)
    with work_in_progress("Saving file"):
        time.sleep(1.5) # Simulate writing time.
        with open(path, "wb") as f:
            pickle.dump(obj[0], f)
    os.remove(path)

# Generated at 2022-06-25 17:05:43.336715
# Unit test for function work_in_progress
def test_work_in_progress():
    for i in range(3):
        with work_in_progress("Sleeping for a while"):
            time.sleep(0.5)
        with work_in_progress("Sleeping for a long time"):
            time.sleep(0.9)
    assert True

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:05:48.659496
# Unit test for function work_in_progress
def test_work_in_progress():
    # test the first use case
    @work_in_progress("Test 1")
    def f():
        time.sleep(3)
        return 42

    assert f() == 42
    print()

    # test the second use case
    with work_in_progress("Test 2"):
        time.sleep(3)

    print()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:05:55.305280
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:06:05.552883
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(2)
        with open(path, "rb") as f:
            return pickle.load(f)
    assert load_file("test.pickle") == "Testing work_in_progress"

    with work_in_progress("Saving file"):
        time.sleep(1)
        with open("test.pickle", "wb") as f:
            pickle.dump("Testing work_in_progress", f)

# Generated at 2022-06-25 17:06:07.722996
# Unit test for function work_in_progress
def test_work_in_progress():
    def func():
        time.sleep(0.05)

    with work_in_progress("Test function"):
        func()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:08:15.048287
# Unit test for function work_in_progress
def test_work_in_progress():
    def _f():
        time.sleep(1)

    with work_in_progress("Testing 1"):
        _f()

# Generated at 2022-06-25 17:08:27.870648
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import random
    import pickle

    def pickle_object(obj, path):
        """Pickle an object to a file."""
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    def unpickle_object(path):
        """Unpickle an object from a file."""
        with open(path, "rb") as f:
            return pickle.load(f)

    # Test for function
    rnd_num = random.random()
    path = os.path.join(os.path.expanduser("~"), "test.pkl")
    @work_in_progress("Pickling object")
    def test_func():
        pickle_object(rnd_num, path)
    test_func()
    assert rnd_num == unpickle

# Generated at 2022-06-25 17:08:39.179328
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == '__main__':
    test_work_in_progress()
    pass

# Generated at 2022-06-25 17:08:43.557443
# Unit test for function work_in_progress
def test_work_in_progress():
    assert True


if __name__ == '__main__':
    import doctest
    doctest.testmod()

    test_work_in_progress()

# Generated at 2022-06-25 17:08:51.312342
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)