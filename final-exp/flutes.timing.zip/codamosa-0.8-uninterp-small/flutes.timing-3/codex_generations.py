

# Generated at 2022-06-25 16:58:56.599588
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        with open("/path/to/some/file", "rb") as f:
            obj = pickle.load(f)
    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

# Generate a test case

# Generated at 2022-06-25 16:58:57.247542
# Unit test for function work_in_progress
def test_work_in_progress():
    pass

# Generated at 2022-06-25 16:59:00.720641
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress() as var_0:
        time.sleep(0.5)
    assert (
        var_0
        is None
    ), "Expected {}, but got {}".format(
        None,
        var_0,
    )

# Generated at 2022-06-25 16:59:04.838371
# Unit test for function work_in_progress
def test_work_in_progress():
    var_0 = work_in_prog

# Generated at 2022-06-25 16:59:05.842117
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        print("Test")

# Generated at 2022-06-25 16:59:08.948746
# Unit test for function work_in_progress
def test_work_in_progress():
    a = 3
    with work_in_progress("Testing"):
        a = 6
    assert(a == 6)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 16:59:12.597414
# Unit test for function work_in_progress
def test_work_in_progress():

    with work_in_progress("Work in progress"):
        time.sleep(2)

    with work_in_progress("Work in progress 2"):
        time.sleep(2)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 16:59:22.442756
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import pickle
    import tempfile
    path = tempfile.mktemp()
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    obj = load_file(path)
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == '__main__':
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-25 16:59:30.573548
# Unit test for function work_in_progress
def test_work_in_progress():
    var_0 = work_in_progress()
    with var_0 as var_1:
        var_2 = work_in_progress("Loading file")
        var_3 = var_2.__get__(var_0)
        def load_file(path):
            var_4 = open(path, "rb")
            with var_4 as var_5:
                var_6 = pickle.load(var_5)
                return var_6
            return var_6
        var_7 = var_3(var_0, load_file)
        obj = var_7("/path/to/some/file")
        with work_in_progress("Saving file") as var_8:
            var_9 = open(path, "wb")
            with var_9 as var_10:
                var_11 = pick

# Generated at 2022-06-25 16:59:32.222517
# Unit test for function work_in_progress
def test_work_in_progress():
    assert type(work_in_progress()) == contextlib._GeneratorContextManager

# Generated at 2022-06-25 16:59:45.698025
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import pickle
    from delira.io.utils import load_json
    from delira.training.utils import save_checkpoint
    from delira.training.backends.chainer.trainer import ChainerTrainer

    class DummyNetwork(nn.Module):
        """
        Dummy Network for testing purposes
        """

        def __init__(self):
            super().__init__()
            self.model = nn.Sequential(
                nn.Linear(10, 50),
                nn.ReLU(),
                nn.Linear(50, 50),
                nn.ReLU(),
                nn.Linear(50, 10)
            )

        def forward(self, inp, **kwargs):
            return self.model(inp)

    dummy_net = ChainerTrainer

# Generated at 2022-06-25 16:59:49.340518
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test context manager
    with work_in_progress("Testing context manager"):
        time.sleep(1.5)

    # Test decorator
    @work_in_progress("Testing decorator")
    def decorator_test():
        time.sleep(0.5)

    decorator_test()

    # Test yield

# Generated at 2022-06-25 16:59:59.321011
# Unit test for function work_in_progress
def test_work_in_progress():
    from tempfile import TemporaryDirectory
    import pickle
    from .unittest_tools import for_all_methods

    @for_all_methods(work_in_progress("Loading file"))
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @for_all_methods(work_in_progress("Saving file"))
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with TemporaryDirectory() as tmp_dir:
        path = os.path.join(tmp_dir, "file.pkl")

        obj = load_file(path)
        assert obj == dict(abc=123)

        save_file(obj, path)

# Generated at 2022-06-25 17:00:03.275154
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Test work_in_progress"
    with work_in_progress():
        time.sleep(1)
    with work_in_progress(desc):
        time.sleep(1)

# Generated at 2022-06-25 17:00:15.289167
# Unit test for function work_in_progress
def test_work_in_progress():
    def _test_work_in_progress(desc, expected, to_test):
        with mock.patch('builtins.print') as mock_print:
            with mock.patch('builtins.input', return_value='y'):
                to_test()
                print('... done. ({0:.2f}s)'.format(time.time()))
                mock_print.assert_called_with(desc + expected)

    # test for decorator
    @work_in_progress('test')
    def to_test1():
        pass


# Generated at 2022-06-25 17:00:18.108012
# Unit test for function work_in_progress
def test_work_in_progress():
    def fun(sleep):
        with work_in_progress():
            time.sleep(sleep)

    fun(0.1)
    fun(0.2)

# Generated at 2022-06-25 17:00:23.476854
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "./ksp_analysis/data/kerbal.pickle"
    with work_in_progress("Loading file"):
        obj = load_file(path)
        # print(obj)

# Generated at 2022-06-25 17:00:32.530753
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with work_in_progress("Loading file"):
        obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        save_file("/path/to/some/file")

# Generated at 2022-06-25 17:00:37.649183
# Unit test for function work_in_progress
def test_work_in_progress():
    # Use case 1: context manager
    print("Test case 1: Use as a context manager\n")
    with work_in_progress("Saving file"):
        # Perform some task
        time.sleep(1.5)
    print()

    # Use case 2: function wraps
    print("Test case 2: Use as function wraps\n")
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    print()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:00:44.233531
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Doing something"):
        time.sleep(0.5)
    print(end="\n")
    with work_in_progress():
        time.sleep(0.2)
    print(end="\n")
    with work_in_progress("Sleeping"):
        time.sleep(1.5)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:57.104996
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile
    import pickle

    for f in (work_in_progress, work_in_progress()):
        with f("Creating file"):
            with tempfile.NamedTemporaryFile(delete=False) as f:
                pickle.dump(range(10), f)
        with f("Loading file"):
            with open(f.name, "rb") as f:
                a = pickle.load(f)
        assert a == range(10)
        os.remove(f.name)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:04.611846
# Unit test for function work_in_progress
def test_work_in_progress():
    #@work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    #with work_in_progress("Saving file"):
    with open("/path/to/some/file", "wb") as f:
        pickle.dump(obj, f)
    return obj

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:12.164420
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile
    from contextlib import contextmanager

    @contextmanager
    def temp_file():
        fd, path = tempfile.mkstemp()
        try:
            yield path
        finally:
            os.close(fd)
            os.remove(path)

    with temp_file() as path:
        with work_in_progress("Creating file"):
            write_data(path, b'abcd')
        assert os.stat(path).st_size == 4


# This code is not executed when imported as module
if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:01:15.748803
# Unit test for function work_in_progress
def test_work_in_progress():
    # test context manager
    with work_in_progress("Testing context manager"):
        time.sleep(1)
    # test decorator
    @work_in_progress("Testing function decorator")
    def foo():
        time.sleep(1)
    foo()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:21.768345
# Unit test for function work_in_progress
def test_work_in_progress():
    # test time.sleep in contextmanager
    with work_in_progress("Testing time.sleep"):
        time.sleep(2)
    assert True

    # test time.sleep in decorator
    @work_in_progress("Testing time.sleep in decorator")
    def timer(time_in_secs):
        time.sleep(time_in_secs)
    timer(2)
    assert True

# Generated at 2022-06-25 17:01:29.008009
# Unit test for function work_in_progress
def test_work_in_progress():
    tmp_path = Path(tempfile.mkdtemp())
    filename = tmp_path / "some_file.pkl"
    test_data = {
        "a" : 1,
        "b" : [2, 3],
    }
    with work_in_progress("Saving file"):
        with open(filename, "wb") as f:
            pickle.dump(test_data, f)
    with work_in_progress("Loading file"):
        with open(filename, "rb") as f:
            result = pickle.load(f)
    assert result == test_data

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:37.776440
# Unit test for function work_in_progress
def test_work_in_progress():
    # Use file /tmp/test_work_in_progress, which does not exist on a default
    # Ubuntu 18.04 LTS VM, to test work_in_progress()
    path = "/tmp/test_work_in_progress.pickle"

    def load_file(path, sleep_time=0.1):
        with open(path, "rb") as f:
            # Sleep longer than the duration needed to complete this
            # operation, to ensure that the meaningful duration of the
            # operation for the test below is less than the sleep time, which
            # makes the test more robust. For example, on some computers, the
            # time taken to load the file might be faster than the sleep time
            # and the test may fail, although in practice this is not the case.
            time.sleep(sleep_time)

# Generated at 2022-06-25 17:01:43.908688
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1.5)
        print("OK")

# pylint: enable=unused-variable,unused-argument,redefined-outer-name,invalid-name

# Generated at 2022-06-25 17:01:47.790589
# Unit test for function work_in_progress
def test_work_in_progress():
    obj = None

    @work_in_progress("Some work")
    def work():
        global obj
        with open("./README.md", "rb") as f:
            obj = pickle.load(f)

    work()

    with work_in_progress("Saving file"):
        with open("./README.md", "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:59.816222
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path: str, iterations: int = 1e4):
        for i in range(iterations):
            with open(path, "rb") as f:
                pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path: str, iterations: int = 1e4):
        for i in range(iterations):
            with open(path, "wb") as f:
                pickle.dump(random.random(), f)

    load_file(__file__, iterations=1e2)
    save_file(__file__, iterations=1e2)
    with work_in_progress("opening file"):
        f = open(__file__)


# Generated at 2022-06-25 17:02:15.201811
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Testing work_in_progress")
    def test_function():
        time.sleep(0.123)

    test_function()
    assert True

# Generated at 2022-06-25 17:02:23.245447
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Loading file" 
    @work_in_progress(desc)
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    path = "/path/to/some/file"
    load_file(path)
 
    desc = "Saving file"
    with work_in_progress(desc):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
            


# Generated at 2022-06-25 17:02:26.485830
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("test"):
        time.sleep(0.1)

# Generated at 2022-06-25 17:02:31.252866
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading pickle file")
    def load_pkl(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    try:
        data = load_pkl("test_data/test_seq.pkl")
        assert data == [1, 2, 3, 4, 5]
        print(data)
    except Exception as err:
        print(err)
        raise err

# Generated at 2022-06-25 17:02:33.047449
# Unit test for function work_in_progress
def test_work_in_progress():
    more_work_in_progress("Work in progress", "done")


# Generated at 2022-06-25 17:02:41.347233
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")
    save_file("/path/to/some/file", obj)
    assert False

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:02:44.294233
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.1)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:02:47.633310
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("This is a demo")
    def demo():
        time.sleep(1)

    demo()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:02:53.094568
# Unit test for function work_in_progress
def test_work_in_progress():
    from contextlib import redirect_stdout
    from os import path

    def slow_function(n):
        for i in range(n):
            for j in range(n):
                for k in range(n):
                    pass

    with redirect_stdout(path.join(path.dirname(__file__),
                                   'test_work_in_progress.txt')):
        with work_in_progress("Test work_in_progress function"):
            slow_function(10000)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:03:00.520328
# Unit test for function work_in_progress
def test_work_in_progress():
    before = time.time()
    with work_in_progress("Sleeping for 1 sec"):
        time.sleep(1)
    time_consumed = time.time() - before
    assert time_consumed >= 1 and time_consumed <= 1.5
    print(f"time_consumed: {time_consumed:.2f}")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:03:28.332616
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Test 1"):
        time.sleep(1.2)
    with work_in_progress("Test 2"):
        time.sleep(2.4)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:03:34.660267
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress."""

    def func1():
        with work_in_progress(desc="Test1"):
            time.sleep(1)

    func1()

    # Test with no description
    @work_in_progress
    def func2():
        time.sleep(1)

    func2()

    if __name__ == "__main__":
        test_work_in_progress()

# Generated at 2022-06-25 17:03:44.338877
# Unit test for function work_in_progress

# Generated at 2022-06-25 17:03:47.887994
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
        print("")
        with work_in_progress("Saving file"):
            time.sleep(1)


# Generated at 2022-06-25 17:03:54.044422
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    Function to unit test function `work_in_progress`

    Returns
    -------
    bool
        Boolean value for test pass or failure.
    """
    try:
        with work_in_progress("Testing work_in_progress"):
            time.sleep(0.3)
            assert True
        return True
    except:
        return False

# Generated at 2022-06-25 17:03:57.328422
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def inner():
        pass
    inner()
    with work_in_progress() as w:
        pass

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:04:05.640398
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
        obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:04:06.859000
# Unit test for function work_in_progress
def test_work_in_progress():
    assert True

# Generated at 2022-06-25 17:04:10.529492
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("This is a test."):
        print("The code block is running.")
        time.sleep(3)
    print("The code block is done.")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:04:18.525772
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for class work_in_progress."""
    import random, pickle
    import tempfile

    obj = [random.randint(0, 999999999) for _ in range(100000)]
    tmp = tempfile.NamedTemporaryFile()

    with work_in_progress("Saving file"):
        with open(tmp.name, 'wb') as f:
            pickle.dump(obj, f)

    with work_in_progress("Loading file"):
        with open(tmp.name, 'rb') as f:
            obj_ = pickle.load(f)

    assert obj == obj_

# Generated at 2022-06-25 17:05:25.337476
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress()
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with open(__file__, "rb") as f:
        obj = f.read()
    assert load_file(__file__) == obj
    save_file(__file__ + ".new")
    assert load_file(__file__ + ".new") == obj
    os.remove(__file__ + ".new")

    with work_in_progress("Loading file"):
        time.sleep(0.1)


# Generated at 2022-06-25 17:05:28.780704
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    with work_in_progress("Some tasks"):
        time.sleep(random.random())
    with work_in_progress("Some tasks"):
        time.sleep(random.random())
    with work_in_progress("Some tasks"):
        time.sleep(random.random())



# Generated at 2022-06-25 17:05:33.814252
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function work_in_progress."""

    with work_in_progress("Making tea") as t:
        time.sleep(1)

    assert t is None

    # Test function decorator
    @work_in_progress("Drinking tea")
    def drink_tea():
        time.sleep(0.5)

    drink_tea()
    return

# Test if module can be imported
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:05:37.418358
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
        with work_in_progress("Computing"):
            time.sleep(2)
    print("Done")

# test_work_in_progress()

# Generated at 2022-06-25 17:05:48.431212
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import pickle

    def worker():
        time.sleep(3.5)

    def worker2():
        with open("/path/to/some/file", "rb") as f:
            return pickle.load(f)

    def worker3():
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

    # Test for timeit
    with work_in_progress("Worker") as w:
        worker()
    # Test for context manager
    with work_in_progress("Worker 2"):
        obj = worker2()
    with work_in_progress("Worker 3"):
        worker3()


# Test module
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:05:51.863002
# Unit test for function work_in_progress
def test_work_in_progress():
    def f():
        with work_in_progress("Task"):
            time.sleep(3)
    f()


# Generated at 2022-06-25 17:06:01.450734
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress."""
    from .itertools import bound_iter
    from .types import is_slice

    def _test(count=10, bound=0.5):
        with work_in_progress("Working"):
            # Emulate a longer running task, like a 'for' loop
            [[v, i] for v in bound_iter(count, bound) for i in range(count)]

    try:
        _test(50, 0.1)
    except KeyboardInterrupt:
        pass

    with work_in_progress("Test"):
        time.sleep(0.1)
        raise KeyboardInterrupt("Interrupting test")

    with work_in_progress("is_slice"):
        assert is_slice(slice(None, None, None))

# Generated at 2022-06-25 17:06:05.284951
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(4)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:06:10.606378
# Unit test for function work_in_progress
def test_work_in_progress():

    # Decorating a function
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(0.1)
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    # Use it as a context manager
    with work_in_progress("Saving file"):
        time.sleep(0.1)
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)
    test_work_in_progress()

# Generated at 2022-06-25 17:06:19.476628
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


# Generated at 2022-06-25 17:08:39.566112
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:08:43.434518
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work in progress for 1s"):
        time.sleep(1)
    with work_in_progress("Testing work in progress for 0.5s"):
        time.sleep(0.5)

# Generated at 2022-06-25 17:08:56.183550
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import pickle
    import tempfile
    import subprocess

    path = tempfile.NamedTemporaryFile(suffix=".txt").name

    print("Execute 'fibonacci_generator' which is decorated by 'work_in_progress'")
    def fibonacci_generator():
        a, b = 0, 1
        while True:
            yield a
            a, b = b, a + b

    print("Execute 'fibonacci_generator' which is not decorated by 'work_in_progress'\n")
    g = fibonacci_generator()
    print(next(g))
    print(next(g))

    print("Attempt to save generator object to a file")