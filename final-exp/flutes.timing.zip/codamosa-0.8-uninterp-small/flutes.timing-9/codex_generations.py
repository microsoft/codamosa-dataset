

# Generated at 2022-06-25 16:58:55.892937
# Unit test for function work_in_progress
def test_work_in_progress():
    result = work_in_progress()
    assert result is None


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-25 16:58:57.398665
# Unit test for function work_in_progress
def test_work_in_progress():
    assert True==True # TODO: implement your test here


# Generated at 2022-06-25 16:59:02.047248
# Unit test for function work_in_progress
def test_work_in_progress():
    # First test case
    var_0 = work_in_progress(desc="Loading file")
    var_0.__enter__()
    var_0.__exit__(None, None, None)
    # Second test case
    with work_in_progress("Saving file"):
        pass


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 16:59:02.866229
# Unit test for function work_in_progress
def test_work_in_progress():
    var_1 = work_in_progress()

# Generated at 2022-06-25 16:59:05.100659
# Unit test for function work_in_progress
def test_work_in_progress():
    # with work_in_progress("Saving file"):
    #     time.sleep(123)
    test_case_0()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 16:59:07.724084
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file") as w:
        with open("./tests/xxx.txt", "rb") as f:
            return pickle.load(f)

    var_0 = work_in_progress()
    assert var_0


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 16:59:10.555623
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("A simple task"):
        time.sleep(1.25)
    assert True

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 16:59:13.026069
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Performing complicated task"):
        time.sleep(1)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 16:59:13.633885
# Unit test for function work_in_progress
def test_work_in_progress():
    pass

# Generated at 2022-06-25 16:59:14.568345
# Unit test for function work_in_progress
def test_work_in_progress():
    var_0 = work_in_progress()

# Generated at 2022-06-25 16:59:20.805831
# Unit test for function work_in_progress
def test_work_in_progress():
    begin_time = time.time()
    with work_in_progress("Work in progress"):
        time.sleep(0.5)
        assert time.time() - begin_time < 1
    assert time.time() - begin_time >= 1

# Generated at 2022-06-25 16:59:26.823506
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Work in progress"):
        time.sleep(2)

    @work_in_progress("Work in progress")
    def sleep_and_print(second: int):
        time.sleep(second)
        print(f"{second} seconds")
    sleep_and_print(1.5)


# Generated at 2022-06-25 16:59:36.222648
# Unit test for function work_in_progress
def test_work_in_progress():

    from os import path
    from .repository import BaseRepository
    from .decorator import cached

    @work_in_progress('Loading repository')
    def load_repository():
        return BaseRepository.load(path.expanduser('~/.parcellation/data/postagger.pkl'))

    @work_in_progress('Loading repository')
    @cached(path.expanduser('~/.parcellation/cache/postagger.pkl'))
    def load_repository_cached():
        return BaseRepository.load(path.expanduser('~/.parcellation/data/postagger.pkl'))

    print('- Without caching:')
    load_repository()
    load_repository()

    print('- With caching:')
    load_repository_

# Generated at 2022-06-25 16:59:46.729018
# Unit test for function work_in_progress

# Generated at 2022-06-25 16:59:49.670983
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def test():
        time.sleep(5)
    test()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 16:59:51.266883
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(1)

    with work_in_progress("Loading file"):
        time.sleep(1)

# Generated at 2022-06-25 16:59:57.856467
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing function work_in_progress...", end=' ', flush=True)
    with work_in_progress("Testing function work_in_progress"):
        time.sleep(1)
    with work_in_progress("Testing function work_in_progress"):
        time.sleep(1)
    with work_in_progress("Testing function work_in_progress"):
        time.sleep(1)
    print()

# Generated at 2022-06-25 17:00:00.944767
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Perform unit testing for all functions in this file."""
    with work_in_progress("Working hard, please wait"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:08.657729
# Unit test for function work_in_progress
def test_work_in_progress():
    # First test: test with a code block
    with work_in_progress("Trying this thing"):
        time.sleep(0.5)
    # Second test: test with a function
    @work_in_progress("Trying this thing again")
    def try_thing():
        time.sleep(0.5)
    try_thing()
    print()


# Unit test
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:15.450308
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(load_file(path), f)

    load_file("../LICENSE")
    save_file("../LICENSE")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:27.185132
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test in function
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/Users/Tony/Project/pytoolkit/README.md")
    assert(obj)

    # Test in code block
    with work_in_progress("Saving file"):
        with open("/Users/Tony/Project/pytoolkit/README.md", "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:33.335834
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test function work_in_progress.
    """
    assert work_in_progress is not None, "The function work_in_progress is missing"
    with work_in_progress("Performing task"):
        time.sleep(0.2)
        print("done.")

if __name__ == "__main__":
    print("Testing function work_in_progress")
    _test_work_in_progress()
    print("work_in_progress passed all tests!")

# Generated at 2022-06-25 17:00:47.478260
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress(desc="Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("test.pickle")
    assert id(obj) == id(load_file.__wrapped__.im_func.__wrapped__.__wrapped__.__wrapped__.__wrapped__.__wrapped__.__wrapped__.__wrapped__.__wrapped__.__wrapped__.__wrapped__.__wrapped__.__wrapped__.__wrapped__.__wrapped__.__wrapped__.__wrapped__)

    with work_in_progress(desc="Saving file"):
        with open("test.pickle", "wb") as f:
            pickle.dump

# Generated at 2022-06-25 17:00:53.793366
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:02.266501
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")
    save_file("/path/to/some/file", obj)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:04.669478
# Unit test for function work_in_progress
def test_work_in_progress():
    def func(arg):
        time.sleep(arg)
        return arg
    with work_in_progress("Test for work_in_progress") as _:
        func(1)

# Generated at 2022-06-25 17:01:05.260957
# Unit test for function work_in_progress
def test_work_in_progress():
    pass

# Generated at 2022-06-25 17:01:10.897584
# Unit test for function work_in_progress
def test_work_in_progress():
    print(f"{__file__}: running test_work_in_progress()")
    @work_in_progress("Testing work_in_progress")
    def consume_time():
        time.sleep(0.1)

    consume_time()

# If the code is run as script, then the following section will be executed.
# This section is used to do some tests on the code.
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:17.642539
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    test_obj = {"a": 1234, "b": 456}

    with tempfile.TemporaryDirectory() as tmpdir:
        save_file(tmpdir + "/data.pkl", test_obj)
        obj = load_file(tmpdir + "/data.pkl")

    assert obj == test_obj

# Generated at 2022-06-25 17:01:23.201133
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Working...")
    def square(x):
        time.sleep(1)
        return x ** 2

    assert square(2) == 4

    with work_in_progress("Working..."):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:41.107491
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1)
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        path = "/tmp/test_work_in_progress.pipe"
        with open(path, "wb") as f:
            pickle.dump(np.random.random(size=(100,100)), f)

    obj = load_file(path)
    assert type(obj) == np.ndarray


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:47.812463
# Unit test for function work_in_progress
def test_work_in_progress():
    from picard.util import ustr, bytesstr

    # Test function decorator format
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, 'rb') as f:
            return pickle.load(f)

    obj = load_file('/path/to/some/file')
    assert ustr(obj) == bytesstr('Loading file... done. (3.52s)')

    # Test context manager format
    with work_in_progress("Saving file"):
        with open(path, 'wb') as f:
            pickle.dump(obj, f)

    assert bytesstr(obj) == bytesstr('Saving file... done. (3.78s)')

# Generated at 2022-06-25 17:01:54.900881
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress."""
    @work_in_progress("Some work")
    def some_work():
        time.sleep(1.2)

    with work_in_progress("Some other work"):
        time.sleep(1.3)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:02:01.590734
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:02:05.917971
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing"):
        time.sleep(1)
    assert True # TODO: find a way to test whether time elapsed is close to 1s

# Generated at 2022-06-25 17:02:10.933371
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing function")
    def test_function():
        time.sleep(0.1)
    test_function()

# Generated at 2022-06-25 17:02:23.315031
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = Path(__file__).parent.as_posix() + "/data/test_file.pkl"
    obj = load_file(path)
    save_path = Path(__file__).parent.as_posix() + "/data/test_save.pkl"

    with work_in_progress("Saving file"):
        with open(save_path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:02:31.314778
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    file_path = "./test_work_in_progress.pkl"
    obj = load_file(file_path)
    assert os.path.exists(file_path)

    with work_in_progress("Saving file"):
        with open(file_path, "wb") as f:
            pickle.dump(obj, f)
    assert os.path.exists(file_path)
    os.remove(file_path)

# Generated at 2022-06-25 17:02:38.436310
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    
    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:02:47.262403
# Unit test for function work_in_progress
def test_work_in_progress():
    from os.path import isfile

    with work_in_progress("Saving file"):
        time.sleep(0.5)
        with open("some-file", "w") as f:
            f.write("some data")

    assert isfile("some-file")

    with work_in_progress("Loading file"):
        time.sleep(0.5)
        with open("some-file", "r") as f:
            data = f.read()

    assert data == "some data"


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:03:19.256451
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(2.34)
    with work_in_progress("Saving file"):
        time.sleep(3.78)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:03:26.116164
# Unit test for function work_in_progress
def test_work_in_progress():
    # Make sure the context management works
    with work_in_progress("Test in progress"):
        time.sleep(0.02)
    print()

    # Make sure decorator works
    @work_in_progress("Test in progress")
    def test():
        time.sleep(0.03)
    print()

    # Run tests
    test()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:03:36.015469
# Unit test for function work_in_progress
def test_work_in_progress():
    def _test_work_in_progress(desc: str, f, *args, **kwargs):
        # capture the current stdout
        stdout = sys.stdout
        try:
            # redirect stdout for testing
            with io.StringIO() as buf, redirect_stdout(buf):
                with work_in_progress(desc):
                    f(*args, **kwargs)
                    # get output
                    out = buf.getvalue()
                    # remove trailing new line
                    out = out.rstrip()
                    # returns (time_consumed, output)
                    return float(out.split()[-2]), out
        finally:
            sys.stdout = stdout
        # returns (time_consumed, output)
        return None, None

    # decorated function test

# Generated at 2022-06-25 17:03:43.006057
# Unit test for function work_in_progress
def test_work_in_progress():
    def _test():
        print("Hello, world! (from inside of the context)")
        time.sleep(1.5)

    import io
    f = io.StringIO()
    with contextlib.redirect_stdout(f):
        with work_in_progress("Test in progress"):
            _test()

    output = f.getvalue()
    assert output == "Test in progress... done. (1.50s)\n"


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:03:52.658078
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile
    from textwrap import dedent

    with tempfile.NamedTemporaryFile(mode="w+b") as f:
        with work_in_progress("Writing to file"):
            pickle.dump({"a": 123}, f)
        with work_in_progress("Reading from file"):
            obj = pickle.load(f)
        assert obj == {"a": 123}

    @work_in_progress("Waiting 3 seconds")
    def wait(seconds):
        time.sleep(seconds)

    wait(3)
    # ===========
    # ===========
    # ===========
    # ===========
    import io
    import sys
    from contextlib import redirect_stdout

    f = io.StringIO()

# Generated at 2022-06-25 17:03:59.068736
# Unit test for function work_in_progress
def test_work_in_progress():
    begin_time = time.time()
    with work_in_progress("Just testing"):
        time.sleep(1)
    end_time = time.time()
    assert abs(end_time - begin_time - 1) < 0.5


if __name__ == "__main__":
    from itertools import permutations

    @work_in_progress("Generating permutations")
    def generate_permutations(seq: list):
        return list(permutations(seq))

    print(generate_permutations(list(range(6))))

# Generated at 2022-06-25 17:03:59.620093
# Unit test for function work_in_progress
def test_work_in_progress():
    pass

# Generated at 2022-06-25 17:04:08.285456
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test 1"):
        time.sleep(0.5)

    def f():
        time.sleep(0.5)
    time_consumed = time.time()
    f()
    time_consumed = time.time() - time_consumed

    @work_in_progress("Test 2")
    def f():
        time.sleep(0.5)

    print("- " * 20 + "\n")

    assert time_consumed - 0.5 < 0.02
    assert time_consumed - 0.5 > -0.02

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:04:10.903922
# Unit test for function work_in_progress
def test_work_in_progress():
    def test_function(a: int) -> int:
        time.sleep(1)
        return a + 1

    with work_in_progress("Test for work in progress"):
        test_function(1)

# Generated at 2022-06-25 17:04:18.134901
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:05:15.923858
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Doing some work"):
        time.sleep(0.5)



# Generated at 2022-06-25 17:05:18.290742
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1.0)
    with work_in_progress("Saving file"):
        time.sleep(1.0)


# Generated at 2022-06-25 17:05:22.611188
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(.1)
    print()


# Unit test
if __name__ == "__main__":
    import doctest
    doctest.testmod()
    test_work_in_progress()

# Generated at 2022-06-25 17:05:25.374010
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Making a cup of coffee"):
        time.sleep(2.52)
    load_file = work_in_progress("Loading file")(load_file)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:05:32.698376
# Unit test for function work_in_progress
def test_work_in_progress():
    print("\n>>> @work_in_progress(\"Loading file\")")
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    print("\n>>> obj = load_file(\"/path/to/some/file\")")
    obj = load_file("/path/to/some/file")

    print("\n>>> with work_in_progress(\"Saving file\"):")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)



# Generated at 2022-06-25 17:05:40.665687
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    import tempfile

    with tempfile.NamedTemporaryFile(delete=False) as f:
        path = f.name

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, o):
        with open(path, "wb") as f:
            pickle.dump(o, f)

    obj = dict(a=1, b=2, c=3)
    save_file(path, obj)
    obj = load_file(path)
    assert obj == dict(a=1, b=2, c=3)

if __name__ == '__main__':
    test

# Generated at 2022-06-25 17:05:43.744017
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        pass

##############################################################################
# vim: set ff=unix fenc=utf8 ft=python ai et sw=4 ts=4 tw=79:

# Generated at 2022-06-25 17:05:47.566924
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test with function")
    def f():
        time.sleep(1)

    with work_in_progress("Test with context manager"):
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:05:59.900519
# Unit test for function work_in_progress
def test_work_in_progress():
    with open("test_work_in_progress.output", "w") as f, \
         redirect_stdout(f):
        with work_in_progress("Loading file"):
            time.sleep(2)
        with work_in_progress("Saving file"):
            time.sleep(3)
    with open("test_work_in_progress.output", "r") as f:
        assert f.read() == "Loading file... done. (2.01s)\nSaving file... done. (3.00s)\n"
        

# Generated at 2022-06-25 17:06:05.426676
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    def foo(sleep_time, **kwargs):
        with work_in_progress(**kwargs):
            time.sleep(sleep_time)

    foo(0.5)
    foo(0.5, desc="Loading")
    foo(0.5, desc="Loading", end="...\n")


# Generated at 2022-06-25 17:08:09.486546
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:08:21.533754
# Unit test for function work_in_progress
def test_work_in_progress():
    from io import StringIO
    from contextlib import redirect_stdout

    # Test for context
    @work_in_progress("Loading file")
    def test():
        time.sleep(0.1)

    with StringIO(newline=None) as buf, redirect_stdout(buf):
        test()

    assert re.match(r'Loading file\.\.\. done\. \(0\.\d+s\)', buf.getvalue())

    # Test for context manager
    with StringIO(newline=None) as buf, redirect_stdout(buf):
        with work_in_progress("Saving file"):
            time.sleep(0.2)

    assert re.match(r'Saving file\.\.\. done\. \(0\.\d+s\)', buf.getvalue())



# Generated at 2022-06-25 17:08:29.166378
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test for context managers
    with work_in_progress("Loading file"):
        time.sleep(1)

    with work_in_progress("Saving file"):
        time.sleep(2)

    # Test for decorators
    @work_in_progress("Loading file")
    def load_file():
        time.sleep(1)

    @work_in_progress("Saving file")
    def save_file():
        time.sleep(2)

    load_file()
    save_file()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:08:30.131829
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing"):
        time.sleep(1)

# Generated at 2022-06-25 17:08:39.178251
# Unit test for function work_in_progress
def test_work_in_progress():
    import pandas as pd
    df = pd.DataFrame([[1, 2, 3], [4, 5, 6], [7, 8, 9]], columns=["a", "b", "c"])
    with work_in_progress("Test work_in_progress"):
        time.sleep(2)
        df.to_csv("tmp_work_in_progress.csv")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:08:46.238389
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test function :func:`work_in_progress`.
    """
    @work_in_progress("Loading file")
    def load_file(path: str):
        with open(path, "r") as f:
            return f.read()

    @work_in_progress("Saving file")
    def save_file(path: str, data: str):
        with open(path, "w") as f:
            f.write(data)

    with tempfile.TemporaryDirectory() as tmpdir:
        filename1 = os.path.join(tmpdir, "file1")
        filename2 = os.path.join(tmpdir, "file2")

        file_content = load_file(__file__)
        save_file(filename1, file_content)

# Generated at 2022-06-25 17:08:53.638003
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def run_test() -> None:
        time.sleep(0.5)
    run_test()


if __name__ == "__main__":
    test_work_in_progress()