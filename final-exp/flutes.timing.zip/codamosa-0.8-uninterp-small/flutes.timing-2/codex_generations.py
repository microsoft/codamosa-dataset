

# Generated at 2022-06-25 16:58:55.948286
# Unit test for function work_in_progress
def test_work_in_progress():
    work_in_progress()



# Generated at 2022-06-25 16:58:57.437404
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(2)


# Generated at 2022-06-25 16:58:59.877726
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        with open("pickle.pck", "rb") as file:
            pickle.load(file)


# Generated at 2022-06-25 16:59:02.247778
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("test"):
        pass

if __name__ == '__main__':
    test_case_0()
    test_work_in_progress()

# Generated at 2022-06-25 16:59:04.833348
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("test") as var_0:
        var_0.send(None)
    print("test case #0 succeeded")

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 16:59:06.992905
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("dummy"):
        pass

if __name__ == "__main__":
    import pytest
    pytest.main(["-s", "--tb=native", "--pyargs", "utils.progress"])

# Generated at 2022-06-25 16:59:08.827788
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress(desc=None):
        time.sleep(3)


# Generated at 2022-06-25 16:59:11.973607
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress function"):
        time.sleep(0.2)
        assert True

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 16:59:17.685182
# Unit test for function work_in_progress
def test_work_in_progress():
    tmp = []
    with work_in_progress("Loading files"):
        time.sleep(0.0002)
        tmp.append(1)
        time.sleep(0.0005)
        tmp.append(2)
        time.sleep(0.0003)
        tmp.append(3)
        time.sleep(0.0001)
        tmp.append(4)
    assert tmp == [1, 2, 3, 4]

# Generated at 2022-06-25 16:59:20.760372
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test case 0"):
        test_case_0()


if __name__ == "__main__":
    # execute only if run as a script
    test_work_in_progress()

# Generated at 2022-06-25 16:59:28.685808
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Cleaning up")
    def cleanup(data):
        import random
        time.sleep(random.random())
        return []

    data = list(range(10))
    data = cleanup(data)
    assert len(data) == 0

# Cleanup the namespace
del contextlib, time

# Generated at 2022-06-25 16:59:32.751770
# Unit test for function work_in_progress
def test_work_in_progress():
    def test_function():
        pass

    def test_context_manager():
        with work_in_progress():
            pass

    assert work_in_progress(desc="Hello")
    assert work_in_progress()
    assert work_in_progress()(test_function)()
    assert test_context_manager()

# Generated at 2022-06-25 16:59:40.379270
# Unit test for function work_in_progress
def test_work_in_progress():

    def load_file(path: str):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Loading file"):
        obj = load_file(__file__)

    with open("test.txt", "wb") as f:
        with work_in_progress("Saving file"):
            pickle.dump(obj, f)

# Run unit test when module is executed as script
if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 16:59:42.051838
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Check work_in_progress()."""
    from .timer import Timer

    with Timer() as timer:
        with work_in_progress("Saving file"):
            time.sleep(1.1)
    assert timer.time_consumed > 1.0
    assert timer.time_consumed < 1.2

# Generated at 2022-06-25 16:59:43.342306
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(0.5)

# Generated at 2022-06-25 16:59:49.985767
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("tests/sample.pickle")
    save_file("tests/sample_out.pickle", obj)
    os.remove("tests/sample_out.pickle")

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 16:59:53.603267
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing")
    def _():
        time.sleep(5)

    with work_in_progress("Testing"):
        time.sleep(5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 16:59:59.009423
# Unit test for function work_in_progress
def test_work_in_progress():

    def test_function():
        for i in range(10):
            time.sleep(0.5)

    def test_context():
        for i in range(10):
            time.sleep(0.5)

    with work_in_progress("Test function"):
        test_function()
    with work_in_progress("Test context"):
        test_context()

# Generated at 2022-06-25 17:00:09.712028
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file_with_desc(path):
        with open(path, 'rb') as f:
            return pickle.load(f)

    def load_file_with_desc_and_time_measured(path, desc):
        with work_in_progress(desc):
            return load_file_with_desc(path)

    def load_file_without_desc(path):
        with open(path, 'rb') as f:
            return pickle.load(f)

    def load_file_without_desc_and_time_measured(path, desc):
        with work_in_progress(desc):
            return load_file_without_desc(path)


# Generated at 2022-06-25 17:00:14.783504
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(0.3)
    with work_in_progress("Saving file") as prog:
        time.sleep(0.1)
        print("Intermediate progress")
        time.sleep(0.2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:27.623013
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file2(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file", verbose=False)
    def load_file3(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with work_in_progress("Saving file", verbose=False):
        with open(path, "wb") as f:
            pickle

# Generated at 2022-06-25 17:00:32.677820
# Unit test for function work_in_progress
def test_work_in_progress():
    # Avoid outputting logs
    logger = logging.getLogger()
    logger.setLevel(logging.CRITICAL)

    # Test work_in_progress
    task_desc = "Work in progress"
    with work_in_progress(task_desc):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:35.827196
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "This is a test description"
    with work_in_progress(desc):
        pass

# Generated at 2022-06-25 17:00:38.989268
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Test for function work_in_progress"
    with work_in_progress(desc) as w:
        time.sleep(1)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:00:42.768434
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    with work_in_progress("Test"):
        time.sleep(3)
    with work_in_progress("Listing current directory"):
        print("\n".join(os.listdir(".")))

# Generated at 2022-06-25 17:00:45.985841
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing"):
        time.sleep(0.1)

# Unit test code
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:56.658465
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress..."):
        objective_functions = [
            schwefel,
            de_jong,
            rosenbrock,
            rastrigin,
            griewank,
            sine_envelope_sine_wave,
            stretched_v_sine_wave,
            ackley,
            rana,
            pathological,
            michalewicz,
            masters_cosine_wave,
            quantized,
            awkward_one,
            schwefel_2_26,
            egg_holder,
            rana
        ]

# Generated at 2022-06-25 17:01:03.176957
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test for context manager
    with work_in_progress("Saving file"):
        time.sleep(0.1)
    assert True

    # Test for decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")
    assert True

# Generated at 2022-06-25 17:01:06.271693
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1)
        with open(path, "rb") as f:
            return pickle.load(f)
    return load_file

# Generated at 2022-06-25 17:01:08.945620
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Collecting results"):
        time.sleep(1)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:01:27.319835
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing function work_in_progress...")

    def test():
        sleep_time = 0.1
        with work_in_progress("Loading file"):
            time.sleep(sleep_time)

        @work_in_progress("Loading file")
        def load_file():
            time.sleep(sleep_time)

        load_file()

    assert_run_time(test, 0.1 + 2 * TIME_TOLERANCE, 0.2 + 2 * TIME_TOLERANCE)

    print("Test passed.")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:32.545032
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:01:41.076182
# Unit test for function work_in_progress
def test_work_in_progress():
    from io import StringIO
    from contextlib import redirect_stdout
    from .test import *

    test_list = [
        "Loading file... ",
        "Saving file... ",
    ]

    def mock_work_in_progress(desc: str = "Loading file"):
        with redirect_stdout(out):
            with work_in_progress(desc):
                time.sleep(0.1)

    out = StringIO()

    @contextlib.contextmanager
    def work_in_progress(desc: str = "Loading file"):
        yield

    with redirect_stdout(out):
        mock_work_in_progress()
    test_eq("Loading file... done. (0.10s)", out.getvalue().rstrip())

    out = StringIO()

# Generated at 2022-06-25 17:01:44.374076
# Unit test for function work_in_progress
def test_work_in_progress():
    # Install dummy function
    @work_in_progress("Calculating")
    def test_func():
        time.sleep(1)
    # Run dummy function
    test_func()
    # Undo
    del test_func

# Generated at 2022-06-25 17:01:46.962711
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test Work in progress")
    def fct1(n):
        s = 0
        for i in range(n):
            s += i ** 2
        return s

    assert fct1(30) == 0


# Task 1: Two-Lane Bridge
# --------------------------------------------------------------------------------

# Generated at 2022-06-25 17:01:48.979413
# Unit test for function work_in_progress
def test_work_in_progress():
    assert 1 == 1

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:58.041524
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test function work_in_progress."""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")
    del obj

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:02:03.411885
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    assert True

# Generated at 2022-06-25 17:02:10.177046
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test case for work in progress"""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    
    print("---------- Test 1 ------------")
    obj = load_file("/path/to/some/file")    
    
    print("---------- Test 2 ------------")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# test_work_in_progress()

# Slow down the execution of a function.

# Generated at 2022-06-25 17:02:23.642075
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""
    .. code:: python

        >>> import pickle
        >>> import tempfile

        >>> @work_in_progress("Loading file")
        ... def load_file(path):
        ...     with open(path, "rb") as f:
        ...         return pickle.load(f)
        ...
        ... obj = load_file("/path/to/some/file")
        Loading file... done. (3.52s)

        >>> with tempfile.TemporaryDirectory() as d:
        ...     path = os.path.join(d, "file.pickle")
        ...     with work_in_progress("Saving file"):
        ...         with open(path, "wb") as f:
        ...             pickle.dump(obj, f)
        Saving file... done. (3.78s)
    """

# Generated at 2022-06-25 17:02:55.992549
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading data")
    def load_data():
        time.sleep(0.03)

    @work_in_progress("Loading model")
    def load_model():
        time.sleep(0.06)

    with work_in_progress("Loading data"):
        time.sleep(0.18)

    with work_in_progress("Loading model"):
        with work_in_progress("Loading data"):
            with work_in_progress("Loading model"):
                with work_in_progress("Loading data"):
                    time.sleep(0.13)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:03:02.256726
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function work_in_progress."""
    with work_in_progress("Test work in progress"):
        time.sleep(0.1)
    print("Test work in progress... Success")

# This function is called when the module is loaded

# Generated at 2022-06-25 17:03:02.789726
# Unit test for function work_in_progress
def test_work_in_progress():
    assert False

# Generated at 2022-06-25 17:03:07.001017
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:03:15.113560
# Unit test for function work_in_progress
def test_work_in_progress():
    print()
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(0.2)
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:03:24.863224
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:03:26.781318
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(1)

# Generated at 2022-06-25 17:03:30.700344
# Unit test for function work_in_progress
def test_work_in_progress():
    def fn():
        time.sleep(0.5)

    with work_in_progress("Testing work_in_progress"):
        fn()


if __name__ == "__main__":
    print("Testing work_in_progress...")
    test_work_in_progress()

# Generated at 2022-06-25 17:03:33.834868
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(3)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:03:37.882801
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(1.2)
    with work_in_progress("Work in progress"):
        time.sleep(1.1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:04:25.231277
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        with open("/dev/null", "wb") as f:
            f.write(b"*" * 2**20)

if __name__ == "__main__":
    print(__doc__)
    test_work_in_progress()

# Generated at 2022-06-25 17:04:27.903818
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test work_in_progress"):
        time.sleep(2.5)

# Generated at 2022-06-25 17:04:36.293738
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:04:47.665333
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert obj == 1

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:04:59.915532
# Unit test for function work_in_progress
def test_work_in_progress():
    print()
    print(work_in_progress.__doc__)
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    class TestObject(object):
        def __init__(self):
            self._inner_list = [None] * 10000

    obj = TestObject()
    with open("temp.txt", "wb") as f:
        pickle.dump(obj, f)

    obj = load_file("temp.txt")

    with work_in_progress("Saving file"):
        with open("temp.txt", "wb") as f:
            pickle.dump(obj, f)


# Generated at 2022-06-25 17:05:06.184698
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Factorial computation"):
        def factorial(n):
            if n <= 1: return 1
            return n * factorial(n - 1)
        factorial(10)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:05:11.102236
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

# Generated at 2022-06-25 17:05:16.284382
# Unit test for function work_in_progress
def test_work_in_progress():
    a = []
    for i in range(100):
        with work_in_progress(f"Task {i}") as progress:
            a.append(0)
            time.sleep(0.2)
    print(a)

# Generated at 2022-06-25 17:05:18.255175
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing function..."):
        time.sleep(0.56)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:05:29.676996
# Unit test for function work_in_progress
def test_work_in_progress():
    test_cases = [
        [
            """
            with work_in_progress("This is a description"):
                time.sleep(1.23)
            """,
            "This is a description... done. (1.23s)"
        ],
        [
            """
            @work_in_progress("This is a description")
            def test():
                time.sleep(1.23)
            """,
            "This is a description... done. (1.23s)"
        ],
        [
            """
            def test_func():
                with work_in_progress("This is a description"):
                    time.sleep(1.23)
            test_func()
            """,
            "This is a description... done. (1.23s)"
        ]
    ]

# Generated at 2022-06-25 17:07:19.278076
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(0.5)
    with work_in_progress():
        time.sleep(0.5)

# Generated at 2022-06-25 17:07:25.329918
# Unit test for function work_in_progress
def test_work_in_progress():
    def get_primes():
        time.sleep(1)
        return [2, 3, 5, 7]


# Generated at 2022-06-25 17:07:34.807911
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    begin_time = time.time()
    with work_in_progress("Testing function..."):
        time.sleep(1)
    assert time.time() - begin_time > 1
    time.sleep(0.1)
    with work_in_progress():
        time.sleep(1)
    assert time.time() - begin_time > 2

# Generated at 2022-06-25 17:07:37.807382
# Unit test for function work_in_progress
def test_work_in_progress():
    # test for function
    @work_in_progress("Loading file")
    def load_file(path) -> str:
        return path

    @work_in_progress("Saving file")
    def save_file(path) -> str:
        return path
    test_dir = os.path.dirname(os.path.abspath(__file__))

# Generated at 2022-06-25 17:07:40.058976
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Dummy operation"
    with work_in_progress(desc=desc):
        time.sleep(0.5)

# Generated at 2022-06-25 17:07:45.361829
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Work being done") as block:
        time.sleep(0.01)
        print("In work_in_progress")
        time.sleep(0.01)
    print("Done!")
    assert block is None


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:07:48.375173
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:07:53.290451
# Unit test for function work_in_progress
def test_work_in_progress():
    time.sleep(3)
    with work_in_progress("Executing test"):
        time.sleep(3)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:07:56.300044
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)

# This block is only executed when this script is executed directly
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:08:06.115180
# Unit test for function work_in_progress
def test_work_in_progress():
    import pytest
    from unittest.mock import patch
    from io import StringIO

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with patch("sys.stdout", new=StringIO()) as fake_stdout:
        obj = load_file("/path/to/some/file")
        assert fake_stdout.getvalue() == "Loading file... done. (3.52s)"

    with patch("sys.stdout", new=StringIO()) as fake_stdout:
        with work_in_progress("Saving file"):
            with open(path, "wb") as f:
                pickle.dump(obj, f)