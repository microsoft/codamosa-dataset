

# Generated at 2022-06-25 16:58:56.523993
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 16:58:57.246931
# Unit test for function work_in_progress
def test_work_in_progress():
    assert True

# Generated at 2022-06-25 16:59:03.724945
# Unit test for function work_in_progress
def test_work_in_progress():
    import threading
    from threading import Thread

    __count__ = 0

    def count_to(n):
        global __count__
        for _ in range(n):
            work_in_progress()
            __count__ += 1

    # call function in multithreading
    threads = []
    for i in range(5):
        threads.append(Thread(target=count_to, args=(1000000,)))

    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert __count__ == 5000000

# Generated at 2022-06-25 16:59:04.786945
# Unit test for function work_in_progress
def test_work_in_progress():
    # Example 1
    print("%s" % test_case_0())
    assert True

# Generated at 2022-06-25 16:59:08.868284
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"): time.sleep(1)
    with work_in_progress("Saving file"): time.sleep(0.5)


if __name__ == "__main__":
    test_case_0()
    test_work_in_progress()

# Generated at 2022-06-25 16:59:12.496394
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test for function work_in_progress."""

    def task():
        time.sleep(1)

    with work_in_progress("Sleeping a bit"):
        task()

    task = work_in_progress("Sleeping a bit")(task)
    task()

# Generated at 2022-06-25 16:59:16.691669
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert work_in_progress.__doc__ is not None

# Generate unit test code for function work_in_progress

# Generated at 2022-06-25 16:59:23.702122
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 16:59:27.528674
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test"):
        time.sleep(1)
    # Test for function work_in_progress
    print("Test for function work_in_progress")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 16:59:31.865979
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        with open("path", "wb") as f:
            pickle.dump("obj", f)
    print(work_in_progress)

if __name__ == "__main__":
    # Testing
    test_case_0()
    test_work_in_progress()

# Generated at 2022-06-25 16:59:42.055594
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile
    path = tempfile.NamedTemporaryFile().name
    with work_in_progress("Saving file"):
        with open(path, "w") as fid:
            fid.write("Hello world!\n")
    with work_in_progress("Loading file"):
        with open(path, "r") as fid:
            data = fid.read()
    assert data == "Hello world!\n"
    os.remove(path)

# Generated at 2022-06-25 16:59:50.082709
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test 1
    import os
    with work_in_progress("Checking..."):
        for _ in range(10000):
            os.getpid()
    # Test 2
    @work_in_progress("Saving...")
    def slow_save(path):
        import pickle
        with open(path, "wb") as f:
            pickle.dump("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa" * 1000000, f)
    slow_save("dummy.bin")
    os.remove("dummy.bin")
    # Test 3
    @work_in_progress("Loading...")
    def slow_load(path):
        import pickle
        with open(path, "rb") as f:
            return pickle.load(f)
    s = slow_load("dummy.bin")

# Generated at 2022-06-25 16:59:52.612387
# Unit test for function work_in_progress
def test_work_in_progress():
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:00:01.847052
# Unit test for function work_in_progress
def test_work_in_progress():
    from . import requires_network, requires_server
    import os, tempfile, subprocess

    # Tests function work_in_progress (in this decorator)
    with work_in_progress('Test work_in_progress, in this decorator'):
        time.sleep(1)

    # Tests function work_in_progress (the decorator)
    def foo(seconds):
        time.sleep(seconds)

    # Tests function work_in_progress (the decorator + ctxmgr)
    @work_in_progress('Test work_in_progress, in this decorator')
    def foo(seconds):
        time.sleep(seconds)

    foo(0.5)
    foo(1.5)

    # The following tests also require an internet connection
    if not requires_network(): return
    # The following tests also require a running

# Generated at 2022-06-25 17:00:09.065662
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function work_in_progress."""

    with work_in_progress("Loading file"):
        time.sleep(3)

    def load_file(path: str):
        r"""Dummy function that takes in a string."""
        with open(path, "rb") as f:
            time.sleep(3)
            return f

    with load_file("/some/fake/path"):
        pass


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:00:13.194322
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress
    def fake_sleep(duration):
        time.sleep(duration)

    fake_sleep(1)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:00:15.385574
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("I am a dummy test")
    def dummy_test(time_delay):
        time.sleep(time_delay)

    dummy_test(3)



# Generated at 2022-06-25 17:00:21.991366
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:00:28.713718
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test with function
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    # Test with context manager
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:00:34.336489
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file(file_name)
    save_file(obj, file_name)

# Generated at 2022-06-25 17:00:40.094496
# Unit test for function work_in_progress
def test_work_in_progress():
    return True

# Generated at 2022-06-25 17:00:43.588678
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:49.461586
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1)
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        time.sleep(1)
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("test.pickle")
    save_file("test.pickle", obj)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:52.439035
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Unittest"):
        time.sleep(1)
        print("Unittest end")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:55.217208
# Unit test for function work_in_progress
def test_work_in_progress():
    for i in range(1, 10):
        with work_in_progress("Test"):
            time.sleep(random.random()*0.1)
        time.sleep(random.random()*0.1)

# Generated at 2022-06-25 17:01:03.218955
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "TEST"
    with work_in_progress(desc) as f:
        time.sleep(2)
        f()
        time.sleep(1)
    with work_in_progress(desc) as f:
        pass
        f()
    with work_in_progress(desc) as f:
        time.sleep(2)
        f()
        time.sleep(1)


if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=True)
    # test_work_in_progress()

# Generated at 2022-06-25 17:01:06.282839
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    with work_in_progress("Processing Foo"):
        time.sleep(0.1)

    @work_in_progress("Processing Bar")
    def bar():
        time.sleep(0.2)

    bar()

# run unit tests if file is called from shell
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:12.761718
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function work_in_progress."""
    import time
    with work_in_progress("Test work_in_progress"):
        time.sleep(1)

    # TODO: The output is not redirected to stdout for unit test, but it
    # works fine when run independently.
    def foo():
        time.sleep(1)

    foo = work_in_progress("Test work_in_progress")(foo)
    foo()


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:01:17.210753
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import time

    random.seed(0)

    def simulate_data_loading():
        time.sleep(random.uniform(0.2, 0.5))

    with work_in_progress("Loading file"):
        simulate_data_loading()

    print()

    @work_in_progress("Saving file")
    def save_file():
        time.sleep(random.uniform(0.2, 0.5))

    save_file()

# Generated at 2022-06-25 17:01:24.823227
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import os
    with work_in_progress("Creating file") as create_file_wip:
        with open("/tmp/testworkinprogress", "w") as f:
            f.write("Test")
        time.sleep(1)
    assert abs(time.time() - create_file_wip.begin_time - 1.0) < 0.1
    os.remove("/tmp/testworkinprogress")


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:01:40.879412
# Unit test for function work_in_progress
def test_work_in_progress():

    with work_in_progress("Test work in progress."):
        time.sleep(1.5)
    obj = pickle.dumps(test_work_in_progress)
    with work_in_progress("Test work in progress. (2)"):
        pickle.loads(obj)
    time.sleep(1)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:01:44.976763
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    
    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("test.pkl")
    save_file("test2.pkl", obj)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:57.923120
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sleeping for a while"):
        time.sleep(3)
    with work_in_progress("Sleeping for a while"):
        time.sleep(5)
if __name__ == "__main__":
    test_work_in_progress()
    # @work_in_progress("Loading file")
    # def load_file(path):
    #     with open(path, "rb") as f:
    #         return pickle.load(f)
    #
    # obj = load_file("/path/to/some/file")
    #
    # with work_in_progress("Saving file"):
    #     with open(path, "wb") as f:
    #         pickle.dump(obj, f)

# Generated at 2022-06-25 17:02:00.766567
# Unit test for function work_in_progress
def test_work_in_progress():
    assert True

# Generated at 2022-06-25 17:02:02.265089
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading data"):
        time.sleep(0.5)

# Generated at 2022-06-25 17:02:10.901047
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    # Expected output:
    # Loading file... done. (3.52s)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    # Expected output:
    # Saving file... done. (3.78s)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:02:14.764544
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.3)

# Generated at 2022-06-25 17:02:23.623457
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    from pathlib import Path

    with work_in_progress("Generating object"):
        array = [i for i in range(10000)]

    with work_in_progress("Dumping object into file"):
        with open("example.pkl", "wb") as f:
            pickle.dump(array, f)

    with work_in_progress("Loading object from file"):
        with open("example.pkl", "rb") as f:
            array2 = pickle.load(f)

    assert array == array2

    Path("example.pkl").unlink()

# Generated at 2022-06-25 17:02:30.573935
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Loading")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving"):
        with open("/tmp/file", "wb") as f:
            pickle.dump([0]*10000, f)
    with open("/tmp/file", "rb") as f:
        assert pickle.load(f) == [0]*10000



# Generated at 2022-06-25 17:02:40.163137
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")
    save_file("/path/to/some/file", obj)

# Local Variables:
# # tab-width:4
# # indent-tabs-mode:nil
# # End:
# vim: set ft=python et ts=4 sw=4:

# Generated at 2022-06-25 17:03:06.641945
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "Loading file"
    with work_in_progress(desc):
        time.sleep(0.1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:03:19.220688
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    from tempfile import TemporaryFile, NamedTemporaryFile

    def test_file(path: str):
        with work_in_progress(f"Test file {path!r}"):
            assert os.path.exists(path)
            with open(path, "rb") as f:
                f.seek(0, os.SEEK_END)
                assert f.tell() > 0

    with work_in_progress("Create temp files"):
        with TemporaryFile() as f:
            f.write(b"A TemporaryFile object has no name")
        with NamedTemporaryFile() as f:
            f.write(b"A NamedTemporaryFile object has a name")

    test_file(__file__)

if __name__ == "__main__":
    import doctest
    doctest.testmod()


# Generated at 2022-06-25 17:03:23.153579
# Unit test for function work_in_progress
def test_work_in_progress():
    import doctest
    doctest.testmod(verbose=True)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:03:26.779832
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Performing task"):
        time.sleep(3)
    load_file = work_in_progress("Loading file")(lambda path: time.sleep(3))
    load_file("/path/to/some/file")

# Generated at 2022-06-25 17:03:28.094572
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading..."):
        time.sleep(2)
    with work_in_progress("Saving..."):
        time.sleep(3)


if __name__ == '__main__':
    import pytest
    pytest.main(__file__)

# Generated at 2022-06-25 17:03:30.973663
# Unit test for function work_in_progress
def test_work_in_progress():
    import doctest
    doctest.testmod(optionflags=doctest.ELLIPSIS)


if __name__ == "__main__":
    print(__doc__)

# Generated at 2022-06-25 17:03:36.977556
# Unit test for function work_in_progress
def test_work_in_progress():
    load_file = lambda path: work_in_progress("Loading file")(load_file(path))

    obj = load_file("/path/to/some/file")
    """
    Loading file... done. (3.52s)
    """

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    """
    Saving file... done. (3.78s)
    """


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:03:46.185599
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:03:56.014507
# Unit test for function work_in_progress
def test_work_in_progress():
    from pytest import raises

    def fn(msg: str = "Unittest function") -> None:
        nonlocal called
        with work_in_progress(desc=msg):
            time.sleep(1)
        called = True

    @contextlib.contextmanager
    def errgen(msg: str = "Unittest function") -> None:
        raise RuntimeError()

    with raises(RuntimeError):
        with work_in_progress(desc="Unit test") as errgen:
            pass



# Generated at 2022-06-25 17:03:58.645839
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/fil")
    assert True

# Generated at 2022-06-25 17:04:49.986630
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test this function"):
        time.sleep(3)

# Generated at 2022-06-25 17:04:57.769356
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")
    save_file("/path/to/some/file")

# Generated at 2022-06-25 17:05:00.765452
# Unit test for function work_in_progress
def test_work_in_progress():
    tic = time.time()
    with work_in_progress(desc="Progress test"):
        time.sleep(5)
    assert time.time() - tic >= 5


# Copy-paste from SO user Khalid

# Generated at 2022-06-25 17:05:06.532215
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing work_in_progress")
    def do_nothing():
        time.sleep(0.3)
    do_nothing()

if __name__ == '__main__':
    import doctest
    doctest.testmod()
    test_work_in_progress()

# Generated at 2022-06-25 17:05:11.132960
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Counting numbers"):
        for i in range(1000000):
            _ = i**2


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:05:17.763555
# Unit test for function work_in_progress
def test_work_in_progress():
    from contextlib import redirect_stdout
    from io import StringIO

    with StringIO() as buf, redirect_stdout(buf):
        with work_in_progress("Loading file"):
            time.sleep(1)
        assert buf.getvalue() == "Loading file... done. (1.00s)\n"


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:05:21.382281
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Task")
    def task():
        time.sleep(1)

    task()

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:05:26.151275
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def do_work_2():
        time.sleep(2)

    @work_in_progress("Long running task")
    def do_work_4():
        time.sleep(4)

    do_work_2()
    do_work_4()
    with work_in_progress("Work in progress"):
        time.sleep(1.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:05:33.970633
# Unit test for function work_in_progress
def test_work_in_progress():
    from random import randint
    from .compare import compare
    from .remove_temp_file import remove_temp_file

    for i in range(4):
        number_of_iterations = randint(1, 100)
        with work_in_progress("Test work in progress %d" % i):
            for _ in range(number_of_iterations):
                pass

    @work_in_progress("Test work in progress 5")
    def f():
        for _ in range(randint(1, 40)):
            pass

    f()

    @work_in_progress("Test work in progress 6")
    def f():
        import time
        time.sleep(1)


# Generated at 2022-06-25 17:05:37.152545
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Testing test_work_in_progress")
    def test_work_in_progress_test():
        time.sleep(0.04)
    test_work_in_progress_test()

# Generated at 2022-06-25 17:07:38.126168
# Unit test for function work_in_progress
def test_work_in_progress():
    def fun():
        time.sleep(2)
    with work_in_progress("Work in progress"):
        fun()

# Generated at 2022-06-25 17:07:40.959286
# Unit test for function work_in_progress
def test_work_in_progress():
    import functools

    @work_in_progress("Sleeping for a while")
    def sleep(time_in_second):
        time.sleep(time_in_second)

    sleep(1.23)

# Generated at 2022-06-25 17:07:46.003922
# Unit test for function work_in_progress
def test_work_in_progress():
    global_var = 0

    @work_in_progress("Simulating long process")
    def simulate_long_process(n):
        global global_var
        global_var += 1
        time.sleep(n)
        return global_var

    simulate_long_process(1)

# Generated at 2022-06-25 17:07:56.422121
# Unit test for function work_in_progress
def test_work_in_progress():
    import random

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    class MyClass:
        def __init__(self, obj):
            self.obj = obj

        def serialize(self):
            return pickle.dumps(self.obj)

        @classmethod
        def deserialize(cls, data):
            cls(pickle.loads(data))


# Generated at 2022-06-25 17:08:02.413773
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test function work_in_progress() with loader function."""
    import pickle
    import tempfile

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")



# Generated at 2022-06-25 17:08:05.878568
# Unit test for function work_in_progress
def test_work_in_progress():
    def bench(n):
        for _ in range(n):
            time.sleep(1e-4)

    with work_in_progress("Benchmark"):
        bench(100_000)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:08:08.196946
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    desc = "Do something"
    with work_in_progress(desc):
        time.sleep(1.234)

# Generated at 2022-06-25 17:08:16.912006
# Unit test for function work_in_progress
def test_work_in_progress():
    try:
        @work_in_progress("Loading file")
        def load_file(path):
            with open(path, "rb") as f:
                return pickle.load(f)

        @work_in_progress()
        def save_file(path, data):
            with open(path, "wb") as f:
                pickle.dump(data, f)

        obj = load_file(__file__)
        save_file(__file__ + ".bak", obj)
    except Exception as e:
        print(e)
        exit(1)
    print("Test OK.\n")
    exit(0)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:08:24.650481
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("py_util/point.pickle")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:08:25.872031
# Unit test for function work_in_progress
def test_work_in_progress():
    assert 1 == 0