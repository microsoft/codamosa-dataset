

# Generated at 2022-06-25 16:58:55.938593
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test Case #0
    try:
        test_case_0()
    except Exception:
        print('Error Exception')
    else:
        print('Fine')

# If this script is invoked, it runs the test cases above
if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 16:59:02.167426
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 16:59:04.230988
# Unit test for function work_in_progress
def test_work_in_progress():
    # Set up test inputs
    desc = "Test Description"

    # Perform test
    test_results = work_in_progress(desc)

    # Verify test
    assert True

    return

# Generated at 2022-06-25 16:59:05.648324
# Unit test for function work_in_progress
def test_work_in_progress():
    #assert callable(work_in_progress)
    assert hasattr(work_in_progress, '__call__')


# Generated at 2022-06-25 16:59:07.612769
# Unit test for function work_in_progress
def test_work_in_progress():
    pass


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-25 16:59:10.885216
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def test_work_in_progress_func():
        time.sleep(3)
        return 5

    if( test_work_in_progress_func() != 5 ):
        print('Test Failed')


# Generated at 2022-06-25 16:59:14.090083
# Unit test for function work_in_progress
def test_work_in_progress():
    assert True


# Test with: python -m xdoctest -v base_utils.py
if __name__ == "__main__":
    import xdoctest

    xdoctest.doctest_module(__file__)

# Generated at 2022-06-25 16:59:16.724747
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        with work_in_progress():
            time.sleep(1.0)
            with work_in_progress():
                time.sleep(0.5)
                with work_in_progress():
                    time.sleep(0.25)
    with work_in_progress():
        time.sleep(3.0)
    with work_in_progress():
        time.sleep(0.25)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 16:59:19.105013
# Unit test for function work_in_progress
def test_work_in_progress():
    var_0 = work_in_progress(desc=str())
    assert True


# Generated at 2022-06-25 16:59:21.586361
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Example") as w:
        time.sleep(1)
    assert w.desc == "Example"



# Generated at 2022-06-25 16:59:30.717277
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test function work_in_progress."""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert obj == "Something"

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 16:59:41.664685
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    assert "Loading file... done. (3.52s)" in capsys.readouterr().out
    assert "Saving file... done. (3.78s)" in capsys.readouterr().out


if __name__ == "__main__":
    import pytest
    pytest.main(["-qq", "-s", "--tb=native", "-x", "--pdb", __file__])

# Generated at 2022-06-25 16:59:46.689240
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import random

    print("Testing work_in_progress()...", end='', flush=True)
    time.sleep(1)
    text = ""
    while True:
        with work_in_progress("Generating random text"):
            text += chr(random.randint(32, 126)) * 50000
        if len(text) >= 1000000:
            break
    time.sleep(1)
    print("done.")

# Generated at 2022-06-25 16:59:53.272920
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    # Time a function using work_in_progress
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(3.5)
        return True

    load_file("/path/to/some/file")

    # Time a with statement using work_in_progress
    with work_in_progress("Saving file"):
        time.sleep(3.5)

    return True

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 16:59:56.709122
# Unit test for function work_in_progress
def test_work_in_progress():
    def f():
        time.sleep(1)

    with work_in_progress("Test"):
        f()

# Generated at 2022-06-25 17:00:08.511357
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import threading

    def print_log(time_sleep):
        def inner_func():
            print("hello", end="")
            time.sleep(time_sleep)
            print("world")

        return inner_func

    time_sleep = 5
    msg = "hello world"
    try:
        with work_in_progress("Test work_in_progress: " + msg):
            print("hello")
            time.sleep(time_sleep)
            print("world")
    except KeyboardInterrupt:
        print("Interruption in function test_work_in_progress")
    else:
        with work_in_progress("Test work_in_progress in threading: " + msg):
            threading.Thread(target=print_log(time_sleep)).start()



# Generated at 2022-06-25 17:00:13.662266
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test for function `work_in_progress`"""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("test_work_in_progress.dat")

    print(f"Loaded {len(obj)} elements")


# Generated at 2022-06-25 17:00:22.033984
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    with temporary_file() as path:

        obj = load_file(path)
        save_file(path, obj)

# Generated at 2022-06-25 17:00:26.847458
# Unit test for function work_in_progress
def test_work_in_progress():
    def testfunc(a):
        time.sleep(a)

    with work_in_progress("Test"):
        testfunc(a = 1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:29.732930
# Unit test for function work_in_progress
def test_work_in_progress():
    # TODO: Add unit test
    pass


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:39.844260
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test work_in_progress")
    def load_file(path):
        time.sleep(1)
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("test_work_in_progress.pkl")
    assert obj == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-25 17:00:47.762842
# Unit test for function work_in_progress
def test_work_in_progress():
    from random import random

    @work_in_progress("Test 1")
    def test():
        time.sleep(random())

    @work_in_progress("Test 2")
    def test2():
        time.sleep(random())

    for _ in range(3):
        test()

    for _ in range(3):
        with work_in_progress("Test 3"):
            time.sleep(random())

    with work_in_progress("Test 4"):
        for _ in range(3):
            test2()

if __name__ == "__main__":
    test_work_in_progress()
    print("All tests passed successfully!")

# Generated at 2022-06-25 17:00:54.547500
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Computing"):
        time.sleep(0.6)
    print("---")
    with work_in_progress("Loading"):
        time.sleep(1.6)
    print("---")
    with work_in_progress("Processing"):
        time.sleep(3.5)
    print("---")
    with work_in_progress("Serializing"):
        time.sleep(6.9)
    print("Done.")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:58.407745
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(1)
        with work_in_progress("Subtask"):
            time.sleep(1)
        time.sleep(1)

# Generated at 2022-06-25 17:01:07.370552
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    print("Unit test for function work_in_progress:", flush=True)
    begin_time = time.time()
    load_file("/path/to/some/file")
    time_consumed = time.time() - begin_time
    print(f"{time_consumed:.2f}s", flush=True)


if __name__ == "__main__":
    import sys
    test_work_in_progress()

# Generated at 2022-06-25 17:01:09.849552
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(3.52)
    with work_in_progress("Saving file"):
        time.sleep(3.78)

# Generated at 2022-06-25 17:01:15.021798
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    with work_in_progress("Performing some task that takes 3 seconds"):
        time.sleep(3)

# Perform this unit test
if __name__ == "__main__":
    from functools import partial

    # Run unit test for this module
    test_work_in_progress()
    # Do it two times for the simple measure of CPU usage
    for i in range(2):
        # Run unit test for this module
        test_work_in_progress()

# Generated at 2022-06-25 17:01:18.648169
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    print("This line should appear after the printing of `done.`")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:01:25.469861
# Unit test for function work_in_progress
def test_work_in_progress():
    from . import rand_str

    @work_in_progress
    def fn():
        time.sleep(0.5)
        return rand_str(3)

    start_time = time.time()
    assert fn() == rand_str(3)
    assert time.time() - start_time >= 0.5

    with work_in_progress("Save file"):
        time.sleep(0.5)

    assert time.time() - start_time >= 1.0

# Generated at 2022-06-25 17:01:25.996284
# Unit test for function work_in_progress
def test_work_in_progress():
    assert True  # stub

# Generated at 2022-06-25 17:01:47.854277
# Unit test for function work_in_progress
def test_work_in_progress():
    import unittest
    import tempfile

    class TestWorkInProgress(unittest.TestCase):
        """Unit tests for function :func:`work_in_progress`."""

        def test_work_in_progress(self):
            """Test function :func:`work_in_progress`."""
            @work_in_progress("Loading file")
            def load_file(path):
                with open(path, "rb") as f:
                    return pickle.load(f)

            obj = load_file("/path/to/some/file")

            with tempfile.TemporaryDirectory() as directory:
                path = os.path.join(directory, "obj.bin")

# Generated at 2022-06-25 17:01:58.082633
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            time.sleep(0.5)
            return pickle.load(f)

    path = os.path.join(os.path.dirname(__file__), "test-utils.py")
    obj = load_file(path)
    assert isinstance(obj, types.ModuleType)
    assert obj.__name__ == "test_utils"

    with work_in_progress("Saving file"):
        time.sleep(0.5)

# Generated at 2022-06-25 17:02:01.402643
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress(desc="Performing an expensive operation"):
        time.sleep(3)
    # Output: Performing an expensive operation... done. (3.00s)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:02:08.075400
# Unit test for function work_in_progress
def test_work_in_progress():
    import random

    random_number = random.randint(1, 100)

    with work_in_progress("Random number generation"):
        time.sleep(random_number / 10)

    def random_list(n):
        with work_in_progress("Generating a list of random numbers"):
            time.sleep(random_number / 10)
            return [random.randint(1, n) for _ in range(n)]

    random_list(10)

# Generated at 2022-06-25 17:02:14.713787
# Unit test for function work_in_progress
def test_work_in_progress():
    begin_at = time.time()
    with work_in_progress("Testing work_in_progress"):
        time.sleep(2)
    time_consumed = time.time() - begin_at
    assert time_consumed >= 2.0 and time_consumed < 2.5

# Generated at 2022-06-25 17:02:16.435877
# Unit test for function work_in_progress
def test_work_in_progress():
    assert work_in_progress

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:02:20.100388
# Unit test for function work_in_progress
def test_work_in_progress():
    try:
        assert "Loading file... done. " in str(_test())
    except:
        print("All tests passed")



# Generated at 2022-06-25 17:02:29.479882
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:02:31.640099
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Saving file"):
        time.sleep(1.0)

# Generated at 2022-06-25 17:02:37.240507
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    with work_in_progress("Test work in progress"):
        time.sleep(2)

if __name__ == "__main__":
    print("Running unit test on", __file__)
    test_work_in_progress()

# Generated at 2022-06-25 17:03:12.919943
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("tests/test.bin")

    with work_in_progress("Saving file"):
        with open("tests/test.bin", "wb") as f:
            pickle.dump(obj, f)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:03:23.397766
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Some task")
    def some_task():
        time.sleep(random.uniform(0, 0.5))

    some_task()
    some_task()
    some_task()
    some_task()
    some_task()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:03:31.596445
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test for function work_in_progress."""
    print("Test for function work_in_progress.")
    @work_in_progress("Loading file")
    def load_file(path: str):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    time.sleep(2)
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:03:39.967611
# Unit test for function work_in_progress
def test_work_in_progress():
    start_time = time.time()
    with work_in_progress("Sleeping for 2 seconds") as _:
        time.sleep(2)
        assert(time.time() - start_time >= 2)
    print("test_work_in_progress OK")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:03:51.260007
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == '__main__':
    test_work_in_progress()

# =============================================================================
# Copyright 2019 by L1u Yang <https://github.com/L1uYang>. All Rights Reserved
#
# Permission to use, copy, modify, and distribute this software and its
# documentation for any purpose and without fee is hereby granted,
# provided that the above copyright notice appear in all copies and that
# both that

# Generated at 2022-06-25 17:03:57.373116
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        timer.sleep(1)
    with work_in_progress("Loading file"):
        timer.sleep(1)
        timer.sleep(1)
    with work_in_progress("Loading file"):
        timer.sleep(1)
        timer.sleep(1)
        timer.sleep(1)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:03:59.542953
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Printing something")
    def print_something():
        time.sleep(random.random() * 0.1)
        print("done.")
    print_something()

# Generated at 2022-06-25 17:04:06.410199
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Middle aged"):
        time.sleep(0.5)
    with work_in_progress("Old"):
        time.sleep(1)
    with work_in_progress("Young"):
        time.sleep(0.25)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:04:09.458836
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:04:16.674927
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    base_path = "/tmp/Pickle Test"

    with work_in_progress("Saving file"):
        with open("/tmp/Pickle Test", "wb") as fp:
            pickle.dump("Test message", fp)

    with work_in_progress("Loading file"):
        with open("/tmp/Pickle Test", "rb") as fp:
            assert pickle.load(fp) == "Test message"

    print('Passed!')

# Generated at 2022-06-25 17:05:25.729745
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import pickle
    import tempfile

    def pickle_object(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    def load_object(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with tempfile.NamedTemporaryFile(delete=False) as temp:
        with work_in_progress("Saving file"):
            pickle_object({'a': 1, 'b': 2, 'c': 3, 'd': 4, 'e': 5, 'f': 6}, temp.name)

        with work_in_progress("Loading file"):
            obj = load_object(temp.name)

    os.remove(temp.name)



# Generated at 2022-06-25 17:05:33.711982
# Unit test for function work_in_progress

# Generated at 2022-06-25 17:05:39.016542
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(obj, path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")
    save_file(obj, "/path/to/other/file")

# Generated at 2022-06-25 17:05:48.265312
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import tempfile
    import pickle
    import inspect

    with tempfile.TemporaryDirectory() as tmp_dir:
        path = os.path.join(tmp_dir, "test")
        with open(path, "wb") as f:
            pickle.dump({"a": 1, "b": 2}, f)

        @work_in_progress("Loading file")
        def load_file(path):
            with open(path, "rb") as f:
                return pickle.load(f)

        ctx = inspect.getgeneratorstate(load_file(path)).frame.f_back
        assert ctx.f_locals["desc"] == "Loading file"

# Generated at 2022-06-25 17:05:59.006823
# Unit test for function work_in_progress
def test_work_in_progress():
    """
    >>> @work_in_progress("Loading file")
    ... def load_file(path):
    ...     with open(path, "rb") as f:
    ...         return pickle.load(f)
    ...
    ... obj = load_file("/path/to/some/file")
    Loading file... done. (3.52s)
    """

    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:06:05.646048
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    # Run tests
    test_work_in_progress()

# Generated at 2022-06-25 17:06:09.370454
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""
    .. code:: python

        >>> @work_in_progress("prepare")
        ... def prepare_data():
        ...     time.sleep(1)
        ...     return 100
        >>> print(f"data = {prepare_data()}")
        prepare... done. (1.00s)
        data = 100
    """
    pass

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:06:15.065082
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1)
        return

    load_file("/path/to/some/file")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:06:23.532816
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("test_work_in_progress.pickle")
    save_file("test_work_in_progress_.pickle", obj)

# Generated at 2022-06-25 17:06:34.619562
# Unit test for function work_in_progress
def test_work_in_progress():
    import random
    import string
    import tempfile
    from io import BytesIO

    random_word = lambda n: ''.join(random.choices(string.ascii_letters, k=n))
    random_bytes = lambda n: random.getstate().digest()[:n]

    word = random_word(10)
    byte = random_bytes(10)

    path = tempfile.mktemp()

    print("Test :work_in_progress: context manager:")

    with work_in_progress("Write word to file"):
        with open(path, "w") as f:
            f.write(word)

    with work_in_progress("Write bytes to file"):
        with open(path, "wb") as f:
            f.write(byte)


# Generated at 2022-06-25 17:08:57.076648
# Unit test for function work_in_progress
def test_work_in_progress():
    from pathlib import Path
    import pickle
    from .io import touch

    with Path("/tmp/test_work_in_progress.pickle").open("wb") as f:
        pickle.dump(list(range(100)), f)

    # test context manager
    with work_in_progress("Loading file"):
        with Path("/tmp/test_work_in_progress.pickle").open("rb") as f:
            res = pickle.load(f)
            assert len(res) == 100
            assert res[0] == 0
            assert res[-1] == 99
    assert not Path("/tmp/test_work_in_progress.pickle").exists()

    # test context manager