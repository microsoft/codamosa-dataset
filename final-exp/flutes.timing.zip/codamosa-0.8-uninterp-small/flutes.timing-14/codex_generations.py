

# Generated at 2022-06-25 16:58:56.295056
# Unit test for function work_in_progress
def test_work_in_progress():
    var_0 = work_in_progress()
    assert var_0 is None


# Generated at 2022-06-25 16:58:58.978325
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("test") as var_0:
        time.sleep(1)
        var_0 = None
    assert True


# Generated at 2022-06-25 16:59:06.816578
# Unit test for function work_in_progress
def test_work_in_progress():
    dummy_0 = list(range(3))
    dummy_1 = list(range(9))
    dummy_2 = list(range(1, 5))
    dummy_3 = list(range(3))
    dummy_4 = list(range(9))
    dummy_5 = list(range(1, 5))
    dummy_6 = list(range(9))
    dummy_7 = list(range(1, 5))
    dummy_8 = list(range(3))
    dummy_9 = list(range(9))
    dummy_10 = list(range(1, 5))
    dummy_11 = list(range(3))
    dummy_12 = list(range(9))
    dummy_13 = list(range(1, 5))
    dummy_14 = list(range(3))

# Generated at 2022-06-25 16:59:10.523230
# Unit test for function work_in_progress
def test_work_in_progress():
    try:
        test_case_0()
    except Exception as e:
        logging.exception(e)
        raise(e)

    print("all tests passed")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 16:59:19.963956
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1.23)
    # Loading file... done. (1.23s)

    # Loading file... done. (1.23s)
    with work_in_progress("Loading file"):
        time.sleep(1.23)
    # Loading file... done. (1.23s)

    # Loading file... done. (1.23s)
    with work_in_progress("Loading file"):
        time.sleep(1.23)
    # Loading file... done. (1.23s)

    # Loading file... done. (1.23s)
    with work_in_progress("Loading file"):
        time.sleep(1.23)
    # Loading file... done. (1.23s)

    # Loading file... done. (1

# Generated at 2022-06-25 16:59:20.857917
# Unit test for function work_in_progress
def test_work_in_progress():
    assert var_0

# Generated at 2022-06-25 16:59:23.031753
# Unit test for function work_in_progress
def test_work_in_progress():
    test_case_0()
    test_case_1()
    test_case_2()



# Generated at 2022-06-25 16:59:28.058186
# Unit test for function work_in_progress
def test_work_in_progress():
    from random import randint

    @work_in_progress("Sorting 100 numbers")
    def sortnums():
        nums = [randint(0, 10000) for _ in range(100)]
        nums.sort()
        return nums

    nums = sortnums()


if __name__ == "__main__":
    test_case_0()
    test_work_in_progress()

# Generated at 2022-06-25 16:59:29.904752
# Unit test for function work_in_progress
def test_work_in_progress():
    assert work_in_progress() == work_in_progress()


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 16:59:31.562185
# Unit test for function work_in_progress
def test_work_in_progress():
    o = work_in_progress()


# Compiled code with context managers

# Generated at 2022-06-25 16:59:42.758176
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(1.4)
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        time.sleep(2.2)
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 16:59:50.506783
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import sys
    import tempfile

    def random_string(length: int):
        return "".join(random.choice("0123456789ABCDEF") for _ in range(length))

    original_stdout = sys.stdout

# Generated at 2022-06-25 16:59:57.636412
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# vim: ts=4:sw=4:sts=4:et:

# Generated at 2022-06-25 17:00:03.797095
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:00:12.195863
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # with work_in_progress("Saving file"):
    #     with open(path, "wb") as f:
    #         pickle.dump(obj, f)
    pass


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:17.325721
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Loading file")
    def load_file2(path):
        with open(path, "rb") as f:
            return pickle.load(f)
        time.sleep(3)

    obj = load_file("/path/to/some/file")
    obj2 = load_file2("/path/to/some/file")


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:00:20.235224
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing") as testing:
        time.sleep(1)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:23.517460
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def f():
        time.sleep(1)
    f()
    with work_in_progress():
        time.sleep(10)


# Generated at 2022-06-25 17:00:35.072689
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Processing a lot of data"):
        time.sleep(0.0034)
    with work_in_progress("Processing a little data"):
        time.sleep(0.000234)
    with work_in_progress("Processing a lot of data", precision=3):
        time.sleep(0.0034)
    with work_in_progress("Processing a little data", precision=3):
        time.sleep(0.000234)
    with work_in_progress("Processing a lot of data", precision=0):
        time.sleep(0.0034)
    with work_in_progress("Processing a little data", precision=0):
        time.sleep(0.000234)
    print("This program should run for 0.0065s.")

# Generated at 2022-06-25 17:00:44.942802
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Unit test for function work_in_progress."""
    print("-" * 80)
    print("Unit test for function work_in_progress")

    # Test context manager
    with work_in_progress("Unit test"):
        print("Test")

    # Test decorator
    @work_in_progress("Unit test")
    def test():
        print("Test")

    test()


# Command-line entry point
if __name__ == "__main__":
    # Test
    test_work_in_progress()

# Generated at 2022-06-25 17:00:54.717758
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    from .test_file_io import read_file_test

    with work_in_progress("test_work_in_progress test1"):
        time.sleep(0.01)
    
    with work_in_progress("test_work_in_progress test2"):
        read_file_test()

# Generated at 2022-06-25 17:01:05.483318
# Unit test for function work_in_progress
def test_work_in_progress():

    def load_file(path):

        time.sleep(1.4)

        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Loading file"):

        time.sleep(1.3)

    load_file = work_in_progress("Loading file")(load_file)

    with work_in_progress("Saving file"):

        time.sleep(1.7)

    with work_in_progress("Test loading file"):

        assert load_file(__file__) == open(__file__, "rb").read()

    with work_in_progress("Test loading file") as progress:

        time.sleep(0.3)
        progress.desc = "Another test"
        time.sleep(0.4)



# Generated at 2022-06-25 17:01:08.825054
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

# Generated at 2022-06-25 17:01:10.658355
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Test in progress")
    def test():
        time.sleep(0.5)
    test()


# Generated at 2022-06-25 17:01:15.460964
# Unit test for function work_in_progress
def test_work_in_progress():
    from random import randint

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open("data.pkl", "wb") as f:
            pickle.dump(randint(0, 1000), f)

    load_file("data.pkl")

# Generated at 2022-06-25 17:01:18.267303
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Sleeping for a little bit")
    def _(): time.sleep(0.2)
    _()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:26.429644
# Unit test for function work_in_progress
def test_work_in_progress():

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Loading file"):
        obj1 = load_file("/path/to/some/file")

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj1, f)

    save_file("/path/to/some/file")


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:33.188555
# Unit test for function work_in_progress
def test_work_in_progress():
    import os
    import pickle
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = {'a': 1, 'b': 2, 'c': 3}
    path = "work_in_progress.pickle"
    save_file(path)
    obj2 = load_file(path)
    assert obj == obj2
    os.remove(path)

# Generated at 2022-06-25 17:01:36.460521
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    path = os.path.realpath(__file__)
    obj = load_file(path)

# Generated at 2022-06-25 17:01:41.010500
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test context manager
    with work_in_progress("Test work_in_progress"):
        time.sleep(0.2)

    # Test decorator
    @work_in_progress("Test work_in_progress")
    def some_function():
        time.sleep(0.1)
    some_function()
if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:57.731236
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    @work_in_progress("Saving file")
    def save_file():
        time.sleep(1)
    save_file()

# Generated at 2022-06-25 17:02:04.044337
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test the work_in_progress context manager and decorator."""
    for i in range(10):
        with work_in_progress("Loading file"):
            time.sleep(0.2)
    for i in range(10):
        @work_in_progress("Saving file")
        def save_file():
            time.sleep(0.2)
        save_file()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:02:10.066964
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    file_path = "test/test_utils_work_in_progress.pickle"

    obj = load_file(file_path)
    assert isinstance(obj, dict)
    assert obj["x"] == 0.1

    with work_in_progress("Saving file"):
        with open(file_path, "wb") as f:
            pickle.dump(obj, f)

# test_work_in_progress()

# Generated at 2022-06-25 17:02:19.047794
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
            with open(path, "wb") as f:
                pickle.dump(obj, f)

# Generated at 2022-06-25 17:02:23.706451
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading data"):
        time.sleep(1)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:02:28.646166
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.1)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:02:33.233683
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Sleeping"):
        time.sleep(0.01)

    with work_in_progress("Sleeping"):
        time.sleep(0.01)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:02:41.705383
# Unit test for function work_in_progress
def test_work_in_progress():

    with work_in_progress("Loading file"):
        time.sleep(2)
    with work_in_progress("Loading file"):
        time.sleep(2)
    with work_in_progress("Loading file"):
        time.sleep(2)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    path = "/home/tunguyen/workplace/project/brain/var/tmp/test_work_in_progress.pkl"
    obj = load_file(path)
    print(obj)

# test_work_in_progress()

# Generated at 2022-06-25 17:02:51.826218
# Unit test for function work_in_progress
def test_work_in_progress():
    from os import path
    from tempfile import TemporaryDirectory
    from pickle import dumps, loads

    obj = b"This is a test"
    desc = "Saving file"

    with TemporaryDirectory() as tmpdir:
        filepath = path.join(tmpdir, "test_data")
        with work_in_progress(desc):
            with open(filepath, "wb") as f:
                f.write(dumps(obj))

    desc = "Loading file"
    with work_in_progress(desc):
        with open(filepath, "rb") as f:
            assert loads(f.read()) == obj


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:02:59.763699
# Unit test for function work_in_progress
def test_work_in_progress():
    global __all__

    # Create a function to test
    def hello():
        print("Hello, World!")

    # Test with a time consuming function
    with work_in_progress("Say Hello"):
        time.sleep(0.5)
        hello()

    # Test a short task
    with work_in_progress("Test short task"):
        pass

    # Test with a class
    class TestWithWorkInProgress:
        def __init__(self):
            pass

        @work_in_progress("Testing class")
        def work(self):
            pass

    test = TestWithWorkInProgress()
    test.work()

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:03:32.106474
# Unit test for function work_in_progress
def test_work_in_progress():
    # Test work_in_progress as a decorator
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    # Test work_in_progress as a context manager
    with work_in_progress("Saving file"):
        with open("/tmp/test.pkl", "wb") as f:
            pickle.dump(load_file("test.pkl"), f)

# Generated at 2022-06-25 17:03:37.993283
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    with work_in_progress("Processing something"):
        time.sleep(0.1)

# Generated at 2022-06-25 17:03:42.807445
# Unit test for function work_in_progress
def test_work_in_progress():
    desc = "TEST IN PROGRESS"
    with work_in_progress(desc) as w:
        pass
    assert w is None
    print(f"{desc}... done. (...s)")

# Generated at 2022-06-25 17:03:45.580116
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(0.5)

if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:03:53.734662
# Unit test for function work_in_progress
def test_work_in_progress():
    from io import StringIO

    with contextlib.redirect_stdout(StringIO()) as output:
        with work_in_progress("Testing"):
            time.sleep(1)
        assert output.getvalue() == "Testing... done. (1.00s)\n"

if __name__ == "__main__":
    # Unit test
    test_work_in_progress()

    # Demonstration
    work_in_progress_demo()

# Generated at 2022-06-25 17:04:01.387039
# Unit test for function work_in_progress
def test_work_in_progress():
    import contextlib
    import time

    @contextlib.contextmanager
    def assert_time(target_time: int):
        with assert_raises(AssertionError):
            yield
        time_consumed = time.time() - begin_time
        assert abs(time_consumed - target_time) < 0.1

    begin_time = time.time()
    with assert_time(0):
        pass
    with assert_time(0):
        print("")
    with assert_time(0.1):
        time.sleep(0.1)

# Generated at 2022-06-25 17:04:05.345024
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    with work_in_progress("Saving file"):
        time.sleep(2)


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:04:09.442099
# Unit test for function work_in_progress
def test_work_in_progress():
    """Function work_in_progress"""
    with work_in_progress(desc=None):
        pass
    with work_in_progress(desc=None):
        time.sleep(1)
    with work_in_progress(desc=None):
        time.sleep(1.5)
    with work_in_progress(desc=None):
        time.sleep(15.3)
    print(time.time())
    with work_in_progress(desc="Loading file"):
        # Fake loading file here
        time.sleep(1.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:04:19.150653
# Unit test for function work_in_progress
def test_work_in_progress():
    import pathlib
    import random
    import string
    import pickle

    class Person:

        def __init__(self, name, age):
            self.name = name
            self.age = age

        def __repr__(self):
            return "<Person: name = {}, age = {}>".format(self.name, self.age)

    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    def save_file(path, obj):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    path = pathlib.Path("/tmp/") / "".join(random.choice(string.ascii_lowercase) for _ in range(10))

    obj = load_file(path)

# Generated at 2022-06-25 17:04:24.430841
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1.0)
    with work_in_progress("Saving file"):
        time.sleep(0.5)
    print("All tests passed.")



# Generated at 2022-06-25 17:05:25.991815
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


# Generated at 2022-06-25 17:05:28.600388
# Unit test for function work_in_progress
def test_work_in_progress():
    def fn(sleep_time):
        with work_in_progress():
            time.sleep(sleep_time)

    fn(1)
    fn(0.5)
    fn(0.1)

# Generated at 2022-06-25 17:05:31.624247
# Unit test for function work_in_progress
def test_work_in_progress():
    for _ in range(3):
        with work_in_progress("Sleeping for 1 second"):
            time.sleep(1)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:05:39.185691
# Unit test for function work_in_progress
def test_work_in_progress():
    # Loading file... done (3.52s)
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file("/path/to/some/file")

    # Saving file... done (3.78s)
    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:05:41.918794
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("test_work_in_progress"):
        time.sleep(0.2)



# Generated at 2022-06-25 17:05:43.268873
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("This is a test"):
        time.sleep(1)

# Generated at 2022-06-25 17:05:45.638038
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Demo")
    def demo(n: int):
        time.sleep(n)
    demo(5)


# Generated at 2022-06-25 17:05:52.883568
# Unit test for function work_in_progress
def test_work_in_progress():

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)


if __name__ == '__main__':

    test_work_in_progress()

# Generated at 2022-06-25 17:05:54.536050
# Unit test for function work_in_progress
def test_work_in_progress():
    assert work_in_progress()

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:06:06.680785
# Unit test for function work_in_progress
def test_work_in_progress():
    import subprocess
    from os import remove
    from os.path import isfile
    from pickle import load, dump
    from tempfile import gettempdir
    from random import randint, choice
    from string import ascii_letters, digits
    from time import sleep

    tempdir = gettempdir()
    filename = f"{tempdir}/{''.join(choice(ascii_letters + digits) for _ in range(10))}.tmp"
    file_already_exist = isfile(filename)
    if file_already_exist:
        remove(filename)
        assert not isfile(filename)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return load(f)


# Generated at 2022-06-25 17:08:22.750244
# Unit test for function work_in_progress
def test_work_in_progress():
    """Run doctest on function work_in_progress."""
    import doctest
    doctest.testmod(verbose=False)

# Generated at 2022-06-25 17:08:26.132047
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Doing nothing"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:08:30.785123
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:08:41.885849
# Unit test for function work_in_progress
def test_work_in_progress():
    if not os.path.exists("/tmp/test.pickle"):
        with open("/tmp/test.pickle", "wb") as f:
            import pickle
            test_obj = object()
            pickle.dump(test_obj, f)
    with work_in_progress("Loading test.pickle"):
        with open("/tmp/test.pickle", "rb") as f:
            import pickle
            test_obj2 = pickle.load(f)
    assert test_obj == test_obj2
    with work_in_progress("Saving test.pickle"):
        with open("/tmp/test.pickle", "wb") as f:
            import pickle
            pickle.dump(test_obj, f)

# Generated at 2022-06-25 17:08:55.724369
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        # Simulate the function takes 1.5 seconds
        time.sleep(1.5)
        with open(path, "rb") as f:
            return pickle.load(f)

    # Simulate the object takes 2 seconds
    obj = load_file("/path/to/some/file")

    print("-" * 80)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)
        # Simulate the function takes 2.5 seconds
        time.sleep(2.5)

if __name__ == "__main__":
    import doctest
    doctest.testmod()

    print("-" * 80)