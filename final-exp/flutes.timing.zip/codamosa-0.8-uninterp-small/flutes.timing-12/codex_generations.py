

# Generated at 2022-06-25 16:58:59.615636
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file") as w:
        time.sleep(1)
    # assert w.time_consumed == 1, "Error"
    assert w.__exit__(None, None, None) is None, "Error"
    print("Testing for work_in_progress completed.")


if __name__ == "__main__":
    # unit test
    test_work_in_progress()

# Generated at 2022-06-25 16:59:02.942925
# Unit test for function work_in_progress
def test_work_in_progress():
    assert callable(work_in_progress), "work_in_progress is not callable"
    result = work_in_progress(desc="Work in progress")
    assert isinstance(result, contextlib.GeneratorContextManager), result
# test_work_in_progress()

# Generated at 2022-06-25 16:59:04.893476
# Unit test for function work_in_progress
def test_work_in_progress():
    var_0 = work_in_progress()
    os.system("sleep 1")
    with var_0: pass
    os.system("sleep 2")
    with var_0: pass

# Generated at 2022-06-25 16:59:06.266406
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file") as ctx:
        print("Loading file")
    with work_in_progress("Loading file"):
        print("Loading file")

# Generated at 2022-06-25 16:59:14.883202
# Unit test for function work_in_progress
def test_work_in_progress():
    assert callable(work_in_progress), "Function `work_in_progress` not callable."
    with work_in_progress("Testing for function `work_in_progress`"):
        var_0 = work_in_progress()
    assert var_0.__enter__() is None, "`work_in_progress` does not call its context manager."
    assert var_0.__exit__(None, None, None) is None, "`work_in_progress` does not call its context manager."
    print("Function `work_in_progress` passed unit test.")

if __name__ == "__main__":
    test_case_0()
    test_work_in_progress()

# Generated at 2022-06-25 16:59:16.568615
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress()
    def testing(a, b):
        time.sleep(2)
        print(a)
        print(b)
        return a + b

    assert testing(10, 20) == 30
    assert testing(10, 20) == 30
    assert testing(10, 20) == 30

# Generated at 2022-06-25 16:59:21.274448
# Unit test for function work_in_progress
def test_work_in_progress():
    begin_time = time.time()
    time.sleep(0.01)
    time_consumed = time.time() - begin_time
    with work_in_progress("Work in progress"):
        time.sleep(0.01)
    assert time_consumed < 0.02

# Generated at 2022-06-25 16:59:25.462577
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file") as var_0:
        var_0 = pickle.load("/path/to/some/file")


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 16:59:30.546832
# Unit test for function work_in_progress
def test_work_in_progress():
    assert callable(work_in_progress)

# @work_in_progress
# def test():
#     x = 1
#     x += 1
#     return x
#
# def test_2():
#     assert test() == 2
#
# def test_3():
#     assert test_2() == 2


# test_work_in_progress()

# Generated at 2022-06-25 16:59:32.169564
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(0.2)
    assert True

# Generated at 2022-06-25 16:59:45.778451
# Unit test for function work_in_progress
def test_work_in_progress():
    # Empty test case
    func_0 = work_in_progress
    assert func_0



# Generated at 2022-06-25 16:59:46.928342
# Unit test for function work_in_progress
def test_work_in_progress():
    pass


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 16:59:50.722533
# Unit test for function work_in_progress
def test_work_in_progress():
    r'''Test case for work_in_progress.
    '''
    # Define arguments to be passed to work_in_progress.
    desc = "Work in progress"

    # Get a context manager with arguments.
    with work_in_progress(desc):
        # Do the thing.
        pass



# Generated at 2022-06-25 17:00:00.501360
# Unit test for function work_in_progress
def test_work_in_progress():
    from contextlib import contextmanager
    from io import StringIO
    from unittest import TestCase, main, mock

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    class TestCase(TestCase):
        @mock.patch("time.time", return_value=0)
        def test_case_0(self, time):
            with captured_output() as (out, err):
                test_case_0()
           

# Generated at 2022-06-25 17:00:05.438898
# Unit test for function work_in_progress
def test_work_in_progress():
    list_0 = []
    list_1 = []
    # Statement coverage testing
    list_0.append(work_in_progress())
    # Branch coverage testing
    if (1 == 1):
        list_1.append(work_in_progress())
    else:
        list_1.append(work_in_progress())

# Generated at 2022-06-25 17:00:07.555715
# Unit test for function work_in_progress
def test_work_in_progress():
    test_case_0()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:00:09.016977
# Unit test for function work_in_progress
def test_work_in_progress():
    with pytest.raises(Exception) as e:
        test_case_0()

# Generated at 2022-06-25 17:00:11.690409
# Unit test for function work_in_progress
def test_work_in_progress():
    path = "test_file.txt"
    with work_in_progress("Test case 0"):
        test_case_0()
    print()

# Generated at 2022-06-25 17:00:19.661543
# Unit test for function work_in_progress
def test_work_in_progress():
    var_0 = work_in_progress("Loading file")
    def func_0(param_0):
        var_0 = open(param_0, "rb")
        with contextlib.closing(var_0) as var_0:
            return pickle.load(var_0)
    obj = func_0("/path/to/some/file")
    var_1 = work_in_progress("Saving file")
    with contextlib.closing(var_1):
        var_2 = open(path, "wb")
        with contextlib.closing(var_2) as var_2:
            pickle.dump(obj, var_2)


# Generated at 2022-06-25 17:00:25.102915
# Unit test for function work_in_progress
def test_work_in_progress():

    # Check type of __return__
    assert isinstance(work_in_progress(), contextlib.AbstractContextManager), \
        f"Expected {contextlib.AbstractContextManager}, but got {type(work_in_progress())}"


if __name__ == "__main__":
    # Run the unit tests
    print("[*] Running unit tests for module '{}'".format(__file__))
    import doctest

    doctest.testmod()

# Generated at 2022-06-25 17:00:35.776776
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing work_in_progress... ", end='', flush=True)

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    # No test for the content of obj

    with work_in_progress("Saving file"):
        path = "/path/to/some/file"
        with open(path, "wb") as f:
            pickle.dump(obj, f)
    # No test for the content of the file

    print("pass.")


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:00:38.408164
# Unit test for function work_in_progress
def test_work_in_progress():
    t = time.time()
    with work_in_progress("Test work_in_progress"):
        time.sleep(3)
    assert time.time() - t > 2

# Generated at 2022-06-25 17:00:39.834234
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        pass

# Generated at 2022-06-25 17:00:42.543183
# Unit test for function work_in_progress
def test_work_in_progress():
    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:00:50.066063
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Automated test for :func:`work_in_progress`.
    """
    out = io.StringIO()
    with contextlib.redirect_stdout(out):
        with work_in_progress("Foo"):
            time.sleep(1)
    assert out.getvalue().rstrip() == "Foo... done. (1.00s)"


# =============================================================================
# Main routine
# =============================================================================

if __name__ == "__main__":
    pass

# Generated at 2022-06-25 17:00:55.167572
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Work in progress 1")
    def foo():
        time.sleep(1)

    @work_in_progress("Work in progress 2")
    def bar():
        with work_in_progress("Work in progress 3"):
            time.sleep(1)
        time.sleep(1)

    foo()
    bar()
# test_work_in_progress()

# Generated at 2022-06-25 17:00:59.167206
# Unit test for function work_in_progress
def test_work_in_progress():
    import time

    @work_in_progress("Test: sleep 2")
    def test():
        time.sleep(2)

    test()


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 17:01:01.988145
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing") as x:
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:05.079021
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.5)
    print("end of testing")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:06.630894
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Test work_in_progress"):
        time.sleep(1)

# Generated at 2022-06-25 17:01:13.323072
# Unit test for function work_in_progress
def test_work_in_progress():
    print("Testing work_in_progress...")
    with work_in_progress("Testing"):
        time.sleep(1)
    print("Done.")

print(__doc__)

# Generated at 2022-06-25 17:01:16.909448
# Unit test for function work_in_progress
def test_work_in_progress():
    def foo():
        with work_in_progress("Loading file"):
            time.sleep(1.23)
    def bar():
        with work_in_progress("Saving file"):
            time.sleep(4.56)

    foo()
    bar()
    print("Done.")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:27.126167
# Unit test for function work_in_progress
def test_work_in_progress():
    import pickle
    from pathlib import Path
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as d:
        path = Path(d) / "data.pickle"

        @work_in_progress("Loading file")
        def load_file(path):
            with open(path, "rb") as f:
                return pickle.load(f)

        @work_in_progress("Saving file")
        def save_file(path, data):
            with open(path, "wb") as f:
                pickle.dump(data, f)

        data = [
            ("foo", [1, 2, 3]),
            ("bar", {"a": 1, "b": 2}),
            ("baz", {"key", "value"}),
        ]
        save_file(path, data)
        assert load_

# Generated at 2022-06-25 17:01:32.021164
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path: str = './dask.py'):
        with open(path, "rb") as f:
            return pickle.load(f)
    obj = load_file()
    assert isinstance(obj, str)

    with work_in_progress("Saving file"):
        with open('test.py', "wb") as f:
            pickle.dump(obj, f)


# Generated at 2022-06-25 17:01:34.373278
# Unit test for function work_in_progress
def test_work_in_progress():
    """test_work_in_progress"""
    with work_in_progress("Testing"):
        time.sleep(0.5)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:01:37.541183
# Unit test for function work_in_progress
def test_work_in_progress():

    with work_in_progress("Saving file"):
        time.sleep(1)

    @work_in_progress("Loading file")
    def func():
        time.sleep(1)

    func()

# Generated at 2022-06-25 17:01:44.179736
# Unit test for function work_in_progress
def test_work_in_progress():
    def mock_func(*, desc: str = "Mocking the execution"):
        with work_in_progress(desc):
            time.sleep(1.0)

    mock_func()


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:01:46.186777
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Unit test")
    def unit_test_function():
        time.sleep(2)

    with work_in_progress():
        time.sleep(3)

    unit_test_function()

# Generated at 2022-06-25 17:01:58.994610
# Unit test for function work_in_progress
def test_work_in_progress():
    test_time_consumed = 3.452
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(test_time_consumed)
        return True

    assert load_file(str())
    s = io.StringIO()
    sys.stdout = s
    load_file(str())
    assert "Loading file... done. (" in s.getvalue()
    assert f"({test_time_consumed:.2f}s)" in s.getvalue()
    s.close()

    with work_in_progress("Saving file"):
        time.sleep(test_time_consumed)
    s = io.StringIO()
    sys.stdout = s

# Generated at 2022-06-25 17:02:06.737404
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import sys
    reload(sys)
    sys.setdefaultencoding('utf8')

    with work_in_progress():
        time.sleep(1)
    #
    # with work_in_progress("Loading file"):
    #     time.sleep(1)
    #
    # @work_in_progress("Loading file")
    # def load_file():
    #     time.sleep(1)
    #
    # load_file()


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:02:27.035533
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return 1

    with work_in_progress("Loading file"):
        obj = load_file("/Users/sijiecao/Documents/NeurIPS_challenge_2019/Robot_learning_scene_graphs/graph_utils/graph_utils.py")

    def save_file(path):
        with open(path, "wb") as f:
            return f

    with work_in_progress("Saving file"):
        obj = save_file("/Users/sijiecao/Documents/NeurIPS_challenge_2019/Robot_learning_scene_graphs/graph_utils/graph_utils.py")

# Generated at 2022-06-25 17:02:31.175465
# Unit test for function work_in_progress
def test_work_in_progress():
    for _ in range(10):
        with work_in_progress("Sleeping..."):
            time.sleep(0.5)

if __name__ == '__main__':
    def main():
        test_work_in_progress()

    main()

# Generated at 2022-06-25 17:02:39.939375
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

    obj = load_file("/path/to/some/file")
    save_file("/path/to/some/file")

    print("=== Testing work_in_progress done. ===")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:02:45.155601
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Loading file"):
        time.sleep(1)
    with work_in_progress("Saving file"):
        time.sleep(2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:02:52.953687
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""Test the function work_in_progress."""
    from pathlib import Path
    from typing import Callable
    from pychro.test.testutil import is_close

    @work_in_progress("Loading file")
    def load_file(path: Path) -> None:
        with open(path, "rb") as f:
            return pickle.load(f)

    def test_decorator(func: Callable) -> None:
        path = Path("data/test.pkl")
        func(path)
        with work_in_progress("Saving file"):
            with open(path, "wb") as f:
                pickle.dump(path, f)

    test_decorator(load_file)



# Generated at 2022-06-25 17:02:58.088601
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    time.sleep(0.1)

# Generated at 2022-06-25 17:03:09.308784
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Loading file"):
        assert load_file("saved") == {"foo": "bar"}

    @work_in_progress("Saving file")
    def save_file(path):
        with open(path, "wb") as f:
            pickle.dump({"foo": "bar"}, f)
    save_file("saved")
test_work_in_progress()

# Generated at 2022-06-25 17:03:18.508295
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test work_in_progress.
    """
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")
    assert obj is not None

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:03:24.824803
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Mock task")
    def _mock_task(time_cost):
        time.sleep(time_cost)
        return 0

    _mock_task(2)

    with work_in_progress("Mock task"):
        time.sleep(2)

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:03:30.458737
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with patch("sys.stdout", new=StringIO()) as fake_stdout:
        obj = load_file("/path/to/some/file")

    assert fake_stdout.getvalue() == "Loading file... done. (0.23s)\n"

# Generated at 2022-06-25 17:03:56.730915
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Saving file")
    def save_file(path, content):
        with open(path, "wb") as f:
            f.write(b"test")

    save_file("test.txt", b"test")


if __name__ == '__main__':
    test_work_in_progress()

# Generated at 2022-06-25 17:03:59.293110
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Testing work_in_progress"):
        time.sleep(0.05)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:04:07.550996
# Unit test for function work_in_progress
def test_work_in_progress():
    from contextlib import contextmanager

    @contextmanager
    def long_action():
        time.sleep(0.1)
        yield

    @contextmanager
    def work_in_progress(desc: str = "Work in progress"):
        start = time.time()
        yield
        time_consumed = time.time() - start
        print(f"{desc}... done. ({time_consumed:.2f}s)")

    with work_in_progress("Loading file"):
        with long_action():
            pass
    # Loading file... done. (0.10s)

# Generated at 2022-06-25 17:04:17.979670
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit test for function work_in_progress"""
    print("work_in_progress")

    class TestClass:
        """Test class to demonstrate usage of work_in_progress decorator"""
        def __init__(self, lst):
            self.lst = lst
            self.sum_ = sum(lst)
            self.total_ = len(lst)
            print(f"Initialized {self}")

        def __str__(self):
            return f"TestClass(sum={self.sum_}, total={self.total_})"

        @work_in_progress("TestClass::__init__ (work_in_progress)")
        def __init__(self, lst):
            self.lst = lst
            self.sum_ = sum(lst)

# Generated at 2022-06-25 17:04:25.272454
# Unit test for function work_in_progress
def test_work_in_progress():
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Loading file"):
        obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:04:32.079238
# Unit test for function work_in_progress
def test_work_in_progress():
    """Test work_in_progress()."""
    with work_in_progress("Walking dog"):
        import time
        time.sleep(1)
        print("Dog barking")
        time.sleep(2)
    assert 1
    print("Done")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:04:37.350377
# Unit test for function work_in_progress
def test_work_in_progress():
    from time import sleep
    print("Test 1")
    with work_in_progress():
        sleep(1.5)
    print("Test 2")
    with work_in_progress("test"):
        sleep(1.5)
    print("Test 3")
    @work_in_progress()
    def test3():
        sleep(1.5)
    test3()

if __name__ == '__main__':  # pragma: no cover
    test_work_in_progress()

# Generated at 2022-06-25 17:04:45.622379
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# vim:sw=4:ts=4:et:

# Generated at 2022-06-25 17:04:48.968703
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open("/path/to/some/file", "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:04:57.848301
# Unit test for function work_in_progress
def test_work_in_progress():
    """Run unit test on function work_in_progress."""
    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:05:52.111121
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress("Running tests"):
        time.sleep(1)


if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:05:59.638831
# Unit test for function work_in_progress
def test_work_in_progress():
    """Testing work_in_progress."""
    case_1 = {
        "desc": "Loading file",
        "we_expected": """Loading file... done. (1.00s)"""
    }

    with work_in_progress(case_1["desc"]):
        time.sleep(1)

# Generated at 2022-06-25 17:06:05.503698
# Unit test for function work_in_progress
def test_work_in_progress():
    # this function holds no information and is not useful in any way,
    # it just takes some time to be evaluated.
    @work_in_progress()
    def _do_nothing(x):
        i = 0
        for _ in range(10000000):
            i += 1 / x
        return i

    assert _do_nothing(2) == 5000000.0

# Generated at 2022-06-25 17:06:08.058831
# Unit test for function work_in_progress
def test_work_in_progress():
    r"""
    .. code:: python

        >>> with work_in_progress("Saving file"):
        ...     time.sleep(3.78)
        Saving file... done. (3.78s)
    """
    pass

# Generated at 2022-06-25 17:06:14.159196
# Unit test for function work_in_progress
def test_work_in_progress():
    def dummy_process(items):
        result = []
        for item in items:
            with work_in_progress("Doing some processing on item"):
                time.sleep(0.1)
                result.append(item)
        return result

    items = list(range(10))
    result = dummy_process(items)
    assert result == items

# Generated at 2022-06-25 17:06:20.418948
# Unit test for function work_in_progress
def test_work_in_progress():
    import time
    import pickle

    @work_in_progress("Loading file")
    def load_file(path):
        with open(path, "rb") as f:
            return pickle.load(f)

    obj = load_file("/path/to/some/file")

    with work_in_progress("Saving file"):
        with open(path, "wb") as f:
            pickle.dump(obj, f)

# Generated at 2022-06-25 17:06:24.547324
# Unit test for function work_in_progress
def test_work_in_progress():
    import tempfile

    @work_in_progress("Testing work_in_progress")
    def _test_work_in_progress():
        with tempfile.TemporaryDirectory(prefix="test_work_in_progress") as d:
            print(d)
        pass

    _test_work_in_progress()
    return True

# Generated at 2022-06-25 17:06:28.662159
# Unit test for function work_in_progress
def test_work_in_progress():
    with work_in_progress():
        time.sleep(0.01)

# Generated at 2022-06-25 17:06:40.788233
# Unit test for function work_in_progress
def test_work_in_progress():
    test_file_name = "test_file.txt"
    test_file_content = "Test file content"

    # Test 1: with block
    with work_in_progress("Writing file"):
        with open(test_file_name, "w") as test_file:
            test_file.write(test_file_content)

    with work_in_progress("Reading file"):
        with open(test_file_name, "r") as test_file:
            assert test_file.read() == test_file_content

    # Test 2: as decorator
    @work_in_progress("Writing file")
    def write_file(file_name: str, content: str):
        with open(file_name, "w") as test_file:
            test_file.write(content)


# Generated at 2022-06-25 17:06:48.640227
# Unit test for function work_in_progress
def test_work_in_progress():
    @work_in_progress("Loading file")
    def load_file(path):
        time.sleep(2)
        return 
    load_file("/path/to/file.txt")

if __name__ == "__main__":
    test_work_in_progress()

# Generated at 2022-06-25 17:08:51.556753
# Unit test for function work_in_progress
def test_work_in_progress():
    """Unit tests for function work_in_progress
    """
    with work_in_progress("Testing work_in_progress()") as _:
        time.sleep(1.5)