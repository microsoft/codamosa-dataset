

# Generated at 2022-06-25 00:13:17.655594
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.collect() == {}

# Generated at 2022-06-25 00:13:21.970081
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    
    if test_case_0() == None:
        print("LocalFactCollector_TestCase_0::PASS")
        
# Generates test case method, which would be called by the test runner    

# Generated at 2022-06-25 00:13:26.961050
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert repr(local_fact_collector_0) == '<ansible.module_utils.facts.local.LocalFactCollector object at 0x7f0a2da0fd68>'
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:13:32.300770
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    # TEST CASE: call collect to fetch local facts.
    #assert local_fact_collector_0.collect()
    print("test_LocalFactCollector_collect called")


# Generated at 2022-06-25 00:13:35.671413
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1 is not None


# Generated at 2022-06-25 00:13:37.966248
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()

# Generated at 2022-06-25 00:13:40.834258
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = 'ansible'
    fact_path = os.path.join(os.path.dirname(__file__), 'data')
    params = {'fact_path': fact_path}

# Create an instance of the LocalFactCollector class
# and use it to invoke method collect on params
    local_fact_collector_1 = LocalFactCollector()
    facts = local_fact_collector_1.collect(module, params)
# test if collected facts contains local
    assert 'local' in facts

# Generated at 2022-06-25 00:13:45.736825
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    print('FILE:')
    print(os.path.basename(__file__))
    print('NAME:')
    print(__name__)
    print('TEST_CASE_0:')
    print('Expect None')
    print('Actual:')
    print(test_case_0())

# Generated at 2022-06-25 00:13:47.434003
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    module_0 = None
    collected_facts_0 = None
    local_facts_0 = local_fact_collector_1.collect(module_0, collected_facts_0)
    assert local_facts_0 == {}


# Generated at 2022-06-25 00:13:51.492433
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert_equals(local_fact_collector.name, 'local')

# Generated at 2022-06-25 00:14:08.497131
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    local_facts = local_fact_collector_1.collect()
    assert (len(local_facts) > 0)



# Generated at 2022-06-25 00:14:10.545500
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Testing if the variable name holds the right value
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1.name == 'local'


# Generated at 2022-06-25 00:14:11.838024
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    obj = LocalFactCollector()
    assert obj is not None, "Failed to create LocalFactCollector object"


# Generated at 2022-06-25 00:14:14.671986
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    module = AnsibleModule(dict())
    local_fact_collector_0 = LocalFactCollector()
    local_facts = local_fact_collector_0.collect(module)
    assert isinstance(local_facts, dict), "return object is a instance of dict"
    assert len(local_facts)>0, "Local Fact path is set"
    assert local_facts['local'] == {}, "Fact path does not exist"

# Generated at 2022-06-25 00:14:16.004562
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        local_fact_collector = LocalFactCollector()
    except Exception:
        assert False


# Generated at 2022-06-25 00:14:19.410172
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'



# Generated at 2022-06-25 00:14:21.526588
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:14:22.840585
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    collect_0 = LocalFactCollector()
    collect_0.collect()


# Generated at 2022-06-25 00:14:25.253008
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1.name == 'local'
    assert not local_fact_collector_1._fact_ids


# Generated at 2022-06-25 00:14:30.489803
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """
    Unit test for method "collect" of class "LocalFactCollector"
    """
    collector_instance = LocalFactCollector()
    ansible_module_instance = AnsibleModule(argument_spec=dict(fact_path='/etc/ansible/facts.d', filters='*'))
    result_from_local_facts_collector = collector_instance.collect(module=ansible_module_instance)
    assert 'local' in result_from_local_facts_collector

# Generated at 2022-06-25 00:14:56.417787
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert isinstance(local_fact_collector._fact_ids, set)


# Generated at 2022-06-25 00:14:58.184315
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector(
        #AnsibleModule = None,
        #collected_facts = None
    )

# Generated at 2022-06-25 00:15:00.946123
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()

    local_facts_0 = local_fact_collector_0.collect()

    assert local_facts_0 is not None


# Generated at 2022-06-25 00:15:03.202280
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == "local"
    assert isinstance(local_fact_collector._fact_ids,set)


# Generated at 2022-06-25 00:15:05.385437
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'
    assert isinstance(LocalFactCollector._fact_ids, set)
    assert LocalFactCollector._fact_ids == set()

# Generated at 2022-06-25 00:15:06.793353
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    local_fact_collector.collect()

# Generated at 2022-06-25 00:15:08.151720
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # test_case_0
    local_fact_collector_0 = LocalFactCollector()

# Generated at 2022-06-25 00:15:08.950798
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert test_case_0() == None

# Generated at 2022-06-25 00:15:09.699543
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:15:11.416903
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert isinstance(LocalFactCollector(), LocalFactCollector)
# if __name__ == "__main__":
#     test_case_0()
#     test_LocalFactCollector()

# Generated at 2022-06-25 00:16:02.100325
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    file_1 = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))) + "/module_utils/facts/local/testcase.fact"
    file_2 = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))) + "/module_utils/facts/local/testcase2.fact"
    file_3 = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))) + "/module_utils/facts/local/testcase3.fact"

    if os.path.exists(file_1)==False:
        f = open(file_1, "w+")
        f.write

# Generated at 2022-06-25 00:16:02.861476
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()


# Generated at 2022-06-25 00:16:04.705069
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert_check_for_whitelisted_facts = True


# Generated at 2022-06-25 00:16:07.893347
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:16:09.456308
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    result = LocalFactCollector()
    assert(result is not None)

# Generated at 2022-06-25 00:16:12.750582
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_1.collect()


# Generated at 2022-06-25 00:16:17.555917
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Arrange
    local_fact_collector_0 = LocalFactCollector()
    module_0 = None
    collected_facts_0 = None

    expected = {'local': {}}
    # Act
    actual = local_fact_collector_0.collect(module_0, collected_facts_0)

    # Assert
    assert expected == actual

# Generated at 2022-06-25 00:16:20.362306
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    local_facts = local_fact_collector_1.collect()
    assert isinstance(local_facts, dict)
    assert 'local' in local_facts
    assert isinstance(local_facts['local'], dict)

# Run tests
test_case_0()
test_LocalFactCollector_collect()

# Generated at 2022-06-25 00:16:24.724288
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Test case 1: run collect method of LocalFactCollector without any input
    local_facts = LocalFactCollector().collect(fact_path='/tmp/facts')

    # Test case 2: Ensure that local fact collector returned a dictionary
    assert isinstance(local_facts, dict), "Expected a dictionary"
    assert 'local' in local_facts, "Expected a local fact"

# Generated at 2022-06-25 00:16:25.693260
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()

# Generated at 2022-06-25 00:17:24.059272
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    print ("LocalFactCollector unit test: Start")
    test_case_0()
    print ("LocalFactCollector unit test: Completed")

if __name__ == '__main__':
    test_LocalFactCollector()

# Generated at 2022-06-25 00:17:31.839370
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    def run_collect(module, fact_path):
        local_fact_collector = LocalFactCollector()
        local_facts = local_fact_collector.collect(module, fact_path)
        return local_facts

    class TestModule(object):
        def __init__(self, params=None):
            self.params = {'fact_path': '/tmp'}
            if params:
                self.params.update(params)

        def warn(self, warning_msg):
            print(warning_msg)

        def run_command(self, cmd):
            print(cmd)
            return 0, "cmd output", "cmd error"

    class TestFactModule(object):
        def __init__(self, params=None):
            self.params = {'fact_path': '/tmp'}

# Generated at 2022-06-25 00:17:33.468613
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.name = 'local'
    local_fact_collector_0.collect()

# Generated at 2022-06-25 00:17:35.994764
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()

    assert len(local_fact_collector_1.collect()) == 1
    assert len(local_fact_collector_1.collect().keys()) == 1

    local_fact_collector_1._fact_ids = set([])


# Generated at 2022-06-25 00:17:37.717722
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()

    # print(local_fact_collector_0)
    local_fact_collector_0.collect()

test_case_0()
test_LocalFactCollector_collect()

# Generated at 2022-06-25 00:17:40.825966
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    collector_0 = LocalFactCollector()
    assert collector_0.name == 'local'
    assert len(collector_0._fact_ids) == 1


# Generated at 2022-06-25 00:17:43.581066
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'
    assert type(LocalFactCollector.name) == str

# Generated at 2022-06-25 00:17:46.689637
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    print("Test 0: Constructor of class LocalFactCollector")
    test_case_0()
   
if __name__ == '__main__':
    test_LocalFactCollector()

# Generated at 2022-06-25 00:17:48.794037
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    TestCase_0()

# Generated at 2022-06-25 00:17:50.500049
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # collect should return a dict
    assert isinstance(local_fact_collector_0.collect(), dict)

# Generated at 2022-06-25 00:18:51.740651
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set([])


# Generated at 2022-06-25 00:18:55.728718
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'

    local_fact_collector_0 = LocalFactCollector()
    assert not local_fact_collector_0.collected_facts

# Generated at 2022-06-25 00:18:59.689571
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_fd_fd = LocalFactCollector()
    local_fact_collector_fd_fd.collect()



# Generated at 2022-06-25 00:19:01.163287
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1.collect() is None


# Generated at 2022-06-25 00:19:06.813675
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert hasattr(LocalFactCollector, '_fact_ids'), "LocalFactCollector() doesn't have '_fact_ids' property"
    assert hasattr(LocalFactCollector, 'name'), "LocalFactCollecctor() doesn't have 'name' property"
    assert hasattr(LocalFactCollector, 'collect'), "LocalFactCollecctor() doesn't have 'collect' property"
    assert LocalFactCollector().name == 'local', "LocalFactCollector() property 'name' should equal 'local'"
    assert isinstance(LocalFactCollector()._fact_ids, set), "LocalFactCollector() property '_fact_ids' should be a 'set' object"

# Generated at 2022-06-25 00:19:12.019166
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_2 = LocalFactCollector()
    var_2 = local_fact_collector_2.collect()


# Generated at 2022-06-25 00:19:15.012481
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:19:19.861207
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()
    assert var_0 == {}, 'Unexpected collect() return value'


# Generated at 2022-06-25 00:19:23.078709
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.name
    assert var_0 == 'local'
    var_1 = local_fact_collector_0._fact_ids
    var_2 = local_fact_collector_0.name
    assert var_2 == var_1


# Generated at 2022-06-25 00:19:25.349381
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()

    local_fact_collector_0.collect()

# Generated at 2022-06-25 00:21:46.786377
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert_true(True)

# Generated at 2022-06-25 00:21:49.178713
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    local_fact_collector = LocalFactCollector()
    local_fact_collector = LocalFactCollector()


# Generated at 2022-06-25 00:21:53.450999
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()
    assert isinstance(var_0, dict)

# Generated at 2022-06-25 00:21:54.141601
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert callable(LocalFactCollector)

# Generated at 2022-06-25 00:21:57.243159
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fact_collector = LocalFactCollector()
    fact_collector._fact_ids.add('a')
    assert fact_collector.collect() == {'local': {'a': None}}

# Generated at 2022-06-25 00:21:59.426701
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()


# Generated at 2022-06-25 00:22:01.342661
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    var = LocalFactCollector()
    var.collect()

    # Test for equality and check for type.
    assert type(var.collect()) == dict

# Generated at 2022-06-25 00:22:02.967411
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert isinstance(local_fact_collector_1, LocalFactCollector)


# Generated at 2022-06-25 00:22:05.410512
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    var_1 = local_fact_collector_1.collect()
    assert var_1 == {'local': {}}

# Generated at 2022-06-25 00:22:08.782343
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    print('test_LocalFactCollector_collect')
    # Test case 0
    test_case_0()
