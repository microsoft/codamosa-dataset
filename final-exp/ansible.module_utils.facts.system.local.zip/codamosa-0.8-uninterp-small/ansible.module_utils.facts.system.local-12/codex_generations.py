

# Generated at 2022-06-25 00:13:17.930454
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    FactCollector = local_fact_collector_0.collect()
    assert FactCollector == {}

# Generated at 2022-06-25 00:13:24.919151
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert len(local_fact_collector_0._fact_ids) == 0
    assert local_fact_collector_0._fact_ids == set([])
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0.collect() == {'local': {}}


# Generated at 2022-06-25 00:13:27.863994
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()
    local_fact_collector_0.get_facts()
    #assert local_fact_collector_0.facts == {}


# Generated at 2022-06-25 00:13:29.907814
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()


# Generated at 2022-06-25 00:13:34.232137
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    local_fact_collector_1 = local_fact_collector.collect()
    assert local_fact_collector_1 is not None

# Generated at 2022-06-25 00:13:38.750062
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    fact_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'testdata', 'facts', 'local')
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect({'fact_path': fact_path})

# Generated at 2022-06-25 00:13:44.912500
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    # Test with a module_0 that returns an empty local fact
    local_facts_0 = local_fact_collector.collect(module=None, collected_facts=None)
    assert local_facts_0 == {'local': {}}
    # Test with a module_1 that returns a local fact
    local_facts_1 = local_fact_collector.collect(module=None, collected_facts=None)
    assert local_facts_1 == {'local': {}}

# Generated at 2022-06-25 00:13:49.473021
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_facts = local_fact_collector_0.collect()
    assert local_facts

# Generated at 2022-06-25 00:13:55.090155
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fail = False

    local_fact_collector = LocalFactCollector()
    if str(local_fact_collector) != '<ansible.module_utils.facts.local.LocalFactCollector object at 0x7f6fbca84828>':
        fail = True

    if local_fact_collector.name != 'local':
        fail = True

    if fail:
        raise AssertionError('test_LocalFactCollector() failed')

# Generated at 2022-06-25 00:13:57.071743
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    print('Executing test case 0')
    test_case_0()

if __name__ == '__main__':
    test_LocalFactCollector_collect()

# Generated at 2022-06-25 00:14:05.279801
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    local_facts = local_fact_collector.collect()
    local_facts.pop("local")
    assert len(local_facts) == 0

# Generated at 2022-06-25 00:14:07.952447
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """
    collect:

    @param module:
    @param collected_facts:
    @return:
    """
    assert True


# Generated at 2022-06-25 00:14:09.232667
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector is not None


# Generated at 2022-06-25 00:14:13.010550
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # In this test case, ansible_local facts on the host has been collected
    local_fact_collector_1 = LocalFactCollector()
    ansible_local_facts = local_fact_collector_1.collect(module=None, collected_facts=None)
    assert isinstance(ansible_local_facts, dict)
    assert 'local' in ansible_local_facts.keys()

# Generated at 2022-06-25 00:14:14.421497
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_1.collect()

# Generated at 2022-06-25 00:14:15.377586
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()


# Generated at 2022-06-25 00:14:22.075472
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    # Setting up mock data for testing input parameters of method collect of class LocalFactCollector
    local_fact_collector_0 = LocalFactCollector()
    module = None
    collected_facts = None

    # Checking if method collect of class LocalFactCollector is working properly
    local_facts = local_fact_collector_0.collect(module, collected_facts)
    assert local_facts == {"local": {}}, "Method 'LocalFactCollector_collect' of class 'LocalFactCollector' is not working properly"

# Generated at 2022-06-25 00:14:25.584832
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    local_facts = {}
    local_facts['local'] = {}
    assert local_fact_collector.collect(local_facts) == local_facts


# Generated at 2022-06-25 00:14:27.401927
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()

    local_fact_collector_1.collect()

# Generated at 2022-06-25 00:14:30.557286
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert('local' == local_fact_collector_1.name)
    assert(set() == local_fact_collector_1._fact_ids)
    local_fact_collector_1.collect()


# Generated at 2022-06-25 00:14:45.227747
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()

    # Test collect method
    assert local_fact_collector.collect() == {'local': {}}

# Generated at 2022-06-25 00:14:48.356177
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-25 00:14:50.060130
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert('local' == local_fact_collector_1.name)


# Generated at 2022-06-25 00:14:53.010120
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Testing with only required parameters
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1.collect() == {'local': {}}


if __name__ == '__main__':
    test_case_0()
    test_LocalFactCollector_collect()

# Generated at 2022-06-25 00:14:56.645239
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1.name == 'local'
    assert local_fact_collector_1._fact_ids == set()


# Generated at 2022-06-25 00:14:59.408693
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()

    assert(local_fact_collector_0.name == 'local')
    assert(local_fact_collector_0.collect() == {'local': {}})

# Generated at 2022-06-25 00:15:02.333311
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        local_fact_collector_0 = LocalFactCollector()
        test_case_0()
    except Exception as err:
        print("Testcase 0 Failed: " + str(err))
        raise


# Generated at 2022-06-25 00:15:03.897431
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    obj1 = LocalFactCollector()
    assert isinstance(obj1, LocalFactCollector)


# Generated at 2022-06-25 00:15:05.558506
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0


# Generated at 2022-06-25 00:15:08.915247
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()

    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()


if __name__ == '__main__':
    test_case_0()
    test_LocalFactCollector()

# Generated at 2022-06-25 00:15:35.549707
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert isinstance(local_fact_collector, LocalFactCollector)

# Generated at 2022-06-25 00:15:41.915426
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    collector = LocalFactCollector()
    fact_path = 'testdata/'
    module = {'params': {'fact_path': fact_path, 'gather_subset': '!all'}, 'warn': print, 'run_command': os.system, 'debug': print}

    collected_facts_0 = {
    'local': {
                'fact_file_path': 'testdata/fact_file.fact',
                'fact_file_path_2': 'testdata/fact_file_2.fact'
            }
        }

    facts_0 = collector.collect(module)
    assert facts_0 == collected_facts_0, 'incorrect facts were gathered'

# Generated at 2022-06-25 00:15:43.563384
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    localFactCollector = LocalFactCollector()
    localFactCollector.collect()

# Generated at 2022-06-25 00:15:46.199071
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'
    local_fact_collector_0 = LocalFactCollector()
    assert not local_fact_collector_0._fact_ids

# Generated at 2022-06-25 00:15:47.826644
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector is not None

# Generated at 2022-06-25 00:15:52.064823
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        local_fact_obj = LocalFactCollector()
    except Exception:
        assert False
    else:
        assert True

# Generated at 2022-06-25 00:15:54.635797
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:15:57.376238
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:16:02.862182
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    fact_path = './ansible/module_utils/ansible_local.fact/'
    collected_facts = local_fact_collector.collect(None, None)
    assert collected_facts == {'local': {}}

    collected_facts = local_fact_collector.collect(None, None, fact_path)
    assert collected_facts == {'local': {}}

    fact_path = fact_path + 'not.exist'
    collected_facts = local_fact_collector.collect(None, None, fact_path)
    assert collected_facts == {'local': {}}

    fact_path = './ansible/module_utils/ansible_local.fact/'

# Generated at 2022-06-25 00:16:09.430789
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Store parameters passed to the module
    module_args = dict()

    local_fact_collector_0 = LocalFactCollector(module=None, collected_facts=None)
    assert local_fact_collector_0
    module_params = local_fact_collector_0.module_params == module_args
    assert module_params

if __name__ == '__main__':
    test_case_0()
    test_LocalFactCollector()

# Generated at 2022-06-25 00:17:16.141729
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        LocalFactCollector()
    except:
        assert False



# Generated at 2022-06-25 00:17:18.765443
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0._fact_ids == set()
    assert local_fact_collector_0.name == 'local'

# Generated at 2022-06-25 00:17:28.429533
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()

    local_facts = {}
    local_facts['local'] = {}

    local = {}
    fact_path = '/etc/ansible/facts.d'


# Generated at 2022-06-25 00:17:32.133913
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_2 = LocalFactCollector()
    assert local_fact_collector_2.collect() == local_fact_collector_2.collect()


# Generated at 2022-06-25 00:17:33.051817
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()

# Generated at 2022-06-25 00:17:38.467687
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        local_fact_collector = LocalFactCollector()
        assert True
    except Exception as e:
        assert False



# Generated at 2022-06-25 00:17:40.791519
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:17:42.936655
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:17:45.358170
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1 is not None



# Generated at 2022-06-25 00:17:48.766736
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:20:23.349423
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.collect() == {'local': {}}, "Test Failed"


# Generated at 2022-06-25 00:20:24.424781
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()


# Generated at 2022-06-25 00:20:25.872513
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector is not None


# Generated at 2022-06-25 00:20:32.664427
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_collect_0 = LocalFactCollector()
    local_fact_collector_collect_1 = LocalFactCollector()

if __name__ == '__main__':
    test_case_0()
    # Unit test for method collect of class LocalFactCollector
    test_LocalFactCollector_collect()

# Generated at 2022-06-25 00:20:36.871499
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Constructor for class LocalFactCollector
    local_fact_collector_0 = LocalFactCollector()


# Generated at 2022-06-25 00:20:46.231992
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    os.mkdir("/tmp/ansible_test_facts")
    f = open("/tmp/ansible_test_facts/test.fact", "w")
    content = u'''
[test]
key1=val1
key2=val2
key3=val3
'''
    f.write(content)
    f.close()
    local_fact_collector = LocalFactCollector()

    module = MockModule()
    module.params['fact_path'] = '/tmp/ansible_test_facts'

    local_facts = local_fact_collector.collect(module)
    assert local_facts['local']['test']['key1'] == 'val1'
    assert local_facts['local']['test']['key2'] == 'val2'

# Generated at 2022-06-25 00:20:48.125828
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert(local_fact_collector_1.name == 'local')
    assert(local_fact_collector_1.priority == 50)

# Generated at 2022-06-25 00:20:54.447631
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    failed_1 = 'Failure executing fact script (c:/Ansible/facts/ansible_local.fact), rc: 1, err: '
    failed_2 = 'Could not execute fact script (c:/Ansible/facts/ansible_local_2.fact): [WinError 2] '
    failed_3 = 'error loading facts as JSON or ini - please check content: c:/Ansible/facts/ansible_local_3.fact'
    failed_local = {'ansible_local': failed_1, 'ansible_local_2': failed_2, 'ansible_local_3': failed_3}

    local_fact_collector_1 = LocalFactCollector()
    result = local_fact_collector_1.collect(None)
    assert result == {}


# Generated at 2022-06-25 00:20:59.459178
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_facts_0 = local_fact_collector_0.collect()
    assert 'local' in local_facts_0
    assert 'local' == local_facts_0['local']


# Generated at 2022-06-25 00:21:02.933373
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    pass