

# Generated at 2022-06-25 00:13:19.510335
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()


# Generated at 2022-06-25 00:13:28.711767
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    try:
        var_1 = LocalFactCollector()
    except Exception as e:
        raise Exception('Could not create LocalFactCollector object: %s' % to_text(e))

    var_2 = {}
    try:
        var_3 = None
        try:
            var_4 = ModuleStub()
        except Exception as e:
            raise Exception('Could not create ModuleStub object: %s' % to_text(e))

        var_5 = var_1.collect(var_4)
        var_2['local'] = var_5
    except Exception as e:
        raise Exception('Could not collect Local facts: %s' % to_text(e))

    assert type(var_2['local']) == dict

# Generated at 2022-06-25 00:13:32.303549
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Verify the constructor of the class LocalFactCollector
    local_fact_collector_0 = LocalFactCollector()


# Generated at 2022-06-25 00:13:35.671468
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()


# Generated at 2022-06-25 00:13:39.044084
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()


# Generated at 2022-06-25 00:13:42.207027
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1.collect() == {'local': {}}


# Generated at 2022-06-25 00:13:44.768039
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local', 'Expected value was: local, Actual value was: %s' % local_fact_collector_0.name

# Generated at 2022-06-25 00:13:49.406527
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1 is not None


# Generated at 2022-06-25 00:13:50.418363
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'

# Generated at 2022-06-25 00:13:55.714164
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    collected_facts_0 = {}
    collected_facts_0['ansible_local'] = {}
    collected_facts_0['ansible_local']['local'] = {}
    var_0 = local_fact_collector_0.collect(collected_facts=collected_facts_0)
    assert var_0 == collected_facts_0['ansible_local']['local']

# Generated at 2022-06-25 00:14:03.305974
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert not hasattr(local_fact_collector_0, 'module')

# Generated at 2022-06-25 00:14:08.596030
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()

# Generated at 2022-06-25 00:14:09.815929
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    local_fact_collector.collect()


# Generated at 2022-06-25 00:14:12.043526
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    try:
        var_1 = local_fact_collector_1.collect()
    except Exception as e:
        print("Error for collect of class LocalFactCollector")
        print(e)
        raise

# Generated at 2022-06-25 00:14:13.164765
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()


# Generated at 2022-06-25 00:14:14.555619
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    collector = LocalFactCollector()
    assert collector.name == 'local'


# Generated at 2022-06-25 00:14:15.780410
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    pass



# Generated at 2022-06-25 00:14:19.445673
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    var = local_fact_collector.collect()
    assert isinstance(var, dict)
    assert var == {}

# Generated at 2022-06-25 00:14:23.934552
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:14:26.323967
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()
    assert var_0['local'] == {}, 'Failed to collect local facts'

# Generated at 2022-06-25 00:14:41.081189
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    # assert local_fact_collector_0._fact_ids == {'local'}


# Generated at 2022-06-25 00:14:43.066293
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    str_0 = local_fact_collector_0.collect()
    assert type(str_0) == dict



# Generated at 2022-06-25 00:14:48.480183
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        test_case_0()
        test_case_1()
    except Exception as e:
        print(e)
        assert False


if __name__ == "__main__":
    test_LocalFactCollector()

# Generated at 2022-06-25 00:14:50.480424
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:14:54.407810
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    print("Unit test for constructor of class LocalFactCollector")

test_case_0()
test_LocalFactCollector()

# Generated at 2022-06-25 00:14:59.362276
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1.collect() == {}



# Generated at 2022-06-25 00:15:01.453595
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        test_case_0()
    except Exception as ex:
        print(ex)
        assert False



# Generated at 2022-06-25 00:15:03.860360
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert isinstance(local_fact_collector, LocalFactCollector)
    assert local_fact_collector.name == 'local'


# Generated at 2022-06-25 00:15:05.814559
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    wo_var = LocalFactCollector()
    assert wo_var.name == 'local'
    assert wo_var._fact_ids == set()


# Generated at 2022-06-25 00:15:08.079918
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'


# Generated at 2022-06-25 00:15:36.674695
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1


# Generated at 2022-06-25 00:15:38.414027
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()
    assert var_0 == {}


# Generated at 2022-06-25 00:15:39.873356
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    var = local_fact_collector.collect()

# Generated at 2022-06-25 00:15:43.847493
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector is not None
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:15:45.175514
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:15:46.355785
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()


# Generated at 2022-06-25 00:15:49.323176
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    from ansible.module_utils.facts.collectors.local.local import LocalFactCollector

    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()



# Generated at 2022-06-25 00:15:53.839819
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_facts_0 = {'local':{}}
    assert local_fact_collector_0.collect() == local_facts_0

if __name__ == "__main__":
    test_case_0()
    test_LocalFactCollector_collect()

# Generated at 2022-06-25 00:15:56.315691
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'  # initialized
    assert local_fact_collector_0._fact_ids == set()  # initialized

# Generated at 2022-06-25 00:15:59.645581
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()

    var = local_fact_collector.collect()
    assert isinstance(var, dict)

# Generated at 2022-06-25 00:17:02.262436
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    var_1 = local_fact_collector_1.collect()
    assert var_1 == {}

if __name__ == "__main__":
    test_LocalFactCollector_collect()

# Generated at 2022-06-25 00:17:05.051422
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()

if __name__ == "__main__":
    test_LocalFactCollector_collect()

# Generated at 2022-06-25 00:17:06.432332
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'


# Generated at 2022-06-25 00:17:09.382375
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector is not None
    assert local_fact_collector.name == 'local'


# Generated at 2022-06-25 00:17:11.346348
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()
    assert var_0 == {}


# Generated at 2022-06-25 00:17:17.061318
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()

# Generated at 2022-06-25 00:17:20.506398
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:17:22.638506
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    var_1 = local_fact_collector_1.collect()
    assert var_1 == {}



# Generated at 2022-06-25 00:17:24.582808
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()

# Generated at 2022-06-25 00:17:26.586916
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector is not None


# Generated at 2022-06-25 00:19:44.778111
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()
    assert True

# Generated at 2022-06-25 00:19:46.312873
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    LocalFactCollector()


# Generated at 2022-06-25 00:19:54.054025
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
   local_fact_collector = LocalFactCollector()
   # Testing with module = None and collected_facts = None
   var = local_fact_collector.collect()
   assert var is not None
   # Testing with module = {'params': {'fact_path': 'C:/Ansible'}} and collected_facts = None
   var = local_fact_collector.collect(module={'params': {'fact_path': 'C:/Ansible'}})
   assert var is not None

# Generated at 2022-06-25 00:19:55.862036
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    assert type(local_fact_collector_1.collect()) is dict


# Generated at 2022-06-25 00:19:57.788017
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    print("Constructor test for class LocalFactCollector starts.")
    test_case_0()
    print("Constructor test for class LocalFactCollector ends.")


# Generated at 2022-06-25 00:20:01.920392
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    var_0 = local_fact_collector_1.collect()
    assert('local' in var_0)==True


# Generated at 2022-06-25 00:20:02.998944
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()
# end of Unit test for constructor of class LocalFactCollector


# Generated at 2022-06-25 00:20:10.524151
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect({'run_command': mock_run_command, 'warn': mock_warn, 'params': {'fact_path': './tests/unit/module_utils/facts/local/fact_path'}})
    assert var_0 == {'local': {'fact_1': 'fact_1_data', 'fact_0': {'test_fact': {'test_key': 'test_value'}}}}


# Mocking

# Generated at 2022-06-25 00:20:12.823166
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        local_fact_collector_0 = LocalFactCollector()
    except Exception as e:
        print (e)
        assert False


# Generated at 2022-06-25 00:20:17.713471
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_1 = local_fact_collector_0.collect()


if __name__ == '__main__':
    test_case_0()