

# Generated at 2022-06-25 00:13:17.210684
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()



# Generated at 2022-06-25 00:13:22.137970
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()

    # Test with facts_module available
    assert local_fact_collector_1.collect()

    # Test with no facts_module
    assert local_fact_collector_1.collect(None, None)

# Generated at 2022-06-25 00:13:25.306553
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0 is not None, 'Test Failed: test_LocalFactCollector 0'


# Generated at 2022-06-25 00:13:31.414156
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    local_fact_collector = LocalFactCollector()

    fact_path = os.path.join(os.path.realpath(os.path.dirname(__file__)), 'fixtures', 'facts')
    facts = {'ansible_local': {'fact_path': fact_path}}
    module = MockModule(params=facts['ansible_local'])

    local_facts = local_fact_collector.collect(module=module, collected_facts=facts)
    assert local_facts != None
    assert local_facts.get('local') != None
    assert len(local_facts['local']) == 5
    assert local_facts['local']['test1'] == 'test1'
    assert local_facts['local']['test2'] == {'test': ['test', 'test2']}
    assert local_

# Generated at 2022-06-25 00:13:33.312172
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Setup the parameters used for the test
    fact_path = '/etc/ansible/facts.d'

    # Parse the output of the collect method
    result = LocalFactCollector.collect(LocalFactCollector, fact_path)

    # Check the result
    assert(result['local'] == {})

# Generated at 2022-06-25 00:13:41.925102
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

    # Test with no parameters
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()

    # Test with single parameter
    local_fact_collector_1 = LocalFactCollector(name='foo')
    assert local_fact_collector_1.name == 'foo'
    assert local_fact_collector_1._fact_ids == set()

    # Test with two parameters
    local_fact_collector_2 = LocalFactCollector(name='foo', fact_ids=set())
    assert local_fact_collector_2.name == 'foo'
    assert local_fact_collector_2._fact_ids == set()


# Generated at 2022-06-25 00:13:44.804636
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """Check if method collect of class LocalFactCollector is working.
    """
    local_fact_collector_0 = LocalFactCollector()
    res = local_fact_collector_0.collect()
    assert res == {'local': {}}


# Generated at 2022-06-25 00:13:49.129061
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector != None


# Generated at 2022-06-25 00:13:51.300390
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_1.collect()

# Generated at 2022-06-25 00:13:58.270527
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    def do_test(local_fact_collector):
        assert local_fact_collector.collect() == {'local': {}}

    def do_method_test(local_fact_collector):
        do_test(local_fact_collector)

    test_case_0()
    do_method_test(LocalFactCollector())

# Generated at 2022-06-25 00:14:08.391273
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_1.collect()

# Generated at 2022-06-25 00:14:09.595209
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()

# Generated at 2022-06-25 00:14:10.381692
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert(LocalFactCollector.name == 'local')

# Generated at 2022-06-25 00:14:12.294231
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert(local_fact_collector_1.name=='local')
    assert(local_fact_collector_1._fact_ids == set())


# Generated at 2022-06-25 00:14:14.818565
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    test_cases = [0]

    for test_case in test_cases:
        print("Running test case %d" % test_case)
        eval("test_case_%d()" % test_case)

# Generated at 2022-06-25 00:14:16.032807
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    LocalFactCollector_0 = LocalFactCollector()
    LocalFactCollector_0.collect()

# Generated at 2022-06-25 00:14:19.410642
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    Collector1 = LocalFactCollector()
    assert Collector1.name == 'local'
    assert Collector1._fact_ids == set()


# Generated at 2022-06-25 00:14:21.372256
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()

    assert local_fact_collector._fact_ids == set(), '_fact_ids is not set'


# Generated at 2022-06-25 00:14:26.603308
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1.name == 'local'


# Generated at 2022-06-25 00:14:30.024776
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    local_facts = local_fact_collector_1.collect()
    assert(local_facts['local'] == {})

if __name__ == '__main__':
    test_case_0()
    test_LocalFactCollector_collect()

# Generated at 2022-06-25 00:14:41.605666
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    var = local_fact_collector.collect()
    assert var['local'] == {u'json': {u'nested': False}, u'ini': {u'nested': False}}
    assert var['local'][u'json'] == {u'nested': False}
    assert var['local'][u'json'][u'nested'] == False
    assert var['local'][u'ini'] == {u'nested': False}
    assert var['local'][u'ini'][u'nested'] == False

# Generated at 2022-06-25 00:14:43.824437
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Make sure the constructor throws an Exception if it receives an invalid parameter
    with pytest.raises(TypeError):
        LocalFactCollector.__init__(None)
    # If the constructor works, then the test passes
    LocalFactCollector.__init__()


# Generated at 2022-06-25 00:14:47.352256
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local = LocalFactCollector()
    print("Executing test case 0")
    test_case_0()

# Generated at 2022-06-25 00:14:52.287531
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = {u'local': {u'uname_c': u'x86_64', u'uname_s': u'Linux', u'uname_a': u'4.4.0-62-generic #83-Ubuntu SMP Wed Jan 18 14:10:15 UTC 2017 x86_64'}}
    var_1 = local_fact_collector_0.collect()
    assert var_0 == var_1

# Generated at 2022-06-25 00:14:54.305166
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1._fact_ids == set()
    assert local_fact_collector_1.name == "local"


# Generated at 2022-06-25 00:15:00.276413
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:15:01.416331
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()

# Generated at 2022-06-25 00:15:03.055700
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()

# Generated at 2022-06-25 00:15:05.043756
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    var_0 = LocalFactCollector()
    assert (var_0._fact_ids == set())
    assert (var_0.name == 'local')

# Generated at 2022-06-25 00:15:07.045073
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    var_1 = local_fact_collector_1.collect()
    assert isinstance(var_1, dict)

# Generated at 2022-06-25 00:15:24.400262
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fact_collector_0 = LocalFactCollector()
    assert isinstance(fact_collector_0, LocalFactCollector)
    assert fact_collector_0._fact_ids == set([])
    assert fact_collector_0.name == 'local'

# Generated at 2022-06-25 00:15:26.737682
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    collector_0 = LocalFactCollector()
    assert collector_0.name == 'local'


# Generated at 2022-06-25 00:15:28.807996
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect(module=None, collected_facts=None)

# Generated at 2022-06-25 00:15:32.467714
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert (local_fact_collector_0.name == 'local')

# Generated at 2022-06-25 00:15:35.357293
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()
    assert var_0 == dict(local={})


# Generated at 2022-06-25 00:15:38.688732
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()
    var_0 = local_fact_collector_0.collect()

# Generated at 2022-06-25 00:15:40.163206
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector is not None


# Generated at 2022-06-25 00:15:43.933825
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:15:47.283684
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:15:51.387978
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    # AssertionError: LocalFactCollector.name != 'local'
    assert local_fact_collector_0.name == 'local'
    # AssertionError: LocalFactCollector._fact_ids != set()
    assert local_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:16:17.225759
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()


# Generated at 2022-06-25 00:16:18.445397
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()


# Generated at 2022-06-25 00:16:20.912521
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    res = local_fact_collector.collect()


if __name__ == "__main__":
    test_LocalFactCollector_collect()

# Generated at 2022-06-25 00:16:21.799891
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()


# Generated at 2022-06-25 00:16:29.453644
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()
    var_1 = local_fact_collector_0.collect(collected_facts={'local': {}}, module={'run_command': run_command_0, 'params': {'fact_path': 'fact_path_0'}})
    var_2 = local_fact_collector_0.collect(collected_facts={'local': {}}, module={'run_command': run_command_1, 'params': {'fact_path': 'fact_path_1'}})

# Generated at 2022-06-25 00:16:30.870450
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'


# Generated at 2022-06-25 00:16:32.314548
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        test_case_0()
    except Exception as e:
        print("Failed")
        raise (e)
    else:
        print("passed")

# Generated at 2022-06-25 00:16:36.795723
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    var = {}
    collector=LocalFactCollector(var)
    assert collector.name == "local"
    assert collector._fact_ids == set()
    assert len(collector.collect()) == 0


# Generated at 2022-06-25 00:16:38.307154
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()


# Generated at 2022-06-25 00:16:39.582799
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.collect() == {}


# Generated at 2022-06-25 00:17:51.007073
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect(module=None, collected_facts=None)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:17:56.420824
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Test instance creation
    # Case 1:
    local_fact_collector_0 = LocalFactCollector()
    assert isinstance(local_fact_collector_0, LocalFactCollector)

# Generated at 2022-06-25 00:17:59.464676
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector is not None


# Generated at 2022-06-25 00:18:01.495160
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_1 = local_fact_collector_0.collect()


# Generated at 2022-06-25 00:18:03.463848
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert len(local_fact_collector._fact_ids) == 0


# Generated at 2022-06-25 00:18:05.751405
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()


# Generated at 2022-06-25 00:18:13.585385
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module_mock = MagicMock(spec=AnsibleModule)
    module_mock.run_command.return_value = (0, 'output', 'error')
    module_mock.params = {
        'fact_path': 'fact_path_mock'
    }
    os_path_exists_mock = Mock(return_value=True)
    os_stat_mock = Mock(return_value=True)
    glob_mock = Mock(return_value=['file1.fact', 'file2.fact'])


# Generated at 2022-06-25 00:18:16.504470
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0


# Generated at 2022-06-25 00:18:19.996227
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    #assert local_fact_collector_0.collect() == {'local': {}}
    #assert local_fact_collector_0.collect() == None
    assert local_fact_collector_0.collect() == {'local': {}}

# Generated at 2022-06-25 00:18:23.689028
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

    # Testing default value of argument module ()
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert len(local_fact_collector_0._fact_ids) == 0


# Generated at 2022-06-25 00:20:57.073146
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()


# Generated at 2022-06-25 00:20:59.765248
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:21:03.145468
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    var_1 = LocalFactCollector()
    var_2 = dict()
    var_2['fact_path'] = '/tmp/ansible_local_facts/ansible_local_facts.d'
    var_3 = var_1.collect(var_2)
    del var_1
    del var_2
    del var_3

# Generated at 2022-06-25 00:21:04.141208
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # local_fact_collector_0 = LocalFactCollector()
    assert True

# Generated at 2022-06-25 00:21:05.106411
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()


# Generated at 2022-06-25 00:21:06.765394
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        test_case_0()
    except Exception:
        assert False

# Generated at 2022-06-25 00:21:10.182999
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()



# Generated at 2022-06-25 00:21:11.127217
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    LocalFactCollector()

# Generated at 2022-06-25 00:21:13.441280
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1.name == 'local'


# Generated at 2022-06-25 00:21:16.116373
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass