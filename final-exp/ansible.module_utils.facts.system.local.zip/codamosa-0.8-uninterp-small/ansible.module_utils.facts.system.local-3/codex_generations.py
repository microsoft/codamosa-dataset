

# Generated at 2022-06-25 00:13:24.995837
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()

    # Test with no module argument
    assert local_fact_collector_1.collect(module=None, collected_facts=None) == {'local': {}}

    # Test with module argument
    assert local_fact_collector_1.collect(module={'params': {'fact_path': None}}, collected_facts=None) == {'local': {}}

# Generated at 2022-06-25 00:13:27.329358
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()

    input_module = None
    result = local_fact_collector_1.collect(input_module)
    assert result is not None


# Generated at 2022-06-25 00:13:30.653679
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.collect(module=None, collected_facts=None) == {'local': {'ansible_local': 'error loading facts as JSON or ini - please check content: /home/runner/.ansible/tmp/ansible-tmp-1550958366.8497701-19240-166828373744122/ansible_fact_ansible_local.fact'}}

# Generated at 2022-06-25 00:13:32.752817
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass


# Generated at 2022-06-25 00:13:34.140636
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()


# Collect facts using LocalFactCollector

# Generated at 2022-06-25 00:13:41.950345
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    params = {
        'fact_path': './test/unit/module_utils/facts/fixtures/local/facts',
        'unsafe_proxy': True
    }
    module_1 = True
    local_facts_1 = local_fact_collector_1.collect(module=module_1, collected_facts=params)

    # Test some of the collected facts
    assert local_facts_1['local']['test_fact']['test_sub_fact'] == 'test_sub_fact_value'
    assert local_facts_1['local']['test_fact_json']['test_sub_fact'] == 'test_sub_fact_value'

# Generated at 2022-06-25 00:13:45.116840
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

    # initialize class
    local_fact_collector_1 = LocalFactCollector()

    # validate name of class
    if os.path.basename(os.path.normpath(local_fact_collector_1.name)) == 'local':
        return True
    else:
        return False



# Generated at 2022-06-25 00:13:49.484370
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'
    assert set(LocalFactCollector._fact_ids) == set(['local'])


# Generated at 2022-06-25 00:13:51.675307
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()

    # Test with the first method if statement
    # Test with the second method if statement


# Generated at 2022-06-25 00:13:57.603416
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1.name == 'local'
    assert local_fact_collector_1._fact_ids == set()


# Generated at 2022-06-25 00:14:13.707586
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

    # Creating a dummy AnsibleModule() class
    class AnsibleModule():
        def __init__(self, *args, **kwargs):
            pass

        # Defining a dummy method to return a dummy fact_path value
        def params(self):
            return {'fact_path': './tests/unit/module_utils/facts/collection/legacy_facts'}

        # Defining a dummy method to return a dummy run_command() object
        def run_command(self, *args, **kwargs):
            out = '{"example_fact1": "Hello World", "example_fact2": "123"}'
            return (0, out, '')

        # Defining a dummy method to display the warning message
        def warn(self, *args, **kwargs):
            pass

    local_fact_collector_0 = LocalFact

# Generated at 2022-06-25 00:14:22.665546
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()
    var_1 = local_fact_collector_0.collect()
    var_2 = local_fact_collector_0.collect()
    var_3 = local_fact_collector_0.collect()
    var_4 = local_fact_collector_0.collect()
    var_5 = local_fact_collector_0.collect()
    var_6 = local_fact_collector_0.collect()
    var_7 = local_fact_collector_0.collect()
    var_8 = local_fact_collector_0.collect()
    var_9 = local_fact_collector_0.collect()
    local_fact_collector_0 = LocalFactCollect

# Generated at 2022-06-25 00:14:24.191720
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector is not None


# Generated at 2022-06-25 00:14:26.003969
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'


# Generated at 2022-06-25 00:14:27.116585
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    case_0()
    case_0()

# Generated at 2022-06-25 00:14:29.188348
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert isinstance(local_fact_collector_0, LocalFactCollector)


# Generated at 2022-06-25 00:14:30.277077
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()


# Generated at 2022-06-25 00:14:34.254413
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    print("Starting test")

# Generated at 2022-06-25 00:14:36.346960
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    assert type(local_fact_collector_0.collect()) == dict


# Generated at 2022-06-25 00:14:38.025589
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    assert isinstance(local_fact_collector_1.collect(), dict)

# Generated at 2022-06-25 00:14:52.749534
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    cmd_0 = 'type -a local_fact_collector_collect'
    rc, out, err = os.system(cmd_0)

    if rc == 0:
        print(out)
    else:
        print(err)


# Generated at 2022-06-25 00:14:56.342034
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert (local_fact_collector_1 != None)
    assert (local_fact_collector_1._fact_ids == set())


# Generated at 2022-06-25 00:14:58.719099
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    print("Testing LocalFactCollector")
    local_fact_collector_2 = LocalFactCollector()
    assert hasattr(local_fact_collector_2, 'name')


# Generated at 2022-06-25 00:15:00.308776
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()


# Generated at 2022-06-25 00:15:05.421940
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    expected_obj = {'local': {'bar': {'foo': 'baz'}, 'test': 'success'}}

# Generated at 2022-06-25 00:15:08.529541
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Test case 0
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()

    # Test case 1
    local_fact_collector_1 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()

# Generated at 2022-06-25 00:15:09.838534
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_obj_0 = LocalFactCollector()
    # TODO
    return


# Generated at 2022-06-25 00:15:11.088646
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    local_fact_collector.collect()



# Generated at 2022-06-25 00:15:16.003351
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:15:16.921290
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    var_1 = LocalFactCollector()

# Generated at 2022-06-25 00:15:44.537940
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()

# Generated at 2022-06-25 00:15:46.633413
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0 is not None


# Generated at 2022-06-25 00:15:48.959725
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    result = local_fact_collector_1.collect()
    # Assert
    assert result is None

# Generated at 2022-06-25 00:15:52.859130
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    var_1 = local_fact_collector_1.collect()
    assert var_1 == {}

# Generated at 2022-06-25 00:15:55.572683
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert str(local_fact_collector) == 'local'


# Generated at 2022-06-25 00:15:59.605580
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1.name == 'local'



# Generated at 2022-06-25 00:16:02.986455
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'


# Generated at 2022-06-25 00:16:05.852374
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.collect() is not False


# Generated at 2022-06-25 00:16:10.347280
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    # Check type of attribute fact_ids of class LocalFactCollector
    assert isinstance(local_fact_collector_0.fact_ids, set)
    # Check type of attribute name of class LocalFactCollector
    assert isinstance(local_fact_collector_0.name, str)


# Generated at 2022-06-25 00:16:14.588119
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()

# Generated at 2022-06-25 00:17:17.311130
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    var_1 = local_fact_collector_1.collect(module='', collected_facts='abc')
    assert var_1 == {'local': {}}

# Generated at 2022-06-25 00:17:18.845222
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()


test_case_0()
test_LocalFactCollector()

# Generated at 2022-06-25 00:17:28.465174
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    FACT_PATH = os.path.join(os.path.dirname(__file__), 'fixtures')
    module = AnsibleModule(fact_path=FACT_PATH)
    local_fact_collector = LocalFactCollector()
    result = local_fact_collector.collect(module)
    local = result['local']
    assert 'test' in local.keys()
    assert isinstance(local['test'], dict)
    assert 'fact_1' in local['test'].keys()
    assert 'fact_2' in local['test'].keys()
    assert local['test']['fact_1'] == 'value_1'
    assert local['test']['fact_2'] == 'value_2'
    assert 'test_invalid_json' in local.keys()

# Generated at 2022-06-25 00:17:31.722151
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-25 00:17:33.144517
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    var_1 = local_fact_collector_1.collect()

# Generated at 2022-06-25 00:17:38.466569
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1.name == 'local'

# Generated at 2022-06-25 00:17:41.731714
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()


# Generated at 2022-06-25 00:17:47.605193
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()
    try:
        assert val == var_0
    except AssertionError:
        raise AssertionError('Expected: %s, got: %s' % (val, var_0))

# Generated at 2022-06-25 00:17:49.216459
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # should be able to initialize
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()



# Generated at 2022-06-25 00:17:51.182931
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()


# Generated at 2022-06-25 00:20:12.786057
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector
    assert isinstance(local_fact_collector, LocalFactCollector)


# Generated at 2022-06-25 00:20:13.536942
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector()

# Generated at 2022-06-25 00:20:17.161111
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()



# Generated at 2022-06-25 00:20:18.056622
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()


# Generated at 2022-06-25 00:20:21.622699
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    var_1 = local_fact_collector_0.name
    assert var_1 == 'local'


# Generated at 2022-06-25 00:20:28.665330
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Path is root because this is local to the module, not the host
    fact_path = os.path.dirname(__file__)

    # Good json file
    out = open(fact_path + '/fact_0.output').read()

    # Bad json file
    out1 = open(fact_path + '/fact_1.output').read()

    # Good ini file
    out2 = open(fact_path + '/fact_2.output').read()

    # Bad ini file
    out3 = open(fact_path + '/fact_3.output').read()

    # File not present
    out4 = open(fact_path + '/fact_4.output').read()

    # Executable
    out5 = open(fact_path + '/fact_5.output').read()

    # Create an empty fact_path


# Generated at 2022-06-25 00:20:31.655581
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    check_prereqs()
    # Create a test instance
    local_fact_collector_0 = LocalFactCollector()
    # Call method collect of LocalFactCollector instance
    var_0 = local_fact_collector_0.collect(module=None, collected_facts=None)
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 00:20:36.516519
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # constructor test
    assert LocalFactCollector.__init__ is not None


# Generated at 2022-06-25 00:20:38.139124
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()
    assert var_0['local'] == {}

# Generated at 2022-06-25 00:20:42.203537
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
