

# Generated at 2022-06-25 00:13:22.054864
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local', 'constructor is broken'


# Generated at 2022-06-25 00:13:29.806947
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    fact_path = "/tmp/facts"
    # Testing when fact_path is None
    module = MockModule(fact_path=None)
    assert local_fact_collector.collect(module=module) == {}
    # Testing when fact_path does not exist
    module = MockModule(fact_path="/tmp")
    assert local_fact_collector.collect(module=module) == {}
    # Testing when fact_path exists
    os.makedirs(fact_path)
    with open(fact_path + "/test.fact", 'w') as f:
        f.write("#!/bin/sh\n")
        f.write("echo {\"my_fact\":\"my_fact_value\"}")

# Generated at 2022-06-25 00:13:33.415975
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    test_case_0()

if __name__ == '__main__':
    # Unit tests
    test_LocalFactCollector_collect()

# Generated at 2022-06-25 00:13:37.656827
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    """Test creation of a new instance of the LocalFactCollector class."""

    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0
    assert local_fact_collector_0.name == 'local'


# Generated at 2022-06-25 00:13:43.080459
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert isinstance(local_fact_collector, LocalFactCollector)
    assert hasattr(local_fact_collector, 'name')
    assert hasattr(local_fact_collector, '_fact_ids')
    assert isinstance(local_fact_collector._fact_ids, set)

# Generated at 2022-06-25 00:13:45.272200
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:13:49.093440
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_0 = LocalFactCollector()
    assert test_0


# Generated at 2022-06-25 00:13:52.443529
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_1.name = 'local'
    result = local_fact_collector_1.collect()
    assert result == {'local': {}}


# Generated at 2022-06-25 00:13:56.585767
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    local_fact_collector = LocalFactCollector()

    result = local_fact_collector.collect()

    assert result == {}


# Generated at 2022-06-25 00:14:03.968897
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # given
    local_fact_collector_0 = None
    # when
    local_fact_collector_0 = LocalFactCollector()
    # then
    assert(local_fact_collector_0 is not None)
    assert(local_fact_collector_0.name == 'local')

# Generated at 2022-06-25 00:14:20.633195
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert str(type(local_fact_collector_0._fact_ids)) == "<class 'set'>"


# Generated at 2022-06-25 00:14:22.212127
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector != None

# Generated at 2022-06-25 00:14:26.438639
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.collect() == {}

# Generated at 2022-06-25 00:14:29.108502
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:14:30.773364
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0 is not None



# Generated at 2022-06-25 00:14:35.123286
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()


# Generated at 2022-06-25 00:14:36.761741
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_1.collect()

# Generated at 2022-06-25 00:14:38.093860
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()

# Generated at 2022-06-25 00:14:44.430763
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()

    local_facts = {}
    local_facts['local'] = {}

    local_fact_collector_0.collect()

    local_fact_collector_1 = LocalFactCollector()

    local_fact_collector_1.collect()

    local_fact_collector_2 = LocalFactCollector()

    local_fact_collector_2.collect()

    local_fact_collector_3 = LocalFactCollector()

    local_fact_collector_3.collect()

    local_fact_collector_4 = LocalFactCollector()

    local_fact_collector_4.collect()

    local_fact_collector_5 = LocalFactCollector()

    local_fact_collector_5.collect()

    local_fact_collector_

# Generated at 2022-06-25 00:14:46.149049
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_i = LocalFactCollector()
    assert local_fact_collector_i.name == 'local'


# Generated at 2022-06-25 00:15:15.101179
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_1.collect()


# Generated at 2022-06-25 00:15:18.613606
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    # Checking if values of class variables have been initialized correctly.
    assert local_fact_collector_1._fact_ids == set()
    assert local_fact_collector_1.name == 'local'



# Generated at 2022-06-25 00:15:26.162581
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    local_facts = local_fact_collector.collect()
    assert local_facts is not None, "local_facts should not be None."
    assert len(local_facts) == 1, "length of local_facts should be one."
    assert local_facts['local'] == {}, "local should have the value {}."

# Generated at 2022-06-25 00:15:28.500506
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'
    assert LocalFactCollector.__name__ == 'LocalFactCollector'
    assert LocalFactCollector.__doc__ is not None

# Generated at 2022-06-25 00:15:32.432605
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
        local_fact_collector_1 = LocalFactCollector()
        local_fact_collector_1.collect()


# Generated at 2022-06-25 00:15:35.624366
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()

    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()



# Generated at 2022-06-25 00:15:37.877171
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert hasattr(LocalFactCollector, 'name')
    assert hasattr(LocalFactCollector, '_fact_ids')
    assert hasattr(LocalFactCollector, 'collect')

# Generated at 2022-06-25 00:15:41.235675
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0 is not None
    assert local_fact_collector_0._fact_ids == set()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0.count == 0


# Generated at 2022-06-25 00:15:45.144477
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()
    del local_fact_collector_0

# Generated at 2022-06-25 00:15:52.778212
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_2 = LocalFactCollector()
    local_fact_collector_3 = LocalFactCollector()
    local_fact_collector_4 = LocalFactCollector()

    ansible_0 = "localhost"
    ansible_1 = "ansible_version"
    ansible_2 = "default_ipv4"
    ansible_3 = "local"
    ansible_4 = "dns"
    ansible_5 = "hostname"
    ansible_6 = "interfaces"

    ansible_dict_1 = ansible_1 in local_fact_collector_1.collect()
    ansible_dict_2 = local_fact_collector_2.collect()[ansible_3][ansible_0]

# Generated at 2022-06-25 00:16:20.439559
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()

if __name__ == "__main__":
    test_LocalFactCollector()

# Generated at 2022-06-25 00:16:20.953846
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    assert True


# Generated at 2022-06-25 00:16:22.917441
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()



# Generated at 2022-06-25 00:16:26.050591
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.name = 'local'
    var_0 = local_fact_collector_0.collect()
    print("var_0: " + str(var_0))


# Generated at 2022-06-25 00:16:28.653481
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()
    var_1 = local_fact_collector_0.collect()
    assert var_0 == var_1


# Generated at 2022-06-25 00:16:30.839619
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert(local_fact_collector_0.name == 'local')
    assert(local_fact_collector_0._fact_ids == set())


# Generated at 2022-06-25 00:16:35.739700
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # initialize variable to test with
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_1 = LocalFactCollector()

    # test for two different instances of the object
    assert local_fact_collector_0 is not local_fact_collector_1
    assert type(local_fact_collector_0) == type(local_fact_collector_1)

    # test for default value of variable name
    assert local_fact_collector_0.name == "local"
    assert local_fact_collector_1.name == "local"


# Generated at 2022-06-25 00:16:38.173324
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:16:40.635117
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    # TODO : Replace with actual values
    module_1 = ""
    # TODO : Replace with actual values
    collected_facts_1 = ""
    var_0 = local_fact_collector_0.collect(module=module_1, collected_facts=collected_facts_1)

# Generated at 2022-06-25 00:16:44.729979
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1.name == 'local'
    assert local_fact_collector_1._fact_ids == set()


# Generated at 2022-06-25 00:17:59.852271
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    ext_fact_path = '/etc/ansible/facts.d'
    ext_fact_path_b = '/etc/ansible/facts.d'
    module_0 = 'ansible.module_utils.facts.collector.LocalFactCollector'
    local_fact_collector_0 = LocalFactCollector(ext_fact_path, ext_fact_path_b)
    assert local_fact_collector_0.fact_path == ext_fact_path
    assert local_fact_collector_0.module_name == module_0
    assert local_fact_collector_0.name == 'local'

# Generated at 2022-06-25 00:18:03.628393
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1.name == 'local'
    assert local_fact_collector_1.priority == 10

# Generated at 2022-06-25 00:18:11.897009
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    mock_module = MagicMock()
    mock_module.params = {'fact_path': 'fact_path_0'}
    mock_module.run_command.side_effect = [
        (0, '', ''),
        (0, '', ''),
        (0, '', ''),
        (0, '', '')
    ]
    mock_module.warn.side_effect = [
        '',
        ''
    ]
    local_fact_collector_0 = LocalFactCollector()
    var_1 = local_fact_collector_0.collect(mock_module)
    assert var_1 == {'local': {'fact_0': '', 'fact_1': '', 'fact_2': '', 'fact_3': ''}}

# Generated at 2022-06-25 00:18:15.321275
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name=='local'
    assert LocalFactCollector._fact_ids==set()


# Generated at 2022-06-25 00:18:24.591735
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    config_parser_0 = configparser.ConfigParser()
    parameter_0 = 'sect_1'
    parameter_1 = 'fact_base_0'
    config_parser_0.set(parameter_0, parameter_1)
    parameter_0 = 'sect_2'
    config_parser_0.set(parameter_0, parameter_1)
    parameter_0 = 'sect_3'
    config_parser_0.set(parameter_0, parameter_1)
    parameter_0 = 'sect_4'
    config_parser_0.set(parameter_0, parameter_1)
    local_fact_collector_0 = LocalFactCollector()
    parameter_0 = config_parser_0.sections()
    parameter_1 = 'local'

# Generated at 2022-06-25 00:18:27.621863
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    var_1 = local_fact_collector_1.collect()


# Generated at 2022-06-25 00:18:30.863219
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    temp_local_fact_collector = LocalFactCollector()
    assert temp_local_fact_collector.name == 'local'
    assert temp_local_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:18:34.620269
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()



# Generated at 2022-06-25 00:18:35.969001
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_test = LocalFactCollector()
    assert local_fact_collector_test.collect() == {'local': {}}


# Generated at 2022-06-25 00:18:36.790979
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    var_1 = LocalFactCollector()

# Generated at 2022-06-25 00:21:17.047589
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'


# Generated at 2022-06-25 00:21:20.115546
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    var_0 = LocalFactCollector()
    var_1 = None
    var_2 = var_0.collect(module=var_1)
    try:
        assert var_2 == dict()
    except AssertionError as e:
        raise AssertionError(e)

# Generated at 2022-06-25 00:21:21.700139
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()


# Generated at 2022-06-25 00:21:24.107369
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Unit test for collect
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()


# Generated at 2022-06-25 00:21:27.050186
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    var_1 = local_fact_collector_0.name
    var_2 = local_fact_collector_0._fact_ids

# Generated at 2022-06-25 00:21:31.261670
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    local_fact_collector.collect()



# Generated at 2022-06-25 00:21:32.213830
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()


# Generated at 2022-06-25 00:21:34.378386
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    '''
    Unit test for method collect of class LocalFactCollector
    '''
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.collect() == {'local': {}}


# Generated at 2022-06-25 00:21:39.899498
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    var_1 = local_fact_collector_1.fact_ids
    var_2 = local_fact_collector_1.name
    var_3 = local_fact_collector_1.priority

if __name__ == "__main__":
    test_case_0()
    test_LocalFactCollector()

# Generated at 2022-06-25 00:21:44.157293
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

    local_fact_collector = LocalFactCollector()
    assert isinstance(local_fact_collector, LocalFactCollector)
    assert str(local_fact_collector) == "<ansible.module_utils.facts.local.local.LocalFactCollector object at 0x7f501fa29a90>"