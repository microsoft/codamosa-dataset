

# Generated at 2022-06-25 00:13:18.083591
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()


# Generated at 2022-06-25 00:13:21.969994
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Test case 0
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'


# Generated at 2022-06-25 00:13:24.840356
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    #executable fact file test
    local_fact_collector_1 = LocalFactCollector()
    results = local_fact_collector_1.collect()
    assert results == {}

# Generated at 2022-06-25 00:13:26.852308
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-25 00:13:27.651784
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert isinstance(LocalFactCollector, object)

# Generated at 2022-06-25 00:13:32.902389
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
# print(dir(local_fact_collector_0))
# print(local_fact_collector_0.name)


# Generated at 2022-06-25 00:13:37.544590
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        test_case_0()
        print("Unit test for constructor of class LocalFactCollector is passed")
    except Exception as e:
        print("Unit test for constructor of class LocalFactCollector is failed")


if __name__ == "__main__":
    test_LocalFactCollector()

# Generated at 2022-06-25 00:13:40.801815
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    localFactCollector = LocalFactCollector()
    assert localFactCollector.collect() == {'local': {}}

# Generated at 2022-06-25 00:13:45.058780
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local', "LocalFactCollector.name is failing"
    assert LocalFactCollector._fact_ids == set(), "LocalFactCollector._fact_ids is failing"


# Generated at 2022-06-25 00:13:49.473235
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_1.collect()

# Generated at 2022-06-25 00:14:00.363853
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    collected_facts_0 = {}
    local_facts_0 = local_fact_collector_0.collect(collected_facts=collected_facts_0)
    # Set expected result
    expected_local_facts_0 = { 'local': {'myfact': 'myval'} }
    # Assert
    assert local_facts_0 == expected_local_facts_0

# Generated at 2022-06-25 00:14:01.319376
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector is not None

# Generated at 2022-06-25 00:14:06.522787
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # path to local facts directory that contains facts for unit testing
    local_facts_path = os.path.join(os.path.dirname(__file__), 'local_facts')
    # import ansible.module_utils.facts.module_facts
    from ansible.module_utils.facts.module_facts import ModuleFacts

    module_facts = ModuleFacts(module=dict(fact_path=local_facts_path))
    local_fact_collector = LocalFactCollector()
    result = local_fact_collector.collect(module=module_facts)
    assert result is not None


# Generated at 2022-06-25 00:14:16.089173
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    fact_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'fixtures', 'facts', 'local')
    fact_path_0 = os.path.join(fact_path, '0')
    fact_path_1 = os.path.join(fact_path, '1')
    fact_path_2 = os.path.join(fact_path, '2')
    fact_path_3 = os.path.join(fact_path, '3')
    # Mock module
    mock_module = type('MockModule', (object,), {'run_command': run_command_0, 'warn': warn})
    # Mock parameter 'fact_path'
    mock_params = type('MockParams', (object,), {'get': get_0})()
   

# Generated at 2022-06-25 00:14:22.004629
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == "local"
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0._fact_ids == set()
    local_fact_collector_2 = LocalFactCollector()
    assert local_fact_collector_0._fact_ids == local_fact_collector_2._fact_ids


# Generated at 2022-06-25 00:14:29.534965
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    fact_path_0 = '/usr/local/facts'
    test_case_0 = {'fact_path': fact_path_0}
    expected = {'local':{
        'hostname': 'localhost',
        'ansible_all_ipv4_addresses': ['10.0.0.12']}}
    local_fact_collector_0 = LocalFactCollector()
    actual = local_fact_collector_0.collect(module=test_case_0)
    assert actual == expected

# Generated at 2022-06-25 00:14:30.874899
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == "local"

# Generated at 2022-06-25 00:14:37.782721
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_facts_0 = {}
    # Testing if 'dict' is a 'dict'
    assert isinstance(local_facts_0, dict)
    local_facts_1 = local_fact_collector_0.collect()
    # Testing if 'local_facts_1' is equal to 'local_facts_0'
    assert local_facts_1 == local_facts_0


# Generated at 2022-06-25 00:14:42.276898
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_1.collect()


# Generated at 2022-06-25 00:14:46.964731
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    # test case where module is none
    collected_facts_1 = local_fact_collector_1.collect(None)
    collected_facts_1_keys = collected_facts_1.keys()
    assert 'local' in collected_facts_1_keys

# Generated at 2022-06-25 00:14:53.990376
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_1.collect()

# Generated at 2022-06-25 00:14:55.905462
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # test class constructor without parameters
    local_fact_collector_0 = LocalFactCollector()

# Generated at 2022-06-25 00:14:57.697828
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector(module=True)
    assert 'ansible.module_utils.facts.collector.BaseFactCollector' \
           == local_fact_collector_1.__class__.__bases__[0].__name__



# Generated at 2022-06-25 00:14:59.161511
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
  assertLocalFactCollector()
  test_case_0()

# Generated at 2022-06-25 00:15:03.018131
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # calling without parameters
    from ansible.module_utils.facts.collector import BaseFactCollector
    local_fact_collector_1 = LocalFactCollector()
    assert type(local_fact_collector_1) == LocalFactCollector
    assert isinstance(local_fact_collector_1, BaseFactCollector)

# Generated at 2022-06-25 00:15:04.305276
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()


# Generated at 2022-06-25 00:15:05.960610
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'


# Generated at 2022-06-25 00:15:08.221126
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    # Test default parameters
    local_fact_collector_0 = LocalFactCollector()

    rv = local_fact_collector_0.collect()
    assert(rv is None)



# Generated at 2022-06-25 00:15:09.804105
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    local_fact_collector.collect()

test_case_0()

# Generated at 2022-06-25 00:15:11.491125
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        test_case_0()
    except AssertionError:
        # clean up code
        return False
    else:
        # clean up code
        return True

# Generated at 2022-06-25 00:15:19.501925
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()

# Generated at 2022-06-25 00:15:20.970056
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()


# Generated at 2022-06-25 00:15:23.710042
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert issubclass(LocalFactCollector, BaseFactCollector)


if __name__ == "__main__":
    test_LocalFactCollector()

# Generated at 2022-06-25 00:15:31.892310
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_1 = LocalFactCollector()
    # Failed to convert (C:\Users\USER\Ansible\playbooks\test.facts) to JSON: (u'ascii', u'"utf8" does not support decoding', 0, 1, u'ordinal not in range(128)')
    s = set([local_fact_collector_0, local_fact_collector_1])
    s.discard(local_fact_collector_1)
    local_fact_collector_2 = LocalFactCollector()
    local_fact_collector_3 = LocalFactCollector()
    s.discard(local_fact_collector_3)
    local_fact_collector_0.collect()

# Generated at 2022-06-25 00:15:32.574840
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:15:34.814212
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert (local_fact_collector_0.name == 'local')


# Generated at 2022-06-25 00:15:35.624569
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:15:37.218181
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    print(local_fact_collector_0)


# Generated at 2022-06-25 00:15:39.343944
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert(local_fact_collector.name == 'local')
    assert(local_fact_collector._fact_ids == set())

# Generated at 2022-06-25 00:15:46.238545
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    fact_path_0 = '/home/vagrant/ansible/tests/unit/module_utils/facts/fixtures/facts/local/'
    module_0 = ''
    local_facts_0 = local_fact_collector_0.collect(module_0, fact_path_0)
    assert local_facts_0 is not None
    assert type(local_facts_0) is dict

# Generated at 2022-06-25 00:15:55.463078
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert isinstance(local_fact_collector, LocalFactCollector) == True


# Generated at 2022-06-25 00:15:59.283394
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """Test method collect of class LocalFactCollector"""
    LocalFactCollector()


# Generated at 2022-06-25 00:16:02.958540
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_collect_0 = LocalFactCollector()

    assert isinstance(local_fact_collector_collect_0.collect(), dict)

# Generated at 2022-06-25 00:16:06.183374
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.__class__.__name__ == 'LocalFactCollector'

# Generated at 2022-06-25 00:16:11.828365
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()
    assert('local' == local_fact_collector_0.name)
    
# unit test for class LocalFactCollector

# Generated at 2022-06-25 00:16:13.916109
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()



# Generated at 2022-06-25 00:16:16.752290
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    print("Name: " + local_fact_collector_0.name)
    print("Facts: " + str(local_fact_collector_0._fact_ids))

# Generated at 2022-06-25 00:16:19.379089
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert len(local_fact_collector_0._fact_ids) == 0


# Generated at 2022-06-25 00:16:23.097052
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name is not None
    assert LocalFactCollector._fact_ids is not None
    assert LocalFactCollector.collect is not None
    assert LocalFactCollector._get_local_facts_dir is not None
    assert LocalFactCollector._get_local_facts_dirs is not None

# Generated at 2022-06-25 00:16:29.140574
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Creating an object for testing
    local_fact_collector_collect = LocalFactCollector()
    os.path.___path___ = property()
    os.path.___path___ = module.params.get('fact_path', None)

    # Testing method collect with no parameters
    return_value = local_fact_collector_collect.collect()
    assert return_value is None

    # Testing method collect with a parameters
    assert local_fact_collector_collect.collect(module) == local_facts

    # Testing method collect with a parameters
    assert local_fact_collector_collect.collect(module, collected_facts) == local_facts

# Generated at 2022-06-25 00:16:37.610540
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        local_fact_collector_0 = LocalFactCollector()
    except Exception:
        assert False


# Generated at 2022-06-25 00:16:39.965034
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()

    assert var_0 == {'local': {}}


# Generated at 2022-06-25 00:16:47.879779
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_1 = local_fact_collector_0.collect()
    assert var_1 == {'local': {}}
    try:
        var_2 = local_fact_collector_0.collect()
    except Exception as e:
        var_3 = hasattr(e, 'message')
    else:
        var_3 = False
    assert var_3


# Generated at 2022-06-25 00:16:53.047385
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()
    assert var_0['local'] == {}, 'Failed to assert that var_0["local"] == {}'


# Generated at 2022-06-25 00:17:02.109574
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    # Test case with no parameters
    var_0 = local_fact_collector_0.collect()
    assert var_0 is not None
    assert var_0['local'] is not None
    assert len(var_0['local'].keys()) == 0
    # Test case with parameter module
    from ansible.module_utils.facts import ModuleBase
    module = ModuleBase()
    var_1 = local_fact_collector_0.collect(module=module)
    assert var_1 is not None
    assert len(var_1['local']) is not None
    assert 'ansible_local' in var_1['local'].keys()

# Generated at 2022-06-25 00:17:05.413913
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    dict_0 = dict()
    dict_1 = dict()
    dict_0['local'] = dict_1
    var_0 = local_fact_collector_0.collect(collected_facts=dict_0)


# Generated at 2022-06-25 00:17:11.106403
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_2 = LocalFactCollector()
    # Module = ansible.module_utils.basic.AnsibleModule
    # collected_facts = dict(local.local.a='a')
    # Exception: unsupported operand type(s) for |: 'dict' and 'str'
    # print(local_fact_collector_2.collect(Module, collected_facts))
    # local_fact_collector_1.collect()

# Generated at 2022-06-25 00:17:16.374647
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()
    assert True



# Generated at 2022-06-25 00:17:17.631894
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()


# Generated at 2022-06-25 00:17:20.184744
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    var_0 = LocalFactCollector()
    var_0.collect(module=None, collected_facts=None)


# Generated at 2022-06-25 00:17:42.255253
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert (local_fact_collector_0.name == 'local')
    assert (local_fact_collector_0._fact_ids == set())
    # check str method of an object
    assert (str(local_fact_collector_0) == "<ansible.module_utils.facts.local.LocalFactCollector(name=local)>")



# Generated at 2022-06-25 00:17:45.002584
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    var_1 = LocalFactCollector()
    assert var_1._fact_ids == set()
    assert var_1.name == 'local'


# Generated at 2022-06-25 00:17:48.493984
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    with pytest.raises(TypeError) as excinfo:
        LocalFactCollector()
    assert excinfo.value.args[0] == "__init__() missing 1 required positional argument: 'collected_facts'"

# Generated at 2022-06-25 00:17:50.860281
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    var_1 = local_fact_collector_1.collect()
    assert var_1 == {}

# Generated at 2022-06-25 00:17:55.850940
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'



# Generated at 2022-06-25 00:18:00.653629
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    obj_0 = local_fact_collector_1
    var_0 = obj_0._fact_ids
    var_0 = obj_0._fact_ids
    var_0 = obj_0._fact_ids


# Generated at 2022-06-25 00:18:02.801337
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert type(local_fact_collector_0) == LocalFactCollector


# Generated at 2022-06-25 00:18:06.262898
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    test_case_0()

test_case_0()

# Generated at 2022-06-25 00:18:08.339908
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert_true(len(LocalFactCollector._fact_ids) == 1)
    assert_true('local' in LocalFactCollector._fact_ids)


# Generated at 2022-06-25 00:18:12.581591
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0._fact_ids == set()
    assert local_fact_collector_0.name == 'local'


# Generated at 2022-06-25 00:18:50.542470
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert isinstance(local_fact_collector_0, LocalFactCollector)


# Generated at 2022-06-25 00:18:55.244715
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Define test inputs and expected distinct values
    # Assert that distinct values are not equal
    assert False


# Generated at 2022-06-25 00:18:59.767392
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    assert isinstance(local_fact_collector_1, LocalFactCollector)


# Generated at 2022-06-25 00:19:00.497973
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector().name == 'local'

# Generated at 2022-06-25 00:19:02.580183
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()


# Generated at 2022-06-25 00:19:06.254247
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    print("Test constructor of class LocalFactCollector")
    local_fact_collector_0 = LocalFactCollector()

if __name__ == '__main__':
    test_case_0()
    test_LocalFactCollector()

# Generated at 2022-06-25 00:19:07.925632
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()

# Generated at 2022-06-25 00:19:11.740786
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()


# Generated at 2022-06-25 00:19:13.556055
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    var_1 = LocalFactCollector()
    var_2 = var_1.collect()

# Generated at 2022-06-25 00:19:15.663739
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    output = local_fact_collector.collect()
    assert output.get('local') == {}


# Generated at 2022-06-25 00:20:41.377769
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    var_0 = LocalFactCollector()
    var_1 = {}
    var_1['GATHER_FACTS_SUBSET'] = None
    var_1['ANSIBLE_FACTS_CACHE_TIMEOUT'] = 86400
    var_1['ANSIBLE_NOCOLOR'] = None
    var_1['ANSIBLE_TRANSPORT'] = 'smart'
    var_1['ANSIBLE_CACHE_PLUGIN'] = 'memory'
    var_1['ANSIBLE_FACTS_CACHE'] = None
    var_1['ANSIBLE_LOG_PATH'] = None
    var_1['ANSIBLE_INTERNAL_TEMPLATE_WARNING'] = 'off'
    var_1['ANSIBLE_STDOUT_CALLBACK'] = 'yaml'

# Generated at 2022-06-25 00:20:43.553122
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()
    assert var_0 is not None

# Generated at 2022-06-25 00:20:47.415117
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    localFactCollector = LocalFactCollector()
    assert localFactCollector.name == 'local'


# Generated at 2022-06-25 00:20:49.200586
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Instantiating object with default attributes
    local_fact_collector_0 = LocalFactCollector()

    # Testing method collect of class LocalFactCollector
    var_0 = local_fact_collector_0.collect()

# Generated at 2022-06-25 00:20:53.600539
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector(
    )
    local_fact_collector_1.collect()


# Generated at 2022-06-25 00:20:58.355390
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()
    assert var_0 ==  {"local": {}}


# Generated at 2022-06-25 00:21:02.704919
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_1 = local_fact_collector_0.collect()
    assert var_1 == {'local': {}}

    # Method called with params

    local_fact_collector_1 = LocalFactCollector()
    var_2 = local_fact_collector_1.collect(None)
    assert var_2 == {'local': {}}



# Generated at 2022-06-25 00:21:04.817170
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert isinstance(local_fact_collector_0, LocalFactCollector)


# Generated at 2022-06-25 00:21:07.035834
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    var_1 = local_fact_collector.collect()


# Generated at 2022-06-25 00:21:11.244797
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

    # Unit test for method collect
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()