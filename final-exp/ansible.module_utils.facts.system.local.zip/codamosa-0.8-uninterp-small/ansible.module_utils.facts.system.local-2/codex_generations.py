

# Generated at 2022-06-25 00:13:28.495631
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    fact_path = './test/fixtures/'
    params = {'fact_path': fact_path}
    local_fact_collector_1 = LocalFactCollector()
    local_facts_0 = local_fact_collector_1.collect(params, collected_facts=None)
    assert 'local'in local_facts_0
    local_facts_1 = local_facts_0['local']
    assert 'testdata'in local_facts_1
    testdata_fact_0 = local_facts_1['testdata']
    assert 'valid'in testdata_fact_0
    valid_fact_0 = testdata_fact_0['valid']
    assert 'dict'== type(valid_fact_0).__name__



# Generated at 2022-06-25 00:13:32.128241
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect(module=None, collected_facts=None)

# Generated at 2022-06-25 00:13:33.510562
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0.collect() == {'local': {}}

# Generated at 2022-06-25 00:13:37.136459
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    # Arrange
    local_fact_collector = LocalFactCollector()

    # Act
    local_facts = local_fact_collector.collect()

    # Assert
    assert local_facts is not None

# Generated at 2022-06-25 00:13:38.156837
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()


# Generated at 2022-06-25 00:13:40.046316
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert "local" == local_fact_collector_0.name

# Generated at 2022-06-25 00:13:41.750832
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()


# Generated at 2022-06-25 00:13:44.053403
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert hasattr(LocalFactCollector(), 'name')
    assert hasattr(LocalFactCollector(), '_fact_ids')
    assert isinstance(LocalFactCollector()._fact_ids, set)


# Generated at 2022-06-25 00:13:46.007060
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Test passed when no exeception occured
    local_fact_collector_1 = LocalFactCollector()
    assert isinstance(local_fact_collector_1.collect(), dict)

# Generated at 2022-06-25 00:13:48.113556
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # create an instance of class LocalFactCollector
    local_fact_collector_collect_obj = LocalFactCollector()
    # call method collect
    return_value = local_fact_collector_collect_obj.collect()
    print("return_value is " + str(return_value))

# Generated at 2022-06-25 00:14:03.460611
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert isinstance(local_fact_collector._fact_ids, set)



# Generated at 2022-06-25 00:14:05.199888
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    collected_facts = {}
    module = None
    expected_result = {'local': {}}
    result = local_fact_collector_0.collect(module, collected_facts)
    assert result == expected_result

# Generated at 2022-06-25 00:14:09.719792
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    local_fact_collector_collect_0 = local_fact_collector.collect(collected_facts=['ansible_distribution', 'ansible_distribution_version', 'ansible_architecture'])
    assert(local_fact_collector_collect_0 == {})



# Generated at 2022-06-25 00:14:11.562249
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        local_fact_collector_0 = LocalFactCollector()
    except NameError:
        local_fact_collector_0 = None
    assert local_fact_collector_0 is not None

# Generated at 2022-06-25 00:14:12.981013
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    collect_0 = local_fact_collector_0.collect()


# Generated at 2022-06-25 00:14:16.503169
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Create an object of class LocalFactCollector
    local_fact_collector = LocalFactCollector()

    # Check type of class attribute _fact_ids
    assert isinstance(local_fact_collector._fact_ids, set)

    # Check type of class attribute name
    assert isinstance(local_fact_collector.name, str)


# Generated at 2022-06-25 00:14:18.927121
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1.name == 'local'


# Generated at 2022-06-25 00:14:19.704758
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:14:21.376159
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    test_case_0()


if __name__ == '__main__':
    # Run all tests
    test_LocalFactCollector_collect()

# Generated at 2022-06-25 00:14:31.578716
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_2 = LocalFactCollector()
    local_fact_collector_3 = LocalFactCollector()
    local_fact_collector_4 = LocalFactCollector()
    local_fact_collector_5 = LocalFactCollector()
    local_fact_collector_6 = LocalFactCollector()

    # Call method collect of LocalFactCollector with arguments: (mocked_module)
    (local_facts_collector_collection_0, is_facts_changed) = local_fact_collector_0.collect(mocked_module)
    # Check is_facts_changed is False
    assert(is_facts_changed == False)
    # Check if local_facts

# Generated at 2022-06-25 00:14:58.741252
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local', 'Test Failed'
    pass

# Generated at 2022-06-25 00:15:02.974161
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    test_name = 'test_LocalFactCollector_collect'
    test_case_0_params = {
        'fact_path': '/tmp/ansible_test_facts'
    }

    # create test directory
    ansible_test_facts_dir = test_case_0_params['fact_path']
    if not os.path.exists(ansible_test_facts_dir):
        os.makedirs(ansible_test_facts_dir)

    # create files
    ansible_test_facts = [
        'ansible_test_fact_0.fact',
        'ansible_test_fact_1.fact',
        'ansible_test_fact_2.fact'
    ]

# Generated at 2022-06-25 00:15:04.230074
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()


# Generated at 2022-06-25 00:15:06.795059
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local', "local_fact_collector.name should be 'local' but is: %s" % local_fact_collector.name


# Generated at 2022-06-25 00:15:10.077693
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    collected_facts_0 = {}
    local_facts_0 = local_fact_collector_0.collect(module=None, collected_facts=collected_facts_0)
    assert local_facts_0 == {
        'local': {}
    }, 'Return value mismatch'

# Generated at 2022-06-25 00:15:11.284597
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    c = LocalFactCollector()
    assert c._fact_ids == set()


# Generated at 2022-06-25 00:15:16.475164
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:15:21.877933
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert(local_fact_collector_1.name == "local")
    assert(len(local_fact_collector_1.collect().keys()) == 1)
    assert(len(local_fact_collector_1.collect()['local'].keys()) == 0)
    assert(len(local_fact_collector_1.collect(collected_facts = {}).keys()) == 1)
    assert(len(local_fact_collector_1.collect(collected_facts = {})['local'].keys()) == 0)


# Generated at 2022-06-25 00:15:26.663016
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0
    assert isinstance(local_fact_collector_0._fact_ids, set)
    assert local_fact_collector_0.name == 'local'


# Generated at 2022-06-25 00:15:30.779579
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    module = type('', (object,), {'run_command': lambda x: (0, '', ''), 'warn': lambda x: None})
    fact_path = '/home/user/ansible_facts'
    module.params = {"fact_path": fact_path}
    assert 'local' in local_fact_collector.collect(module)

# Generated at 2022-06-25 00:16:26.440684
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    config = "{'fact_path': '/etc/ansible/facts.d'}"
    config = json.loads(config)
    module = MockModule(config)
    local_fact_collector_1 = LocalFactCollector()
    ans = local_fact_collector_1.collect(module)
    assert ans == {
        'local': {
            'test.fact': {
                'test': {
                    'test_val': '2',
                },
                'test2': {
                    'test_val': '3',
                },
            }
        }
    }


# Generated at 2022-06-25 00:16:30.362017
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = None
    collected_facts = {}
    local_fact_collector = LocalFactCollector()
    result = local_fact_collector.collect(module, collected_facts)
    assert result is not None
    assert result['local'] is not None
    assert len(result['local'].keys()) == 1
    assert result['local']['local'] is not None
    assert len(result['local']['local'].keys()) == 0

# Generated at 2022-06-25 00:16:31.718213
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    with pytest.raises(Exception):
        local_fact_collector = LocalFactCollector()

# Generated at 2022-06-25 00:16:37.901794
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    temp_module = get_module(**dict(
        basedir='/foo/bar',
        fact_path='/foo/bar/buz',
    ))

    temp_module.run_command = MagicMock(return_value=(0, '', ''))

    temp_collected_facts = dict()

    result = local_fact_collector_0.collect(temp_module, temp_collected_facts)

    assert result is not None
    assert 'local' in result.keys()
    assert result['local'] is not None
    assert len(result['local'].keys()) == 1
    assert result['local']['buz'] is not None
    assert len(result['local']['buz']) == 1
    assert result['local']['buz']['section'] is not None

# Generated at 2022-06-25 00:16:41.012096
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()


# Generated at 2022-06-25 00:16:43.710847
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1._fact_ids == set()


# Generated at 2022-06-25 00:16:45.454330
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()

    assert local_fact_collector.collect() == {'local': {}}



# Generated at 2022-06-25 00:16:48.288838
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_facts_collector = LocalFactCollector()
    result = local_facts_collector.collect()

# Generated at 2022-06-25 00:16:51.937758
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    # TODO: Add test cases for method collect of class LocalFactCollector


# Generated at 2022-06-25 00:17:01.581860
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    fact_path = "tests/unit/ansible_modlib.extract_facts/s00_fact_collection_local/local_facts"
    local_fact_collector = LocalFactCollector()
    collected_facts = local_fact_collector.collect(fact_path)
  
    fact_base1 = 'test_0_fact'
    fact_base2 = 'test_1_fact'
    fact_base3 = 'test_2_fact'
    fact_base4 = 'test_3_fact'
    fact_base5 = 'test_4_fact'
    fact_base6 = 'test_5_fact'
    fact_base7 = 'test_6_fact'
    fact_base8 = 'test_7_fact'
    fact_base9 = 'test_8_fact'
    fact_

# Generated at 2022-06-25 00:19:03.588582
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert local_fact_collector_0.name == 'local'

### END ###

# Generated at 2022-06-25 00:19:05.178091
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:

# Generated at 2022-06-25 00:19:10.403293
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    local_fact_collector_0 = LocalFactCollector()
    fact_path = os.path.dirname(os.path.realpath(__file__)) + "/test_resources/facts.d"
    module = type('module', (), {"run_command":run_command_0, "warn":warn_0, "params":{"fact_path":fact_path}})
    collected_facts = {}
    result = local_fact_collector_0.collect(module, collected_facts)

# Generated at 2022-06-25 00:19:12.776134
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'

    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1.name == 'local'

    local_fact_collector_2 = LocalFactCollector()
    assert local_fact_collector_2.name == 'local'

# Generated at 2022-06-25 00:19:15.203573
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    # No point in testing anything else since it doesn't work under
    # AnsibleEngineCI
    assert 1 == 1

# Generated at 2022-06-25 00:19:19.865230
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    # set up test objects
    local_fact_collector = LocalFactCollector()

    # run the code
    result = local_fact_collector.collect()

    # make assertions
    assert isinstance(result, dict)

# Generated at 2022-06-25 00:19:21.559021
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_facts = LocalFactCollector()
    assert local_facts.name == LocalFactCollector.name


# Generated at 2022-06-25 00:19:31.127421
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_facts = local_fact_collector_0.collect()
    assert local_facts['local']['facts_0'] == {'foo': {'key1': 'value1', 'key2': 'value2'}, 'bar': {'key1': 'value1', 'key2': 'value2'}}
    assert local_facts['local']['facts_1'] == 'Fact script (%s) returned non-zero ex: %s' % ('/etc/ansible/facts.d/facts_1.fact', '2')
    assert local_facts['local']['facts_2'] == 'Fact script (%s) return non-zero exit code: %s' % ('/etc/ansible/facts.d/facts_2.fact', '2')

# Generated at 2022-06-25 00:19:36.843622
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    # collect data from local facts
    def test_run_command(self, cmd, in_data=None, sudoable=False):
        rc = 0
        err = ''
        out = json.dumps({'http_proxy': 'gateway.example.org:3128'})
        return rc, out, err

    # collect data from local facts
    def test_run_command_err(self, cmd, in_data=None, sudoable=False):
        rc = 1
        err = 'File not found'
        out = ''
        return rc, out, err

    def test_warn(self, msg):
        print(msg)

    local_facts = {}
    local_fact_collector_1 = LocalFactCollector()

    # test ansible module parameters

# Generated at 2022-06-25 00:19:38.228837
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_collect = LocalFactCollector()
    assert True == local_fact_collector_collect.collect()


# Generated at 2022-06-25 00:22:00.473199
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    assert not ((local_fact_collector_0.collect() is not None) and (type(local_fact_collector_0.collect()) is dict))


# Generated at 2022-06-25 00:22:02.066324
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_obj = LocalFactCollector()
    local_fact_collector_obj.collect()


# Generated at 2022-06-25 00:22:06.687943
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_1 = {'local': {}}
    local_fact_collector_1['local'] = None
    local_fact_collector_0.collect(None, local_fact_collector_1)
    var_0 = local_fact_collector_0.collect()
    try:
        assert var_0 == {}
    except:
        print("Assertion failed!")
    


# Generated at 2022-06-25 00:22:08.460798
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()

# Generated at 2022-06-25 00:22:09.903832
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1 is not None

# Generated at 2022-06-25 00:22:12.417526
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()

# Generated at 2022-06-25 00:22:17.525555
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()
    assert var_0 == {}

# Generated at 2022-06-25 00:22:20.189857
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    if os.path.isfile(test_case_0()):
        local_fact_collector_0.collect(test_case_0())
    else:
        assert False

# Generated at 2022-06-25 00:22:20.915493
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()


# Generated at 2022-06-25 00:22:23.104441
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector == LocalFactCollector()