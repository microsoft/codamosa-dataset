

# Generated at 2022-06-25 00:13:22.632228
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    dict_1 = local_fact_collector_1.collect()
    assert (dict_1 == {'local': {}}), 'Test Case 1 Failed'


# Generated at 2022-06-25 00:13:25.151663
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.collect() == {}

# Generated at 2022-06-25 00:13:25.819437
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()

# Generated at 2022-06-25 00:13:27.219605
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert len(LocalFactCollector._fact_ids) == 0
    assert len(LocalFactCollector.name) > 0

# Generated at 2022-06-25 00:13:30.914586
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    try:
        local_fact_collector_1.collect()
    except:
        pass

# Generated at 2022-06-25 00:13:36.605791
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert 'BaseFactCollector' in str(type(local_fact_collector_0))
    assert local_fact_collector_0.name == 'local'
    # assert local_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:13:43.610341
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    (os_version_meta,) = local_fact_collector_0.collect()
    local_fact_collector_0._fact_ids = [u'os_version_meta']
    assert local_fact_collector_0._fact_ids == ['os_version_meta']

if __name__ == "__main__":
   test_LocalFactCollector_collect()

# Generated at 2022-06-25 00:13:44.959088
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector is not None

# Generated at 2022-06-25 00:13:54.405998
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
  local_fact_collector = LocalFactCollector()
  fact_path = {'fact_path':'/opt/ansible_test/test_facts'}
  module = type('module',(object,), {'params': fact_path,'run_command': run_command})
  return_val = local_fact_collector.collect(module=module)

# Generated at 2022-06-25 00:13:55.608600
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()



# Generated at 2022-06-25 00:14:03.572426
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1.name == 'local'

# Generated at 2022-06-25 00:14:10.974514
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    from ansible.module_utils.facts import ModuleStub
    import pytest
    from tempfile import mkdtemp
    from shutil import rmtree
    import os

    p = os.path.join
    temp_dir = mkdtemp()
    file_names = ["fact.fact", "fact.json", "fact.ini", "fact.py"]

    for fn in file_names:
        fd = open(p(temp_dir, fn), "w")
        if ".json" in fn:
            fd.write('{"fact": "value"}')
        elif ".ini" in fn:
            fd.write('[fact]\nvalue\n')

# Generated at 2022-06-25 00:14:17.730111
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    local_fact_collector_1 = LocalFactCollector()

    module_1 = object()
    collected_facts_1 = object()

    local_facts_1 = local_fact_collector_1.collect(module_1, collected_facts_1)

    # test_case_0 does not work
    assert local_facts_1 == {'local': {}}

    return

# Generated at 2022-06-25 00:14:18.581500
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()


# Generated at 2022-06-25 00:14:21.024298
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set([])


# Generated at 2022-06-25 00:14:22.540587
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector is not None


# Generated at 2022-06-25 00:14:23.019355
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass

# Generated at 2022-06-25 00:14:24.291263
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()


# Generated at 2022-06-25 00:14:27.407947
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # check if it can collect facts
    local_fact_collector_0 = LocalFactCollector()
    local_facts = {}
    assert local_fact_collector_0.collect(collected_facts=local_facts)


# Generated at 2022-06-25 00:14:29.596414
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0._fact_ids == set()
    assert local_fact_collector_0.name is 'local'


# Generated at 2022-06-25 00:14:37.600897
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()



# Generated at 2022-06-25 00:14:38.698881
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert(LocalFactCollector().name == 'local')


# Generated at 2022-06-25 00:14:42.699829
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    local_fact_collector.collect()
    print('__main__')
    print('    local_fact_collector = LocalFactCollector()')
    print('    local_fact_collector.collect()')
    print('END')


if __name__ == '__main__':
    local_fact_collector = LocalFactCollector()
    local_fact_collector.collect()

# Generated at 2022-06-25 00:14:45.726686
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_1.collect()

# Generated at 2022-06-25 00:14:48.702729
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()


# Generated at 2022-06-25 00:14:50.277568
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert isinstance(local_fact_collector_0, LocalFactCollector)


# Generated at 2022-06-25 00:14:53.156582
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()


# Generated at 2022-06-25 00:14:55.743135
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    do_test(test_case_0)

test_cases = [
    test_case_0,
]


# Generated at 2022-06-25 00:14:58.184537
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    # Run test against a mock module
    local_fact_collector_0.collect()
    # TODO: implement real test
    assert True

# Generated at 2022-06-25 00:14:59.532632
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_2 = LocalFactCollector()
    var_1 = local_fact_collector_2.collect()


# Generated at 2022-06-25 00:15:15.303082
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    fact_path = None
    module = None
    # Test case 0
    fact_path = 'fake_path'
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_1 = LocalFactCollector()
    var_0 = local_fact_collector_1.collect()
    assert var_0 == {}
    assert local_fact_collector_0._fact_ids == set()
    assert local_fact_collector_1._fact_ids == set()

# Generated at 2022-06-25 00:15:17.559128
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()

# Generated at 2022-06-25 00:15:19.196601
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    result = LocalFactCollector()
    assert result.name == 'local'
    assert result._fact_ids == set()


# Generated at 2022-06-25 00:15:21.054472
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    pass



# Generated at 2022-06-25 00:15:26.080614
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_1.collect()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:15:32.564339
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    mock_module = type('mock_module', (object,), {})
    mock_module.params = type('mock_params', (object,), {"get": lambda self, _, default=None: default})
    mock_module.warn = type('mock_warn', (object,), {})
    mock_module.run_command = type('mock_run_command', (object,), {"__call__": lambda self, _: (0, "", "")})
    patcher = patch('ansible.module_utils.facts.local.get_file_content', side_effect=[b'', b''])
    patcher.start()
    lfc = LocalFactCollector()
    result0 = lfc.collect(module=mock_module)
    assert isinstance(result0, dict)
    patcher.stop()

# Generated at 2022-06-25 00:15:34.815624
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()

# Generated at 2022-06-25 00:15:36.269620
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert True

# Generated at 2022-06-25 00:15:38.797189
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    local_fact_collector = LocalFactCollector()
    # assert local_fact_collector.collect()[0] = LocalFactCollector()
    assert local_fact_collector.name == 'local'


# Generated at 2022-06-25 00:15:40.507814
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert isinstance(local_fact_collector, LocalFactCollector)


# Generated at 2022-06-25 00:16:11.607125
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()


# Generated at 2022-06-25 00:16:15.612085
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:16:17.065183
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    assert isinstance(local_fact_collector.collect(), dict)

# Generated at 2022-06-25 00:16:19.378373
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        local_fact_collector = LocalFactCollector()
    except Exception as e:
        assert False , "constructor test of class `LocalFactCollector` failed"



# Generated at 2022-06-25 00:16:23.909759
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()

# Generated at 2022-06-25 00:16:25.345821
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # just run it to make pylint and the test happy
    test_case_0()


# Generated at 2022-06-25 00:16:27.343132
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    assert isinstance(local_fact_collector_0.collect(), dict)


# Generated at 2022-06-25 00:16:29.561652
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        test_case_0()
    except Exception as err:
        print(err)
        assert False

test_LocalFactCollector()

# Generated at 2022-06-25 00:16:35.912562
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import tempfile
    import os

    # create a config file
    (fd, fact_file) = tempfile.mkstemp()

    with os.fdopen(fd, 'w') as f:
        f.write("""[section]
opt=val
""")
    # create a fact file, just a text file with a json content
    (fd, fact_file) = tempfile.mkstemp()

    with os.fdopen(fd, 'w') as f:
        f.write("""{"a":"b"}
""")

    # create a fact file, json file
    (fd, fact_file) = tempfile.mkstemp()

    with os.fdopen(fd, 'w') as f:
        f.write("""{"a":"b"}
""")

    # create a fact file, will be executed


# Generated at 2022-06-25 00:16:37.538572
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1.name == 'local'

# Generated at 2022-06-25 00:17:49.058620
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_obj_0 = LocalFactCollector()
    assert local_fact_collector_obj_0.name == 'local'
    assert local_fact_collector_obj_0._fact_ids == set()
    assert local_fact_collector_obj_0.priority == 80


# Generated at 2022-06-25 00:17:50.447867
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()

# Generated at 2022-06-25 00:17:52.608884
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'


# Generated at 2022-06-25 00:17:53.785727
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    pass # test case for constructor


# Generated at 2022-06-25 00:18:03.333176
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = AnsibleModule(
        argument_spec = dict(
            fact_path=dict(default=None, type='str'),
        ),
        supports_check_mode=True
    )

    path = os.path.join(os.path.dirname(os.path.realpath(__file__)),
                        'unit', 'modules', 'test-support-resources', 'local')
    module.params['fact_path'] = path
    local_fact_collector = LocalFactCollector()
    facts = local_fact_collector.collect(module, {})
    facts = facts['local']

    assert facts['fact_file_0']['fact_option_0'] == 'fact_option_value_0'

# Generated at 2022-06-25 00:18:06.054814
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert(local_fact_collector.name == 'local')

# Generated at 2022-06-25 00:18:07.523803
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector is not None


# Generated at 2022-06-25 00:18:10.597544
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1.collect() == local_fact_collector_0.collect()

# Generated at 2022-06-25 00:18:12.656736
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    try:
        local_fact_collector_0.collect()
    except NotImplementedError:
        pass # expected


# Generated at 2022-06-25 00:18:13.519932
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    variable = LocalFactCollector()
    variable.collect()

# Generated at 2022-06-25 00:20:57.823515
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # set up parameters
    module_0 = []

    # invoke the method
    collected_facts_0 = LocalFactCollector.collect(module_0)



# Generated at 2022-06-25 00:21:00.317445
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Input parameters
    module = None
    collected_facts = None

    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect(module, collected_facts)

# Generated at 2022-06-25 00:21:01.283978
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()

# Generated at 2022-06-25 00:21:08.711638
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    with pytest.raises(TypeError):
        var_0 = local_fact_collector_0.collect(collected_facts = ('collected_facts',))

    # Test with a non-None collected_facts.
    var_0 = local_fact_collector_0.collect(collected_facts = None)
    assert var_0 == {'local': {}}

    # Test with a None collected_facts.
    var_0 = local_fact_collector_0.collect(collected_facts = None)
    assert var_0 == {'local': {}}

    # Test with a None collected_facts and a non-None module.
    local_fact_collector_1 = LocalFactCollector()
    var_0 = local_fact_collector

# Generated at 2022-06-25 00:21:11.412924
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    var_0 = LocalFactCollector()
    var_1 = LocalFactCollector()


# Generated at 2022-06-25 00:21:15.273736
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_1 = LocalFactCollector()
    var_0 = local_fact_collector_1.collect()


if __name__ == '__main__':
    test_case_0()
    test_LocalFactCollector_collect()

# Generated at 2022-06-25 00:21:19.500726
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_obj = LocalFactCollector()
    collected_facts_obj = {}
    # incase the module is not passed, collected facts will be returned as empty dict
    collected_facts_obj = local_fact_collector_obj.collect()
    assert collected_facts_obj == {}

# Generated at 2022-06-25 00:21:22.800414
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # arrange
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_1 = LocalFactCollector()
    # assert
    assert local_fact_collector_0 is not None
    assert local_fact_collector_1 is not None


# Generated at 2022-06-25 00:21:26.194268
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_1 = LocalFactCollector()
    var_0 = local_fact_collector_1.collect()
    assert var_0 == dict()


# Generated at 2022-06-25 00:21:27.715322
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_2 = LocalFactCollector()
    assert local_fact_collector_2 is not None
