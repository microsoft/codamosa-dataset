

# Generated at 2022-06-25 00:13:18.617106
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Testing for empty dict facts
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()
    assert local_fact_collector.collect() == {u'local': {}}

# Generated at 2022-06-25 00:13:22.345450
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0._fact_ids == set(), 'Unit test for constructor of class LocalFactCollector #0 failed'



# Generated at 2022-06-25 00:13:24.569874
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()

# Generated at 2022-06-25 00:13:25.382066
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    LocalFactCollector.collect()

# Generated at 2022-06-25 00:13:27.070881
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    try:
        local_fact_collector = LocalFactCollector()
        local_fact_collector.collect()
    except:
        pass

# Generated at 2022-06-25 00:13:32.361692
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    collected_facts_1 = {}
    local_facts_dict_1 = {'local': {'test_fact_1': {"the_test_fact_1": "the_test_fact_1"}}}
    assert local_facts_dict_1 == local_fact_collector_1.collect(None, collected_facts_1), "test_LocalFactCollector_collect: error test_case_1"
    local_fact_collector_2 = LocalFactCollector()
    collected_facts_2 = {}
    local_facts_dict_2 = {'local': {'test_fact_2': {"the_test_fact_2": "the_test_fact_2"}}}
    assert local_facts_dict_2 == local_fact_collector_2.collect

# Generated at 2022-06-25 00:13:33.431115
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert('local' == LocalFactCollector().name)
    assert(set() == LocalFactCollector()._fact_ids)



# Generated at 2022-06-25 00:13:35.943232
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()


# Generated at 2022-06-25 00:13:38.066952
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    global local_fact_collector_0
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'



# Generated at 2022-06-25 00:13:39.992033
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_1.collect()

# Generated at 2022-06-25 00:13:54.812444
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    module_0 = None
    collected_facts_0 = {}
    local_facts_0 = local_fact_collector_0.collect(module=module_0, collected_facts=collected_facts_0)
    assert local_facts_0 == {'local': {}}
    local_fact_collector_1 = LocalFactCollector()

# Generated at 2022-06-25 00:13:56.466364
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    collector = LocalFactCollector()
    assert collector.name == 'local'

# Generated at 2022-06-25 00:14:03.005993
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local', "Unit test for constructor of class LocalFactCollector"



# Generated at 2022-06-25 00:14:04.986388
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()

test_case_0()


# Generated at 2022-06-25 00:14:07.604657
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    assert isinstance(local_fact_collector_0.collect(), dict)

# Generated at 2022-06-25 00:14:09.165106
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert type(local_fact_collector_0.name) == str

# Generated at 2022-06-25 00:14:14.598104
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()

# Generated at 2022-06-25 00:14:15.464168
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()


# Generated at 2022-06-25 00:14:19.086626
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'


# Generated at 2022-06-25 00:14:21.824912
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:14:35.315356
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:14:36.907623
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()

# Generated at 2022-06-25 00:14:37.674620
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector().name == 'local'

# Generated at 2022-06-25 00:14:39.646069
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:14:42.460993
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert isinstance(LocalFactCollector().name, str)
    assert isinstance(LocalFactCollector()._fact_ids, set)


# Generated at 2022-06-25 00:14:45.012351
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert isinstance(local_fact_collector_0, LocalFactCollector)



# Generated at 2022-06-25 00:14:48.659677
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_1 = LocalFactCollector()



# Generated at 2022-06-25 00:14:52.563721
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'

# Generated at 2022-06-25 00:14:55.603062
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    print("Test Class Constructor for LocalFactCollector")


# Generated at 2022-06-25 00:14:58.333033
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()

    facts_1 = local_fact_collector_1.collect(module=None, collected_facts=None)
    assert facts_1 == {u'local': {}}

# Generated at 2022-06-25 00:15:10.728452
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    current_result = LocalFactCollector()
    assert current_result is not None


# Generated at 2022-06-25 00:15:16.269236
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    # Testing default _fact_ids
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:15:19.129446
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_0.collect() == local_fact_collector_1.collect()

# Generated at 2022-06-25 00:15:22.272131
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:15:25.250091
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert(local_fact_collector_1.name == 'local')


# Generated at 2022-06-25 00:15:27.080487
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'
    assert LocalFactCollector._fact_ids == set()


# Generated at 2022-06-25 00:15:32.314029
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_module = LocalFactCollector()
    assert(isinstance(local_fact_collector_module, LocalFactCollector))

# Generated at 2022-06-25 00:15:36.345695
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()

    # Test with dummy values
    module_1 = None
    collected_facts_1 = None
    result = local_fact_collector_1.collect(module=module_1, collected_facts=collected_facts_1)
    assert result is not None


# Generated at 2022-06-25 00:15:37.876069
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector().name == 'local'
    assert LocalFactCollector()._fact_ids == set()


# Generated at 2022-06-25 00:15:39.343845
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector != None


# Generated at 2022-06-25 00:15:55.910271
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()

# Generated at 2022-06-25 00:15:57.743998
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.collect() == {}


# Generated at 2022-06-25 00:16:04.801504
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fact_path = '/path/to/fact/'
    # Test class constructor
    local_fact_collector = LocalFactCollector()
    # Test name
    assert local_fact_collector.name == 'local'
    # Test _fact_ids
    assert local_fact_collector._fact_ids == set()
    # Test collect
    test_collected_facts = {}
    local_facts = local_fact_collector.collect(fact_path=fact_path, collected_facts=test_collected_facts)
    assert local_facts == {'local': {}}
    # Test name
    assert local_fact_collector.name == 'local'
    # Test _fact_ids
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-25 00:16:07.320550
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.collect() == {}
    assert local_fact_collector.collect(module='') == {}

# Generated at 2022-06-25 00:16:08.966382
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector().name == 'local'

# Generated at 2022-06-25 00:16:13.947133
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    dummy_dict = {'fact_path':'/home/nathangarwood/ansible/test/facts/local/test_fact_path', 'local': {'test_fact': True} }
    assert LocalFactCollector().collect(module=dummy_dict) == {'local': {'test_fact': True}}


# Generated at 2022-06-25 00:16:16.790645
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.collect() == {'local': {}}


if __name__ == "__main__":
    test_LocalFactCollector_collect()

# Generated at 2022-06-25 00:16:17.412838
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()


# Generated at 2022-06-25 00:16:18.118587
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector()

# Generated at 2022-06-25 00:16:23.720793
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    # facts from /etc/ansible/facts.d/
    facts_1 = local_fact_collector_0.collect()

    assert(facts_1.get('local') is not None)
    assert(len(facts_1.get('local')) > 0)

    local_facts = facts_1.get('local', {})
    assert('meta' in local_facts)
    assert(isinstance(local_facts['meta'], dict))
    meta_facts = local_facts['meta']
    assert('hostvars' in meta_facts)
    assert(isinstance(meta_facts['hostvars'], dict))
    hostvars_facts = meta_facts['hostvars']

# Generated at 2022-06-25 00:17:00.868040
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    # Test following two cases:
    # Case 1: when the global fact path exists.
    local_fact_collector_1.collect(module=None, collected_facts=None)

    # Case 2: when the global fact path does not exist.
    # This case cannot be reproduced here but can be tested from
    # command line as follows:
    # $ ansible -m setup -a 'filter=ansible_local' localhost -c local

# Generated at 2022-06-25 00:17:02.659347
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    facts = local_fact_collector.collect()
    assert facts == {'local': {}}


# Generated at 2022-06-25 00:17:04.007855
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    localFactCollector = LocalFactCollector()
    assert localFactCollector.name == 'local'

# Generated at 2022-06-25 00:17:06.342433
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_1.collect()


# Generated at 2022-06-25 00:17:08.969771
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'


# Generated at 2022-06-25 00:17:12.260122
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import ansible.module_utils.facts.collector
    local_fact_collector_0 = ansible.module_utils.facts.collector.LocalFactCollector()
    local_facts_0 = local_fact_collector_0.collect()

    assert len(local_facts_0) == 1 and len(local_facts_0['local']) == 0


# Generated at 2022-06-25 00:17:17.277062
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    result = local_fact_collector_0.collect()
    assert result == {'local': {}}



# Generated at 2022-06-25 00:17:19.809450
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert isinstance(local_fact_collector, LocalFactCollector)



# Generated at 2022-06-25 00:17:23.426090
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    dict_0 = local_fact_collector_0.collect()
    with open('collector_test_0.json', 'w') as f:
        json.dump(dict_0, f, indent=4)


# Generated at 2022-06-25 00:17:28.155162
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    """
    test for retrieving local facts
    """
    local_fact_collector_0 = LocalFactCollector()

    # test for running local facts
    module = None
    assert local_fact_collector_0.collect(module) == {'local': {}}

    test_local_facts = local_fact_collector_0.collect(module)

    assert isinstance(test_local_facts, dict)

# Generated at 2022-06-25 00:18:24.446019
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()


# Generated at 2022-06-25 00:18:27.233843
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.collect() == {'local': {}}


# Generated at 2022-06-25 00:18:30.398164
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_2 = LocalFactCollector()
    assert local_fact_collector_2 is not None


# Generated at 2022-06-25 00:18:34.738617
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    
    # Constructor test case 1 with arguments
    local_fact_collector_1 = LocalFactCollector(
        module=None,
        collected_facts=None
    )


# Generated at 2022-06-25 00:18:36.650246
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        local_fact_collector_1 = LocalFactCollector()
        assert True

    except Exception:
        assert False


# Generated at 2022-06-25 00:18:44.241085
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # test the path to the fact_path so we can test the functionality
    # of the collect method, add a file and show the output
    #Test 1 - test with fact_path and file
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_1.fact_path = "/home/ansible/ansible/unitTests/testFacts/"
    assert local_fact_collector_1.collect() == {'local': {'testFactCollector': 'testFactCollector'}}

    #Test 2 - test with fact_path and no file
    local_fact_collector_2 = LocalFactCollector()
    local_fact_collector_2.fact_path = "/home/ansible/ansible/unitTests/testFacts/empty"
    assert local_fact_collector_

# Generated at 2022-06-25 00:18:47.106247
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    local_fact_collector.collect()
    assert isinstance(local_fact_collector.collect(), dict)

# Generated at 2022-06-25 00:18:50.214745
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:18:52.039443
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        test_case_0()
    except:
        assert False

if __name__ == '__main__':
    test_LocalFactCollector()

# Generated at 2022-06-25 00:19:00.785193
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0._populate_facts_from_cache = lambda x: {'local': {'local': {'local_fact_collector_test_result': 'local_fact_collector_test_result'}, 'module_name': 'local_fact_collector_test'}}
    local_fact_collector_0.collect()
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_1._populate_facts_from_cache = lambda x: {'local': {'local': {'local_fact_collector_test_result': 'local_fact_collector_test_result'}, 'module_name': 'local_fact_collector_test'}}
    local_fact_collector_

# Generated at 2022-06-25 00:21:25.289018
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    local_facts = local_fact_collector_1.collect()

    assert local_facts.get('local') is not None


# Generated at 2022-06-25 00:21:27.855361
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_facts_0 = local_fact_collector_0.collect()
    assert isinstance(local_facts_0, dict)
    assert isinstance(local_facts_0.get('local'), dict)

# Generated at 2022-06-25 00:21:31.785179
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()

# Generated at 2022-06-25 00:21:33.572481
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    actual_output = LocalFactCollector()
    expected_output = "LocalFactCollector Class Test Successfull"
    assert expected_output == actual_output, 'Test Failed'



# Generated at 2022-06-25 00:21:37.689652
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()

# Generated at 2022-06-25 00:21:40.010276
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:21:42.670813
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()

# Generated at 2022-06-25 00:21:46.332731
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # test_case_0()
    local_fact_collector_0 = LocalFactCollector()

# Generated at 2022-06-25 00:21:51.907259
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1.collect(collected_facts=None) == {'local': {}}

    local_fact_collector_2 = LocalFactCollector()
    assert local_fact_collector_2.collect(collected_facts=None) == {'local': {}}

    local_fact_collector_3 = LocalFactCollector()
    assert local_fact_collector_3.collect(collected_facts=None) == {'local': {}}

# Generated at 2022-06-25 00:21:52.941017
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()

