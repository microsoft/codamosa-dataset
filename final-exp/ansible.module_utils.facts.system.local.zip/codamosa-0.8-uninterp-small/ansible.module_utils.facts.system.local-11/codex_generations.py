

# Generated at 2022-06-25 00:13:28.686098
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    try:
        os.mkdir('/tmp/test_LocalFactCollector_collect')
    except OSError:
        pass
    try:
        os.mkdir('/tmp/test_LocalFactCollector_collect/facts.d')
    except OSError:
        pass
    try:
        os.chdir('/tmp/test_LocalFactCollector_collect')
    except OSError:
        pass
    with open('facts.d/facts.d', 'w') as fp_0:
        fp_0.write('{"foo": "bar"}\n')
    str_0 = '/tmp/test_LocalFactCollector_collect/facts.d'
    local_fact_collector_0 = LocalFactCollector(str_0)

# Generated at 2022-06-25 00:13:33.564091
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector('local')
    local_fact_collector_1 = LocalFactCollector()


if __name__ == "__main__":
    test_case_0()
    test_LocalFactCollector()

# Generated at 2022-06-25 00:13:36.348016
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector('AKQa')


# Generated at 2022-06-25 00:13:41.142209
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Unit tests for collect in LocalFactCollector
    local_fact_collector_0 = LocalFactCollector('K')
    local_fact_collector_0.collect()


# Generated at 2022-06-25 00:13:47.071162
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    str_0 = 'K'
    local_fact_collector_0 = LocalFactCollector(str_0)
    module_0 = none(local_fact_collector_0)
    str_1 = 'local'
    dict_0 = local_fact_collector_0.collect(module_0, str_1)

    for key, val in dict_0.items():
        if key == 'local' and val == {}:
            continue


# Generated at 2022-06-25 00:13:57.341312
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    file_path_0 = '/etc/ansible/facts.d/file_1'
    file_path_1 = '/etc/ansible/facts.d/file_2'
    data_1 = '''
    [sect_1]
    opt_1 = val_1
    opt_2 = val_2
    '''
    data_2 = '''
    {
        "var_1": "val_1",
        "var_2": "val_2"
    }
    '''
    # one of the files can't be read
    if os.path.exists(file_path_0):
        os.remove(file_path_0)
    if os.path.exists(file_path_1):
        os.remove(file_path_1)

# Generated at 2022-06-25 00:14:02.121790
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    str_0 = 'K'
    test_case_0(str_0)


# Generated at 2022-06-25 00:14:05.801665
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    str_0 = 'K'
    local_fact_collector_0 = LocalFactCollector(str_0)
    assert local_fact_collector_0.name == 'K'
    assert local_fact_collector_0.failed is False
    assert local_fact_collector_0._fact_ids == set()
    assert local_fact_collector_0.priority == 99


# Generated at 2022-06-25 00:14:09.262393
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector(str)
    str = 'K'
    # assert local_fact_collector_0.collect(str) == {'local': {}}

# Generated at 2022-06-25 00:14:09.976701
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()

# No test cases

# Generated at 2022-06-25 00:14:25.963110
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    d_0 = {'v': 0}
    d_0['k'] = 'K'
    d_0['v'] = 'V'
    d_1 = {'v': 0}
    d_1['v'] = d_0
    k_0 = 'k'
    k_1 = 'v'
    d_2 = {'v': 0}
    d_2['k'] = 'K'
    d_2['v'] = 'V'
    d_3 = {'v': 0}
    d_3['k'] = 'K'
    d_3['v'] = 'V'
    d_4 = {'k': 'V', 'v': 'V'}
    d_5 = {'k': 'V', 'v': 'V'}

    # Creating a mock of module
   

# Generated at 2022-06-25 00:14:28.955414
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create instance of class 'LocalFactCollector'
    local_fact_collector_obj = LocalFactCollector()
    # Call method 'collect' of the class 'LocalFactCollector' with arguments
    result = local_fact_collector_obj.collect()

# Generated at 2022-06-25 00:14:30.313197
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fact_path = '/etc/ansible/facts.d'
    local_facts = LocalFactCollector


# Generated at 2022-06-25 00:14:39.858851
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    str_0 = 'K'
    str_1 = 'B'
    str_2 = 'k'
    str_3 = 'J'
    str_4 = 'J'
    str_5 = 'K'
    str_6 = 'X'
    str_7 = '.'
    str_8 = 'y'
    str_9 = 'I'
    str_10 = 'P'
    str_11 = 'K'
    str_12 = 'K'
    str_13 = 'X'
    str_14 = '.'
    str_15 = 'y'
    str_16 = 'I'
    str_17 = 'P'
    obj_0 = LocalFactCollector()
    obj_1 = LocalFactCollector()
    obj_2 = LocalFactCollector()
    obj_3 = Local

# Generated at 2022-06-25 00:14:44.171860
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        LocalFactCollector()
        test_case_0()
    except Exception as e:
        print('test_LocalFactCollector failed:', str(e))


# Generated at 2022-06-25 00:14:47.341137
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    test_LocalFactCollector = LocalFactCollector()
    test_LocalFactCollector.collect()

# Generated at 2022-06-25 00:14:50.025806
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    str_0 = 'local'
    str_1 = 'K'
    str_2 = 'K'
    str_3 = 'G'
    str_4 = 'G'
    str_5 = 'G'



# Generated at 2022-06-25 00:14:52.934912
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Setup a test for method collect of class LocalFactCollector in module local_facts.py
    fact_path = None
    module = None

    # Exercise the method
    local_facts_1 = LocalFactCollector.collect(fact_path, module)
    # Teardown the test
    return local_facts_1

# Generated at 2022-06-25 00:14:55.656308
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

    # Test with state == 'absent'
    test_case_0()

    # Test with state == 'present'
    test_case_1()

# Generated at 2022-06-25 00:14:57.485567
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    localFactCollector = LocalFactCollector()
    assert localFactCollector.collect() == {'local': {}}


# Generated at 2022-06-25 00:15:05.851047
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fact_path = "mock"
    try:
        LocalFactCollector(fact_path)
    except:
        assert False
    else:
        assert True

# Unit tests for class LocalFactCollector

# Generated at 2022-06-25 00:15:12.544889
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    str_1 = 'K'
    fail = None
    set_0 = set()
    c = LocalFactCollector()
    collected_facts = {}
    module = None
    local_facts = c.collect(collected_facts=collected_facts, module=module) # result of this method is local_facts
    str_2 = 'local'
    assert local_facts[str_1] == local_facts[str_2]


# Generated at 2022-06-25 00:15:16.856948
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_var_0 = LocalFactCollector()
    test_var_2 = LocalFactCollector()
    try:
        test_var_1 = LocalFactCollector()
    except Exception:
        pass
    test_var_0.name = 'name'
    str_0 = test_var_0.name
    str_1 = test_var_0._fact_ids
    test_var_0._fact_ids = '_fact_ids'
    str_2 = test_var_0._fact_ids
    str_3 = test_var_0._fact_ids
    test_var_1 = test_var_0.collect()
    test_var_0._fact_ids = '_fact_ids'
    return str_0, str_1, str_2, str_3, test_var_1



# Generated at 2022-06-25 00:15:19.351113
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    file = 'tst/'
    localFactCollector = LocalFactCollector(file)
    if localFactCollector.fact_path != 'tst/local/':
        return False

    return True


# Generated at 2022-06-25 00:15:21.100585
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    localFactCollector_0 = LocalFactCollector()
    random_0 = test_case_0()
    # TODO: create test cases for method collect of class LocalFactCollector

# Generated at 2022-06-25 00:15:30.911016
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    fn = 'fn'
    fact_base = 'fact_base'
    fact_path = 'fact_path'
    fact_base_0 = 'fact_base_0'
    str_0 = 'L'
    e = 'e'
    val = 'val'
    sect = 'sect'
    opt = 'opt'
    fact = 'fact'
    fn_0 = 'fn_0'
    str_1 = 'M'
    str_2 = 'N'
    fact_base_1 = 'fact_base_1'
    str_3 = 'O'
    fact_0 = 'fact_0'
    e_0 = 'e_0'
    return_value = {}
    return_value['local'] = {}

# Generated at 2022-06-25 00:15:33.161013
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert 'local' == local_fact_collector.name
    assert 'set()' == str(local_fact_collector._fact_ids)


# Generated at 2022-06-25 00:15:35.408711
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'


# Generated at 2022-06-25 00:15:36.366310
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    LocalFactCollector()


# Generated at 2022-06-25 00:15:38.416907
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    fact_collector = LocalFactCollector()
    
    # Test with non-initialised module
    fact_collector.collect()
    
    
    
    
    



# Generated at 2022-06-25 00:15:45.748706
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert test_case_0() == 'K'

# Generated at 2022-06-25 00:15:46.592161
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()


# Generated at 2022-06-25 00:15:47.937043
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    assert test_case_0() == "K"


# Generated at 2022-06-25 00:15:51.358935
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # str(value='')
    str_0 = str()
    # str(value='')
    str_1 = str()
    # class_1 = LocalFactCollector(base_class_0)
    class_2 = LocalFactCollector(str_0)


# Generated at 2022-06-25 00:15:57.277534
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    global str_0

    # Make a local instance of the class to be tested
    local_fact_collector = LocalFactCollector()

    # Stub out actual methods
    local_fact_collector.collect = lambda: str_0

    # Test the method
    result = local_fact_collector.collect()

    # Verify the results (make sure the first two bytes are the version number)
    assert result[0:2] == 'K'


# Generated at 2022-06-25 00:15:58.664854
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    obj_0 = LocalFactCollector()
    print(obj_0.name)
    print(obj_0)


# Generated at 2022-06-25 00:16:08.477150
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    str_0 = 'J'
    str_1 = 'z'
    str_2 = 'l'
    str_3 = 'o'
    str_4 = 'c'
    str_5 = 'a'
    str_6 = 'l'
    str_7 = 'F'
    str_8 = 'a'
    str_9 = 'c'
    str_10 = 't'
    str_11 = 'C'
    str_12 = 'o'
    str_13 = 'l'
    str_14 = 'l'
    str_15 = 'e'
    str_16 = 'c'
    str_17 = 't'
    str_18 = 'o'
    str_19 = 'r'
    str_20 = ':c'
    str_21 = 'o'


# Generated at 2022-06-25 00:16:17.673569
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    result_0 = LocalFactCollector()
    assert isinstance(result_0,LocalFactCollector)
    str_0 = 'c1'
    int_0 = 1
    bool_0 = True
    str_1 = 'local'
    list_0 = [str_0]
    dict_0 = {str_0:str_1}
    dict_1 = {str_0:int_0}
    dict_2 = {str_0:bool_0}
    dict_3 = {str_0:list_0}
    dict_4 = {str_0:dict_0}
    dict_5 = {str_0:dict_1}
    dict_6 = {str_0:dict_2}
    dict_7 = {str_0:dict_3}

# Generated at 2022-06-25 00:16:18.362431
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:16:23.591953
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    int_0 = 3
    int_1 = 2
    int_2 = 56
    str_1 = 'w'
    str_2 = '+'
    str_3 = ')'
    str_4 = 'U'
    str_5 = '6'
    str_6 = 'c'
    str_7 = 'l'
    str_8 = 'z'
    # Format string
    str_9 = '%'
    str_10 = 'i'
    str_11 = '{'
    str_12 = 'F'
    str_13 = 'F'
    str_14 = ')'
    str_15 = 'x'
    str_16 = '9'
    str_17 = '.'
    str_18 = 'C'
    str_19 = 'k'

# Generated at 2022-06-25 00:16:40.342539
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    str_0 = 'N'
    module = test_case_0()
    test = LocalFactCollector(str_0, module)
    return test


# Generated at 2022-06-25 00:16:44.301694
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    lfc = LocalFactCollector()
    assert isinstance(lfc, BaseFactCollector)

if __name__ == "__main__":
    test_LocalFactCollector()
    print("Everything passed")

# Generated at 2022-06-25 00:16:48.079406
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local = LocalFactCollector()
    assert local._fact_ids == set()
    assert local.name == 'local'
    assert local.collect()
    assert local.collect(['test'])



# Generated at 2022-06-25 00:16:53.308422
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Tests for the constructor of class LocalFactCollector
    # No rasie statements, if this is not the case, test fails
    from ansible.module_utils.facts.collector import LocalFactCollector
    LocalFactCollector()

test_case_0()
test_LocalFactCollector()

# Generated at 2022-06-25 00:16:55.940905
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_LocalFactCollector_0()


# Generated at 2022-06-25 00:17:01.267349
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    test = LocalFactCollector()
    module_0 = None
    test_0 = { }
    test_1 = test.collect(module=module_0, collected_facts=test_0)
    assert test_1 == {'local': {}}


# Generated at 2022-06-25 00:17:04.797335
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        obj = test_case_0()
    except NameError:
        pass
    else:
        raise Exception("Failed to raise expected exception")


# Generated at 2022-06-25 00:17:11.600658
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    str_0 = 'F'
    assert len(str_0) == 1
    str_0 = 'B'
    assert len(str_0) == 1
    str_0 = 't'
    assert len(str_0) == 1
    str_0 = 'K'
    assert len(str_0) == 1
    str_0 = 'h'
    assert len(str_0) == 1
    str_0 = 'I'
    assert len(str_0) == 1
    str_0 = '9'
    assert len(str_0) == 1
    str_0 = 'I'
    assert len(str_0) == 1
    str_0 = 'V'
    assert len(str_0) == 1
    str_0 = 'x'
    assert len(str_0) == 1

# Generated at 2022-06-25 00:17:17.891970
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Setup mock arguments and context
    module = None
    collected_facts = None

    lfc = LocalFactCollector()
    dict_0 = lfc.collect(module, collected_facts)

    # Assertions
    assert dict_0 == {'local': {}}


# Generated at 2022-06-25 00:17:20.110500
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    str_0 = 'K'

# Modify the following test cases to include your own.

# Generated at 2022-06-25 00:17:40.623038
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import module_utils.facts.collectors.local as local_collector
    local_collector_obj = local_collector.LocalFactCollector()
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 00:17:42.948804
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:17:43.786930
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    assert test_case_0() == None

# Generated at 2022-06-25 00:17:45.553530
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    str_0 = 'K'

test_case_0()

# Generated at 2022-06-25 00:17:50.499918
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        localFactCollector_0 = LocalFactCollector()
    except Exception as e:
        assert False, "Failed to create instance of LocalFactCollector"


# Generated at 2022-06-25 00:17:58.003227
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    # Test case where no module is passed in
    try:
        LocalFactCollector().collect()
    except KeyError:
        assert False, 'Failure with no module passed in'

    # Test case where a module is passed in with no fact path
    try:
        LocalFactCollector().collect(module=None)
    except KeyError:
        assert False, 'Failure with no fact path'

    # Test case where no fact file is present
    try:
        LocalFactCollector().collect(module=False, fact_path='/tmp')
    except KeyError:
        assert False, 'Failure with no fact file'

    # Test case where fact file is present

# Generated at 2022-06-25 00:18:06.406214
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    str_0 = 'C'
    str_1 = 'a'
    str_2 = 's'
    str_3 = 'e'
    str_4 = ' '
    str_5 = '0'
    str_6 = ':'

    # Test a call to method collect of class LocalFactCollector
    # The method returns nothing, do an assert on return to make sure that the function is properly tested
    assert not LocalFactCollector.collect(module=None, collected_facts=None), "The method collect of class LocalFactCollector has failed with parameters - None, None"
    assert not LocalFactCollector.collect(module='', collected_facts=None), "The method collect of class LocalFactCollector has failed with parameters - '', None"

# Generated at 2022-06-25 00:18:08.407179
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    try:
        assert str_0 == str_1
    except AssertionError as exception:
        print("Failed")

test_LocalFactCollector_collect()

# Generated at 2022-06-25 00:18:12.522861
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    fact_path = 'C'
    collected_facts = {'os_family': 'RedHat'}
    LOCAL_FACT_COLLECTOR = LocalFactCollector()
    local_facts = LOCAL_FACT_COLLECTOR.collect(None, collected_facts)
    assert local_facts == {'local': {'fact_path': fact_path}}

# Generated at 2022-06-25 00:18:16.997757
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    class_name = str(local_fact_collector.__class__.__name__)
    assert class_name == "LocalFactCollector"


# Generated at 2022-06-25 00:18:39.893154
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    str_0 = 'K'
    local_fact_collector_0 = LocalFactCollector(str_0)
    assert isinstance(local_fact_collector_0, LocalFactCollector) is True
    assert local_fact_collector_0.name == 'K'
    assert isinstance(local_fact_collector_0._fact_ids, set) is True


# Generated at 2022-06-25 00:18:43.194132
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:18:45.446799
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        test_case_0()
    except Exception as e:
        print
        str(e)


test_LocalFactCollector()

# Generated at 2022-06-25 00:18:50.322825
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    str_0 = 'Z'
    local_fact_collector_0 = LocalFactCollector(str_0)
    str_0 = 'Z'
    assert local_fact_collector_0.collect(str_0) == {}


# Generated at 2022-06-25 00:18:51.308319
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    assert True


# Generated at 2022-06-25 00:18:55.702742
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    str_0 = 'K'
    local_fact_collector_0 = LocalFactCollector(str_0)
    var_0 = local_fact_collector_0.collect()

# Generated at 2022-06-25 00:18:59.688919
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector('F')
    var_0 = local_fact_collector.collect()


# Generated at 2022-06-25 00:19:00.412808
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:19:03.246061
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    str_0 = 'D'
    local_fact_collector_0 = LocalFactCollector(str_0)
    arg_0 = 'J'
    local_fact_collector_0.collect(arg_0);


# Generated at 2022-06-25 00:19:04.829540
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    str_0 = 'a'
    local_fact_collector_0 = LocalFactCollector(str_0)
    assert local_fact_collector_0.name == 'a'

# Generated at 2022-06-25 00:19:42.427818
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()


# Generated at 2022-06-25 00:19:46.339191
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    str_0 = 'I'
    local_fact_collector_0 = LocalFactCollector(str_0)
    assert local_fact_collector_0._fact_ids == {'_cache', 'local'}
    assert local_fact_collector_0.name == 'I'


# Generated at 2022-06-25 00:19:51.978636
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    str_0 = 'Z'
    local_fact_collector_0 = LocalFactCollector(str_0)
    assert local_fact_collector_0._fact_ids == set(), 'Failed asserting that _fact_ids is set()'
    assert local_fact_collector_0.name == 'Z', 'Failed asserting that name is Z'

# Generated at 2022-06-25 00:19:56.198854
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    str_0 = 'K'
    local_fact_collector_0 = LocalFactCollector(str_0)
    var_0 = local_fact_collector_0.collect()


# Generated at 2022-06-25 00:19:58.657954
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    str_0 = 'K'
    local_fact_collector_0 = LocalFactCollector(str_0)
    local_fact_collector_0.collect()

test_case_0()

# Generated at 2022-06-25 00:20:02.908244
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    from ansible.module_utils.facts.collection import LocalFactCollector
    fact_path = '/home/automaton/ansible/ansible/module_utils/facts/fixture'
    fact_path_0 = LocalFactCollector(fact_path)
    assert fact_path_0.fact_path == fact_path


# Generated at 2022-06-25 00:20:06.346464
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Case 0
    test_case_0()

# Generated at 2022-06-25 00:20:09.739465
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    str_0 = 'K'
    local_fact_collector_0 = LocalFactCollector(str_0)
    var_0 = local_fact_collector_0.collect()
    if var_0 is not None:
        print("Result is: " + var_0)



# Generated at 2022-06-25 00:20:19.231400
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    str_0 = None
    str_1 = 'f'
    str_2 = 'R'
    str_3 = 'Q'
    str_4 = 'b'
    local_fact_collector_0 = LocalFactCollector(str_0)
    local_fact_collector_1 = LocalFactCollector(str_1)
    local_fact_collector_2 = LocalFactCollector(str_2)
    local_fact_collector_3 = LocalFactCollector(str_3)
    local_fact_collector_4 = LocalFactCollector(str_4)
    local_fact_collector_4.collect()
    local_fact_collector_3.collect()
    local_fact_collector_2.collect()
    local_fact_collector_1.collect()
    local_fact

# Generated at 2022-06-25 00:20:23.898932
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
  # Run the test
  test_case_0()

# Generated at 2022-06-25 00:21:38.702808
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    str_0 = 'K'
    local_fact_collector_0 = LocalFactCollector(str_0)
    var_1 = local_fact_collector_0.collect()


# Generated at 2022-06-25 00:21:42.414102
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    
    # Test case 0
    test_case_0()


# Generated at 2022-06-25 00:21:45.214803
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:21:47.064453
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    try:
        test_case_0()
    except Exception:
        print('Exception')
#

# Generated at 2022-06-25 00:21:49.180775
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector
    assert local_fact_collector_0.collect()


# Generated at 2022-06-25 00:21:51.791736
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    str_0 = 'K'
    local_fact_collector_0 = LocalFactCollector(str_0)
    assert local_fact_collector_0.name == 'local', "Constructor of class LocalFactCollector returned wrong name"
    assert local_fact_collector_0._fact_ids == {'local'}, "Constructor of class LocalFactCollector returned wrong fact_id"

# Generated at 2022-06-25 00:21:53.674592
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    print('Testing method collect of class LocalFactCollector')
    test_case_0()

# End of testing method collect of class LocalFactCollector


# Generated at 2022-06-25 00:21:54.576324
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    assert callable(LocalFactCollector.collect)


# Generated at 2022-06-25 00:21:57.912983
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    str_0 = 'K'
    local_fact_collector_0 = LocalFactCollector(str_0)
    var_0 = local_fact_collector_0.collect()


# Generated at 2022-06-25 00:22:00.214080
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    try:
        test_case_0()
    except:
        assert False
    else:
        assert True