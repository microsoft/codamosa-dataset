

# Generated at 2022-06-25 00:13:19.352276
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    result = LocalFactCollector()
    assert result.name == 'local'


# Generated at 2022-06-25 00:13:21.593985
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()

# Generated at 2022-06-25 00:13:25.111441
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    result = local_fact_collector_0.collect(None, None)
    # AssertionError: {} != {'local': {}}
    assert result == {'local': {}}

# Generated at 2022-06-25 00:13:28.220838
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert type(local_fact_collector_0) == LocalFactCollector
    assert local_fact_collector_0.name == 'local'
    assert len(local_fact_collector_0._fact_ids) == 0

# Generated at 2022-06-25 00:13:29.958252
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert local_fact_collector_0.name == 'local'

# Generated at 2022-06-25 00:13:32.638342
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_collect = LocalFactCollector().collect


# Generated at 2022-06-25 00:13:35.578774
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fact_collector = LocalFactCollector()
    assert (fact_collector.name == 'local')


# Generated at 2022-06-25 00:13:46.587492
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    from ansible.module_utils.facts import ansible_local_facts
    from ansible.module_utils import basic
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.common.parameters import ImmutableModuleParameters

    test_module_0 = basic.AnsibleModule(
        argument_spec = dict(
             fact_path = dict(),
        ),
        supports_check_mode=False
    )

    test_module_0.params = ImmutableModuleParameters(
        params = ImmutableDict(
            ansible_facts = ImmutableDict(
                ansible_local_facts = None
            ),
            fact_path = '/Users/james/ansible/test/test_fixtures'
        )
    )

    local_fact_collector_0

# Generated at 2022-06-25 00:13:47.397721
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()


# Generated at 2022-06-25 00:13:51.186878
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0


# Generated at 2022-06-25 00:14:03.781200
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    float_1 = 100.0
    local_fact_collector_1 = LocalFactCollector(float_1)
    var_1 = local_fact_collector_1.collect()
    assert var_1 == {'local': {}}

test_case_0()

# Generated at 2022-06-25 00:14:05.487128
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    assert isinstance(local_fact_collector_0, LocalFactCollector)


# Generated at 2022-06-25 00:14:08.352088
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    var_0 = local_fact_collector_0.collect()

# Generated at 2022-06-25 00:14:10.599635
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """Unit test for method collect of class LocalFactCollector"""
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    var_0 = local_fact_collector_0.collect()

# Generated at 2022-06-25 00:14:15.037593
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        assert test_case_0() == 'test'
    except AssertionError as e:
        print(e)


# Generated at 2022-06-25 00:14:19.097122
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    var_0 = local_fact_collector_0.collect()


# Generated at 2022-06-25 00:14:24.687932
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    float_1 = 100.0
    local_fact_collector_1 = LocalFactCollector(float_1)
    module_0 = None
    collected_facts_0 = None
    var_0 = local_fact_collector_1.collect(module_0, collected_facts_0)
    assert var_0 == {'local': {}}


# Generated at 2022-06-25 00:14:28.164331
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    assert(local_fact_collector_0 is not None)
    assert(isinstance(local_fact_collector_0, LocalFactCollector))


# Generated at 2022-06-25 00:14:30.111209
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    float_2 = 100.0
    local_fact_collector_1 = LocalFactCollector(float_2)
    var_1 = local_fact_collector_1.collect()
    assert var_1


# Generated at 2022-06-25 00:14:35.570471
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    local_fact_collector_0.collect()


# Generated at 2022-06-25 00:14:48.191558
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector


# Generated at 2022-06-25 00:14:49.928894
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fact_collector_0 = LocalFactCollector()
    assert fact_collector_0.name == 'local'



# Generated at 2022-06-25 00:14:51.821758
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    var_0 = local_fact_collector_0.collect()

# Generated at 2022-06-25 00:14:53.719531
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    float_1 = 100.0
    local_fact_collector_1 = LocalFactCollector(float_1)
    assert local_fact_collector_1 is not None

# Function fact_ids()

# Generated at 2022-06-25 00:14:57.598480
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    float_0 = 100.0
    # LocalFactCollector class testing.
    local_fact_collector_0 = LocalFactCollector(float_0)
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set([])

# Generated at 2022-06-25 00:14:58.407970
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:15:02.368880
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    class TestClass(LocalFactCollector):
        def collect(self):
            return 'ok'

    local_fact_collector_0 = TestClass(100.0)
    var_0 = local_fact_collector_0.collect()
    #assert var_0 == 'ok', 'Returned value should be \'ok\''


# Generated at 2022-06-25 00:15:04.790433
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    assert isinstance(local_fact_collector_0, LocalFactCollector)


# Generated at 2022-06-25 00:15:09.599009
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    wildcard_0 = WildCImport()
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0, wildcard_0)
    var_0 = local_fact_collector_0.last_collection
    assert var_0 == 100.0
    var_1 = local_fact_collector_0.name
    assert var_1 == 'local'
    var_2 = local_fact_collector_0._fact_ids


# Generated at 2022-06-25 00:15:10.353903
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:15:37.244662
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    json.load(log)


# Generated at 2022-06-25 00:15:38.689580
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)

# Generated at 2022-06-25 00:15:42.504602
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    assert local_fact_collector_0 is not None
    assert local_fact_collector_0.file_sd_config is False
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()
    assert local_fact_collector_0._cache_expiration == 604800.0


# Generated at 2022-06-25 00:15:45.790007
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    var_0 = local_fact_collector_0.collect()


# Generated at 2022-06-25 00:15:48.430910
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    float_1 = 100.0
    local_fact_collector_1 = LocalFactCollector(float_1)
    local_fact_collector_2 = LocalFactCollector(float_1)


# Generated at 2022-06-25 00:15:50.556813
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    local_fact_collector_0.collect()


# Generated at 2022-06-25 00:15:55.900892
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    assert local_fact_collector_0 is not None


# Generated at 2022-06-25 00:16:01.086186
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    var_0 = local_fact_collector_0.collect()
    assert var_0 == {'local': {}}, 'local_facts set incorrectly'

test_case_0()

# Generated at 2022-06-25 00:16:03.120714
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    assert local_fact_collector_0 is not None


# Generated at 2022-06-25 00:16:07.817191
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    assert local_fact_collector_0.priority == 100.0
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:17:10.455619
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    var_0 = local_fact_collector_0.collect()
    assert var_0 == {"local": {}}

test_case_0()

# Generated at 2022-06-25 00:17:11.083731
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:17:16.325109
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    var_0 = local_fact_collector_0.collect()

# Generated at 2022-06-25 00:17:21.738787
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    module_0 = configparser.ConfigParser()
    var_0 = module_0.readfp(StringIO('[local]\n'))
    field_0 = float_0
    field_1 = module_0
    var_0 = local_fact_collector_0.collect(field_0, field_1)
    assert var_0 == None

# Generated at 2022-06-25 00:17:24.939730
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    var_0 = local_fact_collector_0.collect()
    assert (var_0 == {'local': {}})


# Generated at 2022-06-25 00:17:27.534732
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    var_0 = local_fact_collector_0.collect()

# Generated at 2022-06-25 00:17:31.858508
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)


# Generated at 2022-06-25 00:17:37.166564
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    float_1 = 100.0
    local_fact_collector_1 = LocalFactCollector(float_1)
    local_fact_collector_1.name = 'local'
    local_fact_collector_1._fact_ids = set()
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict(path=dict_1, os=dict_0)
    dict_3 = dict(args=(dict_2,))
    dict_4 = dict(params=dict_3)
    dict_5 = dict(module=dict_4)
    module_0 = AnsibleModule(**dict_5)
    module_0.warn = print
    fact_path_0 = module_0.params.get('fact_path', None)

# Generated at 2022-06-25 00:17:39.873349
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)


# Generated at 2022-06-25 00:17:45.437652
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    var_0 = local_fact_collector_0.collect()
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 00:20:09.212431
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    var_0 = local_fact_collector_0.collect()

    #  check if local facts are set
    assert var_0 == {'local': {}}


# Generated at 2022-06-25 00:20:12.366187
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    float_1 = 100.0
    local_fact_collector_1 = LocalFactCollector(float_1)

    # test function return value with default args
    assert local_fact_collector_1.collect() == {}

    # test function return value with default args
    assert local_fact_collector_1.collect() == {}

# Generated at 2022-06-25 00:20:17.802026
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    var_0 = local_fact_collector_0.collect()
    assert local_fact_collector_0.name == 'local'


# Generated at 2022-06-25 00:20:21.896661
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    assert isinstance(local_fact_collector_0, LocalFactCollector)


# Generated at 2022-06-25 00:20:23.648186
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    var_0 = local_fact_collector_0.collect()

# Generated at 2022-06-25 00:20:26.133307
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    var_0 = local_fact_collector_0.list_collection_methods()

# Generated at 2022-06-25 00:20:29.079043
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
  # Initialization for class LocalFactCollector
  float_0 = 100.0
  local_fact_collector_0 = LocalFactCollector(float_0)


# Generated at 2022-06-25 00:20:32.691541
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    # Test the name property
    var_0 = local_fact_collector_0.name
    assert var_0 == 'local'

# Generated at 2022-06-25 00:20:34.596266
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    var_0 = local_fact_collector_0.collect()

# Generated at 2022-06-25 00:20:36.929314
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    float_0 = 100.0
    local_fact_collector_0 = LocalFactCollector(float_0)
    var_0 = local_fact_collector_0.collect()
    assert var_0 == {}
