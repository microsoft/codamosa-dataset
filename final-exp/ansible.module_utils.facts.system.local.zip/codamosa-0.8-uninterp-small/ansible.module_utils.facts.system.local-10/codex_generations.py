

# Generated at 2022-06-25 00:13:19.075232
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'
    assert LocalFactCollector._fact_ids == set()

# Generated at 2022-06-25 00:13:24.608247
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    # Create the module mock
    module = MagicMock()

    # Create the expected results for each test case

# Generated at 2022-06-25 00:13:27.219003
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_instance = LocalFactCollector()
    local_fact_collector_instance._fact_ids = ['dict']
    assert local_fact_collector_instance.collect() == {'dict': {'local': {}}}

# Generated at 2022-06-25 00:13:29.120573
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert isinstance(local_fact_collector, LocalFactCollector)
    assert isinstance(local_fact_collector._fact_ids, set)

# Generated at 2022-06-25 00:13:32.950726
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector._name == 'local'


# Generated at 2022-06-25 00:13:38.097814
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    fact_path = "/etc/ansible/facts.d"
    local_facts = local_fact_collector_1.collect(fact_path=fact_path)
    print(local_facts)

if __name__ == "__main__":
    test_LocalFactCollector_collect()

# Generated at 2022-06-25 00:13:46.940666
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_2 = LocalFactCollector()
    local_fact_collector_3 = LocalFactCollector()
    local_fact_collector_4 = LocalFactCollector()
    local_fact_collector_5 = LocalFactCollector()
    local_fact_collector_6 = LocalFactCollector()


if __name__ == '__main__':
    dict0 = test_case_0()

    test_LocalFactCollector_collect()

# Generated at 2022-06-25 00:13:51.890653
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    collected_facts = {}
    local_facts = local_fact_collector_0.collect(module=None, collected_facts=collected_facts)

# Generated at 2022-06-25 00:13:57.052594
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    result = local_fact_collector_1.collect()
    assert result['local'] == {}

# Generated at 2022-06-25 00:14:03.717652
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Test constructor
    local_fact_collector_0 = LocalFactCollector()

    # Test __init__ method of class LocalFactCollector
    # There is no init method to test

    # Test collect method
    local_fact_collector_0.collect()


# Generated at 2022-06-25 00:14:10.488049
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert type(local_fact_collector_0) == LocalFactCollector


# Generated at 2022-06-25 00:14:17.906964
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    # Test case with module IS NOT None
    local_facts = local_fact_collector_0.collect(module={"params": {"fact_path": "/home/vagrant/playbook/facts/local"}})
    assert local_facts['local']['os_version'] == 'CentOS Linux release 7.6.1810 (Core)'


# Generated at 2022-06-25 00:14:19.526704
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_facts_0 = local_fact_collector_0.collect()
    assert local_facts_0 == {}


# Generated at 2022-06-25 00:14:21.500431
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    # test case for no module
    result = local_fact_collector.collect()


# Generated at 2022-06-25 00:14:27.732900
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert isinstance(local_fact_collector, LocalFactCollector)
    assert isinstance(local_fact_collector._fact_ids, set)
    assert local_fact_collector.name == 'local'


# Generated at 2022-06-25 00:14:29.108817
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == "local"

# Generated at 2022-06-25 00:14:29.880241
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    test_case_0()

# Generated at 2022-06-25 00:14:35.958691
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    parameter = {'fact_path': 'test'}
    local_facts = local_fact_collector_0.collect(parameter)
    assert local_facts['local'] == {}

# Generated at 2022-06-25 00:14:43.095283
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    try:
        from ansible.module_utils.facts.collector import AnsibleModule
    except ImportError:
        AnsibleModule = None

    if AnsibleModule is None:
        return

    module = AnsibleModule(
        argument_spec = dict(
            fact_path=dict(default=os.path.join(os.path.dirname(__file__), '../../plugins/facts/fixtures'), type='path'),
            test_uni_char=dict(default=True, type='bool')
        )
    )

    local_fact_collector = LocalFactCollector()
    result = local_fact_collector.collect(module)

    assert result['local']['local_file_fact']['sect1']['fact_1'] == 'value_1'

# Generated at 2022-06-25 00:14:47.552630
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    collector = LocalFactCollector()
    assert collector.name == 'local'
    assert collector._fact_ids == set()


# Generated at 2022-06-25 00:14:55.650154
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert isinstance(local_fact_collector, LocalFactCollector)



# Generated at 2022-06-25 00:14:57.485155
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        test_case_0()
    except Exception:
        assert False
    else:
        assert True


# Collect all facts

# Generated at 2022-06-25 00:14:59.295133
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()


# Generated at 2022-06-25 00:15:01.678362
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()

    assert local_fact_collector_0.collect() == {'local': {}}


# Generated at 2022-06-25 00:15:03.823123
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = test_case_0()
    local_fact_collector_1.collect(module)
    return True


# Generated at 2022-06-25 00:15:06.972634
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert 'local' == local_fact_collector_1.name, 'Collector name should be "local"'
    assert set() == local_fact_collector_1._fact_ids, '_fact_ids should be empty'


# Generated at 2022-06-25 00:15:08.878779
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_facts_0 = local_fact_collector_0.collect()
    assert {} == local_facts_0

# Generated at 2022-06-25 00:15:10.198121
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    local_facts = local_fact_collector.collect()
    assert local_facts.get('local', None) == {}, "Unexpected local facts"


# Generated at 2022-06-25 00:15:20.141163
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    fact_path = os.path.expanduser("~/.ansible/local_facts")
    os.mkdir(fact_path)
    test_file = os.path.expanduser("~/.ansible/local_facts/test.fact")
    with open(test_file, "w") as test_file_obj:
        test_file_obj.write("test_fact=testval")
    local_fact_collector_1 = LocalFactCollector()
    result = local_fact_collector_1.collect({}, {})
    assert 'local' in result, "The result does not contain key 'local' for fact_path: %s" % fact_path

# Generated at 2022-06-25 00:15:21.191391
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector._fact_ids == set()

# Generated at 2022-06-25 00:15:30.416911
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    facts = {}
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect(facts)
    assert 'local' in facts
    for path in glob.glob('/etc/ansible/facts.d/*.fact'):
        fact_name = os.path.basename(path).strip('.fact')
        assert fact_name in facts['local']

# Generated at 2022-06-25 00:15:35.799155
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0 != None, "Failed to create LocalFactCollector object"
    local_fact_collector_0.collect()
    local_fact_collector_0.collect()
    local_fact_collector_0.collect()


# Generated at 2022-06-25 00:15:39.911859
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    # Testing with first arg: arg1='module=None'
    # Testing with second arg: arg2='collected_facts=None'
    result = local_fact_collector_0.collect(module=None, collected_facts=None)
    assert(result == {'local': {}})



# Generated at 2022-06-25 00:15:42.958468
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    result = local_fact_collector_1.collect()
    assert isinstance(result, dict)


# Generated at 2022-06-25 00:15:46.198359
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.collect(module=None, collected_facts=None) == {'local': {}}


# Generated at 2022-06-25 00:15:48.185953
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'
    assert LocalFactCollector._fact_ids == set()


# Generated at 2022-06-25 00:15:52.378588
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.collect(None, None) == {'local': {}}


# Generated at 2022-06-25 00:15:53.790191
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    local_facts = local_fact_collector.collect()
    assert local_facts == {u'local': {}}

# Generated at 2022-06-25 00:15:55.062901
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()

# Generated at 2022-06-25 00:16:00.198590
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    local_facts_dict = local_fact_collector.collect()

    assert local_facts_dict
    assert local_facts_dict == {'local': {}}

# Generated at 2022-06-25 00:16:07.931202
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0 is not None, 'The constructor returns a None Object'

# Generated at 2022-06-25 00:16:10.628781
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:16:14.629144
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_1.collect()


# Generated at 2022-06-25 00:16:17.366328
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert isinstance(local_fact_collector_0._fact_ids, set)


# Generated at 2022-06-25 00:16:18.551243
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector is not None


# Generated at 2022-06-25 00:16:20.047484
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_1.collect()

# Generated at 2022-06-25 00:16:27.741128
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Test with fact_path as None
    local_fact_collector_0 = LocalFactCollector()
    assert len(local_fact_collector_0.collect()['local']) == 0
    # Test with fact_path as None and module not None
    local_fact_collector_1 = LocalFactCollector()
    assert len(local_fact_collector_1.collect(module=None)['local']) == 0
    # Test with fact_path as None and module not None and collected_facts not None
    local_fact_collector_2 = LocalFactCollector()
    assert len(local_fact_collector_2.collect(module=None, collected_facts=None)['local']) == 0


# Generated at 2022-06-25 00:16:29.793824
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fact_collector = LocalFactCollector()
    assert fact_collector.name == 'local'
    assert isinstance(fact_collector, BaseFactCollector)

# Generated at 2022-06-25 00:16:30.991617
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    print(LocalFactCollector.collect('./test/utils/fixtures/ansible_local/'))

# Generated at 2022-06-25 00:16:33.292581
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    from ansible.module_utils.facts import collector
    local_fact_collector_0 = LocalFactCollector()
    assert isinstance(local_fact_collector_0, collector.BaseFactCollector) == True


# Generated at 2022-06-25 00:16:43.499874
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    local_fact_collector.collect()


# Generated at 2022-06-25 00:16:44.379292
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:16:46.842980
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()

    local_fact_collector_0.collect()

# Generated at 2022-06-25 00:16:51.819453
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_1.collect()

# Generated at 2022-06-25 00:16:52.598737
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:16:54.068723
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    print(LocalFactCollector.collect(LocalFactCollector()))

# Generated at 2022-06-25 00:16:55.447790
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    facts_1 = local_fact_collector_1.collect()
    assert isinstance(facts_1, dict)

# Generated at 2022-06-25 00:17:00.223058
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
  local_fact_collector = LocalFactCollector()
  assert local_fact_collector.name is not None
  assert local_fact_collector._fact_ids is not None

# Generated at 2022-06-25 00:17:02.169407
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        test_case_0()
    except Exception as err:
        print("TestCase 0 : FAILED")
        print(err)
        assert False


# Generated at 2022-06-25 00:17:03.971829
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

test_case_0()
test_LocalFactCollector()

# Generated at 2022-06-25 00:17:17.818901
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:17:18.770645
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:17:21.298355
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_1.collect()

# Generated at 2022-06-25 00:17:23.823926
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-25 00:17:27.063104
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:17:30.594953
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    cwd = os.getcwd()
    path = os.path.join(cwd, '../module_utils/facts/collectors/local/')
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1.collect(
        {'fact_path':path}) == \
    {'local':{'local':{'a':'b'}}}

# Generated at 2022-06-25 00:17:32.291208
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0._fact_ids is not None


# Generated at 2022-06-25 00:17:34.346112
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_1.collect()

# Generated at 2022-06-25 00:17:35.941313
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    args_0 = {}
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect(**args_0)


# Generated at 2022-06-25 00:17:41.336333
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_1 = {}
    local_1['local'] = {}
    dict_2 = {}
    dict_2['local'] = {}
    assert local_fact_collector_0.collect(dict_2) == local_1


# Generated at 2022-06-25 00:17:56.997128
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    path_1 = '/home/pbrady/dropbox/ansible/test/integration/files/cmdline/basic'
    local_fact_collector_0.collect(path_1)



# Generated at 2022-06-25 00:17:59.904422
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert isinstance(LocalFactCollector(), LocalFactCollector)

# Generated at 2022-06-25 00:18:01.669299
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    if not LocalFactCollector():
        raise Exception('Constructor test failed')


# Generated at 2022-06-25 00:18:03.595907
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:18:12.088370
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # get module object
    module_obj = get_module_obj()
    module_obj.run_command = run_command
    module_obj.warn = warn
    local_fact_collector_3 = LocalFactCollector()
    # get 'module' variable that was passed to module_obj
    module = module_obj._module

    # get module variable 'params'
    params = module.params
    # set module variable 'params' to new value
    params['fact_path'] = '/root/ansible/test/units/module_utils/facts/local/test_data/path_0'
    module.params = params
    # call method
    ret = local_fact_collector_3.collect(module, None)
    # get module variable 'params'
    params = module.params
    # reset module variable 'params' with

# Generated at 2022-06-25 00:18:16.563605
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector
    assert local_fact_collector.name == 'local'


# Generated at 2022-06-25 00:18:19.571669
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    # for some reason this is needed for the module attributes to set even though I don't use them
    module = None
    local_facts = {}
    local_fact_collector_0.collect(module, local_facts)

# Generated at 2022-06-25 00:18:22.137601
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.collect() is not None

# Generated at 2022-06-25 00:18:23.348176
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'
    assert LocalFactCollector._fact_ids == set()

# Generated at 2022-06-25 00:18:25.836149
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Instantiation of LocalFactCollector class
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:18:51.781688
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    fact_path = "/etc/ansible/facts.d"
    fact_base = "test"
    fn = "/etc/ansible/facts.d/test.fact"
    class module:
        def __init__(self):
            self.params = {'fact_path': fact_path}

        def warn(self, msg):
            pass

    local_fact_collector_1 = LocalFactCollector()
    local_facts = local_fact_collector_1.collect(module=module(), collected_facts=None)
    assert local_facts == {'local': {}}
    os.mknod(fn)
    local_facts = local_fact_collector_1.collect(module=module(), collected_facts=None)
    assert os.path.isdir(fact_path)

# Generated at 2022-06-25 00:18:55.523778
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    test_case = 0

    # test case 0
    if test_case == 0:
        test_LocalFactCollector_collect_0()


# Generated at 2022-06-25 00:18:59.065587
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()


# Generated at 2022-06-25 00:19:00.413220
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector is not None

# Generated at 2022-06-25 00:19:01.403392
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()


# Generated at 2022-06-25 00:19:03.645293
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_2 = LocalFactCollector()
    assert local_fact_collector_2.collect() == {'local': {}}


# Generated at 2022-06-25 00:19:09.239485
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    path = os.path.dirname(os.path.realpath(__file__))
    fact_path = os.path.join(path, '..', '..', 'testsuite', 'data', 'facts.d')
    local_fact_collector_0 = LocalFactCollector()

# Generated at 2022-06-25 00:19:11.969814
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()

# Generated at 2022-06-25 00:19:16.259430
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1.collect({
        'params': {
            'fact_path': './examples'
        }
    }) == {
        'local': {
            'example1': {
                'example1': 'example1'
            }
        }
    }


# Generated at 2022-06-25 00:19:19.112873
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()

# Generated at 2022-06-25 00:19:47.783012
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert not os.path.exists('/etc/ansible/facts.d')
    # os.makedirs('/etc/ansible/facts.d')
    os.makedirs('/etc/ansible/facts.d')

    file = open('/etc/ansible/facts.d/hostname.fact','w')
    file.write('{"hostname": "localhost"}')
    file.close()
    file = open('/etc/ansible/facts.d/ipaddr.fact','w')
    file.write('[ipaddr]\nipaddr1 = 127.0.0.1\nipaddr2 = 127.0.0.2')
    file.close()
    local_fact_collector_0 = LocalFactCollector()

# Generated at 2022-06-25 00:19:51.419301
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # path is a string
    local_fact_collector_0 = LocalFactCollector()
    # path does not exist
    result = local_fact_collector_0.collect()
    # Verify that the result is empty
    assert len(result) == 0, 'Expected a empty dictionary'


# Generated at 2022-06-25 00:19:55.926051
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    result_1 = local_fact_collector_0.collect()
    assert result_1 == {'local': {}}

# Generated at 2022-06-25 00:19:57.825962
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    actual_result = local_fact_collector_1.collect()
    assert actual_result == {}

# Generated at 2022-06-25 00:19:59.319872
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        test_case_0()
        res = True
    except Exception:
        res = False

    assert res

# Generated at 2022-06-25 00:20:02.235025
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    # constructor test: 1
    assert local_fact_collector_0.name == "local"
    assert local_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:20:03.095636
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert isinstance(LocalFactCollector(), LocalFactCollector)


# Generated at 2022-06-25 00:20:03.651560
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:20:06.734764
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    collector = LocalFactCollector()
    assert collector.collect() == {}

# Generated at 2022-06-25 00:20:08.904480
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert 'LocalFactCollector' in str(local_fact_collector)


# Generated at 2022-06-25 00:20:30.734046
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assertLocalFactCollectorName(local_fact_collector_0, 'local')
    assertLocalFactCollectorFacts(local_fact_collector_0)


# Generated at 2022-06-25 00:20:34.122359
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()

    # Test case with dummy value for
    # collected_facts
    collected_facts_0 = ''
    local_facts_0 = local_fact_collector_0.collect(collected_facts=collected_facts_0)
    assert local_facts_0 == {}


if __name__ == '__main__':
    pass

# Generated at 2022-06-25 00:20:36.719426
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0 != None

# Generated at 2022-06-25 00:20:37.840341
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_cases = [
        test_case_0
    ]
    for t in test_cases:
        yield t

# Generated at 2022-06-25 00:20:44.239439
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local = LocalFactCollector()
    assert local.name == 'local', "LocalFactCollector() returned wrong name %s" % local.name
    assert local._fact_ids == set(), "LocalFactCollector() returned wrong _fact_ids %s" % local._fact_ids
    assert local.collect() == {'local': {}}, "LocalFactCollector() returned wrong collect() %s" % local.collect()



# Generated at 2022-06-25 00:20:45.503095
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    local_fact_collector.collect()

# Generated at 2022-06-25 00:20:46.416272
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()

# Generated at 2022-06-25 00:20:47.708984
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    result = local_fact_collector_1.collect()
    assert result == {}

# Generated at 2022-06-25 00:20:48.569183
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:20:51.712360
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_collect = LocalFactCollector()
    assert local_fact_collector_collect.collect() == {'local': {}}, 'collect method of LocalFactCollector class does not return correct output'


# Generated at 2022-06-25 00:21:12.854416
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # test constructor of class LocalFactCollector
    local_fact_collector_0 = LocalFactCollector()


# Generated at 2022-06-25 00:21:14.354670
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    #local_fact_collector_0 = LocalFactCollector()
    assert True


# Generated at 2022-06-25 00:21:16.625254
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    print("Testing constructor of class LocalFactCollector")
    assert True


# Generated at 2022-06-25 00:21:17.828200
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'

# Generated at 2022-06-25 00:21:20.876245
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:21:22.292459
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    collector_name = 'local'
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_1.collect()

# Generated at 2022-06-25 00:21:23.356380
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:21:25.454811
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    local_fact_collector.collect()

# Generated at 2022-06-25 00:21:27.114834
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_1.collect()


# Generated at 2022-06-25 00:21:33.059628
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()

    # Testing attribute '_fact_ids' of class LocalFactCollector
    assert local_fact_collector_0._fact_ids == set()

    # Testing attribute 'name' of class LocalFactCollector
    assert local_fact_collector_0.name == 'local'

# Generated at 2022-06-25 00:21:51.623021
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0._fact_ids == set()
    assert local_fact_collector_0.name == 'local'


# Generated at 2022-06-25 00:21:53.641584
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert isinstance(local_fact_collector_0, LocalFactCollector)


# Generated at 2022-06-25 00:21:54.750742
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()

# Generated at 2022-06-25 00:21:57.762665
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_2 = local_fact_collector_0._validate_module_params(module=None)


# Generated at 2022-06-25 00:21:59.730994
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()


# Generated at 2022-06-25 00:22:02.275055
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    var_0 = LocalFactCollector();
    var_1 = var_0.collect();
    # Test case 0
    var_0 = LocalFactCollector();
    var_1 = var_0.collect(var_0);


# Generated at 2022-06-25 00:22:03.307083
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    var = local_fact_collector.collect()
    assert var == {}


# Generated at 2022-06-25 00:22:04.960168
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0 is not None

# Generated at 2022-06-25 00:22:12.275956
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    # No type error is thrown
    try:
        local_fact_collector_1.collect()
        local_fact_collector_1.collect(local_fact_collector_1)
    except TypeError:
        var_0 = False
    else:
        var_0 = True
    assert var_0


# Generated at 2022-06-25 00:22:19.769037
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    # Initialize LocalFactCollector
    myLocalFactCollector = LocalFactCollector()

    # Test input_data_0
    input_data_0 = [{}]

    res = myLocalFactCollector.collect(input_data_0)
    assert res == {'local': {}}

    # Test input_data_1
    input_data_1 = [{'fact_path': './.testing'}]

    res = myLocalFactCollector.collect(input_data_1)
    assert res == {'local': {}}

# Generated at 2022-06-25 00:23:02.363243
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()
    var_1 = local_fact_collector_0.collect(local_fact_collector_0)


# Generated at 2022-06-25 00:23:05.829368
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_collect_0 = LocalFactCollector()

    local_fact_collector_collect_1 = local_fact_collector_collect_0.collect()
    local_fact_collector_collect_2 = local_fact_collector_collect_0.collect(local_fact_collector_collect_0)


# Generated at 2022-06-25 00:23:07.822337
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()
    assert len(var_0) == 1



# Generated at 2022-06-25 00:23:09.262195
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()


# Generated at 2022-06-25 00:23:14.301316
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()
    var_1 = local_fact_collector_0.collect(local_fact_collector_0)
