

# Generated at 2022-06-25 00:13:20.484886
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_collect = LocalFactCollector()
    result = local_fact_collector_collect.collect()


# Generated at 2022-06-25 00:13:24.401426
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.collect() == {'local': {}}
    assert isinstance(local_fact_collector.collect(), dict)

# Generated at 2022-06-25 00:13:26.124985
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()

    assert local_fact_collector_1.collect() == {'local': {}}

# Generated at 2022-06-25 00:13:27.545233
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_1.collect()

# Generated at 2022-06-25 00:13:32.794770
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    assert 'test_facts' == local_fact_collector_1.collect()['local']['test_fact_file']['test_fact']

# Generated at 2022-06-25 00:13:36.060317
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert(local_fact_collector_0.name == 'local')
    return

# Generated at 2022-06-25 00:13:36.856520
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:13:39.076814
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        local_fact_collector_0 = LocalFactCollector()
        test_case_0()
    except Exception as e:
        print('Exception in test_LocalFactCollector:', e)

# Generated at 2022-06-25 00:13:42.553018
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert len(LocalFactCollector().name) > 0
    assert len(LocalFactCollector()._fact_ids) >= 0
    assert LocalFactCollector()._fact_ids == set()


# Generated at 2022-06-25 00:13:44.239032
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_1.collect()


# Generated at 2022-06-25 00:13:57.412549
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    from ansible.module_utils.facts import ModuleStub
    module_stub_0 = ModuleStub(dict())
    module_stub_0.params = dict()
    module_stub_0.params['fact_path'] = 'test/unit/module_utils/ansible_local_facts/test_fact_path/'
    local_facts_0 = local_fact_collector_0.collect(module_stub_0)
    assert 'local' in local_facts_0
    assert 'test_fact' in local_facts_0['local']
    assert local_facts_0['local']['test_fact'] == 'test fact content'

# Generated at 2022-06-25 00:14:02.812671
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    assert isinstance(local_fact_collector_1.collect(), dict)


# Generated at 2022-06-25 00:14:04.000401
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()


# Generated at 2022-06-25 00:14:05.216341
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:14:10.240401
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    if (local_fact_collector_1.name != 'local'):
        raise AssertionError('local_fact_collector_1.name != \'local\'')
    if (local_fact_collector_1._fact_ids != set()):
        raise AssertionError('local_fact_collector_1._fact_ids != set()')


# Generated at 2022-06-25 00:14:14.085019
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:14:14.669812
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    assert LocalFactCollector().collect() == {}

# Generated at 2022-06-25 00:14:17.126490
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    test_cases = [
        ( test_case_0 ),
    ]

    for test_case in test_cases:
        try:
            test_case()
        except Exception as e:
            assert False, "Exception: {}".format(e)
    assert True

# Generated at 2022-06-25 00:14:20.150078
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_collect_0 = LocalFactCollector()
    local_fact_collector_collect_0.collect()
    local_fact_collector_collect_1 = LocalFactCollector()
    params = dict()
    params['fact_path'] = '/etc/ansible/facts.d'
    local_fact_collector_collect_1.collect(params)


# Generated at 2022-06-25 00:14:25.140370
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

    # verify object attributes are correctly initialized
    assert LocalFactCollector().name == 'local'
    #assert LocalFactCollector()._fact_ids == set()

    assert LocalFactCollector().collect() == {'local': {}}

if __name__ == '__main__':
    test_case_0()
    test_LocalFactCollector()

# Generated at 2022-06-25 00:14:37.781737
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()


# Generated at 2022-06-25 00:14:43.813414
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    c1 = LocalFactCollector()
    assert(c1)
    assert(LocalFactCollector.__name__ == 'LocalFactCollector')
    assert(c1.name == 'local')


# Generated at 2022-06-25 00:14:47.619611
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1._fact_ids == set()


# Generated at 2022-06-25 00:14:51.659540
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_1_collect = local_fact_collector_1.collect()
    local_fact_collector_1_collect_local = local_fact_collector_1_collect['local']
    assert 'test_fact_0' in local_fact_collector_1_collect_local


# Generated at 2022-06-25 00:14:56.264664
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:14:57.769801
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector is not None


# Generated at 2022-06-25 00:14:58.745920
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1._fact_ids == set()


# Generated at 2022-06-25 00:14:59.889035
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    assert {} == local_fact_collector_1.collect(None, None)

# Generated at 2022-06-25 00:15:07.723863
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    fact_path = 'tests/units/module_utils/facts/fixtures/local'
    module_kn = {
        'params': {
            'fact_path': fact_path,
        },
        'warn': lambda x: x,
        'run_command': lambda x: (0, '', ''),
    }
    local_fact_collector_1 = LocalFactCollector()
    local_facts_1 = local_fact_collector_1.collect(module=module_kn, collected_facts={})

# Generated at 2022-06-25 00:15:09.326814
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_1.collect()


# Generated at 2022-06-25 00:15:32.817273
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    # TODO: test this method

# Generated at 2022-06-25 00:15:35.697829
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()



# Generated at 2022-06-25 00:15:38.069755
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # create instance of class LocalFactCollector
    local_fact_collector_0 = LocalFactCollector()
    # collect facts for local
    local_facts_0 = local_fact_collector_0.collect()
    assert local_facts_0 == {}

# Generated at 2022-06-25 00:15:39.835141
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1.name == 'local'


# Generated at 2022-06-25 00:15:42.095402
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-25 00:15:45.464800
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

    local_fact_collector = LocalFactCollector()

    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:15:46.319191
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    LocalFactCollector()


# Generated at 2022-06-25 00:15:53.444869
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    from ansible.module_utils.facts import Facts
    
    # Path to the ansible module to be executed
    module_path='modules/system/setup.py'
    # Arguments for the ansible module
    module_args = '{"filter":null}'
    # Name of the ansible module
    module_name = 'setup'
    # Name of the module arguments
    facts_name = 'ansible_facts'
    # Prefix for all ansible facts
    ansible_facts_prefix = 'ansible'

    # Create a facts object
    facts = Facts()

    # Run the setup module function to collect the facts
    module = facts.setup_module(module_path, module_args, module_name, facts_name, ansible_facts_prefix)

    # Initilize the local fact collector
    local_fact_collect

# Generated at 2022-06-25 00:15:56.350300
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1.name == 'local'
    assert local_fact_collector_1._fact_ids == set()


# Generated at 2022-06-25 00:15:59.644509
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.collect() == {u'local': {}}

# Generated at 2022-06-25 00:16:56.006659
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    myLocalFactCollector = LocalFactCollector()
    assert myLocalFactCollector.name == 'local'
    assert myLocalFactCollector._fact_ids == set()


# Generated at 2022-06-25 00:17:00.858017
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        test_case_0()
    except Exception as e:
        print("Test case 0 Failed - Exception: %s" % e)

if __name__ == "__main__":
    test_LocalFactCollector()

# Generated at 2022-06-25 00:17:03.527941
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector({})


# Generated at 2022-06-25 00:17:05.474158
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    obj = LocalFactCollector()
    assert (obj.name == "local")
    assert (obj._fact_ids == set([]))

# Generated at 2022-06-25 00:17:07.898896
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0 is not None


# Generated at 2022-06-25 00:17:09.005293
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    result_0 = test_case_0()
    assert result_0 is None


# Generated at 2022-06-25 00:17:11.908569
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert not local_fact_collector._fact_ids
    assert local_fact_collector.default_mapping == {'local': 'local'}
    assert local_fact_collector.priority == 80

# Generated at 2022-06-25 00:17:16.470692
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    local_fact_collector.collect()


# Generated at 2022-06-25 00:17:25.459822
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0._fact_ids = set(['local'])
    assert local_fact_collector_0.collect() == {'local': {}}

# Unit tests for _get_fact_path
# def test_LocalFactCollector_get_fact_path():
#     local_fact_collector_0 = LocalFactCollector()
#     assert local_fact_collector_0._get_fact_path() == os.path.join(os.sep, 'etc', 'ansible', 'facts.d')
#
#     local_fact_collector_1 = LocalFactCollector()
#     assert local_fact_collector_1._get_fact_path(custom_basedir='/tmp') == os.path.join('/

# Generated at 2022-06-25 00:17:27.315566
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()

# Generated at 2022-06-25 00:19:36.013122
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    result = local_fact_collector_1.collect()
    # Assert type of result
    assert isinstance(result, dict)

    # Assert 'local' key in result
    assert 'local' in result

    # Assert type of result['local']
    assert isinstance(result['local'], dict)

# Generated at 2022-06-25 00:19:41.803400
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Initializing parameters for test function
    # Testing with empty module
    module_0 = {}
    # Testing with empty collected_facts
    collected_facts_0 = {}

    # Testing with fact_path equal to './sample_facts'
    module_1 = {'params': {'fact_path': './sample_facts'}}
    # Testing with collected_facts equal to {'ansible_local': {'version': '2.1.1.0'}}
    collected_facts_1 = {'ansible_local': {'version': '2.1.1.0'}}

    # Testing with fact_path equal to './sample_facts'
    module_2 = {'params': {'fact_path': './sample_facts'}}
    # Testing with collected_facts equal to {'ansible_local': {'version':

# Generated at 2022-06-25 00:19:45.292257
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1.name() == 'local'
    assert local_fact_collector_1.name == 'local'
    assert local_fact_collector_1._fact_ids == {'local'}


# Generated at 2022-06-25 00:19:49.894670
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

    assert local_fact_collector_0.name == 'local'


# Generated at 2022-06-25 00:19:54.993877
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1.name == 'local', 'Name of LocalFactCollector instance is not "local"'


# Generated at 2022-06-25 00:19:57.897682
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0.name == local_fact_collector_1.name


# Generated at 2022-06-25 00:20:01.472889
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'

# Generated at 2022-06-25 00:20:02.789360
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()


# Generated at 2022-06-25 00:20:08.935224
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    # create object
    local_fact_collector_1 = LocalFactCollector()

    # test methods
    params = { 'fact_path': '/etc/ansible/facts.d/'}
    module = None

    local_fact_collector_1.collect(module, params)

# Generated at 2022-06-25 00:20:12.605792
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert(local_fact_collector_0.name == "local")

# Generated at 2022-06-25 00:22:29.081479
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    assert True

# Generated at 2022-06-25 00:22:34.046302
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()
    var_1 = local_fact_collector_0.collect()
    assert var_0 == {'local': {}}
    assert var_1 == {'local': {}}


# Generated at 2022-06-25 00:22:38.041770
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()
    var_1 = local_fact_collector_0.collect(local_fact_collector_0)


# Generated at 2022-06-25 00:22:41.123742
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.collect()[0] == {}


# Generated at 2022-06-25 00:22:44.405136
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    # value of attribute "name" should be equal to "local"
    assert local_fact_collector_0.name == "local"
    # value of attribute "_fact_ids" should be equal to set()
    assert local_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:22:47.348472
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect()
    var_1 = local_fact_collector_0.collect(local_fact_collector_0)

# Generated at 2022-06-25 00:22:49.713193
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()

# Generated at 2022-06-25 00:22:52.243353
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    var_2 = local_fact_collector_0.collect()


# Generated at 2022-06-25 00:22:53.640048
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    var = local_fact_collector.collect()
    assert var is None

# Generated at 2022-06-25 00:22:56.873232
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.collect()
    local_fact_collector_0.collect(local_fact_collector_0)
