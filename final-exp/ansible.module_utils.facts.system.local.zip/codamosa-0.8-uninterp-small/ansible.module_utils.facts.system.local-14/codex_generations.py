

# Generated at 2022-06-25 00:13:17.784480
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()


# Generated at 2022-06-25 00:13:23.065415
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

    # get an instance of class LocalFactCollector
    local_fact_collector = LocalFactCollector()

    # test name
    assert local_fact_collector.name == 'local'

    # test _fact_ids
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:13:25.532575
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0


# Generated at 2022-06-25 00:13:27.508338
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        test_case_0()
        print("Test case 0 pass")
    except:
        print("Test case 0 fail")
    finally:
        print("Test case 0 complete")

# Generated at 2022-06-25 00:13:29.760944
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()


# Generated at 2022-06-25 00:13:33.416340
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert 'local' == LocalFactCollector().name, \
        "local == LocalFactCollector().name"


# Generated at 2022-06-25 00:13:37.067129
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1 is not None
    assert local_fact_collector_1._fact_ids == set()


# Generated at 2022-06-25 00:13:42.439989
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.collect() == {'local': {}}

    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_1.collect() == {'local': {}}

# Generated at 2022-06-25 00:13:44.714921
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_facts = local_fact_collector_0.collect()
    assert local_facts == { 'local': {} }

# Generated at 2022-06-25 00:13:49.903684
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()

# Generated at 2022-06-25 00:13:56.505033
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()


# Generated at 2022-06-25 00:14:03.348182
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:14:13.684256
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    print("***********************************************************************")
    print("*** Test case 1/2: LocalFactCollector() class constructor")
    print("***********************************************************************")
    try:
        local_fact_collector_0 = LocalFactCollector()
        print("LocalFactCollector() class constructor worked")
    except Exception as e:
        print("LocalFactCollector() class constructor failed")
        print("********** Exception Caught **********")
        print("exception type:", type(e))
        print("exception args:", e.args)


## Unit test for function collect() of class LocalFactCollector
#def test_collect():
#    print("***********************************************************************")
#    print("*** Test case 2/2: collect() function of class LocalFactCollector")
#    print("***********************************************************************")
#    try:
#

# Generated at 2022-06-25 00:14:15.587488
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    result = local_fact_collector_1.collect()
    assert result == {'local': {}} #will fail if no local facts are found

# Generated at 2022-06-25 00:14:22.811736
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()

    # Test snippet from ansible/test/units/modules/utils/facts/test_facts_utils.py
    # test snippet taken from above file to test against

    # run py3 style tests
    test_dict = {}
    test_dict['fact_path'] = ''
    test_dict['module'] = 1

    # test
    result = local_fact_collector_0.collect(test_dict)
    exp_result = {
        "local":{},
        }
    assert result == exp_result

# Generated at 2022-06-25 00:14:26.004884
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()

    # test inheritance
    assert isinstance(local_fact_collector, BaseFactCollector)

    # test instance variables
    assert local_fact_collector.name == 'local'
    assert isinstance(local_fact_collector._fact_ids, set)

# Generated at 2022-06-25 00:14:28.125859
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    local_facts = local_fact_collector.collect()



# Generated at 2022-06-25 00:14:29.826008
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    local_facts = local_fact_collector.collect()

    assert local_facts
    assert 'local' in local_facts

# Generated at 2022-06-25 00:14:31.193767
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()


# Generated at 2022-06-25 00:14:32.427260
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect(None, None)

# Generated at 2022-06-25 00:14:49.540492
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    fact_path_0 = None
    module_0 = None

    local_fact_collector_0 = LocalFactCollector()
    local_facts_0 = local_fact_collector_0.collect(module_0, fact_path_0)

    assert local_facts_0 == {'local': {}}

# Generated at 2022-06-25 00:14:51.778093
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    error = None

    local_fact_collector = LocalFactCollector()

    if local_fact_collector is None:
        error = 'LocalFactCollector class instantiation is None'

    assert error is None, "LocalFactCollector class not initialized"


# Generated at 2022-06-25 00:14:56.264552
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert type(local_fact_collector._fact_ids) == set


# Generated at 2022-06-25 00:14:58.033267
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1.name == 'local'

# Generated at 2022-06-25 00:15:00.197231
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()

    assert local_fact_collector.collect() == {'local': {}}

# Generated at 2022-06-25 00:15:02.476749
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    print("Test for method collect of class LocalFactCollector")
    print("TEST PASS\n")

# unit test for class LocalFactCollector

# Generated at 2022-06-25 00:15:04.643110
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_collect = LocalFactCollector()
    local_fact_collector_collect_out = local_fact_collector_collect.collect()


# Generated at 2022-06-25 00:15:08.043082
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Create an instance of class LocalFactCollector
    local_fact_collector = LocalFactCollector()

    # Check whether instance created is of type LocalFactCollector
    assert isinstance(local_fact_collector, LocalFactCollector)

    # Check instance variables of class LocalFactCollector
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-25 00:15:09.119521
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local = LocalFactCollector()
    assert local.name=='local'

# Generated at 2022-06-25 00:15:11.174210
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector._fact_ids == set()
    assert local_fact_collector.name == 'local'


# Generated at 2022-06-25 00:15:37.606772
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector is not None


# Generated at 2022-06-25 00:15:41.490004
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.__dict__['name'] == 'local'
    assert LocalFactCollector.__dict__['_fact_ids'] == set()
    assert LocalFactCollector.__doc__ == "Facts from files in the local directory"
    assert isinstance(LocalFactCollector.__init__, object)
    assert isinstance(LocalFactCollector.collect, object)



# Generated at 2022-06-25 00:15:51.053122
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Build test case inputs
    local_fact_collector_input_1 = dict(
        collected_facts=dict(),
        module=dict(
            params=dict(
                fact_path=os.path.dirname(os.path.realpath(__file__)) + '/local'
            )
        )
    )
    # Build expected results

# Generated at 2022-06-25 00:15:55.675290
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1.collect() == {'local': {}}


# Generated at 2022-06-25 00:15:58.030629
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'
    local_fact_collector = LocalFactCollector(name='local')
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:16:00.646462
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()

    local_facts = {}
    local_facts['local'] = {}

    collected_facts = {"local": {"test.fact": "fact-value"}}

    local_fact_collector.collect(module=None, collected_facts=collected_facts)

    assert local_facts == collected_facts

# Generated at 2022-06-25 00:16:01.273559
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_case_0()

# Generated at 2022-06-25 00:16:02.790913
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:16:10.952288
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_1 = LocalFactCollector()
    local_fact_collector_2 = LocalFactCollector()
    local_fact_collector_3 = LocalFactCollector()
    local_fact_collector_4 = LocalFactCollector()
    local_fact_collector_5 = LocalFactCollector()
    local_fact_collector_6 = LocalFactCollector()
    local_fact_collector_7 = LocalFactCollector()
    local_fact_collector_8 = LocalFactCollector()
    local_fact_collector_9 = LocalFactCollector()
    local_fact_collector_10 = LocalFactCollector()

# Generated at 2022-06-25 00:16:14.252149
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    local_fact_collector.collect()


# Generated at 2022-06-25 00:16:38.891115
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'
    assert LocalFactCollector._fact_ids == set()
    return


# Generated at 2022-06-25 00:16:40.620138
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    local_facts = local_fact_collector.collect(collected_facts=None)
    assert local_facts['local'] == {}


# Generated at 2022-06-25 00:16:44.730859
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    print("Testing Local fact collector class")
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-25 00:16:48.108956
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

    local_fact_collector = LocalFactCollector()

    assert local_fact_collector is not None
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-25 00:16:53.077417
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    local_fact_collector._module = mock_module_class()
    local_fact_collector.collect(collected_facts=None)
    assert local_fact_collector.get_facts() == {'local': {}}

# Generated at 2022-06-25 00:16:55.795007
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'

# Generated at 2022-06-25 00:16:59.609485
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    local_fact_collector.collect()

# Generated at 2022-06-25 00:17:01.437833
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0._fact_ids == set()

# Generated at 2022-06-25 00:17:04.797512
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    facts_collected = local_fact_collector.collect()

    assert('local' in facts_collected)

# Generated at 2022-06-25 00:17:11.434476
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Check constructor for class LocalFactCollector
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local', 'Constructor for class LocalFactCollector is broken'

    # Check method collect for class LocalFactCollector
    collected_facts_0 = {'success': True, 'changed': False, 'ansible_facts': {'whatever': {'a': 'b'}}}
    local_facts_0 = local_fact_collector_0.collect(None, collected_facts_0)
    assert local_facts_0['local'] == {}, 'Method collect for class LocalFactCollector is broken'

# Generated at 2022-06-25 00:17:48.116244
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    int_0 = -6543
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect(int_0)
    assert var_0 == {"local": {}}
    # Test of raising exception
    try:
        int_1 = -1
        local_fact_collector_0.collect(int_1)
    except Exception:
        assert True

# Generated at 2022-06-25 00:17:51.042093
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_1 = local_fact_collector_0

    local_fact_collector_1.collect()



# Generated at 2022-06-25 00:17:58.937807
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    print('Testing constructor of class LocalFactCollector')
    var_0 = LocalFactCollector()
    #assert var_0 == expected_value
    var_0.name
    var_0.name = "a"
    # Test if type of var_0.name is string
    assert isinstance(var_0.name, str)
    var_0._fact_ids = set()
    # Test if type of var_0._fact_ids is set
    assert isinstance(var_0._fact_ids, set)


# Generated at 2022-06-25 00:17:59.959930
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()


# Generated at 2022-06-25 00:18:03.209360
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    int_0 = -62
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect(int_0)

if __name__ == '__main__':
    test_case_0()
    # test_LocalFactCollector_collect()

# Generated at 2022-06-25 00:18:09.138380
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    int_0 = -6543
    local_fact_collector_0 = LocalFactCollector()
    # Uncomment the following lines to get a dummy output
    #assert local_fact_collector_0.name == 'local'
    #assert local_fact_collector_0._fact_ids == set()
    #local_fact_collector_0.collect(int_0)

# Generated at 2022-06-25 00:18:13.307539
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = AnsibleModule(argument_spec=dict(fact_path=dict(type='str'),))
    int_0 = -6543
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect(int_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 00:18:19.386633
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    int_0 = -6543
    local_fact_collector_0 = LocalFactCollector(int_0)
    dict_0 = local_fact_collector_0.collect()
    int_1 = local_fact_collector_0.name
    assert  int_1 == 'local'


# Test for collect of class LocalFactCollector


# Generated at 2022-06-25 00:18:22.280107
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect()



# Generated at 2022-06-25 00:18:30.294364
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import tempfile
    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-25 00:19:40.420394
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    int_0 = 8376
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect(int_0)


# Generated at 2022-06-25 00:19:44.560080
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert local_fact_collector_0._fact_ids == set()


# Generated at 2022-06-25 00:19:47.783306
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Testing empty constructor of LocalFactCollector
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0._fact_ids == set()
    assert local_fact_collector_0.name == 'local'


# Generated at 2022-06-25 00:19:50.645949
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    int_0 = -6543
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'


# Generated at 2022-06-25 00:20:00.394662
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    int_0 = -6543
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0_copy = LocalFactCollector()
    assert local_fact_collector_0._fact_ids == local_fact_collector_0_copy._fact_ids, "'_fact_ids' is different"
    assert local_fact_collector_0._fact_ids == set(), "'_fact_ids' is different"
    assert local_fact_collector_0.name == local_fact_collector_0_copy.name, "'name' is different"
    assert local_fact_collector_0.name == 'local', "'name' is different"
    assert local_fact_collector_0 == local_fact_collector_0_copy, "Objects are different"

# Generated at 2022-06-25 00:20:03.751424
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    int_0 = -6609
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect(int_0)
    local_fact_collector_1 = LocalFactCollector()


# Generated at 2022-06-25 00:20:05.810252
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    int_0 = -6543
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect(int_0)


if __name__ == '__main__':
    test_case_0()
    test_LocalFactCollector_collect()

# Generated at 2022-06-25 00:20:10.546642
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    int_0 = 76989
    var_0 = LocalFactCollector()
    attributes = dir(var_0)
    # Assert that collect is an attribute
    assert 'collect' in attributes
    # Assert that collect is a callable attribute
    assert 'method' in str(type(getattr(var_0, 'collect')))
    # Assert that the return type of collect is of type dict
    assert isinstance(var_0.collect(int_0), dict)


# Generated at 2022-06-25 00:20:11.914831
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()


# Generated at 2022-06-25 00:20:18.358762
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
    assert local_fact_collector_0.name == 'local'
    assert not local_fact_collector_0.valid
    local_fact_collector_1 = LocalFactCollector()
    assert local_fact_collector_1.name == 'local'
    assert not local_fact_collector_1.valid

# Generated at 2022-06-25 00:22:32.137716
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    int_0 = -6543
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect(int_0)

# Generated at 2022-06-25 00:22:35.040070
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    int_0 = 6240
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect(int_0)


# Generated at 2022-06-25 00:22:37.973672
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    int_0 = -6543
    local_fact_collector_0 = LocalFactCollector()
    local_fact_collector_0.collect(int_0)


# Generated at 2022-06-25 00:22:46.048325
# Unit test for method collect of class LocalFactCollector

# Generated at 2022-06-25 00:22:48.569001
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
  int_0 = -1090355799
  local_fact_collector_0 = LocalFactCollector()
  var_0 = local_fact_collector_0.collect(int_0)
  assert var_0 == {}



# Generated at 2022-06-25 00:22:52.290395
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        assert True
    except AssertionError as ae:
        print("Expected True, but got {}".format(str(ae)))


# Generated at 2022-06-25 00:22:53.229423
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()

# Generated at 2022-06-25 00:22:57.450390
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    int_0 = -2986
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect(int_0)
    if var_0 != {'local': {}}:
        raise AssertionError("Expected: %s, Actual: %s" % ({'local': {}}, var_0))



# Generated at 2022-06-25 00:23:01.532809
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    print("test_LocalFactCollector_collect")

    int_0 = -54
    local_fact_collector_0 = LocalFactCollector()
    var_0 = local_fact_collector_0.collect(int_0)

test_case_0()
test_LocalFactCollector_collect()

# Generated at 2022-06-25 00:23:02.878555
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_0 = LocalFactCollector()
