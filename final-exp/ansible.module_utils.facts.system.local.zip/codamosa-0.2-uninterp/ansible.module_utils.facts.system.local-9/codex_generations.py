

# Generated at 2022-06-17 02:16:34.508312
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            fact_path=dict(type='str', default=None),
        )
    )

    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            fact_path=dict(type='str', default=None),
        )
    )

    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            fact_path=dict(type='str', default=None),
        )
    )

    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            fact_path=dict(type='str', default=None),
        )
    )

    # Create a mock module

# Generated at 2022-06-17 02:16:37.155861
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:16:43.104339
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """
    Unit test for method collect of class LocalFactCollector
    """
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.collect() == {'local': {}}

# Generated at 2022-06-17 02:16:48.855699
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = AnsibleModule(argument_spec={'fact_path': {'type': 'str', 'default': '/etc/ansible/facts.d'}})
    local_fact_collector = LocalFactCollector()
    local_facts = local_fact_collector.collect(module)
    assert local_facts['local'] == {'fact1': 'value1', 'fact2': 'value2'}

# Generated at 2022-06-17 02:16:51.840824
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:16:56.709262
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:17:07.129530
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = type('', (), {})()
    module.params = {'fact_path': './test/unit/module_utils/facts/local/test_facts'}
    module.run_command = lambda x: (0, '', '')
    module.warn = lambda x: None

    # Create a LocalFactCollector object
    lfc = LocalFactCollector()

    # Call the collect method
    facts = lfc.collect(module=module)

    # Assert that the facts are correct

# Generated at 2022-06-17 02:17:08.258061
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:17:16.072180
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a test module
    test_module = AnsibleModule(
        argument_spec=dict(
            fact_path=dict(default='/tmp/ansible_local_facts'),
        ),
        supports_check_mode=True
    )

    # Create a test fact_path directory
    os.makedirs('/tmp/ansible_local_facts')

    # Create a test fact file
    with open('/tmp/ansible_local_facts/test.fact', 'w') as f:
        f.write('{"test_fact": "test_fact_value"}')

    # Create a test executable fact file

# Generated at 2022-06-17 02:17:20.597402
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:17:33.064299
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:17:42.905135
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = type('', (), {})()
    module.params = {'fact_path': '/tmp/facts'}
    module.run_command = lambda x: (0, '', '')
    module.warn = lambda x: None

    # Create a mock os
    os = type('', (), {})()
    os.path = type('', (), {})()
    os.path.exists = lambda x: True
    os.stat = type('', (), {})()
    os.stat.S_IXUSR = 1
    os.path.basename = lambda x: 'test.fact'
    os.path.join = lambda x, y: x + '/' + y

    # Create a mock glob
    glob = type('', (), {})()

# Generated at 2022-06-17 02:17:44.259626
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:17:52.832322
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = MockModule()

    # Create a mock ansible module
    ansible_module = MockAnsibleModule()

    # Create a mock ansible module class
    ansible_module_class = MockAnsibleModuleClass()

    # Set the module class of the mock module to the mock ansible module class
    module.AnsibleModule = ansible_module_class

    # Create a mock ansible module instance
    ansible_module_instance = MockAnsibleModuleInstance()

    # Set the module instance of the mock ansible module class to the mock ansible module instance
    ansible_module_class.return_value = ansible_module_instance

    # Create a mock fact path
    fact_path = '/tmp/ansible_local_facts'

    # Create a mock fact file

# Generated at 2022-06-17 02:18:03.766251
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import get_collector_names
    from ansible.module_utils.facts.collector import get_collector_status
    from ansible.module_utils.facts.collector import get_collector_status_all
    from ansible.module_utils.facts.collector import get_collector_status_list
    from ansible.module_utils.facts.collector import get_collector_status_set
    from ansible.module_utils.facts.collector import get_collector_status_str

# Generated at 2022-06-17 02:18:07.587219
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:18:11.750549
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:18:14.931849
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:18:18.325548
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:18:26.978183
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = type('module', (object,), {
        'run_command': lambda self, cmd: (0, '', ''),
        'warn': lambda self, msg: None,
        'params': {'fact_path': './test/unit/module_utils/facts/local/'}
    })()

    # Create a LocalFactCollector object
    lfc = LocalFactCollector()

    # Call method collect of LocalFactCollector
    result = lfc.collect(module)

    # Check the result
    assert result == {'local': {'test': 'test'}}

# Generated at 2022-06-17 02:18:42.384188
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:18:44.957106
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:18:46.579980
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:18:56.183054
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = type('module', (object,), {'run_command': lambda self, x: (0, '', '')})()
    module.params = {'fact_path': 'test/unit/module_utils/facts/local_facts/test_fact_path'}

    # Create a mock ansible module
    ansible_module = type('ansible_module', (object,), {'warn': lambda self, x: None})()

    # Create a LocalFactCollector object
    local_fact_collector = LocalFactCollector()

    # Call method collect of LocalFactCollector
    local_facts = local_fact_collector.collect(module, ansible_module)

    # Assert that local_facts is not empty
    assert local_facts

    # Assert that local_facts is a dictionary


# Generated at 2022-06-17 02:19:04.462264
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import FactsFiles
    from ansible.module_utils.facts.utils import FactsParams
    from ansible.module_utils.facts.utils import FactsUtils
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_status
    from ansible.module_utils.facts.utils import get_mount_uuid

# Generated at 2022-06-17 02:19:07.248874
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:19:11.253663
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:19:13.465860
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:19:22.296080
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    class MockModule:
        def __init__(self, params):
            self.params = params
            self.warn_called = False
            self.warn_msg = None

        def warn(self, msg):
            self.warn_called = True
            self.warn_msg = msg

        def run_command(self, cmd):
            return 0, '', ''

    # Create a mock module with params
    module = MockModule({'fact_path': 'test/unit/module_utils/facts/local/test_data'})

    # Create a LocalFactCollector object
    lfc = LocalFactCollector()

    # Call method collect of LocalFactCollector object
    result = lfc.collect(module)

    # Assert result

# Generated at 2022-06-17 02:19:24.970982
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:19:54.134084
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:20:03.006173
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.utils import FactsParams
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_access_time
    from ansible.module_utils.facts.utils import get_file_modification_time
    from ansible.module_utils.facts.utils import get_file_status_change_time
    from ansible.module_utils.facts.utils import get_file_inode_change_

# Generated at 2022-06-17 02:20:06.006539
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:20:13.674848
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.local import LocalFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_uid
    from ansible.module_utils.facts.utils import get_file_gid
    from ansible.module_utils.facts.utils import get_file_mode

# Generated at 2022-06-17 02:20:18.154424
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:20:26.218742
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import os
    import tempfile
    import shutil
    import json
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import LocalFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.six.moves import configparser
    from ansible.module_utils._text import to_text

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, temp_file = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file
    fd, temp_file_2 = tempfile.mkstemp()
    os.close(fd)

    # Create a temporary file
    f

# Generated at 2022-06-17 02:20:36.381729
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def run_command(self, cmd):
            return (0, '', '')

        def warn(self, msg):
            pass

    # Create a mock module
    module = MockModule({'fact_path': 'tests/unit/module_utils/facts/local/'})
    # Create a LocalFactCollector object
    lfc = LocalFactCollector()
    # Test the collect method
    assert lfc.collect(module) == {'local': {'test_fact': {'test_section': {'test_option': 'test_value'}}}}

# Generated at 2022-06-17 02:20:38.039524
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:20:39.212083
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:20:46.513956
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system
    import ansible.module_utils.facts.network
    import ansible.module_utils.facts.virtual
    import ansible.module_utils.facts.hardware
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.collector
    import ansible.module_

# Generated at 2022-06-17 02:21:53.073690
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:21:54.419431
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:21:58.681050
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:22:01.612041
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass

# Generated at 2022-06-17 02:22:14.915672
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = AnsibleModule(argument_spec={'fact_path': dict(type='str', default='/etc/ansible/facts.d')})

    # Create a mock class
    class MockLocalFactCollector(LocalFactCollector):
        def __init__(self):
            self.name = 'local'
            self._fact_ids = set()

    # Create a mock class
    class MockAnsibleModule(object):
        def __init__(self):
            self.params = {'fact_path': '/etc/ansible/facts.d'}

        def run_command(self, command):
            return 0, '', ''

        def warn(self, warning):
            pass

    # Create a mock class
    class MockStat(object):
        def __init__(self):
            self

# Generated at 2022-06-17 02:22:18.335483
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:22:28.198764
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = type('AnsibleModule', (object,), {
        'params': {
            'fact_path': '/tmp/facts'
        },
        'run_command': lambda self, command: (0, '', '')
    })()

    # Create a mock os
    os = type('os', (object,), {
        'path': type('path', (object,), {
            'exists': lambda self, path: True
        })()
    })()

    # Create a mock glob
    glob = type('glob', (object,), {
        'glob': lambda self, path: ['/tmp/facts/a.fact', '/tmp/facts/b.fact']
    })()

    # Create a mock stat

# Generated at 2022-06-17 02:22:35.669746
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_uid
    from ansible.module_utils.facts.utils import get_file_gid
    from ansible.module_utils.facts.utils import get_file_mode
    from ansible.module_utils.facts.utils import get_file_mtime

# Generated at 2022-06-17 02:22:38.375881
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:22:48.101316
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Setup
    module = MockModule()
    module.params = {'fact_path': './test/unit/module_utils/facts/local/'}
    local_fact_collector = LocalFactCollector()

    # Test
    local_facts = local_fact_collector.collect(module=module)

    # Assert
    assert local_facts['local']['test_fact'] == 'test_fact_value'
    assert local_facts['local']['test_fact_json'] == {'test_fact_json_key': 'test_fact_json_value'}
    assert local_facts['local']['test_fact_ini'] == {'test_fact_ini_section': {'test_fact_ini_key': 'test_fact_ini_value'}}

# Generated at 2022-06-17 02:25:26.730901
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = AnsibleModule(argument_spec={'fact_path': {'type': 'str', 'required': True}})
    module.params['fact_path'] = './test/unit/module_utils/facts/local/test_fact_path'
    local_fact_collector = LocalFactCollector()
    local_facts = local_fact_collector.collect(module=module)
    assert local_facts['local']['test_fact_1'] == 'test_fact_1_value'
    assert local_facts['local']['test_fact_2'] == 'test_fact_2_value'
    assert local_facts['local']['test_fact_3'] == 'test_fact_3_value'

# Generated at 2022-06-17 02:25:36.787283
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = AnsibleModule(
        argument_spec = dict(
            fact_path = dict(type='str', default='/etc/ansible/facts.d'),
        ),
    )

    # Create a mock fact_path
    fact_path = '/etc/ansible/facts.d'

    # Create a mock file
    fact_file = 'test_fact.fact'
    fact_file_path = os.path.join(fact_path, fact_file)
    with open(fact_file_path, 'w') as f:
        f.write('{"test_fact": "test_value"}')

    # Create a mock module

# Generated at 2022-06-17 02:25:40.795552
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:25:45.179827
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:25:48.271148
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:25:53.337708
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:25:56.863852
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:26:02.036450
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:26:15.114657
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = type('', (), {})()
    module.params = {'fact_path': '/tmp/facts'}
    module.run_command = lambda x: (0, '', '')
    module.warn = lambda x: None

    # Create a mock os.path
    os_path = type('', (), {})()
    os_path.exists = lambda x: True

    # Create a mock os
    os = type('', (), {})()
    os.path = os_path
    os.stat = lambda x: type('', (), {'st_mode': 33261})()

    # Create a mock glob
    glob = type('', (), {})()
    glob.glob = lambda x: ['/tmp/facts/a.fact', '/tmp/facts/b.fact']

    # Create