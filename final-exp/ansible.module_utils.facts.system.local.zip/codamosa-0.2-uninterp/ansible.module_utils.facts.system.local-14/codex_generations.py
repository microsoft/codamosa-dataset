

# Generated at 2022-06-17 02:16:27.342363
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a module
    module = AnsibleModule(argument_spec={'fact_path': dict(type='str', default=None)})
    # Create a LocalFactCollector
    local_fact_collector = LocalFactCollector()
    # Create a collected_facts
    collected_facts = {}
    # Call method collect of LocalFactCollector
    local_facts = local_fact_collector.collect(module=module, collected_facts=collected_facts)
    # Asserts
    assert local_facts == {'local': {}}

# Generated at 2022-06-17 02:16:31.163434
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:16:33.807321
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:16:35.644075
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:16:40.351366
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = AnsibleModule(
        argument_spec = dict(
            fact_path = dict(required=True, type='str'),
        ),
    )
    local_fact_collector = LocalFactCollector()
    local_facts = local_fact_collector.collect(module=module)
    assert local_facts['local']['test_fact'] == 'test_fact_value'

# Generated at 2022-06-17 02:16:42.541580
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:16:46.688647
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:16:51.626171
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:16:56.673004
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:17:07.129637
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = AnsibleModule(argument_spec={'fact_path': dict(type='str', default='/etc/ansible/facts.d')})

    # Create a mock class
    class MockLocalFactCollector(LocalFactCollector):
        def __init__(self, module):
            self.module = module

    # Create a mock class
    class MockAnsibleModule(object):
        def __init__(self, argument_spec):
            self.params = argument_spec

        def run_command(self, fn):
            return 0, '{"key": "value"}', ''

    # Create a mock class
    class MockConfigParser(object):
        def __init__(self):
            self.sections = []

        def sections(self):
            return self.sections


# Generated at 2022-06-17 02:17:27.507525
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = type('', (), {})()
    module.params = {'fact_path': './test/unit/module_utils/facts/local/test_facts'}
    module.run_command = lambda x: (0, '', '')

    # Create a mock module
    module_warn = type('', (), {})()
    module_warn.params = {'fact_path': './test/unit/module_utils/facts/local/test_facts'}
    module_warn.warn = lambda x: None
    module_warn.run_command = lambda x: (1, '', '')

    # Create a mock module
    module_error = type('', (), {})()

# Generated at 2022-06-17 02:17:32.636176
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:17:41.991324
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.local import LocalFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_uid
    from ansible.module_utils.facts.utils import get_file_gid
    from ansible.module_utils.facts.utils import get_file_mode

# Generated at 2022-06-17 02:17:46.625272
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:17:49.133313
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:17:59.121669
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.utils import FactsCache
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFact

# Generated at 2022-06-17 02:18:01.855827
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:18:05.681541
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:18:08.281295
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:18:11.831524
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:18:25.782346
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:18:33.354929
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = type('', (), {})()
    module.params = {'fact_path': './test/unit/module_utils/facts/local_facts'}
    module.run_command = lambda x: (0, '', '')
    module.warn = lambda x: None

    # Create a mock ansible module
    ansible_module = type('', (), {})()
    ansible_module.params = {'fact_path': './test/unit/module_utils/facts/local_facts'}
    ansible_module.run_command = lambda x: (0, '', '')
    ansible_module.warn = lambda x: None

    # Create a LocalFactCollector
    local_fact_collector = LocalFactCollector()

    # Test the collect method
    assert local_fact

# Generated at 2022-06-17 02:18:36.077367
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:18:38.509529
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:18:39.715516
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:18:49.397914
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = type('', (), {})()
    module.run_command = lambda x: (0, '', '')
    module.params = {'fact_path': 'test/unit/module_utils/facts/local_facts/test_fact_path'}
    module.warn = lambda x: None

    # Create a LocalFactCollector object
    lfc = LocalFactCollector()

    # Call method collect
    result = lfc.collect(module)

    # Check result
    assert result == {'local': {'test_fact_1': 'test_fact_1_value', 'test_fact_2': 'test_fact_2_value'}}

# Generated at 2022-06-17 02:18:53.550441
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:18:57.505857
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:19:08.351822
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a module for testing
    module = AnsibleModule(argument_spec={})
    module.params = {'fact_path': '/tmp/facts'}

    # Create a LocalFactCollector object
    local_fact_collector = LocalFactCollector()

    # Create a file for testing
    fact_file = '/tmp/facts/test.fact'
    with open(fact_file, 'w') as f:
        f.write('[section]\n')
        f.write('key=value\n')

    # Test collect method
    local_facts = local_fact_collector.collect(module=module)
    assert local_facts['local']['test'] == {'section': {'key': 'value'}}

    # Clean up
    os.remove(fact_file)

# Generated at 2022-06-17 02:19:18.681438
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = AnsibleModule(
        argument_spec = dict(
            fact_path = dict(type='str', default='/etc/ansible/facts.d'),
        )
    )

    # Create a mock module
    module = AnsibleModule(
        argument_spec = dict(
            fact_path = dict(type='str', default='/etc/ansible/facts.d'),
        )
    )

    # Create a mock module
    module = AnsibleModule(
        argument_spec = dict(
            fact_path = dict(type='str', default='/etc/ansible/facts.d'),
        )
    )

    # Create a mock module

# Generated at 2022-06-17 02:19:54.667705
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = type('', (), {})()
    module.params = {'fact_path': './test/unit/module_utils/facts/local/test_facts'}
    module.run_command = lambda x: (0, '', '')
    module.warn = lambda x: None

    # Create a mock facts
    collected_facts = {'local': {}}

    # Create a LocalFactCollector object
    lfc = LocalFactCollector()

    # Call method collect
    facts = lfc.collect(module, collected_facts)

    # Assertion

# Generated at 2022-06-17 02:20:03.108909
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = AnsibleModule(argument_spec={'fact_path': {'type': 'str'}})
    module.params = {'fact_path': '/tmp/test_facts'}
    # Create a mock os
    os = MockOs()
    # Create a mock stat
    stat = MockStat()
    # Create a mock module.run_command
    module.run_command = MockRunCommand()
    # Create a mock get_file_content
    get_file_content = MockGetFileContent()
    # Create a mock to_text
    to_text = MockToText()
    # Create a mock json
    json = MockJson()
    # Create a mock configparser
    configparser = MockConfigParser()
    # Create a mock StringIO
    StringIO = MockStringIO()
    # Create

# Generated at 2022-06-17 02:20:14.483016
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = type('', (), {})()

    # Create a mock module.run_command
    def run_command(self, cmd):
        return 0, '', ''
    module.run_command = run_command

    # Create a mock module.warn
    def warn(self, msg):
        pass
    module.warn = warn

    # Create a mock module.params
    module.params = {
        'fact_path': '/tmp/facts'
    }

    # Create a mock os.path.exists
    def exists(path):
        return True
    os.path.exists = exists

    # Create a mock os.stat
    def stat(path):
        return {
            'st_mode': 33261
        }
    os.stat = stat

    # Create a mock glob.glob

# Generated at 2022-06-17 02:20:17.388982
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:20:25.796249
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = AnsibleModule(argument_spec={'fact_path': {'type': 'str', 'required': True}})
    module.params['fact_path'] = os.path.join(os.path.dirname(__file__), 'fixtures', 'local')
    local_facts = LocalFactCollector().collect(module=module)
    assert local_facts['local']['test_fact'] == {'test_section': {'test_key': 'test_value'}}
    assert local_facts['local']['test_fact_json'] == {'test_key': 'test_value'}
    assert local_facts['local']['test_fact_executable'] == {'test_key': 'test_value'}

# Generated at 2022-06-17 02:20:30.278626
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:20:36.381833
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = None
    collected_facts = None
    fact_path = None
    fact_base = None
    fact = None
    local_facts = {}
    local_facts['local'] = {}

    fact_path = '/etc/ansible/facts.d'
    fact_base = 'test'
    fact = 'test'

    local_facts['local'][fact_base] = fact

    assert LocalFactCollector().collect(module, collected_facts) == local_facts

# Generated at 2022-06-17 02:20:38.351293
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:20:39.974695
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:20:47.390871
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """
    Test the collect method of LocalFactCollector
    """
    # Create a LocalFactCollector object
    local_fact_collector = LocalFactCollector()

    # Create a module object
    module = AnsibleModule(argument_spec={})

    # Create a collected_facts object
    collected_facts = {}

    # Test the collect method
    local_facts = local_fact_collector.collect(module=module, collected_facts=collected_facts)

    # Check the result
    assert local_facts == {'local': {}}

# Generated at 2022-06-17 02:21:48.136259
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:21:56.149833
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = AnsibleModule(
        argument_spec=dict(
            fact_path=dict(type='str', default='/etc/ansible/facts.d'),
        ),
    )

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    os.chmod(tmpdir, 0o755)  # Start with standard permissions

    # Create a temporary file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    tmpfile.write(b'{"foo": "bar"}')
    tmpfile.close()

    # Create a temporary executable file
    tmpfile = tempfile.NamedTemporaryFile(dir=tmpdir, delete=False)
    tmpfile.write(b'#!/bin/sh\necho {"foo": "bar"}')
    tmpfile.close()

# Generated at 2022-06-17 02:21:58.866327
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:22:00.768958
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:22:04.452557
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:22:08.396629
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:22:11.133184
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:22:14.024608
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:22:19.804530
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = type('AnsibleModule', (object,), {
        'params': {'fact_path': './test/unit/module_utils/facts/local/'},
        'run_command': lambda self, cmd: (0, '', ''),
        'warn': lambda self, msg: None
    })()

    # Create a LocalFactCollector object
    lfc = LocalFactCollector()

    # Call method collect of LocalFactCollector object
    result = lfc.collect(module=module)

    # Assert the result
    assert result == {'local': {'test_fact': {'test_section': {'test_option': 'test_value'}}}}

# Generated at 2022-06-17 02:22:28.268721
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = type('', (), {})()
    module.params = {'fact_path': './test/unit/module_utils/facts/local/'}
    module.run_command = lambda x: (0, '', '')
    module.warn = lambda x: None

    # Create a mock ansible module
    ansible_module = type('', (), {})()
    ansible_module.params = {'fact_path': './test/unit/module_utils/facts/local/'}
    ansible_module.run_command = lambda x: (0, '', '')
    ansible_module.warn = lambda x: None

    # Create a LocalFactCollector object
    local_fact_collector = LocalFactCollector()

    # Test collect method
    local_facts = local_

# Generated at 2022-06-17 02:24:32.050824
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:24:37.285427
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:24:48.772095
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = type('', (), {})()
    module.params = {'fact_path': '/tmp/facts'}
    module.run_command = lambda x: (0, '', '')
    module.warn = lambda x: None

    # Create a mock os
    os = type('', (), {})()
    os.path = type('', (), {})()
    os.path.exists = lambda x: True
    os.path.basename = lambda x: 'test.fact'
    os.stat = type('', (), {})()
    os.stat.S_IXUSR = 1

    # Create a mock glob
    glob = type('', (), {})()
    glob.glob = lambda x: ['test.fact']

    # Create a mock json

# Generated at 2022-06-17 02:24:58.050634
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a dummy module
    module = type('', (), {})()
    module.params = {'fact_path': '/tmp/test_local_facts'}
    module.run_command = lambda x: (0, '', '')
    module.warn = lambda x: None

    # Create a dummy fact_path
    fact_path = '/tmp/test_local_facts'
    os.makedirs(fact_path)

    # Create a dummy fact file
    fact_file = os.path.join(fact_path, 'test.fact')
    with open(fact_file, 'w') as f:
        f.write('{"test": "test"}')

    # Create a dummy executable fact file
    fact_file = os.path.join(fact_path, 'test_exec.fact')

# Generated at 2022-06-17 02:25:08.308398
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import os
    import tempfile
    import shutil
    import json

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible.cfg
    fd, path = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as f:
        f.write("[defaults]\n")
        f.write("fact_path = %s\n" % tmpdir)

    # Create a temporary fact file
    fd, path = tempfile.mkstemp(dir=tmpdir, suffix='.fact')
    with os.fdopen(fd, 'w') as f:
        f.write("#!/bin/sh\n")
        f.write("echo '{\"a\": 1}'\n")

# Generated at 2022-06-17 02:25:13.301098
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:25:18.191537
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:25:25.969091
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = type('', (), {})()
    module.params = {'fact_path': '/tmp/ansible_local_facts'}
    module.run_command = lambda x: (0, '', '')
    module.warn = lambda x: None

    # Create a mock os
    os = type('', (), {})()
    os.path = type('', (), {})()
    os.path.exists = lambda x: True
    os.stat = type('', (), {})()
    os.stat.S_IXUSR = 1

    # Create a mock glob
    glob = type('', (), {})()
    glob.glob = lambda x: ['/tmp/ansible_local_facts/test.fact']

    # Create a mock json
    json = type('', (), {})()

# Generated at 2022-06-17 02:25:28.007323
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:25:32.017474
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()
