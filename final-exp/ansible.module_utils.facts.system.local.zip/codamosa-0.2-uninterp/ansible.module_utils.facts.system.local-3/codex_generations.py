

# Generated at 2022-06-17 02:16:25.693016
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:16:37.255810
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = type('module', (object,), {'run_command': lambda self, cmd: (0, '', '')})()
    # Create a mock module.params
    module.params = type('params', (object,), {'get': lambda self, key: 'fact_path'})()
    # Create a mock os.path
    os_path = type('os_path', (object,), {'exists': lambda self, path: True})()
    # Create a mock os
    os = type('os', (object,), {'path': os_path, 'stat': lambda self, path: type('stat', (object,), {'ST_MODE': 0})()})()
    # Create a mock glob

# Generated at 2022-06-17 02:16:39.681916
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:16:48.245700
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = AnsibleModule(
        argument_spec={
            'fact_path': dict(type='str', default='/etc/ansible/facts.d')
        }
    )

    # Create a mock facts
    facts = {}

    # Create a LocalFactCollector object
    lfc = LocalFactCollector()

    # Test the collect method
    lfc.collect(module=module, collected_facts=facts)

    # Test the result
    assert facts['local']['test_fact'] == 'test_value'

# Generated at 2022-06-17 02:16:51.183425
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:16:56.635345
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:16:59.494755
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:17:09.303482
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution

# Generated at 2022-06-17 02:17:11.399499
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:17:14.097195
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:17:22.041109
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:17:29.933813
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a LocalFactCollector object
    local_fact_collector = LocalFactCollector()

    # Create a module object
    module = AnsibleModule(argument_spec={'fact_path': dict(type='str', default='/etc/ansible/facts.d')})

    # Create a collected_facts object
    collected_facts = dict()

    # Call method collect of LocalFactCollector
    local_facts = local_fact_collector.collect(module, collected_facts)

    # Assert that local_facts is not empty
    assert local_facts

# Generated at 2022-06-17 02:17:32.955212
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:17:35.244822
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:17:46.269628
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = type('', (), {})()
    module.params = {'fact_path': '/tmp/ansible_local_facts'}
    module.run_command = lambda x: (0, '', '')
    module.warn = lambda x: None

    # Create a mock file
    fact_file = '/tmp/ansible_local_facts/test.fact'
    with open(fact_file, 'w') as f:
        f.write('{"test": "test"}')

    # Create a LocalFactCollector
    local_fact_collector = LocalFactCollector()

    # Call the collect method
    facts = local_fact_collector.collect(module)

    # Assert the result
    assert facts == {'local': {'test': {'test': 'test'}}}

    #

# Generated at 2022-06-17 02:17:47.891575
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:17:59.048695
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import FactsFiles
    from ansible.module_utils.facts.utils import FactsParams
    from ansible.module_utils.facts.utils import FactsCache
    from ansible.module_utils.facts.utils import AnsibleModule
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_content_safe
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_lines_safe
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_size

# Generated at 2022-06-17 02:18:00.519105
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:18:05.241652
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:18:15.850857
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import os
    import tempfile
    import shutil
    import json
    import stat

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import LocalFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    # create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # create a file with json content
    json_file = os.path.join(tmpdir, 'json.fact')
    with open(json_file, 'w') as f:
        f.write('{"a": 1, "b": 2}')

    # create a file with ini content
    ini_file = os.path.join(tmpdir, 'ini.fact')

# Generated at 2022-06-17 02:18:32.653941
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_content_if_exists
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options

# Generated at 2022-06-17 02:18:42.497588
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import FactsFiles
    from ansible.module_utils.facts.utils import FactsParams
    from ansible.module_utils.facts.utils import FactsUtils
    from ansible.module_utils.facts.utils import ModuleUtils
    from ansible.module_utils.facts.utils import AnsibleModule
    from ansible.module_utils.facts.utils import AnsibleModuleUtils
    from ansible.module_utils.facts.utils import AnsibleModuleUtilsArgSpec
    from ansible.module_utils.facts.utils import AnsibleModuleUtilsParams
    from ansible.module_utils.facts.utils import AnsibleModuleUtilsAnsibleModule
    from ansible.module_utils.facts.utils import Ansible

# Generated at 2022-06-17 02:18:52.069122
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import os
    import tempfile
    import shutil
    import json
    import stat
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import LocalFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_content

# Generated at 2022-06-17 02:19:03.215327
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors import LocalFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_mount_status

# Generated at 2022-06-17 02:19:05.963325
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:19:16.340161
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = AnsibleModule(
        argument_spec=dict(
            fact_path=dict(type='str', default=None),
        ),
    )

    # Create a mock fact_path
    fact_path = '/tmp/ansible_local_facts'
    if not os.path.exists(fact_path):
        os.makedirs(fact_path)

    # Create a mock fact file
    fact_file = os.path.join(fact_path, 'test.fact')
    with open(fact_file, 'w') as f:
        f.write('{"test": "test"}')

    # Create a mock executable fact file
    executable_fact_file = os.path.join(fact_path, 'executable.fact')

# Generated at 2022-06-17 02:19:18.758378
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:19:28.633465
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = AnsibleModule(argument_spec={'fact_path': {'type': 'str'}})
    module.params['fact_path'] = '/etc/ansible/facts.d'
    # Create a mock facts
    collected_facts = {}
    # Create a LocalFactCollector object
    local_fact_collector = LocalFactCollector()
    # Test the collect method
    local_facts = local_fact_collector.collect(module=module, collected_facts=collected_facts)
    assert local_facts == {'local': {}}


# Generated at 2022-06-17 02:19:39.697731
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = AnsibleModule(argument_spec={'fact_path': {'type': 'str', 'required': True}})
    module.params['fact_path'] = os.path.join(os.path.dirname(__file__), 'fixtures', 'local_facts')
    local_facts = LocalFactCollector().collect(module=module)
    assert local_facts['local']['test_fact'] == 'test_fact_value'
    assert local_facts['local']['test_fact_json'] == {'test_fact_json_key': 'test_fact_json_value'}
    assert local_facts['local']['test_fact_ini'] == {'test_fact_ini_section': {'test_fact_ini_key': 'test_fact_ini_value'}}

# Generated at 2022-06-17 02:19:46.168446
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a module object
    module = AnsibleModule(argument_spec={})
    # Create a LocalFactCollector object
    local_fact_collector = LocalFactCollector()
    # Call method collect of LocalFactCollector object
    local_facts = local_fact_collector.collect(module)
    # Assert that local_facts is not None
    assert local_facts is not None
    # Assert that local_facts is a dict
    assert isinstance(local_facts, dict)
    # Assert that local_facts has one key
    assert len(local_facts.keys()) == 1
    # Assert that local_facts has a key named 'local'
    assert 'local' in local_facts.keys()
    # Assert that local_facts['local'] is a dict

# Generated at 2022-06-17 02:20:21.134548
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = type('', (), {})()
    module.params = {'fact_path': '/tmp/facts'}
    module.run_command = lambda x: (0, '', '')
    module.warn = lambda x: None

    # Create a mock os module
    os = type('', (), {})()
    os.path = type('', (), {})()
    os.path.exists = lambda x: True
    os.path.basename = lambda x: 'test.fact'
    os.stat = type('', (), {})()
    os.stat.S_IXUSR = 1

    # Create a mock glob module
    glob = type('', (), {})()
    glob.glob = lambda x: ['/tmp/facts/test.fact']

    # Create a mock json module


# Generated at 2022-06-17 02:20:23.420201
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:20:30.534683
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = AnsibleModule(
        argument_spec = dict(
            fact_path = dict(type='str', default='/etc/ansible/facts.d'),
        ),
    )

    # Create a mock facts
    collected_facts = dict()

    # Create a LocalFactCollector object
    local_fact_collector = LocalFactCollector()

    # Call method collect of LocalFactCollector
    local_facts = local_fact_collector.collect(module=module, collected_facts=collected_facts)

    # Check if local_facts is empty
    assert local_facts == dict()

# Generated at 2022-06-17 02:20:40.693962
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_status
    from ansible.module_utils.facts.utils import get_package_facts
    from ansible.module_utils.facts.utils import get_service_status

# Generated at 2022-06-17 02:20:42.149672
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:20:45.541158
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:20:46.638238
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:20:48.321793
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:20:54.692700
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a module object
    module = AnsibleModule(
        argument_spec = dict(
            fact_path=dict(type='str', default='/etc/ansible/facts.d'),
        ),
        supports_check_mode=True
    )

    # Create a LocalFactCollector object
    local_fact_collector_obj = LocalFactCollector()

    # Test method collect of class LocalFactCollector
    local_facts = local_fact_collector_obj.collect(module=module)
    assert local_facts == {'local': {}}

# Generated at 2022-06-17 02:20:56.629214
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:22:08.715008
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = AnsibleModule(argument_spec={'fact_path': dict(type='str', default='/etc/ansible/facts.d')})

    # Create a mock ansible module
    ansible_module = AnsibleModule(argument_spec={'fact_path': dict(type='str', default='/etc/ansible/facts.d')})

    # Create a mock ansible module
    ansible_module_2 = AnsibleModule(argument_spec={'fact_path': dict(type='str', default='/etc/ansible/facts.d')})

    # Create a mock ansible module
    ansible_module_3 = AnsibleModule(argument_spec={'fact_path': dict(type='str', default='/etc/ansible/facts.d')})

    # Create a mock ansible module

# Generated at 2022-06-17 02:22:13.046131
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:22:18.518478
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:22:23.944861
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:22:29.199935
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = AnsibleModule(
        argument_spec=dict(
            fact_path=dict(type='str', default='/etc/ansible/facts.d'),
        ),
    )
    fact_path = module.params.get('fact_path', None)
    local_facts = {}
    local_facts['local'] = {}
    if not module:
        return local_facts
    if not fact_path or not os.path.exists(fact_path):
        return local_facts
    local = {}
    for fn in sorted(glob.glob(fact_path + '/*.fact')):
        fact_base = os.path.basename(fn).replace('.fact', '')
        if stat.S_IXUSR & os.stat(fn)[stat.ST_MODE]:
            failed = None

# Generated at 2022-06-17 02:22:31.396133
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:22:33.528339
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:22:44.796051
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = AnsibleModule(
        argument_spec = dict(
            fact_path=dict(type='str', required=False)
        )
    )

    # Create a mock fact_path
    fact_path = '/tmp/ansible_local_facts'

    # Create a mock fact file
    fact_file = 'test.fact'

    # Create a mock fact file content
    fact_file_content = '{"test": "test"}'

    # Create a mock fact file path
    fact_file_path = os.path.join(fact_path, fact_file)

    # Create a mock fact file
    open(fact_file_path, 'w').write(fact_file_content)

    # Create a mock fact file mode
    os.chmod(fact_file_path, 0o755)

# Generated at 2022-06-17 02:22:53.326712
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = type('module', (object,), {
        'params': {
            'fact_path': '/tmp/facts'
        },
        'run_command': lambda self, cmd: (0, '', '')
    })

    # Create a mock fact file
    fact_file = '/tmp/facts/test.fact'
    with open(fact_file, 'w') as f:
        f.write('{"test": "test"}')

    # Create a mock fact file
    fact_file = '/tmp/facts/test2.fact'
    with open(fact_file, 'w') as f:
        f.write('[test]\ntest=test')

    # Create a mock fact file
    fact_file = '/tmp/facts/test3.fact'

# Generated at 2022-06-17 02:22:56.090153
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:25:23.282329
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:25:28.550440
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:25:31.782662
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:25:39.374161
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = AnsibleModule(argument_spec={'fact_path': dict(type='str', default=None)})

    # Create a mock fact_path
    fact_path = 'tests/unit/module_utils/facts/collector/local/'

    # Create a LocalFactCollector object
    local_fact_collector = LocalFactCollector()

    # Call method collect of LocalFactCollector object
    local_facts = local_fact_collector.collect(module=module, fact_path=fact_path)

    # Assert that the local_facts is not empty
    assert local_facts

    # Assert that the local_facts is a dict
    assert isinstance(local_facts, dict)

    # Assert that the local_facts has a key 'local'
    assert 'local' in local_facts

# Generated at 2022-06-17 02:25:41.011312
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:25:51.783910
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_file_uid
    from ansible.module_utils.facts.utils import get_file_gid
    from ansible.module_utils.facts.utils import get_file_mode
    from ansible.module_utils.facts.utils import get_file_mtime

# Generated at 2022-06-17 02:25:56.668103
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = AnsibleModule(argument_spec={})

    # Create a mock facts
    collected_facts = dict()

    # Create a LocalFactCollector object
    lfc = LocalFactCollector()

    # Test the method collect of the class LocalFactCollector
    lfc.collect(module=module, collected_facts=collected_facts)

    # Assertion for the method collect
    assert collected_facts == {'local': {}}


# Generated at 2022-06-17 02:26:01.909813
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:26:06.976008
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:26:10.903552
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()