

# Generated at 2022-06-17 02:16:28.062759
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:16:33.291396
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = AnsibleModule(argument_spec={'fact_path': dict(type='str', default=None)})
    local_fact_collector = LocalFactCollector()
    local_facts = local_fact_collector.collect(module)
    assert local_facts == {'local': {}}

# Generated at 2022-06-17 02:16:40.777981
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = type('', (), {})()
    module.params = {'fact_path': 'test/unit/module_utils/facts/local/test_facts'}
    module.run_command = lambda x: (0, '', '')
    module.warn = lambda x: None

    # Create a LocalFactCollector object
    local_fact_collector = LocalFactCollector()

    # Test the collect method
    result = local_fact_collector.collect(module=module)
    assert result == {'local': {'fact1': 'value1', 'fact2': 'value2'}}

# Generated at 2022-06-17 02:16:47.101508
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = AnsibleModule(argument_spec={'fact_path': dict(type='str', default='/etc/ansible/facts.d')})
    local_fact_collector = LocalFactCollector()
    local_facts = local_fact_collector.collect(module=module)
    assert local_facts['local'] == {'test': {'test': 'test'}}

# Generated at 2022-06-17 02:16:49.314495
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:16:52.099707
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:16:55.357307
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:16:57.782388
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:17:04.706216
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {'fact_path': '/tmp/facts'}

        def warn(self, msg):
            print(msg)

        def run_command(self, cmd):
            return 0, '', ''

    # create a mock file
    with open('/tmp/facts/test.fact', 'w') as f:
        f.write('{"test": "test"}')

    # create a mock file
    with open('/tmp/facts/test2.fact', 'w') as f:
        f.write('[test]\ntest=test')

    # create a mock file

# Generated at 2022-06-17 02:17:12.881872
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = type('module', (object,), {
        'run_command': lambda self, cmd: (0, '', ''),
        'params': {'fact_path': 'test/unit/module_utils/facts/local/facts'},
        'warn': lambda self, msg: None
    })()

    # Create a LocalFactCollector object
    lfc = LocalFactCollector()

    # Get the local facts
    local_facts = lfc.collect(module=module)

    # Assert that the local facts are as expected
    assert local_facts['local']['fact1'] == 'value1'
    assert local_facts['local']['fact2'] == 'value2'
    assert local_facts['local']['fact3'] == 'value3'

# Generated at 2022-06-17 02:17:27.193638
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:17:32.630908
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:17:38.179287
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = AnsibleModule(
        argument_spec = dict(
            fact_path=dict(type='str', required=False),
        )
    )

    # Create a mock module
    module = AnsibleModule(
        argument_spec = dict(
            fact_path=dict(type='str', required=False),
        )
    )

    # Create a mock module
    module = AnsibleModule(
        argument_spec = dict(
            fact_path=dict(type='str', required=False),
        )
    )

    # Create a mock module
    module = AnsibleModule(
        argument_spec = dict(
            fact_path=dict(type='str', required=False),
        )
    )

    # Create a mock module

# Generated at 2022-06-17 02:17:48.272411
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_size
    from ansible.module_utils.facts.utils import get_file_stat
    from ansible.module_utils.facts.utils import get_file_type
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_mount_options
    from ansible.module_utils.facts.utils import get_mount_status
    from ansible.module_utils.facts.utils import get_mount_uuid

# Generated at 2022-06-17 02:17:53.676000
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:17:57.808768
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:18:00.522412
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-17 02:18:04.030421
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'
    assert LocalFactCollector._fact_ids == set()

# Generated at 2022-06-17 02:18:11.909822
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """
    Test the collect method of LocalFactCollector
    """
    # Create a mock module
    module = MockModule()
    # Create a LocalFactCollector object
    local_fact_collector = LocalFactCollector()
    # Create a mock collected_facts
    collected_facts = {}
    # Call the collect method of LocalFactCollector object
    local_facts = local_fact_collector.collect(module, collected_facts)
    # Assert the local_facts is empty
    assert local_facts == {}


# Generated at 2022-06-17 02:18:18.044988
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.collector import FactsCache
    from ansible.module_utils.facts.collector import BaseFileCacheModule
    from ansible.module_utils.facts.collector import BaseFileCachePlugin
    from ansible.module_utils.facts.collector import BaseFileSearch
    from ansible.module_utils.facts.collector import FileSearch
    from ansible.module_utils.facts.collector import BaseFileSearchPlugin
    from ansible.module_utils.facts.collector import BaseFile

# Generated at 2022-06-17 02:18:41.070700
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = type('', (), {})()
    module.params = {'fact_path': 'test/unit/module_utils/facts/test_facts/local'}
    module.run_command = lambda x: (0, '', '')

    # Create a mock module
    module2 = type('', (), {})()
    module2.params = {'fact_path': 'test/unit/module_utils/facts/test_facts/local'}
    module2.run_command = lambda x: (1, '', '')

    # Create a mock module
    module3 = type('', (), {})()
    module3.params = {'fact_path': 'test/unit/module_utils/facts/test_facts/local'}

# Generated at 2022-06-17 02:18:44.839554
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:18:52.780336
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import os
    import tempfile
    import shutil
    import json
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible.cfg
    fd, path = tempfile.mkstemp()
    with os.fdopen(fd, 'w') as f:
        f.write("[defaults]\n")
        f.write("fact_path = %s\n" % tmpdir)

    # Create a temporary fact file
    fd, path = tempfile.mkstemp(dir=tmpdir, prefix='fact_', suffix='.fact')
    with os.fdopen(fd, 'w') as f:
        f.write("#!/bin/sh\n")

# Generated at 2022-06-17 02:18:57.105302
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:19:01.210196
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:19:05.101861
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:19:16.566273
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.distribution import Distribution

# Generated at 2022-06-17 02:19:18.166061
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:19:22.116497
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:19:24.779928
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:19:56.203838
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a module object
    module = AnsibleModule(
        argument_spec = dict(
            fact_path = dict(required=False, type='str'),
        ),
        supports_check_mode=True
    )

    # Create a LocalFactCollector object
    local_fact_collector_obj = LocalFactCollector()

    # Get the facts
    facts = local_fact_collector_obj.collect(module=module)

    # Test the facts
    assert facts == {'local': {}}

# Generated at 2022-06-17 02:19:58.791585
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:20:10.271181
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = AnsibleModule(argument_spec={})
    module.run_command = mock.Mock()
    module.warn = mock.Mock()

    # Create a mock fact_path
    fact_path = '/tmp/facts'
    if not os.path.exists(fact_path):
        os.makedirs(fact_path)

    # Create a mock fact file
    fact_file = os.path.join(fact_path, 'test_fact.fact')
    with open(fact_file, 'w') as f:
        f.write('{"test_fact": "test_fact_value"}')

    # Create a mock executable fact file
    fact_file = os.path.join(fact_path, 'test_executable_fact.fact')

# Generated at 2022-06-17 02:20:14.009172
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:20:18.316384
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:20:26.308087
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    import tempfile
    import shutil
    import os
    import json
    import stat

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a file in the temporary directory
    file_path = os.path.join(tmpdir, 'test.fact')
    with open(file_path, 'w') as f:
        f.write('{"test": "test"}')

    # Create a file in the temporary directory
    file_path = os.path.join(tmpdir, 'test2.fact')

# Generated at 2022-06-17 02:20:30.521135
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:20:40.646823
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = type('module', (object,), {
        'params': {
            'fact_path': '/tmp/facts'
        },
        'warn': lambda self, msg: None,
        'run_command': lambda self, cmd: (0, '', '')
    })()

    # Create a mock os.path
    os_path = type('os.path', (object,), {
        'exists': lambda self, path: True
    })()

    # Create a mock os
    os = type('os', (object,), {
        'stat': lambda self, path: type('stat', (object,), {
            'S_IXUSR': lambda self: True
        })()
    })()

    # Create a mock glob

# Generated at 2022-06-17 02:20:44.293178
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a module object
    module = AnsibleModule(argument_spec={'fact_path': {'type': 'str'}})
    # Create a LocalFactCollector object
    lfc = LocalFactCollector()
    # Create a facts dict
    facts = dict()
    # Call method collect of the LocalFactCollector object
    lfc.collect(module, facts)
    # Assertion error if the facts dict is empty
    assert facts

# Generated at 2022-06-17 02:20:55.723308
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = AnsibleModule(
        argument_spec = dict(
            fact_path = dict(type='str', default='/etc/ansible/facts.d'),
        ),
    )

    # Create a mock class
    class MockClass:
        def __init__(self, module):
            self.module = module

        def run_command(self, cmd):
            return 0, '', ''

    # Create a mock AnsibleModule
    class AnsibleModule:
        def __init__(self, argument_spec):
            self.params = argument_spec

        def warn(self, msg):
            pass

    # Create a mock get_file_content
    def get_file_content(fn, default=''):
        return '{"test": "test"}'

    # Create a mock to_text


# Generated at 2022-06-17 02:22:02.001042
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:22:15.082043
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = AnsibleModule(argument_spec={'fact_path': {'type': 'str', 'required': True}})
    module.params['fact_path'] = os.path.join(os.path.dirname(__file__), 'fixtures', 'local_facts')
    local_facts = LocalFactCollector().collect(module=module)
    assert local_facts['local']['fact_1'] == 'fact_1'
    assert local_facts['local']['fact_2'] == 'fact_2'
    assert local_facts['local']['fact_3'] == 'fact_3'
    assert local_facts['local']['fact_4'] == 'fact_4'
    assert local_facts['local']['fact_5'] == 'fact_5'

# Generated at 2022-06-17 02:22:16.819209
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:22:23.480021
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = AnsibleModule(
        argument_spec=dict(
            fact_path=dict(type='str', default='/etc/ansible/facts.d'),
        ),
    )
    local_facts = LocalFactCollector().collect(module=module)
    assert local_facts['local'] == {}

# Generated at 2022-06-17 02:22:27.412759
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # TODO: implement unit test
    pass

# Generated at 2022-06-17 02:22:31.749091
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = AnsibleModule(argument_spec={'fact_path': {'type': 'str', 'required': True}})
    local_fact_collector = LocalFactCollector()
    local_facts = local_fact_collector.collect(module=module)
    assert local_facts['local'] == {'test': {'test': 'test'}}

# Generated at 2022-06-17 02:22:37.310804
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = AnsibleModule(argument_spec={'fact_path': {'type': 'str', 'required': False}})
    module.params = {'fact_path': '/tmp/facts'}

    # Create a mock file
    fact_file = '/tmp/facts/test.fact'
    with open(fact_file, 'w') as f:
        f.write('{"test": "test"}')

    # Create a LocalFactCollector
    lfc = LocalFactCollector()

    # Test the collect method
    assert lfc.collect(module=module) == {'local': {'test': {'test': 'test'}}}

    # Remove the mock file
    os.remove(fact_file)


# Generated at 2022-06-17 02:22:44.027505
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = AnsibleModule(
        argument_spec=dict(
            fact_path=dict(required=True, type='str'),
        ),
        supports_check_mode=True
    )
    local_fact_collector = LocalFactCollector()
    local_facts = local_fact_collector.collect(module)
    assert local_facts['local']['test_fact'] == 'test_fact_value'

# Generated at 2022-06-17 02:22:53.285184
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = type('', (), {})()
    module.params = {'fact_path': 'test/unit/module_utils/facts/local/test_fact_path'}
    module.run_command = lambda x: (0, '', '')
    module.warn = lambda x: None

    # Create a mock collector
    collector = LocalFactCollector()

    # Call the collect method
    facts = collector.collect(module)

    # Assert that the facts are correct

# Generated at 2022-06-17 02:23:01.883152
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            fact_path=dict(type='str', default='/etc/ansible/facts.d'),
        ),
        supports_check_mode=True,
    )

    # create a collector
    collector = Collector(module=module)

    # create a local fact collector
    local_fact_collector = LocalFactCollector(module=module)

    # add the local fact collector to the collector
    collector.add_collector(local_fact_collector)

    # collect facts
    facts = collector.collect(module=module)

    # assert that the local fact collector is in the facts
    assert 'local' in facts

# Generated at 2022-06-17 02:25:45.141808
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:25:48.226219
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:25:53.060581
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:25:55.298590
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:25:56.575337
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:26:01.849799
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:26:04.825046
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-17 02:26:08.838186
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-17 02:26:14.302121
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a mock module
    module = type('module', (object,), {
        'params': {
            'fact_path': '/tmp/facts',
        },
        'run_command': lambda self, cmd: (0, '', ''),
    })()

    # Create a mock fact path
    fact_path = '/tmp/facts'
    os.makedirs(fact_path)

    # Create a mock fact file
    fact_file = os.path.join(fact_path, 'test.fact')
    with open(fact_file, 'w') as f:
        f.write('{"test": "test"}')

    # Create a mock executable fact file
    fact_file = os.path.join(fact_path, 'test_exec.fact')

# Generated at 2022-06-17 02:26:22.249056
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import os
    import tempfile
    import shutil
    import json
    import stat

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import LocalFactCollector

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary ansible.cfg
    fd, path = tempfile.mkstemp()
    with os.fdopen(fd, 'wb') as f:
        f.write(to_bytes(
            '[defaults]\n'
            'fact_path = %s\n' % tmpdir
        ))

    # Create a temporary fact file