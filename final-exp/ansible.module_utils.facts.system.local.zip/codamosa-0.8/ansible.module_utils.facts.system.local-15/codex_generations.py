

# Generated at 2022-06-11 04:49:25.039494
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local = LocalFactCollector()
    assert local.name == 'local'

# Generated at 2022-06-11 04:49:26.618660
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    lc = LocalFactCollector()
    assert lc.name == 'local'

# Generated at 2022-06-11 04:49:36.545803
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.local_collector import LocalFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_text

    local_fact_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_facts')
    module = basic.AnsibleModule(
        argument_spec={'fact_path': dict(type='path', required=True)},
        supports_check_mode=True
    )
    module.params = ImmutableD

# Generated at 2022-06-11 04:49:47.131998
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    '''
    Ansible facts.local test.
    '''
    import ansible.module_utils.facts.collector as facts_collector
    from ansible.module_utils.facts import ModuleConfig
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Test BaseFactCollector by creating a mock
    class BaseFactCollector(BaseFactCollector):
        _fact_ids = set()
        name = 'test_fact'
        def collect(self, module_name=None, collected_facts=None):
            return { self.name: True }
    # Test LocalFactCollector class
    def test_collector(module, collected_facts=None):
        return BaseFactCollector().collect(module, collected_facts)

    # Test collect method

# Generated at 2022-06-11 04:49:53.160123
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fact_path = '/etc/ansible/facts.d'
    fact_path_empty = '/tmp/facts.d'
    module = None
    fact = LocalFactCollector(module)
    fact_path = fact_path_empty
    assert fact.collect(module, fact_path) == {'local': {}}
    fact_path = '/etc/ansible/facts.d/paths.fact'
    assert fact.collect(module, fact_path) is not None

# Generated at 2022-06-11 04:49:55.560585
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector().name == 'local'
    assert LocalFactCollector()._fact_ids == set()


# Generated at 2022-06-11 04:49:58.493192
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_facts_collector = LocalFactCollector()
    assert local_facts_collector.name == 'local'
    assert isinstance(local_facts_collector._fact_ids, set)

# Generated at 2022-06-11 04:50:01.417608
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-11 04:50:10.964855
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import Collector
    import ansible.module_utils.facts.collectors
    ansible.module_utils.facts.collectors.register(LocalFactCollector())
    # Create the objects needed to run the unit test
    module = FakeModule()
    collector = Collector()
    local_facts = {}
    local_facts['local'] = {}

    # Check result when fact_path does not exist
    module.params = dict(fact_path="./wrong_path")
    assert collector.collect(module=module, collected_facts=local_facts) == local_facts
    # Check result when fact_path is empty
    module.params = dict(fact_path="")

# Generated at 2022-06-11 04:50:12.207341
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.__name__ == 'LocalFactCollector'

# Generated at 2022-06-11 04:50:28.954214
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import os
    from ansible.module_utils.facts.collectors.local import LocalFactCollector

    temp_path = os.path.join(os.path.dirname(__file__), 'temp')
    if not os.path.isdir(temp_path):
        os.makedirs(temp_path)

    fact_base = "some_fact"
    fact = {'fact_base': {fact_base: 'some_value'}}
    fact_file = os.path.join(temp_path, fact_base + '.fact')
    with open(fact_file, 'wb') as f:
        f.write(json.dumps(fact, ensure_ascii=False))

    collecter = LocalFactCollector()

# Generated at 2022-06-11 04:50:31.184068
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    l = LocalFactCollector()
    assert l.name == 'local'
    assert l._fact_ids == set()
    assert l.has_facts()

# Generated at 2022-06-11 04:50:40.558282
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    class FactModuleFake(object):
        def __init__(self):
            self.params = {}
            self._warnings = []

        def warn(self, msg):
            self._warnings.append(msg)

    fact_module = FactModuleFake()
    collector = LocalFactCollector()

    # create fake fact_path and some files
    fact_path = 'AA/BB/CC'
    file1 = 'AA/BB/CC/file1.fact'
    file2 = 'AA/BB/CC/file2.fact'
    file3 = 'AA/BB/CC/file3.fact'
    file4 = 'AA/BB/CC/file4.fact'
    os.makedirs(fact_path)
    with open(file1, 'wb') as f:
        f.write('file1')


# Generated at 2022-06-11 04:50:42.316975
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-11 04:50:44.773698
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-11 04:50:53.817715
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    class FakeModule(object):
        def __init__(self, params, run_command_result=(0, '', ''), run_command_exception=False):
            self.params = params
            self.run_command_result = run_command_result
            self.run_command_exception = run_command_exception

        def run_command(self, cmd):
            if self.run_command_exception:
                raise Exception('Fake exception')
            return self.run_command_result

        def warn(self, warning_string):
            pass

    class FakeJsonFile(object):
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content

    import tempfile
    fact_path = tempfile.mkdtemp()
    fake_module = Fake

# Generated at 2022-06-11 04:50:54.724000
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'

# Generated at 2022-06-11 04:51:03.999078
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    config_data = {'fact_path': './test/unit/module_utils/facts/test_collection'}
    local_facts = LocalFactCollector().collect(config_data)
    res = local_facts.get('local', None)
    assert res is not None
    assert (res.get('subdir_fact') == 'subdir fact content')
    assert (res.get('subdir_executable_fact') == 'subdir executable fact content')
    assert (res.get('subdir_executable_fact_error') == 'subdir executable fact error content')
    assert (res.get('subdir_executable_fact_passed') == 'subdir executable fact passed')
    assert (res.get('subdir_executable_json_fact') == 'subdir executable json fact content')

# Generated at 2022-06-11 04:51:05.792650
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-11 04:51:15.980086
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import sys
    if sys.version_info[0] == 2:
        import mock
        from ansible.module_utils import facts
        from ansible.module_utils.facts import collector
        from ansible.module_utils.basic import AnsibleModule
        from ansible.module_utils.facts.collector import BaseFactCollector
        from ansible.module_utils.facts.collectors.local import LocalFactCollector

        assert sys.version_info[0] == 2
        mock_module = mock.Mock(spec=AnsibleModule)
        mock_facts = mock.Mock(spec=collector.Facts)
        mock_base = mock.Mock(spec=BaseFactCollector)
        test_obj = LocalFactCollector()
        test_obj.collect(mock_module, mock_facts)
        mock

# Generated at 2022-06-11 04:51:36.781045
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    facts_info = {
        'local': {
            'facts_info': {
                'facts_info': {
                    'facts_info': {
                        'facts_info': {
                            'facts_info': {
                                'facts_info': {
                                    'facts_info': {
                                        'facts_info': {
                                            'facts_info': {
                                                'facts_info': {
                                                    'facts_info': {
                                                        'facts_info': {
                                                            'facts_info': {'facts_info': {'facts_info': 'facts_info'}}}}}}}}}}}}}}}}

    test_collector = LocalFactCollector(None)
    test_collector.collect(None, facts_info)

# Generated at 2022-06-11 04:51:39.156749
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'
    assert isinstance(LocalFactCollector._fact_ids, set)
    assert callable(LocalFactCollector.collect)

# Generated at 2022-06-11 04:51:47.379170
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Arrange
    from ansible.module_utils.facts.utils import FactsInitError
    module = MagicMock()
    module.configure_mock(params={'fact_path':'/tmp/ansible_local_facts'})
    module.run_command = MagicMock(return_value=(0,'success','demo text'))
    module.warn = MagicMock()
    local_facts = {}
    local_facts['local'] = {}

    # Act
    test_local_fact_collector = LocalFactCollector()
    result = test_local_fact_collector.collect(module=module, collected_facts=local_facts)

    # Assert
    assert result == local_facts
    module.warn.assert_called_once()
    module.run_command.assert_called_once()

# Unit

# Generated at 2022-06-11 04:51:49.077229
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
  assert LocalFactCollector.name == 'local'
  assert 'local' in LocalFactCollector._fact_ids


# Generated at 2022-06-11 04:51:51.496871
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-11 04:51:59.155930
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts import ModuleStub
    import ansible.module_utils.facts.collector as collector
    import os
    import tempfile
    import shutil
    local_fact_collector = collector.LocalFactCollector()
    assert local_fact_collector.name == 'local'
    # Check: Not ModuleStub passed, no path is specified, collected_facts is None
    col_facts = local_fact_collector.collect()
    assert col_facts == {'local': {}}
    # Check: ModuleStub and path to fact file passed, and collected_facts is None
    tmp_dir = tempfile.mkdtemp()
    tmp_file = os.path.join(tmp_dir, 'a_fact.fact')
    with open(tmp_file, 'w') as f:
        f

# Generated at 2022-06-11 04:52:07.947608
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()

    def fake_ansible_module(**kwargs):
        m = FakeAnsibleModule(**kwargs)
        m.fact_path = ''
        return m
    module = fake_ansible_module()
    facts = local_fact_collector.collect(module, {})
    expected = {'local': {}}
    assert facts == expected, "Expected facts to be %s but were %s" % (expected, facts)

    module = fake_ansible_module()
    del module.fact_path
    facts = local_fact_collector.collect(module, {})
    expected = {'local': {}}
    assert facts == expected, "Expected facts to be %s but were %s" % (expected, facts)

    module = fake_ansible_

# Generated at 2022-06-11 04:52:10.411210
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-11 04:52:13.054000
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-11 04:52:22.188622
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    lfc = LocalFactCollector()
    assert lfc.collect() == {'local': {}}
    assert lfc.collect(module=None) == {'local': {}}
    assert lfc.collect(module=True) == {'local': {}}
    assert lfc.collect(module=[]) == {'local': {}}
    assert lfc.collect(module='ok') == {'local': {}}
    assert lfc.collect(module=['ok']) == {'local': {}}
    assert lfc.collect(module=('ok',)) == {'local': {}}
    assert lfc.collect(module={'ok': True}) == {'local': {}}
    assert lfc.collect(module={'params': {'fact_path': None}}) == {'local': {}}

# Generated at 2022-06-11 04:52:48.626737
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert 'local' in local_fact_collector._fact_ids

# Generated at 2022-06-11 04:52:50.370962
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    collector = LocalFactCollector()
    assert collector.name == 'local'
    assert len(collector._fact_ids) == 0


# Generated at 2022-06-11 04:52:56.559514
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts.utils import get_file_content

    test_module = FactsCollector.get_module_args()
    test_module['fact_path'] = "./test/unit/module_utils/facts/fixtures/local"

    collector = LocalFactCollector()
    result = collector.collect(module=test_module)

# Generated at 2022-06-11 04:53:01.602837
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    fake_module = type('', (), {})
    fake_module.params = {'fact_path': os.getcwd()}
    fake_module.warn = lambda message: print(message)
    fake_module.run_command = lambda cmd: (0, cmd, '')
    collector = LocalFactCollector(module=fake_module)
    result = collector.collect()
    # Default test to pass
    assert result is not None

# Generated at 2022-06-11 04:53:10.681882
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Get the module object from the import path
    from ansible.module_utils.facts.collectors import local

    # Create the module object
    runner_args = {
        '_ansible_version': '2.9.0',
        '_ansible_module_name': 'test_local',
        '_ansible_module_sig': 'some_module_signature',
        '_ansible_module_args': {
            'fact_path': '/tmp/test_facts',
        },
        '_ansible_module_complex_args': {},
    }
    module = AnsibleModule(**runner_args)

    # Create the fact path
    fact_path = '/tmp/test_facts'
    os.makedirs(fact_path, mode=0o700)

    # Create the fact file that should

# Generated at 2022-06-11 04:53:13.120127
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Check required arguments and object attributes are assigned correctly.
    obj = LocalFactCollector()
    assert obj.name == 'local'
    assert obj._fact_ids == set()



# Generated at 2022-06-11 04:53:15.958323
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    """Test class constructor for class LocalFactCollector"""

    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-11 04:53:17.371277
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-11 04:53:25.347704
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    # Verify that facts are collected when there is no fact_path
    lfc = LocalFactCollector()
    f = lfc.collect(None, None)
    assert f == {}

    # Verify that facts are collected when there is a fact_path and a fact file
    lfc = LocalFactCollector()
    f = lfc.collect({'params': {'fact_path': './test/unit/module_utils/facts/collectors/local_facts'}}, None)
    assert f['local']['local_fact_1'] == {'local_fact_1': 'local_fact_value_1'}

    # Verify that local facts are collected when there is a fact_path and multiple fact files
    lfc = LocalFactCollector()

# Generated at 2022-06-11 04:53:31.695174
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a temporary module
    module = FakeModule()
    module.params['fact_path'] = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', 'unit', 'modules', 'test_data')
    
    # Create collector
    collector = LocalFactCollector()
    # Collect facts
    facts = collector.collect(module=module)
    # Check facts
    assert facts['local'] == {
        'test_fact.fact': {
            'test_section': {
                'test_option': 'test_value'
            }
        }
    }


# Generated at 2022-06-11 04:54:37.628299
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # result = LocalFactCollector().collect()
    # assert result == {'local': {}}
    pass

# Generated at 2022-06-11 04:54:40.996613
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """Unit test for the method collect of class LocalFactCollector.

    """
    lfc = LocalFactCollector()
    local_facts = lfc.collect()
    assert isinstance(local_facts, dict)
    assert isinstance(local_facts['local'], dict)

# Generated at 2022-06-11 04:54:48.928780
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create an ansible module
    class Module():

        def __init__(self):
            pass

        def run_command(self, cmd):
            if cmd == './test.fact':
                return 0, '{"a": "b"}', None
            elif cmd == './test2.fact':
                return 1, None, None
            elif cmd == './test3.fact':
                return 0, 'test3', None
            elif cmd == './test4.fact':
                return 1, None, None
            elif cmd == './test5.fact':
                raise Exception()
            else:
                return 1, None, None

        def warn(self, msg):
            pass

    # Create a local fact collector
    collector = LocalFactCollector()

    # Create a result object
    result = {}

    #

# Generated at 2022-06-11 04:54:49.413378
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
  LocalFactCollector()

# Generated at 2022-06-11 04:54:51.046334
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    collector = LocalFactCollector()

    assert collector.name is not None
    assert collector._fact_ids is not None


# Generated at 2022-06-11 04:55:00.514004
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import mock
    import sys
    import tempfile

    if sys.version_info[0] == 2:
        import imp
        # we need get_loader to read fact_path
        imp.reload(__import__('ansible.utils.module_docs_fragments.get_loader'))


# Generated at 2022-06-11 04:55:02.592594
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local', 'local_local_collector.name should return local'

# Generated at 2022-06-11 04:55:03.389586
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    assert False, "unit test not implemented"

# Generated at 2022-06-11 04:55:11.771501
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    current_dir = os.path.dirname(os.path.abspath(__file__))
    fact_path = os.path.join(current_dir, 'test_fact_path')
    local_facts = local_fact_collector.collect(fact_path=fact_path)
    assert set(local_facts['local'].keys()) == {'test_fact_1', 'test_fact_2',
                                                'test_fact_3', 'test_fact_5',
                                                'test_fact_6', 'test_fact_7'}
    assert isinstance(local_facts['local']['test_fact_1'], int)
    assert local_facts['local']['test_fact_1'] == 1

# Generated at 2022-06-11 04:55:18.201957
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import tempfile
    import pytest

    # create a temporary directory to store the fact files
    fact_path = tempfile.mkdtemp()

    # create a temporary directory to store the module
    module_path = tempfile.mkdtemp()

    # create an executable fact file
    fact_name = 'executable.fact'
    fact_content = '#!/bin/sh\n[ $# -eq 0 ] && output="OK" || output=$1'
    fact_file_content = {
        fact_name: fact_content
    }
    fact_file_content = create_local_fact_files(fact_path, fact_file_content)

    # create a json fact file
    fact_name = 'json.fact'
    fact_content = {
        "fact1": "value1"
    }
    fact_

# Generated at 2022-06-11 04:58:09.183281
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'
    assert LocalFactCollector._fact_ids == set()


# Generated at 2022-06-11 04:58:10.849821
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

    fact_collector = LocalFactCollector()

    assert fact_collector.name == 'local'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-11 04:58:17.983796
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # mock module
    # AnsibleModule with "run_command" method mocked
    class MockAnsibleModule:
        class ReturnCode:
            OK = 0
            FAILED = 1

        def __init__(self, params):
            self.params = params

        def run_command(self, command, *args, **kwargs):
            # return different value for each command
            # except if the command is "echo -n 100", which returns '100' always
            if command == 'echo -n 100':
                return self.ReturnCode.OK, '100', ''
            elif command == 'echo -n 200':
                return self.ReturnCode.OK, '200', ''
            else:
                return self.ReturnCode.FAILED, 'command failed', ''

    module = MockAnsibleModule({})
    facts = LocalFact

# Generated at 2022-06-11 04:58:20.712633
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    """
    Tests the constructor of the class LocalFactCollector
    """
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-11 04:58:27.572134
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import os.path
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts import FactCache
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.plugins.hash_vals import HashValFactCollector
    from ansible.module_utils.facts.plugins.rabbitmq import RabbitMQFactCollector
    from ansible.module_utils.facts.plugins.service_mgr import ServiceMgrFactCollector
    from ansible.module_utils.facts.plugins.system_profiler import SystemProfilerFactCollector
    from ansible.module_utils.facts.system.system import SystemFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector

# Generated at 2022-06-11 04:58:31.588676
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    fact_path = 'test/units/module_utils/facts/local/'
    fact_file = fact_path + 'test_fact.fact'
    with open(fact_file, 'wb') as f:
        f.write(b'''
[test_fact]
key=value
''')
    os.chmod(fact_file, 0o755)

    module = MockModule()
    module.params = {'fact_path': fact_path}
    assert len(LocalFactCollector().collect(module)['local'].values()) == 1

    os.remove(fact_file)


# Generated at 2022-06-11 04:58:32.674035
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """
    No unit test availble for this method.
    """
    pass

# Generated at 2022-06-11 04:58:36.523110
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = {}
    module['params'] = {}
    module['params']['fact_path'] = "../../test/unit/module_utils/facts/test_data/local"
    local_facts = LocalFactCollector().collect(module)
    assert local_facts['local']['test_fact']['test_sect']['test_opt'] == "test_val"

# Generated at 2022-06-11 04:58:40.544968
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """
    Unit test for method collect of class LocalFactCollector
    """
    base_facts = {
        "some": "fact"
    }
    module = AnsibleModule(argument_spec={})
    lfc = LocalFactCollector()
    local_facts = lfc.collect(module=module, collected_facts=base_facts)
    local_facts_expected = {
        "local": {
        }
    }
    assert local_facts == local_facts_expected

# Generated at 2022-06-11 04:58:46.699571
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFactCollector
    import collections
    import os
    import stat
    import tempfile
    import textwrap

    module = collections.namedtuple('Module', ['run_command', 'warn', 'params'])
    fact_path = tempfile.mkdtemp()

    class TestModule(module):
        def run_command(self, cmd):
            if cmd == fact_path+'/executable.fact':
                return 0, '{"result": "executed"}', ''
            else:
                return 1, '', 'fact was not executable'

    def test_module():
        return TestModule()
