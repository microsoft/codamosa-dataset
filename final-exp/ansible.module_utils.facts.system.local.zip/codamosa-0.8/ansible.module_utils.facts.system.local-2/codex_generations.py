

# Generated at 2022-06-11 04:49:24.424339
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert len(local_fact_collector._fact_ids) == 0

# Generated at 2022-06-11 04:49:27.281312
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Create and initialize an instance of LocalFactCollector
    local_collector = LocalFactCollector()

    # Check if the name of the instance of LocalFactCollector is 'local'
    assert local_collector.name == 'local'


# Generated at 2022-06-11 04:49:37.224835
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # No fact_path to reach
    local_fact_collector = LocalFactCollector()
    local_facts = local_fact_collector.collect()
    assert local_facts == {}

    # Fact_path without any fact file
    local_fact_collector = LocalFactCollector(params={'fact_path': './'})
    local_facts = local_fact_collector.collect()
    assert local_facts == {}

    # Fact_path to reach
    local_fact_collector = LocalFactCollector(params={'fact_path': '../utils/facts/collection/tests/fixtures'})
    local_facts = local_fact_collector.collect()

# Generated at 2022-06-11 04:49:38.145927
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
  assert(LocalFactCollector().name == 'local')

# Generated at 2022-06-11 04:49:48.863405
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

    test_fact_path = "./test/test_local_facts"

    # Construct a LocalFactCollector object
    local_fact_collector = LocalFactCollector()

    # assert that an object is created
    assert local_fact_collector is not None

    # assert that the object has the correct attributes
    assert local_fact_collector.name == "local"
    assert local_fact_collector._fact_ids == set()

    # assert the local_fact_collector collects the facts from the test fact files

    test_facts = local_fact_collector.collect(None, None, fact_path=test_fact_path)

    assert test_facts['local']['test_local_fact_basic_ini'] == {'section': {'key': 'value'}}

# Generated at 2022-06-11 04:49:51.017167
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    lfc = LocalFactCollector()

    assert lfc.name == 'local'
    assert lfc._fact_ids == set()

# Generated at 2022-06-11 04:49:54.590623
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    """
    Test the constructor of the LocalFactCollector class
    """
    from ansible.module_utils.facts.collector import Collector

    local_fact_collector = LocalFactCollector()
    assert isinstance(local_fact_collector, Collector) == True


# Generated at 2022-06-11 04:49:55.253901
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    LocalFactCollector()

# Generated at 2022-06-11 04:50:05.261591
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Mock module
    class MockModule(object):
        def warn(self, msg):
            print("WARN: %s" % msg)

        def run_command(self, cmd):
            return 0, "", ""

    import tempfile
    import os

    def cleanup_file(path):
        try:
            os.unlink(path)
        except:
            pass

    temp_dir = tempfile.mkdtemp()
    test_file_1 = os.path.join(temp_dir, "test_file_1.fact")
    test_file_2 = os.path.join(temp_dir, "test_file_2.fact")
    test_file_3 = os.path.join(temp_dir, "test_file_3.fact")

# Generated at 2022-06-11 04:50:14.560166
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = {
        "params": {
            "fact_path": 'test/fixtures/facts/local'
        },
        "warn": lambda *args, **kwargs: None,
        "run_command": lambda *args, **kwargs: (0, "test_value", ""),
        "get_file_content": lambda *args, **kwargs: "test_value"
    }


# Generated at 2022-06-11 04:50:36.162760
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import MockModule
    from ansible.module_utils import basic

    local = LocalFactCollector()

    # load metadata of unit test to MockModule
    fp = os.path.join(os.path.dirname(__file__), 'unit_test.meta')
    facts = basic.AnsibleModule(argument_spec={}, supports_check_mode=True).load_file_common_arguments(fp)

    # run method collect of LocalFactCollector
    result = local.collect(MockModule(facts['ansible_facts']))

    # check results
    assert('local' in result)
    assert(type(result) is dict)
    assert(type(result['local']) is dict)
    assert(len(result['local']) == 2)

# Generated at 2022-06-11 04:50:38.747639
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-11 04:50:40.630959
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()

    assert local_fact_collector

# Generated at 2022-06-11 04:50:42.010340
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local = LocalFactCollector()
    assert local.name == 'local'

# Generated at 2022-06-11 04:50:43.850422
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    
    local_facts = LocalFactCollector().collect()
    assert isinstance(local_facts, dict)

# Generated at 2022-06-11 04:50:46.103968
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_obj = LocalFactCollector()
    assert test_obj.name == 'local'
    assert isinstance(test_obj._fact_ids, set)


# Generated at 2022-06-11 04:50:47.726336
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-11 04:50:49.060616
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
        local_facts = LocalFactCollector().collect()
        assert local_facts

# Generated at 2022-06-11 04:50:51.775165
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-11 04:50:52.658864
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
  
    assert isinstance(LocalFactCollector, object)

# Generated at 2022-06-11 04:51:25.852849
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Test when fact_path is invalid path
    mock_module = Mock(params={'fact_path':'/abc'})
    lfc = LocalFactCollector()
    lfc.collect(mock_module)

    # Test when fact_path is valid but fact file is not present
    mock_module = Mock(params={'fact_path':'/etc'})
    lfc = LocalFactCollector()
    lfc.collect(mock_module)

    # Test when fact_path is valid, fact file is not executable and not a .fact file
    mock_module = Mock(params={'fact_path':'/etc'})
    file = open('/etc/hosts.fact', 'w')
    file.write('a=b')
    file.close()
    lfc = LocalFactCollector()

# Generated at 2022-06-11 04:51:34.267926
# Unit test for method collect of class LocalFactCollector

# Generated at 2022-06-11 04:51:34.843385
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass

# Generated at 2022-06-11 04:51:36.929017
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    local_fact_collector.collect()

if __name__ == '__main__':
    test_LocalFactCollector()

# Generated at 2022-06-11 04:51:38.997247
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fc = LocalFactCollector()
    assert fc.name == 'local'
    assert fc._fact_ids == set()

# Generated at 2022-06-11 04:51:41.254579
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'
    assert LocalFactCollector._fact_ids == set()


# Generated at 2022-06-11 04:51:43.084957
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    result = LocalFactCollector().collect()
    assert result['local']['test_fact'] == 'test_fact'



# Generated at 2022-06-11 04:51:48.401304
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts

    module = ansible.module_utils.facts
    module.AnsibleModule = object()
    module.AnsibleModule.params = {}

    collector = ansible.module_utils.facts.LocalFactCollector()
    facts = collector.collect(module)
    assert (facts['local']['localhost'] == "Failed to convert (.fact_path/localhost.fact) to JSON: Expecting value: line 1 column 1 (char 0)")

# Generated at 2022-06-11 04:51:50.363610
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = None
    collected_facts = None
    collector = LocalFactCollector()
    result = collector.collect(module, collected_facts)
    assert(isinstance(result, dict))

# Generated at 2022-06-11 04:51:53.149326
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-11 04:52:29.056355
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts import ModuleDataCollector

    module_data_collector_obj = ModuleDataCollector()
    local_fact_collector_obj = LocalFactCollector(module_data_collector_obj)
    module = Mock()

    module.params = {}
    module.params['fact_path'] = './ansible/facts/test/'

    output = local_fact_collector_obj.collect(module)

# Generated at 2022-06-11 04:52:39.991630
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import LocalFactCollector

    module = None
    collected_facts = None

    def get_module_params():
        return dict(fact_path='./test/unittests/module_utils/facts/collector/test_local/')

    module = MockModuleWithParams(get_module_params())
    assert module is not None

    local_facts_collector = LocalFactCollector(module)
    assert local_facts_collector is not None

    # we have a class inheriting from BaseFactCollector
    assert isinstance(local_facts_collector, BaseFactCollector)

    # name property is accessible
    assert local_facts_collector.name == 'local'

    # collect method

# Generated at 2022-06-11 04:52:42.544196
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    lfc = LocalFactCollector()
    assert lfc.name == 'local'
    assert isinstance(lfc._fact_ids, set)

# Generated at 2022-06-11 04:52:51.518270
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fact_path = 'test/units/module_utils/facts/local'

    # create an instance
    local_fact_collector = LocalFactCollector()

    # execute collect
    local_facts = local_fact_collector.collect(fact_path=fact_path)

    # verify local facts
    assert local_facts == {'local': {'fact_1': 'test_fact_1',
                                     'fact_2': 'test_fact_2',
                                     'fact_3': {'sect_1': {'opt_1': 'val_1',
                                                           'opt_2': 'val_2'}}}}

    # execute collect
    local_facts = local_fact_collector.collect(fact_path='invalid_path')

    # verify local facts

# Generated at 2022-06-11 04:52:53.725316
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    LocalFactCollector.init()
    local_collector = LocalFactCollector.instance
    collected_facts = local_collector.collect()
    assert collected_facts is not None
    assert 'local' in collected_facts

# Generated at 2022-06-11 04:52:56.253769
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = AnsibleModule(argument_spec={'fact_path': {'type': 'str'}, 'version': {'type': 'int'}})
    local_facts = LocalFactCollector()
    result = local_facts.collect(module=module)
    assert result == {'local': {'fact1': {'config1': 'value1'}}}

# Generated at 2022-06-11 04:53:05.217290
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import AnsibleRunner
    from io import BytesIO
    import json

    # creating objects
    m = AnsibleRunner(module=None)
    l = LocalFactCollector()

    # fake os module
    class FakeOsModule:
        def __init__(self):
            self.error = None
            self.output = None

        def stat(self, filename):
            m = FakeStatModule()
            if filename == '/path/to/fact_path/json.fact':
                m.ST_MODE = stat.S_IXUSR
                m.ST_MODE = m.ST_MODE | stat.S_IRUSR

# Generated at 2022-06-11 04:53:13.951240
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    def run_command(cmd):
        assert cmd == '/tmp/test/command.fact'
        return 0, '{ "fact": "value" }', ''

    # Test default case
    module = MockModule(params={})
    local_facts = LocalFactCollector(module).collect()
    assert local_facts == {'local': {}}

    # Test case where the fact_path doesn't exist
    module = MockModule(params={'fact_path': '/does_not_exist'})
    local_facts = LocalFactCollector(module).collect()
    assert local_facts == {'local': {}}

    # Test case where there are no fact files in the fact_path
    module = MockModule(params={'fact_path': '/tmp/test'})
    local_facts = LocalFactCollector(module).collect()

# Generated at 2022-06-11 04:53:16.133745
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    collector = LocalFactCollector()
    facts = collector.collect(collected_facts=None)
    print(facts)
    assert facts is not None
    assert len(facts) == 1

# Generated at 2022-06-11 04:53:17.762074
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local = LocalFactCollector()
    assert local.name == 'local'
    assert len(local._fact_ids) == 0

# Generated at 2022-06-11 04:54:26.225364
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    localcollector = LocalFactCollector()
    localcollector.collect()

# Generated at 2022-06-11 04:54:29.412334
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    """ Unit test for constructor of class LocalFactCollector
    """
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-11 04:54:39.847309
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    import json
    import tempfile

    a_json_fact = '{"ansible_local":{"a_fact":{ "branch": "devel", "version": "0.3"}}}'
    local_facts_path = tempfile.mkdtemp()
    json_fact_file_path = os.path.join(local_facts_path, 'fake_fact.fact')
    with open(json_fact_file_path, 'w') as f:
        f.write(json.dumps(a_json_fact))

    a_bad_json_fact = '{"ansible_local":{"a_fact":{ "branch": "devel", "version": "0.3}'
    bad_json_fact_file_path = os.path.join(local_facts_path, 'bad_fake_fact.fact')


# Generated at 2022-06-11 04:54:40.446699
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass

# Generated at 2022-06-11 04:54:42.673212
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    myFactCollector = LocalFactCollector()
    assert myFactCollector.name == 'local'
    assert myFactCollector.collect() == {'local': {}}

# Generated at 2022-06-11 04:54:44.363535
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fact_collector = LocalFactCollector()
    assert fact_collector.name is not None
    assert fact_collector.name == 'local'

# Generated at 2022-06-11 04:54:49.333342
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """
    test_LocalFactCollector_collect
    """
    class_names = ('ansible.module_utils.facts.local.LocalFactCollector',
                   'ansible.module_utils.facts.collector.BaseFactCollector')
    for name in class_names:
        module = imp.load_source(name, '%s.py' % name)
        my_local_fact_collector = module.LocalFactCollector()
        facts_dict = my_local_fact_collector.collect()


# Generated at 2022-06-11 04:54:58.058416
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_collector = LocalFactCollector(None)
    collected_facts = local_collector.collect({'params': {'fact_path': './'}})

# Generated at 2022-06-11 04:55:00.347829
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert(local_fact_collector.name == 'local')

# Generated at 2022-06-11 04:55:03.012048
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    obj = LocalFactCollector()
    assert(obj.name == 'local')
    assert(obj.priority == 50)
    assert(obj._fact_ids is not None)
    assert(len(obj._fact_ids) == 0)

# Generated at 2022-06-11 04:57:53.628652
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    instance = LocalFactCollector()
    assert isinstance(instance, LocalFactCollector)

# Generated at 2022-06-11 04:57:54.713260
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fct = LocalFactCollector()
    assert(fct.name == 'local')

# Generated at 2022-06-11 04:57:56.800157
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    f = LocalFactCollector()
    assert f.name == 'local'
    assert len(f._fact_ids) == 0

# Unit test to collect facts

# Generated at 2022-06-11 04:57:58.454679
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert getattr(LocalFactCollector, 'name', None) == 'local'
    assert getattr(LocalFactCollector, '_fact_ids', None) == set()

# Generated at 2022-06-11 04:58:01.245843
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Constructor of class LocalFactCollector does not take any arguments
    assert LocalFactCollector()
    # Constructor of class LocalFactCollector does not take any keyword arguments
    assert LocalFactCollector(nonexistent='foo')

# Generated at 2022-06-11 04:58:03.019192
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fact_collector = LocalFactCollector()
    assert fact_collector.name == 'local'
    assert not fact_collector._fact_ids



# Generated at 2022-06-11 04:58:10.677974
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    """Unit test for constructor of class LocalFactCollector"""

    # Create a fact_path directory with dummy, executable and broken fact files
    tmpdir = '/tmp/ansible_local_facts'
    os.mkdir(tmpdir)
    fact_file = 'local'
    fact_content = {'a': 1, 'b': 2}
    broken_fact_content = {'a': 1, 'b': 2}
    with open('%s/%s' % (tmpdir, fact_file), 'w') as f:
        f.write(json.dumps(fact_content))
    with open('%s/broken_%s' % (tmpdir, fact_file), 'w') as f:
        f.write('this is not valid json')

# Generated at 2022-06-11 04:58:17.825709
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    test_path = './unit/modules/test/unit/lib/ansible/module_utils/facts/factsd/'
    test_fact_path = './unit/modules/test/unit/lib/ansible/module_utils/facts/factsd/test/'
    truth = {'local': {'test_fact': {'first_section': {'first_key': 'first_value',
                                                       'second_key': 'second_value'},
                        'second_section': {'first_key': 'first_value',
                                           'second_key': 'second_value'}},
             'test_fact_json': {'a': 1,
                                'b': 2}}}

    local_collector = LocalFactCollector(module=None)

# Generated at 2022-06-11 04:58:20.266086
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # create object
    obj = LocalFactCollector()

    # Mock
    module = Mock()
    collected_facts = Mock()

    # test
    result = obj.collect(module, collected_facts)
    assert result is not None

# Generated at 2022-06-11 04:58:25.861699
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    with open('../module_utils/facts/ansible_local.fact', 'w') as f:
        f.write('[local]\n')
        f.write('ansible_local=local')

    try:
        m = AnsibleModule(argument_spec={'fact_path':{'required': True, 'default': '../module_utils/facts'}})
        assert LocalFactCollector().collect(module=m) == {'local': {'ansible_local': 'local'}}
    finally:
        os.remove('../module_utils/facts/ansible_local.fact')