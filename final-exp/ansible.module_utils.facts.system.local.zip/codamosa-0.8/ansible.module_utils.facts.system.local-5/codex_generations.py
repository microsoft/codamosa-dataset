

# Generated at 2022-06-11 04:49:24.760865
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_facts = LocalFactCollector()
    assert local_facts.name == 'local'
    assert local_facts._fact_ids == set()

# Generated at 2022-06-11 04:49:25.356086
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass

# Generated at 2022-06-11 04:49:26.574673
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local = LocalFactCollector()
    assert local.name == 'local'

# Generated at 2022-06-11 04:49:27.962760
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    assert LocalFactCollector().collect() == {'local': {}}

# Generated at 2022-06-11 04:49:31.007435
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-11 04:49:35.827270
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    module = 'file'
    fact_path = '/tmp'
    module_params = {'fact_path': fact_path}

    test_local_fact_collector = LocalFactCollector(module, module_params)
    assert test_local_fact_collector.name == 'local'
    assert test_local_fact_collector._fact_ids == set([])

# Generated at 2022-06-11 04:49:43.521439
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    module = 'module'
    params = {'fact_path': '/home/user/ansible_facts'}
    collected_facts = {}
    local_fact_collector = LocalFactCollector(module=module, params=params, collected_facts=collected_facts)
    assert local_fact_collector.module == module
    assert local_fact_collector.params == params
    assert local_fact_collector.collected_facts == collected_facts
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-11 04:49:45.900048
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    lfc = LocalFactCollector()
    assert lfc.name == 'local'
    assert lfc._fact_ids == set()


# Generated at 2022-06-11 04:49:46.850533
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Static method, no need to test
    pass

# Generated at 2022-06-11 04:49:47.830291
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    assert True


# Generated at 2022-06-11 04:50:03.688312
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    argument_spec = dict(
        fact_path = dict(default = "/etc/ansible/facts.d"),
    )
    module = MagicMock(argument_spec=argument_spec)
    module.params = {}
    local_facts = dict(local = dict())
    local_facts['local']['test1.fact'] = dict(key1 = "value1", key2 = "value2")
    local_facts['local']['test2.fact'] = dict(key3 = "value3")
    local_facts['local']['test3.fact'] = 'testing failure'

    local = LocalFactCollector() 
    local._create_local_fact = lambda x, y: local_facts
    facts = local.collect(module)


# Generated at 2022-06-11 04:50:04.619967
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    LocalFactCollector().collect()

# Generated at 2022-06-11 04:50:07.505731
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    object0 = LocalFactCollector()

    object1 = LocalFactCollector()

    object1.collect()

    object2 = LocalFactCollector()

    object2.collect(module=object0)

# Generated at 2022-06-11 04:50:09.000723
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    x = LocalFactCollector()
    assert x.name == 'local'

# Generated at 2022-06-11 04:50:10.842938
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    localFactCollector = LocalFactCollector()
    assert localFactCollector.name == 'local'

    assert localFactCollector._fact_ids == set()

# Generated at 2022-06-11 04:50:12.371588
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'
    assert isinstance(LocalFactCollector.name, str)

# Generated at 2022-06-11 04:50:15.313756
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Arrange
    module = None
    # Act
    result = LocalFactCollector().collect(module)
    # Assert
    assert result == {'local': {}}


# Generated at 2022-06-11 04:50:24.733136
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Instantiation
    lfc = LocalFactCollector()

    # Get current path
    my_path = os.path.dirname(os.path.realpath(__file__))

    # Get path of test files
    fact_path = os.path.join(my_path, "../../../../test/units/module_utils/facts/collection/local/test_files")

    # Get facts from test files
    local_facts = lfc.collect(fact_path=fact_path)

    # Assert if the fact collection is done correctly
    assert local_facts['local']['fact1'] == {"section1" : {"key1" : "value1"}, "section2" : {"key2" : "value2"}}

# Generated at 2022-06-11 04:50:33.392687
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    class MyModule:
        def __init__(self):
            self.params = {"fact_path": True}

        def run_command(self, cmd):
            return 0, "", ""

    fact = LocalFactCollector()

    # Mock a fact_path
    fact.file_name = "test/ansible_local.fact"
    local_facts = fact.collect(MyModule())

    # Check it contains the expected structure
    assert local_facts['local']
    assert local_facts['local']['ansible_local']

    # No fact_path, no local facts
    local_facts = fact.collect(None)
    assert not local_facts


# Generated at 2022-06-11 04:50:41.826083
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module_mock = MockModule()
    module_mock.params = dict(fact_path='/opt/test/ansible-facts')

    local_fact_collector = LocalFactCollector()
    collected_facts = local_fact_collector.collect(module=module_mock)

    # Assert that local fact script that returns data in ini format is converted to dict
    assert 'ini' in collected_facts['local']
    assert collected_facts['local']['ini']['section']['key'] == 'value'

    # Assert that local fact script that returns data in json format is converted to dict
    assert 'json' in collected_facts['local']
    assert collected_facts['local']['json']['key'] == 'value'


# Generated at 2022-06-11 04:51:01.892633
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = MockModule({'fact_path': '/foo'})
    module.run_command = Mock(return_value=(0, '', ''))
    facts = LocalFactCollector()
    collected_facts = facts.collect(module=module, collected_facts=None)
    assert collected_facts == {'local': {}}
    module = MockModule({'fact_path': '/foo'})
    module.run_command = Mock(return_value=(0, '', ''))
    facts = LocalFactCollector()
    collected_facts = facts.collect(module=module, collected_facts=None)
    assert collected_facts == {'local': {}}
    module = MockModule({'fact_path': '/foo'})
    module.run_command = Mock(return_value=(0, '', ''))
    facts = LocalFactCollector

# Generated at 2022-06-11 04:51:02.825673
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert hasattr(LocalFactCollector, 'name')

# Generated at 2022-06-11 04:51:12.866672
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import os
    import sys
    import types
    import pytest
    import json
    import configparser

    import ansible.module_utils.facts.collector
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.utils import get_file_content

    # code under test
    from ansible.module_utils.facts.local import LocalFactCollector

    # Parameterize tests for each python version
    PYTHON_MAJOR_VERSION = '3' if sys.version_info[0] == 3 else '2'

    # Create test data for this test case

# Generated at 2022-06-11 04:51:14.231847
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.__name__ == 'LocalFactCollector'

# Generated at 2022-06-11 04:51:23.710746
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Initialize the module
    module = AnsibleModule(argument_spec={
        'fact_path': {'type': str, 'required': True},
    })
    # Initialize the LocalFactCollector class
    fact_collector = LocalFactCollector()

    # Insert a fact_path variable with a valid path
    valid_fact_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
    module.params['fact_path'] = valid_fact_path
    # Execute the collect method
    result = fact_collector.collect(module=module)

    assert isinstance(result, dict)
    assert 'local' in result
    assert isinstance(result['local'], dict)



# Generated at 2022-06-11 04:51:32.509130
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collectors import get_collector_instance
    from ansible.module_utils.facts.utils import get_file_content

    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.run_command = MockModule.run_command

        def run_command(self, command):
            rc = 0
            err = ''
            if command.endswith('script2.fact'):
                rc = 1
                err = 'bad script'
            if command.endswith('script3.fact'):
                rc = 1
                err = 'bad script'
            if command.endswith('script4.fact'):
                err = 'script4.fact'
            return rc, '', err


# Generated at 2022-06-11 04:51:38.087040
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module_mock = Mock()
    collect_mock = Mock()
    module_mock.run_command = Mock(return_value=(0, "EXECUTABLE_FILE_OUTPUT", ""))
    module_mock.params = {
        'fact_path': ''
    }
    local_fact_collector = LocalFactCollector()
    local_fact_collector._fact_ids = set()
    local_fact_collector.collect(module=module_mock, collected_facts=collect_mock)


# Generated at 2022-06-11 04:51:40.287683
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # create class instance
    instance = LocalFactCollector()
    assert isinstance(instance, LocalFactCollector)
    assert isinstance(instance, BaseFactCollector)

# Generated at 2022-06-11 04:51:44.047442
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # pylint: disable=unused-argument
    # pylint: disable=redefined-variable-type

    import ansible.module_utils.facts.collector

    # Call collect()
    local_fact_collector = ansible.module_utils.facts.collector.get_collector('local')
    local_fact_collector.collect()

# Generated at 2022-06-11 04:51:45.109119
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    facts = LocalFactCollector()
    assert isinstance(facts, BaseFactCollector)

# Generated at 2022-06-11 04:52:10.347308
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local = LocalFactCollector()
    assert local.name == 'local'

# Generated at 2022-06-11 04:52:14.837908
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    fact_path = os.path.dirname(os.path.realpath(__file__)) + '/data'
    fact_path = fact_path.replace('ansible/module_utils/facts/collector/os', 'test/unit/module_utils/facts/collector')

    LocalFactCollector.collect(fact_path=fact_path)

# Generated at 2022-06-11 04:52:17.435382
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    """This function is to test the constructor of the class LocalFactCollector."""
    local_fact_collector_obj = LocalFactCollector()

    assert local_fact_collector_obj.name == "local"

# Generated at 2022-06-11 04:52:18.925085
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    x = LocalFactCollector()
    assert x.name == 'local'
    assert x._fact_ids == set()

# Generated at 2022-06-11 04:52:26.024767
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def warn(self, msg):
            pass

        def run_command(self, cmd):
            return (0, cmd, '')

    facts = {}

    params = dict(
        fact_path='/tmp',
    )

    module = MockModule(params)
    local = LocalFactCollector()
    local.collect(module, facts)

    assert 'local' in facts
    assert facts['local']['factfile'] == '/tmp/factfile.fact'

# Generated at 2022-06-11 04:52:29.089873
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()

    assert local_fact_collector.name == 'local', 'Test Local Fact Collector constructor: name'
    assert local_fact_collector._fact_ids == set(), 'Test Local Fact Collector constructor: _fact_ids'

# Generated at 2022-06-11 04:52:31.378727
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local = LocalFactCollector()
    # assert that the class variables are set up correctly
    assert local.name == 'local'
    assert local._fact_ids == set()


# Generated at 2022-06-11 04:52:32.738902
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    obj = LocalFactCollector()
    assert obj.name == 'local'

# Generated at 2022-06-11 04:52:35.366711
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-11 04:52:47.151138
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import sys
    import os
    import shutil

    try:
        import ansible.module_utils.facts.system.distribution as distro_test_import
        distro_test_import_present = True
    except ImportError:
        distro_test_import_present = False

    test_dir = 'test_LocalFactCollector_collect'
    test_fact_path = '%s/fact_path' % test_dir

    # create a fake fact_path directory and files
    shutil.rmtree(test_dir, ignore_errors=True)
    os.makedirs(test_fact_path)
    f = open('%s/fact1.fact' % test_fact_path, 'w')
    f.write('{"fact1": "value1", "fact2": "value2"}')
   

# Generated at 2022-06-11 04:53:47.887909
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    pass

# Generated at 2022-06-11 04:53:49.672225
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_facts = LocalFactCollector()
    assert local_facts.name == 'local'
    assert local_facts._fact_ids == set()

# Generated at 2022-06-11 04:53:53.583828
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_facts = {}
    local_facts['local'] = {}
    assert LocalFactCollector().collect(module=None, collected_facts=None) == local_facts

    fact_path = '/tmp/factpath'
    fact_dict = {}
    fact_dict['local'] = {'a': 'b'}
    assert LocalFactCollector().collect(module=None, collected_facts=None) == fact_dict

# Generated at 2022-06-11 04:54:01.681091
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Make sure a temporary directory exists
    fact_path = u'/tmp/ansible_facts.d'
    if not os.path.exists(fact_path):
        os.mkdir(fact_path)

    test_path = os.path.join(os.path.dirname(__file__), '..', '..', 'unit', 'module_utils',
                             'facts', 'local_facts.d')
    local_facts = {}

# Generated at 2022-06-11 04:54:03.428090
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    localfact_collector_obj = LocalFactCollector()
    assert localfact_collector_obj.name == 'local'


# Generated at 2022-06-11 04:54:04.309740
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'

# Generated at 2022-06-11 04:54:07.856726
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Ensure utf8 and not to_text
    # Collect binary facts
    # Ensure local['local'] exists
    # Ensure that executable and non-executable return good data
    # Ensure that json or configparser will return a dict
    # Ensure that incorrect json or configparser will throw exception and warn
    pass

# Generated at 2022-06-11 04:54:09.305352
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    obj = LocalFactCollector()
    assert obj.name == 'local'
    assert obj._fact_ids == set()

# Generated at 2022-06-11 04:54:11.353881
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    print('Unit test for constructor of class LocalFactCollector')
    localFactCollector = LocalFactCollector()
    assert localFactCollector.name == 'local'

# Generated at 2022-06-11 04:54:12.678787
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    obj = LocalFactCollector()
    assert obj.name == 'local'

# Generated at 2022-06-11 04:56:32.942694
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    fake_ansible_module = type('obj', (object,), {})
    FakeAnsibleModule = type('FakeAnsibleModule', (object,), {
        "run_command.return_value": (0, "{ 'test_fact': 'fact_value' }", ""),
        "params": {
            "fact_path": "/etc/ansible/facts.d"
        }
    })
    local_fact_collector = LocalFactCollector()
    local_fact_collector._module = FakeAnsibleModule()
    collected_facts = {
        'facter': {
            'test_fact': 'fact_value'
        }
    }

# Generated at 2022-06-11 04:56:37.989015
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    assert isinstance(local_fact_collector, BaseFactCollector)

    # Avoid pytest ImportError
    try:
        import pytest
    except ImportError:
        pytest = None

    if pytest:
        output = local_fact_collector.collect(module=pytest.Mock())
        assert isinstance(output, dict)
        assert output == {}
    else:
        output = local_fact_collector.collect()
        assert isinstance(output, dict)
        assert output == {}

# Generated at 2022-06-11 04:56:38.652401
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'

# Generated at 2022-06-11 04:56:39.758052
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    lfc = LocalFactCollector()
    assert lfc.collect() == {'local': {}}

# Generated at 2022-06-11 04:56:40.947390
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-11 04:56:41.538186
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    LocalFactCollector().collect()

# Generated at 2022-06-11 04:56:43.067876
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fact_collector = LocalFactCollector()
    assert fact_collector.name == 'local'
    assert isinstance(fact_collector._fact_ids, set)

# Generated at 2022-06-11 04:56:49.168226
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import os
    import shutil
    import tempfile

    import ansible.module_utils.facts.collector

    def cleanup(tmpdir, tmpdir_orig):
        for fn in os.listdir(tmpdir_orig):
            shutil.move(os.path.join(tmpdir_orig, fn), os.path.join(tmpdir, fn))
        shutil.rmtree(tmpdir_orig)

    def test(content, expected_facts, tmpdir, tmpdir_orig, module):
        from ansible.module_utils.common.process import get_bin_path

        fact_path = tmpdir_orig
        os.makedirs(fact_path)

        # Test when file has all supported content
        fn = os.path.join(fact_path, 'test.fact')

# Generated at 2022-06-11 04:56:56.070913
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils import facts
    import sys
    import shutil
    import os

    def run_command(self, cmd, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
        return 0, '', ''

    # import the modules now so we can mock them
    mod_utils_path = os.path.dirname(sys.modules['ansible'].__file__) + '/module_utils'
    if mod_utils_path not in sys.path:
        sys.path.append(mod_utils_path)

    import lib.facts.system.distribution

    # mock the methods to determine if we're running as root
    lib.facts.system.distribution.geteuid = lambda: 0


# Generated at 2022-06-11 04:57:01.953378
# Unit test for method collect of class LocalFactCollector