

# Generated at 2022-06-11 04:49:22.180696
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    obj = LocalFactCollector()
    assert isinstance(obj, LocalFactCollector)

# Generated at 2022-06-11 04:49:24.353010
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-11 04:49:27.198566
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

    localFactCollector = LocalFactCollector()

    assert localFactCollector.name == 'local'
    assert localFactCollector._fact_ids == set()
    assert isinstance(localFactCollector.collect(), dict)


# Generated at 2022-06-11 04:49:29.513462
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    """Test the constructor of class LocalFactCollector"""
    fact_collector = LocalFactCollector()
    assert fact_collector.name == 'local'

# Generated at 2022-06-11 04:49:30.150457
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass

# Generated at 2022-06-11 04:49:31.517925
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    obj = LocalFactCollector()
    assert obj.name == 'local'

# Generated at 2022-06-11 04:49:34.668869
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

    # Create the object for testing
    obj = LocalFactCollector()

    # Check the name attribute value
    assert obj.name == 'local'

    # Check the _fact_ids attribute
    assert obj._fact_ids == set()

# Generated at 2022-06-11 04:49:36.204592
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    l = LocalFactCollector()
    assert l.name == 'local'

# Generated at 2022-06-11 04:49:37.179473
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    _ = BaseFactCollector()

# Generated at 2022-06-11 04:49:39.285777
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()

    assert local_fact_collector.name == 'local'


# Generated at 2022-06-11 04:49:48.012350
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-11 04:49:49.379307
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local = LocalFactCollector()
    assert local.name == 'local'

# Generated at 2022-06-11 04:49:51.138704
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    obj = LocalFactCollector()
    assert obj.name == 'local'
    assert obj._fact_ids == set()

# Generated at 2022-06-11 04:49:52.433016
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert isinstance(LocalFactCollector('dummy'), LocalFactCollector)

# Generated at 2022-06-11 04:50:02.761394
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts import ModuleArgsParser
    from ansible.modules.system import setup

    # These argspecs are taken from the setup module, but we remove certain
    # options that produce additional arguments for the fact gathering.
    modified_argspec = dict(filter_spec=dict(default=None, required=True,
                                             type='dict', no_log=True))
    modified_argspec.update(setup.argspec)
    del modified_argspec['gather_subset']
    del modified_argspec['gather_timeout']

    # Create a module instance with modified argspec to override the original
    # argspec of the setup module.

# Generated at 2022-06-11 04:50:04.662711
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    localFactCollector = LocalFactCollector()
    assert localFactCollector.name == 'local'
    assert not localFactCollector._fact_ids

# Generated at 2022-06-11 04:50:09.865856
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Instantiate the LocalFactCollector and collect facts
    lfc = LocalFactCollector()
    fact_data = lfc.collect()

    # Assert that the fact_data is populated
    assert fact_data['local'] is not None
    assert 'localhostname' in fact_data['local']
    assert 'hostname' in fact_data['local']
    assert 'localhostname' in fact_data['local']

# Generated at 2022-06-11 04:50:18.811549
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fact_path = os.path.join(os.getcwd(), 'test_facts')
    local_fact_collector = LocalFactCollector(module_name='test', module_args={'fact_path': fact_path}, task_vars={})
    result =  local_fact_collector.collect()
    assert result['local']['file_exists'] == 'successful_fact'
    assert result['local']['non_existent_fact'] == 'Failed to convert (./test_facts.fact) to JSON: No such file or directory'
    assert result['local']['command_fail'] == 'Failed to convert (./test_facts/bad_fact.fact) to JSON: unknown error'
    assert result['local']['command_success'] == 'successful_fact'

# Generated at 2022-06-11 04:50:24.162800
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    if local_fact_collector._fact_ids != set():
        assert False, "FAIL: test_LocalFactCollector(): local fact_ids must be empty"
    if local_fact_collector.name != 'local':
        assert False, "FAIL: test_LocalFactCollector(): local name does not match"


# Generated at 2022-06-11 04:50:32.075921
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    fact_path = 'tmp'
    module = MockModule()
    module.params = {
        'fact_path': fact_path
    }
    assert not os.path.exists(fact_path)
    assert LocalFactCollector(module).collect() == {'local': {}}
    assert not os.path.exists(fact_path)
    os.mkdir(fact_path)
    assert LocalFactCollector(module).collect() == {'local': {}}
    assert not os.path.exists(fact_path)
    os.rmdir(fact_path)


# Generated at 2022-06-11 04:50:53.649086
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts import Facts
    import tempfile
    import os
    import stat
    import sys
    import platform
    import json
    from ansible.module_utils._text import to_bytes, to_text

    # stub module
    # pylint: disable=too-many-instance-attributes
    class TestModule:
        """ stub module
        """
        def __init__(self):
            self.params = {}
            self.exit_json = None
            self.fail_json = None
            self.debug = None
            self.warn = lambda msg: sys.stderr.write(msg + '\n')

        def run_command(self, arg):
            """ stub run command
            """
            return 0, '', ''

    # stub contents for fact file

# Generated at 2022-06-11 04:50:57.145114
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fact_path = 'some_path'
    local_fact_collector = LocalFactCollector(None, None, fact_path)
    assert local_fact_collector is not None
    assert fact_path == local_fact_collector.fact_path

# Generated at 2022-06-11 04:51:01.706711
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # NOTE: This method is used to test a non-public method in
    #       BaseFactCollector. See the note in BaseFactCollector.
    #       collect for more information.
    facts_collector = LocalFactCollector()
    assert facts_collector.collect() == {'local': {}}, "Failure while testing function 'collect' with empty params"

# Generated at 2022-06-11 04:51:03.332896
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # object Variables
    local = LocalFactCollector()
    assert local.name == 'local'



# Generated at 2022-06-11 04:51:04.968984
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-11 04:51:11.056281
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    
    # test instantiation of class LocalFactCollector
    local_fact_collector = LocalFactCollector()

    # test class LocalFactCollector has name attribute set
    assert isinstance(local_fact_collector.name, str)
    assert local_fact_collector.name == 'local'

    # test class LocalFactCollector has _fact_ids attribute set
    assert isinstance(local_fact_collector._fact_ids, set)

# Generated at 2022-06-11 04:51:13.902494
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    class test():
        params = {'fact_path':'/root/facts'}
        def warn(self, msg):
            assert msg

    LocalFactCollector(test())


# Generated at 2022-06-11 04:51:23.806608
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = None
    collected_facts = None
    fact_path = './test/units/module_utils/facts/local_facts_collector/facts'
    lfc = LocalFactCollector()
    facts = lfc.collect(module, collected_facts)

    assert 'local' in facts
    # should be 5 facts, warning.fact is not valid
    assert len(facts['local']) == 5
    assert facts['local']['one']['first_var'] == "1"
    assert facts['local']['one']['second_var'] == "4"
    assert facts['local']['two']['first_var'] == "2"
    assert facts['local']['two']['second_var'] == "5"

# Generated at 2022-06-11 04:51:25.944944
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    l = LocalFactCollector()
    assert l.name == 'local'
    assert l._fact_ids == set(['local'])

# Generated at 2022-06-11 04:51:34.307600
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import subprocess
    import pytest
    from tempfile import mkdtemp

    with pytest.raises(Exception):
        LocalFactCollector().collect()

    subprocess.check_call(['touch', '__init__'], cwd=my_fact_path)

    # empty
    subprocess.check_call(['touch', 'x.fact'], cwd=my_fact_path)
    assert LocalFactCollector().collect(dict(fact_path=my_fact_path)) == {'local': {'x': {}}}

    # json
    with open(os.path.join(my_fact_path, 'y.fact'), 'w') as f:
        f.write('{}')

# Generated at 2022-06-11 04:52:00.846928
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    result = LocalFactCollector()
    assert result.name == 'local'
    assert isinstance(result._fact_ids, set)
    assert result._fact_ids == set()

# Generated at 2022-06-11 04:52:10.869547
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # mock module.params
    module_params = {'fact_path': './test/unit/module_utils/facts/files/'}
    # mock module.run_command()
    def mock_run_command(name, *args, **kwargs):
        assert name == './test/unit/module_utils/facts/files/test.fact'
        rc = 0
        out = 'TEST_FACT_SCRIPT_OUTPUT'
        err = 'TEST_FACT_SCRIPT_ERROR'
        return rc, out, err
    # mock module.warn()
    msg = 'TEST_MODULE_WARNING'
    def mock_warn(msg):
        assert msg == msg
    # mock ansible.module_utils.facts.utils.get_file_content()

# Generated at 2022-06-11 04:52:19.947811
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import pytest
    import os
    import tempfile
    import json

    test_fact_path = tempfile.mkdtemp()
    test_fact_file_content = '#!/bin/sh\n'
    test_fact_file_content += 'echo -n \'{"test_added_fact_value":"test_added_fact"}\''
    test_fact_file_name = 'test-added-fact'

    test_fact_file = os.path.join(test_fact_path, test_fact_file_name + '.fact')

    with open(test_fact_file, 'w') as f:
        f.write(test_fact_file_content)

    os.chmod(test_fact_file, 0o755)

    mock_module = pytest.MagicMock()
    mock_module.params

# Generated at 2022-06-11 04:52:27.565107
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    lfc = LocalFactCollector()
    expect = {'local': {'foo': {'b': '2', 'a': '1'}, 'bar': '1'}}
    expect_me = 'foo'
    fact_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_data')
    module = FakeModule(fact_path=os.path.join(fact_path, expect_me))
    collected_facts = {}
    result = lfc.collect(module, collected_facts)
    assert expect == result


# Class for unit test for method collect of class LocalFactCollector

# Generated at 2022-06-11 04:52:33.652942
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import FactCache
    import os
    import shutil
    import tempfile

    test_dir = tempfile.mkdtemp()
    fact_cache = FactCache(test_dir)
    # Make sure fact_cache knows test_dir
    fact_cache._cache_dirs = set([test_dir])

    content = '''#!/usr/bin/python
import sys
print('{"ansible_local": "executed"}')
sys.exit(0)
    '''
    with open(os.path.join(test_dir, 'ansible_local.fact'), "w") as f:
        f.write(content)


# Generated at 2022-06-11 04:52:45.429678
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    fact_path = os.path.join(os.path.dirname(__file__), '../../../../test/units/module_utils/facts/fixtures/local')

    if not os.path.exists(fact_path):
        raise Exception("Test setup failure, path %s doesn't exist" % fact_path)

    module = dict(
        params={'fact_path': fact_path}
    )

    test_obj = LocalFactCollector()
    local_facts = test_obj.collect(module=module)
    result = local_facts['local']

    assert 'local_01' in result
    assert result['local_01'] == dict(var_01='local_01')

    assert 'local_02' in result
    assert result['local_02'] == dict(var_01='local_02')

   

# Generated at 2022-06-11 04:52:46.034927
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass

# Generated at 2022-06-11 04:52:46.956224
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # test constructor of LocalFactCollector class
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-11 04:52:47.528353
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass

# Generated at 2022-06-11 04:52:54.868756
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import ansible.module_utils.facts.collectors.base
    import ansible.module_utils.facts.collectors.local

    # Patch function run_command of class AnsibleModule to avoid command execution
    def mock_run_command(*args, **kwargs):
        return (0, '', '')

    ansible.module_utils.facts.collectors.base.AnsibleModule.run_command = mock_run_command

    # Patch function get_file_content of module utils to avoid file reading

# Generated at 2022-06-11 04:54:04.954084
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    from ansible.module_utils.facts.collector.local import LocalFactCollector

    assert LocalFactCollector.name == "local"
    assert isinstance(LocalFactCollector._fact_ids, set)


# Generated at 2022-06-11 04:54:05.447081
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    pass

# Generated at 2022-06-11 04:54:06.502961
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    #TODO:
    pass

# Generated at 2022-06-11 04:54:07.708873
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    localFactCollector = LocalFactCollector()
    assert localFactCollector is not None

# Generated at 2022-06-11 04:54:09.156695
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    localFactCollector = LocalFactCollector()
    assert localFactCollector.name == 'local'

# Generated at 2022-06-11 04:54:16.677697
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    argument_spec = dict(
        fact_path=dict(default=None),
    )
    module = AnsibleModule(argument_spec=argument_spec)

    c = LocalFactCollector()
    local_facts = c.collect(module=module, collected_facts=None)

    assert local_facts['local']['test_fact_just_a_string'] == 'This is a string'

    # Assert that value of fact_script_already_a_dict is not None because it
    # means that ansible_local.test_fact_script_already_a_dict.value1 should
    # also not be None
    assert local_facts['local']['test_fact_script_already_a_dict'] is not None

    # Assert that value of fact_script_already_a_dict.value1

# Generated at 2022-06-11 04:54:24.564879
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    module = 'ansible_local'
    fact_path = '/etc/ansible/facts.d'

    local_facts = {}
    local_facts['local'] = {}

    if not module or not fact_path:
        return local_facts

    local = {}
    # go over .fact files, run executables, read rest, skip bad with warning and note
    for fn in sorted(glob.glob(fact_path + '/*.fact')):
        # use filename for key where it will sit under local facts
        fact_base = os.path.basename(fn).replace('.fact', '')
        if stat.S_IXUSR & os.stat(fn)[stat.ST_MODE]:
            failed = None

# Generated at 2022-06-11 04:54:25.118232
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass

# Generated at 2022-06-11 04:54:27.766283
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    """
    Test the constructor of class LocalFactCollector.
    """
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-11 04:54:28.279977
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector

# Generated at 2022-06-11 04:57:06.705539
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # test params
    params_1 = {'fact_path': 'some/path/here'}

    # test args
    args_1 = {'collected_facts': None}
    args_2 = {'collected_facts': {}}

    # test return values
    return_1 = {'local': {}}
    return_2 = {'local': {'some_fact_file': {'some_section': {'some_fact': 'some_value'}}}}
    return_3 = {'local': {'some_fact_file': {'some_section': {'some_fact': 'some_value'}}}}

    def get_file_content_1(file_name, default=''):
        return '{"some_fact": "some_value"}\n'


# Generated at 2022-06-11 04:57:10.857701
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils import facts

    facts_obj = facts.Facts(None, {}, {}, None, None, {})
    local = LocalFactCollector(None, facts_obj)

    # Test if empty fact_path returns empty local facts
    collected_facts = local.collect()
    assert 'local' not in collected_facts

    # Test if empty fact_path returns empty local facts
    collected_facts = local.collect(module=None)
    assert 'local' not in collected_facts

# Generated at 2022-06-11 04:57:13.847877
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()

    # Assert that the class is correctly initialised
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

    # Assert that the method collect is correctly initialised
    assert local_fact_collector.collect() == {}

# Generated at 2022-06-11 04:57:15.442970
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_facts = LocalFactCollector()

    assert local_facts.name == 'local'
    assert local_facts._fact_ids == set()


# Generated at 2022-06-11 04:57:16.500254
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    lf = LocalFactCollector()
    assert(lf.name == 'local' and lf._fact_ids == set())

# Generated at 2022-06-11 04:57:17.128735
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert 'local' == LocalFactCollector().name

# Generated at 2022-06-11 04:57:17.750189
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'

# Generated at 2022-06-11 04:57:19.528558
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Instantiate a LocalFactCollector
    lfct = LocalFactCollector()
    assert lfct is not None
    assert lfct.name == 'local'
    assert lfct._fact_ids == set()

# Generated at 2022-06-11 04:57:20.391679
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    lfc = LocalFactCollector()
    assert lfc.name == 'local'

# Generated at 2022-06-11 04:57:23.136235
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    facts_plugin = LocalFactCollector()
    test_module = AnsibleModule(argument_spec={'fact_path': dict(default='/home/jenkins/workspace/ansible/lib/ansible/module_utils/facts/facts.d')})
    results = facts_plugin.collect(test_module, collected_facts=dict())
    assert results['local']
