

# Generated at 2022-06-11 04:49:25.216645
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    def run_command(self, cmd):
        if cmd.endswith('fact1.fact'):
            return 0, b'{"1": 1}', b''
        elif cmd.endswith('fact2.fact'):
            return 0, b'{"2": 2}', b''
        elif cmd.endswith('fact3.fact'):
            return 0, b'{"3": 3}', b''
        else:
            raise Exception("Unexpected task")
    def get_file_content(path, default=None, err_msg=None):
        if path.endswith('fact1.fact'):
            return b'{"4": 4}'
        elif path.endswith('fact2.fact'):
            return b'{"5": 5}'

# Generated at 2022-06-11 04:49:26.787753
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    l = LocalFactCollector()
    assert l.name == 'local'


# Generated at 2022-06-11 04:49:35.039742
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fact_path = '/etc/ansible/facts.d'
    fact_dict = {}
    fact_dict['local'] = {}
    test_file = '/etc/ansible/facts.d/some_fact.fact'
    with open(test_file, 'w') as f:
        f.write('some_fact=some_value')
    os.chmod(test_file, 0o777)
    test = LocalFactCollector(fact_path, fact_dict)
    assert test is not None
    assert test.name == 'local'
    assert test.facts == fact_dict

    assert test.collect() == fact_dict
    os.remove(test_file)

# Generated at 2022-06-11 04:49:45.852624
# Unit test for method collect of class LocalFactCollector

# Generated at 2022-06-11 04:49:48.768405
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Since we are not getting parameters in this class, just call the constructor & verify if the instance is created
    c = LocalFactCollector()
    assert c.name == 'local'
    assert c._fact_ids == set()

# Generated at 2022-06-11 04:49:49.808959
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    res = LocalFactCollector()
    assert res

# Generated at 2022-06-11 04:49:58.684730
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = None
    collected_facts = None
    x = LocalFactCollector()
    result =  x.collect(module, collected_facts)
    assert (result['local'] == {})

    module = None
    collected_facts = None
    x = LocalFactCollector()
    x._fact_path = "abc"
    result =  x.collect(module, collected_facts)
    assert (result['local'] == {})

    module = "a"
    collected_facts = None
    x = LocalFactCollector()
    x._fact_path = "./test_local_fact"
    result =  x.collect(module, collected_facts)
    assert (result['local'] != {})

# Generated at 2022-06-11 04:50:00.084738
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    a = LocalFactCollector()
    assert a.name == 'local'

# Generated at 2022-06-11 04:50:05.620161
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import pytest
    from ansible.module_utils.facts import ansible_local

    # Call module without conditions
    collected_facts = {}
    local_module = ansible_local.AnsibleLocal(module_args=None)
    local_facts = LocalFactCollector().collect(local_module, collected_facts)

    assert 'local' in local_facts
    assert len(local_facts['local']) == 0


# Generated at 2022-06-11 04:50:08.104914
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_coll = LocalFactCollector()
    assert local_fact_coll.name == 'local'
    assert hasattr(local_fact_coll, 'collect')

# Generated at 2022-06-11 04:50:23.138475
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import os
    file_path = os.path.dirname(os.path.realpath(__file__))
    fact = file_path + '/../../../.tmp/facts/local/' + 'test_local.fact'
    fact_path = file_path + '/../../../.tmp/facts/local/'
    expected = {}
    expected['local'] = {}
    expected['local']['test_local'] = {'key': 'value'}

# Generated at 2022-06-11 04:50:25.675372
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    """This is a unit test for constructor of class LocalFactCollector"""
    local_facts = LocalFactCollector()

    assert local_facts.name == 'local'

# Generated at 2022-06-11 04:50:35.785535
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.local import LocalFactCollector
    from ansible.module_utils.facts.utils import FactsParams, AnsibleModuleFake

    class TestPri(object):
        def __init__(self):
            self.stdout_lines = []
            self.warnings = []

    def fake_run_command(args, check_rc=True, close_fds=True, executable=None,
                         data=None, binary_data=False, path_prefix=None,
                         cwd=None, use_unsafe_shell=False, prompt_regex=None,
                         environ_update=None, umask=None, encoding=None,
                         errors=None, text=None):
        return 0, '', ''

    module = AnsibleModuleFake()
    module.run_command = fake_run

# Generated at 2022-06-11 04:50:38.074005
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local = LocalFactCollector()
    # Success
    assert isinstance(local.name, str)
    assert isinstance(local._fact_ids, set)

# Generated at 2022-06-11 04:50:42.189501
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_object = LocalFactCollector()
    assert local_fact_collector_object.name == 'local'
    assert local_fact_collector_object._fact_ids.__len__() == 0



# Generated at 2022-06-11 04:50:51.379360
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    args = {}
    args['ansible_python_interpreter'] = '/usr/bin/python'
    args['ansible_facts'] = {}
    args['ansible_facts']['local'] = {}
    args['ansible_facts']['local']['fail'] = "error loading facts as JSON or ini - please check content: /root/ansible/facts"
    args['ansible_facts']['local']['fact1'] = {'facts': {'a': 'b', 'c': 'd'}}
    args['ansible_facts']['local']['fact2'] = {'facts': {'a': 'b', 'c': 'd'}}

# Generated at 2022-06-11 04:50:54.725911
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    module_args = dict(fact_path=os.path.join(os.path.dirname(__file__), 'fixtures'))
    local_collector = LocalFactCollector(module=None, module_args=module_args)
    assert local_collector.name == 'local'

# Generated at 2022-06-11 04:51:02.609981
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector import get_collector_class
    # Setup
    local_fact_collector = get_collector_class('local', default_collectors)()

    # Test
    local_fact_tuple = local_fact_collector.collect()

    # Assertion
    assert not isinstance(local_fact_tuple, BaseFactCollector)
    assert isinstance(local_fact_tuple, dict)

# Generated at 2022-06-11 04:51:04.928231
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Unit test of method collect()

# Generated at 2022-06-11 04:51:07.071498
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.collect() == {'local': {}}

# Generated at 2022-06-11 04:51:21.674874
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # data
    module = None
    collected_facts = None

    # create instance of LocalFactCollector
    local_fact_collector = LocalFactCollector()

    # test method
    result = local_fact_collector.collect(module, collected_facts)

    # assert
    assert type(result) == dict

# Generated at 2022-06-11 04:51:25.142682
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    local_facts = local_fact_collector.collect()
    assert 'local' in local_facts
    assert isinstance(local_facts['local'], dict)


# Generated at 2022-06-11 04:51:28.569637
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    localFactCollectorObj = LocalFactCollector()

    # Assertion of LocalFactCollector object
    assert localFactCollectorObj is not None
    assert localFactCollectorObj.name == 'local'
    assert localFactCollectorObj._fact_ids == set()

# Generated at 2022-06-11 04:51:29.445507
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'

# Generated at 2022-06-11 04:51:30.758130
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fc = LocalFactCollector()
    assert fc.name == 'local'

# Generated at 2022-06-11 04:51:32.198258
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    localFactCollector = LocalFactCollector()
    assert localFactCollector.name == 'local'

# Generated at 2022-06-11 04:51:39.079905
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fact_path = 'test/ansible/facts/modules/test_local_facts'
    local_fact_collector = LocalFactCollector({ 'fact_path' : fact_path})
    local_facts = local_fact_collector.collect()
    assert local_facts['local']['local_dict'] == {'name': 'local_facts'}
    assert local_facts['local']['local_list'] == ['one', 'two', 'three', 'four']
    assert local_facts['local']['local_string'] == 'local_facts'
    assert local_facts['local']['path'] == fact_path

# Generated at 2022-06-11 04:51:40.524182
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    f = LocalFactCollector()
    assert isinstance(f, BaseFactCollector)

# Generated at 2022-06-11 04:51:46.321203
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    from ansible.module_utils.facts import ModuleFacts

    def mod(path='/tmp/facts', **kwargs):
        class mod:
            def __init__(self):
                self.params = kwargs
        return mod()

    test_mod = mod()

    test_obj = LocalFactCollector(ModuleFacts(test_mod))
    assert test_obj.name is not None
    assert test_obj.name == 'local'
    assert isinstance(test_obj.collect(), dict)
    assert 'local' in test_obj.collect()

# Generated at 2022-06-11 04:51:48.698885
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fact_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'units')
    assert LocalFactCollector(fact_path).name == 'local'

# Generated at 2022-06-11 04:52:17.832209
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.facts import Facts

    fact_path = os.path.join(os.path.dirname(__file__), 'resources', 'local_facts')
    module = MockModule(params={'fact_path': fact_path})
    local_facts = LocalFactCollector().collect(module=module)
    assert local_facts == {'local': {'fact1': 'foo1', 'fact2': {'key1': 'value1', 'key2': 'value2'}}}, local_facts


# Generated at 2022-06-11 04:52:19.494208
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_coll = LocalFactCollector()
    assert local_fact_coll.name == 'local'

# Generated at 2022-06-11 04:52:22.046825
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    localFactCollector = LocalFactCollector()
    local_facts = localFactCollector.collect()
    assert isinstance(local_facts, dict)
    assert 'local' in local_facts

# Generated at 2022-06-11 04:52:23.577382
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    m = LocalFactCollector()
    assert m.name == 'local'

# Generated at 2022-06-11 04:52:25.989502
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    module = None
    x = LocalFactCollector(module)
    assert x.name == 'local'
    #assert x._fact_ids == set()


test_LocalFactCollector()

# Generated at 2022-06-11 04:52:30.640636
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module_mock = MagicMock()

    module_mock.params = {'fact_path': '/some/path'}
    module_mock.run_command.return_value = (0, '', '')

    facts_collector = LocalFactCollector()
    facts_collector.collect(module_mock, collected_facts=None)

    module_mock.run_command.assert_called_once_with('/some/path/*.fact')


# Generated at 2022-06-11 04:52:42.205525
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import os
    import platform
    from ansible.module_utils.facts import default_collectors

    # create a mock module which has a facts_module
    class MockModule:
        def __init__(self, facts_module=None):
            self.params = {'fact_path': facts_module if facts_module else []}
            self.fail_json = lambda msg: None
            self.warn = lambda msg: None
            self.run_command = lambda cmd: (0, '', '')   # default to success

    # class test setup
    test_local_facts_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), '../../../../test/units/module_utils/local_facts.d/')

    # Test facts_module loaded
    test_module = Mock

# Generated at 2022-06-11 04:52:51.250271
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = MockModule()
    test_obj = LocalFactCollector(module)
    # no params set should get empty dict
    assert test_obj.collect() == {'local': {}}

    # set a fact_path and run again
    # os.path.exists will be mocked to return true; and glob from above to return empty
    module.params['fact_path'] = '/some/place'
    assert test_obj.collect() == {'local': {}}

    # inject some executable files into glob call and run again
    with mock.patch("glob.glob", return_value=['/some/place/fact1.fact', '/some/place/fact2.fact', '/some/place/fact3.fact']):
        # expect 'local' to have 3 keys and all values to be string
        result = test_obj.collect

# Generated at 2022-06-11 04:52:59.177378
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module_args = {'fact_path': '/tmp'}
    module = FakeAnsibleModule()
    module.params = module_args
    local_fact_collector = LocalFactCollector(module)
    assert local_fact_collector.collect() == {}

    # Test with one fact file
    parent_dir = os.path.dirname(__file__)
    fact_path = os.path.join(parent_dir, 'fixtures', 'sample_facts')
    module_args = {'fact_path': fact_path}
    module = FakeAnsibleModule()
    module.params = module_args
    local_fact_collector = LocalFactCollector(module)
    facts = local_fact_collector.collect()
    result = facts.get('local')
    assert len(result) == 1
   

# Generated at 2022-06-11 04:53:00.803204
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local = LocalFactCollector()
    assert local.name == 'local'
    assert local.priority == 20


# Generated at 2022-06-11 04:54:07.671422
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Setup the mock
    # 1. Module
    module = MockModule()
    # 2. BaseFactCollector
    base = MockBaseFactCollector(
        module = module
    )
    # 3. LocalFactCollector
    local = LocalFactCollector(
        base = base
    )

    # Test the method with the following scenarios :
    # 1. fact_files and no fact_path
    # 2. fact_files and fact_path
    # 3. fact_files and fact_path but fact_path is not a path
    # 4. fact_files and fact_path and fact_path is a path, but there is no fact_file
    # 5. fact_files and fact_path and fact_path is a path and has fact_file
    # 6. fact_files and fact_path and fact_path is a path, has

# Generated at 2022-06-11 04:54:09.415861
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert isinstance(local_fact_collector, LocalFactCollector)

# Generated at 2022-06-11 04:54:16.862478
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """ Test Ansible module utility method collect of class LocalFactCollector """

    m_answer = {
        "local": {
            "myfact": {
                "somesubfact": "somevalue"
            }
        }
    }

    m_collector = LocalFactCollector()

    class mock_module():
        params = {
            'fact_path': '/tmp',
        }

        def warn(message):
            print(message)

        def run_command(cmd):
            return 0, '', ''

    m_module = mock_module()

    class glob():
        def glob(p):
            return ['/tmp/myfact.fact']

    class os():
        class stat():
            ST_MODE = 1

        def stat(f):
            return stat()


# Generated at 2022-06-11 04:54:17.348634
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass

# Generated at 2022-06-11 04:54:21.708857
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_obj = LocalFactCollector()
    assert test_obj.name == 'local'
    assert test_obj.collected_facts == {}
    assert test_obj._fact_ids == set()
    assert test_obj.plugin_name == 'local'
    assert test_obj.plugin_name_nice == 'Local'
    assert test_obj.plugin_type == 'main'


# Generated at 2022-06-11 04:54:22.768489
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    collector = LocalFactCollector()
    assert collector is not None


# Generated at 2022-06-11 04:54:23.845343
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    lfc = LocalFactCollector()
    assert lfc.name == 'local'

# Generated at 2022-06-11 04:54:31.986344
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import get_collector_instance

    class MockModule(object):
        def __init__(self, params):
            self.params = params

    # To test LocalFactCollecttor method, we invoke get_collector_instance
    # to get the instance of LocalFactCollector
    local_facts = dict()
    local_facts['local'] = dict()
    local_facts['local']['local_fact'] = dict()
    local_facts['local']['local_fact']['local_fact_key1'] = "local_fact_value1"
    local_facts['local']['local_fact']['local_fact_key2'] = "local_fact_value2"


# Generated at 2022-06-11 04:54:42.635745
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    '''
    Unit test: ansible.module_utils.facts.local.LocalFactCollector.collect()
    '''
    # pylint: disable=protected-access
    # pylint: disable=no-member
    LocalFactCollector._fact_ids = set()

    # No fact_path
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.collect() == {}

    # no fact file
    local_fact_collector = LocalFactCollector(module=True)
    assert local_fact_collector.collect() == {}

    # fact file returns a dict
    local_fact_collector = LocalFactCollector(module=True,
                                              fact_path='/tmp')

# Generated at 2022-06-11 04:54:50.190728
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import os
    tmp = None

# Generated at 2022-06-11 04:57:16.232988
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    a = LocalFactCollector()
    assert a.name == 'local'

test_LocalFactCollector()

# Generated at 2022-06-11 04:57:21.954698
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Setup a mock AnsiModule using the ansible.module_utils.facts.utils

    data = dict(ansible_facts={})
    module = MockAnsiModule()
    module.params = dict(fact_path='/tmp/facts.d')
    # Create dummy directories and files
    os.mkdir(module.params.get('fact_path'))
    # Create a valid json fact file
    with open(os.path.join(module.params.get('fact_path'), 'json.fact'), 'w') as f:
        f.write("#!/bin/sh\n")
        f.write("{\"hello\": \"world\"}\n")
    # Create a valid ini fact file

# Generated at 2022-06-11 04:57:27.959049
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # If a module path is provided do not attempt to execute .fact files
    module_mock = MockModule()
    module_mock.params = {}
    module_mock.params['fact_path'] = '/tmp/local_facts'
    module_mock.params['_ansible_version'] = '2.4.2.0'
    module_mock.params['_ansible_module_name'] = 'setup'
    module_mock.params['_ansible_module_sig'] = '998d366244d9b39e02e0da0c53fec097e6b48385'
    module_mock.params['_ansible_system'] = 'Linux'
    module_mock.params['_ansible_python_version'] = '3.6.3'
    local_fact_

# Generated at 2022-06-11 04:57:34.066144
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import os
    import json
    import tempfile
    from ansible.module_utils.facts import ansible_local
    from ansible.module_utils.facts.collector import FactsCollector

    # Create temporary directory
    # On Windows, the temp directory is created in TMP/TEMP

    temp_dir = tempfile.mkdtemp()

    # Create 2 fact files in directory

    file1_path = os.path.join(temp_dir, 'test_local_fact_collector_1.fact')
    file1_content = """
[test_local_fact_collector_1]
test_key_1 = 1
test_key_2 = 2
"""

    with open(file1_path, 'w') as f:
        f.write(file1_content)


# Generated at 2022-06-11 04:57:35.730608
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

    local_fact = LocalFactCollector()
    assert local_fact.name == "local"
    assert local_fact._fact_ids == set()

# Generated at 2022-06-11 04:57:37.507758
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name  == 'local'


# Generated at 2022-06-11 04:57:39.477663
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-11 04:57:46.589597
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import shutil
    import tempfile
    from ansible.module_utils import basic

    file_content = """
foo = bar
"""
    invalid_file_content = """
foo = bar
baz
"""
    tmpdir = tempfile.mkdtemp()
    fact_path = os.path.join(tmpdir, 'facts.d')
    conf_file = os.path.join(fact_path, 'test.fact')
    invalid_conf_file = os.path.join(fact_path, 'invalid.fact')
    executable_file = os.path.join(fact_path, 'executable.fact')

    os.mkdir(fact_path)
    with open(conf_file, 'wb') as f:
        f.write(file_content)

# Generated at 2022-06-11 04:57:48.134192
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    """
    Constructor of class LocalFactCollector
    """
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector

# Generated at 2022-06-11 04:57:55.431818
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import iteritems

    # Helper function for testing
    def fail_json(*args, **kwargs):
        kwargs['failed'] = True
        raise Exception(kwargs)

    def run_command(self, *args, **kwargs):
        return 0, '', ''

    # Initialise AnsibleModule object.
    module = AnsibleModule(
        argument_spec = dict(
            foo=dict(required=False, type='str')
        ),
        supports_check_mode=True
    )

    module.run_command = run_command

    def warn(self, *args, **kwargs):
        pass

    module.warn = warn

    module.params = {'fact_path': '/tmp'}

   