

# Generated at 2022-06-11 04:49:22.439189
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    localFactCollector = LocalFactCollector()
    localFactCollector.collect()

# Generated at 2022-06-11 04:49:23.282477
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == "local"

# Generated at 2022-06-11 04:49:25.636084
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    ''' Unit test for method collect of class LocalFactCollector '''
    collector = LocalFactCollector()
    facts_list = collector.collect()

    assert isinstance(facts_list, dict)

# Generated at 2022-06-11 04:49:33.763826
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    fact_path = '/tmp/ansible_local_facts/'
    local_fact_content = "local_fact=foo"
    with open(fact_path + '/local_fact.fact', 'w+') as f:
        f.write(local_fact_content)
    with open(fact_path + '/local_fact2.fact', 'w+') as f:
        f.write(local_fact_content + '\n')

    collector = LocalFactCollector()
    res = collector.collect()

    assert res['local']['local_fact'] == 'foo'
    assert res['local']['local_fact2'] == 'foo\n'

# Generated at 2022-06-11 04:49:34.366185
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass

# Generated at 2022-06-11 04:49:35.864360
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local = LocalFactCollector()
    assert local.name == 'local'

# Generated at 2022-06-11 04:49:38.663538
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    module = None
    fact_path = None
    local_facts = LocalFactCollector(module, fact_path).collect()
    assert local_facts == {'local': {}}
    

# Generated at 2022-06-11 04:49:49.480140
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    is_json = False
    is_local = True

    class Module:
        def __init__(self):
            self.params = {}
            self.warn_msg = None
            self.warn = self.warn_msg_lambda

        def warn_msg_lambda(self, msg):
            self.warn_msg = msg

        def run_command(self, command):
            if command == '/tmp/fact_path/json.fact':
                return 0, '{"greeting": "hello world"}', ''
            elif command == '/tmp/fact_path/ini.fact':
                return 0, '[world]\ngreeting=hello', ''

# Generated at 2022-06-11 04:49:59.112350
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector.local import LocalFactCollector
    from ansible.module_utils.facts.plugins.bottle import FactModule
    from ansible.module_utils.facts.plugins.bottle import FactCollector
    from ansible.module_utils.facts.plugins.bottle import BaseFactCollector
    fact_collector = get_collector_instance(LocalFactCollector, module=FactModule)
    assert isinstance(fact_collector, BaseFactCollector)
    assert isinstance(fact_collector, FactCollector)
    assert isinstance(fact_collector, LocalFactCollector)

# Generated at 2022-06-11 04:50:01.322989
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    x = LocalFactCollector()
    # Test name
    assert x.name == 'local', "Failed to set collector name"

# Generated at 2022-06-11 04:50:09.409576
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    obj = LocalFactCollector()
    assert obj.name == 'local'
    assert obj._fact_ids == set()

# Generated at 2022-06-11 04:50:13.287971
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Pass fact_path as None to collect method to avoid creating fake fact direcory 
    # and place the test fact files
    fact_collector = LocalFactCollector()
    fact_collector.collect(fact_path=None)
    assert fact_collector.name == 'local'
    assert fact_collector._fact_ids == set()

# Generated at 2022-06-11 04:50:22.811827
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    class TestModule(object):
        def __init__(self, params):
            self.params = params
        def warn(self, message):
            pass
        def run_command(self, command):
            return 0, "", ""

    # it should return a dict with a key 'local'
    module = TestModule({'fact_path': '.'})
    result = LocalFactCollector().collect(module=module)
    assert 'local' in result

    # it should return a dict with a key 'local' on wrong fact_path
    module = TestModule({'fact_path': '/wrong/path'})
    result = LocalFactCollector().collect(module=module)
    assert 'local' in result

    # it should return a dict with values local

# Generated at 2022-06-11 04:50:23.420219
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass

# Generated at 2022-06-11 04:50:25.241021
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_obj = LocalFactCollector()
    assert local_fact_collector_obj

# Generated at 2022-06-11 04:50:25.879104
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    LocalFactCollector()

# Generated at 2022-06-11 04:50:31.727157
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    with open('module_utils/facts/apt/__init__.fact', 'w') as f:
        f.write('{"output": "foo"}')
    module = FakeModule(params=dict(fact_path="module_utils/facts/apt"))
    fact = LocalFactCollector()
    local_facts = fact.collect(module)
    assert local_facts['local']['__init__'] == {'output': 'foo'}



# Generated at 2022-06-11 04:50:34.226560
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-11 04:50:42.531065
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.utils import AnsibleModule

    test_collector = LocalFactCollector()

    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    facts = test_collector.collect(module)
    local = facts.get('local')

    # Doesn't exist, no facts should be found
    assert not local

    # Create a test file in the temp directory
    test_file = open('/tmp/test_ferret_facts.fact', 'w')
    test_file.write('{"foo": "bar", "donkey": "banana"}')
    test_file.close()

    facts = test_collector.collect(module, dict())
    local = facts.get('local')

    # Should have one fact
    assert local


# Generated at 2022-06-11 04:50:43.705667
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector(None, None)

# Generated at 2022-06-11 04:50:57.468117
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector and local_fact_collector.name == 'local'

# Generated at 2022-06-11 04:51:01.303456
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()
    local_fact_collector._set_fact_ids()
    assert 'local' in local_fact_collector._fact_ids

# Generated at 2022-06-11 04:51:06.371136
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    collect_mock = LocalFactCollector()
    collect_mock.executable_find = lambda a, b: ['python']
    collect_mock.run_command = lambda a: (0, "json_or_ini_output", None)
    output = collect_mock.collect()
    assert output['local'] == {'python': 'json_or_ini_output'}


# Generated at 2022-06-11 04:51:08.527798
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.__doc__
    assert LocalFactCollector.name == 'local'
    assert LocalFactCollector._fact_ids == set()

# Generated at 2022-06-11 04:51:09.958233
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local = LocalFactCollector()
    assert local.name == 'local'

# Generated at 2022-06-11 04:51:12.063288
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    localFactCollector = LocalFactCollector()
    assert localFactCollector.name == "local"

# Generated at 2022-06-11 04:51:12.617089
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass

# Generated at 2022-06-11 04:51:14.092469
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

    collector = LocalFactCollector()
    assert collector.name == 'local'

# Generated at 2022-06-11 04:51:15.813650
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fact_collector = LocalFactCollector()
    assert 'local' == fact_collector.name



# Generated at 2022-06-11 04:51:16.830867
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    lfc = LocalFactCollector()
    assert lfc

# Generated at 2022-06-11 04:51:42.617452
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    _module = None
    _collected_facts = None

    collector = LocalFactCollector()
    assert collector.collect(_module, _collected_facts) == dict(local={})

# Generated at 2022-06-11 04:51:50.289343
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_module = DummyModule(params={'fact_path': 'dummy_path'})
    local_module.run_command = DummyRunCommand()
    local_module.warn = lambda x: None
    collector = LocalFactCollector()
    result = collector.collect(local_module)
    assert result is not None
    assert collector.name in result
    assert 'dummy_facts' in result[collector.name]
    assert 'dummy_facts_empty' in result[collector.name]
    assert result[collector.name]['dummy_facts_empty'] is None
    assert result[collector.name]['dummy_facts'] == {'dummy_section': {'dummy_key': 'dummy_value'}}

# Dummy class for Unit test of method collect of class LocalFactCollector


# Generated at 2022-06-11 04:51:58.778725
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    class TestModule:
        def __init__(self):
            self.params = {}
            self.params['fact_path'] = '/path/to/fact'

        def warn(self, msg):
            print(msg)

        def run_command(self, cmd, check_rc=True):
            if cmd == '/path/to/fact/valid_fact.fact':
                return (0, '{"valid_fact": "valid"}', '')
            elif cmd == '/path/to/fact/invalid_fact.fact':
                return (1, '{"invalid_fact": "invalid"}', '')

# Generated at 2022-06-11 04:51:59.904105
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_facts = LocalFactCollector()
    assert local_facts.name == 'local'

# Generated at 2022-06-11 04:52:04.755314
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    FactCollector = LocalFactCollector()

    class FakeModule():
        def __init__(self):
            self.params = {
                'fact_path': '/tmp',
            }
        def run_command(self, cmd):
            pass
        def warn(self, msg):
            print(msg)

    facts = FactCollector.collect(FakeModule())
    assert facts['local'] == {}

# Generated at 2022-06-11 04:52:06.688075
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector(None, None)
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-11 04:52:07.263521
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    LocalFactCollector()

# Generated at 2022-06-11 04:52:10.923213
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Test instantiation of LocalFactCollector class
    localFactCollector = LocalFactCollector()
    assert localFactCollector.name == "local"
    assert set(localFactCollector._fact_ids) == set()

# Generated at 2022-06-11 04:52:20.017177
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Test if method collect of class LocalFactCollector can handle an unknown fact_path without raising an exception
    facts_module_mock = MagicMock()
    result = LocalFactCollector().collect(facts_module_mock)
    assert result['local'] == {}

    # Test if method collect of class LocalFactCollector can handle a fact_path without content without raising an exception
    facts_module_mock.params.get.return_value = os.path.join(os.path.dirname(__file__), '..', 'test_files', 'localfacts')
    result = LocalFactCollector().collect(facts_module_mock)
    assert result['local']['test_file'] == 'A localized test file.'

    # Test if method collect of class LocalFactCollector can handle a fact_path with a non executable file
   

# Generated at 2022-06-11 04:52:20.675505
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass

# Generated at 2022-06-11 04:53:20.557898
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import mock
    import __main__ as ansible_mod
    # create mock fact_path directory with a json file
    fn = 'test.fact'
    with open(fn, 'w') as f:
        f.write('{"test1": "my_value1"}')
    local_fact_collector = LocalFactCollector()
    ansible_mod.params = {'fact_path': '.'}
    ansible_mod.module = mock.Mock('ansible.module_utils.basic.AnsibleModule')
    ansible_facts = local_fact_collector.collect(module=ansible_mod.module)
    assert ansible_facts['local'] == {'test': {'test1': 'my_value1'}}

# Generated at 2022-06-11 04:53:23.755724
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = 'module'
    local_facts = None
    fact_path = '../../../../../unit/listparser/data/sos_facts/'
    module.params = {'fact_path': fact_path}

    LocalFactCollector('a').collect(module, local_facts)

# Generated at 2022-06-11 04:53:26.485859
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert isinstance(local_fact_collector._fact_ids, set)

# Generated at 2022-06-11 04:53:34.110299
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils import basic
    import types

    m_basic = basic.AnsibleModule(
        argument_spec = dict(
            fact_path = dict(default='/etc/ansible/facts.d/', type='path')
        )
    )
    m_basic.run_command = lambda x: (0, '{"foo": "bar"}', '')
    lfc = LocalFactCollector(m_basic)

    assert isinstance(lfc.collect(), types.DictType)
    assert 'local' in lfc.collect().keys()
    assert isinstance(lfc.collect()['local'], types.DictType)
    assert 'foo' in lfc.collect()['local'].keys()
    assert lfc.collect()['local']['foo'] == 'bar'

# Generated at 2022-06-11 04:53:35.708142
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    c = LocalFactCollector()
    assert 'local' == c.name
    assert c._fact_ids == set()


# Generated at 2022-06-11 04:53:37.320468
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    lcl = LocalFactCollector()
    assert lcl.name == 'local'
    assert lcl._fact_ids == set([])

# Generated at 2022-06-11 04:53:43.531752
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = AnsibleModule(
        argument_spec = dict(
            fact_path = dict(type='str'),
        )
    )
    fact_path = module.params.get('fact_path')
    path = os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', '..', 'test', 'integration', 'targets', 'fact_collection', fact_path)
    module.params['fact_path'] = path
    local_fact_collector = LocalFactCollector()
    local_facts = local_fact_collector.collect(module)
    return local_facts

# Generated at 2022-06-11 04:53:49.479017
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = None
    collected_facts = None
    fact_path = 'test/unit/utils/local_facts'

    collected_facts = { 'fact_path': fact_path }
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.collect(module, collected_facts) == {'local': {'fact_file': {'a': '1', 'b': '2'}, 'fact_file2': {'c': '3', 'd': '4'}, 'fact_file3': {'e': '5', 'f': '6'}}}

# Generated at 2022-06-11 04:53:56.661728
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    add_module_info = {}
    collected_facts = {}
    tmp_module = object()
    p = object()
    p.params = {'fact_path': '/tmp/facts'}
    p.run_command = lambda fn: (0, '', '')
    add_module_info['_tmp_module'] = tmp_module
    add_module_info['_tmp_module'].params = p.params
    add_module_info['_tmp_module'].run_command = p.run_command

    if __name__ == "__main__":
        collector = LocalFactCollector()
        assert collector.collect(add_module_info['_tmp_module'], collected_facts) == {'local': {}}

# Generated at 2022-06-11 04:53:58.336029
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Create an instance of LocalFactCollector
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector

# Generated at 2022-06-11 04:56:27.414908
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact = LocalFactCollector()
    assert local_fact.name == "local"

# Generated at 2022-06-11 04:56:29.342261
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_facts = {}
    local_facts['local'] = {}
    local = {}
    local_facts['local'] = local

    assert LocalFactCollector().collect() == local_facts

# Generated at 2022-06-11 04:56:32.085136
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_facts = {}
    local_facts['local'] = {}
    facts = LocalFactCollector().collect(collected_facts=local_facts)
    assert 'local' in facts
    assert isinstance(facts['local'], dict)

# Generated at 2022-06-11 04:56:33.447501
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    localFactCollector = LocalFactCollector()
    assert localFactCollector.name == 'local'

# Generated at 2022-06-11 04:56:34.891634
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    obj = LocalFactCollector()
    assert obj
    assert obj.collect() is not None


# Generated at 2022-06-11 04:56:40.125298
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.collectors.local import LocalFactCollector

    collector = LocalFactCollector()

    # test with no fact_path
    test_collected_facts = collector.collect({})
    assert test_collected_facts == {'local': {}}

    # test with fact_path
    test_module = {
        'params': {
            'fact_path': '/path/to/facts',
        },
    }
    test_collected_facts = collector.collect(test_module)
    assert test_collected_facts == {'local': {}}



# Generated at 2022-06-11 04:56:41.162999
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Test for class constructor
    local_fact_collector = LocalFactCollector()



# Generated at 2022-06-11 04:56:47.246339
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(sys.argv[0])) + '/ansible/module_utils/facts')
    from ansible.module_utils.facts import local_facts

    # Create an instance of class LocalFactCollector
    factcollector = local_facts.LocalFactCollector()
    # Create a POSIX module object
    class Module(object):
        def __init__(self):
            pass
        def run_command(self, cmd):
            return(0, 'SUCCESS', '')
        def warn(self,msg):
            print(msg)
    # Create a new module object
    module = Module()
    # Create a new localfacts dictionary
    localfacts = {}

    # Try to collect facts and load them into localfacts

# Generated at 2022-06-11 04:56:54.104865
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Test with no execution of fact
    fact_path = '/home/ansible/facts_path/'
    fact_file_name = 'facts_file.fact'
    fact_file_path = fact_path + fact_file_name
    os.makedirs(fact_path)
    fact_content = '#!/bin/sh\necho "foobar"\n'
    with open(fact_file_path, 'w') as fact_file_handler:
        fact_file_handler.write(fact_content)
    module = MagicMock()
    module.params = {'fact_path': fact_path}
    local_fact_collector = LocalFactCollector()
    local_facts = local_fact_collector.collect(module)
    assert local_facts['local']['facts_file'] == fact_

# Generated at 2022-06-11 04:56:54.780802
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'