

# Generated at 2022-06-11 04:49:26.189927
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

    local_facts = LocalFactCollector()

    assert local_facts.name == 'local'
    assert local_facts._fact_ids == set()

# Generated at 2022-06-11 04:49:26.749261
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass

# Generated at 2022-06-11 04:49:27.770303
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'

# Generated at 2022-06-11 04:49:30.378982
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fa = LocalFactCollector()
    assert fa is not None
    assert fa.name == 'local'
    assert fa._fact_ids == set()


# Generated at 2022-06-11 04:49:32.470070
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    tester = LocalFactCollector()
    assert tester.name == 'local'
    assert tester._fact_ids == set()

# Generated at 2022-06-11 04:49:34.191330
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    myobj = LocalFactCollector()
    assert myobj
    assert myobj.name == 'local'

# Generated at 2022-06-11 04:49:41.413527
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import CollectedFacts
    from ansible.module_utils.facts.system.local import LocalFactCollector

    module = CollectedFacts()
    module.params = { 'fact_path':'tests/unit/files/facts/local/'}
    local_fact_collector = LocalFactCollector()
    result = local_fact_collector.collect(module)
    assert result['local']['local_fact1'] == True
    assert result['local']['local_fact2'] == False

# Generated at 2022-06-11 04:49:44.594438
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

  # create an instance of the class to be tested
  cls = LocalFactCollector()

  # test the class name
  assert cls.name == 'local', "Class name must be 'local'"

# Generated at 2022-06-11 04:49:46.897139
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert isinstance(LocalFactCollector(), BaseFactCollector), "LocalFactCollector() object is not an instance of BaseFactCollector"

# Generated at 2022-06-11 04:49:48.301656
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_facts = LocalFactCollector()
    assert local_facts.name == 'local'

# Generated at 2022-06-11 04:49:56.084037
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-11 04:49:59.064536
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
  module = None
  collected_facts = None
  lfc = LocalFactCollector()
  output = lfc.collect(module, collected_facts)
  assert output == {'local' : {}}

# Generated at 2022-06-11 04:50:08.016210
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Load up the test fixture
    with open('test/unit/module_utils/facts/local_fixture.json') as fixture_file:
        fixture_dict = json.load(fixture_file)

    # Invoke the collect method from class LocalFactCollector
    # with the first specimen from the test fixture
    local_facts = LocalFactCollector().collect(module=fixture_dict['specimen1'].get('module'),
                                               collected_facts=fixture_dict['specimen1'].get('collected_facts'))
    # Assert that the local fact is the same as the expected value in the test fixture
    assert local_facts == {'local': fixture_dict['specimen1'].get('expected_local_facts')}

# Generated at 2022-06-11 04:50:09.824363
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert 'local' == LocalFactCollector().name
    assert {'local'} == LocalFactCollector()._fact_ids

# Generated at 2022-06-11 04:50:15.407616
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    tmpdir = os.path.dirname(os.path.abspath(__file__)) + '/fixtures/'
    fact_path = tmpdir + 'ansible_local_facts'
    module = {'params': {'fact_path': fact_path}}
    local = LocalFactCollector()
    assert local.collect(module)[u'local'][u'local_fact_file'] == u'local val'
    assert local.name == u'local'

# Generated at 2022-06-11 04:50:16.995709
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    facts = LocalFactCollector()
    assert facts.name == 'local'
    assert facts._fact_ids == set()

# Generated at 2022-06-11 04:50:26.878223
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    '''
    Class method collect of class LocalFactCollector.
    '''
    # Create a mock module
    module = AnsibleModuleMock()
    # Generate empty facts data structure
    facts = {}
    # Generate parameters for module
    params = {'fact_path': './local/'}
    # Set parameters to module
    module.params = params
    # Init instance of LocalFactCollector class
    local_fact_collector = LocalFactCollector()
    # Call method collect of LocalFactCollector class
    local_fact_collector.collect(module, facts)
    # Assert empty facts data structure
    assert facts == {'local': {}}
    # Set status of module to ok
    module.exit_json.called = True
    # Set changed status of module to False
    module.exit_json.changed

# Generated at 2022-06-11 04:50:35.642600
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # arrange

    # act
    local = LocalFactCollector()
    result = local.collect()

    # assert
    assert 'local' in result

    # arrange
    env = os.environ.copy()
    env["ANSIBLE_FACT_PATH"] = './tests/units/module_utils/facts/collectors/local/'
    cmd = "python -c 'import json; import os; local_facts={}; local_facts['local']={}; print(json.dumps(local_facts))'"

    # act
    module = AnsibleModule(command=cmd, environment=env)
    result = local.collect(module=module)

    # assert
    assert 'local' in result


# Generated at 2022-06-11 04:50:38.905644
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    """ Verify function constructor has the correct options """

    # Assert function name
    assert LocalFactCollector.name == 'local'

    # Assert function has empty set of fact_ids
    assert not LocalFactCollector._fact_ids

# Generated at 2022-06-11 04:50:44.533889
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    hostvars = {}
    module = SimpleNamespace(params={},
                             warn=lambda x: hostvars.update({"warnings": x}))
    module.run_command = lambda x: (0, 'test output', '')

    facts = LocalFactCollector(module=module).collect()
    assert facts == {'local': {'fact1': 'test output'}}
    assert hostvars == {}

# Generated at 2022-06-11 04:51:05.306922
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Test a fact with a non-zero exit code
    python = '#!/usr/bin/python\nimport sys\nsys.exit(1)'
    with open('/tmp/fact.py', 'w') as f:
        f.write(python)
    os.chmod('/tmp/fact.py', 0o755)

    # Test a fact with invalid JSON
    json = '{"invalid_json": "true'
    with open('/tmp/fact.json', 'w') as f:
        f.write(json)

    module = MockAnsibleModule()

    # The path does NOT exist, so there should be no facts.
    fact_collector = LocalFactCollector()
    facts = fact_collector.collect(module=module)
    assert len(facts) == 0

    # Create the path, so

# Generated at 2022-06-11 04:51:08.248226
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert hasattr(LocalFactCollector, 'collect')
    assert hasattr(LocalFactCollector, 'name')
    f = LocalFactCollector()
    assert f
    assert f.name == 'local'

# Generated at 2022-06-11 04:51:17.237503
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector.local import LocalFactCollector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import get_file_content
    facts_file = {
        'fact_path': 'modules/module_utils/facts'
    }
    localFactCollector = LocalFactCollector()
    localFactCollector.collect(facts_file)
    assert type(localFactCollector.collect(facts_file)) is dict
    assert localFactCollector.collect(facts_file)['local']['facter'] == get_file_content(to_bytes('modules/module_utils/facts/facter.fact'), default='')

# Generated at 2022-06-11 04:51:18.789012
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fc = LocalFactCollector()
    assert fc.name == 'local'

# Generated at 2022-06-11 04:51:20.609229
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    fact_collector = LocalFactCollector()
    fact_collector.collect()


# Generated at 2022-06-11 04:51:22.132845
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-11 04:51:24.158347
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    localFactCollector = LocalFactCollector()
    assert localFactCollector.collect() == {'local': {}}

# Generated at 2022-06-11 04:51:31.894562
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    module = MockModule()
    fact_path = './test/units/module_utils/facts/collector/local_facts'
    module.params.update({'fact_path': fact_path})
    lf = LocalFactCollector(module)
    local_facts = lf.collect()
    assert len(local_facts) == 1 and local_facts.get('local') is not None
    local = local_facts.get('local')
    assert len(local) == 3
    assert local.get('test1.fact') == 'test'
    assert local.get('test2.sh') == 'test'
    assert local.get('test3.fact') == 'test'


# Generated at 2022-06-11 04:51:34.639322
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Given
    # When
    local_fact_collector = LocalFactCollector()

    # Then
    assert local_fact_collector.name == "local"
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-11 04:51:36.166041
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    l = LocalFactCollector()
    assert l.name == "local"


# Generated at 2022-06-11 04:52:01.477147
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # pylint: disable=import-error
    from ansible.module_utils.facts.collector.local import LocalFactCollector

    pass

# Generated at 2022-06-11 04:52:07.662917
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = MockModule(params={'fact_path': os.path.join(os.path.dirname(__file__), 'files')})
    obj = LocalFactCollector()
    ret = obj.collect(module=module, collected_facts=None)
    assert ret == {'local': {u'key1': {u'key2': u'value2', u'key1': u'value1'}, u'json_file': {u'key1': u'value1', u'key2': u'value2'}}}


# Generated at 2022-06-11 04:52:08.970593
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_facts = LocalFactCollector()
    assert local_facts.name == "local"

# Generated at 2022-06-11 04:52:18.964643
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    localFactCollector = LocalFactCollector()
    import os
    import stat
    import sys

    # creating a temporary directory
    import tempfile
    tempdir = tempfile.mkdtemp()

    # creating a temporary file
    tempFile = tempfile.NamedTemporaryFile(dir=tempdir)

    # writing to the temporary file
    tempFile.write("""
[first]
a = 1
b = 2
[second]
c = 3
""".encode("utf-8"))

    # moving the file pointer to the beginning of the file
    tempFile.seek(0)

    # setting mode executable
    os.chmod(tempFile.name, stat.S_IXUSR)

    # getting the absolute file path
    filename = os.path.abspath(tempFile.name)

    # getting the name of

# Generated at 2022-06-11 04:52:20.276869
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert isinstance(LocalFactCollector(), BaseFactCollector)

# Generated at 2022-06-11 04:52:21.660193
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert isinstance(LocalFactCollector(), LocalFactCollector)

# Generated at 2022-06-11 04:52:26.685859
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Can be tested as long as there is a script/file named ansible_local.fact in fact_path
    #   with a valid json format or a ini config file format
    module = None
    fact_path = os.path.dirname(__file__)
    local_fact = LocalFactCollector(module, fact_path=fact_path)
    assert isinstance(local_fact, LocalFactCollector)

# Generated at 2022-06-11 04:52:28.202460
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-11 04:52:38.722290
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_facts = {'ansible_local': {'fact_base': 'fact'}}
    module = MagicMock()
    module.params = {'fact_path': 'test'}
    module.run_command = MagicMock()
    module.run_command.return_value = (0, '{ "fact": "test" }', '')
    module.warn = MagicMock()
    glob.glob = MagicMock()
    glob.glob.return_value = ['test/fact_base.fact']
    os.stat = MagicMock()
    os.stat.return_value = stat.S_IXUSR
    get_file_content = MagicMock()
    get_file_content.return_value = MagicMock()
    local_fact_collector = LocalFactCollector()
    assert local

# Generated at 2022-06-11 04:52:41.159539
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector is not None

# Generated at 2022-06-11 04:53:38.289605
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    assert True

# Generated at 2022-06-11 04:53:42.761187
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create the base class object
    BaseFactCollector_obj = BaseFactCollector()

    # Setup the arguments
    BaseFactCollector_obj.facts = {}
    BaseFactCollector_obj.module = ''

    # Create the LocalFactCollector object for testing
    LocalFactCollector_obj = LocalFactCollector(BaseFactCollector_obj)
    # Unit test for method collect of class LocalFactCollector
    LocalFactCollector_obj.collect()

# Generated at 2022-06-11 04:53:44.726192
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # LocalFactCollector(module_executor)
    MF = LocalFactCollector()

    assert MF.name == 'local'
    assert MF._fact_ids == set()

# Generated at 2022-06-11 04:53:46.012771
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector().name == 'local'
    assert LocalFactCollector()._fact_ids == set()

# Generated at 2022-06-11 04:53:53.723282
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible_collections.netapp.ontap.tests.unit.compat.mock import patch
    from ansible_collections.netapp.ontap.plugins.modules import na_ontap_facts

    with patch.object(na_ontap_facts.AnsibleModule, 'run_command') as mock_run_command:
        with patch('os.path.exists', return_value=True):
            mock_run_command.return_value = (0, "", "")
            module_args = dict()
            module_args.update(
                {
                    "hostname": "test",
                    "username": "test",
                    "password": "test",
                    "fact_path": "/netapp/ansible/facts"
                }
            )

            module = na_ontap_facts.NetAppOntap

# Generated at 2022-06-11 04:53:54.707911
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    LocalFactCollector()


# Generated at 2022-06-11 04:54:02.626835
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    # import modules used by LocalFactCollector
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import FACT_CACHE
    from ansible.module_utils.facts.utils import get_file_content

    # import needed modules
    import os
    import shutil
    import tempfile
    import unittest.mock as mock

    # set up temp dir
    temp_dir = tempfile.mkdtemp()

    def _touch(path):
        '''touch a file'''
        with open(path, 'a'):
            os.utime(path, None)

    # make a temp test fact file

# Generated at 2022-06-11 04:54:05.296570
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """
    Test case for method collect of class LocalFactCollector
    """
    print("test_LocalFactCollector_collect")
    collector = LocalFactCollector()
    result = collector.collect()
    print(result)
    assert result

# Generated at 2022-06-11 04:54:13.694081
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """ Unit test for method collect of class LocalFactCollector on a fake fact path"""
    from ansible.module_utils._text import to_bytes
    import tempfile
    import shutil
    from ansible.module_utils.facts import get_module_path
    from ansible.module_utils.basic import AnsibleModule

    m_path = os.path.join(get_module_path(), '..')
    f_path = tempfile.mkdtemp()
    test_file = os.path.join(f_path, 'test.fact')
    test_file2 = os.path.join(f_path, 'test2.fact')
    test_file3 = os.path.join(f_path, 'test3.fact')

# Generated at 2022-06-11 04:54:19.368934
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    items = [{'ansible_distribution': 'Fedora', 'ansible_distribution_version': '28'},
             {'ansible_distribution': 'Fedora', 'ansible_distribution_version': '28', 'ansible_local': {'systemd_facts': {'test_key': 'test_value'}}},
             {'ansible_distribution': 'Fedora', 'ansible_distribution_version': '28', 'ansible_local': {'systemd_facts': {'test_key': 'test_value'}}},
             {'ansible_distribution': 'Fedora', 'ansible_distribution_version': '28', 'ansible_local': {'systemd_facts': {'test_key': 'test_value'}}}
             ]
    unit = LocalFactCollector()
    results

# Generated at 2022-06-11 04:56:42.958987
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    res = local_fact_collector.collect()
    assert isinstance(res, dict)

# Generated at 2022-06-11 04:56:44.328545
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_collector = LocalFactCollector()
    assert local_collector.name == 'local'
    assert local_collector._fact_ids == set()

# Generated at 2022-06-11 04:56:47.246341
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = MockAnsibleModule()
    local_fact_collector = LocalFactCollector()

    local_fact_collector.collect(module)
    content = get_file_content(module.params['fact_path']+'/local_facts.fact')

    assert content == '{"test":1,\n"test2":2}'

# Generated at 2022-06-11 04:56:47.883901
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    # TODO: Implement unit test
    return

# Generated at 2022-06-11 04:56:54.804925
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    # create a LocalFactCollector instance
    local_fact_collector = LocalFactCollector()

    # generate the mock data
    fact_path = "local_facts"

    # create a list of the mock data
    module_list = []
    mock_module = {}
    mock_module['params'] = {}
    mock_module['params']['fact_path'] = fact_path
    mock_module['warn'] = None
    mock_module['run_command'] = None
    module_list.append(mock_module)

    # create a list of the mock data
    collected_facts_list = []
    mock_collected_facts = {}
    mock_collected_facts['local'] = {}
    collected_facts_list.append(mock_collected_facts)

    # test the method collect and assert the results

# Generated at 2022-06-11 04:56:58.707287
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_facts_collector = LocalFactCollector()
    module_params = {}
    fact_path = os.path.dirname(os.path.realpath(__file__)) + '/../../lib/ansible/module_utils/facts/local_facts_fact_files/'
    module_params['fact_path'] = fact_path
    local_facts = local_facts_collector.collect(module_params)
    assert local_facts['local']['text']['text1'] == 'value1'

# Generated at 2022-06-11 04:57:01.003422
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
  # Test creating a LocalFactCollector instance
  instance = LocalFactCollector()
  # Test name of class
  assert instance.name == "local"
  # Test name of class
  assert set([]).issubset(instance._fact_ids) == True


# Generated at 2022-06-11 04:57:01.658874
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    obj = LocalFactCollector()
    assert obj.name == 'local'

# Generated at 2022-06-11 04:57:03.137051
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    obj = LocalFactCollector()
    assert isinstance(obj, BaseFactCollector)
    assert isinstance(obj.name, object)
    assert isinstance(obj.priority, object)
    assert isinstance(obj.collect, object)

# Generated at 2022-06-11 04:57:05.239853
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    mock_module = MockModule()
    mock_module.params = {}
    mock_module.params["fact_path"] = "./facts/test/facts_collector/local_facts"
    collector = LocalFactCollector()