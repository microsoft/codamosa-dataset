

# Generated at 2022-06-20 19:32:41.606549
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = MockModule()
    fact_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'fixtures')
    module.params = {
        'fact_path': fact_path
    }
    module.warn = MockModule.warn

    expected = {'local': {'fact': 'value', 'json': {'json_fact': 'json_value'}}}
    collector = LocalFactCollector(module=module)
    assert collector.collect() == expected, 'LocalFactCollector.collect() does not return facts from local fact directory content'


# Generated at 2022-06-20 19:32:44.241241
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.__doc__

# Generated at 2022-06-20 19:32:47.154011
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Statement coverage yet !!!
    c = LocalFactCollector()
    assert c.name == 'local'
    assert c._fact_ids == set()


# Generated at 2022-06-20 19:32:49.115594
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-20 19:32:56.092692
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # test_collect_empty_fact_path
    local_collector = LocalFactCollector()
    local_facts = local_collector.collect(module=None, collected_facts=None)
    assert local_facts['local'] == {}
    # test_collect_non_existing_fact_path
    local_collector = LocalFactCollector()
    local_facts = local_collector.collect(module=dict(params=dict(fact_path='non_existing')), collected_facts=None)
    assert local_facts['local'] == {}


# Generated at 2022-06-20 19:33:00.363392
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local = LocalFactCollector()
    
    if not isinstance(local.collect(), dict):
        assert False
    

# Generated at 2022-06-20 19:33:02.560689
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    localcollector = LocalFactCollector()
    assert localcollector.name == 'local'
    assert localcollector._fact_ids == set()

# Generated at 2022-06-20 19:33:04.034017
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    assert True

# Generated at 2022-06-20 19:33:05.472293
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert(BaseFactCollector.__subclasshook__(LocalFactCollector))

# Generated at 2022-06-20 19:33:17.092236
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import types
    import unittest

    if not hasattr(unittest.TestCase, 'assertIsInstance'):
        unittest.TestCase.assertIsInstance = lambda self, a, b: self.assertTrue(isinstance(a, b))
    if not hasattr(unittest.TestCase, 'assertDictEqual'):
        unittest.TestCase.assertDictEqual = lambda self, a, b: self.assertDictContainsSubset(a, b)

    class ModuleMock(object):
        def __call__(self, *args, **kwargs):
            if not hasattr(self, '_result'):
                self._result = {}

            self._result.update(kwargs)

            if hasattr(self, '_ansible_facts'):
                return self._ansible

# Generated at 2022-06-20 19:33:24.517844
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    r = LocalFactCollector().collect()
    assert r['local'] == {}

# Generated at 2022-06-20 19:33:26.475707
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    """Unit test of LocalFactCollector"""
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector != None

# Generated at 2022-06-20 19:33:34.580288
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    '''class LocalFactCollector: collect method'''
    import os
    import tempfile
    from ansible.module_utils.facts.collector import AnsibleModule

    _, fn1 = tempfile.mkstemp(prefix='ansible_tmp', suffix='.fact')
    _, fn3 = tempfile.mkstemp(prefix='ansible_tmp', suffix='.fact')
    _, fn2 = tempfile.mkstemp(prefix='ansible_tmp', suffix='.fact')

    os.chmod(fn1, 0o700)
    with open(fn1, 'w') as f:
        f.write("#!/bin/sh\necho '{\"hello\":\"world\"}'\n")

# Generated at 2022-06-20 19:33:35.330043
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    assert True

# Generated at 2022-06-20 19:33:41.194740
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fact_path = '/etc/ansible/facts.d'
    params = {}
    params['fact_path'] = fact_path
    module = {}
    module['params'] = params
    module['run_command'] = run_command

    localFactCollector = LocalFactCollector(module)
    localFactCollector.collect()


# Generated at 2022-06-20 19:33:43.416312
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fc = LocalFactCollector()
    assert fc.name == 'local'
    assert LocalFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:33:45.845426
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    """
    This function is used for test the constructor of class LocalFactCollector.
    """
    fact_collector = LocalFactCollector()
    assert fact_collector.name == 'local'


# Generated at 2022-06-20 19:33:57.588582
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Creating a dummy module and dummy config
    module = 'dummymodule'
    config = 'dummyconfig'
    fact_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'unit', 'ansible', 'facts', 'fact_path')

    # Creating dummy LocalFactCollector
    fc = LocalFactCollector(module=module, config=config)
    fc.module.params['fact_path'] = fact_path

    # Checking that returned result is correct
    result = fc.collect()
    expected_result = {'local': {'test_fact_2': 'the fact file is executable and returns JSON', 'test_fact_1': 'the fact file contains JSON'}}
    assert result == expected_result

# Generated at 2022-06-20 19:33:58.923809
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    result = None
    assert result == 'foo'

# Generated at 2022-06-20 19:34:10.491817
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collectors.local import LocalFactCollector

    class TestModule(object):
        def __init__(self):
            self.params = {'fact_path': '/home/ansible_user/facts'}
    class TestRunCommand(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err
    class TestFacts(object):
        def __init__(self):
            self.iteritems = lambda: [('ansible_local', {})]
        def __setitem__(self, key, value):
            pass


# Generated at 2022-06-20 19:34:31.406992
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    my_collector = Collector.fetch_collector('local')
    assert isinstance(my_collector, LocalFactCollector)
    my_local_facts = {'local': {'fact1': 'value1'}}
    assert my_local_facts == my_collector.collect()
    assert {'local': {}} == my_collector.collect({})
    assert {'local': {}} == my_collector.collect({'params': {}})
    assert {'local': {}} == my_collector.collect({'params': {'fact_path': ''}})
    assert {'local': {}} == my_collector.collect({'params': {'fact_path': None}})

# Generated at 2022-06-20 19:34:31.787133
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    pass

# Generated at 2022-06-20 19:34:34.375787
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    lfc = LocalFactCollector()
    assert isinstance(lfc, LocalFactCollector)
    assert not lfc._fact_ids

# Generated at 2022-06-20 19:34:44.463699
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = mock_module()
    fact_path = module.params['fact_path']
    if not os.path.exists(fact_path):
        os.makedirs(fact_path)
    fact = '{"a":1}'
    fact_path_with_file = os.path.join(fact_path, '1.fact')
    with open(fact_path_with_file, 'w') as file_handler:
        file_handler.write(fact)

    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    local_facts = local_fact_collector.collect(module, None)
    assert local_facts == {'local': {'1': fact}}


# Generated at 2022-06-20 19:34:55.727154
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """This is used in test_local.py to test method collect of class LocalFactCollector.

    Args:
        fixture_path: The absolute path to the fixture file.
        test_type: The test type which can be load_facts, load_facts_file_facts, load_facts_file_backup_facts.
    """
    if os.path.exists('/etc/ansible/facts.d'):
        fact_path = '/etc/ansible/facts.d'
    elif os.path.exists('/etc/ansible/facts'):
        fact_path = '/etc/ansible/facts'
    else:
        return {}

    local_facts = {}
    module = None
    collected_facts = None
    local_collector = LocalFactCollector()
    facts = local_collector.collect

# Generated at 2022-06-20 19:34:58.691470
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == "local"
    assert local_fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:35:00.841659
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert isinstance(local_fact_collector, LocalFactCollector)


# Generated at 2022-06-20 19:35:03.742546
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    '''
    Test constructor of the LocalFactCollector class
    '''
    x = LocalFactCollector()
    assert x.name == 'local'
    assert x._fact_ids == set()

# Generated at 2022-06-20 19:35:05.664546
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    c = LocalFactCollector()
    assert c.name == 'local'
    assert c._fact_ids == set()


# Generated at 2022-06-20 19:35:17.443720
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    '''
    Test function to determine LocalFactCollector.collect()
    '''

    import collections
    import json
    import os
    import shutil
    import stat
    import sys
    import tempfile
    import unittest

    # set up temp directory
    temp_dir = tempfile.mkdtemp()


# Generated at 2022-06-20 19:35:43.651776
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector() 
    assert local_fact_collector is not None

# Generated at 2022-06-20 19:35:44.940432
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert isinstance(LocalFactCollector(), LocalFactCollector)

# Generated at 2022-06-20 19:35:50.907035
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import sys
    import tempfile
    if sys.version_info[0] == 2:
        import ConfigParser as configparser
    else:
        import configparser

    def mock_module(ansible_module):
        from ansible.module_utils.facts.collector import AnsibleModule
        return ansible_module(AnsibleModule)

    # create a temporary directory to hold test facts
    tmp_fact_path = tempfile.mkdtemp()

    # create test facts
    os.mkdir(tmp_fact_path + "/executable")

    with open(tmp_fact_path + '/' + "executable" + '/' + "fact1.fact", 'w') as f:
        f.write('#!/bin/sh\n')
        f.write('echo plain=noplain')


# Generated at 2022-06-20 19:36:02.133561
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts import facts_module
    from ansible.module_utils.facts.collector.local import LocalFactCollector

    fixture = dict(
        ansible_python_interpreter='/usr/bin/python',
        ansible_facts=dict(ansible_distribution='Ubuntu'),
        ansible_os_family='Debian'
    )
    collected_facts = Facts(fixture)

    # Testing with a simple facts script
    fact_path = os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'units', 'module_utils', 'facts', 'files', 'fact_collector', 'local')

# Generated at 2022-06-20 19:36:11.309148
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    class UtModule(object):
        def __init__(self, params):
            self.params = params
            self.warn = lambda x: None

        def run_command(self, cmd):
            if cmd == 'local_fact_1':
                return 0, '{"test": "value"}', ''
            elif cmd == 'local_fact_2':
                return 0, '{"test": "value"}', ''
            else:
                return 1, '', 'it failed'

    local_fact_collector = LocalFactCollector()
    module = UtModule({'fact_path': './local_facts_dir'})
    local_facts = local_fact_collector.collect(module)

# Generated at 2022-06-20 19:36:22.761685
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # set up fake module, is_collector_enabled, and collector
    import types
    module = types.ModuleType('ansible.module_utils.facts.local')
    module.params = {'fact_path': 'FAKE_FACTS_PATH'}
    module.warn = lambda s: print(s)
    module.run_command = lambda s: ('0', 'FAKE_FACT_CONTENT\n', '')
    def run_is_collector_enabled():
        pass
    module.is_collector_enabled = run_is_collector_enabled
    collector = LocalFactCollector()

    # create fake files in FAKE_FACTS_PATH
    import tempfile
    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-20 19:36:29.706498
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    m = AnsibleModuleMock()
    m.params = {'fact_path': 'test/units/modules/utils/ansible_local_facts/'}
    lfc = LocalFactCollector()
    result = lfc.collect(module=m)
    assert result == {'local': {'fact1': {'a': '3', 'c': '1', 'b': '2'}, 'fact3': 'fact3', 'fact2': {'a': '1', 'b': '2'}}}

# Generated at 2022-06-20 19:36:36.518828
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.facts import FactCache
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.six import PY2

    # create a fact path
    fact_path = '/tmp/local_setup_facts.d'
    os.mkdir(fact_path)

    # setup a fact to run
    fact_file = fact_path + '/testrunme.fact'
    output = '{"hello":"world"}'
    with open(fact_file, 'w') as f:
        f.write(output)

# Generated at 2022-06-20 19:36:39.801084
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    lfc = LocalFactCollector()
    assert lfc.name == 'local'
    assert isinstance(lfc.collect(), dict)

# Generated at 2022-06-20 19:36:40.411714
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    pass

# Generated at 2022-06-20 19:37:46.185434
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts import ModuleParameters
    from ansible.module_utils.facts.compat import mock

    module_mock = mock.MagicMock(spec=ModuleParameters)
    module_mock.params = {'fact_path': './mock_dir'}

    local_fact_collector = get_collector_instance('local', module_mock)
    local = local_fact_collector.collect()
    assert len(local.keys()) == 1
    assert 'local' in local.keys()
    assert local['local'] == dict()

# Generated at 2022-06-20 19:37:52.754048
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """
    Return a list of collected local facts if fact_path exists.
    """
    module = AnsibleModuleMock(params={'fact_path': '/home/ansible/'})
    localFactCollector = LocalFactCollector()
    assert localFactCollector.collect(module) == {}

    module = AnsibleModuleMock(params={'fact_path': '/tmp/'})
    assert localFactCollector.collect(module) == {'local': {}}

    localFactCollector._fact_ids = set(['local'])
    module = AnsibleModuleMock(params={'fact_path': '/home/ansible/'})
    assert localFactCollector.collect(module) == {}

    module = AnsibleModuleMock(params={'fact_path': '/tmp/'})
    assert localFactCollector.collect

# Generated at 2022-06-20 19:38:01.680997
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # creating a skeleton ansible module
    class ModuleStub:
        _ansible_ignore_errors = False
        params = {}

    # creating a skeleton ansible module result
    class AnsibleModuleResult:
        def __init__(self):
            self.warnings = []
            self.rc = 0

    # creating a stub for module
    module = ModuleStub()

    # creating the collector
    # in order to be able to test the collector we need to initialize the module
    # params, because the collector is initialized from the module
    module.params['fact_path'] = "/tmp/testing"
    module.params['gather_local_facts'] = True
    fact_collector = LocalFactCollector()

    # creating a stub for module.run_command
    # here we return always (0, "", "")

# Generated at 2022-06-20 19:38:03.468900
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_facts = LocalFactCollector()
    assert local_facts.name == 'local'

# Generated at 2022-06-20 19:38:12.884601
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    fake_module = 'fake_module'
    fake_path = 'fake_path'

    class TestLocalFactCollector(LocalFactCollector):
        def __init__(self):
            self.glob_mock = None
            self.stat_mock = None
            self.os_mock = None
            self.mock_run_command = None
            self.mock_get_file_content = None
            self.mock_warn = None

        def fake_glob(self, p):
            return self.glob_mock

        def fake_stat(self, p):
            return self.stat_mock

        def fake_os(self, p):
            return self.os_mock

        def fake_run_command(self, p):
            return self.mock_run_command

       

# Generated at 2022-06-20 19:38:23.566339
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    arg1 = {'ansible_facts': {}, 'ansible_check_mode': False, 'ansible_module_name': 'Test', 'module_name': 'Test', 'module_args': {'fact_path': '/tmp'}, 'ansible_version': {'full': 'hello', 'date': '2016-11-23', 'major': 2, 'revision': 0, 'minor': 5, 'string': '2.5.0'}, 'changed': False, 'ansible_module_args': {'fact_path': '/tmp'}, 'ansible_module_set_locale': True}

# Generated at 2022-06-20 19:38:36.174149
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import os
    from ansible.module_utils._text import to_native
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.compat.tests.mock import patch, MagicMock
    from ansible.module_utils.facts.collector import BaseFactCollector
    localfactcollector = LocalFactCollector()
    localfactcollector.name = 'local'
    localfactcollector._fact_ids = set()
    localfactcollector._cache = {}
    fact_path = ['/path1','/path2']
    module = MagicMock()
    module.params = {}
    module.params['fact_path'] = fact_path
    module.run_command = MagicMock()
    module.run_command.return_value = (0, '', '')
   

# Generated at 2022-06-20 19:38:44.804965
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    '''
    Unit test for method collect of class LocalFactCollector
    '''

    # Test case 1: check success
    result = dict()
    result['local'] = dict()
    result['local']['ansible'] = {'version': {'full': '2.9.6', 'version': 2, 'minor': 9, 'build': '1', 'revision': 0}, 'executable': '/usr/local/bin/ansible'}
    result['local']['not_json'] = '''
[Section1]
foo = bar
'''

    collector = LocalFactCollector()
    module_params = dict()

# Generated at 2022-06-20 19:38:48.252568
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module_mock = FakeModule({'fact_path': '/tmp'})

    l = LocalFactCollector()
    facts = l.collect(module_mock)

    assert facts == {u'local': {}}


# Generated at 2022-06-20 19:38:57.239965
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import sys
    import os

    # set python path to utils dir so we can run individual classes as a script
    sys.path.append(os.path.join(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."), ".."))
    from ansible.module_utils.facts.collector import BaseFactCollector

    fact_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'unit', 'data', 'local_facts')

    module = BaseFactCollector()
    module.params = {'fact_path': fact_path}
    results = LocalFactCollector().collect(module)

    assert results != {}
    assert len(results['local']) != 0

# Generated at 2022-06-20 19:41:23.634146
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    lf = LocalFactCollector()
    assert lf.name == 'local'
    assert lf._fact_ids == set()

# Generated at 2022-06-20 19:41:34.264653
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

    module = MockModule()
    module.params['fact_path'] = 'mypath'

    fact = MockFactCollector()
    fact._fact_ids = set()

    # Test 1
    #isinstance(fact, LocalFactCollector)
    #success
    assert(isinstance(fact, LocalFactCollector))

    # Test 2
    #isinstance(fact, BaseFactCollector)
    #success
    assert(isinstance(fact, BaseFactCollector))

    # Test 3
    #isinstance(fact, FactCollector)
    #success
    assert(isinstance(fact, FactCollector))

    # Test 4
    #if os.path.exists(module.params

# Generated at 2022-06-20 19:41:35.953879
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    lf = LocalFactCollector(None)
    lf.collect()

# Generated at 2022-06-20 19:41:41.015712
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    #################################
    # Run tested method
    #################################
    result = LocalFactCollector().collect()

    #################################
    # Assert
    #################################
    assert isinstance(result, dict)
    assert result.get('local')
    assert isinstance(result.get('local'), dict)

# Generated at 2022-06-20 19:41:45.353576
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = None
    collected_facts ={'local': {'test': '23'}}
    # create instance of LocalFactCollector
    local = LocalFactCollector()
    test_fact_path = 'ansible/test/unit/module_utils/facts/test_local/test_collect/test'
    # call method collect
    result = local.collect(module, collected_facts, fact_path=test_fact_path)
    # check result
    assert result == {'local': {'test': {'test': '23'}}}

# Generated at 2022-06-20 19:41:48.762704
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Test 1
    # '_fact_ids' is not a class attribute
    module = LocalFactCollector()
    assert module.name == 'local'
    assert module._fact_ids is None

# Generated at 2022-06-20 19:41:51.807553
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == "local"
    assert len(local_fact_collector._fact_ids) == 0
    assert isinstance(local_fact_collector._fact_ids, set)


# Generated at 2022-06-20 19:42:00.843237
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    test_module = MockModule(params={})
    test_module.run_command = lambda x, data=None: (0, "some_output", "")
    test_module.warn = lambda x: None
    test_module.params['fact_path'] = '/tmp'

    # empty fact_path
    test_collector = LocalFactCollector(test_module)
    assert {} == test_collector.collect()

    # no executable fact files, no fact file
    fact_path = '/tmp'
    test_collector = LocalFactCollector(test_module)
    assert {} == test_collector.collect()
    os.mkdir(fact_path)
    test_collector = LocalFactCollector(test_module)
    assert {} == test_collector.collect()

# Generated at 2022-06-20 19:42:07.553380
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Inputs
    fixture_path = os.path.join(os.path.dirname(__file__), 'fixtures')
    module = FakeModule(params={'fact_path': fixture_path})
    # Optionally set the requested attribute
    # Execute the method
    result = LocalFactCollector().collect(module)
    # Produce the 'expected' output
    expected = {'local': {'output': 'success', 'error_ignored': 'error loading fact - output of running "error" was not utf-8'}}
    # Compare the actual result with the expected output
    assert result == expected



# Generated at 2022-06-20 19:42:08.389107
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass
