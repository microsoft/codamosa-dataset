

# Generated at 2022-06-20 19:32:43.890888
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    class TestModule():
        params = dict(fact_path="/tmp/test_dir")

        def run_command(self, cmd):
            if "script1" in cmd:
                return 0, "script1out", "script1err"
            elif "script2" in cmd:
                return 1, "script2out", "script2err"
            elif "script3" in cmd:
                return 0, "script3out", "script3err"
            elif "script4" in cmd:
                return 1, "script4out", "script4err"
            elif "script5" in cmd:
                return 0, "script5out", "script5err"
            elif "script6" in cmd:
                return 1, "script6out", "script6err"

        def warn(self, msg):
            print

# Generated at 2022-06-20 19:32:47.664550
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_facts = LocalFactCollector()
    assert local_facts.name == 'local', "Name of LocalFactCollector should be 'local'"
    assert local_facts.collect() == {'local': {}}, 'Collector should return empty dict'

# Generated at 2022-06-20 19:32:49.757206
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-20 19:32:53.632370
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert not local_fact_collector._fact_ids

# Generated at 2022-06-20 19:32:54.891389
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector

# Generated at 2022-06-20 19:32:57.277827
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact = LocalFactCollector()
    assert local_fact.name == 'local'



# Generated at 2022-06-20 19:33:03.577239
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Test for ansible.module_utils.facts.local.LocalFactCollector.collect
    # Test for ansible.module_utils.facts.local.LocalFactCollector.collect: #1
    # Test for ansible.module_utils.facts.local.LocalFactCollector.collect: #2
    # Test for ansible.module_utils.facts.local.LocalFactCollector.collect: #3
    pass

# Generated at 2022-06-20 19:33:07.261481
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    path = os.path.dirname(__file__)
    mod = None
    # Create an object of LocalFactCollector class
    obj = LocalFactCollector(module=mod, fact_path=path)

# Generated at 2022-06-20 19:33:09.343330
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'
    assert LocalFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:33:11.363724
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_collector = LocalFactCollector()
    assert local_collector.name == 'local'

# Generated at 2022-06-20 19:33:19.537219
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    module = AnsibleModule(argument_spec={})
    collector = LocalFactCollector(module)
    assert collector.name == 'local'

# Generated at 2022-06-20 19:33:21.109869
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
  lfc = LocalFactCollector()
  assert lfc.name == 'local'
  assert not lfc._fact_ids

# Generated at 2022-06-20 19:33:31.466380
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # setup test
    LFC = LocalFactCollector()
    module = FakeModule()
    module.params = {}

    # test with a fact_path
    module.params['fact_path'] = 'tests/fake_facts'
    ansible_facts = LFC.collect(module)
    assert ansible_facts['local']['a']['b'] == 'c'
    assert ansible_facts['local']['b'] == 'c'
    assert ansible_facts['local']['c'] == '%s/tests/fake_facts/local/c' % os.getcwd()
    assert ansible_facts['local']['d'] == 'e'

    # test with a non existent fact_path
    module.params['fact_path'] = 'none existent'
    ansible_facts = L

# Generated at 2022-06-20 19:33:34.185708
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local = LocalFactCollector()
    assert local.name == 'local'
    assert local._fact_ids == set()

# Generated at 2022-06-20 19:33:44.937104
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # fixtures
    mock_module = MockModule()
    mock_facts = {}

    mock_module.params = {'fact_path' : '/home/ansible/facts'}

    expected_result = dict()
    expected_result['local'] = {'content': 'test'}

    # mocks
    mock_module.run_command = Mock(return_value=(1, 'test', 'test_err'))

    # test
    local_fact_collector = LocalFactCollector()
    result_local_facts = local_fact_collector.collect(mock_module, mock_facts)

    # assert
    assert expected_result == result_local_facts
    mock_module.run_command.assert_called_with(mock_module.params['fact_path'] + '/*.fact')


# Generated at 2022-06-20 19:33:51.680775
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import os
    import shutil
    import tempfile
    import json

    # create a temporary fact_path with fact files
    fact_path = tempfile.mkdtemp()

# Generated at 2022-06-20 19:33:53.607152
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass



# Generated at 2022-06-20 19:33:59.058603
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """
    Test method collect of class LocalFactCollector
    """
    # Initialize the collector object
    local_fact_collector = LocalFactCollector()

    # Test with empty module
    expected_result = {'local': {}}
    result = local_fact_collector.collect()

    assert result == expected_result

    # Test with non-empty module
    # TODO: add test here

# Generated at 2022-06-20 19:34:04.257405
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector.local import LocalFactCollector

    ac = LocalFactCollector()
    check_value = ac._fact_ids

    assert isinstance(check_value, set)
    assert check_value == set()

    assert ac._name == 'local'

# Generated at 2022-06-20 19:34:12.128282
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    local_fact_collector = LocalFactCollector()

    class FakeModule(object):

        def __init__(self):
            self.params = dict(fact_path='/home/ansible/test')

        def run_command(self, command):
            return 0, '{"test": "fact"}', ''

        def warn(self, *args, **kwargs):
            pass

    module = FakeModule()

    local_facts = local_fact_collector.collect(module=module)

    assert local_facts == {'local': {'test': {'test': 'fact'}}}

# Generated at 2022-06-20 19:34:29.367634
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    result = dict(changed=False, ansible_facts=dict(local=dict(fact1=1, fact2=2)))
    result['ansible_facts']['local']['test_fact'] = dict(value=42)
    result['ansible_facts']['local']['test_ini_fact'] = dict(section=dict(key='value'))
    result['ansible_facts']['local']['test_json_fact'] = dict(key='value')
    result['ansible_facts']['local']['test_fact_script'] = 'test stdout'
    result['ansible_facts']['local']['test_fact_script_err'] = 'test stderr'
    result['ansible_facts']['local']['test_fact_script_rc'] = 1

# Generated at 2022-06-20 19:34:36.082557
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = None
    collected_facts = None
    fact_path = os.path.abspath(__file__).replace(__file__, './local_fact')
    x = LocalFactCollector()
    res = x.collect(module, collected_facts, fact_path=fact_path)
    assert(res == {'local': {'a': {'b': 'c'}, 'd': 'e'}})

# Generated at 2022-06-20 19:34:47.269661
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # use module_utils to mock ansible.module_utils.basic.AnsibleModule
    import sys
    import ansible.module_utils.basic
    from ansible.module_utils.facts import collector
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector
    ansible.module_utils.basic.AnsibleModule = MockAnsibleModule
    # use sys to mock the necessary attributes for module_utils.basic.AnsibleModule
    sys.modules['ansible.module_utils.basic'] = ansible.module_utils.basic
    sys.modules['ansible.module_utils.facts.collector'] = collector
    sys.modules['ansible.module_utils.facts.collector.BaseFactCollector'] = BaseFactCollector
   

# Generated at 2022-06-20 19:34:50.794491
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    localModule = {"params": {"fact_path": "/bin"}}
    localFactCollector = LocalFactCollector()
    assert localFactCollector.name == "local"
    localFactCollector.collect(localModule, None)

# Generated at 2022-06-20 19:34:54.817977
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    base_fact_collector = BaseFactCollector()
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.collect() == {}
    assert local_fact_collector.collect(base_fact_collector) == {}

# Generated at 2022-06-20 19:35:04.647115
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.utils import FactsCollector

    def _run_command(cmd, **kwargs):
        return 0, cmd, ''

    def _warn(msg):
        pass

    module = FactsCollector()
    module.run_command = _run_command
    module.params = {'fact_path': 'tests/unit/module_utils/facts/collectors/fixtures'}
    module.warn = _warn

    local_fact_collector = LocalFactCollector()

    assert local_fact_collector.collect(module) == {'local': {}}

    module.params = {'fact_path': 'tests/unit/module_utils/facts/collectors/fixtures/local'}


# Generated at 2022-06-20 19:35:15.946645
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    class TestModule(object):
        def __init__(self, params):
            self.params = params

        def run_command(self, cmd):
            if cmd == '/path/to/fact_path/failure.fact':
                return 1, "", "Some Error"
            elif cmd == '/path/to/fact_path/file_content.fact':
                return 0, "This is a file content", ""
            elif cmd == '/path/to/fact_path/json_content.fact':
                return 0, "{\"foo\": {\"bar\": \"1\", \"baz\": \"2\"}}", ""
            elif cmd in ['/path/to/fact_path/ini_content.fact']:
                return 0, """[foo]\nbar = 1\nbaz = 2\n""", ""

# Generated at 2022-06-20 19:35:25.509814
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.utils import search_for_file
    from ansible.module_utils.facts.collector import read_file
    from ansible.module_utils.facts.collector import PluginError
    from ansible.module_utils.facts.collector import get_file_content
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.six.moves import configparser
    from io import StringIO

    collector = LocalFactCollector()
    module = MagicMock()
    module.params.get.return_value = None
    # test 1
    # test that if fact_path does not exist,
    # empty dict is returned
    assert collector.collect(module) == {}

   

# Generated at 2022-06-20 19:35:30.660468
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import collect_facts
    from ansible.module_utils.facts.local import LocalFactCollector
    from ansible.module_utils.facts.utils import MockModule

    # populate local facts
    local_facts = {}
    facts = collect_facts(MockModule(params={'fact_path': 'tests/unit/modules/test_facts_modules/local/'}))
    LocalFactCollector().populate(local_facts, facts)
    assert local_facts['local']['local_fact_1'] == 'welcome_to_my_fact_file'
    assert local_facts['local']['local_fact_2'] == '["a", "b", "c"]'

# Generated at 2022-06-20 19:35:40.121857
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.collector import BaseFactCollector

    f1 = '{"test": "value"}'
    f2 = 'error loading facts as JSON or ini - please check content: %s'
    f3 = '{"test": "value"}'
    f4 = '{"test": "value"}'

    mock_module = pytest.Mock()
    mock_module.params = {}
    mock_module.params['fact_path'] = '/tmp/'

    mock_module.run_command.side_effect = [(0, f1, ''), (1, f2, ''), (0, f3, ''), (0, f4, '')]
    mock_GLOBAL_RETURN_VALUES_EXECUTABLE = {'is_executable': True}
    mock

# Generated at 2022-06-20 19:35:48.655236
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local = LocalFactCollector()
    assert local is not None
    assert local.name == 'local'
    assert local._fact_ids == set()

# Generated at 2022-06-20 19:36:00.024445
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """Test collecting local facts."""

    # Create a module instance
    module = AnsibleModule(argument_spec=dict(
        fact_path=dict(type='str', required=False),
    ))

    # Create a LocalFactCollector instance
    fc = LocalFactCollector(module=module)

    # Try to get local facts in a non-existing path
    result = fc.collect()
    assert isinstance(result, dict)
    assert result == {}

    # Test using a local fact file to get facts
    # Create a local fact file
    file_path = tempfile.mkstemp()
    fact_content = '''{"a": "b"}'''
    with open(file_path, 'w') as f:
        f.write(fact_content)
    # Create a new LocalFactCollector instance
    f

# Generated at 2022-06-20 19:36:00.836852
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
                pass

# Generated at 2022-06-20 19:36:06.808699
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    '''
    Test that LocalFactCollector.collect() returns a non-empty dict.
    If this test fails, look for the following:
      1. That the path to fact_path is correct
      2. That the .fact files in fact_path exist
    '''
    from ansible.module_utils import basic
    import ansible.module_utils.facts.collector

    mc = basic.AnsibleModule(argument_spec={'fact_path': {'default': '../../plugins/facts/local'}})
    fac = ansible.module_utils.facts.collector.LocalFactCollector()
    fac._module = mc
    local_fact_dict = fac.collect()
    assert(local_fact_dict is not None)

# Generated at 2022-06-20 19:36:14.138343
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    collected_facts = {
        'ansible_system': 'Linux',
        'ansible_local': {
            'foo': 'bar'
        },
        'ansible_distribution_major_version': '7',
        'ansible_distribution_version': '7.0',
        'ansible_distribution': 'RedHat',
        'ansible_kernel': '3.10.0-327.3.1.el7.x86_64',
        'ansible_os_family': 'RedHat'
    }

    fake_module = FakeAnsibleModule(collected_facts, 'test_host')


# Generated at 2022-06-20 19:36:15.369384
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    a = LocalFactCollector()

# Generated at 2022-06-20 19:36:18.935713
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

    # Create an object of class LocalFactCollector() to test constructor
    test_obj = LocalFactCollector()
    # Check if the value of name is set correctly
    assert test_obj.name == 'local'

# Generated at 2022-06-20 19:36:25.635838
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import os
    import tempfile

    m = AnsibleModuleMock()
    m.params['fact_path'] = tempfile.mkdtemp()
    m.warn = lambda x: x  # we can print out the warning
    # collecting with a module fails
    assert LocalFactCollector().collect() == {}
    # collecting with a module and existing fact path
    assert LocalFactCollector().collect(module=m) == {'local': {}}
    # create a fact file and re-collect
    fact = os.path.join(m.params['fact_path'], 'fact.fact')
    with open(fact, 'w') as f:
        f.write('{"fact-key": "fact-value"}')

# Generated at 2022-06-20 19:36:28.577113
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    '''Test class name of LocalFactCollector'''
    obj = LocalFactCollector()
    assert obj.name == 'local'

# Generated at 2022-06-20 19:36:35.900388
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a module mock
    module = AnsibleModule(
        argument_spec={
            'fact_path': dict(required=False, type='str'),
        }
    )

    # Create an instance of LocalFactCollector
    fact_collector = LocalFactCollector()

    # Test method collect with no module passed

    # should return an empty dictionary
    facts = fact_collector.collect()

    assert isinstance(facts, dict)
    assert len(facts) == 0

    # Test method collect with empty module.params

    # should return an empty dictionary
    facts = fact_collector.collect(module)

    assert isinstance(facts, dict)
    assert len(facts) == 0

    # Test method collect with a module where fact_path is not set

    # should return an empty dictionary
    facts = fact_collector.collect

# Generated at 2022-06-20 19:36:50.794804
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    localFactCollector = LocalFactCollector()

# Generated at 2022-06-20 19:36:58.138530
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = FakeModule()
    local_fact_collector = LocalFactCollector()

    # local dict should be empty
    local = local_fact_collector.collect(module)
    assert(type(local) == dict)
    assert len(local) == 0

    module.params['fact_path'] = './'
    module.params['ansible_local'] = ''

    # local dict should have local dict inside
    local = local_fact_collector.collect(module)
    assert(type(local) == dict)
    assert len(local) == 1
    assert local['local']

    # writing test.fact file
    test_path = './test.fact'
    with open(test_path, 'w') as test_file:
        test_file.write('{ "fact_1": "Hello world" }')

# Generated at 2022-06-20 19:37:03.394336
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    module = None
    local_fact_collector = LocalFactCollector()
    local_facts = local_fact_collector.collect(module)
    # assert 'local' in local_facts
    # assert isinstance(local_facts['local'], dict)

# Generated at 2022-06-20 19:37:10.090579
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Setup required objects
    config = configparser.ConfigParser()
    config.readfp(StringIO("[test]\na = b"))

    class ModuleMock(object):
        def __init__(self):
            self._params = {}
            self._is_local = False
            self._runtime_checks_enabled = False
            self.exit_json = None
            self.fail_json = None
            self.check_mode = False
            self.no_log = False
            self._name = 'MyTest'

        def params(self, name=None):
            if name is None:
                return self._params
            else:
                return self._params.get(name)


# Generated at 2022-06-20 19:37:15.391452
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert isinstance(local_fact_collector._fact_ids, set)
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:37:19.335564
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    collected_facts = {'local': {'test1': 'test 1', 'test2': 'test 2'} }
    local_fact = LocalFactCollector()
    assert local_fact.collect() == collected_facts

# Generated at 2022-06-20 19:37:31.669270
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    # Imports
    import ansible.module_utils.facts.collectors.local
    import ansible.module_utils.facts.collectors
    import ansible.module_utils.facts.collector

    # Setup
    ansible.module_utils.facts.collectors = reload(ansible.module_utils.facts.collectors)
    ansible.module_utils.facts.collectors.local = reload(ansible.module_utils.facts.collectors.local)
    ansible.module_utils.facts.collector = reload(ansible.module_utils.facts.collector)

# Generated at 2022-06-20 19:37:35.147891
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():    
    Module = get_module_mock()    
    # run fact_path
    LocalFactCollector().collect(Module, None)

# Generated at 2022-06-20 19:37:38.074821
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    m = LocalFactCollector()
    assert m.name == 'local'
    assert m._fact_ids == set()


# Generated at 2022-06-20 19:37:40.467636
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_collector = LocalFactCollector()
    assert local_collector.collect() == {'local': {}}

# Generated at 2022-06-20 19:38:08.022588
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_collector = LocalFactCollector()
    assert local_collector.name == "local"
    assert local_collector._fact_ids == set()

# Generated at 2022-06-20 19:38:15.063536
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Fixtures
    test_path = os.path.join(os.path.dirname(__file__), 'test_collection_data')
    fact_path = os.path.join(test_path, 'facts')
    # Setup - create collection module instance and local facts instance
    collector = LocalFactCollector()
    test_module = object()
    test_module.params = {'fact_path': fact_path}
    # Test - run the collect function
    result = collector.collect(test_module)
    # Assert - verify only local facts section is returned with expected contents
    expected = {
        'local': {
            'fact1': 'something',
            'fact3': 'fact3',
            'fact4': '{"a": "b"}'
        }
    }
    assert expected == result

# Generated at 2022-06-20 19:38:17.907140
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'
    assert isinstance(LocalFactCollector._fact_ids, set)
    assert not LocalFactCollector._fact_ids

# Generated at 2022-06-20 19:38:23.216507
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    module = type('obj',(object,),{'params':{'fact_path':'test'}, 'warn': lambda x: True, 'run_command': lambda x: ('1', '', '')})
    instance = LocalFactCollector()
    facts = instance.collect(module)
    assert 'local' in facts,repr(facts)

# Generated at 2022-06-20 19:38:29.323354
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    from ansible.module_utils.facts import ansible_local
    from ansible.module_utils.facts.collector import collect_facts

    local = ansible_local.AnsibleModule(argument_spec=dict(fact_path=dict(required=True)))
    facts = collect_facts(collectors=[LocalFactCollector])
    local.exit_json(ansible_facts=facts)

# Generated at 2022-06-20 19:38:32.160783
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    BaseFactCollector._init_module = lambda x, y: None
    # TODO: complete unit test
    assert True == True

# Generated at 2022-06-20 19:38:42.552823
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import mock
    import pytest
    class MockModule:
        def __init__(self):
            self.warn = mock.Mock(return_value=None)
            self.run_command = mock.Mock(return_value=(0,'','err'))
            self.params = {'fact_path': 'tmp'}

    # Get local fact with no fact path
    assert LocalFactCollector().collect() == {'local': {}}

    # Get local fact with empty path
    mock_module = MockModule()
    mock_module.params['fact_path'] = ''
    assert LocalFactCollector().collect(module=mock_module) == {'local': {}}

    # Get local fact with non existing path
    mock_module = MockModule()
    mock_module.params['fact_path'] = 'xyz'


# Generated at 2022-06-20 19:38:53.196948
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector.local import LocalFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    BaseFactCollector.collectors = [LocalFactCollector]
    # testing LocalFactCollector.collect when fact_path is not set
    module_params = {}
    local_facts = LocalFactCollector().collect(module_params)
    assert {} == local_facts
    module_params['fact_path'] = '/tmp'
    local_facts = LocalFactCollector().collect(module_params)
    assert {} == local_facts
    # testing LocalFactCollector.collect when fact_path is set to the correct path

# Generated at 2022-06-20 19:38:54.607283
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    o = LocalFactCollector()
    assert o.name == 'local'


# Generated at 2022-06-20 19:38:55.073202
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    LocalFactCollector()

# Generated at 2022-06-20 19:40:28.464879
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    '''Unit test for method collect of class LocalFactCollector'''

    import os
    import ansible.module_utils.facts.collectors.platform.local as local_collector

    module = AnsibleModule(
        argument_spec = dict(
            fact_path=dict(type='path', required=True),
        )
    )
    testDir = os.path.dirname(os.path.realpath(__file__))
    module.params['fact_path'] = os.path.join(testDir, 'platform')
    local_collector.LocalFactCollector().collect(module=module)

# Generated at 2022-06-20 19:40:33.379087
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    if 'local_facts.fact_path' not in os.environ:
        raise ImportError("Failed to import the local_facts.fact_path environment variable.")

    local_fact_collector = LocalFactCollector()
    local_facts = local_fact_collector.collect()
    assert local_facts['local']['python_version'] == '3.5.3'

# Generated at 2022-06-20 19:40:35.895220
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.collect() == {'local': {}}

# Generated at 2022-06-20 19:40:38.224379
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_facts = LocalFactCollector()
    assert local_facts.name == 'local'

# Generated at 2022-06-20 19:40:42.996212
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = object()
    collected_facts = object()
    fact_path = os.path.join(os.path.dirname(__file__), 'unit/facts/')

    # Test 1. Executable
    test_collector = LocalFactCollector()
    test_collector.collect(module, collected_facts)

# Generated at 2022-06-20 19:40:48.542743
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Set up mockansible module
    module = MockAnsibleModule()
    # Set up LocalFactCollector
    lfc = LocalFactCollector()

    # First path is not a valid directory
    module.params['fact_path'] = '/dummy/dir/path'
    local_facts = lfc.collect()
    assert local_facts == {'local': {}}

    # Path to a directory
    module.params['fact_path'] = 'tests/unit/module_utils/facts/local_facts'
    local_facts = lfc.collect()
    expected = {
        'local': {
            'var': {
                'one': '1',
                'two': '2'
            }
        }
    }
    assert local_facts == expected



# Generated at 2022-06-20 19:40:51.037590
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()

    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:40:52.285317
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    return LocalFactCollector()

# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-20 19:40:58.351014
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = AnsibleModule(argument_spec={'fact_path': {'required': True, 'type': 'path'}})
    local_fact_collector = LocalFactCollector()
    local_facts = local_fact_collector.collect(module)
    assert local_facts['local'].has_key('ansible_local_facts')
    assert len(local_facts['local'].keys()) == 1


# Generated at 2022-06-20 19:41:02.384018
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Call constructor
    l = LocalFactCollector()

    # Assert proper initialization of attribute
    assert(l.name == "local")
    assert(l._fact_ids == set())
