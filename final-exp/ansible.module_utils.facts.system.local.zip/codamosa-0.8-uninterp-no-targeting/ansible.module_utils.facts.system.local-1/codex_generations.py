

# Generated at 2022-06-20 19:32:40.087219
# Unit test for method collect of class LocalFactCollector

# Generated at 2022-06-20 19:32:47.344460
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    from ansible.module_utils.facts.collector import Collectors
    from ansible.module_utils.facts.utils import serialize_facts
    from ansible.module_utils.facts.fact_cache import FactCache
    from ansible.module_utils.facts import FactCollector, get_collection_exclude
    from ansible.module_utils.facts import get_all_facts
    import ansible.constants as C

    test_file_path = 'modules/ansible_collections/ansible/community/support/tests/unit/module_utils/facts/'
    facts_cache = FactCache(C.FACT_CACHE)
    fact_collection_exclude_list = get_collection_exclude()

# Generated at 2022-06-20 19:32:59.056408
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    test_facts = {'local': {'facts': {'facts': {'facts': 'facts', 'facts2': 'facts2'}, 'facts2': {'facts2': 'facts2'}}}}
    ini_fact = '''[section1]
key1 = 1
key2 = 2
key3 = 3
'''
    json_fact = '''{
  "section1": {
    "key1": "1",
    "key2": "2",
    "key3": "3"
  }
}
'''
    '''Unit test for the method collect of LocalFactCollector'''
    import pytest
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ModuleFailException
    import os
    import stat


# Generated at 2022-06-20 19:33:05.147951
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    '''
    Test method collect of class LocalFactCollector
    '''
    # Test normal behavior
    module = {}
    module['params'] = {}
    module['params']['fact_path'] = 'ansible/module_utils/facts/local'
    module['run_command'] = {}
    local_fact_collector = LocalFactCollector()
    local_facts = local_fact_collector.collect(module=module)
    assert isinstance(local_facts, dict)
    assert local_facts.get('local') is not None

# Generated at 2022-06-20 19:33:07.709756
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert isinstance(LocalFactCollector(), BaseFactCollector)

# Generated at 2022-06-20 19:33:11.220889
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    from ansible.module_utils.facts.collector import FactCollector
    local_fact_collector = LocalFactCollector()
    assert isinstance(local_fact_collector, FactCollector)

# Generated at 2022-06-20 19:33:13.308507
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector is not None

# Generated at 2022-06-20 19:33:24.125555
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """Unit test for method collect of class LocalFactCollector"""
    def test_func(module):
        test_dict = {'foo': 'bar'}
        return test_dict
    name = 'local'
    test_fact_path = '/etc/ansible/facts.d'
    test_fact_base = 'test'
    test_file_name = test_fact_base + '.fact'
    test_file_path = os.path.join(test_fact_path, test_file_name)

    with open(test_file_path, 'w') as fh:
        json.dump(test_func, fh)
    assert os.path.exists(test_file_path)
    local_fc = LocalFactCollector()
    result = local_fc.collect({})
    assert result
    assert result

# Generated at 2022-06-20 19:33:26.435936
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:33:34.554322
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    '''
    init module object
    '''
    import ansible.module_utils.basic

    # must be set to true to use json as it is not set by default
    ansible.module_utils.basic.MODULE_COMPLEX_ARGS = True

    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={
            'fact_path': dict(type='str', required=False),
        }
    )

    if module.params['fact_path'] is None:
        module.params['fact_path'] = os.path.join(os.path.dirname(__file__), '..', '..', 'utils', 'facts', 'local_facts')

    '''
    init fact collector
    '''
    fact_collector = LocalFactCollector()


# Generated at 2022-06-20 19:33:41.153015
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    LocalFactCollector.collect()

# Generated at 2022-06-20 19:33:41.709367
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    assert True

# Generated at 2022-06-20 19:33:52.058765
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """ Test ansible.module_utils.facts.local.LocalFactCollector """
    args = dict()
    args['fact_path'] = 'test/unit/module_utils/facts/files/local_facts'
    local_fact_collector = LocalFactCollector(None, args)
    try:
        module = None
        collected_facts = None
    except:
        module = None
        collected_facts = None
    local_facts = local_fact_collector.collect(module, collected_facts)
    assert local_facts['local']['env']['ANSIBLE_PYTHON_INTERPRETER'] == '/usr/bin/python2'
    assert local_facts['local']['facts']['ansible_local'] == 'test'

# Generated at 2022-06-20 19:34:02.040088
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    fake_module = object()

    fact_path = 'tests/unit/module_utils/facts/test_data/local_facts'

    # Collect facts given a fact path
    collector = LocalFactCollector(fake_module)
    facts = collector.collect(fact_path)


# Generated at 2022-06-20 19:34:13.984714
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """
    Test collect method of LocalFactCollector
    """

    # mocker fixture is defined in conftest.py
    mocker, module_inst, collector_inst = mocker.patch_module(__name__)

    # patch run_command to return custom return code and output
    mocker.patch.object(module_inst, "run_command")
    module_inst.run_command.return_value = (0, 'output', '')

    # create a temporary file that can be added to the fact_path list
    fact_file = mocker.mock_open(read_data='{ "fact_id": "fact_value" }')
    mocker.patch('ansible.module_utils.facts.collector.open', fact_file, create=True)

    fact_path = '/directory/temp/'
    fact

# Generated at 2022-06-20 19:34:16.861976
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = AnsibleModuleMock()
    local_fact_collector = LocalFactCollector()
    result = local_fact_collector.collect(module)

    assert result is not None

# Generated at 2022-06-20 19:34:21.196287
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    with open('test/unit/ansible_local_facts/test_collect_valid.output', 'r') as f:
        mock_output = f.read()
    collect_output = LocalFactCollector().collect()
    assert collect_output == json.loads(mock_output)

# Generated at 2022-06-20 19:34:31.168440
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Given
    # LocalFactCollector.collect
    collector = LocalFactCollector()

    def mocked_module_params(name):
        assert name == 'fact_path'
        return '/root/ansible/ansible/module_utils/facts/ansible/local'

    def mocked_module_run_command(cmd):
        if cmd == '/root/ansible/ansible/module_utils/facts/ansible/local/.fact1.fact':
            return 1, 'err1', 'err2'
        elif cmd == '/root/ansible/ansible/module_utils/facts/ansible/local/.fact2.fact':
            return 0, 'out1', 'out2'
        else:
            raise Exception('unexpected run_command call')


# Generated at 2022-06-20 19:34:39.105181
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = MockModule()
    module.params['fact_path'] = 'test/facts/local'
    local_facts_collector = LocalFactCollector()
    facts = local_facts_collector.collect(module=module)
    assert facts['local']['test_json_fact'] == {'asdf': 'blah'}
    assert facts['local']['test_ini'] == {'section1': {'option1': 'value1', 'option2': 'value2'},
                                          'section2': {'option1': 'value1', 'option2': 'value2'}}

# Generated at 2022-06-20 19:34:43.111403
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    lfc = LocalFactCollector()
    assert lfc.name == "local"
    assert isinstance(lfc._fact_ids, set)
    assert isinstance(lfc.collect(), dict)

# Generated at 2022-06-20 19:34:58.841431
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    collected_facts = {}
    lfc = LocalFactCollector()
    # No collection without module
    assert lfc.collect() == {'local': {}}
    # Not collection without fact_path
    assert lfc.collect(collected_facts=collected_facts) == {'local': {}}
    # Collection without module parameter
    assert lfc.collect(module=None, collected_facts=collected_facts) == {'local': {}}
    # Collection with module parameter but without fact_path
    collected_facts = {'ansible_local': {'fact_path': None}}
    assert lfc.collect(module=None, collected_facts=collected_facts) == {'local': {}}

# Generated at 2022-06-20 19:34:59.427788
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass

# Generated at 2022-06-20 19:35:00.317485
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert isinstance(LocalFactCollector(), LocalFactCollector)

# Generated at 2022-06-20 19:35:02.452346
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_facts = LocalFactCollector()
    assert local_facts.name == 'local'
    assert local_facts._fact_ids == set()

# Generated at 2022-06-20 19:35:10.082584
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import shutil
    module = None
    local_facts = {'local': None}
    fact_path = '/tmp/local_facts'
    os.mkdir(fact_path)
    os.chmod(fact_path, 0o755)
    file_fact_path = '/tmp/local_facts/facts.fact'
    fact_file = open(file_fact_path, 'w+')
    fact_file.write('[foo]\nbar')
    fact_file.close()
    cp = configparser.ConfigParser()
    cp.read(file_fact_path)
    expected_facts = {'foo': {'bar': None}}
    lfc = LocalFactCollector()
    result = lfc.collect(module=module, collected_facts=local_facts)
    assert 'local' in result
   

# Generated at 2022-06-20 19:35:14.963252
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    module = 'fakemodule'
    collected_facts = {}
    local_fact_collector = LocalFactCollector(module=module, collected_facts=collected_facts)

    assert local_fact_collector.name == 'local'

# Generated at 2022-06-20 19:35:24.816411
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    class module:
        def __init__(self):
            self._params = {'fact_path': './local_facts'}

        def params(self):
            return self._params

        def warn(self, msg):
            print("==> %s" % msg)

        def run_command(self, cmd):
            return (0, "", "")

    local_facts = {}
    local_facts['local'] = {}
    local_facts['local']['ansible_net_gather_network_resources'] = 'False'
    local_facts['local']['ansible_os_family'] = 'RedHat'
    local_facts['local']['error_fact'] = 'error loading fact - output of running "error_fact.fact" was not utf-8'

# Generated at 2022-06-20 19:35:26.328996
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    lfc = LocalFactCollector()
    assert lfc
    assert lfc.name == 'local'
    assert lfc.collect()



# Generated at 2022-06-20 19:35:27.985595
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass

# Generated at 2022-06-20 19:35:38.452058
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = mock.Mock()
    module.params.copy.return_value = {'fact_path': '/tmp/facts.d'}
    module.run_command.return_value = (0, '{"a": true}', '')
    stats_mock = mock.Mock()
    stats_mock.st_mode = stat.S_IXUSR
    os_mock = mock.Mock()
    os_mock.stat.return_value = stats_mock
    result = {
      'ansible_local': {
        'a': True
      }
    }

# Generated at 2022-06-20 19:36:01.508481
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Create Fake module object
    module = type('', (), {})()
    module.params = {}
    
    # Create Fake 'os.stat' object
    st = type('', (), {'ST_MODE':0})
    os = type('', (), {'stat': lambda self, path: st})
    os.path = type('', (), {'exists': lambda self, path: True})
    glob = type('', (), {'glob': lambda self, path: path})
    module.run_command = lambda self, fn: (0, fn, '')
    module.warn = lambda self, warning: warning
    local_fact_collector = LocalFactCollector(module)
    collected_facts = local_fact_collector.collect(module)
    
    # Check if fact was collected

# Generated at 2022-06-20 19:36:03.278553
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert 'local' in BaseFactCollector.get_fact_class('local').name

# Generated at 2022-06-20 19:36:04.762681
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector is not None

# Generated at 2022-06-20 19:36:13.052974
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    class MockModule(object):
        params = {
            "fact_path": "/path/to/directory",
        }

        def __init__(self, name):
            self.name = name
            self.warn = lambda msg: msg
            self.run_command = lambda cmd: (0, "", "")

    def mock_get_file_content(file, default):
        return ""

    class MockGlobModule(object):
        glob = lambda path: [path]

    import __builtin__
    old_glob = __builtin__.__import__
    __builtin__.__import__ = lambda name, *args: glob.glob if name == 'glob' else old_glob(name, *args)

    LocalFactCollector._fact_ids = set()

# Generated at 2022-06-20 19:36:15.368596
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local = LocalFactCollector()
    assert local.name == 'local'
    assert local._fact_ids == set()

# Generated at 2022-06-20 19:36:17.890282
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_colector = LocalFactCollector()
    local_fact_colector.collect()

# Generated at 2022-06-20 19:36:27.885896
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Setup of test directory and test files
    filebasedir = '/tmp/ansible_local_facts/'
    local_fact_files = [
        'test1.fact',
        'test2.fact',
        'test3.fact',
        'test4.fact',
        'test5.fact',
        'test6.fact',
        'test7.fact',
        'test8.fact',
        'test9.fact',
        'test10.fact',
        'test11.fact',
        'test12.fact',
        'test13.fact',
        'test14.fact',
        'test15.fact',
        'test16.fact',
    ]

    for file in local_fact_files:
        open(filebasedir + file, 'w').close()

    # Setup of test data

# Generated at 2022-06-20 19:36:29.746269
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # create LocalFactCollector object
    lfc = LocalFactCollector()

    # test collect method
    lfc.collect()

# Generated at 2022-06-20 19:36:30.966899
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    result = LocalFactCollector()
    assert result
    assert result.name == 'local'

# Generated at 2022-06-20 19:36:35.671610
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    filepath = './facts/'
    lfc = LocalFactCollector(filepath)
    assert lfc.name == 'local'
    assert 'test_file' in lfc._fact_ids
    assert 'ansible_version' in lfc._fact_ids

# Generated at 2022-06-20 19:37:04.671721
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()

    assert local_fact_collector.collect() == {}

if __name__ == "__main__":
    test_LocalFactCollector_collect()

# Generated at 2022-06-20 19:37:07.756852
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    obj = LocalFactCollector()
    assert obj.name == 'local'
test_LocalFactCollector.required = ['local']



# Generated at 2022-06-20 19:37:19.008689
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.utils import FactsFiles
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines

    def _create_fact_dir(dir_name):
        """Create a temporary directory and return its name"""
        import tempfile

        # Create a temporary directory
        return tempfile.mkdtemp(dir=dir_name)

    def _create_fact_file(dir_name, file_name, file_content):
        """Create a temporary fact file and return its name"""
        import tempfile

        # Replace path separator with underscore to create a valid file name


# Generated at 2022-06-20 19:37:25.627966
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_module = type("TestModule", (object,), {})
    test_module.run_command = lambda a, b: (0, '{}', '')
    test_module.params = lambda x: True
    test_module.warn = lambda x: True
    LocalFactCollector(module=test_module)

# Generated at 2022-06-20 19:37:33.710629
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a LocalFactCollector instance for testing
    localFactCollector_test = LocalFactCollector()

    # Dummy local fact files
    fact_path = '/var/facts.d'
    if not os.path.exists(fact_path):
        os.makedirs(fact_path)
    fact_json = open(os.path.join(fact_path, 'test_local_fact_json.fact'), 'w')
    fact_ini = open(os.path.join(fact_path, 'test_local_fact_ini.fact'), 'w')
    fact_script = open(os.path.join(fact_path, 'test_local_fact_script.fact'), 'w')

# Generated at 2022-06-20 19:37:35.327461
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_facts = LocalFactCollector()
    assert local_facts.name == 'local'

# Generated at 2022-06-20 19:37:46.751707
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import shutil
    import tempfile
    import ansible.module_utils.facts.collectors
    from ansible.module_utils import basic

    FACT_CONTENT = """
    [a]
    b = 1
    c = 2

    [d]
    e = 3
    """

    tmpdir = tempfile.mkdtemp()
    test_path = os.path.join(tmpdir, 'test.fact')
    open(test_path, 'w').write(FACT_CONTENT)

    module = basic.AnsibleModule(argument_spec={}, supports_check_mode=True)

    module.params['fact_path'] = tmpdir


# Generated at 2022-06-20 19:37:57.743263
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    os.environ['ANSIBLE_PYTHON_INTERPRETER'] = '3'
    os.environ['ANSIBLE_COLLECTIONS_PATHS'] = ''
    os.environ['ANSIBLE_CACHE_PLUGIN'] = 'jsonfile'
    os.environ['ANSIBLE_CACHE_PLUGIN_CONNECTION'] = '/tmp/persist'
    os.environ['ANSIBLE_MODULE_UTILS'] = '/tmp/ansible/module_utils'
    os.environ['ANSIBLE_CACHE'] = 'jsonfile'
    os.environ['ANSIBLE_PIPELINING'] = 'True'
    os.environ['ANSIBLE_NOCOLOR'] = 'false'

# Generated at 2022-06-20 19:37:59.921799
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert not local_fact_collector._fact_ids

# Generated at 2022-06-20 19:38:04.888760
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    module = None
    myLocalFactCollector = LocalFactCollector(module)
    # Tests if the constructor successfully sets the name of fact
    assert myLocalFactCollector.name == 'local'
    # Tests if the constructor successfully sets the fact_ids
    assert myLocalFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:38:59.342499
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts import FactCache

    f = LocalFactCollector("../../files/facts.d")
    module = MockModule("/")

    facts = FactCache()
    f.collect(module, facts)
    assert len(facts.facts) == 1
    assert facts.facts.get('local') is not None

# Generated at 2022-06-20 19:39:03.510083
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # initialize the LocalFactCollector object
    collector = LocalFactCollector()
    assert collector is not None
    # test LocalFactCollector.name
    assert collector.name == 'local'
    # test LocalFactCollector._fact_ids
    assert collector._fact_ids == set()


# Generated at 2022-06-20 19:39:06.566561
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    localFactCollector = LocalFactCollector()
    assert localFactCollector.name == 'local'
    assert localFactCollector._fact_ids == set([])

# Generated at 2022-06-20 19:39:13.399103
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    with open('./test/unit/module_utils/ansible_local_facts.json') as fact_file:
        local_facts = json.load(fact_file)
    fact_path = './test/unit/module_utils/ansible_local_facts'
    local_fact_collector = LocalFactCollector([local_facts['ansible_local']])
    facts = local_fact_collector.collect(fact_path)
    assert facts['local'] == local_facts['local']

# Generated at 2022-06-20 19:39:20.653972
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    collector = LocalFactCollector()
    ansible_module = get_ansible_module()
    result = collector.collect(ansible_module=ansible_module, collected_facts=None)
    assert result

# Unit test helper.
# This method is meant only to be used within an ansible unit test.
# It will fill in the module_runner and module args that would otherwise
# be provided by an AnsibleModule.
#
# Note: This method meant to be used only in the context of an ansible unit test.
#       It will not work with other unit testing frameworks.
#

# Generated at 2022-06-20 19:39:22.240470
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact = LocalFactCollector()
    local_facts = local_fact.collect()

    assert local_facts == {'local': {}}

# Generated at 2022-06-20 19:39:24.965541
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """
    Return some facts
    """
    fact_path = None
    local_facts = {}
    local_facts['local'] = {}

    if not fact_path or not os.path.exists(fact_path):
        return local_facts

    local = {}
    local_facts['local'] = local

    return local_facts

# Generated at 2022-06-20 19:39:27.904390
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'


# Generated at 2022-06-20 19:39:29.027311
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact = LocalFactCollector()
    assert local_fact.name == 'local'

# Generated at 2022-06-20 19:39:31.269819
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

    lfc = LocalFactCollector()
    assert lfc.name == 'local'
    assert lfc._fact_ids == set()
    assert lfc.collect() == {'local': {}}

# Generated at 2022-06-20 19:41:45.202154
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Setup test object
    local_fact_collector = LocalFactCollector()
    local_fact_collector.module = None
    local_fact_collector.collected_facts = None

    # Call method collect
    result = local_fact_collector.collect(module=(local_fact_collector.module),
                                          collected_facts=(local_fact_collector.collected_facts))

    # Assert result
    assert result == {}

# Generated at 2022-06-20 19:41:49.224068
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    lf = LocalFactCollector()
    assert lf.name in lf.collect()
    assert lf.name in lf.collect().keys()
    assert 'local' in lf.collect().keys()
    assert 'local' in lf.collect()

# Generated at 2022-06-20 19:41:52.814111
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'
    assert LocalFactCollector._fact_ids == set()
    assert LocalFactCollector.collect() == {}
    assert LocalFactCollector.collect({'run_command': None}) == {}
    assert LocalFactCollector.collect({'run_command': None, 'params': {}}) == {}

# Generated at 2022-06-20 19:41:56.617337
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    t = LocalFactCollector()
    assert t.name == 'local'
    assert "_fact_ids" in t.__dict__.keys()
    assert t._fact_ids == set()


# Generated at 2022-06-20 19:41:58.522671
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # NOTE: This test is incomplete
    test_module = AnsibleModule(argument_spec=dict(
        fact_path=dict(default='/does/not/exist')
    ))
    local_fact_collector = LocalFactCollector(module=test_module)
    result = local_fact_collector.collect()
    assert result == {'local': {}}

# Generated at 2022-06-20 19:41:59.551544
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    x = LocalFactCollector()
    assert x.name == 'local'

# Generated at 2022-06-20 19:42:07.882915
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    import ansible.module_utils.facts.collectors.local as local

    module = {}
    collected_facts = {}

    #exec_file, exec_dir, exec_links = [], [], []
    #for fn in glob.glob(fact_path + '/*.fact'):
    #    if os.path.isdir(fn):
    #        exec_dir.append(fn)
    #    elif os.path.islink(fn):
    #        exec_links.append(fn)
    #    else:
    #        exec_file.append(fn)

    #NOTICE
    #for fn in exec_links:
    #    #FIXME: module.warn() should accept list.
    #    module.warn([{'warning': 'Symlink is not supported, skipping {0}'.format(

# Generated at 2022-06-20 19:42:09.764321
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    import sys

    # Test direct instantiation of class LocalFactCollector
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector

# Generated at 2022-06-20 19:42:10.761410
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    assert(LocalFactCollector).collect() == {'local': {}}

# Generated at 2022-06-20 19:42:20.732831
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # initialize UtilityModule instance
    import ansible.module_utils.facts.facts

    # initialize LocalFactCollector instance
    from ansible.module_utils.facts.collectors import LocalFactCollector

    m = ansible.module_utils.facts.facts.UtilityModule()
    li = LocalFactCollector()

    # check if fact_path is set to acceptable path
    data = {'fact_path': '../tests/unit/module_utils/facts/fixtures/local_facts/'}
    m.params = data
    output = li.collect(module=m)['local']

    assert 'json_fact' in output

    # check if json_fact is set to string when fact file is not able to be converted to json