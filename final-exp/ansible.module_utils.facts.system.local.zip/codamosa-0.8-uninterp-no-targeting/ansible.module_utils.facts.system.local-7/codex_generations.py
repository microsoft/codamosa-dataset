

# Generated at 2022-06-20 19:32:37.088532
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # constructor can be called without parameter
    LocalFactCollector()

# Generated at 2022-06-20 19:32:46.250380
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    args = {'fact_path': '/tmp/test/'}
    helper = LocalFactCollector(module=None, collected_facts=None)
    result = helper.collect(module=None, collected_facts=None)
    result['local'].update({'a_dir': {'a_file': 'a_value'}})
    assert result['local'] == result['local']

    args = {'fact_path': '/tmp/ansible_issue_23321/'}
    helper = LocalFactCollector(module=None, collected_facts=None)
    result = helper.collect(module=None, collected_facts=None)
    result['local'].update({'test_fact': {'test_group': {'test_key': 'test_value'}}})
    assert result['local'] == result['local']

# Generated at 2022-06-20 19:32:48.683515
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # constructor test
    assert LocalFactCollector.name == 'local'
    assert LocalFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:33:00.511899
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import os
    import shutil
    import tempfile
    import unittest

    class TestLocalFactCollector(LocalFactCollector):
        # create a temporary directory where the source will be copied to.
        # copy the file to the temporary directory so that we can modify its content without polluting the source.
        tmpdir = tempfile.mkdtemp()
        source_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../../../')
        fact_path = os.path.join(source_path, 'lib/ansible/module_utils/facts/local')
        dst_dir = os.path.join(tmpdir, 'lib', 'ansible', 'module_utils', 'facts')

# Generated at 2022-06-20 19:33:01.096662
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    assert 1 == 2

# Generated at 2022-06-20 19:33:02.746195
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.__name__ == 'LocalFactCollector'

# Generated at 2022-06-20 19:33:06.642249
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert 'local' == local_fact_collector.name
    assert not local_fact_collector._fact_ids

# Generated at 2022-06-20 19:33:08.776604
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector is not None

# Generated at 2022-06-20 19:33:10.612332
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    obj = LocalFactCollector()
    obj._fact_ids = set()
    obj.collect()

# Generated at 2022-06-20 19:33:13.204544
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts import ansible_local

    assert isinstance(ansible_local.LocalFactCollector.collect(), dict)

# Generated at 2022-06-20 19:33:24.123385
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Creating object
    lfc = LocalFactCollector()

    # Testing that an exception is raised if the required arguments are not provided
    try:
        lfc.collect()
    except ValueError as e:
        assert e.message == "arguments should be an Ansible Module and a dict of collected_facts"


# Generated at 2022-06-20 19:33:33.048013
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    file_content = "content"
    fact_path = "/tmp/ansible"
    fact_collector = LocalFactCollector()
    fact_collector.fetch_file_content = lambda a, b: file_content
    fact_collector.fetch_file_lines = lambda a, b: file_content.splitlines()
    fact_collector._module = lambda: None
    fact_collector._module().params = lambda: None
    fact_collector._module().params.get = lambda a, b: fact_path
    fact_collector._module().run_command = lambda a: (0, file_content, file_content)
    fact_collector._module().warn = lambda a: None
    fact_dict = fact_collector.collect()

# Generated at 2022-06-20 19:33:37.288032
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_cls = LocalFactCollector
    test_fact_collector = test_cls()
    print(test_fact_collector.name)

# Unit tests for local fact collector.

# Generated at 2022-06-20 19:33:46.728638
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Create a module object
    module = FakeModule()
    fact_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..', '..', 'utils', 'facts', 'playbooks', 'files')
    module.params = { "fact_path": fact_path }
    local_fact_collector = LocalFactCollector()

    # Verify the result
    # AnsibleModule.run_command()
    expected_result = {'local': {'fact1': '{"fact1-key": "fact1-value"}', 'fact2': '{"fact2-key": "fact2-value"}', 'fact3': '{"fact3-key": "fact3-value"}'}}
    assert local_fact_collector.collect(module) == expected_result

# Generated at 2022-06-20 19:33:59.320350
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Test with ansible.cfg
    from ansible.config.manager import ConfigManager
    from ansible.config.data import ConfigData
    from ansible.utils.display import Display
    from ansible.module_utils.facts import ansible_collections_path
    test_config_data1 = ConfigData()
    test_config_data1.set_many({
        'fact_path': ansible_collections_path + '/ansible/windows/',
        'display_skipped_hosts': False,
        'display_ok_hosts': True,
        'display_failed_stderr': False,
        'display_errors_on_console': True,
    })
    config_manager = ConfigManager(display=Display(), config_data=test_config_data1)
    module = MockModule(config_manager)



# Generated at 2022-06-20 19:34:01.305657
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'
    assert type(LocalFactCollector._fact_ids) is set

# Generated at 2022-06-20 19:34:04.892159
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fact_collector = LocalFactCollector()
    assert fact_collector.name == 'local'
    assert fact_collector._fact_ids == set()


# Generated at 2022-06-20 19:34:08.085092
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local = LocalFactCollector()
    assert local.name == 'local'
    assert local._fact_ids == set()



# Generated at 2022-06-20 19:34:10.264387
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    args = {'fact_path': '/dev/null'}
    res = LocalFactCollector(None, args)
    assert res is not None

# Generated at 2022-06-20 19:34:11.202409
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    localFactCollector = LocalFactCollector()

# Generated at 2022-06-20 19:34:26.067925
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module_mock = 'module_mock'
    localFactCollector = LocalFactCollector()
    localFactCollector.collect(module_mock)

# Generated at 2022-06-20 19:34:28.870875
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local = LocalFactCollector()
    local.collect()
    assert isinstance(local, LocalFactCollector)
    assert isinstance(local.name, str)
    assert local_facts == {'local', {'local': {}}}

# Generated at 2022-06-20 19:34:39.807378
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    module = DummyAnsibleModule()
    local_collector = LocalFactCollector()
    assert local_collector.name == 'local'

    collected_facts = {}
    local_fact_dict = local_collector.collect(module, collected_facts)
    assert local_fact_dict.keys() == ['local']

    # Verify that fact_path is passed by ansible module correctly
    fact_path = os.path.dirname(os.path.realpath(__file__))+"/../../../../tests/integration/facts/local"
    module.params['fact_path'] = fact_path

    local_fact_dict = local_collector.collect(module, collected_facts)
    # Verify that local facts are populated correctly

# Generated at 2022-06-20 19:34:43.415179
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector is not None
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-20 19:34:54.740612
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # make sure that if fact_path doesn't exist that it returns an
    # empty dict
    module = AnsibleModule(argument_spec={'fact_path':
                                          dict(required=True, type='path')})
    local_facts = LocalFactCollector().collect(module=module)
    assert 'local' in local_facts
    assert local_facts['local'] == {}

    # make sure that if fact_path does exist that it returns the
    # file content
    module = AnsibleModule(argument_spec={'fact_path':
                                          dict(required=True, type='path')})

    # create a fact file
    fact_dir = tempfile.mkdtemp()
    fact_path = os.path.join(fact_dir, 'test.fact')

# Generated at 2022-06-20 19:34:57.261135
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:35:01.033157
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # local_facts = {
    #     'local': {
    #         'test': {
    #             'test': "This is the test output"
    #         }
    #     }
    # }
    # assert local_facts == LocalFactCollector().collect()
    assert False

# Generated at 2022-06-20 19:35:09.333294
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    #
    # Imports
    #
    import os
    import shutil
    import tempfile
    import traceback

    #
    # Config
    #
    class FakeModule(object):
        def __init__(self):
            self.params = {}
        def fail_json(self, **kwargs):
            raise Exception(kwargs['msg'])
        def warn(self, msg):
            if 'TRACEBACK' in msg:
                raise Exception(msg)
            print(msg)
        def run_command(self, cmd):
            return (0, "", "")

    #
    # Tests
    #
    def tests():
        tmpdir = tempfile.mkdtemp(prefix='ansible_local')

# Generated at 2022-06-20 19:35:21.312055
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts import ModuleStub

    t_fact_path = os.path.join(os.path.dirname(__file__), '..', 'unit', 'ansible', 'facts')

    local_facts = LocalFactCollector().collect(module=ModuleStub(ansible_facts={}, params=dict(fact_path=t_fact_path)))

    assert local_facts['local']['ansible_python']['version_info'][0] == 2
    assert local_facts['local']['ansible_python']['version_info'][1] == 7
    assert local_facts['local']['ansible_python']['version_info'][2] == 15
    assert local_facts['local']['ansible_python']['version_info'][3] == 4

# Generated at 2022-06-20 19:35:21.834100
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert True

# Generated at 2022-06-20 19:35:47.498535
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    localFactCollector = LocalFactCollector()

    # Assert that an instance is created as expected
    assert localFactCollector.name == 'local'
    assert localFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:35:50.844803
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    ansible_module = {
        'params': {
            'fact_path': 'local'
        }
    }
    local_fact_collector = LocalFactCollector(ansible_module)
    assert local_fact_collector.name == 'local'


# Generated at 2022-06-20 19:35:52.575317
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    assert True

# Generated at 2022-06-20 19:35:54.334220
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact = LocalFactCollector()
    assert local_fact.name == 'local'

# Generated at 2022-06-20 19:35:55.780656
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    m = LocalFactCollector()
    assert isinstance(m, LocalFactCollector)

# Generated at 2022-06-20 19:35:58.004482
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    # Create LocalFactCollector Object
    test_obj = LocalFactCollector()
    module = None
    test_obj.collect(module)

# Generated at 2022-06-20 19:35:58.706786
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass

# Generated at 2022-06-20 19:36:08.406332
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Prepare parameters
    params = {'fact_path': 'fact_path'}
    
    # Prepare the collector
    lfc = LocalFactCollector()
    
    # Prepare the module mock
    class module:
        params = params
        def run_command(self, fn):
            return 0, 'test', ''
    mod = module()
    
    # Prepare returned values
    test_value = {'local': {
                'fact1': '',
                'fact2': {'section1': {'value': 'test'}, 'section2': {'value2': 'test'}},
                'fact3': {'value': ['test', 'test2']}
                }
            }
    
    # Test collect - preparation
    # Create test directory
    import os

# Generated at 2022-06-20 19:36:15.852833
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    lfc = LocalFactCollector()
    assert lfc.name == 'local'
    assert lfc.collect() == {'local': {}}
    assert lfc.collect({}) == {'local': {}}
    assert lfc.collect({'params': {'fact_path': ''}}) == {'local': {}}
    assert lfc.collect({'params': {'fact_path': '.'}}) == {'local': {}}

# Generated at 2022-06-20 19:36:18.731517
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_facts = LocalFactCollector()

    assert local_facts.name == "local"
    assert set() == local_facts._fact_ids

# Generated at 2022-06-20 19:37:14.480579
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    """Test constructor of LocalFactCollector class
    """
    obj = LocalFactCollector()
    assert hasattr(obj, 'name')
    assert hasattr(obj, '_fact_ids')


# Generated at 2022-06-20 19:37:15.778367
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    # Trivial test to avoid variable not used error
    assert True

# Generated at 2022-06-20 19:37:26.979447
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import sys
    import os
    import stat
    import json
    import shutil
    import tempfile
    # import ansible.module_utils.facts.collector.local.LocalFactCollector
    from ansible.module_utils.facts.collector import LocalFactCollector

    # create a fake module
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-20 19:37:33.465115
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = None
    # Tests for no fact_path
    fact_path = None
    collector = LocalFactCollector()
    result = collector.collect(module, fact_path)
    assert result['local'] == {}, "Failed to skip elements in collect"

    # Tests for no existing fact_path
    fact_path = "../x/"
    result = collector.collect(module, fact_path)
    assert result['local'] == {}, "Failed to skip elements in collect"

    # Tests for existing fact_path
    fact_path = "../example_facts/"
    result = collector.collect(module, fact_path)
    assert result['local'] != {}, "Failed to collect elements in collect"

# Generated at 2022-06-20 19:37:45.170686
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    # Instantiate mock module
    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def run_command(self, fn):
            return None, None, None

        def warn(self, msg):
            return None

    # Instantiate mock file system

# Generated at 2022-06-20 19:37:47.098066
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact = LocalFactCollector()
    assert local_fact.collect() == {'local': {}}

# Generated at 2022-06-20 19:37:49.180281
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_x = LocalFactCollector()
    assert local_x.name == 'local'



# Generated at 2022-06-20 19:37:59.560951
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Mock module and class
    class TestModule:
        def __init__(self, params):
            self.params = params
        def warn(self, msg):
            pass
        def run_command(self, fn):
            return 0, '', ''
    class TestCollector:
        def __init__(self):
            pass
        def get_file_content(self, file, default):
            if file == '/tmp/ansible_local.fact':
                return 'test_content'
            return default
    # Create input
    test_data = {
        'fact_path': '/tmp',
        'collect': False
    }
    module = TestModule(test_data)
    test_collector = TestCollector()
    # Create collector and gather facts
    collector = LocalFactCollector()
    facts = collector.collect

# Generated at 2022-06-20 19:38:02.949533
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    """
    Test LocalFactCollector class constructor
    """
    local_tst = LocalFactCollector()
    assert local_tst._fact_ids == local_tst._fact_ids

# Generated at 2022-06-20 19:38:04.213939
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    collector = LocalFactCollector()
    assert collector.name == 'local'

# Generated at 2022-06-20 19:40:16.752986
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils import basic

    collector = LocalFactCollector()
    module = basic.AnsibleModule(argument_spec={'fact_path': {'type':'str'}})

    collection = collector.collect(module=module)

    assert collection is not None

# Generated at 2022-06-20 19:40:18.332941
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    obj = LocalFactCollector()
    assert obj.name == 'local'

# Generated at 2022-06-20 19:40:19.288564
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass

# Generated at 2022-06-20 19:40:21.988343
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_facts = LocalFactCollector()
    assert local_facts.collect() == {'local': {}}

# Generated at 2022-06-20 19:40:23.760315
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-20 19:40:34.367556
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import ansible_local_facts
    filename = os.path.join(os.path.dirname(__file__), "__init__.py")
    assert os.path.exists(filename)
    stats = os.stat(filename)
    assert stat.S_ISREG(stats.st_mode)
    assert stat.S_IMODE(stats.st_mode) != 0o755

    mod_args = {}
    mod_args['fact_path'] = os.path.dirname(os.path.abspath(ansible_local_facts.__file__))

    # in case of a failure before the module is loaded, this is the exception
    # instance that will be re-raised.
    fail_exc = None

# Generated at 2022-06-20 19:40:44.652186
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    import ansible.module_utils.facts.collectors.local
    from ansible.module_utils.facts.collectors.local import LocalFactCollector
    from ansible.module_utils.facts import Facts
    import os
    import json
    import tempfile
    import stat


    # create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # make a json file
    jsonfile = os.path.join(tmpdir, 'json.fact')
    jfh = open(jsonfile, 'w')
    jfh.write('{"json_key": "json_value"}')
    jfh.close()

    # make a non-json file
    njfile = os.path.join(tmpdir, 'nonjson.fact')
    njfh = open(njfile, 'w')

# Generated at 2022-06-20 19:40:47.150116
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert isinstance(LocalFactCollector(), BaseFactCollector)

# Generated at 2022-06-20 19:40:57.886807
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    # Mock a module
    module = AnsibleModuleMock()

    # Initialize a local fact collector
    lfc = LocalFactCollector()

    # Test collect on an existing fact_path
    module.params = {'fact_path': 'facts/local'}

    # Run collect method
    facts = lfc.collect(module)

    # Test that the collect method returns a non null result
    assert facts is not None
    assert 'local' in facts

    # Test that the collect method returns a result with the expected facts
    assert 'os_version' in facts['local']
    assert 'output' in facts['local']['os_version']
    assert 'distribution' in facts['local']['os_version']['output']

# Generated at 2022-06-20 19:41:07.027804
# Unit test for method collect of class LocalFactCollector