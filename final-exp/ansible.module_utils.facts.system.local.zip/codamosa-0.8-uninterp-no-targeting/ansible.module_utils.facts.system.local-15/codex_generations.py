

# Generated at 2022-06-20 19:32:45.698380
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import tempfile
    from ansible.module_utils.facts.collector import FactsCollector

    # Write content to temporary file and set up test data
    temp_dir = tempfile.TemporaryDirectory()

    test_fact_path = ['path_1', 'path_2']
    test_rel_fact_path = ['rel_path_1', 'rel_path_2']
    test_fact = 'test_fact'
    test_fact_file_name = test_fact + '.fact'
    test_fact_1 = 'test_fact_1'
    test_rel_fact_1 = 'rel_fact_1'
    test_fact_content = 'test_fact_content'
    test_rel_fact_content = 'test_rel_fact_content'

    # Create content of test fact files in temporary directory

# Generated at 2022-06-20 19:32:49.402167
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    lfc = LocalFactCollector()
    assert lfc._fact_ids == set()
    assert lfc.name == 'local'
    assert hasattr(lfc, 'collect')
    assert callable(lfc.collect)

# Generated at 2022-06-20 19:33:01.367538
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # AnsibleModule object created so that things can be mocked
    module = AnsibleModule(
        argument_spec={'fact_path': {'type': 'str', 'required': True, 'default': None}}
    )

    # Mock module's run_command method
    real_run_command = module.run_command

# Generated at 2022-06-20 19:33:02.958133
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    try:
        result = LocalFactCollector()
    except Exception as e:
        print(e)


# Generated at 2022-06-20 19:33:15.112678
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts import ModuleDataConsumer
    from ansible.module_utils.facts.collector.local import LocalFactCollector

    def format_data(data, pretty=False):
        data = json.loads(json.dumps(data))
        if pretty:
            return json.dumps(data, sort_keys=True, indent=4, separators=(',', ': '))
        else:
            return json.dumps(data, sort_keys=True)

    class MockModule(object):
        params = {
            'fact_path': '/tmp/local_facts'
        }

        def warn(self, msg):
            pass

        def run_command(self, cmd):
            return 0, '', ''

    module = MockModule()
    consumer = ModuleDataConsumer()


# Generated at 2022-06-20 19:33:15.849614
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass

# Generated at 2022-06-20 19:33:16.847925
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    l = LocalFactCollector()


# Generated at 2022-06-20 19:33:27.318997
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.local import LocalFactCollector
    from ansible.module_utils.facts.collector.test_mock.module import TestModule

    test_module = TestModule
    test_module.params = {'fact_path': './lib/ansible/module_utils/facts/collector/test_mock/facts.d'}
    test_module.warn = lambda x: print('WARNING: %s' % x)

    lfc = LocalFactCollector(module=test_module)
    collected_facts = lfc.collect()

# Generated at 2022-06-20 19:33:28.617419
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    collector = LocalFactCollector()
    assert collector.name is not None

# Generated at 2022-06-20 19:33:30.055086
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    collector = LocalFactCollector()
    facts = collector.collect()

    assert facts.has_key('local')
    assert len(facts['local']) == 0

    for key, value in facts['local'].items():
        assert key
        assert value

# Generated at 2022-06-20 19:33:44.190126
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    mock_module = type('MockModule', (object,), {})()
    mock_module.run_command = lambda x: ('', '', '')
    mock_module.params = {
        'fact_path': '/etc/ansible/facts.d/',
    }
    collected_facts = {}
    local_fact_collector = LocalFactCollector()
    local_facts = local_fact_collector.collect(mock_module, collected_facts)

    assert isinstance(local_facts['local'], dict)
    assert local_facts['local'] == {'test': ''}

# Generated at 2022-06-20 19:33:45.959990
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    lfc = LocalFactCollector()
    assert lfc.name == 'local'
    assert lfc._fact_ids == set()


# Generated at 2022-06-20 19:33:52.267165
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import os
    import shutil
    import tempfile
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import get_collector_instance

    # Create temporary fact path
    fact_dir = tempfile.mkdtemp()

    # Create 2 fact files in it
    fact_file_1 = os.path.join(fact_dir, 'fact_1.fact')
    to_write = to_bytes('{ "fact_1": "fact_1_value" }')
    with open(fact_file_1, 'w') as f:
        f.write(to_write)
    # Create a symlink to ensure it is not followed

# Generated at 2022-06-20 19:34:02.181458
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts import FactCollection
    from ansible.module_utils.facts.collector import collec_facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.facts import Fact
    from ansible.module_utils.facts.utils import get_file_content

    module = 'ansible.module_utils.facts.collector'
    # Load module.run_command
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={}, supports_check_mode=True)
    # Load get_file_content
    module = ansible.module_utils.basic.AnsibleModule(argument_spec={}, supports_check_mode=True)
    # Load module.warn
    module = ansible.module_utils

# Generated at 2022-06-20 19:34:05.512745
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
  collector = LocalFactCollector()
  assert collector.name == 'local'
  assert len(collector._fact_ids) == 0


# Generated at 2022-06-20 19:34:06.564212
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert isinstance(LocalFactCollector, object)

# Generated at 2022-06-20 19:34:08.377238
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

    local_fact_collector = LocalFactCollector()

    assert local_fact_collector is not None
    assert 'local' == local_fact_collector.name

# Generated at 2022-06-20 19:34:18.735918
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    class MockModule():
        params = {"fact_path":"/tmp"}
        def warn(self,msg):
            print(msg)
        def run_command(self,cmd):
            return 0, "Test", ""
    m = MockModule()
    l = LocalFactCollector()
    actual = l.collect(module=m)
    # No fact file found, no facts are returned
    assert(not actual)
    # Create a fact file for LocalFactCollector
    with open("/tmp/test.fact","w") as f:
        f.write('{"test1":{"a":"A","b":"B"}}')
    # Run LocalFactCollector again
    actual = l.collect(module=m)
    assert(actual)
    assert(actual['local'])
    assert('test1' in actual['local'])

# Generated at 2022-06-20 19:34:20.571560
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local = LocalFactCollector()
    assert local is not None

# Generated at 2022-06-20 19:34:29.586709
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    src_dir = os.path.dirname(os.path.abspath(__file__))
    local_fact_path = os.path.join(src_dir, 'fixtures/local_facts')
    local_facts = LocalFactCollector({'fact_path': local_fact_path}).collect()
    assert len(local_facts) == 1
    assert local_facts['local']['disk']['sda1']['size'] == '20GB'
    assert local_facts['local']['error_fact'] == 'error loading fact - output of running "fixtures/local_facts/error_fact.fact" was not utf-8'

# Generated at 2022-06-20 19:34:42.433766
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass

# Generated at 2022-06-20 19:34:47.874522
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    def test_method(module):
        pass
    fact_path = '/Users/jean-philippe/Documents/workspace/ansible/ansible/module_utils/facts/local'
    x = LocalFactCollector(test_method, fact_path)
    assert x.name == 'local'
    assert x._fact_ids == set()


# Generated at 2022-06-20 19:34:50.990094
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

    lfc = LocalFactCollector()

    print("\n")
    print("Test: '', expected: 'local'")
    print(lfc.name)

    print(lfc._fact_ids)

# Generated at 2022-06-20 19:34:53.137148
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    obj = LocalFactCollector()
    assert obj.name == 'local'

# Generated at 2022-06-20 19:34:58.393878
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """
    This function test for class LocalFactCollector with method collect.
    """

    result = {}

    module = AnsibleModule(
        argument_spec=dict(
            fact_path=dict(default="/some/path"),
        ),
        supports_check_mode=True
    )

    local = LocalFactCollector()
    result = local.collect(module)

    assert result['local']

# Generated at 2022-06-20 19:35:00.559890
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fact_path = "sample_fact"
    test_obj = LocalFactCollector(fact_path)
    assert test_obj.name == "local"

# Generated at 2022-06-20 19:35:09.081788
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    # ensure not collect facts if fact_path does not exists
    lfc = LocalFactCollector()
    assert lfc.collect()['local'] == {}
    assert lfc.collect(fact_path='/tmp/')['local'] == {}

    # ensure return just from .fact files
    old_path = os.environ['PATH']
    os.environ['PATH'] = '/tmp'


# Generated at 2022-06-20 19:35:21.086970
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """
    Unit test for method collect of class LocalFactCollector
    """

    # patch AnsibleModule so we can return facts from mock_run_command
    from ansible.module_utils.facts.local.test.test_local_facts import FakeModule
    from ansible.module_utils.facts.local.test.test_local_facts import FakeAnsibleModule

    ansible_module = FakeAnsibleModule()
    ansible_module.params = dict(fact_path='/etc/ansible/facts.d', gather_subset=['all'])
    module = FakeModule(ansible_module)

    # test collect when facts module is not loaded
    result = LocalFactCollector().collect(None, None)
    assert result == {'local': {}}

    # test collect when fact_path is not provided or is not a

# Generated at 2022-06-20 19:35:25.006449
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_facts = {}
    local_facts['local'] = {}
    module = {}
    module['params'] = {}
    module['params']['fact_path'] = '/tmp/ansible-facts/'
    collector = LocalFactCollector()
    assert collector.collect(module=module) == local_facts


# Generated at 2022-06-20 19:35:26.631167
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    lfc = LocalFactCollector()

    assert lfc.name == 'local'
    assert lfc._fact_ids == set()

# Generated at 2022-06-20 19:35:54.850787
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    result = { "local": { "fact1": "bar", "fact2": "baz", "fact3": "foo" } }
    assert LocalFactCollector.collect(None, None) == result

# Generated at 2022-06-20 19:35:55.658125
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    LocalFactCollector.collect(module=None, collected_facts=None)
#

# Generated at 2022-06-20 19:36:01.255461
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    os.environ['ANSIBLE_FACT_CACHE'] = '/var/tmp/ansible-local'
    os.environ['ANSIBLE_CACHE_PLUGIN_CONNECTION'] = 'jsonfile'

    module = AnsibleModule(argument_spec={'fact_path': {'required': True, 'type': 'path'}})

    # TODO: Add code here to test the method collect
    #       of class LocalFactCollector

# Generated at 2022-06-20 19:36:06.541298
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """Test the collect method of LocalFactCollector
    """
    # Test for missing fact_path
    local_facts = {}
    local_facts['local'] = {}
    assert dict(LocalFactCollector().collect(module)) == local_facts

    # Test for empty fact_path
    local_facts = {}
    local_facts['local'] = {}
    assert dict(LocalFactCollector().collect(module=None)) == local_facts

# Generated at 2022-06-20 19:36:13.998943
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import os
    import stat
    import glob
    import json
    import tempfile
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common._collections_compat import Mapping, Iterable, Sequence
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts import collector
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import text_type, iteritems

    # This is a skeleton test to get some framework in place.
    # You should use `python -m pytest -p no:warnings test/unit/module_utils/facts/test_collector.py` to run these tests.

# Generated at 2022-06-20 19:36:15.611326
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_obj = LocalFactCollector()
    assert local_obj.name == 'local'

# Generated at 2022-06-20 19:36:25.578351
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    test_m = MockModule()
    test_m.params = {'fact_path': '/fact/path'}
    test_c = LocalFactCollector()

    res = {'local': {"fact_base_1": "fact_1", "fact_base_2": "fact_2"}}

    test_c._listdir = Mock(return_value=["script_1", "script_2"])
    test_c.can_load = Mock(side_effect=[True, True, False, True, False])
    test_c._exec_local_fact = Mock(side_effect=["fact_1", "fact_2"])
    assert res == test_c.collect(module=test_m)

# Generated at 2022-06-20 19:36:34.735409
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """
    Test for method collect of class LocalFactCollector
    """
    # If fact_path is not specified, it should return empty dictionary
    local_facts = {}
    assert LocalFactCollector().collect(collected_facts=local_facts) == local_facts

    test_path = os.path.dirname(__file__)
    fact_path = os.path.join(test_path, '../lib/ansible/module_utils/facts/facts.d')
    assert os.path.exists(fact_path)

    # If fact_path is not specified, it should return dictionary with key "local"
    local_facts = {}
    assert LocalFactCollector().collect(module=dict(params=dict(fact_path=fact_path)), collected_facts=local_facts) == local_facts

    # fact_path is

# Generated at 2022-06-20 19:36:45.303003
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import sys
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ansible_runner

    # Disable pylint message: Access to a protected member _ansible_module of a client class
    # pylint: disable=W0212

    tmp_path = None


# Generated at 2022-06-20 19:36:46.303248
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    assert False


# Generated at 2022-06-20 19:37:45.552715
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_collector = LocalFactCollector()
    assert local_collector.name == 'local'

# Generated at 2022-06-20 19:37:46.219783
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    collector = LocalFactCollector()
    assert collector.collect() == None

# Generated at 2022-06-20 19:37:48.843728
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # >>> from ansible.module_utils.facts.local import LocalFactCollector
    # >>> local_collector = LocalFactCollector()
    # >>> local_collector.collect(module=None)
    # {'local': {}}
    pass

# Generated at 2022-06-20 19:37:50.458408
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    collector = LocalFactCollector()
    assert collector.name == 'local'

# Generated at 2022-06-20 19:38:00.389720
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(argument_spec={'fact_path':{'type':'str'}})
    module.params['fact_path'] = '../unit/data/local'
    module.run_command = lambda x: (0,'localhost','')

    # Data capture
    class AnsibleModuleHelper(object):
        @staticmethod
        def run_command(cmd):
            return (0,'localhost','')

        @staticmethod
        def warn(msg):
            assert False

    def run_command(cmd):
        return (0,'localhost','')

    def warn(msg):
        assert False

    module.run_command = run_command
    module.warn = warn

    lfc = LocalFactCollector()
    collected_facts = lfc.collect

# Generated at 2022-06-20 19:38:02.290023
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector().name == 'local'

# Generated at 2022-06-20 19:38:03.721695
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    lfc = LocalFactCollector()
    assert lfc is not None

# Generated at 2022-06-20 19:38:05.942160
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    collector = LocalFactCollector()
    assert collector.name == 'local'
    assert len(collector._fact_ids) == 0

# Generated at 2022-06-20 19:38:14.224691
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    import os
    import tempfile

    # Dict with type information for LocalFactCollector.collect()
    argspec_collect = {
        'params': {
            'fact_path': {},
        },
        'returns': {
            'local': {},
        },
    }

    default_fact_path = '/usr/share/ansible/local/facts.d'
    test_fact_path = tempfile.mkdtemp()
    print(test_fact_path)

    # Create a fact file that will be used by the test
    # NOTE: The fact is a JSON string, so it is escaped
    fact_file = os.path.join(test_fact_path, 'example.fact')

# Generated at 2022-06-20 19:38:23.977146
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
  fact_path = "/etc/ansible/facts.d"
  fact_name_1 = "test_fact.fact"
  fact_name_2 = "test_fact.fact_json"
  fact_name_3 = "test_fact.fact_ini"
  fact_name_4 = "test_fact.fact_error"
  fact_name_5 = "test_fact.fact_json_error"
  fact_name_6 = "test_fact.fact_ini_error"
  fact_content_1 = "fact_content"
  fact_content_2 = '{"fact_content": {"fact_key": "fact_val"}}'
  fact_content_3 = "[section]\nfact_key = fact_val"
  fact_content_4 = "ERROR"

# Generated at 2022-06-20 19:40:43.375348
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    collector = LocalFactCollector()
    name = 'local'
    assert collector.name == name, "Collector name is wrong"

# Generated at 2022-06-20 19:40:46.585152
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    module = type('', (),{})()
    module.params = {'fact_path': '/tmp'}
    assert isinstance(LocalFactCollector(module), LocalFactCollector)

# Generated at 2022-06-20 19:40:48.331434
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    x = LocalFactCollector()
    assert x.name == 'local'

# Generated at 2022-06-20 19:40:58.513638
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import ansible.module_utils.facts.collectors as facts_collectors
    from ansible.module_utils.facts import ansible_local_facts

    # test method collect of LocalFactCollector
    assert issubclass(facts_collectors.local.LocalFactCollector, facts_collectors.BaseFactCollector)
    collector = facts_collectors.local.LocalFactCollector()
    assert collector.name == 'local'
    assert collector._fact_ids == set()

    result = collector.collect(module = None, collected_facts = None)
    assert result == {}

    current_dir = os.path.dirname(os.path.realpath(__file__))
    test_data_dir = os.path.join(current_dir, "..", "test_data", "facts", "local")
    assert os.path

# Generated at 2022-06-20 19:41:00.657895
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    localFactCollector = LocalFactCollector()
    assert localFactCollector.name == 'local'

# Generated at 2022-06-20 19:41:03.274810
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    test_fact_collector = LocalFactCollector(None)
    assert test_fact_collector.name == 'local'


# Generated at 2022-06-20 19:41:05.298051
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    lfc = LocalFactCollector()
    assert lfc.name == 'local'
    assert lfc._fact_ids == set()
    assert type(lfc) == LocalFactCollector

# Generated at 2022-06-20 19:41:07.352855
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # TODO: Implement an unit test that does not require a playbook to be passed in
    pass

# Generated at 2022-06-20 19:41:18.295280
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    module = {"module_arg_spec":{
                                 "params": {
                                    "fact_path":{
                                        "type": "str",
                                        "required": False,
                                        "default": "/etc/ansible/facts.d"
                                      }
                                    }
                                 }
             }


# Generated at 2022-06-20 19:41:26.701767
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import ansible_facts

    c = ansible_facts.LocalFactCollector()
    assert c.name == 'local'

    module = basic.AnsibleModule(argument_spec={'fact_path': {'type': 'path', 'required': True}})
    module.params['fact_path'] = os.path.join(os.path.dirname(__file__), 'assets', 'local_facts')
    result = c.collect(module)
    assert result == {'local': {'test': 'this is a test',
                                'test3': 'this is a third test',
                                'test2': {'third': 'test', 'second': 'test'}}}, result