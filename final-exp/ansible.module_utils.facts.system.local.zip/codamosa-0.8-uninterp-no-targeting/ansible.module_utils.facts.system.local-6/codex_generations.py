

# Generated at 2022-06-20 19:32:35.637084
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    '''
        Function to test the constructor of class LocalFactCollector
        :return:
        '''
    assert isinstance(LocalFactCollector(), BaseFactCollector)

# Generated at 2022-06-20 19:32:36.688689
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector()

# Generated at 2022-06-20 19:32:41.136700
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert issubclass(LocalFactCollector, BaseFactCollector)
    assert LocalFactCollector.name == 'local'
    assert LocalFactCollector._fact_ids == set()
    assert LocalFactCollector.collect.__doc__.startswith('Collect facts for local')

# Generated at 2022-06-20 19:32:42.233164
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    t = LocalFactCollector()
    assert t.name == 'local'

# Generated at 2022-06-20 19:32:53.064874
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec = dict(
            fact_path = dict(type='str')
        )
    )

    # mock module.run_command
    module.run_command = lambda fn: (0, '{"some_fact": "some_value"}', '')

    # mock module.warn
    module.warn = lambda msg: None

    # create instance
    instance = LocalFactCollector()

    # execute collect method
    result = instance.collect(module=module)

    # check result
    assert(result) == {'local': {'fact_script': {'some_fact': 'some_value'}}}

# Generated at 2022-06-20 19:32:54.316932
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    c = LocalFactCollector()
    assert c.name == "local"

# Generated at 2022-06-20 19:33:04.699145
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    class Module():
        def run_command(command):
            return2 = [1, '', 'test']
            return return2

        def warn(txt):
            return
    class CollectedFacts():
        pass
    testmodule = Module()
    collected_facts = CollectedFacts()
    collected_facts.ansible_local = {}
    test_fact_path = "./test_fact"

    testmodule.params = {
        'fact_path': test_fact_path
    }

    test_local_facts = LocalFactCollector()
    returned_facts = test_local_facts.collect(testmodule, collected_facts)
    assert returned_facts.get('local')
    assert returned_facts['local'].get('test')

# Generated at 2022-06-20 19:33:10.188382
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """
    test_LocalFactCollector_collect
    """
    from ansible.module_utils._text import to_text
    from ansible.module_utils.facts.utils import get_file_content

    executor = LocalFactCollector()
    result = executor.collect()
    assert result == {}



# Generated at 2022-06-20 19:33:11.026589
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass

# Generated at 2022-06-20 19:33:13.500264
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    m = AnsibleModule(argument_spec={})
    fc = LocalFactCollector()
    fc.collect(module=m)

# Generated at 2022-06-20 19:33:20.501067
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    return None

# Generated at 2022-06-20 19:33:22.389775
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    obj = LocalFactCollector()
    assert obj.name == 'local'

# Generated at 2022-06-20 19:33:32.035321
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    class mydict(dict):
        def __init__(self, *args):
            super(mydict, self).__init__(*args)

        def __getattr__(self, name):
            return self.get(name, None)

        def __setattr__(self, name, value):
            self[name] = value

    class mymodule(object):
        def __init__(self, params, local_facts, run_command_results):
            self.params = mydict(params)
            self.local_facts = local_facts
            self.run_command_results = run_command_results
            self.warnings = []

        def warn(self, warning):
            self.warnings.append(warning)

        def run_command(self, cmd):
            return self.run_command_results[cmd]

   

# Generated at 2022-06-20 19:33:34.130435
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    x = LocalFactCollector()
    assert x is not None

# Generated at 2022-06-20 19:33:44.859981
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import pytest
    from ansible.module_utils.facts.utils import AnsibleFactEnvironment
    from ansible.module_utils.facts.collector import FactCollector

    # Set up the environment for facts collection
    fact_env = AnsibleFactEnvironment()
    fact_env.add_module('_text', 'ansible.module_utils._text')
    fact_env.add_module('configparser', 'ansible.module_utils.six.moves.configparser')

    # Set up a LocalFactCollector instance
    fact_collector = FactCollector()
    local_fact_collector = LocalFactCollector(fact_collector=fact_collector)

    # Create a resource type module

# Generated at 2022-06-20 19:33:47.246782
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    instance = LocalFactCollector()
    assert isinstance(instance,LocalFactCollector)
    assert instance.name == "local"
    assert isinstance(instance._fact_ids,set)

# Generated at 2022-06-20 19:33:59.572892
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.local import LocalFactCollector

    # Initialize the local fact collector
    lfc = LocalFactCollector()

    # Verify the attribute of the lfc
    assert lfc.name == 'local'
    assert lfc._fact_ids == set()

    # Verify the collect method
    assert lfc.collect() == {}

    # Verify the collect method with the parameter collected_facts
    assert lfc.collect(collected_facts={}) == {}

    # Verify the collect method with the parameter module
    assert lfc.collect(module=None) == {'local': {}}

    # Initialize the ansible fact collector
    afc = Ans

# Generated at 2022-06-20 19:34:09.346297
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts import ansible_local

    def run_command(self, command):
        return None, '{ "test": "it" }', None

    # Compose a testcase
    testcase = [
        {
            'fact_path': './test_dir',
            'run_command': run_command
        }
    ]

    # Compose expected results
    expected_result = {'local': {'test_file': {'test': 'it'}}}

    # Test method
    result = ansible_local.collect(testcase[0])

    # Assertion
    assert result == expected_result

# Generated at 2022-06-20 19:34:11.465299
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    module = None

    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-20 19:34:14.501736
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fc = LocalFactCollector()
    assert fc.name == 'local'
    assert isinstance(fc._fact_ids, set)


# Generated at 2022-06-20 19:34:28.205088
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    print("test_LocalFactCollector_collect")
    facts = LocalFactCollector()
    data = facts.collect()
    assert data is not None

# Generated at 2022-06-20 19:34:29.981971
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # make sure the .fact files are ignored
    assert LocalFactCollector.collect(None) == {'local': {}}

# Generated at 2022-06-20 19:34:33.555330
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    localFactCollector = LocalFactCollector()
    assert isinstance(localFactCollector, LocalFactCollector)

# Generated at 2022-06-20 19:34:36.210825
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """ Test class LocalFactCollector with method collect.
    """
    # Test environment
    # import ansible.module_utils.facts.collectors.local

    # TODO



# Generated at 2022-06-20 19:34:40.449383
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()
    assert 'local' in local_fact_collector.collect().keys()

# UT for the method collect() of class LocalFactCollector

# Generated at 2022-06-20 19:34:52.595939
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    def run_command(self):
        return 1, '{}', 'error'

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import ansible_collections
    my_facts = ansible_collections['ansible_collections.my_collection']['plugins']['facts']
    local_fact_collector = my_facts.LocalFactCollector()
    module = AnsibleModule({'fact_path': '{}/ansible_collections/my_collection/plugins/facts/test/units/module_utils/local'.format(os.path.dirname(os.path.abspath(__file__)))})
    module.run_command = run_command.__get__(module)
    facts = local_fact_collector.collect(module)

# Generated at 2022-06-20 19:34:55.731467
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fact_collector = LocalFactCollector()
    assert fact_collector.name == 'local'
    assert isinstance(fact_collector._fact_ids, set)
    assert not fact_collector._fact_ids

# Generated at 2022-06-20 19:34:59.871276
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    fc = LocalFactCollector()
    ansible_module = None
    collected_facts =  fc.collect(module=ansible_module, collected_facts=None)
    assert collected_facts == {'local': {}}, "Expected {'local': {}}, GOT {0}".format(collected_facts)

# Generated at 2022-06-20 19:35:03.711310
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Setup class for test
    collector = LocalFactCollector()
    collector.name = 'local'

    # Setup params for test
    params = { 'fact_path': '/tmp/test' }

    # Setup results and check correct value returned
    results = {}
    results['local'] = {}
    assert collector.collect(params, results) == results

# Generated at 2022-06-20 19:35:05.275190
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local = LocalFactCollector()
    collected_facts = local.collect()

    assert collected_facts == {}

# Generated at 2022-06-20 19:35:32.265412
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact = LocalFactCollector()
    assert local_fact.name == 'local'
    assert local_fact._fact_ids == set()

# Generated at 2022-06-20 19:35:34.865640
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    localFactCollector = LocalFactCollector()

    assert localFactCollector
    assert localFactCollector.name == 'local'
    assert localFactCollector._fact_ids == set()


# Generated at 2022-06-20 19:35:37.591959
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    lfc = LocalFactCollector()
    assert lfc.name == 'local'
    assert lfc._fact_ids == set()
    assert lfc.collect() == {}

# Generated at 2022-06-20 19:35:39.070834
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact = LocalFactCollector()
    assert local_fact.name == "local"



# Generated at 2022-06-20 19:35:41.602013
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-20 19:35:44.854341
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    class TestModule:
        def __init__(self):
            self.params = {}
            self.warn = lambda x: x
    obj = LocalFactCollector(TestModule)

    assert obj.name == 'local'

# Generated at 2022-06-20 19:35:46.318599
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert str(LocalFactCollector) == '<ansible.module_utils.facts.local.LocalFactCollector>'

# Generated at 2022-06-20 19:35:48.654776
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-20 19:35:53.103979
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'
    assert local_fact_collector._fact_ids == set()

# Generated at 2022-06-20 19:36:03.239516
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """
    Testing method collect of class LocalFactCollector.
    """

    # Creating a mock module and facts
    module = MagicMock()
    module.params = {'fact_path': 'test_path'}
    collected_facts = None

    # Setting up needed objects
    os.path.exists = Mock(return_value=True)
    os.stat = Mock(return_value=1)
    glob.glob = Mock(return_value=['test_path/test.fact'])
    os.path.basename = Mock(return_value='test.fact')
    module.run_command = Mock(return_value=[0, 'out', 'err'])
    module.warn = Mock()

    local = {}

    # Defining expected results

# Generated at 2022-06-20 19:36:55.656456
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local = LocalFactCollector()
    assert local.name == 'local'
    assert local._fact_ids == set()

# Generated at 2022-06-20 19:37:06.379373
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    fact_path = os.path.join(os.path.dirname(__file__), '../../test/unit/module_utils/facts/local/fact_path')
    local_fact_collector = LocalFactCollector()
    local_facts = local_fact_collector.collect(fact_path=fact_path)
    assert len(local_facts) == 1
    local = local_facts['local']
    assert len(local) == 3
    assert local['json'] == {"foo": "bar"}
    assert local['ini'] == {
        "foo": {
            "baz": "qux"
        }
    }
    assert local['noconvert'].startswith("I am a fact. ")

# Generated at 2022-06-20 19:37:15.855727
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    class MockModule:
        pass
    mod = MockModule()
    mod.params = {'fact_path': '/etc/ansible/facts.d'}
    mod.run_command = lambda x: (0, '{"a": "1"}', None)
    collected_facts = {}
    facts = LocalFactCollector(mod).collect(mod, collected_facts)
    assert 'local' in facts
    assert facts['local'] == {"a": "1"}

# Generated at 2022-06-20 19:37:29.808672
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import os
    import sys
    import tempfile

    # Creating a temporary directory for test cases
    temp_dir = tempfile.mkdtemp()

    # Testing fact_base
    if sys.version_info[0] < 3:
        file_value = 'test_case'
    else:
        file_value = b'test_case'

    # Creating a temporary file for test cases
    test_file = open(os.path.join(temp_dir,'test.fact'), 'wb')
    test_file.write(file_value)
    test_file.close()

    # Creating object of LocalFactCollector
    local_fact_collector = LocalFactCollector()

    # test_path doesn't exist
    test_path = os.path.join(temp_dir,'test_path')

# Generated at 2022-06-20 19:37:34.223986
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
   module = ''
   collected_facts = ''
   
   localFactCollector = LocalFactCollector()
   localFactCollector.collect(module, collected_facts)


# Generated at 2022-06-20 19:37:34.839987
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    assert True

# Generated at 2022-06-20 19:37:36.776194
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    collector = LocalFactCollector()
    assert (collector.name == 'local')

# Generated at 2022-06-20 19:37:37.382800
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    LocalFactCollector()

# Generated at 2022-06-20 19:37:39.736772
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local = LocalFactCollector()
    assert local.name == 'local'
    assert local._fact_ids == set()

# Generated at 2022-06-20 19:37:51.008240
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    attrs = {
        'params': {
            'fact_path': './test_data/custom/facts'
        },
    }
    module = type('test', (), attrs)
    facts_collector = LocalFactCollector()
    result = facts_collector.collect(module)

# Generated at 2022-06-20 19:38:39.329774
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Test with fact_path set to valid directory
    set_module_args({'fact_path': '/etc/ansible/facts.d'})
    local_facts = LocalFactCollector()
    facts = local_facts.collect()
    assert 'local' in facts, "Test with fact_path set to valid directory failed."
    # Test with fact_path set to invalid directory
    set_module_args({'fact_path': ''})
    local_facts = LocalFactCollector()
    facts = local_facts.collect()
    assert 'local' not in facts, "Test with fact_path set to invalid directory failed."
    # Test with fact_path set to a file
    set_module_args({'fact_path': '/etc/ansible/facts.d/test.fact'})
    local_facts = LocalFactCollector()


# Generated at 2022-06-20 19:38:41.249600
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    LocalFactCollector_collect = LocalFactCollector()
    assert LocalFactCollector_collect.collect() == {'local': {}}


# Generated at 2022-06-20 19:38:44.999659
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    from ansible.module_utils.facts.collectors import get_collector_names
    for name in get_collector_names():
        assert isinstance(getattr(getattr(__import__('ansible.module_utils.facts.collectors', fromlist=[name]), name), '__collector__', None),
                          BaseFactCollector), 'Fact collector %s is not a subclass of BaseFactCollector' % name

# Generated at 2022-06-20 19:38:47.316696
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

    local_facts = LocalFactCollector()
    assert local_facts.name == 'local'
    assert local_facts._fact_ids == set()

# Generated at 2022-06-20 19:38:53.735743
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    # Arrange
    class FakeModule:
        def run_command(self, cmd):
            return (1, u"", u"")
        params = {'fact_path': '/some/path'}

    class FakeCollector:
        name = 'local'

    collector = LocalFactCollector(FakeModule(), FakeCollector())

    # Act
    results = collector.collect()

    # Assert
    assert results == {'local': {}}, 'results != {\'local\': {}}'

# Generated at 2022-06-20 19:38:59.315425
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils import basic
    import ansible.module_utils.facts.collector

    m = basic.AnsibleModule(
        argument_spec = dict(
            fact_path = dict(type='str', required=False),
        ),
        supports_check_mode=True,
    )

    lfc = ansible.module_utils.facts.collector.get_collector('local')
    facts = lfc.collect(m)

    assert not facts['local'].get('bad_json', False)
    assert facts['local'].get('molecule', False)
    assert not facts['local'].get('bad_ini', False)


# Generated at 2022-06-20 19:39:06.735452
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    fact_path = os.path.dirname(os.path.abspath(__file__)) + '/files/facts'

    local_fact_collector = LocalFactCollector()
    local_facts = local_fact_collector.collect(None)

    assert local_facts == {'local': {}}

    class MockModule(object):
        def __init__(self):
            self.params = {'fact_path': fact_path}

        def run_command(self, command):
            return 0, 'OUTPUT1', ''
        def warn(self, message):
            pass

    local_fact_collector = LocalFactCollector()
    local_facts = local_fact_collector.collect(MockModule())


# Generated at 2022-06-20 19:39:08.684861
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'


# Generated at 2022-06-20 19:39:13.566691
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    class DummyModule:
        params = {'fact_path': 'tests/unit/module_utils/facts/local/'}

    local_collector = LocalFactCollector(DummyModule())
    assert local_collector.name == 'local'
    assert local_collector._fact_ids == set()

# Generated at 2022-06-20 19:39:22.749586
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    mock_module = type('MockModule', (object,), dict(
        run_command=lambda self, x: (0, '{"foo": 42}', ''),
        params=dict(
            fact_path='/etc/ansible/facts.d',
        ),
        warn=lambda self, msg: None,
    ))

    mock_module_instance = mock_module()

    fact_path = mock_module_instance.params['fact_path']
    test_file = os.path.join(fact_path, 'foo.fact')


# Generated at 2022-06-20 19:41:11.654676
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    import ansible.module_utils.facts.collector
    assert isinstance(ansible.module_utils.facts.collector.get_collector('local'), LocalFactCollector)

# Generated at 2022-06-20 19:41:22.442970
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import ansible.module_utils.basic
    import ansible.module_utils.facts.collector

    facts_dict = dict()
    files = ['test1.fact', 'test2.fact', 'test3.fact', 'test4.fact']
    path = '/etc/ansible/facts.d/'

    class MockModule(object):
        def __init__(self, params):
            self.params = params
            self.run_command_calls = 0
            self.warn_calls = 0
            self.debug_calls = 0

        def run_command(self, cmd):
            self.run_command_calls += 1
            if cmd.endswith('test1.fact'):
                return 0, '{"test1": "testValue1"}', ''

# Generated at 2022-06-20 19:41:28.952218
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import CollectedFacts
    from ansible.module_utils.facts.collectors.local import LocalFactCollector
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.utils import get_file_content

    # Initialize the facts collector
    local_collector = LocalFactCollector()

    # If facts.d path is wrong should return emtpy local facts
    # No check as module object is not passed
    local_collector.collect()

    # Initialize the Ansible module object
    module = AnsibleModule('', {})

    # Initialize the collected_facts object
    collected_facts = CollectedFacts()

    # Create temp file under current directory

# Generated at 2022-06-20 19:41:29.466060
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    pass

# Generated at 2022-06-20 19:41:31.765985
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    local_fact_collector = LocalFactCollector()
    module = object()
    results = local_fact_collector.collect(module)
    assert results == {'local': {}}

# Generated at 2022-06-20 19:41:42.584537
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    m = MockModule()
    lfc = LocalFactCollector()
    test_path = os.path.join(os.path.dirname(__file__), 'test', 'unit', 'test_module_utils_facts_local_test')
    m.params = {'fact_path':test_path}
    m.run_command = Mock(return_value=(0,'','no error'))
    lfc.collect(module=m, collected_facts={'ansible_local':{'no_fact_path':None}})
    assert m.run_command.call_count == 1
    m.run_command.assert_called_with(os.path.join(test_path, 'executable.fact'))
    assert m.warn.call_count == 0

# Generated at 2022-06-20 19:41:45.554171
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    lf = LocalFactCollector()
    assert lf.name == 'local'
    assert lf._fact_ids == set()


# Generated at 2022-06-20 19:41:50.498016
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    collector = LocalFactCollector()
    module = AnsibleModuleMock()
    module.params = {'fact_path': os.path.dirname(__file__)}
    result = collector.collect(module=module)
    assert 'local' in result
    assert result['local'] == {u'fact_path fact': os.path.dirname(__file__)}


# Generated at 2022-06-20 19:41:54.999128
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():

    # Parameters
    module = None
    collected_facts = None

    # Create object
    obj = LocalFactCollector()

    # Return values
    assert obj.name == 'local'
    assert obj._fact_ids == set()

    # Return values
    assert obj.collect(module, collected_facts) == {'local': {}}


# Generated at 2022-06-20 19:41:59.857831
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import ansible.module_utils.facts.collector

    module = ansible.module_utils.facts.collector.BaseFactCollector()
    local_instance = LocalFactCollector()
    collected_facts = {}
    local_facts = local_instance.collect(module, collected_facts)
    assert type(local_facts) is dict
    assert 'local' in local_facts
    assert type(local_facts['local']) is dict