

# Generated at 2022-06-20 19:32:38.075977
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()

    assert local_fact_collector.name == 'local'
    assert len(local_fact_collector._fact_ids) == 0



# Generated at 2022-06-20 19:32:44.695463
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # the module is Mocked
    module = Mock()
    module.params = {'fact_path': '/some/path'}
    # get_file_content is mocked and return an empty string
    get_file_content = Mock(name='get_file_content', return_value='')
    # glob.glob is mocked and return two items:
    # - a real file (and not executable) with the extension .fact
    # - a fake file that do not exists
    glob_mock = Mock(name='glob.glob', return_value=['/some/path/file.fact', '/some/path/fake_file.txt'])
    # os.path.exists is mocked and return True when the path is equals to /some/path/file.fact

# Generated at 2022-06-20 19:32:55.106577
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    from ansible.module_utils.facts.collector import get_collector_instance

    def mock_run_command(arg):
        return [0, 'success', '']

    def mock_warn(arg):
        raise Exception(arg)

    local_facts = dict()
    local_facts['local'] = dict()
    local_facts['local']['mock_fact_base'] = 'mock_fact'
    local_facts['local']['mock_fact_base1'] = 'mock_fact1'
    local_facts['local']['mock_fact_base2'] = 'mock_fact2'
    local_facts['local']['mock_fact_base3'] = 'mock_fact3'

# Generated at 2022-06-20 19:33:05.566360
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import get_file_content

    import errno
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import default_collectors

    # Create temporary directory for local facts
    fact_dir = tempfile.mkdtemp()
    fact_file1 = os.path.join(fact_dir, 'foo.fact')
    fact_file2 = os.path.join(fact_dir, 'bar.fact')
    fact_file3 = os.path.join(fact_dir, 'ziplock.fact')
    fact_file4 = os.path.join(fact_dir, 'bin')

    # Create some local facts
    get_

# Generated at 2022-06-20 19:33:17.209865
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    test_dict = {}
    test_dict['ansible_processor_args'] = 'ghz: 1'
    test_dict['ansible_processor_cores'] = '2'
    test_dict['ansible_processor_count'] = '2'
    test_dict['ansible_processor_threads_per_core'] = '1'
    test_dict['ansible_processor_vcpus'] = '2'
    test_dict['ansible_processor_threads'] = '2'
    test_dict['ansible_processor_vendor_id'] = 'GenuineIntel'
    test_dict['ansible_processor_socket_destination'] = 'CPU Socket - U3E1'

# Generated at 2022-06-20 19:33:19.723065
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector is not None
    assert local_fact_collector.name == 'local'


# Generated at 2022-06-20 19:33:21.583298
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'
    assert 'local' in LocalFactCollector._fact_ids

# Generated at 2022-06-20 19:33:23.991120
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-20 19:33:32.980659
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # pylint: disable=protected-access
    """Unit test for class ``LocalFactCollector`` method ``collect``."""

    # Some mock facts
    facts = {
        'fact1': {'key': 'value1'},
        'fact2': {'key': 'value2'}
    }

    # A mock module
    class MockModule(object):
        """Mock Ansible module"""

        def __init__(self, params=None):
            """Init mock module."""
            self.params = params

        def run_command(self, command):
            """Mock run_command method. Return a mocked value."""
            return dict(rc=0, stdout=json.dumps(facts[command]), stderr='')

        def warn(self, warn_msg):
            """Mock warn method."""

# Generated at 2022-06-20 19:33:40.012118
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    def run_command(self, cmd, check_rc=True, close_fds=True):
        return cmd

    module = type('AnsibleModule', (object,), {'params':{'fact_path':'/path/to/facts.d'},
                                               'run_command':run_command})
    instance = LocalFactCollector(None)
    instance.collect(module)

# Generated at 2022-06-20 19:33:50.908580
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    input_params = dict(
        ansible_python_interpreter="/usr/bin/python",
        fact_path='/etc/ansible/facts.d/',
        all_facts=False
    )
    module = type(
        'AnsibleModuleFake',
        (object, ),
        dict(params=input_params, run_command=lambda self, cmd: (0, '', ''))
    )
    assert LocalFactCollector(module).name == 'local'

# Generated at 2022-06-20 19:34:01.329022
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = AnsibleModule(argument_spec={'fact_path': {'required': False}})

    # Test case 1: fact_path doesn't exists
    local_facts = LocalFactCollector().collect(module)
    assert local_facts['local'] == {}

    # Test case 2: exist .fact file, this file is not executable
    module.params['fact_path'] = '/etc/facts.d'
    local_facts = LocalFactCollector().collect(module)
    assert 'local' in local_facts
    assert 'test' in local_facts['local']
    assert len(local_facts['local']) == 1
    assert local_facts['local']['test'] == 'test'

    # Test case 3: exist .fact file, this file is executable
    local_facts = LocalFactCollector().collect(module)
   

# Generated at 2022-06-20 19:34:09.702070
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import FactsCollector
    from ansible.module_utils.facts import ansible_local
    from ansible.module_utils.facts import default_collectors
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.collector import BaseFactCollector

    facts_instance = get_collector_instance(ansible_local)

    facts_instance.collect(module=None)
    assert facts_instance.__class__ is LocalFactCollector

# Generated at 2022-06-20 19:34:20.474784
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    ''' test code to run when this module is called as a script '''

    # imports
    import os
    from ansible.module_utils.facts.collector import BaseFactCollector

    # create the object under test
    from ansible.module_utils.facts import local_facts
    uut = local_facts.LocalFactCollector()

    # verify the desired class hierarchy
    assert(issubclass(local_facts.LocalFactCollector, BaseFactCollector))

    # create the object under test
    from ansible.module_utils.facts.local_facts import LocalFactCollector

    # verify the desired class hierarchy
    assert(issubclass(LocalFactCollector, BaseFactCollector))

    # test collect method
    # first use case:  a specified fact_path has no files that look like executable facts.
    uut = Local

# Generated at 2022-06-20 19:34:26.666298
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    localFactCollector = LocalFactCollector()
    assert localFactCollector.name == 'local', "The name of the class should be 'local'"
    assert isinstance(localFactCollector._fact_ids,set), "_fact_ids should be a set"
    assert len(localFactCollector._fact_ids) == 0, "_fact_ids should be empty"


# Generated at 2022-06-20 19:34:29.459768
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Unit test to test the constructor of class LocalFactCollector
    assert LocalFactCollector.name == 'local'

# Generated at 2022-06-20 19:34:34.458954
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    lfc = LocalFactCollector()
    assert lfc.collect() == {'local': {}}
    assert lfc.collect(collected_facts={}) == {'local': {}}

# Unit tests for methods in BaseFactCollector

# Generated at 2022-06-20 19:34:41.803851
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = configparser.ConfigParser()
    module.read('test/unit/facts/test_facts_local.facts')
    collected_facts = configparser.ConfigParser()
    local_fact_collector = LocalFactCollector()
    local_facts = local_fact_collector.collect(module, collected_facts)
    assert local_facts == {
        'local': {
            'ansible_local': {
                'result': 'hello',
                'status': 'ok'
            }
        }
    }

# vim: expandtab:tabstop=4:shiftwidth=4

# Generated at 2022-06-20 19:34:54.479335
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts import ModuleStub

    print("Test collect of LocalFactCollector")
    module = ModuleStub()
    module.params = {'fact_path': './test/unit/utils/facts/local_facts'}

    fact_collector = LocalFactCollector()
    result = fact_collector.collect(module=module)


# Generated at 2022-06-20 19:35:00.130452
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = MockModule()
    module.params['fact_path'] = 'tests/unit/module_utils/facts/test_facts'
    local_fact_collector = LocalFactCollector()

    facts = local_fact_collector.collect(module=module)

    assert facts == {'local':{'test1':{'test1_sect': {'test1_opt':'test1_val'}}, 'test2':'test2_data'}}

# Generated at 2022-06-20 19:35:13.560660
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass

# Generated at 2022-06-20 19:35:19.761068
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    fixture_data = {
        'ansible_local': {
            'test_fact': {
                'fact1': 'value1'
            }
        }
    }
    module = Mock(params={'fact_path': './tests/fixtures/ansible_local/'})
    lfcol = LocalFactCollector()
    assert lfcol.collect(module=module) == fixture_data


# Generated at 2022-06-20 19:35:21.234621
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert 'local' == local_fact_collector.name

# Generated at 2022-06-20 19:35:22.704457
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    test = LocalFactCollector()
    result = test.collect()
    assert result is not None

# Generated at 2022-06-20 19:35:25.798549
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Cache local fact collector instance
    local_fact_collector = LocalFactCollector()

    # Assert the facts collection is called as expected
    assert local_fact_collector.name == 'local'
    assert local_fact_collector.collect() is not None

# Generated at 2022-06-20 19:35:34.741240
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = Mock()
    module_params = {'fact_path': '/tmp'}
    module.params = module_params
    module.fail_json = Mock(side_effect=Exception('fake'))
    module.run_command = Mock(return_value=(0, '', ''))
    module.warn = Mock()
    collected_facts = {}
    lfc = LocalFactCollector()
    try:
        assert lfc.collect(module, collected_facts) == {'local': {}}
    except Exception:
        assert False, 'LocalFactCollector.collect() should not raise.'



# Generated at 2022-06-20 19:35:36.166383
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # TODO: Write unit test
    pass

# Generated at 2022-06-20 19:35:46.141099
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts import ModuleCache

    module = None
    collected_facts = {}
    test_dict = { 'ansible_local': {'hello': "world"}}

    # create a test directory
    os.mkdir('/tmp/ansible_facts')
    # create a test fact file
    fsock = open('/tmp/ansible_facts/hello.fact', 'w')
    fsock.write(json.dumps(test_dict))
    fsock.close()

    local_fact = LocalFactCollector()
    result = local_fact.collect(module, collected_facts)
    assert test_dict == result
    os.remove('/tmp/ansible_facts/hello.fact')
    os.rmdir('/tmp/ansible_facts')

# Generated at 2022-06-20 19:35:57.961247
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    test_mod = type("test", (object,), {"run_command": lambda self, cmd: ""})()
    test_mod.params = {}

    local_facts = {}
    local_facts['local'] = {}

    local_fc = LocalFactCollector()

    # try to collect facts when fact_path is invalid
    test_mod.params['fact_path'] = 'some/invalid/path'
    result = local_fc.collect(test_mod, local_facts)
    assert result == local_facts

    # try to collect facts when fact_path is an empty directory
    test_mod.params['fact_path'] = '/tmp/facts.d'
    os.makedirs("/tmp/facts.d")
    result = local_fc.collect(test_mod, local_facts)
    assert result == local_facts

# Generated at 2022-06-20 19:36:01.254742
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector_instance = LocalFactCollector()
    assert local_fact_collector_instance.name == 'local'
    assert local_fact_collector_instance._fact_ids == set()


# Generated at 2022-06-20 19:36:33.579105
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    '''
    Unit test which checks the collection of local facts
    '''

    class MockModule(object):
        def __init__(self):
            self.params = {
                'fact_path': './test/unit/module_utils/facts/files/'
            }

        def run_command(self, command):
            '''
            Mock function for the method run_command
            '''

            return (0, command.split("/")[-1], '')

        def warn(self, message):
            '''
            Mock function for the method warn
            '''

            pass

    # Create a new object of the class LocalFactCollector
    local_fact_collector = LocalFactCollector()

    # Create a MockModule object as parameter for the method collect
    fact_ansible_module = MockModule()

    #

# Generated at 2022-06-20 19:36:44.055356
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    from ansible.module_utils.facts.collector import FactCollector
    from ansible.module_utils.facts import FallbackModuleUtils

    def mock_run_command(self, cmd):
        return (0, 'fake', '')

    def mock_get_file_content(self, file, default='', errors=None):
        return "fake"

    def mock_fallback_module_utils(self, module):
        return True

    class MockAnsibleModule():
        def __init__(self):
            self.params = {}

        def run_command(self, command):
            return (0, 'fake', '')

    class MockFactsCollector():
        def __init__(self):
            self.task_vars = {}

        def get_collector(self, name):
            collector = LocalFact

# Generated at 2022-06-20 19:36:50.794276
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    ''' Unit test for method collect of class LocalFactCollector.
        :return:
            - False, if test did not pass
            - True, if test passed
    '''
    # Input parameters
    module = None
    collected_facts = {}

    # Expected result
    expected_result = {'local': {}}

    # Class being tested
    local_collector = LocalFactCollector()

    # Run method being tested
    result = local_collector.collect(module, collected_facts)

    if expected_result != result:
        return False

    return True

# Generated at 2022-06-20 19:36:53.354520
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    obj = LocalFactCollector()
    assert obj.name == 'local'
    assert obj._fact_ids == set()

# Generated at 2022-06-20 19:36:54.627668
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    lfc = LocalFactCollector()
    assert lfc.name == "local"

# Generated at 2022-06-20 19:37:03.006528
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    '''Unit test for constructor of class LocalFactCollector'''
    mock_module = {}

    def test_empty_path():
        mock_module['params'] = {}
        assert LocalFactCollector().collect(mock_module) == {}

    test_empty_path()

    def test_invalid_path():
        mock_module['params'] = {'fact_path': '/invalid/path'}
        assert LocalFactCollector().collect(mock_module) == {}

    test_invalid_path()

# Generated at 2022-06-20 19:37:04.791608
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local = LocalFactCollector()
    assert local.name == 'local'
    assert local._fact_ids == set()


# Generated at 2022-06-20 19:37:07.756620
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local = LocalFactCollector()
    assert local.name=='local'
    assert local._fact_ids==set()

# Generated at 2022-06-20 19:37:19.009158
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts.collector import TestModule
    from ansible.module_utils.facts.utils import get_file_content

    mod = TestModule()
    ModParams = type(mod.params)

    mod.params = ModParams()
    mod.params.update(fact_path='/home/user')
    lfc = LocalFactCollector()

    # For a path un-exists case
    facts = lfc.collect()
    assert {} == facts

    # For the directory exists but contains no files
    mod.params = ModParams()
    mod.params.update(fact_path='./.ansible')
    facts = lfc.collect(mod)
    assert {} == facts

    # For the directory exists with empty files
    mod.params = ModParams()
    mod.params.update

# Generated at 2022-06-20 19:37:31.407978
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    os.environ['ANSIBLE_LOCAL_TEMP'] = '/tmp'
    os.environ['ANSIBLE_REMOTE_TEMP'] = '/tmp'
    os.environ['ANSIBLE_PIPELINING'] = 'False'
    module = AnsibleModule({'fact_path': '/tmp'})

    # no factpath
    lfc = LocalFactCollector(module, {})
    facts = lfc.collect()
    assert facts == {}

    # invalid factpath
    lfc = LocalFactCollector(module, {'fact_path': '/tmp/randomfact'})
    facts = lfc.collect()
    assert facts == {}

    # valid factpath
    lfc = LocalFactCollector(module, {'fact_path': '/tmp/ansible_fact'})
    facts = lfc.collect()

# Generated at 2022-06-20 19:38:32.502466
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # mock module and collected facts
    import ansible.module_utils.facts.collector
    import ansible.module_utils.facts.local

    import ansible.module_utils.basic
    import ansible.module_utils.facts

    import ansible.module_utils.facts.utils
    import ansible.module_utils.facts.system.distribution
    from ansible.module_utils.facts.collector import BaseFactCollector

    import ansible.module_utils.facts.system.platform
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector
    from ansible.module_utils.facts.system.platform import PlatformFactCollector
    from ansible.module_utils.facts.network.interfaces import InterfacesFactCollector


# Generated at 2022-06-20 19:38:36.219672
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector(
        module=None,
        collected_facts=None,
    )
    assert local_fact_collector.name == 'local'


# Generated at 2022-06-20 19:38:36.755866
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass

# Generated at 2022-06-20 19:38:39.035024
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    collector = LocalFactCollector()
    assert collector.name == "local"
    assert not collector._fact_ids

# Generated at 2022-06-20 19:38:40.627197
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    obj = LocalFactCollector()
    assert obj.name == 'local'
    assert 'local' in obj._fact_ids

# Generated at 2022-06-20 19:38:41.492236
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert(LocalFactCollector)

# Generated at 2022-06-20 19:38:51.062034
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """ Test cases for ansible/module_utils/facts/collector/local.py """
    import ansible.module_utils.facts.collector.local as local
    module_local = local.LocalFactCollector()

    local_facts = {'local': {'test': 'test'}}

    # Test case when module is None
    assert module_local.collect() == local_facts

    # Test case when fact_path is None
    mock_module = Mock()
    mock_module.params = { 'fact_path': None}
    assert module_local.collect(module=mock_module) == local_facts

    # Test case when fact_path is non-existent
    mock_module.params = { 'fact_path': "/tmp/non-existent"}
    assert module_local.collect(module=mock_module) == local

# Generated at 2022-06-20 19:38:53.954164
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils import basic
    local_fact_collector = LocalFactCollector()
    module = basic.AnsibleModule(argument_spec={},
                                 supports_check_mode=False)
    local_fact_collector.collect()

# Generated at 2022-06-20 19:38:54.951290
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
   obj = LocalFactCollector()
   assert obj.name == 'local'

# Generated at 2022-06-20 19:39:01.085512
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    # mock a module
    module = object()
    # get the local fact collector
    fact = LocalFactCollector()

    # test with a path that does not exist
    local_facts = fact.collect(module, None)
    assert local_facts == {'local': {}}

    # mock a function in the module to test if the facts execute correctly
    def run_command(command, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
        return (0, 'output', '')
    setattr(module, 'run_command', run_command)

    # setup a temporary location for the facts
    import tempfile
    path = tempfile.mkdtemp()


    # test with executable and with non executable

# Generated at 2022-06-20 19:41:30.431396
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'
    assert isinstance(LocalFactCollector._fact_ids, set)
    assert issubclass(LocalFactCollector, BaseFactCollector)


# Generated at 2022-06-20 19:41:32.228133
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    collector = LocalFactCollector()
    assert collector.name == 'local'
    assert isinstance(collector._fact_ids, set)


# Generated at 2022-06-20 19:41:36.297668
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    import ansible.module_utils.facts.collectors.local.test_resources.test_script_facts as test_script_facts

    fact_path = test_script_facts.__path__[0]
    local_fact_collector = LocalFactCollector()

    # no fact_path
    facts = local_fact_collector.collect(None)
    assert len(facts) == 0

    # fact_path = filesystem root
    facts = local_fact_collector.collect({"params": {"fact_path": "/"}})
    assert len(facts) == 0

    # fact_path does not exist
    facts = local_fact_collector.collect({"params": {"fact_path": "/this/path/does/not/exist"}})
    assert len(facts) == 0

    # fact_path exists, but no

# Generated at 2022-06-20 19:41:39.901305
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local = LocalFactCollector()
    assert local.name == 'local'
    assert local._fact_ids == set()
    assert callable(local.collect)

# Generated at 2022-06-20 19:41:43.428232
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    localFactCollector = LocalFactCollector()
    assert localFactCollector.name == 'local'
    assert localFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:41:48.845900
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fact_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), '../hacking/test_facts')
    local_fact_collector = LocalFactCollector(module=None, fact_path=fact_path)
    assert isinstance(local_fact_collector, LocalFactCollector)


# Generated at 2022-06-20 19:41:56.973010
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # ansible 2.9.9
    # module == <class 'ansible.module_utils.facts.local.LocalFactCollector'>
    # collected_facts == {}
    # module.params = {'fact_path': '/home/sukujgrg/devel/ansible-collections/ansible_collections/siblgm/automation/ansible_facts/facts.d'}
    lfc = LocalFactCollector()
    out = lfc.collect(collected_facts={})
    assert out == {'local': {'example': 'this is a valid ini style file', 'example2': '{ "this": "is a valid json file" }'}}

# Generated at 2022-06-20 19:41:58.961852
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    lfc = LocalFactCollector()
    assert lfc.name == 'local'
    assert type(lfc._fact_ids) == set


# Generated at 2022-06-20 19:42:00.043075
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fact = LocalFactCollector()
    assert fact.name == 'local'

# Generated at 2022-06-20 19:42:09.097302
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    with open('/tmp/test_local_fact.fact', 'w') as fact_file:
        fact_file.write('{"fact_key": "fact_value"}')
    module_params = {'fact_path': '/tmp'}
    module_obj = lambda: None
    setattr(module_obj, 'params', module_params)
    setattr(module_obj, 'run_command', lambda x: (0, '{"fact_key": "fact_value"}', ''))
    result = LocalFactCollector().collect(module=module_obj)
    output  = {'local': {'test_local_fact': {'fact_key': 'fact_value'}}}
    assert result == output
    os.remove('/tmp/test_local_fact.fact')
