

# Generated at 2022-06-20 19:32:34.994546
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    lfc = LocalFactCollector()
    assert lfc.collect() == {'local': {}}

# Generated at 2022-06-20 19:32:36.891624
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-20 19:32:37.962566
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact = LocalFactCollector()
    assert local_fact.name == 'local'

# Generated at 2022-06-20 19:32:40.363763
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    """Checking ansible.module_utils.facts.local.LocalFactCollector class constructor
    """
    tmp = LocalFactCollector()
    assert tmp.name == 'local'
    assert tmp._fact_ids == set()


# Generated at 2022-06-20 19:32:41.733109
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local = LocalFactCollector()
    assert local.name == 'local'
    assert local._fact_ids == set()

# Generated at 2022-06-20 19:32:43.614384
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass

# Generated at 2022-06-20 19:32:45.269176
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # pylint: disable=no-init
    LocalFactCollector()

# Generated at 2022-06-20 19:32:55.243810
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    def run_command(args):
        return 0, '', ''

    params = {
        'fact_path': 'test/test_local_facts'
    }
    mock_module = MockModule(params=params, run_command=run_command)
    mock_collector = LocalFactCollector()
    local_facts = mock_collector.collect(module=mock_module, collected_facts={})
    assert local_facts == {'local': {
        'test': {
            'test': 'this is a test',
            'section': {
                'option1': 'value1',
                'option2': 'value2'
            }
        },
        'test2': {'this': 'is', 'a': 'test2'}
        }
    }

# Generated at 2022-06-20 19:33:04.343386
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = MagicMock()
    module.run_command.return_value = (0, "echo '{\"foo\": \"baz\"}'", "")
    module.warn.return_value = ""
    fact_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'units', 'data', 'facts', 'local')
    module.params = {'fact_path': fact_path}

    lfc = LocalFactCollector(module=module)


# Generated at 2022-06-20 19:33:11.612811
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    try:
        import ansible
    except ImportError:
        raise Exception("ansible is required for this unit test.")

    obj = LocalFactCollector()

    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec = dict(
          fact_path=dict(type='str', required=False)
        )
    )

    result = obj.collect(module)

    assert result['local']['fact1'] == 'Fact1 value'

# Generated at 2022-06-20 19:33:18.544500
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    LocalFactCollector().collect()

# Generated at 2022-06-20 19:33:19.810134
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    obj = LocalFactCollector()
    assert(obj.name == 'local')

# Generated at 2022-06-20 19:33:22.341563
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'
    assert LocalFactCollector._fact_ids == set()



# Generated at 2022-06-20 19:33:26.560384
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Arrange
    module = MockModule()
    module.params = mock_params
    local_fact_collector = LocalFactCollector()
    # Act
    facts = local_fact_collector.collect(module=module)
    # Assert
    assert 'local' in facts.keys()



# Generated at 2022-06-20 19:33:28.437119
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-20 19:33:35.328155
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    import sys
    import os
    current_dir = os.path.dirname(os.path.realpath(__file__))

    with open(current_dir + '/test_LocalFactCollector_collect.txt', 'r') as f:
       content = f.read()
       print(content)

    result = content

    local = {}
    local['foo'] = "bar"
    local['baz'] = {}
    local['baz']['bing'] = "bong"

    local_facts = {}
    local_facts['local'] = local

    collected_facts = {}

    module = sys.modules['ansible.module_utils.facts.local.local']

    # no fact_path
    local_fact_collector = LocalFactCollector()

# Generated at 2022-06-20 19:33:38.825539
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    lf = LocalFactCollector()
    assert isinstance(lf, BaseFactCollector)
    assert isinstance(lf, LocalFactCollector)

# Generated at 2022-06-20 19:33:47.506806
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    try:
        from ansible.module_utils import basic
    except ImportError:
        print("skipping test_LocalFactCollector_collect as ansible.module_utils.basic library is unavailable")
        return

    def test_module(*args, **kwargs):
        module = basic.AnsibleModule(*args, **kwargs)
        collector = LocalFactCollector(module)
        facts = collector.collect(module, {})
        return facts

    import tempfile
    import os

    fact_dir = tempfile.mkdtemp(prefix='ansible_local_fact_collector')

    config = '[foo]\nbar=baz'
    fact = '{"foo": "bar", "baz": "qux"}'
    config_file = os.path.join(fact_dir, 'config.fact')
    fact

# Generated at 2022-06-20 19:33:49.811958
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    assert LocalFactCollector().collect() == {'local': {}}

# Generated at 2022-06-20 19:34:00.657981
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    class TestModule(object):
        params = {'fact_path': 'test/integration/facts/modules/local/facts.d'}
        def warn(self, msg):
            print('warning: %s' % msg)
        def run_command(self, cmd):
            return (0, '{"fact_test": "something"}', '')

    fact_collector = LocalFactCollector()
    test_module = TestModule()
    result = fact_collector.collect(test_module, collected_facts={})
    assert 'local' in result
    assert len(result['local']) == 3
    assert result['local']['fact_test'] == 'something'
    assert result['local']['test']['result'] == 'success'

# Generated at 2022-06-20 19:34:14.495897
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    facts_dict = { "local": { "hello": "world" } }
    class ModuleMock(object):
        def __init__(self):
            self.params = { "fact_path": "/tmp" }
        def warn(self, message):
            return
        def run_command(self, cmd, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            return 1, "", ""
    mm = ModuleMock()
    lfc = LocalFactCollector(mm)
    assert facts_dict == lfc.collect()

# Generated at 2022-06-20 19:34:20.260052
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    tmpdir = tempfile.mkdtemp()
    os.environ['HOME'] = tmpdir

# Generated at 2022-06-20 19:34:30.529205
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # init a module 
    class MockModule(object):
        def __init__(self):
            self.params = {}
        def run_command(self, cmd):
            return 0, 'fact_value', ''
        def warn(self, msg):
            print(msg)

    module = MockModule()
    # init LocalFactCollector
    fact_path = os.path.dirname(os.path.abspath(__file__)) + '/dummy_facts'
    module.params['fact_path'] = fact_path
    local_collector = LocalFactCollector()
    local_facts = local_collector.collect(module=module)
    assert local_facts == {'local': {'fact_script': {'opt1': 'val1'}, 'fact_text': 'fact_value'}}

# Generated at 2022-06-20 19:34:33.698609
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert not BaseFactCollector.__abstractmethods__
    assert not BaseFactCollector.__subclasses__()

# Generated at 2022-06-20 19:34:44.172604
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # setup test variables for the gather subroutine
    os.environ['ANSIBLE_LOCAL_TEMP'] = '/home/ansible/temp'

    # setup the test environment
    if os.path.exists("test_local_facts.fact"):
        os.remove("test_local_facts.fact")
    fd = open("test_local_facts.fact", "w+")
    fd.write("""{
        "test_fact": {
            "test_field1": "test_value1",
            "test_field2": "test_value2"
        }
    }""")
    fd.close()
    
    # get the returned facts
    facts_collector = LocalFactCollector()
    facts = facts_collector.collect()
    
    # check the facts returned

# Generated at 2022-06-20 19:34:55.389370
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    class ModuleMock():
        def __init__(self, *args, **kwargs):
            self.warned = False
            self.warn_message = ''
            self.warn = self.mock_warn
            self.params = kwargs

        def mock_warn(self, msg):
            self.warned = True
            self.warn_message = msg

        def run_command(self, cmd):
            rc = 0
            err = ''
            if cmd == '/tmp/local_facts/bad_json.fact':
                out = '{"key": "val",}'
            else:
                out = '{"key": "val"}'
            return rc, out, err


# Generated at 2022-06-20 19:35:05.192066
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    from ansible.module_utils.facts.utils import AnsibleFactCollector
    from ansible.module_utils.facts.collector import get_collector_names

    # Set new facts dir path
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

    # Create instance of LocalFactCollector and add the instance of LocalFactCollector
    # to AnsibleFactCollector.fact_collectors
    ansible_fact_collector = AnsibleFactCollector()
    ansible_fact_collector.add_collector(local_fact_collector)

    # Get all fact collectors and verify local facts is one of them
    fact_collector_names = get_collector_names()
    assert 'local' in fact_collector_names

# Generated at 2022-06-20 19:35:09.021303
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    fact_module = type('module', (object, ), {})
    fact_module.params = {'fact_path': '/etc/ansible/facts.d'}
    local_fact = LocalFactCollector(fact_module)
    assert local_fact.name == 'local'

# Generated at 2022-06-20 19:35:11.987835
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    from ansible.module_utils.facts import collector
    test_obj = LocalFactCollector()
    assert test_obj.name == 'local'

# Generated at 2022-06-20 19:35:23.178320
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_collector = LocalFactCollector()
    out = local_collector.collect()
    assert out == {'local': {}}
    out = local_collector.collect(collected_facts={'something': 'test'})
    assert out == {'local': {}}
    out = local_collector.collect(collected_facts={'something': 'test'}, module={'params': {'fact_path': '/tmp/a'}})
    assert out == {'local': {}}
    out = local_collector.collect(collected_facts={'something': 'test'}, module={'params': {'fact_path': 'tests/unit/module_utils/facts/local'}})

# Generated at 2022-06-20 19:35:37.299698
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    module = None
    collected_facts = None
    local_facts = LocalFactCollector()
    local_facts.collect(module, collected_facts)

# Generated at 2022-06-20 19:35:47.277428
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    from ansible.module_utils.facts.local import LocalFactCollector
    from ansible.module_utils.facts.collector import BaseFactCollector

    assert issubclass(LocalFactCollector, BaseFactCollector)

    # test 1
    # test case with empty dictionary
    module = None
    collected_facts = None
    local_facts = LocalFactCollector().collect(module=module, collected_facts=collected_facts)

    assert local_facts == {'local': {}}

    # test 2
    # test case with invalid fact_path
    module = FakeModule()
    module.params = {'fact_path': '/tmp/fake'}

    assert not os.path.exists(module.params.get('fact_path'))

    collected_facts = None

# Generated at 2022-06-20 19:35:48.739054
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-20 19:35:50.883225
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Testing class constructor
    localFactCollector = LocalFactCollector()

    assert localFactCollector is not None


# Generated at 2022-06-20 19:35:54.098040
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()
    assert local_fact_collector.name == 'local'

# Generated at 2022-06-20 19:36:00.396791
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # This function will test collection of local facts and fail if any exception occurs
    # Input variable to the function
    module = ''
    # Output variable of the function
    result = {}
    try:
        local_facts = LocalFactCollector()
        result = local_facts.collect(module=module, collected_facts={})
    except Exception as ex:
        print(ex)
        raise AssertionError('Unkown exception occurs on LocalFactCollector.collect() execution')

    assert result == {u'local': {}}

# Generated at 2022-06-20 19:36:01.423199
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector({})

# Generated at 2022-06-20 19:36:08.080116
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    """
    Unit test for the method collect of class LocalFactCollector
    """
    test_object = LocalFactCollector()
    assert test_object.name == 'local', "The method name of LocalFactCollector is not returning the expected value"

    result=test_object.collect()
    assert "distribution" in result["ansible_local"], "The method collect of LocalFactCollector is not returning the expected value"
    #TODO: Add unit test coverage for the other cases


# Generated at 2022-06-20 19:36:09.625287
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local = LocalFactCollector()
    facts = local.collect()

    assert isinstance(facts, dict)
    assert facts.get('local') is not None
    assert isinstance(facts['local'], dict)

# Generated at 2022-06-20 19:36:23.224158
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    import os
    import tempfile
    import json

    module_path = os.path.dirname(os.path.realpath(__file__))
    fact_path = os.path.join(module_path, 'files', 'mocked', 'ansible_facts')
    valid_json_fact_file = os.path.join(fact_path, 'valid_json_fact.fact')
    valid_ini_fact_file = os.path.join(fact_path, 'valid_ini_fact.fact')

    def create_fact_file(content, directory=fact_path, fact_name='fact_name.fact'):
        file = tempfile.NamedTemporaryFile(delete=False, dir=directory, prefix=fact_name)
        file.write(content)
        file.close()
        return file.name



# Generated at 2022-06-20 19:36:39.146458
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    x = LocalFactCollector()
    assert x.name == 'local'

# Generated at 2022-06-20 19:36:42.083332
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local = LocalFactCollector()
    assert local
    assert local.name == 'local'
    assert local._fact_ids == set()
    assert local._fact_ids == set(["local"])


# Generated at 2022-06-20 19:36:45.918493
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    dummy_module = None
    dummy_collected_facts = None
    fact_collector = LocalFactCollector()
    assert fact_collector.collect(dummy_module, dummy_collected_facts) == {'local': {}}, \
        'LocalFactCollector_collect FAILED! Local facts is empty.'

# Generated at 2022-06-20 19:36:55.269369
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    # Testing instatiation of class LocalFactCollector
    # Should always pass
    import os
    import stat
    import json
    from ansible.module_utils._text import to_text
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.six.moves import configparser
    # Creating an object
    fact_path = os.getcwd() + "/test/unit/ansible_test/test_local_fact_collector/"
    local_fact_collector = LocalFactCollector()
    file_name = 'testfact.fact'
    file_path =  fact_path + file_name

    # Creating a file

# Generated at 2022-06-20 19:37:06.931354
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    LocalFactCollector = __import__("ansible.module_utils.facts.local.LocalFactCollector").ansible.module_utils.facts.local.LocalFactCollector
    fact_path = __import__("ansible.module_utils.facts.local.LocalFactCollector").HERE + "/test_local_facts/"
    module = __import__("ansible.module_utils.facts.local.LocalFactCollector").ANSIBLE_PYTHON_INTERPRETER
    local_facts = LocalFactCollector().collect(fact_path=fact_path, module=module)

# Generated at 2022-06-20 19:37:09.778188
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector()

# Generated at 2022-06-20 19:37:13.222994
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_facts = LocalFactCollector()
    assert local_facts.name == 'local'
    assert isinstance(local_facts._fact_ids, set)

# Generated at 2022-06-20 19:37:15.277994
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    mod = None
    lfc = LocalFactCollector(mod)
    assert lfc is not None


# Generated at 2022-06-20 19:37:18.390544
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    '''
    Return some facts for the local system.

    This method scans a directory for executables and tries to run them.
    The executable should return JSON data which will be included as additional
    local facts.

    This function is not unit testable, since it relys on AnsibleExecutor.
    '''
    pass

# Generated at 2022-06-20 19:37:30.952135
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    from ansible.module_utils.facts import ansible_collections_path

    fake_module = type('FakeModule', (object,), {
        'run_command': lambda self, command: (0, '\n'.join(['/dev/sda2: UUID="123456789"', '/dev/sda3: UUID="987654321"']), '')
    })()

    # This fake facts file is copied from test/unit/module_utils/facts/test_files/test_files_filesystems.fact
    fake_filesystems_fact_path = os.path.join(ansible_collections_path(), 'ansible_collections', 'ansible', 'os', 'facts', 'filesystems.fact')

# Generated at 2022-06-20 19:38:01.235188
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    obj = LocalFactCollector()
    assert obj.name == 'local'
    assert obj._fact_ids == set()
    assert isinstance(obj._fact_ids, set)
    assert obj.collect() == {'local': {}}
    assert obj.collect(collected_facts = {'local':{}}) == {'local': {}}

# Generated at 2022-06-20 19:38:05.454188
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fact_collector = LocalFactCollector()

    assert(local_fact_collector != None)
    assert(local_fact_collector.name == 'local')
    assert(len(local_fact_collector._fact_ids) == 0)


# Generated at 2022-06-20 19:38:07.601462
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    local_fact_collector = LocalFactCollector()
    facts = local_fact_collector.collect()

# Generated at 2022-06-20 19:38:09.221922
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    a = LocalFactCollector()
    assert a.name == 'local'

# Generated at 2022-06-20 19:38:16.060397
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    """
    This is a basic test to see that the class can be instantiated.
    """
    mod = AnsibleModule(
        argument_spec=dict(),
    )

    local_fact_collector = LocalFactCollector(module=mod)
    assert local_fact_collector is not None


# Generated at 2022-06-20 19:38:24.503931
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # mock module class
    class MockModule:
        params = {
            'fact_path': '/home/test/facts',
        }

        def warn(self, msg):
            print('WARNING:', msg)

        def run_command(self, cmd):
            if cmd == '/home/test/facts/test1.fact':
                return (0, '{"first": "one"}', '')
            elif cmd == '/home/test/facts/test2.fact':
                return (0, 'first=one', '')
            else:
                return (1, '', 'Error')

    # create instance of class LocalFactCollector
    fact_collector_obj = LocalFactCollector()

    # create MockModule instance
    module = MockModule()

    # set up test variables

# Generated at 2022-06-20 19:38:29.904461
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    filename = os.path.realpath(__file__)
    directory = os.path.dirname(filename)
    fact_path = os.path.join(directory, '../../unit/module_utils/facts/factsd')
    fact_collector = LocalFactCollector()
    fact_collector.collect(fact_path=fact_path)

# Generated at 2022-06-20 19:38:35.517629
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    import mock

    module_args = {}
    module_params = {}

    local_facts = LocalFactCollector(module_args, module_params)

    # set up the mock
    mock_module = mock.MagicMock()

    assert local_facts.collect(mock_module) == {'local': {}}

# Generated at 2022-06-20 19:38:37.009297
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    x = LocalFactCollector()
    assert isinstance(x, LocalFactCollector) == True

# Generated at 2022-06-20 19:38:39.290952
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    localFactCollector = LocalFactCollector()
    assert localFactCollector.name == 'local'

# Generated at 2022-06-20 19:40:03.501144
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():

    lfc = LocalFactCollector()
    local_facts = lfc.collect()

    assert(local_facts['local']['test_fact_a'] == {'a':'a', 'b': 'b', 'c': 'c'})

# Generated at 2022-06-20 19:40:05.365445
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    class fake_module:
        params = {}

    lf = LocalFactCollector(module=fake_module)
    assert lf.name == 'local'

# Generated at 2022-06-20 19:40:16.833674
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    # Init LocalFactCollector
    local_fact_collector = LocalFactCollector()

    # assert that get_fact_names is a set
    assert isinstance(local_fact_collector.get_fact_names(), set)

    # assert that get_fact_names is a LocalFactCollector.name (local)
    assert local_fact_collector.get_fact_names() == {r'local'}

    # assert that get_fact_names is not a BaseFactCollector.name (setup)
    assert local_fact_collector.get_fact_names() != BaseFactCollector.name

    # assert that collect return a dict
    assert isinstance(local_fact_collector.collect(), dict)

# Generated at 2022-06-20 19:40:28.905648
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    test_module = type('', (), {})
    test_module.params = {}
    test_module.params['fact_path'] = 'tests/unit/modules/test_facts/local_facts/'
    fact_collector = LocalFactCollector()
    facts_dict = fact_collector.collect(test_module)

# Generated at 2022-06-20 19:40:30.441810
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert len(LocalFactCollector().collect()) == 1
    assert type(LocalFactCollector().collect()) == dict

# Generated at 2022-06-20 19:40:33.061750
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_fh = LocalFactCollector()
    assert local_fh.name == 'local'
    assert local_fh._fact_ids == set()

# Generated at 2022-06-20 19:40:34.245356
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
   local = LocalFactCollector()
   assert local.name == 'local'

# Generated at 2022-06-20 19:40:34.804694
# Unit test for method collect of class LocalFactCollector
def test_LocalFactCollector_collect():
    pass

# Generated at 2022-06-20 19:40:37.836762
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    assert LocalFactCollector.name == 'local'
    assert LocalFactCollector.__doc__ == '\'local\' fact collector'
    assert LocalFactCollector._fact_ids == set()

# Generated at 2022-06-20 19:40:40.993732
# Unit test for constructor of class LocalFactCollector
def test_LocalFactCollector():
    local_facts = LocalFactCollector()
    assert local_facts.name == 'local'
    assert len(local_facts._fact_ids) == 0