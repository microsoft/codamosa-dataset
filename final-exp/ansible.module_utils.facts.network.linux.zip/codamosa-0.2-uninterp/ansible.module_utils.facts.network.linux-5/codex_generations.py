

# Generated at 2022-06-17 01:04:07.924694
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: write unit test
    pass


# Generated at 2022-06-17 01:04:17.066437
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:04:26.341115
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/bin/ip')
    linux_network = LinuxNetwork(module)
    linux_network.get_default_interfaces()
    module.run_command.assert_has_calls([
        call(['/bin/ip', 'route', 'get', '8.8.8.8'], errors='surrogate_then_replace'),
        call(['/bin/ip', 'route', 'get', '2001:4860:4860::8888'], errors='surrogate_then_replace'),
    ])


# Generated at 2022-06-17 01:04:39.319497
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/usr/bin/ethtool')
    ln = LinuxNetwork(module)
    data = ln.get_ethtool_data('eth0')
    assert data == {'features': {}, 'timestamping': [], 'hw_timestamp_filters': []}
    module.run_command.assert_called_with(['/usr/bin/ethtool', '-k', 'eth0'], errors='surrogate_then_replace')

# Generated at 2022-06-17 01:04:42.115005
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data('eth0') == {}


# Generated at 2022-06-17 01:04:54.595713
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

# Generated at 2022-06-17 01:05:04.350027
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address'] == '192.168.1.1'
    assert ln.default_ipv4['netmask'] == '255.255.255.0'
    assert ln.default_ipv4['network'] == '192.168.1.0'
    assert ln.default_ipv4['broadcast'] == '192.168.1.255'
    assert ln.default_ipv4['macaddress'] == '00:11:22:33:44:55'
    assert ln.default_ipv4['mtu'] == 1500
    assert ln.default_ipv4['type'] == 'unknown'
    assert ln.default

# Generated at 2022-06-17 01:05:15.297515
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    # TODO: mock out the glob.glob() call
    # TODO: mock out the os.path.exists() calls
    # TODO: mock out the os.path.isdir() calls
    # TODO: mock out the os.path.basename() calls
    # TODO: mock out the os.path.realpath() calls
    # TODO: mock out the os.readlink() calls
    # TODO: mock out the os.listdir() calls
    # TODO: mock out the os.path.join() calls
    # TODO: mock out the get_file_content() calls
    # TODO: mock out the get_file_lines() calls
    # TODO: mock out the get_file_lines() calls

# Generated at 2022-06-17 01:05:18.156235
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data('eth0') == {}


# Generated at 2022-06-17 01:05:20.880380
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # Create a class object
    network_collector = LinuxNetworkCollector()
    # Check the value of the class variable _platform
    assert network_collector._platform == 'Linux'
    # Check the value of the class variable _fact_class
    assert network_collector._fact_class == LinuxNetwork
    # Check the value of the class variable required_facts
    assert network_collector.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-17 01:05:58.208451
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: x
    module.run_command = lambda x, errors='surrogate_then_replace': (0, '', '')
    linux_network = LinuxNetwork(module)
    assert linux_network.get_ethtool_data('eth0') == {}


# Generated at 2022-06-17 01:06:12.842210
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:06:15.499242
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    # FIXME: this is a stub
    assert ln.get_ethtool_data('eth0') == {}


# Generated at 2022-06-17 01:06:18.813202
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    default_ipv4, default_ipv6 = network.get_default_interfaces()
    assert default_ipv4['address'] == '192.168.1.1'
    assert default_ipv6['address'] == 'fe80::1'

# Generated at 2022-06-17 01:06:30.157554
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    # FIXME: this is a hack to get around the fact that we can't pass in a mock
    # for the module.run_command method
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.get_bin_path = lambda *args, **kwargs: '/sbin/ip'
    module.get_file_content = lambda *args, **kwargs: '127.0.0.1'
    module.get_file_content.__name__ = 'get_file_content'
    module.get_bin_path.__name__ = 'get_bin_path'
    module.run_command.__name__ = 'run_command'
    ln = LinuxNetwork(module)
    assert ln.get_default_

# Generated at 2022-06-17 01:06:37.844368
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda x: x
    ln = LinuxNetwork(module)
    device = 'eth0'
    data = ln.get_ethtool_data(device)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data


# Generated at 2022-06-17 01:06:43.692075
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = LinuxNetworkCollector(module)
    assert collector.module == module
    assert collector.platform == 'Linux'
    assert collector.required_facts == set(['distribution', 'platform'])
    assert isinstance(collector.facts, LinuxNetwork)


# Generated at 2022-06-17 01:06:51.209631
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    default_ipv4, default_ipv6 = linux_network.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)
    assert 'address' in default_ipv4
    assert 'address' in default_ipv6
    assert 'gateway' in default_ipv4
    assert 'gateway' in default_ipv6
    assert 'interface' in default_ipv4
    assert 'interface' in default_ipv6
    assert 'scope' in default_ipv6


# Generated at 2022-06-17 01:07:02.518647
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    data = ln.get_ethtool_data('eth0')
    assert data['features']['tx_checksumming'] == 'on'
    assert data['features']['rx_checksumming'] == 'on'
    assert data['features']['scatter_gather'] == 'on'
    assert data['features']['tcp_segmentation_offload'] == 'on'
    assert data['features']['udp_fragmentation_offload'] == 'on'
    assert data['features']['generic_segmentation_offload'] == 'on'
    assert data['features']['generic_receive_offload'] == 'on'

# Generated at 2022-06-17 01:07:05.849531
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec=dict())
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.ips


# Generated at 2022-06-17 01:07:46.994196
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.get_default_ipv4 = MagicMock(return_value={'interface': 'eth0'})
    module.get_default_ipv6 = MagicMock(return_value={'interface': 'eth0'})
    module.get_interfaces_info = MagicMock(return_value=([], {}))
    module.get_ipv4_addr = MagicMock(return_value=('10.0.0.1', '255.255.255.0', '10.0.0.0'))

# Generated at 2022-06-17 01:07:50.521337
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address']
    assert ln.default_ipv6['address']
    assert ln.interfaces
    assert ln.ips


# Generated at 2022-06-17 01:07:59.001911
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    # FIXME: mock out the module.run_command
    # FIXME: mock out the module.get_bin_path
    # FIXME: mock out the get_file_content
    # FIXME: mock out the glob.glob
    # FIXME: mock out the os.path.exists
    # FIXME: mock out the os.path.isdir
    # FIXME: mock out the os.path.basename
    # FIXME: mock out the os.path.realpath
    # FIXME: mock out the os.readlink
    # FIXME: mock out the struct.pack
    # FIXME: mock out the struct.unpack
    # FIXME: mock out the socket.inet_aton
    # FIXME: mock out the socket.inet_ntoa
    #

# Generated at 2022-06-17 01:08:13.775344
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Test with iproute2
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'default via 192.168.1.1 dev eth0  proto static  metric 100', ''))
    module.get_bin_path = MagicMock(return_value='/sbin/ip')
    linux_network = LinuxNetwork(module)
    default_ipv4, default_ipv6 = linux_network.get_default_interfaces()
    assert default_ipv4 == {'address': '192.168.1.1', 'interface': 'eth0'}
    assert default_ipv6 == {}

    # Test with iproute2 and ipv6
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-17 01:08:16.713491
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: write unit test
    pass


# Generated at 2022-06-17 01:08:21.243927
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    linux_network = LinuxNetwork(module)
    assert linux_network.get_ethtool_data('eth0') == {}


# Generated at 2022-06-17 01:08:31.201571
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.get_file_content = MagicMock(return_value=True)
    module.get_default_ipv4 = MagicMock(return_value=True)
    module.get_default_ipv6 = MagicMock(return_value=True)
    module.get_default_route = MagicMock(return_value=True)
    module.get_default_route6 = MagicMock(return_value=True)
    module.get_interfaces_info = MagicMock(return_value=True)

# Generated at 2022-06-17 01:08:42.169014
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            gather_network_resources=dict(default=['all'], type='list')
        ),
        supports_check_mode=True
    )
    # FIXME: this is a hack to get around the fact that we can't pass
    #        a module object to the class constructor
    LinuxNetwork.module = module
    ln = LinuxNetwork()
    ln.populate()
    # FIXME: this is a hack to get around the fact that we can't pass
    #        a module object to the class constructor
    LinuxNetwork.module = None
    result = dict(changed=False, ansible_facts=dict(ansible_network_resources=ln.network_resources))
    module.exit

# Generated at 2022-06-17 01:08:49.953638
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/bin/ethtool')
    ln = LinuxNetwork(module)

    # test with no data
    assert ln.get_ethtool_data('eth0') == {}

    # test with data

# Generated at 2022-06-17 01:08:57.274748
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    interfaces, ips = ln.get_interfaces_info(None, None, None)
    assert isinstance(interfaces, dict)
    assert isinstance(ips, dict)
    assert isinstance(ips['all_ipv4_addresses'], list)
    assert isinstance(ips['all_ipv6_addresses'], list)
    for interface in interfaces.values():
        assert isinstance(interface, dict)
        assert 'device' in interface
        assert 'type' in interface
        assert 'mtu' in interface
        assert 'active' in interface
        if 'ipv4' in interface:
            assert isinstance(interface['ipv4'], dict)
            assert 'address' in interface['ipv4']
           

# Generated at 2022-06-17 01:09:41.057009
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-17 01:09:49.108705
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:09:52.214301
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips


# Generated at 2022-06-17 01:10:04.690130
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert 'default_ipv4' in ln.facts
    assert 'default_ipv6' in ln.facts
    assert 'interfaces' in ln.facts
    assert 'all_ipv4_addresses' in ln.facts['ipv4']
    assert 'all_ipv6_addresses' in ln.facts['ipv6']
    assert 'ipv4' in ln.facts
    assert 'ipv6' in ln.facts
    assert 'routes6' in ln.facts
    assert 'routes' in ln.facts
    assert 'neighbors' in ln.facts
    assert 'neighbors6' in ln.facts


# Generated at 2022-06-17 01:10:15.666397
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

# Generated at 2022-06-17 01:10:17.922474
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: this is a stub
    pass


# Generated at 2022-06-17 01:10:23.689378
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips
    assert ln.gateways


# Generated at 2022-06-17 01:10:35.225148
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    data = ln.get_ethtool_data('lo')

# Generated at 2022-06-17 01:10:45.082252
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Test with a real device
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    device = 'lo'
    data = network.get_ethtool_data(device)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data

    # Test with a fake device
    device = 'fake'
    data = network.get_ethtool_data(device)
    assert 'features' not in data
    assert 'timestamping' not in data
    assert 'hw_timestamp_filters' not in data
    assert 'phc_index' not in data



# Generated at 2022-06-17 01:10:51.141170
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips


# Generated at 2022-06-17 01:11:47.776268
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    linux_network = LinuxNetwork(module)
    device = 'eth0'

# Generated at 2022-06-17 01:11:55.027416
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='')
    module.params = {'config': '', 'autoconnect': True}
    module.check_mode = False
    module.exit_json = MagicMock()
    module.fail_json = MagicMock()
    module.warn = MagicMock()
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='')
    module.params = {'config': '', 'autoconnect': True}
    module.check_mode = False
    module.exit_json = MagicMock()


# Generated at 2022-06-17 01:12:04.523001
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

# Generated at 2022-06-17 01:12:07.090935
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.default_interface_ipv4
    assert ln.default_interface_ipv6
    assert ln.ips


# Generated at 2022-06-17 01:12:12.093594
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address']
    assert ln.default_ipv6['address']
    assert ln.interfaces
    assert ln.ips
    assert ln.gateways


# Generated at 2022-06-17 01:12:23.420579
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Test with no default route
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    ln = LinuxNetwork(module)
    assert ln.get_default_interfaces() == (None, None)

    # Test with default route
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'default via 192.168.1.1 dev eth0', ''))
    ln = LinuxNetwork(module)
    assert ln.get_default_interfaces() == ({'address': '192.168.1.1', 'interface': 'eth0'}, None)

    # Test with default route and ipv6
    module = AnsibleModule(argument_spec={})
    module

# Generated at 2022-06-17 01:12:24.071449
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: add unit test
    pass


# Generated at 2022-06-17 01:12:32.970409
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Test with a real device
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    data = network.get_ethtool_data('eth0')
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data

    # Test with a fake device
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    data = network.get_ethtool_data('eth1')
    assert 'features' not in data
    assert 'timestamping' not in data
    assert 'hw_timestamp_filters' not in data
    assert 'phc_index' not in data


# Generated at 2022-06-17 01:12:42.180560
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address'] == '10.0.2.15'
    assert default_ipv4['netmask'] == '255.255.255.0'
    assert default_ipv4['network'] == '10.0.2.0'
    assert default_ipv4['broadcast'] == '10.0.2.255'
    assert default_ipv6['address'] == 'fe80::a00:27ff:fe1b:9c7d'
    assert default_ipv6['prefix'] == '64'
    assert default_ipv6['scope'] == 'link'


# Generated at 2022-06-17 01:12:47.846429
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)


# Generated at 2022-06-17 01:13:36.550174
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)