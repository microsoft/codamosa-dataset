

# Generated at 2022-06-17 01:04:14.429724
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Test with no default interface
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    rc, out, err = module.run_command("ip route show")
    assert rc == 0
    assert out == ""
    assert err == ""
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4 == {}
    assert default_ipv6 == {}

    # Test with a default interface
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    rc, out, err = module.run_command("ip route show")
    assert rc == 0
    assert out == "default via 192.0.2.1 dev eth0  proto static  metric 100\n"
    assert err == ""


# Generated at 2022-06-17 01:04:25.502184
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data('lo') == {}

# Generated at 2022-06-17 01:04:26.897935
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: add tests
    pass


# Generated at 2022-06-17 01:04:28.343209
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: write unit test
    pass


# Generated at 2022-06-17 01:04:40.898840
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:04:49.137094
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    device = 'eth0'
    data = linux_network.get_ethtool_data(device)
    assert isinstance(data, dict)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data



# Generated at 2022-06-17 01:04:55.980426
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.ips
    assert ln.gateways


# Generated at 2022-06-17 01:05:05.900661
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

    # Test 1:
    # - no default route
    # - no default route6
    # - no default interface
    # - no default interface6
    # - no default address
    # - no default address6
    # - no default gateway
    # - no default gateway6
    # - no default netmask
    # - no default netmask6
    # - no default macaddress
    # - no default mtu
    # - no default type
    # - no default alias
    # - no default scope
    # - no default prefix
    # - no default broadcast
    # - no default network
    # - no default ipv4
    # - no default ipv6
    # - no default ipv4_secondaries
    # - no default

# Generated at 2022-06-17 01:05:17.031472
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4 = {'address': '192.168.1.1'}
    default_ipv6 = {'address': '2001:db8::1'}
    interfaces, ips = ln.get_interfaces_info('/sbin/ip', default_ipv4, default_ipv6)
    assert 'lo' in interfaces
    assert 'eth0' in interfaces
    assert 'eth1' in interfaces
    assert 'eth2' in interfaces
    assert 'eth3' in interfaces
    assert 'eth4' in interfaces
    assert 'eth5' in interfaces
    assert 'eth6' in interfaces
    assert 'eth7' in interfaces
    assert 'eth8' in interfaces
    assert 'eth9' in interfaces


# Generated at 2022-06-17 01:05:22.349523
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)
    assert 'address' in default_ipv4
    assert 'address' in default_ipv6


# Generated at 2022-06-17 01:05:56.813827
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:06:03.560075
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda x: x
    linux_network = LinuxNetwork(module)
    interfaces, ips = linux_network.get_interfaces_info('/sbin/ip', {}, {})
    assert isinstance(interfaces, dict)
    assert isinstance(ips, dict)
    assert 'all_ipv4_addresses' in ips
    assert 'all_ipv6_addresses' in ips
    assert isinstance(ips['all_ipv4_addresses'], list)
    assert isinstance(ips['all_ipv6_addresses'], list)
    for interface in interfaces.values():
        assert 'device' in interface
        assert 'type' in interface

# Generated at 2022-06-17 01:06:16.591213
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:06:29.802550
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address'] == '192.168.1.1'
    assert ln.default_ipv6['address'] == 'fe80::1'
    assert ln.interfaces['eth0']['ipv4']['address'] == '192.168.1.1'
    assert ln.interfaces['eth0']['ipv6'][0]['address'] == 'fe80::1'
    assert ln.interfaces['eth0']['ipv6'][1]['address'] == '2001:db8::1'

# Generated at 2022-06-17 01:06:36.724840
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)


# Generated at 2022-06-17 01:06:47.825915
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda x: x
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address'] == '192.168.1.1'
    assert default_ipv4['broadcast'] == '192.168.1.255'
    assert default_ipv4['netmask'] == '255.255.255.0'
    assert default_ipv4['network'] == '192.168.1.0'
    assert default_ipv6['address'] == 'fe80::5054:ff:fe12:3456'
    assert default_ipv6['prefix'] == '64'

# Generated at 2022-06-17 01:07:00.195087
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    linux_network = LinuxNetwork(module)
    interfaces, ips = linux_network.get_interfaces_info(None, None, None)
    assert isinstance(interfaces, dict)
    assert isinstance(ips, dict)
    assert isinstance(ips['all_ipv4_addresses'], list)
    assert isinstance(ips['all_ipv6_addresses'], list)
    for interface in interfaces.values():
        assert isinstance(interface, dict)
        assert 'device' in interface
        assert 'type' in interface
        assert 'mtu' in interface
        assert 'active' in interface
        assert 'macaddress' in interface
        assert 'ipv4'

# Generated at 2022-06-17 01:07:13.478328
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Test with ethtool_path = None
    ln = LinuxNetwork()
    ln.module = MagicMock()
    ln.module.get_bin_path.return_value = None
    assert ln.get_ethtool_data('eth0') == {}

    # Test with ethtool_path = /usr/bin/ethtool
    ln.module.get_bin_path.return_value = '/usr/bin/ethtool'
    ln.module.run_command.return_value = (0, '', '')
    assert ln.get_ethtool_data('eth0') == {}

    # Test with ethtool_path = /usr/bin/ethtool
    # and ethtool -k output

# Generated at 2022-06-17 01:07:15.676047
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-17 01:07:24.357004
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/sbin/ip')
    ln = LinuxNetwork(module)
    ln.get_default_interfaces()
    module.run_command.assert_called_with(['/sbin/ip', 'route', 'get', '8.8.8.8'], errors='surrogate_then_replace')


# Generated at 2022-06-17 01:08:02.957989
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4 = {}
    default_ipv6 = {}
    interfaces, ips = ln.get_interfaces_info('/sbin/ip', default_ipv4, default_ipv6)
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'lo' in interfaces

# Generated at 2022-06-17 01:08:13.520085
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.ips
    assert ln.gateways
    assert ln.gateways['default']
    assert ln.gateways['default']['ipv4']
    assert ln.gateways['default']['ipv6']
    assert ln.gateways['v4']
    assert ln.gateways['v6']


# Generated at 2022-06-17 01:08:20.922404
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address'] == '192.168.1.1'
    assert default_ipv6['address'] == 'fe80::1'



# Generated at 2022-06-17 01:08:30.964558
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    # TODO: mock out the methods this calls
    # TODO: mock out the module.run_command
    # TODO: mock out the get_bin_path
    # TODO: mock out the get_file_content
    # TODO: mock out the glob.glob
    # TODO: mock out the os.path.isdir
    # TODO: mock out the os.path.exists
    # TODO: mock out the os.path.basename
    # TODO: mock out the os.path.realpath
    # TODO: mock out the os.readlink
    # TODO: mock out the struct.pack
    # TODO: mock out the struct.unpack
    # TODO: mock out the socket.inet

# Generated at 2022-06-17 01:08:38.003009
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:08:47.600623
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Test case 1:
    # ethtool_path is not None
    # rc is 0
    # stdout is not empty
    # stderr is empty
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/usr/bin/ethtool')
    network = LinuxNetwork(module)
    device = 'eth0'
    data = network.get_ethtool_data(device)
    assert data == {'features': {}, 'timestamping': [], 'hw_timestamp_filters': []}
    # Test case 2:
    # ethtool_path is not None
    # rc is 0
    # stdout is not empty
    # stderr is empty

# Generated at 2022-06-17 01:08:58.535224
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Test with a single interface
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='00:00:00:00:00:00')
    ln = LinuxNetwork(module)
    interfaces, ips = ln.get_interfaces_info('/sbin/ip', {}, {})
    assert interfaces == {'lo': {'device': 'lo', 'type': 'loopback', 'active': True, 'macaddress': '00:00:00:00:00:00', 'mtu': 65536, 'promisc': False}}

# Generated at 2022-06-17 01:09:00.085471
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: write unit test
    pass


# Generated at 2022-06-17 01:09:08.339165
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

# Generated at 2022-06-17 01:09:16.607354
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

# Generated at 2022-06-17 01:09:56.422192
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-17 01:10:07.736479
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

    # Test with a dummy /sys/class/net/eth0
    with tempfile.TemporaryDirectory() as tmpdir:
        os.makedirs(os.path.join(tmpdir, 'sys', 'class', 'net', 'eth0'))
        os.makedirs(os.path.join(tmpdir, 'sys', 'class', 'net', 'eth0', 'bonding'))
        os.makedirs(os.path.join(tmpdir, 'sys', 'class', 'net', 'eth0', 'bonding_slave'))
        os.makedirs(os.path.join(tmpdir, 'sys', 'class', 'net', 'eth0', 'bridge'))

# Generated at 2022-06-17 01:10:09.994135
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: this is a stub
    pass


# Generated at 2022-06-17 01:10:21.687749
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    network = LinuxNetwork(module)
    device = "eth0"
    data = network.get_ethtool_data(device)
    assert isinstance(data, dict)
    assert 'features' in data
    assert isinstance(data['features'], dict)
    assert 'timestamping' in data
    assert isinstance(data['timestamping'], list)
    assert 'hw_timestamp_filters' in data
    assert isinstance(data['hw_timestamp_filters'], list)
    assert 'phc_index' in data
    assert isinstance(data['phc_index'], int)


# Generated at 2022-06-17 01:10:29.983354
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.default_interface
    assert ln.default_gateway
    assert ln.default_gateway_interface
    assert ln.default_gateway_ipv4
    assert ln.default_gateway_ipv6
    assert ln.default_interface_ipv4
    assert ln.default_interface_ipv6
    assert ln.default_interface_macaddress
    assert ln.default_interface_mtu
    assert ln.default_interface_type
    assert ln.all_ipv4_addresses
    assert ln

# Generated at 2022-06-17 01:10:36.260667
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address']
    assert ln.default_ipv6['address']
    assert ln.interfaces
    assert ln.ips


# Generated at 2022-06-17 01:10:46.572440
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda x: x
    module.run_command = lambda x: (0, '', '')
    module.get_bin_path = lambda x: '/bin/ip'
    network = LinuxNetwork(module)
    interfaces, ips = network.get_interfaces_info('/bin/ip', {}, {})
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'ipv4' in interfaces['lo']
    assert 'ipv6' in interfaces['lo']
    assert 'all_ipv4_addresses' in ips
    assert 'all_ipv6_addresses' in ips
    assert '127.0.0.1' in ips['all_ipv4_addresses']

# Generated at 2022-06-17 01:10:53.760259
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    device = 'eth0'
    data = ln.get_ethtool_data(device)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data


# Generated at 2022-06-17 01:11:02.091546
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

# Generated at 2022-06-17 01:11:13.975329
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    interfaces, ips = network.get_interfaces_info(None, None, None)
    assert isinstance(interfaces, dict)
    assert isinstance(ips, dict)
    assert 'all_ipv4_addresses' in ips
    assert 'all_ipv6_addresses' in ips
    assert isinstance(ips['all_ipv4_addresses'], list)
    assert isinstance(ips['all_ipv6_addresses'], list)
    for interface in interfaces.values():
        assert isinstance(interface, dict)
        assert 'device' in interface
        assert isinstance(interface['device'], str)
        assert 'type' in interface
        assert isinstance(interface['type'], str)
       

# Generated at 2022-06-17 01:12:15.274169
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            filter=dict(default=None, type='list'),
        ),
        supports_check_mode=True,
    )
    # FIXME: this is a bit of a hack, but it's the best way to get this to work
    # with the current structure of the module.
    module.params['gather_subset'] = ['all']
    module.params['filter'] = ['*']
    network = LinuxNetwork(module)
    network.populate()
    assert network.interfaces
    assert network.default_ipv4
    assert network.default_ipv6
    assert network.all_ipv4_addresses
    assert network.all_ipv6_addresses


# Generated at 2022-06-17 01:12:26.058328
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

# Generated at 2022-06-17 01:12:33.447592
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:12:42.722250
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

# Generated at 2022-06-17 01:12:44.418685
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: this is a stub
    pass


# Generated at 2022-06-17 01:12:50.355887
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.network.common.utils import load_platform_subclass
    module = AnsibleModule(argument_spec={})
    network_module = load_platform_subclass(module, 'network')
    network_module.get_interfaces_info()



# Generated at 2022-06-17 01:12:56.495319
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips


# Generated at 2022-06-17 01:13:04.799080
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = Mock(return_value='/bin/ip')
    module.run_command = Mock(return_value=(0, '', ''))

# Generated at 2022-06-17 01:13:15.151324
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address'] == '192.168.122.1'
    assert default_ipv4['broadcast'] == '192.168.122.255'
    assert default_ipv4['netmask'] == '255.255.255.0'
    assert default_ipv4['network'] == '192.168.122.0'
    assert default_ipv4['macaddress'] == '52:54:00:12:35:02'
    assert default_ipv4['mtu'] == 1500
    assert default_ipv4['type'] == 'unknown'

# Generated at 2022-06-17 01:13:25.209476
# Unit test for method get_interfaces_info of class LinuxNetwork