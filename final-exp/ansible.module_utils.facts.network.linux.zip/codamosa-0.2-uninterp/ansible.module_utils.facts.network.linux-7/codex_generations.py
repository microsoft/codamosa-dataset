

# Generated at 2022-06-17 01:04:22.568054
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['all'], type='list'),
            filter=dict(default=None, type='str'),
        ),
        supports_check_mode=True,
    )
    # FIXME: this is a stub
    # FIXME: this is not a complete test
    # FIXME: this is not a good test
    # FIXME: this is not a unit test
    # FIXME: this is not a test at all
    # FIXME: this is a hack
    # FIXME: this is a hack
    # FIXME: this is a hack
    # FIXME: this is a hack
    # FIXME: this is a hack
    # FIXME: this is a hack
    # FIXME: this is a hack
    # FIXME:

# Generated at 2022-06-17 01:04:31.257315
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
        ),
        supports_check_mode=True,
    )
    # FIXME: this is a hack to get around the fact that the module is not
    #        actually being run, so the module.exit_json() call is not
    #        actually being called.
    module.exit_json = lambda **kwargs: None
    # FIXME: this is a hack to get around the fact that the module is not
    #        actually being run, so the module.fail_json() call is not
    #        actually being called.
    module.fail_json = lambda **kwargs: None
    # FIXME: this is a hack to get around the fact that the module is not
    #        actually being

# Generated at 2022-06-17 01:04:37.520518
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    linux_network = LinuxNetwork(module)
    device = 'eth0'
    data = linux_network.get_ethtool_data(device)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data



# Generated at 2022-06-17 01:04:42.518985
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)


# Generated at 2022-06-17 01:04:54.817691
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address'] == '192.168.1.1'
    assert ln.default_ipv4['netmask'] == '255.255.255.0'
    assert ln.default_ipv4['network'] == '192.168.1.0'
    assert ln.default_ipv4['broadcast'] == '192.168.1.255'
    assert ln.default_ipv6['address'] == 'fe80::a00:27ff:fe6f:a9c0'
    assert ln.default_ipv6['prefix'] == '64'
    assert ln.default_ipv6['scope'] == 'link'


# Generated at 2022-06-17 01:04:56.253513
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # FIXME: this is a stub
    assert True


# Generated at 2022-06-17 01:05:05.215621
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

# Generated at 2022-06-17 01:05:17.254415
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert 'default_ipv4' in ln.facts
    assert 'default_ipv6' in ln.facts
    assert 'interfaces' in ln.facts
    assert 'all_ipv4_addresses' in ln.facts['interfaces']
    assert 'all_ipv6_addresses' in ln.facts['interfaces']
    assert 'ipv4' in ln.facts['interfaces']['lo']
    assert 'ipv6' in ln.facts['interfaces']['lo']
    assert 'address' in ln.facts['interfaces']['lo']['ipv4']

# Generated at 2022-06-17 01:05:18.286467
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: implement
    pass



# Generated at 2022-06-17 01:05:19.519193
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-17 01:05:57.566317
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # FIXME: this is a stub
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.facts['default_ipv4']['address'] == '192.168.1.1'
    assert ln.facts['default_ipv4']['netmask'] == '255.255.255.0'
    assert ln.facts['default_ipv4']['network'] == '192.168.1.0'
    assert ln.facts['default_ipv4']['broadcast'] == '192.168.1.255'
    assert ln.facts['default_ipv4']['macaddress'] == '00:0c:29:8c:11:b1'

# Generated at 2022-06-17 01:06:04.927941
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.ips
    assert ln.gateways


# Generated at 2022-06-17 01:06:15.779508
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Test with a valid device
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    device = 'lo'
    data = linux_network.get_ethtool_data(device)

# Generated at 2022-06-17 01:06:28.902705
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address'] == '192.168.1.1'
    assert default_ipv4['netmask'] == '255.255.255.0'
    assert default_ipv4['network'] == '192.168.1.0'
    assert default_ipv4['broadcast'] == '192.168.1.255'
    assert default_ipv4['macaddress'] == '00:00:00:00:00:00'
    assert default_ipv4['mtu'] == 1500
    assert default_ipv4['type'] == 'unknown'

# Generated at 2022-06-17 01:06:35.662667
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='')
    ln = LinuxNetwork(module)
    ln.get_interfaces_info = MagicMock(return_value=(None, None))
    ln.get_default_interfaces()
    assert ln.default_ipv4['address'] == '127.0.0.1'
    assert ln.default_ipv6['address'] == '::1'


# Generated at 2022-06-17 01:06:42.545588
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda x: x
    ln = LinuxNetwork(module)
    ip_path = module.get_bin_path("ip")
    default_ipv4, default_ipv6 = ln.get_default_interfaces(ip_path)
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)


# Generated at 2022-06-17 01:06:48.019088
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.default_interface
    assert ln.default_gateway
    assert ln.default_gateway_v6
    assert ln.ips


# Generated at 2022-06-17 01:06:58.935081
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    # Test with a real device
    data = linux_network.get_ethtool_data('eth0')
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data
    # Test with a fake device
    data = linux_network.get_ethtool_data('fake_device')
    assert 'features' not in data
    assert 'timestamping' not in data
    assert 'hw_timestamp_filters' not in data
    assert 'phc_index' not in data


# Generated at 2022-06-17 01:07:13.087289
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.params['gather_subset'] = ['!all', 'min']
    module.params['gather_network_resources'] = ['all']
    module.params['filter'] = ['*']
    module.params['config'] = ['/etc/ansible/facts.d']
    module.params['ansible_facts'] = {}
    module.params['ansible_facts']['ansible_net_gather_subset'] = ['!all', 'min']
    module.params['ansible_facts']['ansible_net_gather_network_resources'] = ['all']
    module.params['ansible_facts']['ansible_net_filter'] = ['*']

# Generated at 2022-06-17 01:07:18.723818
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.ips


# Generated at 2022-06-17 01:07:59.678945
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    device = 'eth0'
    data = linux_network.get_ethtool_data(device)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data


# Generated at 2022-06-17 01:08:14.098424
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address'] == '192.168.1.1'
    assert default_ipv4['broadcast'] == '192.168.1.255'
    assert default_ipv4['netmask'] == '255.255.255.0'
    assert default_ipv4['network'] == '192.168.1.0'
    assert default_ipv4['macaddress'] == '00:0c:29:8c:11:b1'
    assert default_ipv4['mtu'] == 1500
    assert default_ipv4['type'] == 'ethernet'
    assert default_ipv

# Generated at 2022-06-17 01:08:26.577371
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: x
    module.run_command = lambda x, errors='surrogate_then_replace': (0, '', '')
    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data('eth0') == {'features': {}, 'timestamping': [], 'hw_timestamp_filters': []}


# Generated at 2022-06-17 01:08:31.744572
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'device': 'eth0'
    }
    linux_network = LinuxNetwork(module)
    data = linux_network.get_ethtool_data(module.params['device'])
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data



# Generated at 2022-06-17 01:08:38.551278
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4 = {'address': '192.168.1.1'}
    default_ipv6 = {'address': 'fe80::1'}
    interfaces, ips = ln.get_interfaces_info('/sbin/ip', default_ipv4, default_ipv6)
    assert interfaces['eth0']['ipv4']['address'] == '192.168.1.1'
    assert interfaces['eth0']['ipv4']['broadcast'] == '192.168.1.255'
    assert interfaces['eth0']['ipv4']['netmask'] == '255.255.255.0'

# Generated at 2022-06-17 01:08:41.838841
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data('eth0') == {}


# Generated at 2022-06-17 01:08:45.536677
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address']
    assert default_ipv6['address']



# Generated at 2022-06-17 01:08:49.717059
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address']
    assert ln.default_ipv6['address']
    assert ln.interfaces
    assert ln.ips


# Generated at 2022-06-17 01:08:58.409402
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            gather_network_resources=dict(default=['all'], type='list'),
        ),
        supports_check_mode=True,
    )
    ln = LinuxNetwork(module)
    ln.populate()
    module.exit_json(changed=False, ansible_facts=dict(ansible_net_interfaces=ln.interfaces, ansible_net_gather_network_resources=ln.gather_network_resources))


# Generated at 2022-06-17 01:09:12.603099
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {'gather_subset': ['all']}
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.facts['default_ipv4']['address'] == '127.0.0.1'
    assert ln.facts['default_ipv6']['address'] == '::1'
    assert ln.facts['interfaces']['lo']['ipv4']['address'] == '127.0.0.1'
    assert ln.facts['interfaces']['lo']['ipv4']['netmask'] == '255.0.0.0'

# Generated at 2022-06-17 01:09:54.767940
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address'] == '192.168.1.2'
    assert default_ipv4['netmask'] == '255.255.255.0'
    assert default_ipv4['network'] == '192.168.1.0'
    assert default_ipv4['broadcast'] == '192.168.1.255'
    assert default_ipv6['address'] == 'fe80::a00:27ff:fe3a:a3f3'
    assert default_ipv6['prefix'] == '64'
    assert default_ipv6['scope'] == 'link'


# Generated at 2022-06-17 01:10:06.309510
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address'] == '192.168.1.1'
    assert ln.default_ipv4['netmask'] == '255.255.255.0'
    assert ln.default_ipv4['network'] == '192.168.1.0'
    assert ln.default_ipv4['broadcast'] == '192.168.1.255'
    assert ln.default_ipv4['macaddress'] == '00:0c:29:8c:11:b1'
    assert ln.default_ipv4['mtu'] == 1500
    assert ln.default_ipv4['type'] == 'ether'
    assert l

# Generated at 2022-06-17 01:10:17.923484
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4 = {'address': '192.168.1.1'}
    default_ipv6 = {'address': '2001:db8::1'}
    interfaces, ips = ln.get_interfaces_info('/sbin/ip', default_ipv4, default_ipv6)
    assert interfaces['lo']['ipv4']['address'] == '127.0.0.1'
    assert interfaces['lo']['ipv4']['netmask'] == '255.0.0.0'
    assert interfaces['lo']['ipv4']['network'] == '127.0.0.0'

# Generated at 2022-06-17 01:10:22.969960
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    # FIXME: this is a hack to get around the fact that we can't pass in a module
    # instance to the class constructor
    LinuxNetwork.module = module
    ln = LinuxNetwork()
    # FIXME: this is a hack to get around the fact that we can't pass in a module
    # instance to the class constructor
    LinuxNetwork.module = module
    # FIXME: this is a hack to get around the fact that we can't pass in a module
    # instance to the class constructor
    LinuxNetwork.module = module
    # FIXME: this is a hack to get around the fact that we can't pass in a module
    # instance to the class constructor
    LinuxNetwork.module = module
    # FIXME: this is a hack to get around the fact that we can't pass in a module

# Generated at 2022-06-17 01:10:34.797500
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: x
    module.run_command = lambda x, errors='surrogate_then_replace': (0, '', '')
    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data('eth0') == {
        'features': {},
        'timestamping': [],
        'hw_timestamp_filters': [],
    }


# Generated at 2022-06-17 01:10:45.251423
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.facts['default_ipv4']['address'] == '192.168.0.1'
    assert ln.facts['default_ipv4']['netmask'] == '255.255.255.0'
    assert ln.facts['default_ipv4']['network'] == '192.168.0.0'
    assert ln.facts['default_ipv4']['broadcast'] == '192.168.0.255'
    assert ln.facts['default_ipv6']['address'] == 'fe80::5054:ff:fe12:3456'

# Generated at 2022-06-17 01:10:57.962103
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:11:12.726618
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda x: x
    ln = LinuxNetwork(module)
    interfaces, ips = ln.get_interfaces_info(None, {}, {})
    assert isinstance(interfaces, dict)
    assert isinstance(ips, dict)
    assert 'all_ipv4_addresses' in ips
    assert 'all_ipv6_addresses' in ips
    assert isinstance(ips['all_ipv4_addresses'], list)
    assert isinstance(ips['all_ipv6_addresses'], list)
    for i in interfaces:
        assert isinstance(interfaces[i], dict)
        assert 'device' in interfaces[i]
        assert 'type' in interfaces[i]
        assert 'mtu'

# Generated at 2022-06-17 01:11:15.258994
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: write unit tests
    pass


# Generated at 2022-06-17 01:11:23.380538
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.network.common.utils import load_platform_subclass

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            gather_network_resources=dict(default=['all'], type='list'),
        ),
        supports_check_mode=True,
    )

    # FIXME: this is a hack to get the module to work with the network_cli connection
    module.params['network_os'] = 'Linux'
    module.params['connection'] = 'network_cli'

    # FIXME: this is a hack to get the module to work with the network_cli connection
    module.params['network_os'] = 'Linux'
    module.params

# Generated at 2022-06-17 01:12:10.877247
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.get_file_content = MagicMock(return_value=True)
    module.get_file_content = MagicMock(return_value=True)
    module.get_file_content = MagicMock(return_value=True)
    module.get_file_content = MagicMock(return_value=True)
    module.get_file_content = MagicMock(return_value=True)
    module.get_file_content = MagicMock(return_value=True)
    module.get_file_content = MagicMock(return_value=True)
    module.get

# Generated at 2022-06-17 01:12:11.986334
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: implement
    pass


# Generated at 2022-06-17 01:12:18.271729
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    device = 'eth0'
    data = linux_network.get_ethtool_data(device)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data


# Generated at 2022-06-17 01:12:19.881374
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-17 01:12:27.927882
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address'] == '192.168.1.1'
    assert default_ipv6['address'] == 'fe80::1'


# Generated at 2022-06-17 01:12:40.309302
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
        ),
        supports_check_mode=True,
    )
    ln = LinuxNetwork(module)
    ln.populate()
    result = ln.data
    assert result['default_ipv4']['address'] == '192.168.1.1'
    assert result['default_ipv4']['broadcast'] == '192.168.1.255'
    assert result['default_ipv4']['netmask'] == '255.255.255.0'
    assert result['default_ipv4']['network'] == '192.168.1.0'

# Generated at 2022-06-17 01:12:53.593949
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda x: x
    linux_network = LinuxNetwork(module)

# Generated at 2022-06-17 01:12:55.216586
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: implement test
    pass


# Generated at 2022-06-17 01:13:03.661498
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:13:15.957352
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, "", ""))
    module.get_bin_path = MagicMock(return_value="/usr/bin/ethtool")
    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data("eth0") == {}
    module.run_command.return_value = (0, "foo: bar", "")
    assert ln.get_ethtool_data("eth0") == {'features': {'foo': 'bar'}}
    module.run_command.return_value = (0, "foo: bar\n", "")
    assert ln.get_ethtool_data("eth0") == {'features': {'foo': 'bar'}}