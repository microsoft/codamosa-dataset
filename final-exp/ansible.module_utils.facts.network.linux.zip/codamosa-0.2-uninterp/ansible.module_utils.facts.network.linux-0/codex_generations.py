

# Generated at 2022-06-17 01:04:22.082939
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    data = ln.get_ethtool_data('eth0')
    assert data['features']['rx_all'] == 'off'
    assert data['features']['tx_tcp_segmentation'] == 'on'
    assert data['timestamping'] == ['hardware', 'software', 'tx_hardware', 'tx_software']
    assert data['hw_timestamp_filters'] == ['all', 'none', 'multicast', 'unicast', 'p2p']
    assert data['phc_index'] == 0



# Generated at 2022-06-17 01:04:30.908751
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.module.params['default_ipv4']['address'] == '10.0.2.15'
    assert ln.module.params['default_ipv4']['broadcast'] == '10.0.2.255'
    assert ln.module.params['default_ipv4']['netmask'] == '255.255.255.0'
    assert ln.module.params['default_ipv4']['network'] == '10.0.2.0'
    assert ln.module.params['default_ipv4']['macaddress'] == '52:54:00:12:35:02'

# Generated at 2022-06-17 01:04:42.317895
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert 'default_ipv4' in ln.facts
    assert 'default_ipv6' in ln.facts
    assert 'interfaces' in ln.facts
    assert 'all_ipv4_addresses' in ln.facts['ipv4']
    assert 'all_ipv6_addresses' in ln.facts['ipv6']
    assert 'ipv4' in ln.facts
    assert 'ipv6' in ln.facts
    assert 'interfaces' in ln.facts
    assert 'default_ipv4' in ln.facts
    assert 'default_ipv6' in ln.facts
    assert 'default_interface' in ln.facts

# Generated at 2022-06-17 01:04:54.805294
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:04:59.739452
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4 is not None
    assert ln.default_ipv6 is not None
    assert ln.interfaces is not None
    assert ln.ips is not None


# Generated at 2022-06-17 01:05:11.360135
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            filter=dict(default=None, type='str'),
        ),
        supports_check_mode=True,
    )
    ln = LinuxNetwork(module)
    ln.populate()
    result = ln.network_facts
    assert result['default_ipv4']['address'] == '192.168.1.1'
    assert result['default_ipv6']['address'] == 'fe80::1'
    assert result['interfaces']['lo']['ipv4']['address'] == '127.0.0.1'

# Generated at 2022-06-17 01:05:20.036678
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    data = ln.get_ethtool_data('eth0')
    assert data['features']['tx_checksumming'] == 'on'
    assert data['features']['rx_checksumming'] == 'on'
    assert data['features']['scatter_gather'] == 'on'
    assert data['features']['tcp_segmentation_offload'] == 'on'
    assert data['features']['udp_fragmentation_offload'] == 'on'
    assert data['features']['generic_segmentation_offload'] == 'on'
    assert data['features']['generic_receive_offload'] == 'on'

# Generated at 2022-06-17 01:05:23.934831
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips
    assert ln.gateways


# Generated at 2022-06-17 01:05:32.613352
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4 = {}
    default_ipv6 = {}
    interfaces, ips = ln.get_interfaces_info('/sbin/ip', default_ipv4, default_ipv6)
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'ipv4' in interfaces['lo']
    assert 'ipv6' in interfaces['lo']
    assert 'all_ipv4_addresses' in ips
    assert 'all_ipv6_addresses' in ips
    assert '127.0.0.1' in ips['all_ipv4_addresses']
    assert '::1' in ips['all_ipv6_addresses']

# Generated at 2022-06-17 01:05:35.783487
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.ips
    assert ln.gateways


# Generated at 2022-06-17 01:06:16.200323
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: implement
    pass



# Generated at 2022-06-17 01:06:19.822381
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # FIXME: this is a stub
    pass



# Generated at 2022-06-17 01:06:21.109654
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: implement
    pass


# Generated at 2022-06-17 01:06:24.972079
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    # FIXME: this is a stub
    assert ln.get_ethtool_data("eth0") == {}


# Generated at 2022-06-17 01:06:26.618399
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-17 01:06:31.813712
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.ipv4
    assert ln.ipv6
    assert ln.default_ipv4
    assert ln.default_ipv6


# Generated at 2022-06-17 01:06:34.039881
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # Test with empty params
    module = AnsibleModule(argument_spec={})
    collector = LinuxNetworkCollector(module)
    assert collector.module == module
    assert collector.facts == {}
    assert collector.platform == 'Linux'
    assert collector.fact_class == LinuxNetwork
    assert collector.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-17 01:06:45.349666
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda x: x
    network = LinuxNetwork(module)
    device = 'eth0'
    data = network.get_ethtool_data(device)
    assert data['features']['tx_checksumming'] == 'on'
    assert data['features']['rx_checksumming'] == 'on'
    assert data['features']['scatter_gather'] == 'on'
    assert data['features']['tcp_segmentation_offload'] == 'on'
    assert data['features']['udp_fragmentation_offload'] == 'on'
    assert data['features']['generic_segmentation_offload'] == 'on'

# Generated at 2022-06-17 01:06:58.256530
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

    # TODO: mock out the run_command and get_bin_path methods
    # TODO: mock out the get_file_content method
    # TODO: mock out the glob.glob method
    # TODO: mock out the os.path.exists method
    # TODO: mock out the os.path.isdir method
    # TODO: mock out the os.path.basename method
    # TODO: mock out the os.path.realpath method
    # TODO: mock out the os.readlink method
    # TODO: mock out the struct.pack method
    # TODO: mock out the struct.unpack method
    # TODO: mock out the socket.inet_aton method
    # TODO: mock out the

# Generated at 2022-06-17 01:07:12.750367
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/bin/ip')
    module.get_file_content = MagicMock(return_value='')

# Generated at 2022-06-17 01:07:56.767145
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params = dict(
        gather_subset=['all'],
    )
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.facts['default_ipv4']['address'] == '192.168.1.1'
    assert ln.facts['default_ipv6']['address'] == 'fe80::5054:ff:fe12:3456'
    assert ln.facts['interfaces']['eth0']['ipv4']['address'] == '192.168.1.1'
    assert ln.facts['interfaces']['eth0']['ipv4']['broadcast'] == '192.168.1.255'

# Generated at 2022-06-17 01:08:01.357236
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    default_ipv4, default_ipv6 = network.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)


# Generated at 2022-06-17 01:08:14.763766
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:08:16.943179
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-17 01:08:21.454876
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = LinuxNetworkCollector(module)
    assert collector.platform == 'Linux'
    assert collector.fact_class == LinuxNetwork
    assert collector.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-17 01:08:24.351196
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data('eth0') == {}


# Generated at 2022-06-17 01:08:36.403249
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            gather_network_resources=dict(default=['all'], type='list'),
        ),
        supports_check_mode=True,
    )
    nm = LinuxNetwork(module)
    nm.populate()
    result = nm.get_result()
    assert result['default_ipv4']['address'] == '192.168.0.1'
    assert result['default_ipv4']['broadcast'] == '192.168.0.255'
    assert result['default_ipv4']['netmask'] == '255.255.255.0'
    assert result['default_ipv4']['network'] == '192.168.0.0'

# Generated at 2022-06-17 01:08:43.204174
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips


# Generated at 2022-06-17 01:08:48.394836
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    # TODO: mock out the methods that get_default_interfaces calls
    #       and test the return values
    #       (this is not a unit test, it's an integration test)
    ln.get_default_interfaces()


# Generated at 2022-06-17 01:08:58.287479
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    device = 'eth0'
    data = linux_network.get_ethtool_data(device)
    assert data['features']['rx_all'] == 'off'
    assert data['features']['tx_udp_csum_tx'] == 'on'
    assert data['timestamping'] == ['hardware', 'software', 'tx_hardware', 'tx_software']
    assert data['hw_timestamp_filters'] == ['all', 'none', 'multicast', 'unicast', 'p2p']
    assert data['phc_index'] == 0


# Generated at 2022-06-17 01:09:52.690996
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/sbin/ip')
    ln = LinuxNetwork(module)
    assert ln.get_default_interfaces() == ({'v4': {}, 'v6': {}}, {'v4': {}, 'v6': {}})


# Generated at 2022-06-17 01:10:05.208762
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:10:10.739010
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Test for method get_interfaces_info(self, ip_path, default_ipv4, default_ipv6)
    # of class LinuxNetwork
    # FIXME: this is a stub, implement your test here
    raise NotImplementedError()


# Generated at 2022-06-17 01:10:12.411867
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: mock out the module, and then test the method
    pass



# Generated at 2022-06-17 01:10:25.222165
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    device = 'eth0'
    data = ln.get_ethtool_data(device)
    assert data['features']['rx_all'] == 'on'
    assert data['features']['tx_udp_tnl_csum_segmentation'] == 'on'
    assert data['timestamping'] == ['hardware', 'software', 'tx_software', 'rx_software']
    assert data['hw_timestamp_filters'] == ['all', 'none', 'pkt_type_sync', 'pkt_type_delay_req', 'pkt_type_pdelay_req', 'pkt_type_pdelay_resp']
    assert data['phc_index'] == 0


# Generated at 2022-06-17 01:10:29.783625
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    # FIXME: this is not a good test, it's not testing anything
    assert ln.get_ethtool_data('eth0') == {}


# Generated at 2022-06-17 01:10:40.328797
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    default_ipv4, default_ipv6 = network.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)
    assert 'address' in default_ipv4
    assert 'address' in default_ipv6
    assert 'gateway' in default_ipv4
    assert 'gateway' in default_ipv6
    assert 'interface' in default_ipv4
    assert 'interface' in default_ipv6


# Generated at 2022-06-17 01:10:43.332377
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips


# Generated at 2022-06-17 01:10:55.702085
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Test with a real module
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', default=['!all', '!min']),
            filter=dict(type='list', default=[]),
        ),
        supports_check_mode=True,
    )
    # FIXME: this is a hack to get around the fact that the module is not
    #        actually loaded by the test framework
    module.exit_json = lambda **kwargs: kwargs
    module.fail_json = lambda **kwargs: kwargs
    # FIXME: this is a hack to get around the fact that the module is not
    #        actually loaded by the test framework
    module.get_bin_path = lambda *args, **kwargs: '/bin/ip'
    module.run_command

# Generated at 2022-06-17 01:11:00.060035
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.ips


# Generated at 2022-06-17 01:11:45.445537
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # create a fake module
    module = AnsibleModule(argument_spec={})
    # create a fake class
    ln = LinuxNetwork(module)
    # create a fake default ipv4
    default_ipv4 = {'address': '192.168.1.1'}
    # create a fake default ipv6
    default_ipv6 = {'address': 'fe80::1'}
    # create a fake ip_path
    ip_path = '/sbin/ip'
    # create a fake interfaces

# Generated at 2022-06-17 01:11:52.560116
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)
    assert 'address' in default_ipv4
    assert 'address' in default_ipv6


# Generated at 2022-06-17 01:12:02.605362
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
        ),
        supports_check_mode=True,
    )

    # FIXME: mock this out
    # FIXME: mock out the module
    # FIXME: mock out the module.run_command
    # FIXME: mock out the module.get_bin_path
    # FIXME: mock out the module.fail_json
    # FIXME: mock out the module.exit_json
    # FIXME: mock out the module.warn
    # FIXME: mock out the module.deprecate
    # FIXME: mock out the module.get_bin_path
    # FIXME: mock out the module.run_command
    # FIXME: mock out the module.run_command


# Generated at 2022-06-17 01:12:05.229581
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    # FIXME: this is a stub
    assert linux_network.get_ethtool_data('eth0') == {}


# Generated at 2022-06-17 01:12:10.690227
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    network.populate()
    assert network.interfaces
    assert network.default_ipv4
    assert network.default_ipv6
    assert network.ips


# Generated at 2022-06-17 01:12:22.058142
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:12:29.074269
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)

# Generated at 2022-06-17 01:12:36.456893
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', default=['!all', '!min']),
        ),
        supports_check_mode=True,
    )

    # FIXME: this is a bit of a hack to get the module_utils path
    # for the imports below.
    module_utils_path = os.path.join(module._ansible_sys_path[0], 'module_utils')
    sys.path.append(module_utils_path)

    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.network.common.utils import load_provider
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.network.common.utils import dict_

# Generated at 2022-06-17 01:12:44.543248
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Test with empty routing table
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    ln = LinuxNetwork(module)
    assert ln.get_default_interfaces() == ({}, {})

    # Test with IPv4 routing table
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'default via 192.0.2.1 dev eth0', ''))
    ln = LinuxNetwork(module)
    assert ln.get_default_interfaces() == ({'v4': {'interface': 'eth0', 'gateway': '192.0.2.1'}}, {})

    # Test with IPv6 routing table

# Generated at 2022-06-17 01:12:54.551658
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    ethtool_path = module.get_bin_path("ethtool")
    if ethtool_path:
        device = 'lo'
        data = linux_network.get_ethtool_data(device)
        assert 'features' in data
        assert 'timestamping' in data
        assert 'hw_timestamp_filters' in data
        assert 'phc_index' in data
        assert data['phc_index'] == 0
    else:
        assert True



# Generated at 2022-06-17 01:13:31.761166
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    assert linux_network.get_ethtool_data('eth0') == {}


# Generated at 2022-06-17 01:13:34.118629
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: this is a stub
    pass


# Generated at 2022-06-17 01:13:45.689964
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            gather_network_resources=dict(default=['all'], type='list'),
        ),
        supports_check_mode=True,
    )
    ln = LinuxNetwork(module)
    ln.populate()