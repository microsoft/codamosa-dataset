

# Generated at 2022-06-17 01:04:09.283273
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.get_default_interfaces()


# Generated at 2022-06-17 01:04:18.809857
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json

    # FIXME: mock module.run_command

    # FIXME: mock module.get_bin_path

    # FIXME: mock get_file_content

    # FIXME: mock glob.glob

    # FIXME: mock os.path.isdir

    # FIXME: mock os.path.exists

    # FIXME: mock os.path.basename

    # FIXME: mock os.path.realpath

    # FIXME: mock os.readlink

    # FIXME: mock socket.inet_aton

    # FIXME: mock socket.inet_ntoa

    # FIXME: mock struct.pack

    # FIXME: mock struct.unpack

    # FIXME: mock

# Generated at 2022-06-17 01:04:20.162662
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: write unit test
    pass


# Generated at 2022-06-17 01:04:29.909350
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            filter=dict(default=None, type='list'),
        ),
        supports_check_mode=True,
    )

    # FIXME: this is a bit of a hack, but it's the best way to get a
    #        LinuxNetwork object without having to mock out a bunch of
    #        other stuff
    obj = LinuxNetwork()
    obj.module = module
    obj.populate()

    # FIXME: this is a bit of a hack, but it's the best way to get a
    #        LinuxNetwork object without having to mock out a bunch of
    #        other stuff
    obj = LinuxNetwork()
    obj.module = module
    obj.populate()

    # FIX

# Generated at 2022-06-17 01:04:36.398113
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    device = 'eth0'
    data = linux_network.get_ethtool_data(device)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data



# Generated at 2022-06-17 01:04:41.004047
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    interfaces, ips = linux_network.get_interfaces_info('/sbin/ip', {}, {})
    assert isinstance(interfaces, dict)
    assert isinstance(ips, dict)
    assert 'all_ipv4_addresses' in ips
    assert 'all_ipv6_addresses' in ips
    assert isinstance(ips['all_ipv4_addresses'], list)
    assert isinstance(ips['all_ipv6_addresses'], list)
    for device in interfaces:
        assert isinstance(interfaces[device], dict)
        assert 'device' in interfaces[device]
        assert 'type' in interfaces[device]
        assert 'mtu' in interfaces[device]


# Generated at 2022-06-17 01:04:41.923203
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # TODO: implement
    pass


# Generated at 2022-06-17 01:04:49.242777
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.gateways
    assert ln.ips


# Generated at 2022-06-17 01:05:01.735856
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address'] == '192.168.1.1'
    assert ln.default_ipv6['address'] == 'fe80::1'
    assert ln.interfaces['eth0']['ipv4']['address'] == '192.168.1.1'
    assert ln.interfaces['eth0']['ipv6'][0]['address'] == 'fe80::1'
    assert ln.interfaces['eth0']['ipv6'][1]['address'] == 'fe80::2'

# Generated at 2022-06-17 01:05:13.299765
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

# Generated at 2022-06-17 01:05:42.586826
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)
    assert 'address' in default_ipv4
    assert 'address' in default_ipv6
    assert 'default_interface' in default_ipv4
    assert 'default_interface' in default_ipv6


# Generated at 2022-06-17 01:05:45.308326
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # TODO: mock out the module and run_command
    # TODO: mock out the ethtool_path
    # TODO: mock out the rc, stdout, stderr
    # TODO: mock out the features
    # TODO: mock out the timestamping
    # TODO: mock out the hw_timestamp_filters
    # TODO: mock out the phc_index
    pass


# Generated at 2022-06-17 01:05:49.107690
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda x: x
    linux_network = LinuxNetwork(module)
    default_ipv4, default_ipv6 = linux_network.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)
    assert 'interface' in default_ipv4
    assert 'interface' in default_ipv6
    assert 'address' in default_ipv4
    assert 'address' in default_ipv6


# Generated at 2022-06-17 01:05:54.366296
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.default_interface
    assert ln.default_gateway
    assert ln.default_gateway_v6
    assert ln.ips


# Generated at 2022-06-17 01:05:55.554195
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-17 01:06:02.464201
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:06:16.122331
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    interfaces, ips = linux_network.get_interfaces_info('/sbin/ip', {}, {})
    assert 'lo' in interfaces
    assert 'eth0' in interfaces
    assert 'eth1' in interfaces
    assert 'eth2' in interfaces
    assert 'eth3' in interfaces
    assert 'eth4' in interfaces
    assert 'eth5' in interfaces
    assert 'eth6' in interfaces
    assert 'eth7' in interfaces
    assert 'eth8' in interfaces
    assert 'eth9' in interfaces
    assert 'eth10' in interfaces
    assert 'eth11' in interfaces
    assert 'eth12' in interfaces
    assert 'eth13' in interfaces
    assert 'eth14' in interfaces

# Generated at 2022-06-17 01:06:29.382330
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    device = 'eth0'

# Generated at 2022-06-17 01:06:38.847455
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    device = 'eth0'
    data = ln.get_ethtool_data(device)
    assert data['features']['rx_all'] == 'off'
    assert data['features']['tx_udp_csum_tx'] == 'on'
    assert data['timestamping'] == ['hardware', 'software', 'tx_software', 'rx_software']
    assert data['hw_timestamp_filters'] == ['all', 'none', 'some']
    assert data['phc_index'] == 0


# Generated at 2022-06-17 01:06:41.182854
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # FIXME: this is a stub
    # assert False, "No test for LinuxNetwork.populate"
    pass


# Generated at 2022-06-17 01:07:26.202511
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    device = 'eth0'
    data = linux_network.get_ethtool_data(device)
    assert data['features']['rx_all'] == 'on'
    assert data['features']['tx_udp_tnl_csum_segmentation'] == 'on'
    assert data['timestamping'] == ['hardware', 'software', 'tx_software']
    assert data['hw_timestamp_filters'] == ['none', 'all']
    assert data['phc_index'] == 0


# Generated at 2022-06-17 01:07:37.742866
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Test with a device that has ethtool data
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    device = 'lo'

# Generated at 2022-06-17 01:07:47.638370
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/sbin/ip')

    # Mock the glob.glob function
    glob.glob = MagicMock(return_value=['/sys/class/net/eth0', '/sys/class/net/eth1'])

    # Mock the os.path.exists function
    os.path.exists = MagicMock(return_value=True)

    # Mock the os.path.isdir function
    os.path.isdir = MagicMock(return_value=True)

    # Mock the os.path.basename function
    os.path.basename = MagicMock(return_value='eth0')

# Generated at 2022-06-17 01:07:56.647128
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = MagicMock(return_value='/bin/ip')
    module.run_command = MagicMock(return_value=(0, '', ''))
    ln = LinuxNetwork(module)
    ln.get_default_interfaces()
    module.run_command.assert_has_calls([
        call(['/bin/ip', 'route', 'get', '8.8.8.8'], errors='surrogate_then_replace'),
        call(['/bin/ip', '-6', 'route', 'get', '2001:4860:4860::8888'], errors='surrogate_then_replace'),
    ])


# Generated at 2022-06-17 01:08:04.446699
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    # FIXME: this is a hack to get around the fact that we can't pass
    #        a class object to the mock.patch decorator
    #        https://github.com/ansible/ansible/issues/10762
    #        https://github.com/ansible/ansible/issues/10763
    #        https://github.com/ansible/ansible/issues/10764
    #        https://github.com/ansible/ansible/issues/10765
    #        https://github.com/ansible/ansible/issues/10766
    #        https://github.com/ansible/ansible

# Generated at 2022-06-17 01:08:12.750577
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address'] == '192.168.1.1'
    assert ln.default_ipv4['netmask'] == '255.255.255.0'
    assert ln.default_ipv4['network'] == '192.168.1.0'
    assert ln.default_ipv4['broadcast'] == '192.168.1.255'
    assert ln.default_ipv6['address'] == 'fe80::1'
    assert ln.default_ipv6['prefix'] == '64'
    assert ln.default_ipv6['scope'] == 'link'

# Generated at 2022-06-17 01:08:23.491351
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

# Generated at 2022-06-17 01:08:35.884070
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: x
    module.run_command = lambda x, **kwargs: (0, '', '')
    network = LinuxNetwork(module)
    interfaces, ips = network.get_interfaces_info('/sbin/ip', {}, {})
    assert interfaces['lo']['ipv4']['address'] == '127.0.0.1'
    assert interfaces['lo']['ipv4']['netmask'] == '255.0.0.0'
    assert interfaces['lo']['ipv4']['network'] == '127.0.0.0'
    assert interfaces['lo']['ipv4']['broadcast'] == '0.0.0.0'

# Generated at 2022-06-17 01:08:47.676625
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = MagicMock(return_value='/sbin/ip')

# Generated at 2022-06-17 01:08:58.575597
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/usr/bin/ethtool')
    network = LinuxNetwork(module)
    assert network.get_ethtool_data('eth0') == {'features': {}, 'timestamping': [], 'hw_timestamp_filters': []}
    module.run_command.assert_called_with(['/usr/bin/ethtool', '-k', 'eth0'], errors='surrogate_then_replace')
    module.run_command.assert_called_with(['/usr/bin/ethtool', '-T', 'eth0'], errors='surrogate_then_replace')


# Generated at 2022-06-17 01:09:48.570421
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)

# Generated at 2022-06-17 01:09:54.890245
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: mock out the module
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='')
    module.params = {}
    ln = LinuxNetwork(module)
    # TODO: mock out the glob.glob and os.path.isdir
    # TODO: mock out the get_file_content
    # TODO: mock out the os.readlink
    # TODO: mock out the os.path.exists
    # TODO: mock out the os.path.basename
    # TODO: mock out the os.path.realpath
    # TODO: mock out the socket.inet_aton
    # TODO: mock out the socket.inet

# Generated at 2022-06-17 01:10:01.316008
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Setup
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = MagicMock(return_value=(0, '', ''))
    linux_network = LinuxNetwork(module)
    # Exercise
    result = linux_network.get_ethtool_data('eth0')
    # Verify
    assert result == {}
    # Cleanup - none necessary



# Generated at 2022-06-17 01:10:13.860486
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address'] == '192.168.1.1'
    assert default_ipv4['netmask'] == '255.255.255.0'
    assert default_ipv4['network'] == '192.168.1.0'
    assert default_ipv4['broadcast'] == '192.168.1.255'
    assert default_ipv6['address'] == '2001:db8:1::1'
    assert default_ipv6['prefix'] == '64'
    assert default_ipv6['scope'] == 'global'


# Generated at 2022-06-17 01:10:26.327474
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:10:36.269233
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    # TODO: mock out the ip command
    # TODO: mock out the ipv6 command
    # TODO: mock out the route command
    # TODO: mock out the route6 command
    # TODO: mock out the get_bin_path method
    # TODO: mock out the run_command method
    # TODO: mock out the get_file_content method
    # TODO: mock out the glob.glob method
    # TODO: mock out the os.path.isdir method
    # TODO: mock out the os.path.exists method
    # TODO: mock out the os.path.basename method
    # TODO: mock out the os.path.realpath method
    # TODO: mock out the

# Generated at 2022-06-17 01:10:45.573538
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    # TODO: mock out the get_interfaces_info method
    # TODO: mock out the get_default_route method
    # TODO: mock out the get_default_route6 method
    # TODO: mock out the get_interfaces_info method
    # TODO: mock out the get_default_route method
    # TODO: mock out the get_default_route6 method
    # TODO: mock out the get_interfaces_info method
    # TODO: mock out the get_default_route method
    # TODO: mock out the get_default_route6 method
    # TODO: mock out the get_interfaces_info method
    # TODO: mock out the get_default_route method
    # TODO

# Generated at 2022-06-17 01:10:49.944636
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data("eth0") == {}


# Generated at 2022-06-17 01:11:00.951159
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

    # TODO: mock out the glob.glob and os.path.exists calls
    # TODO: mock out the get_file_content calls
    # TODO: mock out the get_bin_path calls
    # TODO: mock out the run_command calls

    # TODO: test with a variety of interfaces
    # TODO: test with a variety of ipv4 and ipv6 addresses
    # TODO: test with a variety of ipv4 and ipv6 default addresses
    # TODO: test with a variety of ipv4 and ipv6 secondary addresses
    # TODO: test with a variety of ipv4 and ipv6 addresses on different interfaces
    # TODO: test with a variety of ipv4 and ipv6 addresses on

# Generated at 2022-06-17 01:11:06.725604
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = LinuxNetworkCollector(module)
    assert collector.platform == 'Linux'
    assert collector.required_facts == set(['distribution', 'platform'])
    assert isinstance(collector.get_facts(), LinuxNetwork)



# Generated at 2022-06-17 01:11:54.919711
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-17 01:12:04.412331
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data('lo') == {}

# Generated at 2022-06-17 01:12:11.836596
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    ln = LinuxNetwork(module)
    ln.get_default_interfaces()
    module.run_command.assert_called_once_with(['ip', 'route', 'show', '0/0'], errors='surrogate_then_replace')


# Generated at 2022-06-17 01:12:23.174784
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

# Generated at 2022-06-17 01:12:33.173701
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

# Generated at 2022-06-17 01:12:42.795963
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert isinstance(ln.interfaces, dict)
    assert isinstance(ln.default_ipv4, dict)
    assert isinstance(ln.default_ipv6, dict)
    assert isinstance(ln.routes, dict)
    assert isinstance(ln.ips, dict)
    assert isinstance(ln.gateways, dict)
    assert isinstance(ln.gateways['default'], dict)
    assert isinstance(ln.gateways['default']['ipv4'], dict)
    assert isinstance(ln.gateways['default']['ipv6'], dict)
    assert isinstance(ln.gateways['ipv4'], dict)

# Generated at 2022-06-17 01:12:49.531371
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.gateway_ipv4
    assert ln.gateway_ipv6
    assert ln.ips


# Generated at 2022-06-17 01:13:01.114832
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # TODO: mock the module
    module = AnsibleModule(argument_spec={})
    # TODO: mock the module.run_command
    module.run_command = lambda *args, **kwargs: (0, "", "")
    # TODO: mock the module.get_bin_path
    module.get_bin_path = lambda *args, **kwargs: "/bin/ethtool"
    # TODO: mock the module.fail_json
    module.fail_json = lambda *args, **kwargs: None
    # TODO: mock the module.exit_json
    module.exit_json = lambda *args, **kwargs: None
    # TODO: mock the module.warn
    module.warn = lambda *args, **kwargs: None
    # TODO: mock the module.deprecate

# Generated at 2022-06-17 01:13:14.739130
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address'] == '192.168.1.2'
    assert ln.default_ipv4['netmask'] == '255.255.255.0'
    assert ln.default_ipv4['network'] == '192.168.1.0'
    assert ln.default_ipv4['broadcast'] == '192.168.1.255'
    assert ln.default_ipv4['macaddress'] == '00:0c:29:8c:11:b1'
    assert ln.default_ipv4['mtu'] == 1500
    assert ln.default_ipv4['type'] == 'ether'
    assert l

# Generated at 2022-06-17 01:13:18.472754
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Test for method get_interfaces_info(ip_path, default_ipv4, default_ipv6)
    # of class LinuxNetwork
    # FIXME: this is a stub, implement your test here
    raise NotImplementedError()
