

# Generated at 2022-06-17 01:04:15.291505
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/usr/bin/ethtool')
    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data('eth0') == {}


# Generated at 2022-06-17 01:04:20.045019
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces is not None
    assert ln.default_ipv4 is not None
    assert ln.default_ipv6 is not None
    assert ln.ips is not None


# Generated at 2022-06-17 01:04:24.714417
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address'] == '192.168.1.1'
    assert default_ipv6['address'] == 'fe80::1'


# Generated at 2022-06-17 01:04:32.589090
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Test with a valid device
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = MagicMock(return_value='/usr/sbin/ethtool')

# Generated at 2022-06-17 01:04:34.300713
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: write unit test
    pass


# Generated at 2022-06-17 01:04:40.163547
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
        ),
        supports_check_mode=True,
    )
    nm = LinuxNetwork(module)
    nm.populate()
    result = nm.data
    assert result['default_ipv4']['address'] == '192.168.1.1'
    assert result['default_ipv4']['broadcast'] == '192.168.1.255'
    assert result['default_ipv4']['netmask'] == '255.255.255.0'
    assert result['default_ipv4']['network'] == '192.168.1.0'

# Generated at 2022-06-17 01:04:46.889001
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address']
    assert ln.default_ipv6['address']
    assert ln.interfaces
    assert ln.ips


# Generated at 2022-06-17 01:04:55.865693
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {'gather_subset': ['!all', 'min']}
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.facts['default_ipv4']['address'] == '127.0.0.1'
    assert ln.facts['default_ipv4']['broadcast'] == '127.255.255.255'
    assert ln.facts['default_ipv4']['netmask'] == '255.0.0.0'
    assert ln.facts['default_ipv4']['network'] == '127.0.0.0'
    assert ln.facts['default_ipv4']['interface'] == 'lo'

# Generated at 2022-06-17 01:05:00.379142
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4 is not None
    assert ln.default_ipv6 is not None
    assert ln.interfaces is not None
    assert ln.ips is not None


# Generated at 2022-06-17 01:05:03.454446
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    default_ipv4, default_ipv6 = network.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)


# Generated at 2022-06-17 01:05:27.892147
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.params['ansible_facts'] = {}
    module.params['ansible_facts']['ansible_default_ipv4'] = {}
    module.params['ansible_facts']['ansible_default_ipv6'] = {}
    module.params['ansible_facts']['ansible_default_ipv4']['address'] = '192.168.1.1'
    module.params['ansible_facts']['ansible_default_ipv6']['address'] = '2001:db8::1'
    module.params['ansible_facts']['ansible_default_ipv4']['interface'] = 'eth0'

# Generated at 2022-06-17 01:05:32.995036
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces is not None
    assert ln.default_ipv4 is not None
    assert ln.default_ipv6 is not None
    assert ln.ips is not None


# Generated at 2022-06-17 01:05:39.842584
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address'] == '192.168.1.1'
    assert ln.default_ipv4['netmask'] == '255.255.255.0'
    assert ln.default_ipv4['network'] == '192.168.1.0'
    assert ln.default_ipv4['broadcast'] == '192.168.1.255'
    assert ln.default_ipv4['macaddress'] == '00:0c:29:8c:11:b1'
    assert ln.default_ipv4['mtu'] == 1500
    assert ln.default_ipv4['type'] == 'ether'
    assert l

# Generated at 2022-06-17 01:05:51.138640
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Test with a single interface
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.read_file = MagicMock(return_value='00:00:00:00:00:00')
    module.get_file_content = MagicMock(return_value='1')
    module.os_path_exists = MagicMock(return_value=True)
    module.os_path_isdir = MagicMock(return_value=True)
    module.os_path_realpath = MagicMock(return_value='/sys/class/net/eth0/device/driver/module')
    module.os_readlink = MagicMock

# Generated at 2022-06-17 01:05:54.505647
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4 is not None
    assert ln.default_ipv6 is not None
    assert ln.interfaces is not None
    assert ln.ips is not None


# Generated at 2022-06-17 01:05:59.551145
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    device = 'eth0'
    data = ln.get_ethtool_data(device)
    assert data['features']['rx_all'] == 'on'
    assert data['timestamping'] == ['hardware', 'software', 'tx_hardware', 'tx_software']
    assert data['hw_timestamp_filters'] == ['all', 'none', 'multicast', 'unicast', 'p2p']
    assert data['phc_index'] == 0


# Generated at 2022-06-17 01:06:13.192852
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda x: x
    linux_network = LinuxNetwork(module)
    interfaces, ips = linux_network.get_interfaces_info('/sbin/ip', {}, {})
    assert isinstance(interfaces, dict)
    assert isinstance(ips, dict)
    for interface in interfaces.values():
        assert isinstance(interface, dict)
        assert 'device' in interface
        assert 'type' in interface
        assert 'mtu' in interface
        assert 'active' in interface
        assert 'macaddress' in interface
        assert 'ipv4' in interface
        assert 'ipv6' in interface
        assert 'features' in interface
        assert 'timestamping' in interface
        assert 'hw_timestamp_filters' in interface
       

# Generated at 2022-06-17 01:06:16.637314
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address']
    assert ln.default_ipv6['address']
    assert ln.interfaces
    assert ln.ips
    assert ln.gateways


# Generated at 2022-06-17 01:06:19.747086
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: implement
    pass


# Generated at 2022-06-17 01:06:24.972387
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces is not None
    assert ln.ips is not None
    assert ln.default_ipv4 is not None
    assert ln.default_ipv6 is not None


# Generated at 2022-06-17 01:06:46.342810
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    ln = LinuxNetwork(module)
    ln.get_interfaces_info(None, None, None)
    assert module.run_command.call_count == 2
    assert module.get_bin_path.call_count == 2



# Generated at 2022-06-17 01:06:50.573792
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    device = 'eth0'
    data = ln.get_ethtool_data(device)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data


# Generated at 2022-06-17 01:07:02.060138
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    linux_network = LinuxNetwork(module)
    assert linux_network.get_ethtool_data('eth0') == {}

# Generated at 2022-06-17 01:07:11.812183
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    default_ipv4, default_ipv6 = network.get_default_interfaces()
    assert default_ipv4['address'] == '192.168.1.1'
    assert default_ipv4['broadcast'] == '192.168.1.255'
    assert default_ipv4['netmask'] == '255.255.255.0'
    assert default_ipv4['network'] == '192.168.1.0'
    assert default_ipv4['macaddress'] == '00:00:00:00:00:00'
    assert default_ipv4['mtu'] == 1500
    assert default_ipv4['type'] == 'unknown'

# Generated at 2022-06-17 01:07:24.409226
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    network = LinuxNetwork(module)
    device = 'eth0'
    data = network.get_ethtool_data(device)
    assert data == {}
    module.run_command.assert_called_once_with(['ethtool', '-k', device], errors='surrogate_then_replace')
    module.run_command.reset_mock()


# Generated at 2022-06-17 01:07:29.383665
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    device = 'eth0'
    data = linux_network.get_ethtool_data(device)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data


# Generated at 2022-06-17 01:07:30.510481
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # TODO: implement
    pass


# Generated at 2022-06-17 01:07:38.052883
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address']
    assert ln.default_ipv6['address']
    assert ln.interfaces
    assert ln.ips


# Generated at 2022-06-17 01:07:47.637317
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address'] == '192.168.1.1'
    assert default_ipv4['netmask'] == '255.255.255.0'
    assert default_ipv4['network'] == '192.168.1.0'
    assert default_ipv4['broadcast'] == '192.168.1.255'
    assert default_ipv6['address'] == '2001:db8::1'
    assert default_ipv6['prefix'] == '64'
    assert default_ipv6['scope'] == 'global'


# Generated at 2022-06-17 01:07:53.467453
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    device = 'eth0'
    data = linux_network.get_ethtool_data(device)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data


# Generated at 2022-06-17 01:08:10.725217
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: implement this test
    pass


# Generated at 2022-06-17 01:08:12.989242
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-17 01:08:22.758156
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Test with no default interface
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    default_ipv4, default_ipv6 = network.get_default_interfaces()
    assert default_ipv4 == {}
    assert default_ipv6 == {}

    # Test with default interface
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    network.default_interface = 'eth0'
    default_ipv4, default_ipv6 = network.get_default_interfaces()
    assert default_ipv4 == {'interface': 'eth0'}
    assert default_ipv6 == {'interface': 'eth0'}


# Generated at 2022-06-17 01:08:35.191315
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    linux_network = LinuxNetwork(module)
    linux_network.module.run_command = MagicMock(return_value=(0, '', ''))
    linux_network.module.get_bin_path = MagicMock(return_value='/usr/sbin/ethtool')
    assert linux_network.get_ethtool_data('eth0') == {}

# Generated at 2022-06-17 01:08:41.883670
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, "", ""))
    module.get_bin_path = MagicMock(return_value="/bin/ip")
    ln = LinuxNetwork(module)
    ln.get_default_interfaces()
    module.run_command.assert_called_with(['/bin/ip', 'route', 'get', '8.8.8.8'])


# Generated at 2022-06-17 01:08:50.425212
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
        ),
        supports_check_mode=True,
    )
    nm = LinuxNetwork(module)
    nm.populate()
    result = nm.data
    assert result['default_ipv4']['address'] == '192.168.1.1'
    assert result['default_ipv4']['netmask'] == '255.255.255.0'
    assert result['default_ipv4']['network'] == '192.168.1.0'
    assert result['default_ipv4']['broadcast'] == '192.168.1.255'

# Generated at 2022-06-17 01:09:00.380939
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address'] == '192.168.1.1'
    assert default_ipv4['netmask'] == '255.255.255.0'
    assert default_ipv4['network'] == '192.168.1.0'
    assert default_ipv4['broadcast'] == '192.168.1.255'
    assert default_ipv6['address'] == 'fe80::a00:27ff:fe6c:c8f0'
    assert default_ipv6['prefix'] == '64'
    assert default_ipv6['scope'] == 'link'


# Generated at 2022-06-17 01:09:13.621836
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            gather_network_resources=dict(default=['all'], type='list'),
        ),
        supports_check_mode=True,
    )
    ln = LinuxNetwork(module)
    ln.populate()
    result = ln.get_facts()

# Generated at 2022-06-17 01:09:23.778797
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Test with a single interface
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'default via 192.168.1.1 dev eth0', ''))
    module.get_bin_path = MagicMock(return_value='/sbin/ip')
    linux_network = LinuxNetwork(module)
    default_ipv4, default_ipv6 = linux_network.get_default_interfaces()
    assert default_ipv4 == {'interface': 'eth0', 'gateway': '192.168.1.1'}
    assert default_ipv6 == {'interface': 'eth0'}

    # Test with multiple interfaces

# Generated at 2022-06-17 01:09:29.048402
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    device = 'eth0'
    data = linux_network.get_ethtool_data(device)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data



# Generated at 2022-06-17 01:09:55.333424
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.params['gather_subset'] = ['!all']
    module.params['gather_network_resources'] = ['all']
    module.params['filter'] = ['*']
    module.params['config'] = ['/etc/ansible/facts.d']
    module.params['ansible_facts'] = {}
    module.params['ansible_facts']['ansible_net_gather_subset'] = ['!all']
    module.params['ansible_facts']['ansible_net_gather_network_resources'] = ['all']
    module.params['ansible_facts']['ansible_net_filter'] = ['*']

# Generated at 2022-06-17 01:10:01.372934
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address'] == '192.168.1.1'
    assert default_ipv6['address'] == 'fe80::1'


# Generated at 2022-06-17 01:10:07.200290
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.gateway_ipv4
    assert ln.gateway_ipv6
    assert ln.ips


# Generated at 2022-06-17 01:10:16.675513
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/sbin/ip')
    network = LinuxNetwork(module)

# Generated at 2022-06-17 01:10:25.559146
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: mock the module and its run_command method
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    # TODO: mock the output of the ip command
    default_ipv4 = {}
    default_ipv6 = {}
    interfaces, ips = ln.get_interfaces_info('/sbin/ip', default_ipv4, default_ipv6)
    assert interfaces
    assert ips


# Generated at 2022-06-17 01:10:35.834887
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

# Generated at 2022-06-17 01:10:45.390697
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/sbin/ip')
    ln = LinuxNetwork(module)
    ln.get_interfaces_info = MagicMock(return_value=(None, None))
    ln.get_default_interfaces()
    assert module.run_command.call_count == 2
    assert module.run_command.call_args_list[0][0][0] == ['/sbin/ip', 'route', 'get', '8.8.8.8']

# Generated at 2022-06-17 01:10:52.037688
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4 is not None
    assert ln.default_ipv6 is not None
    assert ln.interfaces is not None
    assert ln.ips is not None


# Generated at 2022-06-17 01:10:55.826096
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # TODO: implement
    pass


# Generated at 2022-06-17 01:11:00.146950
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec=dict())
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.ips


# Generated at 2022-06-17 01:11:26.181219
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address'] == '192.168.1.1'
    assert ln.default_ipv4['netmask'] == '255.255.255.0'
    assert ln.default_ipv4['network'] == '192.168.1.0'
    assert ln.default_ipv4['broadcast'] == '192.168.1.255'
    assert ln.default_ipv4['macaddress'] == '00:00:00:00:00:00'
    assert ln.default_ipv4['mtu'] == 1500
    assert ln.default_ipv4['type'] == 'unknown'
    assert ln.default

# Generated at 2022-06-17 01:11:27.541726
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-17 01:11:34.181032
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.ip_path
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips


# Generated at 2022-06-17 01:11:35.310635
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: write unit test
    pass



# Generated at 2022-06-17 01:11:47.474581
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    default_ipv4, default_ipv6 = linux_network.get_default_interfaces()
    assert default_ipv4['address'] == '192.168.1.1'
    assert default_ipv4['broadcast'] == '192.168.1.255'
    assert default_ipv4['netmask'] == '255.255.255.0'
    assert default_ipv4['network'] == '192.168.1.0'
    assert default_ipv6['address'] == 'fe80::a00:27ff:fea0:c9f'
    assert default_ipv6['prefix'] == '64'
    assert default_ipv6['scope'] == 'link'

# Unit test

# Generated at 2022-06-17 01:11:56.309667
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/sbin/ip')
    ln = LinuxNetwork(module)
    ln.get_default_interfaces()
    assert module.run_command.call_count == 2
    assert module.run_command.call_args_list[0][0][0] == ['/sbin/ip', 'route', 'get', '8.8.8.8']
    assert module.run_command.call_args_list[1][0][0] == ['/sbin/ip', 'route', 'get', '2001:4860:4860::8888']


# Generated at 2022-06-17 01:12:05.369089
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address'] == '192.168.1.1'
    assert ln.default_ipv4['netmask'] == '255.255.255.0'
    assert ln.default_ipv4['network'] == '192.168.1.0'
    assert ln.default_ipv4['broadcast'] == '192.168.1.255'
    assert ln.default_ipv4['macaddress'] == '00:11:22:33:44:55'
    assert ln.default_ipv6['address'] == '2001:db8::1'
    assert ln.default_ipv6['prefix'] == '64'


# Generated at 2022-06-17 01:12:06.934982
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    assert linux_network.get_ethtool_data('eth0') == {}


# Generated at 2022-06-17 01:12:16.369493
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            return '/bin/' + name


# Generated at 2022-06-17 01:12:25.148175
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'gather_subset': [],
        'gather_network_resources': 'yes',
    }
    module.exit_json = lambda x: x
    network = LinuxNetwork(module)
    network.populate()
    assert network.interfaces
    assert network.default_ipv4
    assert network.default_ipv6
    assert network.all_ipv4_addresses
    assert network.all_ipv6_addresses
    assert network.gateway_ipv4
    assert network.gateway_ipv6


# Generated at 2022-06-17 01:13:03.019320
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    device = 'eth0'
    data = linux_network.get_ethtool_data(device)
    assert data['features']['tx_checksumming'] == 'on'
    assert data['features']['rx_checksumming'] == 'on'
    assert data['features']['scatter_gather'] == 'on'
    assert data['features']['tcp_segmentation_offload'] == 'on'
    assert data['features']['udp_fragmentation_offload'] == 'off'
    assert data['features']['generic_segmentation_offload'] == 'on'
    assert data['features']['generic_receive_offload'] == 'on'

# Generated at 2022-06-17 01:13:15.640021
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:13:23.424601
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            gather_network_resources=dict(default=['all'], type='list'),
        ),
        supports_check_mode=True,
    )
    ln = LinuxNetwork(module)
    ln.populate()
    result = ln.data
    assert result['default_ipv4']['address'] == '192.168.1.1'
    assert result['default_ipv4']['broadcast'] == '192.168.1.255'
    assert result['default_ipv4']['netmask'] == '255.255.255.0'
    assert result['default_ipv4']['network'] == '192.168.1.0'

# Generated at 2022-06-17 01:13:28.932361
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ip_path = module.get_bin_path("ip")
    default_ipv4 = {}
    default_ipv6 = {}
    interfaces, ips = ln.get_interfaces_info(ip_path, default_ipv4, default_ipv6)
    assert interfaces
    assert ips


# Generated at 2022-06-17 01:13:39.707081
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data('eth0') == {}
    module.run_command.assert_called_with(['ethtool', '-k', 'eth0'])

# Generated at 2022-06-17 01:13:47.413274
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'gather_subset': ['all'],
        'gather_network_resources': ['all'],
    }
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.facts['default_ipv4']['address'] == '192.168.1.1'
    assert ln.facts['default_ipv4']['netmask'] == '255.255.255.0'
    assert ln.facts['default_ipv4']['network'] == '192.168.1.0'
    assert ln.facts['default_ipv4']['broadcast'] == '192.168.1.255'