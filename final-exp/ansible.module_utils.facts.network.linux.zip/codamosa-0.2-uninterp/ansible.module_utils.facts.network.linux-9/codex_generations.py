

# Generated at 2022-06-17 01:04:10.867729
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)


# Generated at 2022-06-17 01:04:12.193366
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-17 01:04:19.199689
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    default_ipv4 = {}
    default_ipv6 = {}
    interfaces, ips = network.get_interfaces_info("/sbin/ip", default_ipv4, default_ipv6)
    assert len(interfaces) > 0
    assert len(ips['all_ipv4_addresses']) > 0
    assert len(ips['all_ipv6_addresses']) > 0


# Generated at 2022-06-17 01:04:23.691916
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    default_ipv4, default_ipv6 = network.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)


# Generated at 2022-06-17 01:04:31.956185
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    interfaces, ips = ln.get_interfaces_info('/sbin/ip', {}, {})
    assert isinstance(interfaces, dict)
    assert isinstance(ips, dict)
    assert 'all_ipv4_addresses' in ips
    assert 'all_ipv6_addresses' in ips
    assert isinstance(ips['all_ipv4_addresses'], list)
    assert isinstance(ips['all_ipv6_addresses'], list)
    for i in interfaces:
        assert isinstance(interfaces[i], dict)
        assert 'device' in interfaces[i]
        assert 'type' in interfaces[i]
        assert 'mtu' in interfaces[i]

# Generated at 2022-06-17 01:04:43.203399
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    device = 'eth0'
    data = ln.get_ethtool_data(device)
    assert data['features']['tx_checksumming'] == 'on'
    assert data['features']['rx_checksumming'] == 'on'
    assert data['features']['scatter_gather'] == 'on'
    assert data['features']['tcp_segmentation_offload'] == 'on'
    assert data['features']['udp_fragmentation_offload'] == 'on'
    assert data['features']['generic_segmentation_offload'] == 'on'
    assert data['features']['generic_receive_offload'] == 'on'

# Generated at 2022-06-17 01:04:47.828469
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    assert ln.get_default_interfaces() == (None, None)


# Generated at 2022-06-17 01:04:57.840211
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-17 01:05:07.117409
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    # Test with a device that does not exist
    data = linux_network.get_ethtool_data("eth0")
    assert data == {}
    # Test with a device that does exist
    data = linux_network.get_ethtool_data("lo")
    assert data == {}


# Generated at 2022-06-17 01:05:16.987427
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/sbin/ip')
    module.get_file_content = MagicMock(return_value='')
    ln = LinuxNetwork(module)
    ln.get_interfaces_info('/sbin/ip', {}, {})
    assert module.run_command.call_count == 2
    assert module.get_bin_path.call_count == 2
    assert module.get_file_content.call_count == 2


# Generated at 2022-06-17 01:05:53.382919
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips


# Generated at 2022-06-17 01:05:54.990375
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-17 01:06:01.650152
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address'] == '192.168.1.1'
    assert ln.default_ipv4['netmask'] == '255.255.255.0'
    assert ln.default_ipv4['network'] == '192.168.1.0'
    assert ln.default_ipv4['broadcast'] == '192.168.1.255'
    assert ln.default_ipv4['macaddress'] == '00:0c:29:8c:11:b1'
    assert ln.default_ipv4['mtu'] == 1500
    assert ln.default_ipv4['type'] == 'ether'
    assert l

# Generated at 2022-06-17 01:06:07.395627
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.routes_ipv4
    assert ln.routes_ipv6
    assert ln.ips


# Generated at 2022-06-17 01:06:14.407049
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address'] == '192.168.1.1'
    assert default_ipv6['address'] == 'fe80::1'


# Generated at 2022-06-17 01:06:20.482222
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address'] == '192.168.1.1'
    assert ln.default_ipv4['netmask'] == '255.255.255.0'
    assert ln.default_ipv4['network'] == '192.168.1.0'
    assert ln.default_ipv4['broadcast'] == '192.168.1.255'
    assert ln.default_ipv4['macaddress'] == '00:0c:29:8c:11:b1'
    assert ln.default_ipv4['mtu'] == 1500
    assert ln.default_ipv4['type'] == 'ether'
    assert l

# Generated at 2022-06-17 01:06:30.359420
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'gather_subset': ['!all', 'min'],
        'gather_network_resources': 'yes',
    }
    network = LinuxNetwork(module)
    network.populate()
    assert network.interfaces is not None
    assert network.default_ipv4 is not None
    assert network.default_ipv6 is not None
    assert network.all_ipv4_addresses is not None
    assert network.all_ipv6_addresses is not None
    assert network.gateway_ipv4 is not None
    assert network.gateway_ipv6 is not None


# Generated at 2022-06-17 01:06:33.444862
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-17 01:06:38.489673
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    device = 'eth0'
    data = network.get_ethtool_data(device)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data



# Generated at 2022-06-17 01:06:47.881403
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.default_interface_ipv4
    assert ln.default_interface_ipv6
    assert ln.default_interface_name
    assert ln.gateway_ipv4
    assert ln.gateway_ipv6
    assert ln.gateway_interface_ipv4
    assert ln.gateway_interface_ipv6
    assert ln.gateway_interface_name
    assert ln.ips


# Generated at 2022-06-17 01:07:30.996419
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: test with a mocked module
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/bin/ip')
    ln = LinuxNetwork(module)
    ln.get_interfaces_info('/bin/ip', {}, {})
    assert module.run_command.call_count == 2
    assert module.run_command.call_args_list[0][0][0] == ['/bin/ip', 'addr', 'show', 'primary', 'lo']
    assert module.run_command.call_args_list[1][0][0] == ['/bin/ip', 'addr', 'show', 'secondary', 'lo']



# Generated at 2022-06-17 01:07:38.485167
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)


# Generated at 2022-06-17 01:07:43.171249
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips
    assert ln.gateways


# Generated at 2022-06-17 01:07:55.009901
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
        ),
        supports_check_mode=True,
    )
    nm = LinuxNetwork(module)
    nm.populate()
    result = nm.data
    assert result['default_ipv4']['address'] == '192.168.1.1'
    assert result['default_ipv4']['broadcast'] == '192.168.1.255'
    assert result['default_ipv4']['netmask'] == '255.255.255.0'
    assert result['default_ipv4']['network'] == '192.168.1.0'

# Generated at 2022-06-17 01:07:59.391930
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.ips
    assert ln.gateways


# Generated at 2022-06-17 01:08:13.976695
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.exit_json = lambda x: x
    module.run_command = lambda x, **kwargs: (0, "", "")
    module.get_bin_path = lambda x: "/usr/bin/ethtool"
    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data("eth0") == {'features': {}, 'timestamping': [], 'hw_timestamp_filters': []}

    module.run_command = lambda x, **kwargs: (0, "Features for eth0:\nrx-checksumming: on\ntx-checksumming: on\n", "")

# Generated at 2022-06-17 01:08:26.524858
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.network.common.utils import load_platform_subclass

    module = AnsibleModule(
        argument_spec=dict(),
    )
    module.params['gather_subset'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources_network_os'] = 'LinuxNetwork'
    module.params['gather_network_resources_network_os_platform'] = 'Linux'
    module.params['gather_network_resources_network_os_version'] = '2.6.32-754.3.5.el6.x86_64'
    module.params['gather_network_resources_network_os_distribution'] = 'CentOS'

# Generated at 2022-06-17 01:08:32.605036
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/sbin/ip')
    ln = LinuxNetwork(module)
    ln.get_default_interfaces()
    module.run_command.assert_called_with(['/sbin/ip', 'route', 'get', '8.8.8.8'], errors='surrogate_then_replace')


# Generated at 2022-06-17 01:08:35.349195
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    network.populate()
    assert network.interfaces
    assert network.default_ipv4
    assert network.default_ipv6
    assert network.ips


# Generated at 2022-06-17 01:08:45.334978
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.network.common.utils import load_platform_subclass
    from ansible.module_utils.network.common.utils import get_file_content

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    network_module = load_platform_subclass(module, 'network')
    network_module.get_default_interfaces = lambda: {'ipv4': {}, 'ipv6': {}}
    network_module.get_interfaces_info = lambda x, y, z: ({}, {})
    network_module.get_file_content = get_file_content

    # FIXME: this is a bit of a hack
    # FIXME: this is a bit of a hack

# Generated at 2022-06-17 01:09:38.511048
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Test with no default interface
    module = AnsibleModule(argument_spec={})
    module.exit_json = MagicMock()
    network = LinuxNetwork(module)
    default_ipv4, default_ipv6 = network.get_default_interfaces()
    assert default_ipv4 == {}
    assert default_ipv6 == {}
    module.exit_json.assert_called_once_with(changed=False,
                                             default_ipv4={},
                                             default_ipv6={},
                                             interfaces={},
                                             ips={'all_ipv4_addresses': [],
                                                  'all_ipv6_addresses': []})


# Generated at 2022-06-17 01:09:43.833893
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.ips


# Generated at 2022-06-17 01:09:51.956736
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    # FIXME: this is a bit of a hack, but it's better than nothing
    #        we should probably mock out the run_command() method
    #        and return canned output
    ln.module.run_command = lambda x: (0, '', '')
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address'] == '127.0.0.1'
    assert default_ipv6['address'] == '::1'


# Generated at 2022-06-17 01:10:04.317806
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: x
    module.run_command = lambda x: (0, '', '')
    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data('eth0') == {'features': {}, 'timestamping': [], 'hw_timestamp_filters': []}

# Generated at 2022-06-17 01:10:15.531632
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

# Generated at 2022-06-17 01:10:24.091690
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    # FIXME: this is a bit of a hack
    ln.module.run_command = lambda x: (0, '', '')
    ln.get_default_interfaces()
    assert ln.default_ipv4['address'] == '192.0.2.1'
    assert ln.default_ipv6['address'] == '2001:db8::1'


# Generated at 2022-06-17 01:10:35.552483
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda x: x
    linux_network = LinuxNetwork(module)

# Generated at 2022-06-17 01:10:46.167506
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='')
    module.get_file_content = MagicMock(return_value='')
    module.get_default_interfaces = MagicMock(return_value='')
    module.get_interfaces_info = MagicMock(return_value='')
    module.get_default_ipv4 = MagicMock(return_value='')
    module.get_default_ipv6 = MagicMock(return_value='')
    module.get_default_route = MagicMock(return_value='')

# Generated at 2022-06-17 01:10:58.902307
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    module.run_command = MagicMock(return_value=(0, '', ''))
    network = LinuxNetwork(module)
    assert network.get_ethtool_data('eth0') == {}
    module.run_command.assert_called_once_with(['ethtool', '-k', 'eth0'], errors='surrogate_then_replace')
    module.run_command.reset_mock()

# Generated at 2022-06-17 01:11:01.957400
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: implement unit test
    pass


# Generated at 2022-06-17 01:11:54.682662
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-17 01:11:58.584103
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.gateways
    assert ln.ips


# Generated at 2022-06-17 01:12:10.970968
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address'] == '192.168.1.1'
    assert default_ipv4['netmask'] == '255.255.255.0'
    assert default_ipv4['network'] == '192.168.1.0'
    assert default_ipv4['broadcast'] == '192.168.1.255'
    assert default_ipv6['address'] == 'fe80::a00:27ff:fe3a:f9c0'
    assert default_ipv6['prefix'] == '64'
    assert default_ipv6['scope'] == 'link'


# Generated at 2022-06-17 01:12:12.082925
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # TODO: implement
    pass


# Generated at 2022-06-17 01:12:23.420686
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/usr/sbin/ethtool')
    linux_network = LinuxNetwork(module)
    assert linux_network.get_ethtool_data('eth0') == {'features': {}, 'timestamping': [], 'hw_timestamp_filters': []}
    module.run_command.assert_called_with(['/usr/sbin/ethtool', '-k', 'eth0'], errors='surrogate_then_replace')

# Generated at 2022-06-17 01:12:27.721393
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    ln = LinuxNetwork(module)
    default_ipv4 = {}
    default_ipv6 = {}
    interfaces, ips = ln.get_interfaces_info('/sbin/ip', default_ipv4, default_ipv6)
    assert interfaces['lo']['ipv4']['address'] == '127.0.0.1'
    assert interfaces['lo']['ipv4']['netmask'] == '255.0.0.0'
    assert interfaces['lo']['ipv4']['network'] == '127.0.0.0'

# Generated at 2022-06-17 01:12:40.176514
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    ln = LinuxNetwork(module)
    default_ipv4 = dict(address='192.168.1.1')
    default_ipv6 = dict(address='2001:db8::1')
    interfaces, ips = ln.get_interfaces_info('/sbin/ip', default_ipv4, default_ipv6)
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'eth0' in interfaces
    assert 'eth1' in interfaces
    assert 'eth2' in interfaces
    assert 'eth3' in interfaces
    assert 'eth4' in interfaces
    assert 'eth5' in interfaces
    assert 'eth6' in interfaces
    assert 'eth7' in interfaces
    assert 'eth8' in interfaces

# Generated at 2022-06-17 01:12:45.463225
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.ips


# Generated at 2022-06-17 01:12:58.228919
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-17 01:12:59.742218
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: implement
    pass


# Generated at 2022-06-17 01:13:37.100975
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-17 01:13:40.952685
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: implement
    pass
