

# Generated at 2022-06-17 01:04:17.644313
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: mock out the module
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ip_path = ln.module.get_bin_path("ip")
    default_ipv4 = {}
    default_ipv6 = {}
    interfaces, ips = ln.get_interfaces_info(ip_path, default_ipv4, default_ipv6)
    assert isinstance(interfaces, dict)
    assert isinstance(ips, dict)



# Generated at 2022-06-17 01:04:27.630258
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    # FIXME: mock out the calls to run_command
    # FIXME: mock out the calls to get_bin_path
    # FIXME: mock out the calls to get_file_content
    # FIXME: mock out the calls to glob.glob
    # FIXME: mock out the calls to os.path.exists
    # FIXME: mock out the calls to os.path.isdir
    # FIXME: mock out the calls to os.path.basename
    # FIXME: mock out the calls to os.readlink
    # FIXME: mock out the calls to socket.inet_aton
    # FIXME: mock out the calls to socket.inet_ntoa
    # FIXME: mock out the calls to struct.pack
   

# Generated at 2022-06-17 01:04:40.369807
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    default_ipv4 = {'address': '192.168.1.1'}
    default_ipv6 = {'address': '2001:db8::1'}
    interfaces, ips = network.get_interfaces_info('/sbin/ip', default_ipv4, default_ipv6)
    assert interfaces['eth0']['ipv4']['address'] == '192.168.1.1'
    assert interfaces['eth0']['ipv4']['broadcast'] == '192.168.1.255'
    assert interfaces['eth0']['ipv4']['netmask'] == '255.255.255.0'

# Generated at 2022-06-17 01:04:52.932004
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    linux_network = LinuxNetwork(module)
    default_ipv4 = {}
    default_ipv6 = {}
    interfaces, ips = linux_network.get_interfaces_info('ip', default_ipv4, default_ipv6)
    assert interfaces['eth0']['device'] == 'eth0'
    assert interfaces['eth0']['ipv4']['address'] == '192.168.0.1'
    assert interfaces['eth0']['ipv4']['broadcast'] == '192.168.0.255'
    assert interfaces['eth0']['ipv4']['netmask'] == '255.255.255.0'


# Generated at 2022-06-17 01:04:54.243608
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # FIXME: this is a stub
    pass



# Generated at 2022-06-17 01:04:58.496317
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.gateways
    assert ln.ips


# Generated at 2022-06-17 01:05:11.738671
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

# Generated at 2022-06-17 01:05:16.686240
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    # FIXME: this is a stub
    assert ln.get_ethtool_data(None) == {}


# Generated at 2022-06-17 01:05:27.857062
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['all'], type='list'),
            filter=dict(default=None, type='str'),
        ),
        supports_check_mode=True,
    )
    # FIXME: this is a bit of a hack, but it works
    # FIXME: this is a bit of a hack, but it works
    # FIXME: this is a bit of a hack, but it works
    # FIXME: this is a bit of a hack, but it works
    # FIXME: this is a bit of a hack, but it works
    # FIXME: this is a bit of a hack, but it works
    # FIXME: this is a bit of a hack, but it works
    # FIXME: this is a bit of a hack, but it

# Generated at 2022-06-17 01:05:36.523843
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda x: x
    linux_network = LinuxNetwork(module)

# Generated at 2022-06-17 01:06:18.002672
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

# Generated at 2022-06-17 01:06:23.439759
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Test with a real device
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    device = 'lo'
    data = ln.get_ethtool_data(device)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data
    assert data['features']['tx_checksumming'] == 'on'
    assert data['timestamping'] == ['hardware', 'software', 'tx_software', 'rx_software']
    assert data['hw_timestamp_filters'] == ['all']
    assert data['phc_index'] == 0

    # Test with a non-existing device
    device = 'eth0'
    data = ln.get_eth

# Generated at 2022-06-17 01:06:27.640391
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    interfaces, ips = linux_network.get_interfaces_info('/sbin/ip', {}, {})
    assert interfaces
    assert ips


# Generated at 2022-06-17 01:06:36.644188
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
        ),
        supports_check_mode=True,
    )
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address'] == '192.168.1.1'
    assert ln.default_ipv4['netmask'] == '255.255.255.0'
    assert ln.default_ipv4['network'] == '192.168.1.0'
    assert ln.default_ipv4['broadcast'] == '192.168.1.255'
    assert ln.default_ipv6['address'] == 'fe80::5054:ff:fe12:3456'
   

# Generated at 2022-06-17 01:06:37.760438
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: implement
    pass


# Generated at 2022-06-17 01:06:48.725648
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Test with a device that has ethtool data
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    device = 'lo'
    data = linux_network.get_ethtool_data(device)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data
    assert data['features']['rx_all'] == 'on'
    assert data['features']['tx_udp_csum'] == 'on'
    assert data['features']['tx_tcp_csum'] == 'on'
    assert data['features']['tx_sctp_csum'] == 'on'
    assert data['features']['tx_ip_csum']

# Generated at 2022-06-17 01:07:00.580339
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            gather_network_resources=dict(default=['all'], type='list'),
        ),
        supports_check_mode=True,
    )

    # FIXME: this is a hack to get around the fact that the module is not
    #        actually being run through the AnsibleModule constructor
    module.params = {}

    # FIXME: this is a hack to get around the fact that the module is not
    #        actually being run through the AnsibleModule constructor
    module.check_mode = True

    # FIXME: this is a hack to get around the fact that the module is not
    #        actually being run through the AnsibleModule constructor

# Generated at 2022-06-17 01:07:08.219365
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:07:21.829308
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.network.common.utils import load_platform_subclass

    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']
    module.params['gather_network_resources'] = ['interfaces']

# Generated at 2022-06-17 01:07:30.836721
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: x
    module.run_command = lambda x, errors='surrogate_then_replace': (0, '', '')
    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data('eth0') == {
        'features': {},
        'timestamping': [],
        'hw_timestamp_filters': [],
    }


# Generated at 2022-06-17 01:08:20.780508
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:08:30.873519
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # FIXME: this is a very basic test, we should add more
    # FIXME: this test is not run by default, we should add it to the test suite
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    interfaces, ips = ln.get_interfaces_info('/sbin/ip', {}, {})
    assert isinstance(interfaces, dict)
    assert isinstance(ips, dict)
    assert 'all_ipv4_addresses' in ips
    assert 'all_ipv6_addresses' in ips
    for i in interfaces:
        assert 'device' in interfaces[i]
        assert 'type' in interfaces[i]
        assert 'mtu' in interfaces[i]
        assert 'active' in interfaces[i]

# Generated at 2022-06-17 01:08:32.480603
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # FIXME: this is a stub
    pass



# Generated at 2022-06-17 01:08:38.201068
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    linux_network = LinuxNetwork(module)
    interfaces, ips = linux_network.get_interfaces_info(None, None, None)
    assert interfaces
    assert ips


# Generated at 2022-06-17 01:08:48.829398
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-17 01:08:51.007362
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: write unit test
    pass


# Generated at 2022-06-17 01:08:57.218333
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)
    assert 'address' in default_ipv4
    assert 'address' in default_ipv6


# Generated at 2022-06-17 01:09:04.262726
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    device = 'eth0'
    data = network.get_ethtool_data(device)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data


# Generated at 2022-06-17 01:09:06.592311
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-17 01:09:12.153298
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)


# Generated at 2022-06-17 01:10:08.256252
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4 = {'address': '192.168.1.1'}
    default_ipv6 = {'address': '2001:db8::1'}
    interfaces, ips = ln.get_interfaces_info('/sbin/ip', default_ipv4, default_ipv6)
    assert interfaces['eth0']['ipv4']['address'] == '192.168.1.1'
    assert interfaces['eth0']['ipv4']['broadcast'] == '192.168.1.255'
    assert interfaces['eth0']['ipv4']['netmask'] == '255.255.255.0'

# Generated at 2022-06-17 01:10:18.017207
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    module.run_command = MagicMock(return_value=(0, '', ''))
    linux_network = LinuxNetwork(module)
    device = 'eth0'
    data = linux_network.get_ethtool_data(device)
    assert data == {}

# Generated at 2022-06-17 01:10:24.204278
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    device = 'eth0'
    data = linux_network.get_ethtool_data(device)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data



# Generated at 2022-06-17 01:10:34.164439
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    default_ipv4 = {'address': '192.168.1.1'}
    default_ipv6 = {'address': '2001:db8::1'}
    interfaces, ips = linux_network.get_interfaces_info('/sbin/ip', default_ipv4, default_ipv6)
    assert 'lo' in interfaces
    assert 'eth0' in interfaces
    assert 'eth1' in interfaces
    assert 'eth2' in interfaces
    assert 'eth3' in interfaces
    assert 'eth4' in interfaces
    assert 'eth5' in interfaces
    assert 'eth6' in interfaces
    assert 'eth7' in interfaces
    assert 'eth8' in interfaces

# Generated at 2022-06-17 01:10:39.530487
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips


# Generated at 2022-06-17 01:10:42.462536
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data("eth0") == {}


# Generated at 2022-06-17 01:10:54.280214
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Create a mock module
    module = AnsibleModule(argument_spec={})
    # Create a mock module
    module.run_command = MagicMock(return_value=(0, '', ''))
    # Create a mock module
    module.get_bin_path = MagicMock(return_value='/usr/bin/ethtool')
    # Create a LinuxNetwork object
    linux_network = LinuxNetwork(module)
    # Create a device name
    device = 'eth0'
    # Test the method
    result = linux_network.get_ethtool_data(device)
    # Check the result

# Generated at 2022-06-17 01:11:04.093936
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    device = 'eth0'
    ethtool_path = module.get_bin_path("ethtool")
    if ethtool_path:
        args = [ethtool_path, '-k', device]
        rc, stdout, stderr = module.run_command(args, errors='surrogate_then_replace')
        if rc == 0:
            features = {}
            for line in stdout.strip().splitlines():
                if not line or line.endswith(":"):
                    continue
                key, value = line.split(": ")
                if not value:
                    continue
                features[key.strip().replace('-', '_')] = value.strip()
            assert features == linux_network.get_eth

# Generated at 2022-06-17 01:11:11.135513
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    # FIXME: this is a bit of a hack
    ln.module.run_command = lambda args, **kwargs: (0, '', '')
    assert ln.get_ethtool_data('eth0') == {}



# Generated at 2022-06-17 01:11:17.465707
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    ln = LinuxNetwork(module)
    data = ln.get_ethtool_data('eth0')
    assert data['features']['rx_all'] == 'off'
    assert data['features']['tx_tcp_segmentation'] == 'on'
    assert data['timestamping'] == ['hardware', 'software', 'tx_software']
    assert data['hw_timestamp_filters'] == ['all']
    assert data['phc_index'] == 0



# Generated at 2022-06-17 01:12:15.442961
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-17 01:12:21.743001
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    device = 'eth0'
    data = linux_network.get_ethtool_data(device)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data


# Generated at 2022-06-17 01:12:29.804807
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    linux_network = LinuxNetwork(module)
    linux_network.populate()
    assert linux_network.default_ipv4 is not None
    assert linux_network.default_ipv6 is not None
    assert linux_network.interfaces is not None
    assert linux_network.ips is not None
    assert linux_network.gateways is not None


# Generated at 2022-06-17 01:12:32.149167
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips
    assert ln.gateways


# Generated at 2022-06-17 01:12:41.858240
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.params['device'] = 'eth0'
    linux_network = LinuxNetwork(module)
    data = linux_network.get_ethtool_data(module.params['device'])
    assert data['features']['rx_checksumming'] == 'on'
    assert data['features']['tx_checksumming'] == 'on'
    assert data['features']['scatter_gather'] == 'on'
    assert data['features']['tcp_segmentation_offload'] == 'on'
    assert data['features']['udp_fragmentation_offload'] == 'on'
    assert data['features']['generic_segmentation_offload'] == 'on'

# Generated at 2022-06-17 01:12:47.503817
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips
    assert ln.gateways


# Generated at 2022-06-17 01:12:49.154862
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-17 01:13:00.904880
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Test data
    device = 'eth0'
    ethtool_path = '/usr/sbin/ethtool'

# Generated at 2022-06-17 01:13:06.592616
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4 = {'address': '192.168.122.1'}
    default_ipv6 = {'address': 'fe80::5054:ff:fe12:3456'}
    interfaces, ips = ln.get_interfaces_info('/sbin/ip', default_ipv4, default_ipv6)
    assert interfaces['lo']['ipv4']['address'] == '127.0.0.1'
    assert interfaces['lo']['ipv4']['netmask'] == '255.0.0.0'
    assert interfaces['lo']['ipv4']['network'] == '127.0.0.0'

# Generated at 2022-06-17 01:13:14.340693
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    # FIXME: this is a bit of a hack, but it works
    module.run_command = lambda x: (0, '', '')
    module.get_bin_path = lambda x: '/bin/ethtool'
    linux_network = LinuxNetwork(module)
    assert linux_network.get_ethtool_data('eth0') == {'features': {}, 'timestamping': [], 'hw_timestamp_filters': []}
