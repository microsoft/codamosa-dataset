

# Generated at 2022-06-17 01:04:09.695206
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips


# Generated at 2022-06-17 01:04:12.980605
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips


# Generated at 2022-06-17 01:04:18.758144
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda x: x
    network = LinuxNetwork(module)
    device = 'eth0'
    data = network.get_ethtool_data(device)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data



# Generated at 2022-06-17 01:04:28.623988
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/bin/ip')
    module.params = {}

    # Mock the glob.glob function
    glob.glob = MagicMock(return_value=['/sys/class/net/eth0', '/sys/class/net/eth1'])

    # Mock the os.path.isdir function
    os.path.isdir = MagicMock(return_value=True)

    # Mock the os.path.exists function
    os.path.exists = MagicMock(return_value=True)

    # Mock the get_file_content function

# Generated at 2022-06-17 01:04:39.157232
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    module.run_command = MagicMock(return_value=(0, '', ''))
    linux_network = LinuxNetwork(module)
    assert linux_network.get_ethtool_data('eth0') == {}

# Generated at 2022-06-17 01:04:51.534900
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Test with a real device
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    data = network.get_ethtool_data('lo')
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data
    assert data['features']['tx_checksumming'] == 'on'
    assert data['features']['rx_checksumming'] == 'on'
    assert data['timestamping'] == ['hardware', 'software']
    assert data['hw_timestamp_filters'] == ['all']
    assert data['phc_index'] == 0

    # Test with a non-existent device
    data = network.get_ethtool_data('eth0')
   

# Generated at 2022-06-17 01:05:03.584703
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4 = {'address': '192.168.1.1'}
    default_ipv6 = {'address': '2001:db8::1'}
    interfaces, ips = ln.get_interfaces_info('/sbin/ip', default_ipv4, default_ipv6)
    assert interfaces['lo']['ipv4']['address'] == '127.0.0.1'
    assert interfaces['lo']['ipv4']['netmask'] == '255.0.0.0'
    assert interfaces['lo']['ipv4']['network'] == '127.0.0.0'

# Generated at 2022-06-17 01:05:04.557424
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: implement
    pass


# Generated at 2022-06-17 01:05:16.948916
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    device = 'eth0'
    data = linux_network.get_ethtool_data(device)
    assert data['features']['tx_checksumming'] == 'on'
    assert data['features']['rx_checksumming'] == 'on'
    assert data['features']['scatter_gather'] == 'on'
    assert data['features']['tcp_segmentation_offload'] == 'on'
    assert data['features']['udp_fragmentation_offload'] == 'on'
    assert data['features']['generic_segmentation_offload'] == 'on'
    assert data['features']['generic_receive_offload'] == 'on'

# Generated at 2022-06-17 01:05:20.210573
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    assert linux_network.get_default_interfaces() == ({'default_ipv4': {}, 'default_ipv6': {}}, {})


# Generated at 2022-06-17 01:05:48.564056
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/sbin/ip')
    ln = LinuxNetwork(module)
    ln.get_default_interfaces()
    module.run_command.assert_called_with(['/sbin/ip', 'route', 'get', '8.8.8.8'], errors='surrogate_then_replace')


# Generated at 2022-06-17 01:05:55.445060
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/sbin/ip')
    ln = LinuxNetwork(module)
    ln.get_default_interfaces()
    module.run_command.assert_called_with(['/sbin/ip', 'route', 'get', '8.8.8.8'])


# Generated at 2022-06-17 01:06:02.253971
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)

# Generated at 2022-06-17 01:06:04.190483
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: write unit test
    pass


# Generated at 2022-06-17 01:06:16.837012
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.params['gather_subset'] = ['all']
    module.params['gather_network_resources'] = ['all']
    module.params['filter'] = None
    module.params['config'] = None
    module.params['running_config'] = None
    module.params['persistent_connection'] = None
    module.params['network_os'] = None
    module.params['check_running_config'] = None
    module.params['diff_against'] = None
    module.params['diff_ignore_lines'] = None
    module.params['diff_match'] = None
    module.params['diff_replace'] = None
    module.params['diff_exclude'] = None
    module.params['diff_exclude_lines']

# Generated at 2022-06-17 01:06:21.134050
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips
    assert ln.gateways


# Generated at 2022-06-17 01:06:31.979387
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    # FIXME: mock module.get_bin_path
    # FIXME: mock module.run_command
    # FIXME: mock module.fail_json
    # FIXME: mock module.exit_json
    # FIXME: mock module.run_command
    # FIXME: mock module.run_command
    # FIXME: mock module.run_command
    # FIXME: mock module.run_command
    # FIXME: mock module.run_command
    # FIXME: mock module.run_command
    # FIXME: mock module.run_command
    # FIXME: mock module.run_command
    # FIXME: mock module.run_command
    # FIXME: mock

# Generated at 2022-06-17 01:06:32.648540
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: implement
    pass


# Generated at 2022-06-17 01:06:43.962823
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: mock out the module object
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    ln = LinuxNetwork(module)
    # TODO: mock out the glob.glob() call
    # TODO: mock out the os.path.exists() calls
    # TODO: mock out the os.path.isdir() calls
    # TODO: mock out the os.path.basename() calls
    # TODO: mock out the os.path.realpath() calls
    # TODO: mock out the os.readlink() calls
    # TODO: mock out the get_file_content() calls
    # TODO: mock out the socket

# Generated at 2022-06-17 01:06:49.230024
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    device = 'eth0'
    data = network.get_ethtool_data(device)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data


# Generated at 2022-06-17 01:07:29.469060
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address'] == '192.168.1.10'
    assert ln.default_ipv4['netmask'] == '255.255.255.0'
    assert ln.default_ipv4['network'] == '192.168.1.0'
    assert ln.default_ipv4['broadcast'] == '192.168.1.255'
    assert ln.default_ipv4['macaddress'] == '00:0c:29:8c:11:b1'
    assert ln.default_ipv4['mtu'] == 1500
    assert ln.default_ipv4['type'] == 'ether'
    assert l

# Generated at 2022-06-17 01:07:34.548203
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.params['device'] = 'eth0'
    linux_network = LinuxNetwork(module)
    data = linux_network.get_ethtool_data(module.params['device'])
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data


# Generated at 2022-06-17 01:07:41.650631
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )
    ln = LinuxNetwork(module)
    ln.populate()
    result = ln.data
    assert 'default_ipv4' in result
    assert 'default_ipv6' in result
    assert 'interfaces' in result
    assert 'all_ipv4_addresses' in result['ipv4']
    assert 'all_ipv6_addresses' in result['ipv6']


# Generated at 2022-06-17 01:07:50.583803
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    device = 'eth0'
    data = ln.get_ethtool_data(device)
    assert data['features']['rx_all'] == 'off'
    assert data['features']['tx_udp_csum_tx'] == 'on'
    assert data['timestamping'] == ['hardware', 'software', 'tx_hardware', 'tx_software']
    assert data['hw_timestamp_filters'] == ['all', 'none', 'multicast', 'unicast', 'p2p_event', 'p2p_general']
    assert data['phc_index'] == 0


# Generated at 2022-06-17 01:07:57.038287
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/sbin/ip')
    ln = LinuxNetwork(module)
    ln.get_default_interfaces()
    module.run_command.assert_called_with(['/sbin/ip', 'route', 'get', '8.8.8.8'])


# Generated at 2022-06-17 01:08:01.053538
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)


# Generated at 2022-06-17 01:08:14.643035
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:08:22.786839
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, "", ""))
    module.get_bin_path = MagicMock(return_value="/bin/ip")
    ln = LinuxNetwork(module)
    ln.get_default_interfaces()
    module.run_command.assert_called_with(['/bin/ip', 'route', 'get', '8.8.8.8'])


# Generated at 2022-06-17 01:08:35.245432
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address'] == '10.0.2.15'
    assert ln.default_ipv4['netmask'] == '255.255.255.0'
    assert ln.default_ipv4['network'] == '10.0.2.0'
    assert ln.default_ipv4['broadcast'] == '10.0.2.255'
    assert ln.default_ipv4['macaddress'] == '08:00:27:00:00:0f'
    assert ln.default_ipv4['mtu'] == 1500
    assert ln.default_ipv4['type'] == 'ether'

# Generated at 2022-06-17 01:08:41.930427
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips


# Generated at 2022-06-17 01:09:30.278121
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

# Generated at 2022-06-17 01:09:40.549191
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4 = {}
    default_ipv6 = {}
    interfaces, ips = ln.get_interfaces_info('/sbin/ip', default_ipv4, default_ipv6)
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'ipv4' in interfaces['lo']
    assert 'ipv6' in interfaces['lo']
    assert '127.0.0.1' in ips['all_ipv4_addresses']
    assert '::1' in ips['all_ipv6_addresses']
    assert '127.0.0.1' in interfaces['lo']['ipv4']['address']

# Generated at 2022-06-17 01:09:48.753774
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address'] == '192.168.1.2'
    assert ln.default_ipv4['netmask'] == '255.255.255.0'
    assert ln.default_ipv4['network'] == '192.168.1.0'
    assert ln.default_ipv4['broadcast'] == '192.168.1.255'
    assert ln.default_ipv6['address'] == 'fe80::5054:ff:fe12:3456'
    assert ln.default_ipv6['prefix'] == '64'
    assert ln.default_ipv6['scope'] == 'link'
    assert ln

# Generated at 2022-06-17 01:09:55.031045
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            gather_network_resources=dict(default=['all'], type='list'),
        ),
        supports_check_mode=True,
    )
    nm = LinuxNetwork(module)
    nm.populate()
    result = nm.data
    assert result['default_ipv4']['address'] == '192.168.122.1'
    assert result['default_ipv4']['broadcast'] == '192.168.122.255'
    assert result['default_ipv4']['netmask'] == '255.255.255.0'
    assert result['default_ipv4']['network'] == '192.168.122.0'

# Generated at 2022-06-17 01:10:05.825158
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    # FIXME: this is a bit of a hack
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.get_bin_path = lambda *args, **kwargs: '/sbin/ip'
    network = LinuxNetwork(module)
    # FIXME: this is a bit of a hack
    network.get_interfaces_info = lambda *args, **kwargs: ({}, {})
    # FIXME: this is a bit of a hack
    network.get_default_interfaces = lambda *args, **kwargs: ({}, {})
    assert network.get_default_interfaces() == ({}, {})


# Generated at 2022-06-17 01:10:08.119497
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: this is a stub
    pass


# Generated at 2022-06-17 01:10:13.392005
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    device = 'eth0'
    data = ln.get_ethtool_data(device)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data


# Generated at 2022-06-17 01:10:20.402437
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.gateway_ipv4
    assert ln.gateway_ipv6
    assert ln.ips


# Generated at 2022-06-17 01:10:22.137055
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: write unit test
    pass


# Generated at 2022-06-17 01:10:30.703860
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips
    assert ln.routes


# Generated at 2022-06-17 01:11:16.445746
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    device = 'eth0'
    data = network.get_ethtool_data(device)
    assert data['features']['rx_checksumming'] == 'on'
    assert data['features']['tx_checksum_ipv4'] == 'on'
    assert data['features']['tx_checksum_ipv6'] == 'on'
    assert data['features']['tx_checksum_fcoe_crc'] == 'on'
    assert data['features']['tx_checksum_sctp'] == 'on'
    assert data['features']['scatter_gather'] == 'on'
    assert data['features']['tcp_segmentation_offload'] == 'on'
    assert data

# Generated at 2022-06-17 01:11:18.449570
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips


# Generated at 2022-06-17 01:11:20.906651
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = LinuxNetworkCollector(module)
    assert collector.platform == 'Linux'
    assert collector.fact_class == LinuxNetwork
    assert collector.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-17 01:11:24.500397
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.gateways
    assert ln.ips


# Generated at 2022-06-17 01:11:33.864988
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address'] == '192.168.1.1'
    assert default_ipv4['netmask'] == '255.255.255.0'
    assert default_ipv4['network'] == '192.168.1.0'
    assert default_ipv4['macaddress'] == '00:00:00:00:00:00'
    assert default_ipv4['mtu'] == 1500
    assert default_ipv4['type'] == 'unknown'
    assert default_ipv6['address'] == 'fe80::1'
    assert default_ipv6['prefix'] == '64'


# Generated at 2022-06-17 01:11:40.635114
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address'] == '127.0.0.1'
    assert default_ipv6['address'] == '::1'


# Generated at 2022-06-17 01:11:50.725196
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            gather_network_resources=dict(default=['all'], type='list'),
        ),
        supports_check_mode=True,
    )
    nm = LinuxNetwork(module)
    nm.populate()
    result = nm.data
    assert result['default_ipv4']['address'] == '192.0.2.1'
    assert result['default_ipv4']['netmask'] == '255.255.255.0'
    assert result['default_ipv4']['network'] == '192.0.2.0'
    assert result['default_ipv4']['broadcast'] == '192.0.2.255'

# Generated at 2022-06-17 01:12:00.882693
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

# Generated at 2022-06-17 01:12:07.202432
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips


# Generated at 2022-06-17 01:12:16.560496
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: x
    module.run_command = lambda x: (0, '', '')
    ln = LinuxNetwork(module)
    interfaces, ips = ln.get_interfaces_info('/sbin/ip', {}, {})
    assert interfaces['lo']['ipv4']['address'] == '127.0.0.1'
    assert interfaces['lo']['ipv4']['netmask'] == '255.0.0.0'
    assert interfaces['lo']['ipv4']['network'] == '127.0.0.0'
    assert interfaces['lo']['ipv6'][0]['address'] == '::1'

# Generated at 2022-06-17 01:12:58.584542
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    default_ipv4, default_ipv6 = linux_network.get_default_interfaces()
    assert default_ipv4['address'] == '192.168.1.1'
    assert default_ipv6['address'] == 'fe80::1'


# Generated at 2022-06-17 01:13:06.944287
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    ln = LinuxNetwork(module)
    ln.populate()
    result = ln.get_interfaces_info()
    assert result is not None


# Generated at 2022-06-17 01:13:13.153635
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4 is not None
    assert ln.default_ipv6 is not None
    assert ln.interfaces is not None
    assert ln.ips is not None


# Generated at 2022-06-17 01:13:15.962530
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: write unit test
    pass


# Generated at 2022-06-17 01:13:21.863203
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)
    assert 'address' in default_ipv4
    assert 'address' in default_ipv6


# Generated at 2022-06-17 01:13:31.361196
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-17 01:13:38.618262
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address'] == '192.168.122.1'
    assert default_ipv6['address'] == 'fe80::5054:ff:fe12:3456'


# Generated at 2022-06-17 01:13:47.337555
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: x
    module.run_command = lambda x: (0, '', '')
    network = LinuxNetwork(module)
    interfaces = network.get_interfaces_info(None, None, None)[0]
    assert 'lo' in interfaces
    assert 'eth0' in interfaces
    assert 'eth1' in interfaces
    assert 'eth2' in interfaces
    assert 'eth3' in interfaces
    assert 'eth4' in interfaces
    assert 'eth5' in interfaces
    assert 'eth6' in interfaces
    assert 'eth7' in interfaces
    assert 'eth8' in interfaces
    assert 'eth9' in interfaces
    assert 'eth10' in interfaces
    assert 'eth11' in interfaces
    assert 'eth12' in interfaces