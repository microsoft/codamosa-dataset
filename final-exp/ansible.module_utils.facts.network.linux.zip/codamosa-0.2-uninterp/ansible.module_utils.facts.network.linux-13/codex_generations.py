

# Generated at 2022-06-17 01:04:18.638806
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', default=['!all']),
            filter=dict(type='list', default=['*']),
        ),
        supports_check_mode=True,
    )

    # FIXME: this is a bit of a hack to get around the fact that we can't
    # mock the module.run_command() method
    class MockModule(object):
        def __init__(self, module):
            self.module = module
            self.params = module.params
            self.check_mode = module.check_mode

        def get_bin_path(self, arg, required=False):
            return '/sbin/ip'


# Generated at 2022-06-17 01:04:20.145067
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-17 01:04:29.909993
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    linux_network = LinuxNetwork(module)

# Generated at 2022-06-17 01:04:36.855094
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = LinuxNetworkCollector(module)
    assert collector.module == module
    assert collector.facts == {}
    assert collector.fact_class == LinuxNetwork
    assert collector.fact_name == 'network'
    assert collector.required_facts == {'distribution', 'platform'}
    assert collector.platform == 'Linux'


# Generated at 2022-06-17 01:04:41.601566
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.ips


# Generated at 2022-06-17 01:04:54.206674
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:04:56.025782
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # TODO: add unit test for method get_ethtool_data of class LinuxNetwork
    pass


# Generated at 2022-06-17 01:04:57.364859
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: write unit tests for this method
    pass


# Generated at 2022-06-17 01:05:05.635508
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    default_ipv4, default_ipv6 = linux_network.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)


# Generated at 2022-06-17 01:05:16.748751
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    device = 'eth0'
    data = linux_network.get_ethtool_data(device)
    assert data['features']['rx_checksumming'] == 'on'
    assert data['features']['tx_checksum_ipv4'] == 'on'
    assert data['features']['tx_checksum_ipv6'] == 'on'
    assert data['features']['tx_checksum_fcoe_crc'] == 'on'
    assert data['features']['tx_checksum_sctp'] == 'on'
    assert data['features']['scatter_gather'] == 'on'
    assert data['features']['tx_scatter_gather'] == 'on'
   

# Generated at 2022-06-17 01:05:58.270186
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'gather_subset': ['all'],
        'gather_network_resources': ['all'],
    }
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.facts['default_ipv4']['address'] == '192.168.1.1'
    assert ln.facts['default_ipv4']['broadcast'] == '192.168.1.255'
    assert ln.facts['default_ipv4']['netmask'] == '255.255.255.0'
    assert ln.facts['default_ipv4']['network'] == '192.168.1.0'

# Generated at 2022-06-17 01:06:12.874570
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )
    nm = LinuxNetwork(module)
    nm.populate()
    assert nm.facts['default_ipv4']['address'] == '192.168.1.1'
    assert nm.facts['default_ipv4']['broadcast'] == '192.168.1.255'
    assert nm.facts['default_ipv4']['netmask'] == '255.255.255.0'
    assert nm.facts['default_ipv4']['network'] == '192.168.1.0'

# Generated at 2022-06-17 01:06:22.573200
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    # TODO: mock out the run_command method
    # TODO: mock out the get_bin_path method
    # TODO: mock out the get_interfaces_info method
    # TODO: mock out the get_interfaces_addresses method
    # TODO: mock out the get_interfaces_cidrs method
    # TODO: mock out the get_interfaces_masks method
    # TODO: mock out the get_interfaces_ipv4 method
    # TODO: mock out the get_interfaces_ipv6 method
    # TODO: mock out the get_interfaces_gateways method
    # TODO: mock out the get_interfaces_gateways_ipv4 method
    # TODO: mock

# Generated at 2022-06-17 01:06:31.364327
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/sbin/ip')
    module.get_file_content = MagicMock(return_value='127.0.0.1')
    ln = LinuxNetwork(module)
    assert ln.get_default_interfaces() == ({'default_ipv4': {'address': '127.0.0.1'}, 'default_ipv6': {'address': '::1'}}, {})


# Generated at 2022-06-17 01:06:33.123333
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = LinuxNetworkCollector(module)
    assert collector.platform == 'Linux'
    assert collector.required_facts == set(['distribution', 'platform'])
    assert collector.fact_class == LinuxNetwork


# Generated at 2022-06-17 01:06:41.926013
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            filter=dict(default=None, type='list'),
        ),
        supports_check_mode=True,
    )
    ln = LinuxNetwork(module)
    ln.populate()
    result = ln.data
    assert result['default_ipv4']['address'] == '192.168.1.1'
    assert result['default_ipv4']['broadcast'] == '192.168.1.255'
    assert result['default_ipv4']['netmask'] == '255.255.255.0'
    assert result['default_ipv4']['network'] == '192.168.1.0'

# Generated at 2022-06-17 01:06:49.934017
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.get_file_content = MagicMock(return_value=True)
    module.get_default_interfaces = MagicMock(return_value=True)
    module.get_interfaces_info = MagicMock(return_value=True)
    module.get_default_ipv4 = MagicMock(return_value=True)
    module.get_default_ipv6 = MagicMock(return_value=True)
    module.get_default_route = MagicMock(return_value=True)

# Generated at 2022-06-17 01:06:51.592497
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-17 01:06:57.786304
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address'] == '192.168.1.1'
    assert default_ipv6['address'] == 'fe80::1'


# Generated at 2022-06-17 01:07:12.610678
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: '/bin/ethtool'
    module.run_command = lambda x, **kwargs: (0, '', '')
    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data('eth0') == {
        'features': {},
        'timestamping': [],
        'hw_timestamp_filters': [],
    }

# Generated at 2022-06-17 01:07:46.378984
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address']
    assert default_ipv6['address']


# Generated at 2022-06-17 01:07:50.205082
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips


# Generated at 2022-06-17 01:07:55.442347
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address'] == '192.168.1.1'
    assert default_ipv6['address'] == 'fe80::1'


# Generated at 2022-06-17 01:07:58.887183
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    # FIXME: this is a stub, this needs to be tested
    assert ln.get_ethtool_data("eth0") == {}


# Generated at 2022-06-17 01:08:13.733328
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda x: x
    linux_network = LinuxNetwork(module)

# Generated at 2022-06-17 01:08:22.757986
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    device = "eth0"
    data = linux_network.get_ethtool_data(device)
    assert isinstance(data, dict)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data
    assert isinstance(data['features'], dict)
    assert isinstance(data['timestamping'], list)
    assert isinstance(data['hw_timestamp_filters'], list)
    assert isinstance(data['phc_index'], int)



# Generated at 2022-06-17 01:08:27.190198
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips


# Generated at 2022-06-17 01:08:37.412941
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    ln = LinuxNetwork(module)
    interfaces, ips = ln.get_interfaces_info('/sbin/ip', {}, {})
    assert isinstance(interfaces, dict)
    assert isinstance(ips, dict)
    assert isinstance(ips['all_ipv4_addresses'], list)
    assert isinstance(ips['all_ipv6_addresses'], list)
    for interface in interfaces.values():
        assert isinstance(interface, dict)
        assert 'device' in interface
        assert 'type' in interface
        assert 'mtu' in interface
        assert 'active' in interface
        assert 'macaddress' in interface
        assert 'promisc' in interface
        assert 'ipv4' in interface
       

# Generated at 2022-06-17 01:08:41.794517
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # FIXME: this is a stub
    assert False


# Generated at 2022-06-17 01:08:43.452899
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: write unit test
    pass


# Generated at 2022-06-17 01:09:23.739344
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-17 01:09:28.991712
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address'] == '192.168.1.1'
    assert default_ipv6['address'] == 'fe80::1'


# Generated at 2022-06-17 01:09:34.245825
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips


# Generated at 2022-06-17 01:09:38.056923
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = LinuxNetworkCollector(module)
    assert collector.platform == 'Linux'
    assert collector.fact_class == LinuxNetwork
    assert collector.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-17 01:09:48.195917
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address'] == '192.168.1.1'
    assert default_ipv4['netmask'] == '255.255.255.0'
    assert default_ipv4['network'] == '192.168.1.0'
    assert default_ipv4['broadcast'] == '192.168.1.255'
    assert default_ipv6['address'] == 'fe80::a00:27ff:fea3:c9a3'
    assert default_ipv6['prefix'] == '64'
    assert default_ipv6['scope'] == 'link'



# Generated at 2022-06-17 01:09:54.911930
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/sbin/ip')
    module.run_command = MagicMock(return_value=(0, '', ''))
    ln = LinuxNetwork(module)
    ln.get_default_interfaces()
    module.run_command.assert_called_with(['/sbin/ip', 'route', 'get', '8.8.8.8'], errors='surrogate_then_replace')


# Generated at 2022-06-17 01:10:00.377416
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)


# Generated at 2022-06-17 01:10:13.861094
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.exit_json = lambda x: x
    module.run_command = lambda x, **kwargs: (0, "", "")
    module.get_bin_path = lambda x: "/usr/sbin/ethtool"
    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data("eth0") == {
        'features': {},
        'timestamping': [],
        'hw_timestamp_filters': []
    }

# Generated at 2022-06-17 01:10:26.273591
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4 = {'address': '192.168.1.1'}
    default_ipv6 = {'address': '2001:db8::1'}
    interfaces, ips = ln.get_interfaces_info('/sbin/ip', default_ipv4, default_ipv6)
    assert interfaces['lo']['ipv4']['address'] == '127.0.0.1'
    assert interfaces['lo']['ipv4']['netmask'] == '255.0.0.0'
    assert interfaces['lo']['ipv4']['network'] == '127.0.0.0'

# Generated at 2022-06-17 01:10:36.267957
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

# Generated at 2022-06-17 01:11:15.659938
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    assert linux_network.get_ethtool_data('eth0') == {}


# Generated at 2022-06-17 01:11:16.966982
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: write unit test
    pass


# Generated at 2022-06-17 01:11:27.500819
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:11:35.080693
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            gather_network_resources=dict(default=['all'], type='list'),
        ),
        supports_check_mode=True,
    )
    # FIXME: this is a bit of a hack to get around the fact that we can't
    # mock the module.run_command() method.
    module.run_command = lambda *args, **kwargs: (0, '', '')
    # FIXME: this is a bit of a hack to get around the fact that we can't
    # mock the module.get_bin_path() method.
    module.get_bin_path = lambda *args, **kwargs: '/bin/ip'
    # FIXME: this is a bit

# Generated at 2022-06-17 01:11:36.606186
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: write unit test
    pass



# Generated at 2022-06-17 01:11:48.574697
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/sbin/ip')
    module.get_file_content = MagicMock(return_value='')

# Generated at 2022-06-17 01:11:52.601422
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.gateways
    assert ln.ips


# Generated at 2022-06-17 01:11:57.865232
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda x: x
    linux_network = LinuxNetwork(module)
    device = 'eth0'
    data = linux_network.get_ethtool_data(device)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data


# Generated at 2022-06-17 01:12:01.890723
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = LinuxNetworkCollector(module)
    assert collector.platform == 'Linux'
    assert collector.fact_class == LinuxNetwork
    assert collector.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-17 01:12:02.820238
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # TODO: implement
    pass



# Generated at 2022-06-17 01:12:43.784726
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:12:49.261591
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips


# Generated at 2022-06-17 01:12:55.111397
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.ips


# Generated at 2022-06-17 01:12:59.523038
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.ips


# Generated at 2022-06-17 01:13:12.410095
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    # test with a real device
    data = ln.get_ethtool_data('lo')
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data
    # test with a fake device
    data = ln.get_ethtool_data('eth0')
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data



# Generated at 2022-06-17 01:13:22.596000
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4 = {}
    default_ipv6 = {}
    interfaces, ips = ln.get_interfaces_info('/sbin/ip', default_ipv4, default_ipv6)
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'ipv4' in interfaces['lo']
    assert 'ipv6' in interfaces['lo']
    assert 'all_ipv4_addresses' in ips
    assert 'all_ipv6_addresses' in ips
    assert '127.0.0.1' in ips['all_ipv4_addresses']
    assert '::1' in ips['all_ipv6_addresses']

# Generated at 2022-06-17 01:13:29.075558
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.exit_json = lambda x: x
    module.run_command = lambda x: (0, '', '')
    module.get_bin_path = lambda x: '/bin/ip'
    module.get_file_content = lambda x: '00:00:00:00:00:00'
    linux_network = LinuxNetwork(module)
    result = linux_network.populate()
    assert result['default_ipv4']['address'] == '127.0.0.1'
    assert result['default_ipv6']['address'] == '::1'
    assert result['interfaces']['lo']['type'] == 'loopback'

# Generated at 2022-06-17 01:13:39.573519
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'gather_subset': [],
        'gather_network_resources': 'yes',
    }
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.facts['interfaces']
    assert ln.facts['default_ipv4']
    assert ln.facts['default_ipv6']
    assert ln.facts['all_ipv4_addresses']
    assert ln.facts['all_ipv6_addresses']
    assert ln.facts['ipv4']
    assert ln.facts['ipv6']
    assert ln.facts['gateway4']
    assert ln.facts['gateway6']
