

# Generated at 2022-06-17 01:04:17.371237
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.gateway_ipv4
    assert ln.gateway_ipv6
    assert ln.ips


# Generated at 2022-06-17 01:04:24.772743
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.get_file_content = MagicMock(return_value=True)
    module.get_default_interfaces = LinuxNetwork(module).get_default_interfaces()
    assert module.run_command.called
    assert module.get_bin_path.called
    assert module.get_file_content.called


# Generated at 2022-06-17 01:04:37.735637
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)

# Generated at 2022-06-17 01:04:39.916141
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips


# Generated at 2022-06-17 01:04:48.124913
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    linux_network = LinuxNetwork(module)
    linux_network.populate()
    assert linux_network.interfaces
    assert linux_network.default_ipv4
    assert linux_network.default_ipv6
    assert linux_network.ips
    assert linux_network.gateways


# Generated at 2022-06-17 01:04:58.052034
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Test with a real device
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    device = 'eth0'
    data = linux_network.get_ethtool_data(device)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data
    assert isinstance(data['phc_index'], int)

    # Test with a fake device
    device = 'fake0'
    data = linux_network.get_ethtool_data(device)
    assert 'features' not in data
    assert 'timestamping' not in data
    assert 'hw_timestamp_filters' not in data
    assert 'phc_index' not in data



# Generated at 2022-06-17 01:04:59.862405
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-17 01:05:11.481312
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

    # Test with empty interfaces
    interfaces = {}
    ips = {}
    default_ipv4 = {}
    default_ipv6 = {}
    ln.populate(interfaces, ips, default_ipv4, default_ipv6)
    assert interfaces == {}
    assert ips == {}
    assert default_ipv4 == {}
    assert default_ipv6 == {}

    # Test with one interface
    interfaces = {'eth0': {'device': 'eth0', 'macaddress': '00:00:00:00:00:00', 'mtu': 1500, 'type': 'ethernet', 'active': True, 'module': 'e1000'}}
    ips = {}

# Generated at 2022-06-17 01:05:20.080438
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    interfaces, ips = ln.get_interfaces_info(None, {}, {})
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'ipv4' in interfaces['lo']
    assert 'ipv4' in interfaces['lo']
    assert 'address' in interfaces['lo']['ipv4']
    assert 'address' in interfaces['lo']['ipv4']
    assert 'netmask' in interfaces['lo']['ipv4']
    assert 'netmask' in interfaces['lo']['ipv4']
    assert 'network' in interfaces['lo']['ipv4']
    assert 'network' in interfaces['lo']['ipv4']
    assert 'ipv6'

# Generated at 2022-06-17 01:05:25.216461
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.ips


# Generated at 2022-06-17 01:06:07.266482
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    device = 'eth0'
    data = linux_network.get_ethtool_data(device)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data

# Generated at 2022-06-17 01:06:15.608400
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """
    Test the constructor of LinuxNetworkCollector
    """
    # Test with a module
    module = AnsibleModule(argument_spec={})
    collector = LinuxNetworkCollector(module)
    assert collector.module == module
    assert collector.facts == {}
    assert collector.platform == 'Linux'
    assert collector.fact_class == LinuxNetwork
    assert collector.required_facts == set(['distribution', 'platform'])
    assert collector.network_provider is None


# Generated at 2022-06-17 01:06:19.714843
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.all_ipv4_addresses
    assert ln.all_ipv6_addresses
    assert ln.default_ipv4_interface
    assert ln.default_ipv6_interface


# Generated at 2022-06-17 01:06:20.765299
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-17 01:06:31.628930
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)

# Generated at 2022-06-17 01:06:42.602714
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            gather_network_resources=dict(default=['all'], type='list'),
        ),
        supports_check_mode=True,
    )
    nm = LinuxNetwork(module)
    nm.populate()
    result = nm.data
    assert result['default_ipv4']['address'] == '192.168.1.2'
    assert result['default_ipv4']['netmask'] == '255.255.255.0'
    assert result['default_ipv4']['network'] == '192.168.1.0'
    assert result['default_ipv4']['broadcast'] == '192.168.1.255'

# Generated at 2022-06-17 01:06:51.265305
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

# Generated at 2022-06-17 01:06:59.700497
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    v4, v6 = ln.get_default_interfaces()
    assert isinstance(v4, dict)
    assert isinstance(v6, dict)
    assert 'address' in v4
    assert 'address' in v6
    assert 'gateway' in v4
    assert 'gateway' in v6
    assert 'interface' in v4
    assert 'interface' in v6


# Generated at 2022-06-17 01:07:07.348939
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips
    assert ln.gateways


# Generated at 2022-06-17 01:07:15.936912
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address'] == '192.168.0.1'
    assert ln.default_ipv4['netmask'] == '255.255.255.0'
    assert ln.default_ipv4['network'] == '192.168.0.0'
    assert ln.default_ipv4['broadcast'] == '192.168.0.255'
    assert ln.default_ipv6['address'] == 'fe80::1'
    assert ln.default_ipv6['prefix'] == '64'
    assert ln.default_ipv6['scope'] == 'link'

# Generated at 2022-06-17 01:07:57.350513
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: mock out the module
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    # TODO: mock out the output of get_interfaces_info
    interfaces, ips = ln.get_interfaces_info(None, None, None)
    assert isinstance(interfaces, dict)
    assert isinstance(ips, dict)
    assert 'all_ipv4_addresses' in ips
    assert 'all_ipv6_addresses' in ips
    # TODO: assert that the output is correct


# Generated at 2022-06-17 01:08:03.439358
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    # FIXME: this is a terrible test
    assert ln.get_default_interfaces() == ({}, {})


# Generated at 2022-06-17 01:08:10.539320
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address']
    assert default_ipv6['address']


# Generated at 2022-06-17 01:08:18.376306
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: x
    module.run_command = lambda x, **kwargs: (0, '', '')
    ln = LinuxNetwork(module)
    default_ipv4 = {'address': '192.168.1.1'}
    default_ipv6 = {'address': 'fe80::1'}
    interfaces, ips = ln.get_interfaces_info('ip', default_ipv4, default_ipv6)
    assert interfaces['eth0']['ipv4']['address'] == '192.168.1.1'
    assert interfaces['eth0']['ipv6'][0]['address'] == 'fe80::1'

# Generated at 2022-06-17 01:08:29.029345
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.exit_json = lambda x: x
    module.run_command = lambda x, **kwargs: (0, '', '')
    module.get_bin_path = lambda x: '/bin/ip'
    network = LinuxNetwork(module)

    # Test with no interfaces
    interfaces, ips = network.get_interfaces_info('/bin/ip', {}, {})
    assert interfaces == {}
    assert ips == dict(all_ipv4_addresses=[], all_ipv6_addresses=[])

    # Test with one interface

# Generated at 2022-06-17 01:08:35.406259
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json

    # FIXME: this is a stub, we need to mock the module.run_command()
    #        method and return a canned response
    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data("eth0") == {}



# Generated at 2022-06-17 01:08:47.216292
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.default_interface_ipv4
    assert ln.default_interface_ipv6
    assert ln.default_interface_name
    assert ln.default_interface
    assert ln.default_gateway_ipv4
    assert ln.default_gateway_ipv6
    assert ln.default_gateway_interface_ipv4
    assert ln.default_gateway_interface_ipv6
    assert ln.default_gateway_interface_name
    assert ln.default_gateway_interface
    assert ln.ips

# Generated at 2022-06-17 01:08:51.812475
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """
    Test method get_ethtool_data of class LinuxNetwork
    """
    # FIXME: this is a stub
    # assert False, "Test if this is really a unit test"
    # assert True, "Test if this is really a unit test"

# Generated at 2022-06-17 01:08:53.267423
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-17 01:09:02.403550
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'gather_subset': ['all'],
        'gather_network_resources': ['all'],
    }
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='')
    module.get_file_content = MagicMock(return_value='')
    module.get_file_lines = MagicMock(return_value=[])
    module.get_file_size = MagicMock(return_value=0)
    module.get_mount_size = MagicMock(return_value=0)
    module.get_mount_options = MagicMock(return_value=[])
    module.get_mount_attributes

# Generated at 2022-06-17 01:09:52.461324
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    module.run_command = MagicMock(return_value=(0, '', ''))
    network = LinuxNetwork(module)
    assert network.get_ethtool_data('eth0') == {}
    module.run_command.assert_called_once_with(['ethtool', '-k', 'eth0'], errors='surrogate_then_replace')
    module.run_command.reset_mock()

# Generated at 2022-06-17 01:10:04.851756
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.get_file_content = MagicMock(return_value=True)
    module.get_file_content = MagicMock(return_value=True)
    module.get_file_content = MagicMock(return_value=True)
    module.get_file_content = MagicMock(return_value=True)
    module.get_file_content = MagicMock(return_value=True)
    module.get_file_content = MagicMock(return_value=True)
    module.get_file_content = MagicMock(return_value=True)
    module.get

# Generated at 2022-06-17 01:10:08.992018
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address']
    assert ln.default_ipv6['address']
    assert ln.interfaces
    assert ln.ips


# Generated at 2022-06-17 01:10:18.290283
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address'] == '127.0.0.1'
    assert ln.default_ipv6['address'] == '::1'
    assert ln.interfaces['lo']['ipv4']['address'] == '127.0.0.1'
    assert ln.interfaces['lo']['ipv6'][0]['address'] == '::1'
    assert ln.interfaces['lo']['ipv6'][0]['prefix'] == '128'
    assert ln.interfaces['lo']['ipv6'][0]['scope'] == 'host'

# Generated at 2022-06-17 01:10:26.542610
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {'gather_subset': ['all']}
    ln = LinuxNetwork(module)
    ln.populate()
    assert 'default_ipv4' in ln.facts
    assert 'default_ipv6' in ln.facts
    assert 'interfaces' in ln.facts
    assert 'all_ipv4_addresses' in ln.facts['ips']
    assert 'all_ipv6_addresses' in ln.facts['ips']


# Generated at 2022-06-17 01:10:35.785497
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    linux_network = LinuxNetwork(module)
    interfaces = linux_network.get_interfaces_info(None, None, None)
    assert isinstance(interfaces, dict)
    assert len(interfaces) > 0
    for interface in interfaces:
        assert isinstance(interface, str)
        assert isinstance(interfaces[interface], dict)
        assert len(interfaces[interface]) > 0
        for key in interfaces[interface]:
            assert isinstance(key, str)
            assert isinstance(interfaces[interface][key], (str, int, bool))


# Generated at 2022-06-17 01:10:46.208736
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            filter=dict(default=None, type='list'),
        ),
        supports_check_mode=True,
    )
    network = LinuxNetwork(module)
    network.populate()
    result = network.data
    assert result['default_ipv4']['address'] == '192.168.1.1'
    assert result['default_ipv4']['broadcast'] == '192.168.1.255'
    assert result['default_ipv4']['netmask'] == '255.255.255.0'
    assert result['default_ipv4']['network'] == '192.168.1.0'

# Generated at 2022-06-17 01:10:55.505442
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/sbin/ip')
    ln = LinuxNetwork(module)
    ln.get_default_interfaces()
    module.run_command.assert_called_with(['/sbin/ip', 'route', 'get', '8.8.8.8'], errors='surrogate_then_replace')


# Generated at 2022-06-17 01:11:04.515250
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4 = {'address': '192.168.1.1'}
    default_ipv6 = {'address': 'fe80::1'}
    interfaces, ips = ln.get_interfaces_info('/sbin/ip', default_ipv4, default_ipv6)
    assert interfaces['lo']['ipv4']['address'] == '127.0.0.1'
    assert interfaces['lo']['ipv4']['netmask'] == '255.0.0.0'
    assert interfaces['lo']['ipv4']['network'] == '127.0.0.0'
    assert interfaces['lo']['ipv6'][0]['address']

# Generated at 2022-06-17 01:11:11.733046
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)


# Generated at 2022-06-17 01:11:58.250365
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: write this
    pass


# Generated at 2022-06-17 01:12:02.440739
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = LinuxNetworkCollector(module)
    assert collector.platform == 'Linux'
    assert collector.fact_class == LinuxNetwork
    assert collector.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-17 01:12:12.093305
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-17 01:12:23.375080
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4 = {'address': '192.168.1.1'}
    default_ipv6 = {'address': 'fe80::1'}
    interfaces, ips = ln.get_interfaces_info('/sbin/ip', default_ipv4, default_ipv6)
    assert 'lo' in interfaces
    assert 'eth0' in interfaces
    assert 'eth1' in interfaces
    assert 'eth2' in interfaces
    assert 'eth3' in interfaces
    assert 'eth4' in interfaces
    assert 'eth5' in interfaces
    assert 'eth6' in interfaces
    assert 'eth7' in interfaces
    assert 'eth8' in interfaces
    assert 'eth9' in interfaces

# Generated at 2022-06-17 01:12:27.031697
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    default_ipv4, default_ipv6 = linux_network.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)


# Generated at 2022-06-17 01:12:33.367185
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = LinuxNetworkCollector(module)
    assert collector.platform == 'Linux'
    assert collector.fact_class == LinuxNetwork
    assert collector.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-17 01:12:38.034149
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    # FIXME: this is a bit of a hack to get the test to work
    ln.module.run_command = lambda x: (0, '', '')
    assert ln.get_ethtool_data('eth0') == {}



# Generated at 2022-06-17 01:12:39.427250
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-17 01:12:43.706339
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address'] == '192.168.1.1'
    assert default_ipv6['address'] == 'fe80::5054:ff:fe12:3456'


# Generated at 2022-06-17 01:12:50.567812
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.ipv4
    assert ln.ipv6
    assert ln.gateway4
    assert ln.gateway6


# Generated at 2022-06-17 01:13:30.280197
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    device = "eth0"
    data = ln.get_ethtool_data(device)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data


# Generated at 2022-06-17 01:13:36.183826
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    default_ipv4, default_ipv6 = linux_network.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)


# Generated at 2022-06-17 01:13:47.109234
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.params = {'gather_subset': ['all']}
    module.exit_json = lambda x: x
    module.run_command = lambda x, **kwargs: (0, '', '')
    module.get_bin_path = lambda x: x
    module.get_file_content = lambda x: x
    module.get_file_lines = lambda x: x
    module.get_file_size = lambda x: x
    module.get_file_stat = lambda x: x
    module.get_file_type = lambda x: x
    module.get_mount_size = lambda x: x
    module.get_mount_options = lambda x: x
    module.get_mount_path = lambda x: x
    module.get_mount_uu