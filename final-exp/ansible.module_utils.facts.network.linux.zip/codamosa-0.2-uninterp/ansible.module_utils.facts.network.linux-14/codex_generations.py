

# Generated at 2022-06-17 01:04:15.575024
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: implement this unit test
    # NOTE: this is a stub
    pass


# Generated at 2022-06-17 01:04:23.691634
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)
    assert 'address' in default_ipv4
    assert 'address' in default_ipv6
    assert 'gateway' in default_ipv4
    assert 'gateway' in default_ipv6
    assert 'interface' in default_ipv4
    assert 'interface' in default_ipv6


# Generated at 2022-06-17 01:04:33.585358
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:04:38.942329
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)


# Generated at 2022-06-17 01:04:46.963800
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Test with a device that has ethtool features
    module = AnsibleModule(argument_spec=dict())
    module.params = dict(
        device='eth0',
    )
    ln = LinuxNetwork(module)
    data = ln.get_ethtool_data('eth0')
    assert data['features']['rx_checksumming'] == 'on'
    assert data['features']['tx_checksumming'] == 'on'
    assert data['features']['scatter_gather'] == 'on'
    assert data['features']['tcp_segmentation_offload'] == 'on'
    assert data['features']['udp_fragmentation_offload'] == 'on'
    assert data['features']['generic_segmentation_offload'] == 'on'
    assert data

# Generated at 2022-06-17 01:04:52.842130
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    interfaces, ips = ln.get_interfaces_info(None, None, None)
    assert isinstance(interfaces, dict)
    assert isinstance(ips, dict)
    assert 'all_ipv4_addresses' in ips
    assert 'all_ipv6_addresses' in ips



# Generated at 2022-06-17 01:05:03.759932
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    device = 'lo'
    data = linux_network.get_ethtool_data(device)

# Generated at 2022-06-17 01:05:06.388511
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data('eth0') == {}


# Generated at 2022-06-17 01:05:17.569170
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda x: x
    network = LinuxNetwork(module)
    interfaces, ips = network.get_interfaces_info(None, {}, {})
    assert isinstance(interfaces, dict)
    assert isinstance(ips, dict)
    assert 'all_ipv4_addresses' in ips
    assert 'all_ipv6_addresses' in ips
    assert isinstance(ips['all_ipv4_addresses'], list)
    assert isinstance(ips['all_ipv6_addresses'], list)
    for interface in interfaces.values():
        assert isinstance(interface, dict)
        assert 'device' in interface
        assert 'type' in interface

# Generated at 2022-06-17 01:05:26.033551
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert 'default_ipv4' in ln.facts
    assert 'default_ipv6' in ln.facts
    assert 'interfaces' in ln.facts
    assert 'all_ipv4_addresses' in ln.facts['ipv4']
    assert 'all_ipv6_addresses' in ln.facts['ipv6']
    assert 'default_ipv4' in ln.facts
    assert 'default_ipv6' in ln.facts
    assert 'interfaces' in ln.facts
    assert 'all_ipv4_addresses' in ln.facts['ipv4']
    assert 'all_ipv6_addresses' in ln

# Generated at 2022-06-17 01:06:09.781508
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.ips


# Generated at 2022-06-17 01:06:18.907389
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    # Test with empty output
    rc, out, err = module.run_command('ip route show', errors='surrogate_then_replace')
    assert linux_network.get_default_interfaces(out) == (None, None)
    # Test with v4 output
    rc, out, err = module.run_command('ip route show', errors='surrogate_then_replace')
    assert linux_network.get_default_interfaces(out) == (None, None)
    # Test with v6 output
    rc, out, err = module.run_command('ip -6 route show', errors='surrogate_then_replace')
    assert linux_network.get_default_interfaces(out) == (None, None)


# Generated at 2022-06-17 01:06:21.583982
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.get_default_interfaces()
    assert ln.default_ipv4['address'] == '192.168.1.1'
    assert ln.default_ipv6['address'] == 'fe80::1'


# Generated at 2022-06-17 01:06:25.899362
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    linux_network = LinuxNetwork(module)
    linux_network.get_ethtool_data('eth0')


# Generated at 2022-06-17 01:06:35.323508
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address'] == '192.168.1.1'
    assert ln.default_ipv4['netmask'] == '255.255.255.0'
    assert ln.default_ipv4['network'] == '192.168.1.0'
    assert ln.default_ipv4['broadcast'] == '192.168.1.255'
    assert ln.default_ipv4['macaddress'] == '00:0c:29:8c:11:b1'
    assert ln.default_ipv4['mtu'] == 1500
    assert ln.default_ipv4['type'] == 'ether'
    assert l

# Generated at 2022-06-17 01:06:41.452836
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # FIXME: this is a stub
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )
    ln = LinuxNetwork(module)
    # FIXME: this is a stub
    assert ln.get_interfaces_info(None, None, None) == (None, None)


# Generated at 2022-06-17 01:06:47.754424
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/usr/sbin/ethtool')
    network = LinuxNetwork(module)
    assert network.get_ethtool_data('eth0') == {}
    module.run_command.assert_called_with(['/usr/sbin/ethtool', '-k', 'eth0'], errors='surrogate_then_replace')
    module.run_command.reset_mock()

# Generated at 2022-06-17 01:06:59.939858
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:07:03.342209
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)


# Generated at 2022-06-17 01:07:11.554038
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.default_interface_ipv4
    assert ln.default_interface_ipv6
    assert ln.default_interface
    assert ln.default_gateway_ipv4
    assert ln.default_gateway_ipv6
    assert ln.default_gateway
    assert ln.gateways
    assert ln.ips


# Generated at 2022-06-17 01:07:57.196534
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda x: x
    module.get_bin_path = lambda x: x
    module.run_command = lambda x, **kwargs: (0, '', '')
    module.params = {}
    linux_network = LinuxNetwork(module)
    interfaces, ips = linux_network.get_interfaces_info('ip', {}, {})
    assert interfaces == {}
    assert ips == {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}



# Generated at 2022-06-17 01:08:04.485525
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:08:12.750161
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/usr/bin/ethtool')
    linux_network = LinuxNetwork(module)
    assert linux_network.get_ethtool_data('eth0') == {'features': {}, 'timestamping': [], 'hw_timestamp_filters': []}

# Generated at 2022-06-17 01:08:23.357415
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    device = 'eth0'
    ethtool_path = module.get_bin_path("ethtool")
    args = [ethtool_path, '-k', device]
    rc, stdout, stderr = module.run_command(args, errors='surrogate_then_replace')
    if rc == 0:
        features = {}
        for line in stdout.strip().splitlines():
            if not line or line.endswith(":"):
                continue
            key, value = line.split(": ")
            if not value:
                continue
            features[key.strip().replace('-', '_')] = value.strip()
        data = linux_network.get_ethtool_data(device)

# Generated at 2022-06-17 01:08:27.141402
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    assert linux_network.get_ethtool_data('eth0') == {}



# Generated at 2022-06-17 01:08:31.486436
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-17 01:08:38.390446
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address'] == '192.168.1.1'
    assert ln.default_ipv6['address'] == 'fe80::5054:ff:fe12:3456'
    assert ln.interfaces['eth0']['ipv4']['address'] == '192.168.1.1'
    assert ln.interfaces['eth0']['ipv6'][0]['address'] == 'fe80::5054:ff:fe12:3456'
    assert ln.interfaces['eth0']['ipv6'][1]['address'] == '2001:db8:1::1'
    assert ln.interfaces

# Generated at 2022-06-17 01:08:49.243603
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address'] == '192.168.1.1'
    assert ln.default_ipv4['netmask'] == '255.255.255.0'
    assert ln.default_ipv4['network'] == '192.168.1.0'
    assert ln.default_ipv4['broadcast'] == '192.168.1.255'
    assert ln.default_ipv4['macaddress'] == '00:0c:29:8c:11:b1'
    assert ln.default_ipv4['mtu'] == 1500
    assert ln.default_ipv4['type'] == 'ether'
    assert l

# Generated at 2022-06-17 01:08:54.141883
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips


# Generated at 2022-06-17 01:09:03.238339
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            gather_network_resources=dict(default=['all'], type='list'),
        ),
        supports_check_mode=True,
    )

    # Create a Network object
    network = LinuxNetwork(module)

    # Run the populate method
    network.populate()

    # Test the result
    assert network.interfaces is not None
    assert network.default_ipv4 is not None
    assert network.default_ipv6 is not None
    assert network.all_ipv4_addresses is not None
    assert network.all_ipv6_addresses is not None
    assert network.gateway is not None
    assert network.gateway6 is not None

# Generated at 2022-06-17 01:09:48.940083
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: implement
    pass


# Generated at 2022-06-17 01:09:51.246260
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    assert linux_network.get_ethtool_data('eth0') == {}


# Generated at 2022-06-17 01:10:03.490507
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: "/usr/bin/{}".format(x)
    module.run_command = lambda x, **kwargs: (0, "", "")
    network = LinuxNetwork(module)
    assert network.get_ethtool_data("eth0") == {
        "features": {},
        "timestamping": [],
        "hw_timestamp_filters": [],
    }

# Generated at 2022-06-17 01:10:13.887735
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4 = {'address': '192.168.1.1'}
    default_ipv6 = {'address': '2001:db8::1'}
    interfaces, ips = ln.get_interfaces_info('/sbin/ip', default_ipv4, default_ipv6)
    assert interfaces['lo']['ipv4']['address'] == '127.0.0.1'
    assert interfaces['lo']['ipv4']['netmask'] == '255.0.0.0'
    assert interfaces['lo']['ipv4']['network'] == '127.0.0.0'

# Generated at 2022-06-17 01:10:18.097717
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.gateways
    assert ln.ips


# Generated at 2022-06-17 01:10:29.096211
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    device = 'eth0'
    ethtool_path = module.get_bin_path("ethtool")
    if ethtool_path:
        args = [ethtool_path, '-k', device]
        rc, stdout, stderr = module.run_command(args, errors='surrogate_then_replace')
        if rc == 0:
            features = {}
            for line in stdout.strip().splitlines():
                if not line or line.endswith(":"):
                    continue
                key, value = line.split(": ")
                if not value:
                    continue
                features[key.strip().replace('-', '_')] = value.strip()
            assert features == linux_network.get_eth

# Generated at 2022-06-17 01:10:33.087153
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips


# Generated at 2022-06-17 01:10:44.763907
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data('eth0') == {}
    module.run_command.assert_called_once_with(['ethtool', '-k', 'eth0'], errors='surrogate_then_replace')

    module.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-17 01:10:57.450641
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4 = {'address': '192.168.1.1'}
    default_ipv6 = {'address': '2001:db8::1'}
    interfaces, ips = ln.get_interfaces_info('/sbin/ip', default_ipv4, default_ipv6)
    assert interfaces['eth0']['ipv4']['address'] == '192.168.1.1'
    assert interfaces['eth0']['ipv4']['broadcast'] == '192.168.1.255'
    assert interfaces['eth0']['ipv4']['netmask'] == '255.255.255.0'

# Generated at 2022-06-17 01:11:05.477230
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    device = 'eth0'
    data = ln.get_ethtool_data(device)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data


# Generated at 2022-06-17 01:12:04.885682
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/bin/ethtool')
    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data('eth0') == {}

# Generated at 2022-06-17 01:12:11.573644
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    device = 'eth0'
    data = ln.get_ethtool_data(device)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data


# Generated at 2022-06-17 01:12:22.971947
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address'] == '192.168.1.1'
    assert default_ipv4['netmask'] == '255.255.255.0'
    assert default_ipv4['network'] == '192.168.1.0'
    assert default_ipv4['broadcast'] == '192.168.1.255'
    assert default_ipv4['macaddress'] == '00:0c:29:8c:11:b1'
    assert default_ipv4['mtu'] == 1500
    assert default_ipv4['type'] == 'unknown'

# Generated at 2022-06-17 01:12:28.953546
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address']
    assert ln.default_ipv6['address']
    assert ln.interfaces
    assert ln.ips


# Generated at 2022-06-17 01:12:33.940576
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    device = 'lo'
    data = linux_network.get_ethtool_data(device)
    assert data == {}


# Generated at 2022-06-17 01:12:42.107044
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address'] == '127.0.0.1'
    assert default_ipv4['netmask'] == '255.0.0.0'
    assert default_ipv4['network'] == '127.0.0.0'
    assert default_ipv6['address'] == '::1'
    assert default_ipv6['prefix'] == '128'
    assert default_ipv6['scope'] == 'host'


# Generated at 2022-06-17 01:12:55.110670
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=None)
    module.params = {}

    # Mock the glob.glob function

# Generated at 2022-06-17 01:13:03.580081
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Test with a module
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    # Test with a network object
    network = LinuxNetwork(module)
    # Test with a network object
    network.populate()
    # Test with a network object
    assert network.interfaces
    # Test with a network object
    assert network.default_ipv4
    # Test with a network object
    assert network.default_ipv6
    # Test with a network object
    assert network.default_interface
    # Test with a network object
    assert network.default_gateway_ipv4
    # Test with a network object
    assert network.default_gateway_ipv6
    # Test with a network object
    assert network.gateway_interface_ipv4
    #

# Generated at 2022-06-17 01:13:05.832040
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = LinuxNetworkCollector(module)
    assert collector.platform == 'Linux'
    assert collector.fact_class == LinuxNetwork
    assert collector.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-17 01:13:11.890030
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address']
    assert ln.default_ipv6['address']
    assert ln.interfaces
    assert ln.ips
