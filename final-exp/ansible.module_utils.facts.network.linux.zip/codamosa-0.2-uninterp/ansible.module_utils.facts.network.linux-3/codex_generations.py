

# Generated at 2022-06-17 01:04:19.571545
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert 'default_ipv4' in ln.facts
    assert 'default_ipv6' in ln.facts
    assert 'interfaces' in ln.facts
    assert 'all_ipv4_addresses' in ln.facts['interfaces']
    assert 'all_ipv6_addresses' in ln.facts['interfaces']
    assert 'ipv4' in ln.facts['interfaces']['lo']
    assert 'ipv6' in ln.facts['interfaces']['lo']
    assert 'address' in ln.facts['interfaces']['lo']['ipv4']

# Generated at 2022-06-17 01:04:21.066511
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # TODO: this is a stub
    pass


# Generated at 2022-06-17 01:04:22.860597
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-17 01:04:28.127455
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    default_ipv4, default_ipv6 = linux_network.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)


# Generated at 2022-06-17 01:04:30.579304
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: this is a stub
    pass


# Generated at 2022-06-17 01:04:37.025927
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.gateway_ipv4
    assert ln.gateway_ipv6
    assert ln.ips


# Generated at 2022-06-17 01:04:39.752007
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)


# Generated at 2022-06-17 01:04:52.261305
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address'] == '192.168.1.1'
    assert ln.default_ipv4['netmask'] == '255.255.255.0'
    assert ln.default_ipv4['network'] == '192.168.1.0'
    assert ln.default_ipv4['broadcast'] == '192.168.1.255'
    assert ln.default_ipv4['macaddress'] == '00:0c:29:8c:11:b1'
    assert ln.default_ipv4['mtu'] == 1500
    assert ln.default_ipv4['type'] == 'ether'
    assert l

# Generated at 2022-06-17 01:04:58.116310
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    default_ipv4, default_ipv6 = linux_network.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)


# Generated at 2022-06-17 01:05:09.805327
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    device = 'eth0'
    data = linux_network.get_ethtool_data(device)
    assert data['features']['tx_checksumming'] == 'on'
    assert data['features']['rx_checksumming'] == 'on'
    assert data['features']['scatter_gather'] == 'on'
    assert data['features']['tcp_segmentation_offload'] == 'on'
    assert data['features']['udp_fragmentation_offload'] == 'off'
    assert data['features']['generic_segmentation_offload'] == 'on'
    assert data['features']['generic_receive_offload'] == 'on'

# Generated at 2022-06-17 01:05:41.115703
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.gateway_ipv4
    assert ln.gateway_ipv6
    assert ln.ips


# Generated at 2022-06-17 01:05:47.620007
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'gather_subset': ['all'],
        'gather_network_resources': ['all'],
    }
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.facts['default_ipv4']['address'] == '127.0.0.1'
    assert ln.facts['default_ipv4']['netmask'] == '255.0.0.0'
    assert ln.facts['default_ipv4']['network'] == '127.0.0.0'
    assert ln.facts['default_ipv4']['broadcast'] == '127.255.255.255'
    assert ln.facts['default_ipv6']['address']

# Generated at 2022-06-17 01:05:57.004693
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Test for method get_interfaces_info(self, ip_path, default_ipv4, default_ipv6)
    # of class LinuxNetwork
    module = AnsibleModule(
        argument_spec=dict(
            ip_path=dict(type='str', default='ip'),
            default_ipv4=dict(type='dict', default={}),
            default_ipv6=dict(type='dict', default={}),
        ),
        supports_check_mode=True,
    )
    ip_path = module.params['ip_path']
    default_ipv4 = module.params['default_ipv4']
    default_ipv6 = module.params['default_ipv6']
    linux_network = LinuxNetwork(module)
    interfaces, ips = linux_network.get_interfaces_info

# Generated at 2022-06-17 01:06:03.711897
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address'] == '192.168.1.1'
    assert ln.default_ipv6['address'] == 'fe80::1'
    assert ln.interfaces['eth0']['ipv4']['address'] == '192.168.1.1'
    assert ln.interfaces['eth0']['ipv6'][0]['address'] == 'fe80::1'
    assert ln.interfaces['eth0']['ipv6'][1]['address'] == '2001:db8::1'

# Generated at 2022-06-17 01:06:11.060283
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/sbin/ip')
    ln = LinuxNetwork(module)
    ln.get_default_interfaces()
    module.run_command.assert_called_with(['/sbin/ip', 'route', 'get', '8.8.8.8'], errors='surrogate_then_replace')


# Generated at 2022-06-17 01:06:19.163445
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: mock out the module
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)
    module.get_file_content = MagicMock(return_value=True)
    module.get_default_ipv4 = MagicMock(return_value={})
    module.get_default_ipv6 = MagicMock(return_value={})
    module.get_default_route = MagicMock(return_value={})
    module.get_default_route6 = MagicMock(return_value={})
    module.get_default_gateway = MagicMock(return_value={})
    module.get_default_gateway6 = MagicM

# Generated at 2022-06-17 01:06:30.409924
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

# Generated at 2022-06-17 01:06:41.373862
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:06:46.663601
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address'] == '192.168.1.1'
    assert default_ipv6['address'] == 'fe80::1'


# Generated at 2022-06-17 01:06:59.286267
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Test with a valid device
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/usr/bin/ethtool')
    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data('eth0') == {'features': {}, 'timestamping': [], 'hw_timestamp_filters': []}
    # Test with an invalid device
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(1, '', ''))
    module.get_bin_path = MagicMock(return_value='/usr/bin/ethtool')
    ln = LinuxNetwork(module)


# Generated at 2022-06-17 01:07:35.359793
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = LinuxNetworkCollector(module)
    assert collector.platform == 'Linux'
    assert collector.fact_class == LinuxNetwork
    assert collector.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-17 01:07:45.137309
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4 = {}
    default_ipv6 = {}
    interfaces, ips = ln.get_interfaces_info('/sbin/ip', default_ipv4, default_ipv6)
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'lo' in interfaces

# Generated at 2022-06-17 01:07:53.955969
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    linux_network = LinuxNetwork(module)
    device = 'eth0'
    data = linux_network.get_ethtool_data(device)
    assert data['features']['rx_checksumming'] == 'on'
    assert data['features']['tx_checksumming'] == 'on'
    assert data['features']['scatter_gather'] == 'on'
    assert data['features']['tcp_segmentation_offload'] == 'on'
    assert data['features']['udp_fragmentation_offload'] == 'off'
    assert data['features']['generic_segmentation_offload'] == 'on'
    assert data

# Generated at 2022-06-17 01:08:03.185200
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Test with a valid device
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/bin/ethtool')
    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data('eth0') == {}

    # Test with a valid device and valid output
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-17 01:08:15.528971
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='')
    module.params = {}

    # FIXME: this is a hack to get around the fact that we can't mock the
    #        constructor
    module.params['ansible_facts'] = dict(
        default_ipv4=dict(address='192.168.1.1'),
        default_ipv6=dict(address='2001:db8::1'),
    )

    # FIXME: this is a hack to get around the fact that we can't mock the
    #        constructor

# Generated at 2022-06-17 01:08:26.725734
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda x: x
    linux_network = LinuxNetwork(module)
    interfaces, ips = linux_network.get_interfaces_info(
        ip_path='/bin/ip',
        default_ipv4={'address': '192.168.1.1'},
        default_ipv6={'address': 'fe80::1'},
    )
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert 'ipv4' in interfaces['lo']
    assert 'ipv6' in interfaces['lo']
    assert 'all_ipv4_addresses' in ips
    assert 'all_ipv6_addresses' in ips

# Generated at 2022-06-17 01:08:29.416573
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips
    assert ln.gateways


# Generated at 2022-06-17 01:08:34.450824
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address']
    assert default_ipv6['address']


# Generated at 2022-06-17 01:08:38.198067
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.ip_path is not None
    assert ln.default_ipv4 is not None
    assert ln.default_ipv6 is not None
    assert ln.interfaces is not None
    assert ln.ips is not None


# Generated at 2022-06-17 01:08:44.298531
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='')
    ln = LinuxNetwork(module)
    assert ln.get_interfaces_info(None, None, None) == ({}, {'all_ipv4_addresses': [], 'all_ipv6_addresses': []})



# Generated at 2022-06-17 01:09:29.475093
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips


# Generated at 2022-06-17 01:09:39.917588
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:09:48.368353
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4 = {'address': '192.168.0.1'}
    default_ipv6 = {'address': '2001:db8::1'}
    interfaces, ips = ln.get_interfaces_info('/sbin/ip', default_ipv4, default_ipv6)
    assert interfaces['eth0']['ipv4']['address'] == '192.168.0.1'
    assert interfaces['eth0']['ipv4']['broadcast'] == '192.168.0.255'
    assert interfaces['eth0']['ipv4']['netmask'] == '255.255.255.0'

# Generated at 2022-06-17 01:09:54.688557
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    network = LinuxNetwork(module)
    assert network.get_ethtool_data('eth0') == {}

# Generated at 2022-06-17 01:10:06.310537
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    device = "eth0"
    ethtool_path = linux_network.module.get_bin_path("ethtool")
    if ethtool_path:
        args = [ethtool_path, '-k', device]
        rc, stdout, stderr = linux_network.module.run_command(args, errors='surrogate_then_replace')
        if rc == 0:
            features = {}
            for line in stdout.strip().splitlines():
                if not line or line.endswith(":"):
                    continue
                key, value = line.split(": ")
                if not value:
                    continue
                features[key.strip().replace('-', '_')] = value.strip()
            assert features

# Generated at 2022-06-17 01:10:17.922771
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:10:28.109521
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    device = "eth0"
    data = ln.get_ethtool_data(device)
    assert data['features']['rx_all'] == 'off'
    assert data['features']['tx_udp_tnl_csum_segmentation'] == 'off'
    assert data['timestamping'] == ['hardware', 'software', 'tx_hardware', 'tx_software']
    assert data['hw_timestamp_filters'] == ['all', 'none', 'sync', 'pdelay_req', 'pdelay_resp']
    assert data['phc_index'] == 0


# Generated at 2022-06-17 01:10:31.413737
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, "", ""))
    module.get_bin_path = MagicMock(return_value="/bin/ip")
    module.get_file_content = MagicMock(return_value="")
    ln = LinuxNetwork(module)
    ln.get_interfaces_info("/bin/ip", {}, {})


# Generated at 2022-06-17 01:10:43.151154
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            gather_network_resources=dict(default=['all'], type='list'),
        ),
        supports_check_mode=True,
    )
    nm = LinuxNetwork(module)
    nm.populate()
    result = nm.get_network_resources()
    assert result['default_ipv4']['address'] == '192.168.1.1'
    assert result['default_ipv6']['address'] == 'fe80::1'
    assert result['interfaces']['eth0']['ipv4']['address'] == '192.168.1.1'

# Generated at 2022-06-17 01:10:55.409924
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/sbin/ip')
    module.get_file_content = MagicMock(return_value='')
    module.get_file_lines = MagicMock(return_value=[])
    module.get_file_size = MagicMock(return_value=0)
    module.get_mount_size = MagicMock(return_value=0)
    module.get_mount_options = MagicMock(return_value='')
    module.get_mount_status = MagicMock(return_value='')
    module.get_mount

# Generated at 2022-06-17 01:11:42.798499
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # FIXME: this is a stub
    pass


# Generated at 2022-06-17 01:11:52.160932
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-17 01:11:56.704199
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    obj = LinuxNetwork(module)
    device = 'eth0'
    data = obj.get_ethtool_data(device)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data


# Generated at 2022-06-17 01:12:05.609791
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4['address'] == '192.168.1.2'
    assert ln.default_ipv6['address'] == 'fe80::5054:ff:fe12:3456'
    assert ln.default_ipv4['interface'] == 'eth0'
    assert ln.default_ipv6['interface'] == 'eth0'
    assert ln.default_ipv4['gateway'] == '192.168.1.1'
    assert ln.default_ipv6['gateway'] == 'fe80::5054:ff:fe12:1'
    assert ln.interfaces['eth0']['ipv4']['address']

# Generated at 2022-06-17 01:12:15.419332
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)

# Generated at 2022-06-17 01:12:26.180456
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.exit_json = lambda x: x
    linux_network = LinuxNetwork(module)

# Generated at 2022-06-17 01:12:38.681618
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # FIXME: this is a stub
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda x: x
    network = LinuxNetwork(module)
    network.populate()
    assert network.default_ipv4['address'] == '192.168.1.2'
    assert network.default_ipv4['netmask'] == '255.255.255.0'
    assert network.default_ipv4['network'] == '192.168.1.0'
    assert network.default_ipv4['broadcast'] == '192.168.1.255'
    assert network.default_ipv4['macaddress'] == '00:0c:29:8c:11:b1'
    assert network.default_ipv4['mtu'] == 1500
    assert network.default_ip

# Generated at 2022-06-17 01:12:50.296878
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['address'] == '192.168.1.1'
    assert default_ipv4['netmask'] == '255.255.255.0'
    assert default_ipv4['network'] == '192.168.1.0'
    assert default_ipv4['broadcast'] == '192.168.1.255'
    assert default_ipv6['address'] == 'fe80::1'
    assert default_ipv6['prefix'] == '64'
    assert default_ipv6['scope'] == 'link'


# Generated at 2022-06-17 01:13:01.257979
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    default_ipv4, default_ipv6 = network.get_default_interfaces()
    assert default_ipv4['address'] == '192.168.1.1'
    assert default_ipv4['netmask'] == '255.255.255.0'
    assert default_ipv4['network'] == '192.168.1.0'
    assert default_ipv4['broadcast'] == '192.168.1.255'
    assert default_ipv6['address'] == 'fe80::1'
    assert default_ipv6['prefix'] == '64'
    assert default_ipv6['scope'] == 'link'


# Generated at 2022-06-17 01:13:08.509161
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    ln.populate()
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.interfaces
    assert ln.ips
