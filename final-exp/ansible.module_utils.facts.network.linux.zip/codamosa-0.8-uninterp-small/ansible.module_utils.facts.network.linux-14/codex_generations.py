

# Generated at 2022-06-24 23:01:15.611165
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_collector_1 = LinuxNetworkCollector()
    linux_network_collector_1.get_interfaces_info(None, None, None)


# Generated at 2022-06-24 23:01:25.421161
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_collector = LinuxNetworkCollector()

# Generated at 2022-06-24 23:01:36.067000
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Mocked module for testing
    class AnsibleModule:
        def get_bin_path(self, name):
            return "/bin/true"
        def fail_json(self, msg):
            print("AnsibleModule.fail_json: " + msg)
            sys.exit(1)
        def exit_json(self, **fields):
            print("AnsibleModule.exit_json:")
            print(fields['ansible_facts']['ansible_network_resources'])
            sys.exit(0)
        def run_command(self, args, errors='surrogate_then_replace'):
            print("AnsibleModule.run_command:")
            print(args)
            print(errors)
            return 0, None, None
    ansible_module_0 = AnsibleModule()
    linux_

# Generated at 2022-06-24 23:01:47.427549
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_collector_1 = LinuxNetworkCollector()
    device = 'eth0'

# Generated at 2022-06-24 23:01:52.334503
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_collector_0 = LinuxNetworkCollector()
    # TypeError: get_ethtool_data() takes exactly 2 arguments (1 given)
    # Impossible to test "return" type and value
    try:
        linux_network_collector_0.get_ethtool_data(linux_network_collector_0)
    except TypeError:
        pass


# Generated at 2022-06-24 23:02:01.197083
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_collector_0 = LinuxNetworkCollector()
    linux_network_0 = LinuxNetwork(True)
    linux_network_0.populate()
    assert linux_network_0.default_ipv4.get('address') == None
    assert linux_network_0.default_ipv4.get('broadcast') == None
    assert linux_network_0.default_ipv4.get('netmask') == None
    assert linux_network_0.default_ipv4.get('network') == None
    assert linux_network_0.default_ipv4.get('gateway') == '192.0.2.1'
    assert linux_network_0.default_ipv6.get('address') == None
    assert linux_network_0.default_ipv6.get('prefix') == None
   

# Generated at 2022-06-24 23:02:07.668585
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network_collector = LinuxNetworkCollector()
    rc, stdout,stderr = linux_network_collector.module.run_command("ip route")
    default_ipv4, default_ipv6 = linux_network_collector.get_default_interfaces(output=stdout)
    if default_ipv4['interface'] == 'eth0':
        return "test_LinuxNetwork_get_default_interfaces successful"
    else:
        return "test_LinuxNetwork_get_default_interfaces failed"


# Generated at 2022-06-24 23:02:12.942959
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    print('Testing get_default_interfaces...')
    linux_network_collector_0 = LinuxNetworkCollector()
    default_ipv4, default_ipv6 = linux_network_collector_0.get_default_interfaces()
    print('DONE')
    return


# Generated at 2022-06-24 23:02:16.849788
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network_collector_0 = LinuxNetworkCollector()
    ip_path_0 = get_file_content('/usr/bin/ip')
    linux_network_collector_0.get_default_interfaces(ip_path_0)


# Generated at 2022-06-24 23:02:24.352454
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Default case test
    linux_network_collector_1 = LinuxNetworkCollector()
    ip_path_1 = '/sbin/ip'
    default_ipv4_1 = IP(address='192.168.1.1', netmask='255.255.255.255', gateway='192.168.1.1', interface='eth0')
    default_ipv6_1 = IP(address='fe80::5054:ff:fe12:3456', prefix='64', scope='link', interface='eth0')
    result = linux_network_collector_1.get_interfaces_info(ip_path_1, default_ipv4_1, default_ipv6_1)

if __name__ == "__main__":
    test_LinuxNetwork_get_interfaces_info()

# Generated at 2022-06-24 23:03:09.752739
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_0 = LinuxNetwork(module=CustomModule())
    assert linux_network_0.get_interfaces_info({'ipv4': {}, 'ipv6': {}}, {'ipv4': {}, 'ipv6': {}}, {'ipv4': {}, 'ipv6': {}}) == ({}, {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}), 'Failed asserting that LinuxNetwork.get_interfaces_info return ({}, {\'all_ipv4_addresses\': [], \'all_ipv6_addresses\': []}) .'



# Generated at 2022-06-24 23:03:16.314405
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_collector_1 = LinuxNetworkCollector()
    device_1 = ""
    expected_result_1 = {}
    result_1 = linux_network_collector_1.get_ethtool_data(device_1)
    assert result_1 == expected_result_1


# Generated at 2022-06-24 23:03:23.769704
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_collector = LinuxNetworkCollector()
    ip_path = None
    default_ipv4 = {}
    default_ipv6 = {}
    linux_network_collector.get_interfaces_info(ip_path, default_ipv4, default_ipv6)


if __name__ == "__main__":
    test_case_0()
    test_LinuxNetwork_get_interfaces_info()

# Generated at 2022-06-24 23:03:34.626785
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_collector = LinuxNetworkCollector()
    actual_0 = linux_network_collector.get_ethtool_data("eno16777736")
    actual_1 = linux_network_collector.get_ethtool_data("eno33554984")

# Generated at 2022-06-24 23:03:36.569148
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_collector_0 = LinuxNetworkCollector()
    linux_network_collector_0.populate()


# Generated at 2022-06-24 23:03:38.440303
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_0 = LinuxNetwork()

    # Assertions
    assert linux_network_0.populate()
    return


# Generated at 2022-06-24 23:03:40.170990
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_0 = LinuxNetwork()
    linux_network_0.populate()
    pass


# Generated at 2022-06-24 23:03:48.178852
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    import os
    import socket
    import tempfile


# Generated at 2022-06-24 23:03:56.128937
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network_collector_0 = LinuxNetworkCollector()

    # call tested method
    default_ipv4_interface, default_ipv6_interface = linux_network_collector_0.get_default_interfaces()

    assert default_ipv4_interface == {'interface': 'lo', 'address': '127.0.0.1'}, 'Unexpected result returned by get_default_interfaces().default_ipv4_interface'
    assert default_ipv6_interface == {'interface': 'lo', 'address': '::1'}, 'Unexpected result returned by get_default_interfaces().default_ipv6_interface'



# Generated at 2022-06-24 23:04:00.421467
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_collector_1 = LinuxNetworkCollector()
    interfaces = linux_network_collector_1.get_ethtool_data()
    linux_network_collector_1.module.exit_json(actual=interfaces)


# Generated at 2022-06-24 23:04:43.012800
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    float_0 = 1377.599678
    linux_network_0 = LinuxNetwork(float_0)
    linux_network_0.get_ethtool_data(float_0)


# Generated at 2022-06-24 23:04:48.371016
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    float_0 = 1377.599678
    linux_network_0 = LinuxNetwork(float_0)
    float_0 = 1377.599678
    var_1 = ('', '')
    var_2 = var_1[0]
    var_3 = var_1[1]
    var_4 = linux_network_0.get_interfaces_info(linux_network_0, var_2, var_3)


# Generated at 2022-06-24 23:04:58.229326
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    var_0 = 'eth0'
    linux_network_0 = LinuxNetwork(var_0)
    var_1 = linux_network_0.get_ethtool_data(var_0)

# Generated at 2022-06-24 23:05:01.247690
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    class_0 = LinuxNetwork
    var_0 = class_0()
    var_0.get_interfaces_info(var_0, float)


# Generated at 2022-06-24 23:05:06.413695
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    float_0 = 1377.599678
    linux_network_0 = LinuxNetwork(float_0)
    var_0 = linux_network_0.get_default_interfaces(linux_network_0, float_0)


# Generated at 2022-06-24 23:05:10.796967
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network = linux_network = LinuxNetwork(None)
    linux_network.populate()
    int_0 = 0

# Generated at 2022-06-24 23:05:15.504205
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    float_0 = 1377.599678
    linux_network_0 = LinuxNetwork(float_0)
    str_0 = "multicast_v6"
    linux_network_0.get_ethtool_data(str_0)
    linux_network_0.get_ethtool_data(str_0)


# Generated at 2022-06-24 23:05:19.121779
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    float_0 = 1377.599678
    linux_network_0 = LinuxNetwork(float_0)
    string_1 = '*'
    var_0 = linux_network_0.get_ethtool_data(string_1)


# Generated at 2022-06-24 23:05:30.675826
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    float_0 = 0.29
    linux_network_0 = LinuxNetwork(float_0)
    # Test that the correct dictionary is returned
    string_0 = "mislav"
    # Test with a valid device

# Generated at 2022-06-24 23:05:36.288756
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    float_0 = 1377.599678
    linux_network_0 = LinuxNetwork(float_0)
    str_0 = "eth0"
    var_0 = linux_network_0.get_ethtool_data(linux_network_0, str_0)


# Generated at 2022-06-24 23:06:20.793526
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    float_0 = 1377.599678
    linux_network_0 = LinuxNetwork(float_0)
    var_0 = "eth0"
    linux_network_0.interfaces = var_0
    var_0 = False
    linux_network_0.has_ip = var_0
    var_0 = False
    linux_network_0.has_ipv6 = var_0
    var_0 = "eth0"
    linux_network_0.primary = var_0
    var_0 = "eth0"
    linux_network_0.default_interface = var_0
    var_0 = False
    linux_network_0.primary_ipv4 = var_0
    var_0 = False
    linux_network_0.primary_ipv6 = var_0
    var_0 = False


# Generated at 2022-06-24 23:06:31.012487
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    print("Testing get_default_interfaces")

    linux_network_0 = LinuxNetwork(None)
    linux_network_0.default_ipv4, linux_network_0.default_ipv6 = linux_network_0.get_default_interfaces(linux_network_0, None)
    # Assert default_ipv4 type
    assert(isinstance(linux_network_0.default_ipv4, dict))

    # Assert default_ipv6 type
    assert(isinstance(linux_network_0.default_ipv6, dict))

    # Assert default IPv4 address
    assert(linux_network_0.default_ipv4['address'] == '172.16.106.100')

    # Assert default IPv6 address

# Generated at 2022-06-24 23:06:31.826359
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    fact_0 = LinuxNetworkCollector()


# Generated at 2022-06-24 23:06:37.128847
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    float_0 = 1377.599678
    linux_network_0 = LinuxNetwork(float_0)
    # Check calling with required args
    linux_network_0.get_interfaces_info(linux_network_0, linux_network_0, linux_network_0)
    # Check calling with all possible args
    linux_network_0.get_interfaces_info(linux_network_0, linux_network_0, linux_network_0)
    try:
        linux_network_0.get_interfaces_info(21.14, linux_network_0, linux_network_0)
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-24 23:06:41.921579
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    float_0 = 1377.599678
    linux_network_0 = LinuxNetwork(float_0)
    float_1 = linux_network_0.populate(linux_network_0)


# Generated at 2022-06-24 23:06:51.045105
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    float_0 = 1377.599678
    linux_network_0 = LinuxNetwork(float_0)
    linux_network_0.hostname = 1
    linux_network_0.domain = -2
    linux_network_0.gateway = ''
    linux_network_0.default_ipv4 = {
        'address': '10.0.0.1',
        'netmask': '255.255.255.0',
        'broadcast': '10.0.0.255',
        'network': '10.0.0.0',
        'macaddress': '52:54:00:8b:67:2b',
        'mtu': 1500,
        'type': 'ethernet'}

# Generated at 2022-06-24 23:06:54.987503
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    float_0 = 1377.599678
    linux_network_0 = LinuxNetwork(float_0)
    var_0 = linux_network_0.get_default_interfaces(linux_network_0, float_0)
    var_0 = linux_network_0.get_default_interfaces(linux_network_0, float_0)
    var_1 = linux_network_0.get_ethtool_data(var_0)


# Generated at 2022-06-24 23:06:56.120079
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    assert LinuxNetworkCollector.__base__ is NetworkCollector

# Generated at 2022-06-24 23:07:01.607288
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    float_0 = 1377.599678
    linux_network_0 = LinuxNetwork(float_0)
    var_0 = linux_network_0.get_default_interfaces(linux_network_0, float_0)


# Generated at 2022-06-24 23:07:13.983513
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_0 = LinuxNetwork(1377.599678)
    str_0 = '`zhY'
    dict_0 = {str_0: float_0}
    dict_1 = linux_network_0.get_interfaces_info(linux_network_0, dict_0, dict_0)
    assert str_0 == float_0
    assert dict_1 == dict_0
    dict_2 = {str_0: float_0}
    dict_3 = linux_network_0.get_interfaces_info(linux_network_0, dict_2, dict_0)
    assert str_0 == float_0
    assert dict_3 == dict_0
    dict_4 = {str_0: float_0}

# Generated at 2022-06-24 23:07:54.945722
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    try:
        test_case_0()
    except SystemExit:
        pass


# Generated at 2022-06-24 23:07:57.944619
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    float_0 = 32.99
    linux_network_0 = LinuxNetwork(float_0)
    var_0 = linux_network_0.get_ethtool_data(linux_network_0, float_0)



# Generated at 2022-06-24 23:08:00.268626
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    float_0 = 1377.599678
    linux_network_0 = LinuxNetwork(float_0)
    linux_network_0.populate(float_0)


# Generated at 2022-06-24 23:08:03.374599
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    instances = LinuxNetwork.instance()
    linux_network_0 = instances[0]
    float_0 = 1377.599678
    linux_network_0.get_interfaces_info(linux_network_0, float_0)


# Generated at 2022-06-24 23:08:05.906012
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    float_0 = 1377.599678
    ips_0 = {}
    linux_network_0 = LinuxNetwork(float_0)
    (var_0, var_1), ips_0 = linux_network_0.get_interfaces_info(linux_network_0, float_0, ips_0)


# Generated at 2022-06-24 23:08:12.449055
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    linux_network_0 = LinuxNetwork()

    float_0 = 1377.599678

    var_0 = linux_network_0.get_default_interfaces(linux_network_0, float_0)

    # Test case with parameters of type LinuxNetwork and float
    test_case_0()


# Generated at 2022-06-24 23:08:22.189794
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    float_0 = 1377.599678
    linux_network_0 = LinuxNetwork(float_0)
    float_1 = float_0
    float_2 = float_1
    var_0 = linux_network_0.get_default_interfaces(linux_network_0, float_1)
    var_1 = var_0[0]
    var_0 = var_0[1]
    return_0 = linux_network_0.get_interfaces_info(var_0, var_1, var_0)
    return_0 = return_0[0]
    return_0 = return_0[1]
    return_0 = return_0['ipv6']
    return_0 = return_0[0]
    return_0 = return_0['address']
    return_1 = linux_network_

# Generated at 2022-06-24 23:08:27.092625
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    float_0 = 0.4
    linux_network_0 = LinuxNetwork(float_0)
    linux_network_0.get_default_interfaces(linux_network_0, float_0)


# Generated at 2022-06-24 23:08:33.672493
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    float_0 = 1377.599678
    linux_network_0 = LinuxNetwork(float_0)
    var_0 = linux_network_0.get_default_interfaces(linux_network_0, float_0)
    linux_network_1 = LinuxNetwork(float_0)
    var_0 = linux_network_1.get_default_interfaces(linux_network_1, float_0)
    linux_network_2 = LinuxNetwork(float_0)
    var_0 = linux_network_2.get_default_interfaces(linux_network_2, float_0)
    linux_network_3 = LinuxNetwork(float_0)
    var_0 = linux_network_3.get_default_interfaces(linux_network_3, float_0)

# Generated at 2022-06-24 23:08:35.273813
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    float_0 = 930.44
    linux_network_0 = LinuxNetwork(float_0)
    linux_network_0.populate()


# Generated at 2022-06-24 23:09:25.111041
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    float_0 = 1377.599678
    linux_network_0 = LinuxNetwork(float_0)
    float_1 = float_0
    var_1 = linux_network_0.get_default_interfaces(linux_network_0, float_0)
    var_0 = linux_network_0.get_interfaces_info(float_0, var_1[0], var_1[1])


# Generated at 2022-06-24 23:09:27.435263
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network_0 = LinuxNetwork()
    str_0 = 'default'
    str_1 = linux_network_0.get_default_interfaces(str_0)
    bool_0 = isinstance(str_1, list)
    assert bool_0


# Generated at 2022-06-24 23:09:32.370900
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_0 = LinuxNetwork(0)
    interfaces, default_ipv4, default_ipv6, ips = linux_network_0.populate(linux_network_0, 0)


# Generated at 2022-06-24 23:09:34.896422
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    try:
        from .modules.utilities.system_info import LinuxNetwork
    except ImportError:
        return

    # FIXME: idk how to run this test
    # interface = linux_network_0.get_interfaces_info()
    # print(interface)
    raise NotImplementedError()



# Generated at 2022-06-24 23:09:40.572395
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    float_0 = 1377.599678
    linux_network_0 = LinuxNetwork(float_0)
    var_0 = { 'default_ipv4': {}, 'default_ipv6': {}, 'interfaces': {}, 'all_ipv4_addresses': [], 'all_ipv6_addresses': [] }
    assert var_0 == linux_network_0.populate(float_0)


# Generated at 2022-06-24 23:09:51.661715
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Import data from file: test/linux_network_data.json
    try:
        with open("test/linux_network_data.json", "r") as fh:
            test_data = json.load(fh)
    except (IOError, TypeError, ValueError) as ex:
        print("Exception: %s" % ex.message)

    # Generate test data
    float_0 = 1377.599678

# Generated at 2022-06-24 23:09:54.174683
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    float_0 = 1377.599678
    linux_network_0 = LinuxNetwork(float_0)
    var_0 = linux_network_0.get_default_interfaces(linux_network_0, float_0)


# Generated at 2022-06-24 23:10:01.503560
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    float_0 = 1377.599678
    linux_network_0 = LinuxNetwork(float_0)
    var_0 = linux_network_0.get_default_interfaces(linux_network_0, float_0)
    linux_network_0.get_interfaces_info(linux_network_0, var_0, var_0)


# Generated at 2022-06-24 23:10:08.528574
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    float_0 = 1377.599678
    linux_network_0 = LinuxNetwork(float_0)
    float_1 = 1377.599678
    linux_network_0.get_interfaces_info(linux_network_0, float_0, float_1)


# Generated at 2022-06-24 23:10:14.897053
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    default_ipv4, default_ipv6 = LinuxNetwork.get_default_interfaces()
    assert("default_ipv4" in default_ipv4)
    assert("default_ipv6" in default_ipv6)
