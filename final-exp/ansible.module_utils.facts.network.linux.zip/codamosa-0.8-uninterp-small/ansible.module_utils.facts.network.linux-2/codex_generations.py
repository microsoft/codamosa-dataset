

# Generated at 2022-06-24 23:01:10.682719
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network_0 = LinuxNetwork(614.4)
    assert linux_network_0.get_default_interfaces() == ('127.0.0.1', '::1')


# Generated at 2022-06-24 23:01:13.450718
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    float_0 = 614.4
    linux_network_0 = LinuxNetwork(float_0)
    linux_network_0.get_default_interfaces()


# Generated at 2022-06-24 23:01:19.865219
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    float_0 = 614.4
    linux_network_0 = LinuxNetwork(float_0)
    fact_class_0 = LinuxNetwork
    linux_network_collector_0 = LinuxNetworkCollector(fact_class_0)



# Generated at 2022-06-24 23:01:22.822233
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_0 = LinuxNetwork(778.6)
    with pytest.raises(TypeError):
        # test for invalid parameters
        linux_network_0.populate()


# Generated at 2022-06-24 23:01:25.210646
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    float_0 = 614.4
    linux_network_0 = LinuxNetwork(float_0)
    linux_network_0.get_interfaces_info()


# Generated at 2022-06-24 23:01:27.780399
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    float_0 = 614.4
    linux_network_0 = LinuxNetwork(float_0)
    linux_network_0.get_ethtool_data(str_argv_1='lo')


# Generated at 2022-06-24 23:01:29.785488
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    assert LinuxNetworkCollector.get_facts().keys() == {'network'}


# Generated at 2022-06-24 23:01:33.431039
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    float_0 = 615.6
    float_1 = 237.36
    linux_network_0 = LinuxNetwork(float_0)
    str_0 = linux_network_0.get_ethtool_data(float_1)


# Generated at 2022-06-24 23:01:41.551435
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    float_0 = 614.4
    linux_network_0 = LinuxNetwork(float_0)
    # FIXME: this test needs better arguments
    result = linux_network_0.get_interfaces_info(linux_network_0, linux_network_0, linux_network_0)
    # FIXME: we should have a way to check that the methods we call as
    # part of this test are actually tested elsewhere
    assert result is not None


# Generated at 2022-06-24 23:01:47.295313
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network_0 = LinuxNetwork(float_0)
    ip_path = "cjwz0mjg:y-wt.86`<5#jwh5@1r"
    float_0 = float()
    float_1 = float()
    dict_0 = dict()
    dict_1 = dict()
    linux_network_0.get_default_interfaces(ip_path, float_0, float_1)


# Generated at 2022-06-24 23:02:22.256972
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_collector = LinuxNetworkCollector()
    ip_path = linux_network_collector.module.get_bin_path("ip")
    default_ipv4 = {'address': '10.107.87.99'}
    default_ipv6 = {'address': 'fe80::8919:79ff:fe2c:d1a0'}
    result = linux_network_collector.get_interfaces_info(ip_path, default_ipv4, default_ipv6)
    print(result)



# Generated at 2022-06-24 23:02:33.003987
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = MagicMock()
    module.get_bin_path.return_value = None
    module.run_command.return_value = (1, "", "")

    default_ipv4 = {'address': '192.168.1.1'}
    default_ipv6 = {'address': '::1'}
    linux_network_collector_1 = LinuxNetworkCollector()
    linux_network_collector_1.module = module
    result = linux_network_collector_1.populate(default_ipv4=default_ipv4, default_ipv6=default_ipv6)

    assert result is None


# Generated at 2022-06-24 23:02:41.233704
# Unit test for method populate of class LinuxNetwork

# Generated at 2022-06-24 23:02:46.333975
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_collector = LinuxNetworkCollector()
    ifaces, ips = linux_collector.get_interfaces_info(
        ip_path='/usr/bin/ip',
        default_ipv4={},
        default_ipv6={})
    return ifaces, ips


# Generated at 2022-06-24 23:02:55.746338
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_collector = LinuxNetworkCollector()
    ip_path = "/sbin/ip"
    default_ipv4 = { 'address' : '10.0.0.8' }
    default_ipv6 = { 'address' : 'fd01:8765:4321:1234::8' }
    interfaces, ips = linux_network_collector.get_interfaces_info(ip_path, default_ipv4, default_ipv6)
    assert interfaces['test_iface']['ipv4']['address'] == '10.0.0.8'
    assert interfaces['test_iface']['ipv4']['netmask'] == '255.255.224.0'

# Generated at 2022-06-24 23:03:03.776594
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network_collector_get_default_interfaces = LinuxNetworkCollector()
    assert len(linux_network_collector_get_default_interfaces.get_default_interfaces()) == 2
    assert linux_network_collector_get_default_interfaces.get_default_interfaces()[0]['interface'] == 'eth0'
    assert linux_network_collector_get_default_interfaces.get_default_interfaces()[1]['interface'] == 'eth0'



# Generated at 2022-06-24 23:03:13.315916
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    print("Testing get_interfaces_info()")
    linux_n = LinuxNetworkCollector()
    default_ipv4 = {'address': '123.123.123.123'}
    default_ipv6 = {'address': 'fe80::123'}
    interfaces, ips = linux_n.get_interfaces_info('/path', default_ipv4, default_ipv6)
    assert interfaces['lo']['ipv4']['address'] == '127.0.0.1'
    assert default_ipv4['netmask'] == '255.0.0.0'
    assert ips['all_ipv4_addresses'][0] == '127.0.0.1'
    assert interfaces['lo']['mtu'] == 65536

# Generated at 2022-06-24 23:03:21.663898
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_collector_0 = LinuxNetworkCollector()
    ip_path = "./ip"
    default_ipv4 = { 'address': '10.0.2.15' }
    default_ipv6 = { 'address': 'fe80::a00:27ff:febc:9b76' }
    interfaces, ips = linux_network_collector_0.get_interfaces_info(ip_path, default_ipv4, default_ipv6)
    for key, value in interfaces.items():
        print(key, value)
    for key, value in ips.items():
        print(key, value)


# Generated at 2022-06-24 23:03:25.317355
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_collector_0 = LinuxNetworkCollector()
    linux_network_collector_0.get_ethtool_data("")


# Generated at 2022-06-24 23:03:27.221672
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network_collector_0 = LinuxNetworkCollector()
    # FIXME: Test not implemented


# Generated at 2022-06-24 23:04:12.159290
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_0 = LinuxNetwork(
        ansible_module=AnsibleModule(
            argument_spec=dict(
                count=dict(type='int'),
                gateways=dict(type='dict', choices=['v4', 'v6']),
                ipv4=dict(type='dict', choices=['address', 'all_ipv4_addresses', 'default_interface', 'default_ipv4', 'interfaces']),
                ipv6=dict(type='dict', choices=['address', 'all_ipv6_addresses', 'default_interface', 'default_ipv6', 'interfaces']),
                interfaces=dict(type='dict', choices=['default', 'gateway', 'interface', 'ipv4', 'ipv6'])
            )
        )
        )
    linux_network_collect

# Generated at 2022-06-24 23:04:14.908761
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_object_0 = LinuxNetworkCollector()
    device = 'lo'
    ret_0 = linux_network_object_0.get_ethtool_data(device)


# Generated at 2022-06-24 23:04:20.896431
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Case 0:
    # FIXME: any way to really test this?
    # FIXME: raise SkipTest?
    # TODO: mock up LinuxNetworkCollector.get_default_interfaces.__name__ to set this up
    test_case_0()


# Generated at 2022-06-24 23:04:28.824700
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # FIXME: patch module.run_command in a cleaner way
    import unittest.mock
    mock_run_command = unittest.mock.patch('ansible.module_utils.basic.AnsibleModule.run_command')

# Generated at 2022-06-24 23:04:38.206190
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_collector = LinuxNetworkCollector()
    device = "enp0s3"

# Generated at 2022-06-24 23:04:48.868555
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    import json
    from ..module_utils.aws_common import Loader
    from unittest.mock import call, MagicMock, patch, Mock
    from ansible.module_utils._text import to_bytes
    loader = Loader([])
    # Mock the ansible module
    mock_module = MagicMock()
    mock_module.params = {}
    mock_module.params['gather_network_resources'] = 'all'
    mock_module.run_command.return_value = (0, to_bytes("GATEWAYDEV=eth0\n"), to_bytes(""))
    mock_module.get_bin_path.return_value = "/bin/ip"
    # get_bin_path is called twice, once for ip and once for ethtool

# Generated at 2022-06-24 23:04:55.733170
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_collector_0 = LinuxNetworkCollector()

    # device is a string
    device = "lo"
    result_0 = linux_network_collector_0.get_ethtool_data(device)

    # device is not a string
    device = ["lo"]
    result_1 = linux_network_collector_0.get_ethtool_data(device)

    # device is a string but is not a valid device
    device = "not_a_device"
    result_2 = linux_network_collector_0.get_ethtool_data(device)

    if __name__ == '__main__':
        print("result_0: ")
        pprint(result_0)
        print("result_1: ")
        pprint(result_1)

# Generated at 2022-06-24 23:04:57.795224
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_collector_0 = LinuxNetworkCollector()
    result = linux_network_collector_0.get_interfaces_info(ip_path, default_ipv4, default_ipv6)


# Generated at 2022-06-24 23:05:02.724310
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_collector_1 = LinuxNetworkCollector()
    test_device = "eth0"
    linux_network_collector_1.get_ethtool_data(test_device)

if __name__ == '__main__':
    test_case_0()
    test_LinuxNetwork_get_ethtool_data()

# Generated at 2022-06-24 23:05:15.095843
# Unit test for method populate of class LinuxNetwork

# Generated at 2022-06-24 23:05:56.671602
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network_collector_0 = LinuxNetworkCollector()
    assert isinstance(linux_network_collector_0.get_default_interfaces(), tuple)


# Generated at 2022-06-24 23:06:08.980845
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-24 23:06:14.487192
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_collector_0 = LinuxNetworkCollector()
    linux_network_collector_0.populate()


# Generated at 2022-06-24 23:06:22.048372
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.common.network import LinuxNetwork
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import create_autospec

    linux_network = LinuxNetwork()

    IP_PATH = '/sbin/ip'


# Generated at 2022-06-24 23:06:24.917999
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network = LinuxNetwork()
    linux_network.get_ethtool_data()


# Generated at 2022-06-24 23:06:37.237683
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # FIXME: add better test data
    linux_network_collector_0 = LinuxNetworkCollector()
    # FIXME: test 'ethtool_path' to simulate lack of ethtool
    if not linux_network_collector_0.module.get_bin_path("ethtool"):
        return
    # FIXME: test a 'device' that has no features or timestamping
    device = sorted(netifaces.interfaces())[0]

# Generated at 2022-06-24 23:06:43.286147
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    try:
        linux_network_0 = LinuxNetwork()
        linux_network_0.populate()
    except NameError as err:
        print("NameError exception was raised with message: {0}".format(err))

# Unit test method get_interfaces_info of class LinuxNetwork
# FIXME: this is incomplete but the API is so complex that it's non-trivial to test
#        so we'll work on this as we move forward

# Generated at 2022-06-24 23:06:47.328233
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    pass

# Run tests


# Generated at 2022-06-24 23:06:49.419588
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    ansible_collections.ansible.netcommon.plugins.module_utils.network.common.network.LinuxNetwork.populate()


# Generated at 2022-06-24 23:06:57.735381
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_collector_0 = LinuxNetworkCollector()

# Generated at 2022-06-24 23:07:36.392841
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    float_0 = LinuxNetwork(0)
    var_0 = float_0.get_interfaces_info(0, {'0': 0}, {'0': 0})


# Generated at 2022-06-24 23:07:40.645928
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    float_0 = 329.0
    linux_network_0 = LinuxNetwork(float_0)
    float_1 = float_0
    float_2 = float_0
    float_3 = float_0
    linux_network_0.get_interfaces_info(float_1, float_2, float_3)

if __name__ == "__main__":
    test_LinuxNetwork_get_interfaces_info()

# Generated at 2022-06-24 23:07:48.430888
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    # Provide input value for argument 'ip_path'
    ip_path = 'ip'

    # Provide input value for argument 'default_ipv4'
    default_ipv4 = {'address': '', 'broadcast': '', 'netmask': '', 'network': ''}

    # Provide input value for argument 'default_ipv6'
    default_ipv6 = {'address': '', 'prefix': '', 'scope': ''}

    # Execute the function
    linux_network_0 = LinuxNetwork()
    interfaces_info = linux_network_0.get_interfaces_info(ip_path, default_ipv4, default_ipv6)
    print("interfaces_info : %s" % interfaces_info)


# Generated at 2022-06-24 23:07:53.297804
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    float_0 = 329.0
    linux_network_0 = LinuxNetwork(float_0)
    float_1 = 851.0
    float_2 = float_0 / float_1
    var_0 = linux_network_0.populate(float_2)


# Generated at 2022-06-24 23:07:58.512858
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    int_0 = get_random_int(0, 100)
    linux_network_0 = LinuxNetwork(int_0)
    dict_1 = linux_network_0.populate(int_0)
    dict_0 = dict()
    dict_0.setdefault('ansible_all_ipv4_addresses', [])
    dict_0.setdefault('ansible_default_ipv4', dict())
    dict_0.setdefault('ansible_default_ipv6', dict())
    dict_0.setdefault('ansible_devices', dict())
    dict_0.setdefault('ansible_machine_id', '')
    dict_0.setdefault('ansible_network_resources', dict())
    dict_0.setdefault('route6', dict())
    dict_0.setdefault('route', dict())

# Generated at 2022-06-24 23:08:00.660961
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    float_0 = 329.0
    linux_network_0 = LinuxNetwork(float_0)
    str_0 = 'eth0'
    #  test for method get_ethtool_data.
    linux_network_0.get_ethtool_data(str_0)


# Generated at 2022-06-24 23:08:08.632481
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    float_0 = 721.12
    linux_network_0 = LinuxNetwork(float_0)
    var_0 = linux_network_0.get_default_interfaces(float_0)
    assert var_0['v4']['address'] == '172.16.19.127'
    assert var_0['v4']['gateway'] == '172.16.19.1'
    assert var_0['v4']['interface'] == 'eth0'
    assert var_0['v6']['address'] == '2001:0db8:85a3:0000:0000:8a2e:0370:7334'
    assert var_0['v6']['gateway'] == 'fe80::f816:3eff:fe88:af38'

# Generated at 2022-06-24 23:08:13.246544
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    var_0 = LinuxNetworkCollector()
    var_0.collect()
    for fact in var_0.facts:
        print(fact)
    

if __name__ == '__main__':
    test_LinuxNetworkCollector()

# Generated at 2022-06-24 23:08:20.832207
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    float_0 = 0.0
    linux_network_0 = LinuxNetwork(float_0)
    int_0 = 0
    var_0 = linux_network_0.get_interfaces_info(int_0, float_0, float_0)
    # TEST: assert that the first element of var_0 is a dict
    assert isinstance(var_0[0], dict)
    # TEST: assert that the second element of var_0 is a dict
    assert isinstance(var_0[1], dict)


# Generated at 2022-06-24 23:08:29.659708
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    float_0 = 458.0
    linux_network_0 = LinuxNetwork(float_0)
    linux_network_0.module.params = dict()
    int_0 = 776
    bool_0 = linux_network_0.module.params.get('aliases', bool_0)
    linux_network_0.module.params['aliases'] = bool_0
    bool_1 = linux_network_0.module.params.get('gather_network_resources', bool_1)
    linux_network_0.module.params['gather_network_resources'] = bool_1
    bool_2 = linux_network_0.module.params.get('config', bool_2)
    linux_network_0.module.params['config'] = bool_2

# Generated at 2022-06-24 23:09:16.022277
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    float_0 = 81.0
    float_1 = 93.0
    linux_network_0 = LinuxNetwork(float_0)
    var_0 = linux_network_0.get_interfaces_info(float_0, float_1, float_0)


# Generated at 2022-06-24 23:09:20.202671
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    class_obj = LinuxNetwork(None)
    result = class_obj.get_ethtool_data(None)
    assert result is not None


# Generated at 2022-06-24 23:09:28.420888
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # FIXME: there's some kind of coupling between this test and the actual
    # implementation, we should be able to make this into a stand-alone test
    # that doesn't need LinuxSystem
    # TODO: maybe this should be in test/units/module_utils/linux.py
    # instead?
    linux_system_0 = LinuxSystem(float_0)
    var_0 = linux_system_0.get_default_interfaces()
    linux_network_0 = LinuxNetwork(float_0)
    var_1 = linux_network_0.get_interfaces_info(float_0, var_0[0], var_0[2])

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 23:09:40.536352
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    float_0 = 329.0
    linux_network_0 = LinuxNetwork(float_0)
    float_1 = 329.0
    var_0 = linux_network_0.get_default_interfaces(float_1)
    float_2 = 329.0
    linux_network_1 = LinuxNetwork(float_2)
    float_3 = 329.0
    var_1 = linux_network_1.get_default_interfaces(float_3)
    float_4 = 329.0
    linux_network_2 = LinuxNetwork(float_4)
    float_5 = 329.0
    var_2 = linux_network_2.get_default_interfaces(float_5)
    linux_network_3 = LinuxNetwork(float_0)
    var_3 = linux_network_3.get_interfaces_

# Generated at 2022-06-24 23:09:43.527332
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    float_0 = 329.0
    linux_network_0 = LinuxNetwork(float_0)
    var_0 = { 'ipv4': {}, 'ipv6': {} }


# Generated at 2022-06-24 23:09:53.956425
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    float_0 = 5.26
    linux_network_0 = LinuxNetwork(float_0)
    float_1 = 2.0
    bool_0 = True
    float_2 = 2.0
    bool_1 = True
    float_3 = 2.0
    bool_2 = True
    float_4 = 2.0
    bool_3 = True
    float_5 = 2.0
    bool_4 = True
    float_6 = 2.0
    bool_5 = True
    float_7 = 2.0
    bool_6 = True
    float_8 = 2.0
    bool_7 = True
    float_9 = 2.0
    bool_8 = True
    float_10 = 2.0
    bool_9 = True
    float_11 = 2.0
    bool_10 = True

# Generated at 2022-06-24 23:09:59.550131
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    float_0 = 579.0
    linux_network_0 = LinuxNetwork(float_0)
    var_0 = linux_network_0.get_default_interfaces(float_0)


# Generated at 2022-06-24 23:10:02.536836
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    float_0 = 328.0
    int_0 = -6476925430706978091
    linux_network_0 = LinuxNetwork(float_0, int_0)
    linux_network_0.populate()


# Generated at 2022-06-24 23:10:05.286903
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    float_none = None
    float_0 = 329.0
    linux_network_0 = LinuxNetwork(float_0)
    var_0 = linux_network_0.populate()


# Generated at 2022-06-24 23:10:09.960588
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    float_0 = 44.0
    linux_network_1 = LinuxNetwork(float_0)
    str_0 = 'RiDĜ'
    var_0 = linux_network_1.get_ethtool_data(str_0)
    var_1 = linux_network_1.get_ethtool_data(str_0)
    str_1 = 'y'
    var_2 = linux_network_1.get_ethtool_data(str_1)