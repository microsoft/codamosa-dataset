

# Generated at 2022-06-24 23:01:14.640515
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    list_0 = []
    linux_network_0 = LinuxNetwork(list_0)
    list_1 = []
    linux_network_0.populate(list_1)


# Generated at 2022-06-24 23:01:24.527573
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    list_0 = []
    # This method is not available on Windows machines
    if os.name == 'nt':
        return

    linux_network_0 = LinuxNetwork(list_0)
    with patch('ansible.module_utils.basic.AnsibleModule.get_bin_path', side_effect=lambda _:os.path.join(os.path.dirname(__file__), 'test_data')):
        linux_network_1 = LinuxNetwork(list_0)
        with open(os.path.join(os.path.dirname(__file__), 'test_data', 'ipv4_output'), 'r') as f:
            ipv4_output = f.read()

# Generated at 2022-06-24 23:01:31.868868
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-24 23:01:37.652990
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    net_ifaces_0 = {'eth0': {'ipv4': {'address': '10.0.0.3', 'broadcast': '10.0.0.3', 'netmask': '255.255.255.255', 'network': '10.0.0.3'}, 'ipv6': [{'address': 'fe80::a00:27ff:fe15:36c1', 'prefix': '64', 'scope': 'link'}]}}

    list_0 = ['/usr/bin/ethtool']
    linux_network_0 = LinuxNetwork(list_0)
    linux_network_0.get_ethtool_data('eth0')


# Generated at 2022-06-24 23:01:48.904208
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    list_0 = []
    linux_network_0 = LinuxNetwork(list_0)
    tuple_0 = linux_network_0.get_default_interfaces()
    assert type(str(tuple_0[0]["address"])).__name__ == 'str'
    assert type(str(tuple_0[0]["gateway"])).__name__ == 'str'
    assert type(str(tuple_0[0]["netmask"])).__name__ == 'str'
    assert type(tuple_0[1]["address"]).__name__ == 'str'
    assert type(tuple_0[1]["gateway"]).__name__ == 'str'
    assert type(tuple_0[1]["prefix"]).__name__ == 'str'


# Generated at 2022-06-24 23:01:50.558809
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    list_0 = []
    linux_network_0 = LinuxNetwork(list_0)
    result = linux_network_0.get_default_interfaces()
    assert result == None



# Generated at 2022-06-24 23:01:55.525328
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    list_0 = []
    linux_network_0 = LinuxNetwork(list_0)
    linux_network_0.populate()
    linux_network_0.populate()
    linux_network_0.populate()
    linux_network_0.populate()
    linux_network_0.populate()


# Generated at 2022-06-24 23:01:59.533922
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_0 = LinuxNetwork()
    # print(linux_network_0)
    list_0 = []
    list_1 = []
    list_0.append("0")
    list_0.append("1")
    # print(list_0)
    linux_network_0.populate(list_0, list_1)


# Generated at 2022-06-24 23:02:06.634139
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    list_0 = []
    linux_network_0 = LinuxNetwork(list_0)
    print("--- test get_default_interfaces ---")
    result_0 = linux_network_0.get_default_interfaces()
    linux_network_0.cache["interface"] = dict()
    result_1 = linux_network_0.get_default_interfaces()
    assert result_0 == result_1


# Generated at 2022-06-24 23:02:12.988032
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    list_2 = [
        'eth0',
        '192.168.1.1',
        '1',
        '192.168.1.10'
    ]
    linux_network_1 = LinuxNetwork(list_2)
    linux_network_1.get_interfaces_info()
    

# Generated at 2022-06-24 23:02:41.074139
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    # FIXME: use mock and add tests for these properties:
    # 'pciid'
    # 'mtu'
    # 'device'
    # 'macaddress'
    # 'bonding_slave'
    # 'perm_macaddress'
    # 'promisc'
    # 'speed'

    from ansible.module_utils.six import StringIO

    list_0 = []
    linux_network_0 = LinuxNetwork(list_0)

    ip_path = None
    def_ipv4 = {}
    def_ipv6 = {}

# Generated at 2022-06-24 23:02:44.680283
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Test variables
    list_0 = []
    linux_network_0 = LinuxNetwork(list_0)
    device = ''

    # Test code
    linux_network_0.get_ethtool_data(device)


# Generated at 2022-06-24 23:02:55.329028
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    cmd_0 = ["/sbin/ip", "route", "get", "8.8.8.8"]
    ip_path_0 = "/sbin/ip"
    module_0 = MagicMock()
    module_0.run_command.return_value = (0, """8.8.8.8 via 10.0.1.1 dev wlp3s0  src 10.0.1.123
      cache""", "")
    module_0.get_bin_path.return_value = "/sbin/ip"
    default_ipv4_0 = {}
    default_ipv6_0 = {}
    module_0.fail_json.return_value = None
    module_0.warn.return_value = None
    module_0._debug.return_value = None
    module_0.deprec

# Generated at 2022-06-24 23:03:07.198164
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    list_0 = []
    list_0.append("/home/katherine/workspace/sys/bin/.python-venv/bin/python")
    list_0.append("/home/katherine/workspace/sys/bin/ansible/modules/utilities/logic/async_wrapper")
    list_0.append("--module-path")
    list_0.append("/home/katherine/workspace/sys/bin/ansible/modules/network/")
    list_0.append("--host")
    list_0.append("/home/katherine/workspace/sys/bin/ansible/")
    list_0.append("--lock")
    list_0.append("/home/katherine/workspace/sys/bin/ansible/")
    list_0.append("--timeout")


# Generated at 2022-06-24 23:03:15.954150
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    list_0 = []
    linux_network_0 = LinuxNetwork(list_0)
    # Run method populate of class LinuxNetwork
    linux_network_0.populate()
    # Run method get_hostname of class LinuxNetwork
    linux_network_0.get_hostname()
    # Run method get_interfaces_info of class LinuxNetwork
    list_0 = []
    list_1 = []
    linux_network_0.get_interfaces_info(list_0, list_1, list_1)
    # Run method get_interfaces_addresses of class LinuxNetwork
    list_0 = []
    list_1 = []
    linux_network_0.get_interfaces_addresses(list_0, list_1, list_1)
    # Run method get_default_interface of class LinuxNetwork
    list

# Generated at 2022-06-24 23:03:18.329703
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    list_0 = []
    linux_network_0 = LinuxNetwork(list_0)
    linux_network_0.get_ethtool_data('lo')


# Generated at 2022-06-24 23:03:20.592279
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    list_0 = []
    linux_network_0 = LinuxNetwork(list_0)
    linux_network_0.populate(dict_0=None)


# Generated at 2022-06-24 23:03:26.280869
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    list_0 = []
    linux_network_0 = LinuxNetwork(list_0)
    linux_network_0.get_interfaces_info(None, None, None)
    linux_network_0.get_default_interfaces()


# Generated at 2022-06-24 23:03:37.364808
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    list_0 = []
    linux_network_0 = LinuxNetwork(list_0)
    int_0 = linux_network_0.populate()
    assert int_0 == 0
    dict_0 = dict()
    dict_0['all_ipv4_addresses'] = list_0
    dict_0['all_ipv6_addresses'] = list_0
    dict_0['default_interface'] = dict_0
    dict_0['default_ipv4'] = dict_0
    dict_0['default_ipv6'] = dict_0
    dict_0['interfaces'] = dict_0
    dict_0['ipv4'] = dict_0
    dict_0['ipv6'] = dict_0


# Generated at 2022-06-24 23:03:47.795912
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network = LinuxNetwork(None)

    # Test case 1
    print("Test case 1: interface {eth0}")
    device = "eth0"
    data_ethtool_actual = linux_network.get_ethtool_data(device)

# Generated at 2022-06-24 23:04:17.337334
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    list_0 = []
    linux_network_0 = LinuxNetwork(list_0)
    list_1 = []
    linux_network_0.get_interfaces_info(linux_network_0, list_1, list_1)


# Generated at 2022-06-24 23:04:25.752670
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Arrange:
    list_0 = ['1', '2']
    linux_network_0 = LinuxNetwork(list_0)
    args = ['ethtool', '-k', 'enp0s3']
    rc, stdout, stderr = linux_network_0.module.run_command(args, errors='surrogate_then_replace')
    args = ['ethtool', '-T', 'enp0s3']
    rc, stdout, stderr = linux_network_0.module.run_command(args, errors='surrogate_then_replace')
    # Act:
    linux_network_0.get_ethtool_data('enp0s3')

if __name__ == '__main__':
    test_case_0()
    test_LinuxNetwork_get_ethtool_data

# Generated at 2022-06-24 23:04:27.981631
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    list_0 = []
    linux_network_0 = LinuxNetwork(list_0)
    str_0 = "eth0"
    dict_0 = linux_network_0.get_ethtool_data(str_0)


# Generated at 2022-06-24 23:04:29.492504
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    list_0 = []
    linux_network_0 = LinuxNetwork(list_0)
    result_0 = linux_network_0.populate()
    assert result_0 is None


# Generated at 2022-06-24 23:04:31.083941
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    list_0 = []
    linux_network_0 = LinuxNetwork(list_0)
    linux_network_0.populate()


# Generated at 2022-06-24 23:04:33.882057
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    list_0 = []
    linux_network_0 = LinuxNetwork(list_0)
    linux_network_0.get_interfaces_info()


# Generated at 2022-06-24 23:04:37.201420
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    list_0 = []
    linux_network_0 = LinuxNetwork(list_0)
    linux_network_0.get_interfaces_info(None, None, None)


# Generated at 2022-06-24 23:04:39.883740
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    test_LinuxNetwork_populate_0()


# Generated at 2022-06-24 23:04:42.919180
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    list_0 = []
    linux_network_0 = LinuxNetwork(list_0)

    linux_network_0.get_interfaces_info()



# Generated at 2022-06-24 23:04:50.163869
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    print("Testing LinuxNetwork.get_default_interfaces")
    test_0 = LinuxNetwork(None)
    assert test_0.get_default_interfaces('v4') == 'eth0', 'Test LinuxNetwork.get_default_interfaces 1'
    assert test_0.get_default_interfaces('v6') == 'eth0', 'Test LinuxNetwork.get_default_interfaces 2'
    assert test_0.get_default_interfaces('non-existant') == False, 'Test LinuxNetwork.get_default_interfaces 3'

test_case_0()
test_LinuxNetwork_get_default_interfaces()



# Generated at 2022-06-24 23:05:25.021458
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_collector_0 = LinuxNetworkCollector()
    seen_interfaces = []
    gathered_interfaces = {'eth0': {'device': 'eth0', 'promisc': False, 'speed': 100, 'active': True, 'gathered': 'facts'}, 'eth1': {'device': 'eth1', 'promisc': False, 'speed': 1000, 'active': True, 'gathered': 'facts'}}

# Generated at 2022-06-24 23:05:32.592374
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Test case with empty input
    linux_network_collector_0 = LinuxNetworkCollector()
    # Test with empty device name
    device_0 = ""
    expected_0 = {
        "features": {},
        "timestamping": [],
        "hw_timestamp_filters": [],
        "phc_index": None,
    }
    output = linux_network_collector_0.get_ethtool_data(device_0)
    assert output == expected_0


# Generated at 2022-06-24 23:05:38.648662
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_0 = LinuxNetwork(dict(module=None, path=None))
    (dev_name, ethtool_data) = linux_network_0.get_ethtool_data("dev_name")
    assert dev_name == False  # TypeError: expected str, bytes or os.PathLike object, not dict


# Generated at 2022-06-24 23:05:48.811886
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_collector_1 = LinuxNetworkCollector()

    # Check get_ethtool_data on a device without ethtool present
    rc, stdout, stderr = linux_network_collector_1.module.run_command('which ethtool')
    if rc == 0:
        linux_network_collector_1.module.run_command('which ethtool | xargs rm -f')
    assert not linux_network_collector_1.get_ethtool_data('eth0')

    (rc, so, se) = linux_network_collector_1.module.run_command('which ethtool')
    if rc == 0:
        linux_network_collector_1.module.run_command('which ethtool | xargs rm -f')

    # Check get_ethtool_data on a device without ethtool present

# Generated at 2022-06-24 23:05:55.344386
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    # First we need to prepare a fake data structure for the LinuxNetworkCollector class
    import tests.mock_linux_distribution as mock_linux_distribution

    # fake the module settings
    fake_module_setting = {"params": {}}
    fake_module = mock_linux_distribution.get_mock_module(fake_module_setting)

    # instantiate a LinuxNetworkCollector class object
    linux_network_collector_0 = LinuxNetworkCollector()
    linux_network_collector_0.module = fake_module
    linux_network_collector_0.paths = {
        'ip': 'fake_ip_path',
        'ethtool': 'fake_ethtool_path',
        'bridge': 'fake_bridge_path',
    }

    result_0 = ''

# Generated at 2022-06-24 23:06:01.455962
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_0 = LinuxNetwork()

    module_0 = MagicMock()
    module_0.params = {'gather_network_resources': 'enabled'}

    changed = linux_network_0.populate(module_0)

# Generated at 2022-06-24 23:06:05.030039
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network_collector_0 = LinuxNetworkCollector()
    linux_network_collector_0.get_default_interfaces()


# Generated at 2022-06-24 23:06:15.288605
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Unit test for method populate of class LinuxNetwork
    # We don't want to test all the LinuxNetwork methods, only populate.
    # But populate needs to call other LinuxNetwork methods.
    class LinuxNetworkFake:
        def __init__(self):
            self.default_ipv4 = {
                "address": "1.2.3.4",
                "netmask": "255.255.255.0",
                "network": "1.2.3.0",
                "broadcast": "1.2.3.255",
                "macaddress": "01:23:45:67:89:0a",
            }
            self.default_ipv6 = {
                "address": "fe80::1c97:a9ff:fe34:7e27",
                "scope": "link",
            }
            self

# Generated at 2022-06-24 23:06:23.115935
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    # FIXME: make a real test case
    linux_network_collector_0 = LinuxNetworkCollector()
    linux_network_0 = LinuxNetwork()
    # Test the full interface_list first
    #linux_network_collector_0.INTERFACE_LIST = sorted(linux_network_collector_0.INTERFACE_LIST)
    linux_network_0.populate(linux_network_collector_0)
    #linux_network_0.interface_list = sorted(linux_network_0.interface_list)
    #assert linux_network_0.interface_list == linux_network_collector_0.INTERFACE_LIST
    # Now test with a subset
    linux_network_collector_0.INTERFACE_LIST = ["lo", "eth0"]

# Generated at 2022-06-24 23:06:32.157460
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_collector_0 = LinuxNetworkCollector()
    device = "mock_device"
    linux_network_collector_0.module.get_bin_path = lambda *args, **kwargs: True
    linux_network_collector_0.module.run_command = lambda *args, **kwargs: (0, "mock_stdout", "mock_stderr")
    linux_network_collector_0.get_ethtool_data(device)


# Generated at 2022-06-24 23:07:03.450766
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    var_0 = LinuxNetwork('')
    var_0.populate()

if __name__ == '__main__':
    test_LinuxNetwork_populate()
    test_case_0()

# Generated at 2022-06-24 23:07:05.773237
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    var_0 = []
    linux_network_0 = LinuxNetwork(var_0)
    var_1 = linux_network_0.get_default_interfaces()
    assert var_1 is not None


# Generated at 2022-06-24 23:07:07.700762
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network_0 = LinuxNetwork([])
    linux_network_0.get_default_interfaces()


# Generated at 2022-06-24 23:07:12.404639
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    var_0 = []
    linux_network_0 = LinuxNetwork(var_0)
    var_1 = []
    var_2 = False
    var_3 = linux_network_0.populate(var_1, var_2)


# Generated at 2022-06-24 23:07:14.944774
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    var_0 = []
    linux_network_0 = LinuxNetwork(var_0)
    var_1 = {}
    linux_network_0.populate(var_1)


# Generated at 2022-06-24 23:07:20.199420
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    var_0 = []
    linux_network_0 = LinuxNetwork(var_0)
    linux_network_0.get_interfaces_info(linux_network_0, linux_network_0, linux_network_0)
    linux_network_0.describe_default_ipv4()
    linux_network_0.get_net_defaults_v4()


# Generated at 2022-06-24 23:07:21.816298
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-24 23:07:27.314359
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    var_0 = ['/sbin/ip']
    linux_network_0 = LinuxNetwork(var_0)
    var_1 = linux_network_0.get_default_interfaces()
    assert var_1 == ('', '')


# Generated at 2022-06-24 23:07:32.096573
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # dummy input params
    linux_network = LinuxNetwork(linux_network_0)
    linux_network.populate()


# Generated at 2022-06-24 23:07:34.935846
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():

    device_2 = "eth0"
    linux_network_0 = LinuxNetwork()
    var_0 = linux_network_0.get_ethtool_data(device_2)
    print(var_0)



# Generated at 2022-06-24 23:08:09.856545
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    var_0 = []
    linux_network_0 = LinuxNetwork(var_0)
    var_1 = linux_network_0.get_interfaces_info(linux_network_0, linux_network_0, linux_network_0)
    assert type(var_1) == tuple
    assert len(var_1) == 2
    assert type(var_1[0]) == dict
    assert len(var_1[0]) == 0
    assert type(var_1[1]) == dict
    assert len(var_1[1]) == 2
    assert type(var_1[1]['all_ipv4_addresses']) == list
    assert len(var_1[1]['all_ipv4_addresses']) == 0

# Generated at 2022-06-24 23:08:16.207504
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    var_0 = get_ethtool_data()

if __name__ == '__main__':
    # test_case_0()
    test_LinuxNetwork_get_ethtool_data()
    # for i in sys.argv[1:]:
    #     print globals()[i]()
    #     print

    # coverage run --append --rcfile=.coveragerc -m pytest -s -vv test.py
    # coverage report test.py
    # coverage html --rcfile=.coveragerc

# Generated at 2022-06-24 23:08:21.518769
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    var_test = []
    linux_network_0 = LinuxNetwork(var_test)
    var_test = linux_network_0.get_default_interfaces(linux_network_0)
    assert var_test is None



# Generated at 2022-06-24 23:08:26.455509
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():

    # Setup
    var_0 = []
    var_1 = 'device'
    linux_network_0 = LinuxNetwork(var_0)

    # Invocation
    var_2 = linux_network_0.get_ethtool_data(var_1)

    # Verification
    assert isinstance(var_2, dict)
    assert len(var_2) == 1



# Generated at 2022-06-24 23:08:29.421373
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    var_0 = []
    linux_network_0 = LinuxNetwork(var_0)
    var_3, var_4 = linux_network_0.get_default_interfaces(linux_network_0, linux_network_0, linux_network_0)


# Generated at 2022-06-24 23:08:34.932192
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    var_0 = []
    linux_network_0 = LinuxNetwork(var_0)
    var_1 = linux_network_0.get_ethtool_data('device')
    print(var_1)


# Generated at 2022-06-24 23:08:38.498418
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_0 = LinuxNetwork()
    var_1 = linux_network_0.get_interfaces_info(linux_network_0, linux_network_0, linux_network_0)


# Generated at 2022-06-24 23:08:44.791324
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Check if the class constructor is working.
    var_0 = []
    linux_network_0 = LinuxNetwork(var_0)
    var_1 = linux_network_0.get_default_interface()

if __name__ == '__main__':
    test_LinuxNetwork_get_default_interfaces()
    test_case_0()

# Generated at 2022-06-24 23:08:49.349570
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    print("Testing method get_interfaces_info of class LinuxNetwork")
    test_case_0()


# Generated at 2022-06-24 23:08:54.647194
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_str = "linux_network_str"
    linux_network = LinuxNetwork(linux_network_str)
    linux_network.get_ethtool_data(linux_network_str)


# Generated at 2022-06-24 23:09:32.223118
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    var_0 = LinuxNetwork(var_0)
    var_0.populate(var_0)


# Generated at 2022-06-24 23:09:39.183601
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network_0 = LinuxNetwork()
    var_0 = {}
    var_0['default'] = {}
    for var_1 in linux_network_0.get_default_interfaces(linux_network_0):
        var_0[var_1] = {'interface': var_0[var_1]}
    assert var_0 == linux_network_0.get_default_interfaces(linux_network_0)


# Generated at 2022-06-24 23:09:43.361858
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    var_0 = []
    linux_network_0 = LinuxNetwork(var_0)
    var_1 = linux_network_0.get_default_interfaces(linux_network_0)
    linux_network_0.get_ethtool_data(var_1)


# Generated at 2022-06-24 23:09:48.942375
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    var_2 = []
    var_2.append("eth0")
    var_3 = []
    linux_network_1 = LinuxNetwork(var_3)
    var_4 = linux_network_1.get_ethtool_data(var_2[0])
    print(var_4)


# Generated at 2022-06-24 23:09:56.323093
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    var_0 = []
    linux_network_0 = LinuxNetwork(var_0)
    linux_network_0.get_interfaces_info('/bin/ip', {'address': '127.0.0.1'}, {'address': '::'})
    linux_network_0.get_interfaces_info(var_0, {'address': '127.0.0.1'}, {'address': '::'})
    linux_network_0.get_interfaces_info([], {'address': '127.0.0.1'}, {'address': '::'})


# Generated at 2022-06-24 23:09:58.189110
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    var_0 = []
    linux_network_0 = LinuxNetwork(var_0)
    var_1 = linux_network_0.get_default_interfaces(linux_network_0)
    var_2 = linux_network_0.populate(var_1)


# Generated at 2022-06-24 23:10:07.787396
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    a = LinuxNetwork([], []).populate()
    if a:
        return

test_LinuxNetwork_populate.func_name = "test_LinuxNetwork_populate"
test_LinuxNetwork_populate.__doc__ = 'LinuxNetwork.populate'
test_LinuxNetwork_populate.success = '''
tests/test_linux_network.py::test_LinuxNetwork_populate PASSED
'''

test_case_0.func_name = "test_case_0"
test_case_0.__doc__ = 'no doc string; line 23'

# Generated at 2022-06-24 23:10:10.030166
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    var_0 = []
    linux_network_0 = LinuxNetwork(var_0)
    var_1 = linux_network_0.get_default_interfaces(linux_network_0)
    linux_network_0.populate()


# Generated at 2022-06-24 23:10:15.365823
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    obj = LinuxNetwork()

    # Test with default values
    arg_2 = None
    arg_3 = None
    arg_4 = None
    ret_obj = obj.get_interfaces_info(arg_2, arg_3, arg_4)
    assert ret_obj is not None


# Generated at 2022-06-24 23:10:19.734179
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    var_0 = []
    linux_network_0 = LinuxNetwork(var_0)
    var_1, var_2 = linux_network_0.get_interfaces_info(None, None, None)
