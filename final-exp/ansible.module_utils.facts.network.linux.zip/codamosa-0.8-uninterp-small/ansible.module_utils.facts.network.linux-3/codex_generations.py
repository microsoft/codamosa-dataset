

# Generated at 2022-06-24 23:01:21.916765
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    str_0 = '\n        until is evaluated after the execution of the task is complete,\n        and should not be templated during the regular post_validate step.\n        '
    linux_network_0 = LinuxNetwork(str_0)
    str_0 = '\n    until is evaluated after the execution of the task is complete,\n    and should not be templated during the regular post_validate step.\n    '
    str_1 = '\n        until is evaluated after the execution of the task is complete,\n        and should not be templated during the regular post_validate step.\n        '
    str_2 = '\n            until is evaluated after the execution of the task is complete,\n            and should not be templated during the regular post_validate step.\n            '
    str_3

# Generated at 2022-06-24 23:01:32.590801
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    str_0 = '\n        until is evaluated after the execution of the task is complete,\n        and should not be templated during the regular post_validate step.\n        '
    linux_network_0 = LinuxNetwork(str_0)
    str_1 = '2vw8d3l'
    str_2 = 'd05:16:a8:f4:b4:4a'
    str_3 = '6'
    str_4 = 'm'
    int_0 = 9
    str_5 = 'wQz3W8'
    str_6 = 'a'
    str_7 = 'l'
    str_8 = 'wR'
    str_9 = '7'
    str_10 = 'G5'
    str_11 = 'B'

# Generated at 2022-06-24 23:01:38.382686
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_0 = '\n        until is evaluated after the execution of the task is complete,\n        and should not be templated during the regular post_validate step.\n        '
    linux_network_0 = LinuxNetwork(str_0)
    result_0 = linux_network_0.get_default_interfaces()
    test_value_0 = {}
    assert result_0 == test_value_0


# Generated at 2022-06-24 23:01:43.847150
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    test_user_id = 'str_0'

    # Call to populate of class LinuxNetwork with args [p_args]
    linux_network_0 = LinuxNetwork(test_user_id)
    with pytest.raises(AnsibleUndefinedVariable) as excinfo:
        linux_network_0.populate(p_args)
    excinfo.match(
        'The variable `undefined_variable` was not defined in the Jinja2 context. '
        "Make sure you didn't make a typo and that it is available for the template you are using.")


# Generated at 2022-06-24 23:01:56.426408
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    str_0 = '\n        until is evaluated after the execution of the task is complete,\n        and should not be templated during the regular post_validate step.\n        '
    linux_network_0 = LinuxNetwork(str_0)

# Generated at 2022-06-24 23:01:59.357271
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    str_0 = '\n        until is evaluated after the execution of the task is complete,\n        and should not be templated during the regular post_validate step.\n        '
    linux_network_0 = LinuxNetwork(str_0)
    linux_network_0.get_interfaces_info('%c', '192.168.1.1', 'f')


# Generated at 2022-06-24 23:02:08.970689
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_0 = '\n        until is evaluated after the execution of the task is complete,\n        and should not be templated during the regular post_validate step.\n        '
    linux_network_0 = LinuxNetwork(str_0)
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_2['__class__'] = 'module.params'
    dict_2['__kwargtrans__'] = dict()
    dict_1['module'] = dict_2
    dict_2 = dict()
    dict_2['__class__'] = 'AnsibleModule'
    dict_2['get_bin_path'] = 'get_bin_path'
    dict_2['run_command'] = 'run_command'
    dict_2['check_mode'] = False

# Generated at 2022-06-24 23:02:18.440107
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    str_0 = "\n        until is evaluated after the execution of the task is complete,\n        and should not be templated during the regular post_validate step.\n        "
    interface_0, ips_0 = LinuxNetwork(str_0).get_interfaces_info()
    
    # Assert to ensure the type of interface is dictionary
    # Asserts the type of interface is dictionary
    assert type(interface_0) == dict
    
    # Assert to ensure the type of ips is dictionary
    # Asserts the type of ips is dictionary
    assert type(ips_0) == dict
    
    # Assert to ensure the key all_ipv4_addresses is present in ips
    # Asserts the presence of key all_ipv4_addresses in ips

# Generated at 2022-06-24 23:02:26.754561
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    net_0 = LinuxNetwork('/usr/local/bin/', '/usr/bin/ip')
    net_0._get_interfaces_info = MagicMock(return_value=([], {}))
    net_0._get_default_route = MagicMock(return_value=([], [['::1', '11', '::1']], {'eth0': {'module': 'e1000', 'mtu': 1500, 'macaddress': '52:54:00:12:34:56'}}))
    net_0.get_ethtool_data('eth0')
    # AssertionError: Lists differ: [] != ['ncq', 'ntuple', 'rx', 'tx', 'hw_tc_offload', 'tso', 'udp_fragmentation', 'udp_gro', 'fcoe_mtu', 'g

# Generated at 2022-06-24 23:02:32.930347
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    str_0 = '\n        until is evaluated after the execution of the task is complete,\n        and should not be templated during the regular post_validate step.\n        '
    linux_network_0 = LinuxNetwork(str_0)
    str_1 = 'eth0'
    dict_0 = linux_network_0.get_ethtool_data(str_1)
    # Uncomment next line and all assert statements if you want to print test results
    # print(dict_0)


# Generated at 2022-06-24 23:03:12.792199
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_0 = LinuxNetwork('')
    str_0 = '\n        until is evaluated after the execution of the task is complete,\n        and should not be templated during the regular post_validate step.\n        '
    str_1 = '\n        until is evaluated after the execution of the task is complete,\n        and should not be templated during the regular post_validate step.\n        '
    # linux_network_0.get_interfaces_info
    assert str_0 in linux_network_0.get_interfaces_info(str_1, str_0, str_0)


# Generated at 2022-06-24 23:03:19.894663
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Configuring a device and testing the method populate

    linux_network_0 = LinuxNetwork
    linux_network_0.module.params.update({"commit": True, "name": "enp1s0", "state": "up", "module": "ib_core"})

    linux_network_0.module.run_command = MagicMock(return_value=(0, '', ''))
    # Run method populate
    linux_network_0.populate()


# Generated at 2022-06-24 23:03:31.187761
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    str_0 = '\n        until is evaluated after the execution of the task is complete,\n        and should not be templated during the regular post_validate step.\n        '
    linux_network_0 = LinuxNetwork(str_0)
    # device_0 is str
    device_0 = "eth0"
    # self_1 is LinuxNetwork
    self_1 = linux_network_0
    # device_1 is str
    device_1 = device_0
    # ethtool_path_0 is str
    ethtool_path_0 = self_1.module.get_bin_path("ethtool")
    if ethtool_path_0:
        # args_0 is list
        args_0 = [ethtool_path_0, '-k', device_1]
        rc, stdout, stderr

# Generated at 2022-06-24 23:03:36.847556
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    str_0 = '\n        until is evaluated after the execution of the task is complete,\n        and should not be templated during the regular post_validate step.\n        '
    linux_network_0 = LinuxNetwork(str_0)
    linux_network_0.get_ethtool_data()



# Generated at 2022-06-24 23:03:43.961710
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # setup joe_network
    str_0 = '\n        if is evaluated during the regular post_validate step and should\n        be templated.\n        '
    str_1 = '\n        until is evaluated after the execution of the task is complete,\n        and should not be templated during the regular post_validate step.\n        '
    joe_network = LinuxNetwork(str_0)
    joe_network_1 = LinuxNetwork(str_1)
    joe_network.populate()
    # Test after population


# Generated at 2022-06-24 23:03:54.041294
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # FIXME: This test is failing on CentOS 7 / RHEL 7
    #        with the following error:
    #        No printable output from command: ['/usr/sbin/ip', 'route', 'list', '0/0']
    #        This is a very old unit test that is only used here.
    #        See GH-33018 for more details.
    if platform.dist()[0] in ['centos', 'redhat']:
        return
    linux_network_0 = LinuxNetwork()
    str_0 = '\n        until is evaluated after the execution of the task is complete,\n        and should not be templated during the regular post_validate step.\n        '
    str_1 = '10.10.10.10'
    str_2 = '172.10.10.10'
    str_

# Generated at 2022-06-24 23:04:02.913552
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_0 = '\n        until is evaluated after the execution of the task is complete,\n        and should not be templated during the regular post_validate step.\n        '
    linux_network_0 = LinuxNetwork(str_0)
    os_path_0 = {'exists': lambda: True}
    os_path_1 = {'exists': lambda: True}
    os.path = {'join': lambda: 'join', 'dirname': lambda: '/bin/ip'}
    os_makedirs_0 = {'defpath': lambda: 'defpath', 'path': lambda: ''}
    bin_path_0 = 'bin'
    os = {'path': os_path_0, 'makedirs': os_makedirs_0}

# Generated at 2022-06-24 23:04:14.239377
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    str_0 = '\n        until is evaluated after the execution of the task is complete,\n        and should not be templated during the regular post_validate step.\n        '
    linux_network_0 = LinuxNetwork(str_0)
    str_0 = 'foo'
    dict_0 = linux_network_0.get_ethtool_data(str_0)
    float_0 = float(dict_0)
    float_1 = float(['features', 'features'])
    str_1 = str(tuple(dict_0))
    str_2 = str(('features', 'features'))
    str_3 = str(()).join(dict_0)
    str_4 = str(('features', 'features'))
    str_5 = str(())
    str_6 = str("random")


# Generated at 2022-06-24 23:04:22.228821
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_0 = '\n        until is evaluated after the execution of the task is complete,\n        and should not be templated during the regular post_validate step.\n        '
    linux_network_0 = LinuxNetwork(str_0)
    _get_default_interfaces_0 = get_default_interfaces()
    dict_0 = {
        'interface': 'lo', 'address': '127.0.0.1', 'gateway': '::1',
        'address': '::1', 'gateway': '',
    }
    assert dict_0 == _get_default_interfaces_0
    _get_default_interfaces_1 = get_default_interfaces()
    assert _get_default_interfaces_0 == _get_default_interfaces_1


# Generated at 2022-06-24 23:04:34.361738
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    str_0 = '\n        until is evaluated after the execution of the task is complete,\n        and should not be templated during the regular post_validate step.\n        '
    linux_network_0 = LinuxNetwork(str_0)
    str_1 = '/bin/true'
    str_2 = 'eth1'
    str_3 = '/bin/true'
    dict_4 = {str_3: str_3, 'version': 0}
    dict_5 = {str_3: str_3, 'options': {str_3: dict_4}, 'action': str_3, 'post_validate': str_3}
    dict_6 = {str_3: str_3, 'options': {str_3: dict_4}, 'action': str_3, 'post_validate': str_3}

# Generated at 2022-06-24 23:05:19.400113
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # TODO: Test error conditions
    # TODO: Test other configurations
    str_0 = None
    str_1 = '\n        until is evaluated after the execution of the task is complete,\n        and should not be templated during the regular post_validate step.\n        '
    linux_network_0 = LinuxNetwork(str_1)
    str_2 = '\n        until is evaluated after the e task is complete,\n        and should not be templated during the regular post_validate step.\n        '
    linux_network_1 = LinuxNetwork(str_2)
    assert not linux_network_1._LinuxNetwork__g_0

# Generated at 2022-06-24 23:05:30.675166
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    test_case_0()
    # Test when Path is set to /sbin/ip
    linux_network_0 = LinuxNetwork(Path='/sbin/ip')
    _, _ = linux_network_0.get_default_interfaces()

    # Test when Path is set to /bin/ip
    linux_network_1 = LinuxNetwork(Path='/bin/ip')
    _, _ = linux_network_1.get_default_interfaces()

    # Test when Path is set to /usr/sbin/ip
    linux_network_2 = LinuxNetwork(Path='/usr/sbin/ip')
    _, _ = linux_network_2.get_default_interfaces()

    # Test when Path is set to /usr/bin/ip

# Generated at 2022-06-24 23:05:40.416977
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    parameters = dict(
        ip_path = 'ip_path',
        default_ipv4 = dict(),
        default_ipv6 = dict(),
    )
    try:
        # call the method and check the result
        linux_network_0 = LinuxNetwork(str_0)
        result = linux_network_0.get_interfaces_info(**parameters)
        assert result is not None
    except Exception as error:
       fail('Test case "test_LinuxNetwork_get_interfaces_info" failed: '+ str(error))


# Generated at 2022-06-24 23:05:45.264823
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    pass


# Generated at 2022-06-24 23:05:54.648049
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    args = {
        'name': 'test_LinuxNetwork_populate',
        'gateway': '192.0.2.1',
        'state': 'ipv6_absent',
        'network': '192.0.2.0',
        'prefix': 64,
        'mtu': 1500,
        'address': '192.0.2.254',
        'broadcast': '192.0.2.255',
        'netmask': '255.255.255.0',
        'onboot': True,
        'dns1': '192.0.2.1',
        'dns2': '192.0.2.2',
    }

    linux_network_0 = LinuxNetwork(args)

    linux_network_0.state = 'ipv6_present'
    linux_network_0

# Generated at 2022-06-24 23:05:57.836684
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    str_0 = ''
    get_ethtool_data_0 = LinuxNetwork(str_0).get_ethtool_data(str_0)
    str_1 = ''
    get_ethtool_data_1 = LinuxNetwork(str_1).get_ethtool_data(str_1)


# Generated at 2022-06-24 23:06:07.371925
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    #
    str_0 = '\n        until is evaluated after the execution of the task is complete,\n        and should not be templated during the regular post_validate step.\n        '
    linux_network_0 = LinuxNetwork(str_0)
    str_0 = '\n        until is evaluated after the execution of the task is complete,\n        and should not be templated during the regular post_validate step.\n        '
    linux_network_0 = LinuxNetwork(str_0)
    linux_network_0.get_interfaces_info()


# Generated at 2022-06-24 23:06:15.196931
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_0 = LinuxNetwork()
    device_0 = 'enp2s0'
    args = [ethtool_path, '-k', device_0]
    rc, stdout, stderr = self.module.run_command(args, errors='surrogate_then_replace')
    features = {}
    for line in stdout.strip().splitlines():
        key, value = line.split(": ")
        features[key.strip().replace('-', '_')] = value.strip()
    linux_network_0.get_ethtool_data(device_0)


# Generated at 2022-06-24 23:06:18.672944
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    str_0 = '\n        until is evaluated after the execution of the task is complete,\n        and should not be templated during the regular post_validate step.\n        '
    linux_network_0 = LinuxNetwork(str_0)


# Generated at 2022-06-24 23:06:20.521368
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # FIXME: write test cases
    pass


# Generated at 2022-06-24 23:07:04.388309
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_0 = LinuxNetwork('\n        until is evaluated after the execution o the task is complete,\n        and sould not be templated during the regular post_validate step.\n        ')
    linux_network_0.populate(None, None, None)


# Generated at 2022-06-24 23:07:11.241883
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    str_0 = '\n        until is evaluated after the execution o the task is complete,\n        and sould not be templated during the regular post_validate step.\n        '
    linux_network_0 = LinuxNetwork(str_0)
    str_1 = 'pciid'
    var_0 = linux_network_0.get_ethtool_data(str_1)


# Generated at 2022-06-24 23:07:17.512602
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    str_0 = '\n        until is evaluated after the execution o the task is complete,\n        and sould not be templated during the regular post_validate step.\n        '
    linux_network_0 = LinuxNetwork(str_0)
    facts_0 = {
        'network': {},
    }
    str_1 = '\n        until is evaluated after the execution o the task is complete,\n        and sould not be templated during the regular post_validate step.\n        '
    result_0 = linux_network_0.populate(facts_0, str_1)


# Generated at 2022-06-24 23:07:21.957920
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = 'LinuxNetwork'
    linux_network_0 = LinuxNetwork(module)
    var_0 = linux_network_0.populate()


# Generated at 2022-06-24 23:07:30.845466
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    str_0 = '\n        until is evaluated after the execution o the task is complete,\n        and sould not be templated during the regular post_validate step.\n        '
    linux_network_0 = LinuxNetwork(str_0)
    str_1 = '\n        until is evaluated after the execution o the task is complete,\n        and sould not be templated during the regular post_validate step.\n        '
    module_0 = ModuleStub(str_1)
    linux_network_0.module = module_0
    str_2 = 'not_a_valid_path'
    module_0.ip = str_2
    linux_network_0.populate()


# Generated at 2022-06-24 23:07:36.542940
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    dict_0 = dict()
    dict_0['changed'] = True
    dict_0['failed'] = True
    dict_0['rc'] = 0
    dict_0['stdout'] = ''
    dict_0['stdout_lines'] = []
    dict_0['warnings'] = []

    # Test for instance creation of class LinuxNetworkCollector
    linux_network_collector_0 = LinuxNetworkCollector(dict_0)

    # Test for class method post_process()
    dict_1 = dict()
    dict_1['ansible_facts'] = dict()
    dict_1['ansible_facts']['ansible_net_interfaces'] = dict()
    dict_1['ansible_facts']['ansible_net_interfaces']['ansible_net_interfaces_dummy0'] = dict

# Generated at 2022-06-24 23:07:37.854998
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # test case 0
    test_case_0()


# Generated at 2022-06-24 23:07:46.435749
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network_0 = LinuxNetwork(None)
    # Test with no default route
    var_0 = dict(address='192.168.1.1', interface='eth0', network='192.168.1.0', netmask='255.255.255.0')
    var_1 = dict(address='2001:db8:2001:db8:2001:db8:2001:db8', interface='eth0', network='2001:db8:2001:db8:2001:db8:2001:db8', prefix='128')
    # default route

# Generated at 2022-06-24 23:07:58.207171
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    str_0 = '\n        until is evaluated after the execution o the task is complete,\n        and sould not be templated during the regular post_validate step.\n        '
    linux_network_0 = LinuxNetwork(str_0)
    linux_network_0.populate()
    var_0 = linux_network_0.results

# Generated at 2022-06-24 23:08:00.848517
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    # FIXME: could not get this to work (prob a python -v issue)
    # TODO: write as a pytest test
    # LinuxNetwork_populate_0()
    pass


# Generated at 2022-06-24 23:08:45.159637
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # FIXME: need a proper example, the test0.py seems pretty meaningless
    test_case_0()


# Generated at 2022-06-24 23:08:50.415360
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_0 = LinuxNetwork('\n        until is evaluated after the execution o the task is complete,\n        and sould not be templated during the regular post_validate step.\n        ')
    linux_network_0.get_ethtool_data('d')


# Generated at 2022-06-24 23:08:51.629965
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # FIXME: test not implemented
    assert False



# Generated at 2022-06-24 23:08:59.433455
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    str_0 = '\n            until is evaluated after the execution o the task is complete,\n            and sould not be templated during the regular post_validate step.\n            '
    linux_network_0 = LinuxNetwork(str_0)
    var_0 = linux_network_0.get_default_interfaces(linux_network_0)


# Generated at 2022-06-24 23:09:01.254720
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    print('Testing get_default_interfaces()')
    test_case_0()


# Generated at 2022-06-24 23:09:08.352171
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_0 = LinuxNetwork()
    # default_ipv4 and default_ipv6 are unmutated dict objects that
    # point to memory slots that we can resolve from inside the
    # called method. these can be set to None but we expect them to
    # be dicts because that's the way that this works.
    default_ipv4 = dict(address=None)
    default_ipv6 = dict(address=None)

    # TODO: verify that a 3rd argument (ip_path) is required
    var_0 = linux_network_0.get_interfaces_info(None, default_ipv4, default_ipv6)


# Generated at 2022-06-24 23:09:12.613718
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_0 = '\n        until is evaluated after the execution o the task is complete,\n        and sould not be templated during the regular post_validate step.\n        '
    linux_network_0 = LinuxNetwork(str_0)
    var_0 = linux_network_0.get_default_interfaces(linux_network_0)



# Generated at 2022-06-24 23:09:15.253522
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # FIXME: enable these tests when this module is working again
    # FIXME: probably for 2.11 or 2.12
    # FIXME: create a new file for these tests and remove this stub function
    return
    test_case_0()


# Generated at 2022-06-24 23:09:20.005121
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_0 = LinuxNetwork(None)
    var_0 = linux_network_0.get_interfaces_info('', None, None)


# Generated at 2022-06-24 23:09:28.296014
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-24 23:10:24.325501
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_0 = '\n        until is evaluated after the execution o the task is complete,\n        and sould not be templated during the regular post_validate step.\n        '
    linux_network_0 = LinuxNetwork(str_0)
    var_0 = linux_network_0.get_default_interfaces(linux_network_0)
    assert var_0[0] == 'lo'


# Generated at 2022-06-24 23:10:27.523784
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    str_0 = '\n        until is evaluated after the execution o the task is complete,\n        and sould not be templated during the regular post_validate step.\n        '
    linux_network_collector_0 = LinuxNetworkCollector(str_0)

if __name__ == '__main__':
    test_case_0()


# Generated at 2022-06-24 23:10:29.570296
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Test case 0
    try:
        test_case_0()
    except Exception as e:
        print('Caught exception: ' + str(e))


# Generated at 2022-06-24 23:10:41.078509
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    str_0 = '\n        until is evaluated after the execution o the task is complete,\n        and sould not be templated during the regular post_validate step.\n        '
    linux_network_0 = LinuxNetwork(str_0)
    dict_0 = dict()
    dict_0['ipv4'] = dict()
    dict_0['ipv4']['address'] = '172.16.0.9'
    dict_0['ipv4']['broadcast'] = ''
    dict_0['ipv4']['gateway'] = '172.16.0.1'
    dict_0['ipv4']['interface'] = 'eth0'
    dict_0['ipv4']['macaddress'] = '08:00:27:05:b1:64'
    dict