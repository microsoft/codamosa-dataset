

# Generated at 2022-06-24 23:01:26.421582
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Create a mock module object and assign a module argument parse
    # to it as a mock
    mock_module = MagicMock()
    mock_module.params = {'gather_subset': 'all'}
    # Create a mock module object and assign a module argument parse
    # to it as a mock
    mock_module.get_bin_path.return_value = '/usr/bin/ethtool'
    # Create a mock class object
    mock_LinuxNetworkClass = MagicMock()
    mock_LinuxNetworkClass.return_value = LinuxNetworkCollector()
    # Create a mock module object and assign a module argument parse
    # to it as a mock
    mock_module.run_command.return_value = (0, 'mock_command_stdout_output', 'mock_command_stderr_output')
    #

# Generated at 2022-06-24 23:01:37.745242
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_collector_0 = LinuxNetworkCollector()

    device = "eth0"
    expected_result = {
        'features': {
            'rx': 'off',
            'tx': 'off',
            'sg': 'off',
            'tso': 'on',
            'gso': 'off',
            'gro': 'on',
            'lro': 'off',
            'rxvlan': 'off',
            'txvlan': 'off',
            'ntuple': 'off',
            'rxhash': 'off'
        },
        'timestamping': [
            'software',
            'legacy_software',
        ],
        'hw_timestamp_filters': [
            'none',
            'all',
        ],
        'phc_index': 1234
    }



# Generated at 2022-06-24 23:01:45.739786
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # ...
    print('=== Start of test')
    module = AnsibleModule(
        argument_spec={}
    )
    linux_network = LinuxNetwork(module)
    print(linux_network.default_ipv4)
    print(linux_network.default_ipv6)
    print(linux_network.interfaces)
    print(linux_network.ips)
    print(linux_network.gateway_ipv4)
    print(linux_network.gateway_ipv6)
    print('=== End of test')



# Generated at 2022-06-24 23:01:56.141779
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network_collector_1 = LinuxNetworkCollector()
    # TODO: move this to test_case_0
    ip_path = linux_network_collector_1.module.get_bin_path("ip")
    default_ipv4, default_ipv6 = linux_network_collector_1.get_default_interfaces(ip_path)
    # TODO: AssertionError: None != {'address': '172.17.0.1', 'gateway': '172.17.0.1'}
    # TODO: assertEqual(None, default_ipv4)
    assertEqual(None, default_ipv4)
    assertEqual(None, default_ipv6)


# Generated at 2022-06-24 23:01:58.261266
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # FIXME: this test case needs to write a script to create a test interface for ethtool to parse
    # FIXME: and then mock out module.get_bin_path and module.run_command to mock that output
    assert True


# Generated at 2022-06-24 23:02:05.489856
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_collector_0 = LinuxNetworkCollector()
    linux_network_collector_0.populate()
    print([getattr(linux_network_collector_0, attr) for attr in dir(linux_network_collector_0) if not callable(attr) and not attr.startswith("__")])



# Generated at 2022-06-24 23:02:16.839349
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_collector_0 = LinuxNetworkCollector()
    ip_path = '/sbin/ip'
    default_ip_v4_dict = {'address': '10.56.70.32', 'prefix': '24', 'scope': 'global', 'broadcast': '10.56.70.255', 'netmask': '255.255.255.0', 'network': '10.56.70.0'}
    default_ip_v6_dict = {'address': 'fe80::250:56ff:fe70:32', 'prefix': '64', 'scope': 'link'}
    interfaces_info_dict, ips_dict = linux_network_collector_0.get_interfaces_info(ip_path, default_ip_v4_dict, default_ip_v6_dict)

# Unit

# Generated at 2022-06-24 23:02:22.398048
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_collector_0 = LinuxNetworkCollector()
    interfaces, ips = linux_network_collector_0.get_interfaces_info("/sbin/ip", {'address': '127.0.0.1'},
                                                            {'address': '::1'})
    assert interfaces != None
    assert ips != None

if __name__ == '__main__':
    test_LinuxNetwork_get_interfaces_info()

# Generated at 2022-06-24 23:02:26.908817
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    collector = LinuxNetworkCollector()
    network = LinuxNetwork()
    network.populate(collector)


# Generated at 2022-06-24 23:02:32.636400
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    linux_network_collector_0 = LinuxNetworkCollector()
    assert linux_network_collector_0.facts_collected == {'network'}
    assert linux_network_collector_0.required_facts == {'distribution', 'platform'}
    assert linux_network_collector_0.platform == 'Linux'

# Generated at 2022-06-24 23:03:10.395495
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    str_0 = '00:00:00:00:00:00'
    linux_network_collector_0 = LinuxNetworkCollector(str_0)
    var_0 = linux_network_collector_0.get_interfaces_info(str_0, linux_network_collector_0, linux_network_collector_0)


if __name__ == '__main__':
    import logging
    logging.basicConfig(level=logging.DEBUG, format="%(asctime)s %(levelname)s %(message)s")
    # logging.disable(logging.DEBUG)
    test_LinuxNetworkCollector()

# Generated at 2022-06-24 23:03:17.473624
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_0 = '00:00:00:00:00:00'
    linux_network_0 = LinuxNetwork(str_0)
    var_0 = linux_network_0.get_default_interfaces()
    assert var_0[0]['interface'] == 'eth0'
    assert var_0[1]['interface'] == 'eth0'


# Generated at 2022-06-24 23:03:29.036749
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    first_call = get_file_content_mock

# Generated at 2022-06-24 23:03:33.620767
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Test parameters
    obj = LinuxNetwork('00:00:00:00:00:00')
    ip_path = 'str_0'

    # Test results
    obj.get_default_interfaces(ip_path)


# Generated at 2022-06-24 23:03:35.184472
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    str_0 = '00:00:00:00:00:00'
    linux_network_collector_0 = LinuxNetworkCollector('00:00:00:00:00:00')
    # TODO: unit test assert 


# Generated at 2022-06-24 23:03:42.419171
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Setup test fixture
    str_0 = '00:00:00:00:00:00'
    linux_network_0 = LinuxNetwork(str_0)
    str_1 = '10.0.0.0/8'
    str_2 = '01:02:03:04:05:06'
    linux_network_0.get_linux_distribution(str_1, str_2)
    # Exercise preconditions

    # Exercise SUT
    var_0 = linux_network_0.get_interfaces_info(str_0, linux_network_0, linux_network_0)
    # Verify postconditions

    # Cleanup test fixture


# Unit test main

# Generated at 2022-06-24 23:03:47.907526
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    str_0 = '00:00:00:00:00:00'
    str_1 = '01:01:01:01:01:01'
    str_2 = '00:01:02:00:02:01'
    str_3 = '00:01:03:00:03:01'
    str_4 = '00:01:04:00:04:01'
    str_5 = '00:01:05:00:05:01'
    str_6 = '00:01:06:00:06:01'
    str_7 = '00:01:07:00:07:01'
    str_8 = '00:01:08:00:08:01'
    str_9 = '00:01:09:00:09:01'

# Generated at 2022-06-24 23:03:51.325118
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_0 = '00:00:00:00:00:00'
    linux_network_0 = LinuxNetwork(str_0)
    var_0 = linux_network_0.get_default_interfaces()


# Generated at 2022-06-24 23:03:54.158568
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    print('Testing populate...')
    linux_network_0 = LinuxNetwork()
    # TODO: test something


# Generated at 2022-06-24 23:04:00.825225
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    # NOTE: When testing a class method, it's not necessary to create an instance of that class,
    #       unless the method tests the constructor.
    #
    #       In the case of the method: get_interfaces_info, it does not test the constructor, and
    #       does not depend on any other members of the class. Therefore, it is safe to call
    #       without constructing a LinuxNetwork object.
    #
    # TESTCASE NUMBER: 0
    test_case_0()


# Generated at 2022-06-24 23:04:43.640223
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    print("Testing LinuxNetwork.get_interfaces_info")
    test_case_0()
    print("No exceptions raised\n")

if __name__ == '__main__':
    print("Testing LinuxNetwork.get_interfaces_info")
    test_LinuxNetwork_get_interfaces_info()
    print("Done")

# Generated at 2022-06-24 23:04:46.862275
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_0 = LinuxNetwork('')
    str_0 = 'some_if'
    var_0 = linux_network_0.get_ethtool_data(str_0)
    assert var_0 in (None, 0)


# Generated at 2022-06-24 23:04:54.505953
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():

    linux_network_0 = LinuxNetwork('0000:00:00.0')
    linux_network_0.get_ethtool_data('eth0') # Null ptr deref, fixed
    linux_network_0.get_ethtool_data('lo') # Null ptr deref, not fixed


# Generated at 2022-06-24 23:04:57.227638
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    str_0 = '00:00:00:00:00:00'
    linux_network_0 = LinuxNetwork(str_0)
    var_0 = linux_network_0.get_interfaces_info(str_0, linux_network_0, linux_network_0)


# Generated at 2022-06-24 23:05:03.419007
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    str_0 = '0123456789abcdef'
    linux_network_0 = LinuxNetwork(str_0)
    str_1 = '0123456789abcdef0123456789abcdef'
    dict_0 = linux_network_0.get_interfaces_info(str_0, linux_network_0, linux_network_0)
    linux_network_0.populate(str_1, dict_0, dict_0)


# Generated at 2022-06-24 23:05:11.590301
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Ctor from `_ANSIBLE_ARGS`
    module_0 = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    # TODO: mock
    # linux_network = LinuxNetwork(module)
    # linux_network.get_interfaces_info(ip_path, default_ipv4, default_ipv6)

    # TODO: test get_default_interfaces()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 23:05:15.140409
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_0 = '00:00:00:00:00:00'
    linux_network_0 = LinuxNetwork(str_0)
    var_0 = linux_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 23:05:20.568411
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    str_0 = '00:00:00:00:00:00'
    str_1 = 'device'
    linux_network_0 = LinuxNetwork(str_0)
    linux_network_0.get_ethtool_data(str_1)


# Generated at 2022-06-24 23:05:24.709641
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Prepare the parameters and execute the call
    str_0 = '00:00:00:00:00:00'
    str_1 = '00:00:00:00:00:00'
    bool_0 = False
    linux_network_0 = LinuxNetwork(str_0)
    linux_network_0.populate(str_1, bool_0)


# Generated at 2022-06-24 23:05:34.089070
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    str_0 = '00:00:00:00:00:00'
    dict_0 = dict()
    dict_0['changed'] = False
    dict_0['failed'] = False
    dict_1 = dict()
    dict_1['changed'] = False
    dict_1['failed'] = False
    dict_1['_ansible_verbose_always'] = False
    dict_1['_ansible_no_log'] = False
    dict_1['_ansible_verbosity'] = 0
    linux_network_0 = LinuxNetwork(str_0)
    linux_network_0.populate(dict_0, dict_1)


# Generated at 2022-06-24 23:06:16.838903
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    str_0 = 'test'
    str_1 = 'test'
    linux_network_0 = LinuxNetwork(str_0, str_1)
    linux_network_0.populate()


# Generated at 2022-06-24 23:06:26.741788
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    print("Testing method populate of class LinuxNetwork")

    # set up object
    linux_network_0 = LinuxNetwork("lo")

    # set up parameters
    data = dict(
        interfaces = dict(
            eth0 = dict(
                active = True,
                device = "eth0",
                macaddress = "00:00:00:00:00:00",
                mtu = 1500,
                module = "igb",
                type = "unknown",
            )
        )
    )

    # test the run
    # less than ideal, but necessary to get around the conditional
    linux_network_0.populate(data)

    # check for idempotency
    linux_network_0.populate(data)

    # check the result
    # FIXME: add the test once you can print a dict
    # print(

# Generated at 2022-06-24 23:06:30.765435
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network = LinuxNetwork('')
    var_0 = linux_network.get_default_interfaces('')
    assert var_0 == ({'address': '', 'gateway': ''}, {'address': '', 'gateway': ''})


# Generated at 2022-06-24 23:06:36.584850
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    str_0 = '00:00:00:00:00:00'
    linux_network_1 = LinuxNetwork(str_0)
    str_1 = '00:00:00:00:00:00'
    var_0 = linux_network_1.get_ethtool_data(str_1)
    assert var_0 == {}
    str_2 = '00:00:00:00:00:00'
    var_1 = linux_network_1.get_ethtool_data(str_2)
    assert var_1 == {}
    str_3 = '00:00:00:00:00:00'
    var_2 = linux_network_1.get_ethtool_data(str_3)
    assert var_2 == {}

# Generated at 2022-06-24 23:06:47.686966
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    str_1 = '00:00:00:00:00:00'
    linux_network_1 = LinuxNetwork(str_1)
    var_1 = linux_network_1.get_interfaces_info(str_1, str_1, str_1)

# Generated at 2022-06-24 23:06:51.200587
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_0 = '00:00:00:00:00:00'
    linux_network_0 = LinuxNetwork(str_0)
    var_0 = linux_network_0.get_default_interfaces(str_0)


# Generated at 2022-06-24 23:07:00.160918
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    str_0 = '00:00:00:00:00:00'
    linux_network_0 = LinuxNetwork(str_0)
    dict_0 = dict()
    dict_1 = dict()
    dict_0['all_ipv4_addresses'] = []
    linux_network_0.populate('all_ipv4_addresses', dict_0['all_ipv4_addresses'], dict_1)
    assert len(dict_0) == 1
    assert len(dict_1) == 1
    assert linux_network_0.populate('all_ipv4_addresses', dict_0['all_ipv4_addresses'], dict_1) == None


# Generated at 2022-06-24 23:07:05.072417
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    str_1 = '00:00:00:00:00:00'
    linux_network_0 = LinuxNetwork(str_1)
    str_2 = '00:00:00:00:00:00'
    dict_0 = linux_network_0.get_ethtool_data(str_2)
    str_3 = '00:00:00:00:00:00'
    dict_1 = linux_network_0.get_ethtool_data(str_3)


# Generated at 2022-06-24 23:07:09.989854
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    str_0 = '00:00:00:00:00:00'
    linux_network_0 = LinuxNetwork(str_0)
    str_1 = '00:00:00:00:00:00'
    bool_0 = linux_network_0.populate(str_1)


# Generated at 2022-06-24 23:07:12.721112
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    str_1 = 'lo'
    linux_network_1 = LinuxNetwork(str_1)
    var_1 = linux_network_1.get_ethtool_data(str_1)
    assert var_1 == {}


# Generated at 2022-06-24 23:07:51.057173
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    test_case_0()



# Generated at 2022-06-24 23:07:59.715671
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    str_0 = '00:00:00:00:00:00'
    linux_network_0 = LinuxNetwork(str_0)
    var_0 = linux_network_0.get_interfaces_info(str_0, str_0, str_0)
    var_1 = linux_network_0.get_ethtool_data(str_0)

test_LinuxNetwork_get_interfaces_info()
#test_case_0()

# Generated at 2022-06-24 23:08:01.362620
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network = LinuxNetwork()
    linux_network.get_interfaces_info()


# Generated at 2022-06-24 23:08:06.905983
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_0 = LinuxNetwork('test')
    units = []
    default_ipv4 = {}
    default_ipv6 = {}
    ip_path = 'test'
    var_0 = linux_network_0.get_interfaces_info(ip_path, default_ipv4, default_ipv6)
    # TODO: assert var_0 is returning a value as desired


# Generated at 2022-06-24 23:08:13.574276
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    networkModule = LinuxNetwork(None)

    dictionary = networkModule.get_ethtool_data("eth0")

    assert "features" in dictionary
    assert "timestamping" in dictionary
    assert "hw_timestamp_filters" in dictionary
    assert "phc_index" in dictionary


# Generated at 2022-06-24 23:08:22.248959
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    str_0 = '00:00:00:00:00:00'
    linux_network_0 = LinuxNetwork(str_0)
    arr_0 = ['ethtool', '-k', 'eth0']
    str_1 = 'no-tx-nocache-copy: on\n'
    str_2 = 'tx-nocache-copy: on\n'
    str_3 = 'no-tx-nocache-copy: off\n'
    str_4 = 'tx-nocache-copy: off\n'
    list_0 = [str_1, str_2, str_3, str_4]
    for str_5 in list_0:
        str_6 = '00:00:00:00:00:00'
        rc, str_7, str_8 = linux_network

# Generated at 2022-06-24 23:08:28.521967
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_0 = LinuxNetwork()
    device = 'eth0'
    str_0 = 'ethtool -k %s' % device
    assert linux_network_0.get_ethtool_data(device) == ('rc', 'out', 'err')

    linux_network_1 = LinuxNetwork()
    device = 'eth0'
    str_1 = 'ethtool -T %s' % device
    assert linux_network_0.get_ethtool_data(device) == ('rc', 'out', 'err')


# Generated at 2022-06-24 23:08:38.822646
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    str_0 = '00:00:00:00:00:00'
    str_1 = '00:00:00:00:00:00'
    str_2 = '00:00:00:00:00:00'
    str_3 = '00:00:00:00:00:00'
    str_4 = '00:00:00:00:00:00'
    str_5 = '00:00:00:00:00:00'
    str_6 = '00:00:00:00:00:00'
    str_7 = '00:00:00:00:00:00'
    str_8 = '00:00:00:00:00:00'
    linux_network_0 = LinuxNetwork(str_0)
    linux_network_0.get_default_interfaces

# Generated at 2022-06-24 23:08:47.914373
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Defining a helper function for test
    def run_test(self, args, result):
        # NOTE: Could not use assertDictEqual because first value of self.module is a Dict whenever the second is always a string
        # Result
        self.module._populate(args)
        if result == self.module.module.params:
            self.module.module.exit_json(changed=False)
        else:
            self.module.module.fail_json(msg="The obtained result is different than the expected. Expected %r and obtained %r" % (result, self.module.module.params))
        
    # Defining attributes of the Class to test
    LinuxNetwork._populate = wrap_populate(LinuxNetwork._populate)
    linux_network_0 = LinuxNetwork(dict(interfaces=dict()))
    #

# Generated at 2022-06-24 23:08:50.172180
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_0 = LinuxNetwork()
    linux_network_0.populate()


# Generated at 2022-06-24 23:10:21.182474
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_0 = LinuxNetwork()
    linux_network_0.get_interfaces_info()


# Generated at 2022-06-24 23:10:27.281719
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_0 = LinuxNetwork('hZmRl8Y')
    var_0 = linux_network_0.get_default_interfaces('hZmRl8Y')
    linux_network_1 = LinuxNetwork('hZmRl8Y')
    var_1 = linux_network_1.get_interfaces_info('hZmRl8Y', 'hZmRl8Y', 'hZmRl8Y')


# Generated at 2022-06-24 23:10:32.507001
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network_0 = LinuxNetwork('')
    # var_0: default_ipv4, default_ipv6
    var_0 = linux_network_0.get_default_interfaces('')
    # var_1: v4, v6
    var_1 = linux_network_0.get_default_interfaces_using_iproute('')
    # var_2: linux_network_0.INTERFACE_TYPE
    var_2 = linux_network_0.INTERFACE_TYPE
    # var_3: linux_network_0.module
    var_3 = linux_network_0.module
    assert var_0[0] == {}
    assert var_0[1] == {}
    assert var_1[0] == {}
    assert var_1[1] == {}
    assert var_2

# Generated at 2022-06-24 23:10:35.905948
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    str_0 = '00:00:00:00:00:00'
    linux_network_0 = LinuxNetwork(str_0)
    linux_network_0.get_interfaces_info(str_0, str_0, str_0)


# Generated at 2022-06-24 23:10:41.255891
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():

    linux_network_0 = LinuxNetwork(None)
    str_0 = 'lo'
    data_0 = linux_network_0.get_ethtool_data(str_0)
    assert data_0.get('features') is None
    assert data_0.get('timestamping') is None
    assert data_0.get('hw_timestamp_filters') is None
    assert data_0.get('phc_index') is None



# Generated at 2022-06-24 23:10:50.954432
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    str_0 = '00:00:00:00:00:00'
    linux_network_0 = LinuxNetwork(str_0)
    str_1 = '00:00:00:00:00:00'