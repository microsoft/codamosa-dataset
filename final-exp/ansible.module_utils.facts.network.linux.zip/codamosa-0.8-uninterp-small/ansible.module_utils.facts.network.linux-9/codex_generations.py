

# Generated at 2022-06-24 23:01:17.475622
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    str_0 = 'F\x0b@\x10'
    linux_network_0 = LinuxNetwork(str_0)
    str_0 = 'hX\x03`^'
    str_1 = '\x1a\x96\x8c\xd3\xf2\x9df(t\xbb\xa7\x1b\x0c\x83\xe5\x91\x90H\x7f\x8a\x7f'

# Generated at 2022-06-24 23:01:26.817419
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    arg0 = '""+n6r=I\x0cR\x17jg;'
    linux_network_0 = LinuxNetwork(arg0)
    arg0_0 = '}'
    linux_network_0.get_ethtool_data(arg0_0)
    arg0_1 = '%5'
    linux_network_0.get_ethtool_data(arg0_1)
    arg0_2 = 'C!3WZ*?<'
    linux_network_0.get_ethtool_data(arg0_2)
    arg0_3 = '\\\x0e\x0b[4fL\x14b}'
    linux_network_0.get_ethtool_data(arg0_3)
    arg0_4 = 'W'
    linux_network_

# Generated at 2022-06-24 23:01:30.623356
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    str_0 = 'hY;X\tAyiQ'
    linux_network_0 = LinuxNetwork(str_0)
    linux_network_0.populate(*[None, None, None, None, None])


# Generated at 2022-06-24 23:01:42.402541
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    str_0 = 'y'
    linux_network_0 = LinuxNetwork(str_0)
    str_1 = 'b'
    int_2 = -2
    linux_network_0.populate(str_1, int_2)

# Generated at 2022-06-24 23:01:43.784161
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    assert_equal(LinuxNetwork.get_default_interfaces(), ('',''))


# Generated at 2022-06-24 23:01:56.425718
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_0 = '"Ewh[]n#&\rK\tbab'
    linux_network_0 = LinuxNetwork(str_0)
    linux_network_0.module.get_bin_path = lambda x: 'S-G'
    linux_network_0.module.run_command = lambda x: (0, "rtx&,zk!-\n/\n{'l~c[/KpZ\nn", None)
    # FIXME: possibly set self.module.params
    linux_network_0.module.params = {}
    str_1 = "cdcI"
    str_2 = "\rJ1u/p007-&:}\u0003"

# Generated at 2022-06-24 23:02:03.474743
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # FIXME: if we can't find ip, fake it?
    ip_path = LinuxNetwork.module.get_bin_path("ip")
    default_ipv4 = {}
    default_ipv6 = {}
    interfaces, ips = LinuxNetwork.get_interfaces_info(ip_path, default_ipv4, default_ipv6)
    str_0 = '"Ewh[]n#&\rK\tbab'
    assert False == (interfaces == str_0)
    assert False == (ips == str_0)


# Generated at 2022-06-24 23:02:07.971502
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_0 = '>~(RV7\x0cDz-5Kx\x0cV\n;q\x19\x10\x11\x12\x13\x14\x15\x16\x17\x18\x19\x1a\x1b\x1c\x1d\x1e\x1f !"#$%&\'()*+,-./0123456789:;<=>?'
    linux_network_0 = LinuxNetwork(str_0)
    linux_network_0.get_default_interfaces()


# Generated at 2022-06-24 23:02:15.427467
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    str_0 = 'g"B$;p,}<X>u,Ib'
    linux_network_0 = LinuxNetwork(str_0)
    linux_network_0.populate()

if __name__ == '__main__':
    # test_LinuxNetwork_populate()
    str_1 = '#F;A$*VT6p]UW'
    linux_network_1 = LinuxNetwork(str_1)
    linux_network_1.populate()
    linux_network_1.get_interfaces_info()

# Generated at 2022-06-24 23:02:19.771784
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    # Call method get_default_interfaces of class LinuxNetwork
    linux_network_0 = LinuxNetwork('"Ewh[]n#&\rK\tbab')
    linux_network_0.get_default_interfaces(True)


# Generated at 2022-06-24 23:02:55.714730
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    test_linux_network_collector = LinuxNetworkCollector()
    test_default_ipv4, test_default_ipv6 = test_linux_network_collector.get_default_interfaces()
    assert isinstance(test_default_ipv4, dict), 'test_default_ipv4 is an instance of dict class'
    assert isinstance(test_default_ipv6, dict), 'test_default_ipv6 is an instance of dict class'


# Generated at 2022-06-24 23:03:00.261534
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_collector_0 = LinuxNetworkCollector()
    linux_network_0 = LinuxNetwork()
    linux_network_collector_0.populate(linux_network_0)


# Generated at 2022-06-24 23:03:10.912363
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_populate_0 = LinuxNetwork()

# Generated at 2022-06-24 23:03:18.613549
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Arrange
    linux_network_collector_0 = LinuxNetworkCollector()
    # Act
    default_ipv4, default_ipv6 = linux_network_collector_0.get_default_interfaces()
    # Assert
    linux_network_collector_0.assert_ipv4_interface(default_ipv4)
    linux_network_collector_0.assert_ipv6_interface(default_ipv6)


# Generated at 2022-06-24 23:03:25.110186
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_collector_0 = LinuxNetworkCollector()
    # The following statements are used to check if the corresponding exception
    # is thrown or not
    try:
        linux_network_0 = LinuxNetwork()
        linux_network_0.populate()
    except Exception as e:
        print(e.message)


# Generated at 2022-06-24 23:03:35.358090
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: make this a real test
    # TODO: probably also need to make a test_LinuxNetwork_get_route_info()
    # TODO: (also see the comment in LinuxNetworkCollector.get_route_info())
    # TODO: also need to make a test for get_gateway_info() I think

    # NOTE: parameterized tests might be a good way to consolidate the different
    # NOTE: interface types for this test

    # NOTE: we have to use a real module for this
    module = AnsibleModule(
        argument_spec=dict()
    )

    collector = LinuxNetworkCollector(module)
    collector.get_interfaces_info()
    distinct_interfaces = collector.get_interfaces_info_distinct_interfaces()
    interfaces = collector.get_interfaces_info_interfaces()


# Generated at 2022-06-24 23:03:41.359813
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_collector_0 = LinuxNetworkCollector()

    ansible_facts_0 = {}
    linux_network_collector_0.populate(ansible_facts_0)

    assert ansible_facts_0 == {
        'ansible_interfaces': [],
        'ansible_all_ipv4_addresses': [],
        'ansible_all_ipv6_addresses': [],
        'ansible_default_ipv4': {},
        'ansible_default_ipv6': {},
    }



# Generated at 2022-06-24 23:03:49.065404
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    LinuxNetwork = LinuxNetworkCollector().LinuxNetwork

    module = AnsibleModule(
            argument_spec = dict(),
            supports_check_mode = True
    )

    interfaces = [
        'ethtool -k interface_name',
        'ethtool -T interface_name',
        ]

    expected_ansible_module_result = dict()

    # Mocking
    def get_bin_path_mock(command):
        return command

    def run_command_mock(args, **kwargs):
        if args[1] == '-k':
            rc = 0
            stdout = interfaces[0]
            stderr = ''
        elif args[1] == '-T':
            rc = 0
            stdout = interfaces[1]
            stderr = ''
        else:
            rc = 0
           

# Generated at 2022-06-24 23:03:55.177016
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    """
    Test get_default_interfaces method to make sure it returns correct output
    """
    linux_network_collector = LinuxNetworkCollector()
    ipv4_default_dict, ipv6_default_dict = linux_network_collector.get_default_interfaces()
    assert isinstance(ipv4_default_dict, dict)
    assert isinstance(ipv6_default_dict, dict)


# Generated at 2022-06-24 23:04:00.620227
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    linux_network_collector_0 = LinuxNetworkCollector()
    linux_network_get_default_interfaces_0 = linux_network_collector_0.get_default_interfaces()
    assert linux_network_get_default_interfaces_0[0]['address'] == '172.16.0.41'


# Generated at 2022-06-24 23:04:42.984273
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network_collector = LinuxNetworkCollector()
    cmd0 = ["cat", "/proc/net/route"]
    rc0, out0, err0 = linux_network_collector.module.run_command(cmd0)
    v6_routing_present = False
    dummy_results = {}
    # FIXME: what is this magic number?
    if len(err0.split('\n')) > 2:
        cmd1 = ["ip", "-6", "route"]
        rc1, out1, err1 = linux_network_collector.module.run_command(cmd1)
        v6_routing_present = True

# Generated at 2022-06-24 23:04:49.774759
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    linux_network_0 = LinuxNetwork()
    linux_network_collector_0 = LinuxNetworkCollector()

    # Mock module input parameters
    linux_network_collector_0.module.params = {'use_ipv6':True, 'config':None, 'commit':False, 'save':False}

    results = linux_network_0.get_default_interfaces(linux_network_collector_0)
    assert(results == {'default_ipv4': {}, 'default_ipv6': {}})


# Generated at 2022-06-24 23:04:55.653664
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    ipv4 = dict(address='10.0.0.10', network='10.0.0.0', netmask='255.255.255.0', broadcast='10.0.0.255')
    ipv6 = dict(address='2001:0db8:85a3:0000:0000:8a2e:0370:7334', prefix='128')
    interfaces, ips = linux_network_collector_0.get_interfaces_info(ip_path=None, default_ipv4=ipv4, default_ipv6=ipv6)
    assert interfaces['lo']['type'] == 'loopback'


# Generated at 2022-06-24 23:04:59.520107
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_collector_0 = LinuxNetworkCollector()
    device = ""
    linux_network_collector_0.get_ethtool_data(device)


# Generated at 2022-06-24 23:05:03.893215
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    collector = LinuxNetworkCollector()
    device = 'eth0'
    data = collector.get_ethtool_data(device)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data


# Generated at 2022-06-24 23:05:15.690014
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    default_ipv4 = {'address': '192.168.10.4'}
    default_ipv6 = {'address': 'fe80::2aa:ff:fe28:9c5a'}
    linux_network_collector_0 = LinuxNetworkCollector()
    interfaces, ips = linux_network_collector_0.get_interfaces_info("/sbin/ip", default_ipv4, default_ipv6)
    assert interfaces["ens33"]["ipv4"]["address"] == '192.168.10.4'
    assert interfaces["ens33"]["ipv4"]["broadcast"] == '192.168.10.255'
    assert interfaces["ens33"]["ipv4"]["netmask"] == '255.255.255.0'

# Generated at 2022-06-24 23:05:24.351279
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Test case 0
    linux_network_collector_0 = LinuxNetworkCollector()
    user_path = '/Users/jiangxiaotao'
    default_ipv4 = dict(address='127.0.0.1', family='AF_INET')
    default_ipv6 = dict(address='::1', family='AF_INET6')
    result = linux_network_collector_0.get_interfaces_info(user_path, default_ipv4, default_ipv6)
    # Verify the contents of the return value
    assert 'lo' in result[0]
    assert 'eth0' in result[0]
    assert 'all_ipv4_addresses' in result[1]


# Generated at 2022-06-24 23:05:36.505853
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import os
    import tempfile
    from ..sockets import generate_v4_interface_name
    from ..sockets import generate_v6_interface_name

    class Module(object):
        def __init__(self, default_ipv4, default_ipv6, ip_path):
            self._default_ipv4 = default_ipv4
            self._default_ipv6 = default_ipv6
            self._ip_path = ip_path
            self._ip_path

        def get_bin_path(self, name):
            return self._ip_path


# Generated at 2022-06-24 23:05:40.208357
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_collector_1 = LinuxNetworkCollector()
    linux_network_0 = LinuxNetwork()
    linux_network_collector_1.populate(linux_network_0)


# Generated at 2022-06-24 23:05:48.841311
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    test_interfaces = {
        'device': 'lo',
        'ipv4': {'address': '127.0.0.1', 'broadcast': '', 'netmask': '255.0.0.0', 'network': '127.0.0.0'},
        'ipv6': [{'address': '::1', 'prefix': '128', 'scope': 'host'}],
        'type': 'loopback'
    }
    path = os.path.join(THIS_DIR, 'interface_files')

    # pylint: disable=protected-access
    collector = LinuxNetworkCollector()
    interfaces = collector._get_interfaces_info(path)

    # Multiple asserts in test case
    # pylint: disable=too-many-boolean-expressions

# Generated at 2022-06-24 23:06:22.911671
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    with mock.patch.object(LinuxNetwork, 'get_file_content') as mock_get_content:
        mock_get_content.side_effect = ('/sys/class/net/br0',)
        mock_get_content.return_value = '0'
        bool_0 = False
        linux_network_0 = LinuxNetwork(bool_0, bool_0)
        str_0 = '/sys/class/net/eth0'
        var_0 = []
        var_1 = "ipv6"
        var_2 = []
        var_3 = linux_network_0.get_interfaces_info(str_0, var_0, var_1, var_2)

if __name__ == "__main__":
    test_case_0()
    #test_LinuxNetwork_get_interfaces_

# Generated at 2022-06-24 23:06:25.409585
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # TODO: Add test cases
    raise Exception("Unit Test Not Implemented")


# Generated at 2022-06-24 23:06:27.929979
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_0 = LinuxNetwork(bool_0, bool_0)

    assert linux_network_0.get_ethtool_data(str_0) == dict_0


# Generated at 2022-06-24 23:06:31.583884
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    print("\n")
    bool_0 = False
    linux_network_0 = LinuxNetwork(bool_0, bool_0)
    linux_network_0.get_ethtool_data(bool_0)


# Generated at 2022-06-24 23:06:38.800279
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    var_0 = get_module_path('ansible.module_utils.basic')
    basic_0 = import_module('basic', var_0)
    bool_0 = False
    linux_network_0 = LinuxNetwork(bool_0, bool_0)
    var_1 = linux_network_0.populate(basic_0)

# Test that default_ipv4 and default_ipv6 are updated when they are found

# Generated at 2022-06-24 23:06:40.438912
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Test case 0
    assert test_case_0() == True


# Generated at 2022-06-24 23:06:50.047863
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    # FIXME: this will work on an ubuntu box but not on a mac,
    # and it's a lot of setup, but there's no better way to test this.
    if not os.path.exists('/sys/class/net'):
        os.makedirs('/sys/class/net')

    bool_0 = False
    linux_network_0 = LinuxNetwork(bool_0, bool_0)

    # TODO: make a fake /sys/class/net and run a bunch of assertions on the output
    # var_0 = linux_network_0.populate()

    # FIXME: this is a really dumb regression test
    var_0 = linux_network_0.populate()
    assert var_0
    assert default_ipv4
    assert default_ipv6

    # Run test_case_0

# Generated at 2022-06-24 23:06:57.840140
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_0 = LinuxNetwork()
    bool_0 = False
    linux_network_0.populate(bool_0, bool_0)
    str_0 = linux_network_0.module._get_bin_path('ip')
    dict_0 = dict()
    dict_0['address'] = '0.0.0.0'
    dict_2 = dict()
    dict_2['address'] = '::'
    dict_3 = {'interface': 'lo', 'address': '127.0.0.1', 'gateway': '::'}
    dict_4 = {'interface': 'lo', 'address': '::1', 'gateway': '127.0.0.1'}

# Generated at 2022-06-24 23:07:00.524016
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    # FIXME: mock this out or instantiate a real LinuxNetwork?
    # FIXME: replace get_default_interfaces with _get_default_interfaces?
    linux_network_0 = LinuxNetwork(False, False)
    var_0 = linux_network_0.get_default_interfaces()



# Generated at 2022-06-24 23:07:03.627036
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    bool_0 = False
    linux_network_collector_0 = LinuxNetworkCollector(bool_0, bool_0)


# Generated at 2022-06-24 23:07:38.766763
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # FIXME: refactor to use a module argument and test against a mock
    has_ipv6 = os.path.exists("/proc/sys/net/ipv6")
    linux_network_0 = LinuxNetwork(False, has_ipv6)
    dev_0 = "enp0s31f6"
    ethtool_0 = linux_network_0.get_ethtool_data(dev_0)



# Generated at 2022-06-24 23:07:44.350658
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    bool_0 = False
    linux_network_0 = LinuxNetwork(bool_0, bool_0)
    device_0 = "device_0"
    data_0 = linux_network_0.get_ethtool_data(device_0)


# Generated at 2022-06-24 23:07:53.075636
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # TODO: use fuzzing
    address = '127.0.0.1'
    address_2 = '192.168.1.1'

    rc, stdout, stderr = module.run_command(['ip', 'route'], errors='surrogate_then_replace')

    # Split output of ip route into individual routes
    route_list = stdout.split('\n')

    # Check if loopback route exists in list
    if address in route_list[0]:
        assert route_list[0] == "default via %s dev lo  src %s metric 0" % (address, address)
    else:
        assert route_list[0] == "default via %s dev eth0  src %s metric 0" % (address_2, address_2)


# Generated at 2022-06-24 23:07:56.260092
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_1 = LinuxNetwork(bool_0, bool_0)
    var_48 = linux_network_1.get_interfaces_info(var_3, var_0, var_0)
    print(var_48)


# Generated at 2022-06-24 23:08:06.735748
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    print("Testing get_interfaces_info")
    test_dir = os.path.dirname(os.path.realpath(__file__))
    mock_dir = os.path.join(test_dir, "mock_environ_linux")
    get_bin_path = lambda name: os.path.join(mock_dir, name)
    # NOTE: we use the 'ip' binary from our mock_environ_linux directory
    # this binary does not require root privileges
    mock_module = MockModule(get_bin_path)
    linux_network_0 = LinuxNetwork(mock_module, False)
    # NOTE: the 'ip' binary in our mock_environ_linux directory has these
    # values hardcoded as defaults to emulate real world behavior
    ip_path = get_bin_path("ip")
    default

# Generated at 2022-06-24 23:08:10.527442
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_0 = LinuxNetwork(False, False)
    # Write your own code to test get_ethtool_data here


# Generated at 2022-06-24 23:08:14.827709
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    bool_0 = False
    linux_network_0 = LinuxNetwork(bool_0, bool_0)
    str_0 = 'bond0'
    var_0 = linux_network_0.get_ethtool_data(str_0)


# Generated at 2022-06-24 23:08:16.835951
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    print('Testing get_ethtool_data')
    # Put your test code here
    assert True


# Generated at 2022-06-24 23:08:19.739825
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    bool_0 = False


# Generated at 2022-06-24 23:08:21.609123
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    test_case_0()


if __name__ == '__main__':
    test_LinuxNetwork_populate()

# Generated at 2022-06-24 23:09:26.267754
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    try:
        test_case_0()
    except:
        var_0 = sys.exc_info()[1]
        print(var_0)

if __name__ == '__main__':
    test_LinuxNetwork_populate()

# Generated at 2022-06-24 23:09:28.005546
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    try:
        test_case_0()
    except Exception as err:
        print('Caught exception: ' + str(err))


# Generated at 2022-06-24 23:09:36.850679
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    bool_0 = False
    linux_network_0 = LinuxNetwork(bool_0, bool_0)
    linux_network_0.populate()
    arg_0 = dict()
    arg_0['address'] = 'address'
    arg_1 = dict()
    arg_1['address'] = 'address'
    var_0 = linux_network_0.get_interfaces_info(arg_0, arg_1)


# Generated at 2022-06-24 23:09:39.784713
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    bool_0 = False
    linux_network_0 = LinuxNetwork(bool_0, bool_0)
    str_0 = linux_network_0.get_ethtool_data()
    print(str_0)


# Generated at 2022-06-24 23:09:42.804358
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_0 = LinuxNetwork(False, False)
    str_0 = 'enp0s3'
    dict_0 = linux_network_0.get_ethtool_data(str_0)
    assert tuple_0 == dict_0


# Generated at 2022-06-24 23:09:45.318320
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    bool_0 = False
    linux_network_0 = LinuxNetwork(bool_0, bool_0)
    str_0 = 'ppp'
    var_0 = linux_network_0.get_ethtool_data(str_0)


# Generated at 2022-06-24 23:09:57.607814
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    bool_0 = False
    linux_network_0 = LinuxNetwork(bool_0, bool_0)
    assert linux_network_0.get_default_interfaces() == {'v4': {'broadcast': '192.168.1.255',
                                                              'address': '192.168.1.2',
                                                              'gateway': '192.168.1.1',
                                                              'netmask': '255.255.255.0',
                                                             },
                                                         'v6': {'address': 'fe80::42:2dff:fe90:6b3a',
                                                                'gateway': 'fe80::cafe:babe:1414',
                                                               },
                                                        },\
        'Failed get_default_interfaces'

#

# Generated at 2022-06-24 23:10:05.607993
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    bool_0 = False
    linux_network_0 = LinuxNetwork(bool_0, bool_0)
    str_0 = '25'
    str_1 = 'eOI'
    dict_0 = {'v4': {'gateway': 'eOI', 'address': '25'}, 'v6': {'gateway': 'eOI', 'address': '25'}}
    dict_1 = {'v4': {'gateway': 'eOI', 'address': '25'}, 'v6': {'gateway': 'eOI', 'address': '25'}}
    linux_network_0.get_interfaces_info(str_0, dict_0, dict_1)

# Generated at 2022-06-24 23:10:12.572899
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    print("test_LinuxNetwork_get_default_interfaces")
    bool_0 = False
    linux_network_0 = LinuxNetwork(bool_0, bool_0)
    var_12 = linux_network_0.get_default_interfaces()
    var_0 = var_12.get('gateway')
    var_1 = var_12.get('interface')
    var_2 = var_12.get('address')
    var_3 = var_12.get('gateway6')
    var_4 = var_12.get('interface6')
    var_5 = var_12.get('address6')
    var_6 = var_12.get('gateway6')
    var_7 = var_12.get('interface6')
    var_8 = var_12.get('address6')
    var_

# Generated at 2022-06-24 23:10:13.963735
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # TODO: add tests
    assert False
