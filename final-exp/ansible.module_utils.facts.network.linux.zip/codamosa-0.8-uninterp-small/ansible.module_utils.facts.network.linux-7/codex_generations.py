

# Generated at 2022-06-24 23:01:14.838840
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    str_0 = '3#/W#\t)'
    linux_network_0 = LinuxNetwork(str_0)
    str_1 = '1b9gg*5o\x7f'
    linux_network_0.get_ethtool_data(str_1)

if __name__ == '__main__':
    test_LinuxNetwork_get_ethtool_data()

# Generated at 2022-06-24 23:01:17.145999
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    str_0 = '3#/W#\t)'
    linux_network_0 = LinuxNetwork(str_0)
    str_1 = '4nhmf0\r1!g+=+'
    result = linux_network_0.get_ethtool_data(str_1)


# Generated at 2022-06-24 23:01:24.953752
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_0 = LinuxNetwork(None)
    str_0 = 'Local Area Connection'
    dict_0 = {}
    dict_1 = linux_network_0.get_interfaces_info(str_0, dict_0, dict_0)
    assert dict_1[0]['Local_Area_Connection']['ipv4']['address'] == '10.23.68.43'


# Generated at 2022-06-24 23:01:27.514058
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_0 = '3#/W#\t)'
    linux_network_0 = LinuxNetwork(str_0)
    linux_network_0.get_default_interfaces()


# Generated at 2022-06-24 23:01:35.554468
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    # TODO: add test case for check for iproute when no iproute2 installed (useful for darwin)
    # TODO: check for iproute in module utils, not in linux_network

    str_0 = '3#/W#\t)'
    linux_network_0 = LinuxNetwork(str_0)
    default_dict = {'v4': {}, 'v6': {}}
    interface_dict = {"name": "value"}
    # Call method
    result = linux_network_0.get_default_interfaces(default_dict, interface_dict)
    default_dict_expect = {'v4': {}, 'v6': {}}
    assert result == default_dict_expect


# Generated at 2022-06-24 23:01:40.310285
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    chars_0 = 'jY_d(gCm\x7fM\x7f3'
    linux_network_0 = LinuxNetwork(chars_0)
    assert linux_network_0.get_default_interfaces(chars_0) == (
        {'interface': 'enp0s31f6', 'address': '192.168.1.199'},
        {'interface': 'enp0s31f6', 'address': 'fe80::2e0:4cff:fe8a:70e5'}
    )


# Generated at 2022-06-24 23:01:42.297177
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    assert linux_network_0.get_ethtool_data == 'foo'


# Generated at 2022-06-24 23:01:44.169358
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_0 = LinuxNetwork()
    linux_network_0.get_ethtool_data()


# Generated at 2022-06-24 23:01:50.350146
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    network_0 = LinuxNetwork('str_0')
    default_ipv4 = LinuxNetwork_get_interfaces_info_default_ipv4
    default_ipv6 = LinuxNetwork_get_interfaces_info_default_ipv6
    ip_path = 'str_1'
    assert network_0.get_interfaces_info(ip_path, default_ipv4, default_ipv6) == LinuxNetwork_get_interfaces_info_result


# Generated at 2022-06-24 23:01:51.667472
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_0 = 'T0"/@'
    linux_network_0 = LinuxNetwork(str_0)
    linux_network_0.get_default_interfaces()


# Generated at 2022-06-24 23:02:17.477173
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # get ethtool path
    ethtool_path = module.get_bin_path("ethtool")
    # get ethtool data
    data = linux_network.get_ethtool_data(ethtool_path)

# Generated at 2022-06-24 23:02:21.366192
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    str_0 = '3#/W#\t)'
    linux_network_0 = LinuxNetwork(str_0)
    var_0 = linux_network_0.populate()

test_cases = [
    test_case_0,
    test_LinuxNetwork_populate,
]

# Generated at 2022-06-24 23:02:29.044504
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    str_0 = 'W8\x17\x16\x15\x06\x03\x04\x16\t\x0b\x1b\x14\x04\t\x03\x05\x1a\x01\x10\x05\x0f\x12\x01 " \x01\x1f\x0b\x12\x0c\x13\x05\x05\x0e\x08\r\x03\x1f\x1f\x0c\x06\x08\x11\x1f\x02\x1c\x0e\x06\x01\x1c\x14\x07\x0f\r'
    linux_network_0 = LinuxNetwork(str_0)

# Generated at 2022-06-24 23:02:33.709339
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    str_0 = '3#/W#\t)'
    arg = str_0
    linux_network_collector_0 = LinuxNetworkCollector(module, arg)


# Generated at 2022-06-24 23:02:36.657858
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    print("running unit test")
    # Create a LinuxNetwork
    linux_network_0 = LinuxNetwork('')
    # Call method get_default_interfaces
    result_0 = linux_network_0.get_default_interfaces()


# Generated at 2022-06-24 23:02:39.008715
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    str_0 = '3#/W#\t)'
    linux_network_0 = LinuxNetwork(str_0)
    var_0 = linux_network_0.populate()

# Generated at 2022-06-24 23:02:41.289551
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_0 = LinuxNetwork()
    ethtool_path = '/opt/ethtool'
    device = 'em1'
    var_0 = linux_network_0.get_ethtool_data(device)


# Generated at 2022-06-24 23:02:44.187350
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_0 = LinuxNetwork('3#/W#\t)')
    var_1 = linux_network_0.get_ethtool_data('')
    assert var_1 == {}


# Generated at 2022-06-24 23:02:51.845260
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    str_0 = '3#/W#\t)'
    linux_network_0 = LinuxNetwork(str_0)
    linux_network_0.populate()
    device = str_0
    var_1 = linux_network_0.get_ethtool_data(device)
    var_1 = None


# Generated at 2022-06-24 23:02:55.117523
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_0 = LinuxNetwork('')
    linux_network_0.get_ethtool_data('eth0')


# Generated at 2022-06-24 23:03:25.570721
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # interface = get_default_interfaces()
    pass


# Generated at 2022-06-24 23:03:35.606605
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_obj = LinuxNetwork(module='/usr/bin/python')

# Generated at 2022-06-24 23:03:43.521744
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_0 = '3#/W#\t)'
    linux_network_0 = LinuxNetwork(str_0)
    dict_0 = dict({'N_!': 'N_!', 'vi,a': 'vi,a', 'Pw7': 'Pw7', 'J': 'J', '-c.': '-c.', 'R': 'R'})
    linux_network_0.default_ipv4 = dict_0
    dict_0 = dict({'4': '4'})
    linux_network_0.default_ipv6 = dict_0

# Generated at 2022-06-24 23:03:49.063149
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    str_0 = 'p6f/cV^C@!\x7fU\x0b'
    linux_network_0 = LinuxNetwork(str_0)
    linux_network_0.populate()

# Generated at 2022-06-24 23:03:53.335319
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    str_0 = '3#/W#\t)'
    linux_network_0 = LinuxNetworkCollector(str_0)
    var_0 = linux_network_0._platform



# Generated at 2022-06-24 23:04:02.346618
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    str_0 = '3#/W#\t)'
    linux_network_0 = LinuxNetwork(str_0)
    linux_network_0.run(str_0)
    var_0 = linux_network_0.get_interfaces_info(str_0, str_0, str_0)
    var_0 = linux_network_0.get_interfaces_info(str_0, str_0, str_0)
    var_0 = linux_network_0.get_interfaces_info(str_0, str_0, str_0)
    var_0 = linux_network_0.get_interfaces_info(str_0, str_0, str_0)
    return var_0


# Generated at 2022-06-24 23:04:04.138131
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_0 = '5#\t'
    linux_network_0 = LinuxNetwork(str_0)
    var_0 = linux_network_0.get_default_interfaces(0)

# Generated at 2022-06-24 23:04:07.523538
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_0 = LinuxNetwork()
    var_0 = linux_network_0.populate()


# Generated at 2022-06-24 23:04:10.563409
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Test parameters
    ip_path = None
    default_ipv4 = None
    default_ipv6 = None

    linux_network_0 = LinuxNetwork()
    linux_network_0.get_default_interfaces(ip_path, default_ipv4, default_ipv6)


# Generated at 2022-06-24 23:04:17.921382
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    str_0 = '3#/W#\t)'
    linux_network_0 = LinuxNetwork(str_0)
    linux_network_collector_0 = LinuxNetworkCollector(linux_network_0, None)
    linux_network_collector_0 = LinuxNetworkCollector(linux_network_0, linux_network_0)
    linux_network_collector_0 = LinuxNetworkCollector(linux_network_0, None)


# Generated at 2022-06-24 23:05:02.928471
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_0 = '\'#4?B'
    linux_network_0 = LinuxNetwork(str_0)
    var_0 = linux_network_0.populate()
    str_1 = 'MD\x17'
    str_2 = 'J\t'
    var_1 = linux_network_0.get_default_interfaces('0',var_0,str_1,str_2)


# Generated at 2022-06-24 23:05:11.493606
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from test.test_common_control import get_bin_path
    from test.test_common_control import run_command, module
    module.get_bin_path = get_bin_path
    module.run_command = run_command
    # Test the module
    linux_network_0 = LinuxNetwork()
    device_0 = 'lo'
    var_0 = linux_network_0.get_ethtool_data(device_0)
    print(var_0)


# Generated at 2022-06-24 23:05:17.772416
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    str_0 = '3#/W#\t)'
    linux_network_0 = LinuxNetwork(str_0)
    assert_equal(linux_network_0.get_ethtool_data('device'), var_0)

test_case_0()
# -------------------------------------------------------------------------------
# Shamelessly stolen from Ansible!
# https://github.com/ansible/ansible/blob/devel/lib/ansible/module_utils/facts/network/base.py


# Generated at 2022-06-24 23:05:21.540937
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_0 = '3#/W#\t)'
    linux_network_0 = LinuxNetwork(str_0)
    var_0 = linux_network_0.get_default_interfaces()
    # (var_0) should be True
    assert var_0


# Generated at 2022-06-24 23:05:23.369388
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    str_0 = '3#/W#\t)'
    linux_network_0 = LinuxNetwork(str_0)
    var_0 = linux_network_0.populate()


# Generated at 2022-06-24 23:05:32.580326
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # LinuxNetwork_0 = LinuxNetwork()
    # LinuxNetwork_0.get_default_interfaces()

    # TODO: no case given, but this is probably the code from the module
    interface = {}
    ip_path = "ip"
    default_ipv4, default_ipv6 = linux_network_0.get_default_interfaces(ip_path)
    if default_ipv4['address'] == "127.0.0.1":
        raise Exception()
    else:
        return 1



# Generated at 2022-06-24 23:05:37.278127
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    str_0 = '3#/W#\t)'
    linux_network_0 = LinuxNetwork(str_0)
    var_0 = linux_network_0.populate()


# Generated at 2022-06-24 23:05:45.001755
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_0 = 'S:L1\003m\013\005'
    linux_network_0 = LinuxNetwork(str_0)
    linux_network_0.get_interfaces_info('/6C\026\026\034\025', '\032\022\022\022\022\022\022', '\032\022\022\022\022\022\022')
    var_0 = linux_network_0.get_default_interfaces()


# Generated at 2022-06-24 23:05:50.305510
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_0 = '3#/W#\t)'
    linux_network_0 = LinuxNetwork(str_0)
    var_0 = linux_network_0.populate()
    var_1, var_2 = linux_network_0.get_default_interfaces()


# Generated at 2022-06-24 23:05:54.381002
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_0 = LinuxNetwork()
    device = "eth1"
    var_0 = linux_network_0.get_ethtool_data(device)


if __name__ == "__main__":
    # FIXME: move to a test
    # get_file_content('/sys/class/net/lo/mtu')
    test_case_0()
    test_LinuxNetwork_get_ethtool_data()

# Generated at 2022-06-24 23:06:36.476691
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_0 = 'zm}FjIa['
    linux_network_0 = LinuxNetwork(str_0)
    tuple_0 = linux_network_0.get_default_interfaces()


# Generated at 2022-06-24 23:06:45.798264
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_0 = LinuxNetwork(None)
    linux_network_0.module.run_command = MagicMock(return_value=(0, '', ''))
    linux_network_0.INTERFACE_TYPE = dict()
    linux_network_0.get_ethtool_data = MagicMock(return_value=dict())
    linux_network_0.get_default_ipv4_and_ipv6 = MagicMock(return_value=(dict(), dict()))
    var_0 = linux_network_0.get_interfaces_info(str(), dict(), dict())


# Generated at 2022-06-24 23:06:49.820079
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    str_0 = "s]"
    linux_network_0 = LinuxNetwork(str_0)
    str_1 = "m'c"
    var_0 = linux_network_0.get_ethtool_data(str_1)
    assert var_0 == {}


# Generated at 2022-06-24 23:06:53.175221
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_0 = '3#/W#\t)'
    linux_network_0 = LinuxNetwork(str_0)
    linux_network_0.module = MagicMock()
    var_0 = linux_network_0.get_default_interfaces()


# Generated at 2022-06-24 23:06:59.583145
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_1 = '3#/W#\t)'
    linux_network_1 = LinuxNetwork(str_1)
    var_1 = linux_network_1.get_default_interfaces()
    assert var_1[0] == {'address': '192.168.23.180', 'gateway': '192.168.23.1', 'interface': 'eno1', 'netmask': 24}
    assert var_1[1] == {'gateway': 'fe80::5054:ff:fe59:6656%eno1', 'interface': 'eno1', 'scope': 'link'}


# Generated at 2022-06-24 23:07:04.864482
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # linux_network = LinuxNetwork(module)
    # linux_network.get_ethtool_data()
    pass

if __name__ == '__main__':
    # print (__file__)
    # test_LinuxNetwork_get_ethtool_data()
    test_case_0()

# Generated at 2022-06-24 23:07:08.245799
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    str_0 = '3#/W#\t)'
    linux_network_0 = LinuxNetwork(str_0)
    var_0 = linux_network_0.populate()

if __name__ == "__main__":
    test_case_0()
    test_LinuxNetwork_get_interfaces_info()

# Generated at 2022-06-24 23:07:12.076318
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_0 = LinuxNetwork()

    # Test with a different set of params
    # FIXME: add test
    # linux_network.get_interfaces_info(None, None, None)


# Generated at 2022-06-24 23:07:18.670405
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_0 = '3#/W#\t)'
    linux_network_0 = LinuxNetwork(str_0)
    var_0 = linux_network_0.get_default_interfaces()
    assert var_0 == (dict(address='172.31.0.2', broadcast='172.31.15.255', netmask='255.255.240.0', network='172.31.0.0', macaddress='06:5c:08:fc:2e:cf', mtu=9001, type='bridge', alias='eth1.100'), dict(address='fe80::65c:8ff:fefc:2ecf', prefix='64', scope='link'))



# Generated at 2022-06-24 23:07:25.981563
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # ==============================================================
    # Initialize linux network
    # ==============================================================
    frm = inspect.stack()[0]
    mod = inspect.getmodule(frm[0])
    linux_network_0 = LinuxNetwork(mod)
    #linux_network_0 = LinuxNetwork(mod, '/usr/bin', 'eth0')
    # ==============================================================
    # Populate
    # ==============================================================
    var_0 = linux_network_0.populate()
    assert linux_network_0.interfaces == var_0['interfaces']
    assert linux_network_0.default_interface == var_0['default_interface']
    assert linux_network_0.default_address == var_0['default_address'].pop()

# Generated at 2022-06-24 23:08:16.775533
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    str_0 = 'HmvU8W6f\x88\xfa'
    linux_network_0 = LinuxNetwork(str_0)
    linux_network_0.populate()
    str_1 = 'yQ\t'
    var_1 = linux_network_0.get_ethtool_data(str_1)
    str_2 = '4&\x94H'
    str_3 = 'xK'
    str_4 = 'rnX'
    str_5 = 'K'
    assert (var_1 == {str_2: {str_3: 'N/A'}, str_4: {str_5: 'N/A'}})


# Generated at 2022-06-24 23:08:23.874571
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Constructor call with parameters str, dict
    linux_network_0 = LinuxNetwork('3#/W#\t)')
    # Call method get_ethtool_data with parameter '\x19\x0c\x1e$\x123\xcd'
    linux_network_0.get_ethtool_data('\x19\x0c\x1e$\x123\xcd')


# Generated at 2022-06-24 23:08:29.724802
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    var_1 = LinuxNetwork('/root/zooples/zooples.py')
    var_1.populate()
    var_1.get_default_interfaces()
    var_1 = LinuxNetwork('/root/zooples/zooples.py')
    var_1.populate()
    var_1.get_default_interfaces()
    var_1 = LinuxNetwork('/root/zooples/zooples.py')
    var_1.populate()
    var_1.get_default_interfaces()


# Generated at 2022-06-24 23:08:33.283774
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    assert True


# Generated at 2022-06-24 23:08:38.043948
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network_0 = LinuxNetwork(str_0)
    linux_network_0.populate()
    var_0 = linux_network_0.get_default_interfaces(str_0)
    assert var_0 == (linux_network_0.network[str_0]['default_ipv4'],linux_network_0.network[str_0]['default_ipv6'])


# Generated at 2022-06-24 23:08:42.698542
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_0 = ')'
    linux_network_0 = LinuxNetwork(str_0)
    var_0 = linux_network_0.get_default_interfaces()


# Generated at 2022-06-24 23:08:46.474747
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    str_0 = '3#/W#\t)'
    linux_network_0 = LinuxNetwork(str_0)
    var_0 = linux_network_0.populate()

    assert var_0 is None


# Generated at 2022-06-24 23:08:49.825713
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # test stuff
    the_input = []
    output = None

    # No file at that path
    the_input = ['ethtool']
    output = LinuxNetwork.get_ethtool_data(the_input)
    assert output is None



# Generated at 2022-06-24 23:08:54.217723
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    var_0 = LinuxNetwork(str())
    var_0.populate()


# Generated at 2022-06-24 23:08:59.406020
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_0 = LinuxNetwork('127.0.0.1')
    linux_network_0.ethtool = '/usr/bin/ethtool'
    linux_network_0.module = AnsibleModuleMock()
    iface = 'eth0'
    linux_network_0.get_ethtool_data(iface)


# Generated at 2022-06-24 23:10:33.636767
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    test_case_0()


# Generated at 2022-06-24 23:10:36.974847
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Setup mock
    linux_network_0 = LinuxNetwork()
    linux_network_0.module = AnsibleModuleStub()

    # Unit test for get_default_interfaces
    linux_network_0.get_default_interfaces()


# Generated at 2022-06-24 23:10:40.507559
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_0 = LinuxNetwork(1)
    str_0 = '3#/W#\t)'
    var_0 = linux_network_0.get_ethtool_data(str_0)
