

# Generated at 2022-06-24 23:01:17.529883
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    text_0 = 'm2'
    dict_0 = {'j[n': '|D/n)', 'ik': 'y:', 'pI': test_LinuxNetwork_get_interfaces_info.text_0, 'S': ';8'}
    list_0 = [2020, 6, 11, 18, 10, 57, 3, 164, 0]

# Generated at 2022-06-24 23:01:22.923562
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    str_0 = 'u'
    linux_network_0 = LinuxNetwork(str_0)
    str_1 = 'w'
    dict_2 = {'address': str_1}
    str_3 = 'W'
    dict_4 = {'address': str_3}
    str_5 = 'f'
    linux_network_2 = LinuxNetwork(str_5)
    str_6 = 'L'
    dict_7 = {'address': str_6}
    str_8 = 'R'
    dict_9 = {'address': str_8}
    str_10 = 'G_$'
    linux_network_3 = LinuxNetwork(str_10)
    str_11 = 'H'
    dict_12 = {'address': str_11}
    str_13 = 'U9'


# Generated at 2022-06-24 23:01:26.706516
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    print("In method get_ethtool_data of class LinuxNetwork")
    str_0 = '?4L%'
    linux_network_0 = LinuxNetwork(str_0)
    str_1 = 'R?L'
    linux_network_0.get_ethtool_data(str_1)


# Generated at 2022-06-24 23:01:30.451745
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    str_0 = '?4L%'
    linux_network_0 = LinuxNetwork(str_0)
    str_1 = 'qId_'
    dict_1 = {}
    dict_2 = {}
    str_2 = '0S0['
    linux_network_0.populate(dict_1, str_1, dict_2, str_2)
# End unit test


# Generated at 2022-06-24 23:01:38.475959
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_0 = '8<F&]'
    str_1 = '=5Y}4'
    str_2 = '43Vum'
    linux_network_0 = LinuxNetwork(str_0)
    linux_network_0.get_default_interfaces()
    linux_network_1 = LinuxNetwork(str_1)
    linux_network_1.get_default_interfaces()
    str_3 = '<Ri'
    linux_network_1 = LinuxNetwork(str_2)
    linux_network_1.get_default_interfaces(str_3)


# Generated at 2022-06-24 23:01:42.424146
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_0 = 'y'
    linux_network_0 = LinuxNetwork(str_0)
    linux_network_0.get_default_interfaces()
    str_1 = 'c%('
    linux_network_1 = LinuxNetwork(str_1)
    try:
        linux_network_1.get_default_interfaces()
    except Exception:
        pass


# Generated at 2022-06-24 23:01:45.234457
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    str_0 = ''
    linux_network_0 = LinuxNetwork(str_0)
    device = ''
    try:
        linux_network_0.get_ethtool_data(device)
    except CalledProcessError as exec_error_0:
        var_0 = False
    else:
        raise AssertionError(var_0)


# Generated at 2022-06-24 23:01:54.921028
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    str_0 = 'f3;g'
    str_1 = '}/x'
    dict_0 = {'d': 2}
    dict_1 = {}
    dict_2 = {}
    dict_2.update(dict_1)
    dict_2.update(dict_0)
    str_2 = 'K'
    str_3 = 'hE'
    int_0 = 0
    str_4 = 'h'
    str_5 = "W+?K'R"
    str_6 = 'JQC'
    linux_network_0 = LinuxNetwork(str_0)
    var_0 = linux_network_0.get_interfaces_info(str_1, dict_2, dict_2)
    linux_network_0 = LinuxNetwork(str_5)
    linux_network_

# Generated at 2022-06-24 23:02:03.010938
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    str_0 = 'Z]'
    str_1 = '!,s*'
    str_2 = 'Xg*R'
    bool_0 = INSTRING(str_1, str_0)
    if bool_0:
        str_3 = '{H/'
        str_4 = INSTRING(str_3, str_0)
        str_5 = INSTRING(str_2, str_1)
        str_6 = '$' + str_5 + str_4
        str_7 = '2' + str_6 + '1D'
        bool_0 = INSTRING(str_7, str_0)
        str_8 = 'q'
        str_9 = 'R'
        str_10 = str_9 + str_8
        str_11 = 'j' + str_

# Generated at 2022-06-24 23:02:13.674400
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_0 = LinuxNetwork('')
    linux_network_0_get_ethtool_data = linux_network_0.get_ethtool_data('lo')

# Generated at 2022-06-24 23:02:38.376768
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_collector_0 = LinuxNetworkCollector()
    data = linux_network_collector_0.get_interfaces_info('/bin/ip', {}, {})
    assert 'eth0' in data[0]
    assert len(data[0]) >= 2
    assert len(data[1]) >= 4


# Generated at 2022-06-24 23:02:42.737550
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # TODO
    print("Testing method test_LinuxNetwork_get_default_interfaces of class LinuxNetwork")


# Generated at 2022-06-24 23:02:54.468873
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Set up mock for module.run_command
    module = DummyAnsibleModule()
    # The text from 'ethtool --help'

# Generated at 2022-06-24 23:03:06.738953
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_collector_1 = LinuxNetworkCollector()

    # change to test directory
    os.chdir('/usr/share/ansible_collections/ansible/community/tests/unit/modules/network/linux/fixtures/data_get_interfaces')

    # mock
    class MockModule(object):
        pass

    module = MockModule()
    module.run_command = run_command

    def get_bin_path(path, opt_dirs=[]):
        return '/usr/bin/ip'

    module.get_bin_path = get_bin_path

    os.environ['ANSIBLE_NET_TRANSPORT'] = 'network_cli'

    os.environ['ANSIBLE_NET_PASSWORD'] = 'ansible'


# Generated at 2022-06-24 23:03:15.610137
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Test scalar input
    linux_network_collector_0 = LinuxNetworkCollector()
    inp_0 = "eth0"
    out_0 = linux_network_collector_0.get_ethtool_data(inp_0)
    # Test scalar output
    linux_network_collector_0.get_ethtool_data(inp_0)
    # Test for a function call:
    linux_network_collector_0 = LinuxNetworkCollector()
    inp_1 = "eth0"
    out_1 = linux_network_collector_0.get_ethtool_data(inp_1)
    # System exit with 0:
    linux_network_collector_0.module.exit_json(changed=False, ansible_facts=dict(ansible_fact=out_1))


# Generated at 2022-06-24 23:03:20.558211
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    fact_collector_0 = LinuxNetwork()
    fact_collector_0.populate()

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 23:03:33.096525
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_collector_0 = LinuxNetworkCollector()


# Generated at 2022-06-24 23:03:42.735710
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # NOTE: make sure default_ipv4 and default_ipv6 are not ':' or '0.0.0.0'
    default_ipv4 = {'address': '10.0.0.1'}
    default_ipv6 = {'address': '::1'}
    ip_path = '/sbin/ip'
    linux_network_collector_0 = LinuxNetworkCollector()
    interfaces, ips = linux_network_collector_0.get_interfaces_info(ip_path, default_ipv4, default_ipv6)
    assert default_ipv4['broadcast']
    assert default_ipv4['netmask']
    assert default_ipv4['network']
    assert default_ipv4['macaddress']
    assert default_ipv4['mtu']

# Generated at 2022-06-24 23:03:48.198201
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    linux_network_collector_0 = LinuxNetworkCollector()
    linux_network_collector_0.test_data = dict(
        ip_path='/usr/bin/ip',
        ifconfig_path='/sbin/ifconfig',
    )
    linux_network_collector_0.module = MagicMock()


# Generated at 2022-06-24 23:03:51.717529
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_get_ethtool_data_0 = LinuxNetwork()
    device = "/dev/null"
    assert linux_network_get_ethtool_data_0.get_ethtool_data(device) == {}


# Generated at 2022-06-24 23:04:48.778343
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    default_ipv4 = dict(
        address="0.0.0.0",
        broadcast="0.0.0.0",
        netmask="0.0.0.0",
        network="0.0.0.0",
        macaddress="0.0.0.0",
        mtu="0",
        type="unknown",
    )
    default_ipv6 = dict(
        address="0::",
        prefix="0",
        scope="unknown",
        macaddress="0::",
        mtu="0",
        type="unknown",
    )
    interfaces, ips = LinuxNetworkCollector.get_interfaces_info("/bin/ip", default_ipv4, default_ipv6)
    print("interfaces=" + repr(interfaces))

# Generated at 2022-06-24 23:04:58.230625
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-24 23:05:01.294599
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_collector_0 = LinuxNetworkCollector()
    assert linux_network_collector_0.populate() == linux_network_collector_0



# Generated at 2022-06-24 23:05:15.047745
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    device_0 = 'wlp4s0'
    device_1 = 'wlp4s1'
    device_2 = 'lo'
    linux_network_collector_0 = LinuxNetworkCollector()
    result_0 = linux_network_collector_0.get_ethtool_data(device_0)
    result_1 = linux_network_collector_0.get_ethtool_data(device_1)
    result_2 = linux_network_collector_0.get_ethtool_data(device_2)

    assert result_0.get('features').get('rx-checksumming') == 'off'
    assert result_1.get('features').get('rx-checksumming') == 'off'
    assert result_2.get('features').get('rx-checksumming') == 'off'

   

# Generated at 2022-06-24 23:05:19.034483
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    default_ipv4 = linux_network_collector_0.get_default_interfaces()[0]
    assert default_ipv4['address'] == u'192.168.1.5'


# Generated at 2022-06-24 23:05:21.454994
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_collector_0 = LinuxNetworkCollector()
    facts = {}

    linux_network_collector_0.populate(facts)


# Generated at 2022-06-24 23:05:27.625189
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_collector_0 = LinuxNetworkCollector()
    device = 'eth0'

    # Agrs:
    #  device: 'eth0'
    return_value = linux_network_collector_0.get_ethtool_data(device)
    return return_value


# Generated at 2022-06-24 23:05:33.609414
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', default=['!all']),
        ),
    )

    network = LinuxNetworkCollector()
    module.exit_json(ansible_facts=network.get_facts())


# Generated at 2022-06-24 23:05:44.261339
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    # Set up test values

    testvalues = dict(
        gather_subset=['all']
    )

    module = FakeModule(**testvalues)
    result = LinuxNetwork(module)
    result.populate()
    assert result.data['version'] == 2
    assert result.data['interfaces']['lo'] == {'active': True, 'device': 'lo', 'ipv4': {'address': '127.0.0.1', 'broadcast': 'host', 'netmask': '255.0.0.0', 'network': '127.0.0.0'}, 'ipv6': [{'address': '::1', 'prefix': '128', 'scope': 'host'}], 'mtu': 65536, 'type': 'loopback'}


# Generated at 2022-06-24 23:05:54.288896
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_collector = LinuxNetworkCollector()
    device = 'eth0'
    ethtool_path = linux_network_collector.module.get_bin_path("ethtool")
    # FIXME: exit early on falsey ethtool_path and un-indent
    if ethtool_path:
        args = [ethtool_path, '-k', device]
        rc, stdout, stderr = linux_network_collector.module.run_command(args, errors='surrogate_then_replace')
        # FIXME: exit early on falsey if we can
        if rc == 0:
            features = {}
            for line in stdout.strip().splitlines():
                if not line or line.endswith(":"):
                    continue
                key, value = line.split(": ")

# Generated at 2022-06-24 23:06:49.795469
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    options = dict()

    # Generate data
    data = {}
    linux_network_0 = LinuxNetwork(options)
    data['interfaces'], data['routes'], data['default_ipv4'], data['default_ipv6'], data['dns'], data['ips'] = linux_network_0.get_network_state()
    interface_name = list(data['interfaces'].keys())[0]

    # Call the method
    result = linux_network_0.get_ethtool_data(interface_name)

    # Verify the result
    assert result is not None, "Verify the result"


# Generated at 2022-06-24 23:06:54.327039
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    network_collector_0 = LinuxNetworkCollector()
    assert network_collector_0.get_default_interfaces() == ({'address': '10.0.2.15', 'broadcast': '', 'netmask': '255.255.255.0', 'network': '10.0.2.0'}, {'address': 'fe80::a00:27ff:fe35:72da', 'prefix': '64', 'scope': 'link'})


# Generated at 2022-06-24 23:07:01.437593
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_collector_0 = LinuxNetworkCollector()
    test_case_0()

    # Test with data
    interface = 'lo'

# Generated at 2022-06-24 23:07:12.506834
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    # FIXME: convert to pytest

    # Set up mock default_ipv4 and default_ipv6 data structures
    default_ipv4 = {
        'interface': None,
        'address': None,
        'broadcast': None,
        'netmask': None,
        'network': None,
        'macaddress': None,
        'mtu': None,
        'type': None,
        'alias': None,
    }

    default_ipv6 = {
        'interface': None,
        'address': None,
        'prefix': None,
        'scope': None,
        'macaddress': None,
        'mtu': None,
        'type': None,
        'alias': None,
    }

    my_network = LinuxNetwork()

    # Case 0: Call method with empty /proc/

# Generated at 2022-06-24 23:07:16.325927
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    '''
    # FIXME: need to stub glob.glob and os methods
    # FIXME: not sure how to invoke the constructor
    linux_network_collector = LinuxNetworkCollector()
    '''
    pass


# Generated at 2022-06-24 23:07:20.403462
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    """
    Unit test for method get_default_interfaces of class LinuxNetwork
    """
    linux_network_collector_0 = LinuxNetworkCollector()
    interface_0, interface_1 = linux_network_collector_0.get_default_interfaces()


# Generated at 2022-06-24 23:07:26.472585
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_collector_1 = LinuxNetworkCollector()
    linux_network_collector_1.populate()
    assert linux_network_collector_1.interfaces
    assert linux_network_collector_1.ips

if __name__ == '__main__':
    test_LinuxNetwork_populate()

# Generated at 2022-06-24 23:07:36.728541
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # A stub for LinuxNetwork's get_interfaces_info method
    def get_interfaces_info_stub(ip_path, default_ipv4, default_ipv6):
        print("Called get_interfaces_info_stub")

# Generated at 2022-06-24 23:07:42.689201
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Mock class instances 1
    LinuxNetwork_0 = LinuxNetwork()
    #  1. bool( LinuxNetwork_0.default_ipv4) == False
    ipv4_0, ipv6_0 = LinuxNetwork_0.get_iproute_info()
    #  2. bool( LinuxNetwork_0.default_ipv6) == False
    LinuxNetwork_0.default_ipv4 = ipv4_0
    LinuxNetwork_0.default_ipv6 = ipv6_0
    #  3. bool( LinuxNetwork_0.default_ipv4['gateway']) == False

# Generated at 2022-06-24 23:07:50.218424
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_0 = LinuxNetwork('module_0')
    linux_network_0.module.run_command = MagicMock(return_value=(0, '', ''))
    linux_network_0.get_ethtool_data('device_0')
    linux_network_0.module.fail_json.assert_not_called()


# Generated at 2022-06-24 23:08:55.183345
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    dict_0 = dict()
    dict_0 = { 'int': { 'interface': 'int', 'address': 'int', 'gateway': 'int' }, 'v4': { 'interface': 'v4', 'address': 'v4', 'gateway': 'v4' }, 'v6': { 'interface': 'v6', 'address': 'v6', 'gateway': 'v6' } }
    dict_1 = dict()
    dict_1 = { 'int': { 'interface': 'int', 'address': 'int', 'gateway': 'int' }, 'v4': { 'interface': 'v4', 'address': 'v4', 'gateway': 'v4' }, 'v6': { 'interface': 'v6', 'address': 'v6', 'gateway': 'v6' } }
    dict_2 = dict()

# Generated at 2022-06-24 23:08:59.699080
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    list_0 = []
    linux_network_1 = LinuxNetwork(list_0)
    string_0 = 'device'
    device_5 = linux_network_1.get_ethtool_data(string_0)
    assert (isinstance(device_5, dict)) == True


# Generated at 2022-06-24 23:09:03.815924
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
  try:
    list_16 = []
    linux_network_0 = LinuxNetwork(list_16)
    linux_network_0.get_interfaces_info()
  except Exception as e:
    pass


# Generated at 2022-06-24 23:09:14.537849
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    list_0 = []
    linux_network_0 = LinuxNetwork(list_0)
    var_0 = linux_network_0.populate()
    if linux_network_0.interfaces:
        raise Exception("Expected false, got true")
    if var_0.get("all_ipv4_addresses"):
        raise Exception("Expected false, got true")
    if linux_network_0.default_ipv4:
        raise Exception("Expected false, got true")
    if linux_network_0.default_ipv6:
        raise Exception("Expected false, got true")
    if linux_network_0.ip_path:
        raise Exception("Expected false, got true")

# Generated at 2022-06-24 23:09:17.053035
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Simple test case
    list_0 = []
    linux_network_0 = LinuxNetwork(list_0)
    var_0 = linux_network_0.populate()


# Generated at 2022-06-24 23:09:20.597157
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    list_0 = []
    str_0 = ""
    linux_network_0 = LinuxNetwork(list_0)
    linux_network_0.get_ethtool_data(str_0)


# Generated at 2022-06-24 23:09:24.513068
# Unit test for method populate of class LinuxNetwork

# Generated at 2022-06-24 23:09:29.600000
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    list_0 = []
    linux_network_0 = LinuxNetwork(list_0)
    try:
        var_0 = linux_network_0.get_ethtool_data("lo")
    except OSError as e:
        var_0 = e.errno
    assert var_0 == 2
    try:
        var_0 = linux_network_0.get_ethtool_data("nondevice")
    except OSError as e:
        var_0 = e.errno
    assert var_0 == 2


# Generated at 2022-06-24 23:09:38.608749
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    list_0 = []
    linux_network_0 = LinuxNetwork(list_0)
    linux_network_0.populate()
    ansible_module = AnsibleModule()
    default_ipv4, default_ipv6 = linux_network_0.get_default_interfaces(ansible_module)
    assert isinstance(default_ipv4, dict)
    assert 'address' in default_ipv4
    assert isinstance(default_ipv6, dict)
    assert 'address' in default_ipv6


# Generated at 2022-06-24 23:09:40.836374
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    list_0 = []
    linux_network_0 = LinuxNetwork(list_0)
    linux_network_0.get_ethtool_data('em1')

