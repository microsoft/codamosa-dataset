

# Generated at 2022-06-24 23:01:17.698272
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-24 23:01:20.184741
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_collector_0 = LinuxNetworkCollector()
    device_0 = "ens33"
    test_LinuxNetwork_get_ethtool_data = linux_network_collector_0.get_ethtool_data(device_0)
    print(test_LinuxNetwork_get_ethtool_data)


# Generated at 2022-06-24 23:01:25.459560
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """ test get_ethtool_data function """
    linux_network_collector_1 = LinuxNetworkCollector()
    # Test with host with no ethtool installed
    out = linux_network_collector_1.get_ethtool_data("eth0")
    assert {} == out
    # Test with host with ethtool installed and host with no device
    # TODO: how to make this unit test more general and still reliable?
    # ie. don't use a device name but find the first device that matches some criteria
    # ie. only test locally on a host with an interface 'eth0' with ethtool installed
    out = linux_network_collector_1.get_ethtool_data("eth0")

# Generated at 2022-06-24 23:01:36.550142
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    try:
        linux_network_collector_0 = LinuxNetworkCollector()
    except NameError as err:
        print("Unable to init LinuxNetworkCollector class: " + err.args[0])
        return

# Generated at 2022-06-24 23:01:47.654446
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible.module_utils.ansible_release import __version__ as ansible_version
    from ansible.module_utils.six import PY2

    TestLinuxNetwork = LinuxNetwork()

    TestLinuxNetwork.module.params['gather_subset'] = ['network', 'interfaces']
    TestLinuxNetwork.module.params['gather_network_resources'] = 'all'

    # Set up mocks
    def side_effect_get_file_lines(*args, **kwargs):
        if args[0] == '/proc/net/dev':
            return test_case_0.proc_net_dev_lines
        elif args[0] == '/proc/net/vlan/config':
            return test_case_0.proc_net_vlan_config_lines

# Generated at 2022-06-24 23:01:51.534330
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_collector = LinuxNetworkCollector()
    module = AnsibleModuleMock()

    rc, out, err = module.run_command('ip route')
    linux_network_collector.get_default_interfaces(out)


# Generated at 2022-06-24 23:01:55.929788
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network = LinuxNetwork()
    ip_path = '/sbin/ip'
    default_ipv4 = defaultdict()
    default_ipv6 = defaultdict()
    interfaces, ips = linux_network.get_interfaces_info(ip_path, default_ipv4, default_ipv6)

# Generated at 2022-06-24 23:02:02.341717
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # FIXME: use fixture
    _tmp_path = tempfile.mkdtemp(prefix='ansible_test_LinuxNetwork_get_interfaces_info')
    _path = os.path.join(_tmp_path, 'test_get_interfaces_info')
    # FIXME: set up a real test function with a-b-a and fixtures
    # For now, we use the default, in case it's not what we expect
    linux_network_collector_0 = LinuxNetworkCollector()
    linux_network_collector_0.get_interfaces_info(_path, {}, {})


# Generated at 2022-06-24 23:02:09.391514
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-24 23:02:15.573503
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_collector_0 = LinuxNetworkCollector()
    linux_network_collector_1 = LinuxNetworkCollector()
    linux_network = LinuxNetwork(linux_network_collector_0, linux_network_collector_1)
    default_ipv4 = {}
    default_ipv6 = {}
    linux_network.populate(default_ipv4, default_ipv6)


# Generated at 2022-06-24 23:02:51.107402
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    linux_network_collector_0 = LinuxNetworkCollector()

    rc, out, err = linux_network_collector_0.module.run_command("ip -4 route get 1", errors='surrogate_then_replace')
    out = out.splitlines()[0]
    words = out.split()
    _device = words[2].split(':')[0]
    default_ipv4 = {'address': words[4], 'interface': _device}

    rc, out, err = linux_network_collector_0.module.run_command("ip -6 route get 2001:4860:4860::8888", errors='surrogate_then_replace')
    out = out.splitlines()[0]
    words = out.split()
    _device = words[2].split(':')[0]


# Generated at 2022-06-24 23:02:56.231400
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    (interfaces, _) = test_LinuxNetwork_collector.get_interfaces_info(
            None,
            default_ipv4 = {'address': '10.69.69.101'},
            default_ipv6 = {'address': '::1'})
    for i in interfaces.values():
        for j in ['address', 'broadcast', 'netmask', 'network']:
            assert j in i['ipv4']
        for j in ['address', 'prefix', 'scope']:
            assert j in i['ipv6'][0]


# Generated at 2022-06-24 23:02:59.793920
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_collector_0 = LinuxNetworkCollector()
    linux_network_collector_0._get_ethtool_data('not_a_real_device_name')


# Generated at 2022-06-24 23:03:05.502145
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # FIXME: we need to implement a decent test fixture before we can do this
    # linux_network = LinuxNetwork()
    # FIXME: these aren't actually bad, we just don't have a way to put them
    # into the module class yet
    # print("TO IMPLEMENT: test function get_interfaces_info of class LinuxNetwork")
    pass


# Generated at 2022-06-24 23:03:09.272303
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network_collector_1 = LinuxNetworkCollector()
    result = linux_network_collector_1.get_default_interfaces()
    assert result != None, "Return value for method: get_default_interfaces when invoked for class LinuxNetwork."


# Generated at 2022-06-24 23:03:13.435307
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_0 = LinuxNetwork(module=None)
    linux_network_0.populate(params={"ip_path": None, "ip6_path": None})
    return linux_network_0


# Generated at 2022-06-24 23:03:17.591991
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_collector_0 = LinuxNetworkCollector()
    linux_network_collector_0.populate()


# Generated at 2022-06-24 23:03:27.133420
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_collector_0 = LinuxNetworkCollector()

    # Test execution
    interfaces_info = linux_network_collector_0.get_interfaces_info()
    assert isinstance(interfaces_info, tuple)
    assert len(interfaces_info) == 2
    assert isinstance(interfaces_info[0], dict)
    assert isinstance(interfaces_info[1], dict)
    for i, element in interfaces_info[1].items():
        assert isinstance(element, list)
        for e in element:
            assert isinstance(e, str)



# Generated at 2022-06-24 23:03:32.400687
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_collector_0 = LinuxNetworkCollector()
    device = None
    assert linux_network_collector_0.get_ethtool_data(device) == {}


# Generated at 2022-06-24 23:03:34.901989
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Test
    linux_network_collector_0 = LinuxNetworkCollector()

    # Assertion
    assert linux_network_collector_0


# Generated at 2022-06-24 23:04:14.381347
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Test 0
    # This test pass reading test_0_ethtool_data.txt
    set_0 = set()
    linux_network_0 = LinuxNetwork(set_0)
    var_0 = linux_network_0.get_ethtool_data("eth0")

# Generated at 2022-06-24 23:04:24.991165
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    bytes_0 = b'\xb5\xd24_\xf4l:\xaf\x0f\x85\x98\x11\xf7\x82\t\x85\xdf'
    set_0 = set()
    linux_network_0 = LinuxNetwork(set_0)
    var_0 = linux_network_0.get_default_interfaces(bytes_0)
    assert var_0 == [('127.0.0.1', 16)]

    str_0 = '>c7|z\xbf\x8bl\xc5'
    set_1 = set()
    linux_network_1 = LinuxNetwork(set_1)
    var_1 = linux_network_1.get_default_interfaces(str_0)

# Generated at 2022-06-24 23:04:27.159552
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    set_0 = set()
    linux_network_0 = LinuxNetwork(set_0)
    linux_network_collector_0 = LinuxNetworkCollector(linux_network_0)


# Generated at 2022-06-24 23:04:32.339822
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    bytes_0 = b'\xb5\xd24_\xf4l:\xaf\x0f\x85\x98\x11\xf7\x82\t\x85\xdf'
    set_0 = set()
    linux_network_0 = LinuxNetwork(set_0)
    var_0 = linux_network_0.get_default_interfaces(bytes_0)

# Test the print to console function

# Generated at 2022-06-24 23:04:43.078604
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    bytes_1 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    set_1 = set()
    linux_network_1 = LinuxNetwork(set_1)
    var_1 = linux_network_1.get_ethtool_data(bytes_1)

# Generated at 2022-06-24 23:04:51.855019
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Setup
    set_0 = set()
    linux_network_1 = LinuxNetwork(set_0)
    bytes_0 = b'\xbf\xa5\xab\xce\x8eY\xa1\xa0\x95\x9a9\x88\x11\xec\xd6\x1b\xbf\xfd\xcdk\x93\x9a\x8c0\xfb\xab\x11'

# Generated at 2022-06-24 23:04:59.167497
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    if_0 = 'lo'
    if_1 = 'lo'
    if_2 = 'lo'
    if_3 = 'lo'
    bytes_0 = b'\xb5\xd24_\xf4l:\xaf\x0f\x85\x98\x11\xf7\x82\t\x85\xdf'
    set_0 = set()
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_1['alias'] = if_0
    dict_2['alias'] = if_1

# Generated at 2022-06-24 23:05:00.101196
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    pass

# Generated at 2022-06-24 23:05:09.192064
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # FIXME: there is a serious problem with this test
    #        it is tied to the contents of the host
    #        and has little to do with testing
    #        the method under test.
    #        it should be refactored or removed/ignored
    set_0 = set()
    linux_network_0 = LinuxNetwork(set_0)

# Generated at 2022-06-24 23:05:16.045437
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    set_0 = set()
    linux_network_0 = LinuxNetwork(set_0)
    default_ipv4_0 = dict()

    default_ipv6_0 = dict()

    ip_path_0 = "/mnt/fs/proc/sys/net/ipv4/route/flush"

    var_0 = linux_network_0.get_interfaces_info(ip_path_0, default_ipv4_0, default_ipv6_0)


# Generated at 2022-06-24 23:05:59.209527
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    bytes_0 = b'\xb5\xd24_\xf4l:\xaf\x0f\x85\x98\x11\xf7\x82\t\x85\xdf'
    set_0 = set()
    linux_network_0 = LinuxNetwork(set_0)
    var_0 = linux_network_0.get_default_interfaces(bytes_0)


# Generated at 2022-06-24 23:06:07.696230
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Test with a 1 element iterable
    interface_info_iterable = NetworkInterfaceInfo()
    interfaces_info = get_interfaces_info(interface_info_iterable)
    # Check that the result of the method call is a list
    assert(type(interfaces_info) == list)
    # Check that the type of the first element of the result is NetworkInterfaceInfo
    assert(type(interfaces_info[0]) == NetworkInterfaceInfo)


# Generated at 2022-06-24 23:06:17.553856
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    set_0 = set()
    linux_network_0 = LinuxNetwork(set_0)
    device = 'eth0'

# Generated at 2022-06-24 23:06:28.770565
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    iface_data = get_file_content('/proc/net/dev')
    lines = iface_data.splitlines()
    iface_data = []
    for index, line in enumerate(lines):
        if index == 0:
            continue
        elements = line.split()
        iface = elements[0].strip(':')

# Generated at 2022-06-24 23:06:35.811046
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    bytes_0 = b'\xb5\xd24_\xf4l:\xaf\x0f\x85\x98\x11\xf7\x82\t\x85\xdf'
    set_0 = set()
    linux_network_0 = LinuxNetwork(set_0)
    var_0 = linux_network_0.get_default_interfaces(bytes_0)
    linux_network_0.populate()


# Generated at 2022-06-24 23:06:38.501508
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    for instance in LinuxNetwork.instances:
        assert len(instance.get_interfaces_info()) == 2


# Generated at 2022-06-24 23:06:45.067176
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    set_0 = set()
    linux_network_0 = LinuxNetwork(set_0)
    bytes_0 = b'\x00\x00\x00\x00\x00\x00'
    bytes_1 = b'\x00\x00\x00\x00\x00\x00'
    # TODO: implement test_LinuxNetwork_get_interfaces_info(LinuxNetwork)
    raise NotImplementedError()


# Generated at 2022-06-24 23:06:54.582109
# Unit test for method get_default_interfaces of class LinuxNetwork

# Generated at 2022-06-24 23:06:59.758394
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    bytes_0 = b'\xb5\xd24_\xf4l:\xaf\x0f\x85\x98\x11\xf7\x82\t\x85\xdf'
    set_0 = set()
    linux_network_0 = LinuxNetwork(set_0)
    var_0 = linux_network_0.get_default_interfaces(bytes_0)
    var_1 = linux_network_0.get_ethtool_data(var_0)


# Generated at 2022-06-24 23:07:02.378759
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    print("\nEntered method test_LinuxNetwork_populate")
    test_case_0()

if __name__ == '__main__':
    # TODO: Add tests for the other methods
    test_LinuxNetwork_populate()

# Generated at 2022-06-24 23:07:41.963757
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Setup fixture
    bytes_0 = b'\xb5\xd24_\xf4l:\xaf\x0f\x85\x98\x11\xf7\x82\t\x85\xdf'
    set_0 = set()
    linux_network_0 = LinuxNetwork(set_0)
    var_0 = linux_network_0.get_default_interfaces(bytes_0)
    var_1 = list()
    var_1.append(var_0)

    # Test call
    output = linux_network_0.get_interfaces_info(None, None, None)

# Generated at 2022-06-24 23:07:49.013014
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    set_0 = set()
    linux_network_0 = LinuxNetwork(set_0)
    # bytes_0 = b'\xb5\xd24_\xf4l:\xaf\x0f\x85\x98\x11\xf7\x82\t\x85\xdf'
    # bytes_1 = b'\xb5\xd24_\xf4l:\xaf\x0f\x85\x98\x11\xf7\x82\t\x85\xdf'
    # bytes_2 = b'\xb5\xd24_\xf4l:\xaf\x0f\x85\x98\x11\xf7\x82\t\x85\xdf'
    # bytes_3 = b'\xb5\xd24_\xf4l:\xaf\

# Generated at 2022-06-24 23:07:59.268666
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-24 23:08:02.343662
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    set_1 = set()
    linux_network_0 = LinuxNetwork(set_1)
    str_0 = 'test'
    linux_network_0.get_ethtool_data(str_0)


# Generated at 2022-06-24 23:08:08.558270
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    print("Testing LinuxNetwork.populate")
    bytes_0 = b'\xb5\xd24_\xf4l:\xaf\x0f\x85\x98\x11\xf7\x82\t\x85\xdf'
    set_0 = set()
    linux_network_0 = LinuxNetwork(set_0)
    var_0 = linux_network_0.get_default_interfaces(bytes_0)
    linux_network_0.populate(bytes_0, bytes_0)


# Generated at 2022-06-24 23:08:18.290807
# Unit test for method get_default_interfaces of class LinuxNetwork

# Generated at 2022-06-24 23:08:28.406106
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    bytes_0 = b'\xb5\xd24_\xf4l:\xaf\x0f\x85\x98\x11\xf7\x82\t\x85\xdf'
    set_0 = set()
    isinstance_0 = isinstance(set_0, set)
    assert isinstance_0

    linux_network_0 = LinuxNetwork(set_0)
    var_0 = linux_network_0.get_default_interfaces(bytes_0)
    _, _ = var_0

    bytes_1 = b'\xb5\xd24_\xf4l:\xaf'
    set_1 = set()
    isinstance_1 = isinstance(set_1, set)
    assert isinstance_1

    linux_network_1 = LinuxNetwork(set_1)
    var

# Generated at 2022-06-24 23:08:38.412499
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    set_0 = set()
    linux_network_0 = LinuxNetwork(set_0)
    bytes_0 = b'e'
    tuple_0 = linux_network_0.get_default_interfaces(bytes_0)
    assert tuple_0 == ({'address': '127.0.0.1'}, {'address': '::1'})
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-24 23:08:42.174452
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    set_0 = set()
    linux_network_0 = LinuxNetwork(set_0)
    # FIXME: Argument parsed_args is missing default value
    linux_network_0.populate()


# Generated at 2022-06-24 23:08:45.717910
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    config_file_0 = "test_unit_test_case_default_cfg.cfg"
    test_case_0(config_file_0)


# Generated at 2022-06-24 23:09:37.913475
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(
            group=dict(default=None, type='str'),
            state=dict(default='present', choices=['absent', 'present']),
        )
    )
    linux_network_0 = LinuxNetwork(module)
    linux_network_0.get_interfaces_info(module, module.params['group'], module.params['state'])

# Method for unit testing the module

# Generated at 2022-06-24 23:09:40.965662
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    args_0 = 'jhxO'
    linux_network_collector_0 = LinuxNetworkCollector(args_0)
    assert linux_network_collector_0._platform == 'Linux'
    assert linux_network_collector_0._fact_class == LinuxNetwork
    assert linux_network_collector_0.required_facts == set(['distribution', 'platform'])

if __name__ == "__main__":
    test_LinuxNetworkCollector()
    test_case_0()

# Generated at 2022-06-24 23:09:48.889277
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    # Test case for IPv4
    # Test for valid case
    str_0 = 'eth0'
    linux_network_0 = LinuxNetwork(str_0)
    var_0 = linux_network_0.get_default_interface(linux_network_0)

    # Test case for IPv6
    # Test for valid case
    str_1 = 'eth1'
    linux_network_1 = LinuxNetwork(str_1)
    var_1 = linux_network_1.get_default_interface(linux_network_1)



# Generated at 2022-06-24 23:09:53.348231
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_0 = 'm9@Mq!4fJ'
    linux_network_0 = LinuxNetwork(str_0)
    var_0 = linux_network_0.get_interfaces_info(linux_network_0, str_0, linux_network_0)
    var_1 = linux_network_0.get_default_interfaces(str_0, str_0)


# Generated at 2022-06-24 23:09:59.594374
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Init LinuxNetwork
    str_0 = 'Linux'
    linux_network_0 = LinuxNetwork(str_0)
    # Call get_default_interfaces
    var_0, var_1 = linux_network_0.get_default_interfaces()


# Generated at 2022-06-24 23:10:08.875183
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    str_0 = '{u\'os_version\': u\'8.1\', u\'os_major_version\': 8, u\'distribution\': u\'centos\'}'
    str_1 = 'bond0'
    str_2 = 'bond0'
    dict_0 = {'os_version': '8.1', 'os_major_version': 8, 'distribution': 'centos'}
    list_0 = ['3.10.0-327.22.2.el7.x86_64', '#1 SMP Wed May 11 20:41:14 UTC 2016', 'x86_64', 'x86_64']
    list_1 = ['centos', '7.2.1511', 'Core']
    dict_1 = {}

# Generated at 2022-06-24 23:10:10.378928
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_0 = LinuxNetwork()
    linux_network_0.get_ethtool_data(0)


# Generated at 2022-06-24 23:10:14.792591
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_0 = LinuxNetwork()
    linux_network_0.get_interfaces_info('linux_network_0', 'linux_network_0', 'linux_network_0')


# Generated at 2022-06-24 23:10:19.379521
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    str_0 = 'KWWY@57u{-'
    linux_network_0 = LinuxNetwork(str_0)
    var_0 = linux_network_0.get_ethtool_data(str_0)


# Generated at 2022-06-24 23:10:22.794345
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_0 = LinuxNetwork(linux_network_0)
    var_0 = linux_network_0.populate()
    assert var_0 == None, "Failed to populate"
