

# Generated at 2022-06-24 23:01:12.899493
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    bytes_0 = b'\x9c\xf8\xc1\xde\xb2\x8c\x8f\x16\xbf\xdfX\x1c\x18\x01\xcc\x15\xf7\\\xec\x05\x14\x9d'
    linux_network_0 = LinuxNetwork(bytes_0)
    linux_network_0.populate()
    linux_network_0.get_interfaces_info(bytes_0, float_0, float_0)
    linux_network_0.get_default_interfaces(float_0)
    linux_network_0.get_bridges(bytes_0)
    float_0 = float('NaN')

# Generated at 2022-06-24 23:01:23.044157
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    float_0 = 34.8
    bytes_0 = b'u?\xf4\xdb\xd0(\xd6\xa8\x00\xe8\x00\xb5\xc0\x01pm[\xffN\xbf'
    linux_network_0 = LinuxNetwork(bytes_0)
    int_0 = linux_network_0.get_default_interface_index()
    str_0 = linux_network_0.get_default_interface()
    str_1 = linux_network_0.get_default_ipv4()
    str_2 = linux_network_0.get_default_ipv6()
    dict_0, dict_1 = linux_network_0.get_interfaces_info(float_0, str_1, str_2)


# Generated at 2022-06-24 23:01:26.368397
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    float_0 = 34.8
    str_0 = '6:40:08'
    bytes_0 = b'u?\xf4\xdb\xd0(\xd6\xa8\x00\xe8\x00\xb5\xc0\x01pm[\xffN\xbf'
    linux_network_0 = LinuxNetwork(bytes_0)
    str_1 = linux_network_0.populate()


# Generated at 2022-06-24 23:01:35.137612
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    float_0 = 34.8
    bytes_0 = b'u?\xf4\xdb\xd0(\xd6\xa8\x00\xe8\x00\xb5\xc0\x01pm[\xffN\xbf'
    linux_network_0 = LinuxNetwork(bytes_0)
    var_0 = linux_network_0.get_ethtool_data(float_0)
    # AssertionError: expected {'features': {...}} not to equal {'features': {...}}
    assert not var_0 == var_0


# Generated at 2022-06-24 23:01:42.244595
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    float_0 = 34.8
    bytes_0 = b'u?\xf4\xdb\xd0(\xd6\xa8\x00\xe8\x00\xb5\xc0\x01pm[\xffN\xbf'
    linux_network_0 = LinuxNetwork(bytes_0)
    linux_network_0.populate()


# Generated at 2022-06-24 23:01:48.291857
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    cmd0 = b'ip -4 route list exact 0/0'
    bytes_0 = b'192.0.2.1'
    bytes_1 = b'2001:db8:85a3::8a2e:370:7334'
    linux_network_0 = LinuxNetwork(bytes_0)
    os_error_0 = OSError()
    os_error_0.errno = -1
    os_error_0.strerror = 'error'
    os_error_0.filename = 'file'
    # ValueError raised by module.run_command
    with raises(ValueError):
        with patch('os.path.exists', return_value=True):
            linux_network_0.get_default_interfaces()
    # ValueError raised by module.run_command

# Generated at 2022-06-24 23:01:57.568437
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    print("Testing method LinuxNetwork.populate")
    float_0 = 34.8
    bytes_0 = b'u?\xf4\xdb\xd0(\xd6\xa8\x00\xe8\x00\xb5\xc0\x01pm[\xffN\xbf'
    linux_network_0 = LinuxNetwork(bytes_0)
    var_0 = linux_network_0.get_ethtool_data(float_0)
    float_1 = 34.8
    bytes_1 = b'u?\xf4\xdb\xd0(\xd6\xa8\x00\xe8\x00\xb5\xc0\x01pm[\xffN\xbf'
    linux_network_1 = LinuxNetwork(bytes_1)

# Generated at 2022-06-24 23:02:02.007890
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    float_0 = 34.8
    bytes_0 = b'\xd2\xadF\xba\xb9\x9d\xe6\x85\x16\x1f\x8e\xaf'
    linux_network_0 = LinuxNetwork(bytes_0)
    var_0 = linux_network_0.get_default_interfaces(float_0)


# Generated at 2022-06-24 23:02:09.372212
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_0 = LinuxNetwork()
    byte_0 = b'tt\x89\xba\xea\xa4\xbf\xbf\xbf'

# Generated at 2022-06-24 23:02:13.038784
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # noop
    return True

if __name__ == '__main__':
    test_LinuxNetwork_populate()
    test_case_0()

# Generated at 2022-06-24 23:02:38.241610
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    LinuxNetwork_instance = LinuxNetwork()
    # TODO: decide whether we want to test the actual device or
    #       mock it with a "unique" one
    #assert LinuxNetwork_instance.get_ethtool_data(test_case_0) == defined_value


# Generated at 2022-06-24 23:02:50.385119
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    ____ = LinuxNetwork()
    res_0 = ____.get_ethtool_data()
    res_1 = ____.get_ethtool_data()
    res_2 = ____.get_ethtool_data()
    res_3 = ____.get_ethtool_data()
    res_4 = ____.get_ethtool_data()
    res_5 = ____.get_ethtool_data()
    res_6 = ____.get_ethtool_data()
    res_7 = ____.get_ethtool_data()
    res_8 = ____.get_ethtool_data()
    res_9 = ____.get_ethtool_data()
    res_10 = ____.get_ethtool_data()
    res_11 = ____.get_ethtool_data()

# Generated at 2022-06-24 23:02:52.646920
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    networks = LinuxNetwork()
    device = test_case_0()
    res = networks.get_ethtool_data(device)
    assert res is None, 'return value is not None'


# Generated at 2022-06-24 23:02:56.100237
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    ethtool_path = True
    object_class = LinuxNetwork(module, ethtool_path)
    device = True
    try:
        object_class.get_ethtool_data(device)
    except Exception as e:
        print(e)

# Generated at 2022-06-24 23:03:00.602616
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Initialize the class
    linux_network = LinuxNetwork()
    # Set the parameters
    device = 'device_name'
    linux_network.get_ethtool_data(device)


# Generated at 2022-06-24 23:03:08.732150
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network = LinuxNetwork()
    
    default_ipv4 = {}

    default_ipv6 = {}

    assert linux_network.get_interfaces_info(None, default_ipv4, default_ipv6) == (None, None)
    assert type(linux_network.get_interfaces_info(None, default_ipv4, default_ipv6)[0]) == type({})
    assert type(linux_network.get_interfaces_info(None, default_ipv4, default_ipv6)[1]) == type({})


# Generated at 2022-06-24 23:03:20.582507
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-24 23:03:33.131802
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Setup
    # Interface 'lo' is in this list so that we can get to its MAC address easily
    interfaces = ['lo', 'bond0', 'eth0', 'eth1', 'eth2']
    default_ipv4 = {'address': '127.0.0.1'}
    default_ipv6 = {'address': '::1'}
    module = mock.Mock()
    module.get_bin_path.return_value = '/sbin/ip'
    module.run_command.return_value = 0, '', ''
    network = LinuxNetwork(module)
    # Expected

# Generated at 2022-06-24 23:03:42.776323
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    bool_1 = True
    for value in [True, False]:
        if value:
            bool_2 = True
        elif value:
            bool_2 = False
    if bool_1:
        bool_3 = True
    elif not bool_1 and True:
        bool_3 = False
    elif bool_2:
        bool_3 = True
    if bool_3:
        bool_4 = True
    else:
        bool_4 = False
    if not bool_4 or not False:
        bool_4 = False
    if bool_4:
        bool_5 = True
    elif not bool_4 and True:
        bool_5 = False
    elif bool_4:
        bool_5 = True
    if bool_5:
        bool_6 = True
    else:
        bool

# Generated at 2022-06-24 23:03:48.198396
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Instance to test
    inst_ret_obj = LinuxNetwork()
    # check if the returned object has required attributes
    for attr in expected_attributes:
        assert hasattr(inst_ret_obj, attr), 'has not attribute {0}'.format(attr)
    # check if the returned object has an attribute named get_ethtool_data
    assert callable(inst_ret_obj.get_ethtool_data), '{0} is not callable'.format('get_ethtool_data')
    # check if the call to get_ethtool_data produces the expected output
    assert (inst_ret_obj.get_ethtool_data() == {}), 'get_ethtool_data() does not produce the expected output'


# Generated at 2022-06-24 23:04:18.118461
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec = dict(
            filter = dict(default=None, required=False),
            options = dict(default=None, required=False)
        ),
        supports_check_mode = True
    )
    linux_network_0 = LinuxNetwork(module)
    str_0 = ''
    str_1 = ''
    dict_0 = linux_network_0.get_interfaces_info(str_0, str_1)
    assert type(dict_0) is dict


# Generated at 2022-06-24 23:04:23.994842
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    obj = LinuxNetwork()
    obj.module = MagicMock()
    obj.module.executable = MagicMock()
    obj.module.executable.find_bin = MagicMock(return_value='')
    obj.get_default_interfaces()


# Generated at 2022-06-24 23:04:27.152944
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    default_interfaces = LinuxNetwork.get_default_interfaces()
    assert default_interfaces == ('eth0', {'address': '127.0.0.1'}, {'address': '::1'})


# Generated at 2022-06-24 23:04:29.032360
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    params = []
    expected_0 = "expected_0"

    LinuxNetwork.get_ethtool_data(params[0:])

    assert expected_0 == "expected_0"


# Generated at 2022-06-24 23:04:30.950910
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    with pytest.raises(Exception):
        LinuxNetwork.get_interfaces_info(bool_0, bool_0, bool_0)

# Generated at 2022-06-24 23:04:39.311801
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    network = LinuxNetwork()
    default_ipv4 = { 'address':  '192.168.1.1' }
    ip_path = '/home/vagrant/ansible/lib/ansible/modules/network/basics/linux.py'
    default_ipv6 = { 'address':  '2001:0db8:85a3:0000:0000:8a2e:0370:7334' }

    # Call method
    X = network.get_interfaces_info(ip_path, default_ipv4, default_ipv6)
    # get_interfaces_info() returns a tuple
    assert len(X) == 2
    assert type(X[0]) == dict
    assert type(X[1]) == dict



# Generated at 2022-06-24 23:04:42.830794
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Setup
    windows_network_configurator = LinuxNetwork()

    # Testing
    # Call method
    windows_network_configurator.populate()

test_LinuxNetwork_populate()

# Generated at 2022-06-24 23:04:44.198202
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    foo = LinuxNetwork()
    foo.populate()


# Generated at 2022-06-24 23:04:45.570441
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # check if the function is running with valid params
    assert True


# Generated at 2022-06-24 23:04:53.777491
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    linux_network_obj = LinuxNetwork(module, dict(
        provider=dict(
            name='',
            hash=dict,
            auth=dict,
            network_api=dict,
            optional_args=dict,
            env=dict
        )
    ))
    ip_path = 'string_0'
    default_ipv4 = dict(
        address='string_0',
        netmask='string_0',
        network='string_0',
        broadcast='string_0',
        macaddress='string_0',
        module='string_0',
        mtu='string_0',
        type='string_0'
    )

# Generated at 2022-06-24 23:05:24.507582
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    float_0 = 37.1
    bytes_0 = b'\xbd\xb4\x87\xfd\xef\xf9\xb9\x87\x13T\xdf\x07\x08\xa2\xc6\x8a\x9d\x86\xdd\x87\x19'
    linux_network_0 = LinuxNetwork(bytes_0)
    linux_network_0.default_gateway = dict()
    linux_network_0.default_interface = dict()
    linux_network_0.default_interface_ipv4 = dict()
    linux_network_0.default_interface_ipv6 = dict()
    linux_network_0.interfaces = dict()
    linux_network_0.populate(float_0)


# Generated at 2022-06-24 23:05:36.505043
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    float_0 = 34.8
    bytes_0 = b'\xd2\xadF\xba\xb9\x9d\xe6\x85\x16\x1f\x8e\xaf'
    linux_network_0 = LinuxNetwork(bytes_0)

# Generated at 2022-06-24 23:05:39.545367
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # FIXME: add assertions
    try:
        test_case_0()
    except Exception as exception:
        print(exception)


# Generated at 2022-06-24 23:05:45.746179
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    float_0 = 34.8
    bytes_0 = b'\xd2\xadF\xba\xb9\x9d\xe6\x85\x16\x1f\x8e\xaf'
    linux_network_0 = LinuxNetwork(bytes_0)
    str_0 = linux_network_0.get_ethtool_data(float_0)
    print(str_0)


# Generated at 2022-06-24 23:05:51.558132
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    float_0 = 34.8
    bytes_0 = b'\xd2\xadF\xba\xb9\x9d\xe6\x85\x16\x1f\x8e\xaf'
    linux_network_0 = LinuxNetwork(bytes_0)
    linux_network_0.populate(float_0)


# Generated at 2022-06-24 23:06:00.595288
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    float_0 = 34.8
    bytes_0 = b'\xd2\xadF\xba\xb9\x9d\xe6\x85\x16\x1f\x8e\xaf'
    linux_network_0 = LinuxNetwork(bytes_0)
    var_0 = linux_network_0.get_default_interfaces(float_0)
    var_1 = linux_network_0.get_interfaces_info(float_0, var_0, var_0)
    assert len(var_1) == 2
    assert var_1[0]
    assert var_1[1]



# Generated at 2022-06-24 23:06:06.611504
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_0 = LinuxNetwork(None)
    int_0 = 34
    str_0 = '\x00\xef\x01"'
    linux_network_0.get_interfaces_info(int_0, str_0, str_0)


# Generated at 2022-06-24 23:06:11.822241
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    float_0 = 34.8
    bytes_0 = b'\x86\x0c\x9d\xfe[\xad\xfe\x91\xbe\x06\xbb\x14'
    linux_network_0 = LinuxNetwork(bytes_0)
    linux_network_0.populate(float_0)


# Generated at 2022-06-24 23:06:20.625458
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    bytes_0 = b'\xd2\xadF\xba\xb9\x9d\xe6\x85\x16\x1f\x8e\xaf'
    linux_network_0 = LinuxNetwork(bytes_0)
    string_0 = 'U6l\x1d\xad\xa3\xa5D\x8a\xb5\x9d\x1b1'
    dict_0 = linux_network_0.get_ethtool_data(string_0)
    if dict_0:
        string_0 = '_of_ether'
        var_1 = dict_0[string_0]
        string_0 = 'ethtool'
        float_0 = float(var_1)
        float_1 = float(string_0)

# Generated at 2022-06-24 23:06:26.728229
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    float_0 = 34.8
    bytes_0 = b'\xd2\xadF\xba\xb9\x9d\xe6\x85\x16\x1f\x8e\xaf'
    linux_network_0 = LinuxNetwork(bytes_0)
    var_0 = linux_network_0.get_default_interfaces(float_0)


# Generated at 2022-06-24 23:06:56.908974
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_0 = LinuxNetwork(b'\xd2\xadF\xba\xb9\x9d\xe6\x85\x16\x1f\x8e\xaf')
    linux_network_0.populate(float_0=34.8)


# Generated at 2022-06-24 23:06:59.791847
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    float_0 = 34.8
    bytes_0 = b'\xd2\xadF\xba\xb9\x9d\xe6\x85\x16\x1f\x8e\xaf'
    linux_network_0 = LinuxNetwork(bytes_0)
    var_0 = linux_network_0.get_default_interfaces(float_0)


# Generated at 2022-06-24 23:07:00.705548
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    collector = LinuxNetworkCollector()
    output = collector.collect()
    print(output)


# Generated at 2022-06-24 23:07:12.566361
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():

    # Test with no arguments
    # object_1 = LinuxNetworkCollector()

    # Test with mandatory arguments
    # object_2 = LinuxNetworkCollector(arg1)

    # Test with all arguments
    # object_3 = LinuxNetworkCollector(arg1, arg2, arg3, arg4)

    print(object_3.module)
    print(object_3.fact_subset)

    assert object_3.module == arg1
    assert object_3.fact_subset == arg2

    # Test __eq__ and __ne__
    # assert object_1 == object_2
    # assert object_1 != object_3

    # Test __repr__
    # assert repr(object_1) == ''
    # assert repr(object_2) == ''
    # assert repr(object_3) == ''

#

# Generated at 2022-06-24 23:07:20.956252
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    float_0 = 34.8
    bytes_0 = b'\xd2\xadF\xba\xb9\x9d\xe6\x85\x16\x1f\x8e\xaf'
    bytes_1 = b'\x10\x81\xe0\x8c\x14'
    linux_network_0 = LinuxNetwork(bytes_0)
    linux_network_0.get_interfaces_info(bytes_1, float_0, float_0)


if __name__ == '__main__':
    test_case_0()
    test_LinuxNetwork_get_interfaces_info()

# Generated at 2022-06-24 23:07:30.433845
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    float_0 = 34.8
    bytes_0 = b'\xd2\xadF\xba\xb9\x9d\xe6\x85\x16\x1f\x8e\xaf'
    linux_network_0 = LinuxNetwork(bytes_0)

# Generated at 2022-06-24 23:07:37.351241
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    float_0 = 34.8
    bytes_0 = b'\xd2\xadF\xba\xb9\x9d\xe6\x85\x16\x1f\x8e\xaf'
    linux_network_0 = LinuxNetwork(bytes_0)

    float_1 = 34.8
    str_0 = 'ethtool'
    linux_network_0.module.get_bin_path(str_0)
    linux_network_0.get_ethtool_data(float_1)


# Generated at 2022-06-24 23:07:46.416853
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    format_0 = '\x00\x00\xa2\x14\x06\xa9'
    linux_network_0 = LinuxNetwork(format_0)
    float_0 = 34.8
    linux_network_0.get_default_interfaces(float_0)
    format_1 = '\x00\x00\xa2\x14\x06\xa9'
    str_0 = '='
    len_0 = 0
    bytes_0 = b'\xdc\xd3\xd3\xbb\xa1\x83\xb0\x04\x1d\x92\x9e\xfe\x8e\xfb\x85'

# Generated at 2022-06-24 23:07:51.185605
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    float_0 = 34.8
    bytes_0 = b'\xd2\xadF\xba\xb9\x9d\xe6\x85\x16\x1f\x8e\xaf'
    linux_network_0 = LinuxNetwork(bytes_0)
    var_0 = linux_network_0.get_default_interfaces(float_0)
    assert var_0 != float_0


# Generated at 2022-06-24 23:08:00.269141
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    arg_0 = None

# Generated at 2022-06-24 23:08:33.997106
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    float_0 = 34.8
    bytes_0 = b'\xd2\xadF\xba\xb9\x9d\xe6\x85\x16\x1f\x8e\xaf'
    linux_network_0 = LinuxNetwork(bytes_0)
    var_0 = linux_network_0.get_default_interfaces(float_0)
    linux_network_1 = LinuxNetwork(bytes_0)
    linux_network_1.populate(float_0)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-24 23:08:41.486063
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    bytes_0 = b'\x95\x8f\xe3\xc7\xcb\xef'
    linux_network_0 = LinuxNetwork(bytes_0)
    float_0 = 34.8
    result = linux_network_0.get_interfaces_info(float_0, float_0, float_0)
    assert isinstance(result, dict)

# Generated at 2022-06-24 23:08:46.320644
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    linux_network_collector_0 = LinuxNetworkCollector()
    if isinstance(linux_network_collector_0, NetworkCollector):
        assert True
    else:
        assert False

# class LinuxNetwork



# Generated at 2022-06-24 23:08:47.736879
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Test case 0
    test_case_0()


# Generated at 2022-06-24 23:08:58.844026
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    float_0 = float(34)
    float_1 = float(34)
    float_2 = float(34)
    float_3 = float(34)
    float_4 = float(34)
    float_5 = float(34)
    float_6 = float(34)
    float_7 = float(34)
    float_8 = float(34)
    float_9 = float(34)
    float_10 = float(34)
    float_11 = float(34)
    float_12 = float(34)
    float_13 = float(34)
    float_14 = float(34)
    float_15 = float(34)
    float_16 = float(34)
    float_17 = float(34)
    float_18 = float(34)
    float_19 = float(34)

# Generated at 2022-06-24 23:09:06.166103
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    # setup
    float_0 = 34.8

    # execution
    bytes_0 = b'\xd2\xadF\xba\xb9\x9d\xe6\x85\x16\x1f\x8e\xaf'
    linux_network_0 = LinuxNetwork(bytes_0)
    var_0 = linux_network_0.get_default_interfaces(float_0)

    # validation
    assert var_0 == (('ipv4', 'ipv6'), ('ipv4', 'ipv6'))


# Generated at 2022-06-24 23:09:12.720982
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    float_0 = 34.8
    bytes_0 = b'\xd2\xadF\xba\xb9\x9d\xe6\x85\x16\x1f\x8e\xaf'
    linux_network_0 = LinuxNetwork(bytes_0)
    linux_network_0.populate(float_0)


# Generated at 2022-06-24 23:09:15.540826
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    float_0 = 34.8
    bytes_0 = b'\xd2\xadF\xba\xb9\x9d\xe6\x85\x16\x1f\x8e\xaf'
    linux_network_0 = LinuxNetwork(bytes_0)
    var_0 = linux_network_0.get_default_interfaces(float_0)


# Generated at 2022-06-24 23:09:22.372196
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    float_0 = 34.8
    bytes_0 = b'\xd2\xadF\xba\xb9\x9d\xe6\x85\x16\x1f\x8e\xaf'
    linux_network_0 = LinuxNetwork(bytes_0)
    linux_network_0.get_interfaces_info(float_0, float_0, float_0)


# Generated at 2022-06-24 23:09:27.362284
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    float_0 = 34.8
    bytes_0 = b'\xd2\xadF\xba\xb9\x9d\xe6\x85\x16\x1f\x8e\xaf'
    linux_network_0 = LinuxNetwork(bytes_0)
    linux_network_0.populate(float_0)

# Generated at 2022-06-24 23:10:18.814010
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    # Simplified test case example
    linux_network_0 = LinuxNetwork(float_0, float_0)
    linux_network_0.module = float_0
    linux_network_0.module.run_command = lambda a: [0, 'looo', '']
    var_0 = linux_network_0.get_default_interfaces()
    # expected output:
    # {'v4': {}, 'v6': {}}
    if var_0 != {'v4': {}, 'v6': {}}:
        raise Exception("Test case failed: " + var_0)


# Generated at 2022-06-24 23:10:23.144284
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    int_0 = 732
    linux_network_0 = LinuxNetwork(int_0, int_0)
    linux_network_0.get_interfaces_info(int_0, int_0, int_0)
    linux_network_0.populate()


# Generated at 2022-06-24 23:10:26.377271
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    float_0 = 34.07818770975538
    linux_network_2 = LinuxNetwork(float_0, float_0)
    var_1 = linux_network_2.get_default_interfaces(float_0)


# Generated at 2022-06-24 23:10:30.324739
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    float_0 = 34.07818770975538
    linux_network_0 = LinuxNetwork(float_0, float_0)
    linux_network_0.get_ethtool_data("enp0s3")


# Generated at 2022-06-24 23:10:35.329320
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # String precision = ""
    float_0 = 34.07818770975538
    linux_network_0 = LinuxNetwork(float_0, float_0)
    linux_network_0.populate(float_0, float_0, float_0)
    linux_network_0.populate(float_0, float_0, float_0)


# Generated at 2022-06-24 23:10:42.772004
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    def perform_test(testdata, expected_result):
        float_0 = 34.07818770975538
        linux_network_0 = LinuxNetwork(float_0, float_0)
        var_0 = linux_network_0.get_ethtool_data(testdata)
        if var_0 != expected_result:
            raise Exception("Assertion error: Expected {0}, got {1}".format(expected_result, var_0))
        print("Assertion succeeded")

    # Test data from ethtool -k on Ubuntu 18.04
    test_data_0 = "/sys/class/net/eno1"