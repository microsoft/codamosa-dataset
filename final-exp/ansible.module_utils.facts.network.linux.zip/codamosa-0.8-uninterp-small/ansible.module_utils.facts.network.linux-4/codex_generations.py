

# Generated at 2022-06-24 23:01:23.420214
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    obj = LinuxNetwork()
    stub_bool = False
    stub_default_ipv6 = { 'address': 'fe80::20c:29ff:fe9d:6eba'}
    stub_default_ipv4 = { 'address': '192.168.0.1'}
    stub_ip_path = ''

# Generated at 2022-06-24 23:01:27.341059
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    bool_0 = True
    linux_network_collector_0 = LinuxNetworkCollector(bool_0)
    str_0 = ""
    # Act
    result = linux_network_collector_0.get_ethtool_data(str_0)
    # Assert
    #assert result == expected_value


# Generated at 2022-06-24 23:01:38.287585
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    bool_0 = True

    # Test whether ethtool is available on the system,
    # if not, test suite will be skipped
    ethtool_path = module.get_bin_path("ethtool")
    if not ethtool_path:
        module.exit_json(ethtool_path=ethtool_path, skipped=True)

    # Test output for ethtool -k <devname>
    args = [ethtool_path, '-k', 'eth0']
    rc, stdout, stderr = module.run_command(args, errors='surrogate_then_replace')
    if rc != 0:
        module.exit_json(stdout=stdout, stderr=stderr, rc=rc)

    # Test output for ethtool -T <devname>

# Generated at 2022-06-24 23:01:42.982670
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module_0 = None
    bool_0 = False
    linux_network_0 = LinuxNetwork(module_0, bool_0)
    linux_network_collector_0 = None
    linux_network_0.populate(linux_network_collector_0)


# Generated at 2022-06-24 23:01:45.695579
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # FIXME: this is a weak test
    bool_0 = False
    linux_network_collector_0 = LinuxNetworkCollector(bool_0)
    (ipv4_dict_0, ipv6_dict_0) = linux_network_collector_0.get_default_interfaces()


# Generated at 2022-06-24 23:01:48.899702
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    bool_0 = False
    linux_network_collector_0 = LinuxNetworkCollector(bool_0)
    linux_network_collector_0.get_ethtool_data('eth0')


# Generated at 2022-06-24 23:01:58.158805
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_interface_0 = Mock()
    linux_network_interface_0.get_interfaces_info = lambda : (
        (
            "abcd",
            "efgh",
        ),
        (
            "ijkl",
            "mnop",
        ),
    )
    linux_network_interface_0.get_routes = lambda : (
        (
            "qrst",
            "uvwx",
        ),
        (
            "yz12",
            "3456",
        ),
    )
    linux_network_collector_0 = LinuxNetworkCollector(True)
    linux_network_collector_0.interface = linux_network_interface_0
    linux_network_0 = LinuxNetwork(linux_network_collector_0)
    linux_network_0.populate()


# Generated at 2022-06-24 23:02:02.875089
# Unit test for method populate of class LinuxNetwork

# Generated at 2022-06-24 23:02:06.368259
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Test with a test case for the LinuxNetwork class
    test_case_0()


# Generated at 2022-06-24 23:02:15.580197
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # FIXME: we're using local versions of actual methods as test methods
    #        which is probably not ideal
    ip_path = "/path/to/ip"
    default_ipv4 = {"address": '1.2.3.4'}
    default_ipv6 = {"address": 'fe80::'}

# Generated at 2022-06-24 23:02:53.609096
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    result = LinuxNetworkCollector().get_default_interfaces()
    assert type(result) is tuple and len(result) == 2, \
        "The method get_default_interfaces of class LinuxNetwork " \
        "did not return a tuple of length 2"


# Generated at 2022-06-24 23:02:57.565030
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_collector = LinuxNetworkCollector()
    linux_network_collector.get_interfaces_info()


# Generated at 2022-06-24 23:03:08.219084
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """Test get_ethtool_data from LinuxNetwork"""

    linux_network_collector_0 = LinuxNetworkCollector()
    rc, out, err = linux_network_collector_0.module.run_command("ifconfig", errors='surrogate_then_replace')
    if rc == 0:
        device = out.splitlines()[0].split(":")[0]
        ethtool_data = linux_network_collector_0.get_ethtool_data(device)
        assert "features" in ethtool_data
        assert type(ethtool_data["features"]) == dict
        # Asserting "timestamping" is good enough. If it is present all the data is present
        assert "timestamping" in ethtool_data


# Generated at 2022-06-24 23:03:12.019950
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_collector = LinuxNetworkCollector()
    linux_network_collector.get_ethtool_data('eth0')


# Generated at 2022-06-24 23:03:21.866756
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_collector_0 = LinuxNetworkCollector()
    device_0 = 'device_value'

# Generated at 2022-06-24 23:03:25.611286
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_0 = LinuxNetwork()
    linux_network_0.populate()
    assert linux_network_0.interfaces['ens3']['ipv4']['broadcast'] == '10.10.102.255', "test_LinuxNetwork_populate"


# Generated at 2022-06-24 23:03:35.633576
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_collector_0 = LinuxNetworkCollector()
    rc, stdout, stderr = linux_network_collector_0.module.run_command(["ip", "-V"], errors='surrogate_then_replace')
    if rc == 0:
        if stdout and stderr:
            raise Exception("stdout or stderr should be empty, they are not: %s %s" % (stdout, stderr))
        if stdout:
            if 'iproute2' not in stdout:
                raise Exception("iproute2 command not found")
        if stderr:
            raise Exception("stderr should be empty, it is not")
    else:
        raise Exception("ip command not found")
    rc, stdout, stderr = linux_network_collector_0.module.run_

# Generated at 2022-06-24 23:03:43.882442
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_collector_0 = LinuxNetworkCollector()
    # device received as parameter. Expected result is a dict, as returned by
    # the method get_ethtool_data.
    res = linux_network_collector_0.get_ethtool_data("lo")
    assert not res

    # Empty device received as parameter. Expected result is a dict, as
    # returned by the method get_ethtool_data.
    res = linux_network_collector_0.get_ethtool_data("")
    assert not res

    res = linux_network_collector_0.get_ethtool_data("dummy.example.com")
    assert not res



# Generated at 2022-06-24 23:03:49.302372
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    network = LinuxNetwork(module)

# Generated at 2022-06-24 23:03:54.802696
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network = LinuxNetwork()

    # Test case 0
    device = 'enp2s0'
    expected = {
        'features': {
            'rx_all': 'off',
            'rx_fcs': 'off',
            'rx_length_errors': 'off',
            'rx_no_buffer': 'off',
            'rx_shared_errors': 'off',
            'rx_short': 'off',
            'rx_tcp_udp_chksum_offload': 'on',
            'rx_vlan_hw_parse': 'on',
            'rx_vlan_stag_hw_parse': 'on'
        },
        'timestamping': ['hardware', 'software'],
        'hw_timestamp_filters': ['all']
    }
    result = linux_network

# Generated at 2022-06-24 23:04:39.744504
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network_collector_1 = LinuxNetworkCollector()
    # Test with no arguments passed
    result = linux_network_collector_1.get_default_interfaces()
    assert type(result) == tuple
    assert len(result) == 2
    assert type(result[0]) == dict
    assert len(result[0]) == 4
    assert 'interface' in result[0]
    assert type(result[0]['interface']) == str
    assert 'address' in result[0]
    assert type(result[0]['address']) == str
    assert 'netmask' in result[0]
    assert type(result[0]['netmask']) == str
    assert 'network' in result[0]
    assert type(result[0]['network']) == str

# Generated at 2022-06-24 23:04:49.533293
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    config_data = basic_config_data
    module = mock_module(params=config_data)
    # NOTE: AnsibleModule comes in as a mock and thus has no defined dict. How do we add things?
    # module.params.update({'state': 'absent'})
    linux_network_collector = LinuxNetworkCollector()
    results = linux_network_collector.populate(module=module)
    assert results['ipv4']['address'] == '192.0.2.1', 'ipv4 address is incorrect'
    assert results['ipv4']['netmask'] == '255.255.255.0', 'ipv4 netmask is incorrect'
    assert results['ipv6']['address'] == '2001:db8:1::1', 'ipv6 address is incorrect'
    assert results

# Generated at 2022-06-24 23:04:53.641297
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network_collector_1 = LinuxNetworkCollector()
    # get_default_interfaces
    result = linux_network_collector_1.get_default_interfaces()
    assert result[0]['gateway'] == '172.17.0.1'
    assert result[0]['interface'] == 'docker0'
    assert result[1]['interface'] == 'docker0'


# Generated at 2022-06-24 23:05:03.562728
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_collector_0 = LinuxNetworkCollector()
    device = "eth0"
    features = linux_network_collector_0.get_ethtool_data(device).get("features", None)
    if features:
        # All Linux systems should support scatter-gather.
        assert("scatter_gather" in features)
    else:
        assert(False, "Linux system does not support ethtool")

if __name__ == '__main__':
    test_LinuxNetwork_get_ethtool_data()


# Generated at 2022-06-24 23:05:15.327155
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """Tests get_ethtool_data"""
    linux_network_collector_0 = LinuxNetworkCollector()

    linux_network_collector_0.INTERFACE_TYPE = {1: 'loopback',
                                                653: 'bridge',
                                                772: 'bonding'}


# Generated at 2022-06-24 23:05:23.097613
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # FIXME: in linux_network_collector_0.get_default_interfaces()
    # there are a lot of default_ipv4 = None
    # Those should be default_ipv4 = {}, same for default_ipv6
    linux_network_collector_0 = LinuxNetworkCollector()
    default_ipv4, default_ipv6 = linux_network_collector_0.get_default_interfaces()
    # TODO: assert that default_ipv4 and default_ipv6 have the same keys
    # TODO: assert certain keys are in default_ipv4, default_ipv6



# Generated at 2022-06-24 23:05:36.024956
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_collector_0 = LinuxNetworkCollector()
    linux_network_collector_0.get_ethtool_data("lo")


# Generated at 2022-06-24 23:05:39.506757
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    method_under_test = LinuxNetworkCollector.populate
    assert callable(method_under_test), f"{method_under_test} is not callable"


# Generated at 2022-06-24 23:05:41.572801
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network = LinuxNetwork()
    assert linux_network.get_default_interfaces() == ({}, {})


# Generated at 2022-06-24 23:05:50.819247
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.network.common.utils import dict_merge

    current_network = LinuxNetwork()
    current_network.ethtool_path = "/usr/bin/ethtool"
    device = "eth0"


# Generated at 2022-06-24 23:06:29.295298
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Test with default 'rc'
    linux_network_0 = LinuxNetwork()
    # Set 'fact_gather_timeout' to 0
    linux_network_0.get_distribution = MagicMock(return_value={'name': 'some name', 'family': 'some family', 'version': 'some version'})
    linux_network_0.get_routes = MagicMock(return_value=([{'dev': 'some dev'}], [{'dev': 'some dev'}]))
    linux_network_0.get_interfaces_info = MagicMock(return_value=({'some interface': 'value'}, {'all_ipv4_addresses': 'some all ipv4 addresses'}))
    # FIXME: test later
    # linux_network_0.get_hw_addr = MagicM

# Generated at 2022-06-24 23:06:41.430132
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_collector_0 = LinuxNetworkCollector()
    ans_obj = dict()
    ans_obj['network'] = dict()
    ans_obj['network']['default_ipv4'] = dict()
    ans_obj['network']['default_ipv4']['address'] = '192.168.0.12'
    ans_obj['network']['default_ipv6'] = dict()
    ans_obj['network']['default_ipv6']['address'] = '2001:db8:a0b:12f0::1'
    linux_network_collector_0.populate(ans_obj)

# Generated at 2022-06-24 23:06:50.813528
# Unit test for method get_default_interfaces of class LinuxNetwork

# Generated at 2022-06-24 23:06:58.437978
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Create an instance of LinuxNetwork to test method
    linux_network_collector_1 = LinuxNetworkCollector()
    ip_path = linux_network_collector_1.module.get_bin_path("ip")
    default_ipv4 = dict()
    default_ipv6 = dict()
    linux_network_collector_1.get_interfaces_info(ip_path, default_ipv4, default_ipv6)


# Generated at 2022-06-24 23:07:03.767433
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # init
    os_collector = LinuxNetworkCollector()
    os_network = LinuxNetwork(os_collector)
    os_network.populate()
    # assert
    assert len(os_network.interfaces) > 0


# Generated at 2022-06-24 23:07:08.443710
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    # Create an instance of the LinuxNetwork module
    module = LinuxNetwork()

    # Create empty module arguments
    module.params = {}
    # Create a zeroed module result dictionary
    module.result = dict(
        changed=False,
        failed=False,
        meta={},
        msg='',
        rc=0,
        stderr='',
        stdout='',
    )

    # Set module options
    module.params['config'] = 'ansible/test/files/linux_network_test0_config.j2'
    module.params['target'] = 'ansible/test/files/linux_network_test0_target.txt'

    # set up json file with definition of network interface
    # to populate from it

# Generated at 2022-06-24 23:07:16.306173
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Test for get_ethtool_data
    linux_network_collector_2 = LinuxNetworkCollector()
    device = 'eth0'
    # Tests for ethtool not present:
    os.environ["PATH"] = "/usr/sbin:/usr/bin:/sbin:/bin"
    os.environ["PATH"] = re.sub(r"{}/ansible_collections/ansible/micoos/plugins/modules".format(os.getcwd()), "", os.environ["PATH"], flags=re.MULTILINE)
    result = linux_network_collector_2.get_ethtool_data(device)
    assert 0 == result
    # Tests for ethtool present but unknown device:
    os.environ["PATH"] = "/usr/sbin:/usr/bin:/sbin:/bin"
   

# Generated at 2022-06-24 23:07:25.485494
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_collector2 = LinuxNetworkCollector()
    # TODO: There's a lot going on in here
    # The first argument is a list
    # The second argument is a dictionary
    # The third argument is a dictionary
    # In this context, it's a static method call
    (interfaces2, ips2) = LinuxNetworkCollector.get_interfaces_info()
    for i in interfaces2:
        print(i)

    # Now, let's try using the object
    linux_network_collector_0 = LinuxNetworkCollector()
    (interfaces, ips) = linux_network_collector_0.get_interfaces_info()

    interfaces in interfaces2
    ips in ips2


# Generated at 2022-06-24 23:07:36.206919
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_0 = LinuxNetwork()

    linux_network_collector_1 = LinuxNetworkCollector()
    # Var: default_ipv6
    default_ipv6 = {
        'address': 'fe80::1c97:abcd:ef12:3456',
        'scope': 'link'
    }
    # Var: default_ipv4
    default_ipv4 = {
        'address': '10.0.0.1',
        'network': '10.0.0.0'
    }
    # Var: ip_path
    ip_path = None
    # Var: interfaces_ipv6
    interfaces_ipv6 = {}
    # Var: interfaces_ipv4
    interfaces_ipv4 = {}
    # Var: interfaces
    interfaces = {}
    # Var: ips

# Generated at 2022-06-24 23:07:40.274726
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_collector = LinuxNetworkCollector()
    ip_path = linux_network_collector.module.get_bin_path("ip", required=False)
    default_ipv4, default_ipv6 = {}, {}
    interfaces, ips = linux_network_collector.get_interfaces_info(ip_path, default_ipv4, default_ipv6)


# Generated at 2022-06-24 23:08:09.466573
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    pass  # TODO


# Generated at 2022-06-24 23:08:14.391741
# Unit test for method populate of class LinuxNetwork

# Generated at 2022-06-24 23:08:17.469273
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    linux_network_0 = LinuxNetwork()
    linux_network_0.populate()


if __name__ == '__main__':

    test_LinuxNetwork_populate()

    test_case_0()

# Generated at 2022-06-24 23:08:24.326161
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_collector_0 = LinuxNetworkCollector()
    linux_network_collector_0.get_interfaces_info(
        "./test/test_data/test_LinuxNetworkCollector_get_interfaces_info_ip_path",
        {'address': '192.168.1.1'},
        {'address': '2001:db8::1'}
    )


# Generated at 2022-06-24 23:08:27.718329
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_collector = LinuxNetworkCollector()

    linux_network_collector.get_interfaces_info(ip_path='fake_ip_path', default_ipv4='fake_default_ipv4', default_ipv6='fake_default_ipv6')


# Generated at 2022-06-24 23:08:30.375731
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_collector_0 = LinuxNetworkCollector()
    # Mock module inputs
    module_0 = MagicMock(name='ansible.module_utils.basic.AnsibleModule')

# Generated at 2022-06-24 23:08:40.371132
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    linux_network_collector_0 = LinuxNetworkCollector()
    linux_network_collector_0.populate()


# Generated at 2022-06-24 23:08:48.863742
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """AnsibleModule Test Case"""
    def module_mock(name, *args, **kwargs):
        module = AnsibleModule(argument_spec=dict())
        return module

    module_mock.run_command = MagicMock(return_value=(0, "", ""))
    module_mock.get_bin_path = MagicMock(return_value="/sbin/ip")

    linux_network_collector_1 = LinuxNetworkCollector()
    linux_network_collector_1.get_interfaces_info()

# Generated at 2022-06-24 23:08:59.076094
# Unit test for method get_default_interfaces of class LinuxNetwork

# Generated at 2022-06-24 23:09:06.258455
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    linux_network_0 = LinuxNetwork()
    # NOTE: pycharm says these are undefined
    ip_path = ''
    default_ipv4 = {}
    default_ipv6 = {}
    interfaces, ips = linux_network_0.get_interfaces_info(ip_path, default_ipv4, default_ipv6)
    for interface in interfaces:
        print('{} -> {}'.format(interface, interfaces[interface]))

if __name__ == '__main__':
    test_case_0()
    test_LinuxNetwork_get_interfaces_info()

# Generated at 2022-06-24 23:09:53.418370
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # NOTE: this test is currently dependent on the path which is defined in the code
    # it is somewhat kludgy and could be improved upon
    # noinspection PyUnresolvedReferences
    if 'ANSIBLE_TEST_MODULE_MODULE' in os.environ and os.environ['ANSIBLE_TEST_MODULE_MODULE'] == 'linux_network':
        modules_bin_path = os.path.normpath(os.path.join(os.environ['ANSIBLE_TEST_MODULE_PATH'], '../../../../../', 'library'))
        ethtool_path = os.path.join(modules_bin_path, 'ethtool')
        command = [ethtool_path, '-k', 'lo']

# Generated at 2022-06-24 23:09:58.098620
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    test_case_0()

if __name__ == '__main__':
    test_LinuxNetwork_populate()

# Generated at 2022-06-24 23:10:03.363957
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    str_0 = 'eval'
    ip_path_0 = ''
    default_ipv4_0 = {}
    default_ipv6_0 = {}
    linux_network_0 = LinuxNetwork(str_0)
    linux_network_0.get_interfaces_info(ip_path_0, default_ipv4_0, default_ipv6_0)

# Generated at 2022-06-24 23:10:06.446670
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    str_0 = 'eval'
    linux_network_0 = LinuxNetwork(str_0)
    str_1 = 'device'
    var_0 = linux_network_0.get_ethtool_data(str_1)


# Generated at 2022-06-24 23:10:10.597212
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    str_0 = 'eval'
    linux_network_0 = LinuxNetwork(str_0)
    str_1 = 'get_default_interface'
    str_2 = 'get_default_interface'
    (var_1, var_2) = linux_network_0.get_interfaces_info(str_1, str_2)


# Generated at 2022-06-24 23:10:21.376354
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Standard use
    linux_network_0 = LinuxNetwork('test_module_0')
    var_0 = linux_network_0.populate()
    # Check for failure
    linux_network_1 = LinuxNetwork('test_module_1')
    var_1 = linux_network_1.populate()
    # Check for failure
    linux_network_2 = LinuxNetwork('test_module_2')
    var_2 = linux_network_2.populate()
    # Check for failure
    linux_network_3 = LinuxNetwork('test_module_3')
    var_3 = linux_network_3.populate()
    # Check for failure
    linux_network_4 = LinuxNetwork('test_module_4')
    var_4 = linux_network_4.populate()
    # Check for failure
    linux_network

# Generated at 2022-06-24 23:10:22.705526
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    pass


# Generated at 2022-06-24 23:10:32.629083
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    emulated_linux_network_populate_1 = gen_populate(b'lo\n')
    # NOTE: semicolon is to avoid a JSON key starting with a number, and the
    # trailing comma is necessary so that this is valid JSON.

# Generated at 2022-06-24 23:10:34.932470
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    try:
        test_case_0()
    except Exception as err:
        print('Error: ' + str(err))

# Generated at 2022-06-24 23:10:39.082930
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_0 = 'eval'
    linux_network_0 = LinuxNetwork(str_0)
    dict_0, dict_1 = linux_network_0.get_default_interfaces()
    print(dict_0)
    print(dict_1)
