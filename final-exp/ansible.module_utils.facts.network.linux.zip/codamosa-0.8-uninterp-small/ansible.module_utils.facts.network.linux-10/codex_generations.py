

# Generated at 2022-06-24 23:01:16.235553
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    float_0 = 1911.0
    linux_network_0 = LinuxNetwork(float_0)
    linux_network_0.get_ethtool_data(linux_network_0)


# Generated at 2022-06-24 23:01:26.470649
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    float_0 = 1911.0
    module = AnsibleModule(argument_spec={})
    module.check_mode = False
    linux_network_0 = LinuxNetwork(float_0)
    ipv4, ipv6 = linux_network_0.get_interfaces_info('', {}, {})
    for key in ipv4:
        linux_network_0.interfaces[key] = ipv4[key]
    v6_1, v6_0 = linux_network_0.get_default_route('')
    linux_network_0.default_ipv6 = v6_1
    linux_network_0.default_ipv4 = v6_0
    linux_network_0.module = module
    # If number of arguments is not 4 then exception is raised
    # If the types of arguments is not

# Generated at 2022-06-24 23:01:29.031746
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    float_0 = 1911.0
    ansible_hostname_0 = LinuxNetwork(float_0)
    ansible_hostname_0.populate()


# Generated at 2022-06-24 23:01:31.318950
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network_1 = LinuxNetwork()
    linux_network_1.get_default_interfaces()


# Generated at 2022-06-24 23:01:41.375238
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    float_0 = 1911.0
    linux_network_0 = LinuxNetwork(float_0)
    float_1 = 1911.0
    linux_network_1 = LinuxNetwork(float_1)
    float_2 = 1924.0
    linux_network_2 = LinuxNetwork(float_2)
    float_3 = 988.0
    linux_network_3 = LinuxNetwork(float_3)
    int_0 = linux_network_1.populate(linux_network_3, linux_network_3, linux_network_0, linux_network_3, linux_network_0)


# Generated at 2022-06-24 23:01:51.446256
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    float_0 = 1911.0
    linux_network_0 = LinuxNetwork(float_0)
    module_0 = AnsibleModule(argument_spec={})
    linux_network_0.module = module_0
    # FIXME: module_0.params = { ... }
    # FIXME: pin module_0.params
    # FIXME: pin module_0.params['ip'] (not needed here)
    # FIXME: use module_0.params['ip_path'] instead
    ip_path_0 = module_0.params['ip_path']
    if ip_path_0 is None:
        # ip_path_0 = linux_network_0.get_bin_path('ip')
        ip_path_0 = module_0.get_bin_path('ip')
    # FIXME: use module_0.

# Generated at 2022-06-24 23:01:56.776079
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # FIXME
    # pass

    network = LinuxNetwork()
    default_v4, default_v6 = network.get_default_interfaces()
    assert default_v4['address'] == '172.17.0.1'
    assert default_v6['address'] == 'fe80::42:acff:fe11:1'

if __name__ == '__main__':
    import sys
    sys.exit(test_case_0())

# Generated at 2022-06-24 23:02:05.298187
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    float_0 = 27.0
    linux_network_0 = LinuxNetwork(float_0)
    
    # Data for test
    # str_0 is instance of str
    str_0 = "Slovenia"
    # str_1 is instance of str
    str_1 = "0.0.0.0"
    
    # int_0 is instance of int
    int_0 = 1024
    # class_0 is instance of class 'dict'
    class_0 = {}
    class_0['dev'] = str_0
    class_0['address'] = str_1
    
    # class_1 is instance of class 'dict'
    class_1 = {}
    class_1['address'] = str_1
    
    
    # class_2 is instance of class 'dict'
    class_2 = {}

# Generated at 2022-06-24 23:02:07.692250
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    float_0 = 1911.0
    linux_network_0 = LinuxNetwork(float_0)
    linux_network_0.get_default_interfaces()


# Generated at 2022-06-24 23:02:11.097185
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    float_0 = 1911.0
    linux_network_0 = LinuxNetwork(float_0)
    str_0 = '_Q*E9sKsW6U8'
    linux_network_0.get_ethtool_data(str_0)


# Generated at 2022-06-24 23:02:48.326905
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network_1 = _linux_network_class_instance()
    input = ''
    expected_result = ('eth0', 'eth0')
    result = linux_network_1.get_default_interfaces(input)
    assert result == expected_result


# Generated at 2022-06-24 23:02:53.260624
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    def test_case_0():
        linux_network_0 = LinuxNetwork()
        # FIXME: construct needed vars
        # FIXME: call the real class's populate method with the needed args
        linux_network_0.populate()
        # NOTE: assert statements here
        assert False


# Generated at 2022-06-24 23:03:06.259343
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import tempfile
    linux_network_1 = LinuxNetwork()
    default_ipv4 = {"address": "ipv4_address_test_case_1"}
    default_ipv6 = {"address": "ipv6_address_test_case_1"}

    # Test case 1 - for the scenario where all files in /sys/class/net/* exists
    temp_dir_path = tempfile.mkdtemp()

# Generated at 2022-06-24 23:03:08.959681
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    """ Unit test for method get_default_interfaces() of class LinuxNetwork """
    test_module = LinuxNetwork()
    assert test_module.get_default_interfaces() == {'v4': {}, 'v6': {}}


# Generated at 2022-06-24 23:03:20.612892
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_ref = LinuxNetwork()
    ethtool_data_ref = {}

# Generated at 2022-06-24 23:03:33.165593
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible.module_utils.network.common.utils import dict_to_set
    from ansible.module_utils.network.common.cmd_exec import Command
    from ansible.module_utils.network.common.module_runner import ModuleRunner

    class TestLinuxNetworkModule(object):
        def __init__(self, m_runner=None):
            self.runner = m_runner
            self.run_command = None
            self.get_bin_path = None

# Generated at 2022-06-24 23:03:35.240394
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network = LinuxNetwork()
    assert linux_network.get_ethtool_data('dummy0') == {}



# Generated at 2022-06-24 23:03:43.310362
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_0 = LinuxNetwork()

    # Example from https://www.kernel.org/doc/Documentation/networking/timestamping.txt

# Generated at 2022-06-24 23:03:44.986281
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # FIXME: mock out the object and assert on returned results
    linux_network_0 = LinuxNetwork()
    linux_network_0.get_default_interfaces()


# Generated at 2022-06-24 23:03:50.790527
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Run this to see what the class populates
    linux_network_0 = LinuxNetwork()
    pprint(linux_network_0.interfaces)

if __name__ == '__main__':
    test_case_0()
    test_LinuxNetwork_populate()

# Generated at 2022-06-24 23:04:39.263432
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    float_0 = -272.745
    linux_network_0 = LinuxNetwork(float_0)

# Generated at 2022-06-24 23:04:43.164115
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    float_0 = -272.745
    linux_network_0 = LinuxNetwork(float_0)
    linux_network_0.populate()
    var_0 = linux_network_0.get_default_interfaces()



# Generated at 2022-06-24 23:04:49.446209
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    float_0 = -272.745
    linux_network_0 = LinuxNetwork(float_0)
    var_0 = linux_network_0.populate()
    var_1 = linux_network_0.get_default_interfaces()
    # If the output of var_0 does not contain valid values for source, destination, and gateway variables,
    # then there is no default interface
    assert isinstance(var_1['v4'], dict)
    assert isinstance(var_1['v6'], dict)


# Generated at 2022-06-24 23:04:52.988326
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    float_0 = -272.745
    linux_network_0 = LinuxNetwork(float_0)
    var_0 = linux_network_0.get_default_interfaces()
    var_0 = linux_network_0.get_default_interfaces()
    var_0 = linux_network_0.get_default_interfaces()


# Generated at 2022-06-24 23:05:02.736234
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    float_0 = -272.745
    linux_network_0 = LinuxNetwork(float_0)
    var_0 = linux_network_0.populate()
    # get_default_interfaces
    iface = {'interface': 'rhevmgt1', 'address': '10.0.0.4', 'gateway': '172.31.127.253'}

# Generated at 2022-06-24 23:05:04.442673
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network_0 = LinuxNetwork(var_0, var_0)
    linux_network_0.populate()
    var_0 = linux_network_0.populate()

# Generated at 2022-06-24 23:05:08.678509
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    float_0 = -272.745
    linux_network_0 = LinuxNetwork(float_0)
    var_0 = get_default_interfaces(linux_network_0)



# Generated at 2022-06-24 23:05:15.415619
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    float_0 = -572.427
    linux_network_0 = LinuxNetwork(float_0)
    str_0 = '&^Y+#]3%0-]{(p&<'
    str_1 = 'D*MzZ'
    str_2 = '0J_8'
    linux_network_0.populate()
    var_0 = linux_network_0.get_interfaces_info(str_0, str_1, str_2)


# Generated at 2022-06-24 23:05:18.704861
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    float_0 = -272.745
    linux_network_0 = LinuxNetwork(float_0)
    linux_network_0.get_interfaces_info(None, None, None)


# Generated at 2022-06-24 23:05:21.837487
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    unit_testing = [0, 101]
    for i in unit_testing:
        if i == 0:
            test_case_0()
        elif i == 101:
            test_case_1()


# Generated at 2022-06-24 23:06:05.275676
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    ip_path = "/usr/bin/ip"
    default_ipv4 = {}
    default_ipv6 = {}

    float_0 = 3.2
    linux_network_0 = LinuxNetwork(float_0)
    var_0 = linux_network_0.populate()
    var_1 = linux_network_0.get_interfaces_info(ip_path, default_ipv4, default_ipv6)


# Generated at 2022-06-24 23:06:15.517878
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    float_0 = -272.745
    linux_network_0 = LinuxNetwork(float_0)
    linux_network_1 = LinuxNetwork(float_0)
    linux_network_2 = LinuxNetwork(float_0)
    linux_network_3 = LinuxNetwork(float_0)
    var_0 = linux_network_0.populate()

    # Test with an empty device
    var_1 = linux_network_1.get_ethtool_data("")
    assert(var_1 == {})

    # Test with a valid device
    var_2 = linux_network_2.get_ethtool_data("eth0")
    assert(var_2 == {})

    # Test with a device without ethtool
    var_3 = linux_network_3.get_ethtool_data("eth0")

# Generated at 2022-06-24 23:06:18.045920
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    float_0 = -272.745
    linux_network_0 = LinuxNetwork(float_0)
    var_0 = linux_network_0.populate()


# Generated at 2022-06-24 23:06:22.697663
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Case 0
    float_0 = -272.745
    linux_network_0 = LinuxNetwork(float_0)
    var_0 = linux_network_0.populate()
    linux_network_0.get_ethtool_data(var_0)



# Generated at 2022-06-24 23:06:24.645638
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    float_0 = -272.745
    linux_network_0 = LinuxNetwork(float_0)
    linux_network_0.populate()


# Generated at 2022-06-24 23:06:33.996131
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    test_LinuxNetwork_class_0 = LinuxNetwork(0.0)
    #  FIXME: Don't expect type, just for debugging
    var_0 = test_LinuxNetwork_class_0.get_default_interfaces()
    print(var_0)
    linux_network_0 = LinuxNetwork(0.0)
    var_0 = linux_network_0.get_default_interfaces(default=True)
    linux_network_0 = LinuxNetwork(0.0)
    var_0 = linux_network_0.get_default_interfaces(default=False)


# Generated at 2022-06-24 23:06:38.297639
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    float_0 = -9.735
    linux_network_0 = LinuxNetwork(float_0)
    linux_network_0.populate()


if __name__ == "__main__":
    test_LinuxNetwork_populate()

# Generated at 2022-06-24 23:06:43.345231
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    float_0 = -302.759
    linux_network_1 = LinuxNetwork(float_0)
    var_1 = linux_network_1.populate()
    var_2 = linux_network_1.get_interfaces_info()


# Generated at 2022-06-24 23:06:52.176681
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    float_0 = 2.27
    linux_network_0 = LinuxNetwork(float_0)
    dict_0 = dict()
    dict_0['mtu'] = 35552
    dict_0['device'] = 'zjYmFpBuNA'
    dict_0['module'] = 'KjBZnFGceZ'
    dict_0['type'] = 'unknown'
    dict_0['macaddress'] = '2Qo_5U6mtf'
    dict_0['speed'] = 92416
    dict_0['duplex'] = 'half'
    dict_0['autonegotiation'] = 'off'
    dict_0['features'] = dict()
    dict_0['ipv4'] = dict()

# Generated at 2022-06-24 23:06:54.241520
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    test_case_0()

if __name__ == "__main__":
    # FIXME: test LinuxNetwork (other classes are tested in network_common)
    test_LinuxNetwork_populate()

# Generated at 2022-06-24 23:08:09.787637
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Populate the instance with data
    float_0 = -272.745
    os_platform_0 = 'G'
    os_version_0 = 'E'
    python_version_0 = '<'
    current_path_0 = '}'
    ansible_module_0 = AnsibleModule(float_0, os_platform_0, os_version_0, python_version_0, current_path_0)
    linux_network_0 = LinuxNetwork(ansible_module_0)
    linux_network_0.populate()

    # Call the method
    var_0 = linux_network_0.get_default_interfaces()


# Generated at 2022-06-24 23:08:18.925292
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    float_0 = -474.29
    linux_network_0 = LinuxNetwork(float_0)
    linux_network_0.populate()
    data_0 = linux_network_0.get_default_interfaces()

# Generated at 2022-06-24 23:08:23.077554
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    float_0 = -105.558
    linux_network_0 = LinuxNetwork(float_0)
    var_0 = linux_network_0.populate()
    # assert linux_network_0.get_default_interfaces() == var_0


# Generated at 2022-06-24 23:08:32.161737
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    float_0 = -272.745
    linux_network_0 = LinuxNetwork(float_0)
    linux_network_0.populate()
    function_0 = linux_network_0.get_ethtool_data
    str_0 = 'NtS'
    str_1 = ';@'
    str_2 = 'O{'
    str_3 = '@Fv'
    str_4 = '#8c'
    str_5 = '|'
    var_0 = function_0(str_0)


# Generated at 2022-06-24 23:08:35.400735
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_0 = LinuxNetwork()
    linux_network_0.populate()


# Generated at 2022-06-24 23:08:39.101350
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    float_0 = -316.778
    linux_network_0 = LinuxNetwork(float_0)
    var_0 = linux_network_0.get_default_interfaces()


# Generated at 2022-06-24 23:08:49.436266
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    default_ipv4 = {"address": "10.0.2.15",
                    "netmask": "255.255.255.0",
                    "gateway": "10.0.2.2"}
    default_ipv6 = {"address": "fe80::a00:27ff:fe58:2b1d",
                    "prefix": "64",
                    "gateway": "fe80::a00:27ff:fe58:2b15"}
    linux_network_0 = LinuxNetwork.get_default_interfaces(default_ipv4,
                                                          default_ipv6)
    assert linux_network_0 == {'v4': default_ipv4, 'v6': default_ipv6}



# Generated at 2022-06-24 23:08:56.518168
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    float_0 = -272.745
    linux_network_0 = LinuxNetwork(float_0)
    var_0 = linux_network_0.get_ipv4_interface_info("hw")
    if var_0:
        print("Ethtool data : {0}".format(var_0))
    else:
        print("Failed to get ethtool data")

if __name__ == '__main__':
    test_LinuxNetwork_get_ethtool_data()

# Generated at 2022-06-24 23:08:57.338838
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    test_case_0()


# Generated at 2022-06-24 23:09:02.027511
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    test_case_0()

if __name__ == '__main__':
    test_LinuxNetwork_populate()

# Generated at 2022-06-24 23:10:30.110773
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    in_1 = {
    }
    in_2 = {}
    in_3 = {}
    linux_network_0 = LinuxNetwork(in_1)
    var_0, var_1 = linux_network_0.get_interfaces_info(in_2, in_3)
    # Check if var_0 is float
    if not isinstance(var_0, float):
        raise Exception("Expected float, got %s" % (type(var_0)))
    # Check if var_1 is float
    if not isinstance(var_1, float):
        raise Exception("Expected float, got %s" % (type(var_1)))
    # Check if var_1 is float

# Generated at 2022-06-24 23:10:35.380727
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    float_0 = -51.82
    linux_network_0 = LinuxNetwork(float_0)
    string_0 = 'gK'
    var_59 = linux_network_0.get_ethtool_data(string_0)


# Generated at 2022-06-24 23:10:38.772514
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    float_0 = 586.1826
    linux_network_0 = LinuxNetwork(float_0)
    result_0 = linux_network_0.populate()
    assert result_0


# Generated at 2022-06-24 23:10:42.265833
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    float_0 = -837.58
    linux_network_0 = LinuxNetwork(float_0)
    unicode_0 = u't.dM>'
    # Testing get_interfaces_info method
    # FIXME: test seems to be bogus, needs to test output and input params
    str_0 = linux_network_0.get_interfaces_info(unicode_0)
    print(str_0)
