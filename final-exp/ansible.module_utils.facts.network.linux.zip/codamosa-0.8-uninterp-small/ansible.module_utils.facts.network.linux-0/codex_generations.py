

# Generated at 2022-06-24 23:01:13.171295
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_collector_0 = LinuxNetworkCollector(C.data)
    linux_network_collector_0.populate()
    assert linux_network_collector_0.result.get(u'interfaces') is not None
    assert linux_network_collector_0.result.get(u'all_ipv4_addresses') is not None


# Generated at 2022-06-24 23:01:19.090251
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_collector_0 = LinuxNetworkCollector(None)
    str_0 = 'eth0'

# Generated at 2022-06-24 23:01:28.076970
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    device = 'eth0'
    ethtool_path = '/sbin/ethtool'
    args = [ethtool_path, '-k', device]
    rc, stdout, stderr = module.run_command(args, errors='surrogate_then_replace')
    features = {}
    if rc == 0:
        for line in stdout.strip().splitlines():
            if not line or line.endswith(":"):
                continue
            key, value = line.split(": ")
            if not value:
                continue
            features[key.strip().replace('-', '_')] = value.strip()

    args = [ethtool_path, '-T', device]
    rc, stdout, stderr = module.run_command(args, errors='surrogate_then_replace')

# Generated at 2022-06-24 23:01:39.937716
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    print('Running test suite for method - get_default_interfaces')
    linux_network_collector_0 = LinuxNetworkCollector()
    # Test case 0
    ipv4_0, ipv6_0 = linux_network_collector_0.get_default_interfaces()
    assert ipv4_0['address'] is None and ipv6_0['address'] is None

    # Test case 1
    lines_1 = ['default via 192.168.1.1 dev eth0 proto static metric 100', '192.168.1.0/24 dev eth0 proto kernel scope link src 192.168.1.100 metric 100']

# Generated at 2022-06-24 23:01:45.456128
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # FIXME: this is not a unit test.  Without mocking various modules,
    # this is more an integration test.  It should be named so and moved
    # out of the unit test dir.
    module = MockAnsibleModule()
    l = LinuxNetwork(module)
    l.populate()
    assert l.default_ipv4
    assert l.default_ipv6



# Generated at 2022-06-24 23:01:56.539420
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Clean up files and directories created by the test
    rc, out, err = module.run_command('rm -rf %s' % tempfile.mkdtemp())
    mock_path = tempfile.mkdtemp()
    rc, out, err = module.run_command('touch %s/sys/class/net/eth0/address' % mock_path)
    rc, out, err = module.run_command('mkdir %s/sys/class/net/eth0/device' % mock_path)
    rc, out, err = module.run_command('touch %s/sys/class/net/eth0/device/driver/module' % mock_path)
    rc, out, err = module.run_command('echo 1 > %s/sys/class/net/eth0/device/driver/module' % mock_path)

# Generated at 2022-06-24 23:02:05.105441
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    rc, stdout, stderr = get_test_data('test_LinuxNetwork_get_ethtool_data_0.txt')
    device = 'lo'
    ethtool_path = None

    module = Mock(run_command=lambda path, args: (rc, stdout, stderr),
                  get_bin_path=lambda x: ethtool_path)
    linux_network = LinuxNetwork(module)

# Generated at 2022-06-24 23:02:13.256026
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # No exception, should pass
    try:
        linux_network_0 = LinuxNetwork('', '/usr/bin/ip')

        rc, stdout, stderr = linux_network_0.module.run_command(['/usr/bin/ip', 'route', 'show', 'to', 'default'])
        # ip command was successful
        assert rc == 0
        try:
            value_0, value_1 = linux_network_0.get_default_interfaces()
        except Exception as value_0:
            raise Exception('Failed to get default interface %s' % value_0)
    except Exception as e:
        raise Exception('Failed to execute get_default_interfaces: %s' % e)


# Generated at 2022-06-24 23:02:17.643494
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
  str_0 = 'Usage: forks <number>'
  linux_network_collector_0 = LinuxNetworkCollector(str_0)
  str_1 = 'nonempty'
  assert linux_network_collector_0.get_ethtool_data(str_1) == {'features': {}}


# Generated at 2022-06-24 23:02:20.841427
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    str_0 = 'Usage: forks <number>'
    linux_network_collector_0 = LinuxNetworkCollector(str_0)
    linux_network_collector_0.get_default_interfaces()


# Generated at 2022-06-24 23:02:55.537036
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    str_0 = 'Usage: forks <number>'
    linux_network_collector_0 = LinuxNetworkCollector(str_0)
    str_1 = '-k'
    str_2 = 'eth0'
    str_3 = '-k'
    str_4 = ':'
    linux_network_collector_0.module.run_command = MagicMock(name='run_command')
    linux_network_collector_0.module.run_command.return_value = (0, '', '')
    linux_network_collector_0.module.get_bin_path = MagicMock(name='get_bin_path')
    linux_network_collector_0.module.get_bin_path.return_value = str_4
    str_5 = 'ethtool'

# Generated at 2022-06-24 23:03:05.434236
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    str_0 = 'Usage: forks <number>'
    linux_network_collector_0 = LinuxNetworkCollector(str_0)
    linux_network_0 = LinuxNetwork(linux_network_collector_0)
    str_0 = 'Usage: ethtool <options>... <devname>'
    str_1 = 'Usage: ip [ OPTIONS ] OBJECT { COMMAND | help }'
    str_2 = 'Usage: arp [-n] [-v] [-H type] [-i if] [-a] [<hostname>]'
    linux_network_0.ip_path = str_0
    linux_network_0.ethtool_path = str_1
    linux_network_0.arp_path = str_2

# Generated at 2022-06-24 23:03:10.528227
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # No need to have test that tests the interface list on a linux box,
    # since this will change everytime.
    shell_0 = Shell(None, None)
    linux_network_collector_0 = LinuxNetworkCollector(shell_0)
    linux_network_collector_0.get_interfaces_info(None, None, None)
    #assert linux_network_collector_0.get_interfaces_info(None, None, None) == 'foobar'


# Generated at 2022-06-24 23:03:21.069145
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    # Assert module.params[\'gather_subset\'] is \'!all,!min\'.
    assert module.params['gather_subset'] == '!all,!min'

    # Assert module.params[\'gather_timeout\'] is 10.
    assert module.params['gather_timeout'] == 10

    # Assert module.params[\'filter\'] is '*'.
    assert module.params['filter'] == '*'

    # Obtain the return value of method populate of ln
    ln_return_value_populate = ln.populate()

    # Assert ln_return_value_populate is not None
    assert ln_return_value_populate is not None

    # Assert ln_return_value_populate['ansible_facts']['ansible_all

# Generated at 2022-06-24 23:03:22.825350
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Stub: interface, default_ipv4, default_ipv6 = ...
    # Stub: return LinuxNetwork.get_interfaces_info(interface, default_ipv4, default_ipv6)
    pass


# Generated at 2022-06-24 23:03:33.394603
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    # Default interface(s) is/are 'lo' and 'eth0'
    data = {'default_ipv4': {'address': '127.0.0.1', 'interface': 'lo'},
            'default_ipv6': {'address': '::1', 'interface': 'lo', 'scope': 'host'}
            }
    obj = LinuxNetwork()
    obj.set_data(data)

    # Case 0:
    lo_eth0 = {'eth0': '127.0.0.1', 'lo': '::1'}

    obj.get_default_interfaces()
    assert obj.default_interface == lo_eth0



# Generated at 2022-06-24 23:03:35.395745
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network_collector_0 = LinuxNetworkCollector()
    linux_network_collector_0.get_default_interfaces()


# Generated at 2022-06-24 23:03:43.397461
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-24 23:03:47.869677
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    assert linux_network_collector_0.get_default_interfaces() == ('eth0', 'lo')


# Generated at 2022-06-24 23:03:56.748641
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_collector_0 = LinuxNetworkCollector('Usage: forks <number>')

# Generated at 2022-06-24 23:04:29.833369
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_0 = LinuxNetwork()

    # Test case for method populate of class LinuxNetwork
    linux_network_0.populate(True, False)


# Generated at 2022-06-24 23:04:31.663326
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network_0 = LinuxNetwork()
    var_0 = linux_network_0.get_interfaces_info()


# Generated at 2022-06-24 23:04:38.856589
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    bytes_0 = b'\xde\xafu^\x1c\x10'
    linux_network_0 = LinuxNetwork(bytes_0, bytes_0)

    # FIXME: add missing call
    # TODO: replace assert with check
    assert linux_network_0.get_interfaces_info(bytes_0, bytes_0, bytes_0) == (bytes_0, bytes_0)


# Generated at 2022-06-24 23:04:48.944371
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # b'\xde\xafu^\x1c\x10'
    bytes_0 = b'\xde\xafu^\x1c\x10'
    # b't\xfc\x1c\x18\xc9'
    bytes_1 = b't\xfc\x1c\x18\xc9'

    linux_network_0 = LinuxNetwork(bytes_0, bytes_0)
    linux_network_0.module = mock.Mock()

    assert linux_network_0.module.run_command.call_count == 0

    # Call get_default_interfaces with args ('\xde\xafu^\x1c\x10')
    var_0 = linux_network_0.get_default_interfaces(bytes_0)

    assert linux_network_0

# Generated at 2022-06-24 23:04:56.165882
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():

    # Not bad parameter
    def test_get_ethtool_data_0():
        linux_network_0 = LinuxNetwork()
        var_1 = linux_network_0.get_ethtool_data(device=b'')

# Generated at 2022-06-24 23:05:05.784760
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    bytes_0 = b'\xde\xafu^\x1c\x10'
    linux_network_0 = LinuxNetwork(bytes_0, bytes_0)
    var_0 = linux_network_0.get_default_interfaces(bytes_0)
    var_1 = linux_network_0.get_default_interfaces(bytes_0)
    bytes_1 = b'\xde\xafu^\x1c\x10'
    linux_network_1 = LinuxNetwork(bytes_1, bytes_1)
    var_2 = linux_network_1.get_default_interfaces(bytes_1)
    var_3 = linux_network_1.get_default_interfaces(bytes_1)

# Generated at 2022-06-24 23:05:13.788314
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    method_0 = LinuxNetwork.get_ethtool_data
    linux_network_0 = LinuxNetwork(bytes_0, bytes_0)
    device_0 = 'S'
    return_value_0 = method_0(linux_network_0, device_0)
    return_value_1 = method_0(linux_network_0, device_0)
    return_value_2 = method_0(linux_network_0, device_0)



# Generated at 2022-06-24 23:05:22.458508
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    bytes_0 = b'\xde\xafu^\x1c\x10'
    bytes_1 = b'\x8e0\x9a\x10\xe3\xc3t\xcf\x92\xde'
    linux_network_0 = LinuxNetwork(bytes_0, bytes_1)
    linux_network_0.populate()

# unit test for class LinuxNetwork

# Generated at 2022-06-24 23:05:28.232945
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
  javac_output = subprocess.check_output("javac TestLinuxNetwork.java", shell=True, universal_newlines=True)
  java_output = subprocess.check_output("java TestLinuxNetwork", shell=True, universal_newlines=True)

  # If a test fails, an exception will be raised and printed below
  assert java_output == 'OK'


# Generated at 2022-06-24 23:05:37.842001
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Please set the path to an ethtool executable
    ethtool_path = '/path/to/ethtool'
    # the rest of the test is hard-coded, this is not a generic
    # test case.
    # However, if you use the intended interface name, it will not
    # write anything to /proc/net/dev (FIXME: why do we have mock_open)
    device = 'eth0'

# Generated at 2022-06-24 23:06:22.274036
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    bytes_0 = b'\x1a\x04\xec\xd9\x1d\xcc'
    linux_network_0 = LinuxNetwork(bytes_0, bytes_0)
    linux_network_0.populate(bytes_0)



# Generated at 2022-06-24 23:06:26.526980
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    bytes_0 = b'\xde\xafu^\x1c\x10'
    linux_network_0 = LinuxNetwork(bytes_0, bytes_0)
    assert linux_network_0.populate() == 0


# Generated at 2022-06-24 23:06:30.648249
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    bytes_0 = b'\xde\xafu^\x1c\x10'
    linux_network_0 = LinuxNetwork(bytes_0, bytes_0)
    var_0 = linux_network_0.get_default_interfaces(bytes_0)


# Generated at 2022-06-24 23:06:42.749934
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    bytes_0 = b'\xde\xafu^\x1c\x10'
    linux_network_0 = LinuxNetwork(bytes_0, bytes_0)
    var_0 = linux_network_0.get_default_interfaces(bytes_0)
    var_0 = linux_network_0.get_default_interfaces(bytes_0)
    var_0 = linux_network_0.get_default_interfaces(bytes_0)
    var_0 = linux_network_0.get_default_interfaces(bytes_0)
    var_0 = linux_network_0.get_default_interfaces(bytes_0)
    var_0 = linux_network_0.get_default_interfaces(bytes_0)

# Generated at 2022-06-24 23:06:47.747882
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    bytes_0 = b'\xa3\x8f \x80'
    bytes_1 = b'\x8b'
    bytes_2 = b'\xbf\x8e\xb9X\xd9'
    bytes_3 = b'\xec\x04'
    bytes_4 = b'\x9d\x97\x1a'
    bytes_5 = b'\x7f\x8e'
    linux_network_0 = LinuxNetwork(bytes_0, bytes_1)
    var_0 = linux_network_0.get_default_interfaces(bytes_2)
    var_1 = linux_network_0.get_interface(bytes_3)
    var_2 = linux_network_0.get_interfaces_info(bytes_4, bytes_5, bytes_5)

# Generated at 2022-06-24 23:06:51.272950
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_0 = LinuxNetwork()
    var_0 = linux_network_0.get_ethtool_data(bytes_0)


if __name__ == '__main__':
    test_LinuxNetwork_get_ethtool_data()

# Generated at 2022-06-24 23:06:53.852122
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    bytes_0 = b'\xde\xafu^\x1c\x10'
    linux_network_0 = LinuxNetwork(bytes_0, bytes_0)
    var_0 = linux_network_0.get_ethtool_data(bytes_0)


# Generated at 2022-06-24 23:07:01.219678
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
  # Test case readable_format where we test if the return is correct.
  string_type_var_0 = '127.0.0.0'
  bytes_type_var_0 = b'\x7f\x00\x00\x01'
  var_0 = (string_type_var_0,bytes_type_var_0)
  linux_network_0 = LinuxNetwork(bytes_type_var_0,bytes_type_var_0)
  assert linux_network_0.populate(var_0) == (b'\x7f\x00\x00\x00', '127.0.0.0')
  # Test case readable_format where we check if the exception is None.
  string_type_var_1 = '0.0.0.0'
  bytes_type_var_1

# Generated at 2022-06-24 23:07:05.841906
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    bytes_0 = b'\xde\xafu^\x1c\x10'
    linux_network_0 = LinuxNetwork(bytes_0, bytes_0)
    dict_0, dict_1 = linux_network_0.get_interfaces_info(bytes_0, dict_0, dict_1)
    # Default value for device is ''
    str_0 = ''
    dict_2 = linux_network_0.get_ethtool_data()


# Generated at 2022-06-24 23:07:13.853105
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-24 23:08:01.532228
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Default_ipv4 is a dictionary: {'address': '192.168.33.101', 'netmask': '255.255.255.0', 'network': '192.168.33.0'}
    default_ipv4 = {'address': '192.168.33.101', 'netmask': '255.255.255.0', 'network': '192.168.33.0'}
    # Default_ipv6 is a dictionary: {'address': 'fe80::250:56ff:fe00:1', 'prefix': '64'}
    default_ipv6 = {'address': 'fe80::250:56ff:fe00:1', 'prefix': '64'}
    # Ip_path is a string: '/sbin/ip'
    ip_path = '/sbin/ip'
    linux

# Generated at 2022-06-24 23:08:05.494036
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    bytes_0 = b'\xde\xafu^\x1c\x10'
    linux_network_0 = LinuxNetwork(bytes_0, bytes_0)


# Generated at 2022-06-24 23:08:14.035675
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    bytes_0 = b'\xda\x08\xbe\x05\x7f\x9fh\x97\xd2\xfe\xf0\xab?\xec\x06\xd8\x9a\xb4\xa4\x0bq'
    bytes_1 = b'\xda\x08\xbe\x05\x7f\x9fh\x97\xd2\xfe\xf0\xab?\xec\x06\xd8\x9a\xb4\xa4\x0bq'
    linux_network_0 = LinuxNetwork(bytes_0, bytes_0)
    var_0 = linux_network_0.get_default_interfaces(bytes_1)

# Generated at 2022-06-24 23:08:19.691416
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    bytes_0 = b'\xde\xafu^\x1c\x10'
    linux_network_0 = LinuxNetwork(bytes_0, bytes_0)
    var_0 = linux_network_0.get_default_interfaces(bytes_0)


# Generated at 2022-06-24 23:08:28.796350
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    # Test an address with no netmask
    bytes_0 = b''
    linux_network_0 = LinuxNetwork(bytes_0, bytes_0)
    linux_network_0.get_interfaces_info(bytes_0, bytes_0, bytes_0)

    # Test a unicast address with a netmask
    bytes_0 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    linux_network_0 = LinuxNetwork(bytes_0, bytes_0)
    linux_network_0.get_interfaces_info(bytes_0, bytes_0, bytes_0)

    # Test a multicast address with a netmask

# Generated at 2022-06-24 23:08:38.463013
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    bytes_0 = b'\xde\xafu^\x1c\x10'
    linux_network_0 = LinuxNetwork(bytes_0, bytes_0)
    linux_network_0.get_default_interfaces(bytes_0)
    linux_network_0.populate()
    if (not os.path.exists(linux_network_0.local_file)):
        var_2 = False
        return var_2
    var_3 = os.path.getmtime(linux_network_0.local_file)
    var_4 = (linux_network_0.result['time'] > var_3)
    if var_4:
        var_5 = True
        return var_5
    var_2 = False
    return var_2


# Generated at 2022-06-24 23:08:44.799383
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    bytes_0 = b'\xde\xafu^\x1c\x10'
    linux_network_0 = LinuxNetwork(bytes_0, bytes_0)
    var_0 = linux_network_0.get_ethtool_data(bytes_0)
    assert var_0 == dict()


# Generated at 2022-06-24 23:08:50.316009
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    bytes_0 = b'\xfe\xdc\xba\x98\x76\x54'
    linux_network_0 = LinuxNetwork(bytes_0, bytes_0)
    int_0 = 0
    str_0 = 'oAMZ\xef\x1d\x0f\xf1_p\xad\x13\xcf'
    var_0 = linux_network_0.get_ethtool_data(str_0)


# Generated at 2022-06-24 23:08:51.483503
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    for i in range(10):
        test_case_0()


# Generated at 2022-06-24 23:08:54.152822
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    pass

# Generated at 2022-06-24 23:09:49.202358
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    bytes_0 = b'\xde\xafu^\x1c\x10'
    linux_network_0 = LinuxNetwork(bytes_0, bytes_0)
    var_0 = linux_network_0.get_default_interfaces(bytes_0)
    var_1 = linux_network_0.get_interfaces_info(bytes_0, var_0[0], var_0[1])
    assert var_1 is not None


# Generated at 2022-06-24 23:09:58.502736
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    bytes_0 = b'd\xf0\x0f?\xfc\xbe'
    linux_network_0 = LinuxNetwork(bytes_0, bytes_0)
    bytes_1 = b'\x99\xd1\xc5\x96\x8a\xb5\x87M'
    bytes_2 = b'\xf2\xd3\xee\xf3\x8e\x9d\xdf\t\x88\x8b\x96\xbb\xc4\xbe\x8b\xeb\x87\x1f\x8f\xb4'
    dict_0 = linux_network_0.get_ethtool_data(bytes_1)


# Generated at 2022-06-24 23:10:08.077384
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    bytes_0 = b'\x1eg\x1a\xb4\xa3\xe3\x96B\x04\x112\xf3\x0c\x94\xb2\x07\x0b\x06\x08\x04\x01\x02\x03\x04\x05'
    bytes_1 = b"\x03\x04\x05\x06\x07\x08\x09\x0A\x0B\xc0"
    linux_network_0 = LinuxNetwork(bytes_0, bytes_0)
    linux_network_0.test_0 = linux_network_0.module
    linux_network_0.test_1 = linux_network_0.module
    linux_network_0.test_2 = linux_network_0.module
    linux

# Generated at 2022-06-24 23:10:18.388315
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    bytes_1 = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    linux_network_1 = LinuxNetwork(bytes_1, bytes_1)
    # FIXME: we should be mocking the call to get_bin_path
    string_1 = 'ethtool'
    var_1 = linux_network_1.get_bin_path(string_1)
    string_2 = 'eth0'
    var_2 = linux_network_1.get_ethtool_data(string_2)

# Generated at 2022-06-24 23:10:23.314404
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    bytes_0 = b'\xac\x18e\x97\xe2\x08'
    linux_network_0 = LinuxNetwork(bytes_0, bytes_0)
    var_0 = linux_network_0.get_default_interfaces(bytes_0)


# Generated at 2022-06-24 23:10:24.364544
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    test_case_0()


# Generated at 2022-06-24 23:10:25.215331
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    pass


# Generated at 2022-06-24 23:10:27.173760
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    bytes_0 = b'h'
    linux_network_0 = LinuxNetwork(bytes_0, None)
    var_0 = linux_network_0.get_ethtool_data(bytes_0)


# Generated at 2022-06-24 23:10:31.977369
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    bytes_0 = b'\xde\xafu^\x1c\x10'
    linux_network_0 = LinuxNetwork(bytes_0, bytes_0)
    var_1 = linux_network_0.get_interfaces_info(bytes_0, bytes_0, bytes_0)
    return var_1


# Generated at 2022-06-24 23:10:35.008303
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # class LinuxNetwork(object):

    # def get_interfaces_info(data, bytes_0, bytes_1, bytes_2):
    pass
