

# Generated at 2022-06-24 23:01:13.198683
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    bytes_0 = None
    str_0 = 'sendv'
    linux_network_0 = LinuxNetwork(bytes_0, str_0)
    # We may need to set self.module.get_bin_path("ethtool")
    device = 'lo'
    result = linux_network_0.get_ethtool_data(device)
    assert result


# Generated at 2022-06-24 23:01:18.779003
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    bytes_0 = None
    str_0 = 'sendv'
    linux_network_0 = LinuxNetwork(bytes_0, str_0)
    # AssertionError: TypeError: populate() takes exactly 2 arguments (1 given)
    linux_network_0.populate(str_0)

if __name__ == '__main__':
    test_case_0()
    test_LinuxNetwork_populate()

# Generated at 2022-06-24 23:01:24.613992
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    bytes_0 = None
    str_0 = 'sendv'
    linux_network_0 = LinuxNetwork(bytes_0, str_0)

    str_1 = 'tearyrain'
    dict_0 = linux_network_0.get_ethtool_data(str_1)
    print(dict_0)

if __name__ == '__main__':
    test_case_0()
    test_LinuxNetwork_get_ethtool_data()

# Generated at 2022-06-24 23:01:28.146604
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    bytes_0 = None
    str_0 = 'sendv'
    linux_network_0 = LinuxNetwork(bytes_0, str_0)
    module_0 = ModuleStub()
    linux_network_0.module = module_0
    linux_network_0.populate()


# Generated at 2022-06-24 23:01:32.884652
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    bytes_0 = None
    str_0 = 'sendv'
    linux_network_0 = LinuxNetwork(bytes_0, str_0)

    str_1 = 'test_device'
    data = linux_network_0.get_ethtool_data(str_1)
    assert data == {}



# Generated at 2022-06-24 23:01:37.697249
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    bytes_0 = None
    str_0 = 'ipv4'
    linux_network_0 = LinuxNetwork(bytes_0, str_0)
    linux_network_0.populate()


# Generated at 2022-06-24 23:01:43.442024
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    bytes_0 = None
    str_0 = 'sendv'
    linux_network_0 = LinuxNetwork(bytes_0, str_0)
    str_0 = 'return'
    # CAUTION: directly testing a private method
    linux_network_0._LinuxNetwork__get_ethtool_data(str_0)


# Generated at 2022-06-24 23:01:52.135778
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    bytes_str_0 = None
    str_str_0 = 'sendv'
    linux_network_collector_0 = None
    linux_network_collector_0 = LinuxNetworkCollector(bytes_str_0, str_str_0)

    linux_network_collector_0 = None
    linux_network_collector_0 = LinuxNetworkCollector(bytes_str_0, str_str_0)


# Generated at 2022-06-24 23:01:56.004346
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    bytes_0 = None
    str_0 = '^z?'
    linux_network_0 = LinuxNetwork(bytes_0, str_0)
    str_1 = '8'
    dict_0 = linux_network_0.get_ethtool_data(str_1)



# Generated at 2022-06-24 23:01:58.214334
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    bytes_0 = b''
    str_0 = 'sendv'
    linux_network_0 = LinuxNetwork(bytes_0, str_0)

    str_1 = 'spat'
    str_2 = 'kis_0'
    linux_network_0.get_ethtool_data(str_1, str_2)



# Generated at 2022-06-24 23:02:34.939752
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_collector_obj = LinuxNetworkCollector()
    #
    # Test with valid ip_path
    #
    ip_path = "/sbin/ip"
    default_ipv4 = {'address': '10.10.10.10'}
    default_ipv6 = {'address': 'fe80::204:61ff:fe9d:f156'}
    ansible_facts_dict, ansible_default_ipv4, ansible_default_ipv6, ansible_all_ipv4_addresses, ansible_all_ipv6_addresses, ansible_default_interface = linux_network_collector_obj.populate(ip_path, default_ipv4, default_ipv6)
    assert ansible_facts_dict != None
    assert ansible_facts_dict

# Generated at 2022-06-24 23:02:42.363244
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Randomize MAC values, to avoid conflicts between test runs,
    # because even if we remove a veth pair, it seems that the MAC
    # remains the same.
    mac0 = "00:11:22:33:44:%02x" % random.randint(0, 255)
    mac1 = "00:11:22:33:44:%02x" % random.randint(0, 255)

    ip0 = "192.168.77.%d" % random.randint(2, 254)
    ip1 = "192.168.77.%d" % random.randint(2, 254)

    ip6link0 = "2001:db8:1234:%02x::2" % random.randint(2, 254)

# Generated at 2022-06-24 23:02:54.195621
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_collector = LinuxNetworkCollector()
    # Test inputs: device: str
    device = "ens34"

    # Test execution:
    # The method get_ethtool_data() will execute the command "ethtool -k ens34". If
    # the command succeeds, it should return a dictionary as a result of the test.
    # Otherwise, it should return None.
    result = linux_network_collector.get_ethtool_data(device)
    # Test assertions:
    assert isinstance(result, dict)
    assert 'features' in result
    assert type(result['features']) == dict

# Generated at 2022-06-24 23:02:59.352925
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_collector_0 = LinuxNetworkCollector()
    args = {
        "ip_path": None,
        "config": None,
    }
    linux_network_collector_0.populate(**args)


# Generated at 2022-06-24 23:03:04.877524
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = get_test_module()
    # assign args
    args = {'gather_subset':['min','!config'], 'gather_network_resources':['all'], 'filter':[]}
    # instantiate class
    linux_network_0 = LinuxNetwork(module, args)
    rc = linux_network_0.populate()
    print(json.dumps(linux_network_0.facts, indent=2))
    print("Success") if rc == 0 else "Failure", "with rc = %d" % rc


# Generated at 2022-06-24 23:03:14.086760
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # @TODO: Make this work with more than one
    #    interface as well as introduce interfaces
    #    with IP addresses and then rewrite the
    #    tests below
    ln = LinuxNetwork(module=None)
    ln.populate()

    assert ln.default_ipv4['address'] == '192.168.122.1'
    assert ln.default_ipv4['netmask'] == '255.255.255.0'
    assert ln.default_ipv4['network'] == '192.168.122.0'
    assert ln.default_interface['ipv4']['interface'] == 'virbr0'
    assert ln.default_interface['ipv4']['address'] == '192.168.122.1'

# Generated at 2022-06-24 23:03:19.640935
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # FIXME: add tests
    pass


# Generated at 2022-06-24 23:03:25.537451
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # FIXME: add a test case using a real OS install or container.
    LinuxNetworkClass_0 = LinuxNetworkBase()
    linux_network_collector_0 = LinuxNetworkCollector()
    LinuxNetworkClass_0.populate(linux_network_collector_0)


# Generated at 2022-06-24 23:03:30.000053
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_collector_0 = LinuxNetworkCollector()
    linux_network_object_0 = LinuxNetwork(module=MagicMock(check_mode=False))
    linux_network_object_0.populate(linux_network_collector_0)

if __name__ == '__main__':
    test_case_0()
    test_LinuxNetwork_populate()

# Generated at 2022-06-24 23:03:33.024221
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network_collector_1 = LinuxNetworkCollector()
    linux_network_collector_1.get_default_interfaces()


# Generated at 2022-06-24 23:04:08.834307
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    int_0 = -1
    linux_network_0 = LinuxNetwork(int_0)
    linux_network_0.populate()
    var_0 = linux_network_0.get_default_interfaces()
    assert var_0 == {'ipv4': {'address': '192.168.122.1', 'broadcast': '192.168.122.255', 'netmask': '255.255.255.0', 'network': '192.168.122.0'}, 'ipv6': {'address': 'fe80::5054:ff:fe12:3456', 'prefix': '64', 'scope': 'link'}}


# Generated at 2022-06-24 23:04:20.268114
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    int_0 = -124
    linux_network_0 = LinuxNetwork(int_0)
    str_0 = '\'|'
    dict_0 = {}
    dict_0['source'] = 'ansible'
    dict_0['delimiter'] = str_0
    dict_0['data'] = linux_network_0
    dict_0['source_format'] = 'dict'
    dict_0['dest_format'] = 'json'
    dict_0['fail_on_undefined'] = False
    dict_0['unsafe'] = True
    dict_0['fail_on_error'] = True

# Generated at 2022-06-24 23:04:22.582849
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_0 = LinuxNetwork(None)
    linux_network_0.get_ethtool_data('pci_device_0')


# Generated at 2022-06-24 23:04:27.785322
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_1 = LinuxNetwork()
    var_0 = linux_network_1.populate()

# Generated at 2022-06-24 23:04:38.594193
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    print("Testing LinuxNetwork.populate")
    int_0 = -156
    linux_network_0 = LinuxNetwork(int_0)
    var_0 = linux_network_0.populate()
    var_2 = False
    var_3 = None
    if 'default_ipv4' in var_0.get('interfaces'):
        var_6 = var_0['interfaces'].get('default_ipv4')
        var_7 = var_6.get('address')
        var_8 = var_7 != None
        var_3 = var_8
    if var_3 == None:
        var_3 = False
    if var_3:
        var_2 = True
    else:
        var_2 = False
    assert var_2 == True


# Generated at 2022-06-24 23:04:43.164432
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    int_0 = -1
    linux_network_0 = LinuxNetwork(int_0)
    result = linux_network_0.get_interfaces_info(None, None, None)
    assert len(result) == 2 and result[0] and result[1]


# Generated at 2022-06-24 23:04:44.273110
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network_0 = LinuxNetwork()
    linux_network_0.get_ethtool_data()


# Generated at 2022-06-24 23:04:49.175747
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    int_0 = -156
    linux_network_0 = LinuxNetwork(int_0)
    var_0 = linux_network_0.populate()
    var_1 = {'address': '192.168.2.2', 'netmask': '255.255.255.0', 'broadcast': '192.168.2.255', 'network': '192.168.2.0'}
    var_2 = {'address': 'fe80::20c:29ff:fe40:22b', 'prefix': '64', 'scope': 'link'}
    var_3 = linux_network_0.get_interfaces_info(var_0, var_1, var_2)


# Generated at 2022-06-24 23:04:51.606936
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    int_0 = -156
    linux_network_0 = LinuxNetwork(int_0)
    var_0 = linux_network_0.get_ethtool_data(int_0)


# Generated at 2022-06-24 23:04:55.313212
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    int_0 = -156
    linux_network_0 = LinuxNetwork(int_0)
    linux_network_0.populate()
    str_0 = "eth0"
    dict_1 = linux_network_0.get_ethtool_data(str_0)


# Generated at 2022-06-24 23:06:10.931761
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    rc = 0
    if rc != 0:
        print("Constructor of class LinuxNetworkCollector is not working properly.")
    else:
        print("Constructor of class LinuxNetworkCollector is working properly.")


# Generated at 2022-06-24 23:06:15.427831
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    int_0 = -156
    linux_network_0 = LinuxNetwork(int_0)
    var_0 = linux_network_0.populate()
    int_1 = 0
    int_2 = 0
    var_1 = linux_network_0.route_exists(int_1, int_2)


# Generated at 2022-06-24 23:06:22.847026
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    int_0 = -156
    linux_network_0 = LinuxNetwork(int_0)
    var_0 = linux_network_0.populate()

    linux_network_2 = LinuxNetwork(int_0, var_0)
    var_1 = linux_network_2.get_ethtool_data('eth0')
    linux_network_2.module.assertNotEqual(len(var_1), 0)
    linux_network_2.module.assertIn('features', var_1)
    linux_network_2.module.assertIn('timestamping', var_1)
    linux_network_2.module.assertIn('hw_timestamp_filters', var_1)
    linux_network_2.module.assertIn('phc_index', var_1)


# Generated at 2022-06-24 23:06:28.026355
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    int_0 = -155
    linux_network_0 = LinuxNetwork(int_0)
    assert linux_network_0.get_default_interfaces()


# Generated at 2022-06-24 23:06:38.997040
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    int_0 = 0
    linux_network_0 = LinuxNetwork(int_0)
    linux_network_0.MODULE_RETURN_VALUES = {'ls': 'ls', 'ethtool': 'ethtool'}
    device_0 = "device_0"
    assert("features" in linux_network_0.get_ethtool_data(device_0))
    assert("timestamping" in linux_network_0.get_ethtool_data(device_0))
    assert("hw_timestamp_filters" in linux_network_0.get_ethtool_data(device_0))
    assert("phc_index" in linux_network_0.get_ethtool_data(device_0))


# Generated at 2022-06-24 23:06:40.286759
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    assert True


# Generated at 2022-06-24 23:06:50.048151
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Test with no args
    int_0 = -109
    linux_network_0 = LinuxNetwork(int_0)
    device_0 = "6;Ox)i;eU6&:k=S(F"
    linux_network_0._LinuxNetwork__get_ethtool_data(device_0)
    # expected {'features': {'rx-vlan-offload': 'on', 'tx-vlan-offload': 'on', 'tx-checksumming': 'on', 'tx-gso-robust': 'off', 'rx-checksumming': 'on', 'rx-hash': 'on', 'generic-segmentation-offload': 'off', 'tx-generic-segmentation': 'off', 'tx-generic-segmentation-offload': 'off', 'tx-udp_tnl-segment

# Generated at 2022-06-24 23:06:54.272578
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network = LinuxNetwork(0)
    pass


# Generated at 2022-06-24 23:06:57.490093
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    int_0 = 0
    linux_network_0 = LinuxNetwork(int_0)
    str_0 = 'eth0'
    linux_network_0.get_ethtool_data(str_0)


# Generated at 2022-06-24 23:07:00.285804
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_0 = LinuxNetwork(0)
    linux_network_0.populate()
    assert 0 == linux_network_0.default['ipv4']['address']
    assert 0 == linux_network_0.default['ipv6']['address']
    

# Generated at 2022-06-24 23:08:17.091539
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    try:
        test_case_0()
    except:
        print("FAILED while executing test_case_0")
        raise

if __name__ == "__main__":
    test_LinuxNetwork_populate()

# Generated at 2022-06-24 23:08:23.787765
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    int_0 = -156
    linux_network_0 = LinuxNetwork(int_0)
    var_0 = linux_network_0.populate()
    var_1 = linux_network_0.dict
    var_2 = linux_network_0.default_ipv4
    var_3 = linux_network_0.default_ipv6


# Generated at 2022-06-24 23:08:29.371345
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    int_0 = -17
    linux_network_0 = LinuxNetwork(int_0)
    linux_network_0.populate()
    var_0 = linux_network_0.gateways
    var_1 = linux_network_0.default_ipv4
    var_2 = linux_network_0.default_ipv6
    var_3 = linux_network_0.interfaces
    var_4 = linux_network_0.ips
    var_5 = linux_network_0.gateways


# Generated at 2022-06-24 23:08:37.336474
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    linux_network_0 = LinuxNetwork()
    # Tests run in a container, where IPv6 routes are not available
    linux_network_0.module.get_bin_path = lambda *args, **kwargs: '/bin/ip'

    try:
        linux_network_0.get_default_interfaces()
    except Exception as var_0:
        # FIXME: stderr is always going to be the same between tests
        raise AssertionError('Caught exception {0}'.format(str(var_0)))



# Generated at 2022-06-24 23:08:39.153268
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    # Test case 0
    test_case_0()



# Generated at 2022-06-24 23:08:42.982539
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    int_0 = -21
    linux_network_0 = LinuxNetwork(int_0)
    var_0 = linux_network_0.populate()


# Generated at 2022-06-24 23:08:45.986860
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    case_0()
    case_1()
    case_2()
    case_3()
    case_4()

# Integration test for method populate of class LinuxNetwork

# Generated at 2022-06-24 23:08:53.259370
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # global linux_network_1
    if not linux_network_1:
        linux_network_1 = LinuxNetwork(module)

    # global dict_0
    # dict_0 = linux_network_1.get_interfaces_info()

    # global linux_network_2
    linux_network_2 = LinuxNetwork(module)

    # global dict_1
    # dict_1 = linux_network_2.get_interfaces_info()

# Generated at 2022-06-24 23:08:58.860957
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    print("\n>>>>>> Testing LinuxNetwork.get_default_interfaces()")
    linux_network_0 = LinuxNetwork()
    var_0 = linux_network_0.get_default_interfaces()
    print("var_0 = {}".format(var_0))


# Generated at 2022-06-24 23:09:04.295037
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    int_0 = 2
    linux_network_0 = LinuxNetwork(int_0)
    LinuxNetwork.get_ethtool_data(linux_network_0)

if __name__ == '__main__':
    # test_LinuxNetwork_get_ethtool_data():
    test_case_0()

# End of LinuxNetwork.py

# Generated at 2022-06-24 23:10:34.703338
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Prepare
    int_0 = -156
    linux_network_0 = LinuxNetwork(int_0)

    # Get interfaces
    (interfaces, ips) = linux_network_0.get_interfaces_info(None, None, None)

    # Check interface count
    if len(interfaces) < 1:
        raise AssertionError("There should be at least one interface")

    # Check interfaces presence
    if not "lo" in interfaces:
        raise AssertionError("Loopback interface should be present")


# Generated at 2022-06-24 23:10:38.507669
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    test_var_0 = 'eth0'
    int_0 = -129
    linux_network_0 = LinuxNetwork(int_0)
    linux_network_0.get_ethtool_data(test_var_0)

# Generated at 2022-06-24 23:10:45.737598
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    int_0 = -156
    linux_network_0 = LinuxNetwork(int_0)
    ip_path_0 = 'ip'
    default_ipv4_0 = {'address': '127.0.0.1', 'broadcast': '0.0.0.0', 'netmask': '255.0.0.0', 'network': '127.0.0.0'}
    default_ipv6_0 = {'address': '0000:0000:0000:0000:0000:0000:0000:0001', 'prefix': '128', 'scope': 'host'}
    linux_network_0.get_interfaces_info(ip_path_0, default_ipv4_0, default_ipv6_0)
    interfaces_0, ips_0 = linux_network_0.get_interfaces_info