

# Generated at 2022-06-11 03:36:14.527878
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.linux.linux import LinuxNetwork
    module = MagicMock()
    network = LinuxNetwork(module)
    network.get_interfaces_info = MagicMock()
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    network.get_interfaces_info.return_value = (dict(), ips)
    network.get_default_interfaces()
    return network.get_interfaces_info.call_count == 1

# Generated at 2022-06-11 03:36:20.330514
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """Unit test for constructor of class LinuxNetworkCollector"""
    # Test 1
    module = AnsibleModuleMock()
    network_collector = LinuxNetworkCollector(module=module)
    # Test 2
    module.run_command.return_value = (0, 'dummy output', '')
    network_collector = LinuxNetworkCollector(module=module)


# Generated at 2022-06-11 03:36:27.953218
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """
    Constructed a new object to test that no exceptions
    occur when creating the object
    """
    # pylint: disable=protected-access

    # note: the unit test is not run in a specific platform,
    # so we need to provide os_platform to match what is
    # actually running
    module = Mock()
    module.params = {}
    module._ansible_facts = dict(distribution='SuSE',
                                 platform='Linux')
    module.get_bin_path.return_value = "/usr/sbin/ip"
    module.run_command.return_value = 0, "", "error"
    module.os_platform = 'Linux'
    # constructor creates the object here
    network_collector = LinuxNetworkCollector()
    # check that the object was created successfully

# Generated at 2022-06-11 03:36:39.790043
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    device = 'eth0'
    module = AnsibleModule((dict(
        name='eth0',
        type='ethernet',
        state='up',
        ipv4=dict(address='192.168.0.1', netmask='255.255.255.0', broadcast='192.168.0.255'),
        ipv6=dict(address='2001:db8::1', netmask='32', scope='link'),
        macaddress='aa:bb:cc:dd:ee:ff',
    )))
    if platform.system() == 'Linux':
        network = LinuxNetwork(module)
        data = network.get_ethtool_data(device)
        assert data['features']['tx'], 'linux kernel has tx offload support'

# Generated at 2022-06-11 03:36:47.264806
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # ensure populating an invalid interface name fails
    ln = LinuxNetwork()
    module_args = {"interface": "foo"}
    with pytest.raises(SystemExit):
        ln.populate(module_args)
    # ensure populating an invalid address family fails
    module_args = {"interface": "lo", "address_family": "bar"}
    with pytest.raises(SystemExit):
        ln.populate(module_args)



# Generated at 2022-06-11 03:36:57.742845
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    ClassUnderTest = LinuxNetwork
    class_attributes = [a for a in dir(ClassUnderTest) if not a.startswith('_')]
    # FIXME: this is not the most efficient method of doing this
    instance = ClassUnderTest(None, None)

    # This list of dunder/magic attributes has been somewhat arbitrarily chosen

# Generated at 2022-06-11 03:37:07.415317
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Import AnsibleModule and LinuxNetwork.
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils._text import to_text
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.basic import AnsibleModule
    try:
        # FIXME: things break the first time this is imported if the collection is not installed
        # https://github.com/ansible-collections/notstdlib/issues/65
        from ansible_collections.notstdlib.moveitallout.plugins.module_utils.network.common.network import LinuxNetwork
    except ImportError:
        module = AnsibleModule(argument_spec={'_ansible_discard_warnings': dict()})

# Generated at 2022-06-11 03:37:19.665915
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    # Test 1 - Test using a sample input of eth0
    device = 'eth0'

# Generated at 2022-06-11 03:37:25.028899
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    # FIXME: do we have a good way to test this in unit tests?
    # is a function object good enough?
    def fake_module(*args, **kwargs):
        return FakeModule()
    ln = LinuxNetwork(fake_module)
    ln.get_interfaces_info(None, {}, {})
    assert ln



# Generated at 2022-06-11 03:37:32.874965
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, "Foobar", ""))
    linux_network = LinuxNetwork(module)

# Generated at 2022-06-11 03:38:01.175930
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    my_obj = LinuxNetwork()
    with pytest.raises(NotImplementedError):
        my_obj.get_default_interfaces()

# Generated at 2022-06-11 03:38:11.096191
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    '''
    Unit test for method get_default_interfaces of class LinuxNetwork

    WARNING:
    This method uses side effects. It modifies the module arguments
    passed to it.
    Make sure that all unit tests use different module args
    objects.
    If mock_uname is used make sure that it is reset for each test.
    '''

    # Setup
    module = Mock(
        **{
            'params': {},
            'run_command.return_value': (0, '', '')
        }
    )
    check_args = {
        'module': module,
    }

    # Test
    try:
        linux_network = LinuxNetwork(**check_args)
    except Exception:
        raise AssertionError('Unable to instantiate LinuxNetwork object.')
    # The method modifies its module argument

# Generated at 2022-06-11 03:38:19.583533
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    """Returns the name of the default interface for IPv4 and IPv6.
    """
    # Some test data

# Generated at 2022-06-11 03:38:27.224684
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """
    Constructor of class LinuxNetworkCollector
    """
    module = AnsibleModuleMock()
    module.params = {}

    platform_name = 'Linux'
    distribution_name = 'Linux'

    facts = dict(distribution=distribution_name,
                 platform=platform_name)

    lnc = LinuxNetworkCollector(module)

    assert lnc.required_facts == set(['distribution', 'platform'])

    assert lnc.platform == platform_name
    assert lnc.distribution == distribution_name


# Generated at 2022-06-11 03:38:37.728886
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():

    class MockModule():

        def __init__(self):
            self.params = {}

        def fail_json(self, **kwargs):
            exit(1)

        def get_bin_path(self, value, opt_dirs=[]):
            return '/usr/bin/ethtool'

        def run_command(self, value, **kwargs):
            stdout = "Features for eth0:\nrx-checksumming: on\nscatter-gather: on"
            return 0, stdout, ''

    # Test with a valid test case
    module = MockModule()
    linux_network = LinuxNetwork(module)
    features = linux_network.get_ethtool_data('eth0').get('features')

    assert features.get('rx_checksumming') == 'on'

# Generated at 2022-06-11 03:38:40.838797
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    get_default_interfaces_instance = LinuxNetwork()
    assert callable(get_default_interfaces_instance.get_default_interfaces)
    # Exercise the code inside get_default_interfaces()

# Generated at 2022-06-11 03:38:46.871101
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, 'dummy', ''))
    module.get_bin_path = MagicMock(return_value='')
    linux_network = LinuxNetwork(module)

    interfaces, ips = linux_network.get_interfaces_info('', {}, {})
    assert interfaces
    assert ips

# Generated at 2022-06-11 03:38:57.883136
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    required_facts = set(['distribution', 'platform'])

    facts = {'distribution': 'Linux', 'platform': 'Linux'}
    assert isinstance(LinuxNetworkCollector(facts), NetworkCollector) is True
    facts = {'distribution': 'Linux', 'platform': 'Linux', 'network_resources': 'False'}
    assert isinstance(LinuxNetworkCollector(facts), NetworkCollector) is True
    facts = {'distribution': 'BSD', 'platform': 'BSD'}
    assert isinstance(LinuxNetworkCollector(facts), NetworkCollector) is False
    facts = {'distribution': 'Linux', 'platform': 'BSD'}
    assert isinstance(LinuxNetworkCollector(facts), NetworkCollector) is False
    facts = {'distribution': 'Linux'}

# Generated at 2022-06-11 03:39:09.489133
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # NOTE: This is a fake module instance used during testing.
    module = ansible_collections.ansible.os_migrated.plugins.module_utils.network.common.module()

    linux_network = LinuxNetwork(module)

    def get_file_content(path, default=None):
        # Simulate the contents of file /sys/class/net/<device>/address
        if '/address' in path:
            content = {
                'lo': '00:00:00:00:00:00',
                'wlan0': '12:34:56:78:9a:bc',
                'eth0': 'de:ad:be:ef:00:01',
            }
            return content.get(path.split('/')[-2], default)
        # Simulate the contents of file /sys/class/

# Generated at 2022-06-11 03:39:15.127382
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    ln = LinuxNetwork()
    ln.module = MagicMock()
    ln.module.get_bin_path.return_value = '/bin/ethtool'

# Generated at 2022-06-11 03:39:49.286967
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # This just tests whether the method exits or not
    # TODO: test the logic in this method more thoroughly
    m = AnsibleModuleMock()
    n = LinuxNetwork(m)
    n.populate(m.params)



# Generated at 2022-06-11 03:39:50.309430
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    pass



# Generated at 2022-06-11 03:39:53.453711
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # FIXME: write some unit tests for LinuxNetwork.get_default_interfaces
    # TODO: use assertEquals
    # TODO: use assertNotEquals
    raise NotImplementedError()


# Generated at 2022-06-11 03:40:02.943235
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {'state': 'present',
                     'name': 'test',
                     'value': 'test'}

    network = LinuxNetwork(module)
    # have_ip is a dict
    have_ip, all_ipv4_addresses, all_ipv6_addresses = network.get_interfaces_info()
    interfaces = {}
    localhost = {}

# Generated at 2022-06-11 03:40:10.512135
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    """
    linux_network_test.LinuxNetwork.populate test
    """
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    network = LinuxNetwork(module)
    network.populate()
    assert {'ansible_facts': {'ansible_all_ipv4_addresses': [], 'ansible_all_ipv6_addresses': [], 'ansible_interfaces': {}, 'ansible_default_ipv4': {}, 'ansible_default_ipv6': {}}} == network.get_ansible_results()


# Generated at 2022-06-11 03:40:15.275128
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    m = AnsibleModule(argument_spec=dict(), supports_check_mode=False)
    n = LinuxNetwork(m)
    device = 'ens224'
    e = n.get_ethtool_data(device)
    assert e
    assert 'phc_index' in e
    assert e['phc_index'] == 0


# Generated at 2022-06-11 03:40:26.489159
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    # Create a module object to work with
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json

    # Create a LinuxNetwork object and set all values
    x = LinuxNetwork()

    # Set module to our created object
    x.module = module

    # Create a module object to work with
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json

    # Create a LinuxNetwork object and set all values
    x = LinuxNetwork()

    # Set module to our created object
    x.module = module

    # Create a module object to work with
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_

# Generated at 2022-06-11 03:40:36.426632
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-11 03:40:48.284176
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # FIXME: This depends on the host having an 'eth0' interface and a python3
    # interpreter available. Probably a better way to mock up the module and
    # nohup a python2 script on stdin?
    sys.stderr.write('Testing method get_interfaces_info ... ')
    sys.stderr.flush()
    tmp_obj = LinuxNetwork()
    tmp_args = {'module': get_mock_module(), 'ip_path': '/usr/bin/ip', 'default_ipv4': {}, 'default_ipv6': {}}
    tmp_args['default_ipv4']['address'] = '192.168.1.1'
    tmp_args['default_ipv6']['address'] = '::1'
    tmp_interfaces, tmp_ips = tmp_obj

# Generated at 2022-06-11 03:40:52.357766
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule({})
    linux_network = LinuxNetwork(module=module, params={})

    # TODO: un-skip test
    module.exit_json(changed=False, skipped=True)

    # TODO: write test



# Generated at 2022-06-11 03:41:25.615201
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network = LinuxNetwork()
    assert linux_network.get_default_interfaces() == ({}, {})
    # Add more unit test here if necessary


# Generated at 2022-06-11 03:41:33.193963
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    l = LinuxNetwork(module)

    def get_ethtool_data(data):
        ethtool_path = l.module.get_bin_path("ethtool")
        if not ethtool_path:
            return {}

        class MockPopen:
            def __init__(self, data):
                self.data = data

            def communicate(self):
                return (self.data, None)

        class MockPopenError(MockPopen):
            def communicate(self):
                return (b'', b'Some Error text')

        with patch('ansible.module_utils.basic.AnsibleModule.run_command', return_value=(0, MockPopen(data), None)):
            return l.get_ethtool_data('eth0')

    assert get_

# Generated at 2022-06-11 03:41:43.478306
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from ansible.module_utils.basic import AnsibleModule
    # Test setup
    # Test input - no arguments
    module_args = dict()
    # Test args
    module_args.update(dict())
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )
    # Test function declaration
    network = LinuxNetwork(module)
    # Test function input
    device = "eth1"
    # Test function output
    result = network.get_ethtool_data(device)
    # Assertions
    assert isinstance(result, dict)
    assert 'features' in result
    assert isinstance(result['features'], dict)
    assert 'timestamping' in result
    assert isinstance(result['timestamping'], list)

# Generated at 2022-06-11 03:41:45.986483
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    instance = LinuxNetwork()

# Generated at 2022-06-11 03:41:53.997921
# Unit test for method get_default_interfaces of class LinuxNetwork

# Generated at 2022-06-11 03:42:01.209803
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from units.compat import unittest
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    test_module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    test_module.exit_json = lambda x: None
    test_module.params = {}

    test_Network = LinuxNetwork(test_module)
    test_Network._load_config = lambda: None
    test_Network.interfaces = []
    test_Network.default_ipv4 = {}
    test_Network.default_ipv6 = {}
    test_Network.default_interface = {}

    test_Network.populate()


# Generated at 2022-06-11 03:42:03.388912
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: Mock module, etc.
    ln = LinuxNetwork()
    ln.get_interfaces_info()

    raise Exception('unimplemented')



# Generated at 2022-06-11 03:42:13.454942
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
        network_module = LinuxNetwork()
        device = "eth0"
        network_module.module = {
            "run_command": MagicMock(return_value=(0, "", ""))
        }
        match = {
            "ethtool -k": [
                "cmd='ethtool -k', rc=0, out='""'",
                "cmd='ethtool -k', rc=0, out='""'",
                "cmd='ethtool -k', rc=0, out='""'"
            ],
            "ethtool -T": [
                "cmd='ethtool -T', rc=0, out='""'",
                "cmd='ethtool -T', rc=0, out='""'",
                "cmd='ethtool -T', rc=0, out='""'"
            ]
        }

# Generated at 2022-06-11 03:42:22.464416
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # module.params['ANSIBLE_DEBUG'] = True
    mock_module = type('module', (object, ), {
        'params': {
            'debug': False,
        },
        'run_command': MagicMock(return_value=(0, '', '')),
        'get_bin_path': MagicMock(return_value='/bin/ethtool'),
    })
    obj = LinuxNetwork(mock_module)
    # mock_module.get_bin_path.return_value = '/bin/ethtool'
    # mock_module.run_command.return_value = (0, '', '')
    # module.run_command = MagicMock(return_value=(0, '', ''))


# Generated at 2022-06-11 03:42:29.661540
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible.module_utils.common.collections import ImmutableDict
    # Test get_interfaces_info
    network = LinuxNetwork(ImmutableDict(module=dict(params=dict())))
    ip_path = ''  # TODO: set me
    default_ipv4=dict(address='192.0.2.1')
    default_ipv6=dict(address='2001:db8::1')
    interfaces, ips = network.get_interfaces_info(ip_path, default_ipv4, default_ipv6)
    assert interfaces

# Generated at 2022-06-11 03:43:16.036101
# Unit test for method get_default_interfaces of class LinuxNetwork

# Generated at 2022-06-11 03:43:25.886861
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """Test the method get_ethtool_data() of class LinuxNetwork"""
    _module = AnsibleModule(argument_spec={})
    # test fixture
    linux_network = LinuxNetwork(_module=_module)

    linux_network.module.run_command = Mock(return_value=(0, 'a: b\nc: d\n', ''))

    data = linux_network.get_ethtool_data(device='eth0')
    assert data == {
        'features': {
            'a': 'b',
            'c': 'd',
        },
    }

    linux_network.module.run_command = Mock(return_value=(0, 'a: b\nc: \n', ''))

    data = linux_network.get_ethtool_data(device='eth0')

# Generated at 2022-06-11 03:43:33.850442
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: "/sbin/ethtool"
    module.run_command = [lambda x, errors="surrogate_then_replace":
                          (0, b"Features for lo:\nbusy-poll off\n\nFeatures for eth1:\ntx-scatter-gather on\n", b"")]

    ln = LinuxNetwork(module)
    result = ln.get_ethtool_data("eth1")
    assert isinstance(result, dict)
    assert result == {
        "features": {
            "busy_poll": "off",
            "tx_scatter_gather": "on",
        }
    }

# Generated at 2022-06-11 03:43:41.164192
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(argument_spec=dict())

# Generated at 2022-06-11 03:43:51.159884
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector(): # pylint: disable=R0915
    """
    Unit test for constructor of class LinuxNetworkCollector
    """
    mock_module = Mock(LinuxNetworkCollector)
    mock_module.params = {}
    mock_module.run_command.return_value = 0, '', ''
    # Mock the various files we read so that they don't need to exist
    files = list(LinuxNetwork.REQUIRED_FILES)
    files.extend(('/proc/filesystems', '/proc/net/fib_trie'))
    mock_module.get_bin_path.return_value = '/sbin/ip'
    mock_open_mock = mock_open()
    get_file_content_mock = Mock(return_value='1\n')

# Generated at 2022-06-11 03:43:52.076512
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # FIXME
    assert False



# Generated at 2022-06-11 03:44:00.099736
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    device = 'eth0'
    m = LinuxNetwork()
    result = m.get_ethtool_data(device)

    assert result['features']['rx_all'] == 'off'
    assert result['features']['tx_udp_tnl_csum_segmentation'] == 'off'
    assert result['features']['rx_udp_tnl_csum_segmentation'] == 'off'
    assert result['timestamping'] == ['hardware', 'software']
    assert result['hw_timestamp_filters'] == ['none']
    assert result['phc_index'] == -1

# Generated at 2022-06-11 03:44:09.749786
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    network.populate()
    assert module.params['interfaces'] != {}
    assert module.params['default_ipv4'] != {}
    assert module.params['default_ipv6'] != {}
    assert module.params['default_interface_ipv4'] != {}
    assert module.params['default_interface_ipv6'] != {}
    assert module.params['ips'] != {}
    if os.path.exists('/sys/class/net/lo/flags'):
        assert module.params['interfaces']['lo']['active'] == True
    # are the interface names present?
    for i in module.params['interfaces']:
        assert module.params['interfaces'][i]['device'] == i



# Generated at 2022-06-11 03:44:20.124907
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    net = LinuxNetwork()
    module = FakeModule()
    ip_path = '/sbin/ip'
    default_ipv4 = dict()
    default_ipv6 = dict()
    interfaces = net.get_interfaces_info(ip_path, default_ipv4, default_ipv6)
    assert len(interfaces) == 1
    assert interfaces[0]["ens3"]["ipv4"]["address"] == '10.0.2.15'
    assert interfaces[0]["ens3"]["ipv4"]["broadcast"] == '10.0.2.255'
    assert interfaces[0]["ens3"]["ipv4"]["netmask"] == '255.255.255.0'

# Generated at 2022-06-11 03:44:30.052139
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    for ip_path in ('/sbin/ip', '/bin/ip'):
        module = AnsibleModule({
            'gather_subset': ['all'],
        })
        net = LinuxNetwork(module)
        net.ip_path = ip_path

        result = net.populate()
        assert result['gather_subset'] == ['all']
        assert result['gather_timeout'] == 10
        assert result['ipv4']
        assert result['ipv6']
        assert result['interfaces']
        assert result['default_ipv4']
        assert result['default_ipv6']

        if ip_path in ('/sbin/ip', '/bin/ip'):
            assert result['default_interface_ipv4'] == result['ipv4'][0]['interface']