

# Generated at 2022-06-11 03:36:17.936797
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():

    params = dict(
        module=dict(return_value=dict(
            run_command=dict(return_value=(0, "", ""))))
    )
    # FakedModule has been set in the test_module_utils.py file
    m = FakedModule(params=params, check_invalid_arguments=False)
    ln = LinuxNetwork(module=m)
    assert ln.get_ethtool_data("eth0") == {}
    assert m.run_command.call_count == 2


# Generated at 2022-06-11 03:36:25.555889
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # NOTE: these are not proper unit tests, maybe they should use
    #       the unittest module

    # validate that populate() adds correct keys
    # TODO: add tests for actual contents of the keys
    m = AnsibleModule({})
    ln = LinuxNetwork(m)
    ln.populate()

    for key in ['interfaces', 'default_interface', 'default_ipv4', 'default_ipv6', 'gateway_ipv4', 'gateway_ipv6', 'all_ipv4_addresses', 'all_ipv6_addresses']:
        assert key in ln.data, "populate() failed to add key '{}' to data".format(key)



# Generated at 2022-06-11 03:36:36.718429
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    """Test case for the LinuxNetwork.populate method.

    Expected results:
    - The populate method returns a dictionary containing the right information
      in the right format.

    """
    # Test data to be passed to the object's populate method

# Generated at 2022-06-11 03:36:48.615079
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    network = LinuxNetwork()
    # TODO: mock out network.get_interfaces_info so we don't have to fake input
    network.default_ipv4, network.default_ipv6, = {}, {}

# Generated at 2022-06-11 03:36:58.635441
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(
            routes=dict(type='dict', default={}),
            default_interface=dict(type='dict', default={}),
        ),
    )
    module.params['routes'] = {"4":{"gateway":"192.168.1.1","network":"192.168.1.0","netmask":"255.255.255.0","interface":"ens33"},"6":{"gateway":"::","network":"::","netmask":"ffff:ffff:ffff:ffff::","interface":"ens33"}}
    module.params['default_interface'] = {"4":{"address":"192.168.1.113"}}
    linux_network = LinuxNetwork(module)
    linux_network.get_default_interfaces()

# Generated at 2022-06-11 03:37:08.854545
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    module_mock = ansible_module_mock
    ln = LinuxNetwork(module_mock)

# Generated at 2022-06-11 03:37:21.017433
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=["!all", "!min"]),
        ),
        supports_check_mode=True,
    )

    linux_network = LinuxNetwork(module)
    linux_network.populate(gather_subset=['all'], filter_=['fake_interface'])

    assert 'interfaces' in linux_network
    assert 'all_ipv4_addresses' in linux_network
    assert 'all_ipv6_addresses' in linux_network

    linux_network = LinuxNetwork(module)
    linux_network.populate(gather_subset=['!all', '!min'])
    assert 'interfaces' in linux_network
    assert 'all_ipv4_addresses' not in linux_network

# Generated at 2022-06-11 03:37:30.738083
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'get_interfaces_info': True,
        'ip_path': 'ip',
    }
    n = LinuxNetwork(module)
    default_ipv4 = {'address': '192.168.122.1'}
    default_ipv6 = {'address': 'fe80::5054:ff:fea7:8a5a'}
    interfaces, ips = n.get_interfaces_info(module.params['ip_path'], default_ipv4, default_ipv6)
    assert interfaces['virbr0']['ipv4']['address'] == "192.168.122.1"

# Generated at 2022-06-11 03:37:37.311717
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network = LinuxNetwork()
    output= 'default via 172.17.0.1 dev eth0  proto static'
    res = linux_network.get_default_interfaces(output)
    assert res[0]['gateway'] == '172.17.0.1'
    output = "default dev br0  table bridge  proto static  metric 2"
    res = linux_network.get_default_interfaces(output)
    assert res[1]['interface'] == 'br0'


# Generated at 2022-06-11 03:37:47.521189
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule({})
    # TODO: replace the following module.run_command with a mock
    def run_command(args, errors='strict'):
        # TODO: find a better way to mock run_command
        # We check only for args[4] in test_LinuxNetwork_get_default_ip
        if len(args) < 5:
            return None, None, None

# Generated at 2022-06-11 03:38:24.857553
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    m = AnsibleModule(argument_spec={})
    n = LinuxNetwork(m)
    ethtool = n.module.get_bin_path('ethtool')
    # mock ethtool with a file
    with tempfile.NamedTemporaryFile(delete=False) as f:
        filename = f.name

# Generated at 2022-06-11 03:38:32.313615
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    ln = LinuxNetwork()
    ln.module = MagicMock()
    ln.module.get_bin_path.return_value = "ethtool_path"
    ln.module.run_command.return_value = 0, "stdout", "stderr"
    ln.module.run_command.assert_called_once()
    ln.module.get_bin_path.assert_called_once()
#
# Unit tests for LinuxNetwork class methods
#



# Generated at 2022-06-11 03:38:42.448445
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    provided_default_interfaces = {'default_ipv6': {'address': 'fe80::a00:27ff:fe36:e5bd'}, 'default_ipv4': {'address': '127.0.0.1'}}
    expected_default_interfaces = {'default_ipv6': {'address': 'fe80::a00:27ff:fe36:e5bd'}, 'default_ipv4': {'address': '127.0.0.1'}}
    provided_interfaces = {'eth0': {'device': 'eth0'}, 'eth1': {'device': 'eth1'}, 'eth2': {'device': 'eth2'}}

# Generated at 2022-06-11 03:38:50.255731
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # NOTE: this needs to be mocked out
    # module.params['use_ipv6'] = True
    # FIXME: this is a constructor, may make more sense to mock __init__
    ln = LinuxNetwork(module)

    # TODO: add some assertions
    ln.get_default_interfaces()
    ln.get_interfaces_info("", {}, {})

    # FIXME: this is a destructor
    ln.get_systemd_devices()


# Generated at 2022-06-11 03:39:01.846802
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule({}, {}, check_invalid_arguments=False)
    l = LinuxNetwork(module)


# Generated at 2022-06-11 03:39:12.914290
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    network = LinuxNetwork(module)
    device = 'eth1'
    data = network.get_ethtool_data(device)

# Generated at 2022-06-11 03:39:24.218307
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # test the LinuxNetwork class
    ln = LinuxNetwork()

    # test ethtool data retrieval
    stub_path = '/marvin/data/com/redhat/ansible/stubs/module_utils/network/common/network.py'

    def stub_get_bin_path(s):
        return "/sbin/ethtool"

    ln.module.get_bin_path = stub_get_bin_path
    ln.module.run_command = stub_run_command

    data = ln.get_ethtool_data('eth0')
    assert data['features']['rx_vlan_offload'] == 'on'
    assert data['features']['ntuple_filters'] == 'off'
    assert data['features']['rx_hash_function'] == 'default'

# Generated at 2022-06-11 03:39:35.483713
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    '''Unit test for method get_default_interfaces
    '''

    # Create a mock module
    module = AnsibleModule(argument_spec={})
    module.run_command = Mock(return_value=(0, 'eth0', ''))
    module.get_bin_path = Mock(return_value='')

    # Create a mock Network class
    class NetMock(LinuxNetwork):
        '''
        Mock of the LinuxNetwork class
        '''

        def __init__(self, module):
            self.module = module

        def get_interfaces_info(self, ip_path, default_ipv4, default_ipv6):
            '''
            Mock of LinuxNetwork.get_interfaces_info
            '''

            return {}, {}

    # Create an instance of the class

# Generated at 2022-06-11 03:39:44.611088
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    from ansible.module_utils.network.common.utils import parse_data
    from ansible.module_utils.basic import AnsibleModule
    data = parse_data('''
    default via 10.0.2.2 dev eth0
    10.0.2.0/24 dev eth0 proto kernel scope link src 10.0.2.15
    192.168.122.0/24 dev virbr0 proto kernel scope link src 192.168.122.1 linkdown
    ''')
    module = AnsibleModule({})
    ln = LinuxNetwork(module)
    ipv4, ipv6 = ln.get_default_interfaces(data)
    assert ipv4['interface'] == 'eth0'
    assert ipv4['address'] == '10.0.2.15'

# Generated at 2022-06-11 03:39:49.243277
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    linux_network.run()
    assert linux_network.get_default_interfaces() == {'interface': 'ens33', 'address': '192.168.0.105', 'gateway': '192.168.0.1', 'scope': 'global'}


# Generated at 2022-06-11 03:40:52.962694
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    net = LinuxNetwork()
    # Test with invalid device
    interfaces = net.populate('lo')
    # Test with valid device
    interfaces = net.populate('eth0')
    assert interfaces.get('eth0').get('device') == 'eth0'
    # Test with None
    interfaces = net.populate()
    # Test with an empty string
    interfaces = net.populate('')
    # Test with an empty list
    interfaces = net.populate([])

# Generated at 2022-06-11 03:41:03.876897
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    get_default_interfaces = LinuxNetwork.get_default_interfaces

    def mock_run_command_v4_error(self):
        return 1, "No such device", ""

    def mock_run_command_v6_error(self):
        return 1, "", "No route to host"

    def mock_run_command_v4_success(self):
        return 0, "default via 192.168.1.1 dev eth0  proto static  metric 1024  mss 1460", ""

    def mock_run_command_v6_success(self):
        return 0, "default via fe80::caf:babe dev eth0  proto static  metric 1024  mss 1460", ""


# Generated at 2022-06-11 03:41:05.105645
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    NetworkCollector()


# Generated at 2022-06-11 03:41:08.423324
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(
        argument_spec={},
    )
    collector = LinuxNetworkCollector(module)
    assert collector.get_network_interfaces_configuration() == {}



# Generated at 2022-06-11 03:41:19.351915
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Test with a fake file

    # Test with a fake file
    mockFile = mock.mock_open(read_data="[main]\nplugins=ifcfg-rh\n")
    with mock.patch("__main__.open", mockFile):
        inet = LinuxNetwork()
        # FIXME: populate is a static method so this needs to be fixed
        inet.module = module
        inet.module.run_command = lambda args, **kwargs: (0, "", "")
        result = inet.populate(dict(linux=dict(network=dict())))
        expected = dict(
            network=dict(
                config=dict(
                    network_plugins=["ifcfg-rh"],
                ),
            ),
        )
        assert result == expected

    # Test with a fake file
    mockFile = mock

# Generated at 2022-06-11 03:41:29.340521
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    import pytest
    # We need to patch environ before importing module_utils/facts/network/linux.py because it is loaded before pytest actually does the patching.
    monkeypatch = pytest.importorskip("_pytest.monkeypatch")
    m = monkeypatch.monkeypatch()
    m.setattr(os.path, "exists", lambda x: True)
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.facts.network.linux import LinuxNetwork
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.facts.network.base import NetworkError
    from ansible_collections.notmintest.not_a_real_collection.tests.unit.module_utils.facts.utils.file_discovery import mock_

# Generated at 2022-06-11 03:41:32.811373
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = MagicMock()
    mod = LinuxNetwork(module)
    assert mod.get_ethtool_data("eth0") == {'features': {}, 'timestamping': [], 'hw_timestamp_filters': []}

# Generated at 2022-06-11 03:41:43.264111
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})

    ln = LinuxNetwork(module)

    # TODO: should we mock all of these?
    ip_path = "/sbin/ip"
    default_ipv4 = {
        "address": "10.10.10.10",
    }
    default_ipv6 = {
        "address": "2001:db8:a0b:12f0::1",
    }

    expected_ipv4_output = {
        "address": "10.10.10.10",
        "broadcast": "10.10.10.255",
        "netmask": "255.255.255.0",
        "network": "10.10.10.0",
    }


# Generated at 2022-06-11 03:41:51.782149
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # mock module class
    class MockModule(object):
        def __init__(self):
            self.params = {}
            pass

        def fail_json(self, *args, **kwargs):
            pass

        def get_bin_path(self, *args, **kwargs):
            return "/usr/sbin/ethtool"


# Generated at 2022-06-11 03:41:53.113765
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    address = get_file_content('get_file_content', default='')

# Generated at 2022-06-11 03:43:02.481826
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import mock

    module = mock.Mock()
    module._load_params = mock.Mock()
    module._diff = mock.Mock()

# Generated at 2022-06-11 03:43:09.812569
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module_args = {
        "dummy": "value"
    }
    obj = LinuxNetwork(module_args)
    default_ipv4 = {}
    default_ipv6 = {}
    ip_path = ""
    expected_interfaces_info = {}
    interfaces_info, ips = obj.get_interfaces_info(ip_path, default_ipv4, default_ipv6)
    assert interfaces_info == expected_interfaces_info
    assert ips == {
        "all_ipv4_addresses": [],
        "all_ipv6_addresses": []
    }



# Generated at 2022-06-11 03:43:19.757508
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    lin = LinuxNetwork(module=module)
    default_ipv4 = lin.get_default_interfaces()[0]
    assert default_ipv4['address'] == "192.168.33.12"
    assert default_ipv4['broadcast'] == "192.168.33.255"
    assert default_ipv4['netmask'] == '255.255.255.0'
    assert default_ipv4['network'] == '192.168.33.0'
    assert default_ipv4['macaddress'] == "00:0c:29:4d:ab:a4"
    assert default_ipv4['mtu'] == 1500
    assert default_ipv4['alias'] == "eth0"

# Generated at 2022-06-11 03:43:28.113907
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    values = dict(
        default_ipv4=dict(),
        default_ipv6=dict()
    )
    linux_network = LinuxNetwork(dict(ansible_check_mode=False, ansible_module=dict()), dict())
    interface = dict()
    ips = dict()
    interfaces, ips = linux_network.get_interfaces_info('/sbin/ip', values['default_ipv4'], values['default_ipv6'])
    interface, default_ipv4, default_ipv6 = linux_network.populate(interface, ips, values['default_ipv4'], values['default_ipv6'])
    return interface, default_ipv4, default_ipv6

# Generated at 2022-06-11 03:43:32.994098
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    changed = False
    ansible_module = AnsibleModule(
        argument_spec=dict(),
    )
    theclass = LinuxNetwork(ansible_module)
    new_ipv4, new_ipv6 = theclass.get_default_interfaces()
    assert new_ipv4['interface'] == 'eth0'
    assert new_ipv6['interface'] == 'eth0'



# Generated at 2022-06-11 03:43:40.651563
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common import set_module_args
    import os
    import json

    module = AnsibleModule({})
    set_module_args(
        dict(
            config=['lo'],
            matching=['lo', 'eth0'],
            default_ipv4=dict(address='127.0.0.1'),
            default_ipv6=dict(address='::1'),
        )
    )

    test_file_path = os.path.join(os.path.dirname(__file__), 'network_interfaces_info.json')
    test_file = open(test_file_path, 'r')
    test_data = json.load(test_file)
    test_file.close()

    test_

# Generated at 2022-06-11 03:43:50.673614
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Test with no ethtool
    module = AnsibleModule(argument_spec={})
    mock_bin_path = MagicMock(return_value=None)
    with patch.object(module, "get_bin_path", mock_bin_path):
        result = LinuxNetwork().get_ethtool_data(device="eth0")
        assert not result

    # Test with no results from ethtool command
    module = AnsibleModule(argument_spec={})
    mock_bin_path = MagicMock(return_value="ethtool")
    mock_run_command = MagicMock(return_value=(0, '', ''))
    with patch.object(module, "get_bin_path", mock_bin_path), patch.object(module, "run_command", mock_run_command):
        result = LinuxNetwork().get_ethtool

# Generated at 2022-06-11 03:44:00.360524
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict(test_interfaces_content=dict(type='str', required=True)))
    test_interfaces_content = module.params['test_interfaces_content']
    test_output = module.params['test_output']

    ln = LinuxNetwork()
    ln.module = module
    ln.module.run_command = lambda *_, **__: (0, test_interfaces_content, '')
    interfaces, ips = ln.get_interfaces_info('ip',
                                             {'address': '0.0.0.0'},
                                             {'address': '::'})

    for i in test_output:
        assert interfaces[i] == test_output[i]



# Generated at 2022-06-11 03:44:10.021109
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    fixture = dict(path='/bin/ip')
    obj = LinuxNetwork(dict(module=dict(params=dict(ip_path='/bin/ip', nic='eth0'))))
    ansible_facts = dict(default_ipv4=dict(address='192.0.2.1', netmask='255.255.255.0'),
                         default_ipv6=dict(address='2001:db8::1', netmask='64'))

# Generated at 2022-06-11 03:44:16.295449
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network = LinuxNetwork()
    linux_network.module = AnsibleModule(argument_spec={})
    argument_spec = {'addresses': {'type': 'dict', 'default': None}}
    module = AnsibleModule(argument_spec=argument_spec)
    setattr(linux_network.module, 'params', module.params)
    result = linux_network.populate()
    assert result == linux_network.module.params['addresses']

# Generated at 2022-06-11 03:45:28.717480
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    ln = LinuxNetwork()
    ln.module = MagicMock()
    ln.module.get_bin_path = MagicMock(return_value=None)
    ln.module.run_command = MagicMock(return_value=(0, '', ''))

    expected_results = {
        'default_ipv4': {},
        'default_ipv6': {},
        'interfaces': {},
        'routes': {'ipv4': {}, 'ipv6': {}},
    }

    assert expected_results == ln.populate()


# Generated at 2022-06-11 03:45:35.755704
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule
    import tempfile


# Generated at 2022-06-11 03:45:42.356271
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={
    })
    net = LinuxNetwork(module)

    default_ipv4 = {}
    default_ipv6 = {}
    ip_path = module.get_bin_path("ip") or '/bin/ip'

    interfaces, ips = net.get_interfaces_info(ip_path, default_ipv4, default_ipv6)
    assert isinstance(interfaces, dict)
    assert isinstance(ips, dict)
    assert isinstance(ips['all_ipv4_addresses'], list)
    assert isinstance(ips['all_ipv6_addresses'], list)

