

# Generated at 2022-06-11 03:36:20.513182
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class LinuxNetwork."""

    test_path = os.path.dirname(os.path.abspath(__file__))
    mock_path = os.path.join(test_path, 'mock')

    os.environ['PATH'] = os.path.join(mock_path) + os.pathsep + os.environ['PATH']
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    linux_network = LinuxNetwork(module)

    # mocking /sys/class/net/
    mock_sys_class_net_path = os.path.join(mock_path, 'sys', 'class', 'net')


# Generated at 2022-06-11 03:36:29.798551
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    class MockModule(object):
        def __init__(self):
            self.params = {}

        def run_command(self, args, errors='surrogate_then_replace'):
            return (0, '', '')

        def get_bin_path(self, binary):
            return ''

    class MockOs(object):
        @staticmethod
        def readlink(path):
            return ''

    class MockOsPath(object):
        @staticmethod
        def exists(path):
            return True

        @staticmethod
        def isdir(path):
            return True

    class MockGlob(object):
        @staticmethod
        def glob(*args, **kwargs):
            return []

    class MockStruct(object):
        @staticmethod
        def unpack(endian, ipaddress):
            return 0

   

# Generated at 2022-06-11 03:36:35.083878
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # Test without modules loaded
    facts = dict(distribution='Debian',
                 platform='Linux')
    lnc = LinuxNetworkCollector(dict(), facts, None)
    assert lnc.facts == facts
    assert lnc.module == None
    assert lnc.platform == 'Linux'



# Generated at 2022-06-11 03:36:38.937924
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # import pytest
    # pytest.skip()
    module = FakeModule()
    ln = LinuxNetworkCollector(module=module)
    # assert ln.module == module
    assert ln.facts['distribution'] == 'Debian'

# Generated at 2022-06-11 03:36:50.672545
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    mod = AnsibleModule(argument_spec={})
    inst = LinuxNetwork(mod)
    sig = inspect.signature(inst.get_ethtool_data)
    types = [
        param.annotation for name, param in sig.parameters.items()
        if param.annotation != inspect._empty
    ]
    assert types == [str], \
        'get_ethtool_data takes one argument, the ethtool device name'

    # currently (2018) there are three output paths for the test:
    #   1. busybox, i.e. small footprint, missing features
    #   2. g-like, i.e. missing timestamping
    #   3. rhel-like, i.e. all features

    # busybox

# Generated at 2022-06-11 03:36:55.514277
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network import Network

    iface = {'device': 'eth1'}
    net_info = Network()
    net_info.interfaces = {'eth1': iface}

    # Test default values
    assert net_info.get_interfaces_info() == ({'eth1': iface},
                                              {'all_ipv4_addresses': [],
                                               'all_ipv6_addresses': []})

    # Test with an invalid device
    net_info.interfaces = {'eth1': iface, 'eth2': 'invalid'}

# Generated at 2022-06-11 03:37:03.723544
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():

    test_instance = LinuxNetwork()
    device = 'foo'

    def mock_get_bin_path(module, path):
        # We are only testing the ethtool-related behavior so let's make sure
        # it exists.
        return path

    def mock_run_command(module, *cmd, **kwargs):
        args = list(cmd)
        # We are only testing the ethtool-related behavior so let's ignore
        # the actual command.
        output = b''

# Generated at 2022-06-11 03:37:16.045477
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = MagicMock()
    mod_path = lambda x: x  # noqa
    module.get_bin_path.side_effect = mod_path
    n = LinuxNetwork(module=module)
    path = '/path/to/net/'

# Generated at 2022-06-11 03:37:24.578727
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Setup
    m_module = mock.MagicMock(name="module")
    m_module.get_bin_path.return_value = "/bin/ip"
    m_module.run_command.return_value = (0, "", "")
    linux_network = LinuxNetwork(m_module)

    # Exercise
    linux_network.get_default_interfaces()

    # Verify
    m_module.run_command.assert_called_once_with(["/bin/ip", "route", "get", "8.8.8.8"], errors='surrogate_then_replace')


# Generated at 2022-06-11 03:37:32.712809
# Unit test for method get_default_interfaces of class LinuxNetwork

# Generated at 2022-06-11 03:38:13.975175
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module_mock = MagicMock()
    module_mock.params = dict(
        config_format='ini',
        config_file='/etc/sysconfig/network',
        config_include_defaults=True,
        default_interface=None,
        default_interface_type='unknown',
        default_ipv4={},
        default_ipv6={},
        family='all',
        ip_path=None,
        routing_table='all',
    )
    module_mock.run_command.return_value = (0, '', '')
    ln = LinuxNetwork(module=module_mock)
    assert ln.populate() is None



# Generated at 2022-06-11 03:38:24.320181
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network = LinuxNetwork()

# Generated at 2022-06-11 03:38:35.381750
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    class MockModule(object):
        def __init__(self):
            self.run_command_args = []
            self.run_command_rcs = []
            self.run_command_stdouts = []
            self.run_command_stderrs = []

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            self.get_bin_path_name = name
            self.get_bin_path_required = required
            self.get_bin_path_opt_dirs = opt_dirs
            return "/bin/{}".format(name)

        def run_command(self, args, errors='surrogate_then_replace'):
            rc = None
            stdout = ""
            stderr = ""

# Generated at 2022-06-11 03:38:45.701095
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network = LinuxNetwork()

# Generated at 2022-06-11 03:38:56.425625
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible.module_utils.six import BytesIO
    import ansible.module_utils.basic
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True)
    class_LinuxNetwork_obj = LinuxNetwork(module)
    # Assert get_interfaces_info returns expected values

# Generated at 2022-06-11 03:38:59.993981
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    device = "eth0"
    assert ln.get_ethtool_data(device) == {}


# Generated at 2022-06-11 03:39:11.109223
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    network = LinuxNetwork()
    import os
    import tempfile
    # mocked ethtool command
    def mock_run_command(args, errors=None):
        assert args[0] == ethtool_path
        if args[1] == '-k':
            return 0, """
            Features for eth0:
                rx-checksumming: off
                tx-checksumming: off
                scatter-gather: on
                tcp-segmentation-offload: off
                udp-fragmentation-offload: off
                generic-segmentation-offload: off
            """, ""

# Generated at 2022-06-11 03:39:19.226055
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    if not os.path.exists('/sys/class/net/eth0'):
        pytest.skip("Missing /sys/class/net/eth0")

    module = AnsibleModule({'path': '/bin'})
    net = LinuxNetwork(module)
    ip_path = "/bin/ip"
    default_ipv4, default_ipv6 = net.get_default_interfaces(ip_path)
    assert default_ipv4['interface'] == 'eth0'
    assert default_ipv6['interface'] == 'eth0'


# Generated at 2022-06-11 03:39:24.435133
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    linux_network = LinuxNetwork(module)
    default_ipv4, default_ipv6 = linux_network.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)

# Generated at 2022-06-11 03:39:35.711394
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():  # noqa: D202
    module = AnsibleModule(argument_spec={
        'gather_subset': {
            'type': 'list',
            'choices': ['all', 'interfaces', 'ipv6', 'interfaces_ipv6'],
            'default': ['all'],
        },
        'gather_network_resources': {'type': 'bool', 'required': False},
        'gather_dhcp_server_info': {'type': 'bool', 'required': False},
    })
    # perform any setup required for your module's tests

    # In the AnsibleModule constructor, you pass in the AnsibleModule
    # instance, a DICT of any params you will pass to the AnsibleModule and
    # the name of the AnsibleModule you are creating

# Generated at 2022-06-11 03:40:19.745037
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    """
    Regression test for #38214
    """
    module = AnsibleModule(argument_spec={})
    # Mock the module's find_bin_path, so scripts/net_facts tests can run
    # from any place, not just the $root/lib/ansible/module_utils/network
    module.find_bin_path = lambda x: x
    linux_network = LinuxNetwork(module)
    interfaces = {}
    ips = {}
    # Since we mock find_bin_path above, this will not actually execute ip
    linux_network.get_interfaces_info('/bin/ip', interfaces, ips)
    assert interfaces == {}



# Generated at 2022-06-11 03:40:30.429489
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():

    # for testing we just need the LinuxNetwork class, not the whole module
    # the class under test does depend on some class variables in the module
    # so we have to fake these module variables
    # pylint: disable=R0903
    module_mock = MagicMock(name='module')

    # we just need the get_bin_path method
    module_mock.get_bin_path = MagicMock(name='get_bin_path')

    # we define the test data as dicts
    # so we can do assert_equal lateron
    test_data = {}
    test_data[1] = {'ethtool_path': '', 'device': 'eth0', 'expected': {}}

# Generated at 2022-06-11 03:40:39.657251
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # NOTE: all_interfaces_dict is a global here
    global all_interfaces_dict

    network = LinuxNetwork(dict(
        ansible_module=dict(
        ),
    ))
    network.populate()
    assert isinstance(all_interfaces_dict, dict)

    # NOTE: all_interfaces_dict is a global here
    network = LinuxNetwork(dict(
        ansible_module=dict(
            params=dict(
                ip_output='',
            ),
        ),
    ))
    network.populate()
    assert isinstance(all_interfaces_dict, dict)
    assert 'default_ipv4' in all_interfaces_dict
    assert 'default_ipv6' in all_interfaces_dict
    assert 'default_interface' in all_interfaces_dict

# Generated at 2022-06-11 03:40:52.814742
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from ansible.module_utils.basic import AnsibleModule, load_platform_subclass
    import json

    _module = AnsibleModule(argument_spec={})
    module = LinuxNetwork(_module)
    interfaces = {'eth0': {'promisc': False}, 'eth1': {'promisc': False}}
    interfaces.update(module.get_interfaces_info("/sbin/ip",
                                                 {'address': '192.168.122.2'},
                                                 {'address': 'fe80::5054:ff:feb9:eb08'}))

    ifaces = []
    for iface in interfaces:
        if 'type' in interfaces[iface] and interfaces[iface]['type'] == 'bridge':
            continue
        ifaces.append(interfaces[iface]['device'])

# Generated at 2022-06-11 03:40:59.732217
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    result = dict(
        changed=False,
        msg="LinuxNetwork.get_ethtool_data(): unit test succeeded",
    )

    ln = LinuxNetwork(module)
    data = ln.get_ethtool_data('test_interface')
    assert 'features' in data
    assert 'timestamping' in data

    module.exit_json(**result)



# Generated at 2022-06-11 03:41:11.046162
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    # test valid input

# Generated at 2022-06-11 03:41:21.726566
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():

    from os.path import join
    from pprint import pprint
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock, patch
    from ansible_collections.ansible.community.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args

    class MockModule:
        def __init__(self, ansible_options):
            self.params = ansible_options
            self.fail_json = AnsibleFailJson

        def exit_json(self, *args, **kwargs):
            return AnsibleExitJson(kwargs)

        def fail_json(self, *args, **kwargs):
            self.fail_json(msg=args[0], **kwargs)


# Generated at 2022-06-11 03:41:25.424099
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = ansible_module_get()

    network = LinuxNetwork(module)
    network.populate()
    assert network.ip_path, "ip is needed"
    assert network.resolve, "resolve is needed"


# Generated at 2022-06-11 03:41:33.086019
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule
    import sys

    sys.path.append('/home/build/ansible/test')
    test_module = AnsibleModule(
        argument_spec=dict()
    )
    test_instance = LinuxNetwork(test_module)

    def test_other_linux_nets(ip_path, default_ipv4, default_ipv6):
        test_instance.get_interfaces_info(ip_path, default_ipv4, default_ipv6)

    test_other_linux_nets('/bin/ip', {'address': '10.20.42.20'}, {'address': 'dead:beef::42'})

# Generated at 2022-06-11 03:41:35.246249
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = LinuxNetwork()
    # TODO: write a test class
    assert module.get_ethtool_data('lo') == {}

# Generated at 2022-06-11 03:42:21.240391
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path

    class FakeModule(object):
        def __init__(self):
            self._init_called = True
            self.params = {
                'name': 'eth0'
            }

        def get_bin_path(self, *args, **kwargs):
            if not self._get_bin_path_called:
                self._get_bin_path_called = True
            return get_bin_path(*args, **kwargs)

        def run_command(self, *args, **kwargs):
            if not self._run_command_called:
                self._run_command_called = True

# Generated at 2022-06-11 03:42:25.572581
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    test_args = dict(device="::ffff:10.0.0.10", features={})
    linux_network = LinuxNetwork(module=None)
    assert linux_network.get_ethtool_data(**test_args) == dict(features={})

    # If fails, tests would fail, so we can't test it


# Generated at 2022-06-11 03:42:35.590180
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=False)
    network = LinuxNetwork(module=module)

    # test for 6to4 tunnel
    command = ['/sbin/ip', '-4', 'route', 'get', '192.88.99.1' + '\n']
    rc, out, err = module.run_command(command, errors='surrogate_then_replace')
    network.run_commands = [
        (0, '', ''),
        (command[0], out, err)
    ]

# Generated at 2022-06-11 03:42:45.831833
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(
        argument_spec = dict(
            device=dict(type='str', required=True)
        ),
        supports_check_mode=True,
    )
    # pylint: disable=protected-access
    interface_name = 'ethtool_test'
    network = LinuxNetwork(module, interface_name)
    ethtool_path = module.get_bin_path('ethtool')
    module.run_command_environ_update = dict(LANG='C', LC_ALL='C', LC_MESSAGES='C', LC_CTYPE='C')


# Generated at 2022-06-11 03:42:55.494143
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    jsondata = r'''
        {
            "result": [
                {
                    "dev": "eth0",
                    "ip_address": "192.168.122.1",
                    "ip_default_dev": "eth0",
                    "ip_gateway": "10.6.0.1"
                },
                {
                    "dev": "eth1",
                    "ip_address": "10.6.0.34",
                    "ip_default_dev": "eth0",
                    "ip_gateway": "10.6.0.1"
                }
            ],
            "module_stderr": "",
            "msg": "All items completed",
            "rc": 0
        }
        '''

# Generated at 2022-06-11 03:42:56.827611
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    net = LinuxNetwork()
    assert net.get_ethtool_data('eth0')  # no error


# Generated at 2022-06-11 03:42:58.461644
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO:
    # FIXME:
    # mock stuff
    pass

# Generated at 2022-06-11 03:43:03.649503
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network = LinuxNetwork()
    device = 'wlp2s0'
    data = linux_network.get_ethtool_data(device)
    assert 'features' in data
    assert 'ip_tos_pattern' in data['features']
    assert 'corrupt_fw_rds' in data['features']
    assert 'hw_timestamp_filters' in data
    assert 'all' in data['hw_timestamp_filters']
    assert 'phc_index' in data
    assert data['phc_index'] == 0

# Generated at 2022-06-11 03:43:12.937009
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import copy
    import pprint
    my_obj = LinuxNetwork(None)
    # expected

# Generated at 2022-06-11 03:43:23.193515
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    ip_path = module.get_bin_path("ip")
    linux_network = LinuxNetwork(module, ip_path)
    default_ipv4 = {}
    default_ipv6 = {}

    interfaces_info, ips = linux_network.get_interfaces_info(ip_path, default_ipv4, default_ipv6)
    output = {"interfaces_info": interfaces_info, "ips": ips}

    # NOTE: this could be better, but this will catch all three cases
    assert isinstance(interfaces_info, dict)
    assert isinstance(ips, dict)

    # NOTE: change to individual asserts on the fields as soon as I have
    #       better idea how to test it on a wider variety of systems

# Generated at 2022-06-11 03:44:01.942164
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.check_mode = False
    module.params = {}
    module.run_command = MagicMock(return_value=0)
    ln = LinuxNetwork(module)
    data = ln.get_ethtool_data('eth0')
    assert data == {}



# Generated at 2022-06-11 03:44:11.318627
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from ansible_collections.community.general.tests.unit.compat.mock import patch
    from ansible_collections.community.general.tests.unit.modules.utils import set_module_args
    from ansible_collections.community.general.plugins.module_utils import basic
    import platform
    import re

    mock_platform = MagicMock()
    mock_platform.system.return_value = 'Linux'
    mock_platform.release.return_value = '2.6.32-573.18.1.el6.x86_64'
    mock_platform.version.return_value = ''
    mock_platform.machine.return_value = 'x86_64'
    mock_platform.linux_distribution.return_value = ('CentOS release 6.9 (Final)', '', '')
    mock

# Generated at 2022-06-11 03:44:15.899131
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    m = AnsibleModule()

    class TestArgs(object):
        def __init__(self, module):
            self.module = module

    m.params = TestArgs(m)
    m.params.module = m

    l = LinuxNetwork(m)

    assert l.get_default_interfaces() == ({}, {})


# Generated at 2022-06-11 03:44:26.347891
# Unit test for method populate of class LinuxNetwork

# Generated at 2022-06-11 03:44:34.032279
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=["!all"], type='list'),
            gather_network_resources=dict(default=['all'], type='list'),
        ),
    )
    nm = LinuxNetwork(module)
    nm.get_interfaces_info = MagicMock(return_value=([], []))  # FIXME: better return value?
    nm.get_default_interfaces = MagicMock(return_value=([], []))
    nm.populate()
    # FIXME: add good asserts here

if __name__ == '__main__':
    main()

# Generated at 2022-06-11 03:44:44.049883
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    ethtool_data = {
        'features': {'tx_checksumming': 'on',
                     'tx_checksum_ipv4': 'on',
                     'tx_checksum_ipv6': 'on',
                     'rx_checksumming': 'on',
                     'rx_checksum_ipv4': 'on',
                     'rx_checksum_ipv6': 'on',
                     'tx_ipv4_csum_offload_with_fcoe_hdr': 'on'},
        'hw_timestamp_filters': ['all', 'v2_event', 'v2_systime', 'v1_systime'],
        'timestamping': ['hardware'],
        'phc_index': 1,
    }


# Generated at 2022-06-11 03:44:52.239770
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Setup
    module = AnsibleModule(
        argument_spec=dict(),
    )
    class_instance = LinuxNetwork(module)

    # Test
    mocker = patch('ansible_collections.ansible.community.plugins.module_utils.network.common.network.LinuxNetwork.get_ethtool_data')
    input_str = '00:01:02:03:04:05'
    mocked_method = mocker.start()
    mocked_method.return_value = input_str
    result = class_instance.get_ethtool_data()
    mocker.stop()
    assert result == input_str

# Generated at 2022-06-11 03:45:01.796994
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    ln = LinuxNetwork()
    ln.module = unittest.mock.Mock()
    ln.module.run_command.return_value = (0, 'aa:bb:cc:dd:ee:ff', '')
    ln.module.get_bin_path = unittest.mock.Mock(return_value='/bin/ethtool')

    # empty mock object
    ln.module.run_command.return_value = (0, '', '')
    res = ln.get_ethtool_data('bogus')
    assert isinstance(res, dict)
    assert res == {}

    # mock object
    ln.module.run_command.return_value = (0, 'foo: bar', '')

# Generated at 2022-06-11 03:45:11.099168
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    """Testing LinuxNetwork.populate"""
    # Initialization
    my_obj = LinuxNetwork()

# Generated at 2022-06-11 03:45:20.206315
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    # Create new instance of the LinuxNetwork class
    ln = LinuxNetwork()
    ln.module = MagicMock()