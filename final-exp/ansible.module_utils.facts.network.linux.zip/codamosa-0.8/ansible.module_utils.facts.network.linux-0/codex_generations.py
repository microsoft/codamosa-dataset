

# Generated at 2022-06-11 03:36:21.453436
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    l = LinuxNetwork()
    res = l.get_ethtool_data("eth0")
    assert res == {'features': {'gso': 'on',
                                'gro': 'off',
                                'lro': 'off',
                                'rx_checksumming': 'on',
                                'tx_checksumming': 'on',
                                'tx_checksum_ip': 'on',
                                'tx_checksum_ipv6': 'on',
                                'tx_checksum_fcoe_crc': 'off',
                                'tx_checksum_sctp': 'on'},
                   'timestamping': ['rx', 'tx'],
                   'hw_timestamp_filters': ['all'],
                   'phc_index': 0}



# Generated at 2022-06-11 03:36:31.293704
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class LinuxNetwork."""
    network = LinuxNetwork()


# Generated at 2022-06-11 03:36:34.769137
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Can't use TestCase here since it's a classmethod / data return
    pr = LinuxNetwork()
    assert pr.get_default_interfaces() == ('eth0', 'eth1')


# Generated at 2022-06-11 03:36:46.874132
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    class FakeModule(object):
        def __init__(self, bin_path):
            self.bin_path_val = bin_path
        def get_bin_path(self, path):
            if path == 'ethtool':
                return self.bin_path_val
            return None
        def run_command(self, args, errors='surrogate_then_replace'):
            return self.run_command_val

    with pytest.raises(LookupError):
        LinuxNetwork(FakeModule(None))

    m = FakeModule('/bin/ethtool')
    l = LinuxNetwork(m)

    # ethtool not installed
    m.bin_path_val = None
    with pytest.raises(LookupError):
        l.get_ethtool_data('lo')

    # ethtool installed, but no

# Generated at 2022-06-11 03:36:51.359711
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec=dict())
    module.params = dict()
    l = LinuxNetwork(module)
    l.get_interfaces_info(None, None, None)


# ===========================================
# Main
# ===========================================

# Generated at 2022-06-11 03:36:56.542281
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec={},
    )
    ls = LinuxNetwork(module)
    data = ls.populate()
    module.exit_json(changed=False, data=data)
# import module snippets
from ansible.module_utils.basic import *

# Main function to kick off processing
if __name__ == '__main__':
    main()

# Generated at 2022-06-11 03:37:05.466422
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.network.common.utils import load_platform_subclass
    from ansible.module_utils.network.common.utils import get_exception_string

    class FakeLinuxArgs(object):
        def __init__(self):
            self.use_ipv6 = False
            self.gather_subset = []

    class FakeLinuxModule(object):
        def __init__(self):
            self.params = FakeLinuxArgs()
            self.check_mode = False
            self.exit_json = lambda _: None
            self.fail_json = lambda _, **args: None
            self.run_command = lambda _, errors='surrogate_then_replace': (0, '', '')
            self.get_bin_path

# Generated at 2022-06-11 03:37:17.835434
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    import json
    import ansible.module_utils.basic
    from ansible.module_utils.six import PY3

    def get_bin_path(bin_name):
        return bin_name

    module_cls = ansible.module_utils.basic.AnsibleModule
    module_obj = module_cls(argument_spec={}, supports_check_mode=True)
    module_obj.get_bin_path = get_bin_path

    ln = LinuxNetwork(module_obj)
    device = "lo"
    ln_get_ethtool_data = ln.get_ethtool_data(device)
    ln_get_ethtool_data_json = json.dumps(ln_get_ethtool_data, indent=4, sort_keys=True)

# Generated at 2022-06-11 03:37:28.461169
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    ln = LinuxNetwork()
    ln.module = MockModule()
    ln.module.run_command = Mock(return_value=(0, '', ''))
    default_ipv4 = {}
    default_ipv6 = {}
    interfaces, ips = ln.get_interfaces_info('/sbin/ip', default_ipv4, default_ipv6)
    assert interfaces
    assert 'lo' in interfaces
    assert 'eth0' in interfaces
    assert 'br0' in interfaces
    assert 'docker0' in interfaces
    assert len(ips['all_ipv4_addresses']) == 1
    assert len(ips['all_ipv6_addresses']) == 1
    assert ips['all_ipv4_addresses'][0] == '127.0.0.1'


# Generated at 2022-06-11 03:37:36.245140
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module_args = dict()
    # Return the default arguments for AnsibleModule
    module = AnsibleModule(argument_spec=module_args, supports_check_mode=True)

    # Create an instance of LinuxNetwork
    ln = LinuxNetwork(module)

    # Get the default interfaces
    rc, out, err = ln.get_default_interfaces()

    # If the command failed, get_default_interfaces() will raise an exception
    # and Ansible will fail with an error message
    # Since this was called from the test, just assert that rc is 0, meaning
    # the command was successful
    assert rc == 0



# Generated at 2022-06-11 03:38:14.289018
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """
    Class constructor test
    """
    module = AnsibleModule(argument_spec={})
    assert LinuxNetworkCollector(module)._fact_class.__name__ == 'LinuxNetwork'

# Generated at 2022-06-11 03:38:24.666545
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    my_module = AnsibleModule(argument_spec={})
    my_class = LinuxNetwork(my_module)
    my_module.get_bin_path = Mock()
    my_module.run_commands = Mock()
    os.path.exists = Mock()
    my_module.get_bin_path.return_value = "/usr/sbin/ip"
    os.path.exists.return_value = True
    my_module.run_commands.return_value = [['default via 10.0.1.1 dev enp0s3  proto static  metric 100'], []]
    my_class.check_ipv6 = True
    result = my_class.populate()

# Generated at 2022-06-11 03:38:30.879025
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    linux_network = LinuxNetwork(module, 'eth0')
    default_ipv4, default_ipv6 = linux_network.get_default_interfaces()
    assert default_ipv4['address'] is not None
    assert default_ipv6['address'] is not None



# Generated at 2022-06-11 03:38:41.126353
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Case 1: Using default ip command
    test_module = AnsibleModule(
        argument_spec={
            'ip_path': {"default": None, "required": False, "type": "str"},
            'ignore_bond': {"default": False, "required": False, "type": "bool"},
        }
    )
    test_class = LinuxNetwork(test_module)
    out_v4, out_v6 = test_class.get_default_interfaces()
    assert "IPv4 Default Route" in out_v4
    assert out_v6 == {}

    # Case 2: Using given ip command

# Generated at 2022-06-11 03:38:51.388554
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    from io import StringIO
    from ansible.module_utils.six import b
    m = AnsibleModule(argument_spec={})
    ip_path = 'ip'
    net = LinuxNetwork(m, ip_path=ip_path)

# Generated at 2022-06-11 03:38:54.508707
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = NetworkCollector(module)
    assert isinstance(collector, LinuxNetworkCollector)


# Generated at 2022-06-11 03:39:06.546418
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    @contextmanager
    def fake_file(contents):
        with NamedTemporaryFile('w+') as temp_file:
            temp_file.write(contents)
            temp_file.flush()
            yield temp_file.name

    def fake_glob(glob_path):
        if glob_path == "/sys/class/net/*":
            return ["/sys/class/net/eth0",
                    "/sys/class/net/bond0",
                    "/sys/class/net/br0"]
        elif glob_path == "/sys/class/net/br0/brif/*":
            return ["/sys/class/net/br0/brif/eth0"]
        elif glob_path == "/sys/class/net/bond0/bonding/slaves":
            return ["eth0"]


# Generated at 2022-06-11 03:39:17.023395
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule({})
    linux_network = LinuxNetwork(module)

    ethtool_data = linux_network.get_ethtool_data('lo')
    assert ethtool_data['timestamping'] == ['none']
    assert 'hw_timestamp_filters' not in ethtool_data
    assert 'phc_index' not in ethtool_data
    assert 'features' in ethtool_data
    assert ethtool_data['features']['tx_checksum_ipv4'] == 'on'
    assert ethtool_data['features']['tx_checksum_ipv6'] == 'on'
    assert ethtool_data['features']['tx_checksum_fcoe_crc'] == 'on'

# Generated at 2022-06-11 03:39:28.244599
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule({})
    linux_network = LinuxNetwork(module)
    # This can be changed as needed to test for a particular distro
    distro = system_distro()[0].lower()
    if distro == 'debian':
        distro = 'ubuntu'
    linux_network.distro = distro
    interface = {'v4': None, 'v6': None}
    command = linux_network.get_default_interfaces()
    old_default_interface = linux_network.get_old_default_interface(command)
    interface['v4'] = linux_network.get_old_default_interface_address(old_default_interface, 4).get('interface')

# Generated at 2022-06-11 03:39:38.855583
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    ln = LinuxNetwork()
    device_eth0_data = ln.get_ethtool_data('eth0')
    assert isinstance(device_eth0_data, dict)
    assert 'features' in device_eth0_data
    assert isinstance(device_eth0_data['features'], dict)
    features = device_eth0_data['features']

# Generated at 2022-06-11 03:40:23.696345
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    # Test with default arguments
    linux_network = LinuxNetwork()
    res = linux_network.populate()
    assert res['ansible_eth1']['type'] == 'ethernet'
    assert res['ansible_eth1']['mtu'] == 1500
    assert res['ansible_eth1']['active'] is True
    assert res['ansible_eth1']['device'] == 'eth1'
    assert res['ansible_eth1']['ipv4']['network'] == '192.0.2.0'
    assert res['ansible_eth1']['ipv4']['address'] == '192.0.2.3'
    assert res['ansible_eth1']['ipv4']['broadcast'] == '192.0.2.255'

# Generated at 2022-06-11 03:40:33.973904
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)
    assert 'address' in default_ipv4
    assert 'address' in default_ipv6
    assert 'gateway' in default_ipv4
    assert 'gateway' in default_ipv6
    assert isinstance(default_ipv4['gateway'], str)
    assert isinstance(default_ipv6['gateway'], str)
    assert 'broadcast' in default_ipv4
    assert 'netmask' in default_ipv4
    assert 'network' in default_ipv4


# Generated at 2022-06-11 03:40:42.108902
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={})
    module.params = {}
    linux_network = LinuxNetwork(module)


# Generated at 2022-06-11 03:40:53.817544
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """
    This method tests the get_ethtool_data method
    """
    module = AnsibleModule(
        argument_spec = dict()
    )

    ln = LinuxNetwork(module)

    """
    ethtool -k eth0 output to test
    """
    device = 'eth0'

# Generated at 2022-06-11 03:41:04.803932
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    test_hostname = 'test_hostname'
    test_path = '/path'
    test_default_ipv4 = {'address': '1.2.3.4'}
    test_default_ipv6 = {'address': '1:2::3'}
    ln = LinuxNetwork(test_hostname, test_path)
    def mock_get_file_content(arg, default=False):
        del arg  # unused
        # Empty string means macaddress in test_interfaces_content is valid
        return str(default)
    ln.get_file_content = mock_get_file_content

# Generated at 2022-06-11 03:41:15.405073
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """Test behaviour of get_interfaces_info"""
    # Prepare test data
    ipv4 = dict(
        address="192.168.1.101",
        broadcast="192.168.1.255",
    )
    ipv6 = dict(
        address="2001:db8::ff00:42:8329",
        prefix="64",
        scope="global",
    )

# Generated at 2022-06-11 03:41:26.430407
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = MagicMock()
    module.get_bin_path.return_value = None
    ln = LinuxNetwork(module)
    data = ln.get_interfaces_info(ip_path=None, default_ipv4=dict(address='1.2.3.4'), default_ipv6=dict(address='dead:beef::1'))
    print(">> LinuxNetwork_test_get_interfaces_info:data: ", data)
    assert 'all_ipv4_addresses' in data[1]
    assert 'all_ipv6_addresses' in data[1]
    assert 'eth0' in data[0]
    assert 'enp0s3' in data[0]
    assert 'default_ipv4' in data[0]['eth0']

# Generated at 2022-06-11 03:41:32.769139
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = FakeAnsibleModule()
    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data('inter') == {'features': {'rx_all': 'on',
                                            'rx_checksumming': 'off',
                                            'tx_checksum_fcoe_crc': 'on',
                                            'tx_checksum_ip_generic': 'on',
                                            'tx_checksumming': 'off',
                                            'tx_scatter_gather': 'off',
                                            'tx_scatter_gather_fraglist': 'off'}}

# Generated at 2022-06-11 03:41:43.222830
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    def _fixture_linux_network():
        module = AnsibleModuleMock()
        module.run_command = Mock(return_value=(0, '', ''))
        ln = LinuxNetwork(module)
        # Populate with default values

# Generated at 2022-06-11 03:41:51.750250
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule
    lo = {'device': 'lo'}
    modules_to_patch = {
        'ansible.module_utils.basic.AnsibleModule':
            mock.MagicMock(return_value=module),
    }
    with mock.patch.multiple('ansible.module_utils.basic.AnsibleModule', **modules_to_patch):
        """
        Tests for auto-discovery of IP information
        """
        ip_path = '/sbin/ip'
        default_ipv4 = {'address': '127.0.0.1'}
        default_ipv6 = {'address': '::1'}
        interfaces = {'lo': lo}

# Generated at 2022-06-11 03:42:36.301229
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})

    device = "device_name"

    class MockLinuxNetwork(LinuxNetwork):
        def get_bin_path(self, name):
            return name

    linux_network = MockLinuxNetwork(module)

    # Case 1: no features

# Generated at 2022-06-11 03:42:39.619674
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    obj = LinuxNetwork()
    p = module_utils.network.linux_net.LinuxNetworkParser()

    ret = obj.get_default_interfaces(p)
    assert ret



# Generated at 2022-06-11 03:42:49.541067
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    # Test input
    connection, module_mock = get_connection_mock()
    network = LinuxNetwork(connection, module_mock)

    # Preparing test data

# Generated at 2022-06-11 03:42:58.666154
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    mock_module = MagicMock(name='module')
    mock_module.get_bin_path = MagicMock(return_value='fake')
    mock_module.run_command = MagicMock(return_value=(0, 'fake', ''))

    mock_LinuxNetwork = LinuxNetwork(mock_module)
    mock_LinuxNetwork.get_interfaces_info = MagicMock(return_value=(['fake'], {'all_ipv4_addresses': ['fake']}))
    mock_LinuxNetwork.get_default_route = MagicMock(return_value=('fake', 'fake'))

    # run the tested method
    res = mock_LinuxNetwork.populate()

    # validate the response
    assert res['interfaces'] == ['fake']

# Generated at 2022-06-11 03:43:01.871008
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    assert LinuxNetwork.get_default_interfaces(None) == {'v4': {'gateway': '192.168.1.1'}, 'v6': {'gateway': 'fe80::c854:16ff:fe22:b134'}}

# Generated at 2022-06-11 03:43:10.928437
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Setup
    default_ipv4 = {'address':'10.0.0.1'}
    default_ipv6 = {'address':'10::1'}
    # ip command must not exist on the system to test the fallback
    os.environ['PATH'] = ':'.join(['/nonexistent', os.environ['PATH']])
    m = AnsibleModule(argument_spec={'default_ip': {'type': 'str'}})
    ln = LinuxNetwork(m)
    # Returns
    interfaces_info, ips_info = ln.get_interfaces_info('/bin/ip', default_ipv4, default_ipv6)
    assert interfaces_info['lo']['ipv4']['address'] == '127.0.0.1'

# Generated at 2022-06-11 03:43:12.310993
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # TODO: implement unit test
    pass


# Generated at 2022-06-11 03:43:22.506124
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """Unit test for the LinuxNetwork.get_interfaces_info method"""
    # NOTE: The following implementation was copied from the function definition.
    # NOTE: I had to add a "return" statement which is not present in the real method.
    # NOTE: I also had to add some imports, because they are not present in the test file.
    # TODO: import statements could be added to the top of the file.
    import os
    import glob

    interfaces = {}
    ips = {}

    for path in glob.glob('/sys/class/net/*'):
        if not os.path.isdir(path):
            continue
        device = os.path.basename(path)
        # TODO: use a different mock object for this, e.g. a pure dictionary.
        # TODO: maybe even add a pure dictionary as a

# Generated at 2022-06-11 03:43:29.644509
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    n = LinuxNetwork()
    # FIXME: mock
    n.module = MockModule()
    n.module.run_command = lambda args: (0, 'Key: foo', '')
    assert n.get_ethtool_data('eth1') == {'features': {'foo': 'on'}}

    n.module.run_command = lambda args: (0, '', '')
    assert n.get_ethtool_data('eth1') == {}

    n.module.run_command = lambda args: (1, '', '')
    assert n.get_ethtool_data('eth1') == {}
# /Unit test for method get_ethtool_data of class LinuxNetwork


# Generated at 2022-06-11 03:43:33.682218
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # get a LinuxNetwork object
    obj = LinuxNetwork(module)

    obj.populate()

    # check the result
    assert isinstance(obj.facts, dict)
    assert len(obj.facts) > 0



# Generated at 2022-06-11 03:44:18.951312
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    '''Test get_ethtool_data method of LinuxNetwork'''
    # Set up the fake target
    fake_file = "/proc/config.gz"
    fake_exitcode = 0
    fake_output = 'CONFIG_NET_PKTGEN=m\nCONFIG_NET_TCPPROBE=y'

    # Set up the fake module
    fake_module = MagicMock()
    fake_module.run_command.return_value = (fake_exitcode, fake_output, None)

    # Set up the fake module
    setattr(fake_module, "get_bin_path", lambda x: '/usr/sbin/ethtool')

    # Run the get_ethtool_data method
    net = LinuxNetwork(fake_module)

# Generated at 2022-06-11 03:44:29.037422
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    args = [
        '/sbin/ip',
        '-4',
        'addr',
        'show',
        'primary',
        'lo',
    ]
    rc = 0
    out = b'''\
1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default 
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host 
       valid_lft forever preferred_lft forever
'''
    err = b''

# Generated at 2022-06-11 03:44:38.548659
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    test_module = AnsibleModule(argument_spec={})
    test_LinuxNetwork = LinuxNetwork(test_module)


# Generated at 2022-06-11 03:44:48.734464
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # mock out linux_system:
    class MockModule(object):
        def __init__(self):
            self.params = dict(
                use_ipv6=True,
            )

        def get_bin_path(self, executable):
            return executable

        def run_command(self, args, **kwargs):
            if args[0] == "ip" and args[1] == "route" and args[2] == "get":
                return (0, "1.2.3.4 via 1.2.3.5 dev eth0", "")
            return (0, "", "")

    module = MockModule()
    # construct the LinuxNetwork object
    network = LinuxNetwork(module)
    # run populate
    network.populate()

    # did we set interface address with ip route?

# Generated at 2022-06-11 03:44:58.611292
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # "module" instance for AnsibleModule
    module = AnsibleModule(supports_check_mode=True)
    # Create a "dummy" instance for testing of LinuxNetwork class
    linux_network = LinuxNetwork(module)
    # Call the populate method of the instance
    linux_network.populate()

    # Check attributes of the instance
    assert isinstance(linux_network.interfaces, dict)
    assert isinstance(linux_network.routes, dict)
    assert isinstance(linux_network.default_ipv4, dict)
    assert isinstance(linux_network.default_ipv6, dict)
    assert isinstance(linux_network.ips, dict)

    for _, iface in linux_network.interfaces.items():
        assert isinstance(iface, dict)
        assert 'type' in iface

# Generated at 2022-06-11 03:45:08.110182
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    class ModuleTest(object):
        def get_bin_path(self, *args, **kwargs):
            return 'ip'
        def run_command(self, *args, **kwargs):
            return 0, """
127.0.0.1   127.0.0.1   255.0.0.0   lo
192.168.1.1 192.168.1.1 255.255.255.255 eth0
3ffe:ffff:0:f101::1 3ffe:ffff:0:f101::1 64 eth0
""", ''
    class FakeModule(object):
        def __init__(self):
            self.params = dict(
                config=dict(
                    content='',
                    src='/etc/network/interfaces',
                ),
            )
            self.test = ModuleTest()

    fake

# Generated at 2022-06-11 03:45:17.081601
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = get_module()
    ln = LinuxNetwork(module)

    path = ln.module.get_bin_path('ethtool')

# Generated at 2022-06-11 03:45:26.273774
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    rendering = dict()
    rendering['default_ipv4'] = dict()
    rendering['default_ipv6'] = dict()
    class_object = LinuxNetwork(dict())
    class_object.get_interfaces_info('ip', rendering['default_ipv4'], rendering['default_ipv6'])
    assert_true(isinstance(rendering, dict))
    # print('rendering: %s' % str(rendering))
    assert_false(rendering == dict())
    assert_false(rendering['default_ipv4'] == dict())
    assert_true(rendering['default_ipv4'] == {'address': '127.0.0.1', 'prefix': None})
    assert_true(rendering['default_ipv6'] == {'address': '::1', 'prefix': None})


# Generated at 2022-06-11 03:45:32.072245
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )
    instance = LinuxNetwork(module)
    result = instance.populate()
    module.exit_json(**result)

# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.facts import *
from ansible.module_utils.ec2 import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-11 03:45:34.482088
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module=module)
    ln.populate()