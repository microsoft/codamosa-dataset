

# Generated at 2022-06-11 03:36:20.377982
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """
    Test LinuxNetwork.get_interfaces_info
    """
    class TestArgs(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path
        def get_bin_path(self, cmd, required=False):
            return self.bin_path
    class TestModule(object):
        def __init__(self, bin_path, params):
            self.params = params
            self.args = TestArgs(bin_path)
        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception("fail_json called")

# Generated at 2022-06-11 03:36:27.984680
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.network.common.utils import get_interface_dict
    # NOTE: We're skipping this test on Windows since it is Linux specific.
    if os.name != 'nt':
        # NOTE: This is a terrible way of accomplishing this!!
        ln = LinuxNetwork()
        default_ipv4 = {"address": "10.194.122.126"}
        default_ipv6 = {"address": "2001:4800:7818:101:be76:4eff:fe04:a2c1"}

        interfaces_dict = get_interface_dict('Linux')
        interfaces_exp = load_fixture("get_interfaces_info_linux.txt")


# Generated at 2022-06-11 03:36:39.842720
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Destructive actions are disabled in this unit test
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(type='list')
    })

    linux_network = LinuxNetwork(module)
    # Call the method under test
    linux_network.populate()

    # assert call is made with expected args
    module.get_bin_path.assert_called_with("ip", opt_dirs=['/sbin', '/usr/sbin', '/usr/local/sbin'])
    module.get_bin_path.assert_called_with("ethtool", opt_dirs=['/sbin', '/usr/sbin', '/usr/local/sbin'])

    # assert correct data is returned
    assert linux_network.interfaces
    assert linux_network.default_ipv4

# Generated at 2022-06-11 03:36:51.506607
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    net = LinuxNetwork(module)

# Generated at 2022-06-11 03:36:59.230538
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    '''
    Function to test get_default_interfaces
    '''
    test_class = LinuxNetwork()

    # Check for IPv4:
    out = {'ipv4': {'default_interface': 'enp2s0', 'default_gateway': '192.168.1.1'}, 'ipv6': {}}
    rc, my_out, err = test_class.get_default_interfaces(None, None)
    if not rc and my_out == out:
        return (True, 'unit test succeeded')
    else:
        return (False, 'unit test failed')


# Generated at 2022-06-11 03:37:09.709650
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch
    from ansible.utils.path import unfrackpath

    mock_module = MagicMock()

    with patch("ansible_collections.ansible.netcommon.plugins.module_utils.network.common.linux.base.get_file_content") as mock_get_content:
        # default route
        mock_get_content.return_value = "0.0.0.0 192.168.0.1 0.0.0.0 UG 0 0 0 enp3s0"
        LinuxNetwork(mock_module).get_default_interfaces(command={4: ['ip', '-4', 'route', 'show', 'default']}, interface={4: {}, 6: {}})

# Generated at 2022-06-11 03:37:17.473988
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec=dict())
    d = '[' + '\n'.join((
        '{0}: {{}}'.format(device) for device in ["lo", "eth0", "eth1", "eth2"]
    )) + ']'
    module.params = {'interfaces': d}
    i = LinuxNetwork(module)
    # TODO: need to mock/stub out the module.run_command(args)



# Generated at 2022-06-11 03:37:22.131578
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    m = AnsibleModule(argument_spec={})
    set_module_args(dict(
        name='test',
        mtu='1500',
        state='present'
    ))
    lnic = LinuxNetwork(m)
    lnic.get_ethtool_data('dummy0')



# Generated at 2022-06-11 03:37:31.402481
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = None
    d = LinuxNetwork(module)

    class FakeDevice(object):
        def __init__(self):
            self.device = 'eth0'
            self.mtu = 1500
            self.macaddress = '01:23:45:67:89:ab'
            self.active = True
            self.module = 'e1000e'
            self.type = 'ethernet'
            self.pciid = '0000:00:1c.1'
            self.speed = 1000
            self.promisc = False


# Generated at 2022-06-11 03:37:41.816014
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-11 03:38:23.280170
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module=module)
    interfaces = network.populate()
    assert_true(module.exit_json.called)
    assert_equal(module.exit_json.call_args[0][0]['ansible_facts']['ansible_all_ipv4_addresses'], [])
    assert_equal(module.exit_json.call_args[0][0]['ansible_facts']['ansible_all_ipv6_addresses'], [])
    assert_equal(module.exit_json.call_args[0][0]['ansible_facts']['ansible_ethtool'], {})

# Generated at 2022-06-11 03:38:34.410421
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    m = AnsibleModule(argument_spec={})
    l = LinuxNetwork(m)
    interfaces, ips = l.get_interfaces_info(None, {}, {})
    key = random.choice(list(interfaces))
    assert len(interfaces[key]) > 0
    assert "ipv4" in interfaces[key]
    assert "device" in interfaces[key]
    assert "type" in interfaces[key]
    if "macaddress" in interfaces[key]:
        assert re.search('([a-fA-F0-9]{2}:){5}[a-fA-F0-9]{2}', interfaces[key]['macaddress'])
    if "ipv4" in interfaces[key]:
        assert "address" in interfaces[key]["ipv4"]
        assert "netmask"

# Generated at 2022-06-11 03:38:44.670530
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module, Class, name = LinuxNetwork, LinuxNetwork, 'LinuxNetwork'
    m = mock.MagicMock()

    for name in ('get_interfaces_counters', 'get_interfaces_ip', 'get_interfaces_info'):
        getattr(m, name).side_effect = [{}, {}, {}]

    setattr(m, 'is_linux', True)
    setattr(m, 'get_bin_path', lambda x: '/usr/bin/ip')

    # Should raise AttributeError if it was invalid
    network_inst = Class(m)
    if network_inst.get_file_content(None):
        raise AssertionError('LinuxNetwork contains invalid method get_file_content')

    # Should raise AttributeError if it was invalid

# Generated at 2022-06-11 03:38:55.345628
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    l = LinuxNetwork()

    def test(expected, device, ethtool_out):
        def mock_run_command(args, errors='strict'):
            if args == ['/sbin/ethtool', '-k', device]:
                return (0, ethtool_out, '')
            raise AssertionError('mock_run_command invoked with args: %r' % args)

        result = l.get_ethtool_data(device)
        if not expected == result:
            raise AssertionError('result: %r\nexpected: %r' % (result, expected))

    # Test single feature, no spaces, multiple lines

# Generated at 2022-06-11 03:39:07.347553
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Test data.
    ipv4_data = b"""
default via 192.168.1.1 dev eth0  src 192.168.1.245
default dev wlan0  scope link
default dev br-lan  scope link
"""
    ipv6_data = b"""
default via fe80::1 dev eth0  metric 1024
default dev wlan0  scope link
default dev br-lan  scope link
"""
    # Test execution.
    candidates = LinuxNetwork().get_default_interfaces(ipv4_data, ipv6_data)
    # Test results.
    assert candidates['default_ipv4']['interface'] == 'eth0'
    assert candidates['default_ipv4']['address'] == '192.168.1.245'
    assert candidates['default_ipv4']['gateway']

# Generated at 2022-06-11 03:39:11.025055
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    # This can return 'lo' on some systems.
    assert ln.default_ipv4['interface']
    assert ln.default_ipv6['interface']


# Generated at 2022-06-11 03:39:21.736796
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """Returns information about all the interfaces on the system."""
    # TODO: make this a real unit test
    module = AnsibleModule(argument_spec={'ip_interfaces': dict(type='dict'),
                                          'default_ipv4': dict(type='dict', default={}),
                                          'default_ipv6': dict(type='dict', default={})})

    ln = LinuxNetwork(module)
    interfaces, ips = ln.get_interfaces_info(module.params['ip_path'], module.params['default_ipv4'],
                                             module.params['default_ipv6'])
    print("Interfaces: {0}".format(interfaces))
    print("IP Addresses: {0}".format(ips))



# Generated at 2022-06-11 03:39:33.429786
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(
            ip_path=dict(default='/bin/ip'),
            ping_path=dict(default='/bin/ping')
        ),
    )
    # FIXME: skip this test on python3 where importlib is non-trivial
    if not HAS_IMPORTLIB:
        module.exit_json(msg='Required importlib not available')
    ip_path = module.params['ip_path']
    ping_path = module.params['ping_path']
    obj = LinuxNetwork(module=module, ip_path=ip_path, ping_path=ping_path)

    # Test without promiscuous interface

# Generated at 2022-06-11 03:39:42.791939
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from ansible.module_utils.facts.collector.network.linux import LinuxNetworkCollector
    from ansible.module_utils.facts.collector.network.linux import LinuxNetwork
    from copy import deepcopy

    # Create instance of LinuxNetwork
    network = LinuxNetwork()

    # Create instance of LinuxNetworkCollector
    network_collector = LinuxNetworkCollector()
    # Check we got the right type
    assert isinstance(network_collector, LinuxNetworkCollector)
    # Check that we passed the right class _fact_class
    assert network_collector._fact_class == LinuxNetwork

    # Make sure we got the right class as FactCollector
    assert network_collector.__class__.__mro__[1] == BaseCollector

    # Make sure we got the right platform

# Generated at 2022-06-11 03:39:52.166995
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-11 03:40:37.239071
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    from ansible.module_utils.network.common.utils import dict_merge

    module = AnsibleModule(argument_spec={})
    default_v4 = {
        'address': '192.168.122.1',
        'broadcast': '192.168.122.255',
        'netmask': '255.255.255.0',
        'network': '192.168.122.0',
    }
    default_v6 = {
        'address': 'fe80::5054:ff:fe9f:d1f',
        'prefix': '64',
        'scope': 'link',
    }

# Generated at 2022-06-11 03:40:39.872407
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    data = ln.get_ethtool_data("eno1")
    assert "features" in data, "features not in %s" % data



# Generated at 2022-06-11 03:40:46.573153
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network_class = LinuxNetwork()
    a = 'b'
    b = 'c'
    linux_network_class.cache = {a:b}
    linux_network_class.populate()
    assert linux_network_class.cache == {a:b}


# Generated at 2022-06-11 03:40:57.413992
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    default_ipv4 = dict()
    default_ipv6 = dict()
    hostname = 'testhost'
    result = dict()

    # Test case 1
    route_output = "default via 10.1.0.1 dev eth0 proto static metric 100\n"
    route_output += "169.254.0.0/16 dev eth0 scope link metric 1000\n"
    route_output += "192.168.0.0/24 dev eth1 proto kernel scope link src 192.168.0.1 metric 100\n"
    route_output += "10.1.0.0/24 dev eth0 proto kernel scope link src 10.1.0.2 metric 100\n"
    route_output += "10.1.0.1 dev eth0 proto static scope link metric 100\n"

# Generated at 2022-06-11 03:41:08.571102
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    m = AnsibleModule(argument_spec=[
        'gather_subset',
        'gather_network_resources',
    ])
    m.exit_json = MagicMock()
    n = LinuxNetwork(m)
    n.get_default_interfaces = MagicMock(return_value={
        'default_ipv4': {'address': '10.0.0.24'},
        'default_ipv6': {'address': '::1'}
    })
    n.get_interfaces_info = MagicMock(return_value=(
        {'a': {}},
        {'all_ipv4_addresses': []}
    ))

# Generated at 2022-06-11 03:41:19.492942
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = MagicMock()
    module.run_command.return_value = (0, '', '')
    network = LinuxNetwork(module)
    network.get_file_content = MagicMock(return_value='10')
    network.get_bin_path = MagicMock(return_value='ethtool')
    network.INTERFACE_TYPE = {
        '1': 'ethernet',
    }

    def mock_glob(pattern):
        return ['/sys/class/net/bond0', '/sys/class/net/bond0']

    glob.glob = mock_glob

    ips = dict(all_ipv4_addresses=[])
    default_ipv6 = dict(address='fe80::5054:ff:fe89:6a71/64')


# Generated at 2022-06-11 03:41:29.458929
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from unittest.mock import patch
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})

    def test_device_is_up(self, device):
        if device == 'lo':
            return True
        elif device == 'eth0':
            return False
        else:
            assert False  # return value not mocked

    def make_glob_path(device):
        return '/sys/class/net/%s' % device


# Generated at 2022-06-11 03:41:40.062050
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from ansible_collections.community.general.tests.unit.compat.mock import patch
    from ansible_collections.community.general.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args
    from ansible_collections.community.general.plugins.modules.network.linux import get_interfaces_info

    module = get_interfaces_info.LinuxNetwork()

    set_module_args({
        '_ansible_check_mode': False
    })

    with patch('ansible_collections.community.general.plugins.modules.network.linux.LinuxNetwork._load_platform_subclass') as mock_load:
        mock_load.return_value = get_interfaces_info.LinuxNetwork()

# Generated at 2022-06-11 03:41:49.252355
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-11 03:41:56.932398
# Unit test for method get_default_interfaces of class LinuxNetwork

# Generated at 2022-06-11 03:42:36.801070
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # FIXME: this is a stub that needs filling out
    assert True == True


# Generated at 2022-06-11 03:42:47.061920
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    network = LinuxNetwork(dict(module=dict(params=dict(config=dict()))))

    # test hostvars

# Generated at 2022-06-11 03:42:56.559248
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    class TestModule(object):
        def __init__(self):
            self.run_command = run_command
            self.get_bin_path = get_bin_path

    l = LinuxNetwork(TestModule())
    default_ipv4 = {}
    default_ipv6 = {}
    # FIXME: stub out the args to get_interfaces_info
    ifaces, ips = l.get_interfaces_info([], default_ipv4, default_ipv6)

    assert 'eth0' in ifaces
    assert ifaces['eth0']['active'] == True

    assert 'lo' in ifaces
    assert ifaces['lo']['active'] == False

    assert 'br0' in ifaces
    assert ifaces['br0']['active'] == True

# Generated at 2022-06-11 03:43:04.217059
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    args = {
        'params': {
            'all_ipv4_addresses': [],
            'all_ipv6_addresses': [],
            'default_ipv4': {'gateway': '192.168.7.1'},
            'default_ipv6': {'gateway': 'fe80::5054:ff:fe23:17b1'},
            'ip_path': '/bin/ip'
        },
        'path': {
            'sys_class_net': '/sys/class/net'
        }
    }
    obj = LinuxNetwork(args)
    for device in ['device1', 'device2']:
        data = obj.get_ethtool_data(device)
        assert 'features' in data
        assert 'timestamping' in data

# Generated at 2022-06-11 03:43:10.176073
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # provide a custom module to mock the module class
    module_mock = MagicMock()
    module_mock.run_command.return_value = (0,
    """
default via 192.0.2.1 dev eth0  proto static
default via 192.0.2.1 dev eth0  proto static
    """, '')
    result = get_default_interfaces(module_mock)
    assert result == dict(v4='eth0', v6='eth0')



# Generated at 2022-06-11 03:43:16.745014
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Perhaps: refactor
    module = type('test', (object,), {})
    setattr(module, 'run_command', lambda *args, **kwargs: (0, '', ''))
    setattr(module, 'get_bin_path', lambda x: True)
    ln = LinuxNetwork(module)
    v4, v6 = ln.get_default_interfaces()
    assert set(v4.keys()) == {'address', 'interface', 'gateway'}



# Generated at 2022-06-11 03:43:26.474406
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule({})
    m = LinuxNetwork(module)
    device = "eth0"
    module.run_command = MagicMock(wraps=module.run_command)

# Generated at 2022-06-11 03:43:28.230063
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linuxnetwork = LinuxNetwork()
    # test with iproute2, should return false
    assert linuxnetwork.populate('ip') == False


# Generated at 2022-06-11 03:43:37.193478
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    ip_path = '/sbin/ip'
    default_ipv4 = {}
    default_ipv6 = {}
    l = LinuxNetwork(dict(module=AnsibleModule(argument_spec=dict())))
    interfaces, ips = l.get_interfaces_info(ip_path, default_ipv4, default_ipv6)
    # Two networks devices are expected
    # Example of 'interfaces' dictionary
    assert len(interfaces) == 2
    assert 'enp2s0f0' in interfaces
    assert 'enp2s0f1' in interfaces
    # Example of 'ips' dictionary
    assert len(ips['all_ipv4_addresses']) == 1
    assert len(ips['all_ipv6_addresses']) == 1

# Generated at 2022-06-11 03:43:37.976194
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    obj = LinuxNetwork.NetworkModule()
    # FI

# Generated at 2022-06-11 03:44:27.447128
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Prepare a module
    module = AnsibleModule(argument_spec=dict())

    # Create a dummy device
    dummy_device = "/dev/null"
    test_features = "features:\n  asdf:  foo\n  bar:  baz\n  moo:  one\n\n  two\n\n"
    rc = 0
    test_timestamping = "SOF_TIMESTAMPING_TX_SOFTWARE (Software-emulated) SOF_TIMESTAMPING_RX_SOFTWARE (Software-emulated) SOF_TIMESTAMPING_SOFTWARE (Software Clock and Timestamp)\nPTP Hardware Clock: 0"
    test_hw_timestamp_filters = "HWTSTAMP_FILTER_NONE"

# Generated at 2022-06-11 03:44:32.895191
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # A Linux system
    module = Mock(spec_set=AnsibleModule)
    module.run_command.side_effect = [
        # LinuxNetwork.get_default_interfaces
        (1, '', "ip executable not found.\n"),
    ]
    with pytest.raises(AnsibleModuleError) as cm:
        LinuxNetwork(module)
    assert cm.match('ip executable not found.\n')



# Generated at 2022-06-11 03:44:42.687884
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    class ModuleStub(object):
        class RunCommandStub(object):
            def __init__(self, rc, stdout, stderr):
                self.rc = rc
                self.stdout = stdout
                self.stderr = stderr
            def run_command(self, args, errors):
                return self.rc, self.stdout, self.stderr

        def __init__(self):
            self.exit_args = (None, None)
            self.rc = 0
            self.stdout = ""
            self.stderr = ""

        def get_bin_path(self, command):
            return "/bin/" + command

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

   

# Generated at 2022-06-11 03:44:52.890722
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # setup:
    fake_module = module_args_builder()
    fake_module.params = {'gather_subset': ['!all', '!min']}
    ln = LinuxNetwork(fake_module, paramiko=None)

    # When:
    # set mocked_interfaces with at least one interface
    # set mocked_default_ipv4 with at least one valid ipv4 dict
    # set mocked_default_ipv6 with at least one valid ipv6 dict
    mocked_interfaces = {'eth0': {'ipv4': None, 'ipv6': None}}
    mocked_default_ipv4 = {'address': '0.0.0.0'}
    mocked_default_ipv6 = {'address': '::'}

    # Then:
    # returned_interfaces['default

# Generated at 2022-06-11 03:44:55.493373
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModuleMock()
    network = LinuxNetwork(module)
    (interfaces, ips) = network.populate()
    assert interfaces
    assert ips


# Generated at 2022-06-11 03:44:59.503492
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Tests that we get ethtool data.
    # We should be modifying this test to mock out the output of the program
    # call.
    test_network = LinuxNetwork()
    result = test_network.get_ethtool_data("device")
    assert "features" in result
    assert "timestamping" in result

# Generated at 2022-06-11 03:45:09.025022
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Assume the sysfs info exist
    # Assume there are no ipv6 addresses
    # Assume there is a default address in the ipv6 output
    # Assume there is a default address in the ipv6 output
    # Assume there is a default address in the ipv6 output
    # Assume there is a default address in the ipv6 output

    class DummyModule(object):
        def __init__(self):
            self.options = {}
            self.params = {}
            self.args = ['eth0', 'my_ip']

        def get_bin_path(self, cmd):
            return "/bin/{0}".format(cmd)


# Generated at 2022-06-11 03:45:17.974701
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    def mock_get_bin_path(self, arg):
        if arg == 'ethtool':
            return '/sbin/ethtool'
        return None

    module = MagicMock()
    module.get_bin_path = mock_get_bin_path

    c = LinuxNetwork()
    c.module = module


# Generated at 2022-06-11 03:45:26.840970
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule({}, {}, check_invalid_arguments=False)
    network = LinuxNetwork(module)

    interfaces = {
        'eth0': {
            'device': 'eth0',
            'type': 'ethernet',
            'macaddress': '00:00:00:00:00:00',
            'mtu': 1500,
            'active': False,
            'module': 'e1000',
        },
    }
    ips = {
        'all_ipv4_addresses': [],
        'all_ipv6_addresses': [],
    }

    interface_info = network.get_interfaces_info(None, {}, {})

    assert interface_info == (interfaces, ips)


# Generated at 2022-06-11 03:45:30.239462
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModuleMock()
    nm = LinuxNetworkCollector(module)
    assert nm.fact_class == LinuxNetwork
    assert nm.platform == 'Linux'
    assert nm.required_facts == {'distribution', 'platform'}
    assert nm.module == module
