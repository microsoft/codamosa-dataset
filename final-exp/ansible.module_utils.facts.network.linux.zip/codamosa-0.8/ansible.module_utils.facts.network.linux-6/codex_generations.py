

# Generated at 2022-06-11 03:36:24.080425
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    """
    Tests for method LinuxNetwork.populate
    """
    print("Test for LinuxNetwork.populate")
    module = mock.MagicMock
    module_result = mock.MagicMock()
    module_result.stdout = ''
    module_result.rc = 0
    module.run_command.return_value = module_result

    module.params = {'gather_subset': ['all']}

    linux_network = LinuxNetwork(module)
    
    # Arrange
    # module.get_bin_path("ip")
    module.get_bin_path.side_effect = ['dummy', 'dummy', module.get_bin_path("ip")]

# Generated at 2022-06-11 03:36:28.381520
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    result = dict(
        changed=False,
        ansible_facts={},
    )
    collector = NetworkCollector.factory(module)
    assert isinstance(collector, NetworkCollector)
    fact_class = collector.fact_class
    facts = fact_class(module)
    result['ansible_facts'] = facts.get_facts()
    module.exit_json(**result)



# Generated at 2022-06-11 03:36:40.412426
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils._text import to_bytes
    from io import StringIO
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six.moves import builtins

    # FIXME: this is a bogus class just to allow access to a protected member
    class MockAnsibleModule(AnsibleModule):
        def __init__(self):
            self.params = dict()

        def get_bin_path(self, path):
            return path

    # FIXME: this is a bogus class to allow access to a protected member
    class MockLinuxNetwork(LinuxNetwork):
        def __init__(self, module):
            self.module = module

        def get_file_content(self, path, default=None):
            if path.endswith('.address'):
                return

# Generated at 2022-06-11 03:36:44.807261
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    assert network.get_ethtool_data("eth0")


# <<INCLUDE_ANSIBLE_MODULE_COMMON>>

# Generated at 2022-06-11 03:36:53.726457
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    c = LinuxNetwork()
    data = c.get_ethtool_data('eth0')
    assert 'features' in data
    assert 'rx_checksumming' in data['features']
    assert data['features']['rx_checksumming'] in ['on', 'off']
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert data['timestamping'] == ['symmetric_l2', 'symmetric_l4']
    assert data['hw_timestamp_filters'] == ['all']
    assert data['phc_index'] == 1


# ===========================================
# Main
#


# Generated at 2022-06-11 03:37:02.715003
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    ln = LinuxNetwork()
    ln.module = module
    ln.ip_path = "/sbin/ip"
    ln.get_default_interfaces_data = lambda:  ({'default_ipv4': {'address': '192.168.3.254', 'metric': 100}, 'default_ipv6': {'address': 'fe80::d077:65ff:fe9b:7f83', 'metric': 100}}, {'all_ipv4_addresses': ['192.168.3.254', '10.4.4.4'], 'all_ipv6_addresses': ['fe80::d077:65ff:fe9b:7f83']})
    ln

# Generated at 2022-06-11 03:37:05.899000
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    ln = LinuxNetwork(None)

    v4, v6 = ln.get_default_interfaces()
    # TODO: assert on output of get_default_interfaces



# Generated at 2022-06-11 03:37:18.410768
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # fake module
    module = Mock()
    # fake ip path
    module.get_bin_path.return_value = "/usr/sbin/ip"
    # fake default ipv4
    default_ipv4 = {'address': '10.0.0.5'}
    # fake default ipv6
    default_ipv6 = {'address': 'fe80::f610:d4ff:fee4:a4f4'}
    # fake path
    fake_path = './unit/module_utils/network/common/tests/interfaces/%s'
    # create the network object
    network_object = LinuxNetwork(module)
    # get the interfaces info
    interfaces, ips = network_object.get_interfaces_info(fake_path, default_ipv4, default_ipv6)



# Generated at 2022-06-11 03:37:28.847109
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    nm = LinuxNetwork(module)
    #test_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), '../../test/unit/module_utils/network/fixtures/ifcfg-eth0')
    #fixture_path = os.path.join(test_path, 'ifcfg-eth0')
    interfaces, ips = nm.get_interfaces_info('/bin/ip',
                                              {'address': '192.0.2.30'},
                                              {'address': '2001:DB8::1'})
    #assert interfaces == {'eth0': {'device': 'eth0',
    #                               'ipv4': {'address': '192.

# Generated at 2022-06-11 03:37:38.592688
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    class FakeModule:
        def get_bin_path(self, name, required=True, opt_dirs=[]):
            bin_path = {
                'ip': '/sbin/ip',
                'ethtool': '/sbin/ethtool',
            }[name]
            if bin_path:
                return bin_path
            else:
                return

    class FakeParser:
        def get_interfaces_info(self, ip_path, default_ipv4, default_ipv6):
            """get the interfaces info from the ip_path"""
            pass

    class FakeIfcfg:
        def get_interface_info(self):
            pass

    # @patch('subprocess.check_output', return_value=("", "", 0))
    # @patch('subprocess.Popen', return_value=True)


# Generated at 2022-06-11 03:38:14.195341
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """This method will create an object of LinuxNetworkCollector"""
    facts = dict(
        distribution=dict(name='', major_version=''),
        platform='Linux'
    )
    module = Mock()
    module.params = dict()
    LinuxNetworkCollector(module, facts)



# Generated at 2022-06-11 03:38:21.226259
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """Approximate unit test for method get_ethtool_data of class LinuxNetwork
    This unit test approximates the implementation of the get_ethtool_data
    method of the LinuxNetwork class.  The unit test will run a real
    ethtool command on the host running the unit test, that may not
    be an accurate representation of the Linux host used in the
    Ansible module.

    The unit test requires that the 'ethtool' command is installed
    on the host running the unit test.
    """

    module = AnsibleModule(
        argument_spec = dict(
            name = dict(required=True, type='str'),
        ),
        supports_check_mode=True,
    )
    linux = LinuxNetwork(module)
    interface = 'lo'

# Generated at 2022-06-11 03:38:32.567630
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    unittest.mock_module.run_command.return_value = (0, "", "")

    module = LinuxNetwork()
    data = module.get_ethtool_data("eth0")
    assert data == {}
    module.module.run_command.assert_called_with([module.module.get_bin_path("ethtool"), '-k', "eth0"], errors='surrogate_then_replace')


# Generated at 2022-06-11 03:38:42.722067
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():

    device = 'eno1'
    # Assumption: ethtool is installed
    ethtool_path = module.get_bin_path("ethtool")
    args = [ethtool_path, '-k', device]
    rc, stdout, stderr = module.run_command(args, errors='surrogate_then_replace')
    assert rc == 0, '''
stdout: {0}
stderr: {1}
'''.format(stdout, stderr)

    # FIXME: find a way to check the real data returned
    ethtool_data = LinuxNetwork(module).get_ethtool_data(device)
    assert 'features' in ethtool_data, '''
Features are not in the ethtool data
'''

    args = [ethtool_path, '-T', device]
    rc, std

# Generated at 2022-06-11 03:38:53.303948
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    ln = LinuxNetwork()
    ln.module.get_bin_path = lambda x: x

    def run_command(command, errors='stop'):
        """Use the command to choose the return tuple"""

# Generated at 2022-06-11 03:39:00.845336
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = Mock()
    result = LinuxNetwork.populate(module)
    assert result['network']['default_ipv4']['interface'] == 'lo'
    assert result['network']['default_ipv6']['interface'] == 'lo'
    assert result['network']['default_ipv4']['address'] == '127.0.0.1'
    assert result['network']['default_ipv6']['address'] == '::1'


# Generated at 2022-06-11 03:39:06.001827
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from io import StringIO
    module_io = StringIO()
    module = AnsibleModule(argument_spec=dict())
    module.fail_json = lambda x: module_io.write(json.dumps(x))
    module.exit_json = lambda x: module_io.write(json.dumps(x))
    m = LinuxNetwork(module)
    m.populate()
    result = json.loads(module_io.getvalue())
    assert result['changed'] == False
    assert 'all_ipv4_addresses' in result['ansible_facts']['ansible_all_ipv4_addresses']
    assert 'all_ipv6_addresses' in result['ansible_facts']['ansible_all_ipv6_addresses']


# Generated at 2022-06-11 03:39:10.490858
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    # NOTE: this is not a real test, just a proof of concept
    ln.populate()
    module.exit_json(meta=ln.meta)

if __name__ == '__main__':
    test_LinuxNetwork_populate()

# Generated at 2022-06-11 03:39:15.844643
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = mock.Mock(name='module_0')
    module.check_mode = False
    module.params = {'config': {}}
    module.run_command = mock.Mock(name='run_command_0')

    setattr(module, 'run_command', check_output_side_effect)

    # Setup mocks
    _module = mock.Mock(name='module_1')
    _module.params = {'config': {}}

    # create instance of class LinuxNetwork with param 'module'
    ln = LinuxNetwork(module)

    # create tempfile to fake file descriptor
    ln.TEMPFILE = tempfile.mktemp()
    open(ln.TEMPFILE, 'w').close()
    ln.IP_PATH = '/sbin/ip'

    # create tempfile to fake file

# Generated at 2022-06-11 03:39:27.128449
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = NetworkModule()
    module.params = {'ipv4': True, 'ipv6': True}
    default_ipv4 = default_ipv6 = {}
    interfaces, ips = get_distribution(module).get_interfaces_info(module, default_ipv4, default_ipv6)
    assert('lo' in interfaces)
    assert('lo' not in default_ipv4)
    assert('lo' not in default_ipv6)
    assert('lo' not in ips['all_ipv4_addresses'])
    assert('lo' not in ips['all_ipv6_addresses'])
    assert('eth0' in interfaces)
    assert(interfaces['eth0'].get('ipv4'))

# Generated at 2022-06-11 03:40:13.884430
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})

    ethtool_path = module.get_bin_path("ethtool")

    class O:
        pass


# Generated at 2022-06-11 03:40:25.229723
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """
    This method test the get_interfaces_info method of
    LinuxNetwork class.

    It is done in 2 steps:

    - Patching the LinuxNetwork._get_interfaces_ip_details method to
      return a predefined value.
    - Use the get_interfaces_info method to check if it returns
      the value returned by the patched method.
    """


# Generated at 2022-06-11 03:40:32.715814
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module_mock = mock.MagicMock()
    # use lsmod as test command - same output on all platforms
    module_mock.get_bin_path.return_value = "/bin/lsmod"
    module_mock.run_command.return_value = (0, "", "")
    linux_network = LinuxNetwork(module_mock)
    res = linux_network.get_interfaces_info("ip", {}, {})
    assert isinstance(res[0], dict)
    assert isinstance(res[1], dict)



# Generated at 2022-06-11 03:40:40.426750
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict()
    )
    module.run_command = Mock(return_value=(0, 'stdout', 'stderr'))
    network = LinuxNetwork(module=module)
    network.populate()
    assert network.interfaces
    assert network.default_ipv4
    assert network.default_ipv6
    if 'iproute2' in network.ipv4_interfaces:
        assert network.ipv4_interfaces['iproute2']['gateway']
    if 'iproute2' in network.ipv6_interfaces:
        assert network.ipv6_interfaces['iproute2']['gateway']


# Generated at 2022-06-11 03:40:53.067784
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    linux = LinuxNetwork(module)


# Generated at 2022-06-11 03:40:57.507928
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Create an instance of the LinuxNetwork object
    obj = LinuxNetwork()
    # Invoke method populate of the object
    rc = obj.populate()
    assert rc == 0
    # Check for correct return type for method populate of the object
    assert isinstance(rc, int)


# Generated at 2022-06-11 03:41:03.401238
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    obj = LinuxNetwork(module)
    default_ipv4, default_ipv6 = obj.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert 'address' in default_ipv4
    assert isinstance(default_ipv6, dict)
    assert 'address' in default_ipv6

# Generated at 2022-06-11 03:41:14.299990
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    global module
    mod, module = None, None

# Generated at 2022-06-11 03:41:19.557838
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = MockAnsibleModule()
    module.get_bin_path = Mock(return_value='/bin/ip')
    module.run_command = Mock(return_value=[0, 'bin', ''])
    default_ipv4 = {'address': '10.0.0.1'}
    default_ipv6 = {'address': '2001:db8:2:2::52'}
    ip_path = '/bin/ip'

    ln = LinuxNetwork(module)
    assert ln.get_interfaces_info(ip_path, default_ipv4, default_ipv6) == ({}, {'all_ipv4_addresses': [], 'all_ipv6_addresses': []})


# Generated at 2022-06-11 03:41:29.537404
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # If a device has no ethtool, or ethtool returns a non-zero, no data is returned
    data = LinuxNetwork.get_ethtool_data({}, 'eth0')
    assert not data
    data = LinuxNetwork.get_ethtool_data({}, 'eth1')
    assert not data
    # Some devices with no features return an empty features section
    data = LinuxNetwork.get_ethtool_data({}, 'eth3')
    assert data == {'features': {}}
    # This device has some features
    data = LinuxNetwork.get_ethtool_data({}, 'eth4')

# Generated at 2022-06-11 03:42:16.489500
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    import pytest

    @pytest.fixture
    def MockedModule(monkeypatch):
        class MockedModule:
            class AnsibleModule:
                pass

            BIN_PATH_DIRECTORY = '/usr/bin'

            def get_bin_path(self, name, required=False, opt_dirs=[]):
                return '/usr/bin/ethtool'

            def run_command(self, args, **kwargs):
                if args[1] == '-k':
                    return 0, 'Features for eth0:\nrx-checksumming: on\ntx-checksumming: off\nnetns-local: on\n', ''

# Generated at 2022-06-11 03:42:25.696556
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    # Create a class to be instantiated in place of Module when running the unit test
    class MockModule(object):
        # setting bin_paths to {} will cause get_bin_path() to skip normal logic and return the passed in path
        bin_paths = {}
        def get_bin_path(self, arg, opt_dirs=[]):
            if arg in self.bin_paths:
                return self.bin_paths[arg]
            return arg

    # Create a class to hold the test results, because python is retarded and
    # won't let you actually return data from a function.
    class TestResults():
        def __init__(self):
            self.success = None
            self.msg = None
            self.details = None

    # Create the results object
    results = TestResults()

    # The input and expected output

# Generated at 2022-06-11 03:42:29.858326
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Somehow args is populated by unittest, not sure how to clear it
    module = AnsibleModule(argument_spec={})
    module.params['gather_network_resources'] = 'all'
    test_net = LinuxNetwork(module)
    test_net.populate()
    # assert here


# Generated at 2022-06-11 03:42:38.173594
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    '''Unit test for method get_ethtool_data of class LinuxNetwork'''
    # pylint: disable=unused-argument,too-many-arguments
    linux_network = LinuxNetwork('', '', '')
    assert linux_network.get_ethtool_data('em1') == {'features': {'udp_fragmentation_offload': 'on', 'tx_checksumming': 'on', 'tx_udp_tnl_csum_segmentation': 'on', 'tx_tcp_tnl_segmentation': 'on', 'tx_vlan_stag_hw_insert': 'on'}}



# Generated at 2022-06-11 03:42:48.106108
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    network = LinuxNetwork()

    # Mocking class
    class MockModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            return "/bin/true"

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None, umask=None, errors='surrogate_then_replace', ignore_errors=False, encoding=None):
            return 0, [], None


# Generated at 2022-06-11 03:42:50.391373
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():

    # No tests yet, it is hard to test this method without fixtures
    # But empty method is better than missing one
    pass



# Generated at 2022-06-11 03:42:59.368468
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    network = LinuxNetwork()
    network.module = FakeModule()
    network.module.params = {
        'bind_host': '0.0.0.0',
        'interfaces': [],
        'config': False,
        'default_ipv4': {},
        'default_ipv6': {},
        'route': [],
        'commands': [],
        'ip_path': '',
    }
    result = network.populate()
    assert len(result.keys()) == 8
    assert result.get('all_ipv4_addresses')
    assert result.get('all_ipv6_addresses')
    assert result.get('default_ipv4')
    assert result.get('default_ipv6')
    assert result.get('gateway_ipv4')

# Generated at 2022-06-11 03:43:08.130173
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec=dict(
        device=dict(type='str', default='eth0'),
    ))

    linux_network = LinuxNetwork(module)

    # Create the ethtool output

# Generated at 2022-06-11 03:43:09.474085
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: implement test
    assert True


# Generated at 2022-06-11 03:43:17.867613
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = MagicMock(
        get_bin_path=MagicMock(return_value=True),
        run_command=MagicMock(return_value=(0, '', ''))
    )
    facter_instance = MagicMock(
        get_fact_dict=MagicMock(return_value={
            "distribution": "RedHat",
            "platform": "Linux"
        })
    )
    ln = LinuxNetworkCollector(module=module, facter_instance=facter_instance)
    assert  ln.distribution == "RedHat"
    assert ln.module == module
    assert ln.facter == ln.facter_instance



# Generated at 2022-06-11 03:44:03.288931
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    # Construct a "mock" LinuxNetwork object.  I.e. an instance containing
    #   all attributes and methods of the LinuxNetwork class but which
    #   does not actually query the operating system.
    linuxnetwork = LinuxNetwork(module)
    # Set an attribute within the "mock" LinuxNetwork to avoid an exception
    #   on the line "ethtool_path = self.module.get_bin_path(\"ethtool\")"
    linuxnetwork.module = {'get_bin_path': lambda x: '/bin/ethtool'}
    # Use the "mock" LinuxNetwork to perform a test of the get_ethtool_data method.
    #   The parameter is the device name.
    #   The expected output of the method is defined below.  I.e. a dictionary

# Generated at 2022-06-11 03:44:06.876363
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Ensure that we can populate a WindowsNetwork object
    n = LinuxNetwork()
    n.get_interfaces_info('/bin/ip',{},{})
    if n.interfaces == {}:
        two_fail('Failed to populates LinuxNetwork object')


# Generated at 2022-06-11 03:44:16.781362
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """Tests for the get_ethtool_data method of the LinuxNetwork class"""
    class FakeModule():
        class FakeRunCommand():
            def __init__(self, nocmd_return=0, cmd_return=0, cmd_stdout=None):
                self.nocmd_return = nocmd_return
                self.cmd_return = cmd_return
                self.cmd_stdout = cmd_stdout
            def run_command(self, cmd, errors='surrogate_then_replace'):
                if cmd[0] == 'nocmd':
                    return self.nocmd_return, '', ''
                else:
                    return self.cmd_return, self.cmd_stdout, ''
        def __init__(self, ethtool_path, ethtool_disable_cmd):
            self.ethtool_

# Generated at 2022-06-11 03:44:27.064611
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Unit test helper objects and mocks
    #
    # NOTE: consider using @patch to mock the following instead of unit_helper.patch
    #
    # get_file_content, get_file_lines, get_mount_size, get_mount_device
    # glob.glob, os.path.exists, os.readlink, os.path.isdir
    #
    # After getting unit_helper.patch working, consider replacing with @patch
    unit_helper = UnitHelper()

    # Test get_interfaces_info

# Generated at 2022-06-11 03:44:29.567941
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    _module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(_module)
    assert ln.get_default_interfaces() == tuple()


# Generated at 2022-06-11 03:44:39.153800
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Note: this test is for the legacy (ansible.module_utils.network) module_utils
    # This is not a full test, just a simple sanity check that we get expected defaults from the legacy module_utils

    test_result = dict(
        changed=False,
        connection=None,
        messages=[],
        resources=None,
    )
    # TODO: load a fake environment
    ln = LinuxNetwork()
    default_ipv4, default_ipv6 = ln.get_default_interfaces()

    # Let's do a quick sanity check to ensure we got something reasonable
    assert default_ipv4['broadcast'] == '255.255.255.255'
    assert default_ipv4['address'] == '127.0.0.1'

# Generated at 2022-06-11 03:44:49.353863
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(
            default_ipv4=dict(type='dict', default=dict()),
            default_ipv6=dict(type='dict', default=dict()),
        )
    )

    # Create fake path to ip command
    fake_ip_path = '/usr/bin/ip'
    fake_ethtool_path = '/usr/sbin/ethtool'

    # Create fake ip command stdout

# Generated at 2022-06-11 03:44:59.252160
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    _ansible_module_setup()
    module = AnsibleModule(
        argument_spec={
            'device': dict(type='str', required=False, default=None),
        },
        supports_check_mode=True
    )
    network = LinuxNetwork(module)
    device = 'lo'
    ethtool_path = network.module.get_bin_path("ethtool")
    if ethtool_path:

        args = [ethtool_path, '-k', device]
        rc, stdout, stderr = network.module.run_command(args, errors='surrogate_then_replace')
        if rc == 0:
            assert 'features' in network.get_ethtool_data(device)
            args = [ethtool_path, '-T', device]
            assert 'timestamping' in network

# Generated at 2022-06-11 03:45:08.809334
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    import platform
    module = AnsibleModule(
        argument_spec=dict(),
    )
    x = LinuxNetwork(module)
    platform_info = platform.system().lower()
    expected = dict()
    # FIXME: dynamic expectations

# Generated at 2022-06-11 03:45:17.802099
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    """
    Unit test for method LinuxNetwork.populate()
    """
    class ConfigModule:
        def __init__(self):
            self.params = {
                'run_command': '/usr/bin/run_command',
                'get_bin_path': lambda program: '/usr/bin/' + program
            }
    config = ConfigModule()
