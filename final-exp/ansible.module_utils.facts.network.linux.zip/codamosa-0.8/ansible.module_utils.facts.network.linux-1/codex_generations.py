

# Generated at 2022-06-11 03:36:17.889665
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
  from ansible.module_utils import basic
  from ansible.module_utils.network.common.utils import load_platform_subclass
  from ansible.module_utils.basic import AnsibleModule

  def get_bin_path(binary):
    return binary


# Generated at 2022-06-11 03:36:26.338909
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec=dict(
        gather_subset=dict(type='list'),
    ))

    obj = LinuxNetwork(module)
    obj.populate()

    assert obj.ansible_facts['ansible_all_ipv4_addresses'] == obj.ips['all_ipv4_addresses']
    assert obj.ansible_facts['ansible_all_ipv6_addresses'] == obj.ips['all_ipv6_addresses']
    assert obj.ansible_facts['ansible_default_ipv4'].get('address') == obj.default_ipv4.get('address')
    assert obj.ansible_facts['ansible_default_ipv6'].get('address') == obj.default_ipv6.get('address')
    assert obj.ansible_

# Generated at 2022-06-11 03:36:34.981890
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = FakeAnsibleModule()
    module.params = {}

    # FIXME: test with functional data in module_utils/basic.py
    # FIXME: test with valid module.check_mode = False
    # FIXME: test with valid module.check_mode = True
    # FIXME: test with valid module.debug = True
    # FIXME: replace module with a mock
    l = LinuxNetwork(module)
    l.get_interfaces_info()


# ===========================================================================
# LinuxDistribution
#
# See module_utils/basic.py for more details
# ===========================================================================


# Generated at 2022-06-11 03:36:47.038501
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    fake_path = module.tmpdir + "/bin"
    os.mkdir(fake_path)

    with open(fake_path + "/ethtool", "w") as f:
        f.write("#!/bin/sh\necho 'ethtool $@'\n")

    os.chmod(fake_path + "/ethtool", 0o755)

    module.params.update({'ansible_ethtool_path': fake_path + "/ethtool"})

    l = LinuxNetwork(module=module)

# Generated at 2022-06-11 03:36:57.562385
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = FakeAnsibleModule()
    class FakeOs(object):
        def __init__(self):
            self.path = FakeOsPath()

    class FakeOsPath(object):
        def __init__(self):
            pass

        def join(self, path1, path2, path3=None, path4=None):
            return "%s/%s/%s/%s" % (path1, path2, path3, path4)

        def isdir(self, path):
            return False

        def realpath(self, path):
            return path

        def islink(self, path):
            return False

        def exists(self, path):
            return False

    # NOTE: glob.glob is an iterable of strings

# Generated at 2022-06-11 03:37:03.055063
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    test_module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    test_module.run_command = MagicMock(return_value=(0, '1.2.3.4', ''))
    test_linux_network = LinuxNetwork(test_module, '/sbin/ip', False)

    assert test_linux_network.get_default_interfaces() == {'ipv4': {'address': '1.2.3.4'}, 'ipv6': {}}


# Generated at 2022-06-11 03:37:15.270265
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module_args = dict(
        gather_subset=['network', 'interfaces'],
    )
    module = AnsibleModule(argument_spec=module_args,
                           supports_check_mode=True)


# Generated at 2022-06-11 03:37:21.695569
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # A dict containing the parameters passed to the module
    module_params = dict()
    # A dict containing facts about the node
    module_facts = dict()
    # An Network instance
    nm = Network(module=AnsibleModule(module_params, module_facts))
    nm.populate()
    # Assert if the default IPv4 address has changed
    assert nm.default_ipv4['address'] == '172.17.0.1'

# Generated at 2022-06-11 03:37:31.151900
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """
    This method is responsible for testing the get_ethtool_data method of the LinuxNetwork class
    :return:
    """

    # Mocking module
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # Mocking mock_run_commands method

# Generated at 2022-06-11 03:37:41.534216
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

    # Test default route - IPv4
    text = '''default via 192.0.2.1 dev eth1  proto static
10.0.0.0/8 via 192.0.2.1 dev eth1  proto static
'''
    check_text = '''default via 192.0.2.1 dev eth1  proto static metric 1
10.0.0.0/8 via 192.0.2.1 dev eth1  proto static metric 1
'''
    result_tup  = ln.get_default_interfaces(text, check_text)
    assert result_tup[0]['interface'] == 'eth1'
    assert result_tup[0]['address'] == '192.0.2.1'



# Generated at 2022-06-11 03:38:08.762912
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    # Test the presence of a module method
    linenet = LinuxNetwork()
    assert callable(getattr(linenet, 'populate'))



# Generated at 2022-06-11 03:38:18.013008
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-11 03:38:28.624192
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    n = LinuxNetwork()
    n.os_version_info()
    n.populate_significant_kernel_module_properties()
    n.populate_kernel_module_properties()
    n.populate_dist_kernel_module_properties()
    n.populate_params_kernel_module_properties()
    n.populate_sysfs_kernel_module_properties()
    n.populate_devpath_kernel_module_properties()
    n.populate_sys_kernel_module_properties()
    n.populate_real_sys_kernel_module_properties()
    n.populate_brctl_kernel_module_properties()
    n.populate_ip_kernel_module_properties()
    n.populate_ifconfig_kernel_module_properties()

# Generated at 2022-06-11 03:38:38.960703
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.linux.network import LinuxNetwork  # noqa

    ln = LinuxNetwork()  # noqa
    ln.module = type('module', (), {})

    # Test that we can get the default route
    ln._run_ip_command = lambda *args: (0, 'default via 10.0.1.1 dev eth0  metric 100  proto static', '')
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4['interface'] == 'eth0'
    assert default_ipv4['gateway'] == '10.0.1.1'
    assert default_ipv6 == {}

    # Test that we can get the default IPv6 route
    l

# Generated at 2022-06-11 03:38:49.314422
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # FIXME: move to separate test file
    from ansible.module_utils.network_lsr_linux import LinuxNetwork
    from ansible.module_utils.network_lsr_linux import Distribution

    class FakeDistribution(Distribution):

        def __init__(self, name='Ubuntu', version='16.04', id='ubuntu', like='debian'):
            self.name = name
            self.version = version
            self.id = id
            self.like = like

    class FakeModule(object):

        def __init__(self):
            self.params = {}
            self.run_command = lambda *args, **kwargs: (0, '', '')

        def get_bin_path(self, exec_name):
            return exec_name

    module = FakeModule()

# Generated at 2022-06-11 03:39:00.795773
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    loadpath = os.path.join(os.getcwd(), "plugins/module_utils/network/linux")
    sys.path.append(loadpath)
    from LinuxNetwork import LinuxNetwork

    # Test with iproute2 that has no output
    lin = LinuxNetwork()
    lin.module.run_command = MagicMock(return_value=[0, '', ''])
    default_ipv4, default_ipv6 = lin.get_default_interfaces()
    assert len(default_ipv4) == 0
    assert len(default_ipv6) == 0

    # Test with iproute2 that has an output without default route
    lin = LinuxNetwork()

# Generated at 2022-06-11 03:39:11.948669
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    ln = LinuxNetwork()
    ln.module = Mock()
    ln.module.run_command.return_value = (0, '', '')
    ln.module.get_bin_path.return_value = True
    ln.module.exit_json.return_value = 0

    ln.populate()
    ln.module.run_command.asert_called_once_with(
        ['ip', 'route', 'get', 'to', 'default']
    )
    ln.module.run_command.reset_mock()

    ln.populate()
    ln.module.run_command.assert_called_once_with(
        ['ip', '-6', 'route', 'get', 'to', '::']
    )
    ln.module.run_command.reset

# Generated at 2022-06-11 03:39:23.193444
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    network = LinuxNetwork(module)

# Generated at 2022-06-11 03:39:34.664896
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    MOCK_INI_PARAMS = {'name': 'mock_interface', 'alias': 'eth0'}

# Generated at 2022-06-11 03:39:40.312339
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})  # noqa: F841
    linux_network = LinuxNetwork(module)
    module.get_bin_path = lambda x: ''
    module.run_command = lambda x, **y: (1, '', '')
    module.fail_json = lambda x: False

    assert linux_network.get_default_interfaces() == ({'default_ipv4': {}, 'default_ipv6': {}}, {})



# Generated at 2022-06-11 03:40:18.466231
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    ln = LinuxNetwork()

    # device not found
    device = 'lo'
    data = ln.get_ethtool_data(device)
    assert data == {}

    # device found
    device = 'eth0'
    data = ln.get_ethtool_data(device)
    assert data != {}

# Generated at 2022-06-11 03:40:29.249675
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    if not HAS_PY2_IPADDR:
        pytest.skip("py2-ipaddr is not installed")

    class RunCommandMock:
        def __init__(self):
            self.commands = []

        def run_command(self, command, errors='surrogate_then_replace'):
            # print(command)
            self.commands.append(command)
            return 0, "", ""
    module = RunCommandMock()

    network = LinuxNetwork(module)

    default_ipv4, default_ipv6 = network.get_default_interfaces()
    assert default_ipv4 == {'address': '', 'netmask': '', 'broadcast': '', 'gateway': ''}

# Generated at 2022-06-11 03:40:38.709606
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    import pytest
    from ..net_tools import NetworkConfig
    from ..net_tools import NetworkInterface

    nc = NetworkConfig()
    nc.config_found = True
    nc.existing_interfaces = {
        'eth0': NetworkInterface(name='eth0'),
        'eth1': NetworkInterface(name='eth1'),
        'eth99': NetworkInterface(name='eth99'),
        'eth100': NetworkInterface(name='eth100'),
        'eth0:0': NetworkInterface(name='eth0:0'),
    }

    ln = LinuxNetwork(module=None)
    ln.ethtool_path = '/bin/true'
    ln.config = nc

    # positive tests
    assert ln.get_ethtool_data('eth0:0') == {}
    assert ln.get_

# Generated at 2022-06-11 03:40:49.212737
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec=dict())

    # Mock module inputs
    module._verbosity = 4
    module._socket_path = None
    module._connection = None
    module._shell = None

    # Mock interface state
    network = MockedLinuxNetwork(module)
    with mock.patch.object(network, '_get_interfaces_info', return_value=MockedLinuxNetwork.mock_interfaces_info):
        with mock.patch.object(network, '_get_ip_interface_state', return_value=MockedLinuxNetwork.mock_ip_interface_state):
            network.populate()


# Generated at 2022-06-11 03:41:00.010255
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    class MockModule(object):
        def __init__(self):
            self.params = {}
        def get_bin_path(self, arg):
            return "/bin/ethtool"
        def run_command(self, args, errors='surrogate_then_replace'):
            stdout = stderr = ""
            rc = 0

# Generated at 2022-06-11 03:41:11.283225
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import load_platform_subclass

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )

    if not HAS_SUBPROCESS_COMMUNICATE:
        module.fail_json(msg="Error: subprocess.communicate is required by this module")

    network = load_platform_subclass(LinuxNetwork, module)()
    default_network = network.get_default_interfaces()
    assert default_network['default_ipv4']['address'] == "10.0.0.1"
    assert default_network['default_ipv4']['netmask'] == "255.255.255.0"

# Generated at 2022-06-11 03:41:19.161308
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    collected_facts = CommentedMap()
    facts = {
        'distribution': "CentOS",
        'platform': "Linux",
        'distribution_version': "7.6.1810",
        'distribution_major_version': "7",
        'distribution_release': "Core"
    }

    collector = LinuxNetworkCollector(collected_facts, facts)
    assert collector._platform == 'Linux'
    assert collector.required_facts == {'distribution', 'platform'}
    assert collector._fact_class == LinuxNetwork


# Generated at 2022-06-11 03:41:29.218400
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule({})
    # FIXME: move this to a helper func
    module.exit_json = exit_json
    module.fail_json = fail_json
    module.get_bin_path = get_bin_path
    if not HAS_SYS:
        module.fail_json(msg="Missing required sys module (check python version)")
    if not HAS_IPADDR:
        module.fail_json(msg="Missing required ipaddr module (python-ipaddr)")
    network = LinuxNetwork(module)

    default_ipv4 = {'address': '10.0.0.2'}
    default_ipv6 = {'address': 'fe80::f816:3eff:fe20:57c4'}

# Generated at 2022-06-11 03:41:39.693600
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    network = LinuxNetwork(module)
    is_bridge = False
    is_bonding = False
    is_all_slaves_active = False
    interfaces = {}

    ip_path = None
    default_ipv4 = {"address": "192.168.40.11"}
    default_ipv6 = {"address": "2001:db1::1"}
    interfaces, ips = network.get_interfaces_info(ip_path, default_ipv4, default_ipv6)

    for key, value in interfaces.items():
        if key == 'bridge':
            is_bridge = True
            assert value.get('type') == 'bridge', "Failed to get bridge type."

# Generated at 2022-06-11 03:41:45.902536
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    fake_module = AnsibleModule({})
    # ln is an instance of class LinuxNetwork
    ln = LinuxNetwork(fake_module)
    # data is a dict
    data = ln.get_ethtool_data('eth0')
    assert isinstance(data, dict)
    assert data['features']['tx_checksumming'] == 'off'
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data



# Generated at 2022-06-11 03:42:36.618746
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """Unit test for method get_ethtool_data of class LinuxNetwork."""
    # TODO: make these test cases smaller
    module = None
    ln = LinuxNetwork(module)

    # features

# Generated at 2022-06-11 03:42:44.886025
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda x: x

    class PrivateLinuxNetwork(LinuxNetwork):
        def __init__(self, module):
            self.module = module

        def populate(self):
            return dict(default_ipv4=None, default_ipv6=None, interfaces={}, routing4={}, routing6={})

    linux_network = PrivateLinuxNetwork(module)
    assert linux_network.populate() == {'default_ipv4': None, 'default_ipv6': None, 'interfaces': {}, 'routing4': {}, 'routing6': {}}



# Generated at 2022-06-11 03:42:54.754253
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """Test the return values of method get_interfaces_info of class LinuxNetwork"""
    # FIXME: maybe put this stuff in a mock module?
    # FIXME: can't you pass in an empty module obj?
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

    # for sake of testing, say ethtool exists
    with patch.object(ln, "get_bin_path") as get_bin_path:
        get_bin_path.return_value = "/bin/ethtool"
        module.run_command = MagicMock(return_value=(0, "", ""))
        result = ln.get_ethtool_data("foo")
        assert result == {}

    # for sake of testing, say ethtool exists

# Generated at 2022-06-11 03:43:02.482015
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-11 03:43:08.432228
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # TODO: ADD a way to mock the bin_path in runner to not execute the command
    # TODO: get_bin_path seems to be out of scope...
    results = LinuxNetwork().get_ethtool_data('eth0')

# Generated at 2022-06-11 03:43:11.818730
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )
    print(LinuxNetworkCollector(module).collect())



# Generated at 2022-06-11 03:43:22.012882
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import os
    from ansible.module_utils._text import to_bytes
    mock_module = type('module', (object,), {})()
    mock_module.run_command = lambda x, errors='surrogate_then_replace': (0, '', '')
    mock_module.get_bin_path = lambda x: x
    ln = LinuxNetwork(mock_module)

    # TODO: mock the /proc/net/dev file
    def get_file_content(path, default=None):
        if path == '/sys/class/net/lo/address':
            return '00:00:00:00:00:00'
        elif path == '/sys/class/net/lo/type':
            return '1'

# Generated at 2022-06-11 03:43:30.101437
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    ln = LinuxNetwork(module)
    # NOTE: default_ipv4, default_ipv6 are constructor args
    #   for this class
    default_ipv4 = dict(address='192.168.1.1')
    default_ipv6 = dict(address='fe80::')
    path = "/usr/bin/ip"
    interfaces, ips = ln.get_interfaces_info(path, default_ipv4, default_ipv6)

# Generated at 2022-06-11 03:43:38.724231
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = GenericModule()
    module.params = {}
    module.run_command = MagicMock()
    module.run_command.return_value = 0, '', ''

    m = MagicMock()
    m.return_value = "/sbin/ethtool"
    ln = LinuxNetwork(module, bin_paths={"ethtool": "/sbin/ethtool"})

    ln.module.run_command.return_value = 1, '', ''
    res = ln.get_ethtool_data('')
    assert res == {}

    def side_effect_ethtool_k(*args, **kwargs):
        if args[-1] == 'eth0':
            return 0, 'foo: bar', ''
        else:
            return 0, 'foo: \nbar: baz', ''
    l

# Generated at 2022-06-11 03:43:41.822711
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    linux_network = LinuxNetwork()
    interfaces_info = linux_network.get_interfaces_info('/bin/ip', 'default_ipv4', 'default_ipv6')
    assert interfaces_info is not None


# Generated at 2022-06-11 03:45:04.837409
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-11 03:45:13.939953
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    with mock.patch('ansible_collections.notstdlib.moveitallout.plugins.module_utils.network.common.utils.run_commands') as run_commands:
        run_commands.return_value = [
            { 'stdout': '' }
        ]
        path_exists_mock = mock.MagicMock(return_value=True)
        with mock.patch.multiple('ansible_collections.notstdlib.moveitallout.plugins.module_utils.network.common.utils',
                                 get_file_content=mock.MagicMock(return_value='eth0'),
                                 path_exists=path_exists_mock,
                                 get_bin_path=mock.MagicMock(return_value="/sbin/ip")):
            net_utils = NetworkUt

# Generated at 2022-06-11 03:45:20.950078
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    Test = type('Test', (object,), {})
    Test.run_command = lambda self, a, b: ([0, '127.0.0.1 dev lo  table local  proto kernel  scope host  src 127.0.0.1', ''], '')
    Test.get_bin_path = lambda self, s: None
    iface = LinuxNetwork(Test())
    result = iface.get_default_interfaces()
    assert result[0]['address'] == '127.0.0.1'
    assert result[1]['address'] == '::1'


# Generated at 2022-06-11 03:45:29.781998
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-11 03:45:36.414868
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # create mock module
    module = AnsibleModule(
        argument_spec=dict(
            cli=dict(type="bool", default=False),
            ipv4=dict(type="dict", default={}),
            ipv6=dict(type="dict", default={})
        )
    )

    # add mock module to global namespace so it can be used by tested class
    sys.modules[module_utils.basic._ANSIBLE_ARGS] = module

    # create mock LinuxNetwork object
    linux_network = LinuxNetwork()

    # test success
    def run_command_success(args, **kwargs):
        return 0, "CMDOUT", ""

    with patch.object(LinuxNetwork, "run_command", new=run_command_success):
        result = linux_network.get_default_interfaces()

# Generated at 2022-06-11 03:45:40.699957
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    ln = LinuxNetwork()
    ln.populate()
    assert ln.facts['interfaces'] == {}
    assert ln.facts['default_ipv4'] == {}
    assert ln.facts['default_ipv6'] == {}
    assert ln.facts['gateway_ipv4'] == {}
    assert ln.facts['gateway_ipv6'] == {}

