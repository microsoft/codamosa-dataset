

# Generated at 2022-06-11 03:36:21.356602
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module_name = 'ansible.module_utils.network.common.network_linux'
    module = importlib.import_module(module_name)

    class FakeModule():
        def __init__(self, *args, **kwargs):
            self.run_command = mock.Mock(return_value=(0, '', ''))
            self.get_bin_path = mock.Mock(return_value='/bin/ethtool')

    class FakeClass():
        def __init__(self, *args, **kwargs):
            self.module = FakeModule()
            self.INTERFACE_TYPE = {
                '1': 'loopback',
                '24': 'tunnel',
                '32': 'infiniband',
            }

    linux = FakeClass()
    device = 'enp7s0'

    expected

# Generated at 2022-06-11 03:36:31.293723
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)


# Generated at 2022-06-11 03:36:43.538163
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = Mock()
    module.get_bin_path.return_value = '/bin/ip'
    module.run_command.return_value = 0, '', ''

    data = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    default_ipv4 = dict(
        broadcast=True,
        netmask=True,
        network=True,
        macaddress=True,
        mtu=True,
        type=True,
        alias=True,
    )
    default_ipv6 = dict(
        prefix=True,
        scope=True,
        macaddress=True,
        mtu=True,
        type=True,
    )

    obj = LinuxNetwork(module)

# Generated at 2022-06-11 03:36:54.298794
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-11 03:36:59.879519
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import time
    module = AnsibleModule(argument_spec={})
    module.params = {}
    setup_mock_ansible_module(module, params=module.params)

    linux_network = LinuxNetwork(module)
    default_ipv4 = dict()
    default_ipv6 = dict()

    interfaces = linux_network.get_interfaces_info(time.time(), default_ipv4, default_ipv6)

# Generated at 2022-06-11 03:37:10.566687
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    # mock for module
    module_mock = MagicMock()
    # ip_path should be passed to module.get_bin_path()
    module_mock.get_bin_path.return_value = '/path'
    # the following are the expected calls to module methods from the populate() method
    # module.run_command(["/bin/ip", "route", "show"], errors='surrogate_then_replace')
    # module.run_command(["/path", "address", "show", "dev", "lo"], errors='surrogate_then_replace')
    # module.run_command(["/path", "route", "show", "dev", "lo"], errors='surrogate_then_replace')
    # module.run_command(["/path", "address", "show", "dev", "non_lo"],

# Generated at 2022-06-11 03:37:13.036467
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    l = LinuxNetwork()
    assert l.get_ethtool_data('x') == {}



# Generated at 2022-06-11 03:37:24.629905
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Create a boiler plate module for this test
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda a: a

    # Create a LinuxNetwork class from AnsibleModule
    network = LinuxNetwork(module)

    # Populate the LinuxNetwork object
    network.populate()

    # Gets data from network.default_ipv4 and network.default_ipv6
    default_ipv4, default_ipv6 = network.get_default_interfaces_ip()

    # Get data from network.interfaces
    interfaces = network.interfaces

    # Get data from network.all_ipv4_addresses and network.all_ipv6_addresses
    all_ipv4_addresses, all_ipv6_addresses = network.all_ipv4_addresses, network.all_ip

# Generated at 2022-06-11 03:37:32.734046
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """
    Test method get_ethtool_data(device) for cases:
    * Proper test data
    * No test data
    * More than one line of test data
    * Not enough test data
    """
    # create a test module
    class TestModule(object):
        def __init__(self):
            self.run_called = None
            self.run_command_calls = 0
            self.run_command_args = None
            self.run_command_rcs = []
            self.run_command_stdouts = []
            self.run_command_stderrs = []

        def get_bin_path(self, executable, required=False):
            return 'TestScript'


# Generated at 2022-06-11 03:37:43.123387
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    print("test_LinuxNetwork_get_interfaces_info")
    stdout = load_fixture('ip_addr')
    stdout += load_fixture('ip_addr_secondary')
    ethtool_stdout = load_fixture('ethtool')
    ethtool_stdout2 = load_fixture('ethtool_empty')
    stdout += load_fixture('ip_addr_bond')
    stdout += load_fixture('ip_addr_slave')
    ethtool_stdout3 = load_fixture('ethtool_bond')
    stdout += load_fixture('ip_addr_bridge')
    ethtool_stdout4 = load_fixture('ethtool_bridge')
    stdout += load_fixture('ip_addr_ib')

# Generated at 2022-06-11 03:38:13.974844
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    from ansible.module_utils.network.common.utils import dict_merge
    from ansible.module_utils._text import to_bytes
    # Correct IPv4 address in output of route
    route_output_v4 = u"""default via 192.0.2.1 dev eth0
192.0.2.0/24 dev eth0 proto kernel scope link src 192.0.2.100 metric 1
"""
    # Incorrect IPv6 address in output of route
    route_output_v6 = u"""default via dead:beef::1 dev eth0
dead:beef::1 dev enp0s25 scope link
dead:beef::/64 dev eth0 proto kernel scope link metric 100
""".splitlines()
    # Remove last line of route_output_v6 to test case when no address output
    route_output_v6 = route

# Generated at 2022-06-11 03:38:24.319861
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # pylint: disable=protected-access
    # pylint: disable=no-member
    mod = AnsibleModule({})
    linux_network = LinuxNetwork(mod)

    # This is the Linux command the method is running.
    command = linux_network._LinuxNetwork__get_command('netstat')
    command += ' -nr'

    # os.path.isfile() is being used in the method to determine whether
    # the command is present and therefore executable. This is a dummy
    # replacement for that function
    def _fake_isfile(path):
        # This is to make sure that /bin/netstat exists
        if '/bin/netstat' in path:
            return True
        # This makes sure that the command is not executable
        # to test the method's handling of that scenario
        if command in path:
            return

# Generated at 2022-06-11 03:38:29.598351
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linuxnetwork = LinuxNetwork()
    # Replace this with your own result
    rc, out, err = linuxnetwork.module.run_command('route -n | grep ^0.0.0.0', errors='surrogate_then_replace')

# Generated at 2022-06-11 03:38:39.928870
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Fake class so we can pass it around
    class Module(object):
        def __init__(self, return_values):
            self.return_values = return_values
            self.params = {}

        def get_bin_path(self, *args, **kwargs):
            return "/bin/ip"

        def run_command(self, args):
            #return rc, out, err
            # TODO: add support for stderr
            return_value = self.return_values.pop(0)
            if isinstance(return_value, int):
                return return_value, "", ""
            return 0, return_value, ""

    # Sample output of ip addr show dev eth0 primary

# Generated at 2022-06-11 03:38:50.160330
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """
    Test the get_ethtool_data method with the real ethtool
    """
    from ansible.utils.path import unfrackpath
    network_module = LinuxNetwork()
    network_module.module = Mock(module_utils.basic._AnsibleModule())
    network_module.module.run_command.return_value = (0, unfrackpath(__file__, 'network_data/ethtool_k_01.txt'), '')
    network_module.module.run_command.return_value = (0, unfrackpath(__file__, 'network_data/ethtool_T_01.txt'), '')
    result = network_module.get_ethtool_data('ens160')
    assert result['features']['ntuple'] == 'off'
    assert result['features']['tx_checksumming']

# Generated at 2022-06-11 03:38:56.852714
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # instantiate collector with the required facts
    # NOTE: we don't actually care about the values here
    collector = LinuxNetworkCollector(dict(platform="Linux", distribution="RedHat"))

    # test for required_facts
    assert LinuxNetworkCollector.required_facts == set(['distribution', 'platform'])

    # test for fact_class
    assert collector.fact_class == LinuxNetwork

    # test for platform
    assert collector.platform == 'Linux'

# Generated at 2022-06-11 03:39:07.060573
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.check_mode = True
    module.exit_json = lambda x: sys.stdout.write(repr(x))

    real = {
        'lookup': 'populate',
        'default_ipv4': dict(),
        'default_ipv6': dict(),
        'interfaces': dict(),
        'all_ipv4_addresses': [],
        'all_ipv6_addresses': [],
    }
    expected = dict(changed=False, ansible_facts=real)
    ln = LinuxNetwork(module)
    assert(ln.populate() == expected)



# Generated at 2022-06-11 03:39:17.554968
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.run_command = Mock(return_value=(0, "foo", ""))

    # Test with valid all_ipv4_addresses
    ln = LinuxNetwork(module)
    ifaces = dict(
        eth0={}, eth1={},
        eth0_0={}, eth0_1={}, eth0_1_0={}, eth0_1_1={},
        tap0={}, tap1={}, tap2={}, tap3={},
        bond0={}, bond1={}, bond2={}, bond3={},
        br0={}, br1={}, br2={}, br3={},
    )

# Generated at 2022-06-11 03:39:28.812602
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-11 03:39:37.879795
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils import basic
    from collections import namedtuple
    FakeModule = namedtuple('FakeModule', ['run_command', 'get_bin_path'])
    module = FakeModule(
        run_command=lambda *args, **kwargs: (0, '', ''),
        get_bin_path=lambda *args, **kwargs: ''
    )
    module.fail_json = lambda **kwargs: None
    linux_network = LinuxNetwork(module)
    linux_network.is_ipv6_sysctl_disabled = lambda: False
    interfaces = linux_network.get_interfaces_info(None, {}, {})
    assert interfaces



# Generated at 2022-06-11 03:40:02.057999
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network = LinuxNetwork()
    interface = 'lo'
    expected = {'features': {'rx_all': 'off'}}
    actual = linux_network.get_ethtool_data(interface)
    assert actual == expected



# Generated at 2022-06-11 03:40:11.677039
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    import unittest.mock
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule(AnsibleModule):
        def __init__(self):
            self.exit_json = unittest.mock.MagicMock()
            self.run_command = unittest.mock.MagicMock()

    module = FakeModule()
    network = LinuxNetwork(module)

    # If ethtool is not available, return dict without features
    device = 'eth0'
    module.get_bin_path.return_value = None
    expected = {}
    assert network.get_ethtool_data(device) == expected

    # If ethtool is available, return dict of features
    module.get_bin_path.return_value = '/usr/bin/ethtool'

# Generated at 2022-06-11 03:40:23.042306
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})

    # Test OK
    # Setup LinuxNetwork with a non-None `ethtool_path`
    mock_module = MagicMock(**{'debug.side_effect': None})
    test_obj = LinuxNetwork(mock_module)
    test_obj.module.get_bin_path = MagicMock(return_value='/usr/bin/ethtool')

    mock_run_command = MagicMock(return_value=(0, '', ''))
    test_obj.module.run_command = mock_run_command

    # Test method
    device = 'eth0'
    ethtool_data = test_obj.get_ethtool_data(device)

    assert 'features' in ethtool_data, "Failed to get features from get_ethtool_data"
   

# Generated at 2022-06-11 03:40:33.424643
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import tempfile
    import shutil

    # Test that the output of the method is a dict containing the expected keys
    ln = LinuxNetwork()
    ln.module = FakeModule()
    fake_etc = tempfile.mkdtemp()
    fake_sys = tempfile.mkdtemp()
    ln.module.get_bin_path = lambda x: "/bin/%s" % x
    _get_file_content = lambda x: open(x, 'r').read()
    ln.get_file_content = lambda x: _get_file_content(x)
    ln.get_default_interfaces = lambda: ({'default_ipv4': {'gateway': '172.16.42.1'}}, {'default_ipv6': {'gateway': 'fe80::1'}})
   

# Generated at 2022-06-11 03:40:41.703172
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    if not HAS_NETIFACES:
        module.fail_json(msg='netifaces is required for this module.')
    if platform.system() == 'Linux':
        linuxnet = LinuxNetwork(module)
        (default_ipv4, default_ipv6) = linuxnet.get_default_interfaces(module)
        if default_ipv4['address']:
            module.exit_json(ansible_facts={'ansible_default_ipv4': default_ipv4})
        else:
            module.exit_json(ansible_facts={'ansible_default_ipv4': {'address': '127.0.0.1'}})
    else:
        module.fail_json(msg='This module is not supported on this platform')

# Generated at 2022-06-11 03:40:53.579963
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """Test whether the constructor of the `LinuxNetworkCollector` class is returning a usable object"""
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_mount_points
    from ansible.module_utils.facts.utils import get_file_content

    module = object()
    collector = LinuxNetworkCollector(module, [])
    # pylint: disable=protected-access
    assert isinstance(collector, BaseFactCollector)
    assert collector._platform == 'Linux'
    assert collector.required_facts == set(['distribution', 'platform'])
    assert collector.module is module


# Generated at 2022-06-11 03:41:01.615591
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces_info()
    interfaces, ips = ln.get_interfaces_info(None, default_ipv4, default_ipv6)
    ln.populate(interfaces, ips, None, None)
    assert ln.data['default_ipv4']['interface'] == default_ipv4['interface']

# Testing that populating the default interface does not cause a crash

# Generated at 2022-06-11 03:41:12.684019
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from ansible.module_utils._text import to_bytes

    class MockNetworkInterface(object):
        def __init__(self):
            self.params = {}
            self.module = self

        def fail_json(self, *args, **kwargs):
            pass

        def get_bin_path(self, executable, required=False):
            return '/bin/' + executable

        def run_command(self, args, **kwargs):
            status = 0

# Generated at 2022-06-11 03:41:20.450120
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    module.run_command = lambda x: (0, '', '')

    module.get_bin_path = lambda x: '/sbin/ip'
    get_file_content = lambda p: '00:00:00:00:00:00'
    module.get_file_content = get_file_content

    interfaces = LinuxNetwork(module).get_interfaces_info('', dict(), dict())[0]
    assert len(interfaces) > 0

# Generated at 2022-06-11 03:41:30.206875
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import Mock

    # We need to mock all required variables and functions that the
    # LinuxNetworkCollector(NetworkCollector) constructor will try to
    # use.

    # mock the ansible module
    module_mock = Mock()
    module_mock.get_bin_path.return_value = None
    module_mock.run_command.return_value = (0, '', '')

    # instantiate NetworkCollector
    nc = LinuxNetworkCollector(module_mock)
    assert nc.module == module_mock
    assert nc.facts['distribution'] is None

# Generated at 2022-06-11 03:41:56.879538
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    for output_file in ('ipaddr_show', 'ipaddr_show_secondary', 'ipaddr_show_busybox'):
        for default_file in ('default_ipv4', 'default_ipv6'):
            with open(os.path.join(os.path.dirname(__file__), 'linux_network_files', output_file)) as f:
                output = f.read()
            with open(os.path.join(os.path.dirname(__file__), 'linux_network_files', default_file)) as f:
                default = f.read().strip()
            ip_path = "/bin/ip"
            default_ipv4 = {}
            default_ipv6 = {}


# Generated at 2022-06-11 03:42:04.908317
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """get_ethtool_data() returns ethtool info dict"""
    ln = LinuxNetwork()
    ln.module = MockAnsibleModule()
    device = 'foo'

    # FIXME: comment this out
    assert ln.get_ethtool_data(device) == {}
    # FIXME: this is not implemented.
    # TODO: remove this test and the function it's testing?
    # def mocked_run_command(args, **kwargs):
    #     if args == [ethtool_path, '-k', device]:
    #         return 0, FAKE_ETHTOOL_K_STDOUT, ''
    #     if args == [ethtool_path, '-T', device]:
    #         return 0, FAKE_ETHTOOL_T_STDOUT, ''
    #     raise ValueError(args)



# Generated at 2022-06-11 03:42:06.078139
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    assert True



# Generated at 2022-06-11 03:42:16.167297
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    def mock_run_command(args, check_rc=True):
        if args == ['/sbin/ethtool', '-k', 'test0']:
            return 0, test0_ethtool_k, b''
        if args == ['/sbin/ethtool', '-T', 'test0']:
            return 0, test0_ethtool_T, b''
        if args == ['/sbin/ethtool', '-k', 'test1']:
            return 1, b'', b'ethtool: test1: No such device\n'
        raise AssertionError('Unexpected call with args %s' % (args,))

    def mock_get_bin_path(arg):
        return '/sbin/ethtool'


# Generated at 2022-06-11 03:42:25.378752
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # FIXME: refactor to use classes
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    rc, stdout, stderr = module.run_command(['ip', '-f', 'inet', '-o', 'addr', 'show', 'up', 'scope', 'global', '|', 'grep', '-v', '127.', '|', 'sort'])
    default_ipv4, default_ipv6 = network.get_default_interfaces(rc, stdout)
    assert default_ipv4['address'] == '192.168.0.1'
    assert default_ipv4['netmask'] == '255.255.255.0'
    assert default_ipv4['network'] == '192.168.0.0'
    assert default_ipv

# Generated at 2022-06-11 03:42:35.370978
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    try:
        from ansible.module_utils.common.network import LinuxNetwork
    except ImportError:
        raise ImportError("Error importing Module_utils.network.Linux.LinuxNetwork")
    import pytest
    from io import StringIO


# Generated at 2022-06-11 03:42:45.648098
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    def mock_get_file_content(path, default=None):
        if path.endswith('/address'):
            return 'fe:fa:af:fa:ce:fa'
        elif path.endswith('/mtu'):
            return '1500'
        elif path.endswith('/operstate'):
            return 'up'
        elif path.endswith('/device/driver/module'):
            return 'dummy'
        elif path.endswith('/type'):
            return '1'
        elif path.endswith('/bridge'):
            return 'foo'
        elif path.endswith('/speed'):
            return '100'
        elif path.endswith('/flags'):
            return '0x1043'


# Generated at 2022-06-11 03:42:55.333426
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    out_v4_expected = """{
        "macaddress": "00:00:00:00:00:00",
        "broadcast": "10.0.0.255",
        "address": "10.0.0.2",
        "netmask": "255.255.255.0",
        "network": "10.0.0.0",
        "mtu": 1492,
        "type": "ethernet",
        "alias": "eth0"
    }"""
    err_v4_expected = ""


# Generated at 2022-06-11 03:42:58.263327
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})

    # Populate the args from the spec
    args = dict(changed=False, original_message='', message='')
    module.exit_json(**args)

# Generated at 2022-06-11 03:43:05.406052
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    pc = PatchCollection()

    # FIXME: this should all be moved over to a more general-purpose fixture infrastructure

    # gets default_ipv4, default_ipv6
    # returns interfaces, ips
    def fake_get_interfaces_info(self, ip_path, default_ipv4, default_ipv6):
        # TODO: we should just return some fake data for now and remove the rest of this method
        return {}, {}
    pc.add_patch(PathPatch('ansible.module_utils.network.common.Linux.get_interfaces_info', fake_get_interfaces_info))

    # this is only called from get_interfaces_info, but we don't want to patch get_interfaces_info anymore

# Generated at 2022-06-11 03:43:38.107934
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
  from ansible.module_utils.basic import AnsibleModule
  module = AnsibleModule(
      argument_spec=dict(
        gather_subset=dict(required=False, type='list', default=['!all']),
        gather_network_resources=dict(required=False, type='list', default=['all']),
      )
  )
  ln = LinuxNetwork(module)
  ln.populate()
  # Make sure the module didn't fail
  assert not module.fail_json.called
  # Test the behavior of the get_file_content method
  assert ln.get_file_content('/etc/hostname') == 'foo'
  assert ln.get_file_content('/etc/hostname', 'bar') == 'bar'

# Generated at 2022-06-11 03:43:46.849849
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
  import sys
  import StringIO

  mod = __import__("ansible.module_utils.facts.network.linux_net")
  class_to_test = getattr(mod, "LinuxNetwork")

  my_obj = class_to_test()

  # Setup stdout to catch call to print
  stdout_bak = sys.stdout
  try:
    out = StringIO.StringIO()
    sys.stdout = out

    #### TO HERE

    # The code you want to test goes here...

    #### FROM HERE

    sys.stdout = stdout_bak
    out.seek(0)
    content = out.read()
  finally:
    sys.stdout = stdout_bak


# Generated at 2022-06-11 03:43:56.663023
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """Unit tests for method get_interfaces_info of class LinuxNetwork"""

    class FakeModule:
        def run_command(self, cmd, check_rc=True):
            if cmd[:2] == ["ip", "addr"]:
                if len(cmd) == 4 and cmd[1:] == ["addr", "show", "eth0"]:
                    return (0, IP_ADDRESS_SHOW, "")
                if len(cmd) == 5 and cmd[1:] == ["addr", "show", "primary", "eth0"]:
                    return (0, IP_ADDRESS_SHOW, "")
                if len(cmd) == 5 and cmd[1:] == ["addr", "show", "secondary", "eth0"]:
                    return (0, IP_ADDRESS_SHOW_SECONDARY, "")

# Generated at 2022-06-11 03:44:06.395712
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    '''
    Unit test for method populate of class LinuxNetwork
    '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_native

    # FIXME: this mock is just for initialize
    class TestClassLinuxNetwork():
        def __init__(self, module):
            self.module = module
            self.paths = dict(
                ethtool='/sbin/ethtool',
                ip='/sbin/ip',
                route='/sbin/ip',
                ifconfig='/sbin/ifconfig'
            )

# Generated at 2022-06-11 03:44:16.155460
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    """
    Test case get_default_interfaces() of class LinuxNetwork.
    """
    try:
        import mockssocket as socket
    except ImportError:
        import socket


# Generated at 2022-06-11 03:44:26.562793
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # configure module arguments
    args = dict(
        interface_driver=dict(type='str', required=True),
    )
    # instantiate the module object
    module = AnsibleModule(
        argument_spec=args,
        supports_check_mode=True
    )
    # Get a new system
    system = System()

    # Get a new network
    network = LinuxNetwork(module)

    # Get the default interfaces for IPV4 and IPv6
    default_ipv4, default_ipv6 = network.get_default_interfaces()

    # Check the result by comparing against a known value
    assert default_ipv4['address'] == '192.168.61.98'
    assert default_ipv6['address'] == 'fe80::5054:ff:fe14:2ba2'


# Generated at 2022-06-11 03:44:36.056777
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    # use this as a stub for test_Linux_get_all_interfaces_if_ipv4
    module.get_bin_path = lambda _: "/opt/foo"
    network = LinuxNetwork(module)
    # use this to replace the output of 'ip addr show'

# Generated at 2022-06-11 03:44:46.289750
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    test_module = mock.MagicMock()
    test_module.run_command = mock.MagicMock()


# Generated at 2022-06-11 03:44:51.938640
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    m = AnsibleModule({})
    ln = LinuxNetwork(m)
    m.run_command = MagicMock(return_value=(0, '', ''))
    actual = ln.get_ethtool_data('')
    assert 'features' in actual
    assert 'timestamping' in actual
    assert 'hw_timestamp_filters' in actual
    assert 'phc_index' in actual



# Generated at 2022-06-11 03:45:01.507657
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    ln = LinuxNetwork()
    ln.module = MagicMock()
    ln.module.get_bin_path.return_value = '/bin/ethtool'
    ln.module.run_command.side_effect = [
        (0, 'some_feature: off \nother_feature: on\n', ''),
        (0, 'timestamping: some_feature other_feature\nhwtimestamp_filters: some_other_feature\nptp_hardware_clock: 19\n', ''),
        (0, 'some_feature: off \nother_feature: on\n', ''),
        (0, '', ''),
        (0, '', '')]

# Generated at 2022-06-11 03:45:35.961745
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    test_module = AnsibleModule(argument_spec={'gather_subset': dict(type='list', default=['!all'])},
                                supports_check_mode=True)
    test_system = LinuxNetwork(test_module)
    test_data = {
        'default_ipv4': {'address': '192.168.0.1', 'broadcast': '', 'netmask': '', 'network': ''},
        'default_ipv6': {'address': '2001:db8::1', 'prefix': '', 'scope': ''},
    }

# Generated at 2022-06-11 03:45:43.662467
# Unit test for method get_ethtool_data of class LinuxNetwork