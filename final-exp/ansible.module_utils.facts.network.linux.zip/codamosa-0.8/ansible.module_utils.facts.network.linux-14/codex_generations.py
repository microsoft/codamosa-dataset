

# Generated at 2022-06-11 03:36:18.410044
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.basic import env_fallback

    m = AnsibleModule(
        argument_spec=dict(
            default_ipv4=dict(type='dict', fallback=(env_fallback, ['ANSIBLE_NET_DEFAULT_IPV4'])),
            default_ipv6=dict(type='dict', fallback=(env_fallback, ['ANSIBLE_NET_DEFAULT_IPV6'])),
            ip_path=dict(type='path', fallback=(env_fallback, ['ANSIBLE_NET_IP_PATH'])),
            interface=dict(type='str', fallback=(env_fallback, ['ANSIBLE_NET_INTERFACE'])),
        ),
    )

    linux_network = LinuxNetwork()
    linux

# Generated at 2022-06-11 03:36:27.758040
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Setup
    class Module(object):
        def __init__(self):
            self.run_command = MagicMock()

    m = Module()
    m.run_command.return_value = (0, "default via 172.31.254.254 dev eth0\n", '')

    # Call the function
    netinfo = LinuxNetwork(m)
    result = netinfo.get_default_interfaces()
    # Check the result
    assert result == ('eth0', None)

    # Call the function
    m.run_command.return_value = (0, "default via 172.31.254.254 dev eth0 metric 1024 \n", '')
    result = netinfo.get_default_interfaces()
    # Check the result
    assert result == ('eth0', None)

    # Call the function

# Generated at 2022-06-11 03:36:39.563521
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    TEST_GROUP = 'testLinuxNetworkGetInterfacesInfo'

    module = ansible_module_get()
    R = LinuxNetwork(module)

    try:
        # FIXME: this should be a python unit test to support better mocking
        # NOTE: mock_attach_fixture / mock_attach_json are helper methods
        #       defined in ansible/test/unit/module_utils/network.py
        mock_attach_fixture(module, TEST_GROUP, 'get_interfaces_info.stdout')
        mock_attach_json(module, TEST_GROUP, 'get_interfaces_info.json')
        module.exit_json()
    except:  # noqa: E722,B014
        msg = 'Unable to parse ip addr show output with python 3.8'

# Generated at 2022-06-11 03:36:49.095987
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Setup mock module
    module = AnsibleModule(argument_spec=dict())
    module.exit_json = exit_json
    module.fail_json = fail_json

    # Setup mock subprocess to query ip command
    mock_run_command = MagicMock(return_value=(0, '', ''))
    module.run_command = mock_run_command

    # Create an instance of LinuxNetwork and run the test
    linux_network = LinuxNetwork(module)
    assert linux_network.get_default_interfaces() == {'v4': {}, 'v6': {}}
    mock_run_command.assert_called()


# Generated at 2022-06-11 03:36:59.356345
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    import unittest
    class TestLinuxNetworkGetEthertoolData(unittest.TestCase):
        def setUp(self):
            import tempfile
            self.module = MockLinuxNetworkModule()
            self.module.get_bin_path = lambda binary: '/usr/bin/%s' % binary
            self.linux_network = LinuxNetwork(self.module)


# Generated at 2022-06-11 03:37:09.883069
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    m = LinuxNetwork()
    data = m.get_ethtool_data("eno2")
    assert data["features"]['generic-receive-offload'] == 'on'
    assert data["features"]['large-receive-offload'] == 'on'
    assert data["features"]['rx-vlan-offload'] == 'on'
    assert data["features"]['rx-vlan-filter'] == 'off'
    assert data["features"]['tx-vlan-offload'] == 'on'
    assert data["features"]['tx-vlan-stag-hw-insert'] == 'on'
    assert data["features"]['tx-checksumming'] == 'on'
    assert data["features"]['tx-scatter-gather'] == 'on'

# Generated at 2022-06-11 03:37:22.013733
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-11 03:37:25.289447
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    m = AnsibleModuleMock()
    o = LinuxNetwork()
    o.populate(True)
    assert o.current_ipv4['address'] == '192.168.0.1'



# Generated at 2022-06-11 03:37:33.675881
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = exit_json = fail_json = None

    class FakeModule(object):
        params = {}

        def get_bin_path(self, arg):
            return 'ethtool'

        def run_command(self, arg, **kwargs):
            rc = 0

# Generated at 2022-06-11 03:37:43.986217
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = MagicMock()
    network = LinuxNetwork(module)

    # NOTE: get_bin_path returns None
    module.run_commands.return_value = ([], "", 0)
    module.get_bin_path.return_value = None
    default_ipv4, default_ipv6 = network.get_default_interfaces()
    assert default_ipv4 == {}
    assert default_ipv6 == {}

    # NOTE: ip is missing
    module.run_commands.return_value = ([], "", 0)
    module.get_bin_path.return_value = None
    default_ipv4, default_ipv6 = network.get_default_interfaces()
    assert default_ipv4 == {}
    assert default_ipv6 == {}

    # NOTE: ip's output is

# Generated at 2022-06-11 03:38:10.083114
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # test empty input
    assert(LinuxNetwork(None).get_ethtool_data('') == {})



# Generated at 2022-06-11 03:38:18.948729
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    linux_network = LinuxNetwork()
    linux_network.module = mock.MagicMock()

    # Case 1: module.run_command returns rc=0, stdout=None, stderr=None
    # Expected:
    #   dicts for v4 and v6 are empty
    linux_network.module.run_command.return_value = 0, None, None

    v4_dict, v6_dict = linux_network.get_default_interfaces()

    linux_network.module.run_command.assert_called_once_with(
        ['/sbin/ip', '-o', 'route', 'get', 'to', '8.8.8.8'],
        errors='surrogate_then_replace'
    )

    assert v4_dict == {}
    assert v6_dict == {}

   

# Generated at 2022-06-11 03:38:30.055853
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    class module(object):
        @staticmethod
        def run_command(args, **kwargs):
            pass

        @staticmethod
        def get_bin_path(app):
            return app

    m = module()
    ln = LinuxNetwork(module=m)
    interfaces_json_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        'ethtool_output',
        'interfaces.json')
    with open(interfaces_json_path, 'r') as int_file:
        interfaces_json = json.load(int_file)
    assert_type(interfaces_json, dict)

    for interface in interfaces_json:
        for key in interfaces_json[interface].keys():
            if key == 'stp':
                assert_type

# Generated at 2022-06-11 03:38:37.958484
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = Mock(name='module', spec_set=AnsibleModule)
    linux_network = LinuxNetwork(module)
    module.get_bin_path.return_value = '/usr/bin/ethtool'
    actual = linux_network.get_ethtool_data('enp0s25')
    assert actual['features']['tx_checksumming'] == 'on'
    assert actual['timestamping'] == ['tx_hw', 'rx_hw', 'offload']
    assert actual['hw_timestamp_filters'] == ['all']
    assert actual['phc_index'] == 0


# Generated at 2022-06-11 03:38:47.905011
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # mock module and LinuxNetwork class
    module = Mock(name='module')
    class LinuxNetwork:
        def __init__(self, module, **kwargs):
            self.module = module
            self.module.get_bin_path = Mock(return_value=True)
            self.module.run_command = Mock(return_value=(0, "", ""))
    # device data
    device = "dummy0"
    linux_network = LinuxNetwork(module)
    # get device info
    data = linux_network.get_ethtool_data(device)
    # expected result
    expected = {
        "features": {},
        "timestamping": [],
        "hw_timestamp_filters": [],
    }
    assert data == expected



# Generated at 2022-06-11 03:38:58.620220
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """
    Run an integration test of the function get_interfaces_info of the class LinuxNetwork
    """
    # Initialize the parent module object
    module = AnsibleModule(argument_spec={})
    # Initialize the class Network with the parent module object as parent
    linux_network = LinuxNetwork(module)
    # Obtain the class variables
    ip_path, default_ipv4, default_ipv6 = linux_network.get_network_info()
    # Run the method get_interfaces_info
    interfaces, ips = linux_network.get_interfaces_info(ip_path, default_ipv4, default_ipv6)
    print(json.dumps(interfaces, indent=4))
    print(json.dumps(ips, indent=4))



# Generated at 2022-06-11 03:38:59.777804
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    raise NotImplementedError()


# Generated at 2022-06-11 03:39:10.979228
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # set up test
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(type='list', default=[]),
    })
    # module.params
    LinuxNetwork.populate(module)
    # test
    assert 'default_ipv4' in module.exit_json
    default_ipv4 = module.exit_json['default_ipv4']
    assert isinstance(default_ipv4, dict)
    assert 'gateway' in default_ipv4
    assert isinstance(default_ipv4['gateway'], str)
    assert 'ipv6' in module.exit_json
    default_ipv6 = module.exit_json['default_ipv6']
    assert isinstance(default_ipv6, dict)
    assert 'gateway' in default_ip

# Generated at 2022-06-11 03:39:22.194108
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    """
    Unit test for method populate of LinuxNetwork
    """
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import default_collectors
    conf_file = 'unittests_fake/module_utils/ansible/module_utils/network/linux/facts/interfaces.py'
    facts_file = 'unittests_fake/module_utils/ansible/module_utils/facts/facts.py'
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list'),
        ),
        supports_check_mode=True,
    )
    default_collectors.pop('network')
    default_collectors['network'] = [conf_file, 'GatherNetworkFacts']

# Generated at 2022-06-11 03:39:33.796579
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import ansible_collections
    mock_module = ansible_collections.ansible.community.tests.unit.compat.unittest.Mock()
    mock_module.get_bin_path.side_effect = lambda x: '/bin/ip'

# Generated at 2022-06-11 03:40:17.278531
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    mock_module = type('', (), dict())
    mock_module.run_command = MagicMock()
    mock_module.get_bin_path = MagicMock()

    net = LinuxNetwork(mock_module)

    mock_module.run_command.return_value = (0, '', '')
    mock_module.get_bin_path.return_value = '/sbin/ip'

    ret = net.populate()
    assert isinstance(ret, dict)
    assert 'all_ipv4_addresses' in ret
    assert 'all_ipv6_addresses' in ret
    assert 'bootproto' in ret
    assert 'dns' in ret
    assert 'default_ipv4' in ret
    assert 'default_ipv6' in ret
    assert 'gateway' in ret
   

# Generated at 2022-06-11 03:40:28.097586
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    def get_file_content(filepath, default=''):
        assert filepath == '/proc/net/dev'

# Generated at 2022-06-11 03:40:37.901885
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    class MockModule:
        def __init__(self):
            self.params = {}
            self.run_command_values = {}

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            return "/sbin/" + executable

        def run_command(self, args, errors='surrogate_then_replace', check_rc=False):
            return self.run_command_values[str(args)]

    class MockLinuxNetwork:
        def __init__(self, module):
            self.module = module

    module = MockModule()

# Generated at 2022-06-11 03:40:50.091667
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict(
        gather_subset=dict(default=['all'], type='list'),
    ))

    n = LinuxNetwork(module)

    # this is what we are trying to produce, a generic dict
    # from data from a real system

# Generated at 2022-06-11 03:41:01.059206
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from .. import NetworkCollector
    from . import LinuxNetwork
    from . import LinuxNetworkCollector
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils._text import to_text
    import pytest

    collector = LinuxNetworkCollector.LinuxNetworkCollector()
    print('@' * 10)
    print(collector)
    print('@' * 10)
    print(collector.__dict__)
    print('@' * 10)
    assert isinstance(collector, NetworkCollector.NetworkCollector)
    print(to_text(collector.collect()))

# Generated at 2022-06-11 03:41:04.814008
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec=dict())
    network = LinuxNetwork(module)
    device = 'eth0'
    data = network.get_ethtool_data(device)
    assert data is not None

# Generated at 2022-06-11 03:41:15.404174
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec = {})
    l = LinuxNetwork(module)
    device = 'eth0'

# Generated at 2022-06-11 03:41:26.403020
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # pass
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    #
    # initialize
    #
    network = LinuxNetwork(module, dict(configured_provider=dict(), provider=dict(), interfaces=dict(),
                                        routes=dict(), bonds=dict()))
    #
    # examples
    #
    # 'default_ipv4': {},
    # 'default_ipv6': {},
    # 'interface_ip': {'v4': {}, 'v6': {}},
    # 'gateway_ip': {'v4': {}, 'v6': {}},
    # 'interfaces': {},
    # 'all_ipv4_addresses': [],
    # 'all_ipv6_addresses': [],
    #

# Generated at 2022-06-11 03:41:34.662028
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import os
    import sys
    import tempfile

    def mock_run_command(*args, **kwargs):
        if args[0][-1] == "lo":
            rc = 0

# Generated at 2022-06-11 03:41:45.011065
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    import tempfile


# Generated at 2022-06-11 03:42:30.435063
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Initialize the class object
    ln = LinuxNetwork()
    assert ln.get_default_interfaces() == (None, None)

    # Expected out value
    eth0_v4, eth0_v6 = {'address': '10.0.0.100', 'broadcast': '10.0.0.255', 'netmask': '255.255.255.0', 'network': '10.0.0.0', 'interface': 'eth0', 'gateway': '10.0.0.1'}, {'address': 'fe80::5aeb:3fff:fe12:8692', 'prefix': '64', 'interface': 'eth0', 'scope': 'link', 'gateway': 'fe80::5aeb:3fff:fe12:8692', 'autoconf': True}
    eth1

# Generated at 2022-06-11 03:42:40.539356
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    import pytest
    from ansible.module_utils.basic import AnsibleModule, env_fallback
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.network_common import NetworkModule, ComplexList
    from ansible.module_utils.connection import Connection, ConnectionError

    module_name = 'network_linux'

# Generated at 2022-06-11 03:42:50.534869
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule({
        '_ansible_check_mode': True,
    })

    # TODO: get this from a test data file

# Generated at 2022-06-11 03:42:59.482588
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule({})
    linux = LinuxNetwork(module)

    # testing default route
    default_ipv4, default_ipv6, interface_ipv4, interface_ipv6 = linux.get_default_interfaces()
    assert interface_ipv4['interface'] == 'eth0'
    assert interface_ipv6['interface'] == 'eth0'
    assert default_ipv4['address'] == '192.168.56.102'
    assert default_ipv6['address'] == 'fe80::5054:ff:fe12:3456'

    # testing interface ipv4
    interface_ipv4 = linux.get_interface_ipv4('eth1')
    assert interface_ipv4['interface'] == 'eth1'

# Generated at 2022-06-11 03:43:08.306461
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    class Module:
        def __init__(self, name):
            self.name = name
            self.params = {}
            self.paths = {}
        def get_bin_path(self, cmd):
            self.paths.get(cmd)


# Generated at 2022-06-11 03:43:18.239210
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    test_os = 'linux'
    test_module = 'ansible.module_utils.basic.AnsibleModule'
    test_config = dict(
        config_file='/etc/ansible/facts.d/ansible_network.fact',
        default_ipv4=dict(
            address='10.0.0.1',
            netmask='255.255.255.0',
            network='10.0.0.0',
            broadcast='10.0.0.255',
        ),
        default_ipv6=dict(
            address='2001:470:d6ff:1::1',
            scope='global',
            prefix='64',
        )
    )

# Generated at 2022-06-11 03:43:27.541192
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    m = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    # this test setup is kind of complex to mimic how this code is actually
    # used in the core code.  The test side of the code is really so simple
    # that one might think this is overkill, but the real code is more
    # complex.

    # mimicking the real core code (module_common.py), we create our own
    # module object, which is then passed into the instantiation of our class
    p = LinuxNetwork(m)

    # creating our own module class for the class we are testing allows us
    # to replace a method with a test stub which does things like returns
    # values and counts how many times it was called.

# Generated at 2022-06-11 03:43:36.494783
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from units.compat.mock import mock, patch
    from .ansible_module_linux_network import AnsibleModule
    from ansible.module_utils.basic import AnsibleModule

    mock_run_command = mock.Mock()

    def return_code_0(self, args, **kwargs):
        if args == ['ethtool', '-k', 'iface1']:
            return 0, 'offload: fake\nfeature: fake2', ''
        elif args == ['ethtool', '-T', 'iface1']:
            return 0, 'SOF_TIMESTAMPING_fake1 HWTSTAMP_FILTER_fake2 PTP Hardware Clock: 1', ''

    mock_run_command.side_effect = return_code_0

    patch_executable_exists = mock.Mock()


# Generated at 2022-06-11 03:43:38.670515
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    '''Unit test for method get_default_interfaces of class LinuxNetwork'''
    # FIXME: this method is untestable without mocking out subprocess
    pass

# Generated at 2022-06-11 03:43:48.252853
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    class DummyModule:
        def run_command(self, args, errors='surrogate_then_replace'):
            assert args == ['/sbin/ip', 'addr', 'show', 'eth0']

# Generated at 2022-06-11 03:44:31.854368
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule({},{})
    module.run_command = Mock(return_value=(0, 'SOF_TIMESTAMPING_TX_SOFTWARE'))
    module.get_bin_path = Mock(return_value=True)
    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data('eth0') == {
        'features': {},
        'timestamping': ['tx_software'],
        'hw_timestamp_filters': []
    }
    # test non-zero return code
    module.run_command = Mock(return_value=(1, 'No message available'))
    module.get_bin_path = Mock(return_value=True)
    ln = LinuxNetwork(module)

# Generated at 2022-06-11 03:44:39.199276
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    LinuxNetwork = Network()
    assert LinuxNetwork.get_ethtool_data('lo').get('features') == {
        'checksum_offload': 'on',
        'generic_segmentation_offload': 'on',
        'generic_receive': 'on',
        'large_receive_offload': 'off',
        'rx_vlan_offload': 'on',
        'tx_vlan_offload': 'on',
        'ntuple_filters': 'off',
        'receive_hashing': 'off',
        'highdma': 'off'
    }



# Generated at 2022-06-11 03:44:49.395946
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = MagicMock(return_value="/usr/bin/ethtool")

# Generated at 2022-06-11 03:44:54.000689
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    import pprint
    module = AnsibleModule(argument_spec=dict())
    module.params = dict(
        get_default_ipv4=False,
        get_default_ipv6=False
    )
    nm = LinuxNetwork(module)
    facts = nm.populate()
    pprint.pprint(facts)

# Generated at 2022-06-11 03:45:03.673464
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = Mock()
    module.get_bin_path.side_effect = [
        "/usr/bin/ethtool",
        None,
        "/usr/bin/ethtool",
    ]

# Generated at 2022-06-11 03:45:10.424621
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    data = ln.get_ethtool_data('enp0s3')
    assert data['features']['rx_all'] == 'off'
    assert data['features']['tx_checksum_ip_generic'] == 'on'
    assert data['timestamping'] == ['offload', 'tx_software', 'rx_software']
    assert data['hw_timestamp_filters'] == ['all', 'none']
    assert data['phc_index'] == 0



# Generated at 2022-06-11 03:45:12.404089
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # FIXME: create a test instance
    ln = LinuxNetwork()
    ln.get_default_interfaces()



# Generated at 2022-06-11 03:45:20.069209
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    # FIXME: how to expose the interface without requiring a hostname?
    # FIXME: also, this *requires* a network connection and will fail offline
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    obj = LinuxNetwork(module)
    v4, v6 = obj.get_default_interfaces()
    interfaces = obj.get_interfaces_info()
    assert v4['interface'] == interfaces[v4['interface']]['device']
    assert v6['interface'] == interfaces[v6['interface']]['device']


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 03:45:29.023479
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # test IPv4
    net = LinuxNetwork()

# Generated at 2022-06-11 03:45:29.934897
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    pass

