

# Generated at 2022-06-11 03:36:13.202397
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    _module = AnsibleModule(
        argument_spec=dict(),
    )
    _module.params = {}
    _module.run_command = lambda command, check_rc=True, **kwargs: (0, 'real interface\n', '')
    _module.get_bin_path = lambda name: 'real ip'

    network = LinuxNetwork(_module)

    default_v4, default_v6 = network.get_default_interfaces()

    assert default_v4['interface'] == 'real interface'
    assert default_v6['interface'] == 'real interface'



# Generated at 2022-06-11 03:36:23.541431
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # mock module
    module = Mock()
    module.get_bin_path.return_value = True
    # mock subprocess
    stdout = """
    Checksum offload: on
    GSO/GRO onbacklog: off
    GSO/GRO onqueue: on
    Header split: off
    HW timestamping: on
        PTP Hardware Clock: 0
        TX types:
        RX filters:
        Timestamping: hardware
            PTP hardware clock: 0
            PTP hardware clock stepped: no
            PTP hardware clock is adjustable: no
            Hardware Transmit Timestamp Modes: off
            Hardware Receive Filter Modes: none
    """
    subprocess = Mock()
    subprocess.Popen.return_value.returncode = 0
    subprocess.Popen.return_value.communicate.return_value = stdout

# Generated at 2022-06-11 03:36:27.758327
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    test_network = LinuxNetwork(None)
    test_device = "eth1"
    result = test_network.get_ethtool_data(test_device)
    assert 'features' in result
    assert 'timestamping' in result
    assert 'hw_timestamp_filters' in result
    assert 'phc_index' in result



# Generated at 2022-06-11 03:36:39.563375
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    from ansible.module_utils.six import b
    import netaddr

    linux_network = LinuxNetwork()
    # NOTE: this may not work in future, but it does work on CentOS 7

# Generated at 2022-06-11 03:36:51.255539
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    nm = LinuxNetwork()

# Generated at 2022-06-11 03:36:56.816579
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible.module_utils.network.common.utils import load_platform_subclass

    module = AnsibleModule(argument_spec=dict())

    module_network = load_platform_subclass(NetworkModule, 'network')
    module.exit_json(changed=False, module_network=module_network)

if __name__ == '__main__':
    test_LinuxNetwork_populate()

# Generated at 2022-06-11 03:37:06.060963
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    def get_file_content(filename, default=None):
        return "0001.0003.0003"


# Generated at 2022-06-11 03:37:18.464106
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    def get_file_content_fake(path, default=None):
        """
        Fake method for get_file_content.
        Get the content of a file, ignoring comments and blank lines.
        """
        import os
        import re
        content = ''
        path = os.path.realpath(path)
        if path.endswith('/speed'):
            return '1000'
        elif path.endswith('/mtu'):
            return '1500'
        elif path.endswith('/address'):
            return '00:11:22:33:44:55'
        elif path.endswith('/brif/enp0s8'):
            return '.'

# Generated at 2022-06-11 03:37:24.279372
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    _, ips = linux_network.get_interfaces_info('', None, None)
    assert 'all_ipv4_addresses' in ips
    assert 'all_ipv6_addresses' in ips


# Generated at 2022-06-11 03:37:32.554363
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})

    # first test that the function is called with a LinuxNetwork object
    # as it's first argument.
    #
    # Make sure it fails if a non-LinuxNetwork object is passed as the first
    # argument.
    module.fail_json = lambda: None
    with pytest.raises(SystemExit) as pytest_wrapped_e:
        module.run_command = lambda x: (0, "", "")
        LinuxNetwork.get_ethtool_data({}, 'eth0')
    assert pytest_wrapped_e.type == SystemExit
    assert pytest_wrapped_e.value.code == 0

    # Test that we get the expected error code and message when 'ethtool'
    # doesn't exist
    module.fail_json = lambda msg: msg
   

# Generated at 2022-06-11 03:38:06.685824
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    class FakeModule(object):
        def __init__(self):
            self.config = dict()
            self.debug = dict()
            self.log = dict()
            self.run_command = dict()
        def get_bin_path(self, name, required=True):
            return {
                'ethtool': '/sbin/ethtool',
                'ip': '/sbin/ip',
            }[name]
    module = FakeModule()
    ethtool_rc = 0

# Generated at 2022-06-11 03:38:16.397750
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    """
    Test function get_default_interfaces of class LinuxNetwork with valid inputs
    Inputs:
    LinuxNetwork class object
    """
    argument_spec = {"provider": {"required": False, "type": "dict"}, "host": {"required": False, "type": "str"}, "username": {"required": False, "type": "str"}}
    connection = Connection(argument_spec=argument_spec)
    module = AnsibleModule(argument_spec=connection.argument_spec)
    linux_network = connection.get_network_info(module)
    
    expected_response = (('', '', '', '', ''), ('', '', '', '', '', '', ''))
    output_response = linux_network.get_default_interfaces()
    output_response_4 = len(output_response[0])
   

# Generated at 2022-06-11 03:38:20.019047
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    # These are the modules we will be testing
    module = AnsibleModule(supports_check_mode=True)
    network = LinuxNetwork(module)

    # TODO: add more test cases

    module.exit_json(changed=False)



# Generated at 2022-06-11 03:38:31.233956
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    m = LinuxNetwork()

    # Handling null bytes in /sys/class/net/*/speed is broken
    # https://github.com/ansible/ansible/issues/50776
    m.DEBUG = True
    # The following is not set to 100 because the result of int() on the content of /sys/class/net/*/speed is "100"
    speed = 100
    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    device = "test"
    # Create a subdirectory
    path = os.path.join(tmpdir, device)
    os.makedirs(path)
    # Open a file to write the speed value
    speed_file = open(os.path.join(path, "speed"), "w")
    speed_file.write(str(speed))
    speed_file.close()

# Generated at 2022-06-11 03:38:41.078975
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    _module = AnsibleModule(argument_spec={})
    module = _module.params

    l = LinuxNetwork(module)

    # test if the method works with a mock object
    # needs to return a dict with the interface name as key and a dict
    # with the info as value
    mock_interfaces = dict(eth0=dict(address='192.168.1.1'), eth1=dict(address='192.168.2.1'))
    with patch.object(l, 'get_interfaces_infos') as mock_method:
        mock_method.return_value = mock_interfaces
        result = l.get_default_interfaces()
    assert result == mock_interfaces['eth0']


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 03:38:51.332571
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """
    Test method get_ethtool_data
    """
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-11 03:39:00.796558
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    result = linux_network.get_ethtool_data('dummy-eth0')
    assert 'features' in result
    assert isinstance(result['features'], dict)
    assert 'timestamping' in result
    assert isinstance(result['timestamping'], list)
    assert 'hw_timestamp_filters' in result
    assert isinstance(result['hw_timestamp_filters'], list)
    assert 'phc_index' in result
    assert isinstance(result['phc_index'], int)



# Generated at 2022-06-11 03:39:11.948327
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    def get_ip_path():
        return 'ip'


# Generated at 2022-06-11 03:39:18.695439
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    p = LinuxNetwork()
    import ipaddress
    assert isinstance(p.default_ipv4(), ipaddress.IPv4Interface)
    assert isinstance(p.default_ipv6(), ipaddress.IPv6Interface)
    assert isinstance(p.get_interfaces_addresses(), tuple)
    assert isinstance(p.get_interfaces_info("", {}, {}), tuple)
    assert isinstance(p.get_ethtool_data(""), dict)


# Generated at 2022-06-11 03:39:30.295653
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """Unit test for LinuxNetwork.get_ethtool_data()."""
    module = get_module_mock()
    ln = LinuxNetwork(module=module)

    # ethtool_path is Falsey
    assert ln.get_ethtool_data("eno1") == {}

    module.get_bin_path.return_value = "/sbin/ethtool"
    rc = 0

    # ethtool -k returns 1
    module.run_command.return_value = (1, "", "")
    assert ln.get_ethtool_data("eno1") == {}

    # ethtool -k returns 0

# Generated at 2022-06-11 03:40:02.432749
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ip_path = 'ip'
    net = LinuxNetwork(module)
    net.get_default_interfaces(ip_path, None, None)
    # TODO: test output

# Generated at 2022-06-11 03:40:04.140989
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    lnc = LinuxNetworkCollector(module=None)

    assert lnc.fact_class == LinuxNetwork

# Generated at 2022-06-11 03:40:14.115038
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={
    })

    # No ethtool found
    with patch('ansible_collections.ansible.netcommon.plugins.module_utils.network.common.Linux.get_bin_path', return_value=False):
        obj = LinuxNetwork(module)
        obj.get_interfaces_info = MagicMock(return_value=[{}, {}])
        interfaces, ips = obj.populate()
        assert {} == interfaces
        assert {} == ips


# Generated at 2022-06-11 03:40:25.537943
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Create and populate a mock module
    mock_module = Mock(name='ansible_module')

# Generated at 2022-06-11 03:40:35.481343
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    def mocked_read(path, default=None):
        if os.path.basename(path) == 'address':
            return '00:00:00:00:00:00'
        elif os.path.basename(path) == 'mtu':
            return '1500'
        elif os.path.basename(path) == 'operstate':
            return 'up'
        else:
            return default

    default_ipv4 = dict(
        address='192.168.1.1',
        broadcast='192.168.255.255',
        netmask='255.255.0.0',
        network='192.168.0.0',
        macaddress='00:00:00:00:00:00',
        mtu='1500',
    )

# Generated at 2022-06-11 03:40:43.057598
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from ansible.module_utils.six.moves import StringIO
    import sys
    import unittest
    import json

    class TestLinuxNetwork(unittest.TestCase):
        if not (sys.version_info[:2] >= (2, 7) and sys.version_info[:2] < (3, 0)):
            def assertDictContainsSubset(self, sub, d):
                self.assertTrue(d.viewitems() >= sub.viewitems())
        def setUp(self):
            self.module = MockNetwork()
        def tearDown(self):
            pass
        def test_LinuxNetwork_get_ethtool_data_pass(self):
            device = "enp0s8"
            _result = {}

# Generated at 2022-06-11 03:40:54.428636
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})


# Generated at 2022-06-11 03:41:05.415823
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.network.common.utils import dict_merge

    # FIXME: test_LinuxNetwork_get_ethtool_data setUp

    mock_module = ansible_fixture.mock_module
    mock_get_bin_path = ansible_fixture.mock_get_bin_path
    mock_run_command = ansible_fixture.mock_run_command

# Generated at 2022-06-11 03:41:12.587200
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """
    Unit test for LinuxNetworkCollector class constructor
    Raises
    ------
    TypeError
        Throws an exception if the first parameter does not inherit from AnsibleModule
    """
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.network.common.utils import load_provider

    module = AnsibleModule(argument_spec={})

    load_provider(module._name)

    collector = LinuxNetworkCollector(module)
    collector.collect()

# Generated at 2022-06-11 03:41:17.997505
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    n = LinuxNetwork(module)
    n.populate()

    assert type(n.interfaces) is dict
    assert type(n.ips) is dict
    assert type(n.default_ipv4) is dict
    assert type(n.default_ipv6) is dict
    assert type(n.gateways) is dict
    assert type(n.gateway4) is dict
    assert type(n.gateway6) is dict

    assert type(n.interfaces['eth0']['mtu']) is int
    assert type(n.interfaces['eth0']['macaddress']) is str
    assert type(n.interfaces['eth0']['active']) is bool
    assert type

# Generated at 2022-06-11 03:41:50.173464
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    l = LinuxNetwork()
    l.get_ethtool_data('lo')
    l.get_ethtool_data('ethz')



# Generated at 2022-06-11 03:41:56.644700
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    linux_network = LinuxNetwork(module)


# Generated at 2022-06-11 03:42:04.590286
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import sys
    if sys.version_info[0] >= 3:
        from io import StringIO
    else:
        from cStringIO import StringIO

    # Python 3 compability
    try:
        from mock import patch, Mock
    except ImportError:
        from unittest.mock import patch, Mock

    module = Mock()
    module.run_command.return_value = 0, "", ""

    ln = LinuxNetwork(module)
    module.get_bin_path.return_value = "/bin/ip"

# Generated at 2022-06-11 03:42:14.805702
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    import io
    module = FakeAnsibleModule(params={})
    module._socket_path = None

    platform_info = """Linux 3.10.0-327.el7.x86_64
#1 SMP Thu Nov 19 22:10:57 UTC 2015
x86_64 x86_64 x86_64 GNU/Linux
"""

    if_path = 'tests/unit/ansible/modules/network/linux/ansible_test_iface'
    with open(if_path, 'w') as if_file:
        if_file.write("""iface lo inet loopback
iface eth0 inet static
iface eth0 inet6 static
address 192.0.2.1/24
address 2001:db8::1/64
gateway 192.168.1.254
""")

    default_ipv

# Generated at 2022-06-11 03:42:23.652875
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule
    _module = AnsibleModule(
        argument_spec = dict(
            content = dict(),
            path = dict(),
        ),
    )
    _module.get_bin_path = lambda x: x
    _module.run_command = lambda x: (0, '', '')
    obj = LinuxNetwork(_module)
    interfaces = obj.get_interfaces_info('/bin/ip', {}, {})
    assert isinstance(interfaces, tuple)
    (interfaces, ips) = interfaces
    assert isinstance(interfaces, dict)
    assert isinstance(ips, dict)

# Generated at 2022-06-11 03:42:33.798872
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule({}) # DummyModule for testing (has no actual module_args)
    linux_network = LinuxNetwork(module)

    # Generate fake data for testing

    address = '192.168.1.1'
    filename = '/etc/hostname'
    hostname = get_file_content(filename)
    ip_path = linux_network.module.get_bin_path("ip")
    ipv4 = dict(address=address)
    ipv6 = dict(address=address, prefix='15', scope='global')
    default_ipv4 = ipv4
    default_ipv6 = ipv6
    interfaces = linux_network._get_interfaces_info(ip_path, default_ipv4, default_ipv6)

    # TODO: fix the following tests; they are going to fail

# Generated at 2022-06-11 03:42:43.897936
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule({},
                           supports_check_mode=True)
    network = LinuxNetwork(module)
    # Stub methods

# Generated at 2022-06-11 03:42:44.595797
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    assert True

# Generated at 2022-06-11 03:42:54.449964
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    unittest_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    test_data_path = os.path.join(unittest_path, 'test/units/module_utils/linux_network')

    module = AnsibleModule(
        argument_spec=dict(
            ip_path=dict(type='str', default='/sbin/ip'),
            route_path=dict(type='str', default='/sbin/route'),
        ),
        supports_check_mode=True,
    )
    # FIXME: move this to a fixture
    net = LinuxNetwork(module)

    # These values will be tested for default_ipv4 and default_ipv6

# Generated at 2022-06-11 03:43:02.206465
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.network.common.utils import load_provider
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.network.common.utils import to_list

    def get_provider_argument_spec():
        return dict(
            # TODO: fix this
            # https://stackoverflow.com/questions/48317719/cannot-overwrite-existing-dict-key-in-python
            # https://mail.python.org/pipermail/python-dev/2017-March/146861.html
            network_os=dict(type='str', removed_in_version=2.9),
        )


# Generated at 2022-06-11 03:43:40.525566
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    platform_linux = {'system': 'Linux', 'release': '2.6.32-504.8.1.el6.x86_64'}
    module_x = MagicMock(platform=platform_linux)
    module_x.run_command.side_effect = lambda x, **kwargs: [0, '', '']

    o = LinuxNetwork(module_x)
    o.get_default_interfaces()

    # test the module.run_command call, python3 requires bytes for the command variable.
    expected_command = [b"/sbin/ip", b"-4", b"route", b"get", b"8.8.8.8"]
    module_x.run_command.assert_any_call(expected_command)

# Generated at 2022-06-11 03:43:50.511390
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    tempdir = tempfile.mkdtemp()

# Generated at 2022-06-11 03:44:00.231096
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    '''
    Unit test for method LinuxNetwork.populate
    '''

    def mock_get_interfaces_info(ip_path, default_ipv4, default_ipv6):
        '''
        Mock method get_interfaces_info of class LinuxNetwork
        '''

# Generated at 2022-06-11 03:44:09.877692
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = FakeANSIModule()
    anm = LinuxNetwork(module)
    anm.populate()
    # The network module needs to be able to handle "route -n" output with no
    # gateway field.
    module.params = dict(
        config_file='/etc/network/interfaces',
        config_format='ini',
        state='query',
        update_cache=True
    )
    module.run_command = lambda *cmd, **kw: (0, '', '')

# Generated at 2022-06-11 03:44:16.033930
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = type('', (), {})()
    module.run_command = lambda cmd, **kwargs: (0, f'{cmd[-1]}: foo via bar dev baz', '')
    ln = LinuxNetwork(module)
    assert ln.get_default_interfaces() == ({'interface': 'baz', 'address': 'foo', 'gateway': 'bar'}, {'interface': 'baz', 'address': 'foo', 'gateway': 'bar'})

# Generated at 2022-06-11 03:44:26.445934
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import json

    class ReturnValue(object):
        def __init__(self, rc, stdout, stderr):
            self.rc = rc
            self.stdout = stdout
            self.stderr = stderr

    class FakeModule(object):
        def __init__(self):
            self.run_command = mock.MagicMock()

# Generated at 2022-06-11 03:44:35.914356
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    module = AnsibleModuleMock(argument_spec=dict())
    m = LinuxNetwork(module, '')

    class ModuleMock(object):

        def get_bin_path(self, arg):
            if arg == 'ip':
                return '/usr/bin/ip'
            return None

        def run_command(self, arg, errors='surrogate_then_replace'):
            if arg == ['/usr/bin/ip', 'route', 'get', '0.0.0.0']:
                return 0, '0.0.0.0', ''
            raise Exception(arg)

    class Struct(object):

        def __getitem__(self, k):
            return None

    class IPv4Address(object):

        def __init__(self, value):
            self.ip = Struct()
            self.ip

# Generated at 2022-06-11 03:44:46.134194
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    # Patch module object until Ansible 2.8
    module = MagicMock()

    # Patch module exit method to avoid SystemExit exception
    setattr(module, 'exit_json', lambda x: None)

    def run_command(cmd, **kwargs):

        if 'dev' in cmd:
            return 0, '', ''
        if 'bond' in cmd:
            return 0, '', ''
        if 'ethtool' in cmd:
            return 0, '', ''
        if 'ip' in cmd:
            return 0, '', ''
        return 0, '', ''

    module.run_command = run_command

    # Create class instance without __init__
    LinuxNetwork = LinuxNetwork()

    # Override module.get_bin_path

# Generated at 2022-06-11 03:44:56.073163
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    from units.mock.proc import MockProc

    # Setup
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    module.run_command = Mock(return_value=(0, '', ''))
    default_ipv4 = dict()
    default_ipv6 = dict()

    # Test case 1:
    command = ['ip -o -f inet route show default']
    ip_output = [
        'default via 10.0.0.1 dev eth0  src 10.0.0.11 ',
    ]
    ip_output2 = [
        'default dev enp0s3  proto static  metric 100',
    ]

# Generated at 2022-06-11 03:45:05.519286
# Unit test for method get_interfaces_info of class LinuxNetwork