

# Generated at 2022-06-11 03:36:08.345000
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    assert LinuxNetwork.get_ethtool_data('eth0') == dict()


# Generated at 2022-06-11 03:36:10.414209
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    test_subject = LinuxNetwork({}, {}, {})
    assert test_subject.get_ethtool_data('eth0')



# Generated at 2022-06-11 03:36:21.225794
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    LN = LinuxNetwork()

# Generated at 2022-06-11 03:36:31.037947
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    import os
    import sys
    module_path = os.path.normpath(os.path.join(os.path.dirname(__file__), '../../..'))
    if module_path not in sys.path:
        sys.path.append(module_path)
    from unittest.mock import patch


# Generated at 2022-06-11 03:36:43.128149
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from datetime import datetime
    from operator import methodcaller
    import platform
    from unittest import mock

    class MockModule(object):
        def __init__(self, *args, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

        def get_bin_path(self, *args, **kwargs):
            return self.ip_path

        def run_command(self, *args, **kwargs):
            cmd = args[0]
            if cmd[-1] == 'interface':
                return 0, 'interface', None

            if cmd[-1] == 'inet':
                return 0, '192.168.1.1', None

            return 0, 'link/ether', None


# Generated at 2022-06-11 03:36:53.821230
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """
    The expected behavior of this method is as follows:
    If /usr/bin points to a directory and the file 'ethtool' exists in that directory,
    for a given device, if the command 'ethtool -k device' returns a non-zero exit code,
    the method should return an empty dictionary.
    If 'ethtool -k device' returns a zero exit code, the method should return a dictonary
    containing of entries with the key 'features' and a value which is a dict
    containing of key value pairs gathered from the 'ethtool -k device' stdout.
    """
    module = AnsibleModuleMock()
    ethtool_path = '/usr/bin/ethtool'
    device = 'test_device'

# Generated at 2022-06-11 03:37:02.745758
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # /usr/share/doc/ethtool-3.13/examples/{get-default-iface,show-offload}.sh
    import tempfile


# Generated at 2022-06-11 03:37:14.412916
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    m = LinuxNetwork()
    i = dict(
        default_ipv4 = {},
        default_ipv6 = {},
    )
    r = m.populate(i)
    assert 'all_ipv6_addresses' in r[1]
    assert 'all_ipv4_addresses' in r[1]
    assert 'interfaces' in r[0]
    for iface in r[0]['interfaces']:
        assert 'ipv4' in r[0]['interfaces'][iface] or 'ipv4_secondaries' in r[0]['interfaces'][iface] or 'ipv6' in r[0]['interfaces'][iface]
        assert 'device' in r[0]['interfaces'][iface]

# Generated at 2022-06-11 03:37:25.656012
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    ln = LinuxNetwork()

# Generated at 2022-06-11 03:37:29.488666
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class LinuxNetwork"""
    module = AnsibleModule(argument_spec=dict())
    linux_network = LinuxNetwork(module)
    default_ipv4 = dict()
    default_ipv6 = dict()
    assert linux_network.get_interfaces_info('/usr/bin/ip', default_ipv4, default_ipv6)



# Generated at 2022-06-11 03:38:00.458588
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    module_mock = mock.Mock()

# Generated at 2022-06-11 03:38:10.283938
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from ansible.module_utils.network.common.utils import ppp

    """Test function module_utils.network.common.interfaces.get_ethtool_data for method LinuxNetwork.get_ethtool_data
    """

    # Defining test parameters
    device = 'eth0'

    # Defining test class
    class AnsibleModule():

        def get_bin_path(self, arg):
            return "/usr/bin/{0}".format(arg)


# Generated at 2022-06-11 03:38:19.074426
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec=dict())
    module.exit_json = exit_json
    module.fail_json = fail_json
    # assume we're running on a Linux system, so this will work
    ln = LinuxNetwork(module, '/usr/bin/ip')
    ansible_facts = dict()
    ansible_facts['ansible_network_resources'] = dict(interfaces={}, default_ipv4={}, default_ipv6={}, default_interface={}, ips={})
    ansible_facts['ansible_network_resources']['interfaces'], ansible_facts['ansible_network_resources']['ips'] = ln.get_interfaces_info(None, None, None)
    ansible_facts['ansible_network_resources']['default_ipv4'], ansible

# Generated at 2022-06-11 03:38:30.161348
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={'config': dict(default=None, required=False)})
    iface = LinuxNetwork(module)
    # get_default_interfaces
    module._socket_gethostbyname = Mock(return_value="127.0.0.1")
    assert iface.get_default_interfaces() == dict(default_ipv4=dict(address="127.0.0.1",
                                                                    netmask="255.0.0.0",
                                                                    network="127.0.0.0"),
                                                  default_ipv6=None)
    module._socket_gethostbyname = Mock(return_value="::1")

# Generated at 2022-06-11 03:38:40.490322
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    class TestModule(object):
        def __init__(self):
            self.params = dict(
                config_file=None,
                running_config=None,
            )

        def get_bin_path(self, arg, *args, **kwargs):
            return '/sbin/' + arg

    # Setup mocks
    import os
    import glob
    fake_glob = False
    saved_glob = glob.glob
    glob.glob = lambda x: [
        '/sys/class/net/eth0',
        '/sys/class/net/lo',
        '/sys/class/net/fake_net',
    ] if not fake_glob else []

    # glob will return no results so we can test /sys/class/net/* not being present

# Generated at 2022-06-11 03:38:49.175767
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = MagicMock()
    mpath = MagicMock(return_value='/usr/sbin/ethtool')
    module.get_bin_path = mpath
    mrun = MagicMock(return_value=(0, 'SOF_TIMESTAMPING_TX_SOFTWARE\nSOF_TIMESTAMPING_TX_HARDWARE\nPTP Hardware Clock: 0', ''))
    module.run_command = mrun
    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data('dummy0') == {'timestamping': ['tx_software', 'tx_hardware'], 'phc_index': 0}



# Generated at 2022-06-11 03:39:00.634511
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', default=['all']),
        ),
        supports_check_mode=True
    )

    net = LinuxNetwork(module)


# Generated at 2022-06-11 03:39:11.794370
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():

    _module = AnsibleModule(argument_spec={})
    _obj = LinuxNetwork(_module)

    _device = 'eth0'


# Generated at 2022-06-11 03:39:22.979680
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec=dict())

    linux_network = LinuxNetwork(module)
    result = linux_network.populate()
    assert result is not None
    assert result['network']
    assert result['network']['interfaces']
    assert result['network']['ignore_interfaces']
    assert result['network']['default_interface_ipv4']
    assert result['network']['gateway_ipv4']
    assert result['network']['interface_ipv4']
    assert result['network']['default_interface_ipv6']
    assert result['network']['gateway_ipv6']
    assert result['network']['interface_ipv6']
    assert result['network']['interfaces_dict']
    assert result['network']['ips']



# Generated at 2022-06-11 03:39:34.480262
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = object

    # Test get_ethtool_data with a device which has the feature

# Generated at 2022-06-11 03:40:05.678592
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-11 03:40:15.679176
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    ip_path = 'path/to/ip'
    # Modify the module param.
    module = MockLinuxNetworkModule(params={'path': ip_path})
    linux_network = LinuxNetwork(module)
    # Mock the module get_bin_path(cmd) method.
    module.get_bin_path = Mock(return_value=ip_path)
    # Mock the run_command(cmd) method.

# Generated at 2022-06-11 03:40:26.807083
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    def test_get_default_interfaces(content, result, module):
        cmd = "ip -o route get to 1.2.3.4"
        check_args = dict(
            cmd=cmd.split(' '),
            rc=0,
            stdout=content,
            stderr='',
            changed=False,
            rc_succeeds=True,
            check_rc=True,
        )
        module.run_command = mock.Mock(return_value=(0, "", ""))
        module.run_command.side_effect = lambda cmd, **kwargs: (cmd, kwargs)

        n = LinuxNetwork(module)
        assert n.get_default_interfaces(cmd) == result


# Generated at 2022-06-11 03:40:36.772081
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    if not os.path.isfile('/bin/ip'):
        module.fail_json(msg="/bin/ip not found")
    if not os.path.isfile('/sbin/ip'):
        module.fail_json(msg="/sbin/ip not found")

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda a, **b: None

        def fail_json(self, *args, **kwargs):
            self.fail_message = args[0]

    module = FakeModule()
    setattr(module, 'get_bin_path', lambda x: '/bin/ip')
    setattr(module, 'run_command', lambda x: (0, '', ''))


# Generated at 2022-06-11 03:40:43.797640
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # prepare a module for running unit test
    module = AnsibleModule(
        argument_spec=dict(),
    )

    # prepare a test instance of class
    ln = LinuxNetwork(module)

    # Before patching, __init__ should set up a default_ipv4 and default_ipv6
    # These should be NoneType by default
    assert ln.default_ipv4 is None
    assert ln.default_ipv6 is None

    # Mock the get_default_interface method of ln.
    # This method should be called by the get_default_interfaces method.
    # So we need to patch it.
    mock_get_default_interface = mock.MagicMock(return_value={'address': '172.16.0.1'})

# Generated at 2022-06-11 03:40:55.015791
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # initialize the instance since this module is standalone
    instance = LinuxNetwork()

# Generated at 2022-06-11 03:41:00.711792
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from ansible.module_utils.basic import AnsibleModule
    # Dummy module for testing return type of get_ethtool_data
    module = AnsibleModule(
        argument_spec = dict(
            data = dict(required=False, default=None),
        ),
    )
    l = LinuxNetwork(module)
    assert l.get_ethtool_data("dummy") == {}


# Generated at 2022-06-11 03:41:10.505734
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = MockModule()
    module.run_command.return_value = (0, "10.0.0.1 dev eth0  src 10.0.0.2\n    cache  mtu 1500 advmss 1460 hoplimit 64", "")
    linux_network = module.get_bin_path("linux_network")
    linux_network = LinuxNetwork(module)
    default_ipv4, default_ipv6 = linux_network.get_default_interfaces()
    assert default_ipv4 == {'address': '10.0.0.1', 'gateway': '10.0.0.2'}
    assert default_ipv6 == {'address': None, 'gateway': None}



# Generated at 2022-06-11 03:41:17.029223
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    network = LinuxNetwork(module)
    default = network.get_default_interfaces()
    assert default['default_ipv4']['address'] == '192.168.122.173'
    assert default['default_ipv6']['address'] == 'fe80::5054:ff:fe75:e736'



# Generated at 2022-06-11 03:41:22.005920
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    int1, int2 = linux_network.get_default_interfaces()
    assert isinstance(int1, dict)
    assert isinstance(int2, dict)


# Generated at 2022-06-11 03:41:52.297760
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    network = LinuxNetwork(module)
    network.populate()
    assert 'ipv4' in network.default_ipv4
    assert 'ipv6' in network.default_ipv6
    assert 'interfaces' in network.interfaces

# Generated at 2022-06-11 03:41:59.905874
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = Mock(params={})
    module.check_mode = False
    fakes = {}
    fakes['open'] = mock.mock_open(read_data="""
#
# Please read /usr/share/doc/procps/FAQ
#
allow-vm-highmem 1
""")
    fakes['exists'] = lambda path: path.startswith('/')
    fakes['isdir'] = lambda path: path.endswith('brif') or path.endswith('device')
    fakes['isfile'] = lambda path: not path.endswith('brif') and not path.endswith('device')
    fakes['listdir'] = lambda path: ('brif', 'device') if 'bridge' in path else []

# Generated at 2022-06-11 03:42:09.344932
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    M = MockModule()
    ln = LinuxNetwork(M)
    out = ln._get_default_interfaces(
        '/sbin/ip',
        dict(dev='eth0', scope='global', metric=1024, mtu=1500),
        dict(dev='eth0', scope='global', metric=1024, mtu=1500))
    assert out == ('eth0', 'eth0')
    out = ln._get_default_interfaces(
        '/sbin/ip',
        dict(dev='eth0', scope='global', metric=1024, mtu=1500),
        dict(dev='eth0', scope='global', metric=1024, mtu=1500),
        dict(dev='eth1', scope='global', metric=1024, mtu=1500))
    assert out == ('eth1', 'eth0')



# Generated at 2022-06-11 03:42:18.950951
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible.module_utils.pycompat24 import get_exception
    from ansible.module_utils.facts.network.linux import LinuxNetwork


# Generated at 2022-06-11 03:42:25.893454
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    data = dict(
        default_ipv4=dict(),
        default_ipv6=dict(),
    )
    result = dict(
        ansible_facts=dict(
            ansible_all_ipv4_addresses=[],
            ansible_all_ipv6_addresses=[],
            ansible_default_ipv4=dict(),
            ansible_default_ipv6=dict(),
            ansible_devices=dict(),
            ansible_interfaces=dict(),
        )
    )
    assert LinuxNetwork(dict(data=data)).populate() == result



# Generated at 2022-06-11 03:42:35.764607
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # We're using a non-default naming schema
    os.environ['PATH'] = '/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin'

    # FIXME: mock Module and run get_bin_path

    ip_path = '/sbin/ip'
    module = AnsibleModule(argument_spec=dict())
    net = LinuxNetwork(module)

    stdout = 'a\n'  # this should not happen in real life
    stderr = 'RTNETLINK answers: No such device\n'

    module.run_command = MagicMock(return_value=(1, stdout, stderr))
    (default_ipv4, default_ipv6) = net.get_default_interfaces(ip_path)
    module.run_command.assert_

# Generated at 2022-06-11 03:42:46.084686
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    ln = LinuxNetwork()
    ln.module = MagicMock()
    ln.module.run_command.return_value = 0, "", ""
    ln.module.get_bin_path.return_value = ["/usr/bin/ethtool"]
    exp = {
        'features': {
            'rx_checksumming': 'on',
            'tx_checksum_ipv4': 'on',
            'tx_checksum_sctp': 'on',
            'tx_checksum_tcp': 'on',
            'tx_checksum_udp': 'on'
        }
    }

# Generated at 2022-06-11 03:42:54.045044
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Patch the sys.exit so we can continue when called
    # Note that sys.exit will raise a SystemExit which will be catched without the patch
    original_sys_exit = sys.exit
    def sys_exit_stub(code):
        pass
    sys.exit = sys_exit_stub
    # Initialise the class
    network = LinuxNetwork(None)
    # Run the method to be tested
    default_ipv4, default_ipv6 = network.get_default_interfaces()
    # The patch can be removed from live python since we continue after the call
    sys.exit = original_sys_exit


# Generated at 2022-06-11 03:43:01.637269
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Test with a valid interface name
    module = AnsibleModule(argument_spec={'devicename': {'type': 'str'}})
    r = Network()
    r.module = module
    os.environ['PATH'] = '/bin:/usr/bin'

    r.module.params['devicename'] = 'ens160'
    r.populate()
    assert r.iproute_path != None
    assert len(r.ip_command) == 2
    assert r.ip_command[0] == ['ip', '-4', '-o', 'addr', 'show', 'dev', 'ens160']
    assert r.ip_command[1] == ['ip', '-6', '-o', 'addr', 'show', 'dev', 'ens160']

    # Test with invalid Interface name
    r.module.params

# Generated at 2022-06-11 03:43:03.263332
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    pass  # NOTE: this is a stub for testing purposes only, implement this if needed.




# Generated at 2022-06-11 03:43:34.889843
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # goal: test that LinuxNetwork().get_interfaces_info() has good output
    # NOTE: this method is not generally callable

    # create a fake AnsibleModule module object
    module = ansible_fake.AnsibleModule()

    # create a sample LinuxNetwork object
    network = LinuxNetwork(module)

    # Enforce the presence of files to ensure the data of the eth0 interface
    # TODO: ensure the presence of other interface files too

    # TODO: mock this out?
    # FIXME: move to setup/teardown?
    with open(module.params['running_config_path'], 'w') as f:
        f.write(RUNNING_CONFIG)

    # since we are mocking out the file system, this is not true
    # FIXME: move to setup/teardown?

# Generated at 2022-06-11 03:43:42.877876
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    test_module = AnsibleModuleMock()
    test_module.params = {
        'ip_path': '/bin/ip',
        'default_ipv4': {'interface': 'eth0'},
        'default_ipv6': {'interface': 'eth0'},
    }
    test_module.run_command = run_command
    linux = LinuxNetwork(test_module)
    default_ipv4, default_ipv6 = linux.get_default_interfaces()
    assert default_ipv4 == {'interface': 'net0', 'address': '10.0.0.1', 'subnet': '255.0.0.0', 'gateway': '10.0.0.254'}

# Generated at 2022-06-11 03:43:52.583517
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    device_virtio = {
        'ifname': 'eth0',
        'hwaddr': '52:54:00:3c:e1:5f',
        'module': 'virtio_net'
    }
    device_veth = {
        'ifname': 'eth1',
        'hwaddr': '52:54:00:6e:0c:1e',
        'module': 'veth',
    }
    default_ipv4 = {
        'address': '192.168.122.102',
        'broadcast': '',
        'netmask': '255.255.255.0',
        'network': '192.168.122.0'
    }

# Generated at 2022-06-11 03:44:02.760159
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Test for the case where the interface we want does not exist.
    # In this case we want to return two None values.
    module = FakeModule()
    network = LinuxNetwork(module)
    assert network.get_default_interfaces() == (None, None)

    # Test for the case where the interface name is returned.
    module = FakeModule()
    module.run_command.side_effect = ["lo", "eth2"]
    network = LinuxNetwork(module)
    assert network.get_default_interfaces() == ("eth2", None)

    # Test for the case where the interface is not returned, but we
    # get the IPv4 address.
    module = FakeModule()
    module.run_command.side_effect = ["lo", "192.168.1.2"]
    network = LinuxNetwork(module)

# Generated at 2022-06-11 03:44:09.203522
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    res = LinuxNetwork._LinuxNetwork__get_default_interfaces()
    assert res['v4']['gateway'] == '192.168.1.1'
    assert res['v4']['interface'] == 'eth0'
    assert res['v4']['address'] == '192.168.1.3'
    assert res['v6']['address'] == 'fe80::5054:ff:fe5d:c3f3'
    assert res['v6']['interface'] == 'eth0'


# Generated at 2022-06-11 03:44:19.441913
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    """
    Test description
    """

    # FIXME: tests still needed for LinuxNetwork.populate()
    # Maybe start with a docstring example test like the following
    # and add more
    m = LinuxNetwork(module=None)
    fi = m.populate()

    # pprint(fi)

    # Which output keys are expected
    assert 'interfaces' in fi
    assert 'default_ipv4' in fi
    assert 'default_ipv6' in fi
    assert 'all_ipv4_addresses' in fi['ansible_all_ipv4_addresses']
    assert 'all_ipv6_addresses' in fi['ansible_all_ipv6_addresses']
    assert 'default_gateway_interface' in fi
    assert 'default_gateway_ipv4' in fi


# Generated at 2022-06-11 03:44:29.480342
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    m = Network()
    m.populate()
    # Method populate should set ipv4 default route
    assert m.default_ipv4
    # Method populate should set ipv6 default route
    assert m.default_ipv6
    # Method populate should set interfaces dictionary
    assert m.interfaces
    # Method populate should set interfaces dictionary with a lo interface
    assert 'lo' in m.interfaces
    # Method populate should set interfaces dictionary with a ipv4 key
    assert 'ipv4' in m.interfaces['lo']
    # Method populate should set interfaces dictionary with a ipv6 key
    assert 'ipv6' in m.interfaces['lo']
    # Method populate should set interfaces dictionary with a ipv4 key lo_ipv4

# Generated at 2022-06-11 03:44:30.869866
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    assert LinuxNetwork().get_ethtool_data("") == {}


# Generated at 2022-06-11 03:44:40.621583
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(side_effect=lambda x: x)


# Generated at 2022-06-11 03:44:50.580391
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-11 03:45:47.691049
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():

    # FIXME: horrible code for testing a method
    # python -m pytest lib/ansible/module_utils/network/common/utils.py -k test_LinuxNetwork_get_ethtool_data
    # pytest lib/ansible/module_utils/network/common/utils.py -k test_LinuxNetwork_get_ethtool_data
    import sys
    sys.path.insert(0, '/path/to/ansible/hacking')
    import pytest
    from ansible.module_utils.common.text_utils import to_bytes
    from ansible.module_utils.basic import AnsibleModule
    class FakeModule(AnsibleModule):
        def __init__(self, params={}):
            super(FakeModule, self).__init__(params=params)