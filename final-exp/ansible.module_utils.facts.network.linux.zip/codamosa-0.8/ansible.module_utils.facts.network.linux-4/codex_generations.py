

# Generated at 2022-06-11 03:36:22.544929
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Initializations
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-11 03:36:32.687149
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    m = AnsibleModuleMock()
    n = LinuxNetwork(m)
    ethtool_path = n.module.get_bin_path("ethtool")

    def mock_run_command(*args, **kwargs):
        rc = 0
        stdout = ""
        stderr = ""
        if args == (ethtool_path, '-k', 'eth0'):
            rc = 0

# Generated at 2022-06-11 03:36:44.963394
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = Mock(return_value="/path/to/ethtool")
    m_rc = MagicMock(return_value=0)

# Generated at 2022-06-11 03:36:55.608729
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():

    from mock import patch, call, MagicMock
    from ansible.module_utils.network.common.utils import load_platform_subclass

    # load the LinuxNetwork platform subclass
    net = load_platform_subclass(LinuxNetwork)
    # instance the LinuxNetwork platform subclass
    net = net()

    # patch for the calls to get_file_content()
    m_get_file_content = MagicMock()

    with patch('ansible.module_utils.basic.AnsibleModule.get_bin_path', return_value='some_path'),\
         patch.object(net, 'get_file_content', m_get_file_content) as m_gfc:

        # call the get_ethtool_data() method of net
        result = net.get_ethtool_data('some_device')

        # assert that

# Generated at 2022-06-11 03:37:03.779141
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible.module_utils.basic import AnsibleModule
    import ansible.module_utils.net_tools.linux.network as linux_network
    module = AnsibleModule(argument_spec=dict())
    ln = linux_network.LinuxNetwork(module)

    # TODO: set up fixture data
    ln.get_interfaces_info = lambda a,b,c: ({'lo': {'device': 'lo', 'type': 'loopback', 'ipv4': {'address': '127.0.0.1', 'broadcast': '', 'netmask': '255.0.0.0', 'network': '127.0.0.0'}}}, {'all_ipv4_addresses': ['127.0.0.1']})

# Generated at 2022-06-11 03:37:16.097337
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    # list of tuples:
    # - ip_path: path to the ip executable (None if unavailable)
    # - expected_default_ipv4: dictionary with attributes for the default ipv4 interface (None if unavailable)
    # - expected_default_ipv6: dictionary with attributes for the default ipv6 interface (None if unavailable)
    # - expected_interfaces: dictionary with attributes for each interface
    # - expected_ips: dictionary with information about the available ip addresses
    test_cases = []
    # test case 1: ip utility is not available

# Generated at 2022-06-11 03:37:20.638727
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    __set_module_args({
        'gather_subset': ['!all', 'min']
    })
    _module = type('module_', (object,), dict(params={}, check_mode=False))
    module = _module()
    _LinuxNetwork = type('LinuxNetwork', (object,), dict(module=module))
    interface = _LinuxNetwork()
    # test function get_default_interfaces()
    default_ipv4, default_ipv6 = interface.get_default_interfaces()
    assert default_ipv4 == {'address': '127.0.0.1', 'macaddress': '00:00:00:00:00:00', 'mtu': 65536, 'type': 'loopback'}

# Generated at 2022-06-11 03:37:30.471144
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-11 03:37:31.908952
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # TODO: Add test cases
    raise NotImplementedError


# Generated at 2022-06-11 03:37:42.319860
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    args = []

    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=False)
    linux_network = LinuxNetwork(module)
    rc = linux_network.get_ethtool_data(*args)
    assert rc == {}

    module.get_bin_path = MagicMock(return_value="fake_path")
    rc = linux_network.get_ethtool_data(*args)
    assert rc == {}

    module.run_command = MagicMock(side_effect=[
        (0, 'fake_k', ''),
        (0, 'fake_T', '')
    ])
    rc = linux_network.get_ethtool_data(*args)


# Generated at 2022-06-11 03:38:21.479152
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
  from ansible.module_utils.basic import AnsibleModule
  module = AnsibleModule(argument_spec=dict())

  def get_bin_path(path, required=False):
     return path

  module.get_bin_path = get_bin_path

  ln = LinuxNetwork(module)
  ln.populate()

  assert ln.all_ipv4_addresses == ['172.16.10.3', '10.0.2.15']
  assert ln.all_ipv6_addresses == ['fe80::a00:27ff:fe01:8e01']

  # Check the devices
  devices = ln.interfaces
  assert devices['lo']['mtu'] == 65536
  assert devices['lo']['promisc'] == False

# Generated at 2022-06-11 03:38:32.847895
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible_collections.ansible.netcommon.plugins.module_utils import basic
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import dict_merge

    def get_bin_path(name):
        if name in ['ip', 'ss', 'ethtool']:
            return '/bin/' + name
        return None

    module = basic.AnsibleModule(argument_spec={})
    module.get_bin_path = get_bin_path
    ansible_facts = dict(ansible_facts=dict())
    temp_network = LinuxNetwork()
    temp_network.module = module
    temp_network.populate()

# Generated at 2022-06-11 03:38:42.968089
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    ln = LinuxNetwork()
    ln.module = AnsibleModuleMock()
    ln.module.run_command = pipelined_run_command = MagicMock(return_value=(0, '', ''))
    ln.INTERFACE_TYPE = {}
    interfaces = {'eth0': {'device': 'eth0'}}
    ips = dict(all_ipv4_addresses=[], all_ipv6_addresses=[])

    ethtool_path = '/usr/sbin/ethtool'
    ln.module.get_bin_path = MagicMock(return_value=ethtool_path)
    ln.get_ethtool_data('eth0')

# Generated at 2022-06-11 03:38:53.634812
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule({})
    module.run_command = MagicMock(return_value=(0, '', ''))
    ln = LinuxNetwork(module)

# Generated at 2022-06-11 03:39:05.808323
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    import mock
    from ansible.module_utils.basic import AnsibleModule

    # Mock module class used by get_ethtool_data
    class MockAnsibleModule:
        def __init__(self, *args, **kwargs):
            self.params = {'path': kwargs['path']}
            pass

        def fail_json(self, *args, **kwargs):
            pass

        @staticmethod
        def get_bin_path(*args, **kwargs):
            return args[0]

        def run_command(self, *args, **kwargs):
            command, device = args[0][0], args[0][-1]
            if not command:
                return 128, '', 'unknown command'

# Generated at 2022-06-11 03:39:12.335982
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    interfaces, ips = ln.get_interfaces_info("ip -4", dict(), dict())
    module.exit_json(ansible_facts=dict(ansible_interfaces=interfaces, ansible_all_ipv4_addresses=ips['all_ipv4_addresses'], ansible_all_ipv6_addresses=ips['all_ipv6_addresses']))



# Generated at 2022-06-11 03:39:23.557174
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    obj = LinuxNetwork(dict())

# Generated at 2022-06-11 03:39:34.985451
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    if not hasattr(module, 'run_command'):
        module.run_command = lambda command, check_rc=False, close_fds=True: (0, None, None)

    module.run_command = lambda command, check_rc=False, close_fds=True: (0, 'dev qg-c8138760-d6 src 10.0.0.2', None)
    module.run_command = lambda command, check_rc=False, close_fds=True: (0, 'default via 192.168.122.1 dev virbr0 proto dhcp metric 100', None)

# Generated at 2022-06-11 03:39:44.168916
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    class LinuxNetwork_test(LinuxNetwork):
        def __init__(self):
            class FakeModule(object):
                def __init__(self):
                    self.params = dict()
                    self.check_mode = False

                def run_command(self, args, errors=None):
                    if args[-1] == 'nonexistent':
                        return 1, '', ''
                    if args[-1] == 'no_features':
                        return 0, '', ''

# Generated at 2022-06-11 03:39:51.877443
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.linux import LinuxNetwork

    ln = LinuxNetwork(None)
    interfaces_info, ip_info = ln.get_interfaces_info(None, None, None)

    assert isinstance(interfaces_info, dict)

    assert isinstance(ip_info, dict)
    assert 'all_ipv4_addresses' in ip_info
    assert isinstance(ip_info['all_ipv4_addresses'], list)
    assert 'all_ipv6_addresses' in ip_info
    assert isinstance(ip_info['all_ipv6_addresses'], list)


# Generated at 2022-06-11 03:40:33.694398
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    facts = dict(distribution='Linux', platform='Linux', interfaces=['lo'])
    linux_collector = LinuxNetworkCollector(None, facts, None)
    assert linux_collector.facts == facts


# Generated at 2022-06-11 03:40:41.893003
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    test_inst = LinuxNetwork()

# Generated at 2022-06-11 03:40:53.674418
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    #
    # stub methods
    #
    def stub_module_get_bin_path(module, arg, opt_dirs=[]):
        if arg == "ip":
            return "/sbin/ip"
        else:
            return "/usr/bin/bogus"

    module.get_bin_path = stub_module_get_bin_path


# Generated at 2022-06-11 03:41:04.588578
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch, MagicMock
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts import ModuleFacts

    module_mock = MagicMock()

# Generated at 2022-06-11 03:41:13.436956
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    obj = LinuxNetwork(module)
    # test empty string device
    device = ""
    result = obj.get_ethtool_data(device)
    assert result == {}
    # test string device
    device = "eth0"
    result = obj.get_ethtool_data(device)
    assert result != {}
    assert type(result) is dict
    assert "features" in result
    # test int device
    with pytest.raises(TypeError):
        device = 4
        result = obj.get_ethtool_data(device)


# Generated at 2022-06-11 03:41:24.270897
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    ln = LinuxNetwork(module)
    # assign output of function to a variable
    v4, v6 = ln.get_default_interfaces()

    assert v4['address'] == '172.17.0.1'
    assert v4['netmask'] == '255.255.0.0'
    assert v4['network'] == '172.17.0.0'
    assert v4['alias'] == 'eth0'
    assert v6['address'] == 'fe80::42:a003:57ff:fed0:d8d8'
    assert v6['prefix'] == '64'
    assert v6['scope'] == 'link'

# Generated at 2022-06-11 03:41:29.612855
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    """
    test if the default interfaces are current
    """
    net = LinuxNetwork()
    v4, v6 = net.get_default_interfaces()
    assert type(v4) == dict
    assert 'interface' in v4
    assert type(v6) == dict
    assert 'interface' in v6
    assert v4['interface'] not in ['docker0', 'virbr0', 'virbr1', 'virbr2', 'virbr3']

# Generated at 2022-06-11 03:41:40.257760
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    def get_dir_mocked(path):
        if path.endswith('/net/eth0'):
            return True
        if path.endswith('/net/eth1'):
            return True
        if path.endswith('/net/lo'):
            return True
        if path.endswith('/net/lo/lower'):
            return True
        if path.endswith('/net/lo/upper'):
            return True
        if path.endswith('/net/bond0'):
            return True
        if path.endswith('/net/bridge0'):
            return True
        return False

    def is_file_mocked(path):
        if path.endswith('/address'):
            return True

# Generated at 2022-06-11 03:41:49.409996
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    def execute(command, err_msg=None, rc=1, env=None):
        if err_msg is not None:
            raise Exception(err_msg)
        if command == ['ip', '-4', 'route', 'get', '8.8.8.8']:
            return (0, '8.8.8.8 via 192.0.2.4 dev eth0  src 192.0.2.1 cache', '')
        elif command == ['ip', '-6', 'route', 'get', '2001:db8::1']:
            return (0, '2001:db8::1 dev eth0  src 2001:db8::1', '')
        else:
            raise Exception('Unexpected command %s' % command)

    module = MagicMock()
    module.get_bin_path.side_effect

# Generated at 2022-06-11 03:41:56.194020
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # test passing required facts
    required_facts = set(('distribution', 'platform'))
    class MockModule:
        def __init__(self, *args, **kwargs):
            self.params = {}
        def run_command(self, *args, **kwargs):
            return 0, '', ''
        def get_bin_path(self):
            return ''
    module = MockModule()
    class MockFacts:
        def __init__(self, *args, **kwargs):
            self.data = {}
            self.data['distribution'] = 'mageia'
            self.data['platform'] = 'Linux'
        def populate(self, *args, **kwargs):
            pass
    # required facts are missing, a NetworkError should be raised
    facts = MockFacts()

# Generated at 2022-06-11 03:42:36.390728
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    # This test only tests the defaults when no default exists
    # From this point it is up to the user to decide which interfaces to use
    assert 'address' in default_ipv4
    assert 'address' in default_ipv6


# Unit test to check if the LinuxNetwork class populates the interfaces dict
# with the correct syntax

# Generated at 2022-06-11 03:42:46.691743
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list'),
        ),
        supports_check_mode=True
    )
    network = LinuxNetwork(module)
    gather_subset = ['!all', '!min']
    network.populate(gather_subset=gather_subset)

# Generated at 2022-06-11 03:42:56.227638
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Return a tuple of 3 elements:
    # 1. Default IPv4 interface name (if found), or None if not found
    # 2. Default IPv6 interface name (if found), or None if not found
    # 3. Success (True or False)
    rc, out, err = module.run_command("ip -4 route show default")
    if rc != 0:
        return None, None, False
    words = out.split()
    if len(words) == 0 or len(words) < 5:
        return None, None, False
    if words[4] != 'dev':
        return None, None, False
    ipv4_interface_name = words[5]
    rc, out, err = module.run_command("ip -6 route show default")
    if rc != 0:
        return ipv4_interface_name,

# Generated at 2022-06-11 03:43:02.991582
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    network = LinuxNetwork()
    ethtool_path = network.module.get_bin_path("ethtool")
    data = network.get_ethtool_data(None)
    assert data == {}
    assert not network.get_ethtool_data('garbage')
    data.update(network.get_ethtool_data(ethtool_path))
    assert data == {}
    # test static data returned
    data.update(network.get_ethtool_data(ethtool_path))
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data



# Generated at 2022-06-11 03:43:06.749064
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # Create a fake AnsibleModule object
    module = AnsibleModule(
        argument_spec={}
    )
    # Create a instance of LinuxNetworkCollector
    linux_network_collector = LinuxNetworkCollector()
    linux_network_collector.get_facts(module)



# Generated at 2022-06-11 03:43:08.492481
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # FIXME: test_LinuxNetwork_get_interfaces_info
    exit(0)



# Generated at 2022-06-11 03:43:18.414349
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # NOTE: include a few tests for each common pattern
    #       this is not meant to be a full unit test suite

    module = MagicMock()
    network = LinuxNetwork(module)


# Generated at 2022-06-11 03:43:27.637757
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """Unit test for method get_ethtool_data"""
    module = AnsibleModule(
        argument_spec=dict()
    )
    output = file( os.path.join(os.path.dirname(__file__), 'ethtool.txt'), 'rb').read()
    mock_run_command = MagicMock(return_value=(0, output, ''))
    module.run_command = mock_run_command
    result = {}
    result['features'] = {'gso': 'on', 'rss': 'on', 'tso': 'on', 'lro': 'on'}
    result['timestamping'] = ['host', 'network']
    result['hw_timestamp_filters'] = ['all']
    result['phc_index'] = 1
    obj_LinuxNetwork = LinuxNetwork(module)

# Generated at 2022-06-11 03:43:36.574759
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    class Module(object):
        def run_command(self, command, errors='surrogate_if_needed'):
            return (0, '', '')

        def get_bin_path(self, command):
            # this has to be very dumb in order to not test the actual executables
            return "/bin/ethtool"

        def check_mode(self):
            return False

    test_module = Module()
    test_module.params = {
        'use_ipv6': True,
    }

    # happy path
    network = Network(test_module)
    # Just use the local directory since we don't actually use this path
    ip_path = os.path.dirname(os.path.realpath(__file__))

# Generated at 2022-06-11 03:43:45.985338
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)

    # Test ethtool_path value
    module.params['ethtool_path'] = None
    linux_network = LinuxNetwork(module)
    assert linux_network.ethtool_path == 'ethtool'

    module.params['ethtool_path'] = 'test_ethtool_path'
    linux_network = LinuxNetwork(module)
    assert linux_network.ethtool_path == 'test_ethtool_path'

    # Test ip_path value
    module.params['ip_path'] = None
    linux_network = LinuxNetwork(module)
    assert linux_network.ip_path == 'ip'

    module.params['ip_path'] = 'test_ip_path'
    linux_network = LinuxNetwork(module)
   

# Generated at 2022-06-11 03:44:31.061045
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    # Check IPv4 info on a Linux machine
    module = AnsibleModule(argument_spec=dict())
    ln = LinuxNetwork(module)
    interfaces, ips = ln.get_interfaces_info('/bin/ip', {'address': '192.168.3.6'}, {'address': '2001::10'})
    default_ipv4, default_ipv6 = ln.get_default_interfaces(interfaces, '/bin/ip')
    module.exit_json(changed=False,
                     interface_list=interfaces,
                     ips=ips,
                     default_ipv4=default_ipv4,
                     default_ipv6=default_ipv6)


if __name__ == '__main__':
    test_LinuxNetwork_populate()

# import module snippets

# Generated at 2022-06-11 03:44:40.841998
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # FIXME: this should not be using os internals
    # FIXME: this should not be using external resources
    # FIXME: this should not be using internal resources
    if not os.access('/sbin/ip', os.X_OK):
        os.symlink('/bin/true', '/sbin/ip')
    if not os.access('/sbin/ifconfig', os.X_OK):
        os.symlink('/bin/true', '/sbin/ifconfig')
    if not os.access('/sbin/route', os.X_OK):
        os.symlink('/bin/true', '/sbin/route')
    if not os.access('/sbin/arp', os.X_OK):
        os.symlink('/bin/true', '/sbin/arp')
   

# Generated at 2022-06-11 03:44:51.034934
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-11 03:44:55.169099
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from ansible.module_utils.facts.collector.network import LinuxNetworkCollector
    test_obj = LinuxNetworkCollector(dict(distribution='debian'))
    assert test_obj
    assert test_obj.fact_class._distribution == 'debian'

# Unit test class LinuxNetwork

# Generated at 2022-06-11 03:45:04.711231
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    """
    Exercises LinuxNetwork.populate and asserts that it changes member variables.

    When LinuxNetwork.populate is invoked,
    the object's interfaces, default_ipv4, default_ipv6, and ips should be set.
    """
    class DummyModule(object):
        def __init__(self):
            self.params = {
                'use_ipv6': True,
                'gather_alternate_facts': False
            }

        def get_bin_path(self, name):
            # hard-code to true to avoid false positives
            return True

    class DummyRunner(object):
        def run_command(self, args, errors):
            # hard-code to true to avoid false positives
            return 0, True, True

    module = DummyModule()
    runner = DummyRunner()


# Generated at 2022-06-11 03:45:13.804459
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """unit test for LinuxNetwork.get_interfaces_info"""
    # Setup
    net = NetworkHandler()
    net.get_file_content = Mock()

# Generated at 2022-06-11 03:45:22.918171
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    """
    Test case for get_default_interfaces of class LinuxNetwork
    """
    # setup
    module = MagicMock()
    ln = LinuxNetwork(module=module)
    ln.module.run_command = MagicMock(return_value=(0, '', ''))

    # test 1
    rc_value = (1, '', '')
    ln.module.run_command.return_value = rc_value
    result = ln.get_default_interfaces()
    exp_result = ('', '', '')
    assert result == exp_result

    # test 2
    rc_value = (0, '', '')
    ln.module.run_command.return_value = rc_value
    result = ln.get_default_interfaces()

# Generated at 2022-06-11 03:45:31.483524
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    test_module = NetworkModule()
    platform = 'linux'
    test_module.set_platform(platform)
    test_module.params['gather_subset'] = ['all']

    expected_default_interfaces = {'v4': {'broadcast': '169.254.255.255',
                                          'address': '169.254.0.2',
                                          'netmask': '255.255.0.0',
                                          'network': '169.254.0.0'},
                                   'v6': {'address': 'fe80::5054:ff:fe49:dae2',
                                          'scope': 'link',
                                          'prefix': '64'}}

    unittest.main(module=__name__, exit=False, verbosity=2)

# Generated at 2022-06-11 03:45:38.814553
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    net = LinuxNetwork()

    # no argument, both should be None
    assert net.get_default_interfaces() == (None, None)

    # only 1 interface, both should be the same
    assert net.get_default_interfaces('lo') == ('lo', 'lo')

    # only 1 interface, both should be the same
    assert net.get_default_interfaces('lo,lo') == ('lo', 'lo')

    # only 1 interface, both should be the same
    assert net.get_default_interfaces('lo, lo') == ('lo', 'lo')

    # only 1 interface, both should be the same
    assert net.get_default_interfaces('lo, lo, lo') == ('lo', 'lo')

# Generated at 2022-06-11 03:45:43.218814
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)

    # TODO: Mock a file/output
    default_interfaces = linux_network.get_default_interfaces()
    assert default_interfaces['default_ipv4']['address'] != '127.0.0.1'
    assert default_interfaces['default_ipv6']['address'] != '::1'

