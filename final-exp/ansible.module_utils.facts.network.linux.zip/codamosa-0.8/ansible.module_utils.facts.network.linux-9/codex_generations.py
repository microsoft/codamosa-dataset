

# Generated at 2022-06-11 03:36:24.112221
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    def ethtool_fake(command):
        # FIXME: make more fake-y
        # save a copy of module.run_command, hard to do this in a nice way
        module_run_command_real = LinuxNetwork(Mock(run_command=Mock(return_value=[0, "", ""]))).run_command
        fake_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'fakes', 'ethtool')
        with open(os.path.join(fake_path, command[-1]), 'rb') as f:
            fake_stdout = f.read()
        module_run_command_real(command, errors='surrogate_then_replace')
        return 0, fake_stdout, ''


# Generated at 2022-06-11 03:36:30.780721
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    BASE_MOCK_FILE = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'initsystem_mock_data')

    class LinuxNetworkTester(LinuxNetwork):
        def __init__(self, *args, **kwargs):
            super(LinuxNetworkTester, self).__init__(*args, **kwargs)
            self.module = self

        def run_command(self, command, check_rc=True, errors='surrogate_then_replace', encoding='utf-8'):
            """
            Overwrite LinuxNetwork.run_command on purpose to avoid running the remote code.
            Mock the data instead.
            """

# Generated at 2022-06-11 03:36:42.847130
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from ansible.module_utils import basic

    # Define some test input data for get_ethtool_data
    device = 'eth0'

    # Define the expected result for this data as a dict
    # for ethtool -k data

# Generated at 2022-06-11 03:36:53.631986
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    ln = LinuxNetwork()
    ln.module = Mock()
    ln.module.run_command = lambda *a, **kw: (0, "link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00", "")

# Generated at 2022-06-11 03:36:59.664407
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    """
    This is a unit test for the method get_default_interfaces of the class
    'LinuxNetwork'. This unit test mocks the Linux based system and it is
    necessary to mock the methods of the module because they need to be tested
    independently.

    :return: None
    """
    # Mocking modules, classes and functions
    module_mock = MagicMock()
    module_mock.get_bin_path.return_value = '/bin/grep'
    module_mock.run_command.return_value = (0, "default via 192.168.1.1 dev eth0", "")
    # NOTE: here we are mocking a class, not an instance of the class
    # pylint: disable=unnecessary-lambda

# Generated at 2022-06-11 03:37:10.304756
# Unit test for method populate of class LinuxNetwork

# Generated at 2022-06-11 03:37:12.611515
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # TODO: Add unit tests for method get_ethtool_data of class LinuxNetwork
    return None


# Generated at 2022-06-11 03:37:20.543177
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    test_module = FakeModule()
    test_module.run_command = MagicMock(return_value=(0, "", ""))
    ln = LinuxNetwork(test_module)
    ln.get_bin_path = MagicMock(return_value="/usr/bin/ethtool")
    assert ln.get_ethtool_data("eth0") == {'features': {}, 'timestamping': [], 'hw_timestamp_filters': []}


# Test for LinuxNetwork class


# Generated at 2022-06-11 03:37:30.436625
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-11 03:37:40.642203
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    class MockModule(object):
        def get_bin_path(self, arg):
            return '/usr/sbin/ethtool'


# Generated at 2022-06-11 03:38:15.820480
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    m = AnsibleModule(
        argument_spec=dict(
            ip_path=dict(required=False, type='str', default='ip'),
        ),
        supports_check_mode=True,
    )

    l = LinuxNetwork(m)

    # NOTE: how does this work with a return value?
    default_ipv4, default_ipv6 = l.get_default_interfaces(m.params['ip_path'])
    m.exit_json(changed=False, default_ipv4=default_ipv4, default_ipv6=default_ipv6)



# Generated at 2022-06-11 03:38:26.670461
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec=dict())


# Generated at 2022-06-11 03:38:37.400978
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={
        'device': {'type': 'str'},
    })
    ln = LinuxNetwork(module)

# Generated at 2022-06-11 03:38:47.720975
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    class DummyModule():

        def __init__(self):
            self.path_exists = []
            self.get_bin_path_results = []
            self.run_command_results = []
            self.run_command_expectations = {}

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            return self.get_bin_path_results.pop(0)

        def fail_json(self, **kwargs):
            pass


# Generated at 2022-06-11 03:38:58.972739
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: mock module here once we need it

    # Initialize call
    l = LinuxNetwork()
    # TODO: mock here and initialize default_ipv4 and default_ipv6
    default_ipv4 = {}
    default_ipv6 = {}
    interfaces, ips = l.get_interfaces_info('/sbin/ip', default_ipv4, default_ipv6)

    # Check results
    assert isinstance(interfaces, dict)
    assert isinstance(ips, dict)
    assert isinstance(ips['all_ipv4_addresses'], list)
    assert isinstance(ips['all_ipv6_addresses'], list)
    for interface in interfaces.itervalues():
        assert isinstance(interface, dict)

        # For every interface that has an ipv4 section

# Generated at 2022-06-11 03:39:10.314247
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    def run_populate(self, module, ip_path, module_exit_json, module_fail_json):
        self.module_exit_json = module_exit_json
        self.module_fail_json = module_fail_json
        # FIXME: this is not quite as pretty as it should be

        # Mock get_interfaces_info

# Generated at 2022-06-11 03:39:15.763836
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import doctest
    module = AnsibleModule(
        argument_spec=dict(),
    )
    module.ARGS = dict()
    module.exit_json = dict()
    module.run_command = dict()
    module.get_bin_path = dict()
    # TODO: todo:
    #   - test on non-linux
    #   - test on os with no ip/ifconfig
    #   - test on os with no /sys fs
    #   - test on os with no /proc fs
    #   - test on os with no /dev/net
    #   - test on os with no /sys/class/net
    #   - test on a system without ethtool
    #   - test on a system without a normal eth* device
    #   - test with a kernel device named with a colon? Is that even possible

# Generated at 2022-06-11 03:39:26.975325
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # create a mock module to pass into the object
    module = AnsibleModule(
        argument_spec=dict()
    )

    # create a mock for the class we're testing
    linux_network = LinuxNetwork(module)
    # mock the output of the 3 commands we need to run

# Generated at 2022-06-11 03:39:36.375456
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    ln = LinuxNetwork()
    ln.module.get_bin_path = MagicMock(return_value='/usr/sbin/ip')
    ln.module.run_command = MagicMock()
    ln.module.run_command.side_effect = [
        (0, "default via 192.0.2.1 dev eth0 proto static metric 100", ''),
        (0, "default dev eth0 proto static metric 100", ''),
    ]
    expected = {'v4': {'address': '192.0.2.1'}, 'v6': {}}
    actual = ln.get_default_interfaces()
    assert expected == actual



# Generated at 2022-06-11 03:39:45.413727
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    # Patch module.run_command() so that a test
    # can control the output
    def mock_run_command(command, **kwargs):
        if command == ['ip', 'route', 'show', 'default', 'scope', 'global']:
            return 0, 'default via 192.168.1.1 dev eth0\n', ''
        elif command == ['ip', '-6', 'route', 'show', 'default', 'scope', 'global']:
            return 0, 'default via fc00::1 dev eth0 metric 1024\n', ''
        elif command == ['ip', '-o', 'addr', 'show', 'dev', 'eth0']:
            return 0, '', ''
        elif command == ['ip', 'route', 'list', 'dev', 'eth0']:
            return 0, '', ''


# Generated at 2022-06-11 03:40:23.095143
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    device = "lo"
    ln = LinuxNetwork()

    data = ln.get_ethtool_data(device)

# Generated at 2022-06-11 03:40:33.508442
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    net = LinuxNetwork()

    default_ipv4 = {}
    default_ipv6 = {}
    ip_path = '/bin/ip'
    interfaces, ips = net.get_interfaces_info(ip_path, default_ipv4, default_ipv6)

    expected = {'all_ipv4_addresses': [],
        'all_ipv6_addresses': []}
    assert ips == expected


# Generated at 2022-06-11 03:40:37.291399
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network = LinuxNetwork()
    linux_network.module = FakeAnsibleModule()
    # this is a generic interface str, it is not the name of an actual interface
    device = 'foobar'

    # <data> is a dict of information about <device>
    # It should be empty since <device> does not exist
    data = linux_network.get_ethtool_data(device)
    assert data == {}



# Generated at 2022-06-11 03:40:41.961538
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = GenericModule()
    module.run_command = lambda x: (0, '', '')
    ln = LinuxNetwork(module)
    d = ln.get_interfaces_info(None, {}, {})
    # TODO: actually assert something
    return True


# Generated at 2022-06-11 03:40:53.721855
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all', '!min'], type='list'),
            gather_network_resources=dict(default=['all'], type='list'),
        ),
        supports_check_mode=True,
    )
    mock_module = MagicMock(return_value=module)
    mock_run_command = MagicMock()
    mock_get_bin_path = MagicMock(return_value='/sbin/ip')
    with patch.multiple(basic.AnsibleModule,
                        exit_json=mock_module,
                        run_command=mock_run_command,
                        get_bin_path=mock_get_bin_path):
        linux_network = LinuxNetwork(module)

# Generated at 2022-06-11 03:41:04.635256
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    for v in ['v4', 'v6']:
        for cmd in ['route', 'ip']:
            for dest in ['default']:
                key = (v, cmd, dest)
                if key not in test_LinuxNetwork_get_default_interfaces.test_cases:
                    continue
                test_data = test_LinuxNetwork_get_default_interfaces.test_cases[key]
                module = FakeModule(test_data['run_command_output'])
                linux_network = LinuxNetwork(module)
                default_ip = linux_network.get_default_interfaces(cmd)[0 if v == 'v4' else 1]

# Generated at 2022-06-11 03:41:13.109625
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule({})

    # Test 1:
    # Test with a netstat_path that doesn't exist to
    # ensure we get the None back
    network = LinuxNetwork(module=module, ip_path='does_not_exist', netstat_path='does_not_exist')
    result = network.get_interfaces_info(ip_path='ip')
    output = result[0]
    default_ipv4 = result[1]
    default_ipv6 = result[2]
    assert output == {}
    assert default_ipv4 == {}
    assert default_ipv6 == {}



# Generated at 2022-06-11 03:41:18.156137
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    # Arrange
    m = NetworkModule()
    m.check_mode = False
    m.no_log = False

    l = LinuxNetwork(m)

    # Act
    # This can only be called after th get_interfaces_info() method has been called
    # See https://github.com/ansible/ansible/issues/67693 for a discussion about the original issue
    # that has caused this test to be added.
    default_ipv4 = l.default_ipv4['address']
    default_ipv6 = l.default_ipv6['address']

    # Assert
    assert isinstance(default_ipv4, six.text_type)
    assert isinstance(default_ipv6, six.text_type)


# Generated at 2022-06-11 03:41:28.355871
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.six import string_types
    import json

    # Define a fake module to pass to the method
    MOCK_MODULE_ARGS = {
        "match": "eth*",
        "exclude": ["eth0"],
        "gather_network_resources": ["config"],
        "config": ["up", "down"],
        "state": None
    }

# Generated at 2022-06-11 03:41:38.130790
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = type('module', (object,), {})
    obj = LinuxNetwork(module)

    def call_run_command(args, errors):
        if args[0] != 'ethtool':
            raise ValueError('Incorrect command')
        if args[1] == '-k' and args[2] == 'eth0':
            stdout = dedent('''\
            Features for eth0:
                    rx-checksumming: on
                    tx-checksumming: on
                    tx-checksum-ipv4: on
                    tx-checksum-ipv6: off
                    tx-checksum-ip-generic: on
                    tx-checksum-fcoe-crc: off
                    tx-checksum-sctp: off
            ''')
            rc = 0

# Generated at 2022-06-11 03:42:20.105353
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    network = LinuxNetwork(module=module)

    if not os.path.exists('/sys/class/net/lo'):
        os.mkdir('/sys/class/net/lo')
        raise Exception('Test did not clean up!')


# Generated at 2022-06-11 03:42:29.573421
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-11 03:42:35.996877
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    fake_module = FakeModule({
        'PATH': ':/bin:/usr/bin:/sbin:/usr/sbin',
    })
    ln = LinuxNetwork(module=fake_module)
    fake_module.run_command_values['ethtool -k interface'] = (0, None, None)
    fake_module.run_command_values['ethtool -T interface'] = (0, None, None)
    assert ln.get_ethtool_data('interface') == {}



# Generated at 2022-06-11 03:42:46.315630
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    network = NetworkModule(None)
    assert network.get_default_interfaces() == (None, None)
    network = NetworkModule(None, ip_path='/bin/ip')
    assert network.get_default_interfaces() == (None, None)
    network = NetworkModule(None, ip_path='/bin/ip', ifconfig_path='/bin/ifconfig')
    assert network.get_default_interfaces() == ({'interface': 'lo', 'ipv4': {'address': '127.0.0.1'}}, {'interface': 'lo', 'ipv6': [{'address': '::1', 'prefix': '128', 'scope': 'host'}]})

# Generated at 2022-06-11 03:42:55.927846
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # This is the path used for AnsibleModule's get_bin_path
    os.environ['PATH'] = '/sbin:/usr/sbin'
    fake_module = type('FakeModule', (object,), {
        'get_bin_path': lambda _, path, **kwargs: path,
        'run_command': lambda _, **kwargs: ('', '', ''),
    })

    # NOTE: this is a global, not a member to avoid the singleton pattern
    MODULE_ARGS = {
        'ip_path': 'ip'
    }

    # Private method
    data = {
        '_interface_list': {},
        '_interfaces': {}
    }

    # args, kwargs
    network = LinuxNetwork(fake_module, **MODULE_ARGS)

# Generated at 2022-06-11 03:43:01.636453
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = Mock()
    module.run_command.return_value = (0, 'default via 192.168.1.1 dev eth0', '')
    module.get_bin_path.return_value = "ip"
    module.params = {}
    ln = LinuxNetwork(module)
    assert ln.get_default_interfaces() == ({'v4': {'gateway': '192.168.1.1', 'interface': 'eth0'}, 'v6': {}}, {'v4': {}, 'v6': {}})


# Generated at 2022-06-11 03:43:07.797244
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
  # setup
  module = mock.MagicMock()
  module.run_command.return_value = (0, '', '')
  module.get_bin_path.return_value = '/bin/ip'
  module.get_file_content.return_value = ''
  ln = LinuxNetwork(module)
  # test
  rc, changed, msg = ln.populate()
  # assert
  assert rc == 0
  assert changed is False
  assert msg == 'Interfaces and IP addresses collected'
  # cleanup


# Generated at 2022-06-11 03:43:17.597294
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    ln = LinuxNetwork(module, dict(
        config_file='/etc/network/interfaces'
    ))
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    interfaces, ips = ln.get_interfaces_info(ln.module.get_bin_path("ip"), default_ipv4, default_ipv6)
    assert_equal(type(interfaces), dict)
    assert_equal(type(interfaces['lo']), dict)
    assert_equal(type(interfaces['lo']['mtu']), int)
    assert_equal(type(interfaces['lo']['ipv4']), dict)

# Generated at 2022-06-11 03:43:27.171014
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from ansible.module_utils import basic

    test_module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )
    device = 'eth0'

# Generated at 2022-06-11 03:43:36.006633
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():

    class OSModule(object):
        def get_bin_path(self, name):
            return None


# Generated at 2022-06-11 03:44:23.162360
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Test empty input
    assert LinuxNetwork.get_default_interfaces({}, {}, {}, {}) == ({}, {}, {})
    # Test missing interface
    assert LinuxNetwork.get_default_interfaces({}, {'foonet': '0', 'foogateway': '1'}, {}, {}) == ({}, {'foonet': '0', 'foogateway': '1'}, {})
    # Test missing default gateway
    assert LinuxNetwork.get_default_interfaces({}, {'foonet': '1'}, {}, {}) == ({}, {'foonet': '1'}, {})
    # Test all values provided

# Generated at 2022-06-11 03:44:32.803943
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # FIXME: this would be better as a py.test parametrized fixture
    set_module_args({
        'state': '',
        'check_running_config': False,
    })
    module = get_module()
    if not os.path.exists('/proc/net/dev_mcast'):
        open('/proc/net/dev_mcast', 'a').close()
    if not os.path.exists('/sys/class/net'):
        os.makedirs('/sys/class/net')
    if not os.path.exists('/sys/class/net/lo'):
        os.makedirs('/sys/class/net/lo')

# Generated at 2022-06-11 03:44:42.646152
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    from ansible.module_utils.basic import AnsibleModule
    class TestAnsibleModule(AnsibleModule):
        pass
    module = TestAnsibleModule({})
    module.exit_json = lambda x: x
    module.get_bin_path = lambda x: x
    netinfo = LinuxNetwork(module)
    netinfo.interface_paths = ['test/interface_paths']
    netinfo.find_current_connections()

    # Test when link: true
    netinfo.find_default_interface(link=True)
    assert netinfo.default_interface['link'] == 'link'

    # Test when link: false
    netinfo.find_default_interface(link=False)
    assert netinfo.default_interface['default'] == 'default'



# Generated at 2022-06-11 03:44:52.846493
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    nm = LinuxNetwork(module)

    local_interfaces_info, local_ips = nm.get_interfaces_info(ip_path=None, default_ipv4={}, default_ipv6={})
    local_ip_stdout, _, _ = module.run_command('ip a')


# Generated at 2022-06-11 03:45:02.584915
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import collections
    import unittest

    class MockModule:

        def __init__(self, params):
            self.params = params

        def get_bin_path(self, name):
            return '/bin/{}'.format(name)

        def run_command(self, args, errors='surrogate_then_replace'):
            device = args[-1]

            if device not in ['lo', 'fake']:
                return 1, '', ''

            if device == 'lo':
                return 0, LO_IP_OUTPUT, ''

            return 0, FAKE_IP_OUTPUT, ''

    class TestLinuxNetwork(unittest.TestCase):
        """Unit tests for LinuxNetwork."""

        def setUp(self):
            self.module = MockModule({})


# Generated at 2022-06-11 03:45:11.701821
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={
        "config_file": {"default": "", "type": "str"},
    })

    ln = LinuxNetwork(module)
    dct = ln.populate()

    # test keys
    assert "default_ipv4" in dct
    assert "default_ipv6" in dct
    assert "interfaces" in dct
    assert "ipv4" in dct
    assert "ipv6" in dct

    # test values types
    assert isinstance(dct["default_ipv4"], dict)
    assert isinstance(dct["default_ipv6"], dict)
    assert isinstance(dct["interfaces"], dict)
    assert isinstance(dct["ipv4"], dict)

# Generated at 2022-06-11 03:45:20.545703
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    network = LinuxNetwork()
    result = network.get_interfaces_info(
        ip_path="/bin/ip",
        default_ipv4={'address': '9.7.186.218'},
        default_ipv6={'address': 'fe80::21f:5bff:fe9d:c4ec'}
    )
    assert type(result) == tuple, "get_interfaces_info should return a tuple"
    assert len(result) == 2, "get_interfaces_info should return a tuple with two elements"
    assert type(result[0]) == dict, "get_interfaces_info should return a tuple with a dict first"
    assert type(result[1]) == dict, "get_interfaces_info should return a tuple with a dict second"



# Generated at 2022-06-11 03:45:29.425071
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    def get_network_instance(module_args, result_keys=None):
        module = Mock(params=module_args)
        module.get_bin_path = lambda _, req=False: req and None or "test"
        basic = Basic(module)
        network = LinuxNetwork(basic)
        if result_keys:
            network.result = dict((key, "") for key in result_keys)
        return network

    def run_populate(module_args, result_keys=None, assert_failure=False):
        network = get_network_instance(module_args, result_keys)
        try:
            network.populate()
            return network.result
        except AssertionError as e:
            assert assert_failure
            assert "assertion failed" in str(e)


# Generated at 2022-06-11 03:45:37.247336
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    import builtins
    import pytest

    # TODO: newer run_command does not use shell=True so I am not sure what to assert
    # mock_run_command = mock.Mock(return_value = ('', '', ''))
    # builtins.run_command = mock_run_command

    mock_get_bin_path = mock.Mock(return_value='')
    module = mock.Mock(return_value='')
    module.get_bin_path = mock_get_bin_path

    # TODO: test_data is not an object name

# Generated at 2022-06-11 03:45:44.693420
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    ln = LinuxNetwork()
    net = NetworkInfo()

    dummy, ips = ln.get_interfaces_info('dummy', net.default_ipv4, net.default_ipv6)
    assert type(ips) is dict
    assert len(ips) == 2
    assert ips['all_ipv4_addresses'] == []
    assert ips['all_ipv6_addresses'] == []

    dummy, ips = ln.get_interfaces_info('dummy', net.default_ipv4, net.default_ipv6)
    assert type(ips) is dict
    assert len(ips) == 2
    assert ips['all_ipv4_addresses'] == []
    assert ips['all_ipv6_addresses'] == []

