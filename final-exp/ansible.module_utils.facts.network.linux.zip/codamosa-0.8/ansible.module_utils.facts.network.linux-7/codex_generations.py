

# Generated at 2022-06-11 03:36:20.099258
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec=dict())

    module.run_command = MagicMock(return_value=(0, '', ''))
    # FIXME: with the refactor, this is now a global
    module.get_bin_path = MagicMock(return_value=True)

    ln = LinuxNetwork(module)

    # test without any ethtool data
    module.run_command = MagicMock(side_effect=iter([
        (0, '', ''),
        (0, '', ''),
    ]))

    assert ln.get_ethtool_data('eth0') == {}

    # test with ethtool data

# Generated at 2022-06-11 03:36:24.895891
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    mod_args = dict(
        path='/sbin/ip',
    )
    ln = LinuxNetwork(module=MagicMock(), **mod_args)
    interfaces, ips = ln.get_interfaces_info({}, {}, {})

    # test the first interface
    assert interfaces[list(interfaces.keys())[0]]['mtu'] == 16384



# Generated at 2022-06-11 03:36:35.913155
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', default=[]),
        ),
    )
    result = dict(
        changed=False,
        ansible_facts=dict(
            ansible_net_interfaces={},
            ansible_net_all_ipv4_addresses=[],
            ansible_net_all_ipv6_addresses=[],
            ansible_net_default_ipv4={},
            ansible_net_default_ipv6={},
        ),
    )

    ln = LinuxNetwork()

    # Set up a context manager to mock gather_subset calls
    class mock_gather_subset():
        def __init__(self, test_object, results):
            self.test_object = test_object


# Generated at 2022-06-11 03:36:47.908990
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    mock_module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    mock_module.run_command = MagicMock(return_value=(0, "command output", ""))
    mock_module.get_bin_path = MagicMock(return_value="/bin/mock_ip")

# Generated at 2022-06-11 03:36:58.367777
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    interfaces = ln.get_interfaces_info(ip_path='ip', default_ipv4={}, default_ipv6={})[0]
    # ethtool_path is empty: return empty dict
    assert ln.get_ethtool_data('eth0') == {}

    # return empty dict if the binary does not exist
    module.params['ethtool_path'] = '/bin/ethtool_fake'
    assert ln.get_ethtool_data('eth0') == {}

    # ethtool is available, but the interface doesn't exist
    module.params['ethtool_path'] = '/bin/ethtool'
    assert ln.get_ethtool_data('eno1') == {}

    # ethtool is available, and

# Generated at 2022-06-11 03:37:03.475044
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # make sure we are mocking out the right methods
    with patch.object(LinuxNetwork, 'get_interfaces_info') as mock_get_ifaces:
        mock_get_ifaces.return_value = ({}, {'all_ipv4_addresses': [], 'all_ipv6_addresses': []})
        ln = LinuxNetwork()
        ln.populate()
        assert mock_get_ifaces.called


# Generated at 2022-06-11 03:37:15.790203
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            gather_network_resources=dict(default=['!all'], type='list'),
            filter=dict(default=None, required=False, type='list'),
            exclude=dict(default=None, required=False, type='list'),
            config=dict(default=None, required=False, type='str'),
        ),
        supports_check_mode=True,
    )

    # Setup mocks
    mocked = mock.MagicMock()

    mocked.get_file_content.return_value = "192.169.0.1/24"
    mocked.get_interfaces_info.return_value = ({}, {'all_ipv4_addresses': []})
   

# Generated at 2022-06-11 03:37:26.800080
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    device = 'eth1'
    interface = {'device': 'eth1'}
    ip_path = '/sbin/ip'
    interfaces = {device: interface}
    net = LinuxNetwork(module=None, ip_path=ip_path, interfaces=interfaces)
    net.ipv4_addresses = {
        '127.0.0.1': {
            'interface': 'lo',
            'address': '127.0.0.1'
        }
    }
    net.ipv6_addresses = {
        '::1': {
            'interface': 'lo',
            'address': '::1',
            'scope': 'host'
        }
    }
    net.bridge_interfaces = []
    net.vlan_interfaces = []

    # Test populate()
    linux_default

# Generated at 2022-06-11 03:37:35.897759
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModuleMock()
    module.get_bin_path = mock.Mock(return_value="/sbin/ip")
    module.run_command = mock.Mock(return_value=(0, "", ""))
    linux_network = LinuxNetwork(module)
    linux_network.get_interfaces = mock.Mock(return_value=({"lo": {"address": "127.0.0.1"}}, []))
    linux_network.get_interfaces_info = mock.Mock(return_value=({}, {"all_ipv4_addresses": ["127.0.0.1"]}))

# Generated at 2022-06-11 03:37:42.811932
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    network = LinuxNetwork(module)
    # we expect v4 and v6
    assert len(network.get_default_interfaces()) == 2

    # lets make it impossible to get the default address
    module.run_command = lambda *args, **kwargs: (0, '', '')
    # no default ipaddress
    assert len(network.get_default_interfaces()) == 0



# Generated at 2022-06-11 03:38:16.459356
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    class C(object):
        def __init__(self):
            pass
    class M(object):
        def __init__(self):
            pass
        def get_bin_path(self, path, default=None):
            return '/bin/{}'.format(path)

        def run_command(self, args, errors='warn', use_unsafe_shell=False, environ_update=None, check_rc=True, binary_data=False, cwd=None, data=None):
            return 0, '', ''
    l = LinuxNetwork(C(), M())
    l.populate()

# Generated at 2022-06-11 03:38:27.571380
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    f = LinuxNetwork()

# Generated at 2022-06-11 03:38:38.007395
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    # FIXME: Probably move this to mock testing?
    # Mock module_utils/basic.py AnsibleModule
    import sys
    from ansible.module_utils.basic import AnsibleModule

    class AnsibleModuleMock(AnsibleModule):

        def __init__(self, *args, **kwargs):
            super(AnsibleModuleMock, self).__init__(*args, **kwargs)
            self.params = {
                'ip_path': '/sbin/ip',
                'name': 'lo',
            }
            sys.modules['ansible.module_utils.basic'] = self

    class FakeSubProcess(object):
        '''
        Set stdout and stderr in the args to control the output
        '''
        def __init__(self, args):
            self.stdout = ''


# Generated at 2022-06-11 03:38:48.361664
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    import doctest
    module = AnsibleModule(
        argument_spec=dict()
    )
    module.params = {
        "gather_subset": [
            "network",
            "!all",
        ],
    }
    ln = LinuxNetwork(module)

    result = ln.populate()

    # test_list = [
    #     ['populate', '<object>'],
    # ]
    # failed, tested = doctest.testmod(
    #     m=ln,
    #     name="LinuxNetwork_populate",
    #     optionflags=doctest.NORMALIZE_WHITESPACE,
    #     globs=globals(),
    #     report=False,
    #     verbose=True,
    # )
    # if failed:
    #    

# Generated at 2022-06-11 03:38:54.672912
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    preferred_collector = 'LinuxNetworkCollector'
    collected_facts = {'distribution': 'Linux', 'platform': LinuxNetworkCollector._platform}
    lc = LinuxNetworkCollector(object(), collected_facts)
    # Test correct preferred_collector is returned
    assert lc.preferred_collector == preferred_collector
    # Test correct class is assigned to fact_class
    assert lc.fact_class == LinuxNetwork

# Generated at 2022-06-11 03:39:06.722962
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # all should pass
    for platform in ('Linux', 'AIX'):
        for distribution in ('Redhat', 'Debian', 'Fedora', 'CentOS', 'Ubuntu', 'LinuxMint', 'ArchLinux'):
            host = Host(LinuxNetworkCollector, platform=platform, distribution=distribution)
            actual = host.collector
            expected = LinuxNetworkCollector
            assert actual == expected

    # all should fail

# Generated at 2022-06-11 03:39:17.172900
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['all'], type='list'),
            use_ipv4=dict(default=True, type='bool'),
            use_ipv6=dict(default=True, type='bool'),
            config_file=dict(type='str'),
            ip_path=dict(default='', type='str')
        )
    )
    nm = LinuxNetwork(module=module)
    nm.populate()
    facts = module.params.get('ansible_facts', {}).get('ansible_network_resources', {})
    assert 'all_ipv4_addresses' in facts['ips']
    assert 'all_ipv6_addresses' in facts['ips']
    assert 'interfaces' in facts

# Generated at 2022-06-11 03:39:28.400789
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec={
            'command': {
                'default': ['/sbin/ip', '-oneline'],
                'type': 'list',
            },
        }
    )

    # Add the custom class to our module's dict
    module.LinuxNetwork = LinuxNetwork(module)

    # Test passing bad ipv4 command
    module.params['command'] = ['/fake/bin/ip', '-oh', 'wahtever']
    assert module.LinuxNetwork.get_default_interfaces() == ({}, {})
    module.params['command'] = ['/sbin/ip', 'abcd', 'ehfgl']

    # Test passing good ipv4 command

# Generated at 2022-06-11 03:39:38.974291
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-11 03:39:48.149095
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['all'], type='list'),
            gather_network_resources=dict(type='list'),
        ),
    )

    ln = LinuxNetwork(module)

    rc, out, err = ln.run_command(["ip", "route"], errors='surrogate_then_replace')
    if rc != 0:
        module.fail_json(msg='ip cmd failed')
    data = ln.get_interfaces_info(ln.module.get_bin_path('ip'), {}, {})
    assert isinstance(data[0], dict)
    assert isinstance(data[1], dict)

    # FIXME: this leaves system calls in an unknown state
    # FIXME: net is global and stateful
    net

# Generated at 2022-06-11 03:40:29.404932
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    # Create an instance of the AnsibleModule to be able to run tests
    module = AnsibleModule(
        argument_spec=dict()
    )

    # Create a instance of the MockedLinuxNetwork
    network = MockedLinuxNetwork(module)

    # Test with a single name and dictionary content
    name = 'fake_name'
    content = dict(key='value')
    network.populate(name, content)

    # Test that the result is a merged dict with the name
    assert name in network.GATHER_SUBSET
    assert network.GATHER_SUBSET[name] == content

    # Test with a list of names and a dict with one entry
    names = ['fake_name1', 'fake_name2']
    content = dict(key='value')
    network.populate(names, content)

    # Test that

# Generated at 2022-06-11 03:40:30.531913
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    assert True


# Generated at 2022-06-11 03:40:39.679843
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Not sure why but this only works if we do not use the @pytest.mark.skipif above
    if not HAS_ETHTOOL:
        pytest.skip("ethtool not found")

    from unittest import TestCase

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True)

    ln = LinuxNetwork()

    ln.module = module
    ln.INTERFACE_TYPE = {'1': 'loopback', '28': 'bridge', '61680': 'tunnel'}
    ln.IP_VERSION = {'AF_INET': 4, 'AF_INET6': 6}

    # we need some devices

# Generated at 2022-06-11 03:40:52.824657
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    test_class = LinuxNetwork(module)

    fake_ethtool_output = """
    Offload parameters for enp0s3:
    rx-checksumming: off
    tx-checksumming: off
    scatter-gather: off
    tcp-segmentation-offload: off
    udp-fragmentation-offload: off
    generic-segmentation-offload: off
    generic-receive-offload: off
    large-receive-offload: off
    rx-vlan-offload: off
    tx-vlan-offload: off
    ntuple-filters: off
    receive-hashing: off
    """


# Generated at 2022-06-11 03:41:03.771664
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """
    Test the function get_interfaces_info of class LinuxNetwork
    """
    module = AnsibleModule({})
    fn = LinuxNetwork()
    # A normal case

# Generated at 2022-06-11 03:41:14.573409
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-11 03:41:20.168637
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    import json

    # Test with a valid v4 and v6 route
    module = UnsafeFakeModule({
        "PATH": "/usr/sbin:/usr/bin:/sbin:/bin",
        "ANSIBLE_MODULE_ARGS": {
            "ip_path": "/bin/ip",
        },
    })
    ln = LinuxNetwork(module)
    fake_stdout = "default via 192.0.2.1 dev eth1 proto dhcp metric 100\ndefault via 2001:db8:1234::1 dev eth1 proto dhcp metric 100"

# Generated at 2022-06-11 03:41:27.722596
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    fake_module = FakeAnsibleModule()
    fake_module.params = {}
    obj = LinuxNetwork(fake_module)

    fake_device = 'dummy0'
    assert obj.get_ethtool_data(fake_device) == {
        'features': {
            'gso': 'on',
            'gro': 'off',
            'lro': 'off',
            'tso': 'on'
        },
        'timestamping': ['host'],
        'hw_timestamp_filters': ['all']
    }



# Generated at 2022-06-11 03:41:36.967308
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    obj = LinuxNetwork()
    obj.run_command = lambda command, diff=None, output_fields=None, check_rc=True, close_fds=True, executable=None: [""]


# Generated at 2022-06-11 03:41:41.249173
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    from .test_ansibullbot_module import AnsibullbotModule

    module = AnsibullbotModule(args=dict(loopback=True))
    ln = LinuxNetwork(module)
    ln.get_default_interfaces()
    # FIXME: assert something?



# Generated at 2022-06-11 03:42:25.473617
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    class C(object): pass
    class C2(object): pass
    class C3(object): pass

    m = C2()
    # set up a module that has the run_command we expect to be called
    m.run_command = C()
    m.run_command.return_value = 0, '/sbin/ip -4 route show 0/0', None
    # set up a module that has the get_bin_path we expect to be called
    m.get_bin_path = C3()
    m.get_bin_path.return_value = True

    ln = LinuxNetwork(m)

    _, default_ipv6 = ln.get_default_interfaces()

    assert default_ipv6['interface'] == 'eth0'


# Generated at 2022-06-11 03:42:35.417230
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """ test get_ethtool_data """
    import mock
    import platform
    realimport = __import__

    # Build a set of test cases (device, output and expected values)
    platform_id = platform.system()
    platform_release = platform.release()

# Generated at 2022-06-11 03:42:40.629913
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    m = LinuxNetwork()
    # device is a string and it is not in the code if it is empty.
    assert m.get_ethtool_data(device='') == {}
    assert m.get_ethtool_data(device='eth0') == {}

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 03:42:45.217468
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    ln = LinuxNetwork()
    path = '/tmp'
    default_ipv4 = {}
    default_ipv6 = {}
    rt = ln.get_interfaces_info(path, default_ipv4, default_ipv6)
    # assert that assertion here
    assert rt is None


# Generated at 2022-06-11 03:42:46.638730
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: Implement tests for get_interfaces_info()
    pass

# Generated at 2022-06-11 03:42:56.191575
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # create a dummy module and fake a persistent connection module
    module = FakeModule({
        'ansible_network_os': 'linux'
    })
    module.get_bin_path = lambda x: '/bin/ip'

# Generated at 2022-06-11 03:43:03.999186
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec={
            'gather_network_resources': {
                'type': 'list',
                'required': False,
                'default': ['interfaces', 'addresses'],
                'choices': ['interfaces', 'addresses']
            }
        }
    )

    network = LinuxNetwork(module)

    module.params['gather_network_resources'] = ['addresses']
    network.populate()
    addresses = network.get_option('addresses')
    assert addresses is not None
    assert 'all_ipv4_addresses' in addresses
    assert 'all_ipv6_addresses' in addresses

    module.params['gather_network_resources'] = ['interfaces']
    network.populate()
    interfaces = network.get_option('interfaces')


# Generated at 2022-06-11 03:43:05.751287
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    my_obj = LinuxNetwork()
    my_obj.populate()
    # unit test here...


# Generated at 2022-06-11 03:43:15.440549
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # This is an example of how to use unittest
    module = AnsibleModule(SUPPORTED_CONNECTION_INTERFACES)
    # This instantiates the class
    linuxnetwork = LinuxNetwork(module)
    # This gets the default_ipv4 and default_ipv6 from the method
    default_ipv4, default_ipv6 = linuxnetwork.get_default_interfaces()
    # This checks to see if we have an IPv4 address
    assert default_ipv4['address']
    # This checks to see if the IP address is a valid version of IPv4

# Generated at 2022-06-11 03:43:25.398071
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-11 03:44:02.348550
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec=dict())
    collector_instance = LinuxNetworkCollector(module)
    assert collector_instance.platform == 'Linux'


if __name__ == '__main__':
    main()

# Generated at 2022-06-11 03:44:04.423769
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    assert LinuxNetwork().get_default_interfaces() == {'default_ipv4': {}, 'default_ipv6': {}}

# Generated at 2022-06-11 03:44:13.880970
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    module = AnsibleModule(argument_spec=dict(
        gather_subset=dict(type='list', default=['all']),
        filter=dict(type='dict')
    ))


    # Remove the gather_subset options
    arg_spec = dict(
        filter=dict(type='dict')
    )

    module = AnsibleModule(argument_spec=arg_spec, supports_check_mode=True)
    linux_network = LinuxNetwork(module)


# Generated at 2022-06-11 03:44:24.554954
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    class ModuleMock(object):
        module = True

    class FakeCryptoManager(object):
        def __init__(self, *args, **kwargs):
            self.hashes = {}
        def digest(self, value):
            if value not in self.hashes:
                self.hashes[value] = md5(value.encode("utf-8")).hexdigest()
            return self.hashes[value]

    class FakePathManager(object):
        def __init__(self, *args, **kwargs):
            self.paths = {
                "ip": "/bin/",
                "ethtool": "/bin/",
            }

        def get_bin_path(self, cmd, opt_dirs=None, required=False):
            return self.paths[cmd]


# Generated at 2022-06-11 03:44:28.670761
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )
    nm = LinuxNetwork(module=module)
    nm.get_distribution()
    nm.get_default_device()
    nm.get_devices()
    nm.get_network_params()



# Generated at 2022-06-11 03:44:30.724799
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    host = LinuxNetwork()
    host.get_default_interfaces()
    # No assert because this method has no return value


# Generated at 2022-06-11 03:44:39.243138
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    network.get_interfaces_info =  MagicMock()
    network.get_interfaces_info.return_value = ({}, {})
    network.get_default_interfaces =  MagicMock()
    network.get_default_interfaces.return_value = ({'v4': {}}, {'v6': {}})
    network.get_interfaces_links =  MagicMock()
    network.get_interfaces_links.return_value = {'interfaces': {}, 'links': []}
    network.populate()
    assert not network.module.fail_json.called


# Generated at 2022-06-11 03:44:49.441129
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = None
    net = LinuxNetwork(module)
    data = net.get_ethtool_data('eth0')

    assert 'features' in data
    assert 'tx' in data['features']
    assert 'tx' in data['features']
    assert 'tx' in data['features']
    assert 'tx' in data['features']
    assert 'tx' in data['features']
    assert 'tx' in data['features']
    assert 'tx' in data['features']
    assert 'tx' in data['features']
    assert 'tx' in data['features']
    assert 'tx' in data['features']
    assert 'tx' in data['features']
    assert 'tx' in data['features']
    assert 'tx' in data['features']
    assert 'tx' in data['features']
    assert 'tx' in data

# Generated at 2022-06-11 03:44:59.341355
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text
    from tempfile import TemporaryDirectory


# Generated at 2022-06-11 03:45:02.209281
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # FIXME: this method is deprecated
    # NOTE: will be removed in Ansible 2.11
    assert False, "test_LinuxNetwork_get_default_interfaces not implemented"

# Generated at 2022-06-11 03:45:46.030622
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    # Arrange
    mock_module = MagicMock()
    mock_module.run_command.side_effect = [
        (0, 'default via 172.16.1.1 dev enp0s3 proto dhcp metric 100', ''),
        (0, 'default via fe80::20c:29ff:feb5:5226 dev enp0s3 proto ra metric 100 pref medium', ''),
    ]
    ln = LinuxNetwork(mock_module)

    # Act
    result = ln.get_default_interfaces()

    # Assert
    assert ['172.16.1.1', 'fe80::20c:29ff:feb5:5226'] == result
