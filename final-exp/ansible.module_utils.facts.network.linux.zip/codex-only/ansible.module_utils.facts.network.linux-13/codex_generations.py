

# Generated at 2022-06-23 00:06:28.893839
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = LinuxNetworkCollector(module)
    assert collector.module == module



# Generated at 2022-06-23 00:06:33.545250
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    # Constructor of LinuxNetwork
    # create a instance of an object network
    network = LinuxNetwork()
    # check if the object was created
    assert network
    # check if the interfaces attribute was created
    assert network.interfaces
    # check if the ips attribute was created
    assert network.ips

# Generated at 2022-06-23 00:06:38.534604
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    nm = LinuxNetwork(module)
    assert nm is not None


# Generated at 2022-06-23 00:06:45.860534
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # create a module to mock find ansible
    module = AnsibleModule(
        argument_spec = dict()
    )
    command_dict = {}

    # Run method
    ln = LinuxNetwork(module)
    ln.command_dict = command_dict
    ln.populate()

    # Check results
    assert ln.default_ipv4 is None
    assert ln.default_ipv6 is None
    assert ln.interfaces == {}
    assert ln.ips == {}


# Generated at 2022-06-23 00:06:58.403802
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    ln = LinuxNetwork(module)

    rc, default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert rc == 0
    if not default_ipv4:
        assert 'address' not in default_ipv4
        assert 'broadcast' not in default_ipv4
        assert 'netmask' not in default_ipv4
        assert 'network' not in default_ipv4
    if not default_ipv6:
        assert 'address' not in default_ipv6
        assert 'prefix' not in default_ipv6
        assert 'scope' not in default_ipv6


# Generated at 2022-06-23 00:07:10.664173
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # LinuxNetwork_test_obj is an instance of class LinuxNetwork
    LinuxNetwork_test_obj = LinuxNetwork(module)

    # get network device features for mock interface 'ethX'
    features_test_data = LinuxNetwork_test_obj.get_ethtool_data('ethX')

    # the returned data is a dictionary of key-value pairs
    assert isinstance(features_test_data, dict)

    # test that the returned dictionary includes the feature test key 'features'
    assert features_test_data.get('features', 'missing') != 'missing'

    # test that the value for key 'features' is also a dictionary
    assert isinstance(features_test_data['features'], dict)

    # test that the value for key 'features' contains at least one key
    assert len(features_test_data['features']) > 0



# Generated at 2022-06-23 00:07:15.093749
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule({})
    if not distro.check_distro():
        module.fail_json(msg="platform not supported")
    network = LinuxNetwork(module)
    distro_name = distro.get_distro().lower()
    expected_cls = NetworkConfig
    if distro_name.startswith('redhat'):
        expected_cls = RedHatNetworkConfig
    elif distro_name.startswith('suse') or distro_name == 'opensuse-leap':
        expected_cls = SuseNetworkConfig
    elif distro_name in ['ubuntu', 'debian']:
        expected_cls = DebianNetworkConfig
    elif distro_name in ['alpine']:
        expected_cls = AlpineNetworkConfig

# Generated at 2022-06-23 00:07:16.847270
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    assert LinuxNetworkCollector.platform == 'Linux'
    assert LinuxNetworkCollector._fact_class == LinuxNetwork
    assert LinuxNetworkCollector.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-23 00:07:28.527348
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    '''
    Test to check whether the constructor of LinuxNetworkCollector
    is functioning properly.
    '''
    module_mock = MagicMock()
    module_mock.run_command.return_value = (0, "", "")
    # Testing with empty module as input
    obj = LinuxNetworkCollector(module_mock)
    if not isinstance(obj.facts['default_ipv4'], dict):
        print("default_ipv4 is not dict")
        return False
    if not isinstance(obj.facts['default_ipv6'], dict):
        print("default_ipv6 is not dict")
        return False
    if obj.facts['default_ipv4'].get('address', None) is None:
        print("default_ipv4['address'] is None")
        return False


# Generated at 2022-06-23 00:07:32.052914
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    # Constructor test
    try:
        LinuxNetwork()
    except Exception as e:
        assert False, "Failed to create a LinuxNetwork object: %s" % e.message


# Generated at 2022-06-23 00:07:36.357255
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """Test get_interfaces_info method of LinuxNetwork class"""
    # initialize the class
    module = AnsibleModule(argument_spec={})
    network_info = LinuxNetwork(module)

    # result dictionary
    result = dict(
        default_ipv4={},
        default_ipv6={},
        interfaces={},
        ips={}
    )

    # list of expected keys
    interface_keys = [
        'default_ipv4',
        'default_ipv6',
        'interfaces',
        'ips',
    ]

    # check that all keys are present
    for key in interface_keys:
        assert key in result

    # check that the values are all empty dictionaries
    for key in interface_keys:
        assert isinstance(result[key], dict)

# Generated at 2022-06-23 00:07:44.462247
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    o = {'redhat': 'RedHat', 'suse': 'Suse', 'debian': 'Debian', 'centos': 'RedHat',
         'fedora': 'RedHat', 'vmware': 'VMwareESX', 'arch': 'Arch', 'gentoo': 'Gentoo'}

    for l in o.keys():
        m = LinuxNetworkCollector({'platform': 'Linux', 'distribution': l})
        assert m.get_facts()['ansible_os_family'] == 'RedHat'



# Generated at 2022-06-23 00:07:53.705531
# Unit test for method get_default_interfaces of class LinuxNetwork

# Generated at 2022-06-23 00:08:06.507088
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from tempfile import mkdtemp
    from shutil import rmtree
    from ansible_collections.ansible.netcommon.tests.unit.compat import unittest
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch, MagicMock, Mock, call
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.interfaces import Interface

    class AnsibleModuleMock:
        def __init__(self):
            self.params = {}
            self.config = {'device': 'eth0'}

    class AnsibleExitJson(Exception):
        pass

    class AnsibleFailJson(Exception):
        pass

    tempdir = mkdtemp()

# Generated at 2022-06-23 00:08:17.180391
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import json
    import shutil
    import tempfile
    import unittest
    import copy

    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    class TestModule(AnsibleModule):
        """ AnsibleModule with fake run_command() """
        def __init__(self, *args, **kwargs):
            super(TestModule, self).__init__(*args, **kwargs)
            self._cmd_cache = None

        def run_command(self, *cmd, **kwargs):
            if self._cmd_cache is not None:
                return self._cmd_cache
            self._cmd_cache = (0, '', '')
            return self._cmd_cache


# Generated at 2022-06-23 00:08:29.545356
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from distutils.version import LooseVersion
    from sys import version_info
    from unittest.mock import Mock, patch

    # import module snippets
    from ansible.module_utils.facts.network.linux import LinuxNetwork

    ln = LinuxNetwork(module=Mock())

    # version_info is a tuple of (major, minor, micro, releaselevel, serial)
    # py2/3, Python 3.2/3.3 have LooseVersion as (major, minor, patch, pre-release)
    # Python 3.4+ have LooseVersion as (major, minor, micro, releaselevel, serial)
    py34plus = LooseVersion(platform.python_version()) >= LooseVersion("3.4.0")

# Generated at 2022-06-23 00:08:40.338971
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # test_get_ethtool_data_with_ethtool_output_with_features
    linux_network = LinuxNetwork()
    ethtool_path = '/usr/sbin/ethtool'

# Generated at 2022-06-23 00:08:49.578594
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible.module_utils.facts.network.linux.linux_network import LinuxNetwork
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.linux.linux_default_ipv4 import LinuxDefaultIPv4
    from ansible.module_utils.facts.network.linux.linux_default_ipv6 import LinuxDefaultIPv6
    from ansible.module_utils.facts.network.linux.linux_dns_resolver import LinuxDnsResolver
    from ansible.module_utils.facts.network.linux.linux_interfaces import LinuxInterfaces
    from ansible.module_utils.facts.network.linux.linux_ipv4 import LinuxIPv4

# Generated at 2022-06-23 00:08:56.775949
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule(argument_spec={})
    net = LinuxNetwork(mod)
    default_ipv4, default_ipv6 = net.get_default_interfaces_info()
    interfaces_info = net.get_interfaces_info(default_ipv4, default_ipv6)
    return interfaces_info

# Generated at 2022-06-23 00:09:04.860645
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    from ansible.module_utils.basic import AnsibleModule
    import sys
    import json

    m = AnsibleModule(
        argument_spec=dict(
            interfaces=dict(type='dict', default={}),
        ),
        supports_check_mode=True,
    )

    ln = LinuxNetwork(module=m)

    interfaces = json.loads(m.params['interfaces'])

    v4_iface, v6_iface = ln.get_default_interfaces(interfaces, {'name': 'eth0', 'state': 'up'})
    assert v4_iface['address'] == '192.0.2.42'
    assert v6_iface['address'] == '2001:db8::42'

    v4_iface, v6_iface = ln.get_default

# Generated at 2022-06-23 00:09:16.150040
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})

    # fake/mocked tests
    n = LinuxNetwork(module)
    n.os_info = dict(distribution='Alpine',
                     major_release=3.3,
                     minor_release=3,
                     id=None,
                     distro=None,
                     codename=None,
                     description=None,
                     version=None,
                     version_best=None,)

    interfaces = dict(eth0=dict(),)

    n.get_interfaces_info = Mock(return_value=(interfaces, {}))

# Generated at 2022-06-23 00:09:20.731095
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    expected = dict(
        required_facts=set(['distribution', 'platform']),
        facts_module=LinuxNetwork,
        platform='Linux'
    )
    result = LinuxNetworkCollector(module)
    assert result.required_facts == expected['required_facts']
    assert result.facts_module == expected['facts_module']
    assert result._platform == expected['platform']


# Generated at 2022-06-23 00:09:29.229857
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    class FakeModule:
        def get_bin_path(self, path):
            return path
        def run_command(self, args, errors=None):
            return 0, "", ""
        def fail_json(self, **args):
            raise Exception("fail_json called")
    # TODO: real tests
    ln = LinuxNetwork(FakeModule(), dict(ansible_runner=dict(cwd='.')))
    print(ln.get_ethtool_data('eth0'))

# Generated at 2022-06-23 00:09:32.902797
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    network_module = AnsibleModule({},
                                   supports_check_mode=True)
    linux_network = LinuxNetwork(module=network_module)
    linux_network.populate()


# Generated at 2022-06-23 00:09:36.820577
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from ansible_collections.ansible.community.plugins.module_utils.network.common.facts.facts import Facts
    facts = Facts(dict(distribution='debian', platform='linux'))
    nc = LinuxNetworkCollector(facts, None)
    assert nc.platform == 'Linux'
    assert nc.required_facts == set(['distribution', 'platform'])
    assert nc.fact_class == LinuxNetwork



# Generated at 2022-06-23 00:09:41.940331
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    lo = LinuxNetwork(module)
    primary_interface = dict()
    primary_ipv4 = dict()
    primary_ipv6 = dict()
    lo.populate(primary_interface, primary_ipv4, primary_ipv6)
    module.exit_json(changed=False, primary_interface=primary_interface, primary_ipv4=primary_ipv4, primary_ipv6=primary_ipv6)


# Generated at 2022-06-23 00:09:44.037813
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    # test that object successfully created
    assert isinstance(LinuxNetworkCollector(module), LinuxNetworkCollector)


# Generated at 2022-06-23 00:09:48.555521
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = None
    # TODO: add unit tests
    # Testing all code paths is complex. While it would be nice to test all
    # code paths, given that this is a utility class which is only used in this
    # plugin, it might be best to skip unit tests and simply do integration
    # testing with the core module instead.



# Generated at 2022-06-23 00:09:55.905000
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.network import NetworkModule
    _m = AnsibleModule(NetworkModule)

    net = LinuxNetwork(_m)

    # define test input and expected output

# Generated at 2022-06-23 00:10:08.716495
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    # Set up a mock module
    module = AnsibleModule({})

    # Set up parameters
    ip_path = module.get_bin_path("ip", required=True)
    default_ipv4, default_ipv6 = get_default_interfaces()

    # Replace get_interfaces_info with our own function
    from mock_LinuxNetwork import get_interfaces_info
    LinuxNetwork.get_interfaces_info = get_interfaces_info

    # Create a LinuxNetwork object
    obj = LinuxNetwork(module)

    # Call the populate method
    obj.populate()

    # ipv6 was not enabled on the system
    assert obj.params['default_ipv6'] is None
    assert len(obj.params['interfaces']) == 2
    assert "em1" in obj.params['interfaces']
   

# Generated at 2022-06-23 00:10:20.776829
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Prepare the test environment
    class TestModule:
        def get_bin_path(self, arg):
            return "/usr/sbin/ip"

    # Test with no optional parameters
    m = TestModule()
    ln = LinuxNetwork(m)
    ln.populate()

    assert isinstance(ln.interfaces, dict)
    assert isinstance(ln.default_ipv4, dict)
    assert isinstance(ln.default_ipv6, dict)
    assert isinstance(ln.all_ipv4_addresses, list)
    assert isinstance(ln.all_ipv6_addresses, list)
    assert isinstance(ln.gateway_ipv4, dict)
    assert isinstance(ln.gateway_ipv6, dict)

# Generated at 2022-06-23 00:10:33.102119
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network = LinuxNetwork()
    ethtool_path = linux_network.module.get_bin_path("ethtool")
    if not ethtool_path:
        ethtool_path = "/sbin/ethtool"
    device = "lo"

# Generated at 2022-06-23 00:10:46.216715
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    m = AnsibleModuleMock({
        'ANSIBLE_MODULE_ARGS': {}
    })

    test_obj = LinuxNetwork(m)

    # mock get_gateway_from_iproute2
    mocks = {
        "get_gateway_from_iproute2": MockedAnsibleModule(m, out='''
default via 10.0.1.1 dev enp0s3 proto dhcp metric 100
10.0.1.0/24 dev enp0s3 proto kernel scope link src 10.0.1.165 metric 100
10.0.1.0/24 dev enp0s3 proto kernel scope link src 10.0.1.10 metric 100
''')
    }


# Generated at 2022-06-23 00:10:48.408068
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModuleMock()
    net = LinuxNetwork(module)
    assert(net.module == module)


# Generated at 2022-06-23 00:10:57.050457
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    ln = LinuxNetwork(module)
    # : is a reserved character in jinja2 variables
    device = "eth0:"


# Generated at 2022-06-23 00:11:09.459959
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    my_module = AnsibleModule(argument_spec=dict())
    my_module.get_bin_path = Mock(return_value='/bin/ip')
    my_module.run_command = Mock(return_value=(0, '', ''))
    my_LinuxNetwork = LinuxNetwork(module=my_module)
    my_LinuxNetwork.get_ethtool_data = Mock(return_value={'features': {u'rx-checksumming': u'off'}})

    # default_ipv4 is a reference and is updated inside the method
    my_LinuxNetwork.get_interfaces_info(args.ip_path, args.default_ipv4, args.default_ipv6)

    assert my_LinuxNetwork.get_ethtool_data.call_count == 2



# Generated at 2022-06-23 00:11:19.007628
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # check whether ethtool exists on this system
    eth_path = module.get_bin_path("ethtool")
    if not eth_path:
        module.fail_json(msg="ethtool is not installed on this system")
    ln = LinuxNetwork()
    rc, stdout, stderr = module.run_command("ip -4 route get 8.8.8.8")
    for line in stdout.splitlines():
        if "dev" in line:
            device = line.split()[4]
    data = ln.get_ethtool_data(device)
    assert data


# Generated at 2022-06-23 00:11:26.179059
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """Unit test of LinuxNetworkCollector constructor"""
    module = Mock()
    net_collector = NetworkCollector(module)
    assert(isinstance(net_collector, NetworkCollector))
    assert(net_collector._platform == "Linux")
    # FIXME: not sure if this is a valid assert
    # equals is not working for some reason
    assert(net_collector._fact_class is LinuxNetwork)
    assert(net_collector.required_facts == set(['platform', 'distribution']))


# Generated at 2022-06-23 00:11:35.681543
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    class MockedAnsibleModule:
        def __init__(self, params):
            self.params = params
            self.get_bin_path = lambda x: '/bin/ip'

        def run_command(self, command, **kwargs):
            return (0, "", "")

    # TODO: split into smaller tests, like table-driven tests
    module = MockedAnsibleModule({})
    assert LinuxNetwork(module=module).get_default_interfaces() == \
        ({'default_ipv4': {}, 'default_ipv6': {}}, {})

# Generated at 2022-06-23 00:11:48.258713
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = MockLinuxNetworkModule()
    linux_network = LinuxNetwork(module)

# Generated at 2022-06-23 00:11:51.537564
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    m = AnsibleModule(
        argument_spec=dict(
            device=dict(required=True, default=None),
        )
    )

    ln = LinuxNetwork()
    result = ln.get_ethtool_data(m.params['device'])
    m.exit_json(result=result, changed=False)


# Generated at 2022-06-23 00:12:04.932082
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    # Run test with various test data.
    # TODO: use the data from tests/unittests/test_linux_network_module.py
    # FIXME: See ansible/ansible#62430
    #for data in fake_linux_network:
    #    pass
    # TODO: refactor this into a proper unit test with fake_linux_network data
    # and a fixture for a module mock
    module = FakeModule(
        ip_path=FAKE_IP_PATH,
        ifconfig_path=FAKE_IFCONFIG_PATH,
        params=dict(
            default_ipv4=dict(address=FAKE_DEFAULT_IPV4_ADDRESS),
            default_ipv6=dict(address=FAKE_DEFAULT_IPV6_ADDRESS),
        )
    )

# Generated at 2022-06-23 00:12:17.718352
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=(['!all', 'min'])
        ),
        supports_check_mode=True
    )

    fixture = Network(module)
    fixture.populate()

    facts = module.params['ansible_facts']
    assert 'ansible_all_ipv4_addresses' in facts
    assert 'ansible_all_ipv6_addresses' in facts
    assert 'ansible_default_ipv4' in facts
    assert 'ansible_default_ipv6' in facts
    assert 'ansible_interfaces' in facts
    assert 'ansible_machine_id' in facts
    assert 'ansible_netmask' in facts
    assert 'ansible_netmask_bits' in facts

# Generated at 2022-06-23 00:12:21.699301
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """
    Constructor of class LinuxNetworkCollector should set attribute _fact_class to
    LinuxNetwork, as specified in the class documentation.
    """
    lnc = LinuxNetworkCollector()
    assert lnc._fact_class == LinuxNetwork

# Generated at 2022-06-23 00:12:34.663228
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    ln = LinuxNetwork()

    ln.module = Mock()
    ln.module.run_command = Mock()

    def run_command(args, *_, **__):
        if args[-1] == 'default_ipv6':
            return 1, 'default via fe80::2 dev eth0  proto kernel  metric 1024  pref medium', None
        if args[-1] == 'default_ipv4':
            return 1, 'default via 10.0.0.1 dev eth0  proto static  metric 1024  pref medium', None

    ln.module.run_command.side_effect = run_command

    interface_v4, interface_v6 = ln.get_default_interfaces()


# Generated at 2022-06-23 00:12:39.305928
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    unittest.TestCase.assertEqual('foo', 'foo')
    l = LinuxNetwork()
    unittest.TestCase.assertIsInstance(l, LinuxNetwork)
    unittest.TestCase.assertIsInstance(l.interface, dict)
    unittest.TestCase.assertIsInstance(l.ips, dict)


# Generated at 2022-06-23 00:12:50.209542
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    args = dict(  ip_path='/sbin/ip',
                  default_ipv4=dict(address='0.0.0.0', network='0.0.0.0', netmask='0.0.0.0', broadcast='0.0.0.0'),
                  default_ipv6=dict(address='::', network='::', prefixlen='::', scope='::')
              )
    Obj = mock.Mock()
    Obj.run_command.return_value = (0, __sample_ip_addr_output, '')
    Obj.get_bin_path.return_value = '/sbin/ip'
    Obj.MODULE_COMPLEX_ARGS.__getitem__.return_value = '/sbin/ip'
    Obj.boolean.return_value = True

# Generated at 2022-06-23 00:13:02.537708
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    import platform
    import unittest

    class LinuxNetworkTest(unittest.TestCase):
        def setUp(self):
            self.ln = LinuxNetwork()

        def test_get_distribution(self):
            distribution, release, codename = self.ln.get_distribution()
            self.assertTrue(any(distribution == d for d in ['RedHat', 'CentOS', 'OracleLinux', 'Fedora', 'Debian', 'Ubuntu', 'Raspbian', 'OpenWrt', 'Alpine', 'OpenSUSE']))

        def test_get_default_ipv4(self):
            # this method is impure and depends on the environment
            default_ipv4 = self.ln.get_default_ipv4()

# Generated at 2022-06-23 00:13:06.288741
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    network = LinuxNetwork()

    assert network.get_file_content("/tmp/does_not_exist") is None
    assert network.get_file_content("/tmp/does_not_exist", default=1) == 1
    assert len(network.get_all_interfaces()) > 1



# Generated at 2022-06-23 00:13:18.012680
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    m = AnsibleModule({})
    n = LinuxNetwork(m)
    # NOTE: mocks are great!
    interfaces, ips = n.get_interfaces_info('ip',
                                            default_ipv4={'address': '1.2.3.4'},
                                            default_ipv6={'address': '::1'})

# Generated at 2022-06-23 00:13:31.007952
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Set some test vars for the LinuxNetwork instance
    module = MagicMock()
    ip = 'ip'
    default_ipv4 = {}
    default_ipv6 = {}
    class_ = LinuxNetwork(module=module, ip=ip)

    # Test IPv4 only
    interface = {
        'device': 'lo',
        'ipv4': {
            'address': '127.0.0.1',
            'netmask': '255.0.0.0',
            'broadcast': '0.0.0.0'
        }
    }
    interfaces = {'lo': interface}
    result = class_.get_default_interfaces(interfaces, default_ipv4, default_ipv6)

# Generated at 2022-06-23 00:13:37.298554
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock(return_value=(0, "Result of get_ethtool_data", ""))
    network = LinuxNetwork(module)
    assert network.get_ethtool_data("foo") == {"features": {}, "timestamping": [], "hw_timestamp_filters": [], "phc_index": None}



# Generated at 2022-06-23 00:13:43.017712
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module_mock = MagicMock()
    module_mock.check_mode = False
    module_mock.run_command.return_value = (0, '', '')
    ln = LinuxNetwork(module_mock)
    ln.get_ethtool_data('eth0')



# Generated at 2022-06-23 00:13:52.072740
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    network = LinuxNetwork()
    network.populate()

    # TODO: split into multiple test cases?
    # TODO: check type of attributes too?

    assert isinstance(network.ipv4, dict)
    assert isinstance(network.ipv6, dict)
    assert isinstance(network.interfaces, dict)
    assert isinstance(network.default_ipv4, dict)
    assert isinstance(network.default_ipv6, dict)
    assert 'all_ipv4_addresses' in network.ipv4
    assert 'all_ipv6_addresses' in network.ipv6
    assert isinstance(network.ipv4['all_ipv4_addresses'], list)
    assert isinstance(network.ipv6['all_ipv6_addresses'], list)



# Generated at 2022-06-23 00:14:02.876507
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec=dict())
    module.exit_json = MagicMock(return_value={'interfaces': 'foo'})
    import NetworkManager
    # NOTE: These tests only run when NetworkManager is not running so ensure it is running
    nmstate = NetworkManager.State.DISCONNECTED
    if NetworkManager.is_managed():
        nmstate = NetworkManager.NetworkManager.state()
        NetworkManager.NetworkManager.stop()

    default_interface = {'active': True, 'device': 'eth0'}
    default_ipv4 = {'address': '192.0.2.1', 'default_interface': 'eth0'}
    default_ipv6 = {'address': '2001:DB8::1', 'default_interface': 'eth0'}

# Generated at 2022-06-23 00:14:14.695594
# Unit test for method populate of class LinuxNetwork

# Generated at 2022-06-23 00:14:26.182244
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec=dict(
        network_delimiter=dict(type='str', default='-'),
        network_dump=dict(type='bool', default=False),
        network_debug=dict(type='bool', default=False),
    ))
    network = LinuxNetwork(module=module)
    network.populate(
        sys_interfaces=dict(),
        ip_path='/sbin/ip',
        nm_path='/usr/bin/nmcli',
        config_file='/etc/sysconfig/network-scripts/ifcfg-eth0',
        config_file_exists=True,
    )
    # TODO: add assertions here


# Generated at 2022-06-23 00:14:39.517578
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.fail_json = lambda *args, **kwargs: None

    # FIXME: these addresses are ipv4 specific, need to find ipv6 equivalent

# Generated at 2022-06-23 00:14:52.476537
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    """ get_default_interfaces returns a dict of {'4|6': {address: '192.168.1.1', gateway: '192.168.1.254'}}
    where the ipv{4,6} is a string, the values are all strings, and there is no 'gateway' key for ipv6
    """

    # Assert simple case, 1 interface with route and address

# Generated at 2022-06-23 00:14:56.665851
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    mc = LinuxNetworkCollector()
    assert mc._platform == 'Linux'
    assert mc._fact_class == LinuxNetwork
    assert mc.required_facts == {'distribution', 'platform'}
# end of Unit test for constructor of class LinuxNetworkCollector


# Generated at 2022-06-23 00:15:08.690795
# Unit test for method get_default_interfaces of class LinuxNetwork

# Generated at 2022-06-23 00:15:21.203078
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json

    linux_net = LinuxNetwork(module)
    interface = {
        'v4': {
            'address': '192.168.0.2',
            'broadcast': '255.255.255.255',
            'netmask': '255.255.255.0',
            'network': '192.168.0.0'
        },
        'v6': {
            'address': '2001:0db8:85a3:0000:0000:8a2e:0370:7334',
            'prefix': '64'
        }
    }

    # get_interfaces_info() with default params

# Generated at 2022-06-23 00:15:32.618224
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModuleDummy()
    module.params = dict(
        config_file='/etc/ansible/interfaces',
        config_dir='/etc/ansible/interfaces.d',
        config_format='ini',
    )
    network = LinuxNetwork(module)

    assert network.interface_file is not None
    assert network.interface_file.endswith('/etc/ansible/interfaces')
    assert network.interface_dir is not None
    assert network.interface_dir.endswith('/etc/ansible/interfaces.d')
    assert network.config_format == 'ini'
    assert network.is_enabled()
    assert network.has_handlers()


# Generated at 2022-06-23 00:15:42.505251
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from ansible.module_utils.facts.collector import Getter
    from ansible.module_utils.facts.facts import Facts
    from ansible.module_utils.facts.hardware.network import NetworkCollector
    from ansible.module_utils.facts.hardware.network import LinuxNetworkCollector
    from ansible.module_utils.facts.hardware.network import LinuxNetwork

    test_getter = Getter(module=None)
    test_facts = Facts(module=None)

    network = LinuxNetworkCollector(module=None)
    # test class variables
    assert network._platform == 'Linux'
    assert network._fact_class == LinuxNetwork
    assert network.required_facts == {'distribution', 'platform'}

# Unit Test for function run(self) in class LinuxNetworkCollector

# Generated at 2022-06-23 00:15:55.452500
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    import json
    import os
    import sys

    # If we are in a virtualenv, the linux distro detection code fails.  So
    # we use this flag to override the virtualenv behavior so we can run the
    # unit tests in a virtualenv.
    #
    # This does not affect the actual code path for the module code.
    os.environ['_ANSIBLE_TEST_LINUX_DISTRO'] = "python-test-distro"

    # We have to override the module_utils location to our test directory
    # so we can load the test code in module_utils so we can use it
    saved_module_path = sys.path[:]
    for i in saved_module_path:
        sys.path.remove(i)
    sys.path.append('test/unit/test-module-utils')
    sys

# Generated at 2022-06-23 00:16:05.086498
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    def fake_run_command(self):
        return 0, '192.0.2.1\n', ''

    module = Mock(base_dir=os.getcwd(), get_bin_path=lambda x: x)
    module.run_command = fake_run_command

    linux_network = LinuxNetwork(module)
    default_ipv4, default_ipv6 = linux_network.get_default_interfaces()

    assert 'address' in default_ipv4 and default_ipv4['address'] == '192.0.2.1'
    assert 'address' not in default_ipv6



# Generated at 2022-06-23 00:16:13.989279
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    """This is a test for init of LinuxNetwork."""
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

    # Check if the needed environment variable is set
    if os.environ.get('DIST_ZOO'):
        zoo = True
        distributions = os.environ.get('DIST_ZOO')
    else:
        zoo = False
        distributions = ['alpine:v3.9']

    # Iterate through all distributions
    for item in distributions.split(':'):
        # Check if the python module distro is available
        if not distro_exists:
            module.fail_json(msg="python module distro is not installed")
        # split the distribution name and version, e.g. "ubuntu:bionic"
        distro_name, distro_version

# Generated at 2022-06-23 00:16:26.026791
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    output = []
    for i in range(1, 4):
        path = "test/unit/test_module_utils_network_linux/test_data/ifcfg-eth{}".format(i)
        output.append(get_file_content(path, default='').strip())

    def _exec_module(module):
        return str(module.linux_network.get_interfaces_info('fake_path', {'address': '1.1.1.1'}, {'address': '2.2.2.2'}))

    # NOTE: you may need to alter this method signature for other platforms
    module.run_command = MagicMock(side_effect=output)
    module.get_bin_path = MagicMock(return_value="/bin/foo")

# Generated at 2022-06-23 00:16:32.095706
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})