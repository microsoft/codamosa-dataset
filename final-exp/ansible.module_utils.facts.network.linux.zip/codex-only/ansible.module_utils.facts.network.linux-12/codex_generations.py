

# Generated at 2022-06-23 00:06:28.600284
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    pass


# Generated at 2022-06-23 00:06:30.907792
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    assert LinuxNetwork({}).get_default_interfaces() == ('', '')


# Generated at 2022-06-23 00:06:40.953516
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """ This method is the unit test for method get_interfaces_info of class LinuxNetwork """

    # Create a mock of Platform
    # Monkey patching is also done in main() to use the mock
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.bin_path = None

        def get_bin_path(self, bin_name, required=False):
            # bin_path is an attribute of the mock object
            # rather than a method
            try:
                return os.path.join(self.bin_path, bin_name)
            except KeyError:
                return None
    platform_mock = MockModule()

    # Get the path of the real ethtool binary
    ethtool_path = get_bin_path('ethtool')

# Generated at 2022-06-23 00:06:45.042679
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """Test the constructor of LinuxNetworkCollector"""
    nc = LinuxNetworkCollector()
    assert nc.platform == 'Linux'
    assert nc.fact_class.__name__ == 'LinuxNetwork'


# Unit test

# Generated at 2022-06-23 00:06:52.037749
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    ansible_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )

    # This is a fake Module class that is used to pass around
    # the dict of ipv4 and ipv6 interfaces to test.

    # It is also used to provide a fake implementation of
    # the function get_system_localtime() but this is not
    # used by the method populate()

    class FakeModule(object):
        def __init__(self, dict_interfaces):
            self.dict_interfaces = dict_interfaces

    class FakeLinuxSystem(object):
        def __init__(self):
            print("This is a fake init")

        def get_system_localtime(self):
            print("This is a fake implementation of get_system_localtime")
            return None


# Generated at 2022-06-23 00:07:01.378987
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    net = LinuxNetwork(None)
    net.execute = MockExecute(content='')
    assert net.get_default_interfaces() == ('eth0', 'eth0')
    net.execute = MockExecute(content='ens3')
    assert net.get_default_interfaces() == ('ens3', 'ens3')
    net.execute = MockExecute(content='ens3\tens4')
    assert net.get_default_interfaces() == ('ens3', 'ens4')
    net.execute = MockExecute(content='ens3 ens4')
    assert net.get_default_interfaces() == ('ens3', 'ens4')

# Generated at 2022-06-23 00:07:07.527621
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    f = LinuxNetworkCollector(None)
    assert isinstance(f, LinuxNetworkCollector)
    assert f._platform == 'Linux'
    assert f.required_facts == set(['distribution', 'platform'])
    assert f.collect()


# Generated at 2022-06-23 00:07:17.579010
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    sample_input_output = [
        ({"ethtool": "/path/to/ethtool"}, "lo", {
            "features": {},
            "timestamping": ["hw", "sw"],
            "hw_timestamp_filters": ["all", "some"],
        }),
    ]

    for (module, device, expected_result) in sample_input_output:
        mock_module = MagicMock(params={"supported_check": False})
        mock_module.get_bin_path.side_effect = module.get
        network = LinuxNetwork(mock_module)
        if "ethtool" in module:
            mock_module.run_command.return_value = (0, "", "")

# Generated at 2022-06-23 00:07:20.473467
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    res = LinuxNetwork(module)

# Generated at 2022-06-23 00:07:33.823284
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    import pprint
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.process import get_bin_path

    ip_path = get_bin_path('ip')
    default_ipv4 = {'address': '88.190.222.205', 'netmask': '255.255.255.0', 'network': '88.190.222.0'}
    default_ipv6 = {'address': '2a01:e35:2f1b:cbc0:69b1:c1ff:feee:a28f', 'prefix': '64', 'scope': 'link'}
    test_LinuxNetwork = LinuxNetwork()
    test_LinuxNetwork.module = LinuxNetwork()
    test_LinuxNetwork.module.run_command = my_run_command
    data

# Generated at 2022-06-23 00:07:36.286046
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # TODO: actually test this
    return
    _l = LinuxNetwork(dict())
    _l.get_default_interfaces()


# Generated at 2022-06-23 00:07:48.003311
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
        mutually_exclusive=[],
        required_one_of=[],
        required_together=[],
    )

    # most of these are implemented in the base class
    # which is not directly tested here
    ln = LinuxNetwork(module)
    result = ln.populate()

    # FIXME: un-skip this test?
    assert result != None, "populate() should not return None"
    assert 'gather_network_resources_fact' in result, "populate() should define gather_network_resources_fact"
    assert 'ansible_all_ipv4_addresses' in result, "populate() should define ansible_all_ipv4_addresses"

# Generated at 2022-06-23 00:07:49.367296
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: write unit tests
    pass



# Generated at 2022-06-23 00:07:59.400956
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    class DummyModule:
        params = {}
        def get_bin_path(self, arg):
            pass
        def run_command(self, arg):
            pass
        def get_version(self):
            return '2.6.32-431.29.2.el6.x86_64'

    # Test with no interfaces
    interfaces = {}
    default_ipv4 = {}
    default_ipv6 = {}
    ethtool_path = ""
    ip_path = ""

    ln = LinuxNetwork(DummyModule)
    ln.get_interfaces_info = MagicMock(return_value=(interfaces, {}))
    ln.is_default_route = MagicMock(return_value=(default_ipv4, default_ipv6))

# Generated at 2022-06-23 00:08:12.446423
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = DummyModule()
    module.run_command = MagicMock(side_effect=[(0, 'default via 192.0.2.1 dev eth0 proto static', ''),
                                                (0, 'default via 2001:db8::1 dev eth0 proto static metric 1024', ''),
                                                (0, '192.0.2.0/24 via 192.0.2.1 dev eth0 proto static', ''),
                                                (0, '2001:db8::/64 via 2001:db8::1 dev eth0 proto static metric 1024', ''),
                                                (0, '', ''),
                                                (0, '', ''),
                                                (1, 'Failed to read routing table', ''),
                                                (1, 'Failed to read routing table', '')])
    lnx = Linux

# Generated at 2022-06-23 00:08:20.029257
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = Mock()
    ln = LinuxNetwork(module)
    module.run_command = Mock()
    # new_addrs = {'lo': ['127.0.0.1/8', '::1/128'], 'eth0': ['192.168.1.42/24', 'fe80::a00:27ff:fece:1c4a/64']}
    # addresses = {'lo': ['127.0.0.1/8', '::1/128'], 'eth0': ['192.168.1.42/24', 'fe80::a00:27ff:fece:1c4a/64', '192.168.1.2/24']}

# Generated at 2022-06-23 00:08:34.895566
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network = LinuxNetwork()

# Generated at 2022-06-23 00:08:39.045489
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModuleMock()
    network_collector = LinuxNetworkCollector(module)
    assert network_collector.platform == 'Linux'
    assert network_collector.fact_class == LinuxNetwork
    assert network_collector.required_facts == {'distribution', 'platform'}


# Generated at 2022-06-23 00:08:48.735781
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # pylint: disable=line-too-long
    module = AnsibleModule(
        argument_spec=dict(),
    )
    network = LinuxNetwork(module)
    interfaces, ips = network.get_interfaces_info("ip", dict(address='192.168.1.1'), dict(address='2001:db8::1'))
    # display all interfaces
    for interface in interfaces:
        print("interface name %s" % interface)
        for key in sorted(interfaces[interface]):
            print("  %s: %s" % (key, interfaces[interface][key]))
    if 'all_ipv4_addresses' in ips:
        for addr in ips['all_ipv4_addresses']:
            print("ipv4 address %s" % addr)

# Generated at 2022-06-23 00:09:01.235624
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    interface_name_starts_with_e = 'eth0'
    fully_qual_file_path = '/sys/class/net/%s/address' % interface_name_starts_with_e
    fully_qual_file_path_pciid = '/sys/class/net/%s/device/driver/module' % interface_name_starts_with_e

    mock_run_command = mock_module.run_command
    mock_get_bin_path = mock_module.get_bin_path
    mock_get_bin_path.return_value = "/bin/ip"

    mock_open = mock_builtins.open
    mock_open.return_value = mock_file_spec
    mock_file = mock.MagicMock()
    mock_file_spec.return_value = mock_file
   

# Generated at 2022-06-23 00:09:14.120209
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    '''
    Unit test for method get_interfaces_info of class LinuxNetwork
    '''

    # FIXME: flesh out
    import json

    class FakeModule(object):
        def __init__(self, device=None):
            self.params = {}
            self.check_mode = False
            self.debug = False
            self.run_command = self.mock_run_command

            self.device = device

        def mock_run_command(self, cmd, *args, **kwargs):
            result = {
                'stdout': '',
                'stderr': '',
                'rc': 0,
            }
            if self.debug:
                pprint(dict(cmd=cmd, args=args, kwargs=kwargs))

# Generated at 2022-06-23 00:09:22.083879
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    m = LinuxNetworkModule()
    n = LinuxNetwork(m)
    data = n.get_ethtool_data("lo")

# Generated at 2022-06-23 00:09:34.447545
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    fake_module = FakeModule()
    fake_module.params['gather_subset'] = 'all'
    fake_module.run_command = FakeRunCommand()
    fake_module.run_command.stdout = DEFAULT_RUN_COMMAND_STDOUT

# Generated at 2022-06-23 00:09:36.119004
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    return check_args(LinuxNetwork(module).populate())


# Generated at 2022-06-23 00:09:43.598261
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    my_linux = LinuxNetwork()

    # Get artificial data for /sys/class/net
    class Mock():
        def __init__(self):
            self.device = None
            self.path = None
            self.content = None
            self.realpath = None
            self.os_path_isdir = None
            self.os_path_exists = None
            self.os_readlink = None
            self.os_listdir = None
            self.os_path_join = None
            self.glob_glob = None

    mock = Mock()
    mock.path = "/sys/class/net"
    mock.device = "eth0"
    mock.content = "00:11:22:33:44:55"

# Generated at 2022-06-23 00:09:45.188282
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    lnc = LinuxNetworkCollector(dict())
    assert lnc._platform == 'Linux'
    assert lnc.required_facts == set(['distribution', 'platform'])



# Generated at 2022-06-23 00:09:52.776564
# Unit test for method populate of class LinuxNetwork

# Generated at 2022-06-23 00:10:05.287141
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """
    Issue: https://github.com/ansible/ansible/issues/55081
    """

# Generated at 2022-06-23 00:10:18.084875
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    facts = dict(
        default_ipv4=dict(), default_ipv6=dict(),
        ips=dict(), interfaces=dict(),
        ip_path='/sbin/ip', interface_ipv4=dict(),
        interface_ipv6=dict(interface='eth0', address='2001:db8::1', gateway='2001:db8::2'),
    )
    instance = LinuxNetwork(dict(), dict())
    return_value = instance.populate(facts)
    assert return_value is None
    assert facts['default_ipv4'] == dict(interface='eth0', address='192.0.2.1', netmask='255.255.255.0', network='192.0.2.0')

# Generated at 2022-06-23 00:10:30.583431
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    obj = LinuxNetwork()

# Generated at 2022-06-23 00:10:43.271577
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    l = LinuxNetwork(None)
    d = {'ipv4': {'address': '1.1.1.1', 'broadcast': '2.2.2.2',
                  'alias': 'ens32', 'netmask': '3.3.3.3', 'network': '4.4.4.4'},
         'ipv6': [{'address': '5.5.5.5', 'prefix': '6',
                   'scope': '7'}],
         'macaddress': '8.8.8.8',
         'mtu': 9,
         'type': 't'}
    i = {'name': 'foo', 'device': 'bar'}
    l.populate(i, d)

# Generated at 2022-06-23 00:10:48.817509
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    collector = LinuxNetworkCollector(module)
    assert collector
    assert collector._platform == 'Linux'
    assert collector._fact_class == LinuxNetwork
    assert collector.required_facts == set(['distribution', 'platform'])


# Unit test of class LinuxNetwork

# Generated at 2022-06-23 00:10:57.195616
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    ln = LinuxNetwork()

    # Provide a known output to simulate
    def side_effect_get_file_content(arg):
        if arg == "/proc/net/route":
            return "Iface Destination Gateway Flags RefCnt Use Metric Mask MTU Window IRTT\neth1 00000000 FF000000 0003 0 0 0 00000000 0 0 0"
        elif arg == "/proc/net/ipv6_route":
            return "00000000000000000000000000000000 00 00000000000000000000000000000000 00 00 00 00 00000000 00000000    0 0 0 eth1"
        else:
            raise NotImplementedError

    ln.get_file_content = MagicMock(side_effect=side_effect_get_file_content)
    rc = 0
    command_v4 = [ln.ip_path, 'route', 'get', 'to', 'default']
    out_v

# Generated at 2022-06-23 00:11:09.931995
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock()
    module.get_bin_path = MagicMock(return_value="/bin/ip")

# Generated at 2022-06-23 00:11:22.386480
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """Test get_ethtool_data method of LinuxNetwork class"""
    # pylint: disable=invalid-name
    m = AnsibleModule({})
    # pylint: disable=unused-argument
    def run_command(args, **kwargs):
        """mocked run_command"""
        # pylint: disable=unused-argument
        if args == [ethtool_path, '-k', device]:
            return (0, ETHTOOL_K, '')
        if args == [ethtool_path, '-T', device]:
            return (0, ETHTOOL_T, '')
        return (0, '', '')
    ethtool_path = '/sbin/ethtool'
    device = 'em1'

    class MockedModule():
        """mocked module"""

# Generated at 2022-06-23 00:11:29.016271
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(type='list', elements='str', default=[]),
    })
    # FIXME: testing this class requires a system in a very specific configuration
    # which we do not have in our test system.
    # Therefore, we can only test the basic sanity checks of this method
    network = LinuxNetwork(module=module)
    network.populate()
    assert network.data['default_ipv4']
    assert network.data['default_ipv6']
    assert network.data['interfaces']
    assert network.data['ips']



# Generated at 2022-06-23 00:11:30.729842
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    lnc = LinuxNetworkCollector()
    assert lnc._platform == 'Linux'
    assert lnc._fact_class == LinuxNetwork
    assert lnc.required_facts == set(['distribution', 'platform'])

# Generated at 2022-06-23 00:11:38.624936
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    # NOTE: this purposefully calls LinuxNetwork with a stub module
    netinfo = LinuxNetwork(dict(
        ANSIBLE_MODULE_ARGS=dict(gather_subset='all'),
        ansible_facts=dict(),
    ))
    return netinfo


if __name__ == '__main__':
    netinfo = test_LinuxNetwork()
    print(json.dumps(netinfo.get_interfaces_details()))

# Generated at 2022-06-23 00:11:50.424329
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    ipv4_data = {'address': '10.4.4.4',
                 'netmask': '255.255.255.0',
                 'network': '10.4.4.0'}
    ipv6_data = {'address': '2001:0:53aa:64c:416e:d9ff:fe1b:9318',
                 'prefix': '128',
                 'scope': 'global'}
    args = dict(
        ipv4_data=ipv4_data,
        ipv6_data=ipv6_data,
    )
    module = AnsibleModule(argument_spec=args)
    # module.params
    # module.verbose
    # module.debug
    ln = LinuxNetwork(module)


# Generated at 2022-06-23 00:12:02.818901
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = Mock(return_value='/bin/ethtool')

# Generated at 2022-06-23 00:12:06.693346
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    network = LinuxNetwork(module)
    assert network.get_default_interfaces() == ('eth0', 'eth0')

# Generated at 2022-06-23 00:12:12.995378
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    r = ln.get_interfaces_info('/sbin/ip', {}, {})
    from pprint import pprint
    pprint(r)
    assert len(r) == 2

if __name__ == '__main__':
    test_LinuxNetwork()

# Generated at 2022-06-23 00:12:25.073518
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    m = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(m)
    default_ipv4 = dict(address="192.168.56.10")
    default_ipv6 = dict(address="10fe:cd87:15e9:7c8e:2a6c:baff:feef:555")
    interfaces = linux_network.get_interfaces_info([], default_ipv4, default_ipv6)
    assert "eth0" in interfaces
    assert "eth1" in interfaces
    assert "lo" in interfaces
    assert "br0" in interfaces
    assert "bond0" in interfaces
    assert "eth2" in interfaces
    assert "eth3" in interfaces
    assert "eth4" in interfaces
    assert "eth5" in interfaces
    assert "eth6"

# Generated at 2022-06-23 00:12:37.783212
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    obj = LinuxNetwork('/usr/bin/', '/sbin/', '0.14')
    assert obj.ip_path == '/usr/bin/ip'
    assert obj.route_path == '/sbin/route'
    assert obj.version == '0.14'
    assert isinstance(obj.default_ipv4, dict)
    assert isinstance(obj.default_ipv6, dict)
    assert obj.default_ipv4 == {
        'address': '127.0.0.1',
        'broadcast': '0.0.0.0',
        'netmask': '255.0.0.0',
        'network': '0.0.0.0'
    }

# Generated at 2022-06-23 00:12:44.134323
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    n = LinuxNetwork()
    defaults = {
        'all_ipv4_addresses': [],
        'all_ipv6_addresses': [],
        'default_ipv4': {},
        'default_ipv6': {},
    }
    assert n.populate() == defaults
    assert n.populate(root_dir='/does/not/exist') == defaults


# Generated at 2022-06-23 00:12:50.994178
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    platform = 'Linux'
    fact_class = LinuxNetwork
    collect_dict = dict(module=dict(params=dict()), connection=dict(module_name='posix'))
    network_collector = NetworkCollector(module=AnsibleModuleMock(),
                                         fact_class=fact_class,
                                         platform=platform,
                                         collect_dict=collect_dict,
                                         )
    assert network_collector._fact_class == fact_class
    assert network_collector._platform == platform
    assert network_collector._collect_dict == collect_dict



# Generated at 2022-06-23 00:12:54.336458
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """
    Unit test that verifies LinuxNetworkCollector constructor doesn't throw an exception.
    :return:
    """
    assert LinuxNetworkCollector(ModuleStub())

# Generated at 2022-06-23 00:13:05.675065
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Class object instantiation
    ln = LinuxNetwork()

    # Note: the below module_utils.network.common.get_interfaces_info()
    # will call ln.module.run_command() which needs self.module.
    # That is why we define the below variable
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock(return_value=(0, "", ""))
    ln.module = module

    def set_ansible_module_attrs(attrs):
        for attr_name, attr in attrs.items():
            setattr(module, attr_name, attr)

    # Set attributes to the module object

# Generated at 2022-06-23 00:13:17.527968
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Test parameters
    module = None

# Generated at 2022-06-23 00:13:30.550319
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = DummyAnsibleModule(
        dict(
            ansible_path=BIN_PATH,
        ),
    )
    module.run_command = MagicMock(return_value=[0, '08:00:27:d0:9b:46', ''])
    ln = LinuxNetwork(module)
    net_v4 = {}
    net_v6 = {}
    # (v4, v6) = ln.get_default_interfaces()
    ln.get_default_interfaces(net_v4, net_v6)
    assert 'interface' in net_v4
    assert 'interface' not in net_v6
    assert 'address' in net_v4
    assert 'address' not in net_v6
    assert 'gateway' in net_v4

# Generated at 2022-06-23 00:13:43.185039
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    import sys
    import StringIO

# Generated at 2022-06-23 00:13:52.163919
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    def mock_module_run_command(cmd, *args, **kwargs):
        # for this to work, we need to run the function in the
        # same context as the original module
        return linux_network.run_command(cmd, *args, **kwargs)

    def mock_get_bin_path(binary, *args, **kwargs):
        if binary == 'ethtool':
            return 'ethtool'
        if binary == 'ip':
            return 'ip'
        return ''

    module = NetworkModule()
    # We need the module to be runnable so we can call get_bin_path
    module.run_command = mock_module_run_command
    module.get_bin_path = mock_get_bin_path


# Generated at 2022-06-23 00:14:02.908459
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import tempfile
    import shutil
    import platform

    class MockModule:
        def __init__(self, tempdir):
            self.params = {
                'config_file': os.path.join(tempdir, 'ansible.cfg'),
                'remote_tmp': tempdir,
                'accelerate': False,
                'console': None,
            }

        def get_bin_path(self, name):
            if name == "ip":
                return "/bin/%s" % name
            return None

# Generated at 2022-06-23 00:14:14.738848
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-23 00:14:27.367725
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/bin/ethtool')

    data = {
        'features': {
            'rx_all': 'off',
            'tx_tcp_ipv4_segmentation': 'off',
            'tx_tcp_ipv6_segmentation': 'off',
            'rx_fcs': 'off',
            'tx_checksum_ipv4': 'off',
        },
        'timestamping': ['hw', 'sw', 'hw_pst'],
        'hw_timestamp_filters': ['none', 'all'],
        'phc_index': 0
    }

   

# Generated at 2022-06-23 00:14:33.422746
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Test cases:
    # routes, interfaces, dhclient, dns, default_ipv4, default_ipv6
    # exp_routes, exp_interfaces, exp_dhclient, exp_dns, exp_default_ipv4, exp_default_ipv6

    class TestModule():
        def __init__(self):
            self.params = dict()
            self.check_mode = False
            self.debug = False
        def fail_json(self, **args):
            pass
        def get_bin_path(self, path, required=False):
            return "/usr/bin/%s" % path

# Generated at 2022-06-23 00:14:36.324153
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """
    For testing of constructor of class LinuxNetworkCollector
    """
    # Create a instance of Distro
    module = NetworkModule()
    # Create an instance of class LinuxNetworkCollector
    network_collector = LinuxNetworkCollector(module)

    assert network_collector.platform == 'Linux'
    assert network_collector.fact_class == LinuxNetwork
    assert network_collector.required_facts == {'distribution', 'platform'}

# Generated at 2022-06-23 00:14:41.624628
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # TODO: refactor this test
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    interfaces = network.get_interfaces_info(None, {}, {})
    assert len(interfaces) > 0

# Generated at 2022-06-23 00:14:43.236341
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # TODO: needs test
    pass # if false:  # noqa

# Generated at 2022-06-23 00:14:48.127044
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    output_addresses = """
    default via 192.168.0.1 dev eth0
    default via 192.168.0.1 dev eth1
    """
    output_interfaces = """
    eth0      Link encap:Ethernet  HWaddr 1A:2B:3C:4D:5E:6F
    eth1      Link encap:Ethernet  HWaddr 1A:2B:3C:4D:5E:70
    """

# Generated at 2022-06-23 00:14:58.630770
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={'config': {'type': 'dict'}})

    module.config = dict(
        config=dict(
            config='/etc/sysconfig/network-scripts/ifcfg-eth0',
            initscripts='/etc/sysconfig/network-scripts/ifup-eth',
            defaultroute_enabled='yes',
            defaultroute_device='eth0',
        )
    )

    net = LinuxNetwork(module=module)
    net.populate()
    assert net.gateways['default']['via'] == '172.23.1.1'
    assert net.gateways['default']['device'] == 'eth0'


# Generated at 2022-06-23 00:15:10.299245
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=[], type='list'),
            config=dict(default=False, type='bool'),
            active=dict(default=False, type='bool'),
            default_interface=dict(default=None, type='str'),
            ip_path=dict(default=None, type='str'),
            route_path=dict(default=None, type='str'),
            use_ipv6=dict(default=True, type='bool'),
            exclude_interface=dict(),
        )
    )

    adapter = Mock(spec=AnsibleModule)
    adapter.module = module
    adapter.module.get_bin_path.side_effect = lambda path: path
    adapter.module.get_file_content.return_value = "0"


# Generated at 2022-06-23 00:15:22.763943
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    class MockModule(object):
        pass

    m = MockModule()
    m.run_command = MagicMock()
    m.get_bin_path = MagicMock()
    m.get_bin_path.return_value = '/sbin/ip'

# Generated at 2022-06-23 00:15:35.978968
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    ln = LinuxNetwork()

    def _check(command, raw_output, expected):
        if command[-1] == 'ip':
            command.extend([
                '-o', '-4', 'route', 'get', 'default',
                '-o', '-6', 'route', 'get', 'default',
            ])
        else:
            command.extend([
                '-4', 'route', 'get', 'default',
                '-6', 'route', 'get', 'default',
            ])

        rc, out, err = ln.module.run_command(command, errors='surrogate_then_replace')
        assert rc == 0
        assert out == raw_output
        assert expected == ln.get_default_interfaces(rc, out, err, command)


# Generated at 2022-06-23 00:15:44.131949
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # FIXME: we have to mock these to satisfy pylint
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule
    m = AnsibleModule(argument_spec=dict(path=dict(type='str', default='/sbin/ip')))
    ln = LinuxNetwork(m)
    # FIXME: end of mock

    # TODO: test the actual command output

    # ethtool -k <DEVICE>
    # TODO: test cases where some of these fail to find a match
    # TODO: test cases where these lines don't exist or are commented out
    # TODO: test the entire output of ethtool -k <DEVICE>
    # TODO: test multiple features

# Generated at 2022-06-23 00:15:50.806548
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule({'_ansible_is_remote': False}, supports_check_mode=True)
    m = LinuxNetwork(module)
    assert m.get_default_interfaces() == (("lo", "127.0.0.1/8", "127.0.0.1", "::1/128", "::1"),)



# Generated at 2022-06-23 00:16:03.308780
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    l = LinuxNetwork()

# Generated at 2022-06-23 00:16:12.917479
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    #Tested args
    ip_path = "/bin/ip"
    default_ipv4 = dict()
    default_ipv4['address'] = "192.168.56.1"
    default_ipv4['broadcast'] = "192.168.56.255"
    default_ipv4['netmask'] = "255.255.255.0"
    default_ipv4['network'] = "192.168.56.0"
    default_ipv4['macaddress'] = "fa:16:3e:be:b0:6d"
    default_ipv4['mtu'] = 1500
    default_ipv4['type'] = "bridge"
    default_ipv4['alias'] = "venet0:0"
    default_ipv4['scope'] = "link"

    default_

# Generated at 2022-06-23 00:16:20.877053
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from ansible_collections.ansible.community.tests.unit.compat.mock import Mock
    from ansible_collections.ansible.community.tests.unit.modules.utils import set_module_args

    module = Mock()
    set_module_args(dict())
    network = LinuxNetworkCollector(module)
    assert network.required_facts == set(['distribution', 'platform'])
    assert network.platform == 'Linux'



# Generated at 2022-06-23 00:16:28.457420
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module_args={
        '_ansible_verbosity': 0,
    }
    module = AnsibleModule(argument_spec={}, supports_check_mode=True, **module_args)
    # Create a fake module for test purposes
    linux_network = LinuxNetwork(module)
    assert(linux_network.module == module)
    assert(linux_network.default_ipv4 is not None)
    assert(linux_network.default_ipv6 is not None)
    assert(linux_network.INTERFACE_TYPE is not None)
    assert(linux_network.IPv6_TYPE is not None)
