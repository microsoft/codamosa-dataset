

# Generated at 2022-06-23 00:06:34.772994
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # LinuxNetworkCollector(Module) will query file system and populates facts dict
    # we need to mock run_command() to return some values so LinuxNetworkCollector won't fail
    # also we need to patch get_file_content() and return some values

    module = MagicMock()
    # we need to assign LinuxNetworkCollector._platform to some value, so we can test distribution_version logic
    LinuxNetworkCollector._platform = 'Linux'
    LinuxNetworkCollector._fact_class = LinuxNetwork
    # mock run_command so we can test distribution_version
    # also, it's used by get_interfaces_info
    module.run_command = MagicMock(return_value=(0, "", ""))
    # mock get_file_content so we can test distribution_version
    LinuxNetworkCollector.get_file_content = MagicM

# Generated at 2022-06-23 00:06:45.186607
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Unit test for get_interfaces_info
    interface_info = dict()
    interface_info['eth0'] = {}
    interface_info['eth0']['device'] = 'eth0'
    interface_info['eth0']['mtu'] = 1500
    interface_info['eth0']['active'] = True
    interface_info['eth0']['module'] = 'e1000e'
    interface_info['eth0']['type'] = 'unknown'
    interface_info['eth0']['pciid'] = '0000:00:1f.6'
    interface_info['eth0']['macaddress'] = '08:00:27:13:4b:6c'
    interface_info['eth0']['promisc'] = False

# Generated at 2022-06-23 00:06:59.102955
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = ansible_module_get_network_module(argument_spec=dict())
    network = LinuxNetwork(module)

    # assert IPv4
    expected = dict(
        gateway='10.0.0.1',
        address='10.0.1.11',
        interface='br0'
    )
    lookup_call_result = dict(
        stdout = '''
default via 10.0.0.1 dev br0
10.0.1.11 dev br0 proto kernel scope link src 10.0.1.11
10.0.1.0/24 dev br0 proto kernel scope link src 10.0.1.11
''',
        stderr = '',
        rc = 0
    )

# Generated at 2022-06-23 00:07:08.883548
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Arrange
    module = AnsibleModule(
        argument_spec = dict(),
    )
    module.run_command = MagicMock(return_value=(0, "ok", ""))
    # FIXME: this seems too difficult to mock
    #module.get_bin_path = MagicMock(return_value=None)
    m = LinuxNetwork(module)

    # Act
    interfaces, ips = m.get_interfaces_info(None, {}, {})

    # Assert
    assert isinstance(interfaces, dict)
    assert isinstance(ips, dict)



# Generated at 2022-06-23 00:07:18.523713
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import Mapping

    class ModuleStub(AnsibleModule):
        def __init__(self):
            super(ModuleStub, self).__init__(argument_spec={}, supports_check_mode=False)


# Generated at 2022-06-23 00:07:22.299137
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    # check instance attributes
    instance = LinuxNetwork(dict(module=dict()))
    assert hasattr(instance, 'INTERFACE_TYPE')
    assert hasattr(instance, 'module')


# Generated at 2022-06-23 00:07:35.137404
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    """Test module for the populate method of LinuxNetwork class
    """

    # Example data from Red Hat Enterprise Linux 6.5

# Generated at 2022-06-23 00:07:44.929072
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    obj = LinuxNetwork(module)
    # get_default_interface_info
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='')
    (ipv4, ipv6) = obj.get_default_interface_info()
    module.fail_json.assert_called_with(
        msg="neither command ip nor route are available on the host",
        exception=ip_exception_msg)

# Unit test cases for function get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-23 00:07:54.407181
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = FakeAnsibleModule()
    ipv4_address = "127.0.0.1"
    ipv6_address = 'fe80::1'
    default_ipv4 = "127.0.0.1"
    default_ipv6 = 'fe80::1'
    module.run_command.return_value = (0, default_ipv4 + '\n', '')
    module.run_command.return_value = (0, default_ipv6 + '\n', '')
    ln = LinuxNetwork(module)
    interface = ln.get_default_interfaces(ipv4_address, ipv6_address)
    assert interface['ipv4']['address'] == default_ipv4
    assert interface['ipv6']['address'] == default_ipv6

# Generated at 2022-06-23 00:08:01.707407
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = type('Module', (), {})()
    setattr(module, 'run_command', lambda x: (0, 'default via 192.168.122.1 dev enp0s3 proto static metric 100', ''))
    l = LinuxNetwork(module)
    v4, v6 = l.get_default_interfaces()
    assert v4['address'] == '192.168.122.1'
    assert v4['interface'] == 'enp0s3'
    assert v6 is None

    setattr(module, 'run_command', lambda x: (0, 'default via 192.168.122.1 dev enp0s3 proto static metric 100\ndefault via fe80::5054:ff:fe12:3456 dev enp0s9 proto ra metric 600', ''))
    l = LinuxNetwork(module)
   

# Generated at 2022-06-23 00:08:14.448632
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():

    # Prepare args
    args = ('LinuxNetwork', None)

    # Prepare kwargs
    kwargs = {
        'ip_path': 'ip',
        'default_ipv4': {
            'address': '127.0.0.1'
        },
        'default_ipv6': {
            'address': '::1'
        },
    }

    # Instantiate a class and test
    ln = LinuxNetwork(*args, **kwargs)
    assert isinstance(ln, LinuxNetwork)
    assert hasattr(ln, 'get_ip_addresses')
    assert hasattr(ln, 'get_default_ipv4')
    assert hasattr(ln, 'get_default_ipv6')
    assert hasattr(ln, 'get_interfaces_info')

# Generated at 2022-06-23 00:08:23.669421
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    result = te.get_default_interfaces()

# Generated at 2022-06-23 00:08:28.205902
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    """Unit test for constructor of class LinuxNetwork"""
    nm = LinuxNetwork()
    nm.get_devicelist()
    nm.get_devices()
    nm.get_routes()


# Generated at 2022-06-23 00:08:39.594599
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    l = LinuxNetwork()
    l.module = MagicMock()
    l.module.run_command.return_value = (0, DUMMY_IP_OUTPUT, '')
    l.get_interfaces_info = MagicMock()
    l.get_interfaces_info.return_value = ({}, {})
    l.get_default_interface = MagicMock()
    l.get_default_interface.return_value = ({'mtu': 100}, {'mtu': 100})
    l.get_interface_caps = MagicMock()
    l.get_interface_caps.return_value = ({'ipv4': {'forwarding': False}, 'ipv6': {'forwarding': False}}, {})
    l.get_interface_info = MagicMock()
    l.get_interface_

# Generated at 2022-06-23 00:08:42.963304
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = mock.MagicMock()
    net = LinuxNetwork(module)

    device = "test"
    data = net.get_ethtool_data(device)
    assert data == {}


# Generated at 2022-06-23 00:08:51.199916
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import collections
    # set up mock module and functions
    mock = {'get_bin_path.return_value': '',
            'run_command.return_value': 0,
            'fail_json.side_effect': False}
    module = collections.namedtuple('module', mock.keys())(**mock)
    # set up mock class
    ln = LinuxNetwork(module)

    # check default path
    (interfaces, ips) = ln.get_interfaces_info(None, dict(), dict())
    module.get_bin_path.assert_called_with("ip")

    # make sure "ip" is called with the right arguments
    module.get_bin_path.side_effect = lambda x: x

# Generated at 2022-06-23 00:08:56.397424
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    obj = LinuxNetwork()
    assert isinstance(obj, LinuxNetwork)
    assert obj._ip_paths == ['ip', '/sbin/ip']
    assert obj._ss_paths == ['ss', '/sbin/ss']


# Generated at 2022-06-23 00:09:04.686908
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = NetworkModule(argument_spec={})
    # Fixture created from:
    # /sys/class/net/brctl show
    # /sys/class/net/bonding_masters
    # /sys/class/net/enp0s8/brport show
    # /sys/class/net/enp0s8/brport/bridge show
    # /sys/class/net/enp0s8/bonding show
    # /sys/class/net/enp0s8/bonding/slaves show
    # /sys/class/net/enp0s8/mtu
    # /sys/class/net/enp0s8/address
    # /sys/class/net/enp0s8/operstate
    # /sys/class/net/enp0s8/speed
   

# Generated at 2022-06-23 00:09:06.926540
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: make a real test instead of these skipped asserts
    assert False



# Generated at 2022-06-23 00:09:08.474424
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    pass



# Generated at 2022-06-23 00:09:18.124803
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    test_module = AnsibleModule(argument_spec={})

    linux_network = LinuxNetwork(test_module)

    # Setup an Informational function to return the path to the
    # executable if it exists in the module's PATH
    test_module.get_bin_path = lambda _: "/usr/sbin/ip"

    # Setup a helper function to return the contents of a file

# Generated at 2022-06-23 00:09:19.950222
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    is_linux = False
    if sys.platform == 'linux':
        is_linux = True

    # Only test the class if we are on linux.
    if is_linux:
        col = LinuxNetworkCollector()
        assert col.platform == 'Linux'



# Generated at 2022-06-23 00:09:32.955390
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import MagicMock
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch

    class ModuleStub:
        pass

    module = ModuleStub()

    module.run_command = MagicMock(return_value=(1, "hello", "world"))

    setattr(module, 'get_bin_path', MagicMock(return_value="/fake/path"))

    # WARNING: The following assumes IPv4 is enabled on the system
    # Running the module (during a unit test) against a system with IPv6
    # disabled will cause the test to fail

    # Constructor
    linux_network = LinuxNetwork(module)

    result = linux_network.populate()

    # Right now we do not

# Generated at 2022-06-23 00:09:41.871432
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    # Initialize a test module
    # The first argument to Mock is a dictionary of module parameters
    module = AnsibleModule(
        dict(
            config='',
            _ansible_check_mode=False,
            _ansible_debug=False,
        ),
        # FIXME: can we set ADDITIONAL_FILE_METADATA here?
    )

    # Initialize a test class
    ln = LinuxNetwork(module)

    # Run the method populate of class LinuxNetwork
    # TODO: add parameters
    ln.populate()

    # FIXME: test the output is what we expect
    # FIXME: test the output is what we expect



# Generated at 2022-06-23 00:09:51.874689
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    class FakeModule(object):
        @staticmethod
        def run_command(args, **kwargs):
            # NOTE: this is mocked below and not in FakeModule directly
            # because the implementation lives in a class method
            return LinuxNetwork().run_command(args, **kwargs)
        @staticmethod
        def get_bin_path(path, **kwargs):
            # NOTE: this is mocked below and not in FakeModule directly
            # because the implementation lives in a class method
            return LinuxNetwork().get_bin_path(path, **kwargs)

    # Pick a random bitmask from /etc/networks and set it as
    # network_mask_bits in eth0 to test for correct netmask determination

# Generated at 2022-06-23 00:10:04.180074
# Unit test for method populate of class LinuxNetwork

# Generated at 2022-06-23 00:10:08.682952
# Unit test for constructor of class LinuxNetworkCollector

# Generated at 2022-06-23 00:10:20.736992
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    class LinuxNetworkMock(LinuxNetwork):
        def get_file_content(self, path, default=None):
            if path == '/sys/class/net/eth0/mtu': return 1500
            elif path == '/sys/class/net/eth1/mtu': return 1500
            elif path == '/sys/class/net/lo/mtu': return 65536
            elif path == '/sys/class/net/tap0/mtu': return 1500
            elif path == '/sys/class/net/br0/mtu': return 1500
            elif path == '/sys/class/net/eth0/address': return '00:00:00:00:00:01'
            elif path == '/sys/class/net/eth1/address': return '00:00:00:00:00:02'

# Generated at 2022-06-23 00:10:33.098551
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict(
    ))
    ln = LinuxNetwork(module)

    # If I have no interfaces, I should have no default_interface
    module.params = dict(
        interfaces={}
    )
    assert ln.get_default_interfaces() == {"default_interface_ipv4": None, "default_interface_ipv6": None}

    # If my interface is down, I should have no default_interface
    module.params = dict(
        interfaces={"eth0": {"active": False}}
    )
    assert ln.get_default_interfaces() == {"default_interface_ipv4": None, "default_interface_ipv6": None}

    # My default should be the only active interface

# Generated at 2022-06-23 00:10:38.691124
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = Mock()
    ln = LinuxNetwork(module)
    module.run_command.return_value = (0, 'something', 'stderr')
    assert ln.get_ethtool_data('eth0') == {'features': {'something': 'key'}}


# Generated at 2022-06-23 00:10:50.446984
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():

    class MockModule(object):
        @staticmethod
        def get_bin_path(name):
            return '/usr/bin/{}'.format(name)

        @staticmethod
        def run_command(args, errors='strict'):
            if not args:
                return


# Generated at 2022-06-23 00:10:58.092351
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    test_class = LinuxNetwork()
    result = test_class._get_ethtool_data('lo')

# Generated at 2022-06-23 00:11:09.177114
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule({})
    ln = LinuxNetwork(mod)
    device = 'eth0'
    data = ln.get_ethtool_data(device)
    assert 'features' in data
    assert data['features']['tcp_segmentation_offload'] == 'on'
    assert 'timestamping' in data
    assert 'hardware_timestamping' in data['timestamping']
    assert 'hw_timestamp_filters' in data
    assert 'all' in data['hw_timestamp_filters']
    assert data['phc_index'] == 1

# Generated at 2022-06-23 00:11:21.244556
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import datetime
    import time
    my_datetime = datetime.datetime.now()
    random_now = time.mktime(my_datetime.timetuple())
    module = AnsibleModule(argument_spec=dict())
    l = LinuxNetwork(module)
    lo_path = "/sys/class/net/lo"
    ln = os.readlink(lo_path)
    if "devices" not in ln:
        lo_path = "/sys/class/net/lo/"
    tmp_dir = tempfile.mkdtemp()
    content = "1"
    file_path = os.path.join(tmp_dir, "address")
    file = open(file_path, "w")
    file.write(content)
    file.close()

# Generated at 2022-06-23 00:11:32.358263
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    test_ethtool_data = {'features': {'tso': 'on', 'gso': 'on', 'gro': 'on', 'lro': 'on', 'rxvlan': 'on', 'txvlan': 'on', 'ntuple': 'on', 'rxhash': 'on', 'sg': 'on', 'txchecksumming': 'on', 'rxchecksumming': 'on', 'rxvlan-hw-parse': 'on', 'txvlan-hw-parse': 'on'}, 'timestamping': ['tx', 'rx'], 'hw_timestamp_filters': ['rx_all', 'tx_all'], 'phc_index': 0}

# Generated at 2022-06-23 00:11:44.419916
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule({})
    ln = LinuxNetwork(module=module)

    device = 'eth0'
    ethtool_path = ln.module.get_bin_path("ethtool")
    if not ethtool_path:
        module.fail_json(msg="ethtool not found")

    class DummyFile(object):
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content.read()


# Generated at 2022-06-23 00:11:54.972703
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    network_module = LinuxNetwork(module)
    network_module.populate()


# Generated at 2022-06-23 00:12:08.851561
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = Mock()
    module.get_bin_path.return_value = "/usr/sbin/ethtool"
    network = LinuxNetwork(module)
    device = "ens3"

    # Case 1: successful execution
    module.run_command.return_value = (0, "foo")
    data = network.get_ethtool_data(device)
    assert data['features']['tcp_segmentation_offload'] == "on"

    # Case 2: non zero return code
    module.run_command.return_value = (1, "foo")
    data = network.get_ethtool_data(device)
    assert data == {}

    # Case 3: empty string
    module.run_command.return_value = (0, "")
    data = network.get_ethtool_data(device)


# Generated at 2022-06-23 00:12:15.742333
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    ln = LinuxNetwork(module)
    device = "eth0"
    result = ln.get_ethtool_data(device)
    assert "features" in result
    assert "timestamping" in result
    assert "hw_timestamp_filters" in result
    assert "phc_index" in result


# Generated at 2022-06-23 00:12:28.335634
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    temp_dir = tempfile.mkdtemp()
    interfaces = os.path.join(temp_dir, 'sys', 'class', 'net')
    os.makedirs(interfaces)
    default_ipv4 = {'address': "8.8.8.8"}
    default_ipv6 = {'address': "2001::1"}
    with open(os.path.join(interfaces, 'loop0'), 'w') as f:
        f.write('')
    with open(os.path.join(interfaces, 'lo'), 'w') as f:
        f.write('')
    with open(os.path.join(interfaces, 'eth0'), 'w') as f:
        f.write('')

# Generated at 2022-06-23 00:12:33.856350
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
  obj = LinuxNetwork()
  assert obj.get_ip_version('2001::1') == 6
  assert obj.get_ip_version('1.2.3.4') == 4

if __name__ == '__main__':
    test_LinuxNetwork()

# Generated at 2022-06-23 00:12:45.074211
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    from ansible.module_utils.six import PY2
    modules = {
        'ansible': mock.Mock(),
        'ansible.module_utils.basic': mock.Mock(),
        'ansible.module_utils.six': mock.Mock(),
    }
    if PY2:
        modules['__builtin__'] = mock.Mock()
    else:
        modules['builtins'] = mock.Mock()

    modules['ansible.module_utils.basic'].AnsibleModule.return_value = mock.Mock()
    modules['ansible.module_utils.basic'].AnsibleModule.return_value.run_command.return_value = (0, '0.0.0.0', '')

    # inject our monkeypatched modules into __builtin__
    builtins_orig

# Generated at 2022-06-23 00:12:49.993913
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # Instantiate class
    lnc = LinuxNetworkCollector({}, {})
    # Required facts should be stored as variable in class
    facts = ['distribution', 'platform']
    for f in facts:
        assert f in lnc.required_facts
    assert '_platform' in lnc.__dict__
    assert '_fact_class' in lnc.__dict__


# Generated at 2022-06-23 00:12:57.485612
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.collector import BaseFactCollector
    assert issubclass(LinuxNetworkCollector, BaseFactCollector)
    assert LinuxNetworkCollector._platform == 'Linux'
    assert LinuxNetworkCollector.required_facts == set(['distribution', 'platform'])
    assert LinuxNetworkCollector._fact_class == LinuxNetwork


# Generated at 2022-06-23 00:13:05.420781
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    n = LinuxNetwork()
    interfaces, ips = n.get_interfaces_info('/bin/ip', 'lo')
    assert isinstance(interfaces, dict)
    assert isinstance(ips, dict)
    assert interfaces.keys()
    assert ips.keys()


if __name__ == '__main__':
    n = LinuxNetwork()
    interfaces, ips = n.get_interfaces_info('/bin/ip', 'lo')
    print(json.dumps({'ansible_network_resources': {'interfaces': interfaces, 'ips': ips}}, indent=4))

# Generated at 2022-06-23 00:13:10.047052
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    linux_network_info = LinuxNetwork(module)
    assert linux_network_info is not None
    # Ensure we raised no exception during initialization


# Generated at 2022-06-23 00:13:13.648748
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    modules = AnsibleModule(argument_spec=dict())
    interfaces = LinuxNetwork()
    assert interfaces.get_default_interfaces(modules) == ('eth0', 'eth0')



# Generated at 2022-06-23 00:13:19.098523
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from ansible.module_utils.facts.network.linux.collector import LinuxNetworkCollector

    x = LinuxNetworkCollector()
    assert x.__class__.__name__ == 'LinuxNetworkCollector'

    assert hasattr(x, '_platform')
    assert x._platform == 'Linux'

    assert hasattr(x, '_fact_class')
    assert x._fact_class.__name__ == 'LinuxNetwork'

    assert hasattr(x, 'required_facts')


# Generated at 2022-06-23 00:13:32.000977
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.collector import BaseFactCollector
    _platform_mock = patch('ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.collector.NetworkCollector._platform', new_callable=PropertyMock(return_value='Linux'))
    _fact_class_mock = patch('ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.collector.NetworkCollector._fact_class', new_callable=PropertyMock(return_value=LinuxNetwork))

# Generated at 2022-06-23 00:13:44.445125
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.linux.distribution import Distribution
    from ansible.module_utils.facts.network.base import Network
    LN = LinuxNetwork(Distribution(), Network())

# Generated at 2022-06-23 00:13:49.203025
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = mock.MagicMock()
    module.run_command.return_value = (0, 'mocked-reply', '')
    ln = LinuxNetwork(module)
    assert ln.get_default_interfaces() == ({'v4': {}, 'v6': {}}, {'v4': {}, 'v6': {}})



# Generated at 2022-06-23 00:14:00.447087
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    LN = LinuxNetwork()
    interfaces, ips = LN.get_interfaces_info(LN.module.get_bin_path("ip"), dict(), dict())
    assert 'lo' in interfaces.keys(), interfaces
    assert 'lo' in ips['all_ipv4_addresses']
    assert '127.0.0.1' in ips['all_ipv4_addresses']
    assert 'fe80::1' in ips['all_ipv6_addresses']
    assert '::1' in ips['all_ipv6_addresses']
    assert 'ff02::1' not in ips['all_ipv6_addresses']



# Generated at 2022-06-23 00:14:12.843262
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    # Pick up test environment variables
    # FIXME: if we are going to use env vars, let's use credentials plugin
    # and vault https://docs.ansible.com/ansible/playbooks_best_practices.html#variables-and-vaults
    # environ = os.environ
    environ = {}
    environ["PATH"] = "/bin:/usr/bin"

# Generated at 2022-06-23 00:14:22.116894
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
    )

    ln = LinuxNetwork(module)
    # FIXME: assert get_interfaces_info
    # FIXME: assert get_interfaces_info
    # FIXME: assert get_network_config
    # FIXME: assert get_default_route_device
    # FIXME: assert get_default_network_device
    # FIXME: assert get_default_interface
    # FIXME: assert get_interfaces_addresses


# Generated at 2022-06-23 00:14:34.852242
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    """
    Populate method unit test
    """
    from ansible.module_utils.basic import AnsibleModule

    module_args = dict(
        gather_subset=['all']
    )

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    lg = LinuxNetwork(module)
    result = lg.populate()
    assert 'ipv4' in result
    assert 'ipv6' in result
    assert 'interfaces' in result
    assert 'default_ipv4' in result['ipv4']
    assert 'default_ipv6' in result['ipv6']
    assert 'all_ipv4_addresses' in result['ipv4']

# Generated at 2022-06-23 00:14:42.010977
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # Testing with invalid input parameters
    with pytest.raises(Exception) as excinfo:
        LinuxNetworkCollector([], dict())
    assert 'Missing required facts' in str(excinfo.value)

    facts = {'distribution': 'MyDistro', 'platform': 'Linux'}
    collector = LinuxNetworkCollector(facts, dict())
    assert collector.facts == facts


# Generated at 2022-06-23 00:14:54.767572
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    interface = 'dummy'
    net = LinuxNetwork()
    net.module = MagicMock()
    mock_command = MagicMock()
    mock_command.return_code = 0

# Generated at 2022-06-23 00:15:07.123918
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    def mock_get_bin_path(name):
        return name

    def mock_run_command(command, **kwargs):
        if command[0] == 'ip':
            if command[1] == '-V':
                return 0, "ip utility, iproute2-ss151212", ""

# Generated at 2022-06-23 00:15:18.770723
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    nm = LinuxNetwork(module)

    # Test network interfaces
    interfaces = nm.get_interfaces()
    assert len(interfaces) > 0

    # Test IP data
    def_ipv4, def_ipv6 = nm.get_default_interfaces()
    ipv4 = interfaces[def_ipv4['interface']]['ipv4']
    ipv6 = interfaces[def_ipv6['interface']]['ipv6']

    assert def_ipv4['address'] == ipv4['address']
    assert def_ipv4['broadcast'] == ipv4['broadcast']
    assert def_ipv4['netmask'] == ipv4['netmask']
    assert def_ipv4['network'] == ipv4['network']
   

# Generated at 2022-06-23 00:15:29.884928
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = UnsafeEvaluationModule()
    def get_bin_path(name):
        if name == 'ethtool':
            return name
        return None
    module.get_bin_path = get_bin_path
    ln = LinuxNetwork(module)
    data = ln.get_ethtool_data("eth0")
    assert data['features']['tx_checksumming'] == 'on'
    assert data['features']['tx_sctp_segmentation'] == 'off'
    assert data['timestamping'] == ['hardware', 'software']
    assert data['hw_timestamp_filters'] == ['all']
    assert data['phc_index'] == 0


# Generated at 2022-06-23 00:15:40.963605
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    class FakeAnsibleModule:
        def __init__(self):
            self.bin_path = {}
            self._socket_path = None
            self.params = {}
            self.socket_path = None
            self.check_mode = False
            self.run_command = lambda cmd, environ_update=None, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None: (0, '', '')

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            bla = self.bin_path.get(arg)
            return bla


    fake_mod = FakeAnsibleModule()

# Generated at 2022-06-23 00:15:45.800836
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    m = AnsibleModule(argument_spec={})

    l = LinuxNetwork(m)

    # Make sure we don't error when a dir isn't a dir
    assert l.get_interfaces_info(None, {}, {}) == ({}, {'all_ipv4_addresses': [], 'all_ipv6_addresses': []})

    # Make sure we don't error when a dir is missing
    assert l.get_interfaces_info('/path/to/nowhere', {}, {}) == ({}, {'all_ipv4_addresses': [], 'all_ipv6_addresses': []})



# Generated at 2022-06-23 00:15:57.877414
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # This is a very simple test, to make sure populating the data structure
    # works at all.  The full range of tests will be done on the template.
    m = AnsibleModule(
        argument_spec=dict(),
    )
    m.params = dict()
    ln = LinuxNetwork(m)
    data = ln.populate()

    if not isinstance(data, dict):
        raise AssertionError("return value is not a dict")
    for key in ('default_ipv4', 'default_ipv6', 'interfaces', 'ipv4',
            'ipv6'):
        if key not in data:
            raise AssertionError("key %s is missing from return value" % key)

if __name__ == '__main__':
    test_LinuxNetwork_populate()

# Generated at 2022-06-23 00:16:09.418751
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    # Test setup
    from ansible_collections.community.general.tests.unit.compat.mock import patch

    # Mock out the sys module
    with patch('sys.platform', 'Linux'):

        # Mock out the module class
        with patch('ansible.module_utils.network.common.network.LinuxNetwork.__init__') as mock_module:
            mock_module.return_value = None

            # Create a test class
            test_class = LinuxNetwork()

            # Create a test string
            test_string = 'route_destination_default'

            # Create a test dictionary

# Generated at 2022-06-23 00:16:16.484117
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec=dict())
    n = LinuxNetwork(module)
    assert n.default_ipv4['broadcast'] == '10.0.0.255'
    assert n.default_ipv4['gateway'] == '10.0.0.1'
    assert n.default_ipv4['interface'] == 'eth0'
    assert n.default_ipv6['address'] == 'fe80::1'
    assert n.default_ipv6['interface'] == 'eth0'
    assert n.default_ipv6['scope'] == 'host'
    assert n.interfaces['lo']['ipv4']['address'] == '127.0.0.1'

# Generated at 2022-06-23 00:16:27.422146
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """Mock out the method under test using a context manager
    """
    mock_rc = 0
    # Create the mock module to handle the fake data
    # A Return Value plugin is used to allow us to fake
    # running_config_path because it is called in the
    # constructor and the class is not instantiated
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    module.params = {}
    # Return a fake running_config_path value
    module.get_bin_path = lambda x: x
    # Create a mock class object
    mock_context = mock.patch.object(
        LinuxNetwork,
        'run_command',
        return_value=(mock_rc, '', ''),
    )

    # Return a mock run_command response
    mock