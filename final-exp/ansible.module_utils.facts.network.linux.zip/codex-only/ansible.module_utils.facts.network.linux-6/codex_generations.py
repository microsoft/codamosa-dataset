

# Generated at 2022-06-23 00:06:36.705142
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    import platform

# Generated at 2022-06-23 00:06:41.898050
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    args = dict(
        ip_path='/bin/false',
        default_ipv4=dict(address='127.0.0.1'),
        default_ipv6=dict(address='::1'),
    )
    ln = LinuxNetwork(module=MagicMock(**args))
    assert ln.get_default_interfaces() == (args['default_ipv4'], args['default_ipv6'])


# Generated at 2022-06-23 00:06:44.450737
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    import subprocess
    cmd = 'cat hosts'
    subprocess.call(cmd)


# Generated at 2022-06-23 00:06:51.670865
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    class LinuxNetworkSubclass(LinuxNetwork):
        def __init__(self):
            self.module = module
    linux_network = LinuxNetworkSubclass()

    # NOTE: ethtool is not available on macOS
    if linux_network.get_bin_path('ethtool'):
        device = 'eth0'
        # NOTE: assert_equal doesn't handle dict comparison
        assert linux_network.get_ethtool_data(device) == {}

        device = 'dummy0'

# Generated at 2022-06-23 00:06:56.414844
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Testing populate()
    # TODO

    # Invoke populate as it is invoked by module_utils/network.py
    n = LinuxNetwork()
    module = MagicMock()
    module.get_bin_path.return_value = "/bin/ip"
    n.module = module

    n.get_default_route = MagicMock()
    n.get_system_routes = MagicMock()

    n.get_ip_version.return_value = None
    n.get_interfaces_info = MagicMock()
    n.get_interfaces_info.return_value = ({}, {})

# Generated at 2022-06-23 00:07:02.121800
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class LinuxNetwork
    """
    # Test using a simple ethX interface
    module = AnsibleModule(argument_spec={})
    module.params = {
        'ip_path': '/sbin/ip',
    }

    # Mock netifaces.interfaces() to return a single "device"
    get_interfaces = mock.patch('__main__.netifaces.interfaces').start()
    get_interfaces.return_value = ['eth0']

    # Mock is_up() to return True
    is_up = mock.patch('__main__.is_up').start()
    is_up.return_value = True


# Generated at 2022-06-23 00:07:08.562096
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    network_collector = LinuxNetworkCollector(module)
    assert network_collector.platform == 'Linux'
    assert network_collector.fact_class == LinuxNetwork
    assert network_collector.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-23 00:07:18.000007
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    m = ansible_module_mock
    m.run_command.return_value = (None, None, None)
    c = LinuxNetworkCollector(m)

    assert c.platform == 'Linux'
    assert c.required_facts == set(['distribution', 'platform'])
    assert isinstance(c.get_facts(), dict)
    assert 'default_ipv4' in c.get_facts()
    assert 'default_ipv6' in c.get_facts()
    assert 'interfaces' in c.get_facts()
    assert 'all_ipv4_addresses' in c.get_facts()
    assert 'all_ipv6_addresses' in c.get_facts()
    assert 'interfaces' in c.get_facts()



# Generated at 2022-06-23 00:07:19.273696
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # TODO: Implement unit test
    raise NotImplementedError("To be implemented")



# Generated at 2022-06-23 00:07:23.464238
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """
    Test that required_facts is set correctly
    """
    _obj = LinuxNetworkCollector(None, None)
    assert _obj.required_facts == set(['distribution', 'platform'])

# Generated at 2022-06-23 00:07:36.233902
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    result = LinuxNetwork.get_default_interfaces()

# Generated at 2022-06-23 00:07:47.959476
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    class TestLinuxNetwork(LinuxNetwork):
        def __init__(self):
            self.module = None
            self.params = {}

    test = TestLinuxNetwork()
    test.module = MagicMock()
    test.module.run_command.return_value = (0, '', '')
    result = test.get_default_interfaces(MagicMock())

    i = result['ipv4']
    assert i['address'] == '127.0.0.1'
    assert i['netmask'] == '255.0.0.0'
    assert i['network'] == '127.0.0.0'
    assert i['broadcast'] == '127.255.255.255'

    i = result['ipv6']
    assert i['address'] == '::1'

# Generated at 2022-06-23 00:07:57.635754
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    '''
    This test is not intended to be a complete test, but rather just a sanity check
    to make sure the class constructs correctly.
    '''
    module = AnsibleModule(argument_spec={})
    obj = LinuxNetwork(module)
    # Check that we can get the ip path
    assert obj.ip_path, "ip_path was not set"
    # Check that we can get info on the default IPv4 and IPv6 interfaces
    assert obj.default_ipv4, "default_ipv4 dict was not set"
    assert obj.default_ipv6, "default_ipv6 dict was not set"
    # Check that we can get a dict of all interfaces and their info
    for k, v in obj.interfaces.items():
        assert k, "dict key was not set"

# Generated at 2022-06-23 00:08:02.482786
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    mod = AnsibleModule({})
    net = LinuxNetwork(mod)
    net.populate()
    assert net.defaults['ipv4']['default_interface'] != ''
    assert net.defaults['ipv6']['default_interface'] != ''
    assert net.defaults['ipv4']['default_gateway'] != ''
    assert net.defaults['ipv6']['default_gateway'] != ''
    assert net.defaults['ipv4']['address'] != ''
    assert net.defaults['ipv6']['address'] != ''


# Generated at 2022-06-23 00:08:14.764973
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-23 00:08:24.501748
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    ln = LinuxNetwork()

    # Test constants
    interface_type = {
        '1': 'loopback',
        '2': 'ethernet',
        '3': 'tokenring',
        '4': 'ppp',
        '5': 'loopback',
        '6': 'atm',
        '7': 'slip',
        '8': 'cdrom',
        '9': 'tunnel',
        '10': 'loopback',
        '11': 'frame_relay',
        '23': 'bluetooth',
        '24': 'infiniband',
        '256': 'bridge'
    }
    # Expected results

# Generated at 2022-06-23 00:08:27.560176
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():

    ln = LinuxNetwork()
    ln.get_interfaces_information()


# Generated at 2022-06-23 00:08:38.558278
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Empty string should be returned in case of non-existing file.
    assert LinuxNetwork.LinuxNetwork.get_file_content("/sys/class/net", "device", "driver", "module") == ""
    test_file = "/proc/version"
    if os.path.exists(test_file):
        assert LinuxNetwork.LinuxNetwork.get_file_content(test_file) == "Linux version 3.12.28-4-amd64 (debian-kernel@lists.debian.org) (gcc version 4.2.1) #1 SMP Debian 3.12.30-1 (2014-03-23) x86_64 GNU/Linux"

    # TODO: implement the rest of this method and test it


# Generated at 2022-06-23 00:08:44.251480
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    net = LinuxNetwork(module)
    assert net.ip_path == '/sbin/ip'
    assert net.route_path == '/sbin/route'
    assert net.default_ipv4['address'] == '127.0.0.1'
    assert net.default_ipv6['address'] == '::1'


# Generated at 2022-06-23 00:08:52.290597
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """This constructor tests the LinuxNetworkCollector class
    """

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    network_collector = LinuxNetworkCollector(module=module)
    # TODO: assert number of facts
    assert network_collector._platform == 'Linux'
    assert issubclass(network_collector._fact_class, LinuxNetwork)
    assert network_collector.required_facts == set(['distribution', 'platform'])



# Generated at 2022-06-23 00:09:03.073723
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'ip_path': '/sbin/ip',
        'default_ipv4': {},
        'default_ipv6': {},
        'interfaces': {},
    }

    linux_network = LinuxNetwork(module)
    module.params['ip_path'] = '/sbin/ip'
    linux_network.get_interfaces_info(module.params['ip_path'], module.params['default_ipv4'], module.params['default_ipv6'])
    interfaces = module.params['interfaces']
    assert isinstance(interfaces, dict)
    assert len(interfaces) == 5, 'wrong number of interfaces'

# Generated at 2022-06-23 00:09:06.982441
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = Mock()
    # TODO: to be implemented
    #return_value = LinuxNetwork.populate(module)
    #assert return_value is None

# Generated at 2022-06-23 00:09:08.328816
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    nm = LinuxNetwork(module)
    assert nm.ip_path is not None
    assert nm.module is module



# Generated at 2022-06-23 00:09:18.045382
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    fake_module = FakeModule()

    default_ipv4 = dict(address='192.168.1.1', netmask='255.255.255.0', network='192.168.1.0')
    default_ipv6 = dict(address='::1', prefix='128', scope='host')

    fake_module.params.update(
        dict(
            use_ipv6=False,
            routes=dict(ipv4=[dict(network='192.168.2.0', netmask='255.255.255.0')]),
        )
    )
    ln = LinuxNetwork(fake_module)
    ln.populate()
    assert ln.ansible_facts['ansible_default_ipv4']['address'] == default_ipv4['address']
    assert ln.ansible_facts

# Generated at 2022-06-23 00:09:23.068406
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    data = {}
    net = LinuxNetwork(dict(params=data))
    assert net.module == data
    assert net.default_ipv4 == {}
    assert net.default_ipv6 == {}
    assert net.route == {}
    assert net.route6 == {}
    assert net.interfaces == {}
    assert net.ips == {}



# Generated at 2022-06-23 00:09:35.293911
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = FakeModule()
    #
    # TODO: this should be re-written to use fake files and not
    #        real output from the system
    #
    linux_net = LinuxNetwork(module)
    linux_net.INTERFACE_TYPE = dict(
        (x, x) for x in ('loopback', 'ethernet', 'bridge', 'bonding', 'bond')
    )

    # FIXME, this should be based on files, not real output
    interfaces, ips = linux_net.get_interfaces_info('/sbin/ip', {}, {})

    assert interfaces is not None
    assert 'ipv4' in interfaces['lo']
    assert interfaces['lo']['ipv4']['address'] == '127.0.0.1'

# Generated at 2022-06-23 00:09:39.281947
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # unit tests require the following to be set
    #module.params['src'] = None
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    module.exit_json(changed=False)


# Generated at 2022-06-23 00:09:49.870314
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    device = 'eth0'
    network = LinuxNetwork()

    def mock_get_bin_path(arg):
        return '/sbin/ethtool'


# Generated at 2022-06-23 00:10:01.240652
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    class TestModule(object):
        def get_bin_path(self, name):
            return "/usr/bin/{}".format(name)

        def run_command(self, args, errors='strict'):
            cmd = args[1]

# Generated at 2022-06-23 00:10:14.462496
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    '''Test get_interfaces_info method'''
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda x: x
    linux_network = LinuxNetwork(module)

# Generated at 2022-06-23 00:10:19.933135
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['all'], type='list'),
            gather_network_resources=dict(default=['all'], type='list'),
        ),
    )
    ln = LinuxNetwork(module=module)
    ln.populate()
    module.exit_json(network_resources=ln.network_resources)


# Generated at 2022-06-23 00:10:32.218202
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    l_net = LinuxNetwork(module)

    # test no interfaces
    interfaces, ips = l_net.get_interfaces_info('', {}, {})
    l_net.populate({})
    assert interfaces == l_net.interfaces
    assert ips == l_net.ips

    interfaces['lo'] = {}
    l_net.populate({})
    assert interfaces == l_net.interfaces
    assert ips == l_net.ips

    # test 2 interfaces, both have ip, one has default
    interfaces['lo'] = {'ipv4': {}, 'ipv6': []}


# Generated at 2022-06-23 00:10:35.564381
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = FakeModule()
    platform = LinuxNetwork(module)

    platform.get_ethtool_data('eth0')



# Generated at 2022-06-23 00:10:47.582907
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-23 00:10:56.460273
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Windows support, added in 2.5
    # Our function needs to be split into smaller functions
    #   that can be individually tested
    #   and tested directly without calling the whole class
    module = AnsibleModule({})
    # Test with a local variable reference and a changes in the outside
    #   value of the variable reference.
    ip_path = '/bin/ip'
    default_ipv4 = {}
    default_ipv6 = {}

# Generated at 2022-06-23 00:11:09.368800
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    '''
    This test require a loopback interface with an IPv4 address, IPv6 address and a MAC address
    :return:
    '''
    ifname = 'lo'
    if_path = '/sys/class/net/' + ifname
    if_ipv4_addr_file = '/proc/sys/net/ipv4/conf/' + ifname + '/primary_address'
    if_ipv6_addr_file = '/proc/sys/net/ipv6/conf/' + ifname + '/permanent_address'
    if_mac_addr_file = if_path + '/address'
    if_mtu_addr_file = if_path + '/mtu'

# Generated at 2022-06-23 00:11:21.830102
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    mod_mock = mock.MagicMock()
    mod_mock.get_bin_path.return_value = '/usr/bin/ethtool'

    ln = LinuxNetwork(mod_mock, check_fips=True)

    # 1

# Generated at 2022-06-23 00:11:33.215713
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Patch preexisting system.kernel_name variable
    # so this test runs on non Linux platforms.
    linux_kernel_name = system.kernel_name
    system.kernel_name = "Linux"

    # Run the get_default_interfaces method
    obj = LinuxNetwork()
    output = obj.get_default_interfaces()

    # Revert the changes
    system.kernel_name = linux_kernel_name

    assert len(output) == 2

    # Verify the first output has correct keys
    assert set(output[0].keys()).issuperset(set(['interface', 'address', 'gateway']))
    assert output[0]['interface'] is not None
    assert output[0]['address'] is not None
    assert output[0]['gateway'] is not None

    # Verify the second output has correct keys

# Generated at 2022-06-23 00:11:45.773368
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    import tempfile

# Generated at 2022-06-23 00:11:55.404408
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # NOTE: since we depend on a lot of other modules and since we don't have
    #       a specific unit test module in place we just inject a MockModule
    #       here.
    #
    #       Only intended to be used in unit tests, this method of testing
    #       should be used in the first place.
    #

    # Test 1. Test if LinuxNetwork._populate() returns values when module.run_command()
    #         is stubbed/mocked.
    class MockModuleA(object):
        def __init__(self):
            self.run_command = lambda cmd, errors='surrogate_then_replace': (0, '', '')
            self.get_bin_path = lambda path, opt_dirs=[] : '/bin/ip'
    mock_module = MockModuleA()

    network_inst = Linux

# Generated at 2022-06-23 00:12:09.287308
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    payload = ['''
default via 172.20.0.1 dev eth0
172.20.0.0/24 dev eth0  proto kernel  scope link  src 172.20.0.10
''']
    rc = 0
    stdout = payload[0]
    stderr = ''
    obj = linux_network()
    result = obj.get_default_interfaces(module, [], payload, rc, stdout, stderr)
    assert len(result) == 2
    assert result['default']['interface'] == 'eth0'
    assert result['default']['gateway'] == '172.20.0.1'
    assert result['default']['address'] == '172.20.0.10'

# Generated at 2022-06-23 00:12:22.330118
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    """
    Unit test for LinuxNetwork class constructor.
    """
    module = AnsibleModule(argument_spec={})
    # instantiate the object
    linux_network = LinuxNetwork(module)
    assert linux_network is not None
    # confirm default_ipv4 is a dict
    assert type(linux_network.default_ipv4) is dict
    # confirm default_ipv6 is also a dict
    assert type(linux_network.default_ipv6) is dict
    # make sure that default_ipv4 and default_ipv6 are empty
    assert len(linux_network.default_ipv4) == 0
    assert len(linux_network.default_ipv6) == 0
    # make sure ip_path is empty string
    assert linux_network.ip_path == ''



# Generated at 2022-06-23 00:12:35.249978
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Preparing for mocking
    os_path_exists_patch = mock.patch.object(os.path, "exists", return_value=True)
    os_path_exists_patch.start()
    # Mocking out some fragile bits that depend heavily on being run on Linux
    get_file_content_patch = mock.patch.object(NetworkCollector, "get_file_content", return_value="eth0")
    get_file_content_patch.start()
    os_readlink_patch = mock.patch.object(os, "readlink")
    os_readlink_patch.start()
    os_readlink_patch.return_value = os.path.join(os.path.sep, "sys", "class", "net", "eth0")
    # Run test
    l = LinuxNetworkCollector()


# Generated at 2022-06-23 00:12:46.462276
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():   
    import json
    import platform

    class Options:
        def __init__(self, connection='local', gather_subset=None):
            self.connection = connection
            self.gather_subset = gather_subset

    class Module:
        def __init__(self):
            self.params = {
                'gather_subset': 'network',
            }

        def get_bin_path(self, arg, opt_dirs=[]):
            if arg == 'ip':
                return '/sbin/ip'
        
        def run_command(self, cmd, errors='surrogate_then_replace'):
            data = None

# Generated at 2022-06-23 00:12:58.469415
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = Mock()
    module.run_command.return_value = (0, '4: eth0: <BROADCAST,MULTICAST,UP> mtu 1500 qdisc mq state UP group default qlen 1000\n    link/ether 00:00:00:00:00:00 brd ff:ff:ff:ff:ff:ff\n    inet 192.168.1.1/24 brd 192.168.1.255 scope global eth0\n       valid_lft forever preferred_lft forever\n', '')
    linux_network = LinuxNetwork(module)
    default_v4, default_v6 = linux_network.get_default_interfaces()

# Generated at 2022-06-23 00:13:05.736490
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    distribution = LinuxDistribution()
    distribution.major_version = '7'
    options = dict(
        distribution=distribution,
    )
    network = LinuxNetwork(**options)
    assert len(network.interfaces) > 0
    assert len(network.ipaddresses) > 0
    assert network.default_ipv4['address'] == network.ipaddresses['all_ipv4_addresses'][0]
    assert network.default_ipv6['address'] == network.ipaddresses['all_ipv6_addresses'][0]


# Generated at 2022-06-23 00:13:17.614943
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible.module_utils.basic import AnsibleModule
    #
    # Dict of options
    #
    params = dict(
        gather_subset=['!all']
    )
    #
    # Mock module
    #
    module = AnsibleModule(argument_spec=dict(**params))
    #
    # Mock functions
    #
    def mock_get_file_content(*args, **kwargs):
        if args[0] == '/etc/os-release':
            if 'ID_LIKE' in kwargs:
                if 'debian' in kwargs['ID_LIKE']:
                    return 'debian'
                elif 'suse' in kwargs['ID_LIKE']:
                    return 'sles'

# Generated at 2022-06-23 00:13:30.652889
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from ansible_collections.community.general.tests.unit.compat import unittest

    class TestLinuxNetworkCollector(unittest.TestCase):
        def setUp(self):
            self.test_NetworkCollector_obj = NetworkCollector()
            self.test_LinuxNetworkCollector_obj = LinuxNetworkCollector()

        def test_LinuxNetworkCollector_obj_inherits_NetworkCollector_obj(self):
            self.assertIsInstance(self.test_LinuxNetworkCollector_obj, NetworkCollector)

        def test_LinuxNetworkCollector_required_facts(self):
            self.assertEqual(LinuxNetworkCollector.required_facts, {'distribution', 'platform'})
            self.assertNotEqual(LinuxNetworkCollector.required_facts, {'platform'})

    # Run test
   

# Generated at 2022-06-23 00:13:43.125357
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    class MockModule(object):
        def get_bin_path(self, path):
            if path in ('ip', 'which'):
                return '/bin/' + path
            return None

        def run_command(self, args, **kwargs):
            if args[0] == '/bin/which':
                return 0, '', ''
            return 0, '', ''

    module = MockModule()
    linux = LinuxNetwork(module)
    interfaces, ips = linux.get_interfaces_info('/bin/ip',
                                                default_ipv4=dict(address="1.2.3.4"),
                                                default_ipv6=dict(address="fe80::222:19ff:fe5b:f5c5"))

# Generated at 2022-06-23 00:13:45.406582
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec=dict())
    ln = LinuxNetwork(module, network_info=None)
    assert ln


# Generated at 2022-06-23 00:13:51.524895
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork()
    ln.get_interfaces_info(None, None, None)

# -*- -*- -*- End included fragment: ../../../lib_utils/src/class/linux_network.py -*- -*- -*-

# -*- -*- -*- Begin included fragment: lib/base.py -*- -*- -*-

# pylint: disable=too-few-public-methods



# Generated at 2022-06-23 00:14:02.545646
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-23 00:14:06.520812
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule({})
    lin = LinuxNetwork(module)
    ifaces = lin.get_default_interfaces()
    module.exit_json(changed=False, ifaces=ifaces)



# Generated at 2022-06-23 00:14:16.631018
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.facts.network.linux import LinuxNetwork
    from mock import Mock
    from ansible.module_utils import basic
    import sys
    import re


# Generated at 2022-06-23 00:14:28.821635
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network = LinuxNetwork()
    c = 'sudo ip route show'
    output = """default via 192.168.122.1 dev eth1  metric 100 
    default via 192.168.122.1 dev eth2  proto static  metric 101 
    default via 192.168.122.1 dev eth0  proto static  metric 102 
    default via 192.168.122.1 dev p1p1  proto static  metric 103 """
    rc, out, err = linux_network.module.run_command(c)
    assert(linux_network.get_default_interfaces(output) == {'ipv4': {'interface': 'eth2', 'gateway': '192.168.122.1'}, 'ipv6': {'interface': 'eth1', 'gateway': '192.168.122.1'}})


# Generated at 2022-06-23 00:14:42.177485
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # prepare mocks
    module_mock = MagicMock()
    ln_mock = LinuxNetwork(module_mock)
    ln_mock.module.get_bin_path = MagicMock(return_value=True)
    ln_mock.module.run_command = MagicMock(return_value=(0,"",""))

    # check ethtool_path
    data = ln_mock.get_ethtool_data("eth0")
    assert data == {}

    ln_mock.module.get_bin_path = MagicMock(return_value="")

    # check rc != 0
    ln_mock.module.run_command = MagicMock(return_value=(1,"",""))
    data = ln_mock.get_ethtool_data("eth0")

# Generated at 2022-06-23 00:14:54.926867
# Unit test for constructor of class LinuxNetwork

# Generated at 2022-06-23 00:15:02.517959
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
  ln = LinuxNetwork()
  ln.add_section('path1', {})
  ln.add_section('path2', {})
  assert ln.sections != {}
  assert ln.sections['path1'] == {}
  assert ln.sections['path2'] == {}
  assert ln.sections == {}
  l2 = LinuxNetwork()
  l2.add_section('path1', {})
  assert ln.sections == l2.sections


# Generated at 2022-06-23 00:15:03.278000
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    assert 0 == 0

# Generated at 2022-06-23 00:15:12.759682
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    # setup
    module = Mock(name="ansible_module")
    set_module_args(dict(
        config="type=vlan id=42 dev=enp0s3",
        name="enp0s3.42"
    ))
    ln = LinuxNetwork(module)

    # exercise
    ln._run_module(['up'])
    assert module.run_command.call_args_list == [call(['ip', 'link', 'add', 'link', 'enp0s3', 'name', 'enp0s3.42', 'type', 'vlan', 'id', '42']),
                                                 call(['ifup', 'enp0s3.42'])]

    # cleanup
    module.run_command.reset_mock()



# Generated at 2022-06-23 00:15:24.598036
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    mock = MagicMock()
    mock.get_bin_path = MagicMock(side_effect=lambda x: '/sbin/%s' % x)
    nm = LinuxNetwork(mock)
    nm.get_sysctl = MagicMock(side_effect=lambda x: x.split('.')[-1])
    nm.get_text_file_content = MagicMock(side_effect=lambda x: '')
    nm.get_interfaces_info = MagicMock(return_value=([], []))
    nm.get_interfaces_info = MagicMock(return_value=([], []))

    nm.get_default_ipv4 = MagicMock(return_value=dict(address='1.2.3.4'))

# Generated at 2022-06-23 00:15:37.709532
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # FIXME: this test might be better as a unit test in a class

    # Setup
    mt = MockLinuxModule()
    mt.get_bin_path.side_effect = lambda x: x
    mt.run_command.side_effect = lambda x, err: (0, x, '')
    mt.get_file_content.return_value = ''
    ln = LinuxNetwork(mt)

    # Expected result for empty input
    assert ln.get_interfaces_info('', {}, {}) == ({}, {'all_ipv4_addresses': [], 'all_ipv6_addresses': []})

    # Expected result for input pattern 1

# Generated at 2022-06-23 00:15:48.924494
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    """Test function populate of class LinuxNetwork with 2 arguments"""
    # Setup class instance, with a mocked module, and a mocked argspec
    module_spec = dict(
        get_bin_path=dict(return_value='/usr/bin/ip'),
    )
    module = Mock(**module_spec)
    argspec = dict(
        ip_path=dict(default='/usr/bin/ip'),
        default_ipv4=dict(default=dict(address='127.0.0.1')),
        default_ipv6=dict(default=dict(address='::1')),
    )
    ln = LinuxNetwork(module, argspec)

    # Setup test variables for this method

# Generated at 2022-06-23 00:16:00.942894
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
  module = MagicMock(name="module")
  module.params = {}
  module.exit_json = MagicMock(name="exit_json")
  pytest.set_trace()
  linux_net = LinuxNetworkCollector(module)

# Generated at 2022-06-23 00:16:02.293570
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    pass



# Generated at 2022-06-23 00:16:10.687206
# Unit test for constructor of class LinuxNetwork

# Generated at 2022-06-23 00:16:24.512365
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # default_interface_name_for_ipvX_address and interface_has_ipvX_address
    # will be mocked
    # get_default_interfaces_output will be mocked

    def indirect_default_interface_name_for_ipvX_address(ip):
        return default_interface_name_for_ipvX_address(ip)

    def indirect_interface_has_ipvX_address(ip):
        return interface_has_ipvX_address(ip)

    # Test various combinations possible in get_default_interfaces
    def test_for_ipvX(ip, name, has_ip, address):
        mock_module = MagicMock()
        mock_module.get_bin_path.side_effect = lambda x: x
        linux_network = LinuxNetwork(mock_module)

        linux

# Generated at 2022-06-23 00:16:31.399353
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(
        argument_spec=dict()
    )
    mocked_run_command = Mock(return_value=(0, '', ''))
    mocked_get_bin_path = Mock(return_value='/bin/ethtool')
    module.run_command = mocked_run_command
    module.get_bin_path = mocked_get_bin_path
    ln = LinuxNetwork(module)
    interface = 'lo'