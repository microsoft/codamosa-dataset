

# Generated at 2022-06-23 00:06:37.936212
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # For test purpose, we create a dummy LinuxNetwork object
    obj = LinuxNetwork(None)
    # ip_path holds path to the ip executable
    ip_path = "/bin/ip"
    with open(ip_path, "w") as f:
        # We write minimal content to the file, this is enough for the test
        f.write('')

    # Note: we can't create a temporary file with ip executable, and pass the
    # path to the object, because it's not possible to use a temporary file
    # as 'binary_path' like this:
    # obj.binary_path = f.name
    # because binary_path is a property defined by ANSIBLE_NOCOLOR variable
    # So we give the path to the object and it will read it, and check if
    # the file is present. This is the same

# Generated at 2022-06-23 00:06:44.654514
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    test_module = AnsibleModule(argument_spec=dict())
    test_module.get_bin_path = MagicMock(return_value='/bin/ip')
    test_module.run_command = MagicMock(return_value=(0,"", ""))
    test_module.params = {'interfaces': {}}

    ln = LinuxNetwork(test_module)
    ln.populate()



# Generated at 2022-06-23 00:06:51.805528
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    module = AnsibleModuleMock()
    path = module.get_bin_path("ip")

    # It should raise an exception when path to ip command is None
    module.get_bin_path.return_value = None
    # pylint: disable=no-member
    with pytest.raises(NetworkError):
        LinuxNetwork(module).get_default_interfaces()

    # It should return default_ipv4, default_ipv6
    command = []
    command.append([path, 'route', 'get', '8.8.8.8'])
    command.append([path, 'route', 'get', '-6', '2001:4860:4860::8888'])
    module.run_command.side_effect = command.pop(0)
    ln = LinuxNetwork(module)
    #

# Generated at 2022-06-23 00:06:55.251193
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    network_collector = LinuxNetworkCollector(dict(), dict())
    assert network_collector.platform == 'Linux'
    assert network_collector.required_facts == set(['distribution', 'platform'])

# Generated at 2022-06-23 00:07:00.549557
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from ansible_collections.community.general.tests.unit.compat.mock import MagicMock
    module = MagicMock()
    module.params = {}
    collector = LinuxNetworkCollector(module)
    assert collector.platform == 'Linux'
    assert collector.required_facts == {'distribution', 'platform'}

# Generated at 2022-06-23 00:07:13.807699
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule

    def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False,
                    path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None,
                    umask=None, encoding=None, errors='strict', data_encoding=None):
        return 0, "", ""

    module = AnsibleModule(argument_spec={})
    module.run_command = run_command
    platform_network.NetworkModuleMixin.run_command = run_command
    ln = LinuxNetwork(module)

# Generated at 2022-06-23 00:07:20.158897
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = MagicMock()
    mock = LinuxNetwork(module)


# Generated at 2022-06-23 00:07:32.760731
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=['!'], type='list'),
    })
    ln = LinuxNetwork()
    interfaces, ips = ln.get_interfaces_info('/sbin/ip', {}, {})
    assert len(interfaces) > 0
    assert len(ips['all_ipv4_addresses']) > 0
    assert len(ips['all_ipv6_addresses']) > 0
    assert len(ips['all_ipv4_addresses']) + len(ips['all_ipv6_addresses']) > len(ips['all_ipv4_addresses'] + ips['all_ipv6_addresses'])



# Generated at 2022-06-23 00:07:44.739074
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec=dict(
        gather_subset=dict(type='list', elements='str'),
        gather_network_resources=dict(type='list', elements='str'),
        filter=dict(type='list', elements='str'),
        use_ipv6=dict(type='bool'),
    ), supports_check_mode=True)

    ln = LinuxNetwork(module)

    ln.populate(
        ln.get_interfaces_info(ln.get_bin_path('ip'), ln.get_default_interface_ipv4(), ln.get_default_interface_ipv6()),
        ln.get_ip_rules(ln.get_bin_path('ip')),
    )

    if module.params['gather_subset']:
        ln.filter

# Generated at 2022-06-23 00:07:54.284529
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    """
    Basic unit test for Ansible module: ansible.modules.system.cloud.LinuxNetwork.get_default_interfaces().
    """

    # Dummy LinuxNetwork object.
    class linuxN:
        def __init__(self):
            self.module = None

    # Create dummy data for default interface, default IPv4 and default IPv6.
    default_interface = {
        'interface': 'eth0',
        'gateway': '10.0.0.138'}

# Generated at 2022-06-23 00:07:57.414524
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    '''
    Unit test for method get_default_interfaces of class LinuxNetwork
    '''
    LN = LinuxNetwork()
    v4, v6 = LN.get_default_interfaces()
    assert v4['address']
    assert v6['address']

# Generated at 2022-06-23 00:07:58.628136
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    pass #FIXME: write test

# Generated at 2022-06-23 00:08:11.660171
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    import pytest
    from ansible.module_utils.basic import AnsibleModule

    MODULE_NAME = 'ansible_network_resources'
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    module.params['provider'] = dict(
        auth_pass=None,
        authorize=False,
        host=None,
        password=None,
        username=None,
    )
    linux_network = LinuxNetwork(module)

    # First test
    device = 'test-device'

# Generated at 2022-06-23 00:08:18.316610
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    result = LinuxNetwork.get_default_interfaces(default_ipv4='192.0.2.100', default_ipv6='2001:db8::100')
    assert result == {'ipv4': {'address': '192.0.2.100', 'network': '192.0.2.0', 'netmask': '255.255.255.0', 'broadcast': '192.0.2.255'},
                      'ipv6': {'address': '2001:db8::100', 'network': '2001:db8::', 'prefix': '64', 'scope': 'global'}}


# Generated at 2022-06-23 00:08:22.760064
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    collector = LinuxNetworkCollector()
    assert collector.platform == 'Linux'
    assert collector.fact_class == LinuxNetwork
    assert collector.required_facts == set(['distribution', 'platform'])


###
# OpenBSD Network Facts
###

# Generated at 2022-06-23 00:08:36.060277
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    from collections import namedtuple
    module = namedtuple('module', ['run_command'])

    def run_command(command, errors='surrogate_then_replace'):
        if command == ['/bin/ip', 'route', 'get', '8.8.8.8']:
            return 0, '8.8.8.8 via 10.0.0.1 src 10.0.0.2 dev eth0', ''
        else:
            return 0, '', ''
    module.run_command = run_command

    lni = LinuxNetwork(module)
    # v4, v6 = get_default_interfaces(module)
    v4, v6 = lni.get_default_interfaces()

# Generated at 2022-06-23 00:08:43.141675
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    f = open("interface_linux_network.yml", "r")
    config = yaml.load(f)
    f.close()
    # FIXME: no need to pass in config
    ln_obj = LinuxNetwork(config)
    ln_obj.get_interfaces_details()
    assert 'ipv4' in ln_obj.interfaces['eth0']
    assert 'ipv6' in ln_obj.interfaces['eth0']
    assert 'address' in ln_obj.interfaces['eth0']['ipv4']
    assert 'netmask' in ln_obj.interfaces['eth0']['ipv4']
    assert 'macaddress' in ln_obj.interfaces['eth0']
    assert 'mtu' in ln_obj.interfaces['eth0']

# Generated at 2022-06-23 00:08:51.311890
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    device_name = 'test-device'
    interfaces = {
        "lo": {
            "device": "lo"
        },
        device_name: {
            "device": device_name,
            "ipv4": {
                "address": "123.123.123.123"
            },
            "ipv6": [
                {
                    "scope": "global",
                    "address": "ff01::1",
                    "prefix": "16"
                }
            ]
        },
        "lo:1": {
            "device": "lo:1"
        }
    }
    module = DummyModule()
    network = Network(module)
    network.interfaces = interfaces

# Generated at 2022-06-23 00:09:02.802447
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():

    from __main__ import LinuxNetwork

    module_mock = Mock()

# Generated at 2022-06-23 00:09:14.710907
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():

    module = mock.Mock()

    filename = 'ethtool-k.txt'

    linux_network = LinuxNetwork(module)

    module.get_bin_path.side_effect = lambda arg: arg

    # Return value of function get_file_content()
    mock_open = mock.mock_open(read_data=read_fixture(filename))
    with mock.patch('{0}.open'.format(BUILTIN), mock_open, create=True):
        # Call the function
        ret = linux_network.get_ethtool_data('eth0')
        # Verify the results

# Generated at 2022-06-23 00:09:21.085541
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    network_info = LinuxNetwork(module)

    assert len(network_info.default_ipv4) == 0
    assert len(network_info.default_ipv6) == 0
    assert len(network_info.interfaces) > 0
    if platform.system() != 'Linux':
        assert len(network_info.interfaces) == 1
        all_keys = set(['device', 'ipv4', 'macaddress'])
        assert set(network_info.interfaces.keys()) == all_keys

# Generated at 2022-06-23 00:09:30.915925
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    mod = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=[], type='list')
        )
    )
    net = LinuxNetwork(mod)
    net.populate()
    assert net.default_ipv4['address'] in net.default_ipv4['broadcast']
    assert net.default_ipv6['address'] not in net.default_ipv6['broadcast']


if __name__ == '__main__':
    # Unit test for method populate of class LinuxNetwork
    test_LinuxNetwork_populate()

# Generated at 2022-06-23 00:09:33.301077
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    assert LinuxNetwork(None)().get_ethtool_data("eth0") == {}



# Generated at 2022-06-23 00:09:34.448304
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    obj = LinuxNetwork()
    return



# Generated at 2022-06-23 00:09:38.843606
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule({})
    nm = LinuxNetwork(module)
    # FIXME: return module.fail_json(msg='?') on err
    nm.populate()
    # TODO: return module.exit_json()
    # TODO: include an asserted result in the .json



# Generated at 2022-06-23 00:09:42.438797
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # Check to see if the class has been instantiated correctly
    assert LinuxNetworkCollector.get_platform() == 'Linux'
    assert LinuxNetworkCollector.get_fact_class() == LinuxNetwork
    assert LinuxNetworkCollector.required_facts == {'distribution', 'platform'}
    return "SUCCESS"


# Generated at 2022-06-23 00:09:52.061359
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Setup a fake module
    module = Mock()
    module.get_bin_path = Mock(return_value='path/bin/ethtool')

    # Fake device to test with
    device = 'eth0'

    # Instantiate the class
    network_obj = Network(module)

    # Mock the run command method
    # FIXME: not sure about this approach
    module.run_command = Mock(return_value=(0, '', ''))
    data = network_obj.get_ethtool_data(device)
    assert data == {'features': {},
                    'timestamping': [],
                    'hw_timestamp_filters': [],
                    }

# Generated at 2022-06-23 00:09:53.760336
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    assert_equal(LinuxNetwork('/bin/true').get_default_interfaces(), {})


# Generated at 2022-06-23 00:10:01.024349
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = MagicMock()
    ln = LinuxNetwork(module)
    assert ln.module == module
    assert ln.IP_PATH == '/sbin/ip'
    assert ln.IP6_PATH == '/sbin/ip'
    assert ln.INTERFACE_TYPE.get(2) == 'ethernet'
    assert ln.INTERFACE_TYPE.get(6) == 'bridge'



# Generated at 2022-06-23 00:10:13.829752
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-23 00:10:23.280792
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    '''
    unit test for this module

    run at the command line with:
    python -c "import ansible.module_utils.basic; \
        import ansible.module_utils.network.linux.linux_network; \
        m = ansible.module_utils.basic.AnsibleModule(); \
        p = ansible.module_utils.network.linux.linux_network.LinuxNetwork(m); \
        p.get_interfaces_info('/sbin/ip')"
    '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.network.common.utils import remove_default_spec
    from ansible.module_utils.network.common.netconf import get_config


# Generated at 2022-06-23 00:10:36.440406
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-23 00:10:43.332681
# Unit test for method populate of class LinuxNetwork

# Generated at 2022-06-23 00:10:53.721799
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all']
    # NOTE: LinuxNetwork module.params -> Data/data __dict__
    # NOTE: data could be named conf too
    data = Data()
    setattr(module, 'params', data)
    setattr(module, 'params', data.__dict__)
    ln = LinuxNetwork(module)
    results = ln.populate()

    assert(results['gather_facts'])

    assert(results['ansible_facts']['ansible_all_ipv4_addresses'])
    assert(results['ansible_facts']['ansible_all_ipv6_addresses'])

# Generated at 2022-06-23 00:11:06.718662
# Unit test for constructor of class LinuxNetwork

# Generated at 2022-06-23 00:11:19.058676
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    import doctest
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: "/bin/fakeethtool"
    module.run_command = lambda x, **kwargs: (0, "", "")
    l = LinuxNetwork(module)
    ret = l.get_ethtool_data("lo")
    assert {} == ret

    module.run_command = lambda x, **kwargs: (1, "", "")
    ret = l.get_ethtool_data("lo")
    assert {} == ret


# Generated at 2022-06-23 00:11:28.733226
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    def get_ifcfg_path(device):
        return os.path.join(os.path.dirname(__file__), "fixtures/ifcfg-{}".format(device))

    def get_ifcfg_content(device):
        with open(get_ifcfg_path(device)) as f:
            return f.read()

    def get_file_content(path):
        with open(path, "r") as f:
            return f.read()

    def get_file_content_bytes(path):
        with open(path, "rb") as f:
            return f.read()

    def run_command(command):
        return 0, "", ""


# Generated at 2022-06-23 00:11:42.094351
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import unittest
    import tempfile
    import shutil
    import os

    class Test(unittest.TestCase):
        def setUp(self):
            self.working_dir = tempfile.mkdtemp()

        def test_get_interfaces_info(self):
            self.maxDiff = None

# Generated at 2022-06-23 00:11:53.214059
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params = dict()
    ln = LinuxNetwork(module)
    net_facts = {}
    interfaces, ips = ln.get_interfaces_info(None, None, None)
    net_facts['interfaces'] = interfaces
    # this test does not get the default interface values
    # so we fix it here
    for _, iface in net_facts['interfaces'].items():
        if iface.get('ipv4', False):
            iface['ipv4']['broadcast'] = ''
            iface['ipv4']['network'] = ''
            iface['ipv4']['netmask'] = ''
        if iface.get('ipv6', False):
            iface['ipv6'][0]['prefix']

# Generated at 2022-06-23 00:12:07.122852
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """
    This method is a unit test for method LinuxNetwork().get_interfaces_info()
    It is not run automatically by ansible-test, it needs to be run manually.

    Prerequisites:
        - Python 3 interpreter
        - Tested on Fedora Linux and CentOS Linux
        - Kernel needs to have CONFIG_MACVLAN enabled
        - install package iproute
    """

    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule

    # create a mock for class AnsibleModule
    class MockAnsibleModule(AnsibleModule):
        def __init__(self, argument_spec):
            self.argument_spec = argument_spec

# Generated at 2022-06-23 00:12:08.846664
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    args = {}
    args['run_command'] = FakeRunCommand()
    module = FakeModule(**args)
    l = LinuxNetwork(module)
    assert isinstance(l, LinuxNetwork)


# Generated at 2022-06-23 00:12:13.055950
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = Mock(
        run_command=MagicMock(return_value=(0, '', ''))
    )
    x = LinuxNetwork(module)
    x.get_default_interfaces()
    command = module.run_command.call_args_list
    assert command[0] == call(['ip', 'route', 'show', 'to', 'match', '0/0'], errors='surrogate_then_replace')
    assert command[1] == call(['ip', '-6', 'route', 'show', 'to', 'match', '::/0'], errors='surrogate_then_replace')

# Generated at 2022-06-23 00:12:23.019548
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    ln = LinuxNetwork()
    assert ln.get_ethtool_data("eth0")['features']['rx_all'] == 'on'
    assert ln.get_ethtool_data("eth0")['timestamping'][0] == 'software'
    assert ln.get_ethtool_data("eth0")['timestamping'][1] == 'hardware'
    assert ln.get_ethtool_data("eth0")['hw_timestamp_filters'][0] == 'all'
    assert ln.get_ethtool_data("eth0")['phc_index'] == 3



# Generated at 2022-06-23 00:12:35.830912
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-23 00:12:47.027060
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    class ModuleMock(object):
        def get_bin_path(self, path):
            return "/usr/bin/ethtool"
        def run_command(self, args, errors='strict'):
            return 0, "", ""
    lsn = LinuxNetwork(ModuleMock())
    result = lsn.get_ethtool_data("lo")

# Generated at 2022-06-23 00:12:59.829892
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """
    LinuxNetwork.get_interfaces_info
    """

    def mock_get_file_content(path, default=None):
        mock_content = ""
        if path == '/sys/class/net/eth0/mtu':
            mock_content = "9001"
        elif path == '/sys/class/net/eth0/address':
            mock_content = "00:0c:29:89:86:48"
        elif path == '/sys/class/net/eth0/operstate':
            mock_content = "up"
        elif path == '/sys/class/net/eth0/device/driver/module':
            mock_content = "/lib/modules/kernel/drivers/net/e1000"
        elif path == '/sys/class/net/eth0/type':
            mock_content

# Generated at 2022-06-23 00:13:02.764527
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    linux_network_collector = LinuxNetworkCollector(None)
    assert linux_network_collector
    assert isinstance(linux_network_collector._fact_class, LinuxNetwork)


# Generated at 2022-06-23 00:13:07.855193
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # Construct a fake module
    module = AnsibleModule(
        argument_spec=dict(),
        # No params passing
        supports_check_mode=True
    )
    # Set up our collector
    collector = LinuxNetworkCollector(module)
    # Test if we can access the required facts
    # We are passing an empty dictionary using a mock AnsibleModule
    # so that the required facts in the constructor can be safely accessed
    assert collector.get_required_facts() == {}
    # no params means no params to check
    assert collector.check_params() is None



# Generated at 2022-06-23 00:13:18.717995
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    """Unit test for constructor of class LinuxNetwork"""

    # Construct object with valid parameters
    try:
        linux_network = LinuxNetwork()
    except Exception:
        assert False, "Failed to construct object"

    # Construct object with valid parameters
    try:
        linux_network = LinuxNetwork()
    except Exception:
        assert False, "Failed to construct object"

    # Check attributes
    assert linux_network.params == [], "Failed to create empty params"
    assert linux_network.ip_path == "", "Failed to create empty ip_path"

    # Construct object with invalid parameters
    try:
        linux_network = LinuxNetwork(config_file="/etc/modprobe.d/dahdi.conf", module=None)
    except Exception:
        assert False, "Failed to construct object"

    # Construct object

# Generated at 2022-06-23 00:13:31.660645
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from ansible.module_utils.basic import AnsibleModule

    class MockModule(AnsibleModule):
        def get_bin_path(self, arg):
            return True

        def run_command(self, args, errors='strict'):
            if args[-1] == 'fake_non_existant_device':
                return 127, "", "run_command failed"
            if args[-1] == 'fake_error_device':
                return 255, "", "error"
            if args[-1] == 'fake_error_device_v2':
                return 255, "", "error in get_file_content"
            if args[-1] == 'fake_error_device_v3':
                return 0, "", "error in get_file_content"

# Generated at 2022-06-23 00:13:44.108801
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    class ModuleMock():
        def __init__(self, module=None, bin_path=None, run_command=None):
            self.run_command = run_command
            self.bin_path = bin_path
            self.params = {'ip': module,
                           'ip6': module}

        def get_bin_path(self, binary):
            return self.bin_path

    def run_command(args, errors):
        if args == ['/bin/ip', 'addr', 'show']:
            return 0, ip_addr_show, ''
        elif args == ['/bin/ip', '-f', 'inet', 'neigh', 'show']:
            return 0, ip_neigh_show, ''

# Generated at 2022-06-23 00:13:52.698641
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = DummyAnsibleModule()
    ln = LinuxNetwork(module)
    # test with empty /proc/net/route
    module.run_command = MagicMock(return_value= (0, '', ''))
    assert ln.get_default_interfaces() == (None, None)
    def test_with_route(route_file, expected_retval):
        module.run_command = MagicMock(return_value= (0, route_file, ''))
        assert ln.get_default_interfaces() == expected_retval
    # test with sample /proc/net/route values
    route_file = 'Iface\tDestination\tGateway \tFlags\tRefCnt\tUse\tMetric\tMask\tMTU\tWindow\tIRTT\n'
   

# Generated at 2022-06-23 00:13:58.279985
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    linux_network = LinuxNetwork(module=module)
    interfaces = linux_network.get_default_interfaces()
    assert interfaces
    assert "default_ipv4" in interfaces
    assert "default_ipv6" in interfaces



# Generated at 2022-06-23 00:13:59.367812
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # initializations
    assert True

# Generated at 2022-06-23 00:14:12.637125
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-23 00:14:17.502976
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    result = LinuxNetworkCollector(module=module)
    module.exit_json(**result)

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 00:14:25.383477
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    from ansible.module_utils.basic import get_exception
    module = AnsibleModule(argument_spec={})
    try:
        obj = LinuxNetwork()
        obj.module = module
        out = obj.get_default_interfaces()
        assert out['ipv4']['interface'] != ''
        assert out['ipv6']['interface'] != ''
    except Exception as e:
        failure = get_exception()
        print(repr(failure))
        assert False



# Generated at 2022-06-23 00:14:37.961757
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.args = {}
            self.fail_json = Mock(return_value=dict(msg='failed', failed=True))
            self.exit_json = Mock(return_value=dict(msg='successfully', changed=True))

        def get_bin_path(self, cmd):
            return cmd

        def run_command(self, cmd, check_rc=True, errors=None):
            return 0, '', ''

    ln = LinuxNetwork()
    ln.module = MockModule()
    # The following should not result in a KeyError:
    #   "module.fail_json() takes at least failure_message as parameter"
    ln.populate()



# Generated at 2022-06-23 00:14:50.575823
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    obj = LinuxNetwork(module)

# Generated at 2022-06-23 00:15:02.995967
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    if not HAS_LIB_IP:
        module.fail_json(msg="Missing library: libip. You can install it simply with: apt-get install python-ip")
    ln = LinuxNetwork(module)
    interfaces, ips = ln.get_interfaces_info('ip', {}, {})
    assert 'lo' in interfaces
    assert interfaces['lo']['ipv4']['address'] == '127.0.0.1'
    assert interfaces['lo']['ipv4']['netmask'] == '255.0.0.0'
    assert interfaces['lo']['ipv4']['network'] == '127.0.0.0'

# Generated at 2022-06-23 00:15:12.603157
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    fake_module = FakeModule()
    fake_module.run_command = MagicMock(return_value=(0, "default via 10.0.2.2 dev eth0\n10.0.2.0/24 dev eth0 proto kernel scope link src 10.0.2.15\n192.168.122.0/24 dev virbr0 proto kernel scope link src 192.168.122.1\n", ""))
    net = LinuxNetwork(fake_module)
    ipv4, ipv6 = net.get_default_interfaces()
    assert ipv4 == {'address': "10.0.2.15", 'gateway': "10.0.2.2", 'interface': "eth0"}
    assert ipv6 == {'gateway': "", 'interface': ""}

# Generated at 2022-06-23 00:15:16.800738
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec=dict())

    assert LinuxNetwork(module).populate() == dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )


# Generated at 2022-06-23 00:15:29.274268
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    interfaces_info = LinuxNetwork().get_interfaces_info(None, None, None)[0]

    assert isinstance(interfaces_info, dict)
    assert 'lo' in interfaces_info.keys()
    assert 'ens33' in interfaces_info.keys()

    assert 'lo' in interfaces_info.keys()
    # TODO add more asserts
    assert 'active' in interfaces_info['lo']
    assert 'macaddress' in interfaces_info['lo']
    assert 'module' in interfaces_info['lo']
    assert 'type' in interfaces_info['lo']
    assert 'mtu' in interfaces_info['lo']
    assert 'ipv4' in interfaces_info['lo']
    assert 'ipv6' in interfaces_info['lo']
    assert 'ethtool' in interfaces_info['lo']

# Generated at 2022-06-23 00:15:40.544816
# Unit test for method get_default_interfaces of class LinuxNetwork

# Generated at 2022-06-23 00:15:44.727274
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})

    my_network = LinuxNetwork(module)
    assert my_network.ip_path == '/sbin/ip'
    assert my_network.module == module


# Unit tests for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-23 00:15:53.166892
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    obj = LinuxNetwork(module=module)
    obj.default_ipv4, obj.default_ipv6 = obj.get_default_interfaces()
    obj.interfaces, obj.ips = obj.get_interfaces_info(ip_path=module.get_bin_path("ip"),
                                                      default_ipv4=obj.default_ipv4,
                                                      default_ipv6=obj.default_ipv6)


# Generated at 2022-06-23 00:15:57.143745
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = FakeAnsibleModule(dict(name='eth0', state='present'))
    network = LinuxNetwork(module)
    result = network.get_interfaces_info('', {}, {})
    assert result[0]



# Generated at 2022-06-23 00:16:06.122081
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(supports_check_mode=True, argument_spec=dict())
    rc = None
    out = ''
    err = ''
    obj = LinuxNetwork(module=module)
    try:
        obj.populate()
    except Exception as inst:
        obj.result['failed'] = True
        obj.module.fail_json(msg=inst.args, **obj.result)
    else:
        obj.result['changed'] = False
        obj.result['failed'] = False
        obj.module.exit_json(**obj.result)


# Generated at 2022-06-23 00:16:08.440038
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    nm = NetworkModule(module)
    nm.get_distribution()



# Generated at 2022-06-23 00:16:21.034019
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():

    class MockLinuxNetworkModule(object):

        def __init__(self):
            self.params = {
                'ip_path': '/sbin/ip'
            }

        def get_bin_path(self, name):
            return '/sbin/' + name

        def run_command(self, args, **kwargs):
            r = ''

# Generated at 2022-06-23 00:16:22.596428
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    collector = LinuxNetworkCollector(None)
    assert collector is not None


# Generated at 2022-06-23 00:16:30.525898
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """Test get_ethtool_data method of LinuxNetwork class"""

    def get_ethtool_data(self, device):
        """Helper mock method for method get_ethtool_data"""