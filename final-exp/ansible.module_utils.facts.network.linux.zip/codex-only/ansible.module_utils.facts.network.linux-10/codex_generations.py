

# Generated at 2022-06-23 00:06:27.631500
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    m = AnsibleModule()
    network = LinuxNetwork(m)
    features = network.get_ethtool_data("eth0")
    # FIXME: this test is incomplete, but at least it runs
    assert features == {}


# Generated at 2022-06-23 00:06:37.973047
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    fixture_path = os.path.join(os.path.dirname(__file__), 'fixtures', 'LinuxNetwork')

    # Fixture setup

# Generated at 2022-06-23 00:06:48.444930
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    mod = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=[], type='list'),
            filter=dict(default='', type='str'),
        ),
        supports_check_mode=True,
    )

    net = LinuxNetwork()
    net.populate(module=mod)

    assert isinstance(net.interfaces, dict)
    assert 'lo' in net.interfaces
    assert 'ipv4' in net.interfaces['lo']
    assert 'ipv6' in net.interfaces['lo']
    assert isinstance(net.default_ipv4, dict)
    assert 'address' in net.default_ipv4
    assert isinstance(net.default_ipv6, dict)
    assert 'address' in net.default_ipv6
    assert isinstance

# Generated at 2022-06-23 00:07:01.053793
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Only mock if running unittests
    if '__main__' == __name__:
        from ansible.module_utils.basic import AnsibleModule
        # This import is required so that the module can be loaded
        # as a plugin.
        import ansible.plugins.connection.connection_loader  # noqa: F401
        # NOTE: This mock is required because of the
        #       AnsibleModule(argument_spec=dict()) call below
        m = mock.mock_open()
        with mock.patch("%s.open" % builtins.__name__, m, create=True):
            with mock.patch("%s.sleep" % builtins.__name__, lambda x: None):
                m = mock.mock_open()

# Generated at 2022-06-23 00:07:06.293548
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    ''' make sure we get a LinuxNetwork object to work with '''
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    assert network.module is module


# Generated at 2022-06-23 00:07:16.769937
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    l = LinuxNetwork(None)
    with patch('linux.network.get_file_content', return_value='192.168.0.1'):
        assert l.get_default_interfaces() == ({'ipv4': {'gateway': '192.168.0.1', 'address': '192.168.0.1'}}, {})

    with patch('linux.network.get_file_content', return_value=''), \
         patch('linux.network.LinuxNetwork.get_default_ipv4_routes', return_value=(None, None)), \
         patch('linux.network.LinuxNetwork.get_default_ipv6_routes', return_value=(None, None)):
        assert l.get_default_interfaces() == ({}, {})



# Generated at 2022-06-23 00:07:28.476277
# Unit test for method get_default_interfaces of class LinuxNetwork

# Generated at 2022-06-23 00:07:40.454626
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    '''
    Unit tests to make sure the LinuxNetwork class works
    '''
    import ansible.module_utils.linux.network
    n = ansible.module_utils.linux.network.LinuxNetwork()
    return n


if __name__ == '__main__':
    network = test_LinuxNetwork()

    print(network.is_ip_address('1.1.1.1'))
    print(network.is_ip_address(u'::1'))

    print(network.get_default_interface_ipaddr())
    print(network.get_default_ipv4_addr())
    print(network.get_default_ipv6_addr())
    print(network.get_default_network())
    print(network.get_default_route())
    print(network.get_default_gateway())


# Generated at 2022-06-23 00:07:50.802217
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-23 00:07:56.024959
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch
    mock_module = patch('ansible_collections.ansible.netcommon.plugins.module_utils.network.common.network.Linux.populate')
    mock_populate = mock_module.start()
    assert LinuxNetwork.populate(None) == mock_populate.return_value
    mock_module.stop()

# Generated at 2022-06-23 00:08:08.404505
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    """ Check that get_network_module has the correct structure

    """
    network_module = LinuxNetwork()
    default_ipv4 = network_module.get_interface_info('ipv4')
    default_ipv6 = network_module.get_interface_info('ipv6')
    interfaces, ips = network_module.get_interfaces_info(network_module.ip_path, default_ipv4, default_ipv6)

    assert isinstance(interfaces, dict)
    for interface in interfaces.values():
        assert isinstance(interface, dict)
        for key in ['active', 'device', 'type']:
            assert key in interface

    assert isinstance(ips, dict)

# Generated at 2022-06-23 00:08:18.286201
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    # construct LinuxNetwork
    p = LinuxNetwork()
    # get default_ipv4, default_ipv6, interface_ip
    default_ipv4, default_ipv6 = p.get_default_interfaces()
    # get interfaces
    interfaces, ips = p.get_interfaces_info('/sbin/ip', default_ipv4, default_ipv6)
    # check if we have some interfaces, print them
    assert len(interfaces) > 0

# Generated at 2022-06-23 00:08:28.619273
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    import mock

    class MockModule:
        pass

    mod = MockModule()

    mod.run_command = mock.Mock(return_value=(0, '', ''))
    mod.get_bin_path = mock.Mock(return_value='/bin/ip')

    n = LinuxNetwork(mod)

    mod.run_command.assert_called_with(['/bin/ip', 'route'], errors='surrogate_then_replace')
    assert n.default_ipv4['gateway'] == ''
    assert n.default_ipv6['gateway'] == ''



# Generated at 2022-06-23 00:08:39.829467
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    ln = LinuxNetwork(module)

    class Ethtool:
        def __init__(self, data):
            self.data = data

        def get_bin_path(self, _arg):
            return self.data

    def run_command(_args, errors='strict'):
        return 0, "", ""

    class TestObject:
        def __init__(self, module, run_command):
            self.module = module
            self.run_command = run_command

    # Test with no ethtool binary
    module.get_bin_path = Ethtool({})
    module.params = {}
    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data("eth0") == {}

    # Test with

# Generated at 2022-06-23 00:08:42.593882
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    network = LinuxNetwork()
    network.populate()

    # TODO assert something about the results

if __name__ == '__main__':
    test_LinuxNetwork_populate()

# Generated at 2022-06-23 00:08:50.827447
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    module.get_bin_path = lambda x: '/sbin/ip'
    module.run_command = lambda *_, **__: (0, '', '')
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    assert default_ipv4 == {'address': '127.0.0.1', 'netmask': '255.0.0.0', 'network': '127.0.0.0'}
    assert default_ipv6 == {'address': '::1', 'prefix': '128', 'scope': 'host'}

# Generated at 2022-06-23 00:09:01.351824
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})

    rtnl = LinuxNetwork()
    out = rtnl.get_default_interfaces()

    assert type(out) == tuple
    assert len(out) == 2
    assert type(out[0]) == dict
    assert 'address' in out[0]
    assert 'network' in out[0]
    assert 'netmask' in out[0]
    assert type(out[1]) == dict
    assert 'address' in out[1]
    assert 'network' in out[1]
    assert 'netmask' in out[1]
    assert 'scope' in out[1]


# Generated at 2022-06-23 00:09:14.301528
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """Test method get_ethtool_data of class LinuxNetwork."""

    # Test Case 1:
    # Test Case 1 fixtures
    module = MagicMock()
    module.run_command.return_value = (0, 'Features for eno2: \n    rx-checksumming: on \n    tx-checksumming: on \n    ...\n    on', '')
    module.get_bin_path.return_value = '/sbin/ethtool'

    l = LinuxNetwork(module)

    assert l.get_ethtool_data('eno2') == {'features': {'rx_checksumming': 'on', 'tx_checksumming': 'on', '...': 'on'}}

    # Test Case 1 post-conditions

# Generated at 2022-06-23 00:09:24.287666
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    """
    Test get_default_interfaces
    """
    module = mock.MagicMock()
    module.get_bin_path.side_effect = lambda x: {'ip': '/sbin/ip'}.get(x)
    module.run_command.side_effect = lambda x, **kwargs: {
        ('/sbin/ip', 'route'): (0, 'default via 10.0.2.2 dev eth0 proto static', None),
        ('/sbin/ip', '-6', 'route'): (0, 'default via fe80::a00:27ff:fe8c:f95b dev eth0 proto ra metric 1024 expires 1796sec', None),
    }.get(tuple(x))
    module.run_command.return_value = (0, '', '')


# Generated at 2022-06-23 00:09:37.003174
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    with ExitStack() as stack:
        module = stack.enter_context(MockModule())
        stack.enter_context(patch.object(LinuxNetwork, 'get_bin_path'))
        interface = stack.enter_context(patch.object(LinuxNetwork, 'get_interfaces_info'))
        stack.enter_context(patch.object(LinuxNetwork, 'get_interfaces_addresses'))
        stack.enter_context(patch.object(LinuxNetwork, 'get_routes'))
        stack.enter_context(patch.object(LinuxNetwork, 'get_default_route'))
        stack.enter_context(patch.object(LinuxNetwork, 'get_commands_info'))
        stack.enter_context(patch.object(LinuxNetwork, 'get_interfaces_counters'))

# Generated at 2022-06-23 00:09:41.481839
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModuleMock
    l = LinuxNetworkCollector(module)
    assert l._facts['distribution'] == 'unknown'
    assert l._facts['platform'] == 'Linux'
    assert l.required_facts == {'distribution', 'platform'}


# Unit tests for methods of class LinuxNetwork
# TODO: split up into smaller class (s) for _get_interfaces_info/get_distro/get_default_route

# Generated at 2022-06-23 00:09:45.721440
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    n = LinuxNetwork(module=module)
    assert n.ip_path == '/bin/ip'
    assert n.run_commands == {}



# Generated at 2022-06-23 00:09:54.243358
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import dict_merge
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.config import NetworkConfig

    mock_module = patch('ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils.load_provider')
    mock_run_command = patch('ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils.run_commands')

    # first use case: configuration is unset

# Generated at 2022-06-23 00:10:07.024889
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """
    Unit test for method get_ethtool_data of class LinuxNetwork

    Test that the right data is returned by get_ethtool_data() under all
    possible conditions (two empty files, two existing files, one existing
    file, etc.).

    This unit test replaces some filesystem content with test data for a short
    amount of time, then puts the content back to normal.

    :return: None
    """

    import os
    import glob
    import shutil

    from ansible.modules.network.common.utils import get_file_content

    from lib_linux_network import LinuxNetwork

    # Method to be tested
    method = 'get_ethtool_data'

    # Create a temporary directory for tests
    tmp_dir = "/tmp/ansible-tmp-ethtool_data-unittest"

# Generated at 2022-06-23 00:10:19.671683
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(
        argument_spec=dict()
    )
    module.run = Mock()
    module.get_bin_path = Mock(return_value='/usr/bin/ethtool')
    module.run_command = Mock(return_value=(0, "Offload parameters for eth2\nlarge-receive-offload: on\nrsc-offload: on\ntcp-segmentation-offload: off", ''))

    ln = LinuxNetwork(module)
    result = ln.get_ethtool_data('eth2')
    assert result['features']['large_receive_offload'] == 'on'
    assert result['features']['rsc_offload'] == 'on'
    assert result['features']['tcp_segmentation_offload'] == 'off'




# Generated at 2022-06-23 00:10:31.963815
# Unit test for method populate of class LinuxNetwork

# Generated at 2022-06-23 00:10:44.855874
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})

    def get_file_content_mock(*args, **kwargs):
        if args[0] == "/proc/net/fib_trie":
            return b'''
Prefix            Destination             NextHop              Mask             Flags
0x0000000000000000000000000000000000000000000000000000000000000000
0x0000000000000000000000000000000000000001000000000000000000000000 0x0000000000000000000000000000000000000000000000000000000000000000 0x0000000000000000000000000000000000000000000000000000000000000000 000e SIBLING-OF-ROOT
0x0000000000000000000000000000000000000001000000000000000000000000 0x0000000000000000000000000000000000000000000000000000000000000000 0x0000000000000000000000000000000000000000000000000000000000000000 000e SIBLING-OF-ROOT
'''

# Generated at 2022-06-23 00:10:54.650310
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    linux_network = LinuxNetwork(module)
    ip_path = "/bin/ip"
    default_ipv4, default_ipv6 = linux_network.get_default_interfaces(ip_path)

    assert "interface" in default_ipv4
    assert "address" in default_ipv4
    assert "gateway" in default_ipv4

    assert "interface" in default_ipv6
    assert "address" in default_ipv6
    assert "gateway" in default_ipv6

    # make sure the fields are accessible by keys
    assert default_ipv4["interface"] == "enp0s31f6"

# Generated at 2022-06-23 00:11:07.671183
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule({})
    ln = LinuxNetwork(module)

# Generated at 2022-06-23 00:11:18.291920
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    '''
    Unit test for method get_interfaces_info of class LinuxNetwork
    '''
    module = FakeAnsibleModule()
    # test 1
    # module.params = {}
    # state = 'absent'
    # ln = LinuxNetwork(module, state)
    # interfaces, ips = ln.get_interfaces_info("/bin/ip")

    # test 2
    module.params = {}
    state = 'absent'
    ln = LinuxNetwork(module, state)
    interfaces, ips = ln.get_interfaces_info("/bin/ip")
    assert(interfaces is not None)



# Generated at 2022-06-23 00:11:28.216714
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    # constructor doesn't need any options for now
    linux_network = LinuxNetwork({})
    # test results of get_interfaces_info against known values
    (interfaces, ips) = linux_network.get_interfaces_info(None, {'address': '192.168.1.15'}, {'address': 'fe80::1'})
    assert 'lo' in interfaces
    assert 'eth0' in interfaces
    assert interfaces['lo']['type'] == 'loopback'
    assert interfaces['lo']['ipv4']['address'] == '127.0.0.1'
    assert interfaces['eth0']['type'] == 'ether'
    assert interfaces['eth0']['ipv4']['address'] == '192.168.1.15'

# Generated at 2022-06-23 00:11:41.559266
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    l = LinuxNetwork()
    name_to_test = 'eth0'
    ip_to_test = '10.0.0.1'

    l.interfaces = magic_mock()
    l.interfaces.update.return_value = None

    l.ips = magic_mock()
    l.ips.update.return_value = None

    l.default_interface = magic_mock()
    l.default_interface.name = name_to_test

    l.default_ip = magic_mock()
    l.default_ip.get.return_value = ip_to_test

    l.sysctl.return_value = None

    # Call the method
    l.populate()

    # Check if there is any call to the methods
    l.sysctl.assert_called_once()

# Generated at 2022-06-23 00:11:43.889149
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    import ansible.constants
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, "", ""))
    collector = LinuxNetworkCollector(module=module, params={})
    assert collector.get_platform() == 'Linux'
    assert collector.get_required_facts() == {'distribution', 'platform'}


# Generated at 2022-06-23 00:11:54.567105
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule()
    module.params = dict()
    n = LinuxNetwork(module)
    default_ipv4, default_ipv6 = n.get_default_interfaces()
    interfaces, ips = n.get_interfaces_info(None, default_ipv4, default_ipv6)

    assert 'lo' in interfaces
    assert 'eth0' in interfaces
    assert 'br0' in interfaces
    assert 'bond0' in interfaces
    assert 'bond0' in interfaces['eth0']['slaves']
    assert 'bond0' in interfaces['eth1']['slaves']
    assert 'eth0' in interfaces['bond0']['slaves']
    assert 'eth1' in interfaces['bond0']['slaves']

# Generated at 2022-06-23 00:12:05.375699
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    ln = AnsibleNetworkModule()
    net = LinuxNetwork(ln)
    assert net.module is ln
    assert net.default_ipv4 is None
    assert net.default_ipv6 is None
    assert net.interfaces is None
    assert net.ips is None
    assert net.routes is None
    assert net.gateway_interface is None
    assert net.gateway_interface_ipv6 is None
    assert net.gateway_interface_ipv4 is None
    assert net.virtual_router_id == 0



# Generated at 2022-06-23 00:12:18.084384
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # No hostname, one interface, test IPv4 and IPv6
    network = LinuxNetwork(module)
    network.default_ipv4 = {
        'address': '127.0.0.1',
        'broadcast': '127.255.255.255',
        'macaddress': '00:00:00:00:00:00',
        'netmask': '255.0.0.0',
        'network': '127.0.0.0',
    }
    network.default_ipv6 = {
        'address': '::1',
        'macaddress': '00:00:00:00:00:00',
        'prefix': '128',
        'scope': 'host',
    }
    # FIXME: add more interfaces ips and bond
    # FIXME: add a bond

# Generated at 2022-06-23 00:12:30.345874
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    test_module = DummyModule()
    test_module.run_command = Mock(return_value=(0, '', ''))

    instance = LinuxNetwork(test_module)
    instance.get_interfaces_info = Mock(return_value=([], {}))
    instance.get_default_interfaces = Mock(return_value=([], []))

    instance.populate()

    # Assert that get_interfaces_info() and get_default_interfaces() was called
    instance.get_interfaces_info.assert_called_with([], [], [])
    instance.get_default_interfaces.assert_called_with([], [], [])

    assert instance.interfaces == []
    assert instance.all_ipv4_addresses == []
    assert instance.all_ipv6_addresses == []
   

# Generated at 2022-06-23 00:12:42.640327
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    test_class = LinuxNetwork
    test_instance = test_class()

    # get non-public interface and set the returned macaddress
    dummy_interfaces_info = {"dummy0": {"device": "dummy0", "macaddress": "52:54:00:12:34:56"},
                             "dummy1": {"device": "dummy1", "macaddress": "52:54:00:12:34:57"},
                             "dummy2": {"device": "dummy2", "macaddress": "52:54:00:12:34:58"}}

# Generated at 2022-06-23 00:12:51.923682
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from units.mock.exec_command import MockExecCommand


# Generated at 2022-06-23 00:13:04.215251
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Test data provided below and in the test_facts.yml file.

    # data with only some ethtool keys, ie no eth0 and no eth2
    interfaces = {
        'eth1': {},
    }
    # eth0 only has some features (not all)
    interfaces_data = {
        'eth0': {
            'features': {
                'tx': 'on',
                'sg': 'on',
                'tso': 'off',
            },
        },
        'eth1': {
            'features': {
                'tx': 'on',
                'sg': 'on',
                'tso': 'off',
            },
        }
    }

# Generated at 2022-06-23 00:13:15.251827
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    '''Unit test for LinuxNetwork'''
    module = AnsibleModule({})
    module.exit_json = exit_json
    module.fail_json = fail_json

    # instantiate class in the most vanilla way possible
    ln = LinuxNetwork(module)

    # check for the expected Linux distro
    assert ln.distribution == 'Debian'

    # check for the expected distribution release
    assert ln.distribution_version == '7'

    # ln.default_ipv4 must contain a dict
    # ln.default_ipv6 must contain a dict
    assert isinstance(ln.default_ipv4, dict)
    assert isinstance(ln.default_ipv6, dict)

# Generated at 2022-06-23 00:13:17.785261
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    assert network is not None


# Generated at 2022-06-23 00:13:23.031529
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    network_collector = LinuxNetworkCollector(None)
    assert network_collector._platform == 'Linux'
    assert network_collector.required_facts == {'distribution', 'platform'}
    assert network_collector._fact_class == LinuxNetwork


# Generated at 2022-06-23 00:13:35.310987
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    n = LinuxNetwork()
    result = {}
    n.populate(result)
    assert isinstance(result, dict)
    assert result['interfaces']
    assert isinstance(result['interfaces'], dict)
    assert result['default_ipv4']
    assert isinstance(result['default_ipv4'], dict)
    assert result['default_ipv6']
    assert isinstance(result['default_ipv6'], dict)
    assert result['ips']
    assert isinstance(result['ips'], dict)
    assert result['all_ipv4_addresses']
    assert isinstance(result['all_ipv4_addresses'], list)
    assert result['all_ipv6_addresses']
    assert isinstance(result['all_ipv6_addresses'], list)



# Generated at 2022-06-23 00:13:47.053349
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    """Unit test for LinuxNetwork"""
    os_name = "Linux"
    os_release = "2.6.32-504.el6.x86_64"
    os_version = "2.6.32-504.el6.x86_64"

    obj = AnsibleModuleDummy()

    ln = LinuxNetwork(obj)
    ln.os_name = os_name
    ln.os_release = os_release
    ln.os_version = os_version

    # test for constructor
    assert ln
    # test for os_name
    assert ln.os_name == os_name
    # test for os_release
    assert ln.os_release == os_release
    # test for os_version
    assert ln.os_version == os_version


# Generated at 2022-06-23 00:13:54.572540
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    ansible = mock.Mock()
    ansible.get_bin_path = mock.Mock(return_value="/bin/path")
    lnc = LinuxNetworkCollector(ansible)
    assert 'platform' in lnc.required_facts
    assert 'distribution' in lnc.required_facts
    assert lnc.module is ansible
    assert lnc.facts is None
    assert lnc.warnings is None
    assert lnc.command is None



# Generated at 2022-06-23 00:14:04.086285
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    moduleTest = AnsibleModule(argument_spec={})
    networkTest = LinuxNetwork(moduleTest)
    output = []

    def get_file_content(file):
        if file == "/sys/class/net/lo/address":
            return "00:00:00:00:00:00"
        elif file == "/sys/class/net/lo/bridge":
            return "00:00:00:00:00:00"
        elif file == "/sys/class/net/lo/bonding":
            return "00:00:00:00:00:00"
        elif file == "/sys/class/net/lo/mtu":
            return "1500"
        elif file == "/sys/class/net/lo/type":
            return "1"

# Generated at 2022-06-23 00:14:15.488780
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    ######################
    # the variables below are mocks of the data that
    # would normally be on the system
    ######################

    default_ipv4 = {'address': ''}
    default_ipv6 = {'address': ''}
    ip_path = '/bin/true'

# Generated at 2022-06-23 00:14:22.020367
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # instantiate the class
    obj = LinuxNetwork()
    # FIXME: this fails because get_interfaces_info() needs to be mocked, but that's pretty complex
    # because it uses /sys, /proc, net-tools, and likely iproute2
    obj.populate()
    # FIXME: verify output in some way?
    return True


# Generated at 2022-06-23 00:14:34.801109
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    # Test case 1: localhost with net_tools, iproute2, and timestamping support
    # (ubuntu 16.04, rhel 7, ...)
    # Test from Fedora 17, localhost

    fake_module = get_fake_module()

    fake_module.set_fs_attr(path=fake_module.get_bin_path("ifconfig"),
                            attrs={"ifconfig": True})
    fake_module.set_fs_attr(path=fake_module.get_bin_path("ip"),
                            attrs={"ip": True, "ip-netns": True})
    fake_module.set_fs_attr(path=fake_module.get_bin_path("ethtool"),
                            attrs={"ethtool": True})

# Generated at 2022-06-23 00:14:47.732549
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Test case #1
    # Test case data
    LinuxNetwork.get_interface_defs = MagicMock(return_value = {'eth0': {'default': True},
                                                                 'eth1': {'default': True},
                                                                 'eth1:1': {'default': False}})

    # Expected result
    expected_result = {'eth0': {'default': True},
                       'eth1': {'default': True}}

    # Perform the test
    result = LinuxNetwork.get_default_interfaces(None)

    # Verify the results
    assert (result == expected_result)

    # Test case #2
    # Test case data

# Generated at 2022-06-23 00:14:59.690379
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    myclass = LinuxNetwork()
    myclass._module = FakeModule()
    myclass._module.get_bin_path = MagicMock(return_value='/bin/ethtool')

# Generated at 2022-06-23 00:15:10.982487
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    network = LinuxNetwork()
    network.module = FakeAnsibleModule()
    network.module.run_command = MagicMock(return_value=(0, "fake_stdout", "fake_stderr"))
    network.get_interfaces_info = MagicMock(return_value=('fake_interfaces', 'fake_ips'))
    network.get_default_gateway = MagicMock(return_value=('fake_gateways'))

    network.populate()

    # Check that facts have been set
    network.module.exit_json.assert_called_once()
    assert network.module.exit_json.call_args[0][0]['ansible_facts']['ansible_interfaces'] == 'fake_interfaces'

# Generated at 2022-06-23 00:15:22.862681
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    fake_socket = FakeAnsibleModule()
    fake_ansible_module = FakeAnsibleModule()
    mock_fail_json = MagicMock()
    mock_fail_json.side_effect = fake_ansible_module.fail_json
    mock_get_bin_path = MagicMock(return_value="ip_path")
    mock_get_file_content = MagicMock(return_value="")
    mock_run_command = MagicMock(return_value=(0, "", ""))
    import tempfile
    temp_file = tempfile.NamedTemporaryFile()
    mock_write_file = MagicMock(return_value=temp_file)
    mock_get_network_interface_addresses = MagicMock(return_value=({}, {}))

# Generated at 2022-06-23 00:15:28.618208
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = MagicMock()
    module.params.get.return_value = None
    c = LinuxNetworkCollector(module)
    assert c.platform == "Linux"
    assert c.required_facts == {"distribution", "platform"}
    assert type(c.facts) == LinuxNetwork


# Generated at 2022-06-23 00:15:31.584567
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    assert LinuxNetworkCollector(module)._platform == 'Linux'


# Generated at 2022-06-23 00:15:41.843930
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    """ Unit test for class LinuxNetwork """
    spec_file = 'tests/modules/linux_network.json'
    with open(spec_file) as f:
        spec = json.load(f)

    # Fake module class
    class FakeModule:
        def __init__(self):
            self.params = {}
        def get_bin_path(self, arg):
            return '/bin/test_' + arg

    # Fake class for module.run_command and module.run_command()
    class TestRunCommand:
        def __init__(self):
            self.rc = 0
            self.stdout = ''
            self.stderr = ''


# Generated at 2022-06-23 00:15:55.012787
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    distro = "RedHat"
    platform = "Linux"
    class args:
        connection='local'
        gather_subset='!all'
        gather_timeout=10
        filter=''
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    set_module_args(module.params)
    linux_network = LinuxNetworkCollector(module=module)
    assert linux_network._fact_class.required_facts == {'distribution', 'platform'}
    assert linux_network._platform == 'Linux'
    assert isinstance(linux_network._fact_class(module=module), LinuxNetwork)
    # Distro is not RedHat, Fedora, CentOS, which is a Linux platform

# Generated at 2022-06-23 00:16:06.813909
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    """Unit test for method get_default_interfaces"""
    with patch('ansible.module_utils.network.common.network.LinuxNetwork.get_default_interfaces') as mock_get_default_interfaces:
        mock_get_default_interfaces.return_value = {'v4': {'address': '10.0.2.15',
                                                           'gateway': '10.0.2.2',
                                                           'interface': 'eth0'},
                                                    'v6': {'address': 'fe80::a00:27ff:fe0d:a5c0',
                                                           'gateway': 'fe80::a00:27ff:fe0d:a5c1',
                                                           'interface': 'eth0'}}
    assert LinuxNetwork().get_default_interfaces

# Generated at 2022-06-23 00:16:14.970435
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    my_linux_network = LinuxNetwork()
    import os
    import glob
    import socket
    import struct
    import re

    my_linux_network.module.run_command = mock.Mock(return_value = (0, "", ""))
    my_linux_network.get_default_interfaces = mock.Mock(return_value = ("", ""))
    my_linux_network.get_interfaces_info = mock.Mock(return_value = ( {}, { } ))

    my_linux_network.module.HAVE_DBUS = True
    my_linux_network.module.dbus = mock.MagicMock()
    my_linux_network.module.dbus.Interface = mock.Mock(return_value = "1")

# Generated at 2022-06-23 00:16:26.597413
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    # parameters for this test only
    test_parameters = {
            'gather_subset': ['!all', '!min'],
    }
    # create a Network instance
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    linux_network = LinuxNetwork(module)
    # do we have a network_info attribute?
    assert hasattr(linux_network, 'network_info')
    # did we get what we expect?
    name = 'network_info'
    # expected= dict(changed=False, failed=False, pingable=None)
    expected = dict(changed=False)
    actual = linux_network.network_info
    assert actual == expected, "actual: %s, expected: %s" % (actual, expected)
    # did we get what we expect?
   