

# Generated at 2022-06-23 00:06:26.260855
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    assert ln.get_interfaces_info()



# Generated at 2022-06-23 00:06:31.489837
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # inputs
    module = None
    # object instantion
    collector = LinuxNetworkCollector(module)
    # tests
    assert collector._platform == 'Linux'
    assert collector._fact_class == LinuxNetwork
    assert collector.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-23 00:06:41.479612
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    LN = LinuxNetwork()
    for test in ("ethtool --help > /dev/null", "ethtool -k > /dev/null", "ethtool -T > /dev/null"):
        path = LN.module.get_bin_path("ethtool")
        if not path:
            continue
        LN.module.run_command(test)

# Generated at 2022-06-23 00:06:48.616763
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    load_params = dict()
    load_params['load_from_system'] = True
    load_params['load_from_files'] = False
    load_params['load_from_backup'] = False
    module = AnsibleModule(argument_spec={}, supports_check_mode=True,
                           bypass_checks=False)

    linux_network = LinuxNetwork(module)
    linux_network.load_all()

    facts = linux_network.get_facts()
    for key in facts:
        assert(facts[key] is not None)



# Generated at 2022-06-23 00:06:54.340845
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec=dict())
    collector = LinuxNetworkCollector(module)
    assert collector.platform == 'Linux'
    assert collector.network_class == LinuxNetwork
    assert collector.required_facts == set(['distribution', 'platform'])



# Generated at 2022-06-23 00:07:00.468267
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # NOTE: this goes through a lot of trouble for one little test
    # but it does help to see a lot of the interfaces
    module = AnsibleModule(argument_spec={})
    new_interfaces, ips = LinuxNetwork(module).populate()
    return module.exit_json(
        changed=False,
        interfaces=new_interfaces,
        ips=ips,
    )



# Generated at 2022-06-23 00:07:13.758968
# Unit test for method get_default_interfaces of class LinuxNetwork

# Generated at 2022-06-23 00:07:14.963850
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    assert ln, "ln is not defined"


# Generated at 2022-06-23 00:07:23.345903
# Unit test for method populate of class LinuxNetwork

# Generated at 2022-06-23 00:07:36.130967
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Test case args template
    args = dict(
        device='eth0',
    )

    # Mock get_bin_path to return ethtool command
    with mock.patch(MODULE_PATH + '.LinuxNetwork.get_bin_path') as get_bin_path:
        get_bin_path.return_value = "/usr/bin/ethtool"

        # Mock run_command to return valid data

# Generated at 2022-06-23 00:07:41.444075
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModuleMock()
    collector = LinuxNetworkCollector(module)
    # _fact_class is LinuxNetwork
    assert collector._fact_class is LinuxNetwork
    # required_facts = set(['distribution', 'platform'])
    assert collector.required_facts == set(['distribution', 'platform'])

# Generated at 2022-06-23 00:07:51.454557
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    from ansible.module_utils.six import StringIO
    from ansible.module_utils._text import to_bytes

    # NOTE: natively-built modules call platform.system() in module_utils.basic.py
    #       so we have to fake it
    def mock_system(self):
        return 'Linux'

    # NOTE: we don't use
    #       - platform.machine() to return x86_64 or armv6l
    #       - distro.id() to return centos, debian, etc
    #       - distro.version() to return e.g. 7.0
    #       - distro.major_version() to return e.g. 7
    #       - distro.version_parts() to return [7, 0, 0]
    #       - distro.like() to return centos, rhel

# Generated at 2022-06-23 00:07:59.918374
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # we need a little fake module to avoid running commands
    module = AnsibleModule(argument_spec={
        'gather_subset': {'required': True, 'type': 'list'}
    })

    # a I

# Generated at 2022-06-23 00:08:12.990056
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():

    test_device = "foo0"
    test_features = ("""
    Checksum Offload: on
    GSO: on
    Generic Segmentation Offload: on
    Generic Receive Offload: on
    TSO: on
    Tx checksumming: on
    UDP Fragmentation Offload: on
    UDP GSO: on
    Large Receive Offload: on
    Receive checksumming: on
    Timestamps: off
    Large Receive Offload: off
    """)

# Generated at 2022-06-23 00:08:15.111012
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    device = 'lo'
    data = network.get_ethtool_data(device)
    for k, v in data.items():
        assert isinstance(k, str) and isinstance(v, dict)

# Generated at 2022-06-23 00:08:19.306496
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = MagicMock()

# Generated at 2022-06-23 00:08:31.459371
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    a = LinuxNetwork(module)
    assert a.get_default_interfaces() == {'default_ipv4': {'gateway': '172.16.1.1'}, 'default_ipv6': {'gateway': 'fe80::1'}}
    # fall back to get_interfaces_info()
    a.get_interfaces_info = lambda x, y, z: ('interfaces', 'ips')
    assert a.ipv4_addresses == 'ips'
    assert a.ipv6_addresses == 'ips'
    assert a.get_interfaces() == 'interfaces'


# Generated at 2022-06-23 00:08:41.239394
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils import basic

    module = basic.AnsibleModule('')

    class DummyLinuxNetwork(LinuxNetwork):
        def get_default_interfaces(self):
            return {'v4': {}, 'v6': {}}

        @staticmethod
        def interfaces(self):
            return self.interfaces

        @staticmethod
        def get_bin_path(self):
            return self.ip_path

    def get_file_content(path, default=None):
        return default

    linux_network = DummyLinuxNetwork(module)
    linux_network.get_file_content = get_file_content
    linux_network.init_network_info(None, None)
    interfaces = linux_network.get_interfaces()

    assert interfaces
    assert isinstance(interfaces, dict)


# Generated at 2022-06-23 00:08:50.197701
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    net = LinuxNetwork()

    # Given a valid IPv4 address and subnet,
    ipv4_address = '192.0.2.1'
    ipv4_subnet = '192.0.2.0/24'

    # When looking for the default IPv4 gateway,
    ipv4_gateway = net.get_default_gateway_interface(ipv4_address, ipv4_subnet)[1]

    # Then it should be a valid IPv4 address
    assert ipv4_gateway
    ipaddress.IPv4Address(ipv4_gateway)

    # Given a valid IPv6 address and subnet,
    ipv6_address = '2001:db8::1'
    ipv6_subnet = '2001:db8::/64'

    # When looking for the default IPv4 gateway

# Generated at 2022-06-23 00:09:01.114305
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    linux_network = LinuxNetwork(module)
    ip_path = linux_network.module.get_bin_path("ip")
    default_ipv4 = dict(
        address=''
    )
    default_ipv6 = dict(
        address=''
    )
    interfaces, ips = linux_network.get_interfaces_info(ip_path, default_ipv4, default_ipv6)
    assert len(interfaces) > 0
    assert len(ips['all_ipv4_addresses']) > 0
    assert len(ips['all_ipv6_addresses']) > 0



# Generated at 2022-06-23 00:09:07.093569
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    """Unit test for constructor of class LinuxNetwork"""
    module = AnsibleModule({})
    linux_network = LinuxNetwork(module)
    network_info = linux_network.get_network_info()
    assert _assert_network_info(network_info)


# Generated at 2022-06-23 00:09:12.540415
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    default_interface_set = [
        'default via 192.0.2.1 dev eth1 proto static metric 100',
        'default dev eth0 proto static scope link metric 100 ',
        'default via 192.0.2.1 dev eth1 proto static metric 100',
        'default dev eth0 proto static scope link metric 100',
        'default via 2001:db8:2::1 dev eth0 proto static metric 1024',
        'default dev eth0 proto static scope link metric 100',
        'default via 2001:db8:2::1 dev eth0 proto static metric 1024',
        'default dev eth0 proto static scope link metric 100',
        'default via 192.0.2.1 dev eth0 proto static metric 100',
        'default via 192.0.2.1 dev eth0 proto static metric 100',
    ]

# Generated at 2022-06-23 00:09:14.754917
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    ln = LinuxNetwork()

    ln.get_interfaces_info()

# ===========================================
# Main control flow


# Generated at 2022-06-23 00:09:16.299450
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    ln = LinuxNetwork()
    ln_data = ln.get_ethtool_data(device)


# Generated at 2022-06-23 00:09:19.971738
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from ansible.module_utils.facts.collector import CollectorConfiguration
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.network.linux import LinuxNetworkCollector
    CollectorConfiguration.init({})
    BaseFactCollector.init(CollectorConfiguration())
    LinuxNetworkCollector.init(CollectorConfiguration())
    assert BaseFactCollector.cache == CollectorConfiguration().cache
    assert 'Linux' == LinuxNetworkCollector._platform
    assert LinuxNetworkCollector._fact_class
    assert LinuxNetworkCollector.required_facts == {'distribution', 'platform'}
    assert LinuxNetworkCollector.optional_facts == set()



# Generated at 2022-06-23 00:09:25.175281
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    my_net = LinuxNetwork()
    ipv4_addr, ipv6_addr = my_net.get_default_interfaces()
    if ipv4_addr:
        assert ipv4_addr['default']
    if ipv6_addr:
        assert ipv6_addr['default']


# Generated at 2022-06-23 00:09:37.735242
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(
        argument_spec = dict(
            device = dict(default='eth0'),
        ),
        supports_check_mode = True
    )

    network = LinuxNetwork(module)
    device = module.params['device']

    ethtool_path = module.get_bin_path("ethtool")
    if not ethtool_path:
        module.fail_json(msg='Failed to find ethtool command.')

    rslt = network.get_ethtool_data(device)

    # Test the main feature in the result object
    if 'features' not in rslt:
        module.fail_json(msg='Failed to get ethtool features data')

    # Test that the features object contains a populated 'rx' object
    rx = rslt['features']['rx']

    # The first key/

# Generated at 2022-06-23 00:09:45.070109
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = DummyModule()
    network_info_obj = LinuxNetwork(module)
    # Example of input data
    device = "eth0"

# Generated at 2022-06-23 00:09:46.926690
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    network = LinuxNetwork()


if __name__ == '__main__':
    test_LinuxNetwork()

# Generated at 2022-06-23 00:09:55.000213
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    def get_file_content(path, default=''):
        if path == 'gibberish':
            return default
        elif path == 'localhost' or path == '127.0.0.1':
            return '127.0.0.1/8'
        elif path == '::1':
            return '::1/128'
        elif path == '127.0.0.1/8':
            return '127.0.0.1 dev lo  proto kernel  scope host  src 127.0.0.1'
        elif path == '::1/128':
            return '::1 dev lo  proto kernel  scope host  src ::1'
        elif path.endswith('/operstate'):
            return 'down'
        return default


# Generated at 2022-06-23 00:10:07.584000
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(type='list', default=['all']),
    }, supports_check_mode=True)

    ln = LinuxNetwork(module)

    def find_item(items, attr, value):
        for item in items:
            if item[attr] == value:
                return item
    # run the module
    ln.populate()
    # parse the result and test the first item's secondaries
    ipv4_all_addresses = [i for i in ln.distribution.all_ipv4_addresses if i.startswith('192.')]

# Generated at 2022-06-23 00:10:20.150472
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    import pytest
    from ansible.module_utils._text import to_text
    from ansible.module_utils import basic
    from ansible.modules.system.network import ethtool_data

    cmd = 'ethtool -k eth0'
    rc = 0

# Generated at 2022-06-23 00:10:32.426594
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # input arguments for the module
    module_args = {
        'gather_subset': 'all',
        'gather_network_resources': 'yes',
    }
    # result from the module execution

# Generated at 2022-06-23 00:10:35.713481
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModuleMock()
    factstore_mock = FactStore(module)
    collector = LinuxNetworkCollector(module, factstore_mock)
    assert collector.module == module
    assert collector.platform == 'Linux'
    assert collector.fact_class == collector._fact_class
    assert collector.fact_class == LinuxNetwork
    assert collector.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-23 00:10:42.082424
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    ethtool_path = module.get_bin_path("ethtool")

    if not ethtool_path:
        module.fail_json(msg="ethtool path not found, skipping ethtool test")

    # XXX: pytest cannot mock module.run_command
    class MockLinuxNetwork():
        def __init__(self, module):
            self.module = module
    linux_network = MockLinuxNetwork(module)


# Generated at 2022-06-23 00:10:53.013976
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # myhost facts
    # - platform: Linux
    #   distribution: {'name': 'CentOS', 'version': '7.2.1511', 'major_version': '7'}
    linux_network_collector = LinuxNetworkCollector(None, 'myhost', None)
    assert linux_network_collector.platform == 'Linux'
    assert linux_network_collector.distribution['name'] == 'CentOS'

    # myhost facts
    # - platform: Linux
    #   distribution: {'name': 'Ubuntu', 'version': '16.04', 'major_version': '16'}
    linux_network_collector = LinuxNetworkCollector(None, 'myhost', None)
    assert linux_network_collector.platform == 'Linux'
    assert linux_network_collector.distribution['name']

# Generated at 2022-06-23 00:11:03.633513
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={
        'running_config': {'type': 'bool', 'default': False}
    })

    network = LinuxNetwork(module)
    network.construct()

    assert network.get_data() == module.params['running_config']
    assert network.get_interfaces() == module.params['interfaces']
    assert network.get_default_ipv4() == module.params['default_ipv4']
    assert network.get_default_ipv6() == module.params['default_ipv6']
    assert network.get_ips() == module.params['ips']
    assert network.get_ip_path() == module.params['ip_path']



# Generated at 2022-06-23 00:11:15.590048
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-23 00:11:25.829144
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    mock_module = MagicMock()
    mock_module.get_bin_path.return_value = "/bin/ls"
    mock_module.run_command.return_value = (0, '01:00.0', '')
    n = LinuxNetwork(mock_module)

    ret = n.get_default_interfaces()
    assert ret == {'default_ipv4': {'interface': '01:00.0'}, 'default_ipv6': {'interface': '01:00.0'}}

    # should be a cached result, no second run_command call
    ret = n.get_default_interfaces()
    mock_module.run_command.assert_called_once()



# Generated at 2022-06-23 00:11:26.409621
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    LinuxNetworkCollector()


# Generated at 2022-06-23 00:11:39.175968
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command = Mock(return_value = (0, '', None))
            self.get_bin_path = Mock(side_effect=lambda x: x)
            self.fail_json = Mock()

    class MockAddr(object):
        def __init__(self):
            self.family = 2
            self.address = '127.0.0.1'
            self.broadcast = None
            self.netmask = '255.0.0.0'
            self.destination = None
            self.scope = 'Loopback'

    class MockIf(object):
        def __init__(self):
            self.families = {}
            self.if_flags = 0

# Generated at 2022-06-23 00:11:39.918787
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    col = LinuxNetworkCollector()
    assert col


# Generated at 2022-06-23 00:11:41.992077
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    ln = LinuxNetwork()
    ln.get_default_interfaces()



# Generated at 2022-06-23 00:11:53.124072
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    m = AnsibleModule(argument_spec={})

# Generated at 2022-06-23 00:12:07.027277
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # NOTE: This test requires a functional network configuration
    network = LinuxNetwork()
    network.populate()
    # check all IPv4 addresses
    assert 'all_ipv4_addresses' in network.ips, 'network.ips["all_ipv4_addresses"] not populated'
    assert isinstance(network.ips['all_ipv4_addresses'], list), 'network.ips["all_ipv4_addresses"] is not a list'
    assert network.ips['all_ipv4_addresses'], 'network.ips["all_ipv4_addresses"] is empty'
    assert network.default_ipv4['address'] in network.ips['all_ipv4_addresses'], 'network.default_ipv4["address"] not in network.ips["all_ipv4_addresses"]'


# Generated at 2022-06-23 00:12:12.926724
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    device = 'lo'
    data = network.get_ethtool_data(device)
    # Test that phc_index is present, since the test system has an available phc
    assert 'phc_index' in data.keys()


# Generated at 2022-06-23 00:12:24.898855
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = None
    network = LinuxNetwork(module)
    network.module = None
    interfaces = {'eth0': {'macaddress': '00:00:00:00:00:01'}, 'lo': {}}
    ips = {'all_ipv4_addresses': [], 'all_ipv6_addresses': []}
    ipv4, ipv6 = network.populate(interfaces, ips, netifaces.AF_INET, '127.0.0.1')
    assert ipv4['macaddress'] == '00:00:00:00:00:01'
    assert ipv4['address'] == '127.0.0.1'
    assert ipv4['alias'] == 'lo'
    assert ipv6['address'] == '::1'

# Generated at 2022-06-23 00:12:29.497880
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    ln = LinuxNetworkCollector()
    assert ln.platform == 'Linux'
    assert ln.required_facts == set(['distribution', 'platform'])
    assert ln.fact_class == LinuxNetwork


# Generated at 2022-06-23 00:12:41.558455
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    """
    Unit test of populate method of class LinuxNetwork
    """
    # Parameters
    # networks (dict) - current networks information
    # default_ipv4, default_ipv6 (dict) - current default ipv4 and ipv6 interfaces

    # Return a dictionary of information about all the interfaces present on the system
    # Return Dict
    # keys:
    #   'all_ipv4_addresses':   (list) all ipv4 addresses
    #   'all_ipv6_addresses':   (list) all ipv6 addresses
    #   'default_ipv4':         (dict) default ipv4 information generated by get_default_interfaces
    #   'default_ipv6':         (dict) default ipv6 information generated by get_default_interfaces
    #   'interfaces':           (dict

# Generated at 2022-06-23 00:12:51.503470
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    ln = LinuxNetwork()
    ln.module = Mock()
    ln.module.run_command = Mock(return_value=(0, '', ''))
    ln.module.get_bin_path = Mock(return_value='')
    assert ln.get_ethtool_data('') == {}

    ln.module.get_bin_path.return_value='ethtool'
    ln.module.run_command.return_value=(0, '', 'ethtool: unrecognized option')
    assert ln.get_ethtool_data('') == {}

    ln.module.run_command.return_value=(0, '', 'Ethtool output')
    assert ln.get_ethtool_data('') == {}


# Generated at 2022-06-23 00:13:03.959982
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = module_utils.basic.AnsibleModule(
        argument_spec={}
    )
    mock_run_command = MagicMock()
    module.run_command = mock_run_command

    mock_get_bin_path = MagicMock()
    module.get_bin_path = mock_get_bin_path

    mock_get_file_content = MagicMock()
    module.get_file_content = mock_get_file_content

    # Mock get_bin_path(ethtool)
    # 1
    mock_get_bin_path.side_effect = ['/usr/sbin/ethtool']

    # Mock run_command(ethtool)
    # 1

# Generated at 2022-06-23 00:13:16.091611
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.test_utils.mock import Mock, patch


# Generated at 2022-06-23 00:13:28.783429
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():

    default_ipv4 = dict(address='127.0.0.1')
    default_ipv6 = dict(address='::1')

    net = LinuxNetwork()

    assert net.get_default_interface() == DEFAULT_INTERFACE
    assert net.get_default_interface(default='dummy') == 'dummy'

    assert net.get_network_module() == 'auto'
    assert net.get_network_module(network_os='dummy') == 'dummy'
    assert net.get_network_module(network_os='dummy', vars={'ansible_network_os': 'dummy2'}) == 'dummy2'
    assert net.get_network_module(vars={'ansible_network_os': 'dummy2'}) == 'dummy2'

    assert net.get_

# Generated at 2022-06-23 00:13:40.997429
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    # Test with v4 & v6, single interface, no gateway
    rc, out, err = module.run_command('echo "1: lo: <LOOPBACK,UP,LOWER_UP> mtu 65536 qdisc noqueue state UNKNOWN group default qlen 1000" && echo "    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00" && echo "    inet 127.0.0.1/8 scope host lo" && echo "       valid_lft forever preferred_lft forever" && echo "    inet6 ::1/128 scope host" && echo "       valid_lft forever preferred_lft forever"')
    assert rc == 0
    ln = LinuxNetwork(module)

# Generated at 2022-06-23 00:13:51.006081
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = get_module()
    result = LinuxNetwork(module).get_ethtool_data('ens160')

    assert 'features' in result

# Generated at 2022-06-23 00:14:02.321896
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)

# Generated at 2022-06-23 00:14:05.473333
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    my_obj = LinuxNetworkCollector()
    assert my_obj.platform == 'Linux'
    assert my_obj.fact_class == LinuxNetwork


# Generated at 2022-06-23 00:14:16.258610
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    mock_module = MagicMock(params={})
    ln = LinuxNetwork(mock_module)

# Generated at 2022-06-23 00:14:21.152676
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # the first interface should be eth0
    assert LinuxNetwork().get_default_interfaces()[0].startswith('eth')
    # or can be wlan0
    assert LinuxNetwork().get_default_interfaces()[0].startswith('wlan')



# Generated at 2022-06-23 00:14:33.318916
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    
    # Import dependencies (mock and test)
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat import mock

    # Configure arguments for LinuxNetwork.populate
    module = mock.Mock()
    module.get_bin_path = mock.Mock(return_value=True)
    module.run_command = mock.Mock(return_value=[0, '', ''])

    # Configure return variables for get_interfaces_info
    interfaces = {}

# Generated at 2022-06-23 00:14:46.234472
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    runner = AnsibleTaskRunner(
        parallel_ports=['22'],
        # diff=False,
        # diff_peek=False,
    )

    # Put your platform here
    # hostname = get_platform()

    module_args = {
        'config': dict(),
        'running_config': dict(),
        'save_when': dict(modified=True, session=False),
        'diff_peek': False,
        '_ansible_check_mode': True,
        '_ansible_debug': True,
        '_ansible_verbosity': 1,
    }

    d = LinuxNetwork()
    d.module = runner.get_module_mock(**module_args)
    d.module._diff = False
    d.module.params = module_args
    d.populate()



# Generated at 2022-06-23 00:14:55.241880
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    """
    unit test for LinuxNetwork
    """
    ln = LinuxNetwork()
    try:
        interfaces, ips = ln.get_interfaces_info(ln.ip_path, ln.default_ipv4, ln.default_ipv6)
        assert interfaces != {}
        assert ips != {}
    except Exception as e:
        raise AssertionError("LinuxNetwork.get_interfaces_info() error: " + str(e))

if __name__ == '__main__':
    test_LinuxNetwork()

# Generated at 2022-06-23 00:15:07.544483
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    class MockModule(object):
        def __init__(self, params, bin_path=None):
            self.params = params
            self.bin_path = bin_path

        def get_bin_path(self, _):
            return self.bin_path

        def run_command(self, args, errors=None):
            print('Executing: %s %s' % (' '.join(args[0:2]), ' '.join(args[2:])))

# Generated at 2022-06-23 00:15:19.478473
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    fake_executable = "/bin/sh"
    module.get_bin_path = MagicMock()
    module.get_bin_path.return_value = fake_executable
    module.run_command = MagicMock()
    module.run_command.return_value = (0, "", "")
    linux_network = LinuxNetwork(module)
    # when no output from ip route show, empty dict is returned and no error is raised
    expected_result = {'default_ipv4': {}, 'default_ipv6': {}}
    assert linux_network.get_default_interfaces() == expected_result


# Generated at 2022-06-23 00:15:21.529427
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():

    # Setup class
    network = LinuxNetworkCollector()
    assert network.get_facts() is None

# Generated at 2022-06-23 00:15:26.862821
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    assert ln.ip_path == module.get_bin_path('ip')
    assert ln.route_path == module.get_bin_path('route')
    assert ln.get_interfaces_info


# Generated at 2022-06-23 00:15:39.113848
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    LN = LinuxNetwork()

    # mock the following file (order matters!)
    mock_files = [
        '/proc/net/route',
        '/proc/net/ipv6_route',
    ]

# Generated at 2022-06-23 00:15:41.647285
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    assert LinuxNetworkCollector.required_facts == set(['distribution', 'platform'])
    assert LinuxNetworkCollector._platform == 'Linux'
    assert LinuxNetworkCollector._fact_class == LinuxNetwork


# Generated at 2022-06-23 00:15:54.796504
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible.module_utils._text import to_bytes
    module = AnsibleModule(argument_spec=dict(
        gather_subset=dict(required=False, type='list', default=['!all']),
        gather_network_resources=dict(required=False, type='str', default='yes'),
    ), supports_check_mode=True)

# Generated at 2022-06-23 00:16:03.471513
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.network.common.utils import load_platform_subclass

    module = AnsibleModule(argument_spec={})
    parent = load_platform_subclass(LinuxNetwork, device='test_device')
    parent.module = module
    result = parent.get_ethtool_data('test_device')

    assert isinstance(result, dict)
    assert 'features' in result
    assert 'timestamping' in result
    assert 'hw_timestamp_filters' in result



# Generated at 2022-06-23 00:16:06.069443
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    l = LinuxNetwork(module)
    assert l is not None


# Generated at 2022-06-23 00:16:08.973897
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    p = module.params
    l = LinuxNetwork(module)
    assert l.module == module
    assert l.params == p



# Generated at 2022-06-23 00:16:16.243684
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    import tempfile
    import shutil
    import json

    class FakeModule(object):
        @staticmethod
        def get_bin_path(i, opt_dirs=[]):
            return "/bin/ethtool"


# Generated at 2022-06-23 00:16:27.264361
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils._text import to_text
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.network.common.utils import get_file_lines
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.facts.network.base import NetworkCollector
    # expected facts (text output)
    # interfaces:
    #     lo:
    #         active: True
    #         device: lo
    #         ipv4:
    #             address: 127.0.0.1
    #             broadcast:
    #             netmask: 255.0.0.0
    #             network: 127.0.0.0
    #         ipv