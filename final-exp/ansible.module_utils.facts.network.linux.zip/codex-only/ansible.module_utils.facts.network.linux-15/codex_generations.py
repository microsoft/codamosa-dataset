

# Generated at 2022-06-23 00:06:31.004923
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModuleMock()
    module.params = {}
    collector = LinuxNetworkCollector(module)
    assert isinstance(collector._fact, LinuxNetwork)
    assert collector._platform == 'Linux'
    assert collector.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-23 00:06:36.581939
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    v4, v6 = linux_network.get_default_interfaces()
    assert v4 is not None
    assert v6 is not None
    assert 'device' in v4
    assert not v4.get('address')
    assert 'device' in v6
    assert not v6.get('address')



# Generated at 2022-06-23 00:06:47.084685
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    network = LinuxNetwork(dict(module=None))
    # Check that the expected classes are returned

# Generated at 2022-06-23 00:06:54.960930
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # test LinuxNetwork get_ethtool_data() method

    # FIXME: requires actual data from ethtool. To test use ?:
    # if __name__ == "__main__":
    #     from ansible.module_utils.basic import *
    #     module = AnsibleModule({})
    #     ln = LinuxNetwork(module)
    #     print(ln.get_ethtool_data(device='eth0'))
    assert 0


# Generated at 2022-06-23 00:07:02.273540
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # FIXME: write unit test

    # NOTE: method with no args
    # FIXME: need get_interfaces_info signature to test?
    #
    # FIXME: method signature is from get_interfaces_info... has no args
    #
    # FIXME: use assert methods instead of print (if not return/exit)
    #
    # FIXME: need class instance for get_interfaces_info
    #
    # FIXME: need class instance in module_utils/facts/network/linux.py
    print('FIXME: write unit test')

# Generated at 2022-06-23 00:07:14.557773
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    class MockModule(object):
        def get_bin_path(self, *args, **kwargs):
            return "/some/path"

    global module
    module = MockModule()

    from ansible.module_utils import basic
    basic._ANSIBLE_ARGS = [i for i in sys.argv]

    def run_command(*args, **kwargs):
        class MockRC(object):
            def __init__(self, rc, out, err):
                self.rc = rc
                self.stdout = out
                self.stderr = err

        return MockRC(0, "", "")

    module.run_command = run_command

    ln = LinuxNetwork()
    ln.get_interfaces_info({}, {}, {})
    # TODO: add assertions

# Generated at 2022-06-23 00:07:18.806862
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch, MagicMock

    m = MagicMock()
    m.run_command.return_value = [0, 'default via 192.0.2.17 dev eth0', '']
    with patch.object(LinuxNetwork, 'run_command', return_value=m.run_command):
        assert LinuxNetwork.get_default_interfaces() == [{'default': 'eth0', 'gateway': '192.0.2.17'}]


# Generated at 2022-06-23 00:07:31.456044
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():

    class LinuxNetwork_MockModule(object):

        def get_bin_path(self, app):
            return app

        def run_command(self, args, errors='stderr'):
            if args[2] == '--list':
                # Return empty list if no default interface available
                return 0, '', None
            elif args[2] == '--version':
                return 0, 'ip utility, iproute2-ss130815', None

    class TestLinuxNetwork(unittest.TestCase):

        def setUp(self):
            self.mod = LinuxNetwork_MockModule()
            self.ln = LinuxNetwork(self.mod)

    ln_test = TestLinuxNetwork()
    ln_test.setUp()


# Generated at 2022-06-23 00:07:43.332249
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    class ModuleMock:
        def run_command(self, command, *args, **kwargs):
            return 0, '\n'.join(command), ''

    # The first part of LinuxNetwork.get_default_interfaces is
    # deterministic, but not all of it.
    net = LinuxNetwork(ModuleMock())
    default_ipv4, default_ipv6 = net.get_default_interfaces()
    assert default_ipv4.get('address') == '192.0.2.24'
    assert default_ipv4.get('broadcast') == '192.0.2.255'
    assert default_ipv4.get('netmask') == '255.255.255.0'
    assert default_ipv4.get('network') == '192.0.2.0'
    assert default

# Generated at 2022-06-23 00:07:45.736110
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    try:
        # This can't run in a unit test because it requires sudo
        l = LinuxNetwork()
    except Exception:
        pass



# Generated at 2022-06-23 00:07:46.832901
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    global module
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    assert LinuxNetwork(module)



# Generated at 2022-06-23 00:07:54.388049
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    ln = LinuxNetworkSystem()
    ln.module.run_command = Mock(return_value=(0, '', ''))
    ln.get_default_interfaces = Mock(return_value={'default_ipv4': {}, 'default_ipv6': {}})
    ln.get_interfaces_info = Mock(return_value=([], {}))
    ln.get_routes_info = Mock(return_value=([], {}, {}, {}))
    ln.get_interfaces_addresses = Mock(return_value=({}, {}))
    ln.populate()

    assert ln.all_interfaces == []
    assert ln.all_ipv4_addresses == []
    assert ln.all_ipv6_addresses == []
    assert ln.default

# Generated at 2022-06-23 00:08:01.682360
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():

    # Constructor for unit test of class LinuxNetworkCollector
    class ModuleMock(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, option):
            return option

        def run_command(self, args, errors=None):
            return 0, '', ''

        def fail_json(self, **kwargs):
            print(str(kwargs))

    class FactsMock(object):
        def __init__(self):
            self.distribution = LinuxDistribution()
            self.distribution.system = 'Linux'
            self.distribution.distribution = 'RedHatEnterpriseServer'
            self.distribution.major_version = '7'
            self.distribution.minor_version = '3'

# Generated at 2022-06-23 00:08:10.919133
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    """ Unit test for LinuxNetwork() constructor.
        Run python library/system/network.py

        prints module.fail_json on error
    """
    import sys
    module = AnsibleModule(
        argument_spec={},
    )
    netinfo = LinuxNetwork(module)
    if not isinstance(netinfo._interfaces, dict):
        module.fail_json(msg="test_LinuxNetwork() _interfaces is not a dict")
    else:
        module.exit_json(changed=False, _interfaces=netinfo._interfaces)


# Generated at 2022-06-23 00:08:11.841122
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
  pass

# Generated at 2022-06-23 00:08:15.084665
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(
        argument_spec=dict(),
    )
    result = dict(
        changed=False,
        ansible_facts=dict(
            ansible_net_gather_network_resources=dict(),
        )
    )
    lnc = LinuxNetworkCollector(module)
    lnc.collect()
    export = lnc.get_facts()
    result['ansible_facts']['ansible_net_gather_network_resources'] = export
    module.exit_json(**result)


# Generated at 2022-06-23 00:08:17.326311
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = FakeAnsibleModule()
    module.run_command = Mock(return_value=(0, '', ''))
    network = LinuxNetwork(module)
    network.get_ethtool_data('lo')



# Generated at 2022-06-23 00:08:29.926202
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['all'], type='list'),
            filter=dict(default=None),
        ),
        supports_check_mode=False,
    )
    obj = LinuxNetwork(module)
    output = obj.populate()

# Generated at 2022-06-23 00:08:40.460283
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Initialise the mock class
    ln = LinuxNetwork({})
    # Mock the method
    ln.get_interfaces_subnet = mock.MagicMock()
    ln.get_interfaces_subnet.return_value = {
        'ipv4': {
            'gateway': '192.168.122.1',
            'interface': 'vnet0',
            'address': '192.168.122.151',
             },
        'ipv6': {
            'gateway': 'fe80::2',
            'interface': 'vnet0',
            'address': 'fe80::a00:27ff:fe59:bef',
            }
    }


# Generated at 2022-06-23 00:08:49.645251
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    """
    Test LinuxNetwork.get_default_interfaces method
    """
    # FIXME: add better test coverage for
    # Unit tests for Linux Networking Facts class
    # This should probably be way more extensive
    # . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
    # Initialize class.
    # . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .

# Generated at 2022-06-23 00:09:00.244570
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    # normal instantiation
    ln = LinuxNetwork()
    assert ln.module.fail_json.called == 0
    # instantiation with dry-run
    ln = LinuxNetwork(checkmode=True)
    assert ln.module.fail_json.called == 0
    # instantiation with empty module
    ln = LinuxNetwork(module=AnsibleModule(argument_spec={}))
    assert ln.module.fail_json.called == 0
    # instantiation with not-empty module
    ln = LinuxNetwork(module=AnsibleModule(argument_spec={'test': {'required': True}}))
    assert ln.module.fail_json.called == 1



# Generated at 2022-06-23 00:09:12.878114
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(
        argument_spec={},
    )


# Generated at 2022-06-23 00:09:15.759232
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    net = LinuxNetwork(module)
    net.get_default_interfaces()



# Generated at 2022-06-23 00:09:20.711576
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    #local variables
    network_facts = dict(default_ipv4=dict(address='192.168.0.101'))
    LinuxNetworkInstance = LinuxNetwork(dict(module=None, params=None))
    # TODO: Consider using something like pyfakefs or maybe even mock filesystem
    #  functions to figure out what to return.
    try:
        LinuxNetworkInstance.populate(network_facts)
    except Exception:
        assert False


# Generated at 2022-06-23 00:09:30.541244
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict(
        ip_path=dict(type='path', default='/sbin/ip'),
    ))

    try:
        ln = LinuxNetwork(module)
    except (OSError, IOError) as exc:
        module.fail_json(msg=exc.message)
    module.exit_json(changed=False, ansible_facts={'default_ipv4': ln.get_default_interfaces()[1], 'default_ipv6': ln.get_default_interfaces()[0]})



# Generated at 2022-06-23 00:09:41.621319
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    test_interface = {
        'driver': 'bnx2x',
        'version': '2.2.3-k',
        'firmware-version': 'bc 7.12.19',
        'bus-info': '0000:05:00.0'
    }
    test_mac = '90:e2:ba:e9:57:e1'
    test_mtu = 1500
    test_device = {'mtu': test_mtu, 'macaddress': test_mac}

    class MockedModule(object):
        class MockedRunCommand(object):
            def __init__(self, rc, result, err=''):
                if isinstance(rc, list) or isinstance(result, list):
                    self.results = list(zip(rc, result, [err] * len(rc)))
               

# Generated at 2022-06-23 00:09:51.638468
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():

    content = """\
    default via 192.168.22.1 dev enp0s8  proto static  metric 100
    10.0.0.0/8 dev enp0s8  proto kernel  scope link  src 10.0.2.15  metric 100
    169.254.0.0/16 dev enp0s8  scope link  metric 1001
    172.17.0.0/16 dev docker0  proto kernel  scope link  src 172.17.0.1
    172.18.0.0/16 dev br-d11129a89c59  proto kernel  scope link  src 172.18.0.1
    192.168.22.0/24 dev enp0s8  proto kernel  scope link  src 192.168.22.129  metric 100
    """

# Generated at 2022-06-23 00:10:03.912370
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Do not want to actually call into LinuxNetwork.populate()
    # but call the private method _populate which is the same
    # except that this method does not update the ip_defaults
    # object.
    module = AnsibleModule(argument_spec={
        'gather_subset': {'type': 'list', 'default': ['!all', '!min']},
        'gather_timeout': {'type': 'int', 'default': 10},
    })
    linux_network = LinuxNetwork()
    linux_network.module = module
    interfaces, all_ipv4_addresses, all_ipv6_addresses = linux_network._populate()

    # Do not care about the first arg but it is a list.
    assert interfaces
    assert isinstance(interfaces, list)

    # Assert that all_

# Generated at 2022-06-23 00:10:16.841531
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    distro = module.get_distribution()

    # Test get_default_interfaces on Linux
    test_network = TestLinuxNetwork(module, 'Linux', distro)
    assert test_network.get_default_interfaces() == ('', '')
    assert test_network.default_ipv4 == {}
    assert test_network.default_ipv6 == {}

    # Test get_default_interfaces on OpenBSD
    test_network = TestLinuxNetwork(module, 'OpenBSD', distro)
    assert test_network.get_default_interfaces() == ('', '')
    assert test_network.default_ipv4 == {}
    assert test_network.default_ipv6 == {}

    # Test get_default_interfaces on

# Generated at 2022-06-23 00:10:24.855295
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = FakeModule()  # noqa
    instance = LinuxNetwork(module)

    # Test reading bonding device
    get_file_content_mock = MagicMock(side_effect=test_get_file_content)
    module.get_file_content = get_file_content_mock

    with patch("os.path.isdir", return_value=True), \
         patch("os.path.exists", return_value=True), \
         patch("os.path.realpath", return_value="/path/to/module"), \
         patch("os.readlink", return_value="pci_id"):
        module.get_bin_path.return_value = "ip"
        interfaces, ips = instance.get_interfaces_info("", {}, {})
        assert "bond0" in interfaces
       

# Generated at 2022-06-23 00:10:37.965781
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict(
        default_ipv4=dict(type='dict'),
        default_ipv6=dict(type='dict'),
        ip_path=dict(type='str'),
    ))

    # NOTE: ip -4 route list 0.0.0.0/0 2> /dev/null | grep -F 'dev' | cut -d' ' -f3
    # NOTE: ip -6 route list ::/0 2> /dev/null | grep -F 'dev' | cut -d' ' -f3
    # NOTE: ip -6 route list ::/0 2> /dev/null | grep -F 'dev' | cut -d' ' -f3 | sed -e "s/^/'/" -e "s/$/'/"
    # FIXME: make this a param instead of hard

# Generated at 2022-06-23 00:10:44.737969
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    import sys
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    test_default_ipv4 = dict(address='127.0.0.1')
    test_default_ipv6 = dict(address='::1')

    test_module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    test_module.run_command = _run_command_mock

    if sys.version_info[0] < 3:
        _, dummy = test_LinuxNetwork_populate_1(test_module, test_default_ipv4, test_default_ipv6)

# Generated at 2022-06-23 00:10:47.309450
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    fact_collector = LinuxNetworkCollector(module)



# Generated at 2022-06-23 00:10:53.558676
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():

    # Instantiate a class object
    ansible_col = LinuxNetworkCollector
    ansible_nm = ansible_col.collect()

    # store the list for comparison
    nm_list = []
    for dev in ansible_nm:
        nm_list.append(ansible_nm[dev]['device'])

    # check if the L2 interfaces are up
    assert 'lo' in nm_list
    assert 'eth0' in nm_list
    assert 'eth1' in nm_list



# Generated at 2022-06-23 00:11:06.459313
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    test_module = FakeModule()
    # Mock get_file_content method of module

# Generated at 2022-06-23 00:11:13.026939
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """Unit test for testing the constructor of LinuxNetworkCollector class"""
    cls = LinuxNetworkCollector
    # Test instantiation of class
    assert cls._platform == "Linux"
    assert cls._fact_class == LinuxNetwork
    assert cls.required_facts == set(['distribution', 'platform'])


if __name__ == '__main__':
    # Unit test for the class LinuxNetworkCollector
    test_LinuxNetworkCollector()

# Generated at 2022-06-23 00:11:23.501778
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    """ Collection of assertions to test the LinuxNetwork class """
    import pytest
    from ansible.module_utils import basic

    # if these test fail, the init of AnsibleModule() will fail
    assert basic.AnsibleModule
    assert basic.AnsibleModule.exit_json
    assert basic.AnsibleModule.fail_json

    # be able to construct pytest object
    pytest.LinuxNetwork = LinuxNetwork(basic.AnsibleModule)

    # test the constructor
    assert pytest.LinuxNetwork

    # test the private method _get_default_route
    assert pytest.LinuxNetwork.get_default_route() == (None, None)



# Generated at 2022-06-23 00:11:34.965263
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    import json
    import os
    import tempfile

    # NOTE: AnsibleModule fixture is pytest magic
    # it provides, module, params, exit_json and fail_json attrs
    def test_module(module):
        module.exit_json = exit_json
        module.fail_json = fail_json

    def exit_json(*args, **kwargs):
        return
    def fail_json(*args, **kwargs):
        return

    # AnsibleModule fixture always sets ANSIBLE_MODULE_ARGS env variable
    # don't include param from env variable in test case
    params = json.loads(os.environ.get('ANSIBLE_MODULE_ARGS', '{}'))
    tmp = tempfile.NamedTemporaryFile()
    os.environ['ANSIBLE_NET_CONFIG'] = tmp

# Generated at 2022-06-23 00:11:46.642679
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """
    Helper method to unit test module method get_interfaces_info
    Note: get_interfaces_info is called by init, so no need to call it in unit tests

    :return:
    """
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    # a dict of interface names to dictionaries holding their data
    interfaces = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    ln = LinuxNetwork(module)
    interfaces, ips = ln.get_interfaces_info('foo', 'bar', 'baz')
    return interfaces, ips



# Generated at 2022-06-23 00:11:49.944101
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    ln = LinuxNetwork(module)
    ln.get_interfaces_info('ip', {}, {})


# Generated at 2022-06-23 00:12:02.535392
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # TODO: find a way to mock the module object
    # This is a partial implementation to ensure that failures are
    # due to a missing feature, not a missing test
    module = FakeModule()
    linux_network = LinuxNetwork(module)
    default_ipv4, default_ipv6 = {'address': '1.2.3.4'}, {'address': '::1'}
    interfaces = {'eth0': {'mtu': 1500, 'type': 'unknown'}}
    ips = {}
    expected_interfaces = {'eth0': {'mtu': 1500, 'type': 'unknown'}}
    expected_ips = {}
    expected_defaults = {'ipv4': default_ipv4, 'ipv6': default_ipv6}

# Generated at 2022-06-23 00:12:07.354252
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    if_v4, if_v6 = network.get_default_interfaces()
    assert if_v4.get('address', '') and if_v6.get('address', '')


# Generated at 2022-06-23 00:12:20.082220
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Test data
    interfaces = glob.glob('/sys/class/net/*')
    ips = {}
    interface_set = set(interfaces)
    path = '/dev/null'
    ip_path = '/dev/null'
    default = {}
    # All iface in interface_set
    iface = 'lo'
    if os.path.exists(path):
        file_content = get_file_content(path)
        lines = file_content.split('\n')
        for line in lines:
            if not line:
                continue
            # Ignore header/blank/comments.
            if line.startswith("#") or line.startswith(" ") or line.startswith("\t"):
                continue
            words = line.split()

            # Grab the interface name and remove it from

# Generated at 2022-06-23 00:12:33.060298
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-23 00:12:41.606368
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Test populate method of LinuxNetwork class
    module = get_module_mock()

    # Create instance of LinuxNetwork class (class under test)
    linux_network = LinuxNetwork(module)
    # Set default_ipv4, default_ipv6 attributes to None
    linux_network.default_ipv4 = None
    linux_network.default_ipv6 = None
    # Call method populate of LinuxNetwork class
    linux_network.populate()

    assert linux_network.default_ipv4 is not None
    assert linux_network.default_ipv6 is not None


# Generated at 2022-06-23 00:12:42.753243
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    # empty
    hostname = None
    module = None

    # invoke
    assert not LinuxNetwork.populate(hostname, module)



# Generated at 2022-06-23 00:12:52.014706
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, _):
            return '/bin/ip'

        def run_command(self, args, **kwargs):
            # return an empty dict for now, it will get updated later
            from collections import OrderedDict
            data = OrderedDict()


# Generated at 2022-06-23 00:13:04.298658
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    ln = LinuxNetwork()

    # Test 1
    test1 = {}
    default_ipv4 = dict()
    default_ipv6 = dict()
    test1["ip_path"] = "/sbin/ip"
    test1["default_ipv4"] = default_ipv4
    test1["default_ipv6"] = default_ipv6
    result = ln.get_interfaces_info(test1["ip_path"], test1["default_ipv4"], test1["default_ipv6"])
    assert result is not None, "Result must not be None."
    assert isinstance(result, tuple), "Result must be a tuple."

    # Test 2
    test2 = {}
    default_ipv4 = dict()
    default_ipv6 = dict()

# Generated at 2022-06-23 00:13:16.136779
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    m = LinuxNetwork()

    # we need these to not cause a failure
    module = MagicMock()
    module.get_bin_path = MagicMock()
    module.get_bin_path.return_value = '/bin/ip'
    module.run_command = MagicMock()
    module.run_command.return_value = [0, '', '']
    m.module = module

    c = m.get_interfaces_info('', {}, {})
    assert c == ({}, {'all_ipv4_addresses': [], 'all_ipv6_addresses': []})
    assert m.module.get_bin_path.call_count == 1
    assert m.module.run_command.call_count == 4



# Generated at 2022-06-23 00:13:24.318801
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    network = LinuxNetwork()
    network.module.params = { 'gather_subset': ['all']}
    interface = {}
    (interface['v4'], interface['v6']) = network.populate()
    # test default assert
    assert interface['v4']['address'] != interface['v6']['address']
# If run directly, run all tests
if __name__ == '__main__':
    test_LinuxNetwork_populate()

__all__ = [
    'LinuxNetwork'
]

# Generated at 2022-06-23 00:13:36.656884
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-23 00:13:43.620407
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    """Test get_default_interfaces"""
    # FIXME: Explicitly check for expected exceptions, or use @pytest.mark.xfail
    module = AnsibleModule(
        argument_spec=dict(
        ),
        supports_check_mode=True,
    )

    module.params = {
    }

    ln = LinuxNetwork(module)
    ln.get_default_interfaces()



# Generated at 2022-06-23 00:13:51.120955
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec=dict())
    ln = LinuxNetwork(module)
    result = ln.populate()
    assert result
    assert 'network' in result
    assert 'interfaces' in result['network']
    assert 'default_ipv4' in result['network']
    assert 'default_ipv6' in result['network']
    assert 'gateway4' in result['network']
    assert 'gateway6' in result['network']
    assert 'all_ipv4_addresses' in result['network']
    assert 'all_ipv6_addresses' in result['network']


# Generated at 2022-06-23 00:13:55.332664
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    network_collector = LinuxNetworkCollector(module, '', '')
    assert network_collector.platforms == ('Linux',)


# Generated at 2022-06-23 00:14:04.402338
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Initialize class instance(s)
    linux_network = LinuxNetwork()
    # Set class attributes
    linux_network.module = type('module', (), {'deprecate': lambda x, y, z: None})()
    linux_network.module.check_mode = False
    linux_network.module.run_command = lambda x, y, z: (0, '', '')
    # Attempt to execute the method
    result = linux_network.get_default_interfaces()
    # Verify the result
    assert isinstance(result, tuple)
    assert len(result) == 2
    assert result[0] == {'default_ipv4': None, 'default_ipv6': None}
    assert isinstance(result[1], tuple)
    assert len(result[1]) == 2
    assert result[1][0]

# Generated at 2022-06-23 00:14:15.695380
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.common.collections import ImmutableDict
    # call with given args, and check attributes being set

# Generated at 2022-06-23 00:14:28.212723
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    mock_dev = 'eth0'

    # Build a mock dict with mocked methods
    class MockModule:
        def __init__(self):
            self.params = {}
            self.run_command_results = []
            self.run_command_calls = 0

        def fail_json(self, *args, **kwargs):
            self.exception = kwargs['msg']
            raise SystemExit()

        def get_bin_path(self, path):
            if path == 'ethtool':
                return path
            else:
                return None

        # Run command is mocking the execution of the Linux command
        # The first time it runs it returns a string that is the output of ethtool -k eth0
        # The second time it returns a string that is the output of ethtool

# Generated at 2022-06-23 00:14:41.516798
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    data = {}
    m = ansible_module_mock(
        dict(
            data=data
        )
    )

    ethtool_path = m.get_bin_path("ethtool")
    args = [ethtool_path, '-k', 'lo']
    rc = 0

# Generated at 2022-06-23 00:14:52.581720
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    net = LinuxNetwork()
    assert net.get_default_interfaces() == ({'default': {'address': '10.0.2.15', 'broadcast': '10.0.2.255', 'gateway': '10.0.2.2', 'interface': 'eth0', 'netmask': '255.255.255.0', 'network': '10.0.2.0'}}, {'default': {'address': 'fe80::a00:27ff:fe4e:eb86', 'gateway': 'fe80::a00:27ff:fe46:7523', 'interface': 'eth0', 'prefix': '64', 'scope': 'link'}})


# Generated at 2022-06-23 00:15:04.635448
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from collections import namedtuple

    module_test = namedtuple("AnsibleModule", ["params", "exit_json", "exit_args", "fail_json", "run_command"])
    module = module_test(params={}, exit_json=None, exit_args=None, fail_json=None, run_command=None)

    linux_network = LinuxNetwork(module)

    # Default: if ethtool not found and no device is provided,
    # return an empty dict.
    assert linux_network.get_ethtool_data(None) == {}

    # Test with different devices.

# Generated at 2022-06-23 00:15:06.179731
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    assert False



# Generated at 2022-06-23 00:15:13.943736
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModuleDummy()
    ln = LinuxNetwork(module)

    eth0 = {
        'active': True,
        'address': "00:11:22:33:44:55",
        'device': "eth0",
        'features': {"tx": "on", "rx": "off"},
        'hw_timestamp_filters': ['all'],
        'macaddress': "00:11:22:33:44:55",
        'mtu': 1500,
        'promisc': False,
        'timestamping': ['host', 'sof_tx', 'sof_rx'],
        'type': "ethernet"
    }

# Generated at 2022-06-23 00:15:26.092813
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    """
    Test method get_default_interfaces with following command output:

    ip route show
    default via 192.168.0.1 dev eth1  metric 100
    10.0.0.0/8 dev eth0  proto kernel  scope link  src 10.0.0.1
    192.168.0.0/24 dev eth1  proto kernel  scope link  src 192.168.0.2
    """
    default_ipv4, default_ipv6 = LinuxNetwork.get_default_interfaces('ip')
    # Check value of default_ipv4
    assert isinstance(default_ipv4, dict)
    assert default_ipv4 == dict(address='192.168.0.1', interface='eth1', metric='100')
    # Check value of default_ipv6

# Generated at 2022-06-23 00:15:38.709117
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    def get_interface_by_name(name):
        return {
            "name": name,
            "addresses": [
                {
                    "family": "AF_INET6",
                    "address": "fe80::c62b:faff:fe36:fec4"
                },
                {
                    "family": "AF_INET",
                    "address": "192.168.1.17"
                },
                {
                    "family": "AF_LINK",
                    "address": "d6:2b:fa:36:fe:c4"
                }
            ],
            "up": True,
            "mtu": 1500
        }

    class ModuleStub():

        def __init__(self):
            self.run_command_args = None
            self.run_command_rc = 0


# Generated at 2022-06-23 00:15:45.452414
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Set up the mock module
    module = AnsibleModule(argument_spec={})
    # get_bin_path is a noop for tests
    module.get_bin_path = lambda x: x

    # Mock the run_command method
    # - ethtool -k returns 'features/offload' output
    # - ethtool -T returns 'timestamping' output

# Generated at 2022-06-23 00:15:57.598404
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    ln = LinuxNetwork()
    mock_module = Mock()
    ln.module = mock_module
    mock_module.get_bin_path.return_value = "/bin/ethtool"
    def side_effect(*args, **kwargs):
        if args[0] == ['/bin/ethtool', '-k', 'em1']:
            return 0, "xxx", ""

# Generated at 2022-06-23 00:16:02.713127
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    linux_network = LinuxNetwork(module=module)
    # FIXME: turn into unittest format
    linux_network.populate()
    return module.exit_json(changed=False)


# Generated at 2022-06-23 00:16:12.074364
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = Mock()
    result = dict(
        interfaces = dict(),
        default_ipv4 = dict(),
        default_ipv6 = dict(),
        ips = dict(
            all_ipv4_addresses = [],
            all_ipv6_addresses = [],
        ),
    )

    linux_network = LinuxNetwork(module)

    linux_network.populate(result)

    module.run_command.assert_any_call(["ip", "addr", "show", "primary"], errors="surrogate_then_replace")
    module.get_bin_path.assert_called_with("ethtool")
    module.run_command.assert_called_with(["ethtool", "-k", ANY])


# Generated at 2022-06-23 00:16:24.839150
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    TEST_CLASS = LinuxNetwork
    TEST_METHOD = 'get_interfaces_info'

# Generated at 2022-06-23 00:16:30.397619
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModuleMock()

    # Try with a user defined path
    ln = LinuxNetwork(module, 'path')
    assert ln.ip_path == 'path'
    assert ln.module == module

    # Try with the default path
    ln = LinuxNetwork(module)
    assert ln.ip_path == module.get_bin_path("ip")

    # FIXME: need a test for the rest of this class, including the exception handler

# Load and export the module to Ansible
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()