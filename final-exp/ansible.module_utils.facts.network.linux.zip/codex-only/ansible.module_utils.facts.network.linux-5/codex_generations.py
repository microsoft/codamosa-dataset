

# Generated at 2022-06-23 00:06:35.093939
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux = LinuxNetwork()
    result = linux.get_ethtool_data("lo")

# Generated at 2022-06-23 00:06:38.739025
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(default=['!all', '!min'], type='list')
        }
    )

    # noinspection PyTypeChecker
    LinuxNetworkCollector(module)

# Generated at 2022-06-23 00:06:48.745928
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    net = LinuxNetwork()
    net.module.params['config'] = '/etc/sysconfig/network'
    net.module.params['config_v6'] = '/etc/sysconfig/network'
    net.module.params['route_metadata_args'] = ''
    net.module.exit_json = lambda x: None

    net.populate()


# Generated at 2022-06-23 00:07:01.200260
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Test for get_ethtool_data function when ethtool returns "no data available"
    mock_module = MagicMock()
    mock_module.run_command = MagicMock(return_value=(1, "No data", ""))
    l = LinuxNetwork(module=mock_module)
    data = l.get_ethtool_data("testinterface")
    assert data == {}
    # Test for get_ethtool_data function when ethtool output matches expected output
    mock_module = MagicMock()

# Generated at 2022-06-23 00:07:14.246606
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    """
    Unit test for method populate of class LinuxNetwork
    """
    # Setup a mock module
    module = AnsibleModule(argument_spec={})
    result = dict(
        ansible_facts={}
    )

    mocker_module_mock = MagicMock(return_value=module)
    # TODO
    #if sys.version_info < (3,3):
    #    mocker_module_mock = PropertyMock(return_value=module)

    mocker_run_command_mock = MagicMock(return_value=(0,'',''))
    mocker_get_bin_path_mock = MagicMock(return_value='/bin/ip')
    # FIXME: I do not think this is being used?
    mocker_get_file_content_mock = MagicMock

# Generated at 2022-06-23 00:07:17.199698
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModuleMock()
    fact_collector = LinuxNetworkCollector(module)
    assert fact_collector.required_facts == set(['distribution', 'platform'])
    assert fact_collector.has_required_facts(dict(distribution="foo", platform="linux"))
    assert not fact_collector.has_required_facts(dict(distribution="foo", platform="windows"))


# Generated at 2022-06-23 00:07:29.295223
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Create instance of a module
    module = NetworkModule()
    # Create a test class object of parent class Network
    parent_obj = Network(module)
    # Create an object of class LinuxNetwork for testing
    linux_network_obj = LinuxNetwork(module, parent_obj)
    # Create an instance of class to be tested
    linux_network_obj.get_default_interfaces()


if __name__ == '__main__':
    # Ansible internally calls the module test code if name of the module file
    # is __main__.
    #
    # If the above condition passes we invoke the argument parser to execute
    # the module.
    module = NetworkModule(argument_spec=dict())
    linux_network_obj = LinuxNetwork(module, Network(module))
    interfaces, ips = linux_network_obj.get_interfaces

# Generated at 2022-06-23 00:07:41.286844
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    # Set up mock classes and objects
    class MockLinuxNetwork:
        def __init__(self, module):
            pass

        def get_interfaces_info(self, ip_path, default_ipv4, default_ipv6):
            return {
                'data_a': 'value_a',
                'data_b': 'value_b',
                'data_c': 'value_c',
                'data_d': 'value_d',
                'data_e': 'value_e',
                'data_f': 'value_f'
            }


# Generated at 2022-06-23 00:07:51.374997
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import patch
    import os
    import tempfile

    tmpdir = tempfile.mkdtemp()
    mock_glob = patch('glob.glob')
    mock_glob.start().return_value = [os.path.join(tmpdir, 'enp0s25'), os.path.join(tmpdir, 'enp1s0f0'), os.path.join(tmpdir, 'lo')]
    mock_open = patch('io.open', create=True)
    handle = mock_open.start()

# Generated at 2022-06-23 00:07:59.886510
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    test_params = {'module': None, 'rc': 0, 'stdout': '', 'stderr': ''}
    test_obj = LinuxNetwork(test_params)
    test_obj.ethtool_path = 'blah'
    test_device = 'eth0'
    expected_stdout = '''blah -k eth0
blah -T eth0
'''
    args = [test_obj.ethtool_path, '-k', test_device]
    test_params['rc'], test_params['stdout'], test_params['stderr'] = 0, expected_stdout, ''
    test_obj = LinuxNetwork(test_params)

# Generated at 2022-06-23 00:08:12.940574
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import Mock, patch
    from ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils import AnsibleExitJson, AnsibleFailJson, ModuleTestCase, set_module_args

    class AnsibleFailJson(Exception):
        pass

    module = AnsibleModule(
        argument_spec=dict(
            device=dict(type='str'),
        ),
        supports_check_mode=True,
    )

    # base case
    device = 'em5'
    ethtool_path = '/usr/sbin/ethtool'

# Generated at 2022-06-23 00:08:19.236882
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = NetworkModule(argument_spec=dict())
    module.connections = dict(conn_networks=MagicMock())
    sys_net = LinuxNetwork(module)
    module.get_bin_path = Mock(return_value=True)

    def get_command_output_bad(cmd, *args):
        raise RuntimeError


# Generated at 2022-06-23 00:08:33.098551
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule({})
    return_value = dict(v4=dict(address=None, gateway=None, interface=None),
                        v6=dict(address=None, gateway=None, interface=None))
    set_module_args(dict())
    linux_network = LinuxNetwork(module)
    def mock_exec_command(cmd, **kwargs):
        return None, None, None
    with patch.object(AnsibleModule, 'run_command', mock_exec_command):
        assert linux_network.get_default_interfaces() == return_value

    return_value = dict(v4=dict(address='127.0.0.1', gateway=None, interface=None),
                        v6=dict(address=None, gateway=None, interface=None))
    set_module_args(dict())
   

# Generated at 2022-06-23 00:08:39.373065
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    assert type(ln.default_ipv4) is dict
    assert type(ln.default_ipv6) is dict
    assert type(ln.interfaces) is dict
    assert type(ln.module) is AnsibleModule
    assert type(ln.networks) is dict
    assert type(ln.params) is dict


# Generated at 2022-06-23 00:08:49.029917
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {'gather_subset': ['all'],
                     'gather_network_resources': 'no'}
    network = LinuxNetwork(module)
    network.get_default_interface = MagicMock()
    network.get_default_interface.side_effect = network.get_default_interface_mock
    network.get_interfaces_info = MagicMock()
    network.get_interfaces_info.side_effect = network.get_interfaces_info_mock
    network.get_interfaces_ip = MagicMock()
    network.get_interfaces_ip.side_effect = network.get_interfaces_ip_mock
    network.get_route = MagicMock()

# Generated at 2022-06-23 00:09:01.505502
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    expected = {
        'default_ipv4': {
            'address': '192.168.1.101',
            'broadcast': '192.168.1.255',
            'metric': '10',
            'netmask': '255.255.255.0',
            'network': '192.168.1.0',
            'scope': 'global'
        },
        'default_ipv6': {
            'address': 'fe80::b3ae:68ff:fe65:37d1',
            'prefix': '64',
            'scope': 'link'
        }
    }

    ln = LinuxNetwork()
    ln.module.fail_json = lambda a, b: None
    ln.get_bin_path = lambda module: '/bin/%s' % module

# Generated at 2022-06-23 00:09:14.347219
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    tmpfile = '/tmp/ansible_net_linux_network_file.txt'
    if os.path.exists(tmpfile):
        try:
            os.remove(tmpfile)
        except OSError:
            pass

    def test_module():
        return MockModule()

    def get_bin_path(module, arg=None):
        if arg == 'ip':
            return '/bin/ip'
        if arg == 'ethtool':
            return '/bin/ethtool'
        return None

    def get_file_content(arg):
        if arg == '/proc/net/dev':
            return '/proc/net/dev file'
        if arg == '/sys/class/net/lo/device/mtu':
            return '/sys/class/net/lo/device/mtu file'

# Generated at 2022-06-23 00:09:22.183429
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule({'ANSIBLE_MODULE_ARGS': {'gather_subsets': ['all']}})
    test_LN = LinuxNetwork(module)
    interfaces, ips = test_LN.get_interfaces_info(None, {'address': '192.168.0.1'}, {'address': '2001:db8::1'})
    assert 'eth0' in interfaces
    assert 'eth1' in interfaces
    assert 'eth2' not in interfaces
    assert 'eth3' not in interfaces
    assert 'lo' in interfaces
    assert 'bond0' in interfaces and interfaces['bond0']['type'] == 'bonding'
    assert interfaces['lo']['active'] is True
    assert interfaces['lo']['device'] == 'lo'

# Generated at 2022-06-23 00:09:34.447906
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Testing IPv4 only
    # NOTE: this is a static (monkey) patched function
    _get_interface_info = LinuxNetwork.get_interface_info

    # IPv4, no default
    default_ipv4 = {'address': '192.0.2.1', 'network': '192.0.2.0', 'netmask': '255.255.255.0', 'broadcast':'192.0.2.255'}
    default_ipv6 = {'address': '2001:db8::1', 'network': '2001:db8::', 'prefix': 64}
    LinuxNetwork.get_interface_info = lambda *a, **k: ({'address': '127.0.0.1'}, {'address': '::1'})
    network = LinuxNetwork(None)

# Generated at 2022-06-23 00:09:42.013543
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network = LinuxNetwork(None)

    output = [
        'Features for enp2s0:',
        'rx-checksumming: on',
        'tx-checksumming: on',
        'scatter-gather: off',
        'tcp segmentation offload: off',
        'udp fragmentation offload: off',
        'generic segmentation offload: on',
        'large receive offload: off',
        'rx-vlan-offload: on',
        '']
    o = "\n".join(output)

# Generated at 2022-06-23 00:09:51.985885
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # setup
    test_obj = LinuxNetwork()
    linux_network_obj = LinuxNetwork()
    linux_network_obj.module = Mock()
    linux_network_obj.module.run_command = Mock()
    command = {'v4': ['ip', 'route', 'get', '8.8.8.8'], 'v6': ['ip', '-6', 'route', 'get', '2001:4860:4860::8888']}
    # mock
    linux_network_obj.module.run_command.return_value = (0, '8.8.8.8 via 192.168.1.1 dev eth0 src 192.168.1.100 cache\n', '')

# Generated at 2022-06-23 00:09:58.484273
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.fact_cache import FactCache
    fact_cache = FactCache()
    facts = fact_cache.get_facts(None)
    collector = LinuxNetworkCollector(facts)
    assert isinstance(collector.facts, dict)
    assert 'distribution' in collector.facts
    assert 'platform' in collector.facts


# Generated at 2022-06-23 00:10:06.348371
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # pylint: disable=W0212
    module = AnsibleModule(argument_spec={'gather_subset': dict(type='list')})
    module.params['gather_subset'] = ['all']
    nm = LinuxNetwork(module)
    nm.populate()
    assert nm.facts['default_ipv4']['mtu'] == 1500
    assert nm.facts['default_ipv6']['mtu'] == 1500



# Generated at 2022-06-23 00:10:10.783774
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    result = LinuxNetworkCollector.test(None)
    assert result[0] == 'Linux'
    assert result[1] == LinuxNetwork
    assert result[2] == set(['distribution', 'platform'])


# Generated at 2022-06-23 00:10:16.125129
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    m = AnsibleModule(
        argument_spec=dict()
    )
    obj = LinuxNetworkCollector(m)
    assert obj.platform == 'Linux'
    assert obj.required_facts == {'distribution', 'platform'}
    assert obj.config is m


# Generated at 2022-06-23 00:10:21.499571
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # prepare mock data
    rc = 0
    stdout = b''
    stderr = b''

    # run test with mock data
    linux_network = LinuxNetwork()
    mac_address, netmask, broadcast, network = linux_network.get_default_interfaces()

    # test result
    assert mac_address == ''
    assert netmask == ''
    assert broadcast == ''
    assert network == ''


# Generated at 2022-06-23 00:10:22.911107
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    assert True, "FIXME: test not implemented"

# Generated at 2022-06-23 00:10:36.320576
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    run_from = os.path.dirname(os.path.abspath(__file__))
    data_dir = 'test/unit/modules/network/static'
    mocked_module = MockAnsibleModule(
        dd_from=data_dir,
        dd_from_spec={'path': 'ansible.builtin.get_facts'},
    )
    mocked_module.ansible_builtin_config_file = os.path.join(run_from, data_dir, 'fixtures/ansible.cfg')
    ln = LinuxNetwork(mocked_module)
    ln.populate()
    assert ln.facts['default_ipv4']['address'] == '10.10.100.100'

# Generated at 2022-06-23 00:10:48.051435
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    """
    Create a class instance and test its attributes
    """
    net = LinuxNetwork(None)

    assert 'lo' in net.interfaces
    for k, v in NET_EXAMPLE_IFACES.items():
        attrs = ["device", "macaddress", "mtu", "type", "promisc"]
        for a in attrs:
            assert net.interfaces[k][a] == v[a]

    assert net.default_ipv4['address'] == NET_EXAMPLE_DNS['address']
    assert net.default_ipv4['netmask'] == NET_EXAMPLE_DNS['netmask']
    assert net.default_ipv4['network'] == NET_EXAMPLE_DNS['network']
    assert net.default_ipv4['broadcast'] == NET_EXAMPLE

# Generated at 2022-06-23 00:10:53.310017
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModuleMock()
    module.run_command.return_value = [0, '', '']
    n = LinuxNetworkCollector(module)
    assert n._platform == 'Linux'
    assert n._fact_class == LinuxNetwork
    assert len(n.required_facts) == 2
    assert n.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-23 00:11:06.081554
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec=dict())
    ln = LinuxNetwork(module)
    data = ln.get_interfaces_info()
    assert isinstance(data, dict), 'data should be a dict'
    assert 'default_ipv4' in data, 'data should contain a default_ipv4 key'
    assert 'default_ipv6' in data, 'data should contain a default_ipv4 key'
    assert isinstance(data['default_ipv4'], dict), 'default_ipv4 should be a dict'
    assert isinstance(data['default_ipv6'], dict), 'default_ipv6 should be a dict'
    assert 'interfaces' in data, 'data should contain an interfaces key'

# Generated at 2022-06-23 00:11:18.402735
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule({})
    sn = LinuxNetwork(module)
    # FIXME: need to fake out the variables
    sn.active = dict()
    sn.default = dict()

    from ansible.module_utils.basic import AnsibleModule
    from collections import namedtuple
    # FIXME: Find out how to supply a dict to this, rather than a file
    data = namedtuple('data', 'stdout')

# Generated at 2022-06-23 00:11:21.243589
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    nm = LinuxNetwork(module)
    module.exit_json(**nm.get_interfaces_info())



# Generated at 2022-06-23 00:11:32.317469
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    """
    Test :py:meth:`ansible_collections.ansible.community.plugins.module_utils.network.common.network.LinuxNetwork.populate`
    """
    module = mock.MagicMock()
    module.run_command = mock.MagicMock(return_value=(0, "", ""))

    n = network.LinuxNetwork(module)
    data = n.populate()
    assert 'default_ipv4' in data
    assert 'default_ipv6' in data
    assert 'interfaces' in data
    assert 'all_ipv4_addresses' in data['interfaces']
    assert 'all_ipv6_addresses' in data['interfaces']

# Generated at 2022-06-23 00:11:44.316483
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    class MockLinuxNetwork(LinuxNetwork):
        def __init__(self, module):
            super(MockLinuxNetwork, self).__init__(module)

        def run_command(self, args, errors='strict'):
            if args[-1] == 'default':
                return 0, 'dev enp0s3', ''
            elif args[-1] == 'enp0s3':
                return 0, 'src 192.168.0.1', ''
            elif args[-2] == '-6':
                return 0, '', ''
            else:
                return 0, '', ''


# Generated at 2022-06-23 00:11:54.841018
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network = LinuxNetwork(module=None)

    # Test with v4 only routing table
    def _mock_execute(commands, check_rc=True, **kwargs):
        if commands[-1] == 'ip route':
            return '''default via 10.0.0.1 dev eth0
default via 172.16.0.1 dev eth1
default via 192.168.0.1 dev eth2
''', '', 0
        else:
            return '10.0.0.1', '', 0

    linux_network.module.run_command = _mock_execute
    (default_ipv4, default_ipv6) = linux_network.get_default_interfaces()
    assert(default_ipv4['interface'] == 'eth0')

# Generated at 2022-06-23 00:11:59.919338
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    # create reusable object (instead of creating it in every test)
    module = AnsibleModule({})
    network = LinuxNetwork(module)
    assert network.module == module


# Generated at 2022-06-23 00:12:11.735380
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import tempfile
    import os

    # TODO: move to a common test_utils file

    # Temporary path
    temp_dir = tempfile.gettempdir()

    # Create a temporary sys class net directory
    temp_path = temp_dir + "/sys/class/net/"
    try:
        os.makedirs(temp_path)
    except OSError:
        pass

    # Create a temporary dummy network interface inside this directory
    temp_interface = temp_path + "dummy0"
    try:
        os.makedirs(temp_interface)
    except OSError:
        pass

    # Create a temporary ip command
    temp_path = temp_dir + "/ip"

# Generated at 2022-06-23 00:12:24.374679
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModuleMock()
    network = LinuxNetwork(module)
    module.get_bin_path = MagicMock(return_value='/bin/ip')
    module.run_command = MagicMock(return_value=(0, 'mocked stdout', 'mocked stderr'))


# Generated at 2022-06-23 00:12:37.123588
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )
    linux_network = LinuxNetwork(module)

# Generated at 2022-06-23 00:12:40.327043
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    """
    This function tests the LinuxNetwork constructor.
    """
    module = AnsibleModule(argument_spec={})

    ln = LinuxNetwork(module)

    assert ln.module is module

# Generated at 2022-06-23 00:12:50.919236
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = Mock(path_exists=lambda x: True,
                  get_bin_path=lambda x: '/bin/ip')
    module.run_command = Mock(return_value=(0, 'default via 192.168.0.1 dev eth0 proto static metric 100', ''))
    module.run_command.side_effect = [
        ('', '192.168.0.1 dev eth1 scope link src 192.168.0.2\n'
              '192.168.0.1 dev eth2 scope link src 192.168.0.3', ''),
        ('', 'fe80::3c97:eff:fe54:5e dev eth0 scope link\n'
              'fe80::3c97:eff:fe54:5e dev eth1 scope link', '')]
    network = LinuxNetwork(module)
    default_

# Generated at 2022-06-23 00:12:55.137132
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = get_module()
    platform = get_platform(module)
    network = LinuxNetwork(module, platform)

    assert network.get_default_interfaces() == ({}, {})

# Generated at 2022-06-23 00:13:05.885624
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    import os
    import json
    import ansible.constants
    from ansible.module_utils.basic import AnsibleModule

    # FIXME: Make num_mocks an argument,
    # might be useful when testing all/most of the data
    # as well as when adding/removing data
    num_mocks = 1
    filename = "populate-v%s.json" % num_mocks
    filepath = os.path.join(os.path.dirname(__file__), "unit", filename)

    def get_bin_path(name):
        return None

    def run_command(args, errors):
        return 0, "", ""

    orig_get_bin_path = ansible.module_utils.network.common.get_bin_path
    ansible.module_utils.network.common.get_

# Generated at 2022-06-23 00:13:17.725045
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    """Unit test for method populate of class LinuxNetwork

    Test case is:
    - Lo interface is not present
    - Two interfaces with IPv4 and IPv6 addresses

    """
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    ln = LinuxNetwork(module)


# Generated at 2022-06-23 00:13:23.392381
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = MagicMock()
    cache = {}
    l = LinuxNetworkCollector(module=module, cache=cache)

    assert(l._module == module)
    assert(l.cache == cache)
    assert('linux' == l.platform)
    assert('linux' == l.os)


# Generated at 2022-06-23 00:13:35.740023
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    obj = LinuxNetwork()
    obj.module = AnsibleModule(argument_spec=dict())
    input_value = {'.': {
        'all_ipv4_addresses': [],
        'all_ipv6_addresses': []
    }}
    output_value = obj.get_interfaces_info(
        "/bin/ip",
        {"address": "1.1.1.1"},
        {"prefix": "32", "scope": "global"}
    )
    assert output_value['.']['all_ipv4_addresses'] == input_value['.']['all_ipv4_addresses']
    assert output_value['.']['all_ipv6_addresses'] == input_value['.']['all_ipv6_addresses']



# Generated at 2022-06-23 00:13:47.418886
# Unit test for method get_default_interfaces of class LinuxNetwork

# Generated at 2022-06-23 00:14:00.011595
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule({})
    ln = LinuxNetwork(module)

    # update default_ipv4 and default_ipv6
    ln.get_default_ipv4()
    ln.get_default_ipv6()

    # get a dict of all interfaces and addresses
    interfaces, ips = ln.get_interfaces_info(ln.get_bin_path('ip'), ln.default_ipv4, ln.default_ipv6)

    # get the default route interface
    default_route_interface = ln.get_default_route_interface()

    # get the default route gateway
    default_route_gateway = ln.get_default_route_gateway()

    # get the default interface
    ln.get_default_interface()

    # get route information

# Generated at 2022-06-23 00:14:04.732255
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    assert LinuxNetworkCollector._platform == 'Linux'
    assert LinuxNetworkCollector._fact_class.__name__ == 'LinuxNetwork'
    assert LinuxNetworkCollector.required_facts == {'distribution', 'platform'}



# Generated at 2022-06-23 00:14:15.833538
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():

    device = 'eth0'
    fake_stdout = """
    Features for eth0:
        rx-checksumming: on
        tx-checksumming: on
        tx-checksum-ipv4: on
        tx-checksum-unneeded: off
        tx-checksum-ip-generic: off
        [...]
Timestamping capabilities:
    PTP Hardware Clock: 0
    Hardware Transmit Timestamp Modes:
    Hardware Receive Filter Modes:
    HWTSTAMP_FILTER_NONE
        """
    rc = 0
    module_fake = mock.MagicMock()
    module_fake.run_command.return_value = rc, fake_stdout, ''
    module_fake.get_bin_path.return_value = '/usr/bin/ethtool'


# Generated at 2022-06-23 00:14:18.522765
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    network_collector = LinuxNetworkCollector()
    assert network_collector.fact_class == LinuxNetwork



# Generated at 2022-06-23 00:14:24.065627
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Make sure the doc string is up to date
    test_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    _linux_network = LinuxNetwork(test_module)
    assert len(_linux_network.get_default_interfaces()) == 2



# Generated at 2022-06-23 00:14:31.363377
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    class TestModule(object):
        def get_bin_path(self, arg):
            return arg
    module = TestModule()
    net = LinuxNetwork(module)
    if_data = net.get_interfaces_info("/sbin/ip", {}, {})
    # FIXME: I'm not sure what we're asserting here
    assert if_data

# Unit test to check the output of get_interfaces_info

# Generated at 2022-06-23 00:14:44.132505
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # This is a hack to mock the instance variable module by replacing the
    # module global variable with a mock. This works as long as populate
    # is not calling any method of the class LinuxNetwork (which is the case).
    module = mock.MagicMock()
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='')

    # The first argument is self, which is not defined here, so it results in
    # a NameError exception that is expected since self is not defined.
    # The second argument is the only one used in the method.
    with pytest.raises(NameError):
        network_common.LinuxNetwork.populate(None, module)


# Generated at 2022-06-23 00:14:56.494591
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    os.environ['LANG'] = 'C'
    m = AnsibleModule(argument_spec={})
    ip_path = '/sbin/ip'
    default_ipv4 = dict(address='127.0.0.1')
    default_ipv6 = dict(address='::1')
    n = LinuxNetwork(m, ip_path, default_ipv4, default_ipv6)
    interfaces, ips = n.get_interfaces_info(ip_path, default_ipv4, default_ipv6)
    # Lo and eth0 should be in the interfaces map
    assert 'lo' in interfaces
    assert 'enp0s3' in interfaces
    # Lo and eth0 should have a MAC address

# Generated at 2022-06-23 00:15:08.600855
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    nm = LinuxNetwork(module)

    iftype = nm.INTERFACE_TYPE
    assert iftype.get(1) == 'loopback', iftype
    assert iftype.get(2) == 'ethernet', iftype
    assert iftype.get(1) == 'loopback', iftype
    assert iftype.get(3) == 'ppp', iftype
    assert iftype.get(4) == 'software_loopback', iftype
    assert iftype.get(5) == 'arcnet', iftype
    assert iftype.get(6) == 'atm', iftype
    assert iftype.get(7) == 'wireless', iftype
    assert iftype.get(8) == 'modem', iftype

# Generated at 2022-06-23 00:15:21.100636
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    addresses = {'v4': {}, 'v6': {}}
    addresses['v4']['default'] = '192.168.1.2'
    interfaces = {'lo': {'ipv4': {}},
                  'eth0': {'ipv4': {'address': '192.168.1.2'},
                           'ipv6': []},
                  'eth1': {'ipv4': {'address': '192.168.2.2'},
                           'ipv6': [{'address': '2001:db8::10:0:0:1'}]}}
    default_ipv4, default_ipv6 = LinuxNetwork().get_default_interfaces(addresses, interfaces)
    assert default_ipv4 == {'address': '192.168.1.2'}
   

# Generated at 2022-06-23 00:15:25.338879
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    running_platform, distribution = platform.dist(), platform.linux_distribution()
    if running_platform == 'Linux':
        assertLinuxNetworkCollector(LinuxNetworkCollector(dict(distribution=distribution, platform=running_platform)))



# Generated at 2022-06-23 00:15:37.710731
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    module.params['gather_subset'] = ['all']
    module.params['filter'] = '*'
    m = LinuxNetwork(module)
    default_ipv4, default_ipv6 = m.get_default_interfaces()
    r, out, err = module.run_command('ip route list match 0/0 | cut -d" " -f3')
    if out:
        assert default_ipv4['address'] == out.splitlines()[0]
    r, out, err = module.run_command('ip -6 route list match ::/0 | cut -d" " -f3')
    if out:
        assert default_ipv6['address'] == out.splitlines()[0]



# Generated at 2022-06-23 00:15:46.980442
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_native
    import json

    module = AnsibleModule({}, "")

    ln = LinuxNetwork(module)
    try:
        interfaces, ips = ln.get_interfaces_info(module.get_bin_path("ip"), {}, {})
    except Exception as e:
        module.fail_json(msg=to_native(e))
    else:
        module.exit_json(ansible_facts=dict(
            ansible_network_resources=dict(
                interfaces=interfaces,
                ips=ips
            )))



# Generated at 2022-06-23 00:15:59.341131
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    # create an instance of the module (stubs)
    module = argument_spec = dict(
        as_sudo=dict(type='bool', default=False)
    )
    instance = LinuxNetwork(module=AnsibleModule(argument_spec, supports_check_mode=True))
    # create instance of child class
    child = instance.subclass('linux', 'network')

    def _subtest_test_LinuxNetwork_populate(subtest, child, module):
        subtest.test_instance(child, 'subclass', LinuxNetwork)
        subtest.test_instance(child, 'module', AnsibleModule)
        # validate module.run_command is a method
        subtest.test_instance_method(child.module, 'run_command', AnsibleModule)
        # validate property `command`
        subtest.test_instance

# Generated at 2022-06-23 00:16:10.391995
# Unit test for method get_default_interfaces of class LinuxNetwork

# Generated at 2022-06-23 00:16:24.130752
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={ 'ip_path': dict(required=True, type='str') })
    result = dict()
    ln = LinuxNetwork(module)
    # default_ipv4 and default_ipv6 are used to check if the default address is present in our interfaces, so we need to
    # initialize them with the current default address
    # TODO: show how to get the current default ?
    default_ipv4 = {'address': ''}
    default_ipv6 = {'address': ''}
    result['interfaces'], result['ips'] = ln.get_interfaces_info('/usr/bin/ip', default_ipv4, default_ipv6)
    # Test that the default ipv4 address is present in the network interfaces
    assert len(result['interfaces']) > 0