

# Generated at 2022-06-23 00:06:35.899463
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec=dict())
    def get_bin_path(executable):
        if executable == 'ethtool':
            return executable
        raise Exception
    module.get_bin_path = get_bin_path

# Generated at 2022-06-23 00:06:45.352000
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    fake_module = get_fake_module(get_linux_distribution())
    network = LinuxNetwork(fake_module, network_state=False)

    # set up defaults
    network.default_interface_v4 = {'interface': 'eth0'}

# Generated at 2022-06-23 00:06:59.286488
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    """
    Unit test for method LinuxNetwork.populate

    """

    module = AnsibleModule(argument_spec={})
    module.params = {}
    network = LinuxNetwork(module)
    network.populate()
    if 'default_ipv4' in network.facts:
        if 'network' in network.facts['default_ipv4']:
            assert 'default_ipv4' in network.facts
            assert 'default_ipv4' in network.facts['default_ipv4']
            assert 'default_ipv4' in network.facts['default_ipv4']['network']
            assert 'network' in network.facts['default_ipv4']['network']
            assert 'default_ipv6' in network.facts

# Generated at 2022-06-23 00:07:10.171825
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    """
    Test case for constructor of class LinuxNetwork
    """
    # Create a mock module and mock arguments to constructor
    module = MockModule()
    args = MockArgs()
    # Create an instance of class LinuxNetwork with mock module and mock args
    ln = LinuxNetwork(module, args)
    # Check if eth0 interface exist or not in the dictionary
    assert 'eth0' in ln.interfaces
    # Check the type of 'eth0' interface should be ethernet
    assert ln.interfaces['eth0']['type'] == 'ether'
    # Check if eth1 interface exists or not in the dictionary
    assert 'eth1' in ln.interfaces



# Generated at 2022-06-23 00:07:19.292547
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    module = MockModule()
    # NOTE: do not pass module in to make this easier to test
    ln = LinuxNetwork()

    # NOTE: we have to mock the module level get_bin_path method here since it
    #       is being called in populate now
    module.get_bin_path = Mock()
    module.get_bin_path.side_effect = lambda x, required=True: x

    # NOTE: we can't just mock the run_command method on the instance
    #       because it is called from within the class too, so we'll
    #       mock it on the module object itself, and use our own
    #       mock object for the side_effect
    module.run_command = Mock()
    run_command_mock = Mock()
    module.run_command.side_effect = run_command_mock.run_

# Generated at 2022-06-23 00:07:32.870317
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # test_interfaces, test_ips and test_default_routes are defined at
    # module level to reduce indentation
    #   pylint: disable=unused-variable
    #
    # This locally defined function is not detected by pylint
    #   pylint: disable=undefined-variable
    class Module:
        def get_bin_path(self, executable):
            return '/sbin/ip'

        def run_command(self, command, args):
            # The command to be tested will be executed in a subprocess, so
            # use module.exit_json
            def exit_json(**kwargs):
                raise AnsibleExitJson(kwargs)

            # The module executes this method, so stub it here

# Generated at 2022-06-23 00:07:42.502463
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # FIXME: this content is probably outdated
    t_module = AnsibleModule(argument_spec={})
    t_module.run_command = MagicMock(return_value=(0, "", ""))
    linux_network = LinuxNetwork(t_module, '/sbin/ip', 'keep_ipv4')
    t_interfaces, t_ips = linux_network.get_interfaces_info(
        {'address': '192.0.2.1'},
        {'address': '2001:db8::1'}
    )
    assert t_interfaces == {}
    assert t_ips == {}



# Generated at 2022-06-23 00:07:52.206114
# Unit test for constructor of class LinuxNetwork

# Generated at 2022-06-23 00:08:00.503553
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network = LinuxNetwork(module=Mock())
    # Test function populate with simple args
    rc, stdout, stderr = linux_network.module.run_command(['ip', 'route', 'show', '0.0.0.0/0'], errors='surrogate_then_replace')
    assert rc == 0
    output = stdout.split()
    assert len(output) > 0
    default_ipv4_device = output[output.index('dev') + 1]
    rc, stdout, stderr = linux_network.module.run_command(['ip', '-6', 'route', 'show', 'default'], errors='surrogate_then_replace')
    assert rc == 0
    output = stdout.split()
    assert len(output) > 0
    default_ipv6_

# Generated at 2022-06-23 00:08:13.567263
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    test_spec = {
        "data": {
            "features": {
                "rx_checksumming": "on",
                "tx_checksum_sctp": "off",
            },
            "hw_timestamp_filters": [
                "all",
                "none",
            ],
            "phc_index": 0,
            "timestamping": [
                "hardware",
                "software",
                "tx_hardware",
            ],
        },
        "device": "eth0",
    }
    l = LinuxNetwork("module")

# Generated at 2022-06-23 00:08:15.617872
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """ Unit test for method get_interfaces_info of class LinuxNetwork """
    # TODO: add assertions
    pass


# Generated at 2022-06-23 00:08:21.445334
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    # Build an initialized LinuxNetwork object
    fake_module = FakeModule('omit')
    linux_network = LinuxNetwork(fake_module)
    linux_network.get_interfaces_info(None, None, None)
    rc, stdout, stderr = fake_module.run_command.call_args_list[0][0]
    assert rc == 0
    assert stderr == ''
    assert stdout == 'foo'
    fake_module.run_command.reset_mock()
    linux_network.get_interfaces_ip()
    rc, stdout, stderr = fake_module.run_command.call_args_list[0][0]
    assert rc == 0
    assert stderr == ''
    assert stdout == 'foo'
    fake_module.run_command.reset_mock()

# Generated at 2022-06-23 00:08:35.215382
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    import os
    import sys
    import glob
    import struct
    import socket
    import glob
    from tempfile import TemporaryDirectory
    from unittest.mock import patch
    from unittest.mock import MagicMock
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig
    from ansible.module_utils.connection import Connection
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.network.common.netconf import NetworkConfig
    from ansible.module_utils.network.common.netconf import NetworkConfigError
    from ansible.module_utils.network.common.netconf import MockNetconf

# Generated at 2022-06-23 00:08:42.756324
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import os
    import shutil
    import tempfile

    def fake_get_file_content(filename):
        return fake_file_content[filename]

    def fake_module_run_command(command, errors='strict'):
        if command[0] == 'ip -6 addr show dev eth1':
            return 0, fake_ip6_addr_eth1, ''
        elif command[0] == 'ip -6 addr show dev eth2':
            return 0, fake_ip6_addr_eth2, ''
        elif command[0] == 'ip -6 route list scope global':
            return 0, fake_ip6_route_global, ''
        elif command[0] == 'ip -6 route list scope link':
            return 0, fake_ip6_route_link, ''
        return 0, '', ''

# Generated at 2022-06-23 00:08:51.083056
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})

    # setup test values
    rc = 0

# Generated at 2022-06-23 00:09:02.708400
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModuleMock()
    ln = LinuxNetwork(module)

# Generated at 2022-06-23 00:09:14.620407
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import MagicMock

    class FakeModule:
        def __init__(self, module_name):
            self.module_name = module_name
            self.params = {}
            self.check_mode = False
            self.exit_json = MagicMock()
            self.fail_json = MagicMock()
            self.run_command = MagicMock()
            self.run_command.return_value = 0, "", ""
            self.get_bin_path = MagicMock()
            self.get_bin_path.return_value = "ethtool"

    mod = FakeModule("AnsibleModule")
    net = LinuxNetwork(mod)

# Generated at 2022-06-23 00:09:24.824276
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from tempfile import mkdtemp
    import shutil

    def _gen_test_data(path, data):
        for item in data:
            if isinstance(data[item], six.string_types):
                file(os.path.join(path, item), 'wt').write(data[item])
            else:
                os.mkdir(os.path.join(path, item))
                _gen_test_data(path=os.path.join(path, item), data=data[item])

# Generated at 2022-06-23 00:09:37.440364
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Patching a class
    class Mock_Module:
        class Mock_run_command(object):
            def __init__(self, rc, stdout, stderr):
                self.rc = rc
                self.stdout = stdout
                self.stderr = stderr

            def __call__(self, *args, **kwargs):
                # ignoring args
                return (self.rc, self.stdout, self.stderr)

        def __init__(self):
            self.run_command = self.Mock_run_command(0, '', '')

        def get_bin_path(self, path):
            if path == "ip":
                return path
            return None

    module = Mock_Module()
    linux_network = LinuxNetwork(module)
    result = linux_network.get_

# Generated at 2022-06-23 00:09:44.791935
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    # TODO: mock os, os.path and glob
    # emulates /sys/class/net/en*
    with patch("os.walk") as mock_walk:
        with patch("os.path.isdir") as mock_isdir:
            mock_walk.return_value = iter([
                ('/sys/class/net', ('enp0s3', 'enp0s8'), ()),
                ('/sys/class/net/enp0s3', (), ()),
                ('/sys/class/net/enp0s8', (), ())
            ])
            mock_isdir.return_value = True
            network = LinuxNetwork(module)
            interfaces, ips = network.get_inter

# Generated at 2022-06-23 00:09:50.691823
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = MockAnsibleModule()
    # Instantiate the collector class.
    network = LinuxNetworkCollector(module=module)
    # Mock the hostname fact.
    network.facts = {'distribution': 'Ubuntu', 'platform': 'Linux', 'hostname': 'host'}
    fact_file_path = 'files/LinuxNetworkCollector.json'
    with open(fact_file_path) as fact_file:
        json_content = json.loads(fact_file.read())
    # Compare the facts returned by the collector.
    assert network.collect() == json_content


if __name__ == '__main__':
    test_LinuxNetworkCollector()

# Generated at 2022-06-23 00:09:57.065086
# Unit test for method get_default_interfaces of class LinuxNetwork

# Generated at 2022-06-23 00:10:02.066881
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = MockModule()
    linux_network = LinuxNetwork(module)

    assert linux_network.default_ipv4 == {'address': '0.0.0.0'}
    assert linux_network.default_ipv6 == {}
    assert linux_network.module == module

# Generated at 2022-06-23 00:10:10.197247
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    '''
    Test constructor of class LinuxNetwork
    '''
    # Create module
    mod = AnsibleModule(argument_spec={})

    # Create LinuxNetwork instance
    linux_network = LinuxNetwork(module=mod)

    # Test interface_dict
    assert linux_network.interface_dict is not None

    # Test ipv4_dict
    assert linux_network.ipv4_dict is not None

    # Test ipv6_dict
    assert linux_network.ipv6_dict is not None



# Generated at 2022-06-23 00:10:19.075602
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    class PlatformLinux:
        def __init__(self):
            self.system = "Linux"
            self.release = "2.6.32-573.8.1.el6.x86_64"
            self.distribution = "CentOS"
            self.linux_distribution = ['CentOS', '6.8', 'Final']
            self.distribution_release = "CentOS 6.8"

    results = LinuxNetworkCollector.collect(PlatformLinux())
    assert results['interfaces']['eth0']['promisc'] == False



# Generated at 2022-06-23 00:10:22.215237
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = MagicMock()
    module.run_command.return_value = 1, '', ''

    fact = LinuxNetworkCollector(module)
    assert fact.get_facts() is None


# Generated at 2022-06-23 00:10:26.117966
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Note that get_ethtool_data can only be tested as a part of get_interfaces
    # and get_interfaces is tested in test_linux.py as part of test_get_interfaces_info()
    pass

# Generated at 2022-06-23 00:10:29.962147
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    network = LinuxNetwork()
    data = network.populate()
    network.pprint(data)

if __name__ == '__main__':
    test_LinuxNetwork_populate()

# Generated at 2022-06-23 00:10:34.706457
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    if not HAS_PYTHON_NETIFACES:
        module.fail_json(msg=missing_required_lib("python-netifaces"),
                         exception=PYNETIFACES_IMP_ERR)
    if not HAS_PYTHON_IPADDR:
        module.fail_json(msg=missing_required_lib("python-ipaddr"),
                         exception=PYIPADDR_IMP_ERR)
    if not HAS_PYTHON_NETADDRESS:
        module.fail_json(msg=missing_required_lib("python-netaddr"),
                         exception=PYNETADDR_IMP_ERR)

# Generated at 2022-06-23 00:10:46.986436
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():

    class NetworkModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
        def get_bin_path(self, *args, **kwargs):
            return "/bin/ls"
        def run_command(self, *args, **kwargs):
            return 0, "stdout", "stderr"

    class MyFactBase(object):
        def __init__(self, distribution):
            self.distribution = distribution
        def get_distribution(self):
            return self.distribution
        def get_platform(self):
            return 'Linux'

    o = dict(
        module = NetworkModule(
            kind="LinuxNetwork",
            facts = dict(
                distribution = 'RedHat'
            ),
        ),
    )

# Generated at 2022-06-23 00:10:51.936686
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    (is_skip, has_import_error) = import_module()
    if is_skip:
        pytest.skip("Skip this test case since import ansible failed.")
    else:
        assert not has_import_error
        l = LinuxNetwork({}, '/usr/bin/ip', '/sbin/ip')
        assert l.get_interfaces_info("/sbin/ip", {"address":"172.16.3.187"}, {"address":"::1"})

# Generated at 2022-06-23 00:11:02.998181
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModuleMock()
    module.run_command = test_ansible_module_run_command
    linux = LinuxNetwork(module)
    assert linux.get_ethtool_data('eth0') == {}

# Generated at 2022-06-23 00:11:15.372339
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    m = module.ModuleMock({})
    path_exists = m.path_exists
    get_file_content = m.get_file_content
    run_command = m.run_command

# Generated at 2022-06-23 00:11:19.111194
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Test for populate(self, module)

    # FIXME: requires a real module spec
    # FIXME: requires a stubbed module
    assert False



# Generated at 2022-06-23 00:11:28.765929
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    '''
    Unit test for method LinuxNetwork.get_ethtool_data
    '''

    # Test with ethtool binary in PATH
    module_mock = MagicMock()
    setattr(module_mock, 'get_bin_path', MagicMock(return_value='/bin/ethtool'))

    # ethtool returns a non-zero exit code if the interface is not present
    setattr(module_mock, 'run_command', MagicMock(return_value=(1, '', '')))

    linux_network = LinuxNetwork(module_mock)
    result = linux_network.get_ethtool_data('eth0')
    expected_result = {'features': {}, 'timestamping': [], 'hw_timestamp_filters': []}
    assert len(result) == len(expected_result)


# Generated at 2022-06-23 00:11:42.143835
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec=dict())
    ln = LinuxNetwork(module)

    # Success for device wlan0

# Generated at 2022-06-23 00:11:53.251574
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat.mock import patch
    from ansible_collections.misc.not_a_real_collection.tests.unit.modules.utils import set_module_args

    # Parameters for this test function
    pattern = '/sys/class/net/*'
    default_ipv4 = {'address': '192.168.1.1'}
    default_ipv6 = {'address': '::1'}

    # Import module and create class instance to make methods available
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    ln = LinuxNetwork(module)

    # Mock methods

# Generated at 2022-06-23 00:12:03.917859
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = None
    # FIXME: populate mock_module
    ln = LinuxNetwork(module)
    res = ln.populate()
    assert 'ansible_all_ipv4_addresses' in res
    assert 'ansible_all_ipv6_addresses' in res
    assert 'ansible_bond' in res
    assert 'ansible_bridges' in res
    assert 'ansible_devices' in res
    assert 'ansible_default_ipv4' in res
    assert 'ansible_default_ipv6' in res

# Generated at 2022-06-23 00:12:16.064993
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = NetworkModule(argument_spec={}, check_invalid_arguments=False, bypass_checks=True)
    class Bunch(object):
        def __init__(self, **kwds):
            self.__dict__.update(kwds)

# Generated at 2022-06-23 00:12:28.562043
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = FakeModule()
    # We need to mock glob.glob
    # monkeypatch.setattr(glob, 'glob', lambda *args: ["/sys/class/net/%s" % x for x in "enp0s3", "lo", "enp0s8"])

# Generated at 2022-06-23 00:12:30.885614
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    result = LinuxNetworkCollector(dict(module=MockModule()))
    assert isinstance(result, LinuxNetworkCollector)

# Generated at 2022-06-23 00:12:43.129022
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    ln = LinuxNetwork()
    ln.is_changed()
    ln.dump_ifcfg()
    ln.dump_interfaces()
    ln.dump_route()
    ln.dump_iproute()
    ln.get_ip_version()
    ln.get_interface_macaddress()
    ln.expand_interface_range('eth0-eth3')
    ln.get_interfaces()
    ln.get_bond_master()
    ln.get_bridge_members()
    ln.get_module_from_interface()
    ln.get_default_interface()
    ln.get_default_bev4_address()
    ln.get_default_bev6_address()
    ln.get_interfaces_info()



# Generated at 2022-06-23 00:12:52.203009
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule


# Generated at 2022-06-23 00:13:04.382806
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    import tempfile
    test_files = {
        'issue_3666': tempfile.NamedTemporaryFile(prefix='ansible-testfile-', mode='w+t', delete=False),
        'issue_3835': tempfile.NamedTemporaryFile(prefix='ansible-testfile-', mode='w+t', delete=False),
    }

    # write test data

# Generated at 2022-06-23 00:13:16.584814
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    net = LinuxNetwork(module)
    iface, gateways = net.populate()

    assert 'eth0' in iface
    assert iface['eth0']['device'] == 'eth0'
    assert iface['eth0']['mtu'] == 1500
    assert iface['eth0']['promisc'] == False
    assert iface['eth0']['pciid'] == '0000:02:05.0'
    assert iface['eth0']['module'] == 'e1000e'
    assert iface['eth0']['macaddress'] == '00:1d:60:a6:c9:00'

# Generated at 2022-06-23 00:13:29.624493
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six.moves import builtins
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    # TODO: test for ifaces
    # TODO: test for 2ndaries
    # TODO: test for ips
    # TODO: test for routes
    # TODO: test for default_ipv4
    # TODO: test for default_ipv6
    # TODO: test for default_ipv4['alias']

    ansible_module = AnsibleModule({},
        supports_check_mode=False)

    net_info = LinuxNetwork

# Generated at 2022-06-23 00:13:41.827527
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-23 00:13:48.585440
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():

    module = mock.MagicMock()
    module.get_bin_path.return_value = True
    facts = {
        'distribution': 'Linux',
        'platform': 'Linux'
    }
    collector = LinuxNetworkCollector(module, facts)
    assert collector.facts == facts
    assert collector.module == module
    assert collector._platform == 'Linux'
    assert collector._fact_class == LinuxNetwork
    assert collector.required_facts == set(['distribution', 'platform'])



# Generated at 2022-06-23 00:13:56.718021
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.network import NetworkModule
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.facts import Facts
    module = NetworkModule({}, Facts({}, {}, {}))
    network = LinuxNetworkCollector(module)
    assert network.module == module
    assert isinstance(network.facts, Facts)

# Generated at 2022-06-23 00:14:04.926245
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    default_ipv4 = {
        'address': '192.168.16.20',
        'broadcast': '192.168.16.255',
        'netmask': '255.255.255.0',
        'network': '192.168.16.0',
    }
    default_ipv6 = {
        'address': 'fe80::3c4d:f2ff:fe0a:698e',
        'prefix': '64',
        'scope': 'link',
    }
    module = AnsibleModule(argument_spec=dict())
    module.check_mode = False
    module.exit_json = exit_json
    linuxnet = LinuxNetwork(module)

# Generated at 2022-06-23 00:14:15.969221
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Create an instance of LinuxNetwork for testing
    ln = LinuxNetwork()

    # Set module member variables for testing
    ln.module = FakeAnsibleModule()
    ln.module.params = {
            'gather_subset': ['!all', '!min'],
            'gather_network_resources': 'no',
            'filter': '*',
            'config': '/path/to/config',
            'cache': '/path/to/cache',
            'ip_version': 'ipv6',
            'no_log': 'no',
            'additional_network_interfaces': '/path/to/network/interfaces',
            'allow_duplicates': 'no',
        }

    # Pre-configure mock objects

# Generated at 2022-06-23 00:14:28.440096
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """
    This is a unit test to verify that get_ethtool_data() returns the
    expected data.
    """

    # create test data

# Generated at 2022-06-23 00:14:38.989287
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec = dict()
    )
    ln = LinuxNetwork(module)
    assert ln.get_default_interfaces() == (
        dict(
            interface=None,
            address=None,
            netmask=None,
            network=None,
            broadcast=None,
            gateway=None,
        ),
        dict(
            interface=None,
            address=None,
            netmask=None,
            network=None,
            broadcast=None,
            gateway=None,
            scope=None,
        )
    )


# Generated at 2022-06-23 00:14:50.149619
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Initialize the class
    ln = LinuxNetwork()
    # Get interfaces
    interfaces = ln.get_interfaces()
    # Get default ipv4
    default_ipv4, default_ipv6 = ln.get_default_interfaces()
    # Get all ipv4 addresses
    all_ipv4_addresses = ln.get_all_ipv4_addresses()
    # Get all ipv6 addresses
    all_ipv6_addresses = ln.get_all_ipv6_addresses()
    # Get all subinterfaces
    sub_interfaces = ln.get_sub_interfaces()

    # No assertions for now, but code coverage is 100%


# Generated at 2022-06-23 00:14:57.454083
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    test_class = NetworkInfo()
    ip_path = test_class.module.get_bin_path("ip")
    interface_info = test_class.get_interfaces_info(ip_path, {}, {})
    for i in interface_info:
        (default_ipv4, default_ipv6) = test_class.get_default_interfaces(i)
        print(default_ipv4)
        print(default_ipv6)


# Generated at 2022-06-23 00:15:05.264609
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """
    Test module to validate constructor of class LinuxNetworkCollector
    """
    print("Testing main class constructor of LinuxNetworkCollector")
    net = LinuxNetworkCollector()
    print("Validate the platform " + net.platform)
    assert net.platform == "Linux"
    print("Validate the fact_class " + net.fact_class.__class__.__name__)
    assert net.fact_class.__class__.__name__ == "LinuxNetwork"


# Generated at 2022-06-23 00:15:13.652324
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Test with dummy content we don't want to access the real filesystem
    class TestModule(object):
        def get_bin_path(self, name):
            return name


# Generated at 2022-06-23 00:15:17.545643
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Test data for get_ethtool_data
    # Returned object should be a dict with following keys/values
    assert LinuxNetwork({}).get_ethtool_data("") == {}


# Generated at 2022-06-23 00:15:29.991582
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    # running this test requires root privilege, to create named pipes with os.mkfifo
    _original_device_filter_linux = platform.device_filter_linux

    def fake_device_filter_linux(device, *args, **kwargs):
        if 'fake_devices' in kwargs and device.startswith('fake_'):
            return False
        else:
            return _original_device_filter_linux(device, *args, **kwargs)

    platform.device_filter_linux = fake_device_filter_linux
    platform.platform_uname = lambda: ('Linux', 'localhost', '3.10.0-957.5.1.el7.x86_64', '#1 SMP Fri Feb 1 14:54:57 UTC 2019', 'x86_64')

# Generated at 2022-06-23 00:15:41.037658
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    device = dict(name='eth0', ipv4={'address': '10.0.0.1', 'netmask': '255.255.255.0', 'network': '10.0.0.0'}, ipv6={'address': '2001:0db8:85a3:0000:0000:8a2e:0370:7334', 'prefix': '64', 'scope': 'global'}, active=True, macaddress='52:54:00:89:f7:c0', type='ethernet', mtu=1500, promisc=False,
                  features=None, timestamping=None, hw_timestamp_filters=None, phc_index=None)
    module = 'LinuxNetwork'

# Generated at 2022-06-23 00:15:49.551322
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    m = AnsibleModule()
    linux_network = LinuxNetwork(m)
    results = linux_network.populate()
    assert type(results) is dict
    assert results['ipv4']['gateway'] == "127.0.0.1"
    assert results['ipv4']['address'] == "172.16.1.2"
    assert results['ipv4']['netmask'] == "255.255.255.0"
    assert results['ipv4']['network'] == "172.16.1.0"

# Generated at 2022-06-23 00:16:01.530933
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """
    Unit test for constructor of class LinuxNetworkCollector
    """
    network_collector = NetworkCollector(dict(), dict())
    assert network_collector.__class__.__name__ == 'NetworkCollector'

    platform_facts = dict(
        distribution=dict(id='amazon'),
        platform='Linux'
    )
    facts = dict(
        ansible_net_interfaces=[],
        ansible_net_gather_network_resources=[]
    )
    network_collector = NetworkCollector(platform_facts, facts)
    assert network_collector.__class__.__name__ == 'LinuxNetworkCollector'

    system_facts = dict(
        ansible_net_interfaces=[],
        ansible_net_gather_network_resources=[]
    )

# Generated at 2022-06-23 00:16:08.390442
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    n = LinuxNetwork(module)
    assert n is not None
    assert n.module is module
    assert n.ip_path == '/sbin/ip'
    assert n.default_ipv4 is None
    assert n.default_ipv6 is None
    assert n['default_ipv4'] is None
    assert n['default_ipv6'] is None



# Generated at 2022-06-23 00:16:13.976707
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    m = AnsibleModule(argument_spec={})
    linux_net = LinuxNetwork(m)
    ip_path = linux_net.module.get_bin_path('ip')
    v4default, v6default = linux_net.get_default_interfaces(ip_path)
    assert isinstance(v4default, dict)
    assert isinstance(v6default, dict)
    if v4default:
        assert 'address' in v4default
        assert isinstance(v4default['address'], basestring) and v4default['address'] != ''
    if v6default:
        assert 'address' in v6default
        assert isinstance(v6default['address'], basestring) and v6default['address'] != ''



# Generated at 2022-06-23 00:16:26.026576
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    fake_AnsibleModule = Mock(
        check_mode=False,
        debug=False,
        params={},
    )

    def get_bin_path(bin):
        return bin

    fake_AnsibleModule.get_bin_path.side_effect = get_bin_path

    real_run_command = module_utils.linux.network.run_command
    result = []
    values = [
        (0, 'default via 192.0.2.1 dev eth0 proto static', ''),
        (1, 'rtnetlink answers: No such file or directory', ''),
        (2, 'foo', 'bar'),
        (0, '', ''),
    ]
