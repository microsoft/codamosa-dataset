

# Generated at 2022-06-23 00:06:36.031335
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest

    mock_module = unittest.mock.Mock()
    mock_module.run_command.return_value = (0, mock_ethtool_macvlan_out, None)
    interfaces = LinuxNetwork(mock_module).get_interfaces_info(None, {}, {})


# Generated at 2022-06-23 00:06:45.429377
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    def mock_run_command(*args, **kwargs):
        class Object(object):
            pass
        buffer = Object()
        buffer.rc = 255
        return buffer

    module = get_module()
    network = LinuxNetwork(module)
    network.run_command = mock_run_command

    # Test with known output for ip command for version 3.2.0
    # The version number is set in the variable "network.ip_version"
    def mock_run_command_version_3_2_0(*args, **kwargs):
        class Object(object):
            pass
        buffer = Object()
        ip_command = ["/sbin/ip", "route", "get", "to", "8.8.8.8"]

# Generated at 2022-06-23 00:06:59.422374
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # Test with invalid platform and distribution
    module = AnsibleModule(argument_spec={})
    collector = LinuxNetworkCollector(module=module)
    assert not collector.is_valid()
    assert collector.platform == 'Linux'
    assert collector.distribution == ''

    # Test with valid platform, invalid distribution
    module = AnsibleModule(argument_spec={})
    module.params.update({'ansible_facts': {'platform': 'Linux'}})
    collector = LinuxNetworkCollector(module=module)
    assert not collector.is_valid()
    assert collector.platform == 'Linux'
    assert collector.distribution == ''

    # Test with valid platform, invalid distribution
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-23 00:07:12.102296
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    mock_module = unittest.mock.MagicMock()

# Generated at 2022-06-23 00:07:19.845977
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():

    # Test for no interface
    module = AnsibleModule(argument_spec={})
    module.exit_json = Mock()
    ln = LinuxNetwork(module, dict(
        default_ipv4=dict(address="192.168.1.2"),
        default_ipv6=dict(address="fe80::214:9fff:fefc:3b00")
    ))
    ln.get_devices()
    ln.get_default_interfaces()
    ln.get_interfaces_info('/bin/ip', ln.default_ipv4, ln.default_ipv6)
    module.exit_json.assert_called_once_with(changed=False, result={'changed': False})



# Generated at 2022-06-23 00:07:31.000824
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    m = AnsibleModule(argument_spec={}, supports_check_mode=True)
    network_info = NetworkInfo(m)

    # Check for IPv4 address
    assert network_info.default_ipv4

    # Check for IPv6 address
    assert network_info.default_ipv6

    # Check for all_ipv4_addresses
    assert network_info.ips['all_ipv4_addresses']

    # Check for all_ipv6_addresses
    assert network_info.ips['all_ipv6_addresses']

    # Check for network interfaces
    assert network_info.interfaces

# Generated at 2022-06-23 00:07:38.590601
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    ln = LinuxNetwork(module)
    data = ln.populate()
    assert(type(data) == dict)
    assert('interfaces' in data)
    assert('default_ipv4' in data)
    assert('default_ipv6' in data)
    assert('routes' in data)
    assert('routes6' in data)
    assert('dns' in data)



# Generated at 2022-06-23 00:07:46.581086
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Would prefer to use mock.patch here, but it is not available in Ansible 2.6
    module = get_module_mock()
    module.get_bin_path.side_effect = lambda arg: arg
    # Setup
    ln = LinuxNetwork(module)
    # Execute
    ln.populate()
    # Assert
    # TODO: validate interfaces, ip_addresses and default_ipv4 and default_ipv6 values
    #       at least make sure we are not returning empty dicts or strings

# Generated at 2022-06-23 00:07:53.842381
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    nm = LinuxNetwork(module)
    interfaces = nm.interfaces
    default_ipv4 = nm.default_ipv4
    default_ipv6 = nm.default_ipv6
    module.exit_json(
        changed=False,
        ansible_facts=dict(
            ansible_all_ipv4_addresses=nm.ips['all_ipv4_addresses'],
            ansible_all_ipv6_addresses=nm.ips['all_ipv6_addresses'],
            ansible_interfaces=interfaces,
            ansible_default_ipv4=default_ipv4,
            ansible_default_ipv6=default_ipv6,
        )
    )




# Generated at 2022-06-23 00:08:06.678419
# Unit test for method get_default_interfaces of class LinuxNetwork

# Generated at 2022-06-23 00:08:17.285543
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # get_ethtool_data is a method on a class, so we need to instantiate the class
    _module = AnsibleModule(argument_spec=dict())
    ln = LinuxNetwork(_module)

    # ethtool output is actually from the `ethtool -k eth0` command

# Generated at 2022-06-23 00:08:29.723292
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import is_iterable

    import pytest

    # TODO: use as_bytes() instead of to_bytes()
    # TODO: reorganize to share more code
    # TODO: use some sort of test fixtures
    def _run_command(module, command, check_rc=True):

        _rc, _stdout, _stderr = 0, b"", b""

        if check_rc == True:
            if command == module.get_bin_path("ethtool") + ['hello', 'world']:
                _stdout = b"foo\n"
                _stderr = b"bar\n"

# Generated at 2022-06-23 00:08:33.998324
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # pylint: disable=global-statement,protected-access
    global module
    # pylint: enable=global-statement,protected-access

    class MockModule:
        @staticmethod
        def get_bin_path(name, opt_dirs=None):
            if name == 'ip':
                return '/sbin/ip'
            if name == 'ethtool':
                return '/usr/sbin/ethtool'
            return None

        def run_command(self, args, errors='surrogate_then_replace'):
            if args[0] == '/sbin/ip':
                tmp = args[2].split('@')

# Generated at 2022-06-23 00:08:42.266190
# Unit test for method populate of class LinuxNetwork

# Generated at 2022-06-23 00:08:44.216746
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Check it runs
    network = LinuxNetwork()
    network.get_default_interfaces()

# Generated at 2022-06-23 00:08:51.969759
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock()

    linux_network = LinuxNetwork({}, module)

    device = 'test'

    # get_ethtool_data return value with no ethtool_path
    module.get_bin_path.return_value = None
    ret = linux_network.get_ethtool_data(device)
    module.get_bin_path.assert_called_once_with("ethtool")
    assert ret == {}

    # get_ethtool_data return value with no ethtool data
    module.get_bin_path.return_value = True
    module.run_command.return_value = (0, '', '')

# Generated at 2022-06-23 00:09:00.872477
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from .module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    args = {}
    ln = LinuxNetwork(module=module, **args)
    ln.populate()
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6
    assert ln.all_ipv4_addresses
    assert ln.all_ipv6_addresses
    assert ln.distribution



# Generated at 2022-06-23 00:09:13.673321
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    import ansible.module_utils.facts.collector.network.linux_network
    c = LinuxNetworkCollector()

    # Test instantiation
    assert c
    assert c._platform == 'Linux'
    assert c._fact_class.__name__ == 'LinuxNetwork'
    assert c.required_facts == {'distribution', 'platform'}

    # Test get_devices() call through get_device_info()
    # Test with normal output from ip command
    from ansible.module_utils.facts.collector.network.linux_network import Command
    from ansible.module_utils.facts.collector.network.linux_network import NetworkCollector

# Generated at 2022-06-23 00:09:16.447061
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec=dict())
    fail_msg="Failed to create LinuxNetworkCollector object!"
    assert isinstance(LinuxNetworkCollector(module), NetworkCollector), fail_msg



# Generated at 2022-06-23 00:09:22.870297
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    m = AnsibleModule(argument_spec={})
    n = LinuxNetwork(m)
    assert n.has_ipv4 == False
    assert n.has_ipv6 == False
    assert n.interfaces == {}
    assert n.default_ipv4 == {}
    assert n.default_ipv6 == {}
    assert n.all_ipv4_addresses == []
    assert n.all_ipv6_addresses == []



# Generated at 2022-06-23 00:09:27.104996
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(
        argument_spec=dict()
    )
    result = dict(
        ansible_facts=dict(
            network=dict(),
            default_ipv4=dict(),
            default_ipv6=dict(),
            ips=dict()
        ),
        ansible_facts_dictionary=dict(),
        warn=list(),
        failed=False
    )

    # Inject a fake socket.inet_ntoa because we test in a chroot
    socket.inet_ntoa = lambda x: x

    # from linux_network_collector.py (an earlier version)

# Generated at 2022-06-23 00:09:33.301489
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # return value of get_default_interfaces should be a dict of dict defaults
    test = LinuxNetwork()
    default_v4 = {'address': '127.0.0.1'}
    default_v6 = {'address': '::1'}
    assert isinstance(test.get_default_interfaces(default_v4, default_v6), tuple)



# Generated at 2022-06-23 00:09:40.548540
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """Implement unit test for method get_interfaces_info of class LinuxNetwork"""
    class AnsibleModuleMock(object):
        """
        AnsibleModuleMock class will be used to mock AnsibleModule class of ansible
        """
        @staticmethod
        def get_bin_path(binary):
            """
            Method will be used to return binary path
            :param binary: Binary Name
            :return: Binary Path
            """
            if binary == 'ip':
                return '/sbin/ip'
            elif binary == 'ethtool':
                return '/usr/bin/ethtool'
            else:
                return None


# Generated at 2022-06-23 00:09:51.040445
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    """ Test the method get_default_interface of class LinuxNetwork """
    # Create an object of class LinuxNetwork with mock data
    # v4
    mock_v4_stdout = u"\
default via 169.254.0.1 dev eth0 proto static\n\
10.0.0.0/8 dev eth0  proto kernel  scope link  src 10.0.0.11  metric 100\n\
169.254.0.0/16 dev eth0  scope link  metric 100\n\
192.168.0.0/24 dev eth0  proto kernel  scope link  src 192.168.0.10  metric 100\n\
"

    module = AnsibleModuleMock()
    module.run_command = AnsibleModuleMock.run_command

# Generated at 2022-06-23 00:10:03.018423
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule({})
    module.run_command = Mock(return_value=(0, '', ''))
    linux_network = LinuxNetwork(module)

    assert linux_network.get_ethtool_data('foo') == {}

    # return a dump of ethtool -k foo

# Generated at 2022-06-23 00:10:16.019110
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    def get_ansible_module():
        from ansible.module_utils.basic import AnsibleModule
        return AnsibleModule(
            argument_spec={},
            supports_check_mode=True,
        )

    linux_network = LinuxNetwork(get_ansible_module())

    # test with real /sys data
    linux_network.module.sys_path = "/sys"

    interfaces, ips = linux_network.get_interfaces_info(
        linux_network.module.get_bin_path("ip"),
        {"address": "192.168.1.2"},
        {"address": "2001:db8:1:2::a"},
    )

    assert "lo" in interfaces
    assert interfaces["lo"]["active"] is True
    assert interfaces["lo"]["type"] == "loopback"

# Generated at 2022-06-23 00:10:24.393145
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    ln = LinuxNetwork()
    ln.module.run_command = lambda module, device: (0, '', '')

# Generated at 2022-06-23 00:10:32.471164
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    obj = LinuxNetwork()
    # NOTE: empty test
    # we must be able to run this method at any time, it should never fail
    assert obj.get_default_interfaces() == {'interface': {'address': '127.0.0.1', 'broadcast': 'localhost', 'netmask': '255.0.0.0', 'network': '127.0.0.0'}, 'interface': {'address': '::1', 'prefix': '128', 'scope': 'host'}}


# Generated at 2022-06-23 00:10:45.375401
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Allocate an object
    linux_network = LinuxNetwork(None)
    # Mock these objects to be able to run this unit test
    # needed because of the self.module.run_command()
    def get_bin_path(name, opt_dirs=[]):
        return name
    def run_command(args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, prompt=None, environ_update=None, umask=None, encoding=None, errors='surrogate_then_replace', text=False, binary=False, unsafe_shell=False):
        if args[0] == 'ip':
            rc = 1
        else:
            rc = 0
        stdout = 'TODO'
        stder

# Generated at 2022-06-23 00:10:49.509264
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec=dict())
    obj = LinuxNetwork(module)
    assert obj and obj.default_ipv4['address'] == '127.0.0.1'
    assert obj and obj.default_ipv6['address'] == '::1'



# Generated at 2022-06-23 00:10:57.562493
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})

    class FakeConfig:
        class FakeConfigParser:
            def get(self, section, key):
                return '00:11:22:33:44:55'
    class FakeLinuxNetwork(LinuxNetwork):
        def get_config(self):
            return FakeConfig()

    # TODO: figure out class-level mocks
    # @mock.patch.object(LinuxNetwork, 'get_config', return_value=FakeConfig())
    # @mock.patch.object(LinuxNetwork, 'get_default_interfaces')
    # def test_get_interfaces_info(default_mock):
    #     default_mock.return_value = {'v4': {'address': '192.168.122.42'}}, \
    #                                  {'v6

# Generated at 2022-06-23 00:11:10.213545
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule({}, {})
    l = LinuxNetwork(module)

    def set_default(family, cfg, default_value):
        if cfg.startswith('default_'):
            return cfg, family
        raise Exception('unhandled cfg: %s' % cfg)
    module.set_default = set_default

    defaults = [
        ('default_ipv4.address', '1.2.3.4'),
        ('default_ipv4.broadcast', '255.255.255.255'),
        ('default_ipv6.address', 'fe80::1'),
        ('default_ipv6.prefix', '64'),
        ('default_ipv6.scope', 'link'),
        ]

    kwargs = dict(module.params)

# Generated at 2022-06-23 00:11:17.735672
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    opts = []
    clean_args = []
    help_args = []
    options, args = get_module_args(opts, clean_args, help_args, None)
    net = LinuxNetwork(dict(ANSIBLE_MODULE_ARGS=options, ANSIBLE_MODULE_CONSTANTS=dict()), args)
    assert net.get_interfaces_info(None, None, None) is not None



# Generated at 2022-06-23 00:11:27.892385
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    class MockModule:
        def __init__(self, return_value):
            self.all_ipv4_addresses = []
            self.all_ipv6_addresses = []
            self.params = {
                'config': '/etc/sysconfig/network-scripts/',
                'route_path': '/etc/sysconfig/network-scripts/',
                'persistent_device_name': True,
                'name': 'eth0'
            }
            self.results = {}
            self.results[self.params['name']] = {}
            self.results['changed'] = False
            self.return_value = return_value


# Generated at 2022-06-23 00:11:41.141134
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    from collections import namedtuple
    from unittest import mock

    MockReturn = namedtuple('MockReturn', ['rc', 'stdout', 'stderr'])

    class MockModule:
        def run_command(command, errors='surrogate_or_strict'):
            if command[1] == 'route':
                if command[2] == '-n':
                    if command[4] == 'dev':
                        return MockReturn(
                            0,
                            '192.168.1.1',
                            '',
                        )
                    elif command[4] == 'src':
                        return MockReturn(
                            0,
                            '192.168.1.33',
                            '',
                        )

# Generated at 2022-06-23 00:11:52.403574
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = MagicMock(name='module')

    network = LinuxNetwork(module)
    network.get_interfaces_info = MagicMock(name='get_interfaces_info')

# Generated at 2022-06-23 00:12:06.121138
# Unit test for constructor of class LinuxNetworkCollector

# Generated at 2022-06-23 00:12:18.930953
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    DEFAULT_V4, DEFAULT_V6 = {}, {}

# Generated at 2022-06-23 00:12:31.200529
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = Mock()
    ln = LinuxNetwork(module)
    route_info = {
        'v4': {
            'default': {
                'gateway': '192.168.0.1',
                'interface': 'eth0',
            }
        },
        'v6': {
            'default': {
                'gateway': 'fe80::def3:3fff:fe9d:41e8',
                'interface': 'enp0s25',
            }
        }
    }
    expected = [(None, '192.168.0.1', None), ('enp0s25', 'fe80::def3:3fff:fe9d:41e8', 'eth0')]
    assert ln.get_default_interfaces(route_info) == expected

# Generated at 2022-06-23 00:12:33.747077
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    networks = LinuxNetwork()
    assert networks.module


# Generated at 2022-06-23 00:12:39.624736
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
        ),
        supports_check_mode=True,
    )
    nm = LinuxNetwork(module)
    nm.module = module
    nm.load_params()
    nm.populate()
    module.exit_json(changed=False)

if __name__ == '__main__':
    main()

# Generated at 2022-06-23 00:12:50.397578
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """
    Test method get_ethtool_data of Network class.
    """
    import unittest
    import tempfile

    class TestLinuxNetwork(unittest.TestCase):

        def setUp(self):
            import sys
            sys.path.append("..")
            from ansible.module_utils.facts.network import Network

            self.network = Network()

        def test_get_ethtool_data_1(self):
            """
            Test method get_ethtool_data with ethtool present, features present, and timestamping present.
            """
            expected = dict(features=dict(rx_all=False), timestamping=['software', 'hardware'], hw_timestamp_filters=['all'], phc_index=0)
            result = self.network.get_ethtool_data('lo')


# Generated at 2022-06-23 00:13:02.764574
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    m = LinuxNetwork({},  {}, None, None)

    # setup test stubs
    def get_file_content(file, default=None):
        if file == '/sys/class/net/eth0/address':
            return '00:00:00:00:00:00'
        if file == '/sys/class/net/eth0/mtu':
            return '1500'
        if file == '/sys/class/net/eth0/operstate':
            return 'down'
        if file == '/sys/class/net/eth0/device/driver/module':
            return '/sys/module/e1000'
        if file == '/sys/class/net/eth0/type':
            return '1'

# Generated at 2022-06-23 00:13:04.718218
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    network = LinuxNetwork()
    assert network.module.get_bin_path('ip')


# Generated at 2022-06-23 00:13:10.427128
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    with patch('ansible_collections.misc.not_a_real_collection.plugins.module_utils.network.common.platform_debian.Distribution') as mock_dist:
        mock_dist.return_value = mock_dist
        mock_dist.name = 'Debian'
        mock_dist.version = '20.04'
        fact_class_name = 'ansible_collections.misc.not_a_real_collection.plugins.module_utils.network.common.facts.strategies.linux.linux.LinuxNetwork'
        fact_class = import_module(fact_class_name)
        network_collector = LinuxNetworkCollector(module=Mock())
        assert network_collector._platform == 'Linux'
        assert network_collector._fact_class == fact_class
        assert network_collector.required_

# Generated at 2022-06-23 00:13:17.319073
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-23 00:13:19.320970
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # TODO: write this, once we have mockable classes.
    pass


# Generated at 2022-06-23 00:13:28.254606
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = None
    module_utils = AnsibleModule(argument_spec={}, supports_check_mode=True)

    network = LinuxNetwork(module)
    print("Default IPv4: %s" % network.default_ipv4)
    print("Default IPv6: %s" % network.default_ipv6)
    print("Default IPv4 interface: %s" % network.default_ipv4_interface)
    print("Default IPv6 interface: %s" % network.default_ipv6_interface)


# Generated at 2022-06-23 00:13:40.492942
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-23 00:13:50.733257
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    """Unit test for method LinuxNetwork.populate"""
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            gather_network_resources=dict(default=['all'], type='list'),
        )
    )

    # Since we're testing outside of a full playbook run, the network module
    # hasn't been instantiated yet. We need to instantiate it.
    module.params['gather_subset'] = ['!all']
    net = LinuxNetwork(module)

    # Test with an interface that actually exists
    interfaces = net.populate()
    assert 'lo' in interfaces, 'lo is not in the interface dictionary'

# Generated at 2022-06-23 00:14:02.130162
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Testing with /proc/net/route being empty
    module = MagicMock()
    module.check_mode = False
    module.run_command = MagicMock(side_effect=[(0, '', ''), (0, '', '')])

    interface = {'default': {'ipv4': {'default': True}, 'ipv6': {'default': True}}}

    ipv4, ipv6 = LinuxNetwork()._populate(module, interface)

    assert ipv4['default'] == {
        'default': True,
        'gateway': None,
        'interface': None,
        'address': None,
    }
    assert ipv6['default'] == {
        'default': True,
        'gateway': None,
        'interface': None,
        'address': None,
    }



# Generated at 2022-06-23 00:14:14.003993
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    def ip_cmd_v4(*args, **kwargs):
        if len(args[0]) == 1:
            return '2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1400 qdisc pfifo_fast state UP group default qlen 1000\n    link/ether aa:bb:cc:dd:ee:ff brd ff:ff:ff:ff:ff:ff\n    inet 192.168.1.1/24 brd 10.10.10.255 scope global eth0 \n    inet6 fe80::abc:def:abc:def/64 scope link \n       valid_lft forever preferred_lft forever\n'

# Generated at 2022-06-23 00:14:27.275421
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():

    mock_module = MagicMock(name='ansible.module_utils.basic.AnsibleModule')
    mock_module.run_command = MagicMock(name='ansible.module_utils.basic.AnsibleModule.run_command')
    mock_module.get_bin_path = MagicMock(name='ansible.module_utils.basic.AnsibleModule.get_bin_path')
    mock_module.get_bin_path.return_value = '/bin/ip'
    mock_module.run_command.return_value = 0, 'test', 'test'
    mock_module.run_command.return_value = 0, 'test', 'test'

    network = LinuxNetwork(mock_module)

    assert network.ip_path == '/bin/ip'


# Generated at 2022-06-23 00:14:40.737944
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    # Dummy module_args
    module_args = dict(
        config='/etc/sysconfig/network',
        config_path='/etc/sysconfig/network',
        default_ipv4='/etc/sysconfig/network',
        default_ipv6='/etc/sysconfig/network',
        ip_path='/sbin/ip'
    )
    # Populate instance of LinuxNetwork with module_args above
    linux_network = LinuxNetwork(module=None, module_args=module_args)
    # FIXME: validate module_args with AnsibleModule?
    # FIXME: validate populated module_args with AnsibleModule?

    # mock contents of /proc/net/dev

# Generated at 2022-06-23 00:14:53.750440
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    ln = LinuxNetwork()

    ln.module.get_bin_path = MagicMock()
    ln.module.get_bin_path.return_value = '/sbin/ip'
    ln.module.run_command = MagicMock()
    ln.module.run_command.return_value = (0, 'out', 'err')

    ln.get_interfaces_info = MagicMock()
    ln.get_interfaces_info.return_value = ({}, {})

    ln.get_default_interfaces = MagicMock()
    ln.get_default_interfaces.return_value = ({'address': '127.0.0.1'}, {'address': '::1'})

    ln.get_dns_info = MagicMock()
    ln.get

# Generated at 2022-06-23 00:15:06.132586
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule({})

# Generated at 2022-06-23 00:15:08.102378
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module_mock = MagicMock()
    ln = LinuxNetwork(module_mock)

    assert ln
    assert isinstance(ln.module, MagicMock)



# Generated at 2022-06-23 00:15:20.342611
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    unittest.TestCase()

    # if available, use the magic to set the module path from the file location
    # otherwise set it explicitly
    try:
        import inspect
        mod_path = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
    except ImportError:
        mod_path = os.getcwd()
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True,
    )
    # mock the module input parameters
    module.params = {}
    # required arguments that would normally be set by module_utils plugin
    module.params['gather_subset'] = ['!all']
    # instantiate the Linux

# Generated at 2022-06-23 00:15:33.170814
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """This function is used to test the constructor of class LinuxNetworkCollector."""

    # Required parameters for instantiation
    module = AnsibleModule(argument_spec={})

    # Instantiate the LinuxNetworkCollector object
    linux_network_collector = LinuxNetworkCollector(module)

    # Assert that the required_facts set of the object is equal to the required_facts set of the class
    assert linux_network_collector.required_facts == LinuxNetworkCollector.required_facts
    # Assert that the _fact_class set of the object is equal to the _fact_class set of the class
    assert linux_network_collector._fact_class == LinuxNetworkCollector._fact_class
    # Assert that the _platform set of the object is equal to the _platform set of the class
    assert linux_network_collector._platform == LinuxNetwork

# Generated at 2022-06-23 00:15:42.691802
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule({},{})
    ln = LinuxNetwork(module)
    ln.interfaces, ln.ips = ln.get_interfaces_info('/bin/ip', {}, {})
    ln.routes = ln.get_routes()
    ln.gateways = ln.get_gateways()

    # Just one good test, go throught the whole path of populate and check
    # the interfaces provided are correct
    ln.populate()

    assert 'lo' in ln.data['interfaces']
    assert 'eth1' in ln.data['interfaces']
    assert 'eth2' in ln.data['interfaces']
    assert 'eth3' in ln.data['interfaces']
    assert 'eth4' in ln.data['interfaces']

# Generated at 2022-06-23 00:15:45.345848
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    # This call should not raise an exception
    linux_network = LinuxNetwork()


# Generated at 2022-06-23 00:15:57.490826
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # FIXME: use Mock, not a real module
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({}, {})
    linux = LinuxNetwork(module)
    default_ipv4, default_ipv6 = linux.get_default_interfaces()
    interfaces, ips = linux.get_interfaces_info('/sbin/ip',
                                                default_ipv4, default_ipv6)
    print(json.dumps(interfaces, indent=4, sort_keys=True))
    print("All IPv4 addresses:")
    print("\n".join(ips['all_ipv4_addresses']))
    print("All IPv6 addresses:")
    print("\n".join(ips['all_ipv6_addresses']))


# Generated at 2022-06-23 00:16:04.607730
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    set_module_args(dict(
        gather_subset=['all']
    ))

    ln = LinuxNetwork(module)
    # TODO: set up mocks to make this a functional test

    # TODO: figure out how to mock the class methods so you can use the real data

# Generated at 2022-06-23 00:16:15.069898
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    class TestModule:
        def run_command(self, args, **kwargs):
            return (0, "", "")
        def get_bin_path(self, args):
            return "/sbin/ip"

    test_module = TestModule()
    l = LinuxNetwork(test_module, gather_subset=['all'], gather_network_resources=['interfaces', 'ips'])
    interfaces, ips = l.get_interfaces_info("/sbin/ip", {}, {})
    assert 'lo' in interfaces
    assert 'lo' in interfaces
    assert interfaces['lo']['type'] == 'loopback'
    assert interfaces['lo']['mtu'] == 65536
    assert interfaces['lo']['active'] is True

# Generated at 2022-06-23 00:16:26.680692
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    # Arguments
    ip_path = '/tmp/ip'
    default_ipv4 = {
        'address': '192.168.0.2'
    }
    default_ipv6 = {
        'address': 'fe80::621e:6dff:fe69:dd6c'
    }

    # Mock
    class Mock_get_file_content(object):
        def __init__(self, return_value):
            self.return_value = return_value

        def __call__(self, path, default=None):
            if '/sys/class/net/bond0/address' == path:
                return_value = 'B4:69:F4:53:11:12'