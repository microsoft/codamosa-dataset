

# Generated at 2022-06-23 00:06:35.095131
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    net = LinuxNetwork()
    module = get_platform_subclass(AnsibleModule)()

    net.get_default_network_interface = lambda: 'eth0'
    net.get_interfaces_info = lambda a, b, c: ({'eth0': {'ipv4': {'address': '10.1.1.1',
                                                                   'broadcast': '',
                                                                   'netmask': '255.255.255.0',
                                                                   'network': '10.1.1.0'}}}, {})

# Generated at 2022-06-23 00:06:39.795919
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    data = {}
    assert data == LinuxNetwork._get_ethtool_data("eth0")
    data = {
        "features": {},
        "timestamping": [],
        "hw_timestamp_filters": [],
    }
    assert data == LinuxNetwork._get_ethtool_data("eth0")



# Generated at 2022-06-23 00:06:45.654846
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    required_facts = set(['distribution', 'platform'])
    _platform = 'Linux'
    _fact_class = LinuxNetwork

    linux_network_collector = LinuxNetworkCollector()

    assert linux_network_collector.required_facts == required_facts
    assert linux_network_collector._fact_class == _fact_class
    assert linux_network_collector._platform == _platform


# Generated at 2022-06-23 00:06:59.466373
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():

    from ansible.module_utils.basic import AnsibleModule

    class TestModule(object):
        def __init__(self):
            self.run_command_calls = 0
            self.fail_json_calls = 0
            self.exit_json_calls = 0
            self.params = {}

        def get_bin_path(self, opt, required=False, opt_type='s'):
            if opt == 'ip':
                return '/sbin/ip'
            return '/usr/sbin/ethtool'


# Generated at 2022-06-23 00:07:09.629440
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    '''
    Unit test for constructor of class LinuxNetwork
    '''
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import MagicMock
    module = MagicMock()
    ansible_module = MagicMock()
    ansible_module.get_bin_path.return_value = "/bin/ip"
    module.get_bin_path.return_value = "/sbin/ethtool"
    net = LinuxNetwork(module, ansible_module)
    assert net
    assert "/sbin/ethtool" == net.ethtool_path


# Generated at 2022-06-23 00:07:18.980279
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """
    Test get_interfaces_info
    """
    from ansible_collections.os_migrate.os_migrate.plugins.module_utils.network.common import (
        get_file_content,
    )

    # Dummy class to fake module api for mocking and simplify code
    class DummyModule:
        RUN_COMMAND_DEFAULT_ARGS = dict(encoding='utf-8', errors='surrogate_then_replace')
        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg, opt_dirs=None, required=False):
            """Fake get_bin_path by always returning a fake path"""
            return "/bin/fake_bin"


# Generated at 2022-06-23 00:07:32.654054
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    import sys, os
    import tempfile
    from ansible.module_utils import basic

    args = dict(
        device = "eth0",
    )

    module = basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    if not os.path.exists("/usr/bin/ethtool"):
        # skip test if no ethtool
        module.exit_json(skipped=True, msg="ethtool not found, skipping ethtool test")

    network_class = LinuxNetwork(module)

    # Make a fake ethtool so it can be found by get_ethtool_data
    tempdir = tempfile.mkdtemp()
    ethtool_path = os.path.join(tempdir, "ethtool")

# Generated at 2022-06-23 00:07:44.675941
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    interfaces = dict()
    interfaces['lo'] = dict(device='lo', type='loopback', macaddress='00:00:00:00:00:00', mtu=65536, active=True)
    interfaces['eth1'] = dict(device='eth1', type='ether', macaddress='01:23:45:67:89:ab', mtu=1490, active=True)
    interfaces['eth1'].update(vendor='0x8086', model='82574L', speed=1000, duplex='Full', promisc='False', driver='igb', module='igb')

# Generated at 2022-06-23 00:07:47.026234
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = MockAnsibleModule()
    l_network = LinuxNetwork(module)
    assert l_network.module == module


# Generated at 2022-06-23 00:07:54.699153
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import json

    fake_module = FakeModule()
    fake_module.params = {}

    ifaces = LinuxNetwork(fake_module)

    interfaces, ips = ifaces.get_interfaces_info({}, {'address': '8.8.8.8'}, {'address': '::1'})
    assert 'all_ipv4_addresses' in ips
    assert 'all_ipv6_addresses' in ips
    assert 'eth0' in interfaces
    assert 'macaddress' in interfaces['eth0']
    assert 'ipv4' in interfaces['eth0']
    assert 'ipv6' in interfaces['eth0']
    assert 'broadcast' in interfaces['eth0']['ipv4']
    assert 'netmask' in interfaces['eth0']['ipv4']

# Generated at 2022-06-23 00:08:01.923699
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = Mock()
    network = LinuxNetwork(module)
    module.run_command = Mock()
    network.get_default_route = Mock()
    network.get_interfaces_info = Mock()
    network.populate()
    assert module.run_command.call_count == 1
    assert network.get_default_route.call_count == 1
    assert network.get_interfaces_info.call_count == 1


# Generated at 2022-06-23 00:08:09.562510
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec=dict())
    n = LinuxNetwork(module)
    assert n.ip_path
    default_ipv4, default_ipv6 = n.get_default_interfaces()
    assert default_ipv4['address']
    assert not default_ipv6['address']
    assert n.get_interfaces_info(n.ip_path, default_ipv4, default_ipv6)


# Generated at 2022-06-23 00:08:18.929413
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    import os
    import sys
    import unittest

    mock_module = MockModule()

    class FakePopen:
        def __init__(self, cmd, **kwargs):
            self.cmd = cmd
            self.kwargs = kwargs
            self.pid = 123


# Generated at 2022-06-23 00:08:23.235688
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network = LinuxNetwork()
    assert linux_network.get_ethtool_data(None) == {}
    assert linux_network.get_ethtool_data('') == {}


# Generated at 2022-06-23 00:08:36.559611
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    module = MagicMock()
    module.run_command = MagicMock(return_value = (0, '', ''))

    module.get_bin_path = MagicMock(return_value = '/usr/sbin/ip')

    # Create a mock class object
    real_LinuxNetwork = LinuxNetwork(module)

    real_LinuxNetwork.populate()

    # Check call

# Generated at 2022-06-23 00:08:37.970188
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    pass  # TODO: Implement test here



# Generated at 2022-06-23 00:08:40.310500
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    assert NetworkCollector.get_collector(dict(platform='Linux', distribution='CentOS'))


######################################################################################
# *BSD and variants
# FIXME: this seems to only work on FreeBSD

# Generated at 2022-06-23 00:08:46.917557
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    ip_path = '/sbin/ip'
    default_ipv4 = dict()
    default_ipv6 = dict()
    expected = dict(v4=dict(), v6=dict())

    expected['v4']['interface'] = 'eth0'
    expected['v4']['address'] = '192.168.0.1'
    expected['v4']['gateway'] = '192.168.0.254'
    expected['v6']['interface'] = 'eth0'
    expected['v6']['address'] = 'fe80::853:7aff:fefa:7c94'
    expected['v6']['gateway'] = 'fe80::853:7aff:fefa:7c94'

    module = MagicMock()

# Generated at 2022-06-23 00:08:55.552744
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    #
    # A test for get_default_interfaces method of LinuxNetwork class.
    #

    # Setup
    module = AnsibleModule(argument_spec={})

    # Exercise
    linux_network = LinuxNetwork(module)
    default_ipv4, default_ipv6 = linux_network.get_default_interfaces()

    # Verify
    assert 'interface' in default_ipv4
    assert 'interface' in default_ipv6

# Generated at 2022-06-23 00:08:59.095988
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """get_ethtool_data unit tests"""
    module = AnsibleModule(argument_spec={})
    results = dict(changed=False,
                   data={})
    ln = LinuxNetwork(module)
    results = ln.get_ethtool_data("lo")
    assert results["features"]
    assert results["features"]["tx_checksumming"] == "on"
    assert "ipv4" not in results


# Generated at 2022-06-23 00:09:11.177619
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    ret = LinuxNetwork.get_default_interfaces()
    assert ret['ipv4']['network'] == '192.168.0.0'
    assert ret['ipv4']['address'] == '192.168.0.1'
    assert ret['ipv4']['broadcast'] == '192.168.0.255'
    assert ret['ipv4']['netmask'] == '255.255.255.0'
    assert ret['ipv4']['gateway'] == '192.168.0.254'
    assert ret['ipv6']['network'] == '2001:db8:1::'
    assert ret['ipv6']['address'] == '2001:db8:1::1'
    assert ret['ipv6']['prefix'] == '64'
    assert ret

# Generated at 2022-06-23 00:09:13.844578
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule({})
    network = LinuxNetwork(module)
    if not network:
        raise Exception('Failed to instantiate network')


# Generated at 2022-06-23 00:09:21.870357
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Unit test for a method of a class instantiating a mock module
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    # Create object LinuxNetwork, set some arguments
    linux_network = LinuxNetwork(module)
    linux_network.bin_ip = "/usr/bin/ip"

    # Test ipv4
    # Test 1: valid output
    # Test 2: no command output => ipv4 = None
    rc, out, err = (0,
        """
    default via 192.168.122.1 dev eth1  proto static
    default via 192.168.122.1 dev eth1  proto dhcp
    default dev virbr0  proto static
    """, None)
    out_test_1 = out.splitlines()
    out_test_2 = []

# Generated at 2022-06-23 00:09:34.409229
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
  class LinuxNetworkMock(LinuxNetwork):
    def __init__(self, *args, **kwargs):
      pass
    # Wrapper
    def get_default_nic(self):
      return self._get_default_nic()
    def _get_default_nic(self, *args, **kwargs):
      return "eth1"
    def get_ip_route(self):
      return self._get_ip_route()

# Generated at 2022-06-23 00:09:45.178183
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Test with default parameter values
    ln = LinuxNetwork()
    ln.get_interfaces_info = MagicMock()
    ln.get_routes = MagicMock()
    ln.get_interfaces_info.return_value = ({}, {})
    ln.get_routes.return_value = ({}, {})
    ln.populate()
    assert ln.default_ipv4 == {}
    assert ln.default_ipv6 == {}
    ln.get_interfaces_info.assert_called_once_with({}, {}, {})

# Generated at 2022-06-23 00:09:50.658154
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # TODO: this method is getting pretty big, maybe split it up
    ln = LinuxNetwork()

    ln.module = MagicMock(name='module')
    ln.module.run_command = MagicMock(name='run_command')

    ln.module.run_command.return_value = (0, '', '')

    linux_network_data = ln.populate()
    # TODO: asserts



# Generated at 2022-06-23 00:10:02.392606
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Tests that network devices are discovered and parsed correctly
    import os
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import b, next
    from ansible.module_utils._text import to_bytes

    module = AnsibleModule(argument_spec={})

    mock_ipinfo = {
        'default_ipv4': {},
        'default_ipv6': {}
    }
    mock_ips = {
        'all_ipv4_addresses': [],
        'all_ipv6_addresses': []
    }

# Generated at 2022-06-23 00:10:03.670514
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule({})
    c = LinuxNetwork(module)
    module.exit_json(msg=c.result)



# Generated at 2022-06-23 00:10:16.595917
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # test "ethtool -k" parsing

    network = LinuxNetwork()

    test_string = ''
    device = 'test'
    assert network.get_ethtool_data(device) == {}

# Generated at 2022-06-23 00:10:25.761603
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    class MockModule(object):
        def __init__(self, params=None):
            self.params = params

        def run_command(self, cmd, errors='surrogate_then_replace'):
            if cmd == 'ip route get 8.8.8.8':
                if 'default_interface_ipv4' in self.params:
                    return 0, 'default via 192.0.2.1 dev wlp3s0', ''
                else:
                    return 0, '8.8.8.8 via 192.0.2.1 dev wlp3s0', ''

# Generated at 2022-06-23 00:10:29.964547
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    assert LinuxNetworkCollector.platform == 'Linux'
    assert LinuxNetworkCollector._fact_class == LinuxNetwork
    assert LinuxNetworkCollector.required_facts == set(['distribution', 'platform'])

# Generated at 2022-06-23 00:10:32.470917
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    ''' Unit test for constructor of class LinuxNetworkCollector '''
    collector = LinuxNetworkCollector()
    assert collector._platform == 'Linux'



# Generated at 2022-06-23 00:10:40.313638
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    """LinuxNetwork: constructor: return a LinuxNetwok class object"""
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=['!all'], type='list'),
        'gather_network_resources': dict(default=['all'], type='list')
    })
    obj = LinuxNetwork(module)
    assert isinstance(obj, LinuxNetwork)

# Test to see if all the attributes are assigned a value

# Generated at 2022-06-23 00:10:51.707464
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})

    get_bin_path_orig = module.get_bin_path
    def get_bin_path_mock(name):
        if name == 'ethtool':
            return 'ethtool'

        return get_bin_path_orig(name)

    module.get_bin_path = get_bin_path_mock

    run_command_orig = module.run_command
    def run_command_mock(args, errors='surrogate_then_replace'):
        if args[0] == 'ethtool':  # ethtool -k
            return 0, 'Offload parameters for eth0:\ncrc-strip: on\nlarge-receive-offload: on\ngeneric-receive-offload: on\n', ''

# Generated at 2022-06-23 00:11:02.682625
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    m = AnsibleModule({})
    l = LinuxNetwork(m)
    interfaces_info, ips = l.get_interfaces_info('/sbin/ip', {}, {})
    assert 'eth0' in interfaces_info
    eth0_info = interfaces_info['eth0']
    assert 'device' in eth0_info
    assert eth0_info['device'] == 'eth0'
    assert 'ipv4' in eth0_info
    assert 'ipv6' in eth0_info
    assert 'macaddress' in eth0_info
    assert 'mtu' in eth0_info
    assert 'speed' in eth0_info
    assert 'type' in eth0_info
    assert 'features' in eth0_info
    eth0_features = eth0_info['features']

# Generated at 2022-06-23 00:11:15.156045
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.common._collections_compat import UserDict, Mapping
    import socket

    # Create a mock module for test
    class MockModule(object):
        def __init__(self):
            self.params = {'config': 'present'}

        def get_bin_path(self, cmd, **kwargs):
            return cmd

        def run_command(self, args, **kwargs):
            if args[-1] == 'lo':
                return 0, LOOPBACK_DEV_OUTPUT, ''
            elif args[-1] == 'bond1':
                return 0, BOND1_OUTPUT, ''
            elif args[-1] == 'bond3':
                return 0, BOND3_OUTPUT, ''

# Generated at 2022-06-23 00:11:26.552001
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    # Create an instance of LinuxNetwork
    network = LinuxNetwork()
    # Create a list of network interfaces
    interfaces = network.get_interfaces()
    # Create a list of IPv4 and IPv6 routes
    routes = network.get_routes()
    # Create a dictionary of IPv4 and IPv6 interfaces and addresses.
    v4_default_iface, v6_default_iface = network.get_default_interfaces()
    default_ipv4, default_ipv6 = network.get_default_interfaces_addresses(v4_default_iface, v6_default_iface)
    interfaces_info, ips = network.get_interfaces_info('/sbin/ip', default_ipv4, default_ipv6)

    # Test attributes of the LinuxNetwork class

# Generated at 2022-06-23 00:11:39.345471
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    #
    # Initialize LinuxNetwork object
    #
    module = MockModule()
    ln = LinuxNetwork(module=module)

    #
    # Unit test for method populate
    #
    ip_path = module.get_bin_path("ip")
    if ip_path is None:
        module.fail_json(msg='ippath lookup failed')
    else:
        # Define a dict for method populate to populate
        ansible_facts = dict()

        # Define a dict for method get_interfaces_info to populate
        default_ipv4 = dict()
        default_ipv6 = dict()
        default_ipv4['address'] = '192.168.1.1'
        default_ipv6['address'] = '2001:db8::ff00:42:8329'
        ansible_facts

# Generated at 2022-06-23 00:11:50.851371
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import platform

    class get_interfaces_info_stub(object):
        class run_command_stub(object):
            class returncode_stub(object):
                def __init__(self, rc):
                    self.rc = rc

                def rc(self):
                    return self.rc

            def __init__(self, rc, data, err):
                self.rc = rc
                self.data = data
                self.err = err

            def rc(self):
                return self.returncode_stub(self.rc)

            def stdout(self):
                return self.data

            def stderr(self):
                return self.err

        class get_bin_path_stub(object):
            def __init__(self, path):
                self.path = path


# Generated at 2022-06-23 00:12:03.663343
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    from ansible.module_utils.facts.network.linux.network import LinuxNetwork, Interface
    module = FakeModule()
    network = LinuxNetwork(module)
    default_ipv4 = {'address': '1.1.1.1'}
    default_ipv6 = {'address': '::1'}
    interfaces = {
        'eth0':
            Interface('eth0', '00:00:00:00:00:01', '1.1.1.2', [
                Interface('eth0:0', '00:00:00:00:00:01', '1.1.1.1')
            ]),
        'eth1': Interface('eth1', '00:00:00:00:00:01', '2.2.2.1'),
    }

# Generated at 2022-06-23 00:12:12.766176
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    net = LinuxNetwork()
    net.populate()
    assert net.interfaces['lo'] == {'device': 'lo',
                                    'ipv4': {'address': '127.0.0.1'},
                                    'ipv4_secondaries': [],
                                    'ipv6': [{'address': '::1',
                                              'prefix': '128',
                                              'scope': 'host'}],
                                    'module': 'dummy',
                                    'mtu': 65536,
                                    'type': 'loopback'}


# Generated at 2022-06-23 00:12:19.032915
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    net = LinuxNetwork()
    interfaces_before = net.interfaces

    net.populate()

    interfaces_after = net.interfaces
    assert interfaces_after.keys() == interfaces_before.keys()
    for k in interfaces_after.keys():
        for key in interfaces_after[k]:
            assert interfaces_after[k][key] == interfaces_before[k][key]


# Generated at 2022-06-23 00:12:31.252584
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    module = AnsibleModule({})
    module.debug = True

# Generated at 2022-06-23 00:12:43.497662
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    """Test the LinuxNetwork class constructor."""
    module = AnsibleModule(argument_spec={})
    ml = LinuxNetwork(module)
    assert isinstance(ml.module, AnsibleModule)
    assert isinstance(ml.module.fail_json, object)
    assert isinstance(ml.interfaces_mapping, dict)
    assert isinstance(ml.IP_ROUTE_ARGS, dict)
    assert isinstance(ml.IP_LINK_ARGS, dict)
    assert isinstance(ml.IP_LINK_OPTIONS, dict)
    assert isinstance(ml.IP_ADDR_ARGS, dict)
    assert isinstance(ml.IP_ADDR_OPTIONS, dict)
    assert isinstance(ml.INTERFACE_TYPE, dict)
    assert ml.state == 'up'



# Generated at 2022-06-23 00:12:52.373141
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=["!all", "!min"], type='list')
        ),
        supports_check_mode=True
    )
    # creating an instance of the LinuxNetworkCollector class
    collect_net = LinuxNetworkCollector(module)
    # calling the collect method
    # the result of this method call will be the ansible_facts
    facts = collect_net.collect()
    assert 'default_ipv4' in facts
    assert 'interfaces' in facts
    assert 'all_ipv4_addresses' in facts
    assert 'interfaces' in facts
    assert 'all_ipv6_addresses' in facts
    # the following methods can used to test the private functions:
    # facts = collect_net.collect_rout

# Generated at 2022-06-23 00:13:04.534511
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    '''project/ansible/module_utils/network/linux.py unit test'''
    # Set the system to known state
    original_interfaces = {}
    original_interfaces['eth0'] = {'device': 'eth0'}
    original_interfaces['eth1'] = {'device': 'eth1'}
    original_interfaces['eth2'] = {'device': 'eth2'}
    original_interfaces['eth3'] = {'device': 'eth3'}
    original_interfaces['eth0']['ipv4'] = {'address': '1.1.1.1', 'broadcast': '0.0.0.0', 'netmask': '255.255.255.255', 'network': '1.1.1.1'}

# Generated at 2022-06-23 00:13:10.286745
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    result = LinuxNetworkCollector(None)
    assert result._platform == 'Linux'
    assert result._fact_class == LinuxNetwork
    assert result.required_facts == {'distribution', 'platform'}

if __name__ == '__main__':
    # Unit test execution and coverage capture
    import os
    import sys

    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__)))))
    import unittest
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.ansible_release import __version__ as ansible_version


# Generated at 2022-06-23 00:13:17.207573
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch, Mock, MagicMock
    from ansible_collections.notstdlib.moveitallout.plugins.modules import linux_network

    class TestLinuxNetwork(unittest.TestCase):

        def setUp(self):
            self.mock_module = MagicMock()
            self.mock_module.check_mode = False

            self.mock_run_command = MagicMock()
            self.mock_run_command.return_value = (0, '', '')

            self.mock_get_bin_path = MagicMock()
            self.mock_get_

# Generated at 2022-06-23 00:13:18.116393
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    assert LinuxNetwork(None)


# Generated at 2022-06-23 00:13:25.853430
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    from ansible.module_utils import basic

    m = basic.AnsibleModule(argument_spec={})
    n = LinuxNetwork(m)

    ifaces = n.get_default_interfaces()
    assert ifaces['default_ipv4']['address'].count('.') == 3, "Invalid IPv4 default interface"
    assert ifaces['default_ipv6']['address'].count(':') >= 2, "Invalid IPv6 default interface"


# Generated at 2022-06-23 00:13:38.216380
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    ''' Test method get_ethtool_data'''

    class ModuleMock(object):
        ''' Mock class for AnsibleModule '''
        def __init__(self, *_args, **kwargs):
            self.params = kwargs.get('params', dict())
            self.fail_json = kwargs.get('fail_json', dict())

        def get_bin_path(self, arg_str):
            return '/usr/sbin/ethtool'

        def run_command(self, arg_list, errors='surrogate_then_replace'):
            ''' mock run_command for ethtool -k and run_command for ethtool -T'''

# Generated at 2022-06-23 00:13:49.460034
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """
    Unit test for method LinuxNetwork.get_interfaces_info
    """

    mock_module = MockModule(argument_spec={})
    mock_LinuxNetwork = LinuxNetwork(mock_module)
    # we have mock_LinuxNetwork.run_command,
    # we have mock_LinuxNetwork.get_bin_path

    #
    # Mock the get_bin_path return value for ethtool:
    #
    mock_LinuxNetwork.get_bin_path = Mock()
    mock_LinuxNetwork.get_bin_path.return_value = "/usr/bin/ethtool"

    #
    # Mock the run_command return values for ethtool:
    #
    mock_LinuxNetwork.run_command = Mock()

    # ethtool -k eth0
    #
    mock_LinuxNetwork.run_command.side_effect

# Generated at 2022-06-23 00:14:01.159299
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    args = {}
    module = AnsibleModule(argument_spec=dict(args))
    network = LinuxNetwork(module)
    # TODO: verify that we're getting expected data from network
    # pprint(network.facts)
    assert network.facts['default_ipv4']['address'] is not None
    assert network.facts['default_ipv4']['netmask'] is not None
    assert network.facts['default_ipv4']['network'] is not None

    assert network.facts['default_ipv6']['address'] is not None
    assert network.facts['default_ipv6']['prefix'] is not None
    assert network.facts['default_ipv6']['scope'] is not None


# Generated at 2022-06-23 00:14:13.476474
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from ..ansible_collections.ansible.netcommon.tests.unit.compat.mock import Mock, MagicMock
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import get_file_content
    from ansible_collections.ansible.netcommon.tests.unit.plugins.modules.utils import set_module_args

    mocked_module = Mock()
    mocked_facts = MagicMock()
    mock_open = MagicMock()
    mock_open.readline.return_value = '127.0.1.1 hostname'
    mocked_open = (MagicMock())
    mocked_open.side_effect = [mock_open, mock_open]
    mocked_get_file_content = MagicMock(name='get_file_content')
   

# Generated at 2022-06-23 00:14:27.227224
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # In order to test this method, we have to mock the module.run_command()
    # method to return the results we want to test. We have to
    # 1. mock both module.run_command() and module.get_bin_path()
    # 2. mock module.run_command() to return a tuple representing (rc,
    #    stdout, stderr)
    # 3. mock module.get_bin_path() to return a string representing a
    #    non-empty path

    class MockModule():
        def __init__(self):
            self.params = {}

        # FIXME: this method should exist in the Module class
        def get_bin_path(self, cmd, opt_dirs=[]):
            return '/path/to/bin'


# Generated at 2022-06-23 00:14:40.631357
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class LinuxNetwork
    """
    module = AnsibleModule(argument_spec={})
    module.params = {}

    network_module = LinuxNetwork(module)
    # this is the default value on a single interface system
    default_ipv4 = {'interface': 'eth0', 'address': '192.168.122.2'}
    default_ipv6 = {'interface': 'eth0', 'address': 'fe80::a00:27ff:fe1c:b9d6', 'scope': 'link'}

    interfaces, ips = network_module.get_interfaces_info(module.get_bin_path('ip'), default_ipv4, default_ipv6)


# Generated at 2022-06-23 00:14:53.643225
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Create a new instance that happens to work on a Linux machine
    ln = LinuxNetwork()

    # Create a module for use in the populate() method
    class PopulateTestModule(object):
        def get_bin_path(self, arg, required=False):
            if arg == "ip":
                return "/bin/ip"
            else:
                return None
        def run_command(self, args, errors='surrogate_then_replace'):
            if args == ['/bin/ip', 'route', 'get', '1.1.1.1']:
                return (0, "1.1.1.1 via 2.2.2.2 dev eth0  src 3.3.3.3", "")

# Generated at 2022-06-23 00:15:06.082058
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

# Generated at 2022-06-23 00:15:10.650907
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule({})
    nm = LinuxNetwork(module)
    module.exit_json(changed=False, meta=nm.interfaces, default_ipv4=nm.default_ipv4,
                     default_ipv6=nm.default_ipv6, ips=nm.ips)


# ===========================================
# Module execution.
#


# Generated at 2022-06-23 00:15:22.818637
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    import tempfile
    temp_file = tempfile.NamedTemporaryFile()

# Generated at 2022-06-23 00:15:36.025936
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = MockLinuxNetworkModule()
    linux_network = LinuxNetwork(module)
    linux_network.populate()

    assert len(linux_network.interfaces) == 5
    assert linux_network.interfaces['enp4s1']['device'] == 'enp4s1'
    assert linux_network.interfaces['enp4s1']['active'] == True
    assert linux_network.interfaces['enp4s0']['active'] == False
    assert linux_network.interfaces['lo']['active'] == True
    assert linux_network.interfaces['lo']['type'] == 'loopback'
    assert linux_network.interfaces['enp4s1']['ipv4']['address'] == '10.0.0.100'

# Generated at 2022-06-23 00:15:40.824466
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    facts = {
        'distribution': 'Fedora',
        'platform': 'Linux',
        'os_family': 'RedHat',
    }
    required_facts = {
        'distribution',
        'platform',
    }
    nc = LinuxNetworkCollector(facts, NetworkModule())
    assert nc.facts == facts
    assert nc.required_facts == required_facts
    assert nc.platform == 'Linux'
    assert nc.fact_class == LinuxNetwork

# Generated at 2022-06-23 00:15:53.363665
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    # mock a NetworkModule instance
    module = NetworkModule()
    # constructor of LinuxNetwork uses NetworkModule module to run commands on the system
    # mock a helper function of NetworkModule
    module.get_bin_path = lambda *args: "/sbin/ip"
    module.run_command = lambda *args, **kargs: (0, "", "")  # FIXME: this is a bad test, spurious return values

    # test constructor of class LinuxNetwork
    # it should only raise an exception if ip cannot be found
    linux_network = LinuxNetwork(module)
    assert linux_network.ip_path == "/sbin/ip"

    # test get_interfaces_ipv4_info
    # call a method of LinuxNetwork
    ifupdown_config = """
auto lo
iface lo inet loopback
"""
    # mock a

# Generated at 2022-06-23 00:16:05.494775
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    class FakeModule(object):
        def get_bin_path(self, i):
            return i
        def run_command(self, args, errors=None):
            if args == ['ethtool', '-k', 'fake']:
                return 0, "tso: on\nfoo: bar", None
            elif args == ['ethtool', '-T', 'fake']:
                return 0, "capabilities: tx-scheduler offload\n"

# Generated at 2022-06-23 00:16:14.203855
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    if not HAS_NETIFACES:
        # check to see if netifaces module is installed, skip if not
        return
    # default_network = get_default_interfaces()
    interface_ip_addresses = {'enp0s8': ('192.168.0.90', '2001:db8::4', '237.202.23.2'),
                              'lo': ('127.0.0.1', '::1')}
    all_interfaces = get_all_interfaces()

# Generated at 2022-06-23 00:16:26.114256
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """Constructor for LinuxNetworkCollector"""
    # we don't have a class variable _platform in this case
    # so we can't use the test from NetworkCollector
    test_module = type('test_module', (object, ), {'get_bin_path': lambda x, y=0: '/sbin/ip'})

    module = type('test_module_exec', (object, ), {'run_command': lambda x: (0, '', '')})
    setattr(module, 'get_bin_path', test_module.get_bin_path)
    collector = LinuxNetworkCollector(module)
    assert collector._ip_path == '/sbin/ip'
    assert collector._netstat_path == '/bin/netstat'
    assert collector._dig_path == '/usr/bin/dig'

    collector = LinuxNetworkCollect