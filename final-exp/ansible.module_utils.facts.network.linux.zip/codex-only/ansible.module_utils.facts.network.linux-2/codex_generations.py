

# Generated at 2022-06-23 00:06:35.094150
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, "", ""))
    network_info_obj = NetworkInfo(module)
    # I wish I could use mock_open here, but I don't think I can get it
    # to work with the glob that is present in this method

# Generated at 2022-06-23 00:06:45.782406
# Unit test for constructor of class LinuxNetwork

# Generated at 2022-06-23 00:06:52.345624
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    mod = AnsibleModule(
        argument_spec={},
    )
    # noinspection PyTypeChecker
    network_facts = LinuxNetwork(mod)
    # noinspection PyTypeChecker
    result = network_facts.get_default_interfaces()
    assert isinstance(result, tuple)


# Generated at 2022-06-23 00:06:57.462946
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModuleMock()
    collector = LinuxNetworkCollector(module)
    assert(collector.required_facts == LinuxNetworkCollector.required_facts)
    assert(collector._fact_class == LinuxNetworkCollector._fact_class)
    assert(collector._platform == LinuxNetworkCollector._platform)

# Generated at 2022-06-23 00:07:04.546013
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    create_folders = []
    create_links = []
    create_files = []
    # FIXME: files appear to be populated backwards
    # FIXME: We need to handle folders, symlinks, and files
    create_files.append(("/proc/net/route", """Iface\tDestination\tGateway \tFlags\tRefCnt\tUse\tMetric\tMask\t\tMTU\tWindow\tIRTT
eth0\t00000000\t0A00A8C0\t0003\t0\t0\t0\t00000000\t0\t0\t0
eth0\t00A8C0EA\t00000000\t0001\t0\t0\t0\t00FFFFFF\t0\t0\t0
""", 0o0400))
    create

# Generated at 2022-06-23 00:07:12.285651
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    """Test :meth:`ansible_collections.notstdlib.moveitallout.plugins.modules.network_tools.LinuxNetwork._get_default_interfaces`."""

    module = MagicMock()
    module.get_bin_path.return_value = True
    module.run_command.return_value = 0, "", ""

    network = LinuxNetwork(module)
    result = network._get_default_interfaces()

    assert result == {'ipv4': {}, 'ipv6': {}}

# Generated at 2022-06-23 00:07:19.500084
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule({})
    # Would be better to use a Mock, but I'm not sure how to implement that
    module.run_command = lambda x: (0, 'eth0\n', '')

    network = LinuxNetwork(module)

    # We need to call the method
    network.get_default_interfaces()
    # And check the result
    assert 'interface' in network.default_interface['ipv4']
    assert 'macaddress' in network.default_interface['ipv4']
    assert 'interface' in network.default_interface['ipv6']
    assert 'macaddress' in network.default_interface['ipv6']



# Generated at 2022-06-23 00:07:32.873345
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():

    class mock_module():
        def __init__(self):
            self.params = dict()
        def get_bin_path(self, name):
            return "/usr/sbin/ip"

    class mock_os():
        def __init__(self):
            self.path = dict()
        def isdir(self, variable):
            return True
        def path(self):
            return self
        def join(self, path, variable):
            return path + variable
        def readlink(self, path):
            return path
        def exists(self, path):
            return True
        def glob(self, path):
            return path

    class mock_glob():
        def __init__(self):
            self.glob = dict()
        def glob(self, path):
            return path


# Generated at 2022-06-23 00:07:35.686687
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)
    interface_ipv4, interface_ipv6 = network.get_default_interfaces()
    assert isinstance(interface_ipv4, dict)
    assert isinstance(interface_ipv6, dict)

# Generated at 2022-06-23 00:07:47.497790
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Tests only methods that do not require root permissions
    my_network = NetworkLinux()
    interfaces, ips = my_network.get_interfaces_info("/bin/ip", {}, {})

# Generated at 2022-06-23 00:07:56.732495
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    # Create an instance of LinuxNetwork
    # The constructor of LinuxNetwork is only for unit test
    class FakeModule(object):
        def __init__(self, *args, **kwargs):
            pass
    m = FakeModule()
    network = LinuxNetwork(module=m)

    # Test method get_config_attr
    assert network.get_config_attr('ifcfg-eth0', 'BOOTPROTO') == 'dhcp'
    assert network.get_config_attr('ifcfg-eth0', 'DEVICE') == 'eth0'
    assert network.get_config_attr('ifcfg-eth1', 'BOOTPROTO') == 'static'
    assert network.get_config_attr('ifcfg-eth1', 'IPADDR') == '192.0.2.1'
    assert network.get_config_attr

# Generated at 2022-06-23 00:07:58.855726
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    assert LinuxNetwork(module=module).__class__.__name__ == 'LinuxNetwork'


# Generated at 2022-06-23 00:08:01.376119
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    linux_network = LinuxNetwork()
    print(linux_network)

# unit test for get_interfaces_info()

# Generated at 2022-06-23 00:08:12.642418
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """
    This function will test the method get_interfaces_info of the class LinuxNetwork
    """
    module = AnsibleModule(argument_spec=dict())

    linux_network = LinuxNetwork(module)
    default_ipv4 = {}
    default_ipv6 = {}
    interfaces, ips = linux_network.get_interfaces_info("ip", default_ipv4, default_ipv6)
    assert_is_instance(interfaces, dict)
    assert_is_instance(ips, dict)
    assert_dict_equal(ips, dict(all_ipv4_addresses=[], all_ipv6_addresses=[]))



# Generated at 2022-06-23 00:08:20.118184
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = Mock()
    module.get_bin_path = Mock(return_value="/bin/ip")

# Generated at 2022-06-23 00:08:29.262003
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    assert ln.ip_path
    assert ln.module
    # FIXME: check the values of the next items
    assert ln.interface_path
    assert ln.routes
    assert ln.interfaces
    assert ln.default_ipv4
    assert ln.default_ipv6


# Generated at 2022-06-23 00:08:40.180299
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    ln = LinuxNetwork(module)
    assert 'features' not in ln.get_ethtool_data('foobar')

    # This test will fail if the system doesn't have an eth0 device
    ethtool_path = ln.module.get_bin_path("ethtool")
    if ethtool_path:
        assert 'features' in ln.get_ethtool_data('eth0')
        assert 'timestamping' in ln.get_ethtool_data('eth0')
        assert 'hw_timestamp_filters' in ln.get_ethtool_data('eth0')
        assert 'phc_index' in ln.get_ethtool_data('eth0')
        assert l

# Generated at 2022-06-23 00:08:49.445064
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    class FakeModule:
        module_utils = "ansible.module_utils.network"

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            return "/bin/ip"

        def run_command(self, arg, errors='surrogate_then_replace'):
            return 0, "", ""

    module = FakeModule()

    ln = LinuxNetwork(module)

    facts = {}

    ln.populate(facts)
    assert facts

    # test with a value in default_ipv4
    ln_default_ipv4 = LinuxNetwork(module)
    ln_default_ipv4.default_ipv4 = {'address': '10.0.0.1', 'device': 'eth0'}
    ln_default_ipv4.populate

# Generated at 2022-06-23 00:08:55.126830
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linuxnet = LinuxNetwork()
    linuxnet.module = MagicMock()
    linuxnet.get_default_interfaces = MagicMock()
    linuxnet.get_interfaces_info = MagicMock()
    rc = linuxnet.populate()
    assert rc == None


# Generated at 2022-06-23 00:09:03.356729
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """
    Constructor for class LinuxNetworkCollector
    """
    network1 = LinuxNetworkCollector({'distribution': 'distro', 'platform': 'Linux'}, [], None)
    assert isinstance(network1, NetworkCollector)
    assert isinstance(network1, LinuxNetworkCollector)
    assert not hasattr(network1, '_distro')
    assert hasattr(network1, 'required_facts')
    assert hasattr(network1, '_platform')
    assert network1.required_facts == set(['distribution', 'platform'])
    assert network1._platform == 'Linux'
    assert network1._fact_class == LinuxNetwork


# Generated at 2022-06-23 00:09:15.229766
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    linux_network_obj = LinuxNetwork(module)

    expected_default_ipv4 = {
        'address': '127.0.0.1',
        'broadcast': '127.255.255.255',
        'netmask': '255.0.0.0',
        'network': '127.0.0.0',
        'macaddress': '00:00:00:00:00:00',
        'mtu': 65536,
        'type': "loopback",
        'alias': 'lo'
    }


# Generated at 2022-06-23 00:09:22.703978
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    class MockModule:
        def get_bin_path(self, path, opt_dirs=[]):
            return '/sbin/ip'

        def run_command(self, args, check_rc=True):
            return 0, '', ''
    module = MockModule()
    n = LinuxNetwork(module)
    command = {
        'v4': ['/sbin/ip', '-4', 'route', 'get', '169.254.169.254', 'oif', 'metric', '100'],
        'v6': ['/sbin/ip', '-6', 'route', 'get', 'fe80::1', 'oif', 'metric', '100'],
    }

# Generated at 2022-06-23 00:09:34.136980
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Calling method (code under test)
    netinfo = LinuxNetwork()
    netinfo.populate()
    # Testing the results
    result = netinfo.interfaces
    expected = {
        'lo': {
            'device': 'lo',
            'type': 'loopback',
            'ipv4': {
                'address': '127.0.0.1',
                'netmask': '255.0.0.0',
                'network': '127.0.0.0'
            },
            'ipv6': [
                {
                    'address': '::1',
                    'prefix': '128',
                    'scope': 'host'
                }
            ]
        }
    }
    assert result == expected


# Generated at 2022-06-23 00:09:36.535694
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    import pytest
    from ansible.module_utils.facts.network.base import NetworkCollector
    assert issubclass(LinuxNetworkCollector, NetworkCollector)
    assert LinuxNetworkCollector._platform == 'Linux'


# Generated at 2022-06-23 00:09:44.013026
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    '''
    Unit test for method get_ethtool_data of class LinuxNetwork
    '''

    # the output of ethtool -k command

# Generated at 2022-06-23 00:09:49.238883
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec=dict())
    obj = LinuxNetwork(module)
    module.exit_json(changed=False,
                     ansible_facts=dict(network=obj.get_network_facts()))

# standard ansible module imports
from ansible.module_utils.basic import *
from ansible.module_utils.facts import *
if __name__ == '__main__':
    main()

# Generated at 2022-06-23 00:09:50.596714
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # TODO: test with real file content?
    return LinuxNetworkCollector(None, None)



# Generated at 2022-06-23 00:10:02.392681
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # set host and port
    zabbix_host = '127.0.0.1'
    zabbix_port = 10050

    # init zabbix sender
    zabbix_sender = ZabbixMetricSender(zabbix_host, zabbix_port)

    # init module
    module = AnsibleModule(
        argument_spec = dict(
            zabbix_host = dict(required=False, default=zabbix_host),
            zabbix_port = dict(required=False, type='int', default=zabbix_port)
        ),
        supports_check_mode = True
    )
    # set fact

# Generated at 2022-06-23 00:10:15.436869
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # TODO: this unit test should be part of a bigger test suite
    # TODO: this unit test should be much more comprehensive
    # TODO: this unit test should use a mock

    # create the LinuxNetwork object
    module = AnsibleModule(argument_spec={})
    net = LinuxNetwork(module)

    # run the method under test
    result = net.get_default_interfaces()

    # check the result
    if 'default_ipv4' not in result:
        assert False, 'missing default_ipv4'
    if 'default_ipv6' not in result:
        assert False, 'missing default_ipv6'
    if 'default_ipv4' in result and 'default_ipv6' in result:
        assert False, 'both IPv4 and IPv6 are the default, this cannot be true'



# Generated at 2022-06-23 00:10:19.306606
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = NetworkModule(argument_spec={})
    lnc = LinuxNetworkCollector(module)
    assert lnc._platform == 'Linux'
    assert lnc._fact_class == LinuxNetwork
    assert lnc.required_facts == set(['distribution', 'platform'])

# Generated at 2022-06-23 00:10:26.199572
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec=dict(
        config_file=dict(type='path', default=['/etc/network/interfaces']),
        config_dir=dict(type='path', default='/etc/sysconfig/network-scripts/'),
        config_dir_abspath=dict(type='bool', default=True),
        running_config_path=dict(type='path', default='/run/network/ifstate'),
        allow_network_kinds=dict(type='list', default=['bridge', 'bond', 'slave']),
        exclude_interfaces=dict(type='list', default=[]),
    ))
    linux_network = LinuxNetwork(module)
    linux_network.populate()

# Generated at 2022-06-23 00:10:38.975167
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import unittest
    import ansible.constants
    ansible.constants.DEFAULT_SUDO_USER = 'ansible'

    mock_module = AnsibleModule(argument_spec={'name': dict(type='str', default='asdf')})
    mock_module.run_command = MagicMock(return_value=(0, '', ''))

    linux_net = LinuxNetwork(mock_module)
    interfaces, ips = linux_net.get_interfaces_info(None, {}, {})
    
    for key in interfaces.keys():
        if ':' in key:
            assert key == key.replace(':', '_')
        else:
            assert key == key

    assert interfaces['asdf']['device'] == 'asdf'



# Generated at 2022-06-23 00:10:40.905563
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    ln = LinuxNetwork(module)

    # TODO: test other methods

# Generated at 2022-06-23 00:10:46.958105
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    class MockModule:
        def __init__(self):
            self.run_command = lambda cmd, error=None: (0, "", "")
            self.get_bin_path = lambda cmd: cmd
        class MockAnsibleModule:
            def __init__(self):
                self.params = {}
            def fail_json(self, **kwargs):
                pass

    # Arrange
    mock_module = MockModule()
    module = LinuxNetwork(mock_module.MockAnsibleModule())
    default_ipv4 = {}
    default_ipv6 = {}

    # Act
    results = module.get_interfaces_info("foo", default_ipv4, default_ipv6)

    # Assert
    assert results is not None
    assert len(results) == 2

# Generated at 2022-06-23 00:10:55.478823
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    if not HAS_NETIFACES:
        module.fail_json(msg='netifaces is required for this module')
    if not HAS_IPADDR:
        module.fail_json(msg='ipaddr is required for this module')

    ln = LinuxNetwork(module)
    interfaces, ips = ln.get_interfaces_info(ln.ip_path, ln.default_ipv4, ln.default_ipv6)
    routing4, routing6 = ln.get_routing_info(ln.ip_path)

    # FIXME: add asserts
    return (interfaces, ips, routing4, routing6)


# Generated at 2022-06-23 00:11:08.239495
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible.module_utils import basic
    from ansible.module_utils.network.common.utils import transform_commands
    module = basic.AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['all'], type='list')
        ),
        supports_check_mode=True
    )

    # Instantiate class under test
    obj = LinuxNetwork(module)

# Generated at 2022-06-23 00:11:14.399628
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    ln = LinuxNetwork()
    ln.add_default_links()
    ln.add_default_lo_interface()

    ln.add_new_interface('eth0', '00:0c:29:ef:f6:0c', '10.0.0.23', '255.255.255.0')
    ln.add_new_interface('eth1', '00:0c:29:ef:f6:0d', '192.168.0.23', '255.255.255.0')
    ln.add_new_interface('eth2', '00:0c:29:ef:f6:0e', '172.16.0.2', '255.255.252.0')

# Generated at 2022-06-23 00:11:19.803393
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    r = LinuxNetwork(module)
    assert isinstance(r.INTERFACE_TYPE, dict)
    assert r.INTERFACE_TYPE['1'] == 'loopback'
    print("Successfully passed constructor test for LinuxNetwork")


# Generated at 2022-06-23 00:11:27.737081
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    test_module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', elements='str'),
            gather_network_resources=dict(type='list', elements='str', default=list()),
            timeout=dict(type='int', default=10),
        ),
        supports_check_mode=True,
    )
    test_module.exit_json = exit_json
    test_module.fail_json = fail_json

    ln = LinuxNetwork(test_module)
    ln.populate()

if __name__ == '__main__':
    test_LinuxNetwork_populate()

# Generated at 2022-06-23 00:11:40.975935
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    def fake_run_command(self, args, encoding=None, errors=None, data=None, binary_data=False, check_rc=True,
                         close_fds=True, executable=None, cwd=None, path_prefix=None, shell=None,
                         env_update=None, use_unsafe_shell=None):
        fake_run_command.call_count += 1
        if fake_run_command.call_count == 1:
            return (0, "", "")
        elif fake_run_command.call_count == 2:
            return (0, "", "")

# Generated at 2022-06-23 00:11:43.363902
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = MockModule(argument_spec={})
    network = LinuxNetwork(module)
    assert network.module == module

# Module execution

# Generated at 2022-06-23 00:11:49.001298
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # expected values
    dev = 'eth0'
    path = '/sys/class/net/' + dev

# Generated at 2022-06-23 00:11:53.042340
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule({})
    network = LinuxNetworkCollector(module).collect()
    assert 'default_ipv4' in network
    assert 'default_ipv6' in network
    assert 'interfaces' in network
    assert 'all_ipv4_addresses' in network
    assert 'all_ipv6_addresses' in network


if __name__ == '__main__':
    main()

# Generated at 2022-06-23 00:12:06.932106
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils import basic
    from ansible.module_utils.network.linux.interface.alias import Alias
    from ansible.module_utils.network.common.utils import to_list
    from ansible.module_utils.network_lsr.distro.linux import NetworkModule
    sys.modules["ansible_module_utils.network.linux.interface.alias"] = basic.AnsibleModule(
        argument_spec={}
    )
    sys.modules["ansible.module_utils.network.linux.interface.alias"].Alias = Alias
    sys.modules["ansible.module_utils"] = basic
    sys.modules["ansible_module_utils"] = basic
    sys.modules["ansible.module_utils.network"] = basic

# Generated at 2022-06-23 00:12:08.852170
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    network = LinuxNetwork()
    device = network.get_default_interface()
    assert device



# Generated at 2022-06-23 00:12:21.956297
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    class TestModule(object):
        # NOTE: not the same as ansible.module_utils.basic.AnsibleModule
        def __init__(self, rc, stdout, stderr):
            self.rc = rc
            self.stdout = stdout
            self.stderr = stderr

        def run_command(self, args, errors='surrogate_then_replace'):
            """
            mimic the signature of a ansible.module_utils.basic.AnsibleModule.run_command
            """
            return self.rc, self.stdout, self.stderr

        def get_bin_path(self, path):
            return path

    # FIXME: consolidate with the other test_get_ethtool_data tests
    # ethtool_path is not None
    rc, stdout, stderr

# Generated at 2022-06-23 00:12:23.176619
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    assert(True)


# Generated at 2022-06-23 00:12:36.026855
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    network = LinuxNetwork(module)
    facts = network.get_network_facts()

    # normal facts are all string, convert them to string
    assert isinstance(facts['default_ipv4']['address'], str)
    assert isinstance(facts['default_ipv4']['netmask'], str)
    assert isinstance(facts['default_ipv4']['gateway'], str)
    assert isinstance(facts['default_ipv4']['broadcast'], str)
    assert isinstance(facts['default_ipv4']['network'], str)
    assert isinstance(facts['default_ipv4']['macaddress'], str)


# Generated at 2022-06-23 00:12:39.119315
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    ifaces_data = LinuxNetworkIface(module)
    return ifaces_data is not None



# Generated at 2022-06-23 00:12:50.005446
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    from ansible_collections.notmintest.not_a_real_collection.tests.unit.compat.mock import MagicMock

    module = MagicMock()

    # Without default_interface module argument
    default_interface_value = None

    ln = LinuxNetwork(module, default_interface=default_interface_value)

    assert ln.default_interface == default_interface_value
    assert ln.default_interface_ipv4 == {}
    assert ln.default_interface_ipv6 == {}

    # With default_interface module argument

    default_interface_value = "eth0"
    line1 = "default         via 1.2.3.4 dev eth0"
    line2 = "2001:1234:abcd:1::/64 dev eth0 proto kernel metric 1024 pref medium"

    module.run_

# Generated at 2022-06-23 00:13:02.307504
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = NetworkModule(argument_spec=dict(), supports_check_mode=True)
    # FIXME: this should perhaps be mocked
    module.run_command = lambda *args, **kwargs: ('', '', 0)
    module.get_bin_path = lambda *args, **kwargs: ''
    # FIXME: this should perhaps be mocked
    ip_path = module.get_bin_path('ip')
    if not ip_path:
        raise Exception("ip_path is not set")
    default_ipv4 = {
        'address': '',
        'broadcast': '',
        'netmask': '',
        'network': '',
    }
    default_ipv6 = {
        'address': '',
        'prefix': '',
        'scope': '',
    }
    collector = Linux

# Generated at 2022-06-23 00:13:04.966111
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec=dict())
    lnc = LinuxNetworkCollector(module)
    assert lnc.platform == 'Linux'


# Generated at 2022-06-23 00:13:17.204336
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # simple fake class to pass as self
    class FakeModule:
        def __init__(self):
            self.run_command = lambda *args, **kwargs: ('', '', '')

    fake_module = FakeModule()

    # mock the get_bin_path function of class FakeModule to return a given path
    # if the expected path is given
    original_get_bin_path = fake_module.get_bin_path
    def mock_get_bin_path(self, path):
        if path == 'ethtool':
            return '/path/to/ethtool'
        else:
            return original_get_bin_path(path)

    fake_module.get_bin_path = types.MethodType(mock_get_bin_path, fake_module)

    # create a test instance of the class LinuxNetwork to be

# Generated at 2022-06-23 00:13:30.067908
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4 = dict(interface='eth0', address='10.0.0.1', netmask='255.255.255.0', network='10.0.0.0')
    default_ipv6 = dict(interface='eth0', address='fe80::1', scope='link')
    interfaces, ips = ln.get_interfaces_info(None, default_ipv4, default_ipv6)
    assert interfaces['eth0']['ipv4']['address'] == '10.0.0.1'
    assert interfaces['eth0']['ipv4']['broadcast'] == '10.0.0.255'

# Generated at 2022-06-23 00:13:42.586923
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():

    data = {}

# Generated at 2022-06-23 00:13:45.697961
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = DummyAnsibleModule()
    ac = LinuxNetwork(module)
    # Test for populate()
    ac.populate()
    assert ac.module.exit_json.called


# Generated at 2022-06-23 00:13:46.618569
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    LinuxNetworkCollector().collect()


# Generated at 2022-06-23 00:13:59.460970
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # TODO: mock out the IPv6 command and assert things about the IPv6 commands
    # we expect to see
    ipv6_route = dict(
        cmd=['/sbin/ip', '-6', 'route'],
        ignoreerrors=True,
    )
    ipv6_address = dict(
        cmd=['/sbin/ip', '-6', 'addr', 'show'],
        ignoreerrors=True,
    )

    results = dict(
        default_ipv4={'iface': 'eth0', 'address': '127.0.0.1'},
        default_ipv6={'iface': 'eth0', 'address': '::1'}
    )
    results.update(ipv6_route=ipv6_route, ipv6_address=ipv6_address)

# Generated at 2022-06-23 00:14:12.690547
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    l = LinuxNetwork(module)
    d = {}
    ips = {}
    l.populate(d, ips)

    assert 'default_ipv4' in d
    assert 'default_ipv6' in d
    assert 'interfaces' in d
    assert 'all_ipv4_addresses' in ips
    assert 'all_ipv6_addresses' in ips
    assert isinstance(d['default_ipv4'], dict)
    assert isinstance(d['default_ipv6'], dict)
    assert isinstance(d['interfaces'], dict)
    assert isinstance(ips['all_ipv4_addresses'], list)

# Generated at 2022-06-23 00:14:19.953359
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    '''
    Test if the constructor of LinuxNetworkCollector creates the correct object
    '''
    my_obj = LinuxNetworkCollector(None)
    assert my_obj
    assert my_obj._platform == 'Linux'
    assert my_obj._fact_class == 'LinuxNetwork'
    assert my_obj.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-23 00:14:21.036808
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    pass

# Generated at 2022-06-23 00:14:29.265142
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    ifaces = linux_network.get_default_interfaces()
    assert ifaces['default_ipv4']['interface'] == 'lo'
    assert ifaces['default_ipv6']['interface'] == 'lo'
    assert ifaces['default_ipv4']['address'] == '127.0.0.1'
    assert ifaces['default_ipv6']['address'] == '::1'



# Generated at 2022-06-23 00:14:35.216701
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # Test if Platform is Linux, and if the class LinuxNetwork exists
    c = LinuxNetworkCollector()
    assert c.platform == 'Linux' and c._fact_class is LinuxNetwork

    # Test if the required facts in LinuxNetworkCollector() are in fact
    # required
    assert c.required_facts == set(['distribution', 'platform'])

# Generated at 2022-06-23 00:14:48.662824
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    net = LinuxNetwork()
    net.module = type('module', (), {
        'get_bin_path': lambda *args, **kwargs: None
    })()
    net.dns = {
        'domain': 'example.com',
        'search': [],
        'nameservers': [
            '1.1.1.1', '1.0.0.1',
        ],
        'sortlist': [
            ('192.168.1.0', '255.255.255.0'),
            ('192.168.2.0', '255.255.255.0'),
        ],
    }

# Generated at 2022-06-23 00:15:00.400420
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    #
    # Unit test for "get_interfaces_info"
    #
    class Options(object):
        def __init__(self):
            self.params = []

    class Module(object):
        def __init__(self):
            self.debug = False
            self.verbose = False
            self.logger = logging.getLogger(self.__class__.__name__)
            self.logger.addHandler(logging.NullHandler())

        def get_bin_path(self, arg, default=None):
            print('get_bin_path(%s) -> %s' % (arg, default))
            return default


# Generated at 2022-06-23 00:15:11.464390
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-23 00:15:22.916619
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    mock_obj = MagicMock()
    mock_obj.get_bin_path.return_value = False
    ln = LinuxNetwork(module)
    ln.get_bin_path = mock_obj.get_bin_path
    ln.get_default_interface_from_route = mock_obj.get_default_interface_from_route
    ln.get_default_interfaces_from_ip = mock_obj.get_default_interfaces_from_ip
    ln.get_interfaces_info = mock_obj.get_interfaces_info
    ln.get_interfaces_from_ip = mock_obj.get_interfaces_from_ip
    ln.get_interfaces_from_route = mock_obj.get_interfaces_from

# Generated at 2022-06-23 00:15:36.118201
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # monkey patch the module to not need module_utils.network
    from ansible.module_utils.basic import get_exception
    from ansible.module_utils import basic
    basic.ANSIBLE_VERSION = '2.4.3.0'
    def get_module_path(*args, **kwargs):
        return os.path.dirname(__file__)
    def get_bin_path(module, *args, **kwargs):
        return os.path.join(os.path.dirname(__file__), "bin")
    setattr(basic, 'get_module_path', get_module_path)
    setattr(basic, 'get_bin_path', get_bin_path)
    class FakeModule():
        def __init__(self):
            self.params = {}

# Generated at 2022-06-23 00:15:40.192233
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    network_for_test = LinuxNetworkCollector(None)
    assert network_for_test.platform == 'Linux'
    assert network_for_test.fact_class == LinuxNetwork
    assert network_for_test.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-23 00:15:42.213418
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    ''' Constructor test
    >>> module = FakeModule()
    >>> linux_network = LinuxNetwork(module)
    FIXME: add details
    '''
    pass


# Generated at 2022-06-23 00:15:48.135575
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """Test method get_interfaces_info for class LinuxNetwork"""
    linux_network = LinuxNetwork()
    sample_device = 'lo'
    sample_data = {
        'mtu': 65536,
        'active': True
    }
    assert linux_network.get_interfaces_info(sample_device) == sample_data


# Generated at 2022-06-23 00:15:55.061063
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = argparse.Namespace()
    module.run_command = lambda command, errors='surrogate_then_replace': (0, '', '')
    net = LinuxNetwork(module)
    assert net.get_default_interfaces() == ({'interface': None, 'gateway': None, 'address': None},
                                            {'interface': None, 'gateway': None, 'address': None})

# Generated at 2022-06-23 00:16:00.084285
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    """
    Unit test for LinuxNetwork.__init__()

    This is not a real unit test, since it creates a LinuxNetwork object and uses it to obtain information about the system.
    The unit test should be called from the command line like this:

        $ ansible-test units --python 2.7.13 linux-system-info/linux_network.py

    The test does not verify the correctness of the results, so it is possible for the test to succeed even though the code has a bug.
    The purpose of the test is to call each method of the LinuxNetwork class and make sure the method's code can run without throwing an exception.
    The test also checks that the methods return a value of the correct type.

    :return: A boolean indicating the success (True) or failure (False) of the test
    """
    module_mock = mock.MagicMock()
   

# Generated at 2022-06-23 00:16:06.319586
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Test a function whose results are not interesting
    # test the function that is used to determine the results
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils import basic
    # Test that we do not get an exception
    print(LinuxNetwork(basic.AnsibleModule(argument_spec={})).get_interfaces_info(None, {}, {}))

# Generated at 2022-06-23 00:16:14.643858
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-23 00:16:26.342130
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from AnsibleModuleMock import AnsibleModuleMock
    from AnsibleModuleMock import ANSIBLE_VERSION
    if not LooseVersion(ANSIBLE_VERSION) >= LooseVersion("2.4"):
        return

    import platform
    _platform = platform.system()