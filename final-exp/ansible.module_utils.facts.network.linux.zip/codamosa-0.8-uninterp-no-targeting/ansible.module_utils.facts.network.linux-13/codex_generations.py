

# Generated at 2022-06-20 18:20:35.038199
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Initialize the mock
    module_mock = AnsibleModuleMock()
    module_mock.get_bin_path.return_value = "/sbin/ip"

# Generated at 2022-06-20 18:20:47.287239
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    class ModuleTest(object):
        def get_bin_path(self, program):
            return "/usr/bin/ip"


# Generated at 2022-06-20 18:20:56.993799
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    LINUX_NETWORK_CLASS = LinuxNetwork(MockModule())

    # Should match the IPv4 route from `ip -4 r`
    default4 = {'address': '192.168.72.2', 'gateway': '192.168.72.1', 'interface': 'enp0s8'}
    # Should match the IPv6 route from `ip -6 r`
    default6 = {'address': 'fe80::fc54:ff:fea3:f144', 'gateway': 'fe80::fc54:ff:fea3:f141', 'interface': 'enp0s8'}

    assert LINUX_NETWORK_CLASS.get_default_interfaces() == (default4, default6)


# Generated at 2022-06-20 18:21:09.828067
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-20 18:21:14.507793
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():

    module = AnsibleModule(argument_spec=dict())
    nm = LinuxNetwork(module)
    nm.get_interfaces_info(None, None, None)



# ===========================================
# Main
#


# Generated at 2022-06-20 18:21:17.596000
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    m = LinuxNetwork()
    print(m.ipv6_default_interface())
    print(m.ipv4_default_interface())
    print(m.get_interfaces_info())
    print(m.get_interfaces_counters())
    print(m.get_interfaces_ipaddr())
    print(m.get_interfaces_ipaddr6())

if __name__ == '__main__':
    test_LinuxNetwork()

# Generated at 2022-06-20 18:21:27.745899
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({},
        {},
        check_invalid_arguments=False,)
    module.run_command_environ_update = {}
    network = LinuxNetwork(module)
    rc, stdout, stderr = module.run_command(['ip', 'route', 'show', '0/0'], errors='surrogate_then_replace')
    ipv4 = {}
    ipv6 = {}
    if rc == 0 and stdout:
        words = stdout.split()
        # Words: 0: default, 1: via, 2: <gateway>, 3: dev, 4: <interface>
        ipv4['gateway'] = words[2]
        ipv4['interface'] = words[4]
    rc, stdout,

# Generated at 2022-06-20 18:21:41.384188
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    # NOTE: this module is required for the below
    #from unittest.mock import MagicMock
    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, '', '')
    mock_module.get_bin_path.return_value = '/usr/bin'
    ln = LinuxNetwork(mock_module)
    assert ln.module == mock_module
    assert ln.os_distribution == 'unknown'
    # TODO: how do we 'assert' our test above
    #       we can't do this because 'and' short circuits
    # assert LinuxNetwork.module == mock_module
    # assert LinuxNetwork.os_distribution == 'unknown'


############
#  UNIT   #
############
# pylint: disable=unused-argument


# Generated at 2022-06-20 18:21:52.499610
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.params['provider'] = dict(
        name='LinuxNetwork',
        parameters={'test_parameter': True})

    result = {
        'changed': False,
        'failed': False,
    }
    n = LinuxNetwork(module)

    assert n.provider['parameters']['test_parameter'] is True
    assert n.interface_map == {}
    assert n.ansible_facts['network'] == {}
    assert n.ansible_facts['network'] == result['ansible_facts']['network']

    module.exit_json(**result)



# Generated at 2022-06-20 18:22:02.717715
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():

    n = LinuxNetwork()

    def ip_path():
        return None
    n.get_bin_path = ip_path

    assert n.get_default_interface_ipv4()['address'] == '0.0.0.0'
    assert n.get_default_interface_ipv6()['address'] == '::'
    assert n.get_interfaces_info() == ({}, {'all_ipv4_addresses': [], 'all_ipv6_addresses': []})
    assert n.get_interfaces_info(ip_path="/usr/sbin/ip") == ({}, {'all_ipv4_addresses': [], 'all_ipv6_addresses': []})


# Generated at 2022-06-20 18:22:38.993040
# Unit test for method populate of class LinuxNetwork

# Generated at 2022-06-20 18:22:45.259075
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import ModuleDeprecationWarning
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils._text import to_bytes
    import warnings

    # Disable deprecation warning for test purpose.
    warnings.simplefilter("ignore", ModuleDeprecationWarning)

    # Mock module to be used in the constructor
    fake_module = basic.AnsibleModule(argument_spec={})
    fake_module.exit_json = lambda a: None

    # Constructor returns an instance of LinuxNetworkCollector
    linux_network_collector = get_collector_instance(fake_module)
    assert isinstance(linux_network_collector, LinuxNetworkCollector)

    # Call the fact method
    fact_

# Generated at 2022-06-20 18:22:51.227742
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    linuxnetworkcollector = LinuxNetworkCollector()

    # Test constructing without args
    assert linuxnetworkcollector._platform == 'Linux'
    assert linuxnetworkcollector._fact_class == LinuxNetwork
    assert linuxnetworkcollector.required_facts == set(['distribution', 'platform'])



# Generated at 2022-06-20 18:22:55.572520
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # FIXME: this is an example unit test, needs to be replaced with a real one
    assert 1 is 1


# Generated at 2022-06-20 18:23:00.608609
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    mc = LinuxNetworkCollector()
    assert mc._platform == "Linux"
    assert mc._fact_class == LinuxNetwork
    assert mc.required_facts == set(['distribution', 'platform'])



# Generated at 2022-06-20 18:23:11.499284
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    """
    Unit test for constructor of class LinuxNetwork
    """

    # FIXME: check for setUp and tearDown

    test_obj = LinuxNetwork()
    mod_obj = ANSIGModule()
    # FIXME: replace this with the param kwargs under our control
    test_obj.module = mod_obj
    test_obj.run()

    assert mod_obj.exit_json.called is True

# Generated at 2022-06-20 18:23:23.142004
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    class FakeModule(object):
        def get_bin_path(self, *args):
            if args[0] == "ethtool":
                return "/usr/local/bin/ethtool"
            if args[0] == "ip":
                return "/usr/bin/ip"
    class FakeModule2(object):
        def get_bin_path(self, *args):
            if args[0] == "ethtool":
                return "/usr/bin/ethtool"
            if args[0] == "ip":
                return "/usr/bin/ip"
    class FakeModule3(object):
        def get_bin_path(self, *args):
            if args[0] == "ethtool":
                return "/usr/bin/ethtool"
            if args[0] == "ip":
                return "/bin/ip"

# Generated at 2022-06-20 18:23:37.062522
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    ansible_module = AnsibleModule(argument_spec=dict())
    # FIXME: could you come up with a less AGT-like test case?
    ln = LinuxNetwork(ansible_module)
    assert ln.default_ipv4 == {
        'address': '127.0.0.1',
        'broadcast': '127.255.255.255',
        'macaddress': '00:00:00:00:00:00',
        'mtu': 65536,
        'netmask': '255.0.0.0',
        'network': '127.0.0.0',
        'type': 'loopback',
    }
    assert ln.default_ipv6['address'] == '::1'
    assert ln.default_ipv6['macaddress'] == ln.default

# Generated at 2022-06-20 18:23:40.603022
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    import json
    network_collector = LinuxNetworkCollector(None)
    assert network_collector._platform is 'Linux'
    assert network_collector._fact_class is LinuxNetwork
    assert network_collector.required_facts == set(['distribution', 'platform'])



# Generated at 2022-06-20 18:23:51.054388
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    hostname = 'testhostname'
    cache = {'ansible_facts': {
        'distribution': 'Ubuntu',
        'platform': 'Linux',
    }}
    module = mock.Mock()
    module.get_bin_path.return_value = '/usr/sbin/ip'
    module.run_command.return_value = (0, 'output', 'error')
    collector = LinuxNetworkCollector(module=module, cache=cache)
    assert collector.facts['default_ipv4'] == {'interface': 'eth0'}

    ip_path = module.get_bin_path.return_value
    module.get_bin_path.assert_has_calls([mock.call('ip'), mock.call('ethtool')])

# Generated at 2022-06-20 18:24:19.726466
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    l = LinuxNetwork(dict(module=None))



# Generated at 2022-06-20 18:24:30.440114
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={
        'devices': {'type': 'list', 'default': []},
        'default_ipv4': {'type': 'dict', 'default': {}},
        'default_ipv6': {'type': 'dict', 'default': {}},
    })
    # Create a mock module class with fake AnsibleModule
    ln = LinuxNetwork(module)
    # Set up a device to get test data (i.e. eth0)
    device = 'eth0'
    # Test that LinuxNetwork.get_ethtool_data returns a dict
    # with the correct keys and values
    assert isinstance(ln.get_ethtool_data(device), dict)



# Generated at 2022-06-20 18:24:41.710910
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """
    Test for method get_ethtool_data of class LinuxNetwork
    """
    module = AnsibleModule(
        argument_spec=dict(
            device=dict(required=True)
        )
    )
    mock_run_command = MagicMock()
    mock_run_command.return_value = (0, 'test output', None)
    with patch.multiple(LinuxNetwork, run_command=mock_run_command):
        instance = LinuxNetwork(module)
        result = instance.get_ethtool_data('testdevice')
        assert result == {'features': {'hw_tc_offload': 'on'}, 'timestamping': ['sw', 'hw'],
                          'hw_timestamp_filters': ['all'], 'phc_index': 0}

# Generated at 2022-06-20 18:24:45.850000
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    obj = LinuxNetworkCollector(module)
    assert obj.platform == 'Linux'
    assert obj.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-20 18:24:55.770842
# Unit test for method get_default_interfaces of class LinuxNetwork

# Generated at 2022-06-20 18:25:01.027248
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    test_class = LinuxNetwork()

    ip_path = "/sbin/ip"
    ifaces = {}
    ips = {}

    # TODO: Add more tests, particularly the exceptions
    ifaces, ips = test_class.get_interfaces_info(ip_path, ifaces, ips)

    print(ifaces)


# Generated at 2022-06-20 18:25:07.678115
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    linux_network = LinuxNetwork(module)

    assert linux_network.get_default_interfaces() == ({}, {})

# Generated at 2022-06-20 18:25:10.809613
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    assert LinuxNetwork(None).populate() == ({}, {'all_ipv4_addresses': [], 'all_ipv6_addresses': []})
# end-of-LinuxNetwork



# Generated at 2022-06-20 18:25:22.779669
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec=dict(
        name=dict(),
        vlan=dict(type='int'),
        # NOTE: this is white-listed to avoid introspection errors
        ip_address=dict(type='str'),
        # TODO: allow passing additional args
        # TODO: pass a test-module here instead of None
        #enable_dhcp=dict(type='bool'),
        #use_dhcp=dict(type='bool'),
        #mtu=dict(type='int'),
    ))
    ln = LinuxNetwork(module)
    # if isinstance(ln.facts, dict):
    #     module.exit_json(**ln.facts)
    # else:
    #     # TODO: add error handling
    #     module.fail_json(msg=ln.facts)

# Generated at 2022-06-20 18:25:35.271403
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module_name = 'ansible_collections.notstdlib.moveitallout.plugins.module_utils.network.linux'
    module_args = {'check_invalid_interface': True, 'default_ipv4_netmask': '255.255.0.0', 'default_ipv6_prefix': '64'}

# Generated at 2022-06-20 18:26:19.598272
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    mod = get_ansible_mock_module('LinuxNetwork')
    mod.run_command.return_value = AnsibleCommandResult(0, "eth0", "", "")
    net = LinuxNetwork(mod)
    default_ipv4, default_ipv6 = net.get_default_interfaces()
    assert default_ipv4['interface'] == "eth0"
    assert default_ipv6['interface'] == "eth0"


# Generated at 2022-06-20 18:26:24.460295
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    '''Unit test for constructor of class LinuxNetwork'''
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    ln = LinuxNetwork(module)
    assert ln.module == module
    assert ln.ip_path == module.get_bin_path("ip")


# Generated at 2022-06-20 18:26:32.959815
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    m = AnsibleModule(argument_spec={})
    instance = LinuxNetwork(m)
    instance.module = m
    ip_path = m.get_bin_path("ip")
    default_ipv4, default_ipv6 = instance.get_default_interfaces(ip_path)
    assert default_ipv4['address'] in ['127.0.0.1', '0.0.0.0']
    assert default_ipv6['address'] in ['::1', '::']

# Generated at 2022-06-20 18:26:39.753295
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # Build a mock module
    module = Mock()
    module.run_command.return_value = (0, '', '')
    # Build some mock facts
    facts = dict(platform='Linux')
    facts['distribution'] = dict(distribution='RHEL', version='6.6', major_version='6')
    facts['network'] = dict(interfaces={})
    # Instantiate the collector class and call collect()
    collector = LinuxNetworkCollector(module=module, facts=facts)
    collector.collect()
    # Assert the collector ran the expected commands and gathered the expected facts
    assert collector.facts['network']['interfaces']


# Generated at 2022-06-20 18:26:49.450264
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule({}, {}, False)
    network = LinuxNetwork(module=module)
    device = 'eth0'

# Generated at 2022-06-20 18:27:01.429040
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-20 18:27:06.265140
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    result = get_default_interfaces(module)
    expected = {
        "default_ipv4": {},
        "default_ipv6": {}
    }
    assert result == expected


# Generated at 2022-06-20 18:27:08.110149
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: write unit test
    pass


# Generated at 2022-06-20 18:27:12.228502
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={
        "cache": {"type": "bool", "default": False},
    })
    module.params["cache"] = True
    ln = LinuxNetwork(module)
    module.params["cache"] = False
    ln = LinuxNetwork(module)



# Generated at 2022-06-20 18:27:15.829032
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    mod = AnsibleModule(argument_spec={}, supports_check_mode=True)
    ln = LinuxNetwork(module=mod)
    ln.populate()
    mod.exit_json(changed=False, meta=ln.facts)


# Generated at 2022-06-20 18:27:53.447634
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    net = LinuxNetwork()
    net.get_interfaces_info(ip_path=None, default_ipv4=None, default_ipv6=None)


# Generated at 2022-06-20 18:28:00.179595
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})

    # patch ansible module to return a predictable facts dict
    module.run_command = lambda cmd: (0, "", "")
    module.get_bin_path = lambda cmd: '/bin/' + cmd
    setattr(module, '_fact_cache', {})
    module.get_file_content = lambda path: None
    module.fail_json = lambda **kwargs: False

    ln = LinuxNetwork(module)
    ln.get_interfaces_info = lambda a, b, c: ({}, {})

    rc, stdout, stderr = module.run_command('uptime')

# Generated at 2022-06-20 18:28:13.131786
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    # /proc/net/route output for default gateway
    route = {
        'default': {
            'destination': '00000000',
            'gateway': '004A97DF',
            'genmask': '00000000',
            'flags': '00010303',
            'metric': '00000000',
            'refcnt': '000001',
            'use': '00000000',
            'iface': 'eth0',
            'mask': '00000000',
            'mtu': '1500',
            'window': '5840',
            'irtt': '0',
        },
    }

    # /proc/net/fib_trie output for default gateway

# Generated at 2022-06-20 18:28:25.180613
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    """
    Unit test for method get_default_interfaces of class LinuxNetwork

    See the following files for more test data:
        * test/units/lib_network/test_module_network.py
        * test/units/lib_network/test_module_network_linux.py
    """
    tmpfile = tempfile.NamedTemporaryFile()

# Generated at 2022-06-20 18:28:38.529965
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-20 18:28:43.225157
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = MockModule()
    linux_network = LinuxNetwork(module)
    assert ('eth0', '192.168.0.1') == linux_network.get_default_interfaces()



# Generated at 2022-06-20 18:28:47.761514
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
        )
    )
    result = LinuxNetwork.populate(module)
    assert result['interfaces_info']
    assert result['default_ipv4']
    assert result['default_ipv6']


# Generated at 2022-06-20 18:28:54.983680
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all', 'network']
    module.params['gather_timeout'] = 1
    collector = LinuxNetworkCollector(module)
    assert collector.module == module
    assert collector.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-20 18:29:03.782258
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={
        'gather_network_resources': {'type':'list', 'default':['all']},
    })

    # required args that would normally be set by the module
    module.params['gather_network_resources'].append('all')

    ln = LinuxNetwork()
    ln.populate(module)

    # Module has no return value, just exit_json and fail_json
    assert module.exit_json.called
    assert not module.fail_json.called
    # populate does not return anything
    assert module.exit_json.call_args[0][0].get('gathered_resources')
    # these gathered resources should be populated
    result = module.exit_json.call_args[0][0]['gathered_resources']['network']

# Generated at 2022-06-20 18:29:11.428558
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():

    module = NetworkModule()

    # The unittest.mock module is a powerful part of the Python standard library.
    # It provides a core Mock class removing the need to create a host of stubs
    # throughout your test suite.
    # https://docs.python.org/3/library/unittest.mock.html
    # https://docs.ansible.com/ansible/latest/network/user_guide/scenario_test_module.html#test-classes-and-test-cases
    from ansible_collections.nxos.nxos.plugins.modules import network_facts

    # This will make all not found attributes return the mock
    m = Mock(wraps=network_facts)

    # Return the mock instead of the real get_bin_path
    m.get_bin_path.return_value = None
