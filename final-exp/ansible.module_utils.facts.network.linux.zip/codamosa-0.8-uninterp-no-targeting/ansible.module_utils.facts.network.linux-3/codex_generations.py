

# Generated at 2022-06-20 18:20:45.157871
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    net = LinuxNetwork()
    # test network interface for existence
    assert net.get_interface_by_macaddr('00:00:00:00:00:00') is None
    assert net.get_interfaces()
    assert net.get_interface_devname()

    # test IP version's result
    assert net.get_ip_version() == 'ipv4' or net.get_ip_version() == 'ipv6'
    assert net.get_interfaces_info(None,
                                   dict(address='None'),
                                   dict(address='None'))



# Generated at 2022-06-20 18:20:51.994522
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # Construct a LinuxNetworkCollector object
    # compare to the result of the fact_class() method
    collector = LinuxNetworkCollector(dict(), dict())
    fact = collector.get_facts()
    assert isinstance(fact, LinuxNetwork)
    assert fact.module.params == collector.module.params
    assert fact.module.params == {}

# Generated at 2022-06-20 18:21:04.152410
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.network_lsr.common.utils import get_file_content
    from ansible.module_utils.network_lsr.lsr.utils.command import get_command
    from ansible.module_utils.six import PY3
    from io import StringIO
    from unittest import mock


# Generated at 2022-06-20 18:21:09.827414
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    net_ins = LinuxNetwork()
    default_v4, default_v6 = net_ins.get_default_interfaces()

    assert "address" in default_v4
    assert "gateway" in default_v4
    assert "interface" in default_v4

    assert "address" in default_v6
    assert "gateway" in default_v6
    assert "interface" in default_v6


# Generated at 2022-06-20 18:21:13.645835
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    ln = LinuxNetwork()
    ln.populate()
    assert 'default_ipv4' in ln.network_facts
    assert 'default_ipv6' in ln.network_facts
    assert 'interfaces' in ln.network_facts
    assert 'all_ipv4_addresses' in ln.network_facts
    assert 'all_ipv6_addresses' in ln.network_facts

# Generated at 2022-06-20 18:21:15.268237
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = LinuxNetworkCollector(module)
    assert collector.platform == 'Linux'

# Generated at 2022-06-20 18:21:21.449649
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Test for an interface with a v4 and v6 route
    class TestModule(object):
        def __init__(self):
            self.run_command_called = False
            self.bin_path_called = False

        def run_command(self, command, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None, umask=None, encoding=None, errors='surrogate_then_replace', shell=False, logging=True, free_form=False, persist_command=False):
            self.run_command_called = True

# Generated at 2022-06-20 18:21:31.240122
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    nm = LinuxNetwork()
    # input with no ethtool and empty array returned
    assert nm.get_ethtool_data("device") == {}
    nm.module = Mock()
    nm.module.run_command = Mock(return_value=(0, "", ""))
    # input with ethtool, when there are no matches for any regex, empty array returned
    assert nm.get_ethtool_data("device") == {}
    nm.module.run_command = Mock(return_value=(0, "SOF_TIMESTAMPING_", ""))
    # input with ethtool, when there is a match for first regex
    assert nm.get_ethtool_data("device") == {"timestamping": ["sof_timestamping"]}

# Generated at 2022-06-20 18:21:42.483315
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():

    # Mocked data
    device = "eth0"
    ethtool_path = "/sbin/ethtool"
    rc_0_stdout_stderr = 0, "", ""
    rc_1_stdout_stderr = 1, "", ""
    stderr = "stderr"
    rc_0_stdout_1 = 0, "SOF_TIMESTAMPING_RX_SOFTWARE PTP Hardware Clock: 6", ""

# Generated at 2022-06-20 18:21:54.157277
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    if os.path.exists('/sys/class/net/foo'):
        # Do not create the file /sys/class/net/foo if it already exists
        # (this is a security issue)
        raise Exception('/sys/class/net/foo must not exist')


# Generated at 2022-06-20 18:22:34.828714
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = Mock()
    module.run_command = Mock(return_value=(0, '', ''))
    module.get_bin_path = Mock(return_value="/bin/ip")
    # create the object to test
    linux_network = LinuxNetwork(module)
    # no need to test get_bin_path in constructor, since get_bin_path is mocked
    # just test if the objects exist, since their content is tested elsewhere
    assert linux_network.ip_path is not None
    assert linux_network.defaults_path is not None
    assert linux_network.net_tools is not None
    assert len(linux_network.ipv4_interfaces) == 0
    assert linux_network.ipv4_addresses == []
    assert len(linux_network.ipv6_interfaces) == 0
    assert linux_

# Generated at 2022-06-20 18:22:44.066661
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    os.environ['PATH'] = '/bin:/usr/bin'
    module = AnsibleModule(
        argument_spec={},
    )
    nm = LinuxNetwork(module)

    def _call(*args, **kwargs):
        return (0, '', '')

    nm.module.run_command = _call
    nm.module.get_bin_path = lambda x: '/sbin/ethtool'

    # [0] no rc, [1] rc, [2] empty stdout, [3] stdout, [4] empty stderr, [5] stderr

# Generated at 2022-06-20 18:22:56.609036
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible_collections.ansible.netcommon.tests.unit.compat.mock import MagicMock, patch
    class args:
        network_debug = None  # FIXME: This should be tested
    module = MagicMock()
    module.params = {'network_debug': args.network_debug}
    module.fail_json = lambda *args, **kwargs: None
    module.run_command = lambda *args, **kwargs: (0, '', '')
    module.get_bin_path = lambda *args, **kwargs: '/tmp/bin'
    network = LinuxNetwork(module)


# Generated at 2022-06-20 18:22:57.718993
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    pass

# Generated at 2022-06-20 18:23:09.409385
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    fake_module = FakeModule()
    fake_module.params = {'gather_subset': ["!all", "min", "+interfaces"]}

# Generated at 2022-06-20 18:23:10.446586
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # Initialize the class object
    obj = LinuxNetworkCollector('dummy_module', 'dummy_resource')
    assert(obj is not None)

# Generated at 2022-06-20 18:23:22.392782
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Test the populate method of LinuxNetwork class.
    #
    # The method takes two arguments:
    #  - default_ipv4 - a dictionary with default IPv4 info
    #  - default_ipv6 - a dictionary with default IPv6 info
    #
    # Returns two dictionaries:
    #  - interfaces - a dictionary of network interfaces
    #  - ips - a dictionary of IP addresses
    class ModuleStub(object):
        def __init__(self):
            self.params = {}
            self.fail_json = print

        # TODO:
        # * a better way to stub get_bin_path
        # * a better way to stub run_command
        # * a better way to stub the file opening
        def get_bin_path(self, arg):
            return '/bin/ip'


# Generated at 2022-06-20 18:23:23.452350
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    pass


# Generated at 2022-06-20 18:23:37.263619
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-20 18:23:40.749205
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    assert LinuxNetworkCollector._platform == 'Linux'
    assert LinuxNetworkCollector._fact_class == LinuxNetwork
    assert LinuxNetworkCollector.required_facts == set(['distribution', 'platform'])
    assert LinuxNetworkCollector().required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-20 18:24:40.954172
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():

    # Test creation of LinuxNetwork object
    network = LinuxNetwork()

    # Test _gather_route_info()
    route_info = network._gather_route_info()

    print(route_info)
    print(network.default_ipv4)
    print(network.default_ipv6)
    print(network.interfaces)
    print(network.ips)

if __name__ == '__main__':
    test_LinuxNetwork()

# Generated at 2022-06-20 18:24:51.676660
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    import os
    import ansible.module_utils.basic
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.ip import LinuxNetwork
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import load_provider, get_file_content

    module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    module._ansible_builtin_additional_arguments_spec = dict()
    module._ansible_builtin_additional_arguments_spec['provider'] = dict(one_of=[None])
    module._ansible_builtin_additional_arguments_spec['provider']['type'] = 'dict'
    module._ansible_builtin_additional_arguments_spec

# Generated at 2022-06-20 18:25:03.441188
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    device = "lo"
    data = linux_network.get_ethtool_data(device)
    if data:
        assert data["features"]["rx-all"] == "on"
        assert data["features"]["tx-tcp-segmentation"] == "on"
        assert data["features"]["tx-scatter-gather"] == "on"
        assert data["features"]["tx-scatter-gather-fraglist"] == "on"
        assert data["features"]["rx-checksumming"] == "on"
        assert data["features"]["tx-checksum-ipv4"] == "on"

# Generated at 2022-06-20 18:25:13.534332
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """
    This function is used as unittest for LinuxNetworkCollector class.

    To run this test simply type in the root directory of this repository:
    python ansible/modules/system/network/collectors/linux_network.py
    """
    # Create object of class LinuxNetworkCollector
    lnc = LinuxNetworkCollector()

    # Print some attributes of object
    print("Platform: %s" % lnc._platform)
    print("Fact class: %s" % lnc._fact_class)
    print("Required facts: %s" % lnc.required_facts)


if __name__ == '__main__':
    test_LinuxNetworkCollector()

# Generated at 2022-06-20 18:25:23.485899
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # this should not raise an exception
    fact_subclass = LinuxNetworkCollector.fact_class()
    # these should be equal to the default value of an empty string
    assert fact_subclass.default_ipv4['address'] == ''
    assert fact_subclass.default_ipv6['address'] == ''
    assert fact_subclass.ip_path == ''
    # this should be equal to the class defined above
    assert type(fact_subclass) == LinuxNetworkCollector.fact_class()
    # these should be equal to the class defined above
    assert type(fact_subclass.module) == AnsibleModule
    assert type(fact_subclass.module.params) == dict
    # this should be equal to the default value of an empty string
    assert fact_subclass.ip_path == ''
    # this should be equal

# Generated at 2022-06-20 18:25:35.605344
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    def get_bin_path(path):
        return path

    def run_command(command, errors='surrogate_then_replace'):
        return 0, '', ''

    # Create a new AnsibleModule instance
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)

    module.run_command = run_command
    module.get_bin_path = get_bin_path

    ln = LinuxNetwork(module)

    assert(ln.get_default_interface_name() == ('eth0', 'eth0'))

    assert(ln.get_ip_route_default() == {'ipv4': '', 'ipv6': ''})

    assert(ln.get_interfaces_addresses() == ({}, {}))


# Generated at 2022-06-20 18:25:43.319234
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    target = LinuxNetwork()
    target.module = module
    target.populate()
    assert 'default_ipv4' in target.facts
    # default_ipv4 should be a dictionary.
    assert isinstance(target.facts['default_ipv4'], dict)
    # expect a 'default_ipv4' with a 'device' key
    assert 'device' in target.facts['default_ipv4']


# Generated at 2022-06-20 18:25:56.303372
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    """ generate testcases for AnsibleModule.exit_json and AnsibleModule.fail_json """
    import platform
    from ansible.module_utils.facts import FactCollector

    # initialize needed objects
    set_module_args(dict(
        gather_subset=['all']
    ))
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    platform_name = '{}-{}'.format(platform.system(), platform.release())
    linux_distribution = platform.linux_distribution()
    network = LinuxNetwork(module)
    network.populate()
    network.remove_internal_keys()

    # execute testcases

# Generated at 2022-06-20 18:25:58.358972
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = LinuxNetworkCollector(module)
    assert collector.module == module

# Generated at 2022-06-20 18:26:11.939951
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = ansible.module_utils.basic.AnsibleModule
    obj = LinuxNetwork(module)
    rc, out, err = obj.module.run_command('ip route list | grep default', errors='surrogate_then_replace')
    out = out.splitlines()[0]
    v4 = {}
    v6 = {}
    if '::' in out:
        v6['address'] = out.split()[-1]
    else:
        v4['address'] = out.split()[-1]
    result = obj.get_default_interface(v4, v6)

# Generated at 2022-06-20 18:27:24.467491
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat import unittest
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat.mock import patch

    class FakeModule:
        def __init__(self):
            self.params = {}

    module = FakeModule()
    module.run_command = lambda command, check_rc=False, errors='strict': (0, '', '')
    module.get_bin_path = lambda command, opt_dirs=(): command

    class FakeLinuxNetwork(LinuxNetwork):
        def __init__(self, module):
            self.module = module
            self.ip_path = module.get_bin_path('ip')

    ln = FakeLinuxNetwork(module)

# Generated at 2022-06-20 18:27:35.173478
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    # Exit with non-zero status and error message
    module.fail_json = fail_json
    module.fail_json.__doc__ = '''
    The opposite of exit_json(), it fails with a provided message
    '''
    module.run_command = MagicMock(return_value=(0, "", ""))
    module.get_bin_path = MagicMock(return_value="/bin/ethtool")

    network = LinuxNetwork(module)


# Generated at 2022-06-20 18:27:45.252402
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = MagicMock()
    module.run_command.return_value = (0, "", "")
    module.get_bin_path.return_value = "/usr/sbin"
    NetworkCollector.configure_mock(module=module)
    collector = LinuxNetworkCollector(module)
    assert collector.platform == 'Linux'
    assert collector.interface_path == '-o'
    assert collector.interfaces_path == '-a'
    assert collector.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-20 18:27:57.553430
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """unit test for method get_ethtool_data of class LinuxNetwork"""

    # Test get_ethtool_data() - Test data not provided
    linux_network = LinuxNetwork()
    data = linux_network.get_ethtool_data("fake_device_eth0")
    assert data == {}

    # Test get_ethtool_data() - Test data provided
    linux_network = LinuxNetwork()
    data = linux_network.get_ethtool_data("fake_device_eth0")

# Generated at 2022-06-20 18:28:09.202294
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    # check interface types
    for _type in LinuxNetwork.INTERFACE_TYPE:
        linux_network = LinuxNetwork(dict(DEFAULT_SUDO_BINARY=None, DEFAULT_SUDO_FLAGS=""), dict(ANSIBLE_NET_CONFIG_VERSION='1.0'))
        interface = dict(type=_type)
        linux_network._normalize_interface(interface)
        assert interface['type'] == LinuxNetwork.INTERFACE_TYPE[_type]

    # check default interface value
    linux_network = LinuxNetwork(dict(DEFAULT_SUDO_BINARY=None, DEFAULT_SUDO_FLAGS=""), dict(ANSIBLE_NET_CONFIG_VERSION='1.0'))
    interface = dict()
    linux_network._normalize_interface(interface)

# Generated at 2022-06-20 18:28:22.201706
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Test data
    data_file_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), "module_utils", "linux_ethtool_data.json")
    with open(data_file_path, 'r') as data_file:
        data = json.loads(data_file.read())

    # Test execution
    test_module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module=test_module)
    assert data['lo']['features'] == ln.get_ethtool_data('lo')['features']
    assert data['lo']['timestamping'] == ln.get_ethtool_data('lo')['timestamping']
    assert data['lo']['hw_timestamp_filters'] == ln.get_

# Generated at 2022-06-20 18:28:32.084845
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    fd, tmpfile = tempfile.mkstemp()

# Generated at 2022-06-20 18:28:46.032108
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    test_file = '/tmp/test_is'
    test_data = '''
5: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500 qdisc pfifo_fast state UP group default qlen 1000\    link/ether 12:34:56:78:9a:bc brd ff:ff:ff:ff:ff:ff
    inet 192.0.2.1/24 brd 192.0.2.255 scope global dynamic noprefixroute eth0
       valid_lft 85918sec preferred_lft 85918sec
    inet6 2001:db8::1/64 scope link
       valid_lft forever preferred_lft forever
    '''

    def _set_content(d):
        with open(test_file, 'w') as f:
            f

# Generated at 2022-06-20 18:28:59.845872
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Lets mock the module argument spec
    class MockModule():
        def __init__(self):
            self.params = {"gather_subset": ["network"]}

        def get_bin_path(self, name, opt_dirs=None, required=False):
            # Hardcode the path to the ethtool command
            return "/sbin/ethtool"


# Generated at 2022-06-20 18:29:10.467887
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    # FIXME: nasty use of globals
    global module
    module = FakeModule()
    global Facts
    Facts = FakeFacts()
    if not module.check_mode:
        module.fail_json(msg="running the linux network module without check_mode is not supported")
    # FIXME: this should set ipversion and routes to be more like facts
    #        but I don't know how to do that and this will work for what I need
    #        with out all the extra junk
    ln = Linux_Network(module, ipv6=False)
    return bool(ln.default_interface) or bool(ln.default_ipv6) or bool(ln.interfaces) or bool(ln.routes) or bool(ln.routes_ipv6)

# import module snippets