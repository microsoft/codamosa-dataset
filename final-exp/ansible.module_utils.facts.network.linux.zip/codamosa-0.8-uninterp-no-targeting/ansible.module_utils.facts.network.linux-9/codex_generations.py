

# Generated at 2022-06-20 18:20:37.728923
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    # get_bin_path
    module = get_bin_path_mock('ip', '/bin/ip')
    instance = LinuxNetwork(module)
    assert instance.get_bin_path('ip') == '/bin/ip'
    assert instance.get_bin_path('blah') == ''

    # get_file_content
    instance = LinuxNetwork(module, default_ipv4=dict(address='dummy'))
    assert instance.get_file_content('/tmp/foo', 'bar') == 'bar'
    assert instance.get_file_content('/tmp/foo') == ''
    assert instance.get_file_content('/tmp/foo', -1) == -1

    # get_default_interfaces

# Generated at 2022-06-20 18:20:47.422220
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    class TestModule():
        def __init__(self):
            self.params = {
                'config': 'lo=lo\n',
            }

            # FIXME: maybe split into smaller methods?
            # FIXME: this is pretty much a constructor

            self.INTERFACE_TYPE = {
                '1': 'loopback',
                '24': 'tunnel',
            }

            # FIXME: move this to a constant
            self.ipv6_path = '/proc/sys/net/ipv6/conf/'

            self.default_ipv4, self.default_ipv6 = self.get_default_interfaces()
            self.data = {}
            self.static_routes_v4 = {}
            self.static_routes_v6 = {}

            self.ip_path = 'ip'

# Generated at 2022-06-20 18:20:50.561948
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    m = AnsibleModule(argument_spec={})
    o = LinuxNetworkCollector(m)
    assert o.platform == 'Linux'
    assert o.fact_class == LinuxNetwork

#############################################################################
# Main
#############################################################################


# Generated at 2022-06-20 18:21:03.256732
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    # Bootstrapping to make sure the needed directories exist
    for item in ['/proc/net/dev', '/proc/net/route', '/proc/net/if_inet6', '/sys/class/net']:
        if not os.path.exists(item):
            os.makedirs(item)

    # Create an instance of module class
    module = AnsibleModule({}, '', '')

    # Create an instance of get_network_state
    # You can pass arguments to this class if needed
    # You can access the module class from the class
    # as LinuxNetwork.module
    # You can access the module arguments as LinuxNetwork.module.params
    obj = LinuxNetwork()

    # Check if the instance has the needed method
    assert hasattr(obj, 'get_interfaces_addresses')



# Generated at 2022-06-20 18:21:12.119406
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    dev = 'lo'
    module = AnsibleModule(argument_spec=dict(Devices=dict(required=True, type='dict')))

# Generated at 2022-06-20 18:21:16.795172
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-20 18:21:23.474815
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # get_interfaces_info method is the constructor for this module
    # so the easiest way to test is to import it without module deps
    # since this unit test does have module deps and module deps have
    # module deps and we end up having circular module deps.
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.generic import LinuxNetwork

    # create an AnsibleModule object so that we can mock the parameters
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all', '!min'], type='list')
        ),
    )

    # mock the facts module to stub out get_file_content()
    mock_

# Generated at 2022-06-20 18:21:32.300422
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible.module_utils.facts.network.linux import LinuxNetwork
    module = Mock(
        spec_set=['get_bin_path'],
        get_bin_path=Mock(
            return_value='/sbin/ip'))
    linux = LinuxNetwork(module)
    data_dict = dict()
    ipv4_dict = dict()
    ipv6_dict = dict()
    l_f = dict()
    l_a = dict()
    l_a['all_ipv4_addresses'] = ['1.2.3.4', '5.6.7.8', '9.10.11.12']
    l_a['all_ipv6_addresses'] = ['1::1', '2::2', '3::3']

# Generated at 2022-06-20 18:21:33.994895
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    result = LinuxNetworkCollector(module).collect()
    assert result is not None
    assert result.data is not None


# Generated at 2022-06-20 18:21:40.200652
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    '''
    Unit test for constructor of class LinuxNetwork
    '''
    module = AnsibleModule({})
    ln = LinuxNetwork(module)
    # For now test whether it is possible to instantiate and run without error
    # TODO: create more extensive unit tests
    interfaces, ips = ln.get_interfaces_info()
    assert isinstance(interfaces, dict)
    assert isinstance(ips, dict)
    assert interfaces
    assert ips

# Generated at 2022-06-20 18:22:13.600562
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    l = LinuxNetwork(module)
    commands = {
            'ip': {
              'interface': 'ip addr',
              },
            'route': {
              'interface': 'ip route',
              },
            'route_numeric': {
              'interface': 'ip -4 -n route',
              },
            'route6': {
              'interface': 'ip -6 route',
              },
            }
    for i in commands:
        rc, out, err = module.run_command(commands[i]['interface'], errors='surrogate_then_replace')
        assert rc == 0
        assert isinstance(out, str)


# Generated at 2022-06-20 18:22:24.180646
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = Mock(
        params={},
        get_bin_path=Mock(return_value='/sbin/ip'),
    )
    ln = LinuxNetwork(module)

    # Test 1: default_gateway_v4_found
    rc, out, err = Mock(), Mock(), Mock()
    module.run_command = Mock(return_value=[rc, out, err])

# Generated at 2022-06-20 18:22:37.170019
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    import tempfile
    import os
    module = AnsibleModule(argument_spec={})
    tmpdir = tempfile.mkdtemp()
    f = open(os.path.join(tmpdir, 'ethtool'), 'w')
    f.close()
    module.params['_ansible_tmpdir'] = tmpdir
    module.params['_ansible_verbosity'] = 2
    linux_network = LinuxNetwork(module)

    # Test the origin case
    device = 'eth0'

# Generated at 2022-06-20 18:22:46.714605
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', required=False),
        ),
        supports_check_mode=True,
    )

    nm = LinuxNetwork(module)

    failed = False
    result = dict(failed=failed, msg='')

    try:
        nm.populate()
        result['ansible_network_resources'] = nm.resources
    except Exception as exc:
        failed = True
        result['msg'] = 'populate failed with error: %s' % str(exc)

    module.exit_json(**result)

if __name__ == '__main__':
    test_LinuxNetwork_populate()

# Generated at 2022-06-20 18:22:57.657091
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Setup
    args = {
        'config': {
            'ansible_default_ipv4': {},
            'ansible_default_ipv6': {},
            'ansible_interfaces': [],
        },
        'ansible_facts': {
            'ansible_interfaces': [],
        },
    }

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.params = args

    # Test
    network = LinuxNetwork(module)
    res = network.populate()

    # Assertions
    assert res['ansible_default_ipv4'] == {}
    assert res['ansible_default_ipv6'] == {}
    assert res['ansible_interfaces'] == []


# Generated at 2022-06-20 18:23:09.312262
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    #
    # Test with a mock for the os module
    #
    @patch('os.path.exists')
    @patch('os.readlink')
    @patch('os.path.islink')
    def run_test(mock_islink, mock_readlink, mock_exists):

        mock_islink.return_value = True
        mock_readlink.return_value = '/dev/bond0 -> ../../devices/virtual/net/bond0/bond0'
        mock_exists.return_value = False
        module = FakeModule()


# Generated at 2022-06-20 18:23:12.962683
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Test the LinuxNetwork class of the Linux network_utils module
    # This class currently doesn't have unit tests. Once the ansible.module_utils.network.common.Network class has tests,
    # we will add tests here.
    return 0


# Generated at 2022-06-20 18:23:17.145672
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # Nothing to test, but we need this method to make unittest happy
    pass


# Generated at 2022-06-20 18:23:24.682067
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    try:
        from __main__ import module
    except ImportError:
        module = AnsibleModule(
            argument_spec = dict(),
        )
    else:
        module._ansible_no_log = True

    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data("lo") == {}
    assert ln.get_ethtool_data("badevmame") == {}
    assert ln.get_ethtool_data("lo") == {}


# Generated at 2022-06-20 18:23:28.740831
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    # test LinuxNetwork class
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-20 18:24:10.707788
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Test with no arguments
    m = AnsibleModule(argument_spec={})
    # Do the processing and check results
    l = LinuxNetwork(module=m)
    res = l.populate()
    assert 'default_interface' in res
    assert 'interfaces' in res
    assert 'routes' in res
    assert 'dns' in res
    assert 'all_ipv4_addresses' in res['ips']
    assert 'all_ipv6_addresses' in res['ips']
    # Test with all arguments specified
    m = AnsibleModule(argument_spec={
        'ip_path': dict(type='str'),
        'module': dict(type='str'),
    })
    l = LinuxNetwork(module=m)
    res = l.populate()
    assert 'default_interface' in res

# Generated at 2022-06-20 18:24:12.628260
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: Unit test
    pass


# Generated at 2022-06-20 18:24:23.515299
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    get_net_module().run_command = dummy_run_command
    n = LinuxNetwork()
    assert n.ip_path == "/bin/ip"
    assert n.iproute_path == "/sbin/ip"
    assert n.ethtool_path == "/sbin/ethtool"
    assert n.nmcli_path == "/bin/nmcli"
    assert n.route_path == "/sbin/route"
    assert n.modprobe_path == "/sbin/modprobe"
    assert n.sysctl_path == "/sbin/sysctl"
    assert n.dhclient_path == "/sbin/dhclient"
    assert n.dhclient6_path == "/sbin/dhclient6"
    assert n.dhclient_version

# Generated at 2022-06-20 18:24:36.014481
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = NetworkModule()
    linux_network = LinuxNetwork()

    results = {
        'default_ipv4': {
            'address': '10.10.10.10',
            'broadcast': '10.10.10.255',
            'netmask': '255.255.255.0',
            'network': '10.10.10.0',
            'interface': 'eth0'
        },
        'default_ipv6': {
            'address': '2001:db8::1',
            'prefix': '64',
            'scope': 'global',
            'interface': 'eth0'
        }
    }


# Generated at 2022-06-20 18:24:43.610859
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    # test case #1
    global raw_result1
    raw_result1 = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
        default_ipv4={},
        default_ipv6={},
    )
    fake_module = FakeModule(**raw_result1)
    assert LinuxNetwork(fake_module).populate() == raw_result1

    # test case #2
    global raw_result2
    raw_result2 = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
        default_ipv4={},
        default_ipv6={},
    )
    fake_module = FakeModule(**raw_result2)
    assert LinuxNetwork(fake_module).populate() == raw_

# Generated at 2022-06-20 18:24:54.446265
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    ''' test LinuxNetwork constructor'''
    sys_devices_path = 'platform/firmware/devicetree/base'

# Generated at 2022-06-20 18:25:04.721304
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    """
    This unit test runs the get_default_interfaces method of class LinuxNetwork
    and fails if the results are not what is expected. The method is called
    using the provided ip_path and default_ipv4 and default_ipv6 dicts.

    This unit test does not test the most interesting aspects of the method
    output as it only looks for non-empty strings for the gateway and address
    keys in the output dict.

    :return:success or failure
    :rtype: boolean
    """
    ip_path = 'ip'
    default_ipv4 = dict(address="10.0.0.1")
    default_ipv6 = dict(address="2001:db8::1")
    net = LinuxNetwork()

# Generated at 2022-06-20 18:25:12.831007
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    """
    Unit test for constructor of class LinuxNetwork
    """

    # Get the defaults
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    os_facts = dict(
        distro=dict(id='ubuntu'),
    )

    ln = LinuxNet(module, os_facts)

    print(ln.default_ipv4)
    print(ln.default_ipv6)
    print(ln.interfaces)
    print(ln.ips)



# Generated at 2022-06-20 18:25:23.618603
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    n = LinuxNetwork()

# Generated at 2022-06-20 18:25:34.293718
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = Mock(return_value=dict(failed=False, changed=False))
    mp = Mock(side_effect=lambda a: a)
    module.params = dict()
    module.get_bin_path = mp
    facts = NetworkCollector.collect(module=module)
    assert isinstance(facts, dict)
    assert "default_ipv4" in facts
    assert "default_ipv6" in facts
    assert "interfaces" in facts
    assert "all_ipv4_addresses" in facts["ipv4"]
    assert "all_ipv6_addresses" in facts["ipv6"]
    assert "distribution" not in facts
    assert "platform" not in facts



# Generated at 2022-06-20 18:26:22.927821
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = MockModule()
    linux_network = LinuxNetwork(module)

# Generated at 2022-06-20 18:26:29.574688
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.shell = Shell()
    linux_network = LinuxNetwork(module)

    assert linux_network._get_default_interfaces() == ({'gateway': '192.168.1.1', 'interface': 'eth1', 'address': '192.168.1.100'}, {'interface': 'eth1', 'gateway': 'fe80::ca5a:d5ff:fe48:cd01%eth1', 'address': 'fe80::ca5a:d5ff:fe48:cd01'})


# Generated at 2022-06-20 18:26:33.411289
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    args = {}

    linux_network = LinuxNetwork(module, args)

    assert linux_network.module == module
    assert linux_network.args == args



# Generated at 2022-06-20 18:26:34.828283
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    result = LinuxNetworkCollector()
    assert result is not None


# Generated at 2022-06-20 18:26:38.579297
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    f = LinuxNetworkCollector({'distribution': 'Fedora'})
    assert f.fact_class == LinuxNetwork
    assert f.platform == 'Linux'
    assert f.required_facts == set(['distribution', 'platform'])

# Generated at 2022-06-20 18:26:41.008409
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    assert LinuxNetworkCollector._platform == 'Linux'
    assert LinuxNetworkCollector._fact_class == LinuxNetwork
    assert LinuxNetworkCollector.required_facts == set(['distribution', 'platform'])

# Generated at 2022-06-20 18:26:50.303327
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    hostname = socket.gethostname()
    if '.' in hostname:
        fqdn = hostname
    else:
        fqdn = socket.getfqdn()

    set_module_args(dict(
        config_file='/etc/ansible/facts.d/network.fact'
    ))

    network_linux = LinuxNetwork()

    interfaces = network_linux.interfaces
    macaddress = network_linux.default_ipv4['macaddress']
    module = AnsibleModule(
        argument_spec=network_linux.argument_spec,
        supports_check_mode=network_linux.supports_check_mode,
    )

# Generated at 2022-06-20 18:27:02.265223
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """
    This is a unit test for LinuxNetwork.get_interfaces_info()
    Not a real unit test, as it does not use the module_utils/facts.py unittest framework (yet)
    """
    from ansible.module_utils.facts import ModuleArgsParser
    from ansible.module_utils.facts import Facts
    import sys


# Generated at 2022-06-20 18:27:11.150607
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    unittest.TestCase()
    net1 = LinuxNetwork()
    net2 = LinuxNetwork(dict())
    net3 = LinuxNetwork(dict(as_sudo=True))
    net4 = LinuxNetwork(dict(as_sudo=True, sudo_user='me'))
    net5 = LinuxNetwork(dict(as_sudo=True, sudo_user='me', network_debug=True))
    net6 = LinuxNetwork(dict(as_sudo=True, sudo_user='me', network_debug=True, network_diags=True))
    return


# Generated at 2022-06-20 18:27:21.282422
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = FakeAnsibleModule()
    module.run_command = lambda *args, **kwargs: (0, 'no error', '')

    # Create a LinuxNetwork instance with no interfaces
    linux_network = LinuxNetwork(module)
    linux_network.default_ipv4 = dict(address='10.0.0.1')
    linux_network.default_ipv6 = dict(address='fe80::1')

    # Create a mock interfaces directory with 2 interfaces and a bridge
    os.makedirs('/sys/class/net/eth0')
    os.makedirs('/sys/class/net/lo')
    os.makedirs('/sys/class/net/br0')
    os.makedirs('/sys/class/net/br0/brif/eth0')

    # Set the interface type

# Generated at 2022-06-20 18:28:07.919262
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module_mock = Mock()
    network_mock = LinuxNetwork(module_mock)
    network_mock.get_default_interfaces()

    # assert
    module_mock.get_bin_path.assert_has_calls([call('ip'), call('ip')], any_order=True)
    assert module_mock.run_command.call_count == 2
    assert module_mock.run_command.call_args_list == [call(['ip', 'route', 'show', 'default'], errors='surrogate_then_replace'), call(['ip', '-6', 'route', 'show', 'default'], errors='surrogate_then_replace')]


# Generated at 2022-06-20 18:28:18.293316
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    network = LinuxNetwork()
    print(json.dumps(network.ipv4))
    print(json.dumps(network.ipv6))
    print(json.dumps(network.interfaces))
    if network.default_ipv4:
        print(json.dumps(network.default_ipv4))
    if network.default_ipv6:
        print(json.dumps(network.default_ipv6))
    print(json.dumps(network.ips))

if __name__ == '__main__':
    test_LinuxNetwork()

# Generated at 2022-06-20 18:28:23.856643
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # pylint: disable=protected-access
    # Create the class
    ln = LinuxNetwork()
    # ips is normally a dict from get_interfaces_info
    ips = dict(all_ipv4_addresses=["192.168.1.1", "10.0.0.1"],
               all_ipv6_addresses=["::1", "fe80::1"])
    # flags is normally set by get_net_info
    flags = {'v4': "default"}
    # Run the code
    result = ln.get_default_interfaces(ips, flags)
    # check the response
    assert result[0]['address'] == "192.168.1.1", "default interface v4 is wrong"

# Generated at 2022-06-20 18:28:31.116389
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    ansible_collections = os.path.join(os.path.dirname(__file__), "..", "..")
    module = AnsibleModuleMock(ansible_collections)
    module.params = {
        "gather_subset": ["!all", "min"]
    }
    module.run_command = MagicMock(return_value=(0, "", ""))
    net_collector = LinuxNetworkCollector(module)
    module.run_command.assert_called_once_with("ip -V")
    assert net_collector.ip_path == "ip"


# Generated at 2022-06-20 18:28:44.754445
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network = LinuxNetwork(None)
    test_interfaces = {
        'eth0': {
            'features': {
                'rx': 'On',
                'tx': 'On',
                'sg': 'On',
                'tso': 'On',
                'ufo': 'On',
                'gso': 'On',
                'gro': 'On',
                'lro': 'Off',
            },
            'timestamping': ['tx', 'rx'],
            'hw_timestamp_filters': ['all', 'sync', 'pdelay_req', 'pdelay_resp'],
            'phc_index': 0,
        }
    }
    result = linux_network.get_ethtool_data('eth0')
    assert result == test_interfaces['eth0']

# Generated at 2022-06-20 18:28:54.931068
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    default_ip4 = {
        'address': '10.0.0.1',
        'broadcast': '10.0.0.3',
        'netmask': '255.255.255.248',
        'network': '10.0.0.0'
    }
    default_ip6 = {
        'address': 'fc00:1122:3344::1',
        'prefix': '64',
        'scope': 'global',
        'macaddress': 'fa:16:3e:89:b5:b0',
        'mtu': 1500,
        'type': 'unknown'
    }
    default_interface_info = dict(default_ip4, **default_ip6)

# Generated at 2022-06-20 18:29:00.512206
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    m = NetworkCollector()

    assert m.required_facts == set(['distribution', 'platform'])
    assert m.optional_facts == set()
    assert m.additional_facts == set()
    assert m._platform == 'Linux'
    assert m._fact_class == LinuxNetwork
    assert m._platform_to_fact_class == {'Linux': LinuxNetwork}


# Generated at 2022-06-20 18:29:10.613143
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    class TestModule:
        module = None
        bin_path = None

        def get_bin_path(self, name):
            return self.bin_path

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, env_vars=None, errors='surrogate_or_stderr'):
            return (0, '', '')

    args = [
        '/sbin/ethtool',
        '-k',
        'eth0'
    ]

# Generated at 2022-06-20 18:29:18.976361
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    '''
    Unit test for method get_interfaces_info of class LinuxNetwork
    '''

    # Empty input data
    update = {}
    module_return_value = dict(
        cmd=dict(
            rc=0,
            stdout=None,
            stderr=None),
        start=0.00693798,
        end=0.010849,
        delta=0.003911,
        changed=False)
    module_args = {
        'path': '/sbin/ip',
        '_uses_shell': False,
        '_raw_params': 'ip -4 addr show',
        '_raw_args': ['ip', '-4', 'addr', 'show'],
        'warn': True,
        '_diff': False
    }


# Generated at 2022-06-20 18:29:30.864166
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    args = (
        [
            '/usr/sbin/ip',
            '-4',
            'route',
            'list',
            '0/0',
        ],
    )
    ipv4_out = textwrap.dedent('''\
        default via 10.254.0.1 dev eth0
    ''')
    ipv6_out = textwrap.dedent('''\
        default via 10::1 dev eth0
    ''')
    args_v4 = args + ('4',)
    args_v6 = args + ('6',)
    module.run_command = MagicMock(return_value=(0, '', ''))