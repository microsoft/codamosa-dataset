

# Generated at 2022-06-20 18:20:30.113286
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    result = NetworkCollector.collect(module=None, facts={'distribution': 'Linux', 'platform': 'Linux'})
    assert len(result) == 2

# Generated at 2022-06-20 18:20:41.641158
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    from io import StringIO

    def get_file_content(path, default=''):
        if path == '/sys/class/net/enp0s8/address':
            return '08:00:27:b0:f7:e2'
        elif path == '/sys/class/net/enp0s8/mtu':
            return '1500'
        elif path == '/sys/class/net/enp0s8/operstate':
            return 'down'
        elif path == '/sys/class/net/enp0s8/device/driver/module':
            return '/sys/module/e1000e'
        elif path == '/sys/class/net/enp0s8/type':
            return '1'

# Generated at 2022-06-20 18:20:54.242865
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible.module_utils.facts.network.base import NetworkCollector
    from ansible.module_utils.facts.network.linux import LinuxNetwork
    from ansible.module_utils.facts.virtual.base import VirtualCollector
    from ansible.module_utils.facts.virtual.linux import LinuxVirtual

    # Initialize mock data for populate() method

# Generated at 2022-06-20 18:20:57.665724
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from ansible_collections.ansible.community.plugins.module_utils.facts.network.base import NetworkCollector
    nwc = NetworkCollector()
    assert nwc is not None


# Generated at 2022-06-20 18:21:03.705461
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    fact_collector = LinuxNetworkCollector(module)
    assert fact_collector.platform == 'Linux'
    assert fact_collector.required_facts == set(['distribution', 'platform'])



# Generated at 2022-06-20 18:21:08.227191
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    import pytest
    # object instance
    mod = LinuxNetwork()

    # test cases and expected results
    testcases = [
    ]

    for t in testcases:
        res = mod.get_ethtool_data(*t[0])
        assert res == t[1]



# Generated at 2022-06-20 18:21:19.900091
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    class Module(object):
        def __init__(self, ethtool):
            self.ethtool_bin = ethtool
        def get_bin_path(self, arg):
            return self.ethtool_bin
        def run_command(arg, errors='surrogate_then_replace'):
            return 0
    class AnsibleModule(object):
        def __init__(self, module):
            self.module = module
    module = Module('')
    ansible_module = AnsibleModule(module)
    net = LinuxNetwork(AnsibleModule(module))
    def_ipv4 = {'address': '127.0.0.1'}
    def_ipv6 = {'address': '::1'}

# Generated at 2022-06-20 18:21:26.793881
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    assert ln.default_interface is not None

    module = AnsibleModule(argument_spec={'config': {'required': True, 'type': 'dict'}, 'state': {'required': True, 'choices': ['present', 'absent']},})
    with pytest.raises(AnsibleFilterError):
        ln = LinuxNetwork(module)

# Generated at 2022-06-20 18:21:40.464708
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # --TEST--
    # Test LinuxNetwork.get_ethtool_data()
    # --INPUT--
    stdin = ""
    # --SETUP--

    device = "fake_device"
    expectation = {'features': {'tx_checksumming': 'off',
                                'rx_checksumming': 'off',
                                'scatter_gather': 'on',
                                'tcp_segmentation_offload': 'off',
                                'udp_fragmentation_offload': 'off',
                                'generic_segmentation_offload': 'off',
                                'generic_receive_offload': 'off'},
                   'timestamping': [],
                   'hw_timestamp_filters': [],
                   'phc_index': None}

# Generated at 2022-06-20 18:21:42.035177
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    f = LinuxNetworkCollector

if __name__ == '__main__':
    # Unit test for constructor of class LinuxNetworkCollector
    test_LinuxNetworkCollector()

# Generated at 2022-06-20 18:22:13.226948
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-20 18:22:23.980251
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import tempfile

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, msg):
            error_msg = "Test has failed. This is the failure message: {0}".format(msg)
            raise Exception(error_msg)

        def get_bin_path(self, *args):
            return "/bin/ip"

        def run_command(self, *args):
            return 0, "/bin/ip", ''

    class MockIpAddress(object):
        def __init__(self):
            self.params = dict()

        def get_interface_by_ip(self):
            return "lo"

    class MockDracutModule(object):
        def __init__(self):
            self.params = dict()


# Generated at 2022-06-20 18:22:36.800849
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # An object mocking the self.module of a linux network object
    class MyModule:
        def __init__(self, params):
            self.params = params
        def get_bin_path(self, name):
            return '/sbin/' + name
        def run_command(self, args, errors):
            return 0, '', ''

    # An object mocking data that would be available to a linux_network object
    class MyNetwork:
        def __init__(self, data):
            self.data = data
        def get_default_interface_ipv4(self):
            return self.data.get('default_ipv4', {})
        def get_default_interface_ipv6(self):
            return self.data.get('default_ipv6', {})

# Generated at 2022-06-20 18:22:40.565557
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    nkc = NetworkCollector.factory()
    assert nkc.__class__.__name__ == 'LinuxNetworkCollector'

if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-20 18:22:43.302293
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # FIXME: tests are pending
    pass

# Generated at 2022-06-20 18:22:56.151536
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    import collections as pyt

    class ModuleStub:
        def __init__(self, bin_path="ip"):
            self.bin_path = bin_path

        def get_bin_path(self, ip):
            return self.bin_path

        def run_command(self, command, errors='surrogate_then_replace'):
            if command[0] != self.bin_path:
                raise RuntimeError("Test failure: unexpected command: {0}".format(" ".join(command)))
            if self.bin_path == "ip":
                return 0, IP_SAMPLE_OUTPUT, ""
            elif self.bin_path == "ip6":
                return 0, IP6_SAMPLE_OUTPUT, ""
            elif self.bin_path == "ip -oneline":
                return 0, IP

# Generated at 2022-06-20 18:23:09.106221
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Initialize test
    module = AnsibleModule(argument_spec={})
    module.cliconf = DummyCli()
    module.connection = DummyConnection()
    net = LinuxNetwork(module)

    # Initialize expected results
    # The "populate" method is not specific to this host
    # so we can't predict the results
    assert_has_keys = ['default_ipv4', 'default_ipv6', 'interfaces', 'ips', 'routes_v4', 'routes_v6']
    assert_no_keys = ['interface_ipv4', 'interface_ipv6']
    # Initialize module arguments

    # Execute the populate method
    result = net.populate()

    # Verify the results
    for k in assert_has_keys:
        assert k in result

# Generated at 2022-06-20 18:23:15.958920
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    '''Unit test constructor of class LinuxNetworkCollector.'''
    module = Mock()
    module.params = {}
    module.get_bin_path = Mock(return_value="./bin")
    module.run_command = Mock(return_value=(0, "a\nb\nc\n", ""))
    module.get_distribution = Mock(return_value=("ubuntu", "14.04", "trusty"))
    module.get_platform = Mock(return_value="linux")

    ln = LinuxNetworkCollector(module)

    assert ln.platform == 'Linux'
    assert ln.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-20 18:23:28.060766
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Mock module and fail_json
    module = NetworkModule(argument_spec={}, check_invalid_arguments=False, bypass_checks=False)
    module.exit_json = lambda x: x
    module.fail_json = lambda x: x
    # Mock bin path
    bin_path = '/usr/bin'
    module.get_bin_path = lambda x: bin_path
    # Mock run_command
    module.run_command = lambda x: [0, '', '']
    # Create network instance
    network = LinuxNetwork(module)

    # Test without any data
    data = network.get_ethtool_data('eth0')
    assert data == {'features': {}}

    # Test with data and a phc_index

# Generated at 2022-06-20 18:23:34.346067
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network = LinuxNetwork()
    ip_path = "/bin/ip"
    default_ipv4 = {}
    default_ipv6 = {}
    interfaces = {}
    linux_network.populate(ip_path, default_ipv4, default_ipv6, interfaces)


# Generated at 2022-06-20 18:24:15.171680
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    mock_module = Mock()
    mock_module.run_command.return_value = [0, '', '']
    mock_module.get_bin_path.return_value = None
    network = LinuxNetwork(mock_module)

    assert network.get_default_interfaces()[0] == {
        "device": "lo",
        "network": "127.0.0.0",
        "netmask": "255.0.0.0",
        "address": "127.0.0.1"
    }

    # TODO: come back and fix this test
    #   upstream run_command is mocked
    #   therefore the return of network.get_default_interfaces()
    #   does not reflect the `real world`
    #   this is only a cosmetic test, it doesn't affect the module behavior
   

# Generated at 2022-06-20 18:24:23.804380
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    m = AnsibleModule(argument_spec={})
    l = LinuxNetwork(m)
    device = 'lo'
    data = l.get_ethtool_data(device)
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'features' in data
    device = 'eth0'
    data = l.get_ethtool_data(device)
    assert 'timestamping' not in data
    assert 'hw_timestamp_filters' not in data
    assert 'features' not in data
    assert 'phc_index' not in data
    device = 'tap0'
    data = l.get_ethtool_data(device)
    assert 'timestamping' not in data
    assert 'hw_timestamp_filters' not in data

# Generated at 2022-06-20 18:24:25.989085
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    mc = LinuxNetworkCollector()
    assert type(mc.facts) == LinuxNetwork
    assert mc.required_facts == {'distribution', 'platform'}
    assert mc.platform == 'Linux'


# Generated at 2022-06-20 18:24:39.485980
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    pm = AnsibleFakeModule()
    pm.params['ansible_ethtool'] = {}
    pm.params['ansible_ethtool']['features'] = {}
    pm.params['ansible_ethtool']['features']['rx vlan offload'] = 'off'
    pm.params['ansible_ethtool']['features']['rx-vlan-offload'] = 'off'
    pm.params['ansible_ethtool']['features']['tx vlan offload'] = 'on'
    pm.params['ansible_ethtool']['features']['tx-vlan-offload'] = 'on'
    pm.params['ansible_ethtool']['features']['tx hardware tcp segmentation offload'] = 'off'

# Generated at 2022-06-20 18:24:51.256658
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Setup object
    ln = LinuxNetwork()

    # Mock ethtool executable and its output
    def mock_get_bin_path(name, opt_dirs=[]):
        return 'ethtool'
    m_get_bin_path = MagicMock(side_effect=mock_get_bin_path)
    ln.module.get_bin_path = m_get_bin_path


# Generated at 2022-06-20 18:25:03.403578
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    # FIXME: use setup/teardown or self.setUp()/self.tearDown() for this, if it is even needed
    # stubs
    module = DummyModule()
    ip_path = None
    default_ipv4 = {'address': '10.0.0.1'}
    default_ipv6 = {'address': '::1'}

    """
    Stubbing:
    - os.path.exists
    - os.path.isdir
    - os.path.basename
    - os.path.join
    - glob.glob
    - get_file_content
    """
    # reset stubs
    module.reset_mock()

# Generated at 2022-06-20 18:25:15.435414
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModuleDummy()
    module.params = dict(
        config_file='',
        running_config_path='',
        name_type='',
        config_format='',
        default_ipv4=dict(address='', netmask='', network=''),
        default_ipv6=dict(address='', cidr='', scope='', interface=''),
        ipv4_interfaces=dict(),
        ipv6_interfaces=dict(),
    )
    module.exit_json = lambda **kwargs: sys.exit(0)
    module.fail_json = lambda **kwargs: sys.exit(1)


    # monkey patch module.run_command

# Generated at 2022-06-20 18:25:16.899836
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    LinuxNetwork.get_default_interfaces()



# Generated at 2022-06-20 18:25:23.118009
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    m = MagicMock(spec_set=AnsibleModule)
    m.run_command.return_value = [0, '', '']
    m.get_bin_path.return_value = ''
    f = LinuxNetworkCollector(m)
    assert f.fact_class.__name__ == 'LinuxNetwork'
    assert f.required_facts == {'distribution', 'platform'}
    assert f.platform == 'Linux'
    assert f._fact_class is f.fact_class

# Generated at 2022-06-20 18:25:33.048989
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = MagicMock(name='AnsibleModule')
    ln = LinuxNetwork(module)
    ip_path = "/bin/ip"
    default_ipv4 = {'address': "127.0.0.1"}
    default_ipv6 = {'address': "::1"}
    ifaces, ips = ln.get_interfaces_info(ip_path, default_ipv4, default_ipv6)
    new_interfaces = ln.populate(ifaces, ips)
    assert new_interfaces['lo']['mtu'] == 65536
    assert new_interfaces['lo']['ipv4']['address'] == '127.0.0.1'

# Generated at 2022-06-20 18:26:16.610123
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    # these tests require files in /sys/class/net/
    if not os.path.isdir("/sys/class/net/lo"):
        return

    # --------------------------------------------------------------------------------
    # Test 1: no bridges, no bonding, no secondaries
    m = LinuxNetwork()
    m.module = "I am a fake module"
    m.bin_path = dict(ip="/sbin/ip")
    m.INTERFACE_TYPE = "I am interface types"

    (new_interfaces, ips) = m.get_interfaces_info("", dict(), dict())
    iface = new_interfaces["lo"]

    assert iface["device"] == "lo"
    assert iface["type"] == "unknown"
    assert iface["mtu"] == 65536
    assert iface["active"] == True
    assert iface

# Generated at 2022-06-20 18:26:25.322981
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    """Check constructor of class LinuxNetwork"""

    # Create module object and set params
    module = Mock()
    module.params = {'ip': {
        'path': '/bin/ip'
    }}

    # Test all defaults
    network = LinuxNetwork(module)
    assert network.module == module
    assert len(network.interfaces) == 0
    assert len(network.gateways) == 0
    assert len(network.default_ipv4) == 0
    assert len(network.default_ipv6) == 0
    assert network.ip_path == '/bin/ip'
    assert network.ip.path == '/bin/ip'
    assert network.kernel_version == (0, 0, 0)
    assert network.interfaces_path == '/sys/class/net'


# Generated at 2022-06-20 18:26:37.687460
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # to test this function, we will call the function that calls it
    # and inspect the returned data
    module = AnsibleModule(argument_spec={})
    result = module.get_interfaces_info()
    pprint(result)
    # just iterate over the keys to make sure they exist and have sane values
    # if they do not, the unit test will catch it
    for _interface in result[0].keys():
        if 'ipv4' in result[0][_interface]:
            assert result[0][_interface]['ipv4']['address']
            assert result[0][_interface]['ipv4']['netmask']
            assert result[0][_interface]['ipv4']['network']

# Generated at 2022-06-20 18:26:45.957879
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Create a fake module
    fake_module = AnsibleModule({})
    # Create a fake command line
    fake_command = "/usr/bin/whoami"
    # Create a fake ip path
    fake_ip_path = "/bin/ip"
    # Create a fake default ipv4
    fake_default_ipv4 = dict(address='127.0.0.1')
    # Create a fake default ipv6
    fake_default_ipv6 = dict(address=':1')
    # Create a fake interfaces dict
    fake_interfaces = {
        'lo': {},
        'eth0': {}
    }
    # Create a fake ips dict
    fake_ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[]
    )
    #

# Generated at 2022-06-20 18:26:58.247571
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    x = LinuxNetwork()
    x.module = MagicMock()
    x.module.get_bin_path.return_value = "/sbin/ethtool"

    # Example data from get_ethtool_data
    # get_ethtool_data(self, device):
    #     data = {}
    #     ethtool_path = self.module.get_bin_path("ethtool")
    #     if ethtool_path:
    #         args = [ethtool_path, '-k', device]
    #         rc, stdout, stderr = self.module.run_command(args, errors='surrogate_then_replace')
    #         if rc == 0:
    #             features = {}
    #             for line in stdout.strip().splitlines():
    #                 if not line or line.endswith

# Generated at 2022-06-20 18:27:09.608479
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.facts.facts import Facts
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.module_utils import get_module
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.network import NetworkModule

    module = get_module(NetworkModule)
    facts = Facts(module)
    net_obj = LinuxNetworkCollector(facts, module)
    assert net_obj.platform == 'Linux'
    assert net_obj._fact_class == LinuxNetwork
    assert net_obj.required_facts == set(['distribution', 'platform'])
    assert net_obj.optional_facts == set()


# Generated at 2022-06-20 18:27:16.930648
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = sys.modules['__main__']
    module.params = {
        'config': dict(
            config='',
            src=None),
        'ipv4': dict(
            address=None,
            netmask=None,
            gateway=None),
        'ipv6': dict(
            address=None,
            prefix=None,
            gateway=None),
        'name': 'eth0',
        'state': 'up'}
    module.module = FakeAnsibleModule()
    module.exit_json = lambda x: None
    module.fail_json = lambda x: None
    network = LinuxNetwork()


# Generated at 2022-06-20 18:27:20.407467
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    ln = LinuxNetwork()
    (dev4, dev6) = ln.get_default_interfaces()
    assert dev4 == 'eth0'
    assert dev6 == 'eth0'

# Generated at 2022-06-20 18:27:26.341321
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = FakeModule()
    n = LinuxNetwork(module)
    assert n
    assert n.default_interface_v4()
    assert n.default_interface_v6()
    assert n.get_interfaces_info(None, None, None)

if __name__ == "__main__":
    test_LinuxNetwork()

# Generated at 2022-06-20 18:27:37.064628
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    my_linux_network = LinuxNetwork(dict(), False)

    iface_v4, iface_v6 = my_linux_network.get_default_interfaces()
    changed = False
    iface_v4, iface_v6, changed = my_linux_network.get_default_interfaces_from_script_network(iface_v4, iface_v6)
    iface_v4, iface_v6, changed = my_linux_network.get_default_interfaces_from_script_route(iface_v4, iface_v6)
    if changed:
        my_linux_network.update_dynamic_network(iface_v4, iface_v6, True)


# Generated at 2022-06-20 18:28:17.115805
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """
    get_interfaces_info()
    """
    # Helpers
    class MockFile():
        def __init__(self, content):
            self.content = content

        def read(self):
            return self.content

    class Args():
        def __init__(self, binary, content):
            self.binary = binary
            self.content = content

        def get_bin_path(self, binary, opt_dirs=[]):
            if self.binary == binary:
                return self.content

    # Setup
    os.environ['PATH'] = '/usr/bin:/bin'
    os.path.exists = lambda path: True

    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.connect(("8.8.8.8", 80))

# Generated at 2022-06-20 18:28:27.643336
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-20 18:28:31.649503
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    platform = LinuxNetworkCollector(dict(), dict(), dict())
    assert platform.distribution == 'Linux'
    assert platform.platform == 'Linux'


# Generated at 2022-06-20 18:28:41.045798
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Test loading of LinuxNetwork module
    linux_network = LinuxNetwork(dict(module=dict()))
    assert linux_network.module

    # Test running LinuxNetwork.populate
    interfaces, ips = linux_network.get_interfaces_info('/usr/bin/ip', {'version': 4}, {'version': 6})
    addresses = linux_network.get_default_interfaces_info()
    interfaces_facts = linux_network.populate()

    # Make sure the interfaces and addresses are not empty
    assert interfaces
    assert ips
    assert addresses

    # Check to make sure the data is what we expect it to be.
    assert interfaces_facts['all_ipv4_addresses'] == ips['all_ipv4_addresses']
    assert interfaces_facts['all_ipv6_addresses'] == ips

# Generated at 2022-06-20 18:28:52.462137
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    (distribution, major_version, _) = get_distribution()
    module = AnsibleModule(
        argument_spec = dict(),
    )
    loaded_facts = dict(
        distribution=distribution,
        platform='Linux',
    )
    ansible_facts = dict(
        ansible_net_interfaces={},
        ansible_net_all_ipv4_addresses=[],
        ansible_net_all_ipv6_addresses=[],
        ansible_net_ipv4={},
        ansible_net_ipv6={},
    )
    testobj = LinuxNetworkCollector(module, loaded_facts, ansible_facts)
    assert testobj.platform == 'Linux'

# Generated at 2022-06-20 18:28:59.447234
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = MagicMock()
    module.get_bin_path.return_value = "/usr/bin/ethtool"
    device = "eth1"
    network = Network()
    network.module = module

# Generated at 2022-06-20 18:29:10.271222
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    network = LinuxNetwork()
    network.module = MagicMock()
    network.module.get_bin_path.return_value = '/sbin'
    network.module.run_command.side_effect = (
        (0, 'some data', ''),
        (0, '00:00:00:00:00:00', ''),
        (0, 'Foobar 1000', ''),
        (0, 'Bridge firewire0', ''),
    )
    network.populate()
    assert network.data['ipv4'] == {'address': '0.0.0.0'}


# Generated at 2022-06-20 18:29:18.832890
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    """ unit test: constructor """

    module = AnsibleModule(argument_spec={})

    ln = LinuxNetwork(module=module)
    assert ln is not None

    assert ln.is_linux()

    # NOTE: this is not a unit test,
    # NOTE: it is a functional test
#     ln = LinuxNetwork(module=module)
#     print(json.dumps(ln.get_interfaces_info(), indent=4))
#     print(json.dumps(ln.get_interface_defs(), indent=4))



# Generated at 2022-06-20 18:29:30.786211
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    import platform
    host_system = platform.system()
    module = AnsibleModule(argument_spec=dict())
    network = LinuxNetwork(module)
    family = network.get_default_interfaces()
    if host_system == 'Linux':
        assert family == {'v4': 'eth0', 'v6': 'eth0'}
    elif host_system == 'Darwin':
        assert family == {'v4': 'en0', 'v6': 'en0'}
    elif host_system == 'FreeBSD':
        assert family == {'v4': 'lo0', 'v6': 'lo0'}
    elif host_system == 'OpenBSD':
        assert family == {'v4': 'lo0', 'v6': 'lo0'}

# Generated at 2022-06-20 18:29:41.292911
# Unit test for method populate of class LinuxNetwork