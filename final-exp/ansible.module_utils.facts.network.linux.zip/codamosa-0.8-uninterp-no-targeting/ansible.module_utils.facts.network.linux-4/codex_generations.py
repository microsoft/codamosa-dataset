

# Generated at 2022-06-20 18:20:33.719412
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import sys
    module = sys.modules[__name__]
    linux_network = LinuxNetwork(module)
    ip_path = linux_network.get_bin_path("ip")
    default_ipv4 = dict()
    default_ipv6 = dict()
    result = linux_network.get_interfaces_info(ip_path, default_ipv4, default_ipv6)
    assert result is not None



# Generated at 2022-06-20 18:20:47.186717
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    """Unit test for method get_default_interfaces of class LinuxNetwork."""
    try:
        # FIXME: change LinuxNetwork() to LinuxNetwork(module)
        from ansible.module_utils.basic import AnsibleModule
        test_module = AnsibleModule(argument_spec={})
        network = LinuxNetwork(test_module)
    except Exception:
        network = LinuxNetwork()
    ipv4, ipv6 = network.get_default_interfaces()
    assert isinstance(ipv4, dict)
    assert isinstance(ipv6, dict)
    assert 'default_ipv4' in ipv4
    assert 'default_ipv6' in ipv6
    assert 'default_ipv4_interface' in ipv4
    assert 'default_ipv6_interface' in ipv6

# Generated at 2022-06-20 18:20:57.393624
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import tempfile

    # FIXME: this is pretty ugly.. perhaps consider writing a mock?

# Generated at 2022-06-20 18:21:07.140181
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-20 18:21:19.298380
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
  class TestModule:
    class TestRunCommand(object):
      def __init__(self, rc, out, err):
        self.rc = rc
        self.out = out
        self.err = err
      def run_command(self, args, errors=''):
        return (self.rc, self.out, self.err)

    def __init__(self, rc, out, err):
      self.rc = rc
      self.out = out
      self.err = err
      self.run_command = self.TestRunCommand(rc, out, err)

    def get_bin_path(self, path, required=False, opt_dirs=[]):
      return None


# Generated at 2022-06-20 18:21:22.120849
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    '''
    Returns the list with all LinuxNetwork instances.
    '''
    return [LinuxNetwork(MockModule())]


# Generated at 2022-06-20 18:21:29.980004
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    mock_module = MagicMock()
    mock_module.params = {
        'system_distribution': 'ubuntu',
        'system_distribution_release': '20.04.1',
        'ansible_distribution': 'debian',
        'ansible_distribution_major_version': '10',
        'system_distribution_release': '20.04.1',
        'interfaces': 'eth0',
        'routes': 'eth0',
    }

    network = LinuxNetwork(mock_module)

    expected = {
        'interfaces': {
            'eth0': {
            }
        }
    }

    network.populate()
    assert network.network_info == expected

# Generated at 2022-06-20 18:21:39.407217
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    # Test when somewhere in /sys there is a file that is not a directory
    # and cannot be read (permission denied).
    def glob_fake_false_positive(path):
        return ['/sys/class/net/not_a_directory', '/sys/class/net/no_permission']

    module = AnsibleModule(argument_spec={})
    module.glob = glob_fake_false_positive

    net = LinuxNetwork(module)

    # Test when there is no default IPv4 interface.
    module.run_command = Mock(return_value=(1, '', ''))
    net = LinuxNetwork(module)
    assert net.default_ipv4['device'] is None

    # Test when there is no default IPv6 interface.
    module.run_command = Mock(return_value=(1, '', ''))
   

# Generated at 2022-06-20 18:21:46.486941
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.exit_json = Mock(return_value=None)
    obj = LinuxNetwork(module)
    cmd = dict(v4='ip route get 8.8.8.8', v6='ip route get 2001:4860:4860::8888')
    # rc, out, err = obj.module.run_command('ip route get 8.8.8.8', errors='surrogate_then_replace')
    # FIXME fail to mock properly here
    out = """8.8.8.8 via 10.0.2.2 dev eth0  src 10.0.2.15 metric 102
    """
    obj.module.run_command = Mock(return_value=(0, out, None))
    res = obj.get_default_interfaces()
    assert isinstance

# Generated at 2022-06-20 18:21:49.547164
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    linux_net = LinuxNetwork(dict())
    assert linux_net.module
    assert linux_net.ip_path
    assert linux_net.ip_version



# Generated at 2022-06-20 18:22:25.585320
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    ln = LinuxNetwork(module)

# Generated at 2022-06-20 18:22:27.702374
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    net_facts_module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    nc = LinuxNetworkCollector(net_facts_module)
    assert nc.platform == 'Linux'
    assert nc.fact_class == LinuxNetwork
    assert nc.required_facts == {'distribution', 'platform'}


# Generated at 2022-06-20 18:22:39.754751
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = None

# Generated at 2022-06-20 18:22:50.001413
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    m = "LinuxNetwork.test_LinuxNetwork_get_interfaces_info()"

    # setup argparse to get rid of module private args
    obj = LinuxNetwork(None, dict(), dict())


# Generated at 2022-06-20 18:22:54.974789
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # FIXME: this is not an actual unit test, rather just a placeholder
    # and some development code to get you started
    # FIXME: remove or replace it
    module = AnsibleModule(argument_spec={'foo': dict()})
    ln = LinuxNetwork(module)
    # FIXME: enter actual test code here
    pass



# Generated at 2022-06-20 18:23:07.899628
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    class LinuxNetwork(object):

        def __init__(self):
            """Constructor of class LinuxNetwork
            """
            self.module = AnsibleModule(argument_spec=dict())

        def get_bin_path(self, executable):
            return executable

    network = LinuxNetwork()

    interfaces = {}
    # Empty file must return default_interfaces
    interfaces_filename = "/tmp/test_LinuxNetwork_get_default_interfaces_empty"
    interfaces["v4"], interfaces["v6"] = network.get_default_interfaces(interfaces_filename)
    assert interfaces["v4"] == {"address": "0.0.0.0", "gateway": "0.0.0.0"}
    assert interfaces["v6"] == {"address": "::", "gateway": "::"}

    # File with valid content must return

# Generated at 2022-06-20 18:23:18.325413
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    import unittest
    from ansible.module_utils import basic

    module = basic.AnsibleModule(argument_spec={
        "test_stdout": {"type": "str"},
    }, supports_check_mode=True)

    # get_ethtool_data(self, device)
    LINUX_NETWORK = LinuxNetwork(module=module)

# Generated at 2022-06-20 18:23:30.241851
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    os = AnsibleModule(
        argument_spec = dict(
            name=dict(type='str'),
            value=dict(type='str'),
        ),
        supports_check_mode=True,
    )
    os.add_file_common_args = lambda *args, **kwargs: {}
    os.get_bin_path = lambda *args, **kwargs: '/sbin/ip'
    os.run_command = lambda *args, **kwargs: (0, '', '')

    f_module = basic.AnsibleModule(
        argument_spec=dict(
            filename=dict(),
            state=dict(type='str', default='present'),
            contents=dict()
        )
    )


# Generated at 2022-06-20 18:23:36.570080
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule
    module.run_command = Mock()
    module.get_file_content = Mock()
    module.get_bin_path = Mock()

    network_collector = LinuxNetworkCollector(module)
    network_collector.collect()
    assert len(network_collector) > 0
# Unit test class LinuxNetwork used to call a private method of
# LinuxNetworkCollector


# Generated at 2022-06-20 18:23:46.811716
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
    )

    ln = LinuxNetwork(module)
    interfaces, ips = ln.get_interfaces_info('/sbin/ip', {}, {})
    print(interfaces)
    print(ips)
    interface, route = ln.get_default_interfaces()
    print(interface)
    print(route)
    print("---")
    print(ln.get_interfaces_matching("e.*1"))
    print("---")
    print(ln.get_interfaces_matching("e.*1", "Link encap"))
    print("---")
    print(ln.get_interfaces_matching("e.*1", "mtu"))
    print("---")

# Generated at 2022-06-20 18:24:23.322548
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    assert LinuxNetworkCollector.platform == 'Linux'
    assert issubclass(LinuxNetworkCollector._fact_class, LinuxNetwork)
    assert LinuxNetworkCollector.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-20 18:24:35.782743
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # given
    module = object()
    network = LinuxNetwork(module)

# Generated at 2022-06-20 18:24:38.057143
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    assert LinuxNetwork.get_default_interfaces('') == ({'ens33': {}}, {'ens33': {}})

# Generated at 2022-06-20 18:24:41.438825
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModuleMock()

    collector = LinuxNetworkCollector(module)

    assert collector.module == module
    assert collector._platform == 'Linux'
    assert collector._fact_class == LinuxNetwork
    assert collector.required_facts == set(['distribution', 'platform'])



# Generated at 2022-06-20 18:24:52.380074
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """Unit tests for LinuxNetworkCollector"""
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.facts.facts import Facts
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import dict_merge
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.pycompat24 import get_exception

    # Setup a mock module and set up it's facts to test LinuxNetworkCollector()
    fake_module = Mock()
    fact_info_dict = {'distribution': 'RedHat', 'platform': 'Linux'}
    fake_module.params = {'gather_subset': ['all'], 'filter': '*'}
    fake_module.ansible_facts = dict_merge

# Generated at 2022-06-20 18:25:03.779038
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    '''Unit test for get_interfaces_info'''
    net = LinuxNetwork()
    # TODO: do better
    if sys.version_info[0] == 2:
        py_ver = 'py2'
    else:
        py_ver = 'py3'
    data = json.loads(open('test/%s/linux_network.json' % py_ver).read())
    eth0 = data['interfaces']['eth0']

    assert net.get_interfaces_info(data['ip_path'], data['default_ipv4'], data['default_ipv6']) == \
        (data['interfaces'], data['ips'])

    # TODO: look at this
    assert eth0['mtu'] == 1500
    assert eth0['type'] == 'ether'
    assert eth

# Generated at 2022-06-20 18:25:14.692180
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    sample_default_routes = '''default via 192.168.0.1 dev enp0s3  proto static
192.168.0.0/24 dev enp0s3  proto kernel  scope link  src 192.168.0.108  metric 100
unreachable default dev lo  scope link
'''

    module = MockModuleLinuxNetwork()
    module.run_command = Mock(return_value=(0, sample_default_routes, ''))
    linux_network = LinuxNetwork(module)

    ipv4, ipv6 = linux_network.get_default_interfaces()

    assert ipv4['address'] == '192.168.0.108'
    assert ipv4['gateway'] == '192.168.0.1'
    assert ipv4['interface'] == 'enp0s3'

# Generated at 2022-06-20 18:25:24.005470
# Unit test for method populate of class LinuxNetwork

# Generated at 2022-06-20 18:25:26.001860
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # FIXME: This is a placeholder for a unit test that
    # will be written when actual test infrastructure is available.
    assert True



# Generated at 2022-06-20 18:25:36.314131
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    import json
    import stat
    import pytest
    fixtures_path = os.path.join(os.path.dirname(__file__), 'fixtures')
    files = ['lsb_release', 'ifconfig_a', 'ifconfig_b', 'ifconfig_c', 'ifconfig_d', 'ifconfig_e']
    # TODO: create fixtures with cases that test the different path to the ip binary
    # files.extend(['ip_a','ip_b','ip_c','ip_d','ip_e'])
    for f in files:
        shutil.copy(os.path.join(fixtures_path, f), './')
        os.chmod(f, stat.S_IRUSR)
    # LinuxNetwork.BASE_INTERFACE_FILE = '/etc/network/interfaces'
   

# Generated at 2022-06-20 18:26:19.242441
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    mock_run_command = unittest.mock.Mock(return_value=(0,
        '', '',))
    module.run_command = mock_run_command
    module.get_bin_path = lambda path: path
    network = LinuxNetwork(module)
    assert network.INTERFACE_TYPE['1'] == 'loopback'
    assert network.INTERFACE_TYPE['28'] == 'slip'
    assert network.INTERFACE_TYPE['512'] == 'ppp'
    assert network.INTERFACE_TYPE['768'] == 'sit'
    assert network.INTERFACE_TYPE['775'] == 'irda'
    assert network.INTERFACE_TYPE['776'] == 'wlan'
    assert network.INTERFACE_TYPE['800'] == 'plip'
   

# Generated at 2022-06-20 18:26:29.128381
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    import tempfile

    # The output of ethtool -k varies between RHEL 6 and RHEL 7
    # so we need a different test per operating system.
    # We can't deserialize json directly as ansible.module_utils.basic would
    # also deserialize the attributes of the current class, so we need a
    # slightly complex way to deserialize the output.

    # RHEL 6:

    # Offload parameters for eth0:
    # rx-checksumming: on
    # tx-checksumming: on
    # scatter-gather: off
    # tcp-segmentation-offload: on
    # udp-fragmentation-offload: off
    # generic-segmentation-offload: on
    # generic-receive-offload: off
    # large-receive-offload: off

# Generated at 2022-06-20 18:26:39.944693
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    inventory_plaindict = {}
    inventory_plaindict['default_ipv4'] = {
        'address': '172.16.1.1',
        'netmask': '255.255.255.0',
        'network': '172.16.1.0'}
    inventory_plaindict['default_ipv6'] = {
        'address': 'cafe::1',
        'prefix': '64',
        'scope': 'link'}

# Generated at 2022-06-20 18:26:49.609434
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    a = LinuxNetwork()
    a.module = mock_ansible_module()
    a.module.run_command = Mock(return_value=(0, '', ''))
    a.iproute2_path = '/sbin/ip'
    a.get_interfaces_info = Mock(return_value=(None, None))
    a.get_interfaces_info.return_value = ({'eth0': {}, 'eth1': {}}, {'default_ipv4': {}, 'default_ipv6': {}, 'all_ipv4_addresses': []})
    a.get_iproute_addr_data = Mock(return_value=(None, None))

# Generated at 2022-06-20 18:27:01.620452
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-20 18:27:04.516203
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModuleMock()
    facts = LinuxNetworkCollector(module).collect()
    assert facts is not None
    assert type(facts) is dict
    assert facts['distribution'] == 'Linux'
    assert facts['default_ipv4']['address'] == '192.168.10.100'
    assert facts['default_ipv6']['address'] == 'fe80::f2de:f1ff:fe74:1ed'



# Generated at 2022-06-20 18:27:08.896052
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    my_platform = 'Linux'
    assert LinuxNetworkCollector._platform == my_platform
    assert LinuxNetworkCollector._fact_class == LinuxNetwork
    assert LinuxNetworkCollector.required_facts == {'distribution', 'platform'}

# Generated at 2022-06-20 18:27:11.775965
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    obj = LinuxNetwork()
    assert len(obj.get_interfaces_raw()) > 0
    assert len(obj.get_interfaces()) > 0
    assert obj.get_gateways() is not None



# Generated at 2022-06-20 18:27:21.798772
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
  # test with a mocked device_name
  device_name = "smething"

  # we need some mocks
  # mock module
  module = Mock()
  module.run_command = Mock()
  module.get_bin_path = Mock()

  # mock is dict of dicts (to test)
  is_ = {}

  # mock module.get_bin_path
  module.get_bin_path.return_value = "/bin/ethtool"

  # mock module.run_command
  def run_command(command, errors):
    if command[2] == "-k":
      return (0, "Checksum offload: on\n", None) # is_['features'] = {"Checksum_offload":"on"}

# Generated at 2022-06-20 18:27:31.469744
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # mock module input parameters
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(type='list', required=False),
            filter=dict(type='dict', required=False),
        )
    )
    # test LinuxNetwork class initialization and gather_facts function
    linux_network = LinuxNetwork(module)
    linux_network.populate()
    # check that facts were gathered
    assert linux_network.facts['default_ipv4']['address'] == '127.0.0.1'
    assert linux_network.facts['default_ipv6']['address'] == '::1'

# Generated at 2022-06-20 18:28:52.814871
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    out = LinuxNetwork(module)

    interface_v4 = {'gateway': '192.168.1.1', 'interface': 'en0', 'address': '192.168.1.180'}
    interface_v6 = {'interface': 'en0', 'address': 'fe80::9419:31ff:fe01:8c7f'}

    # Check that the return value of get_default_interfaces is right
    # In this case, we fake that using command_runner.
    out.command_runner = MagicMock(return_value=(0, '192.168.1.1 en0 192.168.1.180\nfe80::9419:31ff:fe01:8c7f en0', ''))
    assert out.get_default_inter

# Generated at 2022-06-20 18:29:02.957488
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    from ansible.module_utils._text import to_native
    from ansible.module_utils._text import to_text, to_bytes
    from ansible.module_utils.basic import AnsibleModule
    from tempfile import mkdtemp
    from os.path import join
    from shutil import rmtree

    class FakeLinuxNetwork(LinuxNetwork):
        def __init__(self, module):
            self.module = module

    class FakeAnsibleModule:
        def __init__(self):
            self.tmpdir = mkdtemp()

        def run_command(self, cmd, errors="raise"):
            output = "default via 192.0.2.254 dev eth0 \n"

# Generated at 2022-06-20 18:29:06.028152
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network = LinuxNetwork()
    # FIXME: how do we test this method effectively?
    linux_network.populate()


# Generated at 2022-06-20 18:29:07.356776
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    assert "interfaces" in LinuxNetwork().populate()

# Generated at 2022-06-20 18:29:20.106053
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Create a mocked LinuxModule
    mocked_LinuxModule = mock.MagicMock()

    # Create a mocked module
    mocked_module = mock.MagicMock()


# Generated at 2022-06-20 18:29:26.877480
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    lnc = LinuxNetworkCollector(module)
    facts = lnc.collect()

    assert facts['gather_subset'] == ['!all', '!min']
    assert facts['gather_network_resources'] == ['all']
    assert facts['network_resources']['interfaces'] == Non

# Generated at 2022-06-20 18:29:32.130204
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    platform = 'Linux'
    os_distribution = 'Red Hat Enterprise Linux'
    facts = {'platform': platform, 'distribution': os_distribution}
    collector = LinuxNetworkCollector(None, facts=facts, module=None)
    assert collector


# Generated at 2022-06-20 18:29:41.785548
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # build a fake module
    class FakeModule(object):
        def get_bin_path(self, command, required=True):
            if command == 'ip':
                return command
        def run_command(self, cmd, errors='surrogate_then_replace', **kwargs):
            return 0, '', ''
    module = FakeModule()

    # build a fake network object
    network = LinuxNetwork(module)
    network.default_ipv4 = {}
    network.default_ipv6 = {}
    network.ip_path = "/sbin/ip"
    network.linux_distribution = ['CentOS', '6', 'something']

    # build a stub ipv4 address

# Generated at 2022-06-20 18:29:46.299322
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    network = LinuxNetworkCollector(None)

    assert network._platform == 'Linux'
    assert network._fact_class == LinuxNetwork
    assert network.required_facts == set(['distribution', 'platform'])

# Generated at 2022-06-20 18:29:49.003357
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = FakeAnsibleModule()
    network_collector = LinuxNetworkCollector(module)
    assert network_collector._platform == 'Linux'
    assert network_collector._fact_class == LinuxNetwork
    assert network_collector.required_facts == set(['distribution', 'platform'])
