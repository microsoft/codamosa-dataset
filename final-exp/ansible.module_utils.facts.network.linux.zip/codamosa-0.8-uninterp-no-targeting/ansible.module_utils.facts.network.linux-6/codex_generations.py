

# Generated at 2022-06-20 18:20:36.127109
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    class Options(object):
        def __init__(self, module):
            self.module = module

    class Module(object):
        def __init__(self):
            self.params = {}

            class ReturnVal(object):
                def __init__(self, code, stdout):
                    self.rc = code
                    self.stdout = stdout

            self.run_command = lambda args, errors: ReturnVal(0, '''default via 192.0.2.2 dev em1
    192.0.2.0/24 dev em1  proto kernel  scope link  src 192.0.2.3
default via 2001:db8::2 dev em2
    2001:db8::/64 dev em2  proto kernel  scope link  src 2001:db8::3
''')


# Generated at 2022-06-20 18:20:48.748576
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    '''
    Unit test for LinuxNetwork.get_ethtool_data
    '''
    module = AnsibleModule(argument_spec={})
    mod = module_common_args.copy()
    mod.update({
        'module_defaults': module._load_params(),
        'DEFAULT_SUBSETS': module._load_params(),
        'DEFAULT_COMPLEX_TYPES': module._load_params(),
        'CONSTANTS': module._load_params(),
    })
    # FIXME: create a separate test_module that we can use for testing
    # just like the other modules
    module.get_bin_path = lambda x: '/bin/' + x
    ln = LinuxNetwork(module=module, params=mod)
    data = ln.get_ethtool_data('eth0')

# Generated at 2022-06-20 18:21:01.640555
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    assert LinuxNetwork.get_default_interfaces({
        'v4': {
            'default': {
                'address': '192.168.1.1'
            }
        }
    }) == ['192.168.1.1']

    assert LinuxNetwork.get_default_interfaces({
        'v4': {}
    }) == ['127.0.0.1']

    assert LinuxNetwork.get_default_interfaces({
        'v4': {
            'default': {
                'address': '192.168.1.1'
            }
        },
        'v6': {
            '::1': {
                'scope': 'host'
            }
        }
    }) == ['192.168.1.1', '::1']


# Generated at 2022-06-20 18:21:11.722452
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():

    import tempfile
    import shutil

    # stub module.run_command since we can't use it in unit tests
    module = AnsibleModuleStub()

    # create temporary directory with scripts required by Network module:
    #   ifdown
    #   ifup
    temp_dir = tempfile.mkdtemp()

    iface_up_path = os.path.join(temp_dir, 'ifup')
    os.mknod(iface_up_path)
    os.chmod(iface_up_path, 0o755)

    iface_down_path = os.path.join(temp_dir, 'ifdown')
    os.mknod(iface_down_path)
    os.chmod(iface_down_path, 0o755)

    module.ifup_path = iface_

# Generated at 2022-06-20 18:21:18.480894
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-20 18:21:22.169426
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    collector = LinuxNetworkCollector(None, None)
    assert collector.platform == 'Linux'
    assert collector.fact_class == LinuxNetwork
    assert collector.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-20 18:21:25.330379
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = NetworkModule(argument_spec={})
    network = LinuxNetworkCollector(module)
    assert network.network is not None
    assert network.network.platform == 'Linux'
    assert network.network._platform == 'Linux'


# Generated at 2022-06-20 18:21:33.104501
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec={
            'gather_subset': dict(type='list', elements='str', default=['!config'])
        },
        supports_check_mode=True
    )
    nm = LinuxNetwork(module)
    interfaces = nm.get_interfaces_info(ip_path=None, default_ipv4={}, default_ipv6={})[0]
    assert isinstance(interfaces, dict), 'interfaces should be a dict'
    if interfaces.get('lo'):
        assert interfaces['lo'].get('device') == 'lo'
        assert interfaces['lo'].get('type') == 'loopback'
        assert interfaces['lo'].get('active') == True



# Generated at 2022-06-20 18:21:43.148536
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )

    # Test with OS X (BSD)
    args = {
        'ip_path': '/sbin/ip',
        'default_ipv4': {'address': '192.168.1.1'},
        'default_ipv6': {'address': '::1'},
    }
    net = LinuxNetwork(module, **args)
    assert net.ip_path == '/sbin/ip'
    assert net.default_ipv4 == {'address': '192.168.1.1'}
    assert net.default_ipv6 == {'address': '::1'}
    assert net.get_ipv6_default_interface

# Generated at 2022-06-20 18:21:51.169372
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule({})
    ln = LinuxNetwork(module=module, args="", network_os='Linux')
    msg_1 = "Expecting ethtool_check to be %s, got %s"
    device = 'ifconfig_mock_eth0'

# Generated at 2022-06-20 18:22:15.051074
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModuleMock({
        'distribution': 'unit_test',
        'platform': 'Linux',
    })
    obj = LinuxNetworkCollector(module)
    assert obj._platform == 'Linux'
    assert obj._fact_class == LinuxNetwork
    assert obj.required_facts == {'distribution', 'platform'}



# Generated at 2022-06-20 18:22:25.429853
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    nm = LinuxNetwork(module)
    nm.get_interfaces_info = MagicMock()
    nm.get_network_config = MagicMock()
    nm.get_route = MagicMock()
    nm.get_route.return_value = {}
    nm.get_default_devices = MagicMock()
    nm.get_interfaces_info.return_value = ({}, [])
    nm.get_default_devices.return_value = ({}, {})
    nm.distribution = MagicMock()
    nm.distribution.return_value = {'release': [0, 0, 0], 'distribution': 'Unknown'}
    nm.get_sysctls = MagicMock()

# Generated at 2022-06-20 18:22:32.070885
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """
    Test to verify constructor of class LinuxNetworkCollector
    """
    rndc = LinuxNetworkCollector()
    assert rndc
    assert rndc._platform == "Linux"
    assert rndc._fact_class == LinuxNetwork
    assert rndc.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-20 18:22:43.028507
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Create a test module instance
    module = AnsibleModule(argument_spec={})

    # Define test input data
    gateway_interface = {
        'v4': {'interface': 'eth0', 'address': '172.17.0.1', 'gateway': '172.17.0.1'},
        'v6': {'interface': 'eth0', 'address': 'fe80::42:acff:fe11:1', 'gateway': 'fe80::42:acff:fe11:1'}
    }

# Generated at 2022-06-20 18:22:45.682812
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    network_collector = LinuxNetworkCollector()
    assert network_collector.fact_class == LinuxNetwork
    assert network_collector.platform == 'Linux'

# Generated at 2022-06-20 18:22:57.497703
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    sysfs_net_path = '/sys/class/net'
    linux_net = LinuxNetwork(module=MagicMock())

    # Test unmocked path
    try:
        linux_net.get_interfaces_info(sysfs_net_path, dict(), dict())
    except Exception as e:
        if 'No such file or directory' not in str(e):
            raise
    else:
        assert False, "get_interfaces_info() should raise IOError"

    # Test mocked path
    path = os.path.join(sysfs_net_path, 'eth0')

# Generated at 2022-06-20 18:23:09.150963
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    """Unit test for constructor of class LinuxNetwork"""
    # Default init args are path to 'ip' and dict for default_ipv4/6
    linux_network = LinuxNetwork()
    assert linux_network.default_ipv4 == {}
    assert linux_network.default_ipv6 == {}
    # NOTE: must manually assign a valid ip path for each os type (see above)
    # assert linux_network.ip_path_bin ==
    assert linux_network.ip_path_bin is not None

    # TODO: test ipv4/6 dicts with explicit args to constructor

    if linux_network.ip_path_bin:
        # Path to 'ip' with explicit arg
        linux_network = LinuxNetwork(ip_path=linux_network.ip_path_bin)

# Generated at 2022-06-20 18:23:20.135404
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    class FnModule(object):
        def get_bin_path(self, arg):
            return arg

        def run_command(self, arg, errors='surrogate_then_replace'):
            if arg == ['ip', 'route']:
                return 0, 'default via 192.0.2.1 dev eth1  proto static  metric 100  pref medium\n', None
            if arg == ['ip', 'route']:
                return 0, 'default via 2001:db8::1 dev eth1  proto static  metric 100  pref medium\n', None
            if arg == ['ip', '-6', 'route']:
                return 0, 'default via 2001:db8::1 dev eth1  proto static  metric 100  pref medium\n', None
            return 0, '', None


# Generated at 2022-06-20 18:23:31.341067
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    '''
    Unit test for method get_ethtool_data() of class LinuxNetwork
    '''

# Generated at 2022-06-20 18:23:41.052381
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    import tempfile
    import shutil
    import copy

    from ansible_collections.community.general.tests.unit._test_helper import TestModule

    from ansible_collections.community.general.plugins.modules.network.common.utils import dict_merge
    ###################################################
    # case 1: lo, eth1: active, eth0: inactive
    #
    test_module = TestModule()

    # create a mock module
    test_module.params = dict(
        config='/etc/sysconfig/network-scripts/ifcfg-eth0',
        path='/sbin:/usr/sbin:/bin:/usr/bin'
    )

    tmp_dir = tempfile.mkdtemp()
    test_root_dir = os.path.join(tmp_dir, 'sys')
    test_sys_dir

# Generated at 2022-06-20 18:24:29.849639
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )
    allowed_subsets = frozenset(('interfaces', 'default_gateway', 'gateways'))
    const = type('Const', (), {})
    const.check_mode = True
    const.gather_subset = allowed_subsets
    ipv4, ipv6 = module.params['gather_subset']
    n_obj = LinuxNetworkCollector(module, const)
    ipv4, ipv6 = n_obj.get_interfaces_and_routes(ipv4, ipv6)
    assert isinstance(ipv4, dict)

# Generated at 2022-06-20 18:24:32.693166
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    result = {'ansible_facts': {}}
    ln = LinuxNetwork(module=module)
    assert isinstance(ln, object)

    # TODO: mock `get_file_content` and `readline_from_file`
    # assert ln.get_default_interfaces() == result


# Generated at 2022-06-20 18:24:34.281405
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    run_unittests(LinuxNetwork)



# Generated at 2022-06-20 18:24:43.080910
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(),
    )

    # let's create a LinuxNetwork instance for testing purpose
    lnx_network = LinuxNetwork(module)

    results = lnx_network.populate()
    assert 'interfaces' in results
    assert isinstance(results['interfaces'], dict)
    assert 'default_ipv4' in results
    assert 'default_ipv6' in results
    assert isinstance(results['ips'], dict)


if __name__ == '__main__':
    # unit test for LinuxNetwork
    module = AnsibleModule(
        argument_spec=dict(),
    )
    # let's create a LinuxNetwork instance for testing purpose
    lnx_network = LinuxNetwork(module)


# Generated at 2022-06-20 18:24:52.498078
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = MagicMock()
    module.run_command.return_value = (0, '/data/default_interfaces_out.txt', None)
    net = LinuxNetwork(module)
    result = net.get_default_interface()

# Generated at 2022-06-20 18:25:03.819836
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    runner = RunnerMock()

# Generated at 2022-06-20 18:25:06.785810
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.exit_json(changed=False)

# include magic from lib/ansible/module_common.py
# <<INCLUDE_ANSIBLE_MODULE_COMMON>>



# Generated at 2022-06-20 18:25:20.275487
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(
        )
    )
    n = LinuxNetwork(module)

    # This is a "mock" of the ListData() class from the listdata.py module
    # The class is not available from this file
    class ListData(object):
        def __init__(self, interfaces=None):
            self.interfaces = interfaces or dict()

        def get_list(self, key):
            return self.interfaces.get(key, dict())

    ld = ListData()

    def get_default_interfaces():
        return n.get_default_interfaces()

    get_default_interfaces.listdata = ld
    get_default_interfaces.module = module


# Generated at 2022-06-20 18:25:25.276221
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # create a fact object for testing
    fact = LinuxNetworkCollector()
    assert fact.required_facts == set(['distribution', 'platform'])
    assert fact._platform == 'Linux'



# Generated at 2022-06-20 18:25:34.058398
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all', '!min'], type='list'),
        ),
        supports_check_mode=True,
    )

    collector = LinuxNetworkCollector(module)
    assert collector.module == module
    assert collector.config == {'gather_subset': ['!all', '!min']}
    assert collector.fact_class == collector._fact_class
    assert collector.fact_class == LinuxNetwork
    assert collector.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-20 18:26:21.071692
# Unit test for method get_default_interfaces of class LinuxNetwork

# Generated at 2022-06-20 18:26:30.136147
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # if this test fails, it is likely the get_interfaces_info()
    # method will fail to find an interface
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.system.network.base import NetworkCollector

    # NOTE: this is just a rough sanity test, should have more
    #       negative tests and a test with actual data

    # NOTE: uses a real network interface name (platform and kernel
    #       dependent) so it may fail when expected to succeed
    result = NetworkCollector.get_interfaces_info('/sbin/ip', {}, {})

    # A dict of dicts is returned
    assert isinstance(result, dict)

    # First element returned is interfaces
    assert 'interfaces' in result

    # Interfaces are keyed using the interface name
    assert 'lo'

# Generated at 2022-06-20 18:26:33.805720
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    assert LinuxNetworkCollector(ModuleStub())._platform == 'Linux'
    assert LinuxNetworkCollector(ModuleStub()).required_facts == {'distribution', 'platform'}


# Generated at 2022-06-20 18:26:35.903279
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec=dict())
    collector = LinuxNetworkCollector(module=module)
    assert collector.module == module

# Generated at 2022-06-20 18:26:46.562496
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule({})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value=True)

# Generated at 2022-06-20 18:26:54.502713
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = MagicMock()
    module.get_bin_path.return_value = "/usr/sbin/ethtool"
    module.run_command.return_value = (0, "", "")

    l = LinuxNetwork(module)
    data_ethtool = l.get_ethtool_data("eth0")
    assert data_ethtool == {'features': {}}

# Generated at 2022-06-20 18:27:00.836515
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    exit_json = module.exit_json
    fail_json = module.fail_json
    from ansible_collections.ansible.misc.tests.unit.modules.utils import set_module_args
    set_module_args({})
    ln = LinuxNetwork(module=module)
    with pytest.raises(NotImplementedError):
        ln.populate()

# Generated at 2022-06-20 18:27:02.703003
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    mod = AnsibleModule(argument_spec={})
    assert LinuxNetwork(mod)


# Generated at 2022-06-20 18:27:13.592341
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    linux_network = LinuxNetwork()


# Generated at 2022-06-20 18:27:24.467212
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    ln = LinuxNetwork()
    ln.module = FakeAnsibleModule()
    ln.module.run_command = Mock(return_value=(0, "", ""))

    # First run test with a single interface

# Generated at 2022-06-20 18:28:12.100980
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils import basic
    from ansible.module_utils.network.linux import os_default_impl
    from ansible.module_utils.network.common.utils import dict_merge
    from ansible.module_utils.network.common.utils import load_provider
    from ansible.module_utils.network.common.config import NetworkConfig, load_config
    from ansible.module_utils.network.common.netconf import build_root_xml_node


# Generated at 2022-06-20 18:28:22.711014
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    ln = LinuxNetwork(module)
    # Make a copy of the interface data so we can compare
    interface_copy = copy.deepcopy(ln.interfaces)
    # Use a dictionary comprehension to remove any devices that don't have
    # an ipv4 address
    ln.interfaces = \
        {device: ln.interfaces[device] for device in ln.interfaces if ln.interfaces[device].get('ipv4')}

    # Test the interfaces property
    for device in ln.interfaces:
        # Ignore these keys because they  cause too much output
        ignore_keys = ('ipv6', 'ipv4_secondaries')
        # Remove keys we are ignoring
        for key in ignore_keys:
            l

# Generated at 2022-06-20 18:28:29.982330
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    def mock_run_command(args, errors):
        assert args == ['/sbin/ethtool', '-k', 'eth0'], "Wrong args."
        return 0, "autoneg: on\n", ''

    module = get_module_mock()
    module.run_command = mock_run_command
    linux_network = LinuxNetwork(module)
    ethtool_data = linux_network.get_ethtool_data('eth0')
    assert ethtool_data['features']['autoneg'] == 'on', "Wrong parsed value."



# Generated at 2022-06-20 18:28:32.161189
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    # TODO: Does this need a test?
    module = AnsibleModule({})
    ln = LinuxNetwork(module)
    assert ln



# Generated at 2022-06-20 18:28:46.121080
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # FIXME: this test should probably be in a subclass of UnitTestCase
    # designed to just test one class.
    # Setup a test module
    import ansible.module_utils.basic as basic
    module = basic.AnsibleModule(
        argument_spec={
            'gather_subset': dict(type='list', default=[])
        },
    )
    # FIXME: this is a hack to prevent class instantiation from failing
    module.params['gather_subset'] = None
    module.params['gather_network_resources'] = None
    module.params['expand'] = None

    class LinuxNetwork(Network):
        pass

    net_detect_mod = LinuxNetwork(module)

    # Inject data into the get_file_content

# Generated at 2022-06-20 18:28:59.890066
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    """ Test get_default_interfaces function with mocked output from Linux """
    module = AnsibleModule(argument_spec={})
    # Mocked output from Linux
    # python module.run_command('ip route get 8.8.8.8')
    rc, out, err = 0, '8.8.8.8 via 192.168.56.1 dev eth0  src 192.168.56.41', ''
    module.run_command.return_value = rc, out, err
    # python module.run_command('ip -6 route get 2001:4860:4860::8888')

# Generated at 2022-06-20 18:29:10.498067
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    m = NetworkModule()

    # NOTE: interfaces will be built in a different order on each run

# Generated at 2022-06-20 18:29:15.748035
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    # module.check_mode = True
    # module.debug("")
    # module.exit_json(**facts)
    # module.fail_json(**facts)
    # module.params
    network = LinuxNetworkCollector(module)
    # network.platform
    # network.distribution
    # network.subplatform_fact_name


# Generated at 2022-06-20 18:29:22.835492
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    """Unit test case for LinuxNetwork.get_default_interfaces.

    """

    # Testing with a mockup
    module_mock = MagicMock(name='module mock')
    module_mock.get_bin_path.return_value = '/sbin/ip'

    class RunCommandMock(object):
        """
        """
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def __call__(self, args, errors=None):
            return (self.rc, self.out, self.err)

    # No default
    rc = 0

# Generated at 2022-06-20 18:29:32.622450
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    network = LinuxNetwork()
    interface = {'v4': {'address': '127.0.0.1', 'gateway': 'unknown', 'interface': 'lo'}, 'v6': {'address': '::1', 'gateway': 'unknown', 'interface': 'lo'}}
    interfaces, ips = network.get_interfaces_info('/sbin/ip', interface['v4'], interface['v6'])
    assert interfaces['lo']['macaddress'] == '00:00:00:00:00:00'
    assert interfaces['lo']['mtu'] == 16436
    assert interfaces['lo']['active'] == True
    #assert interfaces['lo']['module'] == 'loopback'
    assert interfaces['lo']['type'] == 'loopback'