

# Generated at 2022-06-20 18:20:28.711672
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    linux_network = LinuxNetwork()
    assert linux_network is not None


# Generated at 2022-06-20 18:20:40.268272
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = LinuxNetworkCollector(module=module)

    ## test AnsibleModule
    assert type(collector.module) == AnsibleModule

    ## test required, platform, distribution and fact_class
    assert collector.required_facts == set(['distribution', 'platform'])
    assert collector._platform == 'Linux'
    assert collector._fact_class == LinuxNetwork
    
    ## test the fact_class
    fact_class = collector._fact_class
    assert fact_class.module.check_mode == False
    
    ## test the fact
    fact = fact_class(collector.module)
    assert fact.module.check_mode == False
    assert type(fact.get_hostname()) == str
    assert type(fact.get_domain()) == str

# Generated at 2022-06-20 18:20:50.043555
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec=dict())

    ifans = LinuxNetwork(module)
    rc = 0
    result = dict()
    result['ipv4'] = dict()
    result['ipv6'] = dict()
    result['interfaces'], result['ipaddresses'] = ifans.get_interfaces_info()


# Generated at 2022-06-20 18:21:02.839136
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    ln = LinuxNetwork()

    # Test default value when route file does not exist
    with patch.object(ln, 'get_default_interfaces_from_route', return_value=dict(v4=dict(interface='A', address='none'), v6=dict(interface='6', address='none'))):
        default = ln.get_default_interfaces()
        assert default['interface'] == 'A'
        assert default['address'] == 'none'
        assert default['ipv4']['interface'] == 'A'
        assert default['ipv4']['address'] == 'none'
        assert default['ipv6']['interface'] == '6'
        assert default['ipv6']['address'] == 'none'

    # Test when route file exists

# Generated at 2022-06-20 18:21:09.900129
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.collector.network.default import NetworkCollector
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.collector.base import BaseCollector
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts.collector import FactsCollector

    def test_LinuxNetworkCollector_is_instance():
        collector = LinuxNetworkCollector(module=None)
        assert isinstance(collector, BaseCollector), "LinuxNetworkCollector is an instance of BaseCollector"

    def test_LinuxNetworkCollector_is_subclass():
        collector = LinuxNetworkCollector(module=None)

# Generated at 2022-06-20 18:21:20.759676
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.network.common.facts import Facts
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.network.common.utils import set_module_args

    facts = Facts(
        module=AnsibleModule(
            argument_spec=dict(
                gather_subset=dict(type='list', default=None),
                gather_network_resources=dict(type='list', default=None)
            )
        ),
        task_vars={
            'ansible_distribution': 'Linux',
            'ansible_platform': 'Linux'
        }
    )
    set_module_args(dict(
        gather_subset=['!all', '!min']
    ))

# Generated at 2022-06-20 18:21:24.504971
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    facts = {}
    network_collector = LinuxNetworkCollector(facts, {})
    assert network_collector
    assert isinstance(network_collector._fact_class, LinuxNetwork)


# Generated at 2022-06-20 18:21:29.916434
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    """Unit test for constructor of class LinuxNetwork"""
    module = FakeAnsibleModule({
        "ANSIBLE_MODULE_ARGS": {
            "gather_subset": "!all,!min",
            "gather_network_resources": "no",
        },
    })
    network_info_instance = LinuxNetwork(module)
    ifaces_info = network_info_instance.get_network_module_resource()
    assert ifaces_info is not None


# Generated at 2022-06-20 18:21:31.365543
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    assert False, "not implemented"



# Generated at 2022-06-20 18:21:39.818719
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # we only test the first part of the function which uses fixed output.
    # the second part with the iproute2 is tested in test_LinuxNetwork_get_interfaces_info
    module = Mock()
    ln = LinuxNetwork(module)
    # should return the ipv4 contents
    assert ln.get_default_interfaces() == {'broadcast': None, 'address': '192.0.2.1', 'netmask': '255.255.255.0', 'network': '192.0.2.0'}



# Generated at 2022-06-20 18:22:04.476808
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    linux_network_collector = LinuxNetworkCollector(None)
    assert linux_network_collector.required_facts == set(['distribution', 'platform'])
    assert linux_network_collector._fact_class == LinuxNetwork

# Generated at 2022-06-20 18:22:06.404788
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    linux_network = get_LinuxNetwork_instance()
    # FIXME: write tests or remove method
    pass

# Generated at 2022-06-20 18:22:08.388427
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    lnc = LinuxNetworkCollector(module)
    assert(lnc is not None)
    assert(lnc.required_facts == set(['distribution', 'platform']))
    assert(lnc._fact_class == LinuxNetwork)
    assert(lnc._platform == 'Linux')


# Generated at 2022-06-20 18:22:15.854002
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    plugin = LinuxNetwork()
    # This is a base setup for a test.
    # It is a very basic one. Only the needed stuff for this test.
    plugin.module = MagicMock()

# Generated at 2022-06-20 18:22:18.704270
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # TODO
    assert True == True

# Generated at 2022-06-20 18:22:33.078504
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from mock import patch, Mock
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.network_common.utils.netutils import get_file_content
    from ansible.module_utils.network_common.utils.netutils import get_default_interface
    from ansible.module_utils.network_common.utils.netutils import get_default_interface_ipv6
    from ansible.module_utils.network_common.utils.netutils import get_default_ip
    module = Mock(spec=AnsibleModule)
    module.params = {}
    module.run_command = Mock(return_value=(0, '', ''))
    type(module).check_mode = False
    module.get_bin_path = Mock(return_value='ip')

# Generated at 2022-06-20 18:22:36.556253
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    network = LinuxNetworkCollector({ "distribution": "debian", "platform": "linux" })
    assert network.get_devices() == {}


# Generated at 2022-06-20 18:22:38.523162
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    result = LinuxNetworkCollector(None)


# Generated at 2022-06-20 18:22:40.410978
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    assert 'lo' == LinuxNetwork().get_default_interfaces()['v4']


# Generated at 2022-06-20 18:22:44.435711
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    '''Constructor of LinuxNetworkCollector'''
    obj = LinuxNetworkCollector(None)
    assert obj.fact_class == LinuxNetwork

# Generated at 2022-06-20 18:23:19.236264
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    (module, network) = MockNetwork.create_network()
    # FIXME: I don't think the following are even possible
    assert network.gateways['v4'] is None
    assert network.gateways['v6'] is None
    # FIXME: I don't think the following are even possible
    assert network.interfaces['default_ipv4']['address'] is None
    assert network.interfaces['default_ipv6']['address'] is None
    # FIXME: I don't think the following are even possible
    assert not network.interfaces['default_ipv4']
    assert not network.interfaces['default_ipv6']
    assert network.interfaces['default_ipv4']['address'] == '192.168.0.1'

# Generated at 2022-06-20 18:23:30.828988
# Unit test for method populate of class LinuxNetwork

# Generated at 2022-06-20 18:23:40.786089
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class LinuxNetwork
    """
    module = AnsibleModule(argument_spec={})
    if not HAS_NETIFACES:
        module.fail_json(msg='The netifaces python module is required')
    if not HAS_IPADDR:
        module.fail_json(msg='The ipaddr python module is required')
    if not HAS_IFADMIN_STATUS:
        module.fail_json(msg='The ifadminstatus python module is required')
    if not HAS_IPLIB:
        module.fail_json(msg='The iplib python module is required')

    # Test if we can create an object instance
    network = LinuxNetwork(module)
    # If we can create an object instance, test method get_interfaces_info
    # If get_interfaces

# Generated at 2022-06-20 18:23:51.216091
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    # TEST 1: No ip_path, /sbin/ip, /bin/ip
    # /bin/ip -> default_ipv6, default_ipv4
    # default_ipv6, default_ipv4 -> interface, ip_cmd
    # Testing for interface["lo"], ip_cmd, ips

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    ip_path = "/usr/bin/ip"
    net = LinuxNetwork(module)
    net.default_ipv4 = {"address": "127.0.0.1"}
    net.default_ipv6 = {"address": "::1"}
    net._parse_ip_cmd_version = Magic

# Generated at 2022-06-20 18:23:57.918379
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = MagicMock()
    interface = {}

    module.get_bin_path.return_value = None
    linux_network = LinuxNetwork(module=module)
    populated_interfaces = linux_network.populate(None, interface)
    assert not populated_interfaces

    module.get_bin_path.return_value = '/usr/bin/ip'
    linux_network = LinuxNetwork(module=module)
    populated_interfaces = linux_network.populate(None, interface)
    assert populated_interfaces



# Generated at 2022-06-20 18:24:10.362969
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    def get_file_content(path, default=None):
        return '{ "default_gateway_v4": "172.23.0.1", "default_gateway_v6": "fe80::21f:6fff:feaf:ed7b" }'

    def get_file_content_default_gw_ipv6_not_resolvable():
        return '{ "default_gateway_v4": "172.23.0.1", "default_gateway_v6": "fd00::21f:6fff:feaf:ed7b" }'


# Generated at 2022-06-20 18:24:19.263119
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)

    fake_file_content = """
default 192.168.1.1 metric 600
default fe80::1 dev eth1 proto kernel metric 256
"""
    with mock.patch('ansible.module_utils.linux.network.Network.get_default_interfaces') as get_default_interfaces:
        get_default_interfaces.return_value = fake_file_content

# Generated at 2022-06-20 18:24:31.000884
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Init
    module = DummyModule()

    filename = os.path.join(os.getcwd(), "test_LinuxNetwork_get_ethtool_data.txt")


# Generated at 2022-06-20 18:24:41.921536
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    src = dict(
        config=dict(
            config='',
            fail_on_errors=False,
            interfaces=dict(),
        ),
        default=dict(
            ipv4=dict(),
            ipv6=dict(),
        ),
        route=dict(
            routes=dict(),
        ),
    )

    module = Mock()
    cls = LinuxNetwork()
    module.fail_json.return_value = None
    cls.get_sysctl = Mock()
    cls.get_interfaces_info = Mock()
    cls.get_routes = Mock()
    cls.get_ip_addresses = Mock()
    cls.get_default_ip = Mock()
    cls.get_default_ip6 = Mock()
    cls.get_default_route = Mock()


# Generated at 2022-06-20 18:24:53.004652
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    system = LinuxNetwork(module)

    fd, tmpsrc = tempfile.mkstemp(prefix='ansible_test_LinuxNetwork_get_interfaces_info_')
    f = os.fdopen(fd, 'w')
    f.write('''{
  "all_ipv4_addresses": [
    "127.0.0.1",
    "192.168.1.1"
  ],
  "all_ipv6_addresses": [
    "::",
    "::1"
  ]
}''')
    f.close()
    fd, tmpout = tempfile.mkstemp(prefix='ansible_test_LinuxNetwork_get_interfaces_info_')

# Generated at 2022-06-20 18:25:34.021779
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    class FakeModule(object):
        def get_bin_path(self, name):
            return '/usr/sbin/ethtool'

        def run_command(self, args, *kwargs):
            rc = 0
            stdout = ''
            stderr = ''

# Generated at 2022-06-20 18:25:40.830512
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """ Unit test for constructor of class LinuxNetworkCollector"""
    obj = LinuxNetworkCollector(None, None, None)
    assert obj._platform == 'Linux'
    assert obj.required_facts == set(['distribution', 'platform'])
    assert obj._fact_class == LinuxNetwork

# Generated at 2022-06-20 18:25:54.828691
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # unit tests
    # check that we can access the LinuxNetwork obj from within the module
    assert hasattr(AnsibleModule, 'linuxnet')
    # check that we have all we need to run the module
    assert hasattr(AnsibleModule.linuxnet, 'get_interfaces_info')
    assert hasattr(AnsibleModule.linuxnet, 'get_routes_info')
    assert hasattr(AnsibleModule.linuxnet, 'get_devices_info')

    # check that we can access the module from within the LinuxNetwork obj
    assert hasattr(AnsibleModule.linuxnet.module, 'params')
    assert hasattr(AnsibleModule.linuxnet.module, 'run_command')
    # check that we have all we need to run the module

# Generated at 2022-06-20 18:25:59.681100
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    """
    Test constructor of class LinuxNetwork
    """
    linux_network = LinuxNetwork()
    assert linux_network

    data = linux_network.get_default_interface('example.com')
    assert data != {}



# Generated at 2022-06-20 18:26:06.757855
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    path = '/bin/ethtool'

# Generated at 2022-06-20 18:26:16.078781
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )

    network = LinuxNetwork(module)
    interfaces, ips = network.get_interfaces_info(network.ip_path, network.default_ipv4, network.default_ipv6)
    module.exit_json(ansible_facts={'ansible_network_resources': {'interfaces': interfaces, 'default_ipv6': network.default_ipv6, 'default_ipv4': network.default_ipv4, 'ipv6': network.interface_ipv6, 'ipv4': network.interface_ipv4, 'ips': ips}})



# Generated at 2022-06-20 18:26:24.987486
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    # Initialize the module
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)
    # Initialize the class
    ln = LinuxNetwork(module)

    # Define the interface than can be used by the loopback interface

# Generated at 2022-06-20 18:26:32.052970
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = MagicMock(name='ansible.module_utils.basic.AnsibleModule')

# Generated at 2022-06-20 18:26:43.088496
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    #m = AnsibleModule(argument_spec=dict())
    failed = False
    changed = False
    ansible_module_mock = AnsibleModuleMock()
    net = LinuxNetwork(ansible_module_mock)
    mtu = {'device': 'test0', 'mtu': 9999}
    interfaces, ips = net.get_interfaces_info('', {'address': '127.0.0.1'}, {})
    if mtu not in interfaces.values():
        failed = True
        print("Failed to get mtu value")
    if interfaces['lo']['mtu'] >= interfaces['lo']['mtu']:
        failed = True
        print("Failed to get appropriate mtu value for lo")

# Generated at 2022-06-20 18:26:53.110560
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    network_obj = LinuxNetworkCollector(dict(ansible_facts=dict(distribution="Linux",
                                                                platform="Linux",
                                                                ansible_default_ipv4=dict(address="172.17.0.1"),
                                                                ansible_default_ipv6=dict(address="fe80::42:caff:fe1b:8044"))))
    #####################################################################################
    # Constructor of NetworkCollector changes the name of the class from NetworkCollector
    # to the inherited class name, LinuxNetworkCollector or FreeBSDNetworkCollector
    # make sure this happens as expected
    #####################################################################################
    assert network_obj.__class__.__name__ == "LinuxNetworkCollector"



# Generated at 2022-06-20 18:27:33.865497
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['all'], type='list'),
            filter=dict(default=None, type='list')
        )
    )

    if not HAS_PYTHON_NETIFACES:
        module.fail_json('Error: python module netifaces is required for gathering network information')

    network = LinuxNetwork(module)
    result = network.populate()
    result['ansible_facts']['ansible_network_resources'].pop('default_ipv4', None)
    result['ansible_facts']['ansible_network_resources'].pop('default_ipv6', None)
    # FIXME: this is not reliable as it is platform dependent

# Generated at 2022-06-20 18:27:47.107832
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-20 18:27:58.033710
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Test with existing device
    module = ansible.module_utils.basic.AnsibleModule(load_fixture('test_LinuxNetwork_populate.py'), {})
    network = LinuxNetwork(module)
    result = network.populate('lo')
    assert result['interface'] == 'lo'
    assert result['type'] == 'loopback'
    assert result['ipv4']['address'] == '127.0.0.1'
    assert result['ipv4']['broadcast'] == ''
    assert result['ipv4']['netmask'] == '255.0.0.0'
    assert result['ipv4']['network'] == '127.0.0.0'
    assert result['ipv6']
    assert result['ipv6'][0]['address'] == '::1'

# Generated at 2022-06-20 18:28:09.434010
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = LinuxNetwork()
    # Ensure that in sysfs the empty path exists
    path = os.path.join("mock_sysfs")
    os.makedirs(path)
    # Mock an _interface
    mock_interface_list = ["eth0", "lo0"]
    mock_interface_hash = {}
    for interface in mock_interface_list:
        mock_interface_hash[interface] = {}
        mock_interface_hash[interface]["device"] = os.path.join(path, interface, "device")
        mock_interface_hash[interface]["address"] = os.path.join(path, interface, "address")
        mock_interface_hash[interface]["flags"] = os.path.join(path, interface, "flags")

# Generated at 2022-06-20 18:28:10.206449
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    assert LinuxNetworkCollector != None


# Generated at 2022-06-20 18:28:21.267242
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-20 18:28:28.396022
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    ''' Test populate of LinuxNetwork '''

    DEFAULT_IPV4 = {
        'address': '127.0.0.1',
        'netmask': '255.0.0.0',
        'network': '127.0.0.0'
    }
    DEFAULT_IPV6 = {
        'address': '::1',
        'prefix': '128',
        'scope': 'host'
    }

    # Test with a few simple interfaces

# Generated at 2022-06-20 18:28:39.478211
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    test_module = AnsibleModule(
        argument_spec={'test_ethtool': {'type': 'str'}}
    )
    # example ethtool output

# Generated at 2022-06-20 18:28:49.081234
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    '''
    result = LinuxNetworkCollector().get_facts()
    assert result['ansible_facts']['ansible_net_interfaces']
    assert result['ansible_facts']['ansible_all_ipv4_addresses']
    assert result['ansible_facts']['ansible_all_ipv6_addresses']
    assert result['ansible_facts']['ansible_net_gw']
    assert result['ansible_facts']['ansible_net_gw6']
    '''


# Generated at 2022-06-20 18:28:58.843270
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    # TODO: write better tests
    # ip_path is None to force returns (no default routing or interface)
    n = LinuxNetwork(None)
    assert n.interface == {}
    assert n.default_interface == {}
    assert n.default_gateway == {}
    assert 'all_ipv4_addresses' in n.ips
    assert 'all_ipv6_addresses' in n.ips
    assert 'test' not in n.interfaces
    assert 'test' not in n.default_interface
    assert n.module is not None


# Generated at 2022-06-20 18:29:39.495473
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type="list"),
            filter=dict(type="dict"),
            cache=dict(type="bool", default=True)
        ),
        supports_check_mode=True
    )

    lni = LinuxNetwork(module)
    lni.populate()

    # if you add or remove any keys here, please update docs
    expected_keys = [
        'default_ipv4',
        'default_ipv6',
        'interfaces',
        'all_ipv4_addresses',
        'all_ipv6_addresses',
    ]

    module.exit_json(ansible_facts=lni.facts)


# Generated at 2022-06-20 18:29:43.896598
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    network_collector = LinuxNetworkCollector()
    assert network_collector._platform == 'Linux'
    assert network_collector.required_facts == set(['distribution', 'platform'])

# Generated at 2022-06-20 18:29:46.836903
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module=module)
    assert ln.module == module



# Generated at 2022-06-20 18:29:58.503812
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    net = LinuxNetwork(warnings=False)
    cmd = "/sbin/ip -o route"
    _ipv4_routes, _ipv6_routes = net.get_routes_info(cmd)
    _default_ipv4, _default_ipv6 = net.get_default_interface()
    _interfaces, _ipaddrs = net.get_interfaces_info(cmd, _default_ipv4, _default_ipv6)
    assert _interfaces
    assert _ipaddrs
    assert "ipv4" in _ipaddrs
    assert "ipv6" in _ipaddrs
