

# Generated at 2022-06-20 18:20:29.935591
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    ln = LinuxNetwork(module=module)
    assert ln.ip_path == '/sbin/ip'
    assert ln.module == module


# Generated at 2022-06-20 18:20:35.353288
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.facts.linux import LinuxNetwork
    from io import StringIO

    ip_path = '/bin/ip'
    default_ipv4 = {}
    default_ipv6 = {}
    interfaces = LinuxNetwork(None).get_interfaces_info(ip_path, default_ipv4, default_ipv6)



# Generated at 2022-06-20 18:20:47.408798
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import doctest
    import json
    import yaml
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda x: x['changed'] == True
    linux_network = LinuxNetwork(module)

    default_ipv4 = dict(address='127.0.0.1')
    default_ipv6 = dict(address='::1')
    test_interfaces, test_ips = linux_network.get_interfaces_info('/bin/ip', default_ipv4, default_ipv6)

    # FIXME: if the test fails, the entire class definition is no longer present
    # To keep debuggin easier, this just throws a RuntimeError

# Generated at 2022-06-20 18:20:50.315458
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: mockup module
    # TODO: mockup response from ip
    l = LinuxNetwork()
    l.get_interfaces_info()
    # TODO: assert

# Generated at 2022-06-20 18:21:03.129018
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    hostname = 'localhost'
    module = FakeAnsibleModule()
    (default_ipv4, default_ipv6) = LinuxNetwork(module).get_default_interfaces()
    assert len(default_ipv4) == 5
    assert len(default_ipv6) == 5
    for key in ['address', 'broadcast', 'netmask', 'macaddress', 'mtu']:
        assert key in default_ipv4
        assert default_ipv4[key] is not None
    assert default_ipv6['address'] is not None
    assert default_ipv6['scope'] == 'host'

    # Default IPv6 is randomly chosen and can be None if none is found.
    # Test to be sure that failed discovery doesn't cause an error.
    hostname = 'localhost'
    module = FakeAnsible

# Generated at 2022-06-20 18:21:05.626790
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    platform = 'Linux'
    facts = {'distribution': 'Linux', 'platform': 'Linux'}
    network = LinuxNetworkCollector(platform, facts)
    assert network._platform == platform


# Generated at 2022-06-20 18:21:17.901894
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = LinuxNetworkCollector(module)
    assert collector.platform == 'Linux'
    assert collector.fact_class == LinuxNetwork
    assert collector.required_facts == {'distribution', 'platform'}
    assert hasattr(collector, '_facts_cache')
    assert collector._facts_cache == {}
    assert hasattr(collector, 'facts')
    assert collector.facts is None
    assert hasattr(collector, 'facts_cache')
    assert collector.facts_cache is None
    assert hasattr(collector, 'fact_cache')
    assert collector.fact_cache is None
    assert hasattr(collector, 'module')
    assert collector.module is module


# Generated at 2022-06-20 18:21:28.141478
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module_path = os.path.dirname(os.path.realpath(__file__))
    fp = open(os.path.join(module_path, "../unit/data/net_linux_ethtool_output.txt"))

    ethtool_mock = MagicMock(return_value=(0, ''.join(fp.readlines()), None))

    module = MagicMock()
    module.run_command = ethtool_mock
    module.get_bin_path.return_value = 'ethtool'
    m = LinuxNetwork(module=module)


# Generated at 2022-06-20 18:21:41.421769
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible.module_utils import basic

    module = basic.AnsibleModule({})
    module.exit_json = lambda: 0
    module.run_command = lambda x: (0, '', '')
    mock_returns = [{'interface': 'eth0', 'address': '192.168.1.1', 'gateway': '192.168.1.254'},
                    {'interface': 'eth0', 'address': 'fe80::dead:beef', 'gateway': 'fe80::1'}]

    def mock_get_default_interfaces(self):
        return mock_returns.pop(0)

    network = LinuxNetwork(module)
    network.get_default_interfaces = mock_get_default_interfaces
    network.populate()


# Generated at 2022-06-20 18:21:46.524481
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    module.exit_json = exit_json
    module.run_command = run_command

    ln = LinuxNetwork(module)
    module.exit_json(
        changed=False,
        ansible_facts={
            'ansible_network_resources': ln.get_resources(),
        },
    )


if __name__ == '__main__':
    test_LinuxNetwork()

# Generated at 2022-06-20 18:22:16.557176
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from . import CommandCollector
    from .distro_facts import FactsCollector

    # CommandCollector is mocked in this test
    cc = CommandCollector
    cc.all = lambda: []

    # distro_facts is mocked in this test
    df = FactsCollector()
    df.all = lambda: {'platform': 'Linux'}

    collector = LinuxNetworkCollector({}, [], CommandCollector(), df)

    assert collector._platform == 'Linux'
    assert collector._fact_class == LinuxNetwork
    assert collector.required_facts == set(['distribution', 'platform'])

# Generated at 2022-06-20 18:22:25.507973
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """
    Unit test for method get_interfaces_info of class LinuxNetwork
    """

    if os.path.exists('/proc/net/bonding/bond0'):
        linux_network = LinuxNetwork()
        default_ipv4, default_ipv6 = linux_network.get_default_interfaces_info()
        interfaces, ips = linux_network.get_interfaces_info(
            ip_path="ip", default_ipv4=default_ipv4, default_ipv6=default_ipv6
        )
        assert '/proc/net/bonding/bond0' in interfaces.get('bond0', {})['filename']
        # NOTE: does this test too much?
        # NOTE: how do we test all_ipv6_addresses, all_ipv4_addresses?

# Generated at 2022-06-20 18:22:38.993084
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Setup mocks
    run_command = mock.MagicMock()
    run_command.side_effect = [
        (0, "default via 192.168.1.1 dev eth0\n", ''),
        (0, "default via 2a01:4f8:161:6191::1 dev eth0\n", '')
    ]
    module = mock.MagicMock()
    module.run_command = run_command
    module.get_bin_path = mock.MagicMock(return_value='/usr/bin/ip')
    # FIXME: add test for case of ip not found

    # Call tested method
    tested = networking_linux.LinuxNetwork(module)
    result = tested.get_default_interfaces()

    # Assertions
    assert run_command.call_count == 2

# Generated at 2022-06-20 18:22:47.365955
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = MockModule()
    module.params = {}
    module.run_command.side_effect = [(0, "", ""), (0, "", "")]
    net = LinuxNetwork(module)
    device = "foo"
    os.path.exists.return_value = True
    ethtool_path = "fake/ethtool/path"
    net.module.get_bin_path.return_value = ethtool_path
    net.get_ethtool_data(device)
    assert net.module.run_command.call_args_list == [call([ethtool_path, '-k', device]), call([ethtool_path, '-T', device])]



# Generated at 2022-06-20 18:22:51.379342
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = LinuxNetwork()
    assert module._network.get_ethtool_data('fake_device') == {'features': {'rx': 'off', 'tx': 'off'}, 'timestamping': [], 'hw_timestamp_filters': [], 'phc_index': None}

# Generated at 2022-06-20 18:23:06.378034
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """
    This test is NOT meant to be run as a unit test.  This is merely a
    scratchpad for the developer to use when creating the unit test.
    """
    # NOTE: You must provide values for the following variables:
    # module_name, binary
    module_name = 'LinuxNetwork'
    binary = 'ip'

    # An instance of ModuleStubber is used by UnitTestCollector in the
    # constructor.  The stubbed instance of the module is required to
    # be passed in to the constructor of this class.
    module = ModuleStubber(ansible_module_name=module_name, binary=binary)

    # If this name is changed to "collector", it must also be changed
    # in the call to collector.collect() below.
    # Note that the name "collector" is also referenced in the


# Generated at 2022-06-20 18:23:11.768944
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(
        argument_spec={},
    )

    lnc = LinuxNetworkCollector(module)

    assert lnc.facts['network'] == {'default_ipv4': {}, 'default_ipv6': {}}


# Generated at 2022-06-20 18:23:25.933057
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Test will only be executed when Python 3.6 or later is used

    m = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    command = dict(
        v4='/sbin/ip -o -4 route show to default',
        v6='/sbin/ip -o -6 route show to default',
    )

    # Fixes issue where ifconfig command doesn't exist
    if not m.get_bin_path('ifconfig'):
        ifconfig_path = '/sbin/ifconfig'
    else:
        ifconfig_path = m.get_bin_path('ifconfig')

    # Redirect I/O messages to a pipe
    old_stdout = os.dup(sys.stdout.fileno())
    old_stderr = os.dup

# Generated at 2022-06-20 18:23:35.514254
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """Unit test for method get_ethtool_data of class LinuxNetwork
    """
    test_module = DummyAnsibleModule(params={'path': '/bin/true'})

# Generated at 2022-06-20 18:23:37.421944
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    n = LinuxNetwork(module)
    assert n.module is not None



# Generated at 2022-06-20 18:24:20.197465
# Unit test for constructor of class LinuxNetwork

# Generated at 2022-06-20 18:24:31.422064
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # TODO: maybe make this an integration test
    m = AnsibleModule(
        argument_spec=dict(
            gather_network_resources=dict(type='bool', default=True),
            gather_subset=dict(type='list', default=list()),
            gather_network_interfaces=dict(type='str', default='yes', choices=['yes', 'no']),
        ),
    )
    n = LinuxNetwork(m)
    resources = n.populate()
    assert resources['default_interface'] == 'ens3'
    assert resources['default_ipv4']['address'] == '10.0.2.15'
    assert resources['default_ipv4']['netmask'] == '255.255.255.0'

# Generated at 2022-06-20 18:24:42.123338
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    class ModuleStub(object):
        def __init__(self, fail_json=False, exit_json=False, result=None):
            self.fail_json = fail_json
            self.exit_json = exit_json
            self.result = result

        def get_bin_path(self, executable=None, required=False, opt_dirs=[]):
            return "/usr/bin/ip"


# Generated at 2022-06-20 18:24:53.071634
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Create the pseudo module - this only provides a dict-like api,
    # so there is no need to create real files.
    module = AnsibleModule(argument_spec={})

# Generated at 2022-06-20 18:25:04.175064
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = MagicMock()
    fake_module = FakeModule(module)
    fake_module.get_bin_path.return_value = True
    ln = LinuxNetwork(fake_module)
    ln.get_interfaces_info = MagicMock()
    ln.get_interfaces_info.return_value = ('interfaces', 'ips')
    ln.get_default_interface = MagicMock()
    ln.get_default_interface.return_value = ('default_interface_v4', 'default_interface_v6')
    ln.get_route = MagicMock()
    ln.get_route.return_value = ('route_v4', 'route_v6')

    ln.populate()

# Generated at 2022-06-20 18:25:08.266074
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    print("Constructor test LinuxNetworkCollector")
    module = NetworkModule()
    facts_cache = FactsCache()
    facts_cache.set_facts(LinuxNetwork.get_facts(module))

    print(facts_cache)
    collector = LinuxNetworkCollector(module, facts_cache)
    print(collector)
    assert collector is not None
    print("End of test LinuxNetworkCollector")


if __name__ == '__main__':
    test_LinuxNetworkCollector()

# Generated at 2022-06-20 18:25:14.305412
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    lnc = LinuxNetworkCollector()
    assert lnc.platform == lnc._platform
    assert lnc.required_facts == lnc._fact_class.required_facts
    assert lnc._fact_class.__name__ == 'LinuxNetwork'


# Generated at 2022-06-20 18:25:23.921926
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    subprocess.Popen("route del -net 0.0.0.0 gw 127.0.0.1", shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    subprocess.Popen("ip route del default", shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    subprocess.Popen("ip addr del dev lo 127.0.0.1/8", shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    arg = {'gather_network_resources': 'no'}
    module = AnsibleModule(argument_spec=arg)
    i = LinuxNetwork(module)
    default_ipv4, default_ipv6 = i.get_defaults_interfaces()
   

# Generated at 2022-06-20 18:25:35.662903
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from ansible.module_utils.facts.collector import base_platform
    from ansible.module_utils.facts.collector import get_collector_name
    from ansible.module_utils.facts.collector import get_collector_for_platform

    platform = base_platform()
    if platform != 'Linux':
        pytest.skip("test_LinuxNetworkCollector.py only supported on Linux")

    # Use the fully-qualified class name here
    # since we're testing whether get_collector_for_platform
    # can return the class and not an instance of it
    name = 'ansible.module_utils.facts.network.LinuxNetworkCollector'
    assert(name == get_collector_name('network', 'Linux'))

# Generated at 2022-06-20 18:25:47.050012
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-20 18:26:25.652920
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # No test possible without mocking `run_command` since it depends on architecture
    pass  # noqa


# Generated at 2022-06-20 18:26:33.035331
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    '''Test function populate of class LinuxNetwork'''
    net = LinuxNetwork()
    net.module.get_bin_path = MagicMock(return_value="/bin/ip")
    net.module.run_command = MagicMock(return_value=[0, '', ''])
    net.get_default_interfaces = MagicMock(return_value=({"address": "2.3.4.5", "promisc": True, "mtu": 1500}, {"address": "6.7.8.9", "promisc": True, "mtu": 1500}))

# Generated at 2022-06-20 18:26:40.976605
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    class Module:
        def __init__(self):
            self.params = {}
        def get_bin_path(self, *args, **kwargs):
            return '/sbin/ethtool'

    class Subprocess:
        PIPE = None

        def __init__(self, args, stdout, stderr):
            self.args = args
            self.stdout = stdout
            self.stderr = stderr

    class Popen:
        def __init__(self, args, stdout, stderr):
            self.args = args
            self.stdout = Subprocess(args, stdout, stderr)
            self.stderr = Subprocess(args, stdout, stderr)


# Generated at 2022-06-20 18:26:47.160365
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    network = LinuxNetwork()
    network.populate()
    assert len(network.interfaces) > 0
    assert len(network.default_ipv4) == 0
    assert len(network.default_ipv6) == 0
    assert isinstance(network.interfaces, dict)
    assert isinstance(network.default_ipv4, dict)
    assert isinstance(network.default_ipv6, dict)



# Generated at 2022-06-20 18:26:59.786554
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    mod = AnsibleModule(argument_spec=dict())
    net = LinuxNetwork(module=mod)

    (ipv4_interface, ipv6_interface) = net.get_default_interface()
    if ipv4_interface:
        mod.debug('ipv4_interface=%s' % json.dumps(ipv4_interface))
    else:
        mod.debug('no ipv4_interface')

    if ipv6_interface:
        mod.debug('ipv6_interface=%s' % json.dumps(ipv6_interface))
    else:
        mod.debug('no ipv6_interface')


# Generated at 2022-06-20 18:27:02.044419
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    result = LinuxNetwork(module).dump()
    assert isinstance(result, dict)


# Generated at 2022-06-20 18:27:13.173546
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    tmp_dir = os.path.realpath(mkdtemp())
    print(tmp_dir)
    path = os.path.join(tmp_dir, 'sys')
    os.makedirs(os.path.join(path, 'class', 'net', 'lo'))
    os.makedirs(os.path.join(path, 'class', 'net', 'eth0'))
    os.makedirs(os.path.join(path, 'class', 'net', 'eth1'))

    # Create zero-length files
    for f in ['address', 'mtu', 'operstate', 'type', 'speed']:
        for i in ['lo', 'eth0', 'eth1']:
            file_path = os.path.join(path, 'class', 'net', i, f)

# Generated at 2022-06-20 18:27:16.670551
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    got = LinuxNetwork(module)
    assert got.ip_path == module.get_bin_path('ip')
    assert got.module == module


# Generated at 2022-06-20 18:27:18.722240
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    assert LinuxNetwork(Host(), {}).populate() is None


# Generated at 2022-06-20 18:27:26.326779
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # set fake module input
    module = AnsibleModule(argument_spec={})

    # set module args
    module.params = dict(
        gather_subset='all',
        use_ipv6=None,
    )

    # Test
    # Run code to be tested
    obj = LinuxNetwork(module)

    # print("obj.dhcp6c_pidfile: " + pformat(obj.dhcp6c_pidfile))
    assert obj.dhcp6c_pidfile == '/var/run/dhcp6c.pid'
    assert obj.dhclient_pidfile == '/var/run/dhclient.pid'
    assert obj.dhclient_script == '/sbin/dhclient-script'
    assert obj.dhclient_leasefile == '/var/lib/dhcp/dhclient.leases'
    assert obj

# Generated at 2022-06-20 18:28:10.875504
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = MockModule()
    n = LinuxNetwork(module)
    assert n


# Generated at 2022-06-20 18:28:14.298299
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    '''
    Unit test for constructor of class LinuxNetwork
    '''
    module = AnsibleModule({})
    obj = LinuxNetwork(module)
    res = obj.get_interfaces_info(obj, '', '')
    assert res

# Generated at 2022-06-20 18:28:17.217684
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    ln = LinuxNetwork()
    ln.get_interfaces_info(None, None, None)



# Generated at 2022-06-20 18:28:27.732339
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from ansible.module_utils.basic import AnsibleModule
    module_args = dict()
    module_args['path'] = '/foo/bar/baz'
    module = AnsibleModule(
        argument_spec=dict(path=dict(aliases=['bin_path'])),
        supports_check_mode=True,
    )
    module.run_command = Mock(return_value=(0, '', ''))
    getpass = Mock()
    getpass.getuser = Mock(return_value='foo')
    pwd = Mock()
    pwd.getpwnam = Mock(return_value=('bar', 'baz', 1, 2, '/'))

# Generated at 2022-06-20 18:28:39.280153
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    m = AnsibleModule(
    )
    if not m:
        raise ValueError
    l = LinuxNetwork(m)
    m.run_command = run_command_test_get_ethtool_data

# Generated at 2022-06-20 18:28:52.226304
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    class FakeModule(object):
        def get_bin_path(self, arg):
            return self.bin_paths[arg]

        def run_command(self, args, **kwargs):
            return self.run_command_args[0], self.run_command_args[1], self.run_command_args[2]

    def test_gen_fake_data(bin_path, ip_data, bridge_data, ethtool_data, ethtool_features_data, ethtool_timestamping_data):
        n = LinuxNetwork(FakeModule())
        n.bin_paths = bin_path
        n.run_command_args = ip_data
        n.get_ethtool_data = lambda x: ethtool_data[x]

# Generated at 2022-06-20 18:28:56.774997
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    assert LinuxNetworkCollector._platform == 'Linux'
    assert LinuxNetworkCollector.required_facts == {'platform', 'distribution'}
    assert LinuxNetworkCollector._fact_class == LinuxNetwork


# Generated at 2022-06-20 18:29:04.731040
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    mc = AnsibleModuleCollector(
        dict(
            module_args=dict(
                gather_subset=['all'],
            )
        ),
        AnsibleModule(
            argument_spec=dict(
                gather_subset=dict(default=[], type='list')
            )
        )
    )
    collector = LinuxNetworkCollector(mc)
    assert collector.platform == 'Linux'

# Generated at 2022-06-20 18:29:12.283329
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible_collections.ansible.misc.tests.unit.modules.utils import ModuleTestCase
    import ansible_collections.ansible.misc.plugins.module_utils.network.common.network as network
    import ansible_collections.ansible.misc.plugins.module_utils.network.common.utils as utils
    from ansible_collections.ansible.misc.plugins.module_utils.network.linux.interfaces import Interfaces

    module = ModuleTestCase.get_module(
        argument_spec=dict(),
        supports_check_mode=True,
    )


# Generated at 2022-06-20 18:29:21.767747
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():

    # FIXME: we should move these to a unittest class that inherits from AnsibleModule
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: "/bin/ethtool"

    module.run_command = lambda *x: (0, '', None)
    linux_network = LinuxNetwork(module)
    linux_network.get_ethtool_data(device="eth0")

    module.run_command = lambda *x: (0, '', None)
    linux_network = LinuxNetwork(module)
    linux_network.get_ethtool_data(device="eth1")

    module.run_command = lambda *x: (0, '', None)
    linux_network = LinuxNetwork(module)
    linux_network.get_ethtool_data(device="eth2")

