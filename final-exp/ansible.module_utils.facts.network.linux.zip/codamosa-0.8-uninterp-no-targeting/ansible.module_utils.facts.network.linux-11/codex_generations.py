

# Generated at 2022-06-20 18:20:37.690909
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    import json
    import StringIO
    from ansible.module_utils._text import to_bytes
    ######################################
    # Test 1:
    # If no info file is found, all keys should be
    # set to None
    ######################################
    module = AnsibleModule(
        argument_spec = dict(),
    )

    module.params = {}

    # Create a fake file containing
    # fake network information
    fake_file_path = os.path.join(os.path.dirname(__file__), 'fake_files/linux_network_no_files')
    fake_file_handler = open(fake_file_path, 'r')
    fake_file_content = fake_file_handler.read()
    fake_file_handler.close()


# Generated at 2022-06-20 18:20:47.204439
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(type='list', default=['all']),
    })
    ln = LinuxNetwork(module)
    r = ln.populate()
    assert r['default_ipv4']['address']
    # macaddress is only present if the interface is up
    if r['interfaces']['eth0']['active']:
        assert r['interfaces']['eth0']['macaddress']
    assert r['interfaces']['eth0']['address']
    assert r['interfaces']['eth0']['netmask']
    assert r['interfaces']['eth0']['network']
    assert r['interfaces']['eth0']['broadcast']

# Generated at 2022-06-20 18:20:59.977852
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    global module_args, ansible_facts
    global module
    module_args = dict()
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    # NOTE: No way currently to not pass ansible_facts
    ansible_facts = dict()
    ln = LinuxNetwork()
    ln.populate()
    assert ansible_facts['ansible_all_ipv4_addresses'] == ['172.16.0.22', '172.16.0.33']
    assert ansible_facts['ansible_all_ipv6_addresses'] == ['2001:0:9d38:6ab8:3052:70d2:e396:ef0c']

# Generated at 2022-06-20 18:21:11.072892
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    ln = LinuxNetwork()
    # TODO: MOCK
    ln.get_file_content = lambda path: None
    # TODO: MOCK
    ln.run_command = lambda cmd, err_msg: (0, '', '')
    data, ips = ln.get_interfaces_info('ip', {'address': '127.0.0.1'}, {'address': '::1'})
    # Test if ipv4, ipv6 and macaddress were correctly resolved
    assert '127.0.0.1' == data['lo']['ipv4']['address']
    assert '::1' == data['lo']['ipv6'][0]['address']
    assert '00:00:00:00:00:00' == data['lo']['macaddress']


# Generated at 2022-06-20 18:21:16.599921
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """ Unit test for LinuxNetworkCollector. """
    # Initialize a module
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    # Initialize a LinuxNetworkCollector instance
    network_col_obj = NetworkCollector(module)
    # pylint: disable=protected-access
    assert network_col_obj._platform == 'Linux'
    assert network_col_obj._fact_class == LinuxNetwork
    assert network_col_obj.required_facts == set(['distribution', 'platform'])
    # pylint: enable=protected-access


# Generated at 2022-06-20 18:21:23.363871
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec=dict())

    # Successfully create a collector
    collector = LinuxNetworkCollector(module=module)

    # If a subclass does not define _platform then fail
    collector._platform = None
    with pytest.raises(NetworkCollectorError):
        collector.collect()

    # If a subclass does not define _fact_class then fail
    collector._platform = 'Linux'
    collector._fact_class = None
    with pytest.raises(NetworkCollectorError):
        collector.collect()

    # If a subclass does not define required_facts then fail
    collector._platform = 'Linux'
    collector._fact_class = LinuxNetwork
    collector.required_facts = None
    with pytest.raises(NetworkCollectorError):
        collector.collect()

    # Any other subclass like 'Windows'

# Generated at 2022-06-20 18:21:28.480376
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.params['gather_network_resources'] = 'interfaces'
    network = LinuxNetwork(module)
    network.populate()
    interfaces = network.get_interfaces_info(linux_network.get_bin_path("ip"), {}, {})[0]
    assert 'lo' in interfaces

# Generated at 2022-06-20 18:21:41.457221
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    m = AnsibleModule(
        argument_spec = dict()
    )
    ln = LinuxNetwork(m)
    data = ln.get_ethtool_data("eth0")
    assert data['features']['tx_checksumming'] == 'on'
    assert data['features']['rx_checksumming'] == 'on'
    assert not data['timestamping']
    assert not data['phc_index']
    assert not data['hw_timestamp_filters']

    data = ln.get_ethtool_data("eno1")
    assert data['features']['tx_checksumming'] == 'on'
    assert data['features']['tx_checksum_ipv4'] == 'on'
    assert data['features']['tx_checksum_ipv6'] == 'on'


# Generated at 2022-06-20 18:21:49.246768
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    module = NetworkModule(argument_spec={}, check_invalid_arguments=False)
    network = LinuxNetwork(module)
    default_ipv4 = {'address': '1.2.3.4'}
    default_ipv6 = {'address': 'dead:beef::1'}

# Generated at 2022-06-20 18:22:02.379262
# Unit test for constructor of class LinuxNetwork

# Generated at 2022-06-20 18:22:36.436514
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    l = LinuxNetwork(module)
    # check that the interface_speeds dict's keys are present in
    # the interface_speed data
    assert set(l.interface_speeds.keys()).issubset(set(l.interface_speed.keys()))
    # check that the valid_change_speeds dict's keys are present in
    # the interface_speed data
    assert set(l.valid_change_speeds.keys()).issubset(set(l.interface_speed.keys()))
    # check that a valid interface speed exists
    assert set(l.interface_speed.keys()).intersection({'100gbps', '50gbps', '40gbps'})
    # check that a valid change speed exists

# Generated at 2022-06-20 18:22:42.096877
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec=dict())
    ln = LinuxNetwork(module)
    assert ln
    assert ln.module
    assert ln.ip_bin
    assert ln.ip_path
    assert ln.run_commands
    assert ln.get_default_interface
    assert ln.get_interfaces_info



# Generated at 2022-06-20 18:22:52.491397
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    fixture_path = os.path.dirname(__name__) + "/fixtures/ethtool_k.txt"
    with open(fixture_path, 'r') as fixture_file:
        data = fixture_file.read()
    linux_network = LinuxNetwork(None)
    K_data = linux_network.get_ethtool_data(None)
    fixture = json.loads(data)["features"]
    if K_data["features"] == fixture:
        return True
    else:
        return False


# Generated at 2022-06-20 18:23:06.717364
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from io import StringIO
    from getpass import getuser
    from os import getuid, rename
    from tempfile import mkstemp
    from shutil import move
    from time import time

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_native
    from ansible.module_utils.common.process import get_bin_path

    def create_fake_file(content, filename, directory=None):
        if directory is None:
            directory = os.getcwd()

        _, tmp_path = mkstemp(prefix=filename, dir=directory)
        with open(tmp_path, 'w') as tmp_file:
            tmp_file.write(to_native(content, nonstring='passthru'))
        return tmp_path


# Generated at 2022-06-20 18:23:15.934475
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_bytes

    class TestModule(object):
        def __init__(self, ip_path, run_command_environ_update, debug):
            self.ip_path = ip_path
            self.run_command_environ_update = run_command_environ_update
            self.debug = debug
            self.params = dict(
                default_ipv4=dict(gateway=None),
                default_ipv6=dict(gateway=None),
            )

        def get_bin_path(self, arg, opt_dirs=[]):
            return self.ip_path


# Generated at 2022-06-20 18:23:26.372476
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', default=['!all']),
            use_ipv6=dict(type='bool', default=True),
            config_file=dict(type='path', default='/etc/network/interfaces'),
        ),
        supports_check_mode=False,
    )
    ln = LinuxNetwork(module)
    # gather_subset is used as a list of 'str' not as a list of 'str or None'.
    # If a 'str or None' is added to gather_subset, set it to 'str' or ignore it.
    gather_subset = []
    for gs in ln.gather_subset:
        if gs is None:
            continue

# Generated at 2022-06-20 18:23:36.310176
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    interface = {"ipv4": {"address": "10.0.2.15", "broadcast": "10.0.2.255", "gateway": "10.0.2.2", "netmask": "255.255.255.0", "network": "10.0.2.0"}, "ipv6": [], "macaddress": "08:00:27:54:c8:d4", "mtu": 1500, "type": "Ethernet"}
    assert interface == LinuxNetwork.get_default_interfaces({"ens3": interface},{"ens3":"ens3"})[0]

# Generated at 2022-06-20 18:23:39.362812
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = MagicMock()
    # the constructor takes no args
    linux_network = LinuxNetwork(module)
    # instantiate the class



# Generated at 2022-06-20 18:23:41.471263
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    c = LinuxNetworkCollector(module)
    assert c.module is module
    assert c.facts is None

# Generated at 2022-06-20 18:23:53.054819
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from ansible.module_utils.facts.network.base import NetworkCollector, Network
    from ansible.module_utils import basic
    from ansible.module_utils.facts import ansible_collector
    from ansible.module_utils._text import to_bytes

    module = basic.AnsibleModule(argument_spec={})
    module.run_command = lambda *args, **kwargs: (0, "", "")
    module.debug = lambda *args, **kwargs: None
    module.get_bin_path = lambda *args, **kwargs: '/bin/ip'
    module.warn = lambda *args: None


# Generated at 2022-06-20 18:24:22.124778
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    lnc = LinuxNetworkCollector({})
    assert lnc.platform == 'Linux'


# Generated at 2022-06-20 18:24:32.191916
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    network = LinuxNetwork()
    network.module = MockModule({
        'kernel': '2.6',
    })
    network.populate()
    assert network.interfaces == {
        'lo': {
            'device': 'lo',
            'ipv4': {
                'address': '127.0.0.1',
                'broadcast': 'host',
                'netmask': '255.0.0.0',
                'network': '127.0.0.0'
            },
            'ipv6': [
                {
                    'address': '::1',
                    'prefix': '128',
                    'scope': 'host'
                }
            ],
            'mtu': 65536,
            'promisc': False,
            'type': 'loopback'
        }
    }
    assert network

# Generated at 2022-06-20 18:24:41.203534
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={
        'state': {'default': 'present', 'choices': ['present', 'absent']}
    })
    # Less typing so tests are more readable, same as `module.exit_json()`
    exit_json = partial(module.exit_json, changed=False)

    # create a singleton instance of LinuxNetwork, so we have a default interface
    linux_network_test = LinuxNetwork(module)

    # test that 2 ethernet ports (eth0 and eth1) can be parsed from ethtool output
    args = [linux_network_test.module.get_bin_path("ethtool"), '-k', 'eth0']
    rc, stdout, stderr = linux_network_test.module.run_command(args, errors='surrogate_then_replace')

# Generated at 2022-06-20 18:24:52.220975
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    import ansible.module_utils.facts.network.linux as linux
    fake_module = FakeANSIModule()
    # fake_module.run_command = ModuleStub(**{'return_value': (0, 'fake', '')})
    fake_module.run_command = ModuleStub(**{
        'default_returns': {
            'return_values': [0, 'fake', ''],
            'kwa': {'arg_blah': 'blah'},
        }})
    mock_socket = Mock()
    # Mock default values for socket module
    # https://docs.python.org/3/library/socket.html#constants
    mock_socket.AF_UNIX = 1
    mock_socket.AF_INET = 2
    mock_socket.AF_INET6 = 10

    linux

# Generated at 2022-06-20 18:25:03.715224
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import tempfile
    import shutil
    import os
    filename = "/tmp/interfaces"
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-20 18:25:09.142160
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule({})
    network = LinuxNetwork(module)
    interfaces, ips = network.get_interfaces_info('', {}, {})

    assert isinstance(interfaces, dict), 'interfaces is not a dict'
    assert interfaces, 'interfaces is empty'
    assert isinstance(ips, dict), 'ips is not a dict'
    assert ips, 'ips is empty'
    assert isinstance(ips['all_ipv4_addresses'], list), 'all_ipv4_addresses is not a list'
    assert isinstance(ips['all_ipv6_addresses'], list), 'all_ipv6_addresses is not a list'



# Generated at 2022-06-20 18:25:23.096511
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Check that result for empty output is an empty dict
    module = AnsibleModule(argument_spec=dict())
    module.params['device'] = 'eth0'
    linux_network = LinuxNetwork(module)
    assert linux_network.get_ethtool_data(module.params['device']) == {}

    # Check that result for filled output contains correct data
    module = AnsibleModule(argument_spec=dict())
    module.params['device'] = 'eth0'
    module.run_command = Mock()

# Generated at 2022-06-20 18:25:30.976679
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    dummy_module = DummyAnsibleModule()
    linux_network = LinuxNetwork(dummy_module)
    device = 'dummy'
    data = linux_network.get_ethtool_data(device)
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data


# Generated at 2022-06-20 18:25:44.767111
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    net = LinuxNetwork()
    net.module = AnsibleModuleMock()
    net.module.get_bin_path = lambda x: True

    net.module.run_command = lambda x: (
        0,  # RC
        'default via 10.10.10.254 dev eth0',  # stdout
        '',  # stderr
        )
    net.module.run_command.side_effect = (
        (0, 'default via 10.10.10.254 dev eth0', ''),  # IPv4 route
        (0, '', ''),  # IPv6 route
        (0, '', ''),  # IPv4 address
        (0, '', ''),  # IPv6 address
    )

    interfaces, ips = net.get_interfaces_info('ip', None, None)
    default_

# Generated at 2022-06-20 18:25:48.482748
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    result = True
    msg = 'LinuxNetwork populate test failed!'
    module = FakeModule()
    mynetwork = LinuxNetwork(module)
    mynetwork.populate()
    if mynetwork.default_ipv4 is None:
        result = False
    if mynetwork.default_ipv6 is None:
        result = False
    if mynetwork.interfaces is None:
        result = False
    if mynetwork.ips is None:
        result = False
    assert result, msg

# Generated at 2022-06-20 18:26:24.198372
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from ansible_collections.community.general.tests.unit.compat.mock import (
        Mock,
        patch,
    )
    from ansible_collections.community.general.plugins.module_utils.network.common import (
        FactsBase,
    )
    from ansible_collections.community.general.plugins.module_utils.network.common.utils import (
        dict_merge,
    )

    # Note: get_bin_path is mocked in test_module so we don't need to mock it here.
    # Note: FactsBase uses dict_merge so we can just mock that here.
    module = Mock()
    module.run_command.return_value = (0, "ip_path", "")
    module.get_bin_path.return_value = "/some/path"

# Generated at 2022-06-20 18:26:25.987677
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    a = LinuxNetwork()
    assert a.INTERFACE_TYPE['1'] == 'ethernet'



# Generated at 2022-06-20 18:26:31.763994
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = LinuxNetworkCollector(module)
    assert isinstance(collector._fact_class, LinuxNetwork)
    assert collector._platform == 'Linux'
    assert collector.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-20 18:26:42.051778
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec=dict())
    ln = LinuxNetwork(module)
    assert ln.module == module

    os.environ['PATH'] = os.environ['PATH'] + ":%s" % os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'lib', 'ansible', 'modules', 'network', 'linux'))
    os.environ['ANSIBLE_LIBRARY'] = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..', 'lib', 'ansible', 'modules', 'network', 'linux'))

    ip_path = ln.module.get_bin_path('ip')
    if ip_path:
        ln.V

# Generated at 2022-06-20 18:26:50.007102
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Given: a LinuxNetwork object
    linux_network = LinuxNetwork()
    # and: a folder which doesn't exist
    folder = '/dev/null/nothere'
    # and: default IPv4 and IPv6 dictionaries
    default_ipv4 = dict(address='127.0.0.1')
    default_ipv6 = dict(address='::1')
    # When: calling get_interfaces_info
    (interfaces, ips) = linux_network.get_interfaces_info(folder, default_ipv4, default_ipv6)
    # Then: we should get no interfaces
    assert 0 == len(interfaces), '0 interfaces'

# Generated at 2022-06-20 18:27:02.003193
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    test_object = LinuxNetwork(dict(module=None, params=dict()))
    device = 'eth0'
    # Test with missing ethtool_path
    test_object.module.get_bin_path = MagicMock(side_effect=lambda x: None)
    assert test_object.get_ethtool_data(device) == {}

    # Test with no features gathered from ethtool
    # FIXME: cleanup this mock
    test_object.module.get_bin_path = MagicMock(side_effect=lambda x: '/bin/ethtool')
    mock_run_command = MagicMock(return_value=(1, None, None))
    test_object.module.run_command = mock_run_command
    assert test_object.get_ethtool_data(device) == {}

    # Test with good data
   

# Generated at 2022-06-20 18:27:11.950226
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    assert LinuxNetworkCollector.platform == 'Linux'
    assert LinuxNetworkCollector.fact_class == LinuxNetwork
    assert LinuxNetworkCollector.required_facts == {'distribution', 'platform'}

"""
    This method accepts an IPv6 address as input and returns a list of:
    4-byte, 3-byte, and 2-byte strings, in that order, which are the leading
    segments of the full IPv6 address.

    :param ipv6_address: An IPv6 address.
    :type ipv6_address: string
    :returns: A list of strings where each string is 1-4 bytes of the full IPv6
    address.
    :rtype: list
"""

# Generated at 2022-06-20 18:27:16.885737
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Create a mock module
    module = AnsibleModule({})
    # Create an empty class
    network_info = LinuxNetwork(module)
    network_info.module = {}
    network_info.populate()
    # assert that the interface eth0 is found
    assert 'eth0' in network_info.interfaces

# Generated at 2022-06-20 18:27:25.429223
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    # test os.path.exists(ip_path)
    with tempfile.NamedTemporaryFile() as f:
        module = AnsibleModule(argument_spec={})
        module.params = dict(ip_path=f.name)
        ln = LinuxNetwork(module)
        assert isinstance(ln.ip_path, str) == True
        assert ln.ip_path == f.name

    # test os.path.exists(ip_path) == False
    with tempfile.NamedTemporaryFile() as f:
        module = AnsibleModule(argument_spec={})
        module.params = dict(ip_path=f.name)
        os.unlink(f.name)
        ln = Linux

# Generated at 2022-06-20 18:27:36.414756
# Unit test for method populate of class LinuxNetwork

# Generated at 2022-06-20 18:28:19.177109
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    def _get_ips(path):
        # not a class method, so no self
        rc, out, _ = module.run_command([path, '-4', 'addr', 'show', 'lo'], errors='surrogate_then_replace')
        ips = set()
        for line in out.splitlines():
            if not line:
                continue
            words = line.split()
            for w in words:
                if w.count('.') == 3:
                    ips.add(w)
        return ips

# noinspection PyTypeChecker
    module = AnsibleModule(argument_spec={})
    ips_before_populate = _get_ips(module.get_bin_path('ip'))

    ln = LinuxNetwork(module)
    ln.populate()
    ips_

# Generated at 2022-06-20 18:28:29.710407
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    import platform
    distro = platform.dist()[0]
    distro_version = platform.dist()[1]
    ln = LinuxNetwork()

    # CentOS
    ln.module.run_command = MagicMock(return_value=(0, "", ""))
    ln.module.get_option = MagicMock(return_value="eth0")
    assert ln.populate(distro, distro_version) == (None, None)

    # Debian
    ln.module.run_command = MagicMock(return_value=(0, "", ""))
    assert ln.populate("Debian", "") == (None, None)

    # Unknown
    ln.module.run_command = MagicMock(return_value=(0, "", ""))

# Generated at 2022-06-20 18:28:38.754333
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    """
    :return:
    """
    # Mock a module
    mod = mock.MagicMock()

    # Create an instance of LinuxNetwork
    ln = LinuxNetwork(mod)

    # Mock the run_command method
    ln.run_command = mock.MagicMock(return_value=(0, 'eth0', ''))

    # This is the method we are testing
    default_ipv4, default_ipv6 = ln.get_default_interfaces(None)

    # There should be no IP addresses (no output from command)
    assert default_ipv4 == {}
    assert default_ipv6 == {}



# Generated at 2022-06-20 18:28:40.358605
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    pass


# Generated at 2022-06-20 18:28:48.211819
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    platform_impl = LinuxNetwork(module)
    data = platform_impl.get_ethtool_data('lo')
    assert data['features']['tx_checksumming'] == 'on'
    assert data['features']['rx_all'] == 'off'
    assert data['features']['rx_fcs'] == 'off'
    if hasattr(platform, 'python_version_tuple'):
        if platform.python_version_tuple()[0] >= 3:
            # python 3.x does not have iteritems
            assert type(data['features'].items()) == dict_items
        else:
            assert type(data['features'].iteritems()) == dict_itemiterator

# Generated at 2022-06-20 18:29:00.948582
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    # Setup the fake module
    class FakeModule:
        def __init__(self):
            self.paths = dict()

        def get_bin_path(self, path, opt_dirs=[]):
            return self.paths.get(path)

        def run_command(self, args, **kwargs):
            args[0] = self.get_bin_path(args[0])
            f = FakeCommand(args, **kwargs)
            return f.rc, f.stdout, f.stderr

    class FakeCommand:
        def __init__(self, args, **kwargs):
            cmd = args[0]
            if cmd == "/bin/ip":
                self.ip(args, **kwargs)

# Generated at 2022-06-20 18:29:10.804835
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """
    Test get_ethtool_data method of the LinuxNetwork class
    """

# Generated at 2022-06-20 18:29:17.408145
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=['!config'], type='list')})
    obj = LinuxNetwork(module=module, params={})
    obj.get_default_interfaces()
    assert obj.default_interface['ipv4'] is not None
    assert obj.default_interface['ipv6'] is not None


# Generated at 2022-06-20 18:29:30.152748
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    # Create a module
    module = AnsibleModule(argument_spec={})
    # Create a instance of this class
    network = LinuxNetwork(module)
    # Test results
    # NOTE: some bits can be None because we get a decent subset of values from
    # the module, which may or may not be able to get the data from the system
    assert network.interfaces['eth0']['type'] in ('ether', 'unknown', None) or (network.interfaces['eth0']['type'] == 'bonding' and network.interfaces['eth0']['slaves'] == ['eth1', 'eth2'])
    assert 'lo' not in network.interfaces
    assert network.interfaces['eth1']['promisc'] == None
    assert 'ipv4' not in network.interfaces['eth2']

# Generated at 2022-06-20 18:29:40.725001
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    """Test for method LinuxNetwork.get_default_interfaces"""
    ln = LinuxNetwork()
    ln.module = Mock()
    ln.module.run_command.return_value = [0, IP_OUTPUT, '']
    (default_ipv4, default_ipv6) = ln.get_default_interfaces()
    assert default_ipv4 == {'address': '10.20.30.40',
                            'gateway': '10.20.30.1',
                            'interface': 'bond0'}
    assert default_ipv6 == {'address': '2001:1::2',
                            'gateway': '2001:1::1',
                            'interface': 'bond0'}
    return True
