

# Generated at 2022-06-20 18:20:36.160278
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # FIXME: wow, this whole setup is janky as hell

    class MockModule(object):
        def __init__(self):
            self.params = {}

    class MockAnsibleModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg):
            return '/usr/bin/ip'

        def run_command(self, cmd, errors=None):
            if cmd == ['/usr/bin/ip', '-6', 'route']:
                return 0, '', ''
            elif cmd == ['/usr/bin/ip', '-4', 'route']:
                return 0, '', ''
            elif cmd == ['/usr/bin/ip', '-6', 'address', 'show']:
                return 0, '', ''

# Generated at 2022-06-20 18:20:43.233261
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    linux_network = LinuxNetwork(module)
    ip_path = '/usr/bin/ip'

    default_ipv4, default_ipv6 = linux_network.get_default_interfaces(ip_path)

    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)


# Generated at 2022-06-20 18:20:55.619470
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_args = None
            self.run_command_return_value = None
            self.run_command_rc = 0

        def get_bin_path(self, _):
            return "/bin/ip"

        def fail_json(self, **kwargs):
            pass

        def run_command(self, args, **kwargs):
            self.run_command_args = args
            return self.run_command_rc, self.run_command_return_value, None

    def get_file_content_mock(path, default=None):
        res = {}
        res['/sys/class/net/eth0/address'] = '00:11:22:33:44:55'
        res

# Generated at 2022-06-20 18:21:09.227244
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """ Unit test for LinuxNetwork.get_interfaces_info """
    f_module = FakeModule()
    orig_module = sys.modules.get('ansible.module_utils.basic')
    sys.modules['ansible.module_utils.basic'] = f_module

    ln = LinuxNetwork()
    default_ipv4 = {}
    default_ipv6 = {}
    interfaces, ips = ln.get_interfaces_info('./ip', default_ipv4, default_ipv6)
    os.remove('/sys/class/net/dummy0/address')
    # FIXME: this isn't a well-formed test
    assert interfaces['dummy0']['macaddress'] == '00:00:00:00:00:00'

    sys.modules['ansible.module_utils.basic']

# Generated at 2022-06-20 18:21:20.357605
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True,
    )
    module_params = {}
    network = LinuxNetwork(module)

# Generated at 2022-06-20 18:21:30.123304
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    class MockModule:

        def __init__(self):
            self.params = {}

        def get_bin_path(self, path):
            return 'bin/' + path

        def run_command(self, args, errors=None):
            cmd = args[0]
            if cmd == 'bin/ip':
                if args[1] == 'addr':
                    if args[2] in ('show', 'show', 'secondary'):
                        return 0, create_ip_output(args[3]), None
                elif args[1] == 'route':
                    return 0, create_ip_route_output(args[3]), None
                elif args[1] == '-o' and args[2] in ('-4', '-6'):
                    return 0, create_ip_output(args[4]), None

# Generated at 2022-06-20 18:21:42.071043
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # arrange
    module = MagicMock()
    module.get_bin_path.return_value = 'ethtool_path'
    device = "fake_device"
    ln = LinuxNetwork(module)

# Generated at 2022-06-20 18:21:50.350486
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    linux_network = LinuxNetwork(module)
    # Unit test for method get_default_interfaces of class LinuxNetwork
    default_ipv4, default_ipv6 = linux_network.get_default_interfaces()
    assert isinstance(default_ipv4, dict) is True
    assert isinstance(default_ipv6, dict) is True



# Generated at 2022-06-20 18:22:02.506396
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    # TODO: this needs some testing, not remotely unit tested
    module = AnsibleModule(argument_spec=dict(
        ip_version=dict(type='str', required=False, default='all'),
    ))
    net = LinuxNetwork(module)
    # Test get_ip_version
    for ip_version in ['4', '4only', '6', '6only', 'all']:
        module._init_params = {'ip_version': ip_version}
        assert net.get_ip_version() == ip_version
    # Test get_interfaces_addresses
    assert net.get_interfaces_addresses() == ({}, {})
    # Test get_interfaces_info

# Generated at 2022-06-20 18:22:10.027566
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.network.common.utils import dict_merge

    module = Mock()
    module.get_bin_path.side_effect = lambda exe: exe

    # NOTE: the test data is slightly modified from the real output
    # removed a loopback device ('lo' in this case) and added some 'dummy' devices
    # cut lines to make it fit better

    ip_path = '/sbin/ip'
    default_ipv4 = dict()
    default_ipv6 = dict()

    network = LinuxNetwork(module)

    data = network.get_interfaces_info(ip_path, default_ipv4, default_ipv6)


# Generated at 2022-06-20 18:22:43.832069
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    class MockModule():
        def get_bin_path(self, name):
            return name
    module = MockModule()
    l = LinuxNetwork(module)
    assert l.ip_path == 'ip'
    assert l.module == module
    assert l.default_ipv4['address'] == '127.0.0.1'
    assert l.default_ipv6['address'] == '::1'
    rc = 0
    out = "default via 10.0.0.1 dev eth0 proto static 10.0.0.0/24 dev eth0 proto kernel scope link src 10.0.0.2"
    err = ""
    (interface_v4, interface_v6) = l.get_route_data(rc, out, err)

# Generated at 2022-06-20 18:22:51.114628
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    ip_path = '/sbin/ip'
    default_ipv4, default_ipv6 = LinuxNetwork.get_default_interfaces_from_iproute(ip_path)
    interfaces, ips = LinuxNetwork.get_interfaces_info(ip_path, default_ipv4, default_ipv6)
    assert len(interfaces) > 0
    assert len(ips['all_ipv4_addresses']) > 0
    assert len(ips['all_ipv6_addresses']) > 0

# Generated at 2022-06-20 18:22:59.348768
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # Constructor test
    module = NetworkModule()
    collector = LinuxNetworkCollector(module)
    assert collector.platform == 'Linux' or collector.platform == 'unknown'
    assert collector.required_facts == {'distribution', 'platform'}
    assert isinstance(collector.facts, LinuxNetwork)

# Constructor test for class LinuxNetwork

# Generated at 2022-06-20 18:23:10.560591
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils._text import to_text

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            gather_network_resources=dict(default=['all'], type='list')
        ),
        supports_check_mode=True
    )

    network = LinuxNetwork(module)
    network.populate(network.gather_subset, network.gather_network_resources)

    module.exit_json(
        ansible_facts=dict(network=network.get_facts())
    )


# import module snippets
from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 18:23:22.560482
# Unit test for method get_default_interfaces of class LinuxNetwork

# Generated at 2022-06-20 18:23:25.884954
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from ansible.module_utils.facts.collector.network.linux import LinuxNetworkCollector
    collector = LinuxNetworkCollector()
    assert collector.platform == 'Linux'
    assert collector.fact_class == LinuxNetwork
    assert collector.required_facts == set(['distribution', 'platform'])
    assert collector.vendor_facts == {}

# Generated at 2022-06-20 18:23:35.484631
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    class StubUnixCommand:
        def get_bin_path(self, _, default=""):
            if _ == "ip":
                return "/sbin/ip"
            if _ == "ethtool":
                return "/usr/sbin/ethtool"
            return default

        def run_command(self, _, errors="surrogate_or_strict"):
            if _ == ['/sbin/ip', '-k', 'lo']:
                return (0, "", "")
            if _ == ['/usr/sbin/ethtool', '-T', 'lo']:
                return (0, "", "")
            if _ == ['/sbin/ip', '-k', 'br0']:
                return (0, "", "")

# Generated at 2022-06-20 18:23:41.151516
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec=dict(name=dict()))
    path = "/tmp/test_get_ethtool_data"
    if not os.path.exists(path):
        os.mkdir(path)

    mock = MockLinuxNetwork(module)
    mock.get_bin_path = Mock(return_value=path)
    ethtool_response = "Features for eth_test:\n      rx-checksumming: on\n"
    ethtool_response += "      tx-checksumming: on\n"
    ethtool_response += "      tx-checksum-ipv4: on\n"
    ethtool_response += "      tx-checksum-unneeded: off\n"
    ethtool_response += "      rx-checksum-unneeded: off\n"
    ethtool

# Generated at 2022-06-20 18:23:52.143595
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    mod = FakeModule()
    net = LinuxNetwork(mod)
    assert net.bin_path['ip'] ==  '/bin/ip-2'
    assert net.bin_path['nmcli'] ==  '/bin/nmcli-4'
    assert net.bin_path['nmcli_v1'] ==  '/bin/nmcli-3'
    assert net.bin_path['nmcli_v2'] ==  '/bin/nmcli-4'
    assert net.bin_path['nmtui'] ==  '/bin/nmtui-2'
    assert net.bin_path['nmcli_nm'] ==  '/bin/nmcli_nm-1'
    assert net.bin_path['nmcli_d'] ==  '/bin/nmcli_d-1'

# Generated at 2022-06-20 18:23:59.970095
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Mock a module object
    class fake_module:
        params = {}
        def get_bin_path(self, name, required=False):
            return name

    fake_module = fake_module()


# Generated at 2022-06-20 18:24:37.913905
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    module.exit_json = MagicMock()

    if getattr(module, 'exit_json', None):
        module.run_command = MagicMock(return_value=(0, 'lo\n', ''))
        module.get_bin_path = MagicMock(return_value='/bin/ip')
        ln = LinuxNetwork(module)
        ln.get_default_interfaces()
        module.run_command.assert_called_with(['/bin/ip', 'route', 'show', '0.0.0.0/0'])
        # TODO: verify return value



# Generated at 2022-06-20 18:24:50.885159
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    spec = dict(
        default_ipv4=dict(),
        default_ipv6=dict(),
        interfaces=dict(),
        ips=dict(),
        gateways=dict(),
    )
    default_ipv4 = dict()
    default_ipv6 = dict()
    interfaces = dict()
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    gateways = dict()
    expected_result = dict(
        default_ipv4=default_ipv4,
        default_ipv6=default_ipv6,
        interfaces=interfaces,
        ips=ips,
        gateways=gateways,
    )

    fake_module = FakeModule(**spec)

# Generated at 2022-06-20 18:25:00.287850
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec=dict(gather_subset=dict(default='all', type='list')))
    nc = LinuxNetworkCollector(module)
    nc.collect()
    facts = nc.get_facts()
    required_facts = set(['distribution', 'platform'])
    assert facts['ansible_network_resources']['capabilities']['platform']['name'] == 'Linux'
    assert nc.required_facts == required_facts


# Generated at 2022-06-20 18:25:13.539307
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={
        'default_interface': {'type': 'str', 'default': 'default'},
    })

    test_cases = (
        # /proc/net/route
        # Iface	Destination	Gateway 	Flags	RefCnt	Use	Metric	Mask		MTU	Window	IRTT
        # eth0	00000000	0102A8C0	0003	0	0	0	00000000	0	0	0
        # lo	00000000	0102A8C0	0003	0	0	0	00000000	0	0	0
        ('0102A8C0', 'eth0', '10.160.192.1'),
        ('00000000', 'eth0', '10.160.192.1'),
        # TODO: test more cases
    )

# Generated at 2022-06-20 18:25:22.059991
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    #
    #
    #
    mock_module = unittest.mock.MagicMock()
    mock_module.get_bin_path.return_value = None

    mock_class = unittest.mock.MagicMock()
    mock_class.return_value.run_command.return_value = (0, "{ \"10.0.0.0/8\": \"eth0\" }", "")

    ln = LinuxNetwork(mock_module)
    with unittest.mock.patch('ansible.module_utils.facts.network.get_active_interface_info', mock_class):
        ln.populate()

# Generated at 2022-06-20 18:25:34.397137
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    # A simple inspection of a system shows that the following values are
    # reasonable.  If these values differ on your system, then you should
    # rerun the following command and replace the corresponding values here:
    #
    # ip route show to 0/0 | awk '{print $3, $5}'
    ipv4 = {u'address': "172.22.60.193"}
    ipv6 = {u'address': u"fe80::215:5dff:fe30:5a5b"}

    # A simple inspection of a system shows that the following values are
    # reasonable.  If these values differ on your system, then you should
    # rerun the following commands and replace the corresponding values here:
    #
    #   ip route show to 0/0 | grep -v default | awk '{print $1}'


# Generated at 2022-06-20 18:25:43.244124
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec=dict())
    ln = LinuxNetwork(module=module)

    # test with LSB
    with patch('os.path.isfile') as mock_isfile:
        mock_isfile.return_value = True
        with patch('os.readlink') as mock_readlink:
            mock_readlink.return_value = '/path/to/file'
            with patch('os.listdir') as mock_listdir:
                mock_listdir.return_value = ['bond0', 'bond1']
                with patch('os.path.isdir') as mock_isdir:
                    mock_isdir.return_value = True
                    with patch.object(LinuxNetwork, 'get_interfaces_info') as mock_get_interfaces_info:
                        mock_get_interfaces

# Generated at 2022-06-20 18:25:56.232260
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModuleMock()
    module.params = dict(
        connection=dict(
            network_os='Linux',
            network_os_version='7.0',
            network_os_db_connection='mongodb://localhost',
            alias='default',
        ),
    )
    # TODO: Find better mocking methods in the future.
    #       See https://github.com/ansible/ansible/issues/54963 for more details.
    #       https://github.com/ansible/ansible/issues/54963
    #       https://github.com/ansible/ansible/issues/54963
    #       https://github.com/ansible/ansible/issues/54963

# Generated at 2022-06-20 18:26:08.367463
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    linux_network = LinuxNetwork()

    def mock_run_command(command, errors='surrogate_then_replace'):
        if command == ['ip', 'route', 'get', '8.8.8.8']:
            return 0, '8.8.8.8 via 23.23.23.23 dev eth0 src 42.42.42.42', ''
        elif command == ['ip', '-6', 'route', 'get', '2001:4860:4860::8888']:
            return 0, '2001:4860:4860::8888 dev eth0  src 2001:db8:1234::42', ''
        elif command == ['ip', 'route', 'get', '192.168.1.1']:
            return 0, 'RTNETLINK answers: Invalid argument', ''

# Generated at 2022-06-20 18:26:18.210614
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    default_ipv4_expected = dict()
    default_ipv4_expected['address'] = '10.255.0.2'
    default_ipv4_expected['broadcast'] = '10.255.3.255'
    default_ipv4_expected['netmask'] = '255.255.252.0'
    default_ipv4_expected['network'] = '10.255.0.0'

    default_ipv6_expected = dict()
    default_ipv6_expected['address'] = 'fe80::222:19ff:fe33:4455'
    default_ipv6_expected['prefix'] = '64'
    default_ipv6_expected['scope'] = 'link'

    default_ipv4, default_ipv6 = LinuxNetwork().get_default_interfaces()
   

# Generated at 2022-06-20 18:27:05.189657
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """Run unit test for LinuxNetwork.get_interfaces_info."""
    # Get fake module
    module = get_fake_module(False, False)
    network = LinuxNetwork(module)
    ipv4 = dict(address='127.0.0.1')
    ipv6 = dict(address='::1')
    (interfaces, ips) = network.get_interfaces_info('/usr/bin/ip', ipv4, ipv6)
    assert interfaces
    assert ips
    # test if vlan device is present
    if 'vlan1000' in interfaces:
        assert interfaces['vlan1000']
    # test if bridge device is present
    if 'br0' in interfaces:
        assert interfaces['br0']
    # test if bonding device is present

# Generated at 2022-06-20 18:27:06.545570
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    LinuxNetworkCollector()


# Generated at 2022-06-20 18:27:16.757877
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # Create the base mock environment for this test.
    module_args = dict(
        gather_subset=['all'],
    )
    module = AnsibleModule(argument_spec=module_args)
    module.run_command = MagicMock(return_value=[0, "", ""])
    module.get_bin_path = MagicMock(return_value="/bin/ip")

    net_module = LinuxNetworkCollector.factory(module)
    net_module.get_default_ipv4_interface = MagicMock(return_value=None)
    net_module.get_default_ipv6_interface = MagicMock(return_value=None)
    net_module.get_interfaces_info = MagicMock(return_value=({}, {}))


# Generated at 2022-06-20 18:27:27.798589
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4 = {}
    default_ipv6 = {}



# Generated at 2022-06-20 18:27:37.968501
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    ip_path = '/sbin/ip'
    default_ipv4 = {'address': '192.168.1.1'}  # will be overwritten by a real value
    default_ipv6 = {'address': 'fe80::1'}  # will be overwritten by a real value
    l = LinuxNetwork()
    interfaces, ips = l.get_interfaces_info(ip_path, default_ipv4, default_ipv6)
    # Parse some interfaces because we know they exists
    for item in ('lo', 'eth0'):
        assert interfaces[item]['device'] == item
        if 'ipv4' in interfaces[item]:
            assert type(interfaces[item]['ipv4']['address']) is str

# Generated at 2022-06-20 18:27:47.553556
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    # Constructor of LinuxNetwork takes a module, which is a MockAnsibleModule.
    # We need to pass it an argument_spec, which is a dict of allowed parameters.
    mod = MockAnsibleModule({
        'gather_subset': dict(required=False, type='list'),
        'gather_network_resources': dict(required=False, type='list'),
        'gather_network_resources': dict(required=False, type='list'),
        'use_ipv6': dict(required=False, type='bool'),
        'config': dict(required=False, type='dict'),
    })
    net = LinuxNetwork(module=mod)
    assert net


# Generated at 2022-06-20 18:27:48.478492
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import doctest
    doctest.testmod(LinuxNetwork)



# Generated at 2022-06-20 18:27:55.127989
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    assert ln.network_state['ipv4'] == {}
    assert ln.network_state['ipv6'] == {}
    assert ln.network_state['interfaces'] == {}
    assert ln.network_state['routes'] == {}



# Generated at 2022-06-20 18:28:08.247152
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    # hwaddr (macaddr)
    assert LinuxNetwork().get_hwaddr("eth0") == '00:0c:29:8c:11:b1'
    assert LinuxNetwork().get_hwaddr("lo") == '00:00:00:00:00:00'
    assert LinuxNetwork().get_hwaddr("lx") is None

    # ipv4
    # TODO: probably not the best test (need better mocking)
    assert LinuxNetwork().get_ipv4_addr("eth0") == '192.168.122.176'
    assert LinuxNetwork().get_ipv4_addr("lo") == '127.0.0.1'
    assert LinuxNetwork().get_ipv4_addr("lx") is None

    # ipv4 interface
    # TODO: probably not the best test (need better mocking

# Generated at 2022-06-20 18:28:14.915707
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    from ansible.module_utils import basic

    m = basic.AnsibleModule(argument_spec={})
    i = LinuxNetwork(m)
    d = i.get_default_interfaces()
    assert d['default_ipv4']['address'] != ''
    assert d['default_ipv6']['address'] != ''


# Generated at 2022-06-20 18:29:01.668560
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = ansible_module_get_network_module(argument_spec=dict(), check_invalid_arguments=False, bypass_checks=True)
    module.run_command = Mock(return_value=(0, '', ''))
    network_module = LinuxNetwork(module)

    assert network_module.get_ethtool_data('lo') == {}


# Generated at 2022-06-20 18:29:04.953637
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    """Constructor"""

    ln = LinuxNetwork()
    # TODO: add assertions
    assert type(ln) is LinuxNetwork



# Generated at 2022-06-20 18:29:09.713331
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    m = MockModule()
    l = LinuxNetwork(module=m)
    output = l.get_ethtool_data(device='eth0')
    assert 'features' in output, "Expected dict with `features` key"
    assert 'SG' in output['features'], "Expected `features` key to contain an SG key"
    assert output['timestamping'] == ['symmetric', 'rx_filters', 'tx_type', 'tx_timestamp_filters']



# Generated at 2022-06-20 18:29:20.838612
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    default_ipv4 = {'address': '192.0.2.1'}
    default_ipv6 = {'address': '2001:db8:1::1'}

# Generated at 2022-06-20 18:29:28.295962
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    network = LinuxNetwork()
    network.module = type('', (), {
        'run_command': lambda x, check_rc=True, encoding=None: (0, '', ''),
        'get_bin_path': lambda x: []
    })();

    # Empty interfaces
    interfaces = {}
    ips = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )

    # Packet and socket are missing
    patched_network_module.PACKET_SUPPORT = False
    patched_network_module.SOCKET_SUPPORT = False
    patched_network_module.netstat_bin = None
    patched_network_module.ss_bin = None
    patched_network_module.ip_bin = None

    # Populate facts
    network.populate

# Generated at 2022-06-20 18:29:36.610874
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    result = dict(
        ansible_facts=dict(
            distribution=dict(
                distribution="Fedora"
            ),
            platform="Linux"
        )
    )
    module.exit_json(**result)

if __name__ == '__main__':
    test_LinuxNetworkCollector()

# Generated at 2022-06-20 18:29:49.403596
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # NOTE: this is a function not a class method
    def run_test(test, result, **kwargs):
        m = LinuxNetwork()
        m.gw = MagicMock(return_value=result)
        test_result = m.get_default_interfaces(**kwargs)
        assert result == test_result

    run_test(0, 'eth0', default_ipv4={'address': '192.168.0.1'})
    run_test(0, None, default_ipv4={})
    run_test(1, 'eth1', default_ipv4={'address': '192.168.0.1'})
    run_test(1, None, default_ipv4={})

# Generated at 2022-06-20 18:29:59.183212
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    import platform
    import ansible.module_utils.basic

    if platform.linux_distribution()[0] not in ['RedHat', 'CentOS', 'Scientific', 'OracleLinux']:
        # TODO: Add more distros here
        return

    # Create the module object
    module = ansible.module_utils.basic.AnsibleModule(
        argument_spec=dict(),
    )
    module.check_mode = False
    module.exit_json = exit_json
    module.run_command = run_command

    # Create an instance of the module
    linux_network = LinuxNetwork(module)
    linux_network.get_default_interfaces()

