

# Generated at 2022-06-20 18:20:28.939633
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    obj = LinuxNetwork()
    assert True is not False  # TODO: more complete tests



# Generated at 2022-06-20 18:20:31.521981
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    network = LinuxNetwork()

    rc, out, err = network.module.run_command([], errors='surrogate_then_replace')
    network.module.fail_json(msg=err)

# Generated at 2022-06-20 18:20:43.382045
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    """
    Test the `get_default_interfaces` function
    """
    # Initialize a fake class
    test_class = LinuxNetwork(None)

    # First case is a system with no default routes in it
    with open('tests/get-default-interfaces-test-1.txt', 'r') as f:
        v4_out = f.read()
    with open('tests/get-default-interfaces-test-2.txt', 'r') as f:
        v6_out = f.read()
    result = test_class.get_default_interfaces(v4_out, v6_out)
    expected = {'v4': {}, 'v6': {}}
    assert result == expected

    # Second case is a system with default routes in it

# Generated at 2022-06-20 18:20:54.093059
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    import kernel_config
    module = kernel_config

    network = LinuxNetwork(module)

    default_ipv4, default_ipv6 = network.get_default_interfaces()

    assert 'macaddress' in default_ipv4
    assert 'macaddress' in default_ipv6

    assert 'netmask' in default_ipv4
    assert 'prefix' in default_ipv6

    assert 'address' in default_ipv4
    assert 'address' in default_ipv6

    assert 'mtu' in default_ipv4
    assert 'mtu' in default_ipv6


# Generated at 2022-06-20 18:21:05.074550
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = MagicMock()
    module.get_bin_path = MagicMock()
    dev = MagicMock()
    dev.run_command = MagicMock()
    dev.run_command.return_value = (0, 'out', 'err')
    net = LinuxNetwork(module)
    n = MagicMock()
    n.nics = "nics"
    n.bonds = "bonds"
    n.vlans = "vlans"
    n.bridges = "bridges"
    n.default_interface = "eth0"

# Generated at 2022-06-20 18:21:13.977099
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils import basic
    module = basic.AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))

    # Mock basic.AnsibleModule.run_command() to return the above mocked dicts
    LinuxNetwork(module).get_ethtool_data('eth0')



# Generated at 2022-06-20 18:21:19.865708
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict(
            config_file=dict(type='str', required=True),
            config_format=dict(type='str', default='ini')
        )
    )

    # Using non-existing config file to test defaults
    network_info = LinuxNetwork(module).get_interfaces_info(None, None, None)
    assert (len(network_info[0]) == 1)
    assert (list(network_info[0].keys())[0] == "lo")
    assert (network_info[1]['all_ipv4_addresses'] == [])
    assert (network_info[1]['all_ipv6_addresses'] == [])
    assert (network_info[0]['lo']['device'] == 'lo')

# Generated at 2022-06-20 18:21:29.885677
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    import os
    from ansible.module_utils.facts.network.linux import LinuxNetwork
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six.moves.urllib.request import urlopen

    # get content from url
    url = 'https://raw.githubusercontent.com/ansible/ansible/devel/lib/ansible/module_utils/facts/network/linux/ip_route.txt'
    content = to_text(urlopen(url).read())

    ip_path = os.path.realpath(__file__)
    ln = LinuxNetwork(
        module=object(),
        ip_path=ip_path,
        lsb_distrib_codename=None,
        lsb_distrib_id=None
    )
    data = {}


# Generated at 2022-06-20 18:21:39.346033
# Unit test for method populate of class LinuxNetwork

# Generated at 2022-06-20 18:21:52.613398
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """Basic test with fake data"""

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    # Set args

# Generated at 2022-06-20 18:22:15.487330
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    ln = LinuxNetwork()

# Utility function to return the default interface name
#   returns the name of the default interface if this can be determined
#   if it cannot be determined, it returns None

# Generated at 2022-06-20 18:22:24.977774
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        )
    )

    # This is for symmetry with the other platforms (which don't require
    # this parameter)
    module.params['gather_network_resources'] = ['all']
    module.params['gather_network_resources'].extend(module.params['gather_subset'])

    # Create a new instance of LinuxNetwork
    ln = LinuxNetwork(module)

    # The method populate returns a dict
    # Using get_bin_path() to get the ansible module binary path
    # Using get_file_content() to get the content of /etc/os-release
    # Using get_file_content() to get the content of /etc/bonding/bonding

# Generated at 2022-06-20 18:22:27.511539
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # TODO: implement method test
    pass

# Generated at 2022-06-20 18:22:39.658109
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = DummyAnsibleModule()
    network = LinuxNetworkCollector(module).collect()

    assert network
    assert network['default_ipv4']['address'] == '192.0.2.41'
    assert network['default_ipv4']['broadcast'] == '192.0.2.255'
    assert network['default_ipv4']['netmask'] == '255.255.255.0'
    assert network['default_ipv4']['network'] == '192.0.2.0'
    assert network['default_ipv4']['mtu'] == 1500
    assert network['default_ipv4']['type'] == 'unknown'
    assert network['default_ipv6']['address'] == '2001:db8:2::41'

# Generated at 2022-06-20 18:22:49.894391
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-20 18:22:54.546925
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    current_kernel = KernelNetwork(module)
    from pprint import pprint
    pprint(current_kernel.interfaces)


if __name__ == '__main__':
    test_LinuxNetwork()

# Generated at 2022-06-20 18:23:03.561837
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    pprint(ln.ip_interface_data)
    pprint(ln.ip_routing_data)
    pprint(ln.ip_addresses_data)

# import module snippets
from ansible.module_utils.basic import *
from ansible.module_utils.facts import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 18:23:14.166474
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    # mock the return of the run_command method
    instance = LinuxNetwork()
    instance.get_bin_path = MagicMock(return_value='/sbin/ip')
    instance.run_command = MagicMock(return_value=(0, 'default via 192.168.1.1 dev eth0\ndefault via 2001:db8:0:1::1 dev eth1', ''))

    ipv4, ipv6 = instance.get_default_interfaces()

    assert ipv4 == {'address': '192.168.1.1', 'device': 'eth0'}
    assert ipv6 == {'address': '2001:db8:0:1::1', 'device': 'eth1'}


# Generated at 2022-06-20 18:23:18.003547
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = MockLinuxNetworkModule()
    ln = LinuxNetwork(module)
    assert isinstance(ln, LinuxNetwork)



# Generated at 2022-06-20 18:23:28.547010
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    nm = LinuxNetwork(module)
    ipv4, ipv6 = nm.get_default_interfaces()
    default_ipv4 = {}
    if ipv4['gateway']:
        default_ipv4['address'] = ipv4['gateway']
    default_ipv6 = {}
    if ipv6['gateway']:
        default_ipv6['address'] = ipv6['gateway']
    nm.get_interfaces_info(ip_path='/bin/ip', default_ipv4=default_ipv4, default_ipv6=default_ipv6)

# Generated at 2022-06-20 18:24:01.759253
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    module = NetworkModule(argument_spec=dict(), check_invalid_arguments=False, bypass_checks=True)
    ip_path = module.get_bin_path("ip")
    default_ipv4 = dict()
    default_ipv6 = dict()
    default_ipv4['address'] = "192.168.1.1"
    default_ipv6['address'] = "fe80::2aa:ff:fe28:9c5a"
    ln = LinuxNetwork(module)
    interfaces, ips = ln.get_interfaces_info(ip_path, default_ipv4, default_ipv6)
    assert interfaces['lo']['device'] == 'lo'
    assert interfaces['lo']['ipv4']['address'] == '127.0.0.1'
   

# Generated at 2022-06-20 18:24:13.653887
# Unit test for constructor of class LinuxNetwork

# Generated at 2022-06-20 18:24:23.515196
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all', '!min'], type='list')
        ),
        # FIXME
        check_invalid_arguments=False
    )

    ln = LinuxNetwork(module)
    ln.init_socket()
    interfaces, ips = ln.get_interfaces_info('ip', {}, {})

    for device in interfaces:
        for address_type in ['ipv4', 'ipv4_secondaries']:
            if address_type in interfaces[device]:
                for address in interfaces[device][address_type]:
                    if 'broadcast' in address:
                        assert valid_ipv4(address['broadcast'])
                    assert valid_ipv4(address['address'])
                    assert valid_

# Generated at 2022-06-20 18:24:36.088787
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    network = LinuxNetwork()
    network.module = DummyModule()
    network.module.run_command = Mock(return_value=(0, 'mock_out', 'mock_err'))
    network.get_interfaces_info = Mock(return_value=([],[]))
    network.get_default_interfaces = Mock(return_value=({'interface': 'eth0', 'address': '192.168.1.1'},
                                                        {'interface': 'eth0', 'address': '2001:db8::1'}))
    network.get_interfaces = Mock(return_value=([],[]))
    network.get_routes = Mock(return_value=([],[]))
    network.get_ipv6_default_gateway = Mock(return_value=None)
    network.get_

# Generated at 2022-06-20 18:24:44.798752
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    linux_network = LinuxNetwork(module)
    interfaces_info, ips = linux_network.get_interfaces_info("",
                                                             {'address': '10.0.0.1'},
                                                             {'address': 'fd00::1'})

    assert interfaces_info['lo']['ipv4']['address'] == '127.0.0.1'
    assert interfaces_info['lo']['ipv4']['netmask'] == '255.0.0.0'
    assert interfaces_info['lo']['ipv4']['broadcast'] == '127.255.255.255'
    assert interfaces_info['lo']['ipv4']['network'] == '127.0.0.0'
   

# Generated at 2022-06-20 18:24:47.685829
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    result = LinuxNetworkCollector(dict(module=dict()))._collect()
    assert result == dict(ansible_facts=dict(network=dict()))


# Generated at 2022-06-20 18:24:52.016387
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # Set up the LinuxNetworkCollector() class.
    network_collector = LinuxNetworkCollector()

    # Assert that required_facts are present.
    assert 'distribution' in network_collector.required_facts
    assert 'platform' in network_collector.required_facts


# Generated at 2022-06-20 18:24:59.433558
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec=dict())
    network_collector = LinuxNetworkCollector(module=module)
    fact_class = network_collector.collect()[0]
    assert fact_class.__class__.__name__ == 'LinuxNetwork'
    assert fact_class._platform == 'Linux'
    assert fact_class.interfaces



# Generated at 2022-06-20 18:25:13.071944
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-20 18:25:23.709607
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import TestCase
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import Mock, patch

    class Test(TestCase):
        def setUp(self):
            self.module = Mock()
            self.module.params = {'gather_subset': ['!all', '!min']}
            self.module.run_command = Mock()
            self.module.get_bin_path = Mock()
            self.class_obj = LinuxNetworkCollector(self.module)

    test = Test()
    test.setUp()
    assert test.class_obj._platform == 'Linux'
    assert test.class_obj._fact_class == LinuxNetwork
    assert test.class_obj

# Generated at 2022-06-20 18:26:08.216546
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # arrange
    class Module:
        def get_bin_path(self, _):
            return "/usr/sbin/ip"

        def run_command(self, cmd, errors='surrogate_then_replace'):
            if cmd[-1] == "eth0":
                return 0, sample_output_ip_addr_show_eth0, ""
            elif cmd[-1] == "eth1":
                return 0, sample_output_ip_addr_show_eth1, ""
            elif cmd[-1] == "lo":
                return 0, sample_output_ip_addr_show_lo, ""
            elif cmd[-1] == "eth2":
                return 0, sample_output_ip_addr_show_eth2, ""

# Generated at 2022-06-20 18:26:17.486659
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import unittest
    import stat

    def makedev(s):
        return stat.S_IFCHR if s.startswith('c') else stat.S_IFBLK

    class BufferedUnixSocket(object):
        def __init__(self, target):
            self.target = target

        def fileno(self):
            return self.target.fileno()

        def recv(self, count, flags=None):
            if self.target.recv(1) == b'':
                raise socket.timeout()
            return self.target.recv(count, flags)


# Generated at 2022-06-20 18:26:26.613697
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

# Generated at 2022-06-20 18:26:37.443153
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """
    Unit test
    """
    module = AnsibleModule(
        argument_spec = dict(
            ip_path = dict(default='/sbin/ip')
        ),
        supports_check_mode = True
    )
    if not os.path.exists(module.params['ip_path']):
        module.fail_json(msg="ip command not found")

    network_info = LinuxNetwork(module)
    interfaces, ips = network_info.get_interfaces_info(
        ip_path=module.params['ip_path'],
        default_ipv4=dict(),
        default_ipv6=dict()
    )
    # FIXME: unit test the output of this function
    assert interfaces


# Generated at 2022-06-20 18:26:45.737352
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    # example data for this function
    class Args:

        def __init__(self):
            self._ansible_debug = True

    args = Args()

    def parse_route_line(line):
        words = line.split()
        return words[0], words[1], words[7]

    def get_file_content(path, default=None):

        def get_file_content():
            with open(path, 'r') as f:
                return f.readline().strip()

        return get_file_content()

    class LinuxNetwork(LinuxNetwork):

        def __init__(self):
            self.module = Args()

        def get_file_content(self, path, default=None):
            return get_file_content(path, default=default)


# Generated at 2022-06-20 18:26:57.920728
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    import pytest
    import mock

    class MockModule(object):
        def __init__(self):
            self.run_command = mock.Mock()
            self.fail_json = mock.Mock()

    class MockAnsibleModule(object):
        def __init__(self):
            self.module = MockModule()

    module = MockModule()

    # test for phc_index, timestamping, features, hw_timestamp_filters

# Generated at 2022-06-20 18:27:09.703140
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = get_test_module()
    module.get_bin_path = lambda x: x
    module.run_command = lambda x: (0, 'if0\nif1\n', '')
    data = dict(
        all_ipv4_addresses=[],
        all_ipv6_addresses=[],
    )
    ln = LinuxNetwork(module, data)
    assert len(ln.interfaces) == 2
    assert 'if0' in ln.interfaces
    assert 'if1' in ln.interfaces
    assert ln.interfaces['if0']['device'] == 'if0'
    assert ln.interfaces['if1']['device'] == 'if1'
    assert len(ln.interfaces_pci) == 0

# Generated at 2022-06-20 18:27:16.987892
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = ['!all']
    module.params['filter'] = ['bond0']
    net = LinuxNetwork(module)
    facts = net.populate()
    assert 'interfaces' in facts
    assert 'bond0' in facts['interfaces']
    assert 'ipv4' in facts['interfaces']['bond0']
    assert 'address' in facts['interfaces']['bond0']['ipv4']
    assert 'macaddress' in facts['interfaces']['bond0']
    assert 'mtu' in facts['interfaces']['bond0']
    assert 'ipv6' in facts['interfaces']['bond0']

# Generated at 2022-06-20 18:27:25.622902
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    import os
    import unittest
    from functools import partial
    from tempfile import TemporaryDirectory

    from ansible.utils.path import unfrackpath
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.linux import ethtool

    class Template:
        def __init__(self, search_path=None):
            self._search_path = search_path

        def search_one(self, name, paths=None):
            return name

        def searchenv(self, name, varname, default=None):
            return self._search_path


# Generated at 2022-06-20 18:27:36.529816
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    """ Unit test for the LinuxNetwork.get_default_interfaces method """

    def mock_get_file_content(path):
        """ Mock the get_file_content method """
        if path == '/proc/net/ipv6_route':
            return '''2001:db8::/64 dev eth0 proto kernel metric 256 expires 2591958 pref medium fe80::/64 dev eth0 proto kernel metric 256 expires 2591958 pref medium default via fe80::211:22ff:fe33:4455 dev eth0 proto ra metric 1024 expires 1777 pref medium'''

# Generated at 2022-06-20 18:28:23.124885
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    os.environ['PATH'] = '/usr/sbin:/sbin:/usr/bin:/bin'
    module = AnsibleModule(argument_spec=dict())
    os.environ['PATH'] = '/usr/sbin:/sbin:/usr/bin:/bin'
    test_obj = LinuxNetwork(module)
    error_msg = "Expected dictionary, got %s instead" % str(type(test_obj.default_ipv4))
    assert isinstance(test_obj.default_ipv4, dict), error_msg
    error_msg = "Expected dictionary, got %s instead" % str(type(test_obj.default_ipv6))
    assert isinstance(test_obj.default_ipv6, dict), error_msg


# Generated at 2022-06-20 18:28:33.178870
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import pytest
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.utils import dict_merge, dict_merge_deeply
    from .test_fixtures.linux_interfaces import \
        OLD_INTERFACES, INTERFACES_WITH_IPV4, INTERFACES_WITH_IPV6, INTERFACES_WITH_IPV4_IPV6, \
        INTERFACES_WITH_IPV4_IPV6_SECONDARIES


# Generated at 2022-06-20 18:28:45.941458
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    ModuleUtil.show_deprecation_warning()
    # Setting up a dummy object that contains the required paramters to instantiate the class
    module = OpenShiftFactsUtils.AnsibleModuleMock()
    module.params = {}

    # Creating a instance of the class
    n_collector_obj = LinuxNetworkCollector(module)
    print("Type of n_collector_obj is " + str(type(n_collector_obj)))
    # Checking if n_collector_obj is an instance and an instance of the required class
    assert isinstance(n_collector_obj, LinuxNetworkCollector)
    assert isinstance(n_collector_obj, NetworkCollector)


# Generated at 2022-06-20 18:28:48.278360
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    return LinuxNetwork(dict(module=Mock()), Mock())


# Generated at 2022-06-20 18:28:50.711093
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # FIXME: stub for now
    assert True



# Generated at 2022-06-20 18:29:02.027223
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import re
    import sys

    if sys.version_info < (3, 4):
        from mock import patch
    else:
        from unittest.mock import patch

    # TODO: these strings could stand to be better cleaned up
    IP_OUTPUT_loopback = '''1: lo: <LOOPBACK> mtu 65536 qdisc noop state DOWN group default qlen 1
    link/loopback 00:00:00:00:00:00 brd 00:00:00:00:00:00
    inet 127.0.0.1/8 scope host lo
       valid_lft forever preferred_lft forever
    inet6 ::1/128 scope host
       valid_lft forever preferred_lft forever'''


# Generated at 2022-06-20 18:29:07.664246
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    assert hasattr(LinuxNetworkCollector, '_fact_class')
    assert LinuxNetworkCollector._fact_class == LinuxNetwork
    assert hasattr(LinuxNetworkCollector, 'required_facts')
    assert LinuxNetworkCollector.required_facts == set(['distribution', 'platform'])



# Generated at 2022-06-20 18:29:20.239411
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # Setup the mock_module
    mock_module = AnsibleModule(argument_spec={
        'interfaces': dict(type=str, default='')
    })

    # Setup the Registry() instance
    registry = Registry()

    # Setup the instance of LinuxNetwork()
    linux_network = LinuxNetwork(registry, mock_module)

    if not linux_network.route_path:
        pytest.skip('route binary not found')

    if not linux_network.ip_path:
        pytest.skip('ip binary not found')

    if not linux_network.netstat_path:
        pytest.skip('netstat binary not found')

    # Expected output
    expected_output = True

    # Mock the methods of the LinuxNetwork() class

# Generated at 2022-06-20 18:29:31.475639
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec=dict())
    ln = LinuxNetwork(module)
    data, ips = ln.populate()
    assert 'all_ipv4_addresses' in ips
    assert isinstance(ips['all_ipv4_addresses'], list)
    assert 'all_ipv6_addresses' in ips
    assert isinstance(ips['all_ipv6_addresses'], list)
    assert 'default_ipv4' in data
    assert isinstance(data['default_ipv4'], dict)
    assert 'default_ipv6' in data
    assert isinstance(data['default_ipv6'], dict)
    assert 'interfaces' in data
    assert isinstance(data['interfaces'], dict)

# Generated at 2022-06-20 18:29:41.531070
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)

    class MockPopen:

        def __init__(self, cmd):
            self.cmd = cmd