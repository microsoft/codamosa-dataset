

# Generated at 2022-06-20 18:20:37.831377
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    check = LinuxNetwork({})
    check.module = DummyAnsibleModule()
    device = 'e1000e'
    result = check.get_ethtool_data(device)
    assert result['features']['generic_receive_offload'] == 'on'
    assert result['features']['large_receive_offload'] == 'on'
    assert result['phc_index'] == 4
    assert 'rx_all' in result['timestamping']
    assert 'tx_sync' in result['timestamping']
    assert 'tx_hw' in result['hw_timestamp_filters']
    assert 'none' in result['hw_timestamp_filters']
    assert 'all' in result['hw_timestamp_filters']



# Generated at 2022-06-20 18:20:43.987883
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule({})
    ln = LinuxNetwork(module)
    default_ipv4 = {}
    default_ipv6 = {}
    interfaces, ips = ln.get_interfaces_info('/sbin/ip', default_ipv4, default_ipv6)
    # Check whether the results look reasonable
    assert 'lo' in interfaces
    assert 'eth0' in interfaces



# Generated at 2022-06-20 18:20:48.659723
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """Test constructor of LinuxNetworkCollector"""
    module = AnsibleModule(argument_spec={})
    collector = LinuxNetworkCollector(module)
    assert isinstance(collector, LinuxNetworkCollector)


# Generated at 2022-06-20 18:21:01.493121
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from copy import deepcopy
    from ansible_collections.ansible.netcommon.plugins.module_utils.network.common.ip import to_list, to_netmask
    from ansible.module_utils.six import PY3, b, string_types, text_type, iteritems


# Generated at 2022-06-20 18:21:11.643900
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    """
    tests at least some of the LinuxNetwork class
    """
    # This is a really really really really bad idea.
    # Should only be used to test the class, which is done in this case
    # If a use-case for this method is introduced, the test should be moved
    # to test_linux.py
    module = AnsibleModule(argument_spec={})

    module.exit_json = exit_json
    module.fail_json = fail_json

    linux_network = LinuxNetwork(module)

    # test get_default_route
    # TODO get_default_route test
    # result = linux_network.get_default_route()

    # test get_interfaces_info
    result = linux_network.get_interfaces_info(None, None, None)
    # TODO: get_interfaces_info

# Generated at 2022-06-20 18:21:15.369364
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    result = ln.populate()
    assert result is None, result


if __name__ == '__main__':
    # Unit test suite for method populate
    test_LinuxNetwork_populate()

# Generated at 2022-06-20 18:21:23.681644
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    #
    # Unit test for method get_default_interfaces of class LinuxNetwork
    #
    class Module(object):
        def __init__(self):
            self.params = {}
            self.check_mode = False

        def get_bin_path(self, to_check='', required=False, opt_dirs=[]):
            return "/usr/bin/ip"

        def run_command(self, command, check_rc=True):
            #
            # Unit test for method run_command of class LinuxNetwork
            #
            class Root(object):
                def __init__(self):
                    self.path = "/tmp/test_LinuxNetwork_get_default_interfaces"

                def exists(self):
                    return True

            class File(object):
                def __init__(self, path):
                    self.path

# Generated at 2022-06-20 18:21:32.457171
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # NOTE: `module_mock` is not an AnsibleModule, it's a MagicMock
    module_mock = MagicMock(name='ansible.module_utils.basic.AnsibleModule')
    linux_network_under_test = LinuxNetwork(module_mock)

    def get_file_content_mock(path, default=None):
        if 'mtu' in path:
            return '1500'
        if 'driver' in path:
            return 'e1000e'
        return ''

    # monkey patch the get_file_content method from the host utilities
    linux_network_under_test.get_file_content = get_file_content_mock

    # NOTE: `target_mock` is not a dict, it's a MagicMock

# Generated at 2022-06-20 18:21:42.924686
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    network = LinuxNetwork()

    network.default_ipv4 = dict()
    network.default_ipv6 = dict()

    module_mock = Mock()
    module_mock.run_command.return_value = (0, '', '')
    module_mock.get_bin_path.return_value = True
    module_mock.get_cmd_dir.return_value = True
    network.module = module_mock

    with patch('socket.inet_aton') as inet_aton_mock:
        inet_aton_mock.return_value = b'some_ip'
        with patch('socket.inet_ntoa') as inet_ntoa_mock:
            inet_ntoa_mock.return_value = 'some_ip'

# Generated at 2022-06-20 18:21:50.933897
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # Test with a module argument that doesn't contain required facts.
    # This should raise an exception.
    try:
        LinuxNetworkCollector({})
    except Exception as e:
        assert str(e) == "Insufficient module arguments for 'Linux' platform."
    # Test with a module argument that contains a required fact.
    # This should not raise an exception.
    try:
        LinuxNetworkCollector({'platform': 'Linux'})
    except Exception as e:
        assert str(e) != "Insufficient module arguments for 'Linux' platform."
    # Test with a module argument that contains a required fact.
    # This should not raise an exception.
    try:
        LinuxNetworkCollector({'distribution': 'Ubuntu'})
    except Exception as e:
        assert str(e) != "Insufficient module arguments for 'Linux' platform."

# Generated at 2022-06-20 18:22:26.014645
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    c = LinuxNetwork(module)
    ip_path = c.module.get_bin_path("ip")

    def get_default_interface_test(expected):
        return lambda: assertDictEqual(expected, c.get_default_interface(ip_path))

    # This test is needed only for CI to pass on CentOS 8 because the test
    # environment does not have an interface with IP address configured.
    # CentOS 8 uses the nftables framework instead of the iptables.
    # The default chain policy for INPUT in nftables is DROP.
    # ip addr add fails with this error:
    #   RTNETLINK answers: Operation not permitted
    # The test environment is not suitable for running this test if
    # the firewall is enabled.

# Generated at 2022-06-20 18:22:32.247616
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = MockModule()
    # NOTE: if this is docker, the interface name is different
    module.run_command.return_value = (0, '', '')
    network = LinuxNetwork(module, 'lo')
    ethtool_data = network.get_ethtool_data('lo')
    assert ethtool_data == {}



# Generated at 2022-06-20 18:22:43.012471
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # if we're on an unsupported version of linux, then we cannot run this test
    if not platform.linux_distribution()[0].lower() in ['centos', 'debian', 'ubuntu']:
        pytest.skip("Skipping test for unsupported distro {}".format(platform.linux_distribution()))
    # construct a mock module and provide module.run_command() as a side_effect
    # we need module.run_command() to use a real instance since we rely on subprocess.Popen()
    # and we can't mock subprocess.Popen()
    module = Mock(run_command=MagicMock(return_value=(0, '', '')))
    # provide a mocked get_bin_path
    module.get_bin_path.side_effect = lambda i: i
    # if we're on an unsupported version of linux,

# Generated at 2022-06-20 18:22:52.765671
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    # Unit test get_interfaces_info of class LinuxNetwork
    # is_module -> module
    mock_module = MockModule(params={'ip_path': '/sbin/ip', 'run': 'run'})

    # mock ip output

# Generated at 2022-06-20 18:23:04.282290
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModuleMock(
        dict(
            ansible_distribution='test_distribution',
            ansible_distribution_version='test_distribution_version',
            ansible_kernel='test_kernel',
            ansible_machine='test_machine',
            ansible_os_family='test_os_family',
        )
    )
    facts = AnsibleFactsCollector.create_instance(module)
    assert facts is not None
    assert LinuxNetworkCollector.platform == 'Linux'
    assert LinuxNetworkCollector.fact_class == LinuxNetwork



# Generated at 2022-06-20 18:23:15.018513
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    import mock

    module = mock.MagicMock()
    module.params = {'config': 'ignored'}
    module.run_command.return_value = 0, 'command output', ''

    ln = LinuxNetwork(module)
    ln.get_interfaces_info = mock.Mock()
    ln.get_interfaces_info.return_value = ({}, {})
    ln.get_networks_data = mock.Mock()
    ln.get_networks_data.return_value = ({},) * 5
    ln.get_routes_data = mock.Mock()
    ln.get_routes_data.return_value = ({}, {})
    ln.get_default_interfaces = mock.Mock()
    ln.get_default_interfaces

# Generated at 2022-06-20 18:23:25.697246
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():

    class MockModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            raise Exception("fail_json")

# Generated at 2022-06-20 18:23:38.604683
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """
    Method get_interfaces_info of LinuxNetwork class
    """
    linux_net = LinuxNetwork()
    for p in ['/sys/class/net/tap0', '/sys/class/net/veth0', '/sys/class/net/bond0']:
        if os.path.isdir(p):
            shutil.rmtree(p)
            shutil.rmtree(p.replace('net', 'devices'))

    os.mkdir('/sys/class/net/tap0')
    os.mkdir('/sys/class/net/tap0/bridge')
    os.mkdir('/sys/class/net/tap0/bonding')
    os.mkdir('/sys/class/net/veth0')

# Generated at 2022-06-20 18:23:48.663915
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    class FakeModule:
        def get_bin_path(self, s):
            return "/usr/bin/" + s
        def run_command(self, arg, **kwargs):
            return 0, "", ""

    class FakeResult:
        pass

    res = FakeResult()
    res.changed = False
    res.failed = False

    # Test case with module.get_bin_path("ip") -> "/usr/bin/ip"

# Generated at 2022-06-20 18:23:58.873615
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    network = LinuxNetwork()

    rc = 0

# Generated at 2022-06-20 18:24:38.129574
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    facts = {
        'distribution': 'Debian',
        'platform': 'Linux'
    }
    instance = LinuxNetworkCollector(facts, {}, False)
    assert isinstance(instance, NetworkCollector)
    assert instance.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-20 18:24:47.440599
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """Unit test for method get_interfaces_info of class LinuxNetwork"""
    test_module = NetworkModule(argument_spec={})
    test_interface_data = {'test1': {'type': 'test_type',
                                     'macaddress': 'test_macaddress',
                                     'mtu': 'test_mtu',
                                     },
                           'test2': {'type': 'test_type2',
                                     'macaddress': 'test_macaddress2',
                                     'mtu': 'test_mtu2',
                                     },
                           }
    test_network_obj = LinuxNetwork(test_module)
    test_default_ipv4 = dict()
    test_default_ipv6 = dict()

# Generated at 2022-06-20 18:24:56.575372
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={})

    class MockFileHandle():
        file_name = "tests/unit/modules/network/fixtures/default_interfaces"

        def __init__(self, file_name):
            self.contents = open(file_name).read()

        def readlines(self):
            return self.contents.splitlines()

    module.open_file = Mock(return_value=MockFileHandle("tests/unit/modules/network/fixtures/default_interfaces"))

    ln = LinuxNetwork(module)
    v4, v6 = ln.get_default_interfaces()
    assert v4['interface'] == "eth1"
    assert v6['interface'] == "eth0"

# Generated at 2022-06-20 18:25:03.779459
# Unit test for constructor of class LinuxNetwork

# Generated at 2022-06-20 18:25:14.692626
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # TODO: Maybe create a dummy get_bin_path method?
    ln = LinuxNetwork()
    ln.module = FakeAnsibleModule()
    # "ethtool -k" on a CentOS 8.2 box

# Generated at 2022-06-20 18:25:22.173338
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    return_value = []

    # FIXME: test run_command
    def run_command_mock(command, errors):
        return_value.append(command)
        return return_value

    ln = LinuxNetwork()
    ln.run_command = run_command_mock
    ln.get_ethtool_data('eth0')
    assert return_value[0] == ['/sbin/ethtool', '-k', 'eth0']
    assert return_value[1] == ['/sbin/ethtool', '-T', 'eth0']


# Generated at 2022-06-20 18:25:34.427888
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = mock.Mock(spec=AnsibleModule)
    module.run_command.return_value = (0, "eth0: flags=4163<UP,BROADCAST,RUNNING,MULTICAST>  mtu 1500 \
        inet 10.0.0.1  netmask 255.255.255.0  broadcast 10.0.0.255\
        inet6 fe80::a00:27ff:fe40:f02c  prefixlen 64  scopeid 0x20<link>\
        ether 08:00:27:40:f0:2c  txqueuelen 1000  (Ethernet)", "")
    linux_network = LinuxNetwork(module)
    linux_network.get_default_interface()
    assert linux_network.default_interface["interface"] == "eth0"
    assert linux

# Generated at 2022-06-20 18:25:37.800383
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec=dict())
    obj = LinuxNetwork()
    obj.module = module
    interfaces = LinuxNetwork.populate(obj)
    assert interfaces['lo']
    assert interfaces['lo']['type'] == 'loopback'


# Generated at 2022-06-20 18:25:47.865852
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    import json
    import os
    import tempfile
    module_name = 'ansible.module_utils.basic.AnsibleModule'

# Generated at 2022-06-20 18:25:57.610052
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda: None

    linux_network = LinuxNetwork(module=module)

    def get_bin_path(binary):
        return binary

    # FIXME: is this a method of module or module?
    module.get_bin_path = get_bin_path

    def run_command(command, errors):
        return 0, '', ''

    # FIXME: is this a method of module or module?
    module.run_command = run_command

    data = linux_network.get_ethtool_data('dummy')

    assert data == {'features': {}, 'timestamping': [], 'hw_timestamp_filters': []}

# Generated at 2022-06-20 18:26:35.948436
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # create an instance of the LinuxNetworkCollector class
    argv = ["ansible", "-m", "linux_network"]
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
        mutually_exclusive=[],
    )
    collector = LinuxNetworkCollector(module)
    assert isinstance(collector, LinuxNetworkCollector)

# Generated at 2022-06-20 18:26:41.008952
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module_args = dict(
        config_file=dict(type='str', default='/etc/ansible/facts.d/network.fact'),
    )
    module = AnsibleModule(argument_spec=module_args)
    ln = LinuxNetwork(module)
    default_ipv4 = {}
    default_ipv6 = {}
    ln.get_interfaces_info("/bin/ip", default_ipv4, default_ipv6)



# Generated at 2022-06-20 18:26:50.304260
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    ''' Unit test for LinuxNetwork() '''
    module = MockModule()
    linux_network = LinuxNetwork(module)
    # Both ipv4 and ipv6 interfaces are present.
    assert len(linux_network.interfaces) > 1
    # There're multiple interfaces in the interfaces list.
    assert len(linux_network.interfaces) > 1
    # By default, the first interface is the default ipv4 interface.
    assert len(linux_network.default_interface['ipv4']) > 0
    # By default, the first interface is the default ipv6 interface.
    assert len(linux_network.default_interface['ipv6']) > 0
    # All ipv4 and ipv6 interfaces are present.
    assert len(linux_network.ips['all_ipv4_addresses']) > 0

# Generated at 2022-06-20 18:26:59.938743
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    """
    Unit test for constructor of class LinuxNetwork.
    """
    network = LinuxNetwork()
    interface = network.get_interface('eth0')
    assert 'interface' in interface
    assert 'v4' in interface
    assert 'v6' in interface
    assert 'all_ipv4_addresses' in interface
    assert 'all_ipv6_addresses' in interface
    assert 'default_ipv4' in interface
    assert 'default_ipv6' in interface
    assert 'interfaces' in interface

# pylint: disable=expression-not-assigned
test_LinuxNetwork()

# Generated at 2022-06-20 18:27:04.516730
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    module.exit_json = Mock(return_value=True)
    module.run_command = Mock(return_value=(0, "", ""))
    module.get_bin_path = Mock(return_value="/bin/ip")
    module.params = {}
    # Instantiate a LinuxNetwrokCollector object
    network_collector = LinuxNetworkCollector(module)
    # check if the object is a NetworkCollector
    assert isinstance(network_collector, NetworkCollector)
    # check if the object is a LinuxNetworkCollector
    assert isinstance(network_collector, LinuxNetworkCollector)
    # check if the required_facts are set properly
    assert network_collector.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-20 18:27:05.591010
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    c = LinuxNetworkCollector()
    assert c.platform == 'Linux'
    assert c.fact_class == LinuxNetwork



# Generated at 2022-06-20 18:27:12.267144
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec=dict())
    ln = LinuxNetwork(module)
    assert ln.get_interface() == ('eth0', 'eth0')
    assert len(ln.get_interfaces_info()[0]) > 1
    # TODO: find a way to test get_route_onlink()
    # TODO: find a way to test get_ip_address()

# ===========================================
# Main
# ===========================================


# Generated at 2022-06-20 18:27:18.200244
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    ln = LinuxNetwork(module)
    # invoke method get_default_interfaces with no parameters.
    assert ln.get_default_interfaces() == ({"address":"172.30.28.10","broadcast":"","netmask":"255.255.240.0","network":"172.30.16.0",},)


# Generated at 2022-06-20 18:27:25.921917
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    # Test create with args
    module = AnsibleModule(
        argument_spec = dict(
            state      = dict(default='present', choices=['present','absent']),
        ),
    )
    result = dict(
        changed = False,
        original_message = '',
        message = '',
        ansible_facts = dict(
            interfaces = {},
        )
    )
    mock_module = MagicMock(return_value=result)
    mock_run_command = MagicMock(return_value=(0, "", ""))
    mock_get_bin_path = MagicMock(return_value='/bin/ip')

# Generated at 2022-06-20 18:27:28.238507
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec=dict())
    nm = LinuxNetworkCollector(module)
    assert nm is not None

# Generated at 2022-06-20 18:28:15.531706
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_network_resources=dict(type='bool'),
        ),
        supports_check_mode=True,
    )
    network = LinuxNetwork(module)
    network.get_routes()
    # TODO: expand


# Generated at 2022-06-20 18:28:20.314980
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = type('DummyModule', (object,), {})()
    module.get_bin_path = lambda x: '/bin/ip'
    module.run_command = lambda x, **kwargs: (0, "", "")
    obj = LinuxNetwork(module)
    assert obj.ip_path == '/bin/ip'



# Generated at 2022-06-20 18:28:30.812689
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-20 18:28:44.178331
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    '''
    Unit test for method get_interfaces_info of class LinuxNetwork
    '''
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import basic
    module, args, facts = basic.AnsibleModule(), dict(), dict()
    setattr(module, 'run_command', lambda *_, **__: (0, u'', u''))
    n = LinuxNetwork(module, args, facts)
    # os.readlink is mocking readlink, so returns the same thing it was given
    # os.path.realpath is mocking realpath, so returns the same thing it is given
    # os.path.exists is mocking exists, so returns True always
    # os.path.isdir is mocking isdir, so returns True always

# Generated at 2022-06-20 18:28:54.711703
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec=dict(
            use_iproute2=dict(required=False, type='bool', default=False),
        ),
        supports_check_mode=True,
    )

    # Add a stub for get_bin_path method
    setattr(module, 'get_bin_path', lambda x, opt_flags=None: None)

    # Add a stub for get_file_content method

# Generated at 2022-06-20 18:29:03.676551
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    net = LinuxNetwork()
    net.module = MagicMock()
    net.module.run_command = MagicMock()
    net.module.run_command.return_value = 0, _EXAMPLE_OUTPUT_LS_LINK, ''
    net.module.get_bin_path = MagicMock(return_value='/sbin/ip')

    default_ipv4 = {'address': '192.168.100.100', 'broadcast': '192.168.100.255',
                    'netmask': '255.255.255.0', 'network': '192.168.100.0'}

# Generated at 2022-06-20 18:29:11.397312
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    fixture_file = open("unit/modules/network/linux/fixtures/fixture_get_interfaces_info", "rb")
    fixture_data = fixture_file.read()
    fixture_file.close()

    # TODO: figure out a way to avoid parsing a string to a dict using literal_eval
    # Also:
    # - make this a fixture?
    # - add more sample output?
    # - add more unit tests? (not using default_ipv4, default_ipv6)

# Generated at 2022-06-20 18:29:14.818779
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule({})
    assert LinuxNetwork(module).ip_path == '/sbin/ip'


# Generated at 2022-06-20 18:29:22.560501
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule({})
    os_name = 'Linux'
    os_version = '3.10.0-957.12.2.el7.x86_64'
    distro_name = 'CentOS Linux'
    distro_version = '7.6.1810'
    distro_id = 'Core'
    ifaces = ['eth0', 'eth1', 'eth2']
    ip_path = '/sbin/ip'
    with open(os.path.join(os.path.dirname(__file__), 'fixtures', 'ip-addr-show-output.txt')) as f:
        ip_addr_show_output = f.read()

# Generated at 2022-06-20 18:29:26.403109
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = LinuxNetworkCollector(module=module)
    assert collector._platform == 'Linux'
    assert collector._fact_class == LinuxNetwork