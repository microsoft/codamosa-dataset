

# Generated at 2022-06-20 18:20:27.822151
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    result = LinuxNetworkCollector(module).collect()
    assert isinstance(result, dict)

# Generated at 2022-06-20 18:20:37.619014
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(
        argument_spec=dict(),
    )

    #
    # Test cases
    #
    # 1. __init__: AnsibleModule
    # 2. collect: distribution, platform
    # 3. collect: fact_module
    # 4. collect: fact_module.distribution
    # 5. collect: fact_module.platform
    #
    # NOTE: 1.__init__: AnsibleModule is implicitly tested by the import.
    #

    # 2. collect: distribution, platform
    with pytest.raises(AssertionError):
        LinuxNetworkCollector(module=module)

    # 3. collect: fact_module
    module.params.update(dict(fact_module=None))
    with pytest.raises(AssertionError):
        LinuxNetworkCollector(module=module)

# Generated at 2022-06-20 18:20:43.705421
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = Mock()
    module.params = {'gather_subset': '!all,!min', 'gather_network_resources': 'yes'}
    module.get_bin_path.return_value = True
    net = LinuxNetwork(module)

    assert net.module == module

    # FIXME: assert other attrs initialized by `.__init__`

# Generated at 2022-06-20 18:20:55.972451
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = MagicMock()
    # must be true in order for the class to get instantiated
    module.params['gather_subset'] = ['network']
    # must be false in order for the class to get instantiated
    module.params['gather_network_resources'] = ['all']
    # requirements for constructor of NetworkCollector
    module.params['gather_timeout'] = 10
    module.run_command.return_value = (0, '', '')
    module.get_bin_path.return_value = '/usr/bin/ip'
    module.get_option.return_value = dict()
    # requirements for constructor of LinuxNetworkCollector
    setattr(module, 'facts', dict(distribution='RedHat', platform='Linux'))
    # requirements for constructor of LinuxNetwork
    # NOTE: This cannot be mocked

# Generated at 2022-06-20 18:21:08.445378
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)

    # test IPv4 address
    interface_ipv4 = {
        'interface': 'eth0',
        'address': '10.0.0.1',
        'gateway': '10.0.0.254'
    }
    assert network.get_ipv4_interface('10.0.0.1') == interface_ipv4
    interface_ipv4['interface'] = 'eth1'
    interface_ipv4['gateway'] = '10.0.0.2'
    assert network.get_ipv4_interface('10.0.0.2') == interface_ipv4



# Generated at 2022-06-20 18:21:11.202171
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: write unit tests for method get_interfaces_info of class LinuxNetwork
    pass


# Generated at 2022-06-20 18:21:18.006095
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    specs = dict(
        module=dict(),
        ip_path='/sbin/ip',
        default_ipv4=dict(),
        default_ipv6=dict(),
    )
    l = LinuxNetwork(specs)
    rc, out, err = l.module.run_command('/sbin/ip route show')
    if not out:
        return dict()

    # IPv4
    words = out.splitlines()[0].split()
    if words[0] != 'default':
        return dict()
    default_ipv4 = {
        'gateway': words[2],
    }
    v4_interface_name = words[4]
    iface = {
        v4_interface_name: dict(
            interface=v4_interface_name,
        ),
    }
    rc,

# Generated at 2022-06-20 18:21:28.214091
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-20 18:21:37.449805
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    ln = LinuxDistribution()
    ln.include_sources = False

    ln.get_interface_properties()
    assert ln.ip_path == '/sbin/ip'

    ln.get_default_gateway() == {'ipv4': {'interface': None,
                                          'address': '172.19.0.1',
                                          'gateway': None},
                                 'ipv6': {'interface': None,
                                          'address': 'fe80::42:acff:fe13:1',
                                          'gateway': None}}

    interfaces = ln.get_interfaces_info(ln.ip_path, ln.default_ipv4, ln.default_ipv6)

# Generated at 2022-06-20 18:21:51.667910
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-20 18:22:25.529033
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY2

    module = AnsibleModule(argument_spec=dict(), supports_check_mode=True)

    # A couple of test cases are PY2 only, so bail out now if we're on PY3
    if not PY2:
        module.exit_json(changed=False, msg="Test skipped on this platform (Python 3)")

    linux = LinuxNetwork(module)


# Generated at 2022-06-20 18:22:39.479871
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    """
    get_default_interfaces function
    """
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    ln = LinuxNetwork(module=module)
    default_ipv4, default_ipv6 = ln.get_default_interfaces()

# Generated at 2022-06-20 18:22:41.228307
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    n = LinuxNetwork()
    assert n.ip_path == '/sbin/ip'


# Generated at 2022-06-20 18:22:45.935853
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModuleMock()
    lnc = LinuxNetworkCollector(module)
    assert isinstance(lnc._fact_class, LinuxNetwork)

# Unit tests for get_default_interfaces() function

# Generated at 2022-06-20 18:22:51.665024
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    klass = NetworkCollector(module=module)
    assert klass.required_facts == LinuxNetworkCollector.required_facts
    assert klass.fact_class == LinuxNetwork
    assert klass.platform == LinuxNetworkCollector._platform

# Generated at 2022-06-20 18:23:06.506324
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    ln = LinuxNetwork()
    ln.module.run_command = MagicMock(return_value=(0, '', ''))
    ln.get_interface_type = MagicMock(return_value='Ethernet')
    ln.get_interfaces_info = MagicMock(return_value=(dict(), dict()))

    all_ipv4_addresses = MagicMock()
    all_ipv6_addresses = MagicMock()

# Generated at 2022-06-20 18:23:15.870453
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Arrange
    devices = [
        'lo',
        'eth0',
        'eth1',
        'eth2',
        'eth3',
        'bond0',
        'bond1',
        'br0',
        'br1',
        'vnet0',
        'vnet1',
        'usb0',
        'usb1',
        'usb2',
        'vlan0',
        'vlan1',
        'ppp0',
        'tun0',
        'tun1',
        'gre0',
        'gre1',
        'ipsec0',
        'ipsec1',
        'gre',
        'vxlan0',
    ]
    module = FakeModule()

# Generated at 2022-06-20 18:23:26.317189
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    nm = LinuxNetwork(module)
    assert nm.ip_path == '/sbin/ip'
    assert nm.module == module

# ===========================================
# Linux Network Platform Specific Unit Tests
# ===========================================
# Unit tests for get_interfaces_info() method of class LinuxNetwork

# Generated at 2022-06-20 18:23:39.062481
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModuleMock()
    m = LinuxNetworkMock()

# Generated at 2022-06-20 18:23:49.084746
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """ Test LinuxNetwork.get_ethtool_data method with mocked output """
    import mock

    module = mock.MagicMock(name='module')
    linux_network = LinuxNetwork(module)

    # data from ethtool -k eth0
    # FIXME: should be a single string

# Generated at 2022-06-20 18:24:40.965345
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """LinuxNetworkCollector: check constructor of class LinuxNetworkCollector"""
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import Mock
    assert LinuxNetworkCollector is not None

    # create mocks
    module = Mock()
    module.params = {"gather_subset": None, "gather_timeout": 10}
    module.command = lambda x: (0, '', '')
    module.run_command = lambda x, **y: (0, '', '')
    module.get_bin_path = lambda x, **y: x

    # run test
    fact_collector = LinuxNetworkCollector(module)
    # assert fact_collector

# Generated at 2022-06-20 18:24:51.716756
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    if isinstance(netifaces, Mock):
        return

    # Setup
    module = AnsibleModule(argument_spec=dict())
    net = LinuxNetwork(module)

    # Run function
    with patch('os.path.exists') as mock_path, \
            patch('os.listdir') as mock_listdir, \
            patch.object(net, "get_default_interface") as mock_get_default_interface, \
            patch.object(net, "get_interface_mac") as mock_get_interface_mac, \
            patch.object(net, "get_route_interface") as mock_get_route_interface, \
            patch.multiple(net, get_file_content=DEFAULT, run_command=DEFAULT):
        # Test
        mock_path.side_effect = lambda p: os.path

# Generated at 2022-06-20 18:24:59.902434
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule({})
    if platform.system() == 'Linux':
        network = LinuxNetwork(module)
        interfaces, ips = network.get_interfaces_info('ip',
                                                      {'address': '127.0.0.1'},
                                                      {'address': '::1'})
        # TODO: more tests
        assert interfaces and ips
    else:
        raise Exception("This platform is not Linux")



# Generated at 2022-06-20 18:25:09.609685
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={'primary': dict(required=False, type='bool', default=True)})
    ln = LinuxNetwork(module)
    module.exit_json(changed=False,
                     default_ipv4=ln.default_ipv4,
                     default_ipv6=ln.default_ipv6,
                     interfaces=ln.interfaces,
                     ips=ln.ips)



# Generated at 2022-06-20 18:25:22.456869
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-20 18:25:34.292644
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    class FakeModule(object):
        def __init__(self):
            self.run_command = lambda x: (0, '', '')
            self.get_bin_path = lambda x: x

    module = FakeModule()
    api = basic.AnsibleModule(argument_spec={})
    net = LinuxNetwork(module, "")
    interfaces, ips = net.get_interfaces_info('', {}, {})
    assert isinstance(interfaces, dict)
    assert isinstance(ips, dict)
    assert 'all_ipv4_addresses' in ips
    assert 'all_ipv6_addresses' in ips



# Generated at 2022-06-20 18:25:43.086490
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    collector = LinuxNetworkCollector({})
    assert collector.required_facts == set(['distribution', 'platform'])

    # Check that empty dict has no changes
    # check that collector.update_host_info(host_info, facts={}) is a noop
    collector.update_host_info({}, {})
    assert not collector.host_info
    host_info = {'ansible_facts': {'distribution': 'debian', 'platform': 'linux'}}
    collector.update_host_info(host_info, {})
    assert 'ipv4' in collector.host_info['ansible_all_ipv4_addresses']
    assert 'ansible_all_ipv4_addresses' in collector.host_info
    assert 'ansible_all_ipv6_addresses' in collector.host_info

# Generated at 2022-06-20 18:25:56.121070
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = None
    ln = LinuxNetwork(module)
    rc = 0

# Generated at 2022-06-20 18:26:05.492079
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    a = LinuxNetwork()
    a.module.get_bin_path = lambda x:"/tmp/"
    a.module.run_command = lambda cmd, err: (0, '', '')
    result = a.get_ethtool_data("")
    assert not result

    a.module.run_command = lambda cmd, err: (0, 'Offload parameters for em1:\nFeatures for em1:\nrx-checksumming: on\ntx-checksumming: on\ntcp-segmentation-offload: on\ntcp-sack: on\ntcp-fack: on\ntx-nocache-copy: off\ntcp-timestamps: on\ntcp-window-scaling: on', '')
    result = a.get_ethtool_data("")

# Generated at 2022-06-20 18:26:14.084471
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    interfaces, ips = ln.get_interfaces_info(None, None, None)

    assert len(interfaces) > 0
    assert len(interfaces) == len(ips['all_ipv4_addresses']) + len(ips['all_ipv6_addresses'])
    for device, attrs in interfaces.items():
        assert isinstance(attrs, dict)
        assert device in attrs['device']


# Generated at 2022-06-20 18:27:01.573428
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    ''' Unit test for class LinuxNetwork
    '''
    # NOTE: AnsibleModule is really a subclass of AnsibleModule
    module = AnsibleModule(argument_spec={})
    current_facts = LinuxNetwork(module)
    interfaces, ips = current_facts.get_interfaces_info('/sbin/ip', {}, {})
    assert len(interfaces.keys()) > 0
    default_ipv4, default_ipv6 = current_facts.get_default_interfaces()
    assert len(default_ipv4.keys()) > 0
    assert len(default_ipv6.keys()) > 0

# Unit test the function get_interface_mac

# Generated at 2022-06-20 18:27:07.529369
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(supports_check_mode=True)
    collector = LinuxNetworkCollector(module)
    assert collector.version == '1.0'
    assert collector.platform == 'Linux'
    assert collector.required_facts == {'distribution', 'platform'}
    assert collector._fact_class().module == module



# Generated at 2022-06-20 18:27:15.786092
# Unit test for method get_ethtool_data of class LinuxNetwork

# Generated at 2022-06-20 18:27:26.898803
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.network.common.utils import dict_merge

    module = Mock(return_value=None)
    m = LinuxNetwork(module)
    # our test variables
    d4_ipv4 = {'address': '192.168.122.1', 'prefix': '24', 'broadcast': '0.0.0.0', 'netmask': '255.255.255.0', 'network': '192.168.122.0', 'macaddress': '52:54:00:41:57:a6', 'module': 'virtio_net', 'mtu': 1500, 'type': 'ether'}

# Generated at 2022-06-20 18:27:35.005658
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['all'], type='list'),
            gather_network_resources=dict(default=[], type='list'),
        ),
        supports_check_mode=True,
    )

    # Create instance of LinuxNetwork
    ln = LinuxNetwork(module)
    # Invoke the populate method
    ln.populate()
    # Invoke the get_interfaces_info method
    ln.get_interfaces_info()

if __name__ == '__main__':
    test_LinuxNetwork_populate()

# Generated at 2022-06-20 18:27:47.554997
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    # establish our basic network facts
    linux_network = LinuxNetwork(module)
    ansible_facts = linux_network.populate()

    # skip all the stuff below if we are in check mode
    if module.check_mode:
        module.exit_json(ansible_facts=ansible_facts)

    # assert some things about the gathered facts
    assert 'ansible_net_gather_subset' in ansible_facts
    assert 'default_gateway_interface' in ansible_facts
    assert 'default_ipv4' in ansible_facts
    assert 'default_ipv6' in ansible_

# Generated at 2022-06-20 18:27:53.095005
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    import doctest
    m = LinuxNetwork
    dt = doctest.DocTestSuite(m)
    runner = unittest.TextTestRunner(verbosity=3)
    runner.run(dt)



# Generated at 2022-06-20 18:27:59.652726
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(
        argument_spec={
            'use_ipv6': dict(type='bool', required=False),
        }
    )
    network = LinuxNetwork()
    if network.module.get_bin_path('ip'):
        default_v4, default_v6 = network.get_default_interfaces(module.params.get('use_ipv6'))
    else:
        default_v4, default_v6 = network.get_default_interfaces_route(module.params.get('use_ipv6'))

    assert isinstance(default_v4, dict) or default_v4 is None
    assert isinstance(default_v6, dict) or default_v6 is None



# Generated at 2022-06-20 18:28:12.851662
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})

    ln = LinuxNetwork(module)

# Generated at 2022-06-20 18:28:24.972287
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    with open('/proc/net/dev', 'r') as f:
        data = f.readlines()
    inet = LinuxNetwork()
    interfaces = inet.get_interfaces()
    assert len(interfaces) > 0
    # Choose an arbitrary interface to check
    interface = 'lo'
    if interface not in interfaces:
        raise Exception("Interface '%s' not found in %s" % (interface, interfaces))
    # make sure we have at least 1 address
    addresses = inet.get_interfaces_addresses(interface)
    all_ipv4_addresses = inet.get_interfaces_addresses('all', 'IPv4')
    assert len(addresses) > 0
    # choose an arbitrary address to check
    address = addresses[0]['address']

# Generated at 2022-06-20 18:29:03.052311
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    linux_network = LinuxNetwork()

    # On Linux, each device is an interface
    devices = glob.glob('/sys/class/net/*')
    assert len(devices) == len(linux_network.interfaces.keys())

    # Each interface has the name as key
    for device in devices:
        if os.path.isdir(device):
            assert device.replace('/sys/class/net/', '') in linux_network.interfaces.keys()


# Generated at 2022-06-20 18:29:05.747525
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    i = LinuxNetwork(None)
    i.populate()
    assert(isinstance(i.interfaces, dict))

# Generated at 2022-06-20 18:29:09.286083
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # This was just a test for linting, calling populate will just get the same info
    linux_network = LinuxNetwork()
    linux_network.populate()

# Generated at 2022-06-20 18:29:12.547367
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    result = LinuxNetworkCollector()
    assert(result.platform == "Linux")


# Generated at 2022-06-20 18:29:21.852437
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    import mock


# Generated at 2022-06-20 18:29:32.178506
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    test_module = AnsibleModule(argument_spec=dict(
        gather_subset=dict(type='list'),
        gather_network_resources=dict(type='list'),
    ))

    test_obj = LinuxNetwork(test_module)
    test_obj.populate(["all"])

    assert isinstance(test_obj.default_ipv4, dict)
    assert isinstance(test_obj.default_ipv6, dict)
    assert isinstance(test_obj.interfaces, dict)
    assert isinstance(test_obj.ipv4, dict)
    assert isinstance(test_obj.ipv6, dict)
    assert isinstance(test_obj.routes, dict)
    assert isinstance(test_obj.ipv4_addresses, dict)

# Generated at 2022-06-20 18:29:38.452301
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    fake_module = FakeAnsibleModule()
    linux_network = LinuxNetwork(fake_module)

# Generated at 2022-06-20 18:29:50.077199
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    """
    Unit test for method LinuxNetwork.get_default_interfaces.
    """
    # initialize helper object
    helper = LinuxNetwork(test_module)

    # initialize test data
    # NOTE: Implement more test data as needed.
    #
    # test_data[id]
    #   id: string
    #   stdout[return_code]
    #       return_code: int
    #       stdout: string
    test_data = dict()

    test_data['A'] = dict()

# Generated at 2022-06-20 18:29:59.476541
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Verify all the keys are present in the output
    # and contain the right type of value

    # (Type) -> (method, [args])
    types = {
        str: ('run_command', (['/bin/ip', '-o', 'link', 'show'],)),
        dict: ('get_default_interfaces', ()),
        list: ('get_interfaces_info', (None, None, None)),
    }
    for key, (method, args) in types.items():
        ins = LinuxNetwork()
        result = getattr(ins, method)(*args)
        assert isinstance(result, key), '{} is of type {} instead of {}'.format(result, type(result), key)
