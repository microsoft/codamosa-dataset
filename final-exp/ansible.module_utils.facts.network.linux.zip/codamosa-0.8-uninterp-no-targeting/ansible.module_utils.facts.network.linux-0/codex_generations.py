

# Generated at 2022-06-20 18:20:32.273058
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    test_module = AnsibleModule(argument_spec={})
    # initializing the network object
    network_object = LinuxNetwork(test_module)
    default_ipv4, default_ipv6 = network_object.get_default_interfaces()
    assert isinstance(default_ipv4, dict)
    assert isinstance(default_ipv6, dict)
    assert 'default_ipv4' in default_ipv4
    assert 'default_ipv6' in default_ipv6



# Generated at 2022-06-20 18:20:40.594583
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    m = LinuxNetwork()
    m.populate('/sbin/ip')

    # m.interfaces is a dict with keys of interface name
    # m.interface is a dict with the defailted interface info
    #
    # print('m.interfaces:', m.interfaces)
    # print('m.interface:', m.interface)
    #
    # print('m.ipv4:', m.ipv4)
    # print('m.ipv6:', m.ipv6)

    assert m.ipv4
    assert m.ipv6

# Generated at 2022-06-20 18:20:46.225981
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    linuxnet = LinuxNetwork(module)

    data = linuxnet.get_ethtool_data("test")
    assert 'features' in data
    assert 'timestamping' in data
    assert 'hw_timestamp_filters' in data
    assert 'phc_index' in data



# Generated at 2022-06-20 18:20:57.053786
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    class ModuleMock:
        def get_bin_path(self, cmd, required=False):
            return cmd


# Generated at 2022-06-20 18:21:00.678063
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    LN = LinuxNetwork()
    LN.get_interfaces_info(1,2,3)

if __name__ == '__main__':
    test_LinuxNetwork()

# Generated at 2022-06-20 18:21:11.340560
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    class LinuxNetworkModuleExitException(Exception):
        pass

    module_args = {'gather_subset': ['all'], 'gather_timeout': 5}

    class LinuxNetworkModule(object):

        def __init__(self, module_args):
            self.params = module_args

        def get_bin_path(self, executable, required=False):
            if 'ip' in executable:
                class Paths(object):
                    def __init__(self, path):
                        self.path = path

                    def __str__(self):
                        return self.path

                return Paths('ip_path')
            elif 'ethtool' in executable:
                class Paths(object):
                    def __init__(self, path):
                        self.path = path

                    def __str__(self):
                        return self.path

# Generated at 2022-06-20 18:21:21.314969
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    c = dict(
        check_rc=False,
        check_invalid_arguments=False,
        module_args=dict(
            name='eth0',
        ),
    )
    # find a "real interface name" on the machine where to test this
    module = AnsibleModule(**c)
    l = LinuxNetwork(module)
    interfaces = l.get_interfaces()
    default_ipv4 = 'unknown'
    default_ipv6 = 'unknown'
    for i, v in interfaces.items():
        if 'ipv4' in v:
            ipv4 = v['ipv4']
            if ipv4.get('default_interface'):
                default_ipv4 = ipv4['address']
                break

# Generated at 2022-06-20 18:21:31.240050
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import MagicMock, patch
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils._text import to_bytes

    def ethtool_path(self, arg):
        return "/bin/ethtool"

    def run_command(self, arg, errors=None):
        boolValue = 1 if random.choice((True, False)) else 0
        return (0, "", "")


# Generated at 2022-06-20 18:21:38.433478
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    collector = LinuxNetworkCollector(module)
    assert isinstance(collector, (NetworkCollector, BaseCollector))
    assert collector.module == module
    assert collector.facts == {}
    assert collector.platform == 'Linux'
    assert collector.required_facts == set(['distribution', 'platform'])
    assert collector.network_facts is None
    assert collector.ip_path == '/sbin/ip'
    assert collector.has_getmac == 0
    assert collector.has_netstat == 0
    assert collector.additional_paths == []


# Generated at 2022-06-20 18:21:45.576312
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    ln = LinuxNetwork({})
    assert ln.get_interfaces_info(None, None, None)[1]['all_ipv4_addresses'] == []
    assert ln.get_interfaces_info(None, None, None)[1]['all_ipv6_addresses'] == []



# Generated at 2022-06-20 18:22:14.958972
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # test without default_route defined
    rc, out, err = module.run_command(["ip", "-4", "route", "list", "0.0.0.0/0"])
    (default_ipv4, default_ipv6) = net.get_default_interfaces()
    assert(default_ipv4 == {"default": True})
    assert('default' not in default_ipv6)

    # test with default_route defined
    rc, out, err = module.run_command(["ip", "-6", "route", "list", "::/0"])
    (default_ipv4, default_ipv6) = net.get_default_interfaces()
    assert(default_ipv6 == {'scope': 'universe', 'default': True})

# Generated at 2022-06-20 18:22:24.166773
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={})
    network = LinuxNetwork(module)

    # call get_ethtool_data for device "eth0" with output from ethtool

# Generated at 2022-06-20 18:22:36.927195
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    print("Testing get_ethtool_data")
    # FIXME: how do we test this?
    # expected = {
    #     'features': {
    #         'tx': 'on',
    #         'rx': 'on',
    #         'tx_scatter': 'on',
    #         'tx_gather': 'on',
    #         'tx_checksumming': 'on',
    #         'tx_checksum_ipv4': 'on',
    #         'tx_checksum_ipv6': 'on',
    #         'tx_checksum_ip_generic': 'on',
    #         'tx_checksum_fcoe_crc': 'on',
    #         'tx_checksum_sctp': 'on',
    #         'rx_checksumming': 'on',


# Generated at 2022-06-20 18:22:46.122664
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    if not HAS_IPROUTE:
        module = MagicMock()
        module.fail_json.assert_called_once_with(msg='Please install the iproute package\n')
        return

    module = MagicMock()

    # Set module attributes
    module.get_bin_path.return_value = "/usr/bin/ip"
    module.run_command.return_value = 0, "192.168.0.1", None

    ln = LinuxNetwork(module)
    # Check for missing module parameters
    assert ln.get_default_interfaces() == ({"address": "192.168.0.1"}, None)



# Generated at 2022-06-20 18:22:57.750661
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    def run_test(test_defaults):
        m = mock.mock_open()
        with mock.patch('{}{}'.format(builtins, 'open'), m, create=True):
            m.return_value = io.StringIO(test_defaults['contents'])
            net = LinuxNetwork()
            net.populate()
            #assert net.default_ipv4 == test_defaults['default_ipv4']
            #assert net.default_ipv6 == test_defaults['default_ipv6']
            assert net.interfaces == test_defaults['interfaces']
            m.close.assert_called_once_with()

    # TODO: this should be more like a proper unit test

    # No default route

# Generated at 2022-06-20 18:23:09.346591
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # create a module for use as a fake AnsibleModule
    module = AnsibleModule({})
    # create a class for testing
    ln = LinuxNetwork(module)

    # dictionary of the interfaces to be used in the test
    test_interfaces = {}

# Generated at 2022-06-20 18:23:13.576597
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec=dict())
    obj = LinuxNetwork(module)
    module.exit_json(changed=False, ansible_facts=dict(ansible_network_resources=obj.get_resources()))


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 18:23:19.731069
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    ln = LinuxNetwork(module)
    #
    #
    # TODO: There are no asserts yet
    #
    #

# Generated at 2022-06-20 18:23:27.906524
# Unit test for method populate of class LinuxNetwork

# Generated at 2022-06-20 18:23:39.330038
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Arrange
    module_args = dict(
        config_file=dict(
            name='config_file',
            type='str',
            required=False,
            default=None
        ),
        running_config=dict(
            name='running_config',
            type='str',
            required=False,
        ),
        use_ipv6=dict(
            name='use_ipv6',
            type='bool',
            required=False,
            default=False
        ),
    )
    # NOTE: AnsibleModule object is not used because it is too heavy-weighted
    # We need either a mock or a light-weighted object

# Generated at 2022-06-20 18:24:11.857421
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """
    Test data from get_ethtool_data() method of LinuxNetwork class
    output of ethtool -k eth0
    """


# Generated at 2022-06-20 18:24:22.062172
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    import json
    import os
    import shutil
    import tempfile
    import sys

    print("Running " + sys._getframe().f_code.co_name)

    # Create a temporary directory containing mocked files
    tmp = tempfile.mkdtemp()
    path = os.path.join(tmp, 'sbin', 'ethtool')
    os.makedirs(os.path.dirname(path))

# Generated at 2022-06-20 18:24:29.259951
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # Instantiate class LinuxNetworkCollector
    module = AnsibleModule(argument_spec=dict())
    linux_network_collector = LinuxNetworkCollector(module=module)

    # Assert that class attributes are correctly set.
    assert linux_network_collector._platform == 'Linux'
    assert linux_network_collector._fact_class == LinuxNetwork
    assert linux_network_collector.required_facts == set(['distribution', 'platform'])



# Generated at 2022-06-20 18:24:31.263990
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    test_module = 'ansible.modules.network.linux'
    test_class = 'LinuxNetwork'

    module = import_module(test_module)
    obj = getattr(module, test_class)()

    assert obj is not None

# Generated at 2022-06-20 18:24:42.030888
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    ln = LinuxNetwork(module)

    default_ipv4, default_ipv6 = ln._get_default_interfaces()

    interfaces, ips = ln.get_interfaces_info(ln.ip_path, default_ipv4, default_ipv6)
    assert(len(interfaces) > 0)
    assert(interfaces['lo']['ipv4']['address'] == '127.0.0.1')
    assert(interfaces['lo']['ipv4']['netmask'] == '255.0.0.0')
    assert(interfaces['lo']['ipv4']['broadcast'] == '')

# Generated at 2022-06-20 18:24:47.230625
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    nc = LinuxNetworkCollector(module)
    nc._detect()
    assert nc._platform == 'Linux'
    assert nc._fact_class.__name__ == 'LinuxNetwork'


# Generated at 2022-06-20 18:24:50.313176
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    interfaces = ln.interfaces
    assert isinstance(interfaces, dict)



# Generated at 2022-06-20 18:24:58.008703
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """Unit test for constructor of class LinuxNetworkCollector"""
    # Show that instance of class LinuxNetworkCollector is created and has required attributes
    result = LinuxNetworkCollector()
    assert result._platform == 'Linux'
    assert result._fact_class == LinuxNetwork
    assert result.required_facts == {'distribution', 'platform'}



# Generated at 2022-06-20 18:25:04.321441
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # TODO: Mock out time
    # TODO: This is not really a unit test, it writes to disk

    from ansible.module_utils.basic import AnsibleModule
    import os

    test_interface = "lo"
    test_interface_file = "/proc/net/dev"
    test_interface_txt = """Inter-|   Receive                                                |  Transmit
 face |bytes    packets errs drop fifo frame compressed multicast|bytes    packets errs drop fifo colls carrier compressed
  lo:       0       0    0    0    0     0          0         0        0       0    0    0    0     0       0          0
  eth0:  53581    1275    0    0    0     0          0         0    63987    1573    0    0    0     0       0          0"""



# Generated at 2022-06-20 18:25:09.066749
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    # Fixture
    set_module_args({})
    linux_network_collector = LinuxNetworkCollector(module=module)
    assert linux_network_collector
    # Test setting of correctly copied attributes
    assert linux_network_collector.module == module


# Generated at 2022-06-20 18:25:47.253643
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = MagicMock(get_bin_path=lambda x: True)
    l = LinuxNetwork(module)

# Generated at 2022-06-20 18:25:57.906803
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    network = LinuxNetwork()
    # we cannot use __dict__ because we cannot set read-only attributes
    for k, v in vars(LinuxNetwork).items():
        if not k.startswith('_'):
            setattr(network, k, v)


# Generated at 2022-06-20 18:26:11.209513
# Unit test for method get_interfaces_info of class LinuxNetwork

# Generated at 2022-06-20 18:26:14.997661
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    myln = LinuxNetwork()
    myln.get_interfaces_info(ip_path='/sbin/ip', default_ipv4={}, default_ipv6={})


# Generated at 2022-06-20 18:26:20.181582
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={
        'path': dict(type='path', default='/sbin:/usr/sbin:/bin:/usr/bin'),
    })
    network = LinuxNetwork(module)
    data = network.get_ethtool_data('sdfsdfsdfsdfsdfsssss')
    assert data == {}



# Generated at 2022-06-20 18:26:29.574919
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(argument_spec={
        'name': {'type': 'str'}
    })

    m = LinuxNetwork(module=module)

    class MockEthtool:
        def __init__(self, device):
            self.device = device
            self.data = {
                'eth0': {
                    'features': {
                        'tx-checksumming': 'on',
                        'tx-checksum-ipv4': 'on',
                    },
                    'timestamping': ['hw'],
                    'hw_timestamp_filters': ['all'],
                    'phc_index': 1,
                }
            }
        def run_command(self):
            rc = 0
            stdout = ''
            stderr = ''


# Generated at 2022-06-20 18:26:36.659129
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # instantiate class
    network = LinuxNetwork()
    (interfaces, ips) = network.get_interfaces_info('', {}, {})
    # retrieve ethtool data of an interface
    ethtool_data = network.get_ethtool_data("eth0")
    # check if some attributes are present:
    assert  'features' in ethtool_data
    assert  'timestamping' in ethtool_data
    assert  'hw_timestamp_filters' in ethtool_data

# Generated at 2022-06-20 18:26:47.200560
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """Unit tests for LinuxNetwork.get_ethtool_data"""
    # mock to run the get_ethtool_data method without any command

# Generated at 2022-06-20 18:26:51.743546
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    test_net = LinuxNetwork(None)
    test_device = 'eth0'
    ethtool_data = test_net.get_ethtool_data(test_device)
    assert ethtool_data['features']['rx_all'] == 'on'


# Generated at 2022-06-20 18:27:03.793650
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    ethtool_path = False

# Generated at 2022-06-20 18:28:22.284369
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # Parameters to init the instance
    module = None
    module_params = dict()

    # Return values to test the result of the populating method

# Generated at 2022-06-20 18:28:32.162458
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    import tempfile
    import os

    module = AnsibleModule(argument_spec=dict(
        fail_on_missing=dict(type='bool', required=False, default=False),
        gather_subset=dict(type='list', required=False, default=['!all']),
    ))
    # mocked module
    module.run_command = lambda cmd, **kwargs: (0, '', '')

    linux_network = LinuxNetwork(module)
    # add mocked methods
    linux_network.get_interfaces_info = lambda ip_path, default_ipv4, default_ipv6: (dict(), dict())
    linux_network.get_interfaces_from_ip_output = lambda: (dict(), dict())
    linux_network.get_default_interface = lambda: (dict(), dict())

# Generated at 2022-06-20 18:28:36.282493
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = AnsibleModule(
        argument_spec=dict(
            device=dict(type='str'),
        ),
    )
    ln = LinuxNetwork(module)
    assert ln.get_ethtool_data('foo') == {}


# Generated at 2022-06-20 18:28:42.660521
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    # empty constructor
    a = LinuxNetworkCollector()

    # constructor with parameters
    a = LinuxNetworkCollector(
        module=None,
        params=None,
        facts=None
    )
    assert a._platform == 'Linux'
    assert a._fact_class == LinuxNetwork


# Generated at 2022-06-20 18:28:54.062558
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    current_os = 'Linux'

    class FakeModule(object):
        def __init__(self):
            self.bin_path = {}

        def get_bin_path(self, bin_name):
            return self.bin_path.get(bin_name)

        def run_command(self, bin_args, errors='surrogate_or_stderr'):
            if bin_args[0] == 'ip':
                if bin_args[1] == 'addr':
                    arg_2 = bin_args[2]
                    if arg_2 == 'show':
                        arg_3 = bin_args[3]

# Generated at 2022-06-20 18:28:55.144901
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    pass

# Generated at 2022-06-20 18:29:07.381403
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    # Setup a fake module so we can test method populate of class LinuxNetwork
    module = DummyModule()
    module.params.update({
        'gather_network_resources': True
    })

    # Setup a fake module so we can test method compile of class BSDNetwork
    module.run_command = MagicMock()
    module.run_command.return_value = 0, 'fake_data', 'fake_error'

    # Execute method populate of class LinuxNetwork
    network = LinuxNetwork(module)
    network.populate()

    # Assert module.run_command was called with expected args

# Generated at 2022-06-20 18:29:13.932710
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    linux_network_obj = LinuxNetwork()
    actual = linux_network_obj.populate()
    assert module.params['ansible_facts'] == actual


# Generated at 2022-06-20 18:29:23.162940
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    # Return default interface tuple (ipv4, ipv6) or None at index or
    # None if there are no default interface (with any IPv4 or IPv6 IP)
    # or None if there are 0 interface on the machine

    def assert_default_interface(interfaces, expected_interface, expected_ipv4=None, expected_ipv6=None):

        network = LinuxNetwork()
        network.LOCAL_INTERFACE = interfaces
        default_interface = network.get_default_interface()
        if default_interface is None:
            assert expected_interface is None
        else:
            actual_interface = default_interface[0]
            actual_ipv4 = default_interface[1]
            actual_ipv6 = default_interface[2]
            assert actual_interface == expected_interface

# Generated at 2022-06-20 18:29:32.792634
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    l = LinuxNetwork(module)
    v4, v6 = l.get_routes_interfaces()
    assert isinstance(v4, dict)
    assert isinstance(v6, dict)
    assert isinstance(v4.get('interface', None), str)
    assert isinstance(v6.get('interface', None), str)
    assert isinstance(v4.get('default', None), bool)
    assert isinstance(v6.get('default', None), bool)

    interfaces, ips = l.get_interfaces_info('/sbin/ip', dict(address=None), dict(address=None))
    assert isinstance(interfaces, dict)
    assert isinstance(ips, dict)