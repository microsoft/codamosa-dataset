

# Generated at 2022-06-20 18:20:23.410156
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    obj = LinuxNetwork()
    result = obj.get_device_info()
    return result

# Testing below

# Generated at 2022-06-20 18:20:36.348302
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():

    # Create fake module
    class DummyModule(object):
        def __init__(self):
            self.tmpdir = tempfile.mkdtemp()

        def run_command(self, command, errors='surrogate_then_replace'):
            command1 = ['/sbin/ip', 'route', 'get', '8.8.8.8']
            command2 = ['/sbin/ip', '-6', 'route', 'get', '2001:4860:4860::8888']
            if command == command1:
                return (0, "8.8.8.8 via 11.22.33.44 dev eth0  src 1.2.3.4 uid 1000 \n cache ", "")

# Generated at 2022-06-20 18:20:47.344360
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    from .. import NetworkCollector

    # Create an instance of LinuxNetworkCollector
    lnc = LinuxNetworkCollector()

    # Check if it is an instance of NetworkCollector
    assert isinstance(lnc, NetworkCollector)

    # Check if it is an instance of LinuxNetworkCollector
    assert isinstance(lnc, LinuxNetworkCollector)

    # Does LinuxNetworkCollector have all necessary instance attributes?
    assert hasattr(lnc, '_platform') and hasattr(lnc, 'required_facts') and hasattr(lnc, '_fact_class')

    # Check if LinuxNetworkCollector creates the right object
    assert lnc._fact_class == LinuxNetwork


# Generated at 2022-06-20 18:21:00.181006
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat import unittest
    from ansible_collections.misc.not_a_real_collection.tests.unit.compat.mock import patch, Mock

    class LinuxNetworkTestCase(unittest.TestCase):

        def setUp(self):
            self.module = Mock()
            self.module.get_bin_path.return_value = "/usr/sbin/ethtool"

        def test_get_ethtool_data_parses_features_correctly(self):
            device = "eth0"


# Generated at 2022-06-20 18:21:11.165719
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    ln = LinuxNetwork()
    ln.module = AnsibleModule(argument_spec={})

    ln.module.run_command = MagicMock()

# Generated at 2022-06-20 18:21:13.282075
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})

    nm = LinuxNetwork(module=module)
    nm.get_interfaces_info()
    nm.get_ip_addresses(args=None)



# Generated at 2022-06-20 18:21:19.932961
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    '''
    Test that instantiation of the LinuxNetworkCollector object works
    '''
    # Get a module object
    module = AnsibleModuleFake()
    module.get_bin_path = lambda x: x
    # Set required facts
    module.ansible_facts = {
        'distribution': 'Debian',
        'platform': 'Linux'
    }
    # Instantiate the LinuxNetworkCollector object
    my_obj = LinuxNetworkCollector(module)
    # Test that object is not none
    assert my_obj



# Generated at 2022-06-20 18:21:29.947762
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    """
    setup mock objects and test populate of class LinuxNetwork
    """
    module = mock.MagicMock()
    module.get_bin_path.return_value = 'ip'

# Generated at 2022-06-20 18:21:39.378249
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    import ansible_collections.ansible.community.plugins.module_utils.network.common.network.module_utils.network as network
    import ansible_collections.ansible.community.plugins.module_utils.network.common.network.module_utils.facts as facts_module
    import ansible_collections.ansible.community.plugins.module_utils.network.common.network.module_utils.utils as utils
    import ansible_collections.ansible.community.plugins.module_utils.network.common.network.module_utils.argspec as argspec
    from ansible_collections.ansible.community.plugins.module_utils.network.common.facts.network.network import NetworkCollector
    from ansible_collections.ansible.community.plugins.module_utils.network.common.facts.facts import Facts


# Generated at 2022-06-20 18:21:52.651362
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    am = LinuxNetwork(module)
    ip_path = am.module.get_bin_path('ip')
    if platform.system() == 'FreeBSD':
        p = subprocess.Popen([ip_path, 'route', 'get', '8.8.8.8'], stdout=subprocess.PIPE)
    else:
        p = subprocess.Popen([ip_path, 'route', 'get', '8.8.8.8'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    output, stderr = p.communicate()
    v4default, v6default = am.get_default_interfaces(output)

# Generated at 2022-06-20 18:22:30.126424
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    """
    Unit test for method LinuxNetwork.get_ethtool_data
    """
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module, {'kernel': '2.6.32'})
    assert ln.get_ethtool_data(device="test_int") == {}



# Generated at 2022-06-20 18:22:36.417931
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """Unit test for class LinuxNetworkCollector
    """
    # Constructor instantiates Netstats and Route classes
    c = LinuxNetworkCollector({}, None)
    assert(c.network)
    assert(c.route)
    assert(c.netstats)



# Generated at 2022-06-20 18:22:45.936675
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    linux_network = LinuxNetwork(module={})
    ifaces, ips = linux_network.get_interfaces_info("/sbin", {}, {'address': '::1'})
    facts = {}
    linux_network.populate(facts, ifaces, ips, {}, {}, {})
    assert facts['network']['interfaces']['lo']['ipv6'][0]['scope'] == 'host'
    assert facts['network']['default_ipv4']['address'] == '10.0.2.15'
    assert facts['network']['default_ipv6']['address'] == '::1'



# Generated at 2022-06-20 18:22:54.226971
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(argument_spec={})
    module.params = {
        'use_ipv6': True,
        'default_ipv4': dict(address='8.8.8.8'),
        'default_ipv6': dict(address='2001:4860:4860::8888'),
    }
    ln = LinuxNetwork(module)
    ln.populate()

    assert 'interfaces' in ln.data
    assert 'ipv4' in ln.data
    assert ln.data['ipv4']['address'] == '8.8.8.8'
    assert 'ipv6' in ln.data
    assert ln.data['ipv6']['address'] == '2001:4860:4860::8888'

# Generated at 2022-06-20 18:23:07.715937
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # prepare LinuxNetwork object
    linux_net = LinuxNetwork()

    # check LinuxNetwork.get_ethtool_data() with ethtool present
    linux_net.module.get_bin_path = lambda name: "/bin/ethtool"

# Generated at 2022-06-20 18:23:12.729266
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)
    default_ipv4, default_ipv6 = ln.get_default_interface()
    output = ln.get_interfaces_info(ln.ip_path, default_ipv4, default_ipv6)
    pprint.pprint(output)


# Generated at 2022-06-20 18:23:26.746911
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    class TestArgs(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

    class TestModule(object):
        def __init__(self, bin_path):
            self.params = TestArgs(bin_path)

        def get_bin_path(self, arg, required=False):
            return self.params.bin_path

        def run_command(self, *args, **kwargs):
            cmd = args[0]
            if cmd[0] != "ethtool":
                return 1, "", "ethtool executable not found"


# Generated at 2022-06-20 18:23:32.312253
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    n = LinuxNetwork()
    n.populate()
    assert n.interfaces.keys()
    assert n.ips['all_ipv4_addresses']
    assert n.ips['all_ipv6_addresses']



# Generated at 2022-06-20 18:23:38.383465
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())
    ln = LinuxNetwork(module)
    out = ln.get_default_interfaces()

    # Default IPv4 address for my Ubuntu VM
    assert out[0]['address'] == '10.0.2.15'

    # Default IPv6 address for my Ubuntu VM
    assert out[1]['address'] == 'fe80::a00:27ff:fe07:aa8c'


# Generated at 2022-06-20 18:23:39.892807
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    l = LinuxNetwork()
    # l.get_ethtool_data('')
    assert 1



# Generated at 2022-06-20 18:24:54.294554
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    os = LinuxNetwork(module)
    module.exit_json(
        default_ipv4=os.default_ipv4,
        default_ipv6=os.default_ipv6,
        interfaces=os.interfaces,
        ips=os.ips,
        interfaces_ipv4=os.interfaces_ipv4,
        interfaces_ipv6=os.interfaces_ipv6,
        primary_ipv4=os.primary_ipv4,
        primary_ipv6=os.primary_ipv6,
    )



# Generated at 2022-06-20 18:25:04.667352
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    from ansible.module_utils.facts.network.base import NetworkCollector

    path_exists_orig = os.path.exists
    path_isdir_orig = os.path.isdir
    path_isfile_orig = os.path.isfile
    get_file_content_orig = NetworkCollector.get_file_content
    run_command_orig = NetworkCollector.run_command


# Generated at 2022-06-20 18:25:17.559333
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # TODO: refactor tests to not use a shared global
    global dev_mock
    global addr_mock

    # TODO: refactor tests to use 'setup_method'
    dev_mock = MagicMock()
    addr_mock = MagicMock()
    module = MagicMock(name="AnsibleModule",
                       check_mode=False,
                       params={})
    lnm = LinuxNetwork(module)
    facts = {}
    # TODO: refactor tests to use 'assert'
    if not lnm.populate(facts):
        raise Exception('LinuxNetwork.populate() was not successful - see previous error')

    lnm = LinuxNetwork(module)
    # TODO: refactor tests to use 'assert'
    if not lnm.populate(facts, 'eth0'):
        raise Exception

# Generated at 2022-06-20 18:25:22.049533
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    module.exit_json = lambda **kw: None
    module.run_command = lambda args, **kw: (0, '', '')
    ln = LinuxNetwork(module)
    assert hasattr(ln, 'route')

# Helper to test LinuxNetwork methods

# Generated at 2022-06-20 18:25:34.373724
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # Test with bad path
    module = AnsibleModule(argument_spec=dict())
    mock_path = MagicMock(return_value=None)
    mock_run_command = MagicMock(return_value=(0, "some output", ""))
    with patch.dict(module.__dict__, {'get_bin_path': mock_path, 'run_command': mock_run_command}):
        assert LinuxNetwork(module).get_ethtool_data("test123") == {}

    # Test ethtool output
    module = AnsibleModule(argument_spec=dict())
    mock_path = MagicMock(return_value="ethtool")
    mock_run_command = MagicMock(return_value=(0, "some output", ""))

# Generated at 2022-06-20 18:25:46.271032
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    class FakeModule(object):
        def __init__(self, params):
            self.params = dict(
                name="eth0",
                ipv4=dict(
                    gateway="192.0.2.1",
                    address="192.0.2.5/24"
                ),
                ipv6=dict(
                    gateway="2001:db8::1",
                    address="::1/64"
                )
            )
            self.params.update(params)
            self.fail_json = self.exit_json = lambda **kwargs: None

        # NOTE: This bypasses the check that we are running the module
        # locally and the module is executable.

# Generated at 2022-06-20 18:25:57.496470
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    """
    Method get_interfaces_info should return a dict of dicts.
    It tests whether the dict has the correct number of keys and if the v4 and v6 subkeys are also dicts.
    """
    linux_network = LinuxNetwork()

    # read ip_path from path
    ip_path = linux_network.module.get_bin_path("ip")
    default_ipv4 = {}
    default_ipv6 = {}
    interfaces, ips = linux_network.get_interfaces_info(ip_path, default_ipv4, default_ipv6)

    assert isinstance(interfaces, dict)
    # check if the number of interfaces matches the number of interfaces of the machine

# Generated at 2022-06-20 18:26:00.649150
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule({})
    linux_network = LinuxNetwork(module)
    assert linux_network.module == module


# Generated at 2022-06-20 18:26:13.820335
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # Setup Test Environment
    mock_module = Mock()
    mock_module.get_bin_path.return_value = '/bin/ip'

# Generated at 2022-06-20 18:26:23.273033
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    net = LinuxNetwork()
    good_data = {'v4': {'gateway': '192.168.1.1', 'address': '192.168.1.13', 'interface': 'eth0'},
                'v6': {'gateway': 'fe80::a00:27ff:fe5d:f45e', 'address': 'fe80::a00:27ff:fe5d:f45e'}}
    bad_data = {}
    assert good_data == net.get_default_interfaces(good_data, bad_data)

    good_data = {'v4': {'gateway': '192.168.1.1', 'address': '192.168.1.13', 'interface': 'eth0'}}
    bad_data = {}
    assert good_data == net.get_default_inter

# Generated at 2022-06-20 18:27:36.688547
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
  # Setup a simple object for method to run on
  linux_network = LinuxNetwork()
  linux_network.module = AnsibleModule(argument_spec= {'module_name': dict(required=False)})

  # We expect the populate method to raise an exception when no network
  # provider has been set.
  with pytest.raises(Exception) as exception_info:
    linux_network.populate()


# Generated at 2022-06-20 18:27:48.011593
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module_mock = AnsibleModuleMock({})
    rsyslog_mock = LinuxNetwork(module_mock)

# Generated at 2022-06-20 18:27:53.186957
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = NetworkCollector()
    assert module.platform == 'Linux'
    assert module.fact_class == LinuxNetwork


# Generated at 2022-06-20 18:27:55.876102
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """Class is defined."""
    assert LinuxNetworkCollector._platform == 'Linux'
    assert LinuxNetworkCollector._fact_class == LinuxNetwork
    assert LinuxNetworkCollector.required_facts == set(['distribution', 'platform'])

# Generated at 2022-06-20 18:28:01.135764
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    instance = LinuxNetwork()
    # Setup mock objects
    module = MagicMock()
    module.warn = MagicMock()
    instance.module = module

    # Run test
    instance.get_ethtool_data('eth0')



# Generated at 2022-06-20 18:28:06.872906
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    module = Mock()
    module.run_command.return_value = 0, '', ''
    network = LinuxNetwork(module)
    data = network.get_ethtool_data("fake_device")
    assert data == {"features": {}, "timestamping": [], "hw_timestamp_filters": []}


# Generated at 2022-06-20 18:28:18.655946
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule({})
    ln = LinuxNetwork(module)
    interfaces, ips = ln.get_interfaces_info(os.path.realpath(__file__), ln.default_ipv4, ln.default_ipv6)
    assert 'lo' in interfaces
    assert interfaces['lo']['type'] == 'loopback'
    assert interfaces['lo']['mtu'] == 16436
    assert interfaces['lo']['ipv4']['address'] == "127.0.0.1"
    assert 'all_ipv4_addresses' in ips
    assert 'all_ipv6_addresses' in ips


# Generated at 2022-06-20 18:28:29.163213
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    test_module = AnsibleModule(
        argument_spec={},
    )
    network = LinuxNetwork(test_module)
    test_module.params['config'] = '''
# interfaces(5) file used by ifup(8) and ifdown(8)
auto lo
iface lo inet loopback

auto enp1s0
iface enp1s0 inet static
    address 192.0.2.1
    netmask 255.255.255.0
auto eno2
iface eno2 inet static
    address 192.0.2.1
    netmask 255.255.255.0
auto eth0
iface eth0 inet static
    address 192.0.2.1
    netmask 255.255.255.0
'''
    interfaces = network._parse_config()

# Generated at 2022-06-20 18:28:32.964619
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = AnsibleModule(argument_spec={})
    nm = LinuxNetworkCollector(module=module)
    assert nm.platform == 'Linux'


# Generated at 2022-06-20 18:28:46.762494
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    p = mock.patch.object(platform, 'system', new=mock.Mock(return_value='Linux'))
    p.start()
    m = mock.MagicMock()
    m.run_command = mock.Mock(return_value=[0, "", ""])
    m.get_bin_path = mock.Mock(return_value="/bin")
    m.get_file_content = mock.Mock()

    p = mock.patch.object(m, 'get_file_content', new=mock.Mock(return_value='0x0080'))
    p.start()

    ln = LinuxNetwork(m)

    assert ln.get_interfaces_info(None, None, None)
    assert ln.get_interfaces_info('/bin', None, None)
   