

# Generated at 2022-06-20 18:20:37.831324
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = DummyAnsibleModule()
    network = LinuxNetwork(module=module)
    module.run_command = Mock(return_value=(0, "default via 10.0.2.2 dev eth0\n10.0.2.0/24 dev eth0 proto kernel scope link src 10.0.2.15\n169.254.0.0/16 dev eth0 scope link metric 1002\n", None))
    data = network.get_default_interface()
    assert data['ipv4']['address'] == '10.0.2.15'
    assert data['ipv4']['gateway'] == '10.0.2.2'
    assert data['ipv4']['interface'] == 'eth0'


# Generated at 2022-06-20 18:20:49.692990
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    hostname = "ansible.linux"
    cls_net = LinuxNetwork(AnsibleModule(argument_spec=dict(
    )))
    # Set the following criteria in order to have data to test
    output_ethtool_k_1 = b'''
    Features for eno37345896:
    Cannot get device settings: Operation not supported
    Cannot get wake-on-lan settings: Operation not supported
    Cannot get message level: Operation not supported
    Cannot get link status: Operation not supported
    '''

# Generated at 2022-06-20 18:21:02.530395
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec={})
    ln = LinuxNetwork(module)

    # test get_interfaces_addresses() without argument
    (v4, v6) = ln.get_interfaces_addresses()

    # test get_interfaces_addresses() with an ipv4 argument
    (v4, v6) = ln.get_interfaces_addresses("192.168.122.238")
    assert v4['address'] == '192.168.122.238'
    assert v4['interface'] == 'virbr0'
    assert v4['gateway'] == '192.168.122.1'
    assert v4['netmask'] == '255.255.255.0'
    assert v4['network'] == '192.168.122.0'

    # test get_inter

# Generated at 2022-06-20 18:21:11.994260
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    fixture_path = os.path.join(os.path.dirname(__file__), 'fixtures',
                                'get_interfaces_info')
    with open(os.path.join(fixture_path, 'get_interfaces_info.txt'), 'r') as f:
        ip_data = f.read()
    with open(os.path.join(fixture_path, 'get_interfaces_info_secondary.txt'), 'r') as f:
        ip_data_secondary = f.read()
    with open(os.path.join(fixture_path, 'get_interfaces_info_bridged.txt'), 'r') as f:
        ip_data_bridged = f.read()

# Generated at 2022-06-20 18:21:13.382031
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    result = LinuxNetworkCollector()
    assert result._platform == 'Linux'
    assert result._fact_class == LinuxNetwork
    assert result.required_facts == {'distribution', 'platform'}



# Generated at 2022-06-20 18:21:19.062148
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    """Unit test"""
    linux_network = LinuxNetwork()
    interfaces, ips = linux_network.get_interfaces_info('/sbin/ip', None, None)
    assert any(interfaces)
    assert all(interfaces.values())

    default_ipv4, default_ipv6 = linux_network.get_default_interfaces()
    assert default_ipv4
    assert default_ipv6



# Generated at 2022-06-20 18:21:29.214246
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    fake_module = FakeAnsibleModule()
    fake_module.params = dict()
    network_module = LinuxNetwork(fake_module)

    test_device = 'eno1'

# Generated at 2022-06-20 18:21:41.657478
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule(argument_spec=dict())
    network = LinuxNetwork(module)
    # for attr in dir(network):
    #     if not re.match('__.*__', attr) and not attr.endswith('_info'):
    #         print(attr)
    # print json.dumps(network.default_ipv4, indent=2)
    # print json.dumps(network.ipv4, indent=2)
    # print json.dumps(network.interfaces, indent=2)
    assert network.default_gateway['interface'] == 'eth0'
    assert network.default_gateway['ipv4']['address'] == '192.168.122.1'

# Generated at 2022-06-20 18:21:53.770509
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils import basic

    module = basic.AnsibleModule({}, '', True)
    l_net = LinuxNetwork(module)

# Generated at 2022-06-20 18:21:55.785103
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    x=LinuxNetwork()
    x.get_ethtool_data("eth0")

# Generated at 2022-06-20 18:22:32.068327
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    required_facts = set(['distribution', 'platform'])
    network_collector = LinuxNetworkCollector(dict(), required_facts)
    assert network_collector
    assert isinstance(network_collector, NetworkCollector)
    assert network_collector._platform == 'Linux'
    assert network_collector.required_facts == required_facts


# Generated at 2022-06-20 18:22:42.999392
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    import tempfile
    from ansible.module_utils.six import StringIO

    # This unit test needs to be run as root because we need to create device
    # files that are owned by root and therefore not writable by normal users
    if os.geteuid():
        raise AssertionError("This test needs to be run as root")

    # We will create a network device using a temporary file (the actual
    # creation is done by the tunctl command).
    # We need the temporary file because tunctl wants the filename to be a
    # number (the major device number), and python temporary files have no
    # number at all.
    temp = tempfile.NamedTemporaryFile()
    # We also need a temporary directory to store the temporary file in.
    tempdir = tempfile.TemporaryDirectory()

# Generated at 2022-06-20 18:22:56.026523
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict()
    )
    module.params = {}
    module.exit_json = lambda x: x
    module.fail_json = lambda x: x
    # NOTE: this is a class variable
    LinuxNetwork.module = module

    linux_network = LinuxNetwork()

    # test when no interfaces exist
    interfaces = linux_network.get_interfaces_info([], {}, {})
    assert interfaces == ({}, {'all_ipv4_addresses': [], 'all_ipv6_addresses': []})

    # test when only loopback exists
    interfaces = linux_network.get_interfaces_info(["127.0.0.1"], {}, {})

# Generated at 2022-06-20 18:23:08.465377
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():

    # construct a mock module
    module = MagicMock()
    module.params = {}
    module.params['gather_network_resources'] = True
    module.run_command = MagicMock()
    module.get_bin_path = MagicMock()

    # TODO: setup module.run_command to return fake data
    # TODO: setup module.get_bin_path to return fake data
    module.run_command.return_value = (0, "", "")
    module.get_bin_path.return_value = "/usr/bin"

    # setup mocks for get_file_content

# Generated at 2022-06-20 18:23:19.497307
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    """None"""
    module = AnsibleModule(argument_spec=dict(
        gather_subset=dict(type='list', default=["all"]),
        gather_network_resources=dict(type='list', default=['all']),
    ), supports_check_mode=True)

    def _read_file(path):
        try:
            with open(path, 'r') as target:
                return target.read()
        except Exception as e:
            return ''

    # TODO: not sure how to mock this properly
    c_read_file = _read_file
    c_run_command = run_command
    _run_command = Mock(side_effect=c_run_command)
    _read_file = Mock(side_effect=c_read_file)

# Generated at 2022-06-20 18:23:30.959440
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    assert LinuxNetwork(None).get_default_interfaces(None) == (None, None)
    assert LinuxNetwork(None).get_default_interfaces({}) == ({}, None)
    assert LinuxNetwork(None).get_default_interfaces({'interfaces': {}}) == ({}, None)
    assert LinuxNetwork(None).get_default_interfaces({'interfaces': {'eth0': {}}}) == ({}, 'eth0')
    assert LinuxNetwork(None).get_default_interfaces({'interfaces': {'eth0': {'interface': 'eth0'}}}) == ({}, 'eth0')
    assert LinuxNetwork(None).get_default_interfaces({'interfaces': {'eth0': {'device': 'eth0'}}}) == ({}, 'eth0')
    assert LinuxNetwork(None).get_default_inter

# Generated at 2022-06-20 18:23:35.271279
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    target = LinuxNetwork()
    target.populate()
    assert not target.populated
    assert not target.interfaces
    assert not target.default_ipv4
    assert not target.default_ipv6


# Generated at 2022-06-20 18:23:45.510263
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # mock module
    module = Mock()

# Generated at 2022-06-20 18:23:49.271050
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = AnsibleModule({})
    ln = LinuxNetwork(module)
    assert ln


# Generated at 2022-06-20 18:23:50.158996
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    pass

# Generated at 2022-06-20 18:24:37.954854
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():

    for params in [
        {'module': {'get_bin_path': lambda x: x}},
        {'module': {'get_bin_path': lambda x: None}}]:

        with mock.patch.object(Network, '_linux_default_gateway', return_value={'v4': {}, 'v6': {}}) as mock_get_gw:
            with mock.patch.object(Network, 'get_interfaces_info', return_value=(
                    {'eth0': {'interface': 'eth0'}}, {'all_ipv4_addresses': ['10.0.0.1']})) as mock_get_if:
                nm = LinuxNetwork(params)
                result = nm.populate()


# Generated at 2022-06-20 18:24:50.907605
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():

    import platform
    from ansible_collections.ansible.netcommon.tests.unit.compat import unittest

    class TestLinuxNetwork(unittest.TestCase):
        def test_linux_network(self):
            module = AnsibleModule({}, {}, {}, True, True)
            ln = LinuxNetwork(module)
            self.assertEqual({}, ln.ipv4)
            self.assertEqual({}, ln.ipv6)
            self.assertEqual({}, ln.interfaces)
            self.assertEqual({}, ln.routes)
            self.assertEqual(ln.ip_path, '/bin/ip')
            self.assertEqual(ln.distribution, platform.dist()[0])

# Generated at 2022-06-20 18:25:03.169266
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # TODO:
    #   This test function is quite far from the goal of 'unit test' that
    #   tests each method of a class in isolation.
    #   - This test function accesses a private variable of an instance of
    #     the class, it shouldn't.
    #   - It tests the interface which makes it hard to migrate the code
    #     further (e.g. to rewrite the unit test for WindowsNetwork, to
    #     make it more obvious that it does not work (yet)).
    #   - The function also runs commands that are specific for GNU/Linux,
    #     thus failing if run on a different platform.
    from ansible.module_utils.common.process import get_bin_path
    from ansible.module_utils.basic import AnsibleModule

# Generated at 2022-06-20 18:25:09.344541
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # note that we use a copy of the module here
    m = copy.deepcopy(module)

    # "mock" default_ipv4, default_ipv6, default_route_ipv4, default_route_ipv6 args to module
    # note that we typecast to unicode strings since AnsibleModule will always return unicode strings

# Generated at 2022-06-20 18:25:23.096465
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    #  mock code from https://goo.gl/5x5x5x
    #  https://goo.gl/XcgjJ0
    #  https://goo.gl/AJNZt4
    #  https://goo.gl/tQ9Jt1
    ip_path = '/sbin/ip'
    default_ipv4 = {'address': '192.168.0.1'}
    default_ipv6 = {'address': 'fe80::'}

# Generated at 2022-06-20 18:25:28.017948
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    assert LinuxNetworkCollector.platform == 'Linux'
    assert LinuxNetworkCollector.fact_class == LinuxNetwork
    assert LinuxNetworkCollector.required_facts == set(['distribution', 'platform'])


# Generated at 2022-06-20 18:25:36.948878
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    import random
    device = 'lo'
    module = Mock()
    module.get_bin_path = Mock(return_value='/sbin/ethtool')
    module.run_command = Mock(autospec=True)
    data = {'features': {}, 'timestamping': [], 'hw_timestamp_filters': []}
    expected_rc = 0
    module.run_command.return_value = (expected_rc, '', '')
    ln = LinuxNetwork(module)
    result = ln.get_ethtool_data(device)
    module.run_command.assert_called_once_with(['/sbin/ethtool', '-k', 'lo'], errors='surrogate_then_replace')
    assert data == result


# Generated at 2022-06-20 18:25:47.569250
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    """Unit test for constructor of class LinuxNetwork"""
    module = NetworkModule()
    ln = LinuxNetwork(module)
    # Test for creating object for class LinuxNetwork
    assert ln.module == module

    # Test for default_ipv4 creation
    assert ln.default_ipv4['address'] == '0.0.0.0'
    assert ln.default_ipv4['broadcast'] == ''
    assert ln.default_ipv4['netmask'] == ''
    assert ln.default_ipv4['network'] == '0.0.0.0'
    assert ln.default_ipv4['macaddress'] == ''

    # Test for default_ipv6 creation
    assert ln.default_ipv6['scope'] == 'global'

# Generated at 2022-06-20 18:25:58.051096
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule({}, "", "", "", False, None)
    get_interfaces_info = {
        'myiface': {
            'ipv4': {
                'address': '1.2.3.4',
                'broadcast': '1.2.3.4',
                'netmask': '255.255.255.255',
                'network': '1.2.3.4',
            },
            'ipv6': [{
                'address': 'a',
                'prefix': '64',
                'scope': 'link',
            }],
        },
    }
    default_ipv4 = {}
    default_ipv6 = {}
    ip_path = './ip_path'

# Generated at 2022-06-20 18:26:06.205754
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    import json
    from ansible.module_utils import basic

    hostname = 'test.example.com'
    ip_path = '/sbin/ip'

    m = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    ln = LinuxNetwork(m)

    a = ln.get_ethtool_data('lo')
    b = {'features': {}}
    assert a == b

    a = ln.get_ethtool_data('eth0')

# Generated at 2022-06-20 18:26:37.630613
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    network = LinuxNetwork()
    assert network.ip_path == '/sbin/ip'
    network.module.params = {'interfaces': True}
    interfaces = network.get_interfaces_info(network.ip_path, default_ipv4={}, default_ipv6={})
    assert type(interfaces) is tuple
    # TODO: check whether interfaces_info is correct
    # assert interfaces[0]['lo']['mtu'] == 65536
    # assert interfaces[0]['lo']['mtu'] == 65536

# Generated at 2022-06-20 18:26:45.882308
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    test_module = 'linux_network'
    test_class = 'LinuxNetwork'
    test_ansible_module = AnsibleModule(test_module, 'linux_network')

    # This sets the module args from the user input.
    test_ansible_module.params = {
        'default_ipv4': None,
        'default_ipv6': None
    }

    # Create an instance from class LinuxNetwork
    test_linux_network = LinuxNetwork(test_ansible_module, "", "", "")

    # call method populate to get result
    test_result = test_linux_network.populate()

    # test result
    assert test_result['interfaces'] or test_result['interfaces']
    assert type(test_result['interfaces']) is dict
    assert test_result['ips'] or test_

# Generated at 2022-06-20 18:26:58.140415
# Unit test for constructor of class LinuxNetwork
def test_LinuxNetwork():
    module = MagicMock()
    module.run_command.return_value = (0, '', '')
    module.get_bin_path.return_value = '/sbin/ip'
    network = LinuxNetwork(module=module)
    assert network

if __name__ == '__main__':
    # Unit test
    test_LinuxNetwork()
    exit()


# Generated at 2022-06-20 18:27:09.184279
# Unit test for method get_ethtool_data of class LinuxNetwork
def test_LinuxNetwork_get_ethtool_data():
    # NOTE: the docker container used for Travis-CI doesn't seem to have ethtool installed
    if shutil.which("ethtool") is None:
        return None

    network = LinuxNetwork()

    # NOTE: this is unlikely a bridge or bond interface
    device = "eth0"

    data = network.get_ethtool_data(device)

    assert "features" in data
    assert isinstance(data["features"], dict)
    assert len(data["features"]) > 0

    assert "timestamping" in data
    assert isinstance(data["timestamping"], list)

    assert "hw_timestamp_filters" in data
    assert isinstance(data["hw_timestamp_filters"], list)

    return True


# Generated at 2022-06-20 18:27:14.948685
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(default=['!all'], type='list'),
            use_ipv6=dict(default=True, type='bool'),
        ),
        supports_check_mode=True,
    )
    network_info = LinuxNetwork(module)
    network_info.populate()
    facts = network_info.get_facts()
    print(json.dumps(facts, sort_keys=True, indent=4))
    module.exit_json(ansible_facts=facts)



# Generated at 2022-06-20 18:27:20.034576
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = Mock()
    mod_utils = Mock()
    mod_utils.get_bin_path = Mock(return_value="/sbin/ip")
    module.get_bin_path = Mock(return_value="/sbin/ip")
    module.run_command = Mock(return_value=(0, "", ""))
    module.params = {
        'dhcp_timeout': 10,
        'timeout': 1,
        'mtu': 1500
    }

    net = LinuxNetwork(module, mod_utils)
    out = net.get_default_interfaces()
    module.run_command.assert_called_with(['/sbin/ip', '-4', 'route', 'get', '1'], errors='surrogate_then_replace')

# Generated at 2022-06-20 18:27:31.989993
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    from ansible.module_utils._text import to_bytes

# Generated at 2022-06-20 18:27:40.267138
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    module = AnsibleModule(
        argument_spec=dict()
    )

    # FIXME: mock instead of re-writing
    # FIXME: break into smaller methods
    class LinuxNetworkThatMocksInterfacesInfo(LinuxNetwork):
        # TODO: move to module, not class
        # https://github.com/ansible/ansible/issues/50871
        def __init__(self, module):
            self.module = module
            self.ip_path = '/sbin/ip'

        def get_ip_version(self, command):
            # TODO: use version from command
            # https://github.com/ansible/ansible/issues/50871
            if command[0] == self.ip_path and command[1] == '-6':
                return 6
            return 4


# Generated at 2022-06-20 18:27:48.832595
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = MagicMock(params={'gather_subset': 'all'})
    # NOTE: the class name of the class we're mocking is used as the
    # return value for the mock if we don't specify a return value
    module.run_command.side_effect = [
        (0,
         "# skonta\n0.0.0.0 0.0.0.0 169.254.0.1 U 1003 0 0 eth0\n",
         None
         ),
        (0,
         "# skonta6\n::/0 fe80::1 U 1002 256 0 eth0\n",
         None
         ),
    ]

    linux_network = LinuxNetwork(module)
    result = linux_network.get_default_interfaces()


# Generated at 2022-06-20 18:27:52.005273
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    # TODO: provide unit test
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 18:28:28.326035
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    # setup
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    module.params = {'gather_subset': ['!all', 'min']}  # override gather_subset in AnsibleModule
    linux_network = LinuxNetwork(module)

    # execute
    ip_path = linux_network.module.get_bin_path("ip")

    # TODO: mock/stub
    def get_of(*args, **kwargs):
        return 0, "default via 10.0.0.1 dev eth0", ""

    def get_ip_routes(*args, **kwargs):
        return 0, "10.0.0.1 dev eth0", ""

    setattr(linux_network.module, 'run_command', get_of)
    default_ipv4, default

# Generated at 2022-06-20 18:28:39.331587
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    module = AnsibleModule(argument_spec=dict())


# Generated at 2022-06-20 18:28:42.117121
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    """Test LinuxNetworkCollector"""
    module = MockModule()
    network = LinuxNetworkCollector(module)
    assert network.module == module
    assert network._platform == 'Linux'
    assert network._fact_class == LinuxNetwork
    assert network.required_facts == set(['distribution', 'platform'])



# Generated at 2022-06-20 18:28:50.967981
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    required_facts = {'distribution': 'Linux', 'platform': 'Linux'}
    platform_facts = get_all_facts(required_facts)
    network_collector = LinuxNetworkCollector(platform_facts)
    assert network_collector.platform == "Linux"
    assert network_collector.fact_class == LinuxNetwork
    assert network_collector.required_facts == set(['distribution', 'platform'])
    assert type(network_collector.fact_class(required_facts)) == LinuxNetwork


# Generated at 2022-06-20 18:28:54.228827
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    module = MagicMock()
    network_collector = LinuxNetworkCollector(module)
    assert network_collector is not None


# Generated at 2022-06-20 18:28:58.378639
# Unit test for method populate of class LinuxNetwork
def test_LinuxNetwork_populate():
    ln = LinuxNetwork()
    ln.populate(dict(
        config={},
        ip_path='/bin/ip',
        default_ipv4={},
        default_ipv6={},
    ))



# Generated at 2022-06-20 18:29:04.701588
# Unit test for method get_default_interfaces of class LinuxNetwork
def test_LinuxNetwork_get_default_interfaces():
    default_ipv4, default_ipv6 = LinuxNetwork().get_default_interfaces(b'testdata/ifconfig.output')
    expected_ipv4 = {'address': '10.55.55.55', 'broadcast': '10.55.55.255', 'netmask': '255.255.255.0', 'network': '10.55.55.0'}
    expected_ipv6 = {'address': 'fe80::250:56ff:fea1:856b', 'prefix': '64', 'scope': 'link'}
    assert default_ipv4 == expected_ipv4
    assert default_ipv6 == expected_ipv6


# Generated at 2022-06-20 18:29:08.099720
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    '''Unit test for constructor of class LinuxNetworkCollector'''
    module = AnsibleModule(argument_spec={})
    network_collector = LinuxNetworkCollector(module)
    assert network_collector.facts == {'ansible_network': {}}

# Generated at 2022-06-20 18:29:20.271637
# Unit test for method get_interfaces_info of class LinuxNetwork
def test_LinuxNetwork_get_interfaces_info():
    # run to get new set of interfaces
    ln = LinuxNetwork()

    rc, interfaces, dummy = ln.get_interfaces_info("/bin/ip", {}, {})
    assert rc

    # check that all keys are present
    # add new keys to this list when adding new keys
    key_list = [
        'all_ipv6_addresses',
        'all_ipv4_addresses',
        'ansible_facts',
        'interfaces'
    ]
    for k in interfaces:
        key_list.remove(k)
    assert not key_list, "Following keys are not present: %s" % key_list

    # verify interfaces
    for i in interfaces['interfaces']:
        # verify that all interfaces are mapped to keys

        assert i in interfaces['interfaces']
        d = interfaces

# Generated at 2022-06-20 18:29:27.622070
# Unit test for constructor of class LinuxNetworkCollector
def test_LinuxNetworkCollector():
    facts = dict(
        distribution=dict(id='debian', name='Debian'),
        platform='Linux',
        # NOTE: this is to make tests independent of the fact platform and platform_version
        lsb=dict(description='Debian GNU/Linux 8.11 (jessie)', id='debian', release='8.11')
    )
    network_collector = LinuxNetworkCollector(module=None, facts=facts)
    # instance of LinuxNetworkCollector
    assert isinstance(network_collector, LinuxNetworkCollector)
    # it derives from NetworkCollector
    assert isinstance(network_collector, NetworkCollector)
    # its _fact_class is LinuxNetwork
    assert network_collector._fact_class == LinuxNetwork
    # its _platform is Linux
    assert network_collector._platform == 'Linux'
    #