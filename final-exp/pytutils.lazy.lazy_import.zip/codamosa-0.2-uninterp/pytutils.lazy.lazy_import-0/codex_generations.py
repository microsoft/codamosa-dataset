

# Generated at 2022-06-18 04:03:56.265587
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False
    try:
        import bzrlib.tests.blackbox
        bzrlib.tests.blackbox.__dict__['ScopeReplacer'] = bzrlib.lazy_import.ScopeReplacer
        import bzrlib.tests.blackbox.test_lazy_import
        bzrlib.tests.blackbox.test_lazy_import.test_ScopeReplacer___setattr__()
    finally:
        bzrlib.lazy_import.ScopeReplacer._should_proxy = True


# Generated at 2022-06-18 04:04:07.840605
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __init__(self, *args, **kwargs):
                    self.args = args
                    self.kwargs = kwargs
                def __call__(self, *args, **kwargs):
                    return self.args, self.kwargs, args, kwargs
            scope = {}
            def factory(self, scope, name):
                return Foo(1, 2, 3, a=4, b=5, c=6)
            name = 'foo'
            scope[name] = ScopeReplacer(scope, factory, name)

# Generated at 2022-06-18 04:04:18.534915
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer

    class TestScopeReplacer(TestCase):

        def test_getattribute(self):
            # Test that __getattribute__ works as expected.
            scope = {}
            def factory(self, scope, name):
                return 'real_obj'
            lazy_import(scope, '''
            from bzrlib.lazy_import import ScopeReplacer
            ''')
            replacer = ScopeReplacer(scope, factory, 'replacer')
            self.assertEqual('real_obj', replacer.__getattribute__('foo'))
            self.assertEqual('real_obj', replacer.__getattribute__('bar'))

    TestScope

# Generated at 2022-06-18 04:04:20.944469
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:04:24.708494
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:04:28.487315
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:04:31.664920
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    u = e.__unicode__()
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:04:34.647210
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:04:38.814298
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return 'foo'
            name = 'bar'
            obj = ScopeReplacer(scope, factory, name)
            obj.baz = 'quux'
            self.assertEqual('quux', obj.baz)
            self.assertEqual('quux', scope['bar'].baz)
    TestScopeReplacer('test___setattr__').run()

# Generated at 2022-06-18 04:04:42.602316
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:05:01.548633
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    # Test that the callable object is called.
    # This is a bit of a silly test, but it's the best we can do.
    osutils.call_captured_output(lambda: None)
    # Test that the callable object is called with the right arguments.
    # This is a bit of a silly test, but it's the best we can do.
    osutils.call_captured_output(lambda: None, 'foo', 'bar')
    # Test that the callable object is called with the right keyword arguments.

# Generated at 2022-06-18 04:05:11.342773
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Test(TestCase):
        def test_setattr(self):
            class Foo(object):
                def __init__(self):
                    self.x = 1
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            foo = ScopeReplacer(scope, factory, name)
            self.assertEqual(1, foo.x)
            foo.x = 2
            self.assertEqual(2, foo.x)
            self.assertEqual(2, foo._real_obj.x)
    Test().test_setattr()

# Generated at 2022-06-18 04:05:19.179204
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    import bzrlib.tests.test_lazy_import
    ''')
    # Check that calling a ScopeReplacer object works
    # and that the real object is returned.
    obj = bzrlib.tests.test_lazy_import.ScopeReplacer(globals(),
        lambda self, scope, name: self, 'obj')
    assert obj() is obj

# Generated at 2022-06-18 04:05:28.856213
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            scope[name] = ScopeReplacer(scope, factory, name)
            self.assertEqual(((1, 2), {'a': 3}), scope[name](1, 2, a=3))
    TestScopeReplacer('test___call__').run()

    # Unit test for method _resolve of class ScopeReplacer

# Generated at 2022-06-18 04:05:35.605654
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import, ScopeReplacer
    import bzrlib.tests.test_lazy_import
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            scope = {}
            def factory(self, scope, name):
                return bzrlib.tests.test_lazy_import
            name = 'bzrlib.tests.test_lazy_import'
            scope[name] = ScopeReplacer(scope, factory, name)
            self.assertEqual(scope[name].__name__, 'bzrlib.tests.test_lazy_import')

# Generated at 2022-06-18 04:05:40.167465
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:05:43.997808
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg"


# Generated at 2022-06-18 04:05:48.155321
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg"


# Generated at 2022-06-18 04:05:53.169000
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:05:55.628766
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__(self, *args, **kwargs)"""
    # FIXME: implement this test
    pass


# Generated at 2022-06-18 04:06:04.517552
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object."""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:06:16.470783
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    import bzrlib
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    # Test that assigning to a member of a lazy object works
    bzrlib.errors.BzrError.__name__ = 'BzrError'
    # Test that assigning to a member of a lazy object works
    bzrlib.osutils.pathjoin.__name__ = 'pathjoin'
    # Test that assigning to a member of a lazy object works
    bzrlib.branch.Branch.__name__ = 'Branch'
    # Test that assigning to a member of a lazy object

# Generated at 2022-06-18 04:06:27.149798
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should raise an exception when proxying is disabled"""
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests import TestCase
    import bzrlib
    class TestScopeReplacer(TestCase):
        def test_setattr(self):
            ScopeReplacer._should_proxy = False
            lazy_import(globals(), '''
            from bzrlib import (
                errors,
                osutils,
                branch,
                )
            import bzrlib.branch
            ''')
            self.assertRaises(IllegalUseOfScopeReplacer,
                              setattr, errors, 'foo', 'bar')
            self.assertRaises(IllegalUseOfScopeReplacer,
                              setattr, osutils, 'foo', 'bar')
            self

# Generated at 2022-06-18 04:06:37.549036
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__(self, attr, value)"""
    # This test is not run by default, because it is not safe to run
    # in a normal test run. It is only run when the selftest command
    # is run with the --strict option.
    #
    # This test is not safe to run in a normal test run because it
    # disables the proxy mechanism that is normally used to prevent
    # illegal use of lazy objects.
    #
    # This test is not safe to run in a normal test run because it
    # uses the 'exec' statement, which is a security risk.
    #
    # This test is not safe to run in a normal test run because it
    # uses the 'eval' statement, which is a security risk.
    #
    # This test is not safe to run in a normal test run because

# Generated at 2022-06-18 04:06:48.892500
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import bzrlib.lazy_import
    import bzrlib.trace
    bzrlib.lazy_import.lazy_import(globals(), '''
    import bzrlib.trace
    ''')
    bzrlib.trace.set_verbosity(1)
    bzrlib.trace.enable_default_logging()
    bzrlib.trace.mutter('test_ScopeReplacer___getattribute__')
    bzrlib.trace.mutter('test_ScopeReplacer___getattribute__')
    bzrlib.trace.mutter('test_ScopeReplacer___getattribute__')
    bzrlib.trace.mutter('test_ScopeReplacer___getattribute__')

# Generated at 2022-06-18 04:06:52.658316
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    import bzrlib.tests.blackbox
    ''')
    bzrlib.tests.blackbox.test_selftest()



# Generated at 2022-06-18 04:07:00.867256
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            # __setattr__ is called when an attribute assignment is attempted.
            # This method sets the given name to the given value in the
            # instance's dictionary.
            # __setattr__() is also called when an instance is created.
            # This is the reason you see __dict__ being set below.
            # It is only an implementation detail.
            class Foo(object):
                def __init__(self):
                    self.__dict__['bar'] = 'baz'
            foo = Foo()
            self.assertEqual('baz', foo.bar)
            foo.bar = 'qux'
            self

# Generated at 2022-06-18 04:07:10.074005
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            ScopeReplacer._should_proxy = True
            def factory(self, scope, name):
                return 'foo'
            scope = {}
            name = 'bar'
            lazy_import(scope, 'bar = ScopeReplacer(scope, factory, name)')
            self.assertEqual('foo', scope['bar']())
            ScopeReplacer._should_proxy = False
            self.assertRaises(IllegalUseOfScopeReplacer, scope['bar'])
    Test('test_ScopeReplacer___call__').run()



# Generated at 2022-06-18 04:07:20.655132
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            scope[name] = ScopeReplacer(scope, factory, name)
            self.assertEqual(((1, 2), {'a': 'b'}), scope[name](1, 2, a='b'))
    TestScopeReplacer('test___call__').run()

    # Unit test for method __getattribute__ of class ScopeReplacer

# Generated at 2022-06-18 04:07:27.334932
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    import bzrlib
    class TestScopeReplacer(TestCase):
        def test_getattribute(self):
            scope = {}
            def factory(self, scope, name):
                return bzrlib
            replacer = ScopeReplacer(scope, factory, 'bzrlib')
            self.assertEqual(replacer.__getattribute__('__name__'), 'bzrlib')
            self.assertEqual(replacer.__getattribute__('__file__'),
                             bzrlib.__file__)
            self.assertEqual(replacer.__getattribute__('__path__'),
                             bzrlib.__path__)

# Generated at 2022-06-18 04:07:38.789880
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests
    bzrlib.tests.TestCaseWithMemoryTransport.tearDown = lambda self: None
    bzrlib.tests.TestCaseWithMemoryTransport.setUp = lambda self: None
    bzrlib.tests.TestCaseWithMemoryTransport.__init__ = lambda self: None
    bzrlib.tests.TestCaseWithMemoryTransport.run = lambda self, result: None
    bzrlib.tests.TestCaseWithMemoryTransport.__call__ = lambda self, *args, **kwargs: None
    bzrlib.tests.TestCaseWithMemoryTransport.__call__(None)
    bzrlib.tests.TestCaseWithMemoryTransport.__call__(None, None)
    bzrlib.tests.TestCaseWithMemoryTransport.__call__

# Generated at 2022-06-18 04:07:50.124922
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_setattr(self):
            scope = {}
            def factory(self, scope, name):
                return 'foo'
            name = 'bar'
            replacer = ScopeReplacer(scope, factory, name)
            replacer.foo = 'bar'
            self.assertEqual('bar', replacer.foo)
            self.assertRaises(IllegalUseOfScopeReplacer, setattr, replacer,
                              'foo', 'bar')
    TestScopeReplacer('test_setattr').run()

# Generated at 2022-06-18 04:07:52.813368
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object."""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:07:56.941773
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__(self, attr, value)"""
    # TODO: implement this test
    raise NotImplementedError(
        "Test for method __setattr__ of class ScopeReplacer not implemented")

# Generated at 2022-06-18 04:08:06.972792
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    from bzrlib.tests import TestCase
    class TestException(IllegalUseOfScopeReplacer):
        _fmt = "TestException: %(msg)s"
    e = TestException('name', 'msg')
    TestCase().assertEqual('TestException: msg', str(e))
    TestCase().assertEqual('TestException: msg', unicode(e))
    TestCase().assertEqual('TestException(name, msg)', repr(e))
    e = TestException('name', 'msg', 'extra')
    TestCase().assertEqual('TestException: msg: extra', str(e))
    TestCase().assertEqual('TestException: msg: extra', unicode(e))
    TestException._fmt = None

# Generated at 2022-06-18 04:08:12.312436
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__() should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg: extra"

# Generated at 2022-06-18 04:08:20.862669
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__(self, *args, **kwargs)"""
    # TODO: implement this test
    raise NotImplementedError

    # TODO: implement this test
    raise NotImplementedError

    # TODO: implement this test
    raise NotImplementedError

    # TODO: implement this test
    raise NotImplementedError

    # TODO: implement this test
    raise NotImplementedError

    # TODO: implement this test
    raise NotImplementedError

    # TODO: implement this test
    raise NotImplementedError

    # TODO: implement this test
    raise NotImplementedError

    # TODO: implement this test
    raise NotImplementedError

    # TODO: implement this test
    raise NotImplementedError

    # TODO: implement this test
    raise Not

# Generated at 2022-06-18 04:08:25.716041
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:08:29.013931
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)



# Generated at 2022-06-18 04:08:32.563147
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def setUp(self):
            super(TestScopeReplacer, self).setUp()
            self.scope = {}
            self.name = 'test'
            self.obj = object()
            def factory(self, scope, name):
                return self.obj
            self.replacer = ScopeReplacer(self.scope, factory, self.name)
        def test_call(self):
            self.assertEqual(self.replacer(), self.obj)
    TestScopeReplacer('test_call').run()

# Generated at 2022-06-18 04:08:41.543870
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = e.__unicode__()
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:08:52.087109
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should raise an exception if the object has already been
    replaced.
    """
    import sys
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    from bzrlib.lazy_import import ScopeReplacer
    ''')
    # We need to disable proxying for this test
    ScopeReplacer._should_proxy = False
    try:
        # Create a ScopeReplacer object
        scope = {}
        name = 'foo'
        def factory(self, scope, name):
            return 'bar'
        scope_replacer = ScopeReplacer(scope, factory, name)
        # Now try to set an attribute on it
        scope_replacer.attr = 'baz'
    except IllegalUseOfScopeReplacer:
        pass

# Generated at 2022-06-18 04:09:02.429072
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            import bzrlib.lazy_import
            bzrlib.lazy_import.ScopeReplacer.__call__(None)
    Test('test_ScopeReplacer___call__').run()

    def __getitem__(self, key):
        obj = object.__getattribute__(self, '_resolve')()
        return obj[key]

    def __setitem__(self, key, value):
        obj = object.__getattribute__(self, '_resolve')()
        return obj.__setitem__(key, value)

    def __delitem__(self, key):
        obj = object.__getattribute__(self, '_resolve')()


# Generated at 2022-06-18 04:09:07.726766
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should set the attribute on the real object"""
    class Foo(object):
        pass
    scope = {}
    def factory(self, scope, name):
        return Foo()
    replacer = ScopeReplacer(scope, factory, 'foo')
    replacer.bar = 'baz'
    assert scope['foo'].bar == 'baz'

# Generated at 2022-06-18 04:09:11.145705
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:09:16.537796
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    # Test that a ScopeReplacer can be called.
    # This is a regression test for bug #238870
    try:
        osutils.pathjoin('a', 'b')
    except AttributeError:
        raise AssertionError("ScopeReplacer cannot be called")


# Generated at 2022-06-18 04:09:25.010394
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self, value):
            self.value = value
        def __getattribute__(self, attr):
            if attr == 'value':
                return object.__getattribute__(self, attr)
            else:
                return attr
    class TestCase(TestCase):
        def test_getattribute(self):
            scope = {}
            def factory(self, scope, name):
                return TestObj(name)
            ScopeReplacer(scope, factory, 'test')
            self.assertEqual('test', scope['test'].value)
            self.assertEqual('value', scope['test'].value)

# Generated at 2022-06-18 04:09:29.134497
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:09:38.316577
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            class Foo(object):
                def __init__(self, a, b):
                    self.a = a
                    self.b = b
                def __call__(self, c, d):
                    return self.a + self.b + c + d
            scope = {}
            def factory(self, scope, name):
                return Foo(1, 2)
            replacer = ScopeReplacer(scope, factory, 'foo')
            self.assertEqual(6, replacer(3, 4))
            self.assertEqual(Foo(1, 2), scope['foo'])
    TestScopeReplacer('test___call__').run()


# Generated at 2022-06-18 04:09:41.752961
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'foo was used incorrectly: bar'


# Generated at 2022-06-18 04:10:03.028818
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False

# Generated at 2022-06-18 04:10:05.650196
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:10:17.642812
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib import lazy_import
    import sys
    import bzrlib
    lazy_import.lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    # Test that the object is replaced in the scope
    assert 'errors' in sys.modules
    assert 'osutils' in sys.modules
    assert 'branch' in sys.modules
    assert 'bzrlib' in sys.modules
    # Test that the object is replaced in the scope
    assert sys.modules['errors'] is errors
    assert sys.modules['osutils'] is osutils
    assert sys.modules['branch'] is branch
    assert sys.modules['bzrlib'] is bzr

# Generated at 2022-06-18 04:10:25.846422
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_setattr(self):
            class Foo(object):
                def __init__(self):
                    self.bar = None
            scope = {}
            def factory(self, scope, name):
                return Foo()
            replacer = ScopeReplacer(scope, factory, 'foo')
            replacer.bar = 'baz'
            self.assertEqual('baz', scope['foo'].bar)
    TestScopeReplacer('test_setattr').run()

# Generated at 2022-06-18 04:10:28.501867
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:10:33.710396
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = True
    # Test that the method __getattribute__ of class ScopeReplacer
    # returns the attribute '_resolve' of the object self.
    def _factory(self, scope, name):
        return self
    scope = sys._getframe(0).f_locals
    name = 'name'
    obj = bzrlib.lazy_import.ScopeReplacer(scope, _factory, name)
    assert obj._resolve == obj.__getattribute__('_resolve')
    # Test that the method __getattribute__ of class ScopeReplacer
    # returns the attribute '_resolve' of the object self.

# Generated at 2022-06-18 04:10:37.654958
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:10:42.206276
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:10:52.434579
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Foo(object):
        def __init__(self):
            self.a = 1
    class Bar(object):
        def __init__(self):
            self.b = 2
    class TestScopeReplacer(TestCase):
        def test_setattr(self):
            scope = {}
            def factory(self, scope, name):
                return Foo()
            ScopeReplacer(scope, factory, 'foo')
            self.assertEqual(1, scope['foo'].a)
            scope['foo'].a = 2
            self.assertEqual(2, scope['foo'].a)
            def factory(self, scope, name):
                return Bar()

# Generated at 2022-06-18 04:11:02.970635
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __init__(self, *args, **kwargs):
                    self.args = args
                    self.kwargs = kwargs
                def __call__(self, *args, **kwargs):
                    self.args = args
                    self.kwargs = kwargs
                    return self
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            scope[name] = ScopeReplacer(scope, factory, name)
            foo = scope[name]

# Generated at 2022-06-18 04:11:35.425874
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            class TestClass(object):
                def __init__(self):
                    self.test_attr = None
            scope = {}
            def factory(self, scope, name):
                return TestClass()
            name = 'test_name'
            test_obj = ScopeReplacer(scope, factory, name)
            test_obj.test_attr = 'test_value'
            self.assertEqual('test_value', test_obj.test_attr)
            self.assertEqual('test_value', scope[name].test_attr)
    TestScopeReplacer('test_ScopeReplacer___setattr__').run

# Generated at 2022-06-18 04:11:39.911500
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__(self, *args, **kwargs)"""
    # This is a stub implementation of ScopeReplacer.__call__
    # It may not do what you want, but at least it should typecheck.
    return ScopeReplacer.__call__(self, *args, **kwargs)


# Generated at 2022-06-18 04:11:43.521967
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:11:47.902890
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)
    assert s == 'ScopeReplacer object \'name\' was used incorrectly: msg: extra'

# Generated at 2022-06-18 04:11:51.995347
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:11:55.581141
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:12:07.476879
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import types
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False
    scope = sys._getframe(1).f_globals
    name = 'test_ScopeReplacer___getattribute__'
    scope[name] = bzrlib.lazy_import.ScopeReplacer(scope, lambda s, sc, n: n, name)

# Generated at 2022-06-18 04:12:09.702349
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:12:19.750137
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = True
    class Foo(object):
        def __init__(self, x):
            self.x = x
        def bar(self):
            return self.x
    scope = {}
    def factory(self, scope, name):
        return Foo(name)
    sr = bzrlib.lazy_import.ScopeReplacer(scope, factory, 'foo')
    assert sr.x == 'foo'
    assert sr.bar() == 'foo'
    assert scope['foo'].x == 'foo'
    assert scope['foo'].bar() == 'foo'
    assert sr.x == 'foo'
    assert sr.bar() == 'foo'
    # Test that the object is replaced in the scope

# Generated at 2022-06-18 04:12:23.134484
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s == 'name: msg'

# Generated at 2022-06-18 04:12:50.680113
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:12:54.866639
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s == 'name: msg'

# Generated at 2022-06-18 04:13:01.285808
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert str(e) == "ScopeReplacer object 'name' was used incorrectly: msg: extra"
    assert unicode(e) == u"ScopeReplacer object 'name' was used incorrectly: msg: extra"
    assert repr(e) == "IllegalUseOfScopeReplacer('ScopeReplacer object \'name\' was used incorrectly: msg: extra')"



# Generated at 2022-06-18 04:13:09.255582
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            class TestClass(object):
                def __init__(self):
                    self.attr = None
            scope = {}
            def factory(self, scope, name):
                return TestClass()
            name = 'test'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.attr = 'value'
            self.assertEqual('value', scope_replacer.attr)
            self.assertEqual('value', scope[name].attr)
    TestScopeReplacer('test_ScopeReplacer___setattr__').run()

# Generated at 2022-06-18 04:13:12.073525
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:13:18.348571
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return self
            name = 'name'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.attr = 'value'
            self.assertEqual('value', scope_replacer.attr)
    TestScopeReplacer('test___setattr__').run()