

# Generated at 2022-06-18 04:04:12.540250
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return 'real_obj'
            name = 'name'
            obj = ScopeReplacer(scope, factory, name)
            obj.attr = 'value'
            self.assertEqual('value', obj.attr)
            self.assertEqual('value', scope[name].attr)
    TestScopeReplacer('test___setattr__').run()

# Generated at 2022-06-18 04:04:23.675828
# Unit test for method __getattribute__ of class ScopeReplacer

# Generated at 2022-06-18 04:04:27.379385
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:04:30.246602
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:04:37.148849
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Foo(object):
        def __init__(self, value):
            self.value = value
        def get_value(self):
            return self.value
    class Test(TestCase):
        def test_get_value(self):
            scope = {}
            def factory(self, scope, name):
                return Foo(42)
            scope_replacer = ScopeReplacer(scope, factory, 'foo')
            self.assertEqual(42, scope_replacer.get_value())
    Test('test_get_value').run()

# Generated at 2022-06-18 04:04:46.900955
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # __call__(self, *args, **kwargs)
    # Calling a ScopeReplacer should call the real object
    class Foo(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
    scope = {}
    def factory(self, scope, name):
        return Foo()
    replacer = ScopeReplacer(scope, factory, 'foo')
    assert scope['foo'] is replacer
    assert replacer.args == ()
    assert replacer.kwargs == {}
    replacer(1, 2, 3, a=4, b=5)
    assert replacer.args == (1, 2, 3)
    assert replacer.kwargs == {'a': 4, 'b': 5}

# Generated at 2022-06-18 04:04:57.377165
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            class Foo(object):
                def __init__(self):
                    self.bar = None
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            foo = ScopeReplacer(scope, factory, name)
            foo.bar = 'baz'
            self.assertEqual('baz', foo.bar)
            self.assertEqual('baz', scope[name].bar)
    TestScopeReplacer('test_ScopeReplacer___setattr__').run()

# Generated at 2022-06-18 04:05:08.602563
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            scope = {}
            def factory(self, scope, name):
                return Foo()
            scope_replacer = ScopeReplacer(scope, factory, 'foo')
            self.assertEqual(((), {}), scope_replacer(1, 2, 3))
            self.assertEqual(((1, 2, 3), {}), scope_replacer(1, 2, 3))

# Generated at 2022-06-18 04:05:11.761903
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:05:15.594953
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:05:41.431666
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:05:50.869555
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            lazy_import(scope, '''
            from bzrlib import (
                errors,
                osutils,
                branch,
                )
            import bzrlib.branch
            ''')
            self.assertEqual(scope['errors'].__class__, ScopeReplacer)
            self.assertEqual(scope['osutils'].__class__, ScopeReplacer)
            self.assertEqual(scope['branch'].__class__, ScopeReplacer)
            self.assertEqual(scope['bzrlib'].__class__, ScopeReplacer)
           

# Generated at 2022-06-18 04:06:01.929924
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should raise an exception if the object has already been
    replaced.
    """
    scope = {}
    def factory(self, scope, name):
        return object()
    name = 'name'
    replacer = ScopeReplacer(scope, factory, name)
    # The first time we set an attribute, it should work
    replacer.foo = 'bar'
    # But the second time, it should raise an exception
    e = raises(IllegalUseOfScopeReplacer, setattr, replacer, 'foo', 'bar')
    # And the exception should have a useful message
    assert e.msg == "Object already replaced, did you assign it to another variable?"
    # And the exception should have a useful name
    assert e.name == 'name'
    # And the exception should have a useful extra message
    assert e.extra

# Generated at 2022-06-18 04:06:05.857210
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class TestClass(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            test_obj = TestClass()
            scope = {}
            def factory(self, scope, name):
                return test_obj
            replacer = ScopeReplacer(scope, factory, 'test_obj')
            self.assertEqual(((1, 2), {'a': 'b'}), replacer(1, 2, a='b'))
    TestScopeReplacer('test___call__').run()

# Generated at 2022-06-18 04:06:17.275528
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import, ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            def factory(self, scope, name):
                return lambda *args, **kwargs: (args, kwargs)
            scope = {}
            name = 'foo'
            obj = ScopeReplacer(scope, factory, name)
            self.assertEqual(((), {}), obj())
            self.assertEqual(((1,), {}), obj(1))
            self.assertEqual(((1, 2), {}), obj(1, 2))
            self.assertEqual(((1, 2), {'a': 3}), obj(1, 2, a=3))

# Generated at 2022-06-18 04:06:27.607071
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            import bzrlib.lazy_import
            import bzrlib.tests.blackbox.test_selftest
            bzrlib.lazy_import.ScopeReplacer._should_proxy = True
            try:
                bzrlib.tests.blackbox.test_selftest.test_suite()
            except bzrlib.lazy_import.IllegalUseOfScopeReplacer:
                self.fail('ScopeReplacer._should_proxy should be True')
            bzrlib.lazy_import.ScopeReplacer._should_proxy = False

# Generated at 2022-06-18 04:06:38.125012
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy

# Generated at 2022-06-18 04:06:44.147793
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should set the attribute on the real object"""
    class Foo(object):
        def __init__(self):
            self.bar = None
    scope = {}
    def factory(self, scope, name):
        return Foo()
    replacer = ScopeReplacer(scope, factory, 'foo')
    replacer.bar = 'baz'
    assert scope['foo'].bar == 'baz'

# Generated at 2022-06-18 04:06:48.328667
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:06:54.926809
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_setattr(self):
            scope = {}
            def factory(self, scope, name):
                return 'foo'
            obj = ScopeReplacer(scope, factory, 'name')
            obj.attr = 'value'
            self.assertEqual('value', obj.attr)
            self.assertEqual('value', scope['name'].attr)
    TestScopeReplacer('test_setattr').run()

# Generated at 2022-06-18 04:07:07.962455
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:07:19.943778
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            import bzrlib.lazy_import
            import bzrlib.tests.test_lazy_import
            bzrlib.lazy_import.lazy_import(globals(), '''
            from bzrlib.lazy_import import ScopeReplacer
            ''')
            def factory(self, scope, name):
                return bzrlib.tests.test_lazy_import.test_ScopeReplacer___call__
            scope = {}
            name = 'test'
            obj = ScopeReplacer(scope, factory, name)

# Generated at 2022-06-18 04:07:26.921685
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    import bzrlib.tests.test_lazy_import
    ''')
    # Test that the method __call__ of class ScopeReplacer
    # calls the method __call__ of the real object.
    # Create a ScopeReplacer object.
    scope = {}
    name = 'test'
    scope[name] = bzrlib.tests.test_lazy_import.TestClass()
    factory = lambda self, scope, name: scope[name]
    scope_replacer = bzrlib.lazy_import.ScopeReplacer(scope, factory, name)
    # Call the method __call__ of the ScopeReplacer object.
    scope_replacer()
    # Check

# Generated at 2022-06-18 04:07:31.926374
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:07:41.649670
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            scope[name] = ScopeReplacer(scope, factory, name)
            self.assertEqual(((1, 2), {'a': 'b'}), scope[name](1, 2, a='b'))
    TestScopeReplacer('test_ScopeReplacer___call__').test_ScopeReplacer___call__()

    # Unit test for method __get

# Generated at 2022-06-18 04:07:52.868560
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    # This test is not run by default, because it is not a unit test for
    # bzrlib.
    # It is a unit test for the bzrlib.lazy_import module.
    # It is run by the test_lazy_import.py test suite.
    #
    # This test is not run by default, because it is not a unit test for
    # bzrlib.
    # It is a unit test for the bzrlib.lazy_import module.
    # It is run by the test_lazy_import.py test suite.
    #
    # This test is not run by default, because it is not a unit test for
    # bzrlib.
    # It is a unit test for the bzrlib

# Generated at 2022-06-18 04:08:01.103405
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False
    try:
        scope = {}
        bzrlib.lazy_import.ScopeReplacer(scope, lambda x, y, z: x, 'x')
        scope['x'].__setattr__('_real_obj', 1)
        scope['x'].__setattr__('_real_obj', 2)
    finally:
        bzrlib.lazy_import.ScopeReplacer._should_proxy = True



# Generated at 2022-06-18 04:08:04.050287
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:08:06.856975
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:08:18.188069
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = True
    class Foo(object):
        def __init__(self, name):
            self.name = name
        def __getattribute__(self, attr):
            return object.__getattribute__(self, attr)
        def __setattr__(self, attr, value):
            return object.__setattr__(self, attr, value)
        def __call__(self, *args, **kwargs):
            return self.name
    scope = {}
    def factory(self, scope, name):
        return Foo(name)
    name = 'foo'
    obj = bzrlib.lazy_import.ScopeReplacer(scope, factory, name)
    assert obj.name

# Generated at 2022-06-18 04:08:36.554272
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    # This test is here because the method is defined in this file.
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg: extra"
    # Now test with a unicode string
    e = IllegalUseOfScopeReplacer(u'name', u'msg', u'extra')
    s = str(e)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg: extra"
    # Now test with a unicode string that cannot be encoded
    e = IllegalUseOfScopeReplacer(u'name', u'msg', u'\xe9xtra')
    s = str(e)

# Generated at 2022-06-18 04:08:37.922029
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:08:42.142796
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:08:46.087676
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    import bzrlib.tests
    ''')
    bzrlib.tests.TestCase.run_tests(globals())



# Generated at 2022-06-18 04:08:57.077372
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()

    This method is used by the unicode() builtin function and by the
    '%s' operator.  This means that it should always return a unicode
    object.
    """
    # This test is not a doctest because it needs to test the
    # __unicode__() method, not the __str__() method.
    e = IllegalUseOfScopeReplacer('name', 'msg')
    # The __unicode__() method should return a unicode object.
    u = unicode(e)
    # The __unicode__() method should return a unicode object.
    u = e.__unicode__()
    # The __unicode__() method should return a unicode object.
    u = e.__str__()
    # The __unicode__() method

# Generated at 2022-06-18 04:09:01.584186
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self):
            self.attr = None
    class TestCase(TestCase):
        def test_set_attr(self):
            scope = {}
            name = 'test'
            def factory(self, scope, name):
                return TestObj()
            replacer = ScopeReplacer(scope, factory, name)
            replacer.attr = 'value'
            self.assertEqual('value', scope[name].attr)
    TestCase.run_tests()

# Generated at 2022-06-18 04:09:12.176076
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    import bzrlib.tests
    import bzrlib.tests.blackbox
    import bzrlib.tests.blackbox.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest.test_selftest.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest.test_selftest.test_selftest.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSel

# Generated at 2022-06-18 04:09:22.503235
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___getattribute__(self):
            import sys
            def factory(self, scope, name):
                return 'foo'
            scope = sys._getframe(1).f_locals
            name = 'foo'
            obj = ScopeReplacer(scope, factory, name)
            self.assertEqual('foo', obj.__getattribute__('__name__'))
            self.assertEqual('foo', obj.__getattribute__('__class__'))
            self.assertEqual('foo', obj.__getattribute__('__module__'))
            self.assertEqual('foo', obj.__getattribute__('__doc__'))

# Generated at 2022-06-18 04:09:27.420141
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            def factory(self, scope, name):
                return lambda x: x
            scope = {}
            name = 'foo'
            obj = ScopeReplacer(scope, factory, name)
            self.assertEqual(obj(1), 1)
            self.assertEqual(obj('a'), 'a')
            self.assertEqual(obj(None), None)
    test_ScopeReplacer___call__ = TestScopeReplacer('test___call__').test___call__

# Generated at 2022-06-18 04:09:31.077689
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'name was used incorrectly: msg'


# Generated at 2022-06-18 04:09:47.983984
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class TestClass(object):
        def __init__(self, value):
            self.value = value
    def factory(self, scope, name):
        return TestClass(name)
    scope = {}
    name = 'test'
    replacer = ScopeReplacer(scope, factory, name)
    assert replacer.value == name
    assert scope[name].value == name

# Generated at 2022-06-18 04:09:50.488947
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:09:52.747180
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__() should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:09:55.407840
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """__getattribute__(self, attr)"""
    # __getattribute__(self, attr)
    # Implementation details
    pass

# Generated at 2022-06-18 04:09:59.575626
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:10:06.612581
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    import sys
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            def factory(self, scope, name):
                return lambda: 'foo'
            scope = {}
            name = 'foo'
            scope_replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual('foo', scope_replacer())

    # Run the test suite
    from bzrlib.tests import test_suite
    return test_suite()


# Generated at 2022-06-18 04:10:10.942366
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:10:22.022990
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests
    import bzrlib.lazy_import
    import bzrlib.tests.blackbox
    import bzrlib.tests.blackbox.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSelfTest
    import bzrlib.tests.blackbox.test_selftest.TestSelfTest.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSelfTest.test_selftest.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSelfTest.test_selftest.test_selftest.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSelfTest.test_

# Generated at 2022-06-18 04:10:30.790324
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__()"""
    # This test is here because it is a unit test for a method of a class
    # that is not defined in this module.
    # This test is also here because it is a unit test for a method of a class
    # that is not defined in the same module as the test.
    # This test is also here because it is a unit test for a method of a class
    # that is not defined in the same module as the test.
    # This test is also here because it is a unit test for a method of a class
    # that is not defined in the same module as the test.
    # This test is also here because it is a unit test for a method of a class
    # that is not defined in the same module as the test.
    # This test is also here because it is a unit test

# Generated at 2022-06-18 04:10:34.050439
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'name was used incorrectly: msg'


# Generated at 2022-06-18 04:11:34.576561
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg: extra"

# Generated at 2022-06-18 04:11:38.386358
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert isinstance(s, unicode)

# Generated at 2022-06-18 04:11:41.795309
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__() should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:11:44.648219
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:11:53.719584
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            scope = {}
            def factory(self, scope, name):
                return lambda: 'foo'
            name = 'foo'
            lazy_import(scope, 'foo = bzrlib.lazy_import.ScopeReplacer(scope, factory, name)')
            self.assertEqual('foo', scope['foo']())
    TestScopeReplacer('test___call__').run()

# Generated at 2022-06-18 04:11:59.000599
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert str(e) == 'name: msg: extra'
    assert repr(e) == "IllegalUseOfScopeReplacer('name', 'msg', 'extra')"
    e = IllegalUseOfScopeReplacer('name', 'msg')
    assert str(e) == 'name: msg'
    assert repr(e) == "IllegalUseOfScopeReplacer('name', 'msg')"



# Generated at 2022-06-18 04:12:03.185211
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:12:09.927966
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer

    class TestScopeReplacer(TestCase):

        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return object()
            name = 'name'
            obj = ScopeReplacer(scope, factory, name)
            self.assertRaises(IllegalUseOfScopeReplacer,
                              obj.__setattr__, 'attr', 'value')

# Generated at 2022-06-18 04:12:15.763227
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = e.__unicode__()
    assert isinstance(u, unicode)
    assert u == u'ScopeReplacer object \'name\' was used incorrectly: msg: extra'

# Generated at 2022-06-18 04:12:18.141646
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:13:16.464620
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___getattribute__(self):
            import sys
            class TestClass(object):
                def __init__(self, name):
                    self.name = name
                def __getattribute__(self, attr):
                    if attr == 'name':
                        return object.__getattribute__(self, attr)
                    raise AttributeError(attr)
            def factory(self, scope, name):
                return TestClass(name)
            scope = {}
            name = 'test_name'
            scope_replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual(scope_replacer.name, name)

# Generated at 2022-06-18 04:13:18.992397
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert isinstance(s, unicode)
