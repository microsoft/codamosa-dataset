

# Generated at 2022-06-18 04:03:53.269223
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:03:56.636181
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'name was used incorrectly: msg'

# Generated at 2022-06-18 04:04:01.706902
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'ScopeReplacer object \'name\' was used incorrectly: msg: extra'

# Generated at 2022-06-18 04:04:12.732613
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class TestClass(object):
                def __init__(self, *args, **kwargs):
                    self.args = args
                    self.kwargs = kwargs
                def __call__(self, *args, **kwargs):
                    return self.args, self.kwargs, args, kwargs
            scope = {}
            def factory(self, scope, name):
                return TestClass
            name = 'test'
            scope[name] = ScopeReplacer(scope, factory, name)

# Generated at 2022-06-18 04:04:16.564340
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:04:19.415062
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:04:23.254113
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:04:31.953290
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return args, kwargs
            scope = {}
            def factory(self, scope, name):
                return Foo()
            scope_replacer = ScopeReplacer(scope, factory, 'foo')
            self.assertEqual(((), {}), scope_replacer(1, 2, 3, a=4, b=5))
    TestScopeReplacer('test___call__').run()

# Generated at 2022-06-18 04:04:38.509934
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___call__(self):
            import sys
            import bzrlib
            def factory(self, scope, name):
                return bzrlib
            scope = sys.modules
            name = 'bzrlib'
            obj = ScopeReplacer(scope, factory, name)
            self.assertEqual(obj, bzrlib)
            self.assertEqual(obj.__name__, 'bzrlib')
            self.assertEqual(obj.__file__, bzrlib.__file__)
    TestScopeReplacer('test_ScopeReplacer___call__').run()

# Generated at 2022-06-18 04:04:42.062305
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:05:00.395810
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class Foo(object):
        def __init__(self, x):
            self.x = x
    def factory(self, scope, name):
        return Foo(42)
    scope = {}
    name = 'foo'
    foo = ScopeReplacer(scope, factory, name)
    assert foo.x == 42
    assert foo.x == 42
    assert foo.x == 42
    assert foo._resolve().x == 42
    assert foo._resolve().x == 42
    assert foo._resolve().x == 42
    assert foo._resolve().x == 42
    assert foo._resolve().x == 42
    assert foo._resolve().x == 42
    assert foo._resolve().x == 42
    assert foo._resolve().x == 42
    assert foo._resolve().x == 42

# Generated at 2022-06-18 04:05:03.498186
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:05:14.706348
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return args, kwargs
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            scope[name] = ScopeReplacer(scope, factory, name)
            self.assertEqual(((), {}), scope[name]())
            self.assertEqual(((1, 2, 3), {'a': 'b', 'c': 'd'}),
                             scope[name](1, 2, 3, a='b', c='d'))
    Test

# Generated at 2022-06-18 04:05:23.347612
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # __call__(self, *args, **kwargs)
    # Calling a ScopeReplacer should call the real object
    class Foo(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
        def __call__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs
    scope = {}
    def factory(self, scope, name):
        return Foo()
    sr = ScopeReplacer(scope, factory, 'foo')
    sr(1, 2, 3, a=4, b=5, c=6)
    assert scope['foo'].args == (1, 2, 3)

# Generated at 2022-06-18 04:05:32.910267
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    import bzrlib
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False
    bzrlib.lazy_import.ScopeReplacer(sys.modules[__name__].__dict__,
                                     lambda self, scope, name: None,
                                     'test_ScopeReplacer___setattr__')

# Generated at 2022-06-18 04:05:36.146380
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert isinstance(s, unicode)


# Generated at 2022-06-18 04:05:39.874094
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:05:43.019258
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:05:48.911601
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert isinstance(s, unicode)
    e = IllegalUseOfScopeReplacer('name', 'msg', extra='extra')
    s = str(e)
    assert isinstance(s, str)
    assert isinstance(s, unicode)


# Generated at 2022-06-18 04:05:59.041621
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self):
            self.attr = 'attr'
    class TestScopeReplacer(TestCase):
        def test_setattr(self):
            obj = TestObj()
            scope = {'obj': obj}
            def factory(self, scope, name):
                return scope[name]
            replacer = ScopeReplacer(scope, factory, 'obj')
            replacer.attr = 'new_attr'
            self.assertEqual('new_attr', obj.attr)
    TestScopeReplacer('test_setattr').run()

# Generated at 2022-06-18 04:06:28.202698
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_lazy_import import TestScopeReplacer
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    class Test(TestCase):
        def test_setattr(self):
            scope = {}
            def factory(self, scope, name):
                return TestScopeReplacer()
            scope_replacer = ScopeReplacer(scope, factory, 'name')
            scope_replacer.attr = 'value'
            self.assertEqual('value', scope_replacer.attr)
            self.assertEqual('value', scope['name'].attr)

# Generated at 2022-06-18 04:06:36.937185
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self):
            self.foo = 'bar'
    class TestCase(TestCase):
        def test_getattr(self):
            scope = {}
            def factory(self, scope, name):
                return TestObj()
            replacer = ScopeReplacer(scope, factory, 'test')
            self.assertEqual('bar', replacer.foo)
            self.assertEqual('bar', scope['test'].foo)

# Generated at 2022-06-18 04:06:40.871811
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:06:50.045023
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Test(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return object()
            name = 'foo'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.bar = 'baz'
            self.assertEqual('baz', scope_replacer.bar)
            self.assertEqual('baz', scope[name].bar)
    Test('test_ScopeReplacer___setattr__').run()

# Generated at 2022-06-18 04:06:52.330485
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg: extra"

# Generated at 2022-06-18 04:06:58.434015
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___call__(self):
            scope = {}
            def factory(self, scope, name):
                return 'foo'
            name = 'bar'
            x = ScopeReplacer(scope, factory, name)
            self.assertEqual('foo', x())
    # test_ScopeReplacer___call__()



# Generated at 2022-06-18 04:07:01.836881
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:07:09.583721
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Test(TestCase):
        def test_setattr(self):
            class Foo(object):
                def __init__(self):
                    self.bar = None
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            replacer = ScopeReplacer(scope, factory, name)
            replacer.bar = 'baz'
            self.assertEqual('baz', scope[name].bar)
    Test().test_setattr()

# Generated at 2022-06-18 04:07:13.359917
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:07:16.228508
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:07:33.817296
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_

# Generated at 2022-06-18 04:07:37.530931
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg"

# Generated at 2022-06-18 04:07:40.733826
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:07:51.915179
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    import bzrlib.tests
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import.ScopeReplacer
    import bzrlib.tests.test_lazy_import.ScopeReplacer
    import bzrlib.tests.test_lazy_import.ScopeReplacer
    import bzrlib.tests.test_lazy_import.ScopeReplacer
    import bzrlib.tests.test_lazy_import.ScopeReplacer
    import bzrlib.tests.test_lazy_import.ScopeReplacer
    import bzrlib.tests.test_lazy_import.ScopeReplacer
    import bzrlib.tests.test_lazy_import.ScopeReplacer

# Generated at 2022-06-18 04:08:02.963078
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            from bzrlib.lazy_import import lazy_import
            from bzrlib.lazy_import import ScopeReplacer
            from bzrlib.lazy_import import IllegalUseOfScopeReplacer
            def factory(self, scope, name):
                return lambda: 'foo'
            scope = {}
            name = 'test'
            lazy_import(scope, '''
            test = ScopeReplacer(scope, factory, name)
            ''')
            self.assertEqual('foo', scope[name]())
            self.assertRaises(IllegalUseOfScopeReplacer,
                              scope[name].__call__)
            ScopeReplacer._should_proxy = False
           

# Generated at 2022-06-18 04:08:05.247989
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:08:08.752222
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:08:19.309310
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    import bzrlib.tests
    ''')
    # test_ScopeReplacer___call__()
    # test_ScopeReplacer___call__()
    # test_ScopeReplacer___call__()
    # test_ScopeReplacer___call__()
    # test_ScopeReplacer___call__()
    # test_ScopeReplacer___call__()
    # test_ScopeReplacer___call__()
    # test_ScopeReplacer___call__()
    # test_ScopeReplacer___call__()
    # test_ScopeReplacer___call__()
    # test_ScopeReplacer___call__()
    # test_ScopeReplacer___call__()
    # test_ScopeRepl

# Generated at 2022-06-18 04:08:23.555690
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:08:27.603482
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:08:43.220682
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            class Foo(object):
                def __init__(self, value):
                    self.value = value
            scope = {}
            def factory(self, scope, name):
                return Foo(name)
            name = 'foo'
            replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual(replacer.value, 'foo')
            replacer.value = 'bar'
            self.assertEqual(replacer.value, 'bar')
            self.assertEqual(scope[name].value, 'bar')

# Generated at 2022-06-18 04:08:47.907446
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()

    IllegalUseOfScopeReplacer.__unicode__() should return a unicode object.
    """
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:08:52.067628
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:09:02.431391
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should raise an exception if the object has already been
    replaced.
    """
    class Foo(object):
        pass
    scope = {}
    def factory(self, scope, name):
        return Foo()
    name = 'foo'
    replacer = ScopeReplacer(scope, factory, name)
    replacer.bar = 'baz'
    ScopeReplacer._should_proxy = False
    try:
        replacer.bar = 'baz'
    except IllegalUseOfScopeReplacer as e:
        assert e.name == name
        assert e.msg == "Object already replaced, did you assign it to another variable?"
    else:
        raise AssertionError("Expected IllegalUseOfScopeReplacer")
    finally:
        ScopeReplacer._should_proxy = True



# Generated at 2022-06-18 04:09:11.595484
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test___setattr__(self):
            class Foo(object):
                def __init__(self, value):
                    self.value = value
            def factory(self, scope, name):
                return Foo(self)
            scope = {}
            name = 'foo'
            foo = ScopeReplacer(scope, factory, name)
            foo.value = 'bar'
            self.assertEqual('bar', foo.value)
    TestScopeReplacer('test___setattr__').run()

# Generated at 2022-06-18 04:09:15.793374
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:09:24.761973
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    import bzrlib.errors
    import bzrlib.trace
    import bzrlib.tests
    import bzrlib.tests.blackbox
    import bzrlib.tests.blackbox.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSelfTest
    import bzrlib.tests.blackbox.test_selftest.TestSelfTest.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSelfTest.test_selftest.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSelfTest.test_selftest.test_selftest.test_selftest
    import bzrlib

# Generated at 2022-06-18 04:09:29.205161
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:09:31.358588
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:09:41.593939
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    bzrlib.lazy_import._should_proxy = False

# Generated at 2022-06-18 04:10:03.261102
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    import sys
    def factory(self, scope, name):
        return 'real_obj'
    scope = {}
    name = 'name'
    scope_replacer = ScopeReplacer(scope, factory, name)
    scope_replacer._should_proxy = False
    scope_replacer._real_obj = 'real_obj'
    scope['name'] = scope_replacer

# Generated at 2022-06-18 04:10:14.317797
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should raise an exception if proxying is disabled"""
    import bzrlib.tests
    bzrlib.tests.disable_proxying()

# Generated at 2022-06-18 04:10:17.951929
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:10:27.946675
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Test(TestCase):
        def test_ScopeReplacer___setattr__(self):
            class Foo(object):
                pass
            foo = Foo()
            foo.bar = 1
            foo.baz = 2
            foo.qux = 3
            foo.quux = 4
            foo.corge = 5
            foo.grault = 6
            foo.garply = 7
            foo.waldo = 8
            foo.fred = 9
            foo.plugh = 10
            foo.xyzzy = 11
            foo.thud = 12
            foo.spam = 13
            foo.eggs = 14
            foo.ham = 15
            foo.sausage = 16
            foo.beans = 17

# Generated at 2022-06-18 04:10:30.182092
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:10:39.874652
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return args, kwargs
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            scope[name] = ScopeReplacer(scope, factory, name)
            self.assertEqual(((1, 2), {'a': 1}), scope[name](1, 2, a=1))
    TestScopeReplacer('test___call__').run()

    # Unit test for method __getattribute__ of class ScopeReplacer

# Generated at 2022-06-18 04:10:44.828990
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:10:55.121806
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class TestClass(object):
                def __init__(self, *args, **kwargs):
                    self.args = args
                    self.kwargs = kwargs
                def __call__(self, *args, **kwargs):
                    self.args = args
                    self.kwargs = kwargs
            test_obj = TestClass()
            scope = {}
            name = 'test_obj'
            scope[name] = test_obj
            def factory(self, scope, name):
                return scope[name]
            obj = ScopeReplacer(scope, factory, name)

# Generated at 2022-06-18 04:10:59.829915
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'ScopeReplacer object \'name\' was used incorrectly: msg: extra'

# Generated at 2022-06-18 04:11:08.414394
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    import bzrlib.tests
    bzrlib.tests.TestCase.assertEqual(bzrlib.lazy_import.ScopeReplacer,
                                      bzrlib.lazy_import.ScopeReplacer)

    def _factory(self, scope, name):
        return self
    scope = {}
    name = 'foo'
    obj = bzrlib.lazy_import.ScopeReplacer(scope, _factory, name)
    bzrlib.tests.TestCase.assertEqual(obj, obj())



# Generated at 2022-06-18 04:11:37.391882
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:11:39.154395
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:11:43.078427
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return unicode"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:11:46.286792
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object."""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:11:57.162707
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___getattribute__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __init__(self, name):
                    self.name = name
                def __getattribute__(self, attr):
                    if attr == 'name':
                        return object.__getattribute__(self, attr)
                    raise AttributeError(attr)
            scope = {}
            def factory(self, scope, name):
                return Foo(name)
            name = 'foo'
            sr = ScopeReplacer(scope, factory, name)
            self.assertEqual(sr.name, 'foo')
            self.assertRaises(AttributeError, getattr, sr, 'bar')


# Generated at 2022-06-18 04:11:59.844139
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:12:10.899327
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    # __str__ of IllegalUseOfScopeReplacer
    # This test comes from Logilab's pytest module
    # <http://www.logilab.org/project/pytest>
    # Copyright (c) 2003-2008 by LOGILAB S.A. (Paris, FRANCE).
    # http://www.logilab.fr/ -- mailto:contact@logilab.fr
    #
    # This program is free software; you can redistribute it and/or modify it under
    # the terms of the GNU General Public License as published by the Free Software
    # Foundation; either version 2 of the License, or (at your option) any later
    # version.
    #
    # This program is distributed in the hope that it will be useful, but WITHOUT
    # ANY WARRANTY

# Generated at 2022-06-18 04:12:16.033204
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:12:22.050028
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            class Foo(object):
                def __init__(self):
                    self.bar = 'baz'
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            replacer = ScopeReplacer(scope, factory, name)
            replacer.bar = 'qux'
            self.assertEqual('qux', replacer.bar)
            self.assertEqual('qux', scope[name].bar)
    TestScopeReplacer('test_ScopeReplacer___setattr__').run()

# Generated at 2022-06-18 04:12:27.121423
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False

# Generated at 2022-06-18 04:13:22.752467
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)