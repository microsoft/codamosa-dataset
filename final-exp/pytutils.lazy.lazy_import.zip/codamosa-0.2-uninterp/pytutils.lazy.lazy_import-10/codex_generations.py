

# Generated at 2022-06-18 04:03:39.813411
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:03:44.081648
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'ScopeReplacer object \'name\' was used incorrectly: msg: extra'


# Generated at 2022-06-18 04:03:48.613623
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert isinstance(s, unicode)


# Generated at 2022-06-18 04:03:55.916966
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___getattribute__(self):
            import sys
            import bzrlib
            def factory(self, scope, name):
                return bzrlib
            scope = sys.modules
            name = 'bzrlib'
            obj = ScopeReplacer(scope, factory, name)
            self.assertEqual(obj.__getattribute__('__name__'), 'bzrlib')
    test_ScopeReplacer___getattribute__ = TestScopeReplacer(
        'test_ScopeReplacer___getattribute__').test_ScopeReplacer___getattribute__

# Generated at 2022-06-18 04:04:07.488424
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False
    try:
        scope = {}
        def factory(self, scope, name):
            return 42
        bzrlib.lazy_import.ScopeReplacer(scope, factory, 'foo')
        try:
            scope['foo']._resolve()
        except bzrlib.lazy_import.IllegalUseOfScopeReplacer as e:
            assert e.name == 'foo'
            assert e.msg == "Object already replaced, did you assign it to another variable?"
            assert e.extra == ''
        else:
            assert False, "Should have raised IllegalUseOfScopeReplacer"
    finally:
        bzrlib.lazy_import.ScopeReplacer._

# Generated at 2022-06-18 04:04:18.224316
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # Test that __getattribute__ works as expected
    class MyClass(object):
        def __init__(self, value):
            self.value = value
    def factory(self, scope, name):
        return MyClass(name)
    scope = {}
    name = 'my_class'
    replacer = ScopeReplacer(scope, factory, name)
    assert scope[name] is replacer
    assert replacer.value == name
    assert scope[name].value == name
    assert scope[name] is not replacer
    assert scope[name] is scope[name]
    assert scope[name] is not scope[name]
    assert scope[name] is scope[name]
    assert scope[name] is not scope[name]
    assert scope[name] is scope[name]

# Generated at 2022-06-18 04:04:21.236267
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:04:27.746834
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ of IllegalUseOfScopeReplacer"""
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    ''')
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    assert isinstance(e.__unicode__(), unicode)
    assert isinstance(e.__str__(), str)
    assert isinstance(e.__repr__(), str)
    assert e.__unicode__() == u'foo was used incorrectly: bar'
    assert e.__str__() == 'foo was used incorrectly: bar'
    assert e.__repr__() == "IllegalUseOfScopeReplacer('foo', 'bar')"


# Generated at 2022-06-18 04:04:32.884289
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u.startswith('name')
    assert u.endswith('msg')
    assert u.find('IllegalUseOfScopeReplacer') != -1


# Generated at 2022-06-18 04:04:35.067757
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:05:00.438277
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_lazy_import import TestLazyImport
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return object()
            name = 'name'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.__setattr__('attr', 'value')
            self.assertEqual('value', scope_replacer.attr)
    TestLazyImport.test_suite().addTest(TestScopeReplacer('test_ScopeReplacer___setattr__'))

# Generated at 2022-06-18 04:05:03.544690
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:05:08.270146
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg: extra"

# Generated at 2022-06-18 04:05:18.702563
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    class Test(TestCase):
        def test_call(self):
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            scope = {}
            lazy_import(scope, '''
            from bzrlib.lazy_import import ScopeReplacer
            ''')
            foo = Foo()
            scope['foo'] = ScopeReplacer(scope, lambda s, sc, n: foo, 'foo')
            self.assertEqual(((1, 2), {'a':3}), scope['foo'](1, 2, a=3))
    Test().test_call()

# Generated at 2022-06-18 04:05:25.162076
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            foo = Foo()
            scope = {}
            def factory(self, scope, name):
                return foo
            name = 'foo'
            sr = ScopeReplacer(scope, factory, name)
            self.assertEqual(((1, 2, 3), {'a':1, 'b':2}), sr(1, 2, 3, a=1, b=2))
    TestScopeReplacer('test___call__').run()


# Generated at 2022-06-18 04:05:29.475160
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:05:31.977290
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:05:36.440209
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:05:46.578643
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Foo(object):
        def __init__(self):
            self.bar = None
    class TestScopeReplacer(TestCase):
        def test___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.bar = 'baz'
            self.assertEqual('baz', scope[name].bar)
    TestScopeReplacer('test___setattr__').run()

# Generated at 2022-06-18 04:05:53.719572
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should set attributes on the real object"""
    class Foo(object):
        def __init__(self):
            self.bar = None
    scope = {}
    def factory(self, scope, name):
        return Foo()
    replacer = ScopeReplacer(scope, factory, 'foo')
    replacer.bar = 'baz'
    assert scope['foo'].bar == 'baz'

# Generated at 2022-06-18 04:06:11.138526
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:06:19.587268
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self, value):
            self.value = value
    class TestScopeReplacer(TestCase):
        def test_getattribute(self):
            scope = {}
            def factory(self, scope, name):
                return TestObj(name)
            scope_replacer = ScopeReplacer(scope, factory, 'test')
            self.assertEqual('test', scope_replacer.value)
            self.assertEqual('test', scope['test'].value)
    TestScopeReplacer('test_getattribute').run()

# Generated at 2022-06-18 04:06:29.300486
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            foo = Foo()
            foo_replacer = ScopeReplacer(locals(), lambda self, scope, name: foo, 'foo')
            self.assertEqual(((1, 2), {'a': 3}), foo_replacer(1, 2, a=3))
    TestScopeReplacer('test___call__').run()

    def __getattr__(self, attr):
        obj = object.__getattribute__(self, '_resolve')()

# Generated at 2022-06-18 04:06:34.710728
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should set the attribute on the real object"""
    scope = {}
    def factory(self, scope, name):
        return object()
    replacer = ScopeReplacer(scope, factory, 'foo')
    replacer.bar = 'baz'
    assert scope['foo'].bar == 'baz'


# Generated at 2022-06-18 04:06:44.340198
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            foo = Foo()
            scope = {}
            def factory(self, scope, name):
                return foo
            name = 'foo'
            replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual(((1, 2), {'a': 'b'}), replacer(1, 2, a='b'))
    TestScopeReplacer('test___call__').run()



# Generated at 2022-06-18 04:06:54.394069
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = True
    bzrlib.lazy_import.ScopeReplacer._fmt = "test"
    bzrlib.lazy_import.ScopeReplacer._name = "test"
    bzrlib.lazy_import.ScopeReplacer._real_obj = None
    bzrlib.lazy_import.ScopeReplacer._scope = sys.modules
    bzrlib.lazy_import.ScopeReplacer._factory = lambda self, scope, name: self
    bzrlib.lazy_import.ScopeReplacer._resolve = lambda self: self
    bzrlib.lazy_import.ScopeReplacer._get_format_string = lambda self: "test"

# Generated at 2022-06-18 04:06:57.651991
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == 'ScopeReplacer object \'name\' was used incorrectly: msg: extra'

# Generated at 2022-06-18 04:07:01.737485
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:07:06.994610
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object."""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'ScopeReplacer object \'name\' was used incorrectly: msg: extra'

# Generated at 2022-06-18 04:07:12.056530
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:07:23.112029
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should set the attribute on the real object"""
    class Foo(object):
        pass
    scope = {}
    def factory(self, scope, name):
        return Foo()
    lazy_foo = ScopeReplacer(scope, factory, 'foo')
    lazy_foo.bar = 'baz'
    assert scope['foo'].bar == 'baz'

# Generated at 2022-06-18 04:07:26.844991
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str), '__str__ should return a str object'

# Generated at 2022-06-18 04:07:37.920565
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class TestClass(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            test_obj = TestClass()
            scope = {}
            def factory(self, scope, name):
                return test_obj
            replacer = ScopeReplacer(scope, factory, 'test_obj')
            self.assertEqual(((1, 2), {'a': 1, 'b': 2}),
                             replacer(1, 2, a=1, b=2))
    TestScopeReplacer('test___call__').run()



# Generated at 2022-06-18 04:07:45.075550
# Unit test for method __setattr__ of class ScopeReplacer

# Generated at 2022-06-18 04:07:54.378373
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            # Test that assigning to a ScopeReplacer object raises an
            # IllegalUseOfScopeReplacer exception.
            scope = {}
            lazy_import(scope, '''
            from bzrlib import (
                errors,
                osutils,
                branch,
                )
            import bzrlib.branch
            ''')
            self.assertIsInstance(scope['errors'], ScopeReplacer)

# Generated at 2022-06-18 04:08:04.838287
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False

# Generated at 2022-06-18 04:08:08.090742
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert isinstance(s, unicode)

# Generated at 2022-06-18 04:08:12.252951
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:08:18.299000
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object.

    This is a unit test for the method __unicode__ of class
    IllegalUseOfScopeReplacer.
    """
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = e.__unicode__()
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:08:29.906630
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __init__(self, a, b, c):
                    self.a = a
                    self.b = b
                    self.c = c
                def __call__(self, *args, **kwargs):
                    return (self.a, self.b, self.c, args, kwargs)
            scope = {}
            def factory(self, scope, name):
                return Foo(1, 2, 3)
            sr = ScopeReplacer(scope, factory, 'foo')
            self.assertEqual((1, 2, 3, (), {}), sr())

# Generated at 2022-06-18 04:08:38.383301
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg"

# Generated at 2022-06-18 04:08:46.193036
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            from bzrlib.tests import TestUtil
            scope = {}
            def factory(self, scope, name):
                return TestUtil.TestObject()
            name = 'test_object'
            test_object = ScopeReplacer(scope, factory, name)
            self.assertEqual(test_object.test_method(), 'test')
            self.assertEqual(test_object.test_method(), 'test')
            self.assertEqual(test_object.test_method(), 'test')
            self.assertEqual(test_object.test_method(), 'test')
            self.assertEqual

# Generated at 2022-06-18 04:08:49.803944
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg"

# Generated at 2022-06-18 04:08:53.738259
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:09:04.055656
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            class Foo(object):
                def __init__(self):
                    self.a = 1
            foo = Foo()
            scope = {}
            def factory(self, scope, name):
                return foo
            name = 'foo'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.a = 2
            self.assertEqual(2, foo.a)
            self.assertEqual(2, scope_replacer.a)
            self.assertEqual(2, scope[name].a)

# Generated at 2022-06-18 04:09:08.068397
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() should return a str object."""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:09:11.793864
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:09:22.408384
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    # IllegalUseOfScopeReplacer.__str__
    # IllegalUseOfScopeReplacer.__str__:RETURN
    # IllegalUseOfScopeReplacer.__str__:EXCEPTION
    # IllegalUseOfScopeReplacer.__str__:EXCEPTION:IllegalUseOfScopeReplacer
    # IllegalUseOfScopeReplacer.__str__:EXCEPTION:IllegalUseOfScopeReplacer:RETURN
    # IllegalUseOfScopeReplacer.__str__:EXCEPTION:IllegalUseOfScopeReplacer:EXCEPTION
    # IllegalUseOfScopeReplacer.__str__:EXCEPTION:IllegalUseOfScopeReplacer:EXCEPTION:IllegalUseOfScopeReplacer
    # IllegalUseOfScopeReplacer.__str__:EXCEPTION:IllegalUse

# Generated at 2022-06-18 04:09:25.706759
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:09:34.301098
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            class Foo(object):
                def __init__(self):
                    self.bar = None
            foo = Foo()
            scope = {'foo':foo}
            def factory(self, scope, name):
                return scope[name]
            replacer = ScopeReplacer(scope, factory, 'foo')
            replacer.bar = 'baz'
            self.assertEqual('baz', foo.bar)
    TestScopeReplacer('test_ScopeReplacer___setattr__').run()

# Generated at 2022-06-18 04:09:46.066312
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Foo(object):
        def __init__(self, x):
            self.x = x
        def bar(self):
            return self.x
    class Test(TestCase):
        def test_getattribute(self):
            scope = {}
            def factory(self, scope, name):
                return Foo(name)
            replacer = ScopeReplacer(scope, factory, 'foo')
            self.assertEqual('foo', replacer.x)
            self.assertEqual('foo', replacer.bar())
            self.assertEqual('foo', scope['foo'].x)
            self.assertEqual('foo', scope['foo'].bar())

# Generated at 2022-06-18 04:09:53.781110
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            import sys
            class Foo(object):
                pass
            foo = Foo()
            foo.bar = 'bar'
            replacer = ScopeReplacer(sys.modules, lambda self, scope, name: foo, 'foo')
            replacer.bar = 'baz'
            self.assertEqual('baz', foo.bar)
            self.assertEqual('baz', replacer.bar)
    TestScopeReplacer('test_ScopeReplacer___setattr__').test_ScopeReplacer___setattr__()

# Generated at 2022-06-18 04:10:04.357815
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    class TestScopeReplacer(TestCase):
        def test_call(self):
            # Test that ScopeReplacer.__call__() works as expected.
            # This is a regression test for bug #569073.
            scope = {}
            def factory(self, scope, name):
                return lambda x: x+1
            lazy_import(scope, '''
            from bzrlib.lazy_import import ScopeReplacer
            ''')
            scope['ScopeReplacer'](scope, factory, 'f')
            self.assertEqual(2, scope['f'](1))
    TestScopeReplacer('test_call').run()

    # Test that ScopeReplacer.__call__() raises an exception if

# Generated at 2022-06-18 04:10:09.097644
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)
    assert s.startswith('ScopeReplacer object')

# Generated at 2022-06-18 04:10:17.301495
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return None
            name = 'name'
            self.assertRaises(IllegalUseOfScopeReplacer, ScopeReplacer, scope, factory, name)
    TestScopeReplacer('test_ScopeReplacer___setattr__').test_ScopeReplacer___setattr__()

# Generated at 2022-06-18 04:10:20.249742
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:10:23.803405
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:10:31.973827
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test___setattr__(self):
            class Foo(object):
                def __init__(self):
                    self.foo = 'foo'
            class Bar(object):
                def __init__(self):
                    self.bar = 'bar'
            scope = {}
            def factory(self, scope, name):
                if name == 'foo':
                    return Foo()
                else:
                    return Bar()
            ScopeReplacer(scope, factory, 'foo')
            ScopeReplacer(scope, factory, 'bar')
            self.assertEqual('foo', scope['foo'].foo)
            self.assertEqual('bar', scope['bar'].bar)
           

# Generated at 2022-06-18 04:10:35.777346
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:10:38.730667
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s == 'name: msg'

# Generated at 2022-06-18 04:10:46.849036
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:10:56.109222
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self):
            self.a = 1
    class TestCase(TestCase):
        def test_setattr(self):
            scope = {}
            def factory(self, scope, name):
                return TestObj()
            replacer = ScopeReplacer(scope, factory, 'test_obj')
            replacer.a = 2
            self.assertEqual(2, replacer.a)
            self.assertEqual(2, scope['test_obj'].a)
    TestCase.run_tests()

# Generated at 2022-06-18 04:11:00.021342
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s.startswith('IllegalUseOfScopeReplacer(')
    assert s.endswith(')')

# Generated at 2022-06-18 04:11:03.465294
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() should return a str object."""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:11:13.816633
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.lazy_import import _scope_replacer_factory
    from bzrlib.lazy_import import _scope_replacer_factory_for_module
    from bzrlib.lazy_import import _scope_replacer_factory_for_module_and_name
    from bzrlib.lazy_import import _scope_replacer_factory_for_module_and_name_and_attr
    from bzrlib.lazy_import import _scope_replacer_factory_for_module_and_name_and_attr_and_value

# Generated at 2022-06-18 04:11:23.362409
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            # Test that __setattr__ works as expected
            class Foo(object):
                def __init__(self):
                    self.bar = 'bar'
            foo = Foo()
            scope = {}
            def factory(self, scope, name):
                return foo
            replacer = ScopeReplacer(scope, factory, 'foo')
            replacer.bar = 'baz'
            self.assertEqual('baz', foo.bar)
            self.assertEqual('baz', replacer.bar)
    TestScopeReplacer('test_ScopeReplacer___setattr__').run_tests()
# Unit test

# Generated at 2022-06-18 04:11:34.537054
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests
    import bzrlib.lazy_import
    import bzrlib.tests.blackbox
    import bzrlib.tests.blackbox.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest.test_selftest.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest.test_selftest.test_selftest.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSel

# Generated at 2022-06-18 04:11:43.035061
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Foo(object):
        def __init__(self):
            self.bar = 'bar'
    class Test(TestCase):
        def test_ScopeReplacer___getattribute__(self):
            scope = {}
            def factory(self, scope, name):
                return Foo()
            replacer = ScopeReplacer(scope, factory, 'foo')
            self.assertEqual('bar', replacer.bar)
            self.assertEqual('bar', scope['foo'].bar)

# Generated at 2022-06-18 04:11:54.338239
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            class TestClass(object):
                def __init__(self):
                    self.a = 1
                    self.b = 2
            scope = {}
            def factory(self, scope, name):
                return TestClass()
            name = 'test'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.a = 3
            self.assertEqual(scope_replacer.a, 3)
            self.assertEqual(scope_replacer.b, 2)
            self.assertEqual(scope[name].a, 3)

# Generated at 2022-06-18 04:11:56.837797
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:12:13.010564
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert isinstance(e.__unicode__(), unicode)
    assert isinstance(e.__str__(), str)
    assert isinstance(repr(e), str)
    assert isinstance(str(e), str)
    assert isinstance(unicode(e), unicode)
    assert isinstance(e.__repr__(), str)
    assert isinstance(e.__str__(), str)
    assert isinstance(e.__unicode__(), unicode)
    assert isinstance(e.__repr__(), str)
    assert isinstance(e.__str__(), str)
    assert isinstance(e.__unicode__(), unicode)



# Generated at 2022-06-18 04:12:16.923154
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg"

# Generated at 2022-06-18 04:12:28.195727
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should raise an exception if the object has already been
    replaced.
    """
    import sys
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    # This should not raise an exception
    osutils.pathjoin('foo', 'bar')
    # This should raise an exception
    ScopeReplacer._should_proxy = False

# Generated at 2022-06-18 04:12:30.521884
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:12:35.092702
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:12:38.060210
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:12:47.730849
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should raise an exception if the object has already been
    replaced.
    """
    import sys
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    from bzrlib.lazy_import import ScopeReplacer
    ''')
    # Create a ScopeReplacer object
    ScopeReplacer(sys.modules, lambda self, scope, name: None, 'test_module')
    # Replace it with a real object
    sys.modules['test_module'] = 'test_module'
    # Now try to set an attribute on the ScopeReplacer object

# Generated at 2022-06-18 04:12:54.438694
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_lazy_import import TestScopeReplacer
    class Test(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return TestScopeReplacer()
            name = 'name'
            obj = ScopeReplacer(scope, factory, name)
            obj.attr = 'value'
            self.assertEqual('value', obj.attr)
            self.assertEqual('value', scope[name].attr)
    Test().test_ScopeReplacer___setattr__()

# Generated at 2022-06-18 04:12:59.835532
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    # This test is a bit of a hack, but it is better than nothing.
    # We just check that the string is not empty.
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert s != '', 'str(e) is empty'


# Generated at 2022-06-18 04:13:03.114448
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = e.__unicode__()
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:13:20.385113
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.lazy_import
    import bzrlib.tests.blackbox
    import bzrlib.tests.blackbox.test_selftest
    import bzrlib.tests.blackbox.test_selftest.test_selftest
    import bzrlib.tests.blackbox.test_selftest.test_selftest.test_selftest
    import bzrlib.tests.blackbox.test_selftest.test_selftest.test_selftest.test_selftest
    import bzrlib.tests.blackbox.test_selftest.test_selftest.test_selftest.test_selftest.test_selftest
    import bzrlib.tests.blackbox.test_selftest.test_selftest.test