

# Generated at 2022-06-18 04:03:51.847545
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:03:57.230536
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self):
            self.a = 1
    class TestCase(TestCase):
        def test_setattr(self):
            scope = {}
            def factory(self, scope, name):
                return TestObj()
            obj = ScopeReplacer(scope, factory, 'obj')
            obj.a = 2
            self.assertEqual(2, obj.a)
            self.assertEqual(2, scope['obj'].a)

# Generated at 2022-06-18 04:04:00.859384
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:04:03.772417
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:04:12.439535
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_setattr(self):
            scope = {}
            def factory(self, scope, name):
                return 'real'
            replacer = ScopeReplacer(scope, factory, 'name')
            replacer.attr = 'value'
            self.assertEqual('value', replacer.attr)
            self.assertEqual('value', scope['name'].attr)
    TestScopeReplacer('test_setattr').run()

# Generated at 2022-06-18 04:04:16.241070
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:04:18.722466
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:04:22.318296
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'name: msg: extra'


# Generated at 2022-06-18 04:04:25.521829
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:04:29.714403
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:05:02.158130
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:05:06.729567
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()

    This method should return a unicode object.
    """
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:05:18.082324
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    import bzrlib.tests.test_lazy_import
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            # __call__(self, *args, **kwargs)
            # Calling a ScopeReplacer should call the real object.
            def factory(self, scope, name):
                return lambda *args, **kwargs: (args, kwargs)
            scope = {}
            name = 'foo'
            replacer = ScopeReplacer(scope, factory, name)
            args = (1, 2, 3)
            kwargs = {'a': 'b'}
            self.assertEqual((args, kwargs), replacer(*args, **kwargs))
    bzrlib.tests.test_lazy_import.Test

# Generated at 2022-06-18 04:05:25.411024
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import _make_scope_replacer_factory
    from bzrlib.lazy_import import _make_module_scope_replacer_factory
    from bzrlib.lazy_import import _make_module_scope_replacer_factory_from_name
    from bzrlib.lazy_import import _make_module_scope_replacer_factory_from_name_and_scope
    from bzrlib.lazy_import import _make_module_scope_replacer_factory_from_name_and_scope_and_factory


# Generated at 2022-06-18 04:05:34.445084
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()

    This method is used by the unicode() builtin function and by the %s
    format character.
    """
    # Test that the method returns a unicode object.
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)
    # Test that the method returns a unicode object even if the exception
    # object has a __str__ method that returns a str object.
    class MyException(IllegalUseOfScopeReplacer):
        def __str__(self):
            return 'str'
    e = MyException('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)
    # Test that the method returns a unicode object even if the

# Generated at 2022-06-18 04:05:46.263378
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import

# Generated at 2022-06-18 04:05:52.712210
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test_getattribute(self):
            scope = {}
            def factory(self, scope, name):
                return name
            replacer = ScopeReplacer(scope, factory, 'foo')
            self.assertEqual('foo', replacer.__getattribute__('_name'))
            self.assertEqual('foo', replacer.__getattribute__('_resolve')())
            self.assertEqual('foo', replacer.__getattribute__('_name'))
            self.assertEqual('foo', replacer.__getattribute__('_resolve')())
            self.assertEqual('foo', replacer.__getattribute__('_name'))

# Generated at 2022-06-18 04:06:02.724311
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'IllegalUseOfScopeReplacer object foo was used incorrectly: bar'
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'IllegalUseOfScopeReplacer object foo was used incorrectly: bar: baz'
    # Test that the exception is not cached
    e._fmt = '%(msg)s'
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'bar: baz'
    e._

# Generated at 2022-06-18 04:06:14.439611
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.lazy_import import lazy_import
    import bzrlib.lazy_import
    import bzrlib.lazy_import
    import bzrlib.lazy_import
    import bzrlib.lazy_import
    import bzrlib.lazy_import
    import bzrlib.lazy_import
    import bzrlib.lazy_import
    import bzrlib.lazy_import
    import bzrlib.lazy_import
    import bzrlib.lazy_import
    import bzrlib.lazy_import
    import bzrlib.lazy_import
    import bzrlib.lazy_import
    import bzrlib.lazy_import
    import bzrlib.lazy_import
    import b

# Generated at 2022-06-18 04:06:17.530243
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__(self, attr, value)"""
    # Test the method __setattr__ of class ScopeReplacer
    # This test is not implemented yet.
    pass


# Generated at 2022-06-18 04:06:36.111185
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'ScopeReplacer object \'foo\' was used incorrectly: bar'


# Generated at 2022-06-18 04:06:39.184548
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:06:42.212302
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:06:51.628425
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            foo = Foo()
            scope = {}
            replacer = ScopeReplacer(scope, lambda self, scope, name: foo, 'foo')
            self.assertEqual(((1, 2), {'a': 'b'}), replacer(1, 2, a='b'))
    TestScopeReplacer('test___call__').test___call__()


# Generated at 2022-06-18 04:06:56.013092
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:06:58.395408
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:07:04.094004
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object."""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'ScopeReplacer object \'name\' was used incorrectly: msg: extra'

# Generated at 2022-06-18 04:07:07.032410
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:07:19.694670
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """__getattribute__(self, attr)"""
    # __getattribute__(self, attr)
    # Test for method __getattribute__ of class ScopeReplacer
    # __getattribute__(self, attr)
    # Test for method __getattribute__ of class ScopeReplacer
    # __getattribute__(self, attr)
    # Test for method __getattribute__ of class ScopeReplacer
    # __getattribute__(self, attr)
    # Test for method __getattribute__ of class ScopeReplacer
    # __getattribute__(self, attr)
    # Test for method __getattribute__ of class ScopeReplacer
    # __getattribute__(self, attr)
    # Test for method __getattribute__ of class ScopeReplacer
    # __getattribute__(self, attr)
    # Test for

# Generated at 2022-06-18 04:07:25.579720
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    import sys
    class TestScopeReplacer(TestCase):
        def test___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return 'foo'
            name = 'bar'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.__setattr__('_should_proxy', False)
            self.assertRaises(IllegalUseOfScopeReplacer, scope_replacer.__setattr__, 'baz', 'qux')
    TestScopeReplacer('test___setattr__').run()

# Generated at 2022-06-18 04:07:41.375480
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:07:52.581516
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_lazy_import import TestLazyImport
    from bzrlib.tests.test_lazy_import import TestLazyImportWithScopeReplacer
    from bzrlib.tests.test_lazy_import import TestLazyImportWithScopeReplacer2
    from bzrlib.tests.test_lazy_import import TestLazyImportWithScopeReplacer3
    from bzrlib.tests.test_lazy_import import TestLazyImportWithScopeReplacer4
    from bzrlib.tests.test_lazy_import import TestLazyImportWithScopeReplacer5
    from bzrlib.tests.test_lazy_import import TestLazyImportWith

# Generated at 2022-06-18 04:07:57.424514
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:08:03.323361
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class Foo(object):
        def __init__(self, x):
            self.x = x
    def factory(self, scope, name):
        return Foo(name)
    scope = {}
    name = 'foo'
    replacer = ScopeReplacer(scope, factory, name)
    assert replacer.x == 'foo'
    assert scope[name].x == 'foo'
    assert replacer.x == 'foo'

# Generated at 2022-06-18 04:08:06.855834
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object."""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:08:13.833340
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    class A(object):
        def __init__(self, x):
            self.x = x
        def f(self):
            return self.x
    def factory(self, scope, name):
        return A(42)
    scope = sys._getframe(1).f_locals
    name = 'a'
    a = ScopeReplacer(scope, factory, name)
    assert a.x == 42
    assert a.f() == 42
    assert scope[name] is a
    assert scope[name].x == 42
    assert scope[name].f() == 42
    assert scope[name].x == 42
    assert scope[name].f() == 42
    assert scope[name].x == 42
    assert scope[name].f() == 42
    assert scope[name].x == 42

# Generated at 2022-06-18 04:08:17.661608
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:08:20.631726
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() returns a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:08:24.800386
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:08:34.988494
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_lazy_import import ScopeReplacerTest

    class TestScopeReplacer(ScopeReplacerTest):

        def test_setattr(self):
            """Test that __setattr__ works."""
            lazy_import(globals(), '''
            from bzrlib import (
                errors,
                osutils,
                branch,
                )
            import bzrlib.branch
            ''')
            self.assertIsInstance(branch, ScopeReplacer)
            self.assertIsInstance(bzrlib, ScopeReplacer)
            self.assertIsInstance(errors, ScopeReplacer)

# Generated at 2022-06-18 04:08:56.401357
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return 'foo'
            name = 'bar'
            obj = ScopeReplacer(scope, factory, name)
            obj.foo = 'bar'
            self.assertEqual('bar', obj.foo)
            self.assertEqual('bar', scope['bar'].foo)
    TestScopeReplacer('test_ScopeReplacer___setattr__').test_ScopeReplacer___setattr__()

# Generated at 2022-06-18 04:08:58.744043
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:09:02.548476
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:09:06.321246
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:09:09.856437
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:09:12.933081
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:09:23.448845
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___call__(self):
            import sys
            import bzrlib.lazy_import
            bzrlib.lazy_import.lazy_import(globals(), '''
            import bzrlib.tests.test_lazy_import
            ''')
            def factory(self, scope, name):
                return bzrlib.tests.test_lazy_import
            scope = sys.modules
            name = 'bzrlib.tests.test_lazy_import'
            scope_replacer = bzrlib.lazy_import.ScopeReplacer(scope, factory, name)

# Generated at 2022-06-18 04:09:32.358056
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return name
            name = 'name'
            obj = ScopeReplacer(scope, factory, name)
            self.assertEqual(scope[name], obj)
            obj.attr = 'value'
            self.assertEqual(scope[name].attr, 'value')
            self.assertEqual(obj.attr, 'value')
    TestScopeReplacer('test_ScopeReplacer___setattr__').run()

# Generated at 2022-06-18 04:09:36.384228
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:09:42.202686
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__()"""
    # This test is here because it is a good example of how to use
    # IllegalUseOfScopeReplacer.
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    assert str(e) == "ScopeReplacer object 'foo' was used incorrectly: bar: baz"
    assert unicode(e) == u"ScopeReplacer object 'foo' was used incorrectly: bar: baz"
    assert repr(e) == "IllegalUseOfScopeReplacer('ScopeReplacer object \'foo\' was used incorrectly: bar: baz')"



# Generated at 2022-06-18 04:10:06.812998
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:10:10.393752
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:10:14.281486
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'name was used incorrectly: msg'

# Generated at 2022-06-18 04:10:25.145772
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should raise an exception if the object has already been
    replaced.
    """
    import sys
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests import TestCase
    from bzrlib.tests.lazy_import_helper import (
        get_module_name,
        get_module_path,
        )
    from bzrlib.tests.test_lazy_import import (
        TestLazyImport,
        )

    class TestScopeReplacer(TestCase):

        def test_setattr(self):
            """__setattr__ should raise an exception if the object has already
            been replaced.
            """
            module_name = get_module_name()
            module_path = get_module_path()
            # Create a module to import


# Generated at 2022-06-18 04:10:27.655992
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:10:32.755457
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests.blackbox import ExternalBase
    class TestableScopeReplacer(ScopeReplacer):
        def __init__(self, scope, factory, name):
            ScopeReplacer.__init__(self, scope, factory, name)
    class TestableExternalBase(ExternalBase):
        def test_ScopeReplacer___call__(self):
            import sys
            def factory(self, scope, name):
                return lambda: 'foo'
            scope = sys._getframe(1).f_locals
            name = 'foo'
            obj = TestableScopeReplacer(scope, factory, name)
            self.assertEqual('foo', obj())
    TestableExternalBase().run_tests()

# Generated at 2022-06-18 04:10:37.117051
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:10:39.460543
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:10:51.664196
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # __getattribute__ of ScopeReplacer
    # Calling __getattribute__ on a ScopeReplacer should return the real object
    # and not the ScopeReplacer itself.
    import sys
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    # Check that the objects are ScopeReplacers
    assert isinstance(errors, bzrlib.lazy_import.ScopeReplacer)
    assert isinstance(osutils, bzrlib.lazy_import.ScopeReplacer)
    assert isinstance(branch, bzrlib.lazy_import.ScopeReplacer)
   

# Generated at 2022-06-18 04:10:54.736334
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:11:18.381720
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:11:27.524939
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestClass(object):
        def __init__(self, value):
            self.value = value
        def __getattribute__(self, attr):
            if attr == 'value':
                return object.__getattribute__(self, attr)
            else:
                return 'value'
    class TestCase(TestCase):
        def test_ScopeReplacer___getattribute__(self):
            scope = {}
            def factory(self, scope, name):
                return TestClass(name)
            name = 'name'
            scope_replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual('value', scope_replacer.value)

# Generated at 2022-06-18 04:11:37.056726
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self):
            self.attr = None
    class TestCase(TestCase):
        def test_setattr(self):
            obj = TestObj()
            scope = {}
            replacer = ScopeReplacer(scope, lambda x, y, z: obj, 'obj')
            replacer.attr = 'value'
            self.assertEqual('value', obj.attr)
            self.assertEqual('value', scope['obj'].attr)
            self.assertEqual('value', replacer.attr)
            replacer.attr = 'value2'
            self.assertEqual('value2', obj.attr)

# Generated at 2022-06-18 04:11:40.030041
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:11:45.015204
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() should return a str object"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    s = str(e)
    assert isinstance(s, str)
    assert s == "IllegalUseOfScopeReplacer object 'foo' was used incorrectly:" \
        " bar"


# Generated at 2022-06-18 04:11:56.129266
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Test(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return object()
            name = 'name'
            scope_replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual(scope_replacer._should_proxy, True)
            scope_replacer._should_proxy = False
            self.assertEqual(scope_replacer._should_proxy, False)
            self.assertRaises(IllegalUseOfScopeReplacer,
                scope_replacer.__setattr__, 'attr', 'value')
            scope_replacer._should_proxy = True
            scope_replacer.__

# Generated at 2022-06-18 04:11:59.250876
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:12:10.370690
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Unit test for method __setattr__ of class ScopeReplacer"""
    from bzrlib.tests import TestCase
    import sys
    class TestScopeReplacer(TestCase):
        def test_setattr_after_resolve(self):
            # Test that __setattr__ works after the object has been resolved.
            # This is important because it is used to set attributes on the
            # real object.
            scope = {}
            def factory(self, scope, name):
                return object()
            replacer = ScopeReplacer(scope, factory, 'test')
            replacer.foo = 'bar'
            self.assertEqual('bar', replacer.foo)
            self.assertEqual('bar', scope['test'].foo)
    TestScopeReplacer('test_setattr_after_resolve').run()

# Generated at 2022-06-18 04:12:20.225249
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """Unit test for method __setattr__ of class ScopeReplacer"""
    import sys
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False

# Generated at 2022-06-18 04:12:29.451323
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            class TestClass(object):
                def __init__(self):
                    self.a = 1
            scope = {}
            def factory(self, scope, name):
                return TestClass()
            name = 'test'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.a = 2
            self.assertEqual(2, scope_replacer.a)
            self.assertEqual(2, scope[name].a)
    TestScopeReplacer('test_ScopeReplacer___setattr__').run()