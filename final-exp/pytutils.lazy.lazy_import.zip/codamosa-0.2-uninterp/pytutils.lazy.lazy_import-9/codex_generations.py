

# Generated at 2022-06-18 04:03:46.045646
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:03:56.148823
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test__call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            foo = Foo()
            self.assertEqual(((1, 2), {'a': 'b'}), foo(1, 2, a='b'))
            foo = ScopeReplacer({}, lambda self, scope, name: foo, 'foo')
            self.assertEqual(((1, 2), {'a': 'b'}), foo(1, 2, a='b'))
    TestScopeReplacer('test__call__').run()


# Generated at 2022-06-18 04:04:00.721037
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:04:05.545488
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()"""
    # This test is here because it is a method of a class that is defined in
    # this module.
    import doctest
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    doctest.testmod(IllegalUseOfScopeReplacer)



# Generated at 2022-06-18 04:04:08.816717
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:04:11.997383
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:04:22.842897
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            class Foo(object):
                pass
            foo = Foo()
            foo.bar = 'bar'
            scope = {}
            def factory(self, scope, name):
                return foo
            scope_replacer = ScopeReplacer(scope, factory, 'foo')
            scope_replacer.bar = 'baz'
            self.assertEqual('baz', foo.bar)
    test_ScopeReplacer___setattr__ = TestScopeReplacer('test_ScopeReplacer___setattr__').test_ScopeReplacer___setattr__


# Generated at 2022-06-18 04:04:26.299777
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:04:35.183810
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer

    class TestScopeReplacer(TestCase):

        def test_setattr_after_resolve(self):
            scope = {}
            def factory(self, scope, name):
                return object()
            replacer = ScopeReplacer(scope, factory, 'foo')
            replacer.bar = 'baz'
            self.assertEqual('baz', replacer.bar)
            self.assertEqual('baz', scope['foo'].bar)
            self.assertRaises(IllegalUseOfScopeReplacer, setattr,
                              replacer, 'bar', 'qux')


# Generated at 2022-06-18 04:04:45.427196
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __init__(self, *args, **kwargs):
                    self.args = args
                    self.kwargs = kwargs
            foo = Foo(1, 2, 3, a=4, b=5, c=6)
            scope = {}
            def factory(self, scope, name):
                return foo
            name = 'foo'
            obj = ScopeReplacer(scope, factory, name)
            self.assertEqual(obj(1, 2, 3, a=4, b=5, c=6), foo)

# Generated at 2022-06-18 04:04:57.508623
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:05:08.696234
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer

    class TestScopeReplacer(TestCase):

        def test___setattr__(self):
            class Foo(object):
                def __init__(self):
                    self.a = 1
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.a = 2
            self.assertEqual(2, scope_replacer.a)
            self.assertEqual(2, scope[name].a)
            self.assertEqual(2, scope_replacer.a)

    TestScopeReplacer('test___setattr__').run()

# Generated at 2022-06-18 04:05:09.902139
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:05:20.472006
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False

# Generated at 2022-06-18 04:05:24.068805
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:05:33.482185
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__()"""
    # Test that the __str__ method returns a str object.
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    # Test that the __str__ method returns a str object even when the
    # exception message is unicode.
    e = IllegalUseOfScopeReplacer('name', u'msg')
    s = str(e)
    assert isinstance(s, str)
    # Test that the __str__ method returns a str object even when the
    # exception message is unicode and the default encoding is ascii.
    import sys
    old_default_encoding = sys.getdefaultencoding()
    sys.setdefaultencoding('ascii')
    e = IllegalUseOf

# Generated at 2022-06-18 04:05:36.841000
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:05:40.815139
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:05:43.871689
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:05:51.075086
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___getattribute__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __init__(self):
                    self.bar = 'bar'
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            obj = ScopeReplacer(scope, factory, name)
            self.assertEqual('bar', obj.bar)
    TestScopeReplacer('test_ScopeReplacer___getattribute__').run()

# Generated at 2022-06-18 04:06:13.983957
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer

    class TestScopeReplacer(TestCase):

        def test___call__(self):
            def factory(self, scope, name):
                return lambda x: x
            scope = {}
            name = 'foo'
            obj = ScopeReplacer(scope, factory, name)
            self.assertEqual(obj(1), 1)

    TestScopeReplacer('test___call__').run()



# Generated at 2022-06-18 04:06:17.843797
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:06:21.139664
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:06:27.402947
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import, ScopeReplacer
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            def factory(self, scope, name):
                return lambda: 'foo'
            scope = {}
            name = 'foo'
            obj = ScopeReplacer(scope, factory, name)
            self.assertEqual('foo', obj())

# Generated at 2022-06-18 04:06:29.073510
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    assert isinstance(str(e), str)


# Generated at 2022-06-18 04:06:33.955146
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:06:37.187355
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:06:48.634402
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()

    This method is used to format the exception for printing.
    """
    # This is a regression test for bug #178820.
    # The bug was that the method __unicode__() of class
    # IllegalUseOfScopeReplacer was not implemented.
    # The method __unicode__() is used to format the exception for printing.
    # The method __unicode__() must return a unicode object.
    # The method __str__() must return a str object.
    # The method __repr__() must return a str object.
    # The method __str__() and __repr__() must return the same value.
    # The method __str__() and __repr__() must return a value that
    # can be used to recreate the exception.
    # The method

# Generated at 2022-06-18 04:06:53.727571
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should set the attribute on the real object."""
    class Foo(object):
        def __init__(self):
            self.foo = None
    scope = {}
    def factory(self, scope, name):
        return Foo()
    replacer = ScopeReplacer(scope, factory, 'foo')
    replacer.foo = 'bar'
    assert scope['foo'].foo == 'bar'


# Generated at 2022-06-18 04:07:01.126849
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Test method __str__ of class IllegalUseOfScopeReplacer"""
    import sys
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    if sys.version_info[0] < 3:
        # Python 2.x
        assert isinstance(str(e), str)
        assert isinstance(unicode(e), unicode)
    else:
        # Python 3.x
        assert isinstance(str(e), str)
        assert isinstance(bytes(e), bytes)
        assert isinstance(e.__str__(), str)
        assert isinstance(e.__unicode__(), str)
        assert isinstance(e.__repr__(), str)
        assert isinstance(e.__format__('foo'), str)
       

# Generated at 2022-06-18 04:07:53.675100
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import bzrlib.tests
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.lazy_import import _test_ScopeReplacer___getattribute__
    from bzrlib.lazy_import import _test_ScopeReplacer___getattribute__
    from bzrlib.lazy_import import _test_ScopeReplacer___getattribute__
    from bzrlib.lazy_import import _test_ScopeReplacer___getattribute__
    from bzrlib.lazy_import import _test_ScopeReplacer___getattribute__
    from bzrlib.lazy_import import _test_ScopeReplacer___get

# Generated at 2022-06-18 04:07:57.377903
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)



# Generated at 2022-06-18 04:08:01.696347
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg: extra"


# Generated at 2022-06-18 04:08:04.880111
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:08:15.623670
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'ScopeReplacer object \'name\' was used incorrectly: msg'
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'ScopeReplacer object \'name\' was used incorrectly: msg: extra'
    # Test that the exception is printable when the format string is not
    # available.
    e = IllegalUseOfScopeReplacer('name', 'msg')
    del e._fmt
    u = unicode(e)
    assert isinstance(u, unicode)
   

# Generated at 2022-06-18 04:08:18.523246
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:08:22.083535
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:08:25.757711
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:08:31.156582
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            class Foo(object):
                def __init__(self):
                    self.bar = None
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            foo = ScopeReplacer(scope, factory, name)
            foo.bar = 'baz'
            self.assertEqual('baz', foo.bar)
            self.assertEqual('baz', scope[name].bar)
    test_ScopeReplacer___setattr__ = TestScopeReplacer('test_ScopeReplacer___setattr__').test_ScopeReplacer___setattr__
# Unit

# Generated at 2022-06-18 04:08:39.431462
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    # Test that the callable is actually called.
    def _factory(self, scope, name):
        return lambda: 'called'
    scope = {}
    name = 'test_name'
    replacer = bzrlib.lazy_import.ScopeReplacer(scope, _factory, name)
    assert scope[name] is replacer
    assert replacer() == 'called'
    assert scope[name]() == 'called'



# Generated at 2022-06-18 04:08:59.583524
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_ScopeReplacer___getattribute__(self):
            import sys
            import bzrlib
            scope = sys._getframe(1).f_globals
            scope['bzrlib'] = bzrlib
            scope['bzrlib']._should_proxy = False

# Generated at 2022-06-18 04:09:09.945635
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            foo = Foo()
            scope = {}
            def factory(self, scope, name):
                return foo
            name = 'foo'
            scope_replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual(((1, 2), {'a': 3}), scope_replacer(1, 2, a=3))
    TestScopeReplacer('test___call__').run()



# Generated at 2022-06-18 04:09:21.097262
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__(self, attr, value)"""
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.lazy_import import _lazy_import_module
    from bzrlib.lazy_import import _lazy_import_module_from_path
    from bzrlib.lazy_import import _lazy_import_module_from_name
    from bzrlib.lazy_import import _lazy_import_module_from_path_and_name
    from bzrlib.lazy_import import _lazy_import_module_from_name_

# Generated at 2022-06-18 04:09:25.910660
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:09:34.897936
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            foo = Foo()
            scope = {}
            def factory(self, scope, name):
                return foo
            name = 'foo'
            scope_replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual(((), {}), scope_replacer())
            self.assertEqual(((1,), {}), scope_replacer(1))
            self.assertEqual(((1, 2), {}), scope_replacer(1, 2))
            self.assertEqual

# Generated at 2022-06-18 04:09:41.753045
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            def factory(self, scope, name):
                return lambda: 'foo'
            scope = {}
            name = 'foo'
            obj = ScopeReplacer(scope, factory, name)
            self.assertEqual('foo', obj())
    Test('test_ScopeReplacer___call__').run()

# Generated at 2022-06-18 04:09:51.533437
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            foo = Foo()
            scope = {}
            def factory(self, scope, name):
                return foo
            name = 'foo'
            obj = ScopeReplacer(scope, factory, name)
            self.assertEqual(((1, 2), {'a': 'b'}), obj(1, 2, a='b'))
    TestScopeReplacer('test___call__').run()

    # Unit test for method __getattribute__ of class ScopeReplacer

# Generated at 2022-06-18 04:09:56.270120
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'name was used incorrectly: msg'

# Generated at 2022-06-18 04:10:06.902538
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            import bzrlib.lazy_import
            import bzrlib.tests
            bzrlib.lazy_import.lazy_import(globals(), '''
            from bzrlib import (
                errors,
                osutils,
                branch,
                )
            import bzrlib.branch
            ''')
            self.assertIsInstance(errors, bzrlib.lazy_import.ScopeReplacer)
            self.assertIsInstance(osutils, bzrlib.lazy_import.ScopeReplacer)
            self.assertIsInstance(branch, bzrlib.lazy_import.ScopeReplacer)

# Generated at 2022-06-18 04:10:10.497099
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:10:23.703780
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'name was used incorrectly: msg'

# Generated at 2022-06-18 04:10:31.914752
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self):
            self.attr = None
    class TestCase(TestCase):
        def test_setattr(self):
            obj = TestObj()
            scope = {}
            def factory(self, scope, name):
                return obj
            replacer = ScopeReplacer(scope, factory, 'obj')
            replacer.attr = 'value'
            self.assertEqual('value', obj.attr)
            self.assertEqual('value', replacer.attr)
            self.assertEqual('value', scope['obj'].attr)
            self.assertEqual('value', scope['obj'].attr)

# Generated at 2022-06-18 04:10:36.944068
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__()"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg: extra"


# Generated at 2022-06-18 04:10:39.874370
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg"

# Generated at 2022-06-18 04:10:52.028945
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_lazy_import import TestLazyImport
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            lazy_import(scope, '''
            from bzrlib.lazy_import import ScopeReplacer
            ''')
            def factory(self, scope, name):
                return self
            scope['ScopeReplacer'](scope, factory, 'test')
            self.assertRaises(IllegalUseOfScopeReplacer,
                              getattr, scope['test'], '_resolve')
    TestLazyImport.add_tests(TestScopeReplacer)

# Generated at 2022-06-18 04:10:55.120556
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:10:59.095614
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s.startswith('IllegalUseOfScopeReplacer')

# Generated at 2022-06-18 04:11:02.170605
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:11:05.069109
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:11:08.839410
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:11:35.978760
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False
    scope = {}
    def factory(self, scope, name):
        return self
    name = 'name'
    obj = bzrlib.lazy_import.ScopeReplacer(scope, factory, name)

# Generated at 2022-06-18 04:11:44.467303
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__()"""
    # This test is not complete, but it is better than nothing.
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)
    assert s.startswith('IllegalUseOfScopeReplacer(')
    assert s.endswith(')')
    assert 'name' in s
    assert 'msg' in s
    assert 'extra' in s
    assert 'dict' not in s
    assert 'fmt' not in s
    assert 'error' not in s



# Generated at 2022-06-18 04:11:47.712795
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:11:55.194215
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    def _factory(self, scope, name):
        return bzrlib.tests.blackbox.test_lazy_import.TestLazyImport
    scope = {}
    name = 'TestLazyImport'
    bzrlib.lazy_import.ScopeReplacer(scope, _factory, name)
    scope[name]().test_lazy_import()



# Generated at 2022-06-18 04:12:03.084553
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.tests
    bzrlib.tests.TestCase.assertEqual(
        ScopeReplacer(None, None, None).__getattribute__('_resolve'),
        ScopeReplacer._resolve)
    bzrlib.tests.TestCase.assertRaises(
        AttributeError,
        ScopeReplacer(None, None, None).__getattribute__, '_resolve_')

# Generated at 2022-06-18 04:12:06.006709
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:12:14.398815
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test_setattr(self):
            class Foo(object):
                pass
            foo = Foo()
            foo.bar = 'baz'
            scope = {}
            lazy_import(scope, 'foo', 'foo')
            self.assertEqual('baz', scope['foo'].bar)

    from bzrlib.tests import TestUtil
    TestUtil.test_suite()



# Generated at 2022-06-18 04:12:17.178307
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:12:24.878173
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return object()
            name = 'name'
            obj = ScopeReplacer(scope, factory, name)
            obj.attr = 'value'
            self.assertEqual('value', obj.attr)
    TestScopeReplacer('test_ScopeReplacer___setattr__').run()

# Generated at 2022-06-18 04:12:30.246041
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should set the attribute on the real object"""
    class Foo(object):
        def __init__(self):
            self.bar = None
    scope = {}
    def factory(self, scope, name):
        return Foo()
    replacer = ScopeReplacer(scope, factory, 'foo')
    replacer.bar = 'baz'
    assert scope['foo'].bar == 'baz'

# Generated at 2022-06-18 04:12:56.235510
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s == 'msg'

# Generated at 2022-06-18 04:13:04.518037
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            class Foo(object):
                def __init__(self):
                    self.bar = None
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            foo = ScopeReplacer(scope, factory, name)
            foo.bar = 'baz'
            self.assertEqual('baz', foo.bar)
    TestScopeReplacer('test_ScopeReplacer___setattr__').run()

# Generated at 2022-06-18 04:13:07.399115
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:13:10.340053
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:13:18.617979
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    import bzrlib.tests
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import

# Generated at 2022-06-18 04:13:27.146019
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___call__(self):
            import bzrlib.lazy_import
            import bzrlib.tests.blackbox.test_selftest
            import bzrlib.tests.blackbox.test_selftest
            import bzrlib.tests.blackbox.test_selftest
            import bzrlib.tests.blackbox.test_selftest
            import bzrlib.tests.blackbox.test_selftest
            import bzrlib.tests.blackbox.test_selftest
            import bzrlib.tests.blackbox.test_selftest
            import bzrlib.tests.blackbox.test_selftest
            import bzrlib