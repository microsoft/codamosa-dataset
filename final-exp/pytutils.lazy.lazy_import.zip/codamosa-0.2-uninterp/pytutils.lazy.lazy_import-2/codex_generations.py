

# Generated at 2022-06-18 04:03:45.028730
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:03:54.013566
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_lazy_import import FakeModule
    class TestScopeReplacer(TestCase):
        def test_setattr(self):
            scope = {}
            def factory(self, scope, name):
                return FakeModule(name)
            replacer = ScopeReplacer(scope, factory, 'foo')
            replacer.bar = 'baz'
            self.assertEqual('baz', replacer.bar)
            self.assertEqual('baz', scope['foo'].bar)

# Generated at 2022-06-18 04:03:56.472091
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:04:00.350613
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:04:08.672574
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Test(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return object()
            name = 'name'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.__setattr__('attr', 'value')
            self.assertEqual('value', scope_replacer.attr)
    Test().test_ScopeReplacer___setattr__()


# Generated at 2022-06-18 04:04:19.280010
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            class Foo(object):
                def __init__(self):
                    self.x = 1
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual(1, replacer.x)
            replacer.x = 2
            self.assertEqual(2, replacer.x)
            self.assertEqual(2, scope[name].x)

# Generated at 2022-06-18 04:04:26.443141
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    import sys
    class TestScopeReplacer(TestCase):
        def test_getattribute(self):
            class Foo(object):
                def __init__(self, a, b):
                    self.a = a
                    self.b = b
                def __getattribute__(self, attr):
                    if attr == 'a':
                        raise AttributeError(attr)
                    return object.__getattribute__(self, attr)
            def factory(self, scope, name):
                return Foo(1, 2)
            scope = {}
            name = 'foo'
            sr = ScopeReplacer(scope, factory, name)
            self.assertEqual(2, sr.b)
            self.assertRaises(AttributeError, getattr, sr, 'a')

# Generated at 2022-06-18 04:04:31.675218
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer

    class TestScopeReplacer(TestCase):

        def test_ScopeReplacer___setattr__(self):
            class Foo(object):
                pass
            foo = Foo()
            foo.bar = 'baz'
            scope = {}
            replacer = ScopeReplacer(scope, lambda x, y, z: foo, 'foo')
            replacer.bar = 'qux'
            self.assertEqual('qux', foo.bar)
            self.assertEqual('qux', replacer.bar)
            self.assertEqual('qux', scope['foo'].bar)
            self.assertRaises(IllegalUseOfScopeReplacer, setattr, replacer,
                              'bar', 'quux')

# Generated at 2022-06-18 04:04:36.110657
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False

# Generated at 2022-06-18 04:04:39.185977
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:05:30.937863
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'name was used incorrectly: msg'

# Generated at 2022-06-18 04:05:35.953973
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:05:47.523409
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False
    scope = sys._getframe(1).f_globals
    scope['foo'] = bzrlib.lazy_import.ScopeReplacer(scope, lambda x,y,z: x, 'foo')

# Generated at 2022-06-18 04:05:51.078931
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object."""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:06:02.119698
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return args, kwargs
            scope = {}
            name = 'foo'
            scope[name] = ScopeReplacer(scope, lambda self, scope, name: Foo(), name)
            self.assertEqual(scope[name](1, 2, 3), ((1, 2, 3), {}))
            self.assertEqual(scope[name](1, 2, 3, a=4, b=5), ((1, 2, 3), {'a':4, 'b':5}))
    test_ScopeReplacer___

# Generated at 2022-06-18 04:06:06.182091
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_setattr(self):
            class Foo(object):
                def __init__(self):
                    self.bar = None
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            foo = ScopeReplacer(scope, factory, name)
            foo.bar = 'baz'
            self.assertEqual('baz', foo.bar)
            self.assertEqual('baz', scope[name].bar)

# Generated at 2022-06-18 04:06:17.423727
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_

# Generated at 2022-06-18 04:06:21.355819
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object."""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode), type(u)

# Generated at 2022-06-18 04:06:28.551589
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import bzrlib.lazy_import
    import bzrlib.tests
    import bzrlib.tests.test_lazy_import
    def _factory(self, scope, name):
        return bzrlib.tests.test_lazy_import
    bzrlib.lazy_import.ScopeReplacer(sys.modules, _factory, 'bzrlib.tests.test_lazy_import')
    bzrlib.tests.test_lazy_import.test_ScopeReplacer___getattribute__()

# Generated at 2022-06-18 04:06:32.547755
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:06:54.252318
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer

    class TestScopeReplacer(TestCase):

        def test_setattr(self):
            class Foo(object):
                pass
            foo = Foo()
            foo.bar = 'bar'
            scope = {}
            def factory(self, scope, name):
                return foo
            replacer = ScopeReplacer(scope, factory, 'foo')
            replacer.bar = 'baz'
            self.assertEqual('baz', foo.bar)

    TestScopeReplacer().test_setattr()

# Generated at 2022-06-18 04:06:56.307602
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:07:01.540826
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_setattr_after_resolve(self):
            scope = {}
            def factory(self, scope, name):
                return object()
            replacer = ScopeReplacer(scope, factory, 'name')
            replacer.attr = 'value'
            self.assertEqual('value', replacer.attr)
            self.assertRaises(IllegalUseOfScopeReplacer, setattr, replacer,
                              'attr', 'value2')
    TestScopeReplacer('test_setattr_after_resolve').run()

# Generated at 2022-06-18 04:07:05.523215
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:07:08.466543
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s == 'IllegalUseOfScopeReplacer(name, msg)'

# Generated at 2022-06-18 04:07:19.978945
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    # This test is needed because the __str__ method of
    # IllegalUseOfScopeReplacer is overridden.
    # The __str__ method of IllegalUseOfScopeReplacer is overridden
    # because it is used in a traceback.
    # The traceback module calls str() on the exception object.
    # The __str__ method of IllegalUseOfScopeReplacer must return a str
    # object.
    # The __str__ method of IllegalUseOfScopeReplacer must not return a
    # unicode object.
    # The __str__ method of IllegalUseOfScopeReplacer must not raise an
    # exception.
    # The __str__ method of IllegalUseOfScopeReplacer must return a string
    # that contains the exception message.
    # The __str__ method of IllegalUseOf

# Generated at 2022-06-18 04:07:22.028748
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:07:32.931846
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return 'real_obj'
            name = 'name'
            obj = ScopeReplacer(scope, factory, name)
            obj.attr = 'value'
            self.assertEqual('value', obj.attr)
            self.assertEqual('value', scope['name'].attr)
            self.assertEqual('real_obj', scope['name']._real_obj)
    TestScopeReplacer('test_ScopeReplacer___setattr__').run()

# Generated at 2022-06-18 04:07:36.667791
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False
    try:
        import bzrlib.tests.test_lazy_import
        bzrlib.tests.test_lazy_import.test_ScopeReplacer___getattribute__()
    finally:
        bzrlib.lazy_import.ScopeReplacer._should_proxy = True

# Generated at 2022-06-18 04:07:40.062998
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:08:12.146466
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__() should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg"

# Generated at 2022-06-18 04:08:15.488926
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:08:23.864983
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # test_ScopeReplacer___setattr__()
    # Test that __setattr__ works as expected.
    class Foo(object):
        def __init__(self):
            self.bar = None
    foo = Foo()
    scope = {}
    def factory(self, scope, name):
        return foo
    replacer = ScopeReplacer(scope, factory, 'foo')
    replacer.bar = 'baz'
    assert foo.bar == 'baz'
    assert replacer.bar == 'baz'
    assert scope['foo'].bar == 'baz'
    assert scope['foo'].bar == replacer.bar
    assert scope['foo'].bar == foo.bar
    assert scope['foo'].bar == replacer.bar
    assert scope['foo'].bar == foo.bar

# Generated at 2022-06-18 04:08:29.013822
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'ScopeReplacer object \'name\' was used incorrectly: msg: extra'

# Generated at 2022-06-18 04:08:30.832097
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg"

# Generated at 2022-06-18 04:08:32.860335
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__(self, attr, value)"""
    # TODO: implement this test
    pass

# Generated at 2022-06-18 04:08:35.604832
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:08:44.082642
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            from bzrlib.lazy_import import lazy_import, ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return args, kwargs
            foo = Foo()
            scope = {}
            lazy_import(scope, 'foo = Foo()')
            self.assertEqual(scope['foo'], foo)
            self.assertIsInstance(scope['foo'], ScopeReplacer)
            self.assertEqual(scope['foo'](1, 2, 3), ((1, 2, 3), {}))
    Test('test_ScopeReplacer___call__').run()


# Generated at 2022-06-18 04:08:49.354527
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should set the attribute on the real object."""
    scope = {}
    def factory(self, scope, name):
        return object()
    obj = ScopeReplacer(scope, factory, 'obj')
    obj.foo = 'bar'
    assert obj.foo == 'bar'
    assert scope['obj'].foo == 'bar'



# Generated at 2022-06-18 04:08:53.371366
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:09:37.586288
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:09:40.414360
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:09:42.346765
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:09:46.105459
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:09:49.537607
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return unicode"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:09:52.484606
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:09:55.871739
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:10:05.926288
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Test:
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            scope = {}
            def factory(self, scope, name):
                return Test()
            name = 'test'
            scope[name] = ScopeReplacer(scope, factory, name)
            self.assertEqual(((), {}), scope[name]())
            self.assertEqual(((1,), {}), scope[name](1))
            self.assertEqual(((1, 2), {}), scope[name](1, 2))

# Generated at 2022-06-18 04:10:10.746459
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__() should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg"

# Generated at 2022-06-18 04:10:21.807071
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    # Test that __str__() returns a str object
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    # Test that __str__() returns a unicode object
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)
    # Test that __str__() returns a str object
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    # Test that __str__() returns a unicode object
    e = IllegalUseOfScopeReplacer('name', 'msg')

# Generated at 2022-06-18 04:11:22.890830
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:11:25.958949
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:11:30.072414
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)



# Generated at 2022-06-18 04:11:38.207877
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            foo = Foo()
            scope = {}
            def factory(self, scope, name):
                return foo
            name = 'foo'
            scope_replacer = ScopeReplacer(scope, factory, name)
            args = (1, 2, 3)
            kwargs = {'a': 1, 'b': 2}
            self.assertEqual((args, kwargs), scope_replacer(*args, **kwargs))
    Test('test_ScopeReplacer___call__').run

# Generated at 2022-06-18 04:11:42.033538
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:11:53.372395
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer

    class TestScopeReplacer(TestCase):

        def test_setattr(self):
            scope = {}
            def factory(self, scope, name):
                return object()
            name = 'name'
            replacer = ScopeReplacer(scope, factory, name)
            self.assertRaises(IllegalUseOfScopeReplacer,
                              replacer.__setattr__, '_real_obj', None)
            self.assertRaises(IllegalUseOfScopeReplacer,
                              replacer.__setattr__, '_name', 'new_name')
            self.assertRaises(IllegalUseOfScopeReplacer,
                              replacer.__setattr__, '_factory', factory)
            self

# Generated at 2022-06-18 04:11:56.012067
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:12:07.533780
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    class Foo(object):
        def __init__(self, value):
            self.value = value
    def factory(replacer, scope, name):
        return Foo(replacer)
    scope = {}
    replacer = ScopeReplacer(scope, factory, 'foo')
    assert replacer.value is replacer
    assert scope['foo'].value is replacer
    assert scope['foo'].value.value is replacer
    assert scope['foo'].value.value.value is replacer
    assert scope['foo'].value.value.value.value is replacer
    assert scope['foo'].value.value.value.value.value is replacer
    assert scope['foo'].value.value.value.value.value.value is replacer

# Generated at 2022-06-18 04:12:16.990056
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self, value):
            self.value = value
    class TestScopeReplacer(TestCase):
        def test_setattr(self):
            scope = {}
            def factory(self, scope, name):
                return TestObj(name)
            replacer = ScopeReplacer(scope, factory, 'test_obj')
            self.assertEqual('test_obj', replacer.value)
            replacer.value = 'new_value'
            self.assertEqual('new_value', replacer.value)

# Generated at 2022-06-18 04:12:28.194156
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False