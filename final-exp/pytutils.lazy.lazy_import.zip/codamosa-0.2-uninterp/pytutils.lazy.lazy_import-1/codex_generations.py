

# Generated at 2022-06-18 04:03:40.805076
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:03:51.894767
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    def _factory(self, scope, name):
        return scope[name]
    lazy_import(sys.modules[__name__].__dict__, '''
    import bzrlib
    ''')
    try:
        bzrlib.__getattribute__('_resolve')
    except AttributeError:
        pass
    else:
        raise AssertionError
    try:
        bzrlib.__getattribute__('_factory')
    except AttributeError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-18 04:04:02.690987
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            import bzrlib.lazy_import
            import bzrlib.tests.blackbox.test_selftest
            bzrlib.lazy_import.ScopeReplacer._should_proxy = False
            try:
                bzrlib.tests.blackbox.test_selftest.test_selftest()
            except bzrlib.lazy_import.IllegalUseOfScopeReplacer as e:
                self.assertEqual(
                    "ScopeReplacer object 'test_selftest' was used incorrectly:"
                    " Object already replaced, did you assign it to another"
                    " variable?",
                    str(e))

# Generated at 2022-06-18 04:04:06.499460
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:04:12.776937
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False
    try:
        import bzrlib.tests.blackbox.test_selftest
        bzrlib.tests.blackbox.test_selftest.test_selftest_command.test_selftest_command()
    finally:
        bzrlib.lazy_import.ScopeReplacer._should_proxy = True



# Generated at 2022-06-18 04:04:16.598356
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:04:19.166057
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:04:26.372877
# Unit test for method __eq__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___eq__():
    """Unit test for method __eq__ of class IllegalUseOfScopeReplacer"""
    class Foo(IllegalUseOfScopeReplacer):
        pass
    a = Foo('a', 'b', 'c')
    b = Foo('a', 'b', 'c')
    c = Foo('a', 'b', 'd')
    d = Foo('a', 'b')
    e = Foo('a', 'b', 'c', 'd')
    assert a == b
    assert a != c
    assert a != d
    assert a != e
    assert a != 'a'
    assert a != object()
    assert a != None
    assert a != 1
    assert a != 1.0

# Generated at 2022-06-18 04:04:28.281912
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:04:36.916031
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # __getattribute__(self, attr)
    # Test that __getattribute__ works as expected.
    # This test is a bit tricky because we need to test that the object
    # is replaced in the scope, but we can't use the object itself to
    # check that.
    import sys
    import bzrlib.lazy_import
    bzrlib.lazy_import._scope_replacer_test_mode = True

# Generated at 2022-06-18 04:04:59.478984
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___getattribute__(self):
            import sys
            class Foo(object):
                pass
            foo = Foo()
            foo.bar = 'bar'
            scope = sys._getframe(0).f_locals
            scope['foo'] = foo
            scope['Foo'] = Foo
            scope['ScopeReplacer'] = ScopeReplacer
            scope['test_ScopeReplacer___getattribute__'] = \
                test_ScopeReplacer___getattribute__
            scope['TestScopeReplacer'] = TestScopeReplacer
            scope['TestCase'] = TestCase
            scope['self'] = self
            scope['sys'] = sys
            scope['__name__'] = '__main__'
            scope['__file__']

# Generated at 2022-06-18 04:05:02.934717
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = e.__unicode__()
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:05:11.295089
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self):
            self.a = 1
    class TestCase(TestCase):
        def test_setattr(self):
            obj = TestObj()
            scope = {}
            replacer = ScopeReplacer(scope, lambda x, y, z: obj, 'obj')
            replacer.a = 2
            self.assertEqual(2, obj.a)
            self.assertEqual(2, scope['obj'].a)
    TestCase.run_tests()

# Generated at 2022-06-18 04:05:21.362583
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import, ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return args, kwargs
            foo = Foo()
            scope = {}
            lazy_import(scope, 'foo = Foo()')
            self.assertIsInstance(scope['foo'], ScopeReplacer)
            self.assertEqual(((1, 2), {'a': 3}), scope['foo'](1, 2, a=3))
            self.assertEqual(foo, scope['foo'])
    return TestScopeReplacer('test___call__')



# Generated at 2022-06-18 04:05:24.594297
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:05:31.827946
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            scope = {}
            def factory(self, scope, name):
                return 'foo'
            name = 'bar'
            scope_replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual('foo', scope_replacer())

# Generated at 2022-06-18 04:05:43.534834
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self, value):
            self.value = value
    class TestCase(TestCase):
        def test_getattribute(self):
            scope = {}
            obj = TestObj(1)
            def factory(self, scope, name):
                return obj
            replacer = ScopeReplacer(scope, factory, 'obj')
            self.assertEqual(1, replacer.value)
            self.assertEqual(1, scope['obj'].value)
            self.assertEqual(1, replacer.value)
            self.assertEqual(1, scope['obj'].value)
            self.assertEqual(1, replacer.value)
            self

# Generated at 2022-06-18 04:05:47.241919
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:05:51.132289
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:05:56.514195
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == 'name: msg'

# Generated at 2022-06-18 04:06:09.488739
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:06:18.819932
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Test(TestCase):
        def test_setattr(self):
            class Foo(object):
                def __init__(self):
                    self.bar = None
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.bar = 'baz'
            self.assertEqual('baz', scope_replacer.bar)
            self.assertEqual('baz', scope[name].bar)
    Test().test_setattr()

# Generated at 2022-06-18 04:06:26.933701
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    import sys
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = sys._getframe(1).f_locals
            name = 'foo'
            scope[name] = ScopeReplacer(scope, lambda self, scope, name: self, name)
            scope[name].foo = 'bar'
            self.assertEqual('bar', scope[name].foo)
    test_ScopeReplacer___setattr__.__test__ = False

# Generated at 2022-06-18 04:06:33.435851
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.lazy_import import _ScopeReplacerTestHelper
    from bzrlib.lazy_import import _ScopeReplacerTestHelper2
    from bzrlib.lazy_import import _ScopeReplacerTestHelper3
    from bzrlib.lazy_import import _ScopeReplacerTestHelper4
    from bzrlib.lazy_import import _ScopeReplacerTestHelper5
    from bzrlib.lazy_import import _ScopeReplacerTestHelper6
    from bzrlib.lazy_import import _ScopeReplacerTest

# Generated at 2022-06-18 04:06:36.756375
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:06:41.664819
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:06:52.131097
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class TestClass(object):
                def __init__(self, *args, **kwargs):
                    self.args = args
                    self.kwargs = kwargs
                def __call__(self, *args, **kwargs):
                    self.args = args
                    self.kwargs = kwargs
            test_class = TestClass()
            scope = {}
            scope_replacer = ScopeReplacer(scope, lambda self, scope, name: test_class, 'test_class')
            self.assertEqual(scope_replacer.__call__(), None)

# Generated at 2022-06-18 04:06:56.339202
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()"""
    # This test is needed because IllegalUseOfScopeReplacer.__unicode__()
    # is not trivial.
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'ScopeReplacer object \'name\' was used incorrectly: msg: extra'



# Generated at 2022-06-18 04:07:00.826071
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    class Foo(object):
        def __init__(self):
            self.bar = None
    scope = {}
    def factory(self, scope, name):
        return Foo()
    name = 'foo'
    scope_replacer = ScopeReplacer(scope, factory, name)
    scope_replacer.bar = 'baz'
    assert scope_replacer.bar == 'baz'
    assert scope['foo'].bar == 'baz'

# Generated at 2022-06-18 04:07:05.510821
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:07:26.138318
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_ScopeReplacer___setattr__(self):
            from bzrlib.lazy_import import ScopeReplacer
            from bzrlib.lazy_import import IllegalUseOfScopeReplacer
            class Foo(object):
                def __init__(self):
                    self.a = 1
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            foo = ScopeReplacer(scope, factory, name)
            foo.a = 2
            self.assertEqual(2, foo.a)
            self.assertRaises(IllegalUseOfScopeReplacer, setattr, foo, 'a', 3)
    Test().test_ScopeReplacer___setattr__()
# Unit test

# Generated at 2022-06-18 04:07:30.675526
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:07:33.446750
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:07:42.724830
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    # Check that the lazy objects have been replaced by the real objects
    assert isinstance(errors, bzrlib.errors.BzrError)
    assert isinstance(osutils, bzrlib.osutils.OSUtils)
    assert isinstance(branch, bzrlib.branch.Branch)
    assert isinstance(bzrlib, sys.modules['bzrlib'])
    # Check that the lazy objects are still available in the scope
    assert 'errors' in globals()

# Generated at 2022-06-18 04:07:53.664678
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            class Foo(object):
                def __init__(self):
                    self.x = 1
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            foo = ScopeReplacer(scope, factory, name)
            self.assertEqual(1, foo.x)
            foo.x = 2
            self.assertEqual(2, foo.x)
            self.assertEqual(2, scope[name].x)
            self.assertEqual(2, foo.x)

# Generated at 2022-06-18 04:08:03.783916
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            class Foo(object):
                def __init__(self, x):
                    self.x = x
            scope = {}
            def factory(self, scope, name):
                return Foo(self)
            name = 'foo'
            foo = ScopeReplacer(scope, factory, name)
            self.assertEqual(foo.x, foo)
            self.assertEqual(scope[name].x, scope[name])
    TestScopeReplacer('test_ScopeReplacer___setattr__').run()

# Generated at 2022-06-18 04:08:11.680687
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return args, kwargs
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            scope[name] = ScopeReplacer(scope, factory, name)
            self.assertEqual(((), {}), scope[name]())
            self.assertEqual(((1,), {}), scope[name](1))
            self.assertEqual(((1, 2), {}), scope[name](1, 2))

# Generated at 2022-06-18 04:08:20.694774
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    import bzrlib.tests
    ''')
    # test __call__
    # __call__ is a method of class ScopeReplacer
    # test __call__
    # __call__ is a method of class ScopeReplacer
    # test __call__
    # __call__ is a method of class ScopeReplacer
    # test __call__
    # __call__ is a method of class ScopeReplacer
    # test __call__
    # __call__ is a method of class ScopeReplacer
    # test __call__
    # __call__ is a method of class ScopeReplacer
    # test __call__
    # __call__ is a method of class ScopeReplacer
    # test

# Generated at 2022-06-18 04:08:25.948300
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object, not a unicode object."""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    assert isinstance(str(e), str)
    assert isinstance(unicode(e), unicode)

# Generated at 2022-06-18 04:08:29.992785
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:08:41.816556
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:08:44.921681
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:08:56.517163
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            foo = Foo()
            scope = {}
            def factory(self, scope, name):
                return foo
            name = 'foo'
            scope_replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual(((), {}), scope_replacer())
            self.assertEqual(((1, 2, 3), {}), scope_replacer(1, 2, 3))

# Generated at 2022-06-18 04:09:05.016193
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_setattr(self):
            class Foo(object):
                def __init__(self):
                    self.bar = None
            foo = Foo()
            scope = {'foo':foo}
            def factory(self, scope, name):
                return scope[name]
            replacer = ScopeReplacer(scope, factory, 'foo')
            replacer.bar = 'baz'
            self.assertEqual('baz', foo.bar)
    TestScopeReplacer('test_setattr').run()

# Generated at 2022-06-18 04:09:14.898644
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.lazy_import import _lazy_import_module
    from bzrlib.lazy_import import _lazy_import_module_from_path
    from bzrlib.lazy_import import _lazy_import_module_from_name
    from bzrlib.lazy_import import _lazy_import_module_from_path_and_name
    from bzrlib.lazy_import import _lazy_import_module_from_path_and_name_and_scope

# Generated at 2022-06-18 04:09:18.801904
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:09:21.884045
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:09:25.342024
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:09:34.501375
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __init__(self, a, b, c=None):
                    self.a = a
                    self.b = b
                    self.c = c
                def __call__(self, *args, **kwargs):
                    return (self.a, self.b, self.c, args, kwargs)
            scope = {}
            def factory(self, scope, name):
                return Foo(1, 2, 3)
            name = 'foo'
            scope[name] = ScopeReplacer(scope, factory, name)
            foo = scope[name]

# Generated at 2022-06-18 04:09:43.416132
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    import sys
    class TestScopeReplacer(TestCase):
        def test___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return 'real_obj'
            name = 'name'
            replacer = ScopeReplacer(scope, factory, name)
            replacer.attr = 'value'
            self.assertEqual('value', replacer.attr)
            self.assertEqual('value', scope[name].attr)
    # Unit test for method __getattribute__ of class ScopeReplacer
    def test_ScopeReplacer___getattribute__():
        from bzrlib.tests import TestCase
        import sys
        class TestScopeReplacer(TestCase):
            def test___getattribute__(self):
                scope = {}

# Generated at 2022-06-18 04:09:56.496901
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:10:07.201536
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()"""
    import sys
    if sys.version_info[0] < 3:
        # Python 2.x
        from bzrlib.lazy_import import IllegalUseOfScopeReplacer
        e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
        u = unicode(e)
        assert isinstance(u, unicode)
        assert u == u'ScopeReplacer object \'name\': msg: extra'
    else:
        # Python 3.x
        from bzrlib.lazy_import import IllegalUseOfScopeReplacer
        e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
        u = str(e)
        assert isinstance(u, str)

# Generated at 2022-06-18 04:10:18.616833
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__()"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    assert str(e) == 'bar'
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    assert str(e) == 'bar: baz'
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    e._fmt = '%(msg)s'
    assert str(e) == 'bar'
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    e._fmt = '%(msg)s %(extra)s'
    assert str(e) == 'bar baz'
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    e._fmt

# Generated at 2022-06-18 04:10:21.912751
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__(self, *args, **kwargs)"""
    # This is a stub implementation of ScopeReplacer.__call__
    # It may be replaced by a real implementation during test execution
    pass


# Generated at 2022-06-18 04:10:27.562963
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self):
            self.foo = 'bar'
    class TestScopeReplacer(TestCase):
        def test_setattr(self):
            scope = {}
            def factory(self, scope, name):
                return TestObj()
            replacer = ScopeReplacer(scope, factory, 'testobj')
            replacer.foo = 'baz'
            self.assertEqual('baz', replacer.foo)
            self.assertEqual('baz', scope['testobj'].foo)

# Generated at 2022-06-18 04:10:32.496301
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self):
            self.attr = None
    class TestCase(TestCase):
        def test_setattr(self):
            obj = TestObj()
            scope = {}
            def factory(self, scope, name):
                return obj
            replacer = ScopeReplacer(scope, factory, 'obj')
            replacer.attr = 'value'
            self.assertEqual('value', obj.attr)
            self.assertEqual(obj, scope['obj'])
    TestCase.run_tests()



# Generated at 2022-06-18 04:10:37.492428
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'name was used incorrectly: msg'

# Generated at 2022-06-18 04:10:48.513381
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import

# Generated at 2022-06-18 04:10:51.818305
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:10:56.519072
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg: extra"

# Generated at 2022-06-18 04:11:21.718736
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            def factory(self, scope, name):
                return lambda: 'foo'
            scope = {}
            name = 'foo'
            scope_replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual('foo', scope_replacer())
    TestScopeReplacer('test___call__').run()


# Generated at 2022-06-18 04:11:27.336280
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer___call__(TestCase):
        def test_ScopeReplacer___call__(self):
            import sys
            import bzrlib.lazy_import
            bzrlib.lazy_import.lazy_import(globals(), '''
            from bzrlib.lazy_import import ScopeReplacer
            ''')
            def factory(self, scope, name):
                def f(x):
                    return x
                return f
            scope = sys.modules
            name = 'f'
            scope_replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual(scope_replacer(1), 1)
    return TestScopeReplacer___call__



# Generated at 2022-06-18 04:11:32.865199
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            import bzrlib.lazy_import
            bzrlib.lazy_import.ScopeReplacer.__call__(None, None)
    Test('test_ScopeReplacer___call__').run()

# Generated at 2022-06-18 04:11:39.833099
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Foo(object):
        def __init__(self):
            self.x = 1
    class Bar(object):
        def __init__(self):
            self.x = 2
    class Test(TestCase):
        def test_setattr(self):
            scope = {}
            def factory(self, scope, name):
                return Foo()
            ScopeReplacer(scope, factory, 'foo')
            self.assertEqual(1, scope['foo'].x)
            scope['foo'].x = 2
            self.assertEqual(2, scope['foo'].x)
            def factory(self, scope, name):
                return Bar()
            ScopeReplacer(scope, factory, 'bar')


# Generated at 2022-06-18 04:11:51.818947
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self, value):
            self.value = value
        def __getattribute__(self, attr):
            if attr == 'value':
                return object.__getattribute__(self, attr)
            else:
                raise AttributeError(attr)
    class TestScopeReplacer(TestCase):
        def test_getattribute(self):
            scope = {}
            name = 'test_obj'
            def factory(self, scope, name):
                return TestObj(42)
            scope_replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual(42, scope_replacer.value)

# Generated at 2022-06-18 04:11:55.412594
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:12:07.427928
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    # Test that the __call__ method of ScopeReplacer works
    # as expected.
    #
    # This test is not very good, but it is better than nothing.
    #
    # The test is not very good because it does not test the
    # functionality of the __call__ method of ScopeReplacer.
    #
    # The test is not very good because it does not test the
    # functionality of the __call__ method of ScopeReplacer.
    #
    # The test is not very good because it does not test the

# Generated at 2022-06-18 04:12:18.095493
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return name
            name = 'name'
            obj = ScopeReplacer(scope, factory, name)
            self.assertEqual(obj._name, name)
            self.assertEqual(obj._scope, scope)
            self.assertEqual(obj._factory, factory)
            self.assertEqual(obj._real_obj, None)
            self.assertEqual(obj.__dict__, {})
            self.assertEqual(obj.__class__, ScopeReplacer)

# Generated at 2022-06-18 04:12:21.156267
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:12:24.265030
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:13:16.893362
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:13:18.878233
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:13:27.414234
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            # __call__() is a special method, so we need to test it
            # separately
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            scope = {}
            lazy_import(scope, '''
            from bzrlib.lazy_import import ScopeReplacer
            ''')
            ScopeReplacer(scope, lambda self, scope, name: Foo(), 'foo')
            self.assertEqual(((1, 2), {'a': 3}), scope['foo'](1, 2, a=3))
    TestScopeReplacer('test___call__').run()

