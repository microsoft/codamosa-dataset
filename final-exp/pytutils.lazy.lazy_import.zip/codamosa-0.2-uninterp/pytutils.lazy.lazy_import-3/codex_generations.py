

# Generated at 2022-06-18 04:03:42.812996
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:03:46.255845
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg"

# Generated at 2022-06-18 04:03:50.781643
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:03:57.832369
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            from bzrlib.lazy_import import lazy_import
            lazy_import(globals(), '''
            from bzrlib import (
                errors,
                osutils,
                branch,
                )
            import bzrlib.branch
            ''')
            self.assertEqual(osutils.sha_string('foo'), '0beec7b5ea3f0fdbc95d0dd47f3c5bc275da8a33')
            self.assertEqual(branch.Branch.open('.').base, '.')
    Test('test_ScopeReplacer___call__').run()


# Generated at 2022-06-18 04:04:01.061363
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:04:04.001824
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:04:15.880689
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            class Foo(object):
                def __init__(self, x):
                    self.x = x
            def factory(self, scope, name):
                return Foo(1)
            scope = {}
            name = 'foo'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.x = 2
            self.assertEqual(2, scope_replacer.x)
            self.assertEqual(2, scope[name].x)
    TestScopeReplacer('test_ScopeReplacer___setattr__').run()

# Generated at 2022-06-18 04:04:26.008212
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            class Foo(object):
                def __init__(self):
                    self.bar = None
            foo = Foo()
            scope = {}
            def factory(self, scope, name):
                return foo
            name = 'foo'
            replacer = ScopeReplacer(scope, factory, name)
            replacer.bar = 'baz'
            self.assertEqual('baz', foo.bar)
            self.assertEqual('baz', replacer.bar)
    TestScopeReplacer('test_ScopeReplacer___setattr__').run()

# Generated at 2022-06-18 04:04:29.175433
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:04:32.963969
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg: extra"

# Generated at 2022-06-18 04:04:54.556029
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    class TestObj(object):
        def __init__(self, name):
            self.name = name
        def __getattribute__(self, attr):
            if attr == 'name':
                return object.__getattribute__(self, attr)
            raise AttributeError(attr)
    class TestCaseWithScopeReplacer(TestCase):
        def setUp(self):
            TestCase.setUp(self)
            self.scope = {}
            self.name = 'test_obj'
            self.obj = TestObj(self.name)
            self.replacer = ScopeReplacer(self.scope,
                                          lambda self, scope, name: self.obj,
                                          self.name)

# Generated at 2022-06-18 04:04:57.496514
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:05:08.696402
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should raise an exception if the object has already been
    replaced.
    """
    from bzrlib.tests import TestCase
    class TestScopeReplacer(ScopeReplacer):
        def __init__(self, scope, factory, name):
            super(TestScopeReplacer, self).__init__(scope, factory, name)
            self.foo = 'bar'
    scope = {}
    def factory(self, scope, name):
        return self
    replacer = TestScopeReplacer(scope, factory, 'replacer')
    self.assertEqual('bar', replacer.foo)
    replacer.foo = 'baz'
    self.assertEqual('baz', replacer.foo)
    # Now disable proxying
    ScopeReplacer._should_proxy = False

# Generated at 2022-06-18 04:05:18.746805
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            class Foo(object):
                def __init__(self, value):
                    self.value = value
            def factory(self, scope, name):
                return Foo(42)
            scope = {}
            name = 'foo'
            foo = ScopeReplacer(scope, factory, name)
            foo.value = 43
            self.assertEqual(43, foo.value)
            self.assertEqual(43, scope[name].value)
    TestScopeReplacer('test_ScopeReplacer___setattr__').run()

# Generated at 2022-06-18 04:05:24.507318
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self):
            self.x = 1
    class TestCase(TestCase):
        def test_setattr(self):
            scope = {}
            def factory(self, scope, name):
                return TestObj()
            replacer = ScopeReplacer(scope, factory, 'test')
            replacer.x = 2
            self.assertEqual(2, replacer.x)
            self.assertEqual(2, scope['test'].x)
    TestCase.run_tests()

# Generated at 2022-06-18 04:05:32.046998
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            import bzrlib.lazy_import
            import bzrlib.tests.blackbox
            bzrlib.lazy_import.lazy_import(globals(), '''
            import bzrlib.tests.blackbox
            ''')
            self.assertEqual(bzrlib.tests.blackbox.TestCase, TestCase)
    Test('test_ScopeReplacer___call__').run()

# Generated at 2022-06-18 04:05:43.579153
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_

# Generated at 2022-06-18 04:05:52.005279
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer

    class TestScopeReplacer(TestCase):

        def test_ScopeReplacer___setattr__(self):
            class Foo(object):
                def __init__(self):
                    self.bar = None
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.bar = 'baz'
            self.assertEqual('baz', scope_replacer.bar)
            self.assertEqual('baz', scope['foo'].bar)

    TestScopeReplacer('test_ScopeReplacer___setattr__').run()

# Generated at 2022-06-18 04:05:58.075159
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should set attributes on the real object"""
    class Foo(object):
        def __init__(self):
            self.bar = None
    scope = {}
    def factory(self, scope, name):
        return Foo()
    replacer = ScopeReplacer(scope, factory, 'foo')
    replacer.bar = 'baz'
    assert scope['foo'].bar == 'baz'

# Generated at 2022-06-18 04:06:05.551267
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_setattr(self):
            class Foo(object):
                def __init__(self):
                    self.bar = 'baz'
            scope = {}
            def factory(self, scope, name):
                return Foo()
            replacer = ScopeReplacer(scope, factory, 'foo')
            self.assertEqual('baz', replacer.bar)
            replacer.bar = 'qux'
            self.assertEqual('qux', replacer.bar)
    Test().run()

# Generated at 2022-06-18 04:06:21.914578
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    assert isinstance(unicode(e), unicode)
    assert unicode(e) == u'foo was used incorrectly: bar'
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    assert isinstance(unicode(e), unicode)
    assert unicode(e) == u'foo was used incorrectly: bar: baz'
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    e._preformatted_string = 'baz'
    assert isinstance(unicode(e), unicode)
    assert unicode(e) == u'baz'

# Generated at 2022-06-18 04:06:25.338829
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:06:32.570832
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __init__(self, *args, **kwargs):
                    self.args = args
                    self.kwargs = kwargs
                def __call__(self, *args, **kwargs):
                    return (self.args, self.kwargs, args, kwargs)
            scope = {}
            def factory(self, scope, name):
                return Foo(1, 2, 3, a=1, b=2, c=3)
            name = 'foo'
            scope[name] = ScopeReplacer(scope, factory, name)

# Generated at 2022-06-18 04:06:40.966420
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_lazy_import import TestLazyImport

    class TestScopeReplacer(TestCase):

        def test_ScopeReplacer___setattr__(self):
            # __setattr__ should be able to set attributes on the real object
            # once it has been created.
            def factory(self, scope, name):
                return object()
            scope = {}
            lazy_import(scope, '''
            from bzrlib.lazy_import import ScopeReplacer
            import bzrlib.tests.test_lazy_import
            ''')
            replacer = ScopeReplacer(scope, factory, 'replacer')
            replacer.foo = 'bar'

# Generated at 2022-06-18 04:06:49.348743
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer

    class TestScopeReplacer(TestCase):

        def test_setattr(self):
            class Foo(object):
                pass
            foo = Foo()
            foo.bar = 'bar'
            scope = {}
            def factory(self, scope, name):
                return foo
            replacer = ScopeReplacer(scope, factory, 'foo')
            replacer.bar = 'baz'
            self.assertEqual('baz', foo.bar)

    TestScopeReplacer().run_tests()

# Generated at 2022-06-18 04:06:50.859280
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:06:56.572895
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    class TestScopeReplacer(TestCase):
        def test_call(self):
            scope = {}
            lazy_import(scope, '''
            from bzrlib import (
                errors,
                osutils,
                branch,
                )
            import bzrlib.branch
            ''')
            self.assertEqual(scope['errors'].__class__, ScopeReplacer)
            self.assertEqual(scope['osutils'].__class__, ScopeReplacer)
            self.assertEqual(scope['branch'].__class__, ScopeReplacer)
            self.assertEqual(scope['bzrlib'].__class__, ScopeReplacer)

# Generated at 2022-06-18 04:06:59.523058
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg"

# Generated at 2022-06-18 04:07:02.063004
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:07:06.380368
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:07:19.978452
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should set attributes on the real object"""
    class Foo(object):
        pass
    scope = {}
    def factory(self, scope, name):
        return Foo()
    replacer = ScopeReplacer(scope, factory, 'foo')
    replacer.bar = 'baz'
    assert scope['foo'].bar == 'baz'

# Generated at 2022-06-18 04:07:26.961907
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    import sys
    if sys.version_info[0] == 2:
        # Python 2.x
        assert str(IllegalUseOfScopeReplacer('foo', 'bar')) == \
            "ScopeReplacer object 'foo' was used incorrectly: bar"
        assert str(IllegalUseOfScopeReplacer('foo', 'bar', 'baz')) == \
            "ScopeReplacer object 'foo' was used incorrectly: bar: baz"
    else:
        # Python 3.x
        assert str(IllegalUseOfScopeReplacer('foo', 'bar')) == \
            "ScopeReplacer object 'foo' was used incorrectly: bar"

# Generated at 2022-06-18 04:07:31.978688
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:07:35.473610
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s == 'name: msg'

# Generated at 2022-06-18 04:07:43.550586
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test___setattr__(self):
            class TestClass(object):
                def __init__(self):
                    self.foo = 'bar'
            scope = {}
            def factory(self, scope, name):
                return TestClass()
            name = 'test'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.foo = 'baz'
            self.assertEqual('baz', scope_replacer.foo)
            self.assertEqual('baz', scope[name].foo)
    TestScopeReplacer('test___setattr__').run()

# Generated at 2022-06-18 04:07:47.512712
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    s = str(e)
    assert isinstance(s, str)
    assert s == 'foo: bar'

# Generated at 2022-06-18 04:07:55.142430
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            class Foo(object):
                def __init__(self):
                    self.foo = None
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.foo = 'bar'
            self.assertEqual('bar', scope_replacer.foo)
    TestScopeReplacer('test_ScopeReplacer___setattr__').run()

# Generated at 2022-06-18 04:08:05.485065
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer

    class TestScopeReplacer(TestCase):

        def test_ScopeReplacer___setattr__(self):
            class TestClass(object):
                def __init__(self):
                    self.attr = None
            scope = {}
            def factory(self, scope, name):
                return TestClass()
            name = 'test_class'
            scope_replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual(scope_replacer._real_obj, None)
            scope_replacer.attr = 'test'
            self.assertEqual(scope_replacer._real_obj.attr, 'test')
            self.assertEqual(scope[name].attr, 'test')
    return Test

# Generated at 2022-06-18 04:08:09.593123
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:08:15.082489
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    class Test(TestCase):
        def test_call(self):
            def factory(self, scope, name):
                return lambda: 'called'
            scope = {}
            lazy_import(scope, '''
            from bzrlib.lazy_import import ScopeReplacer
            ''')
            scope['test'] = ScopeReplacer(scope, factory, 'test')
            self.assertEqual('called', scope['test']())
    test_suite = Test.make_test_suite()
    return test_suite

# Generated at 2022-06-18 04:08:26.092071
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:08:34.065238
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Test(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return "foo"
            name = "bar"
            x = ScopeReplacer(scope, factory, name)
            x.baz = "baz"
            self.assertEqual(x.baz, "baz")
            self.assertEqual(x._real_obj, "foo")
            self.assertEqual(scope["bar"], "foo")

# Generated at 2022-06-18 04:08:37.245719
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'name was used incorrectly: msg'


# Generated at 2022-06-18 04:08:41.514182
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg"

# Generated at 2022-06-18 04:08:48.438719
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self):
            self.attr = None
    class TestCase(TestCase):
        def test_setattr(self):
            scope = {}
            def factory(self, scope, name):
                return TestObj()
            obj = ScopeReplacer(scope, factory, 'obj')
            obj.attr = 'value'
            self.assertEqual('value', scope['obj'].attr)
    TestCase.run_tests()

# Generated at 2022-06-18 04:08:59.140578
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # __call__(self, *args, **kwargs)
    # Calling a ScopeReplacer should call the real object
    import sys
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    # Calling a ScopeReplacer should call the real object
    # Calling a ScopeReplacer should call the real object
    # Calling a ScopeReplacer should call the real object
    # Calling a ScopeReplacer should call the real object
    # Calling a ScopeReplacer should call the real object
    # Calling a ScopeReplacer should call the real object
    # Calling a ScopeReplacer should call the real object


# Generated at 2022-06-18 04:09:10.881545
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_setattr(self):
            # Test that __setattr__ works correctly
            lazy_import(globals(), '''
            from bzrlib import (
                errors,
                osutils,
                branch,
                )
            import bzrlib.branch
            ''')
            self.assertIsInstance(errors, ScopeReplacer)
            self.assertIsInstance(osutils, ScopeReplacer)
            self.assertIsInstance(branch, ScopeReplacer)
            self.assertIsInstance(bzrlib, ScopeReplacer)
            # Check that __setattr__ works correctly
            errors.foo = 'bar'

# Generated at 2022-06-18 04:09:13.210572
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:09:23.689110
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class TestClass(object):
                def __init__(self, *args, **kwargs):
                    self.args = args
                    self.kwargs = kwargs
                def __call__(self, *args, **kwargs):
                    return self.args, self.kwargs, args, kwargs
            scope = {}
            def factory(self, scope, name):
                return TestClass('a', 'b', 'c', d='e', f='g')
            replacer = ScopeReplacer(scope, factory, 'test')
            self.assertEqual(('a', 'b', 'c'), replacer.args)


# Generated at 2022-06-18 04:09:28.447859
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:09:43.947277
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __init__(self, a, b, c):
                    self.a = a
                    self.b = b
                    self.c = c
                def __call__(self, *args, **kwargs):
                    return (self.a, self.b, self.c, args, kwargs)
            scope = {}
            def factory(self, scope, name):
                return Foo(1, 2, 3)
            name = 'foo'
            obj = ScopeReplacer(scope, factory, name)
            self.assertEqual((1, 2, 3, (), {}), obj())
            self

# Generated at 2022-06-18 04:09:46.424339
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:09:54.497657
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    import sys
    def factory(self, scope, name):
        return 'real'
    scope = {}
    name = 'name'
    scope_replacer = ScopeReplacer(scope, factory, name)
    scope_replacer.__getattribute__('_resolve')()
    scope_replacer.__getattribute__('_resolve')()
    scope_replacer.__getattribute__('_resolve')()
    scope_replacer.__getattribute__('_resolve')()
    scope_replacer.__getattribute__('_resolve')()
    scope_replacer.__getattribute__('_resolve')()

# Generated at 2022-06-18 04:10:04.862381
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    # Test that calling a lazy object works
    osutils.dirname('/foo/bar')
    # Test that calling a lazy object that has already been replaced works
    osutils.dirname('/foo/bar')
    # Test that calling a lazy object that has already been replaced works
    # even when the object has been assigned to another variable
    x = osutils
    x.dirname('/foo/bar')
    # Test that calling a lazy object that has already been replaced works
    # even when the object has been assigned to another variable and the
    # original variable

# Generated at 2022-06-18 04:10:08.596815
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:10:18.464902
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self):
            self.attr = None
    class TestCase(TestCase):
        def test_setattr(self):
            obj = TestObj()
            scope = {}
            def factory(self, scope, name):
                return obj
            replacer = ScopeReplacer(scope, factory, 'obj')
            replacer.attr = 'value'
            self.assertEqual('value', obj.attr)
            self.assertEqual('value', scope['obj'].attr)
    TestCase.run_tests()

# Generated at 2022-06-18 04:10:22.906455
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg: extra"


# Generated at 2022-06-18 04:10:31.389848
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = True
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = True
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = True
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False
   

# Generated at 2022-06-18 04:10:40.728495
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.tests import TestCase
    from bzrlib.tests import TestSkipped
    from bzrlib.tests import TestUtil
    from bzrlib.tests import TestCaseWithTransport
    from bzrlib.tests import TestCaseWithMemoryTransport
    from bzrlib.tests import TestCaseWithMemoryTree
    from bzrlib.tests import TestCaseWithMemoryTransport
    from bzrlib.tests import TestCaseWithTransport
    from bzrlib.tests import TestCaseWithMemoryTransport

# Generated at 2022-06-18 04:10:52.108359
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import, ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            class Foo(object):
                pass
            foo = Foo()
            foo.bar = 'baz'
            scope = {}
            lazy_import(scope, 'foo', 'foo')
            self.assertEqual('baz', scope['foo'].bar)
            scope['foo'].bar = 'qux'
            self.assertEqual('qux', scope['foo'].bar)
            self.assertEqual('qux', foo.bar)
            self.assertEqual('qux', scope['foo'].bar)
            self.assertEqual('qux', foo.bar)

# Generated at 2022-06-18 04:11:02.361697
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:11:11.038768
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Test(TestCase):
        def test_setattr(self):
            scope = {}
            def factory(self, scope, name):
                return 'foo'
            name = 'bar'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.foo = 'bar'
            self.assertEqual('bar', scope_replacer.foo)
            self.assertEqual('bar', scope['bar'].foo)
    Test('test_setattr').run()

# Generated at 2022-06-18 04:11:14.969451
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:11:22.852697
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    # Test that __call__ works.
    class Foo(object):
        def __call__(self, *args, **kwargs):
            return (args, kwargs)
    foo = Foo()
    scope = {}
    lazy_foo = ScopeReplacer(scope, lambda self, scope, name: foo, 'foo')
    assert lazy_foo(1, 2, 3, a=4, b=5, c=6) == ((1, 2, 3), {'a': 4, 'b': 5, 'c': 6})
    assert scope['foo'] is foo
    # Test that __call__ works when the object is already resolved.
    scope = {}
    lazy_foo = ScopeReplacer(scope, lambda self, scope, name: foo, 'foo')
    scope['foo'] = foo

# Generated at 2022-06-18 04:11:33.926790
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            from bzrlib.lazy_import import ScopeReplacer
            from bzrlib.lazy_import import IllegalUseOfScopeReplacer
            class Foo(object):
                def __init__(self):
                    self.a = 1
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            scope[name] = ScopeReplacer(scope, factory, name)
            scope[name].a = 2
            self.assertEqual(2, scope[name].a)
            self.assertRaises(IllegalUseOfScopeReplacer,
                              setattr, scope[name], 'a', 3)
    Test

# Generated at 2022-06-18 04:11:44.426827
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __init__(self, a, b, c):
                    self.a = a
                    self.b = b
                    self.c = c
                def __call__(self, d, e, f):
                    return self.a, self.b, self.c, d, e, f
            def factory(self, scope, name):
                return Foo(1, 2, 3)
            scope = {}
            name = 'foo'
            scope_replacer = ScopeReplacer(scope, factory, name)

# Generated at 2022-06-18 04:11:55.616060
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), """
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    """)
    # Test that the lazy_import call above has created ScopeReplacer
    # objects in the globals() dict.
    assert isinstance(errors, bzrlib.lazy_import.ScopeReplacer)
    assert isinstance(osutils, bzrlib.lazy_import.ScopeReplacer)
    assert isinstance(branch, bzrlib.lazy_import.ScopeReplacer)
    assert isinstance(bzrlib, bzrlib.lazy_import.ScopeReplacer)
    # Test that the Scope

# Generated at 2022-06-18 04:12:07.475855
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            foo = Foo()
            foo_replacer = ScopeReplacer(locals(), lambda self, scope, name: foo, 'foo')
            self.assertEqual(((1, 2), {'a': 'b'}), foo_replacer(1, 2, a='b'))
    TestScopeReplacer('test___call__').run()

    def __getitem__(self, key):
        obj = object.__getattribute__(self, '_resolve')()

# Generated at 2022-06-18 04:12:09.518962
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:12:19.653671
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should behave like setattr"""
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = True
    class Foo(object):
        def __init__(self):
            self.bar = 'baz'
    scope = {}
    def factory(self, scope, name):
        return Foo()
    name = 'foo'
    foo = bzrlib.lazy_import.ScopeReplacer(scope, factory, name)
    foo.bar = 'quux'
    assert foo.bar == 'quux'
    assert scope[name].bar == 'quux'
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False
    foo.bar = 'quux2'

# Generated at 2022-06-18 04:12:44.347930
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Test(TestCase):
        def test_setattr(self):
            class Foo(object):
                def __init__(self):
                    self.x = 1
            scope = {}
            def factory(self, scope, name):
                return Foo()
            replacer = ScopeReplacer(scope, factory, 'foo')
            replacer.x = 2
            self.assertEqual(2, replacer.x)
            self.assertEqual(2, scope['foo'].x)
    Test('test_setattr').run()

# Generated at 2022-06-18 04:12:47.939779
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:12:50.455629
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:13:01.526644
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            class Foo(object):
                def __init__(self, a, b, c):
                    self.a = a
                    self.b = b
                    self.c = c
                def __call__(self, a, b, c):
                    return a, b, c
            def factory(self, scope, name):
                return Foo(1, 2, 3)
            scope = {}
            name = 'foo'
            foo = ScopeReplacer(scope, factory, name)
           

# Generated at 2022-06-18 04:13:09.419715
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False

# Generated at 2022-06-18 04:13:11.643889
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:13:15.508461
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object."""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:13:17.950233
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert isinstance(e.__unicode__(), unicode)