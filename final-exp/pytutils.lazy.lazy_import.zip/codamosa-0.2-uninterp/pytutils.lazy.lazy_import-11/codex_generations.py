

# Generated at 2022-06-18 04:03:46.415566
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self):
            self.test = None
    class TestCase(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return TestObj()
            obj = ScopeReplacer(scope, factory, 'test')
            obj.test = 'test'
            self.assertEqual('test', scope['test'].test)

# Generated at 2022-06-18 04:03:54.269639
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        pass
    class TestCase(TestCase):
        def test_setattr(self):
            scope = {}
            def factory(self, scope, name):
                return TestObj()
            replacer = ScopeReplacer(scope, factory, 'test')
            replacer.test = 'value'
            self.assertEqual('value', scope['test'].test)
    TestCase.run_tests()



# Generated at 2022-06-18 04:03:57.409749
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert isinstance(s, unicode)


# Generated at 2022-06-18 04:04:08.780692
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should raise an exception if the object has already been
    replaced.
    """
    scope = {}
    def factory(self, scope, name):
        return object()
    name = 'foo'
    replacer = ScopeReplacer(scope, factory, name)
    # The object has not been replaced yet, so this should be fine
    replacer.foo = 'bar'
    # Now we replace the object
    scope[name] = object()
    # And now we should get an exception

# Generated at 2022-06-18 04:04:11.997241
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:04:15.832066
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:04:26.300635
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    # Test that the method __call__ of class ScopeReplacer works as expected
    # when the object has been replaced.
    #
    # The following code is used to test the method __call__ of class
    # ScopeReplacer.
    #
    #     def f(x):
    #         return x
    #     f(1)
    #
    # The expected result is:
    #     1
    #
    # The actual result is:
    #     1
    #
    # The following code is used to test the method __call__ of

# Generated at 2022-06-18 04:04:30.450793
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Test(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return object()
            name = 'name'
            o = ScopeReplacer(scope, factory, name)
            o.foo = 'bar'
            self.assertEqual('bar', o.foo)
            self.assertEqual('bar', scope[name].foo)
    Test().test_ScopeReplacer___setattr__()

# Generated at 2022-06-18 04:04:32.924916
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:04:39.305955
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            scope[name] = ScopeReplacer(scope, factory, name)
            self.assertEqual(((), {}), scope[name]())
            self.assertEqual(((1, 2, 3), {'a': 1, 'b': 2}),
                             scope[name](1, 2, 3, a=1, b=2))
    TestScopeRepl

# Generated at 2022-06-18 04:04:54.868758
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:04:57.135756
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should set the attribute on the real object."""
    class Foo(object):
        def __init__(self):
            self.bar = None
    scope = {}
    replacer = ScopeReplacer(scope, lambda self, scope, name: Foo(), 'foo')
    replacer.bar = 'baz'
    assert scope['foo'].bar == 'baz'

# Generated at 2022-06-18 04:05:01.317586
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:05:07.297206
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    bzrlib.lazy_import._testing = True
    try:
        import bzrlib.tests
        bzrlib.tests.SyntheticTestCase.run_test_with_all_interleavings(
            test_ScopeReplacer___setattr__)
    finally:
        del bzrlib.lazy_import._testing



# Generated at 2022-06-18 04:05:10.968828
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:05:21.398934
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import bzrlib.lazy_import
    import bzrlib.lazy_import
    import bzrlib.lazy_import
    import bzrlib.lazy_import
    import bzrlib.lazy_import
    import bzrlib.lazy_import
    import bzrlib.lazy_import
    import bzrlib.lazy_import
    import bzrlib.lazy_import
    import bzrlib.lazy_import
    import bzrlib.lazy_import
    import bzrlib.lazy_import
    import bzrlib.lazy_import
    import bzrlib.lazy_import
    import bzrlib.lazy_import
    import bzrlib.lazy_import
    import b

# Generated at 2022-06-18 04:05:31.941750
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            from bzrlib.lazy_import import lazy_import
            from bzrlib.lazy_import import _lazy_import_module
            from bzrlib.lazy_import import _lazy_import_object
            from bzrlib.lazy_import import _lazy_import_symbol
            from bzrlib.lazy_import import _lazy_import_symbols
            from bzrlib.lazy_import import _lazy_import_submodule
            from bzrlib.lazy_import import _lazy_import_submodules

# Generated at 2022-06-18 04:05:39.543714
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should set the attribute on the real object"""
    class Foo(object):
        def __init__(self):
            self.bar = None
    scope = {}
    def factory(self, scope, name):
        return Foo()
    name = 'foo'
    foo = ScopeReplacer(scope, factory, name)
    foo.bar = 'baz'
    assert foo.bar == 'baz'
    assert scope[name].bar == 'baz'

# Generated at 2022-06-18 04:05:49.583413
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import bzrlib.lazy_import
    import bzrlib.tests
    import bzrlib.tests.blackbox
    import bzrlib.tests.blackbox.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest.test_selftest.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest.test_selftest.test_selftest.test_selftest
    import bzrlib.tests.blackbox.test_selft

# Generated at 2022-06-18 04:05:55.628936
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert isinstance(unicode(e), unicode)
    assert unicode(e) == u'ScopeReplacer object \'name\' was used incorrectly: msg: extra'

# Generated at 2022-06-18 04:06:08.544994
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert u == u'ScopeReplacer object \'name\' was used incorrectly: msg: extra'
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert u == u'ScopeReplacer object \'name\' was used incorrectly: msg'
    e = IllegalUseOfScopeReplacer('name', 'msg', None)
    u = unicode(e)
    assert u == u'ScopeReplacer object \'name\' was used incorrectly: msg'
    e = IllegalUseOfScopeReplacer('name', 'msg', '')
    u = unicode(e)

# Generated at 2022-06-18 04:06:17.394410
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self):
            self.foo = 'foo'
    class TestCase(TestCase):
        def test_set_attr(self):
            scope = {}
            def factory(self, scope, name):
                return TestObj()
            obj = ScopeReplacer(scope, factory, 'obj')
            obj.foo = 'bar'
            self.assertEqual('bar', scope['obj'].foo)
    TestCase.run_tests()

# Generated at 2022-06-18 04:06:26.036547
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            scope = {}
            def factory(self, scope, name):
                return lambda: 'foo'
            lazy_import(scope, '''
            from bzrlib.lazy_import import ScopeReplacer
            ''')
            scope['ScopeReplacer'](scope, factory, 'foo')
            self.assertEqual('foo', scope['foo']())
    TestScopeReplacer('test___call__').run()

# Generated at 2022-06-18 04:06:28.857860
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() should return a unicode object."""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:06:34.560443
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)
    assert u == u'ScopeReplacer object \'name\' was used incorrectly: msg'

# Generated at 2022-06-18 04:06:37.692070
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:06:43.127291
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should set attributes on the real object"""
    class Foo(object):
        pass
    scope = {}
    def factory(self, scope, name):
        return Foo()
    replacer = ScopeReplacer(scope, factory, 'foo')
    replacer.bar = 'baz'
    assert scope['foo'].bar == 'baz'

# Generated at 2022-06-18 04:06:46.604276
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:06:53.885399
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Test(TestCase):
        def test_setattr(self):
            scope = {}
            def factory(self, scope, name):
                return scope[name]
            scope['foo'] = 'bar'
            ScopeReplacer(scope, factory, 'foo')
            self.assertEqual('bar', scope['foo'])
            scope['foo'] = 'baz'
            self.assertEqual('baz', scope['foo'])
    Test('test_setattr').run()

# Generated at 2022-06-18 04:06:58.694858
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    import bzrlib.tests.test_lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    bzrlib.tests.test_lazy_import.test_ScopeReplacer___call__()



# Generated at 2022-06-18 04:07:15.996502
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:07:19.453747
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:07:26.400784
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return 'foo'
            name = 'bar'
            obj = ScopeReplacer(scope, factory, name)
            self.assertEqual('foo', obj)
            self.assertEqual('foo', scope['bar'])
            obj.baz = 'qux'
            self.assertEqual('qux', scope['bar'].baz)
    TestScopeReplacer('test_ScopeReplacer___setattr__').test_ScopeReplacer___setattr__()

# Generated at 2022-06-18 04:07:31.324867
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg"

# Generated at 2022-06-18 04:07:41.207413
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Foo(object):
        def __init__(self, name):
            self.name = name
        def __getattribute__(self, attr):
            if attr == 'name':
                return object.__getattribute__(self, attr)
            raise AttributeError(attr)
    class TestScopeReplacer(TestCase):
        def test___getattribute__(self):
            scope = {}
            def factory(self, scope, name):
                return Foo(name)
            ScopeReplacer(scope, factory, 'foo')
            self.assertEqual('foo', scope['foo'].name)
            self.assertRaises(AttributeError, getattr, scope['foo'], 'bar')
    TestScope

# Generated at 2022-06-18 04:07:52.475376
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            foo = Foo()
            scope = {}
            def factory(self, scope, name):
                return foo
            name = 'foo'
            replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual(((1, 2), {'a': 'b'}), replacer(1, 2, a='b'))
    TestScopeReplacer('test___call__').test___call__()

    # Test that the replacer is replaced with the real object

# Generated at 2022-06-18 04:08:01.747756
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test___setattr__(self):
            class Foo(object):
                def __init__(self):
                    self.a = 1
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            foo = ScopeReplacer(scope, factory, name)
            foo.a = 2
            self.assertEqual(2, foo.a)
    TestScopeReplacer('test___setattr__').run()

# Generated at 2022-06-18 04:08:04.921518
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:08:15.706107
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    # __str__ of IllegalUseOfScopeReplacer
    # This test comes from Martin Pool's bzrlib.tests.test_errors.TestErrors
    # It has been modified to use IllegalUseOfScopeReplacer instead of
    # BzrError.
    #
    # The test is in the public domain.
    #
    # Copyright (C) 2005-2006 Canonical Ltd
    #
    # This program is free software; you can redistribute it and/or modify
    # it under the terms of the GNU General Public License as published by
    # the Free Software Foundation; either version 2 of the License, or
    # (at your option) any later version.
    #
    # This program is distributed in the hope that it will be useful,
    # but WITHOUT ANY WARRANTY; without

# Generated at 2022-06-18 04:08:21.815557
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self):
            self.attr = None
    class TestScopeReplacer(TestCase):
        def test_setattr(self):
            obj = TestObj()
            scope = {}
            def factory(self, scope, name):
                return obj
            replacer = ScopeReplacer(scope, factory, 'obj')
            replacer.attr = 'value'
            self.assertEqual('value', obj.attr)
            self.assertEqual('value', scope['obj'].attr)

# Generated at 2022-06-18 04:09:08.462767
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:09:12.506721
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg"

# Generated at 2022-06-18 04:09:23.065275
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False

# Generated at 2022-06-18 04:09:25.706489
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:09:30.174204
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() returns a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:09:40.173537
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__(self, attr, value)"""
    # Test that __setattr__ raises an exception if the object has already
    # been replaced.
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    ScopeReplacer._should_proxy = False
    try:
        bzrlib.branch = 'foo'
    except IllegalUseOfScopeReplacer as e:
        assert e.name == 'bzrlib.branch'
        assert e.msg == "Object already replaced, did you assign it" \
                        " to another variable?"

# Generated at 2022-06-18 04:09:42.939733
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s == 'name: msg'

# Generated at 2022-06-18 04:09:45.869253
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:09:50.565195
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = e.__unicode__()
    assert isinstance(u, unicode)
    assert u == u'ScopeReplacer object \'name\' was used incorrectly: msg: extra'

# Generated at 2022-06-18 04:09:58.290726
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_setattr(self):
            scope = {}
            def factory(self, scope, name):
                return scope[name]
            replacer = ScopeReplacer(scope, factory, 'foo')
            replacer.bar = 'baz'
            self.assertEqual('baz', scope['foo'].bar)
    TestScopeReplacer('test_setattr').run()

# Generated at 2022-06-18 04:11:00.889446
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:11:04.180196
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:11:14.397722
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()

    This method is used to convert an exception to a unicode string.
    """
    # Test with a unicode format string
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    e._fmt = u'%(name)s: %(msg)s%(extra)s'
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'name: msgextra'
    # Test with a str format string
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    e._fmt = '%(name)s: %(msg)s%(extra)s'
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:11:17.250239
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert isinstance(s, unicode)


# Generated at 2022-06-18 04:11:19.650509
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests.blackbox.test_lazy_import
    bzrlib.tests.blackbox.test_lazy_import.test_ScopeReplacer___setattr__()

# Generated at 2022-06-18 04:11:27.571759
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test___setattr__(self):
            class Foo(object):
                def __init__(self):
                    self.bar = None
            scope = {}
            def factory(self, scope, name):
                return Foo()
            replacer = ScopeReplacer(scope, factory, 'foo')
            replacer.bar = 'baz'
            self.assertEqual('baz', scope['foo'].bar)
    test_ScopeReplacer___setattr__.__test__ = False
    return TestScopeReplacer



# Generated at 2022-06-18 04:11:37.100585
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return args, kwargs
            foo = Foo()
            scope = {}
            def factory(self, scope, name):
                return foo
            name = 'foo'
            replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual(((), {}), replacer())
            self.assertEqual(((1,), {}), replacer(1))
            self.assertEqual(((1, 2), {}), replacer(1, 2))

# Generated at 2022-06-18 04:11:47.994459
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __init__(self, *args, **kwargs):
                    self.args = args
                    self.kwargs = kwargs
                def __call__(self, *args, **kwargs):
                    self.args = args
                    self.kwargs = kwargs
                    return self
            foo = Foo()
            scope = {}
            scope_replacer = ScopeReplacer(scope, lambda self, scope, name: foo, 'foo')
            self.assertEqual(scope_replacer.args, ())
            self.assertEqual(scope_replacer.kwargs, {})
            scope_

# Generated at 2022-06-18 04:11:58.069045
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return name
            name = 'test'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.test = 'test'
            self.assertEqual(scope_replacer.test, 'test')
            self.assertEqual(scope_replacer._real_obj, 'test')
            self.assertEqual(scope_replacer._name, 'test')
            self.assertEqual(scope_replacer._scope, scope)

# Generated at 2022-06-18 04:12:09.088859
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return args, kwargs
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            scope[name] = ScopeReplacer(scope, factory, name)
            self.assertEqual(((1, 2), {'a': 3}), scope[name](1, 2, a=3))
    test_ScopeReplacer___call__.__test__ = False
    test_ScopeReplacer___call__()

    # Unit test for method __getattribute__ of class ScopeReplacer

# Generated at 2022-06-18 04:13:01.162687
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object."""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:13:09.155266
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    import sys
    class TestScopeReplacer(TestCase):
        def test___setattr__(self):
            class Foo(object):
                pass
            foo = Foo()
            foo.bar = 'baz'
            self.assertEqual('baz', foo.bar)
            foo.bar = 'qux'
            self.assertEqual('qux', foo.bar)
            foo.bar = 'quux'
            self.assertEqual('quux', foo.bar)
            foo.bar = 'corge'

# Generated at 2022-06-18 04:13:11.405087
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:13:14.620022
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:13:21.017142
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False