

# Generated at 2022-06-18 04:03:47.241135
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    # Test that calling a lazy object works.
    # This is a regression test for https://bugs.launchpad.net/bzr/+bug/333908
    # where calling a lazy object would raise an exception.
    try:
        osutils.pathjoin('a', 'b')
    except errors.BzrError:
        pass
    else:
        raise AssertionError('Calling a lazy object should raise an exception')



# Generated at 2022-06-18 04:03:51.374561
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:03:54.395049
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:04:04.817396
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    class Foo(object):
        def __call__(self, *args, **kwargs):
            return (args, kwargs)
    scope = {}
    def factory(self, scope, name):
        return Foo()
    name = 'foo'
    sr = ScopeReplacer(scope, factory, name)
    assert sr.__call__(1, 2, 3) == ((1, 2, 3), {})
    assert sr.__call__(a=1, b=2, c=3) == ((), {'a': 1, 'b': 2, 'c': 3})
    assert sr.__call__(1, 2, 3, a=1, b=2, c=3) == ((1, 2, 3), {'a': 1, 'b': 2, 'c': 3})
    # Check that the real object is

# Generated at 2022-06-18 04:04:16.685180
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import
    import bzrlib.tests.blackbox.test_lazy_import

# Generated at 2022-06-18 04:04:25.795426
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            foo = Foo()
            foo_replacer = ScopeReplacer(locals(), lambda self, scope, name: foo, 'foo')
            self.assertEqual(((1, 2), {'a': 3}), foo_replacer(1, 2, a=3))
    TestScopeReplacer('test___call__').run()



# Generated at 2022-06-18 04:04:34.670019
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            foo = Foo()
            scope = {}
            def factory(self, scope, name):
                return foo
            name = 'foo'
            scope_replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual(((1, 2), {'a': 'b'}),
                             scope_replacer(1, 2, a='b'))
    TestScopeReplacer('test___call__').run()

# Generated at 2022-06-18 04:04:36.285706
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:04:39.313263
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object."""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:04:43.346472
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:04:57.051539
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False
    try:
        import bzrlib.tests
        bzrlib.tests.TestCase.assertRaises(
            bzrlib.lazy_import.IllegalUseOfScopeReplacer,
            bzrlib.tests.TestCase.fail,
            "This should raise an IllegalUseOfScopeReplacer")
    finally:
        bzrlib.lazy_import.ScopeReplacer._should_proxy = True



# Generated at 2022-06-18 04:05:08.221799
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    # This test is here to ensure that the __str__ method of
    # IllegalUseOfScopeReplacer is not broken.
    # It is not a test of the functionality of the method.
    #
    # It is not possible to test the functionality of the method because
    # it is not possible to create an instance of IllegalUseOfScopeReplacer
    # without triggering the exception.
    #
    # The test is here to ensure that the __str__ method does not raise
    # an exception.
    #
    # The test is here to ensure that the __str__ method does not raise
    # an exception.
    #
    # The test is here to ensure that the __str__ method does not raise
    # an exception.
    #
    # The test is here to ensure that the __str__

# Generated at 2022-06-18 04:05:11.027576
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:05:21.439463
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___getattribute__(self):
            from bzrlib.lazy_import import ScopeReplacer
            from bzrlib.lazy_import import IllegalUseOfScopeReplacer
            class Foo(object):
                def __init__(self, name):
                    self.name = name
                def __getattribute__(self, attr):
                    if attr == 'name':
                        return object.__getattribute__(self, attr)
                    else:
                        raise AttributeError(attr)
                def __setattr__(self, attr, value):
                    if attr == 'name':
                        object.__setattr__(self, attr, value)

# Generated at 2022-06-18 04:05:30.699036
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self):
            self.attr = None
    class TestScopeReplacer(TestCase):
        def test_setattr(self):
            obj = TestObj()
            scope = {}
            def factory(self, scope, name):
                return obj
            replacer = ScopeReplacer(scope, factory, 'obj')
            replacer.attr = 'value'
            self.assertEqual('value', obj.attr)
            self.assertEqual('value', scope['obj'].attr)

# Generated at 2022-06-18 04:05:42.646971
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return args, kwargs
            foo = Foo()
            scope = {}
            def factory(self, scope, name):
                return foo
            replacer = ScopeReplacer(scope, factory, 'foo')
            self.assertEqual(((), {}), replacer())
            self.assertEqual(((1,), {}), replacer(1))
            self.assertEqual(((1, 2), {}), replacer(1, 2))

# Generated at 2022-06-18 04:05:49.983893
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self):
            self.attr = None
    class TestCase(TestCase):
        def test_setattr(self):
            scope = {}
            def factory(self, scope, name):
                return TestObj()
            obj = ScopeReplacer(scope, factory, 'obj')
            obj.attr = 'value'
            self.assertEqual('value', scope['obj'].attr)
    TestCase.run_tests()

# Generated at 2022-06-18 04:05:54.961441
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:06:02.994390
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self):
            self.a = 1
    class TestCase(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            name = 'test_obj'
            def factory(self, scope, name):
                return TestObj()
            obj = ScopeReplacer(scope, factory, name)
            obj.a = 2
            self.assertEqual(2, obj.a)
            self.assertEqual(2, scope[name].a)

# Generated at 2022-06-18 04:06:15.268910
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            scope = {}
            def factory(self, scope, name):
                return Foo()
            scope_replacer = ScopeReplacer(scope, factory, 'foo')
            self.assertEqual(((), {}), scope_replacer())
            self.assertEqual(((1,), {}), scope_replacer(1))
            self.assertEqual(((1, 2), {}), scope_replacer(1, 2))

# Generated at 2022-06-18 04:06:29.406609
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False
    import bzrlib.trace
    import bzrlib.errors
    import bzrlib.osutils
    import bzrlib.branch
    import bzrlib
    bzrlib.lazy_import.ScopeReplacer._should_proxy = True
    bzrlib.trace.note(bzrlib.errors.BzrError.__name__)
    bzrlib.trace.note(bzrlib.osutils.pathjoin.__name__)
    bzrlib.trace.note(bzrlib.branch.Branch.__name__)
    bzrlib.trace.note(bzrlib.__name__)
   

# Generated at 2022-06-18 04:06:37.959838
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return 'test'
            name = 'test'
            obj = ScopeReplacer(scope, factory, name)
            obj.test = 'test'
            self.assertEqual('test', obj.test)
    TestScopeReplacer('test_ScopeReplacer___setattr__').run()


# Generated at 2022-06-18 04:06:41.847568
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:06:44.990733
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:06:49.707299
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:06:55.324145
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False

# Generated at 2022-06-18 04:06:58.317332
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'name was used incorrectly: msg'

# Generated at 2022-06-18 04:07:08.338171
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.tests import TestCase
    from bzrlib.tests import TestSkipped
    from bzrlib.tests import TestNotApplicable
    from bzrlib.tests import TestCaseWithMemoryTransport
    from bzrlib.tests import TestCaseWithTransport
    from bzrlib.tests import TestCaseWithTwoWorkingDirs
    from bzrlib.tests import TestCaseWithTransportAndRequirement
    from bzrlib.tests import TestCaseWithTransportAndMemoryTree
    from bzrlib.tests import TestCaseWithTransportAndTempDir

# Generated at 2022-06-18 04:07:10.675013
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    from bzrlib import osutils
    ''')
    osutils.pathjoin('a', 'b')



# Generated at 2022-06-18 04:07:19.789233
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            foo = Foo()
            sr = ScopeReplacer(locals(), lambda self, scope, name: foo, 'foo')
            self.assertEqual(((1, 2), {'a': 'b'}), sr(1, 2, a='b'))
    TestScopeReplacer('test___call__').run()



# Generated at 2022-06-18 04:07:33.490511
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests import TestCase
    import sys
    class TestScopeReplacer(TestCase):
        def test___setattr__(self):
            # Test that __setattr__ works as expected
            def factory(self, scope, name):
                return 'foo'
            lazy_import(sys.modules[__name__], '''
            from bzrlib.lazy_import import ScopeReplacer
            ''')
            self.assertRaises(IllegalUseOfScopeReplacer,
                              ScopeReplacer, sys.modules[__name__], factory, 'foo')

# Generated at 2022-06-18 04:07:42.055162
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    try:
        bzrlib.lazy_import.ScopeReplacer._should_proxy = False
        # Test that calling the object works
        bzrlib.branch.Branch()
        # Test that calling the object works
        bzrlib.branch.Branch()
    finally:
        bzrlib.lazy_import.ScopeReplacer._should_proxy = True
    return



# Generated at 2022-06-18 04:07:46.207609
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert isinstance(str(e), str)


# Generated at 2022-06-18 04:07:52.817809
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    import bzrlib.lazy_import
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            def factory(self, scope, name):
                return lambda: 'foo'
            scope = {}
            name = 'foo'
            self.assertEqual('foo', bzrlib.lazy_import.ScopeReplacer(scope, factory, name)())
    TestScopeReplacer('test___call__').run()

# Generated at 2022-06-18 04:08:03.830409
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            foo = Foo()
            scope = {}
            def factory(self, scope, name):
                return foo
            name = 'foo'
            replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual(((1, 2), {'a': 'b'}), replacer(1, 2, a='b'))
    TestScopeReplacer('test_ScopeReplacer___call__').test_ScopeReplacer___call__()


# Generated at 2022-06-18 04:08:11.712784
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should raise an exception if the object has already been
    replaced.
    """
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests import TestCase
    import bzrlib.tests.test_lazy_import

    class TestScopeReplacer(TestCase):

        def test_setattr(self):
            # Test that __setattr__ raises an exception if the object has
            # already been replaced.
            def factory(self, scope, name):
                return self
            scope = {}
            lazy_import(scope, '''
            from bzrlib.lazy_import import ScopeReplacer
            ''')
            ScopeReplacer(scope, factory, 'ScopeReplacer')

# Generated at 2022-06-18 04:08:14.997550
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:08:18.298015
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = e.__unicode__()
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:08:29.907139
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_lazy_import import TestLazyImport

    class TestScopeReplacer(TestCase):

        def test_ScopeReplacer___setattr__(self):
            """Test method __setattr__ of class ScopeReplacer"""
            from bzrlib.lazy_import import lazy_import
            from bzrlib.tests import TestCase
            from bzrlib.tests.test_lazy_import import TestLazyImport

            class TestScopeReplacer(TestCase):

                def test_ScopeReplacer___setattr__(self):
                    """Test method __setattr__ of class ScopeReplacer"""
                    class TestClass(object):
                        pass
                    scope = {}
                    lazy_

# Generated at 2022-06-18 04:08:34.065853
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s.startswith('IllegalUseOfScopeReplacer(')
    assert s.endswith(')')


# Generated at 2022-06-18 04:08:46.533859
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    import bzrlib.tests.test_lazy_import
    ''')
    class Foo(object):
        def __call__(self, *args, **kwargs):
            return (args, kwargs)
    foo = Foo()
    scope = {}
    bzrlib.lazy_import.ScopeReplacer(scope, lambda self, scope, name: foo, 'foo')
    assert scope['foo'].__call__(1, 2, 3) == ((1, 2, 3), {})

# Generated at 2022-06-18 04:08:54.841014
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self, value):
            self.value = value
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return TestObj(name)
            replacer = ScopeReplacer(scope, factory, 'test')
            replacer.value = 'test'
            self.assertEqual('test', scope['test'].value)

# Generated at 2022-06-18 04:08:58.170847
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:09:07.879883
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            import bzrlib.lazy_import
            def factory(self, scope, name):
                return bzrlib.lazy_import
            scope = {}
            name = 'bzrlib'
            sr = ScopeReplacer(scope, factory, name)
            self.assertEqual(sr.__call__, bzrlib.lazy_import.__call__)
    Test('test_ScopeReplacer___call__').run()

# Generated at 2022-06-18 04:09:11.636701
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() should return a str object."""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:09:15.422395
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__(self, *args, **kwargs)"""
    # TODO: Implement test_ScopeReplacer___call__
    raise NotImplementedError(__name__)


# Generated at 2022-06-18 04:09:19.519109
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:09:24.423591
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    # Test that we can call the object
    bzrlib.branch.Branch()
    # Test that we can call the object with arguments
    bzrlib.branch.Branch('.')
    # Test that we can call the object with keyword arguments
    bzrlib.branch.Branch(name='.')
    # Test that we can call the object with arguments and keyword arguments
    bzrlib.branch.Branch('.', name='.')
    # Test that we can call the object with

# Generated at 2022-06-18 04:09:31.692185
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    import bzrlib.tests.blackbox
    ''')
    bzrlib.tests.blackbox.TestCaseWithTransport.__call__()

    # Test that calling a class works
    bzrlib.tests.blackbox.TestCaseWithTransport()

    # Test that calling a function works
    bzrlib.tests.blackbox.TestCaseWithTransport.setUp()



# Generated at 2022-06-18 04:09:35.491916
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:09:43.315457
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:09:52.242409
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer

    class TestScopeReplacer(TestCase):

        def test___setattr__(self):
            class Foo(object):
                pass
            foo = Foo()
            foo.bar = 'baz'
            scope = {}
            def factory(self, scope, name):
                return foo
            replacer = ScopeReplacer(scope, factory, 'foo')
            replacer.bar = 'qux'
            self.assertEqual('qux', foo.bar)
            self.assertEqual('qux', replacer.bar)
            self.assertEqual('qux', scope['foo'].bar)
    test_ScopeReplacer___setattr__ = TestScopeReplacer('test___setattr__')
    return test_

# Generated at 2022-06-18 04:09:56.585418
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:10:07.192332
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    import bzrlib.tests
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import

# Generated at 2022-06-18 04:10:13.708659
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should set the attribute on the real object"""
    class Foo(object):
        def __init__(self):
            self.bar = None
    scope = {}
    def factory(replacer, scope, name):
        return Foo()
    replacer = ScopeReplacer(scope, factory, 'foo')
    replacer.bar = 'baz'
    assert scope['foo'].bar == 'baz'

# Generated at 2022-06-18 04:10:19.265816
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = e.__unicode__()
    assert isinstance(u, unicode)
    assert u == u'ScopeReplacer object \'name\' was used incorrectly: msg: extra'

# Generated at 2022-06-18 04:10:29.009859
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.lazy_import import _scope_replacer_factory
    import bzrlib

# Generated at 2022-06-18 04:10:32.968470
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    assert isinstance(str(e), str)
    assert isinstance(unicode(e), unicode)

# Generated at 2022-06-18 04:10:36.989431
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests.blackbox.test_lazy_import
    bzrlib.tests.blackbox.test_lazy_import.test_ScopeReplacer___setattr__()

# Generated at 2022-06-18 04:10:41.446980
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    # Test that the __str__ method returns a str object
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    # Test that the __str__ method returns a unicode object
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)



# Generated at 2022-06-18 04:10:49.754679
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'name was used incorrectly: msg'

# Generated at 2022-06-18 04:11:00.610884
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __init__(self, a, b, c):
                    self.a = a
                    self.b = b
                    self.c = c
                def __call__(self, *args, **kwargs):
                    return (self.a, self.b, self.c, args, kwargs)
            scope = {}
            def factory(self, scope, name):
                return Foo(1, 2, 3)
            scope_replacer = ScopeReplacer(scope, factory, 'foo')
            self.assertEqual((1, 2, 3, (), {}), scope_replacer())
            self

# Generated at 2022-06-18 04:11:04.266101
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object."""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = e.__unicode__()
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:11:08.459226
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return unicode"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:11:11.247671
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    import sys
    class TestScopeReplacer(TestCase):
        def test___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return scope[name]
            name = 'name'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.__setattr__('_real_obj', 'real_obj')
            self.assertEqual('real_obj', scope[name])
    TestScopeReplacer('test___setattr__').run()

# Generated at 2022-06-18 04:11:20.564990
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            from bzrlib.lazy_import import lazy_import
            import bzrlib.tests.test_lazy_import
            import bzrlib.tests.test_lazy_import
            import bzrlib.tests.test_lazy_import
            import bzrlib.tests.test_lazy_import
            import bzrlib.tests.test_lazy_import
            import bzrlib.tests.test_lazy_import
            import bzrlib.tests.test_lazy_import
            import bzrlib.tests.test_lazy_import
            import bzrlib.tests.test_lazy_import
            import bzr

# Generated at 2022-06-18 04:11:23.027818
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:11:34.577191
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should raise an exception if the object has already been
    replaced.
    """
    # Create a scope and a ScopeReplacer
    scope = {}
    def factory(self, scope, name):
        return self
    name = 'foo'
    replacer = ScopeReplacer(scope, factory, name)
    # Set an attribute on the replacer
    replacer.bar = 'baz'
    # Check that the attribute is set on the object in the scope
    assert scope['foo'].bar == 'baz'
    # Disable proxying
    ScopeReplacer._should_proxy = False
    # Try to set an attribute on the replacer

# Generated at 2022-06-18 04:11:45.332544
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import types
    import bzrlib.lazy_import
    reload(bzrlib.lazy_import)
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import _lazy_import_module
    from bzrlib.lazy_import import _lazy_import_object
    from bzrlib.lazy_import import _lazy_import_function
    from bzrlib.lazy_import import _lazy_import_class
    from bzrlib.lazy_import import _lazy_import_constant
    from bzrlib.lazy_import import _

# Generated at 2022-06-18 04:11:48.897930
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s == 'name: msg'


# Generated at 2022-06-18 04:12:00.828749
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            def factory(self, scope, name):
                return lambda x: x
            scope = {}
            name = 'name'
            replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual(replacer(1), 1)
            self.assertEqual(replacer(2), 2)
            self.assertEqual(replacer(3), 3)
            self.assertEqual(replacer(4), 4)

# Generated at 2022-06-18 04:12:05.198041
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:12:08.489553
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)



# Generated at 2022-06-18 04:12:14.234178
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object

    This is a regression test for bug #177880.
    """
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:12:21.552861
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ of ScopeReplacer"""
    import bzrlib.tests
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.tests import TestCase
    from bzrlib.tests import TestSkipped
    from bzrlib.tests import TestUtil
    from bzrlib.tests import test_lazy_import
    from bzrlib.tests.blackbox import ExternalBase
    from bzrlib.tests.test_lazy_import import TestLazyImport
    from bzrlib.tests.test_lazy_import import TestLazyImportWith

# Generated at 2022-06-18 04:12:30.574913
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    # This test is not run by default because it is not a unit test.
    # It is run by test_lazy_import.py
    # It is here because it is convenient to have it here.
    # It is a test of the __str__ method of IllegalUseOfScopeReplacer.
    # It is not a unit test because it is not testing a unit of code.
    # It is a test of the interaction between the code and the environment.
    # It is not a unit test because it is not testing a unit of code.
    # It is a test of the interaction between the code and the environment.
    # It is not a unit test because it is not testing a unit of code.
    # It is a test of the interaction between the code and the environment.
    # It is not a unit test

# Generated at 2022-06-18 04:12:34.812155
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:12:43.113616
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_setattr_on_lazy_import(self):
            # Test that we can set attributes on lazy_imported objects.
            # This is important for things like bzrlib.branch.Branch.
            # See bug #251062 for more details.
            lazy_import(globals(), '''
            from bzrlib import (
                branch,
                )
            ''')
            branch.Branch.foo = 'bar'
            self.assertEqual('bar', branch.Branch.foo)
    Test().run()

# Generated at 2022-06-18 04:12:52.328370
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.lazy_import import _lazy_import_scope_replacer_factory
    from bzrlib.lazy_import import _lazy_import_scope_replacer_factory_with_attr
    from bzrlib.lazy_import import _lazy_import_scope_replacer_factory_with_attr_and_value
    from bzrlib.lazy_import import _lazy_import_scope_replacer_factory_with_value
    from bzrlib.lazy_import import _lazy_import_scope

# Generated at 2022-06-18 04:12:55.963755
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:13:28.590795
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self):
            self.x = 1
    class TestCase(TestCase):
        def test_setattr(self):
            scope = {}
            def factory(self, scope, name):
                return TestObj()
            obj = ScopeReplacer(scope, factory, 'obj')
            obj.x = 2
            self.assertEqual(2, scope['obj'].x)
    TestCase.run_tests()