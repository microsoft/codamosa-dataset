

# Generated at 2022-06-18 04:03:44.403773
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:03:48.574454
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests.blackbox.test_lazy_import
    bzrlib.tests.blackbox.test_lazy_import.test_ScopeReplacer___setattr__()


# Generated at 2022-06-18 04:03:51.997621
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() should return a unicode object."""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:04:02.933632
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = True
    # Test the case where the object has not been replaced yet
    scope = {}
    def factory(self, scope, name):
        return 'foo'
    name = 'bar'
    replacer = bzrlib.lazy_import.ScopeReplacer(scope, factory, name)
    replacer.__setattr__('baz', 'qux')
    assert scope['bar'].baz == 'qux'
    # Test the case where the object has already been replaced
    scope = {}
    def factory(self, scope, name):
        return 'foo'
    name = 'bar'
    replacer = bzrlib.lazy_import.ScopeReplacer(scope, factory, name)

# Generated at 2022-06-18 04:04:06.746715
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:04:14.257036
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            def factory(self, scope, name):
                return lambda: 'foo'
            scope = {}
            name = 'bar'
            scope_replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual('foo', scope_replacer())
    TestScopeReplacer().test___call__()

# Generated at 2022-06-18 04:04:24.789558
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()"""
    # This test is here to ensure that the __unicode__ method is
    # implemented.
    #
    # The method is used by the traceback module to format the
    # exception.
    #
    # If the method is not implemented, the traceback module will
    # fallback to the __str__ method.
    #
    # This test is here to ensure that the __unicode__ method is
    # implemented, so that the traceback module does not fallback
    # to the __str__ method.
    #
    # The reason for this is that the __str__ method is implemented
    # in terms of the __unicode__ method.
    #
    # If the traceback module fallsback to the __str__ method,
    # then the __unicode__ method will

# Generated at 2022-06-18 04:04:34.602304
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests.blackbox import ExternalBase
    from bzrlib.tests import TestCase
    import bzrlib
    class TestScopeReplacer(ExternalBase):
        def test_ScopeReplacer___call__(self):
            # test __call__ of class ScopeReplacer
            import bzrlib.lazy_import
            import bzrlib.tests.blackbox
            import bzrlib.tests.test_lazy_import
            import bzrlib.tests.test_lazy_import
            import bzrlib.tests.test_lazy_import
            import bzrlib.tests.test_lazy_import
            import bzrlib.tests.test_lazy_import
            import bzrlib.tests.test_lazy_import
            import bzrlib.tests

# Generated at 2022-06-18 04:04:45.321295
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return args, kwargs
            foo = Foo()
            scope = {}
            def factory(self, scope, name):
                return foo
            name = 'foo'
            replacer = ScopeReplacer(scope, factory, name)
            args = (1, 2, 3)
            kwargs = {'a': 1, 'b': 2}
            self.assertEqual((args, kwargs), replacer(*args, **kwargs))
    TestScopeReplacer('test___call__').run()

# Generated at 2022-06-18 04:04:54.648284
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return object()
            name = 'name'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.__setattr__('attr', 'value')
            self.assertEqual('value', scope_replacer.attr)
    TestScopeReplacer('test_ScopeReplacer___setattr__').test_ScopeReplacer___setattr__()

# Generated at 2022-06-18 04:05:15.739754
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:05:19.504936
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:05:23.279064
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:05:32.058994
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should raise an exception if the object has already been
    replaced.
    """
    class Foo(object):
        pass
    scope = {}
    def factory(self, scope, name):
        return Foo()
    name = 'foo'
    replacer = ScopeReplacer(scope, factory, name)
    replacer.bar = 'baz'
    # Now disable proxying
    ScopeReplacer._should_proxy = False
    try:
        replacer.bar = 'baz'
    except IllegalUseOfScopeReplacer:
        pass
    else:
        raise AssertionError("__setattr__ should raise an exception if the"
            " object has already been replaced.")


# Generated at 2022-06-18 04:05:35.601969
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:05:47.284524
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase

# Generated at 2022-06-18 04:05:51.177930
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert isinstance(s, unicode)

# Generated at 2022-06-18 04:05:59.542245
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Foo(object):
        def __init__(self):
            self.bar = None
    class Test(TestCase):
        def test_setattr(self):
            foo = Foo()
            replacer = ScopeReplacer(foo.__dict__, lambda self, scope, name: self, 'bar')
            replacer.bar = 'baz'
            self.assertEqual('baz', foo.bar)
    Test('test_setattr').run()

# Generated at 2022-06-18 04:06:05.805654
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self):
            self.attr = None
    class TestScopeReplacer(TestCase):
        def test___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return TestObj()
            obj = ScopeReplacer(scope, factory, 'obj')
            obj.attr = 'value'
            self.assertEqual('value', scope['obj'].attr)

# Generated at 2022-06-18 04:06:10.120109
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode string"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:06:32.977851
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    import bzrlib.trace
    bzrlib.lazy_import.lazy_import(globals(), '''
    import bzrlib.trace
    ''')
    bzrlib.trace.note('foo')
    return



# Generated at 2022-06-18 04:06:41.155661
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False

# Generated at 2022-06-18 04:06:45.834179
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    import bzrlib.tests
    ''')
    # test that calling a lazy_import object works
    bzrlib.tests.TestCase.assertTrue(bzrlib.tests.TestCase)



# Generated at 2022-06-18 04:06:51.065587
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    import bzrlib.tests.blackbox
    ''')
    bzrlib.tests.blackbox.TestCaseWithTransport.__call__(None)

# Generated at 2022-06-18 04:06:53.721077
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should set the attribute on the real object"""
    scope = {}
    def factory(self, scope, name):
        return object()
    replacer = ScopeReplacer(scope, factory, 'foo')
    replacer.bar = 'baz'
    assert scope['foo'].bar == 'baz'

# Generated at 2022-06-18 04:06:56.988624
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg: extra"

# Generated at 2022-06-18 04:07:01.914213
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert isinstance(s, unicode)
    assert s == u'name was used incorrectly: msg'

# Generated at 2022-06-18 04:07:08.911735
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    import bzrlib.tests.test_lazy_import
    ''')
    test_ScopeReplacer___call__.__doc__ = bzrlib.tests.test_lazy_import.test_ScopeReplacer___call__.__doc__

    # test_ScopeReplacer___call__ is defined in bzrlib/tests/test_lazy_import.py



# Generated at 2022-06-18 04:07:20.062214
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False

# Generated at 2022-06-18 04:07:30.182757
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert str(e) == 'msg: extra'
    assert unicode(e) == u'msg: extra'
    assert repr(e) == "IllegalUseOfScopeReplacer('name', 'msg', 'extra')"
    e = IllegalUseOfScopeReplacer('name', 'msg')
    assert str(e) == 'msg'
    assert unicode(e) == u'msg'
    assert repr(e) == "IllegalUseOfScopeReplacer('name', 'msg')"
    e = IllegalUseOfScopeReplacer('name', 'msg', None)
    assert str(e) == 'msg'
    assert unicode(e) == u'msg'

# Generated at 2022-06-18 04:07:54.336463
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer

    class TestScopeReplacer(TestCase):

        def test___call__(self):
            scope = {}
            def factory(self, scope, name):
                return lambda: 'called'
            name = 'foo'
            replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual('called', replacer())

    TestScopeReplacer('test___call__').run()



# Generated at 2022-06-18 04:08:04.839240
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            scope = {}
            def factory(self, scope, name):
                return Foo()
            scope['foo'] = ScopeReplacer(scope, factory, 'foo')
            self.assertEqual(((), {}), scope['foo']())
            self.assertEqual(((1, 2), {}), scope['foo'](1, 2))
            self.assertEqual(((), {'a': 1}), scope['foo'](a=1))

# Generated at 2022-06-18 04:08:15.581512
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import, ScopeReplacer

    class TestScopeReplacer(TestCase):

        def test___setattr__(self):
            # __setattr__ should set the attribute on the real object.
            scope = {}
            lazy_import(scope, '''
            from bzrlib.lazy_import import ScopeReplacer
            ''')
            class Foo(object):
                pass
            def factory(self, scope, name):
                return Foo()
            replacer = ScopeReplacer(scope, factory, 'foo')
            replacer.bar = 'baz'
            self.assertEqual('baz', scope['foo'].bar)

    from bzrlib.tests import TestUtil
    TestUtil.test_suite

# Generated at 2022-06-18 04:08:18.486088
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:08:27.891680
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            scope = {}
            def factory(self, scope, name):
                return lambda x: x
            lazy_import(scope, '''
            from bzrlib.lazy_import import ScopeReplacer
            ''')
            scope['ScopeReplacer'](scope, factory, 'foo')
            self.assertEqual(scope['foo'](1), 1)
    TestScopeReplacer('test___call__').run()

# Generated at 2022-06-18 04:08:37.245622
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    # Test that the lazy-loaded objects can be called.
    # This is a bit of a silly test, but it is the only way to test that
    # the __call__ method is working.
    errors.BzrError()
    osutils.dirname('foo')
    branch.Branch()
    bzrlib.branch.Branch()
    # Test that the lazy-loaded objects can be called.
    # This is a bit of a silly test, but it is the only way to test that
    # the __

# Generated at 2022-06-18 04:08:41.130321
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:08:43.311038
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__() should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s == 'name: msg'

# Generated at 2022-06-18 04:08:46.938370
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:08:49.804216
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:09:08.178025
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u.startswith('name')
    assert u.endswith('msg')


# Generated at 2022-06-18 04:09:16.479865
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __init__(self, *args, **kwargs):
                    self.args = args
                    self.kwargs = kwargs
            foo = Foo(1, 2, 3, a=1, b=2, c=3)
            scope = {}
            def factory(self, scope, name):
                return foo
            name = 'foo'
            scope_replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual(scope_replacer(1, 2, 3, a=1, b=2, c=3), foo)

# Generated at 2022-06-18 04:09:20.127607
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:09:22.642663
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:09:30.337389
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import, ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            def factory(self, scope, name):
                return lambda: 'foo'
            scope = {}
            name = 'name'
            scope_replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual('foo', scope_replacer())

    TestScopeReplacer('test___call__').run()



# Generated at 2022-06-18 04:09:34.170998
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:09:43.125842
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import bzrlib.tests
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.lazy_import import _test_ScopeReplacer___getattribute__
    from bzrlib.lazy_import import _test_ScopeReplacer___getattribute__
    from bzrlib.lazy_import import _test_ScopeReplacer___getattribute__
    from bzrlib.lazy_import import _test_ScopeReplacer___getattribute__
    from bzrlib.lazy_import import _test_ScopeReplacer___getattribute__
    from bzrlib.lazy_import import _test_ScopeReplacer___get

# Generated at 2022-06-18 04:09:52.242598
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return args, kwargs
            foo = Foo()
            scope = {}
            def factory(self, scope, name):
                return foo
            name = 'foo'
            replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual(((), {}), replacer())
            self.assertEqual(((1,), {}), replacer(1))
            self.assertEqual(((1, 2), {}), replacer(1, 2))

# Generated at 2022-06-18 04:10:03.260060
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.lazy_import
    import bzrlib.tests.test_lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = True
    bzrlib.tests.test_lazy_import.ScopeReplacer._should_proxy = True
    import bzrlib.tests.test_lazy_import
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False
    bzrlib.tests.test_lazy_import.ScopeReplacer._should_proxy = False
    import bzrlib.tests.test_lazy_import
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = True
    b

# Generated at 2022-06-18 04:10:07.238384
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object."""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg"

# Generated at 2022-06-18 04:10:53.498230
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestClass(TestCase):
        def test_setattr(self):
            class Foo(object):
                def __init__(self):
                    self.x = 1
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            replacer = ScopeReplacer(scope, factory, name)
            replacer.x = 2
            self.assertEqual(2, replacer.x)
            self.assertEqual(2, scope[name].x)
    TestClass('test_setattr').run()

# Generated at 2022-06-18 04:10:56.907379
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.tests.blackbox.test_lazy_import
    bzrlib.tests.blackbox.test_lazy_import.test_ScopeReplacer___setattr__()

# Generated at 2022-06-18 04:11:01.029240
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)
    assert s == 'ScopeReplacer object \'name\' was used incorrectly: msg: extra'

# Generated at 2022-06-18 04:11:03.933521
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:11:08.506831
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:11:12.128530
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s.startswith('IllegalUseOfScopeReplacer(')

# Generated at 2022-06-18 04:11:14.896104
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:11:22.509299
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    import sys
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __init__(self):
                    self.bar = None
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.bar = 'baz'
            self.assertEqual('baz', scope_replacer.bar)
    test_ScopeReplacer___setattr__.__test__ = False
    test_ScopeReplacer___setattr__()

# Generated at 2022-06-18 04:11:25.484338
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__(self, *args, **kwargs)"""
    # TODO: Implement test.
    raise NotImplementedError(
        "Test for method __call__ of class ScopeReplacer not implemented")



# Generated at 2022-06-18 04:11:29.525464
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:13:02.996818
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            foo = Foo()
            scope = {}
            def factory(self, scope, name):
                return foo
            name = 'foo'
            scope_replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual(((), {}), scope_replacer())
            self.assertEqual(((1,), {}), scope_replacer(1))
            self.assertEqual(((1, 2), {}), scope_replacer(1, 2))
            self.assertEqual

# Generated at 2022-06-18 04:13:10.532926
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_setattr(self):
            scope = {}
            lazy_import(scope, '''
            from bzrlib import (
                errors,
                osutils,
                branch,
                )
            import bzrlib.branch
            ''')
            self.assertIsInstance(scope['errors'], ScopeReplacer)
            self.assertIsInstance(scope['osutils'], ScopeReplacer)
            self.assertIsInstance(scope['branch'], ScopeReplacer)

# Generated at 2022-06-18 04:13:17.241577
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            scope = {}
            def factory(self, scope, name):
                return lambda: 'foo'
            name = 'bar'
            scope[name] = ScopeReplacer(scope, factory, name)
            self.assertEqual('foo', scope[name]())
    Test('test_ScopeReplacer___call__').run()

# Generated at 2022-06-18 04:13:22.932383
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return 'foo'
            name = 'bar'
            obj = ScopeReplacer(scope, factory, name)
            obj.baz = 'qux'
            self.assertEqual('qux', obj.baz)
    TestScopeReplacer('test_ScopeReplacer___setattr__').run_tests()