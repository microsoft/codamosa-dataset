

# Generated at 2022-06-18 04:04:09.381177
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class TestClass(object):
                def __init__(self, *args, **kwargs):
                    self.args = args
                    self.kwargs = kwargs
                def __call__(self, *args, **kwargs):
                    self.args = args
                    self.kwargs = kwargs
            test_obj = TestClass()
            scope = {}
            def factory(self, scope, name):
                return test_obj
            name = 'test_obj'
            obj = ScopeReplacer(scope, factory, name)
            self.assertEqual(obj.args, ())
            self.assertE

# Generated at 2022-06-18 04:04:12.491868
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:04:21.846271
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Test(TestCase):
        def test_setattr(self):
            class Foo(object):
                pass
            foo = Foo()
            foo.bar = 'baz'
            scope = {}
            def factory(self, scope, name):
                return foo
            replacer = ScopeReplacer(scope, factory, 'foo')
            replacer.bar = 'qux'
            self.assertEqual('qux', foo.bar)
    test_ScopeReplacer___setattr__.__test__ = False
    return Test

# Generated at 2022-06-18 04:04:24.466520
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__() should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:04:28.198233
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object."""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:04:36.853992
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    # Test that __call__ works
    def test_func(x, y):
        return x + y
    scope = {}
    factory = lambda self, scope, name: test_func
    name = 'test_func'
    replacer = ScopeReplacer(scope, factory, name)
    assert replacer(1, 2) == 3
    assert scope[name] is test_func
    assert replacer(1, 2) == 3
    assert replacer(1, 2) == 3
    assert replacer(1, 2) == 3
    assert repl

# Generated at 2022-06-18 04:04:46.758499
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    import bzrlib.tests
    import bzrlib.tests.blackbox
    import bzrlib.tests.blackbox.test_selftest
    import bzrlib.tests.blackbox.test_selftest as test_selftest
    import bzrlib.tests.blackbox.test_selftest as test_selftest
    import bzrlib.tests.blackbox.test_selftest as test_selftest
    import bzrlib.tests.blackbox.test_selftest as test_selftest
    import bzrlib.tests.blackbox.test_selftest as test_selftest
    import bzrlib.tests.blackbox.test_selftest as test_selftest


# Generated at 2022-06-18 04:04:49.650266
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:05:00.932603
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    import bzrlib.tests
    import bzrlib.tests.blackbox
    import bzrlib.tests.blackbox.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest.test_selftest.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest.test_selftest.test_selftest.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSel

# Generated at 2022-06-18 04:05:10.740742
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            foo = Foo()
            scope = {}
            factory = lambda self, scope, name: foo
            name = 'foo'
            replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual(((1, 2), {'a': 'b'}), replacer(1, 2, a='b'))
    test_suite = TestCase.build_test_suite(Test)
    return test_suite


# Generated at 2022-06-18 04:05:31.677540
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    import bzrlib.tests.test_lazy_import
    ''')
    # Test that ScopeReplacer.__call__() calls the real object.
    class TestClass(object):
        def __call__(self, *args, **kwargs):
            return (args, kwargs)
    test_obj = TestClass()
    scope = {}
    replacer = ScopeReplacer(scope, lambda self, scope, name: test_obj, 'test')
    args = (1, 2, 3)
    kwargs = {'a': 'b', 'c': 'd'}
    result = replacer(*args, **kwargs)

# Generated at 2022-06-18 04:05:35.556204
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:05:47.241213
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.lazy_import
    import bzrlib.trace
    import bzrlib.errors
    import bzrlib.osutils
    import bzrlib.branch
    import bzrlib.branch
    import bzrlib.lazy_import
    import bzrlib.trace
    import bzrlib.errors
    import bzrlib.osutils
    import bzrlib.branch
    import bzrlib.branch
    import bzrlib.lazy_import
    import bzrlib.trace
    import bzrlib.errors
    import bzrlib.osutils
    import bzrlib.branch
    import bzrlib.branch
    import bzrlib.lazy_import

# Generated at 2022-06-18 04:05:50.073021
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests.blackbox.test_lazy_import
    bzrlib.tests.blackbox.test_lazy_import.test_ScopeReplacer___call__()

# Generated at 2022-06-18 04:05:55.058976
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:06:03.697856
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return args, kwargs
            scope = {}
            name = 'foo'
            scope[name] = ScopeReplacer(scope, lambda self, scope, name: Foo(), name)
            self.assertEqual(((1, 2), {'a': 3}), scope[name](1, 2, a=3))
    Test().test_ScopeReplacer___call__()

    # Unit test for method __getattribute__ of class ScopeReplacer

# Generated at 2022-06-18 04:06:15.582273
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    import bzrlib
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.lazy_import import _scope_replacer_factory
    from bzrlib.lazy_import import _scope_replacer_factory_import
    from bzrlib.lazy_import import _scope_replacer_factory_import_from
    from bzrlib.lazy_import import _scope_replacer_factory_import_star
    from bzrlib.lazy_import import _scope_replacer_factory_import_as
    from bzrlib.lazy_import import _scope_replacer_

# Generated at 2022-06-18 04:06:18.866589
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:06:23.193885
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:06:30.097742
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Test(TestCase):
        def test_call(self):
            def factory(self, scope, name):
                return lambda: 'foo'
            scope = {}
            name = 'test'
            replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual('foo', replacer())
            self.assertEqual('foo', scope[name]())
    Test('test_call').run()

    # Unit test for method __getattribute__ of class ScopeReplacer

# Generated at 2022-06-18 04:06:46.861365
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests
    import bzrlib.lazy_import
    import bzrlib.tests.blackbox
    import bzrlib.tests.blackbox.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest.test_selftest.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest.test_selftest.test_selftest.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSel

# Generated at 2022-06-18 04:06:50.089949
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:06:55.575848
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Foo(object):
        def __init__(self, name):
            self.name = name
        def __getattribute__(self, attr):
            if attr == 'name':
                return object.__getattribute__(self, attr)
            raise AttributeError(attr)
    def factory(replacer, scope, name):
        return Foo(name)
    scope = {}
    name = 'foo'
    replacer = ScopeReplacer(scope, factory, name)
    self.assertEqual('foo', replacer.name)
    self.assertRaises(AttributeError, getattr, replacer, 'bar')

# Generated at 2022-06-18 04:06:58.584491
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:07:01.950269
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:07:10.749968
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___call__(self):
            scope = {}
            def factory(self, scope, name):
                return lambda *args, **kwargs: (args, kwargs)
            lazy_import(scope, '''
            from bzrlib.lazy_import import ScopeReplacer
            ''')
            scope['ScopeReplacer'](scope, factory, 'foo')
            self.assertEqual(((), {}), scope['foo']())
            self.assertEqual(((1, 2, 3), {'a': 1, 'b': 2}),
                             scope['foo'](1, 2, 3, a=1, b=2))


# Generated at 2022-06-18 04:07:21.156788
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    import sys
    class Foo(object):
        def __init__(self, x):
            self.x = x
    def factory(self, scope, name):
        return Foo(self)
    scope = {}
    name = 'foo'
    scope[name] = ScopeReplacer(scope, factory, name)
    assert scope[name].x is scope[name]
    assert scope[name].x.x is scope[name]
    assert scope[name].x.x.x is scope[name]
    assert scope[name].x.x.x.x is scope[name]
    assert scope[name].x.x.x.x.x is scope[name]
    assert scope

# Generated at 2022-06-18 04:07:23.792291
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:07:35.235813
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            from bzrlib.tests import TestCase
            from bzrlib.lazy_import import lazy_import
            from bzrlib.lazy_import import ScopeReplacer
            class Test(TestCase):
                def test_ScopeReplacer___call__(self):
                    from bzrlib.tests import TestCase
                    from bzrlib.lazy_import import lazy_import
                    from bzrlib.lazy_import import ScopeReplacer

# Generated at 2022-06-18 04:07:37.873882
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:07:47.204241
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:07:53.873672
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Test(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return 'foo'
            name = 'bar'
            x = ScopeReplacer(scope, factory, name)
            x.foo = 'bar'
            self.assertEqual('bar', x.foo)
    Test().test_ScopeReplacer___setattr__()

# Generated at 2022-06-18 04:08:04.804738
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False

# Generated at 2022-06-18 04:08:08.700398
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'name: msg'

# Generated at 2022-06-18 04:08:17.454977
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    import bzrlib.lazy_import
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            bzrlib.lazy_import.ScopeReplacer(scope, lambda self, scope, name: self, 'name')
            scope['name']._should_proxy = False
            self.assertRaises(bzrlib.lazy_import.IllegalUseOfScopeReplacer,
                              setattr, scope['name'], 'attr', 'value')

# Generated at 2022-06-18 04:08:19.863914
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:08:24.214895
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:08:34.434429
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return args, kwargs
            foo = Foo()
            scope = {}
            def factory(self, scope, name):
                return foo
            name = 'foo'
            scope_replacer = ScopeReplacer(scope, factory, name)
            args = (1, 2, 3)
            kwargs = {'a':1, 'b':2}
            self.assertEqual((args, kwargs), scope_replacer(*args, **kwargs))
    TestScopeReplacer('test___call__').run()

    #

# Generated at 2022-06-18 04:08:43.513885
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__(self, attr, value)"""
    # Test that __setattr__ raises an exception if the object has already
    # been replaced.
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_lazy_import import TestScopeReplacer
    import sys
    # Create a lazy object.
    lazy_import(globals(), '''
    from bzrlib.tests.test_lazy_import import TestScopeReplacer
    ''')
    # Replace the object with a real one.
    TestScopeReplacer._resolve()
    # Disable proxying.
    TestScopeReplacer._should_proxy = False
    # Try to set an attribute on the object.

# Generated at 2022-06-18 04:08:47.860544
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg: extra"

# Generated at 2022-06-18 04:08:59.145840
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:09:05.062927
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    bzrlib.lazy_import._should_proxy = False
    try:
        import bzrlib.tests
        bzrlib.tests.lazy_import_test_module_1.test_ScopeReplacer___setattr__()
    finally:
        bzrlib.lazy_import._should_proxy = True


# Generated at 2022-06-18 04:09:14.928087
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    assert str(e) == 'IllegalUseOfScopeReplacer(foo): bar'
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    assert str(e) == 'IllegalUseOfScopeReplacer(foo): bar: baz'
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    e._fmt = '%(name)s: %(msg)s'
    assert str(e) == 'foo: bar'
    e = IllegalUseOfScopeReplacer('foo', 'bar', 'baz')
    e._fmt = '%(name)s: %(msg)s: %(extra)s'

# Generated at 2022-06-18 04:09:21.392026
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False
    try:
        import bzrlib.tests.blackbox.test_selftest
        bzrlib.tests.blackbox.test_selftest.test_selftest_command.test_selftest_command()
    finally:
        bzrlib.lazy_import.ScopeReplacer._should_proxy = True


# Generated at 2022-06-18 04:09:31.691876
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Test(TestCase):
        def test_setattr(self):
            class Foo(object):
                def __init__(self):
                    self.bar = None
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            foo = ScopeReplacer(scope, factory, name)
            foo.bar = 'baz'
            self.assertEqual('baz', foo.bar)
            self.assertEqual('baz', scope[name].bar)
    Test('test_setattr').run()

# Generated at 2022-06-18 04:09:36.231329
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:09:44.447437
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    import bzrlib.branch
    assert bzrlib.branch.__class__.__name__ == 'ScopeReplacer'
    assert bzrlib.branch.__class__.__call__(bzrlib.branch) is bzrlib.branch
    assert bzrlib.branch.__class__.__call__(bzrlib.branch, 1, 2, 3) == (1, 2, 3)

# Generated at 2022-06-18 04:09:50.529039
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'name: msg'
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'name: msg: extra'


# Generated at 2022-06-18 04:09:56.632228
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    # Test that the lazy_import function works
    assert bzrlib.lazy_import.ScopeReplacer is ScopeReplacer
    # Test that the lazy_import function works
    assert bzrlib.lazy_import.IllegalUseOfScopeReplacer is IllegalUseOfScopeReplacer
    # Test that the lazy_import function works
    assert bzrlib.errors is errors
    # Test that the lazy_import function works
    assert bzrlib.osutils is osutils
    # Test that the lazy_import function

# Generated at 2022-06-18 04:09:59.114671
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s.startswith('IllegalUseOfScopeReplacer(')


# Generated at 2022-06-18 04:10:09.403258
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:10:20.390650
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    import bzrlib.tests
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import

# Generated at 2022-06-18 04:10:27.948729
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self, value):
            self.value = value
    class TestCase(TestCase):
        def test_getattribute(self):
            scope = {}
            def factory(replacer, scope, name):
                return TestObj(name)
            replacer = ScopeReplacer(scope, factory, 'test')
            self.assertEqual('test', replacer.value)
            self.assertEqual('test', scope['test'].value)

# Generated at 2022-06-18 04:10:32.094241
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should set attributes on the real object"""
    scope = {}
    def factory(self, scope, name):
        return object()
    name = 'foo'
    sr = ScopeReplacer(scope, factory, name)
    sr.bar = 'baz'
    assert scope[name].bar == 'baz'



# Generated at 2022-06-18 04:10:41.230559
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    # Test that the callable object is called.
    def my_func(arg):
        return arg
    bzrlib.lazy_import.lazy_import(globals(), 'my_func = my_func')
    assert my_func('foo') == 'foo'
    # Test that the callable object is called with arguments.
    def my_func_with_args(arg1, arg2):
        return arg1, arg2

# Generated at 2022-06-18 04:10:52.150912
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests import TestCase
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import as test_lazy_import
    import bzrlib.tests.test_lazy_import as test_lazy_import2
    import bzrlib.tests.test_lazy_import as test_lazy_import3
    import bzrlib.tests.test_lazy_import as test_lazy_import4
    import bzrlib.tests.test_lazy_import as test_lazy_import5
    import bzrlib.tests.test_lazy_import as test_lazy_import6
    import bzrlib.tests.test_l

# Generated at 2022-06-18 04:10:55.324350
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:10:59.699257
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__()"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)
    assert s == 'ScopeReplacer object \'name\' was used incorrectly: msg: extra'

# Generated at 2022-06-18 04:11:02.783661
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:11:06.966241
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:11:21.092452
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer

    class TestScopeReplacer(TestCase):

        def test_ScopeReplacer___setattr__(self):
            class Foo(object):
                pass
            foo = Foo()
            foo.bar = 'bar'
            scope = {}
            scope_replacer = ScopeReplacer(scope, lambda self, scope, name: foo,
                                           'foo')
            scope_replacer.bar = 'baz'
            self.assertEqual('baz', foo.bar)

    TestScopeReplacer('test_ScopeReplacer___setattr__').run()



# Generated at 2022-06-18 04:11:24.014106
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:11:32.768237
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self):
            self.attr = None
    class TestCase(TestCase):
        def test_setattr(self):
            scope = {}
            def factory(self, scope, name):
                return TestObj()
            replacer = ScopeReplacer(scope, factory, 'obj')
            replacer.attr = 'value'
            self.assertEqual('value', scope['obj'].attr)
    TestCase.run_tests()

# Generated at 2022-06-18 04:11:39.778917
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False

# Generated at 2022-06-18 04:11:51.775235
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    import bzrlib.tests
    lazy_import(globals(), '''
    from bzrlib.tests import TestCase
    ''')
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            from bzrlib.lazy_import import ScopeReplacer
            from bzrlib.lazy_import import lazy_import
            import bzrlib.tests
            lazy_import(globals(), '''
            from bzrlib.tests import TestCase
            ''')
            class TestScopeReplacer(TestCase):
                def test_ScopeReplacer___setattr__(self):
                    from bzrlib.lazy_import import ScopeReplacer

# Generated at 2022-06-18 04:11:55.696936
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s.startswith('IllegalUseOfScopeReplacer(')
    assert s.endswith(')')

# Generated at 2022-06-18 04:11:59.925790
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:12:11.383257
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False

# Generated at 2022-06-18 04:12:20.354158
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    # test that __str__ returns a str object
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    # test that __str__ returns a str object even if the exception message
    # contains unicode characters
    e = IllegalUseOfScopeReplacer('name', u'msg')
    s = str(e)
    assert isinstance(s, str)
    # test that __str__ returns a str object even if the exception message
    # contains non-ascii characters
    e = IllegalUseOfScopeReplacer('name', u'\u1234')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:12:29.551865
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            foo = Foo()
            scope = {}
            def factory(replacer, scope, name):
                return foo
            replacer = ScopeReplacer(scope, factory, 'foo')
            self.assertEqual(((1, 2), {'a': 3}), replacer(1, 2, a=3))
    TestScopeReplacer('test___call__').run()

    # Unit test for method __getattribute__ of class ScopeReplacer

# Generated at 2022-06-18 04:12:44.672237
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            from bzrlib.lazy_import import lazy_import
            def factory(self, scope, name):
                return lambda: 'foo'
            scope = {}
            lazy_import(scope, '''
            from bzrlib.lazy_import import ScopeReplacer
            ''')
            scope['test'] = ScopeReplacer(scope, factory, 'test')
            self.assertEqual('foo', scope['test']())
    Test('test_ScopeReplacer___call__').run()

    # Unit test for method __getattribute__ of class ScopeReplacer

# Generated at 2022-06-18 04:12:49.943302
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    # This test is here because it is hard to test the __str__ method
    # of an exception in a separate test module.
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg: extra"



# Generated at 2022-06-18 04:12:52.696990
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:12:56.008482
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:12:59.445427
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:13:07.784634
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class TestObject(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            scope = {}
            def factory(self, scope, name):
                return TestObject()
            name = 'test'
            scope_replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual(((1, 2), {'a': 'b'}), scope_replacer(1, 2, a='b'))
    TestScopeReplacer('test___call__').run()

    # Test that calling the object after it has been replaced works.
    scope = {}


# Generated at 2022-06-18 04:13:16.966983
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    import sys
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            # Test that ScopeReplacer.__setattr__() raises an exception when
            # _should_proxy is False.
            ScopeReplacer._should_proxy = False
            try:
                scope = {}
                def factory(self, scope, name):
                    return None
                name = 'foo'
                scope_replacer = ScopeReplacer(scope, factory, name)
                scope_replacer.foo = 'bar'
            finally:
                ScopeReplacer._should_proxy = True
            self.assertRaises(IllegalUseOfScopeReplacer,
                              scope_replacer.__setattr__, 'foo', 'bar')
    test_suite = TestCase

# Generated at 2022-06-18 04:13:19.404164
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() should return a str"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:13:27.933753
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    import bzrlib.branch
    assert bzrlib.branch.__class__.__name__ == 'ScopeReplacer'
    assert bzrlib.branch.__call__.__class__.__name__ == 'instancemethod'
    assert bzrlib.branch.__call__.__self__.__class__.__name__ == 'ScopeReplacer'
    assert bzrlib.branch.__call__.__self__._name == 'bzrlib.branch'
    assert bzrlib.br