

# Generated at 2022-06-18 04:03:56.162555
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import bzrlib.lazy_import
    bzrlib.lazy_import._ScopeReplacer = ScopeReplacer
    reload(bzrlib.lazy_import)
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.lazy_import import _ScopeReplacer
    from bzrlib.lazy_import import _should_proxy
    from bzrlib.lazy_import import _resolve
    from bzrlib.lazy_import import _factory
    from bzrlib.lazy_import import _name
    from bzrlib.lazy_import import _real_obj
   

# Generated at 2022-06-18 04:04:07.746739
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests
    import bzrlib.tests.blackbox
    import bzrlib.tests.blackbox.test_selftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest
    import bzrlib.tests.blackbox.test_selftest.TestSelftest._run_tests
    import bzrlib.tests.blackbox.test_selftest.TestSelftest._run_tests.TestSelftest._run_tests
    import bzrlib.tests.blackbox.test_selftest.TestSelftest._run_tests.TestSelftest._run_tests.TestSelftest._run_tests
    import bzrlib.tests.blackbox.test_selftest.TestSelftest._run_tests.TestSel

# Generated at 2022-06-18 04:04:17.509863
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return 'real_obj'
            name = 'name'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.__setattr__('attr', 'value')
            self.assertEqual('value', scope_replacer.attr)
            self.assertEqual('value', scope[name].attr)
    TestScopeReplacer('test_ScopeReplacer___setattr__').run()

# Generated at 2022-06-18 04:04:20.213976
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:04:25.032248
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg: extra"

# Generated at 2022-06-18 04:04:34.771158
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    import bzrlib.tests
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import

# Generated at 2022-06-18 04:04:37.385597
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    # __str__ must return a str.
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)
    assert s == 'ScopeReplacer object \'name\' was used incorrectly: msg: extra'


# Generated at 2022-06-18 04:04:47.111855
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import sys
    import bzrlib.lazy_import
    reload(bzrlib.lazy_import)
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import lazy_import_function
    from bzrlib.lazy_import import lazy_import_module
    from bzrlib.lazy_import import lazy_import_symbol
    from bzrlib.lazy_import import lazy_import_symbols
    from bzrlib.lazy_import import lazy_import_symbols_from_module
    from bzrlib.lazy_import import lazy_import_symbols

# Generated at 2022-06-18 04:04:58.029145
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return 'real_obj'
            name = 'name'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.foo = 'bar'
            self.assertEqual('bar', scope_replacer.foo)
            self.assertEqual('bar', scope['name'].foo)
            self.assertEqual('bar', scope_replacer._real_obj.foo)

# Generated at 2022-06-18 04:05:09.237320
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests import TestCase
    import bzrlib.tests.test_lazy_import
    class TestScopeReplacer(TestCase):
        def test_setattr(self):
            # Test that setattr works on the object.
            # This is a regression test for bug #539096
            def factory(self, scope, name):
                return bzrlib.tests.test_lazy_import.TestLazyImport()
            scope = {}
            lazy_import(scope, '''
            from bzrlib.lazy_import import ScopeReplacer
            import bzrlib.tests.test_lazy_import
            ''')
            scope['test_obj'] = ScopeReplacer(scope, factory, 'test_obj')


# Generated at 2022-06-18 04:05:20.666170
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode string"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:05:24.363042
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:05:29.243828
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'name: msg'


# Generated at 2022-06-18 04:05:32.874937
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should set the attribute on the real object"""
    scope = {}
    def factory(self, scope, name):
        return object()
    replacer = ScopeReplacer(scope, factory, 'foo')
    replacer.bar = 'baz'
    assert scope['foo'].bar == 'baz'

# Generated at 2022-06-18 04:05:35.695068
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:05:47.286482
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    assert isinstance(e.__unicode__(), unicode)
    assert isinstance(e.__str__(), str)
    assert isinstance(e.__repr__(), str)
    assert isinstance(e.__str__(), str)
    assert isinstance(e.__unicode__(), unicode)
    assert isinstance(e.__repr__(), str)
    assert isinstance(e.__str__(), str)
    assert isinstance(e.__unicode__(), unicode)
    assert isinstance(e.__repr__(), str)
    assert isinstance(e.__str__(), str)
    assert isinstance(e.__unicode__(), unicode)
   

# Generated at 2022-06-18 04:05:50.470826
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:05:58.074442
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    import sys
    class Test(TestCase):
        def test_getattribute(self):
            def factory(self, scope, name):
                return 42
            scope = {}
            name = 'foo'
            scope[name] = ScopeReplacer(scope, factory, name)
            self.assertEqual(42, scope[name])
    test = Test('test_getattribute')
    test.run()

# Generated at 2022-06-18 04:06:01.337678
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:06:04.478341
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object."""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:06:19.728496
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self, value):
            self.value = value
        def __getattribute__(self, attr):
            if attr == 'value':
                return object.__getattribute__(self, attr)
            return 'TestObj.%s' % attr
    class TestScopeReplacer(TestCase):
        def test_getattribute(self):
            scope = {}
            def factory(self, scope, name):
                return TestObj(name)
            obj = ScopeReplacer(scope, factory, 'obj')
            self.assertEqual(obj.value, 'obj')
            self.assertEqual(obj.foo, 'TestObj.foo')
            self

# Generated at 2022-06-18 04:06:28.475193
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()

    This method is called by the unicode() builtin.
    """
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    # Check that the unicode object is not empty
    assert len(u) > 0
    # Check that the unicode object is not a str
    assert not isinstance(u, str)
    # Check that the unicode object is a unicode object
    assert isinstance(u, unicode)
    # Check that the unicode object contains the expected string
    assert u == u'ScopeReplacer object \'name\' was used incorrectly: msg: extra'


# Generated at 2022-06-18 04:06:39.117758
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            # __call__(self, *args, **kwargs)
            # Calling a ScopeReplacer should call the real object
            scope = {}
            def factory(self, scope, name):
                return lambda *args, **kwargs: (args, kwargs)
            lazy_import(scope, '''
            from bzrlib.lazy_import import ScopeReplacer
            ''')
            ScopeReplacer(scope, factory, 'foo')
            self.assertEqual(((1, 2), {'a':3}), scope['foo'](1, 2, a=3))
    # test_ScopeReplacer___call__

# Generated at 2022-06-18 04:06:49.952726
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            class Foo(object):
                def __init__(self):
                    self.bar = None
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.bar = 'baz'
            self.assertEqual('baz', scope_replacer.bar)
            self.assertEqual('baz', scope[name].bar)
            self.assertEqual('baz', scope_replacer.bar)

# Generated at 2022-06-18 04:06:57.501039
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # test __setattr__
    # __setattr__ is called when an attribute assignment is attempted.
    # This method attempts to delegate the assignment to the real object.
    # If the real object has not yet been created, it will be created.
    # If the real object has already been created, the assignment will
    # be delegated to it.
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer

# Generated at 2022-06-18 04:07:01.356242
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__() should return a str object."""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:07:05.971484
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:07:08.842961
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:07:20.019839
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    # Test that the callable is called.
    def f(x):
        return x
    assert bzrlib.branch(f) == f
    # Test that the callable is called with arguments.
    def f(x, y):
        return x, y
    assert bzrlib.branch(f, 1, y=2) == (1, 2)
    # Test that the callable is called with keyword arguments.
    def f(x, y):
        return x, y
    assert bzr

# Generated at 2022-06-18 04:07:24.236377
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    if not isinstance(u, unicode):
        raise AssertionError('IllegalUseOfScopeReplacer.__unicode__() should return a unicode object, not %r' % (type(u),))

# Generated at 2022-06-18 04:07:33.818624
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:07:36.765285
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:07:44.530664
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False

# Generated at 2022-06-18 04:07:52.889382
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self):
            self.attr = None
    class TestCase(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return TestObj()
            obj = ScopeReplacer(scope, factory, 'obj')
            obj.attr = 'value'
            self.assertEqual('value', scope['obj'].attr)
    TestCase().test_ScopeReplacer___setattr__()

# Generated at 2022-06-18 04:07:58.820260
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """Unit test for method __str__ of class IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert str(e) == 'msg: extra'
    assert unicode(e) == u'msg: extra'
    assert repr(e) == "IllegalUseOfScopeReplacer('msg: extra')"



# Generated at 2022-06-18 04:08:08.135172
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    import bzrlib.trace
    import sys
    import traceback
    import unittest
    class TestCase(unittest.TestCase):
        def test_ScopeReplacer___call__(self):
            def test_func():
                """Return a string"""
                return 'test_func'
            def test_func_factory(self, scope, name):
                """Return a function"""
                return test_func
            scope = {}
            bzrlib.lazy_import.ScopeReplacer(scope, test_func_factory, 'test_func')
            self.assertEqual('test_func', scope['test_func']())

# Generated at 2022-06-18 04:08:16.138581
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    # This test is here because the method is defined in this file.
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_IllegalUseOfScopeReplacer___unicode__(self):
            e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
            self.assertIsInstance(unicode(e), unicode)

    Test('test_IllegalUseOfScopeReplacer___unicode__').run()



# Generated at 2022-06-18 04:08:19.243134
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:08:31.012286
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    # This test is needed because IllegalUseOfScopeReplacer.__unicode__()
    # is implemented using IllegalUseOfScopeReplacer._format() which
    # returns a str object.
    #
    # The test is needed because IllegalUseOfScopeReplacer.__unicode__()
    # is used by the bzrlib.trace.show_error_in_browser() function.
    #
    # The test is needed because the bzrlib.trace.show_error_in_browser()
    # function uses the unicode() function to convert the exception
    # message to a unicode object.
    #
    # The test is needed because the unicode() function uses the
    # __unicode__() method of the exception object.
    #

# Generated at 2022-06-18 04:08:35.562189
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'ScopeReplacer object \'name\' was used incorrectly: msg: extra'

# Generated at 2022-06-18 04:08:51.898996
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    class Foo(object):
        def __init__(self, value):
            self.value = value
    def factory(self, scope, name):
        return Foo(self.value)
    scope = {}
    name = 'foo'
    value = 'bar'
    replacer = ScopeReplacer(scope, factory, name)
    replacer.value = value
    assert scope[name].value == value

# Generated at 2022-06-18 04:08:56.442679
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    """__setattr__ should set attributes on the real object"""
    scope = {}
    def factory(self, scope, name):
        return object()
    replacer = ScopeReplacer(scope, factory, 'foo')
    replacer.bar = 'baz'
    assert scope['foo'].bar == 'baz'


# Generated at 2022-06-18 04:09:05.274053
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_setattr(self):
            class Foo(object):
                def __init__(self):
                    self.bar = 'bar'
            scope = {}
            def factory(self, scope, name):
                return Foo()
            replacer = ScopeReplacer(scope, factory, 'foo')
            replacer.bar = 'baz'
            self.assertEqual('baz', replacer.bar)
            self.assertEqual('baz', scope['foo'].bar)
    TestScopeReplacer('test_setattr').run()

# Generated at 2022-06-18 04:09:08.669564
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:09:16.795765
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    class Test(TestCase):
        def test_getattribute(self):
            scope = {}
            lazy_import(scope, '''
            from bzrlib import (
                errors,
                osutils,
                branch,
                )
            import bzrlib.branch
            ''')
            self.assertEqual(scope['errors'].__class__, ScopeReplacer)
            self.assertEqual(scope['osutils'].__class__, ScopeReplacer)
            self.assertEqual(scope['branch'].__class__, ScopeReplacer)
            self.assertEqual(scope['bzrlib'].__class__, ScopeReplacer)

# Generated at 2022-06-18 04:09:25.163986
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    import sys
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            class Foo(object):
                pass
            foo = Foo()
            foo.bar = 'bar'
            self.assertEqual('bar', foo.bar)
            foo.bar = 'baz'
            self.assertEqual('baz', foo.bar)
            foo.bar = 'qux'
            self.assertEqual('qux', foo.bar)
            foo.bar = 'quux'
            self.assertEqual('quux', foo.bar)
            foo.bar = 'corge'
            self.assertEqual('corge', foo.bar)
            foo.bar = 'grault'

# Generated at 2022-06-18 04:09:34.388543
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            import sys
            import bzrlib.lazy_import
            bzrlib.lazy_import._should_proxy = False

# Generated at 2022-06-18 04:09:43.316364
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            lazy_import(globals(), '''
            from bzrlib.lazy_import import ScopeReplacer
            ''')
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            scope[name] = ScopeReplacer(scope, factory, name)
            self.assertEqual(((1, 2), {'a': 3}), scope[name](1, 2, a=3))
    test_ScopeReplacer___

# Generated at 2022-06-18 04:09:47.774189
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert isinstance(e.__unicode__(), unicode)
    assert e.__unicode__() == u"ScopeReplacer object 'name' was used incorrectly: msg: extra"

# Generated at 2022-06-18 04:09:54.998705
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    class TestScopeReplacer(TestCase):
        def test_call(self):
            class Foo(object):
                def __init__(self, a, b, c):
                    self.a = a
                    self.b = b
                    self.c = c
                def __call__(self, a, b, c):
                    return (a, b, c)
            def factory(self, scope, name):
                return Foo(1, 2, 3)
            scope = {}
            lazy_import(scope, '''
            from bzrlib.lazy_import import ScopeReplacer
            ''')
            replacer = ScopeReplacer(scope, factory, 'foo')

# Generated at 2022-06-18 04:10:21.913308
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self):
            self.attr = None
    class TestCase(TestCase):
        def test_setattr(self):
            scope = {}
            def factory(self, scope, name):
                return TestObj()
            name = 'test'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.attr = 'value'
            self.assertEqual('value', scope[name].attr)
    TestCase.run_tests()

# Generated at 2022-06-18 04:10:30.167626
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            def factory(self, scope, name):
                return lambda x: x
            scope = {}
            name = 'foo'
            obj = ScopeReplacer(scope, factory, name)
            self.assertEqual(obj(1), 1)
            self.assertEqual(obj(2), 2)
            self.assertEqual(obj(3), 3)
    test_ScopeReplacer___call__ = TestScopeReplacer('test___call__').test___call__


# Generated at 2022-06-18 04:10:38.123180
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            scope = {}
            def factory(self, scope, name):
                return 'foo'
            name = 'foo'
            obj = ScopeReplacer(scope, factory, name)
            self.assertEqual('foo', obj())
    # Unit test for method __getattribute__ of class ScopeReplacer

# Generated at 2022-06-18 04:10:42.521556
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:10:52.669531
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___getattribute__(self):
            class Foo(object):
                def __init__(self, x):
                    self.x = x
                def bar(self):
                    return self.x
            def factory(self, scope, name):
                return Foo(name)
            scope = {}
            name = 'foo'
            obj = ScopeReplacer(scope, factory, name)
            self.assertEqual(obj.bar(), name)
    test_ScopeReplacer___getattribute__ = TestScopeReplacer(
        'test_ScopeReplacer___getattribute__').test_ScopeReplacer___getattribute__

# Generated at 2022-06-18 04:10:56.385237
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:10:59.925171
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object, not unicode"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert not isinstance(s, unicode)

# Generated at 2022-06-18 04:11:03.629610
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    # __setattr__ of class ScopeReplacer
    # This is tested by test_lazy_import.TestLazyImport.test_lazy_import_setattr
    pass # tested by test_lazy_import.TestLazyImport.test_lazy_import_setattr


# Generated at 2022-06-18 04:11:07.422567
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:11:16.355842
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            scope = {}
            def factory(self, scope, name):
                return Foo()
            scope_replacer = ScopeReplacer(scope, factory, 'foo')
            self.assertEqual(((), {}), scope_replacer())
            self.assertEqual(((1,), {}), scope_replacer(1))
            self.assertEqual(((1, 2), {}), scope_replacer(1, 2))

# Generated at 2022-06-18 04:11:48.314082
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    # Test that the ScopeReplacer object is replaced with the real object
    # when an attribute is accessed.
    assert isinstance(bzrlib, bzrlib.lazy_import.ScopeReplacer)
    assert isinstance(bzrlib.branch, bzrlib.lazy_import.ScopeReplacer)
    assert isinstance(branch, bzrlib.lazy_import.ScopeReplacer)

# Generated at 2022-06-18 04:11:52.369555
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:12:00.051247
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Foo(object):
        def __init__(self, x):
            self.x = x
        def bar(self):
            return self.x
    class TestScopeReplacer(TestCase):
        def test_getattribute(self):
            scope = {}
            def factory(self, scope, name):
                return Foo(42)
            replacer = ScopeReplacer(scope, factory, 'foo')
            self.assertEqual(42, replacer.bar())
            self.assertEqual(42, scope['foo'].bar())
            self.assertEqual(42, replacer.bar())
            self.assertEqual(42, scope['foo'].bar())

# Generated at 2022-06-18 04:12:05.531728
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    import bzrlib.tests
    lazy_import(globals(), '''
    import bzrlib.tests
    ''')
    # call the method
    bzrlib.tests.test_suite()



# Generated at 2022-06-18 04:12:16.637877
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __init__(self, a, b, c):
                    self.a = a
                    self.b = b
                    self.c = c
            def factory(self, scope, name):
                return Foo(1, 2, 3)
            scope = {}
            name = 'foo'
            foo = ScopeReplacer(scope, factory, name)
            self.assertEqual(1, foo.a)
            self.assertEqual(2, foo.b)
            self.assertEqual(3, foo.c)
    test_ScopeReplacer___call__.__test__ = False
   

# Generated at 2022-06-18 04:12:21.853500
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """IllegalUseOfScopeReplacer.__str__()"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert str(e) == 'name: msg: extra'
    assert unicode(e) == u'name: msg: extra'



# Generated at 2022-06-18 04:12:30.673409
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __init__(self, *args, **kwargs):
                    self.args = args
                    self.kwargs = kwargs
                def __call__(self, *args, **kwargs):
                    return (self.args, self.kwargs, args, kwargs)
            foo = Foo(1, 2, 3, a=4, b=5, c=6)
            scope = {}
            name = 'foo'
            def factory(self, scope, name):
                return foo
            scope_replacer = ScopeReplacer(scope, factory, name)

# Generated at 2022-06-18 04:12:35.702185
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:12:39.184273
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:12:42.011887
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)
