

# Generated at 2022-06-18 04:03:46.211727
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return args, kwargs
            foo = Foo()
            scope = {}
            def factory(self, scope, name):
                return foo
            name = 'foo'
            replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual(((), {}), replacer())
            self.assertEqual(((1, 2, 3), {'a': 'b'}), replacer(1, 2, 3, a='b'))
            self.assertEqual(foo, scope[name])
    TestScopeReplacer

# Generated at 2022-06-18 04:03:55.259929
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    import bzrlib
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            def factory(self, scope, name):
                return bzrlib
            scope = {}
            name = 'bzrlib'
            self.assertRaises(IllegalUseOfScopeReplacer, ScopeReplacer, scope, factory, name)
    Test().test_ScopeReplacer___call__()



# Generated at 2022-06-18 04:03:58.777403
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:04:09.664228
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_lazy_import import TestScopeReplacer
    # Test that __setattr__ works as expected.
    class TestScopeReplacer(TestCase):
        def test_setattr(self):
            # Test that __setattr__ works as expected.
            # Create a scope replacer and set an attribute on it.
            scope = {}
            def factory(self, scope, name):
                return object()
            lazy_import(scope, '''
            from bzrlib.tests.test_lazy_import import TestScopeReplacer
            TestScopeReplacer.test_setattr_obj = TestScopeReplacer(scope, factory, 'test_setattr_obj')
            ''')


# Generated at 2022-06-18 04:04:14.364173
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s.startswith('name')
    assert s.endswith('msg')


# Generated at 2022-06-18 04:04:24.547322
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            class Foo(object):
                def __init__(self):
                    self.bar = None
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            foo = ScopeReplacer(scope, factory, name)
            foo.bar = 'baz'
            self.assertEqual('baz', foo.bar)
            self.assertEqual('baz', scope['foo'].bar)
    TestScopeReplacer('test_ScopeReplacer___setattr__').run()

# Generated at 2022-06-18 04:04:34.111169
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __init__(self, a, b):
                    self.a = a
                    self.b = b
                def __call__(self, c, d):
                    return self.a + self.b + c + d
            scope = {}
            def factory(self, scope, name):
                return Foo(1, 2)
            scope_replacer = ScopeReplacer(scope, factory, 'foo')
            self.assertEqual(6, scope_replacer(3, 4))
    TestScopeReplacer('test___call__').run()


# Generated at 2022-06-18 04:04:40.279291
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    import bzrlib.tests.blackbox
    ''')
    bzrlib.tests.blackbox.run_bzr('selftest')
    return # unit test for method __call__ of class ScopeReplacer



# Generated at 2022-06-18 04:04:47.328217
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            import bzrlib.lazy_import
            import bzrlib.tests.blackbox
            bzrlib.lazy_import.lazy_import(globals(), '''
            import bzrlib.tests.blackbox
            ''')
            self.assertEqual(bzrlib.tests.blackbox.TestCase, TestCase)
    test_ScopeReplacer___call__()



# Generated at 2022-06-18 04:04:58.269104
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = True

# Generated at 2022-06-18 04:05:16.318294
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    # test with a function
    def foo(a, b):
        return a + b
    def factory(self, scope, name):
        return foo
    scope = {}
    name = 'foo'
    bzrlib.lazy_import.ScopeReplacer(scope, factory, name)
    assert scope[name](1, 2) == 3
    # test with a class
    class Foo(object):
        def __init__(self, a, b):
            self.a = a
            self.b = b

# Generated at 2022-06-18 04:05:24.011106
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return args, kwargs
            foo = Foo()
            scope = {}
            def factory(self, scope, name):
                return foo
            replacer = ScopeReplacer(scope, factory, 'foo')
            self.assertEqual(((), {}), replacer())
            self.assertEqual(((1,), {}), replacer(1))
            self.assertEqual(((1,2), {}), replacer(1,2))

# Generated at 2022-06-18 04:05:33.455954
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    import sys
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False

# Generated at 2022-06-18 04:05:43.156920
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            class Foo(object):
                def __init__(self):
                    self.bar = None
            foo = Foo()
            scope = {}
            def factory(self, scope, name):
                return foo
            name = 'foo'
            replacer = ScopeReplacer(scope, factory, name)
            replacer.bar = 'baz'
            self.assertEqual('baz', foo.bar)
    TestScopeReplacer('test_ScopeReplacer___setattr__').run()

# Generated at 2022-06-18 04:05:49.549057
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def setUp(self):
            def factory(self, scope, name):
                return lambda: 'foo'
            self.scope = {}
            self.replacer = ScopeReplacer(self.scope, factory, 'foo')
        def test___call__(self):
            self.assertEqual('foo', self.replacer())
    TestScopeReplacer('test___call__').run()


# Generated at 2022-06-18 04:06:00.912886
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestClass(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return 'real_obj'
            name = 'name'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.__setattr__('attr', 'value')
            self.assertEqual('value', scope_replacer.attr)
            self.assertEqual('value', scope[name].attr)
            self.assertEqual('value', scope_replacer._real_obj.attr)
    TestClass('test_ScopeReplacer___setattr__').run()

# Generated at 2022-06-18 04:06:03.546703
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    """__getattribute__(self, attr)"""
    # FIXME: implement this test
    raise NotImplementedError(
        "Test for method ScopeReplacer.__getattribute__ not implemented")


# Generated at 2022-06-18 04:06:07.522757
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:06:10.948817
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:06:15.896561
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:06:26.759354
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u.startswith('name')
    assert u.endswith('msg')


# Generated at 2022-06-18 04:06:33.346903
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            class Foo(object):
                def __init__(self, value):
                    self.value = value
            def factory(self, scope, name):
                return Foo(name)
            scope = {}
            name = 'foo'
            ScopeReplacer(scope, factory, name)
            self.assertEqual(scope[name].value, name)
            scope[name].value = 'bar'
            self.assertEqual(scope[name].value, 'bar')
            self.assertRaises(IllegalUseOfScopeReplacer,
                              setattr, scope[name], 'value', 'baz')
   

# Generated at 2022-06-18 04:06:43.127936
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    from bzrlib.tests import TestCase
    ''')
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            def factory(self, scope, name):
                return lambda: 'called'
            scope = {}
            name = 'test'
            obj = ScopeReplacer(scope, factory, name)
            self.assertEqual('called', obj())
            self.assertEqual('called', scope[name]())
    TestScopeReplacer('test___call__').run()



# Generated at 2022-06-18 04:06:45.638991
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:06:50.669294
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)
    assert u == u'name: msg'

# Generated at 2022-06-18 04:06:54.697050
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    # __str__ should always return a 'str' object
    # never a 'unicode' object.
    assert not isinstance(s, unicode)


# Generated at 2022-06-18 04:06:57.067130
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:07:08.147462
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer___call__(TestCase):
        def test_ScopeReplacer___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            from bzrlib.lazy_import import lazy_import
            from bzrlib.lazy_import import _module_import
            from bzrlib.lazy_import import _module_import_and_submodules
            from bzrlib.lazy_import import _module_import_and_submodules_by_name
            from bzrlib.lazy_import import _module_import_by_name
            from bzrlib.lazy_import import _module_import_by_name_and_attr
            from bzrlib.lazy_import import _module_import

# Generated at 2022-06-18 04:07:17.090721
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Test(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return object()
            name = 'name'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.attr = 'value'
            self.assertEqual('value', scope_replacer.attr)
    Test('test_ScopeReplacer___setattr__').run()

# Generated at 2022-06-18 04:07:20.417470
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:07:30.285298
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:07:33.109296
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object."""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:07:35.777451
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:07:39.087277
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:07:42.660883
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:07:46.813989
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:07:50.560877
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:07:53.999806
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)
    assert s.startswith('IllegalUseOfScopeReplacer')
    assert s.endswith('msg')


# Generated at 2022-06-18 04:07:57.378616
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)


# Generated at 2022-06-18 04:08:01.314987
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object."""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = e.__unicode__()
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:08:20.884604
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            def _factory(self, scope, name):
                return 'foo'
            scope = {}
            name = 'bar'
            obj = ScopeReplacer(scope, _factory, name)
            self.assertEqual('foo', obj())
            self.assertEqual('foo', scope[name])
            self.assertRaises(IllegalUseOfScopeReplacer, obj)
    TestScopeReplacer('test___call__').run()

# Generated at 2022-06-18 04:08:32.373263
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_lazy_import import TestScopeReplacer
    from bzrlib.tests.test_lazy_import import TestScopeReplacer_factory
    from bzrlib.tests.test_lazy_import import TestScopeReplacer_factory_2
    from bzrlib.tests.test_lazy_import import TestScopeReplacer_factory_3
    from bzrlib.tests.test_lazy_import import TestScopeReplacer_factory_4
    from bzrlib.tests.test_lazy_import import TestScopeReplacer_factory_5
    from bzrlib.tests.test_lazy_import import TestScopeReplacer_f

# Generated at 2022-06-18 04:08:41.999581
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__()"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert e.__unicode__() == u'ScopeReplacer object \'name\' was used incorrectly: msg: extra'
    e = IllegalUseOfScopeReplacer('name', 'msg', None)
    assert e.__unicode__() == u'ScopeReplacer object \'name\' was used incorrectly: msg'
    e = IllegalUseOfScopeReplacer('name', 'msg')
    assert e.__unicode__() == u'ScopeReplacer object \'name\' was used incorrectly: msg'
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    e._fmt = '%(name)s'
    assert e.__unicode__() == u'name'
   

# Generated at 2022-06-18 04:08:44.199460
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:08:55.626948
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import

# Generated at 2022-06-18 04:09:04.140671
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestObj(object):
        def __init__(self):
            self.attr = None
    class TestScopeReplacer(TestCase):
        def test_setattr(self):
            scope = {}
            def factory(self, scope, name):
                return TestObj()
            name = 'test_obj'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.attr = 'test'
            self.assertEqual('test', scope[name].attr)
    TestScopeReplacer('test_setattr').run()

# Generated at 2022-06-18 04:09:08.098651
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)

# Generated at 2022-06-18 04:09:16.422784
# Unit test for method __getattribute__ of class ScopeReplacer
def test_ScopeReplacer___getattribute__():
    # Test that __getattribute__ works as expected.
    class Foo(object):
        def __init__(self, name):
            self.name = name
        def __getattribute__(self, attr):
            return object.__getattribute__(self, attr)
    foo = Foo('foo')
    scope = {}
    factory = lambda self, scope, name: foo
    name = 'foo'
    replacer = ScopeReplacer(scope, factory, name)
    assert replacer.name == 'foo'
    assert replacer.name == 'foo'
    assert replacer.name == 'foo'
    assert replacer.name == 'foo'
    assert replacer.name == 'foo'
    assert replacer.name == 'foo'
    assert replacer.name == 'foo'

# Generated at 2022-06-18 04:09:24.957584
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.lazy_import import lazy_import
    lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_lazy_import import TestLazyImport
    from bzrlib.tests.test_lazy_import import TestLazyImportWithImportError
    from bzrlib.tests.test_lazy_import import TestLazyImportWithImportError2
    from bzrlib.tests.test_lazy_import import TestLazyImportWithImportError3
    from bzrlib.tests.test_lazy_import import TestLazyImportWithImportError4

# Generated at 2022-06-18 04:09:30.090547
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    s = str(e)
    assert isinstance(s, str)
    assert s == "ScopeReplacer object 'name' was used incorrectly: msg: extra"

# Generated at 2022-06-18 04:10:08.376692
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    s = str(e)
    assert isinstance(s, str)

# Generated at 2022-06-18 04:10:16.420736
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ of IllegalUseOfScopeReplacer"""
    e = IllegalUseOfScopeReplacer('name', 'msg', 'extra')
    assert str(e) == 'name was used incorrectly: msg: extra'
    assert repr(e) == "IllegalUseOfScopeReplacer('name', 'msg', 'extra')"
    e = IllegalUseOfScopeReplacer('name', 'msg')
    assert str(e) == 'name was used incorrectly: msg'
    assert repr(e) == "IllegalUseOfScopeReplacer('name', 'msg')"



# Generated at 2022-06-18 04:10:22.392831
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests.blackbox import ExternalBase


# Generated at 2022-06-18 04:10:23.750059
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    """__call__(self, *args, **kwargs)"""


# Generated at 2022-06-18 04:10:29.989008
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class Foo(object):
        pass
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return Foo()
            name = 'foo'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.bar = 'baz'
            self.assertEqual('baz', scope_replacer.bar)
            self.assertEqual('baz', scope['foo'].bar)

# Generated at 2022-06-18 04:10:39.841097
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    import bzrlib.tests.test_lazy_import
    ''')
    # Test that the __call__ method of class ScopeReplacer works as expected.
    # This is a simple test, just calling the method.
    #   >>> bzrlib.tests.test_lazy_import.test_ScopeReplacer___call__()
    #   Called bzrlib.tests.test_lazy_import.test_ScopeReplacer___call__()
    #   >>>

# Generated at 2022-06-18 04:10:51.655517
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    class TestScopeReplacer(TestCase):
        def test___call__(self):
            from bzrlib.lazy_import import ScopeReplacer
            class Foo(object):
                def __call__(self, *args, **kwargs):
                    return (args, kwargs)
            foo = Foo()
            scope = {}
            def factory(replacer, scope, name):
                return foo
            replacer = ScopeReplacer(scope, factory, 'foo')
            self.assertEqual(((1, 2, 3), {'a': 1, 'b': 2}),
                             replacer(1, 2, 3, a=1, b=2))
    TestScopeReplacer('test___call__').run()

# Generated at 2022-06-18 04:10:55.505993
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:11:02.589765
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import lazy_import
    from bzrlib.lazy_import import ScopeReplacer
    class Test(TestCase):
        def test_ScopeReplacer___call__(self):
            scope = {}
            def factory(self, scope, name):
                return 'foo'
            name = 'bar'
            scope_replacer = ScopeReplacer(scope, factory, name)
            self.assertEqual('foo', scope_replacer())

# Generated at 2022-06-18 04:11:13.105399
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.lazy_import import lazy_import
    from bzrlib.tests import TestCase
    from bzrlib.tests.test_lazy_import import TestScopeReplacer

    class TestScopeReplacer___setattr__(TestScopeReplacer):

        def test_setattr(self):
            # Test that __setattr__ works as expected.
            # This is a bit of a hack, but it's the only way to test it.
            # We need to make sure that the object is replaced before
            # we can test it.
            self.assertEqual(self.obj.__class__, ScopeReplacer)
            self.obj.foo = 'bar'
            self.assertEqual(self.obj.foo, 'bar')

# Generated at 2022-06-18 04:11:55.381084
# Unit test for method __str__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___str__():
    """__str__ should return a str object"""
    e = IllegalUseOfScopeReplacer('foo', 'bar')
    s = str(e)
    assert isinstance(s, str)
    assert s == "foo was used incorrectly: bar"


# Generated at 2022-06-18 04:11:59.514322
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:12:03.749058
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """__unicode__ should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:12:13.428982
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestScopeReplacer(TestCase):
        def test_ScopeReplacer___setattr__(self):
            scope = {}
            def factory(self, scope, name):
                return 'real_obj'
            name = 'name'
            scope_replacer = ScopeReplacer(scope, factory, name)
            scope_replacer.__setattr__('attr', 'value')
            self.assertEqual('value', scope_replacer.attr)
            self.assertEqual('value', scope[name].attr)
    TestScopeReplacer('test_ScopeReplacer___setattr__').run()

# Generated at 2022-06-18 04:12:21.347269
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.tests
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_import
    import bzrlib.tests.test_lazy_

# Generated at 2022-06-18 04:12:30.494202
# Unit test for method __call__ of class ScopeReplacer
def test_ScopeReplacer___call__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.lazy_import(globals(), '''
    from bzrlib import (
        errors,
        osutils,
        branch,
        )
    import bzrlib.branch
    ''')
    # Test that the object can be called
    bzrlib.branch.Branch()
    # Test that the object can be called with arguments
    bzrlib.branch.Branch.open('.')
    # Test that the object can be called with keyword arguments
    bzrlib.branch.Branch.open(bzrdir='.')
    # Test that the object can be called with arguments and keyword arguments

# Generated at 2022-06-18 04:12:39.185473
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    from bzrlib.tests import TestCase
    from bzrlib.lazy_import import ScopeReplacer
    class TestClass(object):
        def __init__(self):
            self.a = 1
    scope = {}
    def factory(self, scope, name):
        return TestClass()
    name = 'test'
    scope_replacer = ScopeReplacer(scope, factory, name)
    scope_replacer.a = 2
    self.assertEqual(2, scope_replacer.a)
    self.assertEqual(2, scope[name].a)

# Generated at 2022-06-18 04:12:42.671796
# Unit test for method __unicode__ of class IllegalUseOfScopeReplacer
def test_IllegalUseOfScopeReplacer___unicode__():
    """IllegalUseOfScopeReplacer.__unicode__() should return a unicode object"""
    e = IllegalUseOfScopeReplacer('name', 'msg')
    u = unicode(e)
    assert isinstance(u, unicode)


# Generated at 2022-06-18 04:12:48.596729
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    bzrlib.lazy_import.ScopeReplacer._should_proxy = False
    try:
        import bzrlib.tests.blackbox.test_selftest
        bzrlib.tests.blackbox.test_selftest.test_selftest()
    finally:
        bzrlib.lazy_import.ScopeReplacer._should_proxy = True



# Generated at 2022-06-18 04:12:55.425215
# Unit test for method __setattr__ of class ScopeReplacer
def test_ScopeReplacer___setattr__():
    import bzrlib.lazy_import
    reload(bzrlib.lazy_import)
    from bzrlib.lazy_import import ScopeReplacer
    from bzrlib.lazy_import import IllegalUseOfScopeReplacer
    def factory(self, scope, name):
        return self
    scope = {}
    name = 'name'
    obj = ScopeReplacer(scope, factory, name)